<?php

require_once __DIR__ . '/functions/core_functions.php';
require_once __DIR__ . '/functions/config_functions.php';
require_once __DIR__ . '/functions/user_functions.php';
require_once __DIR__ . '/functions/search_functions.php';
require_once __DIR__ . '/functions/message_functions.php';
require_once __DIR__ . '/functions/post_functions.php';
require_once __DIR__ . '/functions/feed_functions.php';
require_once __DIR__ . '/functions/like_functions.php';
require_once __DIR__ . '/functions/notification_functions.php';
require_once __DIR__ . '/functions/payment_functions.php';
require_once __DIR__ . '/functions/comment_functions.php';
require_once __DIR__ . '/functions/explore_functions.php';
require_once __DIR__ . '/functions/profile_functions.php';
require_once __DIR__ . '/functions/reels_functions.php';
require_once __DIR__ . '/functions/count_postview_functions.php';
require_once __DIR__ . '/functions/images_functions.php';
require_once __DIR__ . '/functions/creators_functions.php';
require_once __DIR__ . '/functions/creator_dashboard_functions.php';
require_once __DIR__ . '/functions/follow_unfollow_functions.php';
require_once __DIR__ . '/functions/chat_functions.php';
require_once __DIR__ . '/functions/bookmarks_functions.php';
require_once __DIR__ . '/functions/widget_functions.php';
require_once __DIR__ . '/functions/advertisement_functions.php';
require_once __DIR__ . '/functions/podcast_ad_functions.php';
require_once __DIR__ . '/functions/announcement_functions.php';
require_once __DIR__ . '/functions/subscription_functions.php';
require_once __DIR__ . '/functions/live_tip_functions.php';
require_once __DIR__ . '/functions/live_functions.php';
require_once __DIR__ . '/functions/live_chat_functions.php';
require_once __DIR__ . '/functions/audio_room_functions.php';
require_once __DIR__ . '/functions/ebook_functions.php';
require_once __DIR__ . '/functions/landing_page_functions.php';
require_once __DIR__ . '/functions/welcome_page_functions.php';
require_once __DIR__ . '/functions/page_cms_functions.php';
require_once __DIR__ . '/functions/security_functions.php';
require_once __DIR__ . '/functions/payout_functions.php';

class Reel_Data
{
    use CoreFunctions,
        ConfigFunctions,
        UserFunctions,
        SearchFunctions,
        MessageFunctions,
        PostFunctions,
        FeedFunctions,
        LikeFunctions,
        NotificationFunctions,
        PaymentFunctions,
        CommentFunctions,
        ExploreFunctions,
        WelcomePageFunctions,
        ProfileFunctions,
        ReelsFunctions,
        CountPostViewFunctions,
        ImagesFunctions,
        CreatorsFunctions,
        CreatorDashboardFunctions,
        FollowUnfollowFunctions,
        ConversationsFunctions,
        BookmarksFunctions,
        WidgetFunctions,
        AdvertisementFunctions,
        PodcastAdFunctions,
        AnnouncementFunctions,
        SubscriptionsFunctions,
        LiveTipFunctions,
        LiveFunctions,
        LiveChatFunctions,
        AudioRoomFunctions,
        EbookFunctions,
        LandingPageFunctions,
        PageCmsFunctions,
        SecurityFunctions,
        PayoutFunctions;

    private PDO $db;

    public function __construct(PDO $db) {
        $this->db = $db;
    }

    /** Optionally expose PDO for external helpers */
    public function getDb(): PDO {
        return $this->db;
    }
}
