<?php
declare(strict_types=1);

require_once __DIR__ . '/StorageAdapterInterface.php';
require_once __DIR__ . '/StorageException.php';
require_once __DIR__ . '/StorageResult.php';

final class LocalAdapter implements StorageAdapterInterface
{
    private const VISIBILITY_PUBLIC = 'public';
    private const VISIBILITY_PRIVATE = 'private';

    /** @var string */
    private $rootPath;

    /** @var string */
    private $publicBaseUrl;

    /** @var string */
    private $defaultVisibility;

    public function __construct(
        ?string $rootPath = null,
        ?string $publicBaseUrl = null,
        string $defaultVisibility = self::VISIBILITY_PUBLIC
    ) {
        $this->rootPath = $this->normalizeDirectoryPath($rootPath ?? $this->detectDefaultRootPath());
        $this->publicBaseUrl = $this->normalizeBaseUrl($publicBaseUrl ?? $this->detectDefaultBaseUrl());
        $this->defaultVisibility = $this->normalizeVisibility($defaultVisibility);

        if (!is_dir($this->rootPath)) {
            throw new StorageException(
                sprintf('Local storage root path does not exist: %s', $this->rootPath),
                'config'
            );
        }
    }

    public function put(
        string $localPath,
        string $remoteKey,
        string $contentType,
        string $visibility = self::VISIBILITY_PRIVATE,
        array $options = []
    ): StorageResult {
        $sourcePath = $this->validateSourcePath($localPath);
        $normalizedKey = $this->normalizeKey($remoteKey);
        $targetPath = $this->buildAbsolutePath($normalizedKey);

        $this->ensureDirectory(dirname($targetPath));

        if (!$this->moveFile($sourcePath, $targetPath)) {
            throw new StorageException(
                sprintf('Unable to persist file to %s', $targetPath),
                'write'
            );
        }

        $finalVisibility = $this->resolveVisibility($visibility);
        $this->applyVisibility($targetPath, $finalVisibility);

        $size = $this->safeFilesize($targetPath);
        $etag = $this->generateEtag($targetPath, $contentType, $options);
        $checksum = $this->generateChecksum($targetPath, $options);

        return new StorageResult(
            $normalizedKey,
            $etag,
            $size,
            $finalVisibility,
            $checksum
        );
    }

    public function delete(string $remoteKey): bool
    {
        $normalizedKey = $this->normalizeKey($remoteKey);
        $absolutePath = $this->buildAbsolutePath($normalizedKey);

        if (!file_exists($absolutePath)) {
            return false;
        }

        if (!@unlink($absolutePath)) {
            throw new StorageException(
                sprintf('Unable to delete file at %s', $absolutePath),
                'delete'
            );
        }

        $this->cleanupEmptyDirectories(dirname($absolutePath));

        return true;
    }

    public function url(string $remoteKey, ?int $ttl = null): string
    {
        $normalizedKey = $this->normalizeKey($remoteKey);
        $relativePath = str_replace(DIRECTORY_SEPARATOR, '/', $normalizedKey);

        return $this->publicBaseUrl . $relativePath;
    }

    public function getPublicBaseUrl(): string
    {
        return $this->publicBaseUrl;
    }

    public function exists(string $remoteKey): bool
    {
        $normalizedKey = $this->normalizeKey($remoteKey);
        $absolutePath = $this->buildAbsolutePath($normalizedKey);

        return is_file($absolutePath);
    }

    public function copy(string $sourceKey, string $targetKey, array $options = []): bool
    {
        $normalizedSource = $this->normalizeKey($sourceKey);
        $normalizedTarget = $this->normalizeKey($targetKey);

        $sourcePath = $this->buildAbsolutePath($normalizedSource);
        $targetPath = $this->buildAbsolutePath($normalizedTarget);

        if (!is_file($sourcePath)) {
            throw new StorageException(
                sprintf('Unable to copy missing source file %s', $sourcePath),
                'not_found'
            );
        }

        $this->ensureDirectory(dirname($targetPath));

        if (!@copy($sourcePath, $targetPath)) {
            throw new StorageException(
                sprintf('Unable to copy %s to %s', $sourcePath, $targetPath),
                'copy'
            );
        }

        $this->applyVisibility($targetPath, $this->defaultVisibility);

        return true;
    }

    public function move(string $sourceKey, string $targetKey, array $options = []): bool
    {
        $normalizedSource = $this->normalizeKey($sourceKey);
        $normalizedTarget = $this->normalizeKey($targetKey);

        $sourcePath = $this->buildAbsolutePath($normalizedSource);
        $targetPath = $this->buildAbsolutePath($normalizedTarget);

        if (!is_file($sourcePath)) {
            throw new StorageException(
                sprintf('Unable to move missing source file %s', $sourcePath),
                'not_found'
            );
        }

        $this->ensureDirectory(dirname($targetPath));

        if (!@rename($sourcePath, $targetPath)) {
            if (!@copy($sourcePath, $targetPath) || !@unlink($sourcePath)) {
                throw new StorageException(
                    sprintf('Unable to move %s to %s', $sourcePath, $targetPath),
                    'move'
                );
            }
        }

        $this->applyVisibility($targetPath, $this->defaultVisibility);

        return true;
    }

    private function validateSourcePath(string $localPath): string
    {
        $realPath = realpath($localPath);
        if ($realPath === false || !is_file($realPath) || !is_readable($realPath)) {
            throw new StorageException(
                sprintf('Source file is not readable: %s', $localPath),
                'source_missing'
            );
        }

        return $realPath;
    }

    private function normalizeKey(string $remoteKey): string
    {
        $key = str_replace('\\', '/', $remoteKey);
        $key = trim($key);
        $normalized = preg_replace('#/+#', '/', $key);
        if (!is_string($normalized)) {
            throw new StorageException('Unable to normalize remote key', 'invalid_key');
        }

        $key = ltrim($normalized, '/');

        if ($key === '') {
            throw new StorageException('Remote key cannot be empty', 'invalid_key');
        }

        if (strpos($key, '..') !== false) {
            throw new StorageException('Remote key cannot contain traversal segments', 'invalid_key');
        }

        return $key;
    }

    private function buildAbsolutePath(string $normalizedKey): string
    {
        $path = $this->rootPath . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $normalizedKey);

        $rootPrefix = $this->rootPath . DIRECTORY_SEPARATOR;
        if (strpos($this->normalizeDirectoryPath($path), $rootPrefix) !== 0) {
            throw new StorageException(
                sprintf('Resolved path escapes storage root: %s', $path),
                'invalid_key'
            );
        }

        return $path;
    }

    private function ensureDirectory(string $directory): void
    {
        if (is_dir($directory)) {
            return;
        }

        if (!@mkdir($directory, 0755, true) && !is_dir($directory)) {
            throw new StorageException(
                sprintf('Unable to create directory %s', $directory),
                'mkdir'
            );
        }
    }

    private function moveFile(string $sourcePath, string $targetPath): bool
    {
        if (@rename($sourcePath, $targetPath)) {
            return true;
        }

        if (@copy($sourcePath, $targetPath)) {
            @unlink($sourcePath);

            return true;
        }

        return false;
    }

    private function applyVisibility(string $path, string $visibility): void
    {
        $mode = $visibility === self::VISIBILITY_PRIVATE ? 0600 : 0644;
        @chmod($path, $mode);
    }

    private function resolveVisibility(string $visibility): string
    {
        $normalized = $this->normalizeVisibility($visibility);
        if ($normalized === 'inherit') {
            return $this->defaultVisibility;
        }

        return $normalized;
    }

    private function normalizeVisibility(string $visibility): string
    {
        $value = strtolower(trim($visibility));
        if ($value === 'inherit') {
            return 'inherit';
        }

        return $value === self::VISIBILITY_PRIVATE ? self::VISIBILITY_PRIVATE : self::VISIBILITY_PUBLIC;
    }

    private function safeFilesize(string $path): int
    {
        $size = @filesize($path);
        if ($size === false) {
            return 0;
        }

        return (int) $size;
    }

    private function generateEtag(string $path, string $contentType, array $options): string
    {
        $hash = @hash_file('sha1', $path);
        if ($hash !== false) {
            return $hash;
        }

        return (string) md5($path . $contentType . json_encode($options));
    }

    private function generateChecksum(string $path, array $options): ?string
    {
        $hash = @hash_file('md5', $path);
        if ($hash === false) {
            return null;
        }

        return $hash;
    }

    private function cleanupEmptyDirectories(string $directory): void
    {
        $directory = $this->normalizeDirectoryPath($directory);

        while ($directory !== $this->rootPath && strpos($directory, $this->rootPath) === 0) {
            if (!is_dir($directory)) {
                break;
            }

            $files = @scandir($directory);
            if ($files === false) {
                break;
            }

            if (count(array_diff($files, ['.', '..'])) > 0) {
                break;
            }

            @rmdir($directory);
            $directory = dirname($directory);
        }
    }

    private function normalizeDirectoryPath(string $path): string
    {
        $normalized = rtrim(str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $path), DIRECTORY_SEPARATOR);

        return $normalized !== '' ? $normalized : DIRECTORY_SEPARATOR;
    }

    private function normalizeBaseUrl(string $baseUrl): string
    {
        if ($baseUrl === '') {
            return '/';
        }

        return rtrim($baseUrl, '/') . '/';
    }

    private function detectDefaultRootPath(): string
    {
        $candidates = [];

        if (!empty($GLOBALS['uploadFile'])) {
            $uploadRoot = dirname((string) $GLOBALS['uploadFile']);
            if ($uploadRoot !== '') {
                $candidates[] = $uploadRoot;
            }
        }

        $projectRoot = dirname(__DIR__, 2);
        $candidates[] = $projectRoot . DIRECTORY_SEPARATOR . 'uploads';
        $candidates[] = $projectRoot;

        $documentRoot = (string) ($_SERVER['DOCUMENT_ROOT'] ?? '');
        if ($documentRoot !== '') {
            $candidates[] = $documentRoot . DIRECTORY_SEPARATOR . 'uploads';
            $candidates[] = $documentRoot;
        }

        $cwd = getcwd();
        if ($cwd !== false) {
            $candidates[] = $cwd;
        }

        foreach ($candidates as $candidate) {
            if (!is_string($candidate) || $candidate === '') {
                continue;
            }

            $realCandidate = realpath($candidate);
            if ($realCandidate !== false && is_dir($realCandidate)) {
                return rtrim($realCandidate, DIRECTORY_SEPARATOR);
            }

            if (is_dir($candidate)) {
                return rtrim($candidate, DIRECTORY_SEPARATOR);
            }
        }

        return DIRECTORY_SEPARATOR;
    }

    private function detectDefaultBaseUrl(): string
    {
        if (!empty($GLOBALS['base_url'])) {
            return (string) $GLOBALS['base_url'];
        }

        if (function_exists('env')) {
            $envBase = (string) env('BASE_URL', '');
            if ($envBase !== '') {
                return $envBase;
            }
        }

        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host     = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');

        return $protocol . '://' . $host . '/';
    }
}
