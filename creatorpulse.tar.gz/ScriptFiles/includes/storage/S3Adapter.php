<?php

declare(strict_types=1);

require_once __DIR__ . '/StorageAdapterInterface.php';
require_once __DIR__ . '/StorageException.php';
require_once __DIR__ . '/StorageResult.php';

class S3Adapter implements StorageAdapterInterface
{
    private const SERVICE = 's3';
    private const ACL_PUBLIC = 'public-read';
    private const ACL_PRIVATE = 'private';
    private const MAX_PRESIGN_TTL = 604800; // 7 days

    /** @var string */
    protected $accessKey;

    /** @var string */
    protected $secretKey;

    /** @var string */
    protected $region;

    /** @var string */
    protected $bucket;

    /** @var string */
    protected $endpoint;

    /** @var string */
    protected $endpointScheme;

    /** @var string */
    protected $endpointHost;

    /** @var bool */
    protected $endpointIncludesBucket;

    /** @var bool */
    protected $pathStyle;

    /** @var string */
    protected $defaultVisibility;

    /** @var string */
    protected $publicBaseUrl;

    /** @var bool */
    protected $deferNetwork;

    /** @var int */
    protected $defaultPresignTtl;

    /** @var array */
    protected $httpOptions;

    /** @var string */
    protected $sessionToken;

    public function __construct(array $config)
    {
        $this->accessKey = (string) ($config['access_key'] ?? '');
        $this->secretKey = (string) ($config['secret_key'] ?? '');
        $this->region = (string) ($config['region'] ?? '');
        $this->bucket = (string) ($config['bucket'] ?? '');
        $this->sessionToken = (string) ($config['session_token'] ?? '');

        if ($this->accessKey === '' || $this->secretKey === '' || $this->region === '' || $this->bucket === '') {
            throw new StorageException('S3 adapter requires access_key, secret_key, region, and bucket', 'config');
        }

        $this->pathStyle = (bool) ($config['path_style'] ?? false);
        $this->deferNetwork = (bool) ($config['defer_network'] ?? false);
        $this->defaultPresignTtl = (int) ($config['default_presign_ttl'] ?? 3600);
        if ($this->defaultPresignTtl <= 0 || $this->defaultPresignTtl > self::MAX_PRESIGN_TTL) {
            $this->defaultPresignTtl = 3600;
        }
        $this->httpOptions = (array) ($config['http'] ?? []);

        $endpoint = (string) ($config['endpoint'] ?? '');
        if ($endpoint === '') {
            $endpoint = $this->buildDefaultEndpoint();
        }

        $this->endpoint = rtrim($endpoint, '/');
        $this->parseEndpoint();

        $visibility = (string) ($config['default_visibility'] ?? 'private');
        $this->defaultVisibility = $this->normalizeVisibility($visibility);

        $publicBase = (string) ($config['public_base_url'] ?? '');
        if ($publicBase === '') {
            $publicBase = $this->buildDefaultPublicBaseUrl();
        }
        $this->publicBaseUrl = $this->normalizePublicBaseUrl($publicBase);
    }

    public function put(
        string $localPath,
        string $remoteKey,
        string $contentType,
        string $visibility = 'private',
        array $options = []
    ): StorageResult {
        $sourcePath = $this->validateSourcePath($localPath);
        $normalizedKey = $this->normalizeKey($remoteKey);
        $resolvedVisibility = $this->resolveVisibility($visibility);
        $acl = $this->mapVisibilityToAcl($resolvedVisibility);

        $size = $this->safeFilesize($sourcePath);
        $payloadHash = $this->hashFileSha256($sourcePath);

        $headers = [
            'content-type' => $contentType,
            'content-length' => (string) $size,
            'x-amz-acl' => $acl,
        ];

        if (!empty($options['cache_control'])) {
            $headers['cache-control'] = (string) $options['cache_control'];
        }

        if (!empty($options['content_disposition'])) {
            $headers['content-disposition'] = (string) $options['content_disposition'];
        }

        if (!empty($options['metadata']) && is_array($options['metadata'])) {
            foreach ($options['metadata'] as $metaKey => $metaValue) {
                $headers['x-amz-meta-' . strtolower((string) $metaKey)] = (string) $metaValue;
            }
        }

        $request = $this->createSignedRequest(
            'PUT',
            $normalizedKey,
            $headers,
            [],
            $payloadHash,
            $sourcePath
        );

        $response = $this->sendRequest($request);

        if ($response['status'] < 200 || $response['status'] >= 300) {
            throw new StorageException(
                sprintf('S3 put failed with status %s', $response['status']),
                'write'
            );
        }

        $etag = $this->generateEtag($sourcePath);
        $checksum = $this->generateChecksum($sourcePath);

        return new StorageResult(
            $normalizedKey,
            $etag,
            $size,
            $resolvedVisibility,
            $checksum
        );
    }

    public function delete(string $remoteKey): bool
    {
        $normalizedKey = $this->normalizeKey($remoteKey);

        $request = $this->createSignedRequest(
            'DELETE',
            $normalizedKey,
            ['content-length' => '0'],
            [],
            hash('sha256', '')
        );

        $response = $this->sendRequest($request);

        if ($response['status'] === 404) {
            return false;
        }

        if ($response['status'] < 200 || $response['status'] >= 300) {
            throw new StorageException(
                sprintf('S3 delete failed with status %s', $response['status']),
                'delete'
            );
        }

        return true;
    }

    public function url(string $remoteKey, ?int $ttl = null): string
    {
        $normalizedKey = $this->normalizeKey($remoteKey);

        if ($ttl === null && $this->defaultVisibility === 'public') {
            return $this->buildPublicUrl($normalizedKey);
        }

        $effectiveTtl = $ttl !== null ? max(1, min(self::MAX_PRESIGN_TTL, $ttl)) : $this->defaultPresignTtl;

        return $this->createPresignedUrl($normalizedKey, $effectiveTtl);
    }

    public function exists(string $remoteKey): bool
    {
        $normalizedKey = $this->normalizeKey($remoteKey);

        $request = $this->createSignedRequest(
            'HEAD',
            $normalizedKey,
            [],
            [],
            hash('sha256', '')
        );

        $response = $this->sendRequest($request);

        if ($response['status'] === 404) {
            return false;
        }

        if ($response['status'] >= 200 && $response['status'] < 300) {
            return true;
        }

        $headerCode = '';
        $headerMessage = '';
        if (isset($response['headers']) && is_array($response['headers'])) {
            $headerCode = (string) ($response['headers']['x-amz-error-code'] ?? '');
            $headerMessage = (string) ($response['headers']['x-amz-error-message'] ?? '');
        }

        if (function_exists('error_log')) {
            $details = '[Storage] S3 exists() unexpected status ' . $response['status'];
            if ($headerCode !== '' || $headerMessage !== '') {
                $details .= ' header_code=' . $headerCode . ' header_message=' . $headerMessage;
            }
            if (isset($response['body']) && is_string($response['body']) && $response['body'] !== '') {
                $details .= ' body=' . substr($response['body'], 0, 1024);
            }
            error_log($details);
        }

        throw new StorageException(
            sprintf(
                'S3 exists check failed with status %s%s%s',
                $response['status'],
                $headerCode !== '' ? ' (' . $headerCode . ')' : '',
                $headerMessage !== '' ? ': ' . $headerMessage : ''
            ),
            'exists'
        );
    }

    public function copy(string $sourceKey, string $targetKey, array $options = []): bool
    {
        $normalizedSource = $this->normalizeKey($sourceKey);
        $normalizedTarget = $this->normalizeKey($targetKey);

        $headers = [
            'content-length' => '0',
            'x-amz-copy-source' => $this->buildCopySourceHeader($normalizedSource),
            'x-amz-metadata-directive' => 'COPY',
        ];

        if (!empty($options['acl'])) {
            $headers['x-amz-acl'] = (string) $options['acl'];
        }

        $request = $this->createSignedRequest(
            'PUT',
            $normalizedTarget,
            $headers,
            [],
            hash('sha256', '')
        );

        $response = $this->sendRequest($request);

        if ($response['status'] < 200 || $response['status'] >= 300) {
            throw new StorageException(
                sprintf('S3 copy failed with status %s', $response['status']),
                'copy'
            );
        }

        return true;
    }

    public function move(string $sourceKey, string $targetKey, array $options = []): bool
    {
        $this->copy($sourceKey, $targetKey, $options);
        $this->delete($sourceKey);

        return true;
    }

    protected function createSignedRequest(
        string $method,
        string $normalizedKey,
        array $headers,
        array $queryParameters,
        string $payloadHash,
        ?string $bodyPath = null
    ): array {
        $method = strtoupper($method);
        $requestTarget = $this->buildRequestTarget($normalizedKey);
        $amzDate = $this->getAmzDate();
        $dateStamp = substr($amzDate, 0, 8);

        $headers = $this->prepareHeadersForSigning($headers);
        $headers['host'] = $requestTarget['host'];
        $headers['x-amz-date'] = $amzDate;
        $headers['x-amz-content-sha256'] = $payloadHash;

        if ($this->sessionToken !== '') {
            $headers['x-amz-security-token'] = $this->sessionToken;
        }

        $canonicalHeaders = $this->buildCanonicalHeaders($headers);
        $signedHeaders = implode(';', array_keys($canonicalHeaders));
        $canonicalHeadersString = $this->implodeCanonicalHeaders($canonicalHeaders);
        $canonicalQueryString = $this->buildCanonicalQueryString($queryParameters);

        $canonicalRequest = $method . "\n" . $requestTarget['canonical_uri'] . "\n" . $canonicalQueryString . "\n" . $canonicalHeadersString . "\n" . $signedHeaders . "\n" . $payloadHash;

        $credentialScope = $this->buildCredentialScope($dateStamp);
        $stringToSign = 'AWS4-HMAC-SHA256' . "\n" . $amzDate . "\n" . $credentialScope . "\n" . hash('sha256', $canonicalRequest);

        $signature = $this->signStringToSign($stringToSign, $dateStamp);

        $headers['authorization'] = 'AWS4-HMAC-SHA256 Credential=' . $this->accessKey . '/' . $credentialScope . ', SignedHeaders=' . $signedHeaders . ', Signature=' . $signature;

        $url = $requestTarget['scheme'] . '://' . $requestTarget['host'] . $requestTarget['canonical_uri'];
        if ($canonicalQueryString !== '') {
            $url .= '?' . $canonicalQueryString;
        }

        return [
            'method' => $method,
            'url' => $url,
            'headers' => $this->formatHeadersForTransport($headers),
            'status_expect' => $this->determineExpectedStatus($method),
            'body_path' => $bodyPath,
        ];
    }

    protected function sendRequest(array $request): array
    {
        if ($this->deferNetwork) {
            $this->logDeferredRequest($request);

            return [
                'status' => 200,
                'headers' => [],
                'body' => '',
            ];
        }

        $method   = isset($request['method']) ? strtoupper((string) $request['method']) : 'GET';
        $url      = (string) ($request['url'] ?? '');
        $headers  = isset($request['headers']) && is_array($request['headers']) ? $request['headers'] : [];
        $bodyPath = isset($request['body_path']) ? (string) $request['body_path'] : null;

        if ($url === '') {
            throw new StorageException('S3 request missing URL', 'network');
        }

        $handle = curl_init($url);
        if ($handle === false) {
            throw new StorageException('Unable to initialise cURL handle for S3 request', 'network');
        }

        $responseHeaders = [];
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($handle, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($handle, CURLOPT_HEADER, false);
        curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($handle, CURLOPT_HEADERFUNCTION, static function ($ch, $header) use (&$responseHeaders) {
            $length = strlen($header);
            $header = trim($header);
            if ($header === '' || strpos($header, ':') === false) {
                return $length;
            }
            [$name, $value] = explode(':', $header, 2);
            $responseHeaders[strtolower(trim($name))] = trim($value);
            return $length;
        });

        $this->applyHttpOptions($handle);

        $stream = null;
        if ($method === 'PUT') {
            if ($bodyPath === null || $bodyPath === '' || !is_file($bodyPath)) {
                curl_close($handle);
                throw new StorageException('PUT body source missing for S3 request', 'source_missing');
            }
            $stream = @fopen($bodyPath, 'rb');
            if (!$stream) {
                curl_close($handle);
                throw new StorageException('Unable to open body stream for S3 request', 'source_missing');
            }
            $size = filesize($bodyPath);
            curl_setopt($handle, CURLOPT_UPLOAD, true);
            curl_setopt($handle, CURLOPT_INFILE, $stream);
            if ($size !== false) {
                curl_setopt($handle, CURLOPT_INFILESIZE, $size);
            }
        } elseif ($method === 'HEAD') {
            curl_setopt($handle, CURLOPT_NOBODY, true);
            curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'HEAD');
        } elseif ($method === 'DELETE') {
            curl_setopt($handle, CURLOPT_CUSTOMREQUEST, 'DELETE');
        } elseif ($method !== 'GET') {
            curl_setopt($handle, CURLOPT_CUSTOMREQUEST, $method);
        }

        $body = curl_exec($handle);
        $curlError = curl_error($handle);
        $status = (int) curl_getinfo($handle, CURLINFO_RESPONSE_CODE);

        if (is_resource($stream)) {
            @fclose($stream);
        }

        if ($body === false) {
            curl_close($handle);
            throw new StorageException('cURL error: ' . ($curlError !== '' ? $curlError : 'unknown'), 'network');
        }

        curl_close($handle);

        return [
            'status' => $status,
            'headers' => $responseHeaders,
            'body' => $body,
        ];
    }

    protected function applyHttpOptions($handle): void
    {
        if (!$this->httpOptions) {
            return;
        }

        if (isset($this->httpOptions['timeout'])) {
            curl_setopt($handle, CURLOPT_TIMEOUT, (int) $this->httpOptions['timeout']);
        }

        if (isset($this->httpOptions['connect_timeout'])) {
            curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, (int) $this->httpOptions['connect_timeout']);
        }

        if (array_key_exists('verify', $this->httpOptions) && $this->httpOptions['verify'] === false) {
            curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, 0);
        }

        if (isset($this->httpOptions['proxy'])) {
            curl_setopt($handle, CURLOPT_PROXY, (string) $this->httpOptions['proxy']);
        }
    }

    protected function buildRequestTarget(string $normalizedKey): array
    {
        $encodedKey = $this->encodeKey($normalizedKey);

        if ($this->shouldUsePathStyleAddressing()) {
            $canonicalUri = '/' . rawurlencode($this->bucket) . '/' . $encodedKey;
            $host = $this->endpointHost;
        } else {
            $canonicalUri = '/' . $encodedKey;
            $host = $this->endpointIncludesBucket
                ? $this->endpointHost
                : $this->bucket . '.' . $this->endpointHost;
        }

        return [
            'scheme' => $this->endpointScheme,
            'host' => $host,
            'canonical_uri' => $canonicalUri,
        ];
    }

    protected function buildCopySourceHeader(string $normalizedSource): string
    {
        return rawurlencode($this->bucket . '/' . $normalizedSource);
    }

    protected function buildCanonicalHeaders(array $headers): array
    {
        $normalized = [];
        foreach ($headers as $name => $value) {
            $lower = strtolower((string) $name);
            $normalized[$lower] = preg_replace('/\s+/', ' ', trim((string) $value));
        }
        ksort($normalized, SORT_STRING);

        return $normalized;
    }

    protected function implodeCanonicalHeaders(array $headers): string
    {
        $lines = [];
        foreach ($headers as $name => $value) {
            $lines[] = $name . ':' . $value;
        }

        return implode("\n", $lines) . "\n";
    }

    protected function buildCanonicalQueryString(array $params): string
    {
        if (empty($params)) {
            return '';
        }

        $pairs = [];
        foreach ($params as $key => $value) {
            if (is_array($value)) {
                sort($value, SORT_STRING);
                foreach ($value as $item) {
                    $pairs[] = $this->percentEncode((string) $key) . '=' . $this->percentEncode((string) $item);
                }
            } else {
                $pairs[] = $this->percentEncode((string) $key) . '=' . $this->percentEncode((string) $value);
            }
        }

        sort($pairs, SORT_STRING);

        return implode('&', $pairs);
    }

    protected function buildCredentialScope(string $dateStamp): string
    {
        return $dateStamp . '/' . $this->region . '/' . self::SERVICE . '/aws4_request';
    }

    protected function signStringToSign(string $stringToSign, string $dateStamp): string
    {
        $kSecret = 'AWS4' . $this->secretKey;
        $kDate = hash_hmac('sha256', $dateStamp, $kSecret, true);
        $kRegion = hash_hmac('sha256', $this->region, $kDate, true);
        $kService = hash_hmac('sha256', self::SERVICE, $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);

        return hash_hmac('sha256', $stringToSign, $kSigning);
    }

    protected function formatHeadersForTransport(array $headers): array
    {
        $formatted = [];
        foreach ($headers as $name => $value) {
            $formatted[] = $this->formatHeaderName($name) . ': ' . $value;
        }

        return $formatted;
    }

    protected function formatHeaderName(string $name): string
    {
        if ($name === 'authorization') {
            return 'Authorization';
        }

        $segments = explode('-', $name);
        $segments = array_map(function ($segment) {
            return $segment !== '' ? ucfirst($segment) : $segment;
        }, $segments);

        return implode('-', $segments);
    }

    protected function determineExpectedStatus(string $method): array
    {
        if ($method === 'PUT') {
            return [200, 201, 204];
        }

        if ($method === 'DELETE') {
            return [200, 202, 204, 404];
        }

        if ($method === 'HEAD') {
            return [200, 404];
        }

        return [200, 201, 202, 204];
    }

    protected function createPresignedUrl(string $normalizedKey, int $ttl): string
    {
        $ttl = min(self::MAX_PRESIGN_TTL, max(1, $ttl));
        $requestTarget = $this->buildRequestTarget($normalizedKey);
        $amzDate = $this->getAmzDate();
        $dateStamp = substr($amzDate, 0, 8);
        $credentialScope = $this->buildCredentialScope($dateStamp);
        $credential = $this->accessKey . '/' . $credentialScope;

        $query = [
            'X-Amz-Algorithm' => 'AWS4-HMAC-SHA256',
            'X-Amz-Credential' => $credential,
            'X-Amz-Date' => $amzDate,
            'X-Amz-Expires' => (string) $ttl,
            'X-Amz-SignedHeaders' => 'host',
        ];

        if ($this->sessionToken !== '') {
            $query['X-Amz-Security-Token'] = $this->sessionToken;
        }

        $canonicalQueryString = $this->buildCanonicalQueryString($query);

        $canonicalRequest = 'GET' . "\n"
            . $requestTarget['canonical_uri'] . "\n"
            . $canonicalQueryString . "\n"
            . 'host:' . $requestTarget['host'] . "\n\n"
            . 'host' . "\n"
            . 'UNSIGNED-PAYLOAD';

        $stringToSign = 'AWS4-HMAC-SHA256' . "\n" . $amzDate . "\n" . $credentialScope . "\n" . hash('sha256', $canonicalRequest);
        $signature = $this->signStringToSign($stringToSign, $dateStamp);

        $signedQuery = $this->appendToQueryString($canonicalQueryString, 'X-Amz-Signature', $signature);

        return $requestTarget['scheme'] . '://' . $requestTarget['host'] . $requestTarget['canonical_uri'] . '?' . $signedQuery;
    }

    protected function appendToQueryString(string $queryString, string $key, string $value): string
    {
        $pair = $this->percentEncode($key) . '=' . $this->percentEncode($value);

        return $queryString !== '' ? $queryString . '&' . $pair : $pair;
    }

    protected function buildPublicUrl(string $normalizedKey): string
    {
        return $this->publicBaseUrl . str_replace('//', '/', $normalizedKey);
    }

    public function getPublicBaseUrl(): string
    {
        return $this->publicBaseUrl;
    }

    protected function buildDefaultEndpoint(): string
    {
        if ($this->region === 'us-east-1') {
            return 'https://s3.amazonaws.com';
        }

        return 'https://s3.' . $this->region . '.amazonaws.com';
    }

    protected function buildDefaultPublicBaseUrl(): string
    {
        if ($this->shouldUsePathStyleAddressing()) {
            return $this->endpoint . '/' . rawurlencode($this->bucket);
        }

        $host = $this->endpointIncludesBucket
            ? $this->endpointHost
            : $this->bucket . '.' . $this->endpointHost;

        return $this->endpointScheme . '://' . $host;
    }

    protected function normalizePublicBaseUrl(string $baseUrl): string
    {
        if ($baseUrl === '') {
            return '/';
        }

        return rtrim($baseUrl, '/') . '/';
    }

    protected function parseEndpoint(): void
    {
        $parsed = parse_url($this->endpoint);
        if ($parsed === false || !isset($parsed['scheme']) || !isset($parsed['host'])) {
            throw new StorageException('Invalid S3 endpoint: ' . $this->endpoint, 'config');
        }

        $this->endpointScheme = strtolower($parsed['scheme']);
        $this->endpointHost = strtolower($parsed['host']);

        $bucketHost = strtolower($this->bucket) . '.';
        $this->endpointIncludesBucket = $bucketHost !== '.' && strpos($this->endpointHost, $bucketHost) === 0;
    }

    protected function shouldUsePathStyleAddressing(): bool
    {
        if ($this->pathStyle) {
            return true;
        }

        // Buckets with dots can break HTTPS wildcard cert matching in virtual-host mode.
        return $this->endpointScheme === 'https'
            && strpos($this->bucket, '.') !== false
            && !$this->endpointIncludesBucket;
    }

    protected function encodeKey(string $key): string
    {
        $segments = explode('/', $key);
        $encoded = [];
        foreach ($segments as $segment) {
            $encoded[] = rawurlencode($segment);
        }

        return implode('/', $encoded);
    }

    protected function normalizeKey(string $remoteKey): string
    {
        $key = str_replace('\\', '/', $remoteKey);
        $key = trim($key);
        $key = preg_replace('#/+#', '/', $key);
        $key = ltrim((string) $key, '/');

        if ($key === '') {
            throw new StorageException('Remote key cannot be empty', 'invalid_key');
        }

        if (strpos($key, '..') !== false) {
            throw new StorageException('Remote key cannot contain traversal segments', 'invalid_key');
        }

        if (!preg_match('/^[A-Za-z0-9\/_\.-]+$/', $key)) {
            $key = preg_replace('/[^A-Za-z0-9\/_\.-]/', '-', $key);
        }

        return $key;
    }

    protected function validateSourcePath(string $localPath): string
    {
        $realPath = realpath($localPath);
        if ($realPath === false || !is_file($realPath) || !is_readable($realPath)) {
            throw new StorageException('Source file is not readable: ' . $localPath, 'source_missing');
        }

        return $realPath;
    }

    protected function safeFilesize(string $path): int
    {
        $size = @filesize($path);
        if ($size === false) {
            return 0;
        }

        return (int) $size;
    }

    protected function hashFileSha256(string $path): string
    {
        $hash = @hash_file('sha256', $path);
        if ($hash === false) {
            throw new StorageException('Unable to hash file for S3 upload: ' . $path, 'hash');
        }

        return $hash;
    }

    protected function generateEtag(string $path): string
    {
        $hash = @hash_file('md5', $path);
        if ($hash === false) {
            return md5($path . microtime());
        }

        return $hash;
    }

    protected function generateChecksum(string $path): ?string
    {
        $hash = @hash_file('md5', $path);
        if ($hash === false) {
            return null;
        }

        return $hash;
    }

    protected function resolveVisibility(string $visibility): string
    {
        $normalized = $this->normalizeVisibility($visibility);
        if ($normalized === 'inherit') {
            return $this->defaultVisibility;
        }

        return $normalized;
    }

    protected function normalizeVisibility(string $visibility): string
    {
        $value = strtolower(trim($visibility));
        if ($value === 'inherit') {
            return 'inherit';
        }

        return $value === 'public' ? 'public' : 'private';
    }

    protected function mapVisibilityToAcl(string $visibility): string
    {
        return $visibility === 'public' ? self::ACL_PUBLIC : self::ACL_PRIVATE;
    }

    protected function getAmzDate(): string
    {
        return gmdate('Ymd\THis\Z');
    }

    protected function prepareHeadersForSigning(array $headers): array
    {
        $normalized = [];
        foreach ($headers as $name => $value) {
            if ($value === null || $value === '') {
                continue;
            }

            $normalized[strtolower((string) $name)] = trim((string) $value);
        }

        return $normalized;
    }

    protected function percentEncode(string $value): string
    {
        return str_replace(['+', '%7E'], ['%20', '~'], rawurlencode($value));
    }

    protected function logDeferredRequest(array $request): void
    {
        $message = '[Storage] Deferred S3 request: ' . ($request['method'] ?? '') . ' ' . ($request['url'] ?? '');
        if (function_exists('error_log')) {
            error_log($message);
        }
    }
}
