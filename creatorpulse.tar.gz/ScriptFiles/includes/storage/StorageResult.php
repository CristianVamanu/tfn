<?php

declare(strict_types=1);

final class StorageResult
{
    /** @var string */
    private $remoteKey;

    /** @var string */
    private $etag;

    /** @var int */
    private $contentLength;

    /** @var string|null */
    private $checksum;

    /** @var string */
    private $visibility;

    public function __construct(
        string $remoteKey,
        string $etag,
        int $contentLength,
        string $visibility,
        ?string $checksum = null
    ) {
        $this->remoteKey = $remoteKey;
        $this->etag = $etag;
        $this->contentLength = $contentLength;
        $this->visibility = $visibility;
        $this->checksum = $checksum;
    }

    public function getRemoteKey(): string
    {
        return $this->remoteKey;
    }

    public function getEtag(): string
    {
        return $this->etag;
    }

    public function getContentLength(): int
    {
        return $this->contentLength;
    }

    public function getChecksum(): ?string
    {
        return $this->checksum;
    }

    public function getVisibility(): string
    {
        return $this->visibility;
    }
}
