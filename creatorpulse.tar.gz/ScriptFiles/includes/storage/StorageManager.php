<?php

declare(strict_types=1);

require_once __DIR__ . '/StorageAdapterInterface.php';
require_once __DIR__ . '/StorageException.php';
require_once __DIR__ . '/StorageResult.php';
require_once __DIR__ . '/LocalAdapter.php';
require_once __DIR__ . '/S3Adapter.php';
require_once __DIR__ . '/DoSpacesAdapter.php';
require_once __DIR__ . '/WasabiAdapter.php';
require_once __DIR__ . '/BackblazeAdapter.php';
if (!function_exists('storage_decrypt_secret')) {
    require_once __DIR__ . '/../helpers/storage_helpers.php';
}

class StorageManager
{
    /** @var StorageManager|null */
    private static $instance;

    /** @var StorageAdapterInterface */
    private $adapter;

    /** @var string */
    private $driver = 'local';

    /** @var array */
    private $siteConfig;

    /** @var array */
    private $context;

    /** @var string */
    private $publicBaseUrl = '';

    /** @var array<string, bool> */
    private $webpAvailability = [];

    private function __construct(array $siteConfig, array $context)
    {
        $this->siteConfig = $siteConfig;
        $this->context = $context;
        $this->adapter = $this->resolveAdapter();
    }

    public static function boot(array $siteConfig, array $context = []): void
    {
        self::$instance = new self($siteConfig, $context);
    }

    public static function getInstance(): StorageManager
    {
        if (!self::$instance instanceof StorageManager) {
            self::$instance = new self([], []);
        }

        return self::$instance;
    }

    public static function adapter(): StorageAdapterInterface
    {
        return self::getInstance()->getAdapter();
    }

    public static function url(string $remoteKey, ?int $ttl = null): string
    {
        return self::getInstance()->buildUrl($remoteKey, $ttl);
    }

    public function getAdapter(): StorageAdapterInterface
    {
        return $this->adapter;
    }

    public function getDriver(): string
    {
        return $this->driver;
    }

    public function isRemote(): bool
    {
        return $this->driver !== 'local';
    }

    public function getResolvedConfig(): array
    {
        $context = $this->context;
        $context['public_base_url'] = $this->publicBaseUrl;

        return $context;
    }

    public function getPublicBaseUrl(): string
    {
        return $this->publicBaseUrl;
    }

    private function buildUrl(string $remoteKey, ?int $ttl = null): string
    {
        $key = trim((string) $remoteKey);
        if ($key === '') {
            return '';
        }

        if (preg_match('#^(?:[a-z][a-z0-9+\.\-]*:)?//#i', $key) === 1 || strncmp($key, 'data:', 5) === 0) {
            return $key;
        }

        $preferredKey = $this->preferWebpKey($key);
        if ($preferredKey !== $key) {
            try {
                return $this->adapter->url($preferredKey, $ttl);
            } catch (StorageException $e) {
                $this->logError('Adapter url() failed for WebP variant (' . $e->getErrorCode() . '): ' . $e->getMessage());
            } catch (\Throwable $e) {
                $this->logError('Adapter url() threw for WebP variant: ' . $e->getMessage());
            }
        }

        try {
            return $this->adapter->url($key, $ttl);
        } catch (StorageException $e) {
            $this->logError('Adapter url() failed (' . $e->getErrorCode() . '): ' . $e->getMessage());
        } catch (\Throwable $e) {
            $this->logError('Adapter url() threw: ' . $e->getMessage());
        }

        return $this->fallbackPublicUrl($key);
    }

    private function resolveAdapter(): StorageAdapterInterface
    {
        $adapter = null;
        $driver = 'local';
        $storageConfig = $this->extractStorageConfig($this->siteConfig);
        $providerConfig = [];

        if (!empty($storageConfig)) {
            $candidate = $this->normalizeDriver($storageConfig['driver'] ?? '');
            if ($candidate !== '') {
                $driver = $candidate;
            }

            $providerConfig = $this->extractProviderSettings($storageConfig, $driver);
        }

        try {
            $adapter = $this->buildAdapter($driver, $providerConfig);
        } catch (\Throwable $e) {
            $this->logError('Storage adapter build failed: ' . $e->getMessage());
            $adapter = null;
        }

        if (!$adapter instanceof StorageAdapterInterface) {
            $adapter = $this->buildAdapter('local', []);
            $driver = 'local';
        }

        $this->driver = $driver;
        $this->context['resolved_driver'] = $driver;
        $this->context['is_remote'] = ($driver !== 'local');
        $this->publicBaseUrl = $this->determinePublicBaseUrl($adapter, $providerConfig);
        $this->context['public_base_url'] = $this->publicBaseUrl;
        $this->context['keep_local_copy'] = isset($providerConfig['keep_local_copy']) ? (bool) $providerConfig['keep_local_copy'] : true;
        $this->context['sync_mode'] = isset($providerConfig['sync_mode']) ? (string) $providerConfig['sync_mode'] : 'manual';
        $this->context['provider_settings'] = $providerConfig;

        return $adapter;
    }

    private function preferWebpKey(string $originalKey): string
    {
        $acceptHeader = isset($_SERVER['HTTP_ACCEPT']) ? (string) $_SERVER['HTTP_ACCEPT'] : '';
        if ($acceptHeader === '' || stripos($acceptHeader, 'image/webp') === false) {
            return $originalKey;
        }

        if (preg_match('/\.(jpe?g|png)$/i', $originalKey) !== 1) {
            return $originalKey;
        }

        $candidate = preg_replace('/\.(jpe?g|png)$/i', '.webp', $originalKey);
        if (!is_string($candidate) || $candidate === '') {
            return $originalKey;
        }

        if (!array_key_exists($candidate, $this->webpAvailability)) {
            try {
                $this->webpAvailability[$candidate] = $this->adapter->exists($candidate);
            } catch (\Throwable $e) {
                $this->webpAvailability[$candidate] = false;
                $this->logError('WebP availability check failed: ' . $e->getMessage());
            }
        }

        return $this->webpAvailability[$candidate] ? $candidate : $originalKey;
    }

    private function decryptProviderSecrets(array $providerConfig): array
    {
        foreach (['access_key', 'secret_key', 'session_token'] as $field) {
            if (!isset($providerConfig[$field]) || !is_string($providerConfig[$field]) || $providerConfig[$field] === '') {
                continue;
            }
            $providerConfig[$field] = storage_decrypt_secret($providerConfig[$field]);
        }

        return $providerConfig;
    }

    private function extractStorageConfig(array $siteConfig): array
    {
        $possibleKeys = [
            'storage_settings',
            'storage_config',
            'storage_configuration',
            'storage_options',
        ];

        $raw = null;
        foreach ($possibleKeys as $key) {
            if (isset($siteConfig[$key]) && $siteConfig[$key] !== null && $siteConfig[$key] !== '') {
                $raw = $siteConfig[$key];
                break;
            }
        }

        if ($raw === null && isset($siteConfig['storage_driver'])) {
            $raw = [
                'driver' => $siteConfig['storage_driver'],
            ];
        }

        if (is_string($raw)) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                $raw = $decoded;
            } else {
                $raw = [];
            }
        }

        if (!is_array($raw)) {
            $raw = [];
        }

        if (!isset($raw['driver']) && isset($siteConfig['storage_driver'])) {
            $raw['driver'] = $siteConfig['storage_driver'];
        }

        if (!isset($raw['default_visibility']) && isset($siteConfig['storage_default_visibility'])) {
            $raw['default_visibility'] = $siteConfig['storage_default_visibility'];
        }

        if (!isset($raw['public_base_url']) && isset($siteConfig['storage_public_base_url'])) {
            $raw['public_base_url'] = $siteConfig['storage_public_base_url'];
        }

        if (!isset($raw['defer_network']) && isset($siteConfig['storage_defer_network'])) {
            $raw['defer_network'] = (bool) $siteConfig['storage_defer_network'];
        }

        return $raw;
    }

    private function extractProviderSettings(array $storageConfig, string $driver): array
    {
        $providerConfig = [];
        $candidates = $this->candidateKeysForDriver($driver);

        if (isset($storageConfig['providers']) && is_array($storageConfig['providers'])) {
            foreach ($candidates as $candidate) {
                if (isset($storageConfig['providers'][$candidate]) && is_array($storageConfig['providers'][$candidate])) {
                    $providerConfig = $storageConfig['providers'][$candidate];
                    break;
                }
            }
        }

        if (empty($providerConfig)) {
            foreach ($candidates as $candidate) {
                if (isset($storageConfig[$candidate]) && is_array($storageConfig[$candidate])) {
                    $providerConfig = $storageConfig[$candidate];
                    break;
                }
            }
        }

        if (!is_array($providerConfig)) {
            $providerConfig = [];
        }

        $defaults = ['default_visibility', 'public_base_url', 'path_style', 'default_presign_ttl', 'defer_network'];
        foreach ($defaults as $key) {
            if (!isset($providerConfig[$key]) && isset($storageConfig[$key])) {
                $providerConfig[$key] = $storageConfig[$key];
            }
        }

        if (!isset($providerConfig['keep_local_copy'])) {
            if (isset($storageConfig['keep_local_copy'])) {
                $providerConfig['keep_local_copy'] = (bool) $storageConfig['keep_local_copy'];
            } else {
                $providerConfig['keep_local_copy'] = true;
            }
        } else {
            $providerConfig['keep_local_copy'] = (bool) $providerConfig['keep_local_copy'];
        }

        $syncMode = isset($providerConfig['sync_mode']) ? (string) $providerConfig['sync_mode'] : (string)($storageConfig['sync_mode'] ?? 'manual');
        $syncMode = strtolower(trim($syncMode));
        if (!in_array($syncMode, ['manual', 'background'], true)) {
            $syncMode = 'manual';
        }
        $providerConfig['sync_mode'] = $syncMode;

        return $this->decryptProviderSecrets($providerConfig);
    }

    private function buildAdapter(string $driver, array $config): StorageAdapterInterface
    {
        $driver = $this->normalizeDriver($driver);

        if ($driver === 's3') {
            $normalized = $this->normalizeRemoteConfig($config);

            return new S3Adapter($normalized);
        }

        if ($driver === 'do_spaces') {
            $normalized = $this->normalizeRemoteConfig($config);

            return new DoSpacesAdapter($normalized);
        }

        if ($driver === 'wasabi') {
            $normalized = $this->normalizeRemoteConfig($config);

            return new WasabiAdapter($normalized);
        }

        if ($driver === 'backblaze') {
            $normalized = $this->normalizeRemoteConfig($config);

            return new BackblazeAdapter($normalized);
        }

        return $this->buildLocalAdapter($config);
    }

    private function buildLocalAdapter(array $config): StorageAdapterInterface
    {
        $root = isset($config['root_path']) ? (string) $config['root_path'] : '';
        if ($root === '' && isset($this->context['local_root'])) {
            $root = (string) $this->context['local_root'];
        }
        if ($root === '' && isset($GLOBALS['uploadFile'])) {
            $root = dirname((string) $GLOBALS['uploadFile']);
        }
        if ($root === '') {
            $root = null;
        }

        $publicBase = isset($config['public_base_url']) ? (string) $config['public_base_url'] : '';
        if ($publicBase === '' && isset($this->context['public_base_url'])) {
            $publicBase = (string) $this->context['public_base_url'];
        }
        if ($publicBase === '' && isset($this->context['base_url'])) {
            $publicBase = (string) $this->context['base_url'];
        }
        if ($publicBase === '') {
            $publicBase = null;
        }

        $visibility = isset($config['default_visibility']) ? (string) $config['default_visibility'] : '';
        if ($visibility === '' && isset($this->context['default_visibility'])) {
            $visibility = (string) $this->context['default_visibility'];
        }
        if ($visibility === '') {
            $visibility = 'public';
        }

        return new LocalAdapter($root !== '' ? $root : null, $publicBase !== '' ? $publicBase : null, $visibility);
    }

    private function determinePublicBaseUrl(StorageAdapterInterface $adapter, array $providerConfig): string
    {
        $candidate = '';

        if (method_exists($adapter, 'getPublicBaseUrl')) {
            $value = $adapter->getPublicBaseUrl();
            if (is_string($value) && $value !== '') {
                $candidate = $value;
            }
        }

        if ($candidate === '' && isset($providerConfig['public_base_url'])) {
            $candidate = (string) $providerConfig['public_base_url'];
        }

        if ($candidate === '' && isset($this->context['public_base_url'])) {
            $candidate = (string) $this->context['public_base_url'];
        }

        if ($candidate === '' && isset($this->context['base_url'])) {
            $candidate = (string) $this->context['base_url'];
        }

        return $this->normalizeBaseUrl($candidate);
    }

    private function fallbackPublicUrl(string $key): string
    {
        $base = $this->publicBaseUrl !== '' ? $this->publicBaseUrl : ($this->context['public_base_url'] ?? ($this->context['base_url'] ?? ''));
        $base = $this->normalizeBaseUrl($base);

        $normalizedKey = ltrim($key, '/');

        return $base !== '' ? $base . $normalizedKey : '/' . $normalizedKey;
    }

    private function normalizeBaseUrl(?string $value): string
    {
        if ($value === null) {
            return '';
        }

        $normalized = trim((string) $value);
        if ($normalized === '') {
            return '';
        }

        return rtrim($normalized, '/') . '/';
    }

    private function normalizeRemoteConfig(array $config): array
    {
        $normalized = [];
        foreach ($config as $key => $value) {
            $normalized[$key] = $value;
        }

        $normalized['access_key'] = isset($normalized['access_key']) ? trim((string) $normalized['access_key']) : '';
        $normalized['secret_key'] = isset($normalized['secret_key']) ? trim((string) $normalized['secret_key']) : '';
        $normalized['region'] = isset($normalized['region']) ? trim((string) $normalized['region']) : '';
        $normalized['bucket'] = isset($normalized['bucket']) ? trim((string) $normalized['bucket']) : '';

        if ($normalized['access_key'] === '' || $normalized['secret_key'] === '' || $normalized['region'] === '' || $normalized['bucket'] === '') {
            throw new StorageException('Remote storage configuration incomplete', 'config');
        }

        if (isset($normalized['session_token'])) {
            $normalized['session_token'] = trim((string) $normalized['session_token']);
        }

        if (!isset($normalized['default_visibility']) && isset($this->context['default_visibility'])) {
            $normalized['default_visibility'] = (string) $this->context['default_visibility'];
        }

        if (!isset($normalized['public_base_url']) && isset($this->context['public_base_url'])) {
            $normalized['public_base_url'] = (string) $this->context['public_base_url'];
        }

        if (!isset($normalized['defer_network']) && isset($this->context['defer_network'])) {
            $normalized['defer_network'] = (bool) $this->context['defer_network'];
        }

        if (isset($normalized['defer_network'])) {
            $normalized['defer_network'] = (bool) $normalized['defer_network'];
        }

        if (!defined('APP_DEBUG') || APP_DEBUG !== true) {
            $normalized['defer_network'] = false;
        }

        return $normalized;
    }

    private function normalizeDriver(string $driver): string
    {
        $driver = strtolower(trim($driver));

        if ($driver === '' || $driver === 'local' || $driver === 'filesystem' || $driver === 'native') {
            return 'local';
        }

        if ($driver === 's3' || $driver === 'aws' || $driver === 'amazon' || $driver === 'amazon_s3') {
            return 's3';
        }

        if ($driver === 'spaces' || $driver === 'do_spaces' || $driver === 'digitalocean' || $driver === 'digitalocean_spaces') {
            return 'do_spaces';
        }

        if ($driver === 'wasabi' || $driver === 'wasabi_s3') {
            return 'wasabi';
        }

        if (
            $driver === 'backblaze'
            || $driver === 'backblaze_b2'
            || $driver === 'b2'
            || $driver === 'blackblaze'
        ) {
            return 'backblaze';
        }

        return 'local';
    }

    private function candidateKeysForDriver(string $driver): array
    {
        if ($driver === 's3') {
            return ['s3', 'aws', 'amazon', 'amazon_s3'];
        }

        if ($driver === 'do_spaces') {
            return ['do_spaces', 'spaces', 'digitalocean', 'digitalocean_spaces'];
        }

        if ($driver === 'wasabi') {
            return ['wasabi', 'wasabi_s3'];
        }

        if ($driver === 'backblaze') {
            return ['backblaze', 'backblaze_b2', 'b2', 'blackblaze'];
        }

        return ['local', 'filesystem', 'local_adapter'];
    }

    private function logError(string $message): void
    {
        if (function_exists('error_log')) {
            error_log('[StorageManager] ' . $message);
        }
    }
}
