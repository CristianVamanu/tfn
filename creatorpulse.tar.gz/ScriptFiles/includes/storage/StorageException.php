<?php

declare(strict_types=1);

final class StorageException extends \RuntimeException
{
    /** @var string */
    private $errorCode;

    public function __construct(string $message, string $errorCode = 'general', ?\Throwable $previous = null)
    {
        $this->errorCode = $errorCode;
        parent::__construct($message, 0, $previous);
    }

    public function getErrorCode(): string
    {
        return $this->errorCode;
    }
}
