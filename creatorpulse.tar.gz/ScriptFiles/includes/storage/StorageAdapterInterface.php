<?php
declare(strict_types=1);

require_once __DIR__ . '/StorageResult.php';

interface StorageAdapterInterface
{
    /**
     * Persist a local file to remote storage.
     *
     * @param string $localPath   Absolute filesystem path to the source file.
     * @param string $remoteKey   Normalized storage key (e.g., uploads/files/... ).
     * @param string $contentType MIME type of the object being stored.
     * @param string $visibility  Desired visibility: public | private | inherit.
     * @param array  $options     Adapter-specific options (metadata, ACLs, etc.).
     *
     * @throws StorageException
     */
    public function put(
        string $localPath,
        string $remoteKey,
        string $contentType,
        string $visibility = 'private',
        array $options = []
    ): StorageResult;

    /**
     * Delete an object identified by the given key.
     *
     * @throws StorageException
     */
    public function delete(string $remoteKey): bool;

    /**
     * When $ttl is null return a stable, cacheable URL; otherwise generate a signed URL valid for $ttl seconds.
     *
     * @throws StorageException
     */
    public function url(string $remoteKey, ?int $ttl = null): string;

    public function exists(string $remoteKey): bool;

    public function copy(string $sourceKey, string $targetKey, array $options = []): bool;

    public function move(string $sourceKey, string $targetKey, array $options = []): bool;
}
