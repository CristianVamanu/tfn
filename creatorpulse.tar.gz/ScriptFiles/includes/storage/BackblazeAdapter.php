<?php

declare(strict_types=1);

require_once __DIR__ . '/S3Adapter.php';

class BackblazeAdapter extends S3Adapter
{
    public function __construct(array $config)
    {
        if (!isset($config['region']) && isset($config['backblaze_region'])) {
            $config['region'] = (string) $config['backblaze_region'];
        }

        if (empty($config['endpoint']) && !empty($config['region'])) {
            $config['endpoint'] = sprintf('https://s3.%s.backblazeb2.com', $config['region']);
        }

        if (!isset($config['path_style'])) {
            $config['path_style'] = true;
        }

        if (empty($config['public_base_url']) && !empty($config['cdn_domain'])) {
            $config['public_base_url'] = self::ensureScheme((string) $config['cdn_domain']);
        }

        parent::__construct($config);
    }

    protected static function ensureScheme(string $value): string
    {
        $value = trim($value);
        if ($value === '') {
            return '';
        }

        if (stripos($value, 'http://') === 0 || stripos($value, 'https://') === 0) {
            return rtrim($value, '/');
        }

        return 'https://' . ltrim($value, '/');
    }
}
