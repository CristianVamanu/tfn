<?php

declare(strict_types=1);

require_once __DIR__ . '/S3Adapter.php';

class WasabiAdapter extends S3Adapter
{
    public function __construct(array $config)
    {
        if (!isset($config['region']) && isset($config['wasabi_region'])) {
            $config['region'] = (string) $config['wasabi_region'];
        }

        if (empty($config['endpoint']) && !empty($config['region'])) {
            $config['endpoint'] = 'https://s3.' . $config['region'] . '.wasabisys.com';
        }

        if (empty($config['public_base_url']) && !empty($config['cdn_domain'])) {
            $config['public_base_url'] = self::ensureScheme((string) $config['cdn_domain']);
        }

        parent::__construct($config);
    }

    protected static function ensureScheme(string $value): string
    {
        $value = trim($value);
        if ($value === '') {
            return '';
        }

        if (stripos($value, 'http://') === 0 || stripos($value, 'https://') === 0) {
            return rtrim($value, '/');
        }

        return 'https://' . ltrim($value, '/');
    }
}
