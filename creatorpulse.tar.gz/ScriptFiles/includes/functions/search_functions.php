<?php
declare(strict_types=1);
trait SearchFunctions {
    public function RL_SearchUser(string $keyword, int $userID = 0, bool $creatorOnly = false): array
    {
        try {
            if (empty($keyword)) {
                return [];
            }

            if (function_exists('mb_strtolower')) {
                $normalized = mb_strtolower($keyword, 'UTF-8');
            } else {
                $normalized = strtolower($keyword);
            }

            $searchPattern = '%' . $normalized . '%';

            $creatorFilter = $creatorOnly ? " AND u.creator_status = 'approved'" : '';
            $query = "
                SELECT u.user_id, u.username, u.user_fullname, u.user_avatar, u.verified_status,
                    (SELECT fr_status FROM i_friends WHERE fr_one = :cu1 AND fr_two = u.user_id AND fr_status = 'flwr' LIMIT 1) AS is_following,
                    (SELECT fr_status FROM i_friends WHERE fr_one = u.user_id AND fr_two = :cu2 AND fr_status = 'flwr' LIMIT 1) AS is_follower,
                    (SELECT fr_status FROM i_friends WHERE fr_one = :cu3 AND fr_two = u.user_id AND fr_status = 'subscriber' LIMIT 1) AS is_subscribing,
                    (SELECT fr_status FROM i_friends WHERE fr_one = u.user_id AND fr_two = :cu4 AND fr_status = 'subscriber' LIMIT 1) AS is_subscriber
                FROM i_users u
WHERE (LOWER(u.username) LIKE :term1 OR LOWER(u.user_fullname) LIKE :term2)" . $creatorFilter . "
                ORDER BY u.user_fullname ASC
                LIMIT 15
            ";

            $stmt = $this->db->prepare($query);
            $stmt->bindValue(':term1', $searchPattern, PDO::PARAM_STR);
            $stmt->bindValue(':term2', $searchPattern, PDO::PARAM_STR);
            $stmt->bindValue(':cu1', $userID, PDO::PARAM_INT);
            $stmt->bindValue(':cu2', $userID, PDO::PARAM_INT);
            $stmt->bindValue(':cu3', $userID, PDO::PARAM_INT);
            $stmt->bindValue(':cu4', $userID, PDO::PARAM_INT);
            $stmt->execute();

            $results = [];

            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $relation = [];

                if (!empty($row['is_following'])) {
                    $relation[] = 'following';
                }
                if (!empty($row['is_follower'])) {
                    $relation[] = 'follower';
                }
                if (!empty($row['is_subscribing'])) {
                    $relation[] = 'subscribing';
                }
                if (!empty($row['is_subscriber'])) {
                    $relation[] = 'subscriber';
                }

                $results[] = [
                    'user_id'           => (int) $row['user_id'],
                    'username'          => $row['username'],
                    'fullname'          => $row['user_fullname'],
                    'verified_status'   => (int) $row['verified_status'],
                    'avatar'            => $row['user_avatar'] ?: 'uploads/user_avatars/default_avatar.png',
                    'relationship'      => implode(', ', $relation)
                ];
            }

            return $results;
        } catch (PDOException $e) {
            $this->logError('RL_SearchUser() failed: ' . $e->getMessage());
            return [];
        }
    }

    public function RL_SearchHashtags(string $keyword, int $limit = 8): array
    {
        try {
            $keyword = trim($keyword);
            if ($keyword === '') {
                return [];
            }
            if (method_exists($this, 'RL_EnsureHashtagTables')) {
                $this->RL_EnsureHashtagTables();
            }
            $normalized = ltrim($keyword, '#');
            if (function_exists('mb_strtolower')) {
                $normalized = mb_strtolower($normalized, 'UTF-8');
            } else {
                $normalized = strtolower($normalized);
            }
            $normalized = preg_replace('/[^\p{L}\p{N}_]+/u', '', $normalized) ?? '';
            if ($normalized === '') {
                return [];
            }
            $limit = max(1, min(12, $limit));
            $pattern = $normalized . '%';
            $stmt = $this->db->prepare("
                SELECT hashtag_id, tag, display_tag, use_count
                FROM i_hashtags
                WHERE tag LIKE :term1 OR display_tag LIKE :term2
                ORDER BY use_count DESC, tag ASC
                LIMIT :limit
            ");
            $stmt->bindValue(':term1', $pattern, PDO::PARAM_STR);
            $stmt->bindValue(':term2', $pattern, PDO::PARAM_STR);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (PDOException $e) {
            $this->logError('RL_SearchHashtags() failed: ' . $e->getMessage());
            return [];
        }
    }

    public function RL_SearchPosts(string $keyword, int $userID = 0, int $limit = 8): array
    {
        try {
            $keyword = trim($keyword);
            if ($keyword === '') {
                return [];
            }
            if (method_exists($this, 'RL_EnsureUserPostsSchema')) {
                $this->RL_EnsureUserPostsSchema();
            }
            if (method_exists($this, 'RL_EnsurePostMediaTable')) {
                $this->RL_EnsurePostMediaTable();
            }
            if (function_exists('mb_strtolower')) {
                $normalized = mb_strtolower($keyword, 'UTF-8');
            } else {
                $normalized = strtolower($keyword);
            }
            $limit = max(1, min(12, $limit));
            $pattern = '%' . $normalized . '%';
            $stmt = $this->db->prepare("
                SELECT
                    p.post_id,
                    p.post_title,
                    p.post_text,
                    p.post_type,
                    p.post_file,
                    p.locked_preview_path,
                    p.post_visibility,
                    p.post_created_time,
                    u.username,
                    u.user_fullname,
                    u.user_avatar,
                    u.verified_status,
                    (SELECT pm.path FROM i_post_media pm WHERE pm.post_id = p.post_id AND pm.role = 'cover' ORDER BY pm.id ASC LIMIT 1) AS cover_path
                FROM i_user_posts p
                INNER JOIN i_users u ON u.user_id = p.post_owner_id
                WHERE (p.approval_status IS NULL OR p.approval_status = 'approved')
                  AND (p.post_visibility = 'everyone' OR p.post_owner_id = :viewer_id)
                  AND (
                    LOWER(COALESCE(p.post_title, '')) LIKE :term1
                    OR LOWER(COALESCE(p.post_text, '')) LIKE :term2
                  )
                ORDER BY p.post_created_time DESC, p.post_id DESC
                LIMIT :limit
            ");
            $stmt->bindValue(':viewer_id', $userID, PDO::PARAM_INT);
            $stmt->bindValue(':term1', $pattern, PDO::PARAM_STR);
            $stmt->bindValue(':term2', $pattern, PDO::PARAM_STR);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();

            $results = [];
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $text = trim(strip_tags((string) ($row['post_text'] ?? '')));
                $title = trim(strip_tags((string) ($row['post_title'] ?? '')));
                $file = trim((string) ($row['cover_path'] ?? ''));
                if ($file === '') {
                    $file = trim((string) ($row['locked_preview_path'] ?? ''));
                }
                if ($file === '') {
                    $parts = array_values(array_filter(array_map('trim', explode(',', (string) ($row['post_file'] ?? '')))));
                    $file = $parts[0] ?? '';
                }
                $excerpt = $text;
                if (function_exists('mb_strlen') && mb_strlen($excerpt, 'UTF-8') > 90) {
                    $excerpt = mb_substr($excerpt, 0, 90, 'UTF-8') . '...';
                } elseif (!function_exists('mb_strlen') && strlen($excerpt) > 90) {
                    $excerpt = substr($excerpt, 0, 90) . '...';
                }
                $results[] = [
                    'post_id' => (int) ($row['post_id'] ?? 0),
                    'title' => $title,
                    'excerpt' => $excerpt,
                    'post_type' => (string) ($row['post_type'] ?? ''),
                    'thumb' => $file,
                    'username' => (string) ($row['username'] ?? ''),
                    'fullname' => (string) ($row['user_fullname'] ?? ''),
                    'avatar' => (string) ($row['user_avatar'] ?? 'uploads/user_avatars/default_avatar.png'),
                    'verified_status' => (int) ($row['verified_status'] ?? 0),
                ];
            }
            return $results;
        } catch (PDOException $e) {
            $this->logError('RL_SearchPosts() failed: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Retrieve recent searched users for the logged-in user.
     * Fetches the user records from i_users table based on recent search entries.
     *
     * @param int $userID The ID of the logged-in user.
     * @param int $limit Optional limit on number of results (default 5).
     * @return array Returns a list of user data arrays or empty array if none found.
     */
    public function RL_RecentSearches(int $userID, int $limit = 5): array
    {
        try {
            if ($userID <= 0) {
                return [];
            }

            $query = "
                SELECT u.user_id, u.username, u.user_fullname, u.user_avatar, u.verified_status
                FROM i_recent_searches r
                INNER JOIN i_users u ON r.keyword = u.username
                WHERE r.user_id = :user_id
                ORDER BY r.search_time DESC
                LIMIT :limit
            ";

            $stmt = $this->db->prepare($query);
            $stmt->bindValue(':user_id', $userID, PDO::PARAM_INT);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();

            $results = [];

            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $results[] = [
                    'user_id'         => (int) $row['user_id'],
                    'username'        => $row['username'],
                    'fullname'        => $row['user_fullname'],
                    'avatar'          => $row['user_avatar'] ?: 'uploads/user_avatars/default.jpeg',
                    'verified_status' => (int) ($row['verified_status'] ?? 0),
                    'relationship'    => '' // optionally extendable later
                ];
            }

            return $results;
        } catch (PDOException $e) {
            $this->logError('RL_RecentSearches() failed: ' . $e->getMessage());
            return [];
        }
    }
}
