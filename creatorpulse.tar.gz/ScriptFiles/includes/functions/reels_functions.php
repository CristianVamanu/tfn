<?php
declare(strict_types=1);
trait ReelsFunctions {
    /**
     * Fetch ALL posts with post_type = 'video' without enforcing relation/visibility.
     *
     * Notes:
     * - This does NOT filter by visibility or relationships; caller decides what to show.
     * - Kept return shape similar to other feed methods so templates can reuse the same keys.
     * - `relation_status` is always null here.
     *
     * @param int $userID  Current viewer id (used only to compute is_owner flag; 0 if guest)
     * @param int $limit   Pagination size
     * @param int $offset  Pagination offset
     * @return array<int, array<string, mixed>>
     */
    public function RL_FeedAllVideos(int $userID = 0, int $limit = 20, int $offset = 0): array
    {
        try {
            $limit  = max(1, (int) $limit);
            $offset = max(0, (int) $offset);

            $sql = "
                SELECT
                    p.post_id,
                    p.post_owner_id,
                    p.post_type,
                    p.post_file,
                    p.post_text,
                    p.post_views,
                    p.post_visibility,
                    p.post_price,
                    p.comment_status,
                    p.like_status,
                    p.approval_status,
                    p.approval_notes,
                    p.approved_at,
                    p.approved_by,
                    p.post_created_time,

                    u.user_id         AS owner_id,
                    u.username        AS owner_username,
                    u.user_fullname   AS owner_fullname,
                    u.user_avatar     AS owner_avatar,
                    u.verified_status AS owner_verified
                FROM i_user_posts AS p
                INNER JOIN i_users AS u
                    ON u.user_id = p.post_owner_id
                WHERE p.post_type = 'video' AND p.post_visibility = 'everyone' AND (p.approval_status IS NULL OR p.approval_status = 'approved')
                ORDER BY p.post_created_time DESC
                LIMIT $offset, $limit
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->execute();

            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            $list = [];
            foreach ($rows as $row) {
                $ownerId = (int) $row['post_owner_id'];
                $list[] = [
                    // Post fields
                    'post_id'           => (int) $row['post_id'],
                    'post_owner_id'     => $ownerId,
                    'post_type'         => (string) $row['post_type'],
                    'post_file'         => (string) $row['post_file'],
                    'post_text'         => (string) $row['post_text'],
                    'post_visibility'   => (string) $row['post_visibility'],
                    'post_price'        => $row['post_price'] !== null ? (string) $row['post_price'] : null,
                    'comment_status'    => (string) $row['comment_status'],
                    'like_status'       => (string) $row['like_status'],
                    'approval_status'   => isset($row['approval_status']) ? (string)$row['approval_status'] : 'approved',
                    'approval_notes'    => $row['approval_notes'] !== null ? (string)$row['approval_notes'] : null,
                    'approved_at'       => $row['approved_at'] !== null ? (int)$row['approved_at'] : null,
                    'approved_by'       => $row['approved_by'] !== null ? (int)$row['approved_by'] : null,
                    'post_created_time' => (int) $row['post_created_time'],
                    'post_views'        => (int) $row['post_views'],

                    // Owner fields
                    'owner_id'          => (int) $row['owner_id'],
                    'owner_username'    => (string) $row['owner_username'],
                    'owner_fullname'    => (string) $row['owner_fullname'],
                    'owner_avatar'      => (string) $row['owner_avatar'],
                    'owner_verified'    => (int) $row['owner_verified'],

                    // No relation context in this query
                    'relation_status'   => null,

                    // Convenience flag
                    'is_owner'          => ($userID > 0 && $userID === $ownerId),
                ];
            }

            return $list;
        } catch (\Throwable $e) {
            $this->logError('RL_FeedAllVideos failed: ' . $e->getMessage());
            return [];
        }
    }
    public function videoThumbNail(string $videoPath): string
    {
        $p = trim($videoPath);
        if ($p === '') { return ''; }
        // Strip query if any
        $qpos = strpos($p, '?');
        if ($qpos !== false) {
            $p = substr($p, 0, $qpos);
        }
        // Replace extension with .png
        $dot = strrpos($p, '.');
        if ($dot !== false) {
            $p = substr($p, 0, $dot) . '.png';
        } else {
            $p .= '.png';
        }
        return $this->url($p);
    }
}
