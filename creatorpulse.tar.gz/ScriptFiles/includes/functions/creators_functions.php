<?php
trait CreatorsFunctions {
    public function RL_GetCreatorsWithPublicPreviews(
        int $limit = 24,
        int $offset = 0,
        array $userFilter = []
    ): array {
        // --- 1) Fetch user rows + counters in one query (followers/following/posts) ---
        // Followers: fr_two = user_id, status in ('flwr','subscriber')
        // Following: fr_one = user_id, status in ('flwr','subscriber')
        // Posts total: all posts by user (any visibility)
        $where = [];
        $params = [
            ':limit'  => $limit,
            ':offset' => $offset,
        ];

        if (!empty($userFilter)) {
            // Build IN (...) safely
            $in = [];
            foreach ($userFilter as $i => $uid) {
                $key = ':u' . $i;
                $in[] = $key;
                $params[$key] = (int) $uid;
            }
            $where[] = 'u.user_id IN (' . implode(',', $in) . ')';
        }

        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        $sqlUsers = "
            SELECT
                u.user_id,
                u.username,
                u.user_fullname,
                u.user_avatar,
                u.verified_status,
                u.about_me,
                /* followers = people who follow or subscribe to u */
                (
                    SELECT COUNT(*)
                    FROM i_friends f
                    WHERE f.fr_two = u.user_id
                      AND f.fr_status IN ('flwr','subscriber')
                ) AS followers_count,
                /* following = accounts that u follows or subscribes to */
                (
                    SELECT COUNT(*)
                    FROM i_friends f
                    WHERE f.fr_one = u.user_id
                      AND f.fr_status IN ('flwr','subscriber')
                ) AS following_count,
                /* total posts by user (any visibility) */
                (
                    SELECT COUNT(*)
                    FROM i_user_posts p
                    WHERE p.post_owner_id = u.user_id AND (p.approval_status IS NULL OR p.approval_status = 'approved')
                ) AS posts_count
            FROM i_users u
            {$whereSql}
            ORDER BY u.user_id ASC
            LIMIT :limit OFFSET :offset
        ";

        $st = $this->db->prepare($sqlUsers);
        foreach ($params as $k => $v) {
            $type = is_int($v) ? \PDO::PARAM_INT : \PDO::PARAM_STR;
            $st->bindValue($k, $v, $type);
        }
        $st->execute();

        $users = $st->fetchAll(\PDO::FETCH_ASSOC);
        if (!$users) {
            return [];
        }

        // Map for quick access
        $byId = [];
        $ids = [];
        foreach ($users as $row) {
            $uid = (int) $row['user_id'];
            $ids[] = $uid;
            $row['latest_posts'] = []; // will fill below
            $byId[$uid] = $row;
        }

        // --- 2) Fetch last 3 public posts for all these users at once ---
        // Rule: only post_visibility = 'everyone'
        $inParts = [];
        $binds = [];
        foreach ($ids as $i => $uid) {
            $key = ':pid' . $i;
            $inParts[] = $key;
            $binds[$key] = $uid;
        }

        $sqlPosts = "
            SELECT
                p.post_id,
                p.post_owner_id,
                p.post_type,
                p.post_file,
                p.post_visibility,
                p.post_created_time
            FROM i_user_posts p
            WHERE p.post_owner_id IN (" . implode(',', $inParts) . ")
              AND p.post_visibility = 'everyone'
              AND (p.approval_status IS NULL OR p.approval_status = 'approved')
            ORDER BY p.post_owner_id ASC, p.post_created_time DESC
        ";

        $pst = $this->db->prepare($sqlPosts);
        foreach ($binds as $k => $v) {
            $pst->bindValue($k, $v, \PDO::PARAM_INT);
        }
        $pst->execute();

        // Keep only top 3 per user
        while ($p = $pst->fetch(\PDO::FETCH_ASSOC)) {
            $owner = (int) $p['post_owner_id'];
            if (!isset($byId[$owner])) {
                continue;
            }
            if (count($byId[$owner]['latest_posts']) < 3) {
                // Normalize first image path if image with multiple files
                if (($p['post_type'] ?? '') === 'image') {
                    $first = $this->firstMediaPath((string) ($p['post_file'] ?? ''));
                    $p['media_thumb'] = $first; // view will prefix $base_url if needed
                } else {
                    // For videos, leave file as-is; view can call $RL->videoThumbNail(...)
                    $p['media_thumb'] = (string) ($p['post_file'] ?? '');
                }
                $byId[$owner]['latest_posts'][] = $p;
            }
        }

        // Return as a numerically indexed array for foreach
        return array_values($byId);
    }

    /**
     * Utility: return the first path from a comma-separated list.
     */
    private function firstMediaPath(string $postFile): string
    {
        $postFile = trim($postFile);
        if ($postFile === '') {
            return '';
        }
        $parts = array_map('trim', explode(',', $postFile));
        return $parts[0] ?? '';
    }

    /**
     * Fetch suggested users for sidebar.
     *
     * @param int    $viewerId current viewer id (0 for guest)
     * @param int    $limit    max number of users to return
     * @param string $mode     creators|users|mixed
     * @return array<int, array<string,mixed>>
     */
    public function RL_GetSuggestedUsers(int $viewerId = 0, int $limit = 5, string $mode = 'creators'): array
    {
        try {
            $limit = max(1, min(24, $limit));
            $mode = in_array($mode, ['creators', 'users', 'mixed'], true) ? $mode : 'creators';

            $runQuery = function (string $modeFilter) use ($viewerId, $limit): array {
                $where = [
                    'u.is_banned = 0',
                    "u.user_mode = 'user'",
                ];
                $params = [
                    ':limit' => $limit,
                ];

                if ($viewerId > 0) {
                    $where[] = 'u.user_id != :viewer';
                    $params[':viewer'] = $viewerId;
                }

                if ($modeFilter === 'creators') {
                    $where[] = "u.creator_status = 'approved'";
                } elseif ($modeFilter === 'users') {
                    $where[] = "u.creator_status IN ('none','pending','rejected')";
                } // mixed = no extra creator filter

                $whereSql = implode(' AND ', $where);

                $sql = "
                    SELECT
                        u.user_id,
                        u.username,
                        u.user_fullname,
                        u.user_avatar,
                        u.verified_status,
                        u.about_me,
                        u.creator_status
                    FROM i_users u
                    WHERE {$whereSql}
                      AND NOT EXISTS (
                        SELECT 1
                          FROM i_friends f
                         WHERE f.fr_one = :viewer_check
                           AND f.fr_two = u.user_id
                           AND f.fr_status IN ('flwr','subscriber')
                      )
                    ORDER BY COALESCE(u.last_login_time, 0) DESC, u.user_id DESC
                    LIMIT :limit
                ";

                $st = $this->db->prepare($sql);
                foreach ($params as $k => $v) {
                    $type = is_int($v) ? \PDO::PARAM_INT : \PDO::PARAM_STR;
                    $st->bindValue($k, $v, $type);
                }
                $st->bindValue(':viewer_check', $viewerId, \PDO::PARAM_INT);
                $st->bindValue(':limit', $limit, \PDO::PARAM_INT);
                $st->execute();

                $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
                $out = [];
                foreach ($rows as $row) {
                    $uid = (int) ($row['user_id'] ?? 0);
                    if ($uid <= 0) {
                        continue;
                    }
                    $avatar = (string) ($row['user_avatar'] ?? '');
                    if (method_exists($this, 'RL_userAvatar')) {
                        $avatar = $this->RL_userAvatar($uid);
                    }
                    $out[] = [
                        'user_id'         => $uid,
                        'username'        => (string) ($row['username'] ?? ''),
                        'user_fullname'   => (string) ($row['user_fullname'] ?? ''),
                        'user_avatar'     => $avatar,
                        'verified_status' => (int) ($row['verified_status'] ?? 0),
                        'about_me'        => (string) ($row['about_me'] ?? ''),
                        'creator_status'  => (string) ($row['creator_status'] ?? 'none'),
                    ];
                }
                return $out;
            };

            $suggestions = $runQuery($mode);
            if (empty($suggestions) && $mode !== 'mixed') {
                $suggestions = $runQuery('mixed');
            }

            return $suggestions;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetSuggestedUsers failed: ' . $e->getMessage());
            }
            return [];
        }
    }
}
?>
