<?php
declare(strict_types=1);

trait ExploreFunctions {
    /**
     * Build Explore blocks from the latest public posts.
     *
     * Each post is normalized to a single tile:
     *  - image → first image from the CSV stored in post_file
     *  - video → the video path (thumbnail is derived at render time)
     *
     * @param int $limit Maximum posts to scan (safely clamped by fetchPosts).
     * @return array<int, array<int, array{type:string,src:string,thumb?:string,id?:int,multi?:bool,role?:string}>>
     */
    public function getBlocks(int $limit = 60): array
    {
        $rows = $this->fetchPosts($limit);

        // Each post is reduced to a single tile (image -> first image, video -> video path)
        $tiles = [];
        foreach ($rows as $r) {
            $type = (string) $r['post_type'];
            if ($type === 'image') {
                $src = $this->firstImage((string) $r['post_file']);
                $imgCount = $this->countImages((string) $r['post_file']);
                if ($src === '') {
                    continue;
                }
                $tiles[] = [
                    'type'  => 'image',
                    'src'   => $this->url($src),
                    'id'    => (int) ($r['post_id'] ?? 0),
                    'multi' => ($imgCount > 1),
                    // Plumb context fields for alt text
                    'username'     => (string)($r['username'] ?? ''),
                    'display_name' => (string)($r['user_fullname'] ?? ''),
                    'caption'      => (string)($r['post_text'] ?? ''),
                ];
            } else {
                $tiles[] = [
                    'type' => 'video',
                    'src'  => $this->url((string) $r['post_file']),
                    'id'   => (int) ($r['post_id'] ?? 0),
                    // Context for alt
                    'username'     => (string)($r['username'] ?? ''),
                    'display_name' => (string)($r['user_fullname'] ?? ''),
                    'caption'      => (string)($r['post_text'] ?? ''),
                ];
            }
        }

        // Group into 5-item blocks (rule: max 1 video per block)
        return $this->packIntoBlocks($tiles);
    }

    /**
     * Render the Explore grid.
     *
     * The layout alternates per block based on $startLayout: 'right' → 'left' → ...
     * This method echoes HTML directly. Use renderToString() if buffering is preferred.
     *
     * @param array<int, array<int, array{type:string,src:string,thumb?:string,id?:int,multi?:bool,role?:string}>> $blocks
     * @param string $startLayout Either 'right' or 'left'.
     */
    public function render(array $blocks, string $startLayout = 'right', bool $wrap = true): void
    {
        if ($wrap) {
            echo '<div class="explore-grid">' . PHP_EOL;
        }

        $right = ($startLayout === 'right');
        $areas = ['a', 'b', 'c', 'd'];

        foreach ($blocks as $block) {
            $layoutClass = $right ? 'is-right' : 'is-left';
            $right = !$right;

            $realItems = array_values(array_filter($block, static function ($item): bool {
                return is_array($item) && !empty($item['src']) && in_array(($item['type'] ?? ''), ['image', 'video'], true);
            }));

            if (count($realItems) > 0 && count($realItems) < 5) {
                echo '<section class="explore-block is-compact">' . PHP_EOL;

                foreach ($realItems as $item) {
                    if (($item['type'] ?? '') === 'image') {
                        $badge = $this->renderBadge('images', !empty($item['multi']));
                        $eng = $this->getEngagement((int)($item['id'] ?? 0));
                        $cap = dzShortCaption($item['caption'] ?? '', 80);
                        $handle = (string)($item['display_name'] ?? '');
                        if ($handle === '' && !empty($item['username'])) { $handle = (string)$item['username']; }
                        if ($handle !== '') { $handle = '@' . $handle; }
                        $alt = $cap !== '' ? $cap : ($handle !== '' ? sprintf(customLang('alt_tile_by_user'), $handle) : customLang('image_alt_generic'));
                        $this->renderSquare($item['src'], 'compact', (int)($item['id'] ?? 0), $badge, $eng, $alt);
                    } elseif (($item['type'] ?? '') === 'video') {
                        $badge = $this->renderBadge('video', true);
                        $eng = $this->getEngagement((int)($item['id'] ?? 0));
                        $cap = dzShortCaption($item['caption'] ?? '', 80);
                        $handle = (string)($item['display_name'] ?? '');
                        if ($handle === '' && !empty($item['username'])) { $handle = (string)$item['username']; }
                        if ($handle !== '') { $handle = '@' . $handle; }
                        $alt = $cap !== '' ? $cap : ($handle !== '' ? sprintf(customLang('alt_tile_by_user'), $handle) : customLang('image_alt_generic'));
                        $this->renderSquareVideo($item['src'], 'compact', (int)($item['id'] ?? 0), $badge, $eng, $alt);
                    }
                }

                echo '</section>' . PHP_EOL;
                continue;
            }

            echo '<section class="explore-block ' . $layoutClass . '">' . PHP_EOL;

            // --- Square areas: block[0..3] -> a,b,c,d ---
            for ($i = 0; $i < 4; $i++) {
                $item = $block[$i] ?? ['type' => 'ghost', 'src' => ''];

                if (($item['type'] ?? '') === 'image' && !empty($item['src'])) {
                    $badge = $this->renderBadge('images', !empty($item['multi']));
                    $eng = $this->getEngagement((int)($item['id'] ?? 0));
                    // Alt: caption → content by @username → generic
                    $cap = dzShortCaption($item['caption'] ?? '', 80);
                    $handle = (string)($item['display_name'] ?? '');
                    if ($handle === '' && !empty($item['username'])) { $handle = (string)$item['username']; }
                    if ($handle !== '') { $handle = '@' . $handle; }
                    $alt = $cap !== '' ? $cap : ($handle !== '' ? sprintf(customLang('alt_tile_by_user'), $handle) : customLang('image_alt_generic'));
                    $this->renderSquare($item['src'], $areas[$i], (int)($item['id'] ?? 0), $badge, $eng, $alt);
                } elseif (($item['type'] ?? '') === 'video' && !empty($item['src'])) {
                    $badge = $this->renderBadge('video', true);
                    // Render video in square area
                    $eng = $this->getEngagement((int)($item['id'] ?? 0));
                    $cap = dzShortCaption($item['caption'] ?? '', 80);
                    $handle = (string)($item['display_name'] ?? '');
                    if ($handle === '' && !empty($item['username'])) { $handle = (string)$item['username']; }
                    if ($handle !== '') { $handle = '@' . $handle; }
                    $alt = $cap !== '' ? $cap : ($handle !== '' ? sprintf(customLang('alt_tile_by_user'), $handle) : customLang('image_alt_generic'));
                    $this->renderSquareVideo($item['src'], $areas[$i], (int)($item['id'] ?? 0), $badge, $eng, $alt);
                } else {
                    $this->renderGhost($areas[$i]);
                }
            }

            // --- Tall area: block[4] -> V ---
            $tall = $block[4] ?? ['type' => 'ghost', 'src' => ''];

            if (($tall['type'] ?? '') === 'video' && !empty($tall['src'])) {
                $badge = $this->renderBadge('video', true);
                $engTall = $this->getEngagement((int)($tall['id'] ?? 0));
                $cap = dzShortCaption($tall['caption'] ?? '', 80);
                $handle = (string)($tall['display_name'] ?? '');
                if ($handle === '' && !empty($tall['username'])) { $handle = (string)$tall['username']; }
                if ($handle !== '') { $handle = '@' . $handle; }
                $altTall = $cap !== '' ? $cap : ($handle !== '' ? sprintf(customLang('alt_tile_by_user'), $handle) : customLang('image_alt_generic'));
                $this->renderTallVideo($tall['src'], (int)($tall['id'] ?? 0), $badge, $engTall, $altTall);
            } elseif (($tall['type'] ?? '') === 'image' && !empty($tall['src'])) {
                $badge = $this->renderBadge('images', !empty($tall['multi']));
                // Fallback: if no video, render tall image
                $engTall = $this->getEngagement((int)($tall['id'] ?? 0));
                $cap = dzShortCaption($tall['caption'] ?? '', 80);
                $handle = (string)($tall['display_name'] ?? '');
                if ($handle === '' && !empty($tall['username'])) { $handle = (string)$tall['username']; }
                if ($handle !== '') { $handle = '@' . $handle; }
                $altTall = $cap !== '' ? $cap : ($handle !== '' ? sprintf(customLang('alt_tile_by_user'), $handle) : customLang('image_alt_generic'));
                $this->renderTallImage($tall['src'], (int)($tall['id'] ?? 0), $badge, $engTall, $altTall);
            } else {
                $this->renderGhost('V', true);
            }

            echo '</section>' . PHP_EOL;
        }

        if ($wrap) {
            echo '</div>' . PHP_EOL;
        }
    }

    /**
     * Try to invoke a like-count function/method with flexible arity.
     * Supports both signatures: fn(postId) and fn(postId, 'like').
     *
     * @param callable $callable Candidate like counter.
     * @param int $postId Post identifier.
     * @return int|null Non-negative count or null on failure.
     */
    private function __tryInvokeLikeCallable($callable, int $postId): ?int
    {
        try {
            if (is_array($callable)) {
                $ref = new \ReflectionMethod($callable[0], $callable[1]);
            } else {
                $ref = new \ReflectionFunction($callable);
            }
            $required = $ref->getNumberOfRequiredParameters();

            if ($required <= 1) {
                $val = \call_user_func($callable, $postId);
            } elseif ($required === 2) {
                // Some codebases require the reaction type as second arg
                $val = \call_user_func($callable, $postId, 'like');
            } else {
                // Fallback to single-arg call
                $val = \call_user_func($callable, $postId);
            }

            $v = (int) $val;
            return ($v >= 0) ? $v : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Resolve and attempt known like-count providers across common scopes.
     * Checks: $this methods, $this->RL methods, and global functions.
     *
     * @param string $fn Function/method name to try.
     * @param int $postId Post identifier.
     * @return int|null Non-negative count or null if unresolved.
     */
    private function __resolveAndCallLike(string $fn, int $postId): ?int
    {
        // 1) Method on this
        if (method_exists($this, $fn)) {
            $res = $this->__tryInvokeLikeCallable([$this, $fn], $postId);
            if ($res !== null) { return $res; }
        }
        // 2) Method on $this->RL, if present
        if (property_exists($this, 'RL') && is_object($this->RL) && method_exists($this->RL, $fn)) {
            $res = $this->__tryInvokeLikeCallable([$this->RL, $fn], $postId);
            if ($res !== null) { return $res; }
        }
        // 3) Global function
        if (\function_exists($fn)) {
            $res = $this->__tryInvokeLikeCallable($fn, $postId);
            if ($res !== null) { return $res; }
        }
        return null;
    }

    /**
     * Count likes directly from the real schema.
     *
     * Table: i_post_liked
     * Columns: liked_item_id (int), liked_item_type ENUM('post','comment')
     *
     * @param int $postId Post identifier.
     * @return int|null Non-negative like count or null on failure.
     */
    private function tryCountLikesFromDb(int $postId): ?int
    {
        try {
            $sql = "SELECT COUNT(*) AS c
                    FROM i_post_liked
                    WHERE liked_item_id = :pid
                      AND liked_item_type = 'post'";
            $st  = $this->db->prepare($sql);
            $st->bindValue(':pid', (int)$postId, \PDO::PARAM_INT);
            if ($st->execute()) {
                $row = $st->fetch(\PDO::FETCH_ASSOC);
                if ($row && isset($row['c'])) {
                    $v = (int)$row['c'];
                    if ($v >= 0) { return $v; }
                }
            }
        } catch (\Throwable $e) {
            // fall through to indirect providers
        }
        return null;
    }

    /**
     * Safely get total like count for a post by trying DB first, then common method names.
     * Caches results per-request to avoid repeated queries/calls.
     */
    private function getTotalLikes(int $postId): int
    {
        static $memo = [];
        if (isset($memo[$postId])) { return $memo[$postId]; }

        // 1) Use the real DB table as the primary source of truth
        $dbCount = $this->tryCountLikesFromDb($postId);
        if ($dbCount !== null) {
            return $memo[$postId] = (int)$dbCount;
        }

        // 2) Fallback to known function/method names (if project provides them)
        $candidates = [
            'RL_CountLikes'
        ];
        foreach ($candidates as $fn) {
            $val = $this->__resolveAndCallLike($fn, $postId);
            if ($val !== null) {
                return $memo[$postId] = (int)$val;
            }
        }

        // 3) Nothing matched
        return $memo[$postId] = 0;
    }

    /**
     * Safely get total comment count for a post by trying known method names.
     * Defaults to 0 if no provider is available.
     */
    private function getTotalComments(int $postId): int
    {
        $candidates = [
            'RL_TotalComment'
        ];
        foreach ($candidates as $fn) {
            if (method_exists($this, $fn)) {
                try {
                    $v = (int) $this->{$fn}($postId);
                    if ($v >= 0) { return $v; }
                } catch (\Throwable $e) { /* ignore */ }
            }
        }
        return 0;
    }

    /**
     * Convenience wrapper to fetch both metrics at once.
     *
     * @param int $postId
     * @return array{likes:int, comments:int}
     */
    private function getEngagement(int $postId): array
    {
        return [
            'likes'    => $this->getTotalLikes($postId),
            'comments' => $this->getTotalComments($postId),
        ];
    }

    /**
     * Render hover overlay with like/comment counts.
     * CSS handles visibility on hover; markup remains minimal (no inline styles).
     *
     * @param array{likes:int, comments:int} $eng
     */
    private function renderOverlay(array $eng): void
    {
        $likes = (int) ($eng['likes'] ?? 0);
        $comms = (int) ($eng['comments'] ?? 0);

        $base = $this->resolveIconPath();


        echo '  <div class="tile-overlay flex align_items" aria-hidden="true">';
        echo '    <span class="metric metric-like flex align_items"><span class="metric-icon flex align_items">'. renderVerifiedBadge($base . 'post_liked.svg', true) .'</span><span class="metric-value flex align_items">' . $likes . '</span></span>';
        echo '    <span class="metric metric-comment flex align_items"><span class="metric-icon flex align_items">'. renderVerifiedBadge($base . 'post_commented.svg', true) .'</span><span class="metric-value flex align_items">' . $comms . '</span></span>';
        echo '  </div>' . PHP_EOL;
    }

    // --- Low-level helpers ----------------------------------------------------

    /**
     * Fetch latest public posts for the Explore feed.
     *
     * Applies a hard safety clamp on LIMIT and orders by recency.
     *
     * @param int $limit
     * @return array<int, array<string,mixed>>
     */
    /**
     * Test checklist (Explore alt text):
     * - Tiles show caption-based alt when post_text is present
     * - Else alt falls back to "Content by @username"
     * - Else uses generic image_alt_generic
     * - No extra queries in loops (single SELECT with JOIN)
     */
    private function fetchPosts(int $limit): array
    {
        // Apply safe clamp + int cast
        if ($limit < 1)  { $limit = 1; }
        if ($limit > 200){ $limit = 200; }
        $limit = (int) $limit;

        // Include username/display name and caption for contextual alt (no extra per-row queries)
        $sql = "SELECT p.post_id, p.post_type, p.post_file, p.post_created_time, p.post_text,
                       u.username, u.user_fullname
                FROM i_user_posts p
                JOIN i_users u ON u.user_id = p.post_owner_id
                WHERE p.post_visibility = 'everyone' AND (p.approval_status IS NULL OR p.approval_status = 'approved')
                ORDER BY p.post_created_time DESC
                LIMIT {$limit}";
        $st  = $this->db->prepare($sql);
        $st->execute();
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }

    /**
     * Pack a flat tile list into 5-item blocks (a,b,c,d + V).
     *
     * Rule: at most one tall video per block. Extra videos may occupy square
     * slots if available; otherwise they are deferred to the next block.
     *
     * @param array<int, array{type:string,src:string,id?:int,multi?:bool}> $tiles
     * @return array<int, array<int, array{type:string,src:string,id?:int,multi?:bool,role?:string}>>
     */
    private function packIntoBlocks(array $tiles): array
    {
        $queue  = array_values($tiles); // queue to process
        $blocks = [];

        // Upper guard to avoid infinite loops (generous)
        $outerGuard = 10000;

        while (!empty($queue) && $outerGuard-- > 0) {
            $images   = [];   // squares
            $tall     = null; // video (or fallback image)
            $next     = [];   // items we couldn't process this round
            $progress = false;

            // Iterate until we gather 4 squares + 1 tall for this block
            while (!empty($queue) && (count($images) < 4 || $tall === null)) {
                $t = array_shift($queue);
                $progress = true;

                if (!is_array($t) || empty($t['type'])) {
                    continue;
                }

                if ($t['type'] === 'video') {
                    if ($tall === null) {
                        $tall = $t; // this block's tall area
                    } else {
                        // Second+ video: if squares have space, fill it; else leave for next block
                        if (count($images) < 4) {
                            $images[] = $t; // render video in square
                        } else {
                            $next[] = $t;
                        }
                    }
                } elseif ($t['type'] === 'image') {
                    if (count($images) < 4) {
                        $images[] = $t;
                    } else {
                        $next[] = $t;
                    }
                } else {
                    // Unknown type -> skip
                    continue;
                }
            }

            // If no tall is set, promote the last image to tall (if available)
            if ($tall === null) {
                if (count($images) >= 1) {
                    $tall = array_pop($images);
                } else {
                    // If neither tall nor square exists and no progress was made, exit
                    if (!$progress) { break; }
                    // Otherwise, try the next round
                    continue;
                }
            }

            // Prepare the block as a,b,c,d + V
            $block = [];
            foreach ($images as $img) {
                $block[] = $img;
            }
            while (count($block) < 4) {
                $block[] = ['type' => 'ghost', 'src' => ''];
            }
            $tall['role'] = 'tall';
            $block[] = $tall;

            $blocks[] = $block;

            // Update queue: leftovers + remaining
            $prevCount = count($queue);
            $queue = array_merge($next, $queue);

            // Break if no progress was made this round
            if (!$progress && $prevCount === count($queue)) {
                break;
            }
        }

        return $blocks;
    }

    /**
     * Try to resolve icon base path.
     * Uses $this->iconPath if defined, else $GLOBALS['iconPath'] if set, else ''.
     *
     * @return string Trailing slash guaranteed when non-empty.
     */
    private function resolveIconPath(): string
    {
        // If the using class defines $iconPath
        if (property_exists($this, 'iconPath') && !empty($this->iconPath)) {
            return rtrim((string) $this->iconPath, '/') . '/';
        }
        // Try global scope (page template usually sets this)
        $global = $GLOBALS['iconPath'] ?? '';
        return $global ? rtrim((string) $global, '/') . '/' : '';
    }

    /**
     * Wrapper to render a badge HTML for video/images icon.
     *
     * @param 'video'|'images' $kind
     * @param bool $show Whether to output the badge.
     * @return string Badge HTML or empty string when suppressed.
     */
    private function renderBadge(string $kind, bool $show): string
    {
        if (!$show) {
            return '';
        }
        $base = $this->resolveIconPath();
        if ($base === '') {
            return '';
        }
        // renderVerifiedBadge is assumed globally available in templates
        if ($kind === 'video') {
            return (string) renderVerifiedBadge($base . 'video.svg', true);
        }
        if ($kind === 'images') {
            return (string) renderVerifiedBadge($base . 'images.svg', true);
        }
        return '';
    }

    /**
     * Count images in a comma-separated list.
     */
    private function countImages(string $csv): int
    {
        if ($csv === '') { return 0; }
        $parts = array_filter(array_map('trim', explode(',', $csv)));
        return count($parts);
    }

    /**
     * Render a square tile with optional badge and engagement overlay.
     */
    // Render a square tile; caller provides alt text for context
    private function renderSquare(string $src, string $area, int $postId, string $badgeHtml = '', ?array $engagement = null, ?string $altText = null): void
    {
        echo '<div class="tile tile--square area-' . $area . ' tile-'. (int) $postId .' getFullPost" data-post-id="' . (int) $postId . '">';
        if ($badgeHtml !== '') {
            echo '  <div class="tile-badge tile-badge--tr">' . $badgeHtml . '</div>';
        }
        $alt = $altText !== null && $altText !== '' ? iN_HelpSecure($altText) : iN_HelpSecure(customLang('image_alt_generic'));
        echo '  <img src="' . htmlspecialchars($src, ENT_QUOTES, 'UTF-8') . '" alt="' . $alt . '">';
        if (is_array($engagement)) {
            $this->renderOverlay($engagement);
        }
        echo '</div>' . PHP_EOL;
    }

    /**
     * Derive thumbnail path for a given video file.
     * Example: /uploads/reels/2025-08-16/foo.mp4 -> /uploads/reels/2025-08-16/foo.png
     */
    private function videoThumb(string $videoPath): string
    {
        $p = trim($videoPath);
        if ($p === '') { return ''; }
        // Strip query if any
        $qpos = strpos($p, '?');
        if ($qpos !== false) {
            $p = substr($p, 0, $qpos);
        }
        // Replace extension with .png
        $dot = strrpos($p, '.');
        if ($dot !== false) {
            $p = substr($p, 0, $dot) . '.png';
        } else {
            $p .= '.png';
        }
        return $this->url($p);
    }

    /**
     * Render a video tile in a square area using the derived thumbnail.
     */
    private function renderSquareVideo(string $src, string $area, int $postId, string $badgeHtml = '', ?array $engagement = null, ?string $altText = null): void
    {
        $thumb = $this->videoThumb($src);

        echo '<div class="tile tile--square area-' . $area . ' tile--video tile-'. (int) $postId .' getFullPost" data-post-id="' . (int) $postId . '">';
        if ($badgeHtml !== '') {
            echo '  <div class="tile-badge tile-badge--tr">' . $badgeHtml . '</div>';
        }
        $alt = $altText !== null && $altText !== '' ? iN_HelpSecure($altText) : iN_HelpSecure(customLang('image_alt_generic'));
        echo '  <img src="' . htmlspecialchars($thumb, ENT_QUOTES, 'UTF-8') . '" alt="' . $alt . '">';
        if (is_array($engagement)) {
            $this->renderOverlay($engagement);
        }
        echo '</div>' . PHP_EOL;
    }

    /**
     * Render a tall video tile using the derived thumbnail.
     */
    private function renderTallVideo(string $src, int $postId, string $badgeHtml = '', ?array $engagement = null, ?string $altText = null): void
    {
        $thumb = $this->videoThumb($src);

        echo '<div class="tile tile--tall area-V tile--video tile-'. (int) $postId .' getFullPost" data-post-id="' . (int) $postId . '">';
        if ($badgeHtml !== '') {
            echo '  <div class="tile-badge tile-badge--tr">' . $badgeHtml . '</div>';
        }
        $alt = $altText !== null && $altText !== '' ? iN_HelpSecure($altText) : iN_HelpSecure(customLang('image_alt_generic'));
        echo '  <img src="' . htmlspecialchars($thumb, ENT_QUOTES, 'UTF-8') . '" alt="' . $alt . '">';
        if (is_array($engagement)) {
            $this->renderOverlay($engagement);
        }
        echo '</div>' . PHP_EOL;
    }

    /**
     * Render a placeholder (empty) tile for layout continuity.
     */
    private function renderGhost(string $area, bool $tall = false): void
    {
        $cls = $tall ? 'tile tile--tall tile--ghost area-' . $area : 'tile tile--square tile--ghost area-' . $area;
        echo '<div class="' . $cls . '"></div>' . PHP_EOL;
    }

    /**
     * Return the first image path from a CSV string.
     */
    private function firstImage(string $csv): string
    {
        $parts = array_filter(array_map('trim', explode(',', $csv)));
        return $parts[0] ?? '';
    }

    /**
     * URL normalizer hook. Left as a passthrough; adapt if absolute URLs are required.
     */
    private function url(string $path): string
    {
        if (function_exists('storage_resolve_media_url')) {
            return storage_resolve_media_url($path);
        }

        return $path;
    }
    /**
     * Fetches a page by cursor and packs into 5-item blocks.
     *
     * If $cursorTime is 0, this returns the newest page; otherwise returns a page
     * older than the given (time,id) cursor.
     *
     * @param int $cursorTime Cursor UNIX timestamp (0 for first page).
     * @param int $cursorId Cursor post id (tie-breaker for equal timestamps).
     * @param int $tileLimit Max tiles per page (safely clamped).
     * @return array{
     *   blocks: array,
     *   hasMore: bool,
     *   nextCursor: array{time:int,id:int},
     *   startLayout: 'right'|'left'
     * }
     */
    public function getPageByCursor(int $cursorTime, int $cursorId, int $tileLimit = 25): array
    {
        if ($tileLimit < 1)  { $tileLimit = 1; }
        if ($tileLimit > 200){ $tileLimit = 200; }
        // If first page, fetch newest; otherwise fetch older than cursor
        $rows = $this->fetchByCursor($cursorTime, $cursorId, $tileLimit + 1); // +1 => detect hasMore
        $hasMore = count($rows) > $tileLimit;
        if ($hasMore) {
            array_pop($rows); // trim the overscan
        }

        // Reduce to tiles
        $tiles = [];
        foreach ($rows as $r) {
            if ($r['post_type'] === 'image') {
                $src = $this->firstImage((string) $r['post_file']);
                $imgCount = $this->countImages((string) $r['post_file']);
                if ($src === '') { continue; }
                $tiles[] = [
                    'type'  => 'image',
                    'src'   => $this->url($src),
                    'id'    => (int) ($r['post_id'] ?? 0),
                    'multi' => ($imgCount > 1),
                    // Context for alt text
                    'username'     => (string)($r['username'] ?? ''),
                    'display_name' => (string)($r['user_fullname'] ?? ''),
                    'caption'      => (string)($r['post_text'] ?? ''),
                ];
            } else {
                $tiles[] = [
                    'type' => 'video',
                    'src'  => $this->url((string) $r['post_file']),
                    'id'   => (int) ($r['post_id'] ?? 0),
                    // Context for alt text
                    'username'     => (string)($r['username'] ?? ''),
                    'display_name' => (string)($r['user_fullname'] ?? ''),
                    'caption'      => (string)($r['post_text'] ?? ''),
                ];
            }
        }

        $blocks = $this->packIntoBlocks($tiles);

        // Next cursor: use the last item’s time/id
        $last = end($rows);
        if (is_array($last)) {
            $nextCursor = [
                'time' => (int) ($last['post_created_time'] ?? 0),
                'id'   => (int) ($last['post_id'] ?? 0),
            ];
        } else {
            // No rows were retrieved; keep cursor unchanged so client stops gracefully.
            $nextCursor = [
                'time' => (int) $cursorTime,
                'id'   => (int) $cursorId,
            ];
        }

        // For A/B pattern, alternate start layout per page (optional)
        $startLayout = 'right';

        return [
            'blocks'     => $blocks,
            'hasMore'    => $hasMore,
            'nextCursor' => $nextCursor,
            'startLayout'=> $startLayout,
        ];
    }

    /**
     * Cursor-aware fetcher.
     *
     * If $cursorTime is 0, returns newest items; otherwise returns items strictly
     * older than the (time, id) pair.
     *
     * @param int $cursorTime
     * @param int $cursorId
     * @param int $limit
     * @return array<int, array<string,mixed>>
     */
    private function fetchByCursor(int $cursorTime, int $cursorId, int $limit): array
    {
        // Apply safe clamp + int cast
        if ($limit < 1)  { $limit = 1; }
        if ($limit > 200){ $limit = 200; }
        $limit = (int) $limit;

        if ($cursorTime > 0) {
            $sql = "SELECT p.post_id, p.post_type, p.post_file, p.post_created_time, p.post_text,
                           u.username, u.user_fullname
                    FROM i_user_posts p
                    JOIN i_users u ON u.user_id = p.post_owner_id
                    WHERE p.post_visibility = 'everyone' AND (p.approval_status IS NULL OR p.approval_status = 'approved')
                      AND (
                           p.post_created_time < :ct1
                           OR (p.post_created_time = :ct2 AND p.post_id < :cid)
                      )
                    ORDER BY p.post_created_time DESC, p.post_id DESC
                    LIMIT {$limit}";
            $st  = $this->db->prepare($sql);
            $st->bindValue(':ct1', (int)$cursorTime, \PDO::PARAM_INT);
            $st->bindValue(':ct2', (int)$cursorTime, \PDO::PARAM_INT);
            $st->bindValue(':cid', (int)$cursorId,   \PDO::PARAM_INT);
        } else {
            $sql = "SELECT p.post_id, p.post_type, p.post_file, p.post_created_time, p.post_text,
                           u.username, u.user_fullname
                    FROM i_user_posts p
                    JOIN i_users u ON u.user_id = p.post_owner_id
                    WHERE p.post_visibility = 'everyone' AND (p.approval_status IS NULL OR p.approval_status = 'approved')
                    ORDER BY p.post_created_time DESC, p.post_id DESC
                    LIMIT {$limit}";
            $st  = $this->db->prepare($sql);
        }

        $st->execute();
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
}

    /**
     * Buffered renderer variant that returns the produced HTML as a string.
     * Useful for testing or when you want to assemble markup before output.
     */
    public function renderToString(array $blocks, string $startLayout = 'right', bool $wrap = true): string
    {
        ob_start();
        $this->render($blocks, $startLayout, $wrap);
        return (string) ob_get_clean();
    }

    /**
     * Render a tall image tile with optional badge and engagement overlay.
     */
    private function renderTallImage(string $src, int $postId, string $badgeHtml = '', ?array $engagement = null, ?string $altText = null): void
    {
        echo '<div class="tile tile--tall area-V tile-'. (int) $postId .' getFullPost" data-post-id="' . (int) $postId . '">';
        echo '  <div class="tile-meta">#' . (int) $postId . '</div>';
        if ($badgeHtml !== '') {
            echo '  <div class="tile-badge tile-badge--tr">' . $badgeHtml . '</div>';
        }
        $alt = $altText !== null && $altText !== '' ? iN_HelpSecure($altText) : iN_HelpSecure(customLang('image_alt_generic'));
        echo '  <img src="' . htmlspecialchars($src, ENT_QUOTES, 'UTF-8') . '" alt="' . $alt . '">';
        if (is_array($engagement)) {
            $this->renderOverlay($engagement);
        }
        echo '</div>' . PHP_EOL;
    }
}
