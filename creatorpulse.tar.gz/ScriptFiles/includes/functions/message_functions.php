<?php
declare(strict_types=1);
trait MessageFunctions {
    /**
     * Get the latest conversation per user for a given user.
     *
     * Returns one row per conversation partner (the other user),
     * including that partner's profile data from i_users and the
     * latest message exchanged in the thread. Ordered by most recent.
     *
     * @param int $userID  The current user's ID.
     * @param int $limit   Max number of conversations to return (default 20).
     * @param int $offset  Offset for pagination (default 0).
     *
     * @return array<int, array<string, mixed>> A list of conversations with keys:
     *               partner_id, username, fullname, avatar,
     *               verified_status, last_message, last_time
     */
    public function RL_GetNewMessages(int $userID, int $limit = 20, int $offset = 0): array
    {
        try {
            // Guard clause: invalid user id
            if ($userID <= 0) {
                return [];
            }

            // Ensure sane integers and embed into SQL to avoid LIMIT/OFFSET binding issues
            $limit  = max(1, (int) $limit);
            $offset = max(0, (int) $offset);

            // Index-friendly approach without LEAST/GREATEST
            // 1) Build (other_user, last_time) for this user via UNION ALL
            // 2) Join back to i_messages for the exact last message row
            // 3) Join i_users for partner profile data
            $sql = "
                SELECT
                    l.other_user AS partner_id,
                    u.username,
                    u.user_fullname,
                    u.user_avatar,
                    u.verified_status,
                    m.message,
                    m.file,
                    m.message_type,
                    m.metadata,
                    m.message_time,
                    cs.pinned_at,
                    mr.request_id,
                    mr.sender_id AS request_sender_id,
                    mr.receiver_id AS request_receiver_id,
                    mr.status AS request_status
                FROM (
                    SELECT other_user, MAX(message_time) AS last_time
                    FROM (
                        SELECT m1.user_two AS other_user, m1.message_time
                        FROM i_messages m1
                        LEFT JOIN i_chat_conversation_states cs1
                          ON cs1.user_id = ? AND cs1.partner_id = m1.user_two
                        WHERE m1.user_one = ?
                          AND m1.message_time > GREATEST(COALESCE(cs1.cleared_at, 0), COALESCE(cs1.deleted_at, 0))
                        UNION ALL
                        SELECT m2.user_one AS other_user, m2.message_time
                        FROM i_messages m2
                        LEFT JOIN i_chat_conversation_states cs2
                          ON cs2.user_id = ? AND cs2.partner_id = m2.user_one
                        WHERE m2.user_two = ?
                          AND m2.message_time > GREATEST(COALESCE(cs2.cleared_at, 0), COALESCE(cs2.deleted_at, 0))
                    ) x
                    GROUP BY other_user
                ) l
                JOIN i_users u
                  ON u.user_id = l.other_user
                LEFT JOIN i_chat_conversation_states cs
                  ON cs.user_id = ? AND cs.partner_id = l.other_user
                JOIN i_messages m
                  ON m.message_id = (
                        SELECT m2.message_id
                        FROM i_messages m2
                        WHERE (
                                 (m2.user_one = ? AND m2.user_two = l.other_user)
                              OR (m2.user_two = ? AND m2.user_one = l.other_user)
                              )
                          AND m2.message_time = l.last_time
                        ORDER BY m2.message_id DESC
                        LIMIT 1
                  )
                LEFT JOIN i_message_requests mr
                  ON mr.request_id = (
                        SELECT mr2.request_id
                        FROM i_message_requests mr2
                        WHERE (
                                (mr2.sender_id = ? AND mr2.receiver_id = l.other_user)
                             OR (mr2.sender_id = l.other_user AND mr2.receiver_id = ?)
                              )
                        ORDER BY FIELD(mr2.status, 'pending', 'accepted', 'declined', 'blocked'), COALESCE(mr2.updated_at, mr2.created_at) DESC
                        LIMIT 1
                  )
                ORDER BY CASE WHEN COALESCE(cs.pinned_at, 0) > 0 THEN 0 ELSE 1 END ASC,
                         COALESCE(cs.pinned_at, 0) DESC,
                         m.message_time DESC
                LIMIT $limit OFFSET $offset
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(1, $userID, PDO::PARAM_INT);
            $stmt->bindValue(2, $userID, PDO::PARAM_INT);
            $stmt->bindValue(3, $userID, PDO::PARAM_INT);
            $stmt->bindValue(4, $userID, PDO::PARAM_INT);
            $stmt->bindValue(5, $userID, PDO::PARAM_INT);
            $stmt->bindValue(6, $userID, PDO::PARAM_INT);
            $stmt->bindValue(7, $userID, PDO::PARAM_INT);
            $stmt->bindValue(8, $userID, PDO::PARAM_INT);
            $stmt->bindValue(9, $userID, PDO::PARAM_INT);
            $stmt->execute();

            $conversations = [];
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $partnerId = (int) $row['partner_id'];
                $lastMessage = (string) $row['message'];
                $lastTime = (int) $row['message_time'];
                $lastActivityType = isset($row['message_type']) ? (string)$row['message_type'] : 'text';
                $lastReaction = $this->RL_GetLatestMessageReactionActivity($userID, $partnerId);
                if ($lastReaction && (int)($lastReaction['created_at'] ?? 0) >= $lastTime) {
                    $reactionKey = (string)($lastReaction['reaction'] ?? '');
                    $reactionLabel = customLang('chat_reaction_' . $reactionKey, ucfirst($reactionKey ?: 'reaction'));
                    $actorName = (string)($lastReaction['actor_name'] ?? '');
                    $template = customLang('message_reaction_preview', '{user} reacted {reaction} to your message.');
                    $lastMessage = str_replace(
                        ['{user}', '{reaction}'],
                        [$actorName !== '' ? $actorName : (string)$row['username'], $reactionLabel],
                        $template
                    );
                    $lastTime = (int)$lastReaction['created_at'];
                    $lastActivityType = 'message_reaction';
                }

                $conversations[] = [
                    'partner_id'      => $partnerId,
                    'username'        => (string) $row['username'],
                    'fullname'        => !empty($row['user_fullname']) ? (string) $row['user_fullname'] : (string) $row['username'],
                    'avatar'          => !empty($row['user_avatar']) ? (string) $row['user_avatar'] : 'uploads/user_avatars/default.jpeg',
                    'verified_status' => (int) ($row['verified_status'] ?? 0),
                    'last_message'    => $lastMessage,
                    'last_file'       => isset($row['file']) ? (string)$row['file'] : '',
                    'last_message_type' => $lastActivityType,
                    'last_metadata'   => isset($row['metadata']) ? (string)$row['metadata'] : '',
                    'last_time'       => $lastTime,
                    'pinned_at'       => (int)($row['pinned_at'] ?? 0),
                    'request_id'      => (int)($row['request_id'] ?? 0),
                    'request_status'  => (string)($row['request_status'] ?? 'none'),
                    'request_direction' => !empty($row['request_sender_id'])
                        ? (((int)$row['request_sender_id'] === $userID) ? 'outgoing' : 'incoming')
                        : '',
                ];
            }
            usort($conversations, static function (array $a, array $b): int {
                $ap = (int)($a['pinned_at'] ?? 0);
                $bp = (int)($b['pinned_at'] ?? 0);
                if ($ap > 0 || $bp > 0) {
                    if ($ap !== $bp) {
                        return $bp <=> $ap;
                    }
                }
                return ((int)($b['last_time'] ?? 0)) <=> ((int)($a['last_time'] ?? 0));
            });

            return $conversations;
        } catch (PDOException $e) {
            $this->logError('RL_GetNewMessages() failed: ' . $e->getMessage());
            return [];
        }
    }

    private function RL_GetLatestMessageReactionActivity(int $recipientId, int $partnerId): ?array
    {
        $recipientId = (int)$recipientId;
        $partnerId = (int)$partnerId;
        if ($recipientId <= 0 || $partnerId <= 0) {
            return null;
        }

        try {
            $sql = 'SELECT n.created_at,
                           n.extra_data,
                           u.username,
                           u.user_fullname
                    FROM i_notifications n
                    INNER JOIN i_users u ON u.user_id = n.actor_id
                    WHERE n.recipient_id = :recipient
                      AND n.actor_id = :partner
                      AND n.type = "message_reaction"
                    ORDER BY n.created_at DESC, n.id DESC
                    LIMIT 1';
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':recipient', $recipientId, PDO::PARAM_INT);
            $stmt->bindValue(':partner', $partnerId, PDO::PARAM_INT);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                return null;
            }

            $extra = [];
            if (!empty($row['extra_data'])) {
                $decoded = json_decode((string)$row['extra_data'], true);
                if (is_array($decoded)) {
                    $extra = $decoded;
                }
            }

            return [
                'created_at' => (int)($row['created_at'] ?? 0),
                'reaction' => (string)($extra['reaction'] ?? ''),
                'message_id' => (int)($extra['message_id'] ?? 0),
                'actor_name' => (string)(($row['user_fullname'] ?? '') ?: ($row['username'] ?? '')),
            ];
        } catch (Throwable $e) {
            $this->logError('RL_GetLatestMessageReactionActivity() failed: ' . $e->getMessage());
            return null;
        }
    }
}
