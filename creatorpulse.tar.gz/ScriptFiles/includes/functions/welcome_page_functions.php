<?php
declare(strict_types=1);

trait WelcomePageFunctions
{
    /**
     * Fetch up to $limit media posts for the welcome page hero.
     * Ensures a mix of image/video entries when available.
     *
     * @param int $limit Desired item count (clamped to 1..20).
     * @return array<int, array<string, mixed>>
     */
    public function RL_GetWelcomeHeroPosts(int $limit = 8, array $options = []): array
    {
        try {
            $limit = max(1, min(20, (int) $limit));
            // Fetch extra rows so we can balance images/videos without extra queries.
            $fetchLimit = max($limit, min(60, $limit * 3));

            $mediaMode = isset($options['media_mode']) ? strtolower((string) $options['media_mode']) : 'mixed';
            if (!in_array($mediaMode, ['mixed', 'image', 'video'], true)) {
                $mediaMode = 'mixed';
            }

            $sql = "
                SELECT
                    p.post_id,
                    p.post_type,
                    p.post_file,
                    p.post_views,
                    p.post_created_time,
                    u.username,
                    u.user_fullname,
                    u.verified_status,
                    COALESCE(l.likes_count, 0) AS likes_count
                FROM i_user_posts AS p
                INNER JOIN i_users AS u ON u.user_id = p.post_owner_id
                LEFT JOIN (
                    SELECT liked_item_id AS post_id, COUNT(*) AS likes_count
                    FROM i_post_liked
                    WHERE liked_item_type = 'post'
                    GROUP BY liked_item_id
                ) AS l ON l.post_id = p.post_id
                WHERE p.post_visibility = 'everyone'
                  AND p.post_type IN ('image', 'video')
                  AND p.post_file IS NOT NULL
                  AND p.post_file <> ''
                  AND (p.approval_status IS NULL OR p.approval_status = 'approved')
                ORDER BY p.post_created_time DESC, p.post_id DESC
                LIMIT :lim
            ";

            $st = $this->db->prepare($sql);
            $st->bindValue(':lim', $fetchLimit, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            if (!$rows) {
                return [];
            }

            $images = [];
            $videos = [];
            foreach ($rows as $row) {
                $entry = $this->buildWelcomeHeroEntry($row);
                if ($entry === null) {
                    continue;
                }
                if ($entry['type'] === 'video') {
                    $videos[] = $entry;
                } else {
                    $images[] = $entry;
                }
            }

            if (empty($images) && empty($videos)) {
                return [];
            }

            $result = [];
            $preferVideo = count($videos) >= count($images);
            while (count($result) < $limit && (!empty($images) || !empty($videos))) {
                if ($mediaMode === 'video') {
                    if (!empty($videos)) {
                        $result[] = array_shift($videos);
                    } else {
                        break;
                    }
                } elseif ($mediaMode === 'image') {
                    if (!empty($images)) {
                        $result[] = array_shift($images);
                    } else {
                        break;
                    }
                } elseif ($preferVideo && !empty($videos)) {
                    $result[] = array_shift($videos);
                } elseif (!$preferVideo && !empty($images)) {
                    $result[] = array_shift($images);
                } elseif (!empty($videos)) {
                    $result[] = array_shift($videos);
                } elseif (!empty($images)) {
                    $result[] = array_shift($images);
                } else {
                    break;
                }
                $preferVideo = !$preferVideo;
            }

            if (count($result) < $limit) {
                $leftovers = [];
                if ($mediaMode === 'video') {
                    $leftovers = $videos;
                } elseif ($mediaMode === 'image') {
                    $leftovers = $images;
                } else {
                    $leftovers = array_merge($videos, $images);
                }
                foreach ($leftovers as $leftover) {
                    $result[] = $leftover;
                    if (count($result) >= $limit) {
                        break;
                    }
                }
            }

            return $result;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetWelcomeHeroPosts failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    /**
     * Normalize a single database row into a hero entry array.
     *
     * @param array<string, mixed> $row
     * @return array<string, mixed>|null
     */
    private function buildWelcomeHeroEntry(array $row): ?array
    {
        $postId = (int) ($row['post_id'] ?? 0);
        if ($postId <= 0) {
            return null;
        }

        $type = (string) ($row['post_type'] ?? '');
        $rawFile = (string) ($row['post_file'] ?? '');
        $firstMedia = $this->firstWelcomeMedia($rawFile);
        if ($firstMedia === '') {
            return null;
        }

        $views = max(0, (int) ($row['post_views'] ?? 0));
        $likes = max(0, (int) ($row['likes_count'] ?? 0));

        $username = (string) ($row['username'] ?? '');
        $fullName = trim((string) ($row['user_fullname'] ?? ''));
        $display = $fullName !== '' ? $fullName : $username;
        if ($display === '') {
            $display = 'user-' . $postId;
        }

        if ($type === 'image') {
            $imageUrl = $this->normalizeWelcomeMediaPath($firstMedia);
        } elseif ($type === 'video') {
            $thumbRel = $this->videoPathToThumbnail($firstMedia);
            $imageUrl = $this->normalizeWelcomeMediaPath($thumbRel);
            if ($imageUrl === '') {
                $imageUrl = $this->normalizeWelcomeMediaPath($firstMedia);
            }
        } else {
            return null;
        }

        if ($imageUrl === '') {
            return null;
        }

        return [
            'post_id'        => $postId,
            'type'           => $type,
            'image_url'      => $imageUrl,
            'views'          => $views,
            'likes'          => $likes,
            'owner_username' => $username,
            'owner_display'  => $display,
            'owner_verified' => ((int) ($row['verified_status'] ?? 0)) === 1,
        ];
    }

    private function firstWelcomeMedia(string $csv): string
    {
        $parts = array_filter(array_map('trim', explode(',', $csv)), static fn($item) => $item !== '');
        return $parts[0] ?? '';
    }

    private function videoPathToThumbnail(string $path): string
    {
        $trimmed = trim($path);
        if ($trimmed === '') {
            return '';
        }
        $qPos = strpos($trimmed, '?');
        if ($qPos !== false) {
            $trimmed = substr($trimmed, 0, $qPos);
        }
        $dot = strrpos($trimmed, '.');
        if ($dot !== false) {
            $trimmed = substr($trimmed, 0, $dot) . '.png';
        } else {
            $trimmed .= '.png';
        }
        return $trimmed;
    }

    private function normalizeWelcomeMediaPath(string $path): string
    {
        $path = trim($path);
        if ($path === '') {
            return '';
        }
        if (preg_match('#^https?://#i', $path) === 1 || strncmp($path, '//', 2) === 0) {
            return $path;
        }
        $base = $GLOBALS['base_url'] ?? '';
        if ($base === '') {
            return $path;
        }
        return rtrim((string) $base, '/') . '/' . ltrim($path, '/');
    }
}
