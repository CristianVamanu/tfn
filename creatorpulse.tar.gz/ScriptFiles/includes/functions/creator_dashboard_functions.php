<?php
declare(strict_types=1);

trait CreatorDashboardFunctions
{
    /**
     * Aggregate per-day follower/subscriber counts from i_friends.
     */
    private function cdFetchFriendDailyMap(int $creatorId, string $status, int $since): array
    {
        if ($creatorId <= 0) {
            return [];
        }
        try {
            $sql = "SELECT DATE_FORMAT(FROM_UNIXTIME(fr_time), '%Y-%m-%d') AS d, COUNT(*) AS c
                    FROM i_friends
                    WHERE fr_two = :uid
                      AND fr_status = :status
                      AND fr_time IS NOT NULL
                      AND fr_time >= :since
                    GROUP BY d";
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $creatorId, \PDO::PARAM_INT);
            $st->bindValue(':status', $status, \PDO::PARAM_STR);
            $st->bindValue(':since', $since, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            $map = [];
            foreach ($rows as $row) {
                $day = (string)($row['d'] ?? '');
                if ($day === '') {
                    continue;
                }
                $map[$day] = (float)($row['c'] ?? 0);
            }
            return $map;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('cdFetchFriendDailyMap failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    /**
     * Sum creator earnings per day since a timestamp without counting Audio Room tips twice.
     */
    private function cdFetchEarningsDailyMap(int $creatorId, int $since): array
    {
        $map = [];
        $totals = [
            'tips'               => 0.0,
            'subscriptions'      => 0.0,
            'sales'              => 0.0,
            'ebook_sales'        => 0.0,
            'audio_room_tips'    => 0.0,
            'audio_room_tickets' => 0.0,
        ];
        if ($creatorId <= 0) {
            return ['map' => $map, 'totals' => $totals];
        }

        // Tips
        try {
            $sql = "SELECT DATE_FORMAT(FROM_UNIXTIME(tp.created_at), '%Y-%m-%d') AS d,
                           SUM(COALESCE(tp.net_amount, tp.amount, 0)) AS total
                    FROM i_tip_payments tp
                    LEFT JOIN i_audio_room_tip_events arte
                      ON arte.provider = tp.provider
                     AND arte.reference = tp.reference
                    WHERE tp.recipient_id = :uid
                      AND tp.status IN ('succeeded','paid','completed')
                      AND tp.created_at IS NOT NULL
                      AND tp.created_at >= :since
                      AND arte.id IS NULL
                    GROUP BY d";
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $creatorId, \PDO::PARAM_INT);
            $st->bindValue(':since', $since, \PDO::PARAM_INT);
            $st->execute();
            foreach ($st->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $row) {
                $day = (string)($row['d'] ?? '');
                if ($day === '') { continue; }
                $value = (float)($row['total'] ?? 0.0);
                $map[$day] = ($map[$day] ?? 0.0) + $value;
                $totals['tips'] += $value;
            }
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('cdFetchEarningsDailyMap tips failed: ' . $e->getMessage());
            }
        }

        // Audio Room tips linked to a verified payment record.
        try {
            $sql = "SELECT DATE_FORMAT(FROM_UNIXTIME(arte.created_at), '%Y-%m-%d') AS d,
                           SUM(COALESCE(arte.net_amount, tp.net_amount, tp.amount, arte.amount, 0)) AS total
                    FROM i_audio_room_tip_events arte
                    INNER JOIN i_tip_payments tp
                      ON tp.provider = arte.provider
                     AND tp.reference = arte.reference
                     AND tp.recipient_id = arte.recipient_id
                    WHERE arte.recipient_id = :uid
                      AND arte.status IN ('succeeded','paid','completed')
                      AND tp.status IN ('succeeded','paid','completed')
                      AND arte.created_at >= :since
                    GROUP BY d";
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $creatorId, \PDO::PARAM_INT);
            $st->bindValue(':since', $since, \PDO::PARAM_INT);
            $st->execute();
            foreach ($st->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $row) {
                $day = (string)($row['d'] ?? '');
                if ($day === '') { continue; }
                $value = (float)($row['total'] ?? 0.0);
                $map[$day] = ($map[$day] ?? 0.0) + $value;
                $totals['audio_room_tips'] += $value;
            }
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('cdFetchEarningsDailyMap audio room tips failed: ' . $e->getMessage());
            }
        }

        // Paid Audio Room admission tickets.
        try {
            $sql = "SELECT DATE_FORMAT(FROM_UNIXTIME(created_at), '%Y-%m-%d') AS d,
                           SUM(COALESCE(net_amount, amount, 0)) AS total
                    FROM i_audio_room_tickets
                    WHERE owner_id = :uid
                      AND status IN ('succeeded','paid','completed')
                      AND created_at >= :since
                    GROUP BY d";
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $creatorId, \PDO::PARAM_INT);
            $st->bindValue(':since', $since, \PDO::PARAM_INT);
            $st->execute();
            foreach ($st->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $row) {
                $day = (string)($row['d'] ?? '');
                if ($day === '') { continue; }
                $value = (float)($row['total'] ?? 0.0);
                $map[$day] = ($map[$day] ?? 0.0) + $value;
                $totals['audio_room_tickets'] += $value;
            }
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('cdFetchEarningsDailyMap audio room tickets failed: ' . $e->getMessage());
            }
        }

        // Subscriptions
        try {
            $sql = "SELECT DATE_FORMAT(FROM_UNIXTIME(created_at), '%Y-%m-%d') AS d,
                           SUM(COALESCE(amount, 0)) AS total
                    FROM i_subscription_payments
                    WHERE recipient_id = :uid
                      AND status IN ('succeeded','paid','completed')
                      AND created_at IS NOT NULL
                      AND created_at >= :since
                    GROUP BY d";
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $creatorId, \PDO::PARAM_INT);
            $st->bindValue(':since', $since, \PDO::PARAM_INT);
            $st->execute();
            foreach ($st->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $row) {
                $day = (string)($row['d'] ?? '');
                if ($day === '') { continue; }
                $value = (float)($row['total'] ?? 0.0);
                $map[$day] = ($map[$day] ?? 0.0) + $value;
                $totals['subscriptions'] += $value;
            }
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('cdFetchEarningsDailyMap subscriptions failed: ' . $e->getMessage());
            }
        }

        // Post sales
        try {
            $sql = "SELECT DATE_FORMAT(FROM_UNIXTIME(created_at), '%Y-%m-%d') AS d,
                           SUM(COALESCE(net_amount, amount, 0)) AS total
                    FROM i_post_purchases
                    WHERE recipient_id = :uid
                      AND status IN ('succeeded','paid','completed')
                      AND created_at IS NOT NULL
                      AND created_at >= :since
                    GROUP BY d";
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $creatorId, \PDO::PARAM_INT);
            $st->bindValue(':since', $since, \PDO::PARAM_INT);
            $st->execute();
            foreach ($st->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $row) {
                $day = (string)($row['d'] ?? '');
                if ($day === '') { continue; }
                $value = (float)($row['total'] ?? 0.0);
                $map[$day] = ($map[$day] ?? 0.0) + $value;
                $totals['sales'] += $value;
            }
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('cdFetchEarningsDailyMap sales failed: ' . $e->getMessage());
            }
        }

        // eBook sales
        try {
            $sql = "SELECT DATE_FORMAT(FROM_UNIXTIME(created_at), '%Y-%m-%d') AS d,
                           SUM(COALESCE(net_amount, amount, 0)) AS total
                    FROM i_ebook_purchases
                    WHERE seller_id = :uid
                      AND status IN ('succeeded','paid','completed')
                      AND created_at IS NOT NULL
                      AND created_at >= :since
                    GROUP BY d";
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $creatorId, \PDO::PARAM_INT);
            $st->bindValue(':since', $since, \PDO::PARAM_INT);
            $st->execute();
            foreach ($st->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $row) {
                $day = (string)($row['d'] ?? '');
                if ($day === '') { continue; }
                $value = (float)($row['total'] ?? 0.0);
                $map[$day] = ($map[$day] ?? 0.0) + $value;
                $totals['ebook_sales'] += $value;
            }
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('cdFetchEarningsDailyMap ebook sales failed: ' . $e->getMessage());
            }
        }

        return ['map' => $map, 'totals' => $totals];
    }

    /**
     * Normalize a date=>value map into ordered daily series for the last $days days (oldest first).
     */
    private function cdNormalizeDailySeries(array $map, int $days, int $now): array
    {
        $days = max(1, $days);
        $series = [];
        $values = [];
        $labels = [];
        $start = strtotime(date('Y-m-d 00:00:00', $now)) - ($days - 1) * 86400;
        for ($i = 0; $i < $days; $i++) {
            $ts = $start + ($i * 86400);
            $key = date('Y-m-d', $ts);
            $value = (float)($map[$key] ?? 0.0);
            $label = date('M j', $ts);
            $series[] = ['t' => $ts, 'v' => $value, 'label' => $label];
            $values[] = $value;
            $labels[] = $label;
        }
        return [
            'series' => $series,
            'values' => $values,
            'labels' => $labels,
        ];
    }

    private function cdSumSlice(array $values, int $length, int $offsetFromEnd = 0): float
    {
        $count = count($values);
        if ($length <= 0 || $count === 0) {
            return 0.0;
        }
        $endIndex = $count - 1 - max(0, $offsetFromEnd);
        if ($endIndex < 0) {
            return 0.0;
        }
        $startIndex = max(0, $endIndex - $length + 1);
        $sum = 0.0;
        for ($i = $startIndex; $i <= $endIndex && $i < $count; $i++) {
            $sum += (float) $values[$i];
        }
        return $sum;
    }

    private function cdPercentChange(float $current, float $previous): float
    {
        if ($previous <= 0.0) {
            return $current > 0.0 ? 100.0 : 0.0;
        }
        return (($current - $previous) / $previous) * 100.0;
    }

    private function cdFormatPlanLabel(?string $interval, ?int $count): string
    {
        $interval = strtolower(trim((string)$interval));
        $count = (int)($count ?? 1);
        if ($count <= 0) {
            $count = 1;
        }
        $map = [
            'day' => 'Daily',
            'daily' => 'Daily',
            'week' => 'Weekly',
            'weekly' => 'Weekly',
            'month' => 'Monthly',
            'monthly' => 'Monthly',
            'year' => 'Yearly',
            'yearly' => 'Yearly',
        ];
        $label = $map[$interval] ?? ucfirst($interval ?: 'Plan');
        return $count > 1 ? ($count . 'x ' . $label) : $label;
    }

    private function cdSummarizePost(?string $text, int $postId): string
    {
        $text = trim((string)$text);
        if ($text !== '') {
            $clean = strip_tags($text);
            if (function_exists('mb_strlen') && function_exists('mb_substr')) {
                if (mb_strlen($clean, 'UTF-8') > 60) {
                    return mb_substr($clean, 0, 57, 'UTF-8') . '…';
                }
                return $clean;
            }
            if (strlen($clean) > 60) {
                return substr($clean, 0, 57) . '…';
            }
            return $clean;
        }
        return 'Post #' . $postId;
    }

    private function cdGetRecentSubscriptions(int $creatorId, int $limit = 8): array
    {
        if ($creatorId <= 0) {
            return [];
        }
        try {
            $sql = "SELECT sp.buyer_id, sp.amount, sp.currency, sp.plan_interval, sp.interval_count, sp.created_at,
                           u.username, u.user_fullname, u.user_avatar
                    FROM i_subscription_payments sp
                    LEFT JOIN i_users u ON u.user_id = sp.buyer_id
                    WHERE sp.recipient_id = :uid
                      AND sp.status IN ('succeeded','paid','completed')
                    ORDER BY sp.created_at DESC
                    LIMIT :lim";
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $creatorId, \PDO::PARAM_INT);
            $st->bindValue(':lim', $limit, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            $out = [];
            foreach ($rows as $row) {
                $buyerId = (int)($row['buyer_id'] ?? 0);
                $username = trim((string)($row['username'] ?? ''));
                $fullName = trim((string)($row['user_fullname'] ?? ''));
                $display = $fullName !== '' ? $fullName : ($username !== '' ? $username : 'User #' . $buyerId);
                $avatar = 'uploads/user_avatars/default.jpeg';
                if ($buyerId > 0 && method_exists($this, 'RL_userAvatar')) {
                    $candidate = (string) $this->RL_userAvatar($buyerId);
                    if ($candidate !== '') {
                        $avatar = $candidate;
                    }
                } elseif (!empty($row['user_avatar'])) {
                    $avatar = (string) $row['user_avatar'];
                }
                $out[] = [
                    'user'         => $display,
                    'display_name' => $display,
                    'full_name'    => $fullName,
                    'username'     => $username,
                    'avatar'       => $avatar,
                    'user_id'      => $buyerId,
                    'plan'         => $this->cdFormatPlanLabel($row['plan_interval'] ?? '', (int)($row['interval_count'] ?? 1)),
                    'amount'       => isset($row['amount']) ? (float)$row['amount'] : null,
                    'date'         => isset($row['created_at']) ? (int)$row['created_at'] : null,
                ];
            }
            return $out;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('cdGetRecentSubscriptions failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    private function cdGetRecentTips(int $creatorId, int $limit = 8): array
    {
        if ($creatorId <= 0) {
            return [];
        }
        try {
            $sql = "SELECT tp.buyer_id, COALESCE(tp.net_amount, tp.amount) AS amount, tp.currency, tp.status, tp.created_at,
                           u.username, u.user_fullname, u.user_avatar
                    FROM i_tip_payments tp
                    LEFT JOIN i_users u ON u.user_id = tp.buyer_id
                    LEFT JOIN i_audio_room_tip_events arte
                      ON arte.provider = tp.provider
                     AND arte.reference = tp.reference
                    WHERE tp.recipient_id = :uid
                      AND tp.status IN ('succeeded','paid','completed')
                      AND arte.id IS NULL
                    ORDER BY tp.created_at DESC
                    LIMIT :lim";
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $creatorId, \PDO::PARAM_INT);
            $st->bindValue(':lim', $limit, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            $out = [];
            foreach ($rows as $row) {
                $buyerId = (int)($row['buyer_id'] ?? 0);
                $username = trim((string)($row['username'] ?? ''));
                $fullName = trim((string)($row['user_fullname'] ?? ''));
                $display = $fullName !== '' ? $fullName : ($username !== '' ? $username : 'User #' . $buyerId);
                $avatar = 'uploads/user_avatars/default.jpeg';
                if ($buyerId > 0 && method_exists($this, 'RL_userAvatar')) {
                    $candidate = (string) $this->RL_userAvatar($buyerId);
                    if ($candidate !== '') {
                        $avatar = $candidate;
                    }
                } elseif (!empty($row['user_avatar'])) {
                    $avatar = (string) $row['user_avatar'];
                }
                $out[] = [
                    'user'         => $display,
                    'display_name' => $display,
                    'full_name'    => $fullName,
                    'username'     => $username,
                    'avatar'       => $avatar,
                    'user_id'      => $buyerId,
                    'amount'       => isset($row['amount']) ? (float)$row['amount'] : null,
                    'note'         => '',
                    'status'       => (string)($row['status'] ?? ''),
                    'date'         => isset($row['created_at']) ? (int)$row['created_at'] : null,
                ];
            }
            return $out;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('cdGetRecentTips failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    private function cdGetRecentAudioRoomEarnings(int $creatorId, int $limit = 8): array
    {
        if ($creatorId <= 0) {
            return [];
        }

        try {
            $sql = "SELECT earning_type, buyer_id, room_id, amount, currency, status, created_at,
                           username, user_fullname, user_avatar, room_title
                    FROM (
                        SELECT 'ticket' AS earning_type,
                               t.buyer_id,
                               t.room_id,
                               COALESCE(t.net_amount, t.amount, 0) AS amount,
                               t.currency,
                               t.status,
                               t.created_at,
                               u.username,
                               u.user_fullname,
                               u.user_avatar,
                               r.title AS room_title
                        FROM i_audio_room_tickets t
                        LEFT JOIN i_users u ON u.user_id = t.buyer_id
                        LEFT JOIN i_audio_rooms r ON r.room_id = t.room_id
                        WHERE t.owner_id = :ticket_uid
                          AND t.status IN ('succeeded','paid','completed')

                        UNION ALL

                        SELECT 'tip' AS earning_type,
                               arte.buyer_id,
                               arte.room_id,
                               COALESCE(arte.net_amount, tp.net_amount, tp.amount, arte.amount, 0) AS amount,
                               arte.currency,
                               arte.status,
                               arte.created_at,
                               u.username,
                               u.user_fullname,
                               u.user_avatar,
                               r.title AS room_title
                        FROM i_audio_room_tip_events arte
                        INNER JOIN i_tip_payments tp
                          ON tp.provider = arte.provider
                         AND tp.reference = arte.reference
                         AND tp.recipient_id = arte.recipient_id
                        LEFT JOIN i_users u ON u.user_id = arte.buyer_id
                        LEFT JOIN i_audio_rooms r ON r.room_id = arte.room_id
                        WHERE arte.recipient_id = :tip_uid
                          AND arte.status IN ('succeeded','paid','completed')
                          AND tp.status IN ('succeeded','paid','completed')
                    ) audio_room_earnings
                    ORDER BY created_at DESC
                    LIMIT :lim";
            $st = $this->db->prepare($sql);
            $st->bindValue(':ticket_uid', $creatorId, \PDO::PARAM_INT);
            $st->bindValue(':tip_uid', $creatorId, \PDO::PARAM_INT);
            $st->bindValue(':lim', $limit, \PDO::PARAM_INT);
            $st->execute();

            $out = [];
            foreach ($st->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $row) {
                $buyerId = (int)($row['buyer_id'] ?? 0);
                $username = trim((string)($row['username'] ?? ''));
                $fullName = trim((string)($row['user_fullname'] ?? ''));
                $display = $fullName !== '' ? $fullName : ($username !== '' ? $username : 'User #' . $buyerId);
                $avatar = 'uploads/user_avatars/default.jpeg';
                if ($buyerId > 0 && method_exists($this, 'RL_userAvatar')) {
                    $candidate = (string)$this->RL_userAvatar($buyerId);
                    if ($candidate !== '') {
                        $avatar = $candidate;
                    }
                } elseif (!empty($row['user_avatar'])) {
                    $avatar = (string)$row['user_avatar'];
                }

                $out[] = [
                    'type'         => (string)($row['earning_type'] ?? ''),
                    'room_id'      => (int)($row['room_id'] ?? 0),
                    'room_title'   => trim((string)($row['room_title'] ?? '')),
                    'user'         => $display,
                    'display_name' => $display,
                    'full_name'    => $fullName,
                    'username'     => $username,
                    'avatar'       => $avatar,
                    'user_id'      => $buyerId,
                    'amount'       => (float)($row['amount'] ?? 0),
                    'currency'     => (string)($row['currency'] ?? ''),
                    'status'       => (string)($row['status'] ?? ''),
                    'date'         => isset($row['created_at']) ? (int)$row['created_at'] : null,
                ];
            }
            return $out;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('cdGetRecentAudioRoomEarnings failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    private function cdGetRecentSales(int $creatorId, int $limit = 8): array
    {
        if ($creatorId <= 0) {
            return [];
        }
        try {
            $sql = "SELECT pp.buyer_id, pp.post_id, pp.amount, pp.currency, pp.created_at,
                           u.username, u.user_fullname, u.user_avatar, p.post_text
                    FROM i_post_purchases pp
                    LEFT JOIN i_users u ON u.user_id = pp.buyer_id
                    LEFT JOIN i_user_posts p ON p.post_id = pp.post_id
                    WHERE pp.recipient_id = :uid
                      AND pp.status IN ('succeeded','paid','completed')
                    ORDER BY pp.created_at DESC
                    LIMIT :lim";
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $creatorId, \PDO::PARAM_INT);
            $st->bindValue(':lim', $limit, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            $out = [];
            foreach ($rows as $row) {
                $buyerId = (int)($row['buyer_id'] ?? 0);
                $username = trim((string)($row['username'] ?? ''));
                $fullName = trim((string)($row['user_fullname'] ?? ''));
                $display = $fullName !== '' ? $fullName : ($username !== '' ? $username : 'User #' . $buyerId);
                $avatar = 'uploads/user_avatars/default.jpeg';
                if ($buyerId > 0 && method_exists($this, 'RL_userAvatar')) {
                    $candidate = (string) $this->RL_userAvatar($buyerId);
                    if ($candidate !== '') {
                        $avatar = $candidate;
                    }
                } elseif (!empty($row['user_avatar'])) {
                    $avatar = (string) $row['user_avatar'];
                }
                $postId = (int)($row['post_id'] ?? 0);
                $out[] = [
                    'post'           => $this->cdSummarizePost($row['post_text'] ?? '', $postId),
                    'buyer'          => $display,
                    'display_name'   => $display,
                    'full_name'      => $fullName,
                    'buyer_display'  => $display,
                    'buyer_username' => $username,
                    'buyer_avatar'   => $avatar,
                    'username'       => $username,
                    'avatar'         => $avatar,
                    'buyer_id'       => $buyerId,
                    'amount'         => isset($row['amount']) ? (float)$row['amount'] : null,
                    'date'           => isset($row['created_at']) ? (int)$row['created_at'] : null,
                ];
            }
            return $out;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('cdGetRecentSales failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    private function cdGetRecentEbookSales(int $creatorId, int $limit = 8): array
    {
        if ($creatorId <= 0) {
            return [];
        }
        try {
            $sql = "SELECT ep.buyer_id, ep.ebook_id, ep.amount, ep.net_amount, ep.currency, ep.created_at,
                           u.username, u.user_fullname, u.user_avatar, e.title, e.slug
                    FROM i_ebook_purchases ep
                    LEFT JOIN i_users u ON u.user_id = ep.buyer_id
                    LEFT JOIN i_ebooks e ON e.ebook_id = ep.ebook_id
                    WHERE ep.seller_id = :uid
                      AND ep.status IN ('succeeded','paid','completed')
                    ORDER BY ep.created_at DESC
                    LIMIT :lim";
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $creatorId, \PDO::PARAM_INT);
            $st->bindValue(':lim', $limit, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            $out = [];
            foreach ($rows as $row) {
                $buyerId = (int)($row['buyer_id'] ?? 0);
                $username = trim((string)($row['username'] ?? ''));
                $fullName = trim((string)($row['user_fullname'] ?? ''));
                $display = $fullName !== '' ? $fullName : ($username !== '' ? $username : 'User #' . $buyerId);
                $avatar = 'uploads/user_avatars/default.jpeg';
                if ($buyerId > 0 && method_exists($this, 'RL_userAvatar')) {
                    $candidate = (string) $this->RL_userAvatar($buyerId);
                    if ($candidate !== '') {
                        $avatar = $candidate;
                    }
                } elseif (!empty($row['user_avatar'])) {
                    $avatar = (string) $row['user_avatar'];
                }
                $ebookId = (int)($row['ebook_id'] ?? 0);
                $title = trim((string)($row['title'] ?? ''));
                if ($title === '') {
                    $title = 'eBook #' . $ebookId;
                }
                $out[] = [
                    'type'           => 'ebook',
                    'post'           => $title,
                    'ebook'          => $title,
                    'ebook_id'       => $ebookId,
                    'slug'           => (string)($row['slug'] ?? ''),
                    'buyer'          => $display,
                    'display_name'   => $display,
                    'full_name'      => $fullName,
                    'buyer_display'  => $display,
                    'buyer_username' => $username,
                    'buyer_avatar'   => $avatar,
                    'username'       => $username,
                    'avatar'         => $avatar,
                    'buyer_id'       => $buyerId,
                    'amount'         => isset($row['net_amount']) && $row['net_amount'] !== null ? (float)$row['net_amount'] : (isset($row['amount']) ? (float)$row['amount'] : null),
                    'currency'       => (string)($row['currency'] ?? ''),
                    'date'           => isset($row['created_at']) ? (int)$row['created_at'] : null,
                ];
            }
            return $out;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('cdGetRecentEbookSales failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    /**
     * Entry point to compute creator dashboard metrics.
     */
    public function RL_GetCreatorDashboard(int $creatorId, ?int $now = null): array
    {
        if ($creatorId <= 0) {
            return [];
        }
        $now = $now ?? time();

        // Followers/subscribers series cover last 14 days to compute week-over-week change.
        $seriesDays = 14;
        $seriesStart = strtotime(date('Y-m-d 00:00:00', $now)) - ($seriesDays - 1) * 86400;

        $followersMap = $this->cdFetchFriendDailyMap($creatorId, 'flwr', $seriesStart);
        $followersSeries = $this->cdNormalizeDailySeries($followersMap, $seriesDays, $now);

        $subsMap = $this->cdFetchFriendDailyMap($creatorId, 'subscriber', $seriesStart);
        $subsSeries = $this->cdNormalizeDailySeries($subsMap, $seriesDays, $now);

        // Earnings: collect 30 days for chart & revenue breakdown.
        $earnDays = 30;
        $earnStart = strtotime(date('Y-m-d 00:00:00', $now)) - ($earnDays - 1) * 86400;
        $earnData = $this->cdFetchEarningsDailyMap($creatorId, $earnStart);
        $earnSeries = $this->cdNormalizeDailySeries($earnData['map'], $earnDays, $now);

        $followersValues = $followersSeries['values'];
        $subsValues = $subsSeries['values'];
        $earnValues = $earnSeries['values'];

        $todayFollowers = $followersValues[count($followersValues) - 1] ?? 0.0;
        $yesterdayFollowers = $followersValues[count($followersValues) - 2] ?? 0.0;
        $todaySubs = $subsValues[count($subsValues) - 1] ?? 0.0;
        $yesterdaySubs = $subsValues[count($subsValues) - 2] ?? 0.0;
        $todayEarn = $earnValues[count($earnValues) - 1] ?? 0.0;
        $yesterdayEarn = $earnValues[count($earnValues) - 2] ?? 0.0;

        $weeklyFollowers = $this->cdSumSlice($followersValues, 7, 0);
        $prevWeeklyFollowers = $this->cdSumSlice($followersValues, 7, 7);
        $weeklySubs = $this->cdSumSlice($subsValues, 7, 0);
        $prevWeeklySubs = $this->cdSumSlice($subsValues, 7, 7);
        $weeklyEarn = $this->cdSumSlice($earnValues, 7, 0);
        $prevWeeklyEarn = $this->cdSumSlice($earnValues, 7, 7);

        $followersSeriesLast7 = array_slice($followersSeries['series'], -7);
        $subsSeriesLast7 = array_slice($subsSeries['series'], -7);
        $earnSeriesLast7 = array_slice($earnSeries['series'], -7);

        $recentSubscribers = $this->cdGetRecentSubscriptions($creatorId);
        $recentTips = $this->cdGetRecentTips($creatorId);
        $recentSales = $this->cdGetRecentSales($creatorId);
        $recentEbookSales = $this->cdGetRecentEbookSales($creatorId);
        $recentAudioRoomEarnings = $this->cdGetRecentAudioRoomEarnings($creatorId);
        $combinedSales = array_merge(
            array_map(static function (array $sale): array {
                $sale['type'] = $sale['type'] ?? 'post';
                return $sale;
            }, $recentSales),
            $recentEbookSales
        );
        usort($combinedSales, static function (array $a, array $b): int {
            return (int)($b['date'] ?? 0) <=> (int)($a['date'] ?? 0);
        });
        $combinedSales = array_slice($combinedSales, 0, 8);

        return [
            'daily' => [
                'followers' => [
                    'value'  => $todayFollowers,
                    'delta'  => $this->cdPercentChange($todayFollowers, $yesterdayFollowers),
                    'series' => $followersSeriesLast7,
                    'labels' => array_slice($followersSeries['labels'], -7),
                ],
                'subscribers' => [
                    'value'  => $todaySubs,
                    'delta'  => $this->cdPercentChange($todaySubs, $yesterdaySubs),
                    'series' => $subsSeriesLast7,
                    'labels' => array_slice($subsSeries['labels'], -7),
                ],
                'earnings' => [
                    'value'  => $todayEarn,
                    'delta'  => $this->cdPercentChange($todayEarn, $yesterdayEarn),
                    'series' => $earnSeriesLast7,
                    'labels' => array_slice($earnSeries['labels'], -7),
                ],
            ],
            'weekly' => [
                'followers' => [
                    'value'  => $weeklyFollowers,
                    'delta'  => $this->cdPercentChange($weeklyFollowers, $prevWeeklyFollowers),
                    'series' => $followersSeriesLast7,
                    'labels' => array_slice($followersSeries['labels'], -7),
                ],
                'subscribers' => [
                    'value'  => $weeklySubs,
                    'delta'  => $this->cdPercentChange($weeklySubs, $prevWeeklySubs),
                    'series' => $subsSeriesLast7,
                    'labels' => array_slice($subsSeries['labels'], -7),
                ],
                'earnings' => [
                    'value'  => $weeklyEarn,
                    'delta'  => $this->cdPercentChange($weeklyEarn, $prevWeeklyEarn),
                    'series' => $earnSeriesLast7,
                    'labels' => array_slice($earnSeries['labels'], -7),
                ],
            ],
            'recent_subscribers' => $recentSubscribers,
            'recent_tips'        => $recentTips,
            'recent_sales'       => $combinedSales,
            'recent_post_sales'  => $recentSales,
            'recent_ebook_sales' => $recentEbookSales,
            'recent_audio_room_earnings' => $recentAudioRoomEarnings,
            'revenue_breakdown'  => $earnData['totals'],
        ];
    }
}
