<?php
declare(strict_types=1);

/**
 * Profile-specific helpers: cover image + filtered, cursor-based grid feed.
 */
trait ProfileFunctions
{
    // Profile grid context (avoid dynamic properties in PHP 8.2+)
    private int $pfOwnerId  = 0;
    private int $pfViewerId = 0;
    private ?string $pfRelation = null; // 'subscriber' | 'flwr' | 'me' | null
    /**
     * Get user's cover path (relative). Returns empty string when no cover is set.
     */
    public function RL_GetUserCover(int $userId): string
    {
        if ($userId <= 0) { return ''; }
        try {
            $st = $this->db->prepare("SELECT user_cover FROM i_users WHERE user_id = :uid LIMIT 1");
            $st->bindValue(':uid', $userId, \PDO::PARAM_INT);
            $st->execute();
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            $val = isset($row['user_cover']) ? trim((string)$row['user_cover']) : '';
            if ($val !== '') { return $val; }

            return '';
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetUserCover failed: ' . $e->getMessage());
            }
            return '';
        }
    }

    /**
     * Aggregate profile counters for a user.
     * Returns:
     *  - posts: total posts (any visibility) EXCLUDING podcasts (keeps All tab focused on images/videos)
     *  - reels: public videos count (post_type='video' AND post_visibility='everyone')
     *  - images: public images count (post_type='image' AND post_visibility='everyone')
     *  - premium: locked posts count (post_visibility='locked')
     *  - subscriber: subscribers-only posts count (post_visibility IN ('subscriber','subscribers'))
     *  - podcasts: public podcasts count (post_type='podcast' AND post_visibility='everyone')
     */
    public function RL_ProfileCounters(int $userId): array
    {
        $out = ['posts'=>0,'reels'=>0,'images'=>0,'premium'=>0,'subscriber'=>0,'podcasts'=>0];
        if ($userId <= 0) { return $out; }
        $viewerId = (int)($GLOBALS['userID'] ?? 0);
        $viewerIsAdmin = isset($GLOBALS['isAdminUser']) ? (bool)$GLOBALS['isAdminUser'] : false;
        $viewerIsOwner = $viewerId > 0 && $viewerId === $userId;
        $approvalClause = (!$viewerIsOwner && !$viewerIsAdmin) ? " AND approval_status = 'approved'" : '';
        try {
            $sql = "SELECT
                        SUM(CASE WHEN post_type <> 'podcast' THEN 1 ELSE 0 END) AS total_posts,
                        SUM(CASE WHEN post_type = 'video' AND post_visibility = 'everyone' THEN 1 ELSE 0 END) AS total_videos,
                        SUM(CASE WHEN post_type = 'image' AND post_visibility = 'everyone' THEN 1 ELSE 0 END) AS total_images,
                        SUM(CASE WHEN post_visibility = 'locked' THEN 1 ELSE 0 END) AS total_premium,
                        SUM(CASE WHEN post_visibility IN ('subscriber','subscribers') THEN 1 ELSE 0 END) AS total_subscribers,
                        SUM(CASE WHEN post_type = 'podcast' AND post_visibility = 'everyone' THEN 1 ELSE 0 END) AS total_podcasts
                    FROM i_user_posts
                    WHERE post_owner_id = :uid" . $approvalClause;
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', (int)$userId, \PDO::PARAM_INT);
            $st->execute();
            $row = (array)$st->fetch(\PDO::FETCH_ASSOC);
            $out['posts']      = (int)($row['total_posts'] ?? 0);
            $out['reels']      = (int)($row['total_videos'] ?? 0);
            $out['images']     = (int)($row['total_images'] ?? 0);
            $out['premium']    = (int)($row['total_premium'] ?? 0);
            $out['subscriber'] = (int)($row['total_subscribers'] ?? 0);
            $out['podcasts']   = (int)($row['total_podcasts'] ?? 0);
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_ProfileCounters failed: ' . $e->getMessage());
            }
        }
        return $out;
    }

    /**
     * Cursor-aware page builder for a user's grid with filter.
     *
     * @param int    $userId      Profile owner id
     * @param int    $cursorTime  0 for first page; otherwise older-than
     * @param int    $cursorId    tie-break id when timestamps equal
     * @param int    $tileLimit   max tiles
     * @param string $filter      'all'|'reels'|'images'|'premium'|'subscriber'
     * @return array{blocks: array, hasMore: bool, nextCursor: array{time:int,id:int}, startLayout: string}
     */
    public function RL_ProfileGetPageByCursor(
        int $userId,
        int $cursorTime,
        int $cursorId,
        int $tileLimit = 25,
        string $filter = 'all'
    ): array {
        if ($tileLimit < 1)  { $tileLimit = 1; }
        if ($tileLimit > 200){ $tileLimit = 200; }

        // Initialize profile context (owner/viewer and relation)
        $this->pfOwnerId  = (int)$userId;
        $this->pfViewerId = (int)($GLOBALS['userID'] ?? 0);
        $this->pfRelation = $this->RL_ProfileRelationToOwner($this->pfViewerId, $this->pfOwnerId);

        $rows   = $this->RL_ProfileFetchByCursor($userId, $cursorTime, $cursorId, $tileLimit + 1, $filter);
        $hasMore = count($rows) > $tileLimit;
        if ($hasMore) { array_pop($rows); }

        // Map rows -> tiles
        $tiles = [];
        foreach ($rows as $r) {
            $type = (string)($r['post_type'] ?? '');
            $pid  = (int)($r['post_id'] ?? 0);
            if ($type === 'image') {
                $src = $this->RL_ProfileFirstImage((string)($r['post_file'] ?? ''));
                $imgCount = $this->RL_ProfileCountImages((string)($r['post_file'] ?? ''));
                if ($src === '') { continue; }
                $tiles[] = [
                    'type'  => 'image',
                    'src'   => $this->RL_ProfileUrl($src),
                    'id'    => $pid,
                    'multi' => ($imgCount > 1),
                    'views' => (int)($r['post_views'] ?? 0),
                    'visibility' => (string)($r['post_visibility'] ?? ''),
                    'price'      => $r['post_price'] !== null ? (string)$r['post_price'] : null,
                    'approval_status' => strtolower((string)($r['approval_status'] ?? 'approved')),
                    'approval_notes'  => $r['approval_notes'] ?? null,
                    // Context for alt text
                    'username'     => (string)($r['owner_username'] ?? ''),
                    'display_name' => (string)($r['owner_fullname'] ?? ''),
                    'caption'      => (string)($r['post_text'] ?? ''),
                ];
            } else {
                $tiles[] = [
                    'type' => 'video',
                    'src'  => $this->RL_ProfileUrl((string)($r['post_file'] ?? '')),
                    'id'   => $pid,
                    'views'=> (int)($r['post_views'] ?? 0),
                    'visibility' => (string)($r['post_visibility'] ?? ''),
                    'price'      => $r['post_price'] !== null ? (string)$r['post_price'] : null,
                    'approval_status' => strtolower((string)($r['approval_status'] ?? 'approved')),
                    'approval_notes'  => $r['approval_notes'] ?? null,
                    // Context for alt text
                    'username'     => (string)($r['owner_username'] ?? ''),
                    'display_name' => (string)($r['owner_fullname'] ?? ''),
                    'caption'      => (string)($r['post_text'] ?? ''),
                ];
            }
        }

        $blocks = $this->RL_ProfilePackIntoBlocks($tiles);

        $last = end($rows) ?: [];
        $nextCursor = [
            'time' => (int)($last['post_created_time'] ?? 0),
            'id'   => (int)($last['post_id'] ?? 0),
        ];

        return [
            'blocks'      => $blocks,
            'hasMore'     => $hasMore,
            'nextCursor'  => $nextCursor,
            'startLayout' => 'right',
        ];
    }

    /**
     * Fetch profile posts for a feed-style profile view.
     *
     * Uses the same visibility buckets as the existing profile tabs, but returns
     * rows shaped for the shared post_view.php renderer so locked/subscriber
     * handling stays centralized.
     *
     * @return array{posts: array<int,array<string,mixed>>, hasMore: bool, nextCursor: array{time:int,id:int}}
     */
    public function RL_ProfileGetFeedByCursor(
        int $userId,
        int $cursorTime,
        int $cursorId,
        int $limit = 10,
        string $filter = 'all'
    ): array {
        if ($userId <= 0) {
            return ['posts' => [], 'hasMore' => false, 'nextCursor' => ['time' => 0, 'id' => 0]];
        }
        if ($limit < 1) { $limit = 1; }
        if ($limit > 50) { $limit = 50; }

        $feedLang = isset($GLOBALS['currentLang']) && is_string($GLOBALS['currentLang']) ? strtolower((string) $GLOBALS['currentLang']) : 'eng';
        if ($feedLang === '') { $feedLang = 'eng'; }
        if (method_exists($this, 'RL_EnsurePodcastCategoriesTable')) {
            $this->RL_EnsurePodcastCategoriesTable();
        }

        $viewerId = (int)($GLOBALS['userID'] ?? 0);
        $viewerIsOwner = $viewerId > 0 && $viewerId === $userId;
        $viewerIsAdmin = isset($GLOBALS['isAdminUser']) ? (bool)$GLOBALS['isAdminUser'] : false;

        $where = ['p.post_owner_id = :uid'];
        $params = [':uid' => $userId, ':cat_lang' => $feedLang, ':viewer_id' => $viewerId];

        if (!$viewerIsOwner && !$viewerIsAdmin) {
            $where[] = "(p.approval_status IS NULL OR p.approval_status = 'approved')";
        }

        $f = strtolower(trim($filter));
        if ($f === 'images') {
            $where[] = "p.post_type = 'image'";
            $where[] = "p.post_visibility = 'everyone'";
        } elseif ($f === 'reels' || $f === 'videos' || $f === 'video') {
            $where[] = "p.post_type = 'video'";
            $where[] = "p.post_visibility = 'everyone'";
        } elseif ($f === 'premium') {
            $where[] = "p.post_visibility = 'locked'";
            $where[] = "p.post_type <> 'podcast'";
        } elseif ($f === 'subscriber' || $f === 'subscribers') {
            $where[] = "p.post_visibility = 'subscribers'";
            $where[] = "p.post_type <> 'podcast'";
        } else {
            $where[] = "p.post_visibility = 'everyone'";
            $where[] = "p.post_type <> 'podcast'";
        }

        if ($cursorTime > 0) {
            $where[] = "(p.post_created_time < :ct1 OR (p.post_created_time = :ct2 AND p.post_id < :cid))";
            $params[':ct1'] = $cursorTime;
            $params[':ct2'] = $cursorTime;
            $params[':cid'] = $cursorId;
        }

        $fetchLimit = $limit + 1;
        $sql = "SELECT
                    p.post_id,
                    p.post_owner_id,
                    p.post_type,
                    p.post_file,
                    p.audio_duration_seconds,
                    p.podcast_category_id,
                    p.locked_preview_path,
                    p.locked_preview_type,
                    p.post_text,
                    p.post_visibility,
                    p.post_price,
                    p.comment_status,
                    p.like_status,
                    p.approval_status,
                    p.approval_notes,
                    p.approved_at,
                    p.approved_by,
                    p.post_created_time,
                    u.user_id AS owner_id,
                    u.username AS owner_username,
                    u.user_fullname AS owner_fullname,
                    u.user_avatar AS owner_avatar,
                    u.verified_status AS owner_verified,
                    rel_v2o.fr_status AS viewer_to_owner_status,
                    COALESCE(pct.name, pc.name) AS podcast_category_name,
                    pc.slug AS podcast_category_slug,
                    pc.status AS podcast_category_status
                FROM i_user_posts p
                INNER JOIN i_users u ON u.user_id = p.post_owner_id
                LEFT JOIN i_podcast_categories pc ON pc.id = p.podcast_category_id
                LEFT JOIN i_podcast_category_translations pct ON pct.category_id = pc.id AND pct.language = :cat_lang
                LEFT JOIN (
                    SELECT fr_two AS other_id,
                        SUBSTRING_INDEX(
                            GROUP_CONCAT(fr_status ORDER BY FIELD(fr_status,'subscriber','flwr','me') DESC SEPARATOR ','),
                            ',', 1
                        ) AS fr_status
                    FROM i_friends
                    WHERE fr_one = :viewer_id
                    GROUP BY fr_two
                ) rel_v2o ON rel_v2o.other_id = p.post_owner_id
                WHERE " . implode(' AND ', $where) . "
                ORDER BY p.post_created_time DESC, p.post_id DESC
                LIMIT {$fetchLimit}";

        $stmt = $this->db->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value, is_int($value) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        $stmt->execute();
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];

        $hasMore = count($rows) > $limit;
        if ($hasMore) {
            array_pop($rows);
        }

        $posts = [];
        foreach ($rows as $row) {
            $ownerId = (int)($row['post_owner_id'] ?? 0);
            $posts[] = [
                'post_id'           => (int)($row['post_id'] ?? 0),
                'post_owner_id'     => $ownerId,
                'post_type'         => (string)($row['post_type'] ?? ''),
                'post_file'         => (string)($row['post_file'] ?? ''),
                'audio_duration_seconds' => $row['audio_duration_seconds'] !== null ? (int)$row['audio_duration_seconds'] : null,
                'podcast_category_id' => $row['podcast_category_id'] !== null ? (int)$row['podcast_category_id'] : null,
                'podcast_category_name' => $row['podcast_category_name'] !== null ? (string)$row['podcast_category_name'] : null,
                'podcast_category_slug' => $row['podcast_category_slug'] !== null ? (string)$row['podcast_category_slug'] : null,
                'podcast_category_status' => $row['podcast_category_status'] !== null ? (string)$row['podcast_category_status'] : null,
                'locked_preview_path' => $row['locked_preview_path'] !== null ? (string)$row['locked_preview_path'] : '',
                'locked_preview_type' => $row['locked_preview_type'] !== null ? (string)$row['locked_preview_type'] : null,
                'post_text'         => (string)($row['post_text'] ?? ''),
                'post_visibility'   => (string)($row['post_visibility'] ?? ''),
                'post_price'        => $row['post_price'] !== null ? (string)$row['post_price'] : null,
                'comment_status'    => (string)($row['comment_status'] ?? 'active'),
                'like_status'       => (string)($row['like_status'] ?? 'active'),
                'approval_status'   => isset($row['approval_status']) ? (string)$row['approval_status'] : 'approved',
                'approval_notes'    => $row['approval_notes'] !== null ? (string)$row['approval_notes'] : null,
                'approved_at'       => $row['approved_at'] !== null ? (int)$row['approved_at'] : null,
                'approved_by'       => $row['approved_by'] !== null ? (int)$row['approved_by'] : null,
                'post_created_time' => (int)($row['post_created_time'] ?? 0),
                'owner_id'          => (int)($row['owner_id'] ?? $ownerId),
                'owner_username'    => (string)($row['owner_username'] ?? ''),
                'owner_fullname'    => (string)($row['owner_fullname'] ?? ''),
                'owner_avatar'      => (string)($row['owner_avatar'] ?? ''),
                'owner_verified'    => (int)($row['owner_verified'] ?? 0),
                'viewer_to_owner_status' => $row['viewer_to_owner_status'] !== null ? (string)$row['viewer_to_owner_status'] : null,
                'is_owner'          => ($viewerId > 0 && $viewerId === $ownerId),
            ];
        }

        $last = end($rows) ?: [];
        return [
            'posts' => $posts,
            'hasMore' => $hasMore,
            'nextCursor' => [
                'time' => (int)($last['post_created_time'] ?? 0),
                'id' => (int)($last['post_id'] ?? 0),
            ],
        ];
    }

    /** Core fetcher used by RL_ProfileGetPageByCursor. */
    private function RL_ProfileFetchByCursor(
        int $userId,
        int $cursorTime,
        int $cursorId,
        int $limit,
        string $filter
    ): array {
        if ($userId <= 0) { return []; }
        if ($limit < 1)  { $limit = 1; }
        if ($limit > 200){ $limit = 200; }

        $where = ['post_owner_id = :uid'];
        $params = [':uid' => $userId];
        $viewerIsOwner = $this->pfViewerId > 0 && $this->pfViewerId === $this->pfOwnerId;
        $viewerIsAdmin = isset($GLOBALS['isAdminUser']) ? (bool)$GLOBALS['isAdminUser'] : false;
        if (!$viewerIsOwner && !$viewerIsAdmin) {
            $where[] = "(p.approval_status IS NULL OR p.approval_status = 'approved')";
        }

        $f = strtolower(trim($filter));
        if ($f === 'images') {
            // Public images only
            $where[] = "post_type = 'image'";
            $where[] = "post_visibility = 'everyone'";
        } elseif ($f === 'reels' || $f === 'videos' || $f === 'video') {
            // Public videos only
            $where[] = "post_type = 'video'";
            $where[] = "post_visibility = 'everyone'";
        } elseif ($f === 'podcasts' || $f === 'podcast') {
            // Public podcasts only
            $where[] = "post_type = 'podcast'";
            $where[] = "post_visibility = 'everyone'";
        } elseif ($f === 'premium') {
            // Only locked (PPV) posts
            $where[] = "post_visibility = 'locked'";
        } elseif ($f === 'subscriber') {
            // Subscribers-only posts
            $where[] = "post_visibility = 'subscribers'";
        } else {
            // Default 'all' => only public posts (exclude podcasts to keep tab separate)
            $where[] = "post_visibility = 'everyone'";
            $where[] = "post_type <> 'podcast'";
        }

        // Cursor clause
        $cursorSql = '';
        if ($cursorTime > 0) {
            $cursorSql = " AND (post_created_time < :ct1 OR (post_created_time = :ct2 AND post_id < :cid))";
            $params[':ct1'] = (int)$cursorTime;
            $params[':ct2'] = (int)$cursorTime;
            $params[':cid'] = (int)$cursorId;
        }

        // Include caption + owner identity for contextual alt text (single SELECT; no per-row queries)
        // Test checklist (Profile alt text):
        // - Tiles use caption-based alt when available
        // - Else fall back to "Content by @username"
        // - Else generic image_alt_generic
        // - No extra per-row queries (JOIN users once)
        $sql = "SELECT p.post_id, p.post_type, p.post_file, p.post_created_time, p.post_visibility, p.post_price, p.post_views,
                       p.post_text, p.approval_status, p.approval_notes, p.approved_at, p.approved_by,
                       u.username AS owner_username, u.user_fullname AS owner_fullname
                FROM i_user_posts p
                JOIN i_users u ON u.user_id = p.post_owner_id
                WHERE " . implode(' AND ', $where) . $cursorSql . "
                ORDER BY p.post_created_time DESC, p.post_id DESC
                LIMIT {$limit}";

        $st = $this->db->prepare($sql);
        foreach ($params as $k => $v) {
            $st->bindValue($k, $v, is_int($v) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        $st->execute();
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }

    /**
     * Fetch a list of public podcasts for the profile (newest first).
     * Returns an array of rows with resolved URLs and durations.
     */
    public function RL_ProfileGetPodcastsList(int $userId, int $limit = 25, ?string $categorySlug = null): array
    {
        if ($userId <= 0) { return []; }
        if ($limit < 1) { $limit = 1; }
        if ($limit > 100) { $limit = 100; }

        if (method_exists($this, 'RL_EnsurePodcastCategoriesTable')) {
            $this->RL_EnsurePodcastCategoriesTable();
        }

        $profileLang = isset($GLOBALS['currentLang']) && is_string($GLOBALS['currentLang']) ? strtolower((string) $GLOBALS['currentLang']) : 'eng';
        if ($profileLang === '') {
            $profileLang = 'eng';
        }

        $categoryIdFilter = null;
        if ($categorySlug !== null) {
            $slug = strtolower(trim($categorySlug));
            if ($slug !== '') {
                $cat = method_exists($this, 'RL_GetPodcastCategoryBySlug') ? $this->RL_GetPodcastCategoryBySlug($slug) : null;
                if (!$cat) {
                    return [];
                }
                $categoryIdFilter = (int) ($cat['id'] ?? 0);
                if ($categoryIdFilter <= 0) {
                    return [];
                }
            }
        }

        $viewerId = (int)($GLOBALS['userID'] ?? 0);
        $viewerIsOwner = $viewerId > 0 && $viewerId === $userId;
        $viewerIsAdmin = isset($GLOBALS['isAdminUser']) ? (bool)$GLOBALS['isAdminUser'] : false;

        $where = ["p.post_owner_id = :uid", "p.post_type = 'podcast'"];
        if (!$viewerIsOwner && !$viewerIsAdmin) {
            $where[] = "p.post_visibility = 'everyone'";
            $where[] = "(p.approval_status IS NULL OR p.approval_status = 'approved')";
        }
        if ($categoryIdFilter !== null) {
            $where[] = "p.podcast_category_id = :catId";
        }

        $sql = "SELECT p.post_id, p.post_text, p.post_file, p.audio_duration_seconds, p.post_created_time,
                       p.podcast_category_id,
                       COALESCE(pct.name, pc.name) AS podcast_category_name,
                       pc.slug AS podcast_category_slug,
                       pc.status AS podcast_category_status
                FROM i_user_posts p
                LEFT JOIN i_podcast_categories pc ON pc.id = p.podcast_category_id
                LEFT JOIN i_podcast_category_translations pct ON pct.category_id = pc.id AND pct.language = :cat_lang
                WHERE " . implode(' AND ', $where) . "
                ORDER BY p.post_created_time DESC, p.post_id DESC
                LIMIT {$limit}";

        $st = $this->db->prepare($sql);
        $st->bindValue(':uid', $userId, \PDO::PARAM_INT);
        $st->bindValue(':cat_lang', $profileLang, \PDO::PARAM_STR);
        if ($categoryIdFilter !== null) {
            $st->bindValue(':catId', $categoryIdFilter, \PDO::PARAM_INT);
        }
        $st->execute();
        $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];

        $out = [];
        foreach ($rows as $r) {
            $audioKey  = isset($r['post_file']) ? trim((string)$r['post_file']) : '';
            $coverKey  = '';
            if (isset($r['cover_path'])) {
                $coverKey = trim((string)$r['cover_path']);
            } elseif (method_exists($this, 'RL_GetPostCoverPath')) {
                $coverKey = $this->RL_GetPostCoverPath((int)($r['post_id'] ?? 0));
            }
            $out[] = [
                'post_id'   => (int)($r['post_id'] ?? 0),
                'title'     => trim((string)($r['post_text'] ?? '')),
                'audio_url' => $this->RL_ProfileUrl($audioKey),
                'cover_url' => $coverKey !== '' ? $this->RL_ProfileUrl($coverKey) : '',
                'duration'  => isset($r['audio_duration_seconds']) ? (int)$r['audio_duration_seconds'] : null,
                'created'   => (int)($r['post_created_time'] ?? 0),
                'category_id' => $r['podcast_category_id'] !== null ? (int)$r['podcast_category_id'] : null,
                'category_name' => isset($r['podcast_category_name']) ? (string)$r['podcast_category_name'] : null,
                'category_slug' => isset($r['podcast_category_slug']) ? (string)$r['podcast_category_slug'] : null,
                'category_status' => isset($r['podcast_category_status']) ? (string)$r['podcast_category_status'] : null,
            ];
        }

        return $out;
    }

    /**
     * Reduce images CSV to first image path.
     */
    private function RL_ProfileFirstImage(string $csv): string
    {
        $parts = array_filter(array_map('trim', explode(',', $csv)));
        return $parts[0] ?? '';
    }

    /** Relation to owner collapsed to one status: 'subscriber' > 'flwr' > 'me' or null. */
    private function RL_ProfileRelationToOwner(int $viewerId, int $ownerId): ?string
    {
        if ($viewerId <= 0 || $ownerId <= 0 || $viewerId === $ownerId) {
            return $viewerId === $ownerId ? 'me' : null;
        }
        try {
            $sql = "SELECT SUBSTRING_INDEX(GROUP_CONCAT(fr_status ORDER BY FIELD(fr_status,'subscriber','flwr','me') DESC SEPARATOR ','), ',', 1) AS s
                    FROM i_friends WHERE fr_one = :v AND fr_two = :o";
            $st = $this->db->prepare($sql);
            $st->execute([':v'=>$viewerId, ':o'=>$ownerId]);
            $s = $st->fetchColumn();
            return $s !== false ? (string)$s : null;
        } catch (\Throwable $e) { return null; }
    }

    /** Decide visibility for a tile based on post_view.php rules. */
    private function RL_ProfileTileCanView(array $tile): array
    {
        $can = true; $msg = '';
        $vis = (string)($tile['visibility'] ?? 'everyone');
        $price = $tile['price'] ?? null;
        $pid = (int)($tile['id'] ?? 0);

        if ($this->pfViewerId > 0 && $this->pfViewerId === $this->pfOwnerId) {
            return [true, '']; // owner always can view
        }

        switch ($vis) {
            case 'everyone':
                $can = true; break;
            case 'followers':
                $can = in_array($this->pfRelation, ['flwr','subscriber'], true); break;
            case 'subscriber': // tolerate singular
            case 'subscribers':
                $can = ($this->pfRelation === 'subscriber'); break;
            case 'locked':
                $can = method_exists($this, 'hasPurchasedPost') ? $this->hasPurchasedPost($this->pfViewerId, $pid) : false; break;
            default:
                $can = true; break;
        }

        if (!$can) {
            $base = $this->resolveIconPath();
            if ($vis === 'subscriber' || $vis === 'subscribers') {
                // CTA: Join Now (subscribeMe) — use owner id from context
                $ownerId = (int) $this->pfOwnerId;
                $cta = '<div class="unlock-price flex align_items transition subscribeMe" data-id="' . $ownerId . '">' . (function_exists('customLang') ? customLang('join_now') : 'Join Now') . '</div>';
                $msg = '<div class="tile-overlay tile-overlay--interactive flex align_items flexBoxColumn gap">'
                    . '<div class="unlock-icon flex align_items">'
                    . '  <div class="locked">' . renderVerifiedBadge($base . 'locked.svg', true) . '</div>'
                    . '  <div class="unlock">' . renderVerifiedBadge($base . 'unlocked.svg', true) . '</div>'
                    . '</div>'
                    . '<span class="metric-value flex align_items">' . (function_exists('customLang') ? customLang('subscribers_only') : 'Subscribers-Only') . '</span>'
                    . $cta
                    . '</div>';
            } elseif ($vis === 'locked') {
                // CTA: Unlock for {price}
                $cur = (string)($GLOBALS['currency'] ?? 'USD');
                $settings = $GLOBALS['currency_format_settings'] ?? null;
                if (!is_array($settings) || !isset($settings['position'])) {
                    if (isset($GLOBALS['currency_format_client']) && is_array($GLOBALS['currency_format_client'])) {
                        $cfc = $GLOBALS['currency_format_client'];
                        $settings = [
                            'position'        => $cfc['position']      ?? 'left',
                            'decimal_places'  => $cfc['decimalPlaces'] ?? 2,
                            'decimal_sep'     => $cfc['decimalSep']    ?? '.',
                            'thousands_sep'   => $cfc['thousandsSep']  ?? ',',
                        ];
                    } else {
                        $settings = dz_currency_normalize_settings([]);
                    }
                }
                $label = (function_exists('customLang') ? customLang('unlock_for') : 'Unlock for');
                $formatted = dz_format_currency((float)$price, $cur, null, $settings);
                $position = $settings['position'] ?? 'left';
                $btn  = '<div class="unlock-price flex align_items transition unlockPost"'
                      . ' data-id="' . $pid . '"'
                      . ' data-price="' . htmlspecialchars((string)$price, ENT_QUOTES, 'UTF-8') . '"'
                      . ' data-price-display="' . htmlspecialchars($formatted, ENT_QUOTES, 'UTF-8') . '"'
                      . ' data-currency-position="' . htmlspecialchars($position, ENT_QUOTES, 'UTF-8') . '">'
                      . $label . ' ' . htmlspecialchars($formatted, ENT_QUOTES, 'UTF-8')
                      . '</div>';
                $msg = '<div class="tile-overlay tile-overlay--interactive flex align_items flexBoxColumn gap">'
                    . '<div class="unlock-icon flex align_items">'
                    . '  <div class="locked">' . renderVerifiedBadge($base . 'locked.svg', true) . '</div>'
                    . '  <div class="unlock">' . renderVerifiedBadge($base . 'unlocked.svg', true) . '</div>'
                    . '</div>'
                    . $btn
                    . '</div>';
            } else {
                $msg = '<div class="tile-overlay flex align_items"><span class="metric-icon flex align_items">' . renderVerifiedBadge($base . 'locked.svg', true) . '</span><span class="metric-value flex align_items">Followers only</span></div>';
            }
        }
        return [$can, $msg];
    }

    /** Count images in CSV. */
    private function RL_ProfileCountImages(string $csv): int
    {
        if ($csv === '') { return 0; }
        $parts = array_filter(array_map('trim', explode(',', $csv)));
        return count($parts);
    }

    /** Keep URLs relative like ExploreFunctions::url(). */
    private function RL_ProfileUrl(string $path): string
    {
        $path = trim($path);
        if ($path === '') { return ''; }

        // If already absolute (http/https or data URI), return as-is
        if (preg_match('~^(?:https?:)?//~i', $path) || str_starts_with($path, 'data:')) {
            return $path;
        }

        // Prepend global base_url safely
        $base = (string) ($GLOBALS['base_url'] ?? '');
        if ($base === '') { return $path; }

        $full = rtrim($base, '/') . '/' . ltrim($path, '/');
        // Collapse any accidental double slashes (except protocol)
        $full = preg_replace('~(?<!:)//+~', '/', $full);
        return $full;
    }

    /**
     * Pack tiles into 5-tile blocks (a,b,c,d + V), similar to Explore.
     * Accepts both image and video tiles and ensures max one tall video per block.
     *
     * @param array<int, array{type:string,src:string,id?:int,multi?:bool}> $tiles
     * @return array<int, array<int, array{type:string,src:string,id?:int,multi?:bool,role?:string}>>
     */
    private function RL_ProfilePackIntoBlocks(array $tiles): array
    {
        $queue  = array_values($tiles);
        $blocks = [];
        $outerGuard = 10000;

        while (!empty($queue) && $outerGuard-- > 0) {
            $images = [];
            $tall   = null;
            $next   = [];
            $progress = false;

            while (!empty($queue) && (count($images) < 4 || $tall === null)) {
                $t = array_shift($queue);
                $progress = true;
                if (!is_array($t) || empty($t['type'])) { continue; }

                if ($t['type'] === 'video') {
                    if ($tall === null) {
                        $tall = $t;
                    } else {
                        if (count($images) < 4) { $images[] = $t; } else { $next[] = $t; }
                    }
                } elseif ($t['type'] === 'image') {
                    if (count($images) < 4) {
                        $images[] = $t;
                    } else {
                        // Images-only mode: if we already have 4 squares and no tall yet,
                        // use this extra image as the tall slot instead of deferring it.
                        if ($tall === null) {
                            $tall = $t; // ensures 4 squares + 1 tall image (no ghost)
                        } else {
                            $next[] = $t;
                        }
                    }
                }
            }

            // If we still don't have a tall tile (no 5th item yet), optionally try to take one more
            // from the queue ONLY if it exists; NEVER promote a square to tall.
            if ($tall === null) {
                if (count($images) >= 4) {
                    if (!empty($queue)) {
                        $peek = reset($queue);
                        if (is_array($peek) && (($peek['type'] ?? '') === 'image' || ($peek['type'] ?? '') === 'video')) {
                            $tall = array_shift($queue);
                        }
                    }
                } else {
                    if (!$progress) { break; }
                    // Continue to next outer loop without forcing a tall
                }
            }

            // Do NOT re-queue the last tall tile. It's valid to end with
            // fewer than 5 real items (e.g., 0-3 squares + tall). Re-queuing
            // here causes an endless loop that emits ghost-only sections.

            // If there is no real content at all, skip emitting a block.
            if (empty($images) && $tall === null) {
                // Nothing real to render; stop to avoid ghost-only blocks.
                break;
            }

            $block = [];
            foreach ($images as $img) { $block[] = $img; }
            while (count($block) < 4) { $block[] = ['type' => 'ghost', 'src' => '']; }
            if ($tall !== null) {
                $tall['role'] = 'tall';
                $block[] = $tall;
            }
            $blocks[] = $block;

            $prevCount = count($queue);
            $queue = array_merge($next, $queue);
            if (!$progress && $prevCount === count($queue)) { break; }
        }

        return $blocks;
    }

    /** Render blocks with views count inside each tile (profile-only). */
    public function RL_ProfileRender(array $blocks, string $startLayout = 'right'): void
    {
        echo '<div class="explore-grid full-width">' . "\n";
        $right = ($startLayout === 'right');
        $areas = ['a', 'b', 'c', 'd'];

        foreach ($blocks as $block) {
            $layoutClass = $right ? 'is-right' : 'is-left';
            $right = !$right;

            echo '<section class="explore-block ' . $layoutClass . '">' . "\n";

            // Squares a,b,c,d
            for ($i = 0; $i < 4; $i++) {
                $item = $block[$i] ?? ['type' => 'ghost', 'src' => ''];
                $area = $areas[$i];
                $pid  = (int)($item['id'] ?? 0);
                $views= (int)($item['views'] ?? 0);
                $approvalPill = '';
                $approvalStatusTile = strtolower((string)($item['approval_status'] ?? 'approved'));
                if ($approvalStatusTile !== 'approved' && $this->pfViewerId === $this->pfOwnerId) {
                    $label = $approvalStatusTile === 'rejected'
                        ? (customLang('post_status_rejected') ?: 'Rejected')
                        : (customLang('post_status_pending') ?: 'Pending');
                    $approvalPill = '<span class="tile-approval-pill tile-approval-pill--' . iN_HelpSecure($approvalStatusTile, false) . '">' . iN_HelpSecure($label, false) . '</span>';
                }

                if (($item['type'] ?? '') === 'image' && !empty($item['src'])) {
                    $badge = $this->renderBadge('images', !empty($item['multi'] ?? false)) . $approvalPill;
                    $eng   = $this->getEngagement($pid);
                    [$canView, $lock] = $this->RL_ProfileTileCanView($item);
                    // Alt text: caption → content by @username → generic
                    $cap   = dzShortCaption($item['caption'] ?? '', 80);
                    $handle = (string)($item['display_name'] ?? '');
                    if ($handle === '' && !empty($item['username'])) { $handle = (string)$item['username']; }
                    if ($handle !== '') { $handle = '@' . $handle; }
                    $alt   = $cap !== '' ? $cap : ($handle !== '' ? sprintf(customLang('alt_tile_by_user'), $handle) : customLang('image_alt_generic'));
                    $this->RL_ProfileRenderSquare((string)$item['src'], $area, $pid, $views, $badge, $eng, $canView, $lock, $alt);
                } elseif (($item['type'] ?? '') === 'video' && !empty($item['src'])) {
                    $badge = $this->renderBadge('video', true) . $approvalPill;
                    $eng   = $this->getEngagement($pid);
                    [$canView, $lock] = $this->RL_ProfileTileCanView($item);
                    $cap   = dzShortCaption($item['caption'] ?? '', 80);
                    $handle = (string)($item['display_name'] ?? '');
                    if ($handle === '' && !empty($item['username'])) { $handle = (string)$item['username']; }
                    if ($handle !== '') { $handle = '@' . $handle; }
                    $alt   = $cap !== '' ? $cap : ($handle !== '' ? sprintf(customLang('alt_tile_by_user'), $handle) : customLang('image_alt_generic'));
                    $this->RL_ProfileRenderSquareVideo((string)$item['src'], $area, $pid, $views, $badge, $eng, $canView, $lock, $alt);
                } else {
                    $this->renderGhost($area);
                }
            }

            // Tall V
            $tall = $block[4] ?? ['type' => 'ghost', 'src' => ''];
            $pidTall = (int)($tall['id'] ?? 0);
            $viewsTall = (int)($tall['views'] ?? 0);
            $approvalPillTall = '';
            $approvalStatusTall = strtolower((string)($tall['approval_status'] ?? 'approved'));
            if ($approvalStatusTall !== 'approved' && $this->pfViewerId === $this->pfOwnerId) {
                $labelTall = $approvalStatusTall === 'rejected'
                    ? (customLang('post_status_rejected') ?: 'Rejected')
                    : (customLang('post_status_pending') ?: 'Pending');
                $approvalPillTall = '<span class="tile-approval-pill tile-approval-pill--' . iN_HelpSecure($approvalStatusTall, false) . '">' . iN_HelpSecure($labelTall, false) . '</span>';
            }
            if (($tall['type'] ?? '') === 'video' && !empty($tall['src'])) {
                $badge = $this->renderBadge('video', true) . $approvalPillTall;
                $eng   = $this->getEngagement($pidTall);
                [$canViewT, $lockT] = $this->RL_ProfileTileCanView($tall);
                $cap   = dzShortCaption($tall['caption'] ?? '', 80);
                $handle = (string)($tall['display_name'] ?? '');
                if ($handle === '' && !empty($tall['username'])) { $handle = (string)$tall['username']; }
                if ($handle !== '') { $handle = '@' . $handle; }
                $alt   = $cap !== '' ? $cap : ($handle !== '' ? sprintf(customLang('alt_tile_by_user'), $handle) : customLang('image_alt_generic'));
                $this->RL_ProfileRenderTallVideo((string)$tall['src'], $pidTall, $viewsTall, $badge, $eng, $canViewT, $lockT, $alt);
            } elseif (($tall['type'] ?? '') === 'image' && !empty($tall['src'])) {
                $badge = $this->renderBadge('images', !empty($tall['multi'] ?? false)) . $approvalPillTall;
                $eng   = $this->getEngagement($pidTall);
                [$canViewT, $lockT] = $this->RL_ProfileTileCanView($tall);
                $cap   = dzShortCaption($tall['caption'] ?? '', 80);
                $handle = (string)($tall['display_name'] ?? '');
                if ($handle === '' && !empty($tall['username'])) { $handle = (string)$tall['username']; }
                if ($handle !== '') { $handle = '@' . $handle; }
                $alt   = $cap !== '' ? $cap : ($handle !== '' ? sprintf(customLang('alt_tile_by_user'), $handle) : customLang('image_alt_generic'));
                $this->RL_ProfileRenderTallImage((string)$tall['src'], $pidTall, $viewsTall, $badge, $eng, $canViewT, $lockT, $alt);
            } else {
                $this->renderGhost('V', true);
            }

            echo '</section>' . "\n";
        }

        echo '</div>' . "\n";
    }

    public function RL_ProfileRenderToString(array $blocks, string $startLayout = 'right'): string
    {
        ob_start();
        $this->RL_ProfileRender($blocks, $startLayout);
        return (string) ob_get_clean();
    }

    /**
     * Flat list renderer (images.php-like) for non-"All" tabs.
     * Accepts a flat tile list (not blocks). Each tile contains: type, src, id, views, multi?, visibility?, price?
     */
    public function RL_ProfileRenderList(array $tiles, string $mode = 'images'): void
    {
        $base = $this->resolveIconPath();
        foreach ($tiles as $item) {
            $pid   = (int)($item['id'] ?? 0);
            $views = (int)($item['views'] ?? 0);
            $type  = (string)($item['type'] ?? 'image');

            // Derive display image
            $srcIn = (string)($item['src'] ?? '');
            if ($mode === 'reels') {
                // Force video thumb style like reels.php
                $thumb = $this->videoThumb($srcIn);
                $tileClass = 'reels_post_wrapper_reels';
            } else {
                // Images-style list (also works if item is video)
                $thumb = ($type === 'video') ? $this->videoThumb($srcIn) : $srcIn;
                $tileClass = 'reels_post_wrapper';
            }
            $imgSrc = $this->RL_ProfileUrl($thumb);

            // Visibility check (lock overlay and media suppression)
            [$canView, $lockHtml] = $this->RL_ProfileTileCanView($item);

            // Engagement metrics
            $eng = $this->getEngagement($pid);
            $likes = (int)($eng['likes'] ?? 0);
            $comms = (int)($eng['comments'] ?? 0);

            $wrapCls = $tileClass . ' relative';
            if ($canView) { $wrapCls .= ' getFullPost'; }
            echo '<div class="' . $wrapCls . '" data-post-id="' . $pid . '">';
            if ($canView) {
                // Alt: caption → content by @username → generic
                $cap   = dzShortCaption($item['caption'] ?? '', 80);
                $handle = (string)($item['display_name'] ?? '');
                if ($handle === '' && !empty($item['username'])) { $handle = (string)$item['username']; }
                if ($handle !== '') { $handle = '@' . $handle; }
                $alt   = $cap !== '' ? $cap : ($handle !== '' ? sprintf(customLang('alt_tile_by_user'), $handle) : customLang('image_alt_generic'));
                echo '  <img class="post-media" src="' . htmlspecialchars($imgSrc, ENT_QUOTES, 'UTF-8') . '" alt="' . iN_HelpSecure($alt) . '" loading="lazy" data-lazy-dimensions="skip" data-skip-image-dimensions="true">';
                // Hover overlay: like/comment
                echo '  <div class="tile-overlay flex align_items" aria-hidden="true">';
                echo '    <span class="metric metric-like flex align_items"><span class="metric-icon flex align_items">' . renderVerifiedBadge($base . 'post_liked.svg', true) . '</span><span class="metric-value flex align_items">' . $likes . '</span></span>';
                echo '    <span class="metric metric-comment flex align_items"><span class="metric-icon flex align_items">' . renderVerifiedBadge($base . 'post_commented.svg', true) . '</span><span class="metric-value flex align_items">' . $comms . '</span></span>';
                echo '  </div>';
            } else {
                // Locked placeholder + lock overlay
                echo '  <div class="tile-locked" aria-hidden="true"></div>';
                echo $lockHtml;
            }
            // Views counter
            echo '  <div class="tile-total-view flex align_items">';
            echo '    <div class="view-svg flex align_items">' . renderVerifiedBadge($base . 'view.svg', true) . '</div>';
            echo '    <div class="view-total flex align_items">' . $views . '</div>';
            echo '  </div>';
            // Multi-image indicator for images-only list
            if ($mode !== 'reels' && $type === 'image' && !empty($item['multi'])) {
                echo '  <div class="multi-image-indicator flex align_items" aria-label="Multiple images">' . renderVerifiedBadge($base . 'plus_image.svg', true) . '</div>';
            }
            echo '</div>';
        }
    }

    public function RL_ProfileRenderListToString(array $tiles, string $mode = 'images'): string
    {
        ob_start();
        $this->RL_ProfileRenderList($tiles, $mode);
        return (string) ob_get_clean();
    }

    private function RL_ProfileRenderViews(int $views): void
    {
        $base = $this->resolveIconPath();
        echo '<div class="tile-total-view flex align_items">';
        echo '  <div class="view-svg flex align_items">' . renderVerifiedBadge($base . 'view.svg', true) . '</div>';
        echo '  <div class="view-total flex align_items">' . (int)$views . '</div>';
        echo '</div>';
    }

    // Render square tile; alt text provided by caller for context-aware output
    private function RL_ProfileRenderSquare(string $src, string $area, int $postId, int $views, string $badgeHtml = '', ?array $engagement = null, bool $canView = true, string $lockHtml = '', ?string $altText = null): void
    {
        $rootCls = 'tile tile--square area-' . $area . ' tile-' . (int)$postId;
        if ($canView) { $rootCls .= ' getFullPost'; }
        echo '<div class="' . $rootCls . '" data-post-id="' . (int) $postId . '">';
        if ($badgeHtml !== '') {
            echo '  <div class="tile-badge tile-badge--tr">' . $badgeHtml . '</div>';
        }
        if ($canView) {
            $alt = $altText !== null && $altText !== '' ? iN_HelpSecure($altText) : iN_HelpSecure(customLang('image_alt_generic'));
            echo '  <img src="' . htmlspecialchars($src, ENT_QUOTES, 'UTF-8') . '" alt="' . $alt . '">';
            if (is_array($engagement)) { $this->renderOverlay($engagement); }
        } else {
            // Do not leak real media when locked
            echo '  <div class="tile-locked" aria-hidden="true"></div>';
            echo $lockHtml; // lock overlay
        }
        $this->RL_ProfileRenderViews($views);
        echo '</div>' . "\n";
    }

    private function RL_ProfileRenderSquareVideo(string $src, string $area, int $postId, int $views, string $badgeHtml = '', ?array $engagement = null, bool $canView = true, string $lockHtml = '', ?string $altText = null): void
    {
        $thumb = $this->videoThumb($src);
        $rootCls = 'tile tile--square area-' . $area . ' tile--video tile-' . (int)$postId;
        if ($canView) { $rootCls .= ' getFullPost'; }
        echo '<div class="' . $rootCls . '" data-post-id="' . (int) $postId . '">';
        if ($badgeHtml !== '') {
            echo '  <div class="tile-badge tile-badge--tr">' . $badgeHtml . '</div>';
        }
        if ($canView) {
            $alt = $altText !== null && $altText !== '' ? iN_HelpSecure($altText) : iN_HelpSecure(customLang('image_alt_generic'));
            echo '  <img src="' . htmlspecialchars($thumb, ENT_QUOTES, 'UTF-8') . '" alt="' . $alt . '">';
            if (is_array($engagement)) { $this->renderOverlay($engagement); }
        } else {
            echo '  <div class="tile-locked" aria-hidden="true"></div>';
            echo $lockHtml;
        }
        $this->RL_ProfileRenderViews($views);
        echo '</div>' . "\n";
    }

    private function RL_ProfileRenderTallImage(string $src, int $postId, int $views, string $badgeHtml = '', ?array $engagement = null, bool $canView = true, string $lockHtml = '', ?string $altText = null): void
    {
        $rootCls = 'tile tile--tall area-V tile-' . (int)$postId;
        if ($canView) { $rootCls .= ' getFullPost'; }
        echo '<div class="' . $rootCls . '" data-post-id="' . (int) $postId . '">';
        echo '  <div class="tile-meta">#' . (int) $postId . '</div>';
        if ($badgeHtml !== '') {
            echo '  <div class="tile-badge tile-badge--tr">' . $badgeHtml . '</div>';
        }
        if ($canView) {
            $alt = $altText !== null && $altText !== '' ? iN_HelpSecure($altText) : iN_HelpSecure(customLang('image_alt_generic'));
            echo '  <img src="' . htmlspecialchars($src, ENT_QUOTES, 'UTF-8') . '" alt="' . $alt . '">';
            if (is_array($engagement)) { $this->renderOverlay($engagement); }
        } else {
            echo '  <div class="tile-locked" aria-hidden="true"></div>';
            echo $lockHtml;
        }
        $this->RL_ProfileRenderViews($views);
        echo '</div>' . "\n";
    }

    private function RL_ProfileRenderTallVideo(string $src, int $postId, int $views, string $badgeHtml = '', ?array $engagement = null, bool $canView = true, string $lockHtml = '', ?string $altText = null): void
    {
        $thumb = $this->videoThumb($src);
        $rootCls = 'tile tile--tall area-V tile--video tile-' . (int)$postId;
        if ($canView) { $rootCls .= ' getFullPost'; }
        echo '<div class="' . $rootCls . '" data-post-id="' . (int) $postId . '">';
        if ($badgeHtml !== '') {
            echo '  <div class="tile-badge tile-badge--tr">' . $badgeHtml . '</div>';
        }
        if ($canView) {
            $alt = $altText !== null && $altText !== '' ? iN_HelpSecure($altText) : iN_HelpSecure(customLang('image_alt_generic'));
            echo '  <img src="' . htmlspecialchars($thumb, ENT_QUOTES, 'UTF-8') . '" alt="' . $alt . '">';
            if (is_array($engagement)) { $this->renderOverlay($engagement); }
        } else {
            echo '  <div class="tile-locked" aria-hidden="true"></div>';
            echo $lockHtml;
        }
        $this->RL_ProfileRenderViews($views);
        echo '</div>' . "\n";
    }

    /**
     * Followers list for a profile owner.
     * Returns minimal user info to render a simple list.
     *
     * @return array<int,array{user_id:int,username:string,user_fullname:string,verified_status:int,user_avatar:string}>
     */
    public function RL_ProfileGetFollowers(int $userId, int $offset = 0, int $limit = 50): array
    {
        if ($userId <= 0) { return []; }
        if ($limit < 1)  { $limit = 1; }
        if ($limit > 200){ $limit = 200; }

        $sql = "SELECT u.user_id, u.username, u.user_fullname, u.verified_status, u.user_avatar
                FROM (
                    SELECT fr_one AS uid, MAX(fr_time) AS t
                    FROM i_friends
                    WHERE fr_two = :uid AND fr_status IN ('flwr','subscriber')
                    GROUP BY fr_one
                ) s
                JOIN i_users u ON u.user_id = s.uid
                ORDER BY s.t DESC
                LIMIT :lim OFFSET :off";
        $st = $this->db->prepare($sql);
        $st->bindValue(':uid', $userId, \PDO::PARAM_INT);
        $st->bindValue(':lim', $limit, \PDO::PARAM_INT);
        $st->bindValue(':off', max(0, $offset), \PDO::PARAM_INT);
        $st->execute();
        $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        // Normalize types
        foreach ($rows as &$r) {
            $r['user_id'] = (int)($r['user_id'] ?? 0);
            $r['verified_status'] = (int)($r['verified_status'] ?? 0);
            if (empty($r['user_fullname'])) { $r['user_fullname'] = $r['username']; }
        }
        unset($r);
        return $rows;
    }

    /**
     * Following list for a profile owner (who they follow).
     */
    public function RL_ProfileGetFollowing(int $userId, int $offset = 0, int $limit = 50): array
    {
        if ($userId <= 0) { return []; }
        if ($limit < 1)  { $limit = 1; }
        if ($limit > 200){ $limit = 200; }

        $sql = "SELECT u.user_id, u.username, u.user_fullname, u.verified_status, u.user_avatar
                FROM (
                    SELECT fr_two AS uid, MAX(fr_time) AS t
                    FROM i_friends
                    WHERE fr_one = :uid AND fr_status IN ('flwr','subscriber')
                    GROUP BY fr_two
                ) s
                JOIN i_users u ON u.user_id = s.uid
                ORDER BY s.t DESC
                LIMIT :lim OFFSET :off";
        $st = $this->db->prepare($sql);
        $st->bindValue(':uid', $userId, \PDO::PARAM_INT);
        $st->bindValue(':lim', $limit, \PDO::PARAM_INT);
        $st->bindValue(':off', max(0, $offset), \PDO::PARAM_INT);
        $st->execute();
        $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        foreach ($rows as &$r) {
            $r['user_id'] = (int)($r['user_id'] ?? 0);
            $r['verified_status'] = (int)($r['verified_status'] ?? 0);
            if (empty($r['user_fullname'])) { $r['user_fullname'] = $r['username']; }
        }
        unset($r);
        return $rows;
    }

    /** Render a simple vertical list of user rows for followers/following pages. */
    public function RL_ProfileRenderUsersList(array $users): void
    {
        $base = (string) ($GLOBALS['base_url'] ?? '');
        $iconBase = $this->resolveIconPath();
        echo '<div class="user-list">';
        foreach ($users as $u) {
            $uid   = (int)($u['user_id'] ?? 0);
            $uname = (string)($u['username'] ?? '');
            $fname = (string)($u['user_fullname'] ?? $uname);
            $vstat = (int)($u['verified_status'] ?? 0);
            $avatarRel = (string)($u['user_avatar'] ?? 'uploads/user_avatars/default.jpeg');
            $avatarUrl = $base !== '' ? rtrim($base,'/') . '/' . ltrim($avatarRel,'/') : $avatarRel;
            $profileUrl = $base . 'profile/' . $uname;

            echo '<a class="user-list__item flex align_items" href="' . htmlspecialchars($profileUrl, ENT_QUOTES, 'UTF-8') . '">';
            $alt = sprintf(customLang('alt_avatar_of_user'), ($fname !== '' ? $fname : $uname));
            echo '  <span class="user-list__avatar"><img src="' . htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8') . '" alt="' . iN_HelpSecure($alt) . '"></span>';
            echo '  <span class="user-list__meta">';
            echo '    <span class="user-list__name">' . htmlspecialchars($fname, ENT_QUOTES, 'UTF-8');
            if ($vstat > 0) { echo ' ' . renderVerifiedBadge($iconBase . 'verified.svg', true); }
            echo '    </span>';
            echo '    <span class="user-list__username">@' . htmlspecialchars($uname, ENT_QUOTES, 'UTF-8') . '</span>';
            echo '  </span>';
            echo '</a>';
        }
        echo '</div>';
    }

    public function RL_ProfileRenderUsersListToString(array $users): string
    {
        ob_start();
        $this->RL_ProfileRenderUsersList($users);
        return (string) ob_get_clean();
    }

    /**
     * Enrich a list of users with counts and latest posts suitable for creators.php.
     * Input items should have at least: user_id, username, user_fullname?, verified_status?, user_avatar?
     * Output adds: posts_count, followers_count, following_count, latest_posts[] (max 3 per user).
     *
     * @param array<int,array> $users
     * @return array<int,array>
     */
    public function RL_ProfileEnrichCreators(array $users): array
    {
        if (empty($users)) { return []; }
        // Normalize and collect IDs
        $byId = [];
        $ids  = [];
        foreach ($users as $u) {
            $uid = isset($u['user_id']) ? (int)$u['user_id'] : 0;
            if ($uid <= 0) { continue; }
            if (empty($u['user_fullname']) && !empty($u['username'])) {
                $u['user_fullname'] = $u['username'];
            }
            $byId[$uid] = $u;
            $ids[] = $uid;
        }
        if (empty($ids)) { return array_values($byId); }

        // Helper to build IN clause safely
        $placeholders = implode(',', array_fill(0, count($ids), '?'));

        // Posts count per user
        try {
            $sql = "SELECT post_owner_id AS uid, COUNT(*) AS cnt
                    FROM i_user_posts
                    WHERE post_owner_id IN ($placeholders) AND post_visibility = 'everyone' AND approval_status = 'approved'
                    GROUP BY post_owner_id";
            $st = $this->db->prepare($sql);
            foreach ($ids as $i => $v) { $st->bindValue($i+1, $v, \PDO::PARAM_INT); }
            $st->execute();
            foreach ($st->fetchAll(\PDO::FETCH_ASSOC) as $r) {
                $uid = (int)($r['uid'] ?? 0);
                if ($uid && isset($byId[$uid])) { $byId[$uid]['posts_count'] = (int)($r['cnt'] ?? 0); }
            }
        } catch (\Throwable $e) { /* ignore */ }

        // Followers count per user (followers + subscribers)
        try {
            $sql = "SELECT fr_two AS uid, COUNT(*) AS cnt
                    FROM i_friends
                    WHERE fr_two IN ($placeholders) AND fr_status IN ('flwr','subscriber')
                    GROUP BY fr_two";
            $st = $this->db->prepare($sql);
            foreach ($ids as $i => $v) { $st->bindValue($i+1, $v, \PDO::PARAM_INT); }
            $st->execute();
            foreach ($st->fetchAll(\PDO::FETCH_ASSOC) as $r) {
                $uid = (int)($r['uid'] ?? 0);
                if ($uid && isset($byId[$uid])) { $byId[$uid]['followers_count'] = (int)($r['cnt'] ?? 0); }
            }
        } catch (\Throwable $e) { /* ignore */ }

        // Following count per user
        try {
            $sql = "SELECT fr_one AS uid, COUNT(*) AS cnt
                    FROM i_friends
                    WHERE fr_one IN ($placeholders) AND fr_status IN ('flwr','subscriber')
                    GROUP BY fr_one";
            $st = $this->db->prepare($sql);
            foreach ($ids as $i => $v) { $st->bindValue($i+1, $v, \PDO::PARAM_INT); }
            $st->execute();
            foreach ($st->fetchAll(\PDO::FETCH_ASSOC) as $r) {
                $uid = (int)($r['uid'] ?? 0);
                if ($uid && isset($byId[$uid])) { $byId[$uid]['following_count'] = (int)($r['cnt'] ?? 0); }
            }
        } catch (\Throwable $e) { /* ignore */ }

        // Latest 3 posts per user
        $latest = [];
        try {
            $sql = "SELECT post_id, post_owner_id, post_type, post_file, post_created_time
                    FROM i_user_posts
                    WHERE post_owner_id IN ($placeholders) AND post_visibility = 'everyone' AND approval_status = 'approved'
                    ORDER BY post_created_time DESC, post_id DESC";
            $st = $this->db->prepare($sql);
            foreach ($ids as $i => $v) { $st->bindValue($i+1, $v, \PDO::PARAM_INT); }
            $st->execute();
            while ($r = $st->fetch(\PDO::FETCH_ASSOC)) {
                $uid = (int)($r['post_owner_id'] ?? 0);
                if (!isset($byId[$uid])) { continue; }
                if (!isset($latest[$uid])) { $latest[$uid] = []; }
                if (count($latest[$uid]) >= 3) { continue; }
                $type = (string)($r['post_type'] ?? '');
                $file = (string)($r['post_file'] ?? '');
                if ($type === 'image') {
                    $src = $this->RL_ProfileFirstImage($file);
                    if ($src === '') { continue; }
                    $latest[$uid][] = [
                        'post_id' => (int)($r['post_id'] ?? 0),
                        'post_type' => 'image',
                        'media_thumb' => $src, // relative, creators.php prefixes baseUrl
                    ];
                } else {
                    $latest[$uid][] = [
                        'post_id' => (int)($r['post_id'] ?? 0),
                        'post_type' => 'video',
                        'media_thumb' => $file, // relative video path; creators.php will call videoThumbNail
                    ];
                }
            }
        } catch (\Throwable $e) { /* ignore */ }

        // Apply latest_posts to users
        foreach ($byId as $uid => &$u) {
            $u['posts_count']     = (int)($u['posts_count']     ?? 0);
            $u['followers_count'] = (int)($u['followers_count'] ?? 0);
            $u['following_count'] = (int)($u['following_count'] ?? 0);
            $u['latest_posts']    = array_values($latest[$uid] ?? []);
        }
        unset($u);

        return array_values($byId);
    }
}
