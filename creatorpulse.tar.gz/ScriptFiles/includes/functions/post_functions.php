<?php
declare(strict_types=1);
trait PostFunctions {
    /** Holds last PDO error message from post insert helpers. */
    private ?string $rlLastPostSqlError = null;
    /** Cached column map for i_user_posts. */
    private ?array $rlUserPostsColumns = null;

    private function RL_EnsurePodcastCategoriesTable(): void
    {
        static $ensured = false;
        if ($ensured) { return; }
        $ensured = true;

        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_podcast_categories (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                name VARCHAR(120) NOT NULL,
                slug VARCHAR(160) NOT NULL,
                status ENUM('active','inactive') NOT NULL DEFAULT 'active',
                sort_order INT NOT NULL DEFAULT 0,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_slug (slug),
                KEY idx_status_sort (status, sort_order),
                KEY idx_sort (sort_order)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

            $this->db->exec("CREATE TABLE IF NOT EXISTS i_podcast_category_translations (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                category_id INT UNSIGNED NOT NULL,
                language VARCHAR(16) NOT NULL,
                name VARCHAR(120) NOT NULL,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_cat_lang (category_id, language),
                KEY idx_cat (category_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
        } catch (\Throwable $__) {}
    }

    private function RL_EnsurePostMediaTable(): void
    {
        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_post_media (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                post_id INT UNSIGNED NOT NULL,
                path VARCHAR(255) NOT NULL,
                role VARCHAR(32) NULL,
                storage VARCHAR(32) NOT NULL DEFAULT 'local',
                created_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq (post_id, path),
                KEY idx_post (post_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;");
        } catch (\Throwable $__) {}
    }

    /** Expose last PDO error captured by RL insert helpers (debugging). */
    public function RL_GetLastPostSqlError(): ?string
    {
        return $this->rlLastPostSqlError;
    }

    private function RL_GetUserPostsColumns(): array
    {
        if (is_array($this->rlUserPostsColumns)) {
            return $this->rlUserPostsColumns;
        }

        $columns = [];
        try {
            $stmt = $this->db->query('SHOW COLUMNS FROM i_user_posts');
            if ($stmt) {
                while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                    if (!is_array($row) || !isset($row['Field'])) {
                        continue;
                    }
                    $columns[$row['Field']] = $row;
                }
            }
        } catch (\Throwable $__) {
            $columns = [];
        }

        $this->rlUserPostsColumns = $columns;
        return $columns;
    }

    private function RL_ResetUserPostsColumnsCache(): void
    {
        $this->rlUserPostsColumns = null;
    }

    private function RL_EnsureHashtagTables(): void
    {
        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_hashtags (
                hashtag_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                tag VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                display_tag VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                use_count INT UNSIGNED NOT NULL DEFAULT 0,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED DEFAULT NULL,
                PRIMARY KEY (hashtag_id),
                UNIQUE KEY uniq_tag (tag),
                KEY idx_use_count (use_count)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

            $this->db->exec("CREATE TABLE IF NOT EXISTS i_post_hashtags (
                post_id INT NOT NULL,
                hashtag_id INT UNSIGNED NOT NULL,
                created_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (post_id, hashtag_id),
                KEY idx_hashtag (hashtag_id),
                KEY idx_post (post_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
        } catch (\Throwable $__) {}
    }

    public function RL_NormalizeHashtag(string $tag): string
    {
        $tag = trim($tag);
        $tag = ltrim($tag, '#');
        $tag = preg_replace('/[^\p{L}\p{N}_]+/u', '', $tag) ?? '';
        if (function_exists('mb_strtolower')) {
            $tag = mb_strtolower($tag, 'UTF-8');
        } else {
            $tag = strtolower($tag);
        }
        return function_exists('mb_substr') ? mb_substr($tag, 0, 80, 'UTF-8') : substr($tag, 0, 80);
    }

    public function RL_ExtractHashtags(string $text): array
    {
        if ($text === '') {
            return [];
        }
        if (!preg_match_all('/(?<![\p{L}\p{N}_])#([\p{L}\p{N}_]{1,80})/u', $text, $matches)) {
            return [];
        }
        $tags = [];
        foreach (($matches[1] ?? []) as $rawTag) {
            $normalized = $this->RL_NormalizeHashtag((string) $rawTag);
            if ($normalized === '') {
                continue;
            }
            $tags[$normalized] = (string) $rawTag;
        }
        return $tags;
    }

    public function RL_SavePostHashtags(int $postId, string $postText, ?string $postTitle = null): void
    {
        if ($postId <= 0) {
            return;
        }
        $this->RL_EnsureHashtagTables();
        $tags = $this->RL_ExtractHashtags(trim((string) $postTitle . ' ' . $postText));
        try {
            $oldIds = [];
            $oldStmt = $this->db->prepare('SELECT hashtag_id FROM i_post_hashtags WHERE post_id = :post_id');
            $oldStmt->bindValue(':post_id', $postId, \PDO::PARAM_INT);
            $oldStmt->execute();
            while ($row = $oldStmt->fetch(\PDO::FETCH_ASSOC)) {
                $oldIds[] = (int) ($row['hashtag_id'] ?? 0);
            }

            $this->db->prepare('DELETE FROM i_post_hashtags WHERE post_id = :post_id')->execute([':post_id' => $postId]);
            $affectedIds = $oldIds;
            $now = time();

            if (!empty($tags)) {
                $upsert = $this->db->prepare("
                    INSERT INTO i_hashtags (tag, display_tag, use_count, created_at, updated_at)
                    VALUES (:tag, :display_tag, 0, :created_at, :updated_at)
                    ON DUPLICATE KEY UPDATE display_tag = VALUES(display_tag), updated_at = VALUES(updated_at)
                ");
                $select = $this->db->prepare('SELECT hashtag_id FROM i_hashtags WHERE tag = :tag LIMIT 1');
                $map = $this->db->prepare('INSERT IGNORE INTO i_post_hashtags (post_id, hashtag_id, created_at) VALUES (:post_id, :hashtag_id, :created_at)');

                foreach ($tags as $tag => $displayTag) {
                    $upsert->execute([
                        ':tag' => $tag,
                        ':display_tag' => $displayTag,
                        ':created_at' => $now,
                        ':updated_at' => $now,
                    ]);
                    $select->execute([':tag' => $tag]);
                    $hashtagId = (int) ($select->fetchColumn() ?: 0);
                    if ($hashtagId <= 0) {
                        continue;
                    }
                    $map->execute([
                        ':post_id' => $postId,
                        ':hashtag_id' => $hashtagId,
                        ':created_at' => $now,
                    ]);
                    $affectedIds[] = $hashtagId;
                }
            }

            $affectedIds = array_values(array_unique(array_filter(array_map('intval', $affectedIds))));
            if (!empty($affectedIds)) {
                $recount = $this->db->prepare('UPDATE i_hashtags SET use_count = (SELECT COUNT(*) FROM i_post_hashtags WHERE i_post_hashtags.hashtag_id = i_hashtags.hashtag_id), updated_at = :updated_at WHERE hashtag_id = :hashtag_id');
                foreach ($affectedIds as $hashtagId) {
                    $recount->execute([':updated_at' => $now, ':hashtag_id' => $hashtagId]);
                }
            }
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_SavePostHashtags failed: ' . $e->getMessage());
            }
        }
    }

    /**
     * Ensure i_user_posts schema has required columns/keys for new insert flows.
     * Runs once per request to avoid repeated ALTER TABLE checks.
     */
    private function RL_EnsureUserPostsSchema(): void
    {
        static $ensured = false;
        if ($ensured) { return; }
        $ensured = true;

        $this->RL_EnsurePodcastCategoriesTable();

        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_user_posts (
                post_id INT NOT NULL AUTO_INCREMENT,
                post_owner_id INT DEFAULT NULL,
                post_title VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                post_type ENUM('image','video','podcast') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'video',
                post_file LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
                audio_duration_seconds INT UNSIGNED NULL,
                podcast_category_id INT UNSIGNED NULL,
                post_text LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
                post_visibility ENUM('everyone','followers','subscribers','locked') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'everyone',
                post_price VARCHAR(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                comment_status ENUM('on','off') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'on',
                like_status ENUM('on','off') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'on',
                post_created_time INT DEFAULT NULL,
                post_views INT NOT NULL DEFAULT 0,
                PRIMARY KEY (post_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
        } catch (\Throwable $__) {
            return;
        }

        try {
            $columns = [];
            $stmt = $this->db->query('SHOW COLUMNS FROM i_user_posts');
            if ($stmt) {
                while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                    if (!is_array($row) || !isset($row['Field'])) { continue; }
                    $columns[$row['Field']] = $row;
                }
            }

            $addColumn = function(string $sql): void {
                try { $this->db->exec($sql); } catch (\Throwable $__) {}
            };

            if (!isset($columns['post_type'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN post_type ENUM('image','video','podcast') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'video'");
            } else {
                $col = $columns['post_type'];
                $type = strtolower((string)($col['Type'] ?? ''));
                if (strpos($type, "enum('image','video','podcast')") === false) {
                    $addColumn("ALTER TABLE i_user_posts MODIFY post_type ENUM('image','video','podcast') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'video'");
                }
            }
            if (!isset($columns['post_title'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN post_title VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL AFTER post_owner_id");
                $this->RL_ResetUserPostsColumnsCache();
            }
            if (!isset($columns['post_visibility'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN post_visibility ENUM('everyone','followers','subscribers','locked') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'everyone'");
            }
            if (!isset($columns['post_price'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN post_price VARCHAR(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL");
            }
            if (!isset($columns['comment_status'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN comment_status ENUM('on','off') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'on'");
            } else {
                $col = $columns['comment_status'];
                $type = strtolower((string)($col['Type'] ?? ''));
                $default = (string)($col['Default'] ?? '');
                if (strpos($type, "enum('on','off')") === false || ($default !== 'on' && $default !== 'off')) {
                    $addColumn("ALTER TABLE i_user_posts MODIFY comment_status ENUM('on','off') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'on'");
                }
            }
            if (!isset($columns['like_status'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN like_status ENUM('on','off') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'on'");
            } else {
                $col = $columns['like_status'];
                $type = strtolower((string)($col['Type'] ?? ''));
                $default = (string)($col['Default'] ?? '');
                if (strpos($type, "enum('on','off')") === false || ($default !== 'on' && $default !== 'off')) {
                    $addColumn("ALTER TABLE i_user_posts MODIFY like_status ENUM('on','off') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'on'");
                }
            }
            if (!isset($columns['locked_preview_path'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN locked_preview_path VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL AFTER post_file");
            }
            if (!isset($columns['locked_preview_type'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN locked_preview_type ENUM('static','animated') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL AFTER locked_preview_path");
            }
            if (!isset($columns['audio_duration_seconds'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN audio_duration_seconds INT UNSIGNED NULL AFTER post_file");
            }
            if (!isset($columns['podcast_category_id'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN podcast_category_id INT UNSIGNED NULL AFTER audio_duration_seconds");
            }
            if (!isset($columns['approval_status'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN approval_status ENUM('pending','approved','rejected') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'approved' AFTER like_status");
            } else {
                $col = $columns['approval_status'];
                $type = strtolower((string)($col['Type'] ?? ''));
                $default = strtolower((string)($col['Default'] ?? ''));
                if (strpos($type, "enum('pending','approved','rejected')") === false || ($default !== 'approved' && $default !== 'pending' && $default !== 'rejected')) {
                    $addColumn("ALTER TABLE i_user_posts MODIFY approval_status ENUM('pending','approved','rejected') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'approved'");
                }
            }
            if (!isset($columns['approval_notes'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN approval_notes TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL AFTER approval_status");
            }
            if (!isset($columns['approved_at'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN approved_at INT NULL AFTER approval_notes");
            }
            if (!isset($columns['approved_by'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN approved_by INT NULL AFTER approved_at");
            }
            try { $this->db->exec("ALTER TABLE i_user_posts ADD INDEX idx_approval_status (approval_status, post_created_time)"); } catch (\Throwable $__) {}
            try { $this->db->exec("ALTER TABLE i_user_posts ADD INDEX idx_type_created (post_type, post_created_time)"); } catch (\Throwable $__) {}
            try { $this->db->exec("ALTER TABLE i_user_posts ADD INDEX idx_podcast_category (podcast_category_id)"); } catch (\Throwable $__) {}
            try { $this->db->exec("ALTER TABLE i_user_posts ADD INDEX idx_post_title (post_title)"); } catch (\Throwable $__) {}
            if (!isset($columns['post_created_time'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN post_created_time INT DEFAULT NULL");
            } else {
                $col = $columns['post_created_time'];
                $type = strtolower((string)($col['Type'] ?? ''));
                if (strpos($type, 'int') === false) {
                    $addColumn("ALTER TABLE i_user_posts MODIFY post_created_time INT DEFAULT NULL");
                }
            }
            if (!isset($columns['post_views'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN post_views INT NOT NULL DEFAULT 0");
            } else {
                $col = $columns['post_views'];
                $type = strtolower((string)($col['Type'] ?? ''));
                $default = $col['Default'] ?? null;
                $nullFlag = strtoupper((string)($col['Null'] ?? ''));
                $needsFix = (strpos($type, 'int') === false) || ($nullFlag === 'NO' && ($default === null || $default === ''));
                if ($needsFix) {
                    $addColumn("ALTER TABLE i_user_posts MODIFY post_views INT NOT NULL DEFAULT 0");
                }
            }
            if (!isset($columns['post_id'])) {
                $addColumn("ALTER TABLE i_user_posts ADD COLUMN post_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST");
            } else {
                $extra = strtolower((string) ($columns['post_id']['Extra'] ?? ''));
                if (strpos($extra, 'auto_increment') === false) {
                    $columnType = strtolower((string)($columns['post_id']['Type'] ?? 'int'));
                    $isUnsigned = strpos($columnType, 'unsigned') !== false;
                    $definition = $isUnsigned ? 'INT UNSIGNED NOT NULL AUTO_INCREMENT' : 'INT NOT NULL AUTO_INCREMENT';
                    $addColumn("ALTER TABLE i_user_posts MODIFY post_id {$definition}");
                }
            }

            try {
                $idx = $this->db->query("SHOW INDEX FROM i_user_posts WHERE Key_name = 'PRIMARY'");
                $hasPrimary = $idx && $idx->fetch();
                if (!$hasPrimary) {
                    $this->db->exec('ALTER TABLE i_user_posts ADD PRIMARY KEY (post_id)');
                }
            } catch (\Throwable $__) {}
        } catch (\Throwable $__) {
            // Swallow schema introspection issues silently.
        }
        $this->RL_EnsureHashtagTables();
    }

    public function RL_GetPodcastCategoryById(int $id, ?string $lang = null): ?array
    {
        if ($id <= 0) { return null; }
        $this->RL_EnsurePodcastCategoriesTable();
        try {
            $langNormalized = null;
            if ($lang === null && isset($GLOBALS['currentLang']) && is_string($GLOBALS['currentLang'])) {
                $lang = $GLOBALS['currentLang'];
            }
            if ($lang !== null) {
                $langNormalized = strtolower(trim((string) $lang));
                if ($langNormalized === '') {
                    $langNormalized = null;
                }
            }

            $sql = 'SELECT pc.id,
                           COALESCE(pct_lang.name, pc.name) AS name,
                           pc.slug,
                           pc.status,
                           pc.sort_order,
                           pc.created_at,
                           pc.updated_at
                    FROM i_podcast_categories pc';
            if ($langNormalized) {
                $sql .= ' LEFT JOIN i_podcast_category_translations AS pct_lang
                          ON pct_lang.category_id = pc.id AND pct_lang.language = :lang';
            }
            $sql .= ' WHERE pc.id = :id LIMIT 1';

            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':id', $id, \PDO::PARAM_INT);
            if ($langNormalized) {
                $stmt->bindValue(':lang', $langNormalized, \PDO::PARAM_STR);
            }
            $stmt->execute();
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            return $row !== false ? $row : null;
        } catch (\Throwable $__) {
            return null;
        }
    }

    public function RL_GetPodcastCategoryBySlug(string $slug, ?string $lang = null): ?array
    {
        $slug = trim(strtolower($slug));
        if ($slug === '') { return null; }
        $this->RL_EnsurePodcastCategoriesTable();
        try {
            $langNormalized = null;
            if ($lang === null && isset($GLOBALS['currentLang']) && is_string($GLOBALS['currentLang'])) {
                $lang = $GLOBALS['currentLang'];
            }
            if ($lang !== null) {
                $langNormalized = strtolower(trim((string) $lang));
                if ($langNormalized === '') {
                    $langNormalized = null;
                }
            }

            $sql = 'SELECT pc.id,
                           COALESCE(pct_lang.name, pc.name) AS name,
                           pc.slug,
                           pc.status,
                           pc.sort_order,
                           pc.created_at,
                           pc.updated_at
                    FROM i_podcast_categories pc';
            if ($langNormalized) {
                $sql .= ' LEFT JOIN i_podcast_category_translations AS pct_lang
                          ON pct_lang.category_id = pc.id AND pct_lang.language = :lang';
            }
            $sql .= ' WHERE pc.slug = :slug LIMIT 1';

            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':slug', $slug, \PDO::PARAM_STR);
            if ($langNormalized) {
                $stmt->bindValue(':lang', $langNormalized, \PDO::PARAM_STR);
            }
            $stmt->execute();
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            return $row !== false ? $row : null;
        } catch (\Throwable $__) {
            return null;
        }
    }

    public function RL_GetPodcastCategories(?string $status = null, ?string $lang = null, array $includeTranslationsFor = []): array
    {
        $this->RL_EnsurePodcastCategoriesTable();
        $langNormalized = null;
        if ($lang === null && isset($GLOBALS['currentLang']) && is_string($GLOBALS['currentLang'])) {
            $lang = $GLOBALS['currentLang'];
        }
        if ($lang !== null) {
            $langNormalized = strtolower(trim((string) $lang));
            if ($langNormalized === '') {
                $langNormalized = null;
            }
        }
        $allowedStatus = ['active', 'inactive'];
        $where = [];
        $params = [];
        if ($status !== null) {
            $normalized = strtolower(trim($status));
            if (in_array($normalized, $allowedStatus, true)) {
                $where[] = 'status = :status';
                $params[':status'] = $normalized;
            }
        }

        try {
            $sql = 'SELECT pc.id,
                           COALESCE(pct_lang.name, pc.name) AS name,
                           pc.slug,
                           pc.status,
                           pc.sort_order,
                           pc.created_at,
                           pc.updated_at
                    FROM i_podcast_categories pc';
            if ($langNormalized) {
                $sql .= ' LEFT JOIN i_podcast_category_translations AS pct_lang
                          ON pct_lang.category_id = pc.id AND pct_lang.language = :lang';
            }
            if ($where) {
                $sql .= ' WHERE ' . implode(' AND ', $where);
            }
            $sql .= ' ORDER BY sort_order ASC, name ASC, id ASC';

            $stmt = $this->db->prepare($sql);
            foreach ($params as $k => $v) {
                $stmt->bindValue($k, $v, is_int($v) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
            }
            if ($langNormalized) {
                $stmt->bindValue(':lang', $langNormalized, \PDO::PARAM_STR);
            }
            $stmt->execute();
            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            if (!$rows) {
                return [];
            }

            $results = $rows;

            $langList = array_values(array_unique(array_filter(array_map(static function ($entry) {
                return strtolower(trim((string) $entry));
            }, $includeTranslationsFor))));

            if ($langList) {
                $categoryIds = array_map(static function ($row) {
                    return (int) ($row['id'] ?? 0);
                }, $rows);
                $categoryIds = array_values(array_filter(array_unique($categoryIds), static function ($v) {
                    return $v > 0;
                }));

                if ($categoryIds) {
                    $placeholdersCat = implode(',', array_fill(0, count($categoryIds), '?'));
                    $placeholdersLang = implode(',', array_fill(0, count($langList), '?'));
                    $sqlTrans = 'SELECT category_id, language, name
                                 FROM i_podcast_category_translations
                                 WHERE category_id IN (' . $placeholdersCat . ')';
                    if ($langList) {
                        $sqlTrans .= ' AND language IN (' . $placeholdersLang . ')';
                    }

                    $stmtTrans = $this->db->prepare($sqlTrans);
                    $bindValues = array_merge($categoryIds, $langList);
                    foreach ($bindValues as $idx => $val) {
                        $stmtTrans->bindValue($idx + 1, $val, is_int($val) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
                    }
                    $stmtTrans->execute();
                    $translations = [];
                    while ($row = $stmtTrans->fetch(\PDO::FETCH_ASSOC)) {
                        if (!isset($row['category_id'], $row['language'])) {
                            continue;
                        }
                        $cid = (int) $row['category_id'];
                        $lng = strtolower(trim((string) $row['language']));
                        if ($cid <= 0 || $lng === '') {
                            continue;
                        }
                        $translations[$cid][$lng] = (string) ($row['name'] ?? '');
                    }

                    foreach ($results as &$cat) {
                        $cid = (int) ($cat['id'] ?? 0);
                        $cat['translations'] = $translations[$cid] ?? [];
                    }
                    unset($cat);
                }
            }

            return $results;
        } catch (\Throwable $__) {
            return [];
        }
    }

    public function RL_AddPostMedia(int $postId, string $path, ?string $role = null, string $storage = 'local'): bool
    {
        if ($postId <= 0 || trim($path) === '') { return false; }
        $this->RL_EnsurePostMediaTable();
        try {
            $st = $this->db->prepare('INSERT IGNORE INTO i_post_media (post_id, path, role, storage, created_at) VALUES (:p,:path,:r,:s,:t)');
            return $st->execute([':p'=>$postId, ':path'=>ltrim($path,'/'), ':r'=>$role, ':s'=>$storage, ':t'=>time()]);
        } catch (\Throwable $__) { return false; }
    }

    public function RL_AddPostMediaMany(int $postId, array $paths, ?string $role = null, string $storage = 'local'): int
    {
        $ok = 0;
        foreach ($paths as $p) { if ($this->RL_AddPostMedia($postId, (string)$p, $role, $storage)) { $ok++; } }
        return $ok;
    }
    private function RL_EnsurePostReportsTable(): void
    {
        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_post_reports (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                post_id INT UNSIGNED NOT NULL,
                reporter_id INT UNSIGNED NOT NULL,
                reason VARCHAR(255) NULL,
                created_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq (post_id, reporter_id),
                KEY idx_post (post_id),
                KEY idx_user (reporter_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;");
        } catch (\Throwable $__) {}
    }

    /**
     * Toggle report for a post by a user. Returns ['reported' => bool]
     */
    public function RL_TogglePostReport(int $postId, int $reporterId, ?string $reason = null, ?int $now = null): array
    {
        $now = (int) ($now ?? time());
        if ($postId <= 0 || $reporterId <= 0) { return ['reported' => false]; }
        $this->RL_EnsurePostReportsTable();
        try {
            $sel = $this->db->prepare('SELECT id FROM i_post_reports WHERE post_id = :p AND reporter_id = :u LIMIT 1');
            $sel->execute([':p' => $postId, ':u' => $reporterId]);
            $rowId = (int) ($sel->fetchColumn() ?: 0);
            if ($rowId > 0) {
                $del = $this->db->prepare('DELETE FROM i_post_reports WHERE id = :id');
                $del->execute([':id' => $rowId]);
                return ['reported' => false];
            }
            $ins = $this->db->prepare('INSERT INTO i_post_reports (post_id, reporter_id, reason, created_at) VALUES (:p, :u, :r, :t)');
            $ins->execute([':p' => $postId, ':u' => $reporterId, ':r' => ($reason !== '' ? $reason : null), ':t' => $now]);
            return ['reported' => true];
        } catch (\Throwable $__) { return ['reported' => false]; }
    }
    public function RL_UpdatePostVisibility(int $postId, string $visibility): bool
    {
        $allowed = ['everyone','followers','subscribers','locked'];
        if (!in_array($visibility, $allowed, true)) { return false; }
        try {
            $up = $this->db->prepare('UPDATE i_user_posts SET post_visibility = :v WHERE post_id = :p LIMIT 1');
            return $up->execute([':v'=>$visibility, ':p'=>$postId]);
        } catch (\Throwable $__) { return false; }
    }

    public function RL_UpdatePostPriceAndLock(int $postId, int $price): bool
    {
        try {
            $up = $this->db->prepare("UPDATE i_user_posts SET post_price = :pr, post_visibility = 'locked' WHERE post_id = :p LIMIT 1");
            return $up->execute([':pr'=>$price, ':p'=>$postId]);
        } catch (\Throwable $__) { return false; }
    }

    public function RL_UpdatePostText(int $postId, string $text): bool
    {
        try {
            $up = $this->db->prepare('UPDATE i_user_posts SET post_text = :t WHERE post_id = :p LIMIT 1');
            return $up->execute([':t'=>$text, ':p'=>$postId]);
        } catch (\Throwable $__) { return false; }
    }

    public function RL_TogglePostCommentStatus(int $postId, string $status): bool
    {
        $status = $status === 'on' ? 'on' : 'off';
        try {
            $st = $this->db->prepare('UPDATE i_user_posts SET comment_status = :s WHERE post_id = :p LIMIT 1');
            return $st->execute([':s'=>$status, ':p'=>$postId]);
        } catch (\Throwable $__) { return false; }
    }

    public function RL_TogglePostLikeStatus(int $postId, string $status): bool
    {
        $status = $status === 'off' ? 'off' : 'on';
        try {
            $st = $this->db->prepare('UPDATE i_user_posts SET like_status = :s WHERE post_id = :p LIMIT 1');
            return $st->execute([':s'=>$status, ':p'=>$postId]);
        } catch (\Throwable $__) { return false; }
    }

    /** Clear post price (set to 0) without changing visibility */
    public function RL_ClearPostPrice(int $postId): bool
    {
        try {
            $up = $this->db->prepare('UPDATE i_user_posts SET post_price = 0 WHERE post_id = :p LIMIT 1');
            return $up->execute([':p'=>$postId]);
        } catch (\Throwable $__) { return false; }
    }

    /** Delete a single media path from a post (removes file + DB refs). */
    public function RL_DeletePostMediaPath(int $postId, string $path): bool
    {
        $path = ltrim((string)$path, '/');
        if ($postId <= 0 || $path === '') { return false; }
        try {
            // Remove from i_post_media (if present)
            try {
                $st = $this->db->prepare('DELETE FROM i_post_media WHERE post_id = :p AND path = :path');
                $st->execute([':p'=>$postId, ':path'=>$path]);
            } catch (\Throwable $__) {}

            // If image/video stored in i_user_posts.post_file, update accordingly
            try {
                $sel = $this->db->prepare('SELECT post_type, post_file FROM i_user_posts WHERE post_id = :p LIMIT 1');
                $sel->execute([':p'=>$postId]);
                $row = $sel->fetch(\PDO::FETCH_ASSOC) ?: [];
                $ptype = (string)($row['post_type'] ?? '');
                if ($ptype === 'image') {
                    $files = array_filter(array_map('trim', explode(',', (string)($row['post_file'] ?? ''))));
                    $files2 = [];
                    foreach ($files as $f) { $f = ltrim($f, '/'); if ($f !== $path) { $files2[] = $f; } }
                    $new = implode(',', $files2);
                    $up = $this->db->prepare('UPDATE i_user_posts SET post_file = :f WHERE post_id = :p LIMIT 1');
                    $up->execute([':f'=>$new, ':p'=>$postId]);
                } elseif ($ptype === 'video') {
                    $curr = ltrim((string)($row['post_file'] ?? ''), '/');
                    if ($curr === $path) {
                        $up = $this->db->prepare("UPDATE i_user_posts SET post_file = '' WHERE post_id = :p LIMIT 1");
                        $up->execute([':p'=>$postId]);
                    }
                }
            } catch (\Throwable $__) {}

            // Delete physical file under project root (and parent docroot) if exists (safe)
            try {
                $root = realpath(__DIR__ . '/..'); // ReelsProject root
                $safeRel = ltrim(str_replace(['..\\','../','\\'], ['','','/'], $path), '/');
                $candidates = [];
                if ($root) { $candidates[] = rtrim($root, '/') . '/' . $safeRel; }
                $altRoot = $root ? realpath($root . '/..') : null; // e.g., docroot when app in subfolder
                if ($altRoot) { $candidates[] = rtrim($altRoot, '/') . '/' . $safeRel; }

                foreach ($candidates as $cand) {
                    $rp = @realpath($cand) ?: $cand;
                    $base = $root;
                    if ($base && strpos($rp, $base) === 0 && @is_file($rp)) { @unlink($rp); break; }
                    if ($altRoot && strpos($rp, $altRoot) === 0 && @is_file($rp)) { @unlink($rp); break; }
                }
            } catch (\Throwable $__) {}

            return true;
        } catch (\Throwable $__) {
            return false;
        }
    }

    /** Reorder image media paths in post_file according to provided order. */
    public function RL_ReorderImageMedia(int $postId, array $order): bool
    {
        try {
            $sel = $this->db->prepare('SELECT post_type, post_file FROM i_user_posts WHERE post_id = :p LIMIT 1');
            $sel->execute([':p'=>$postId]);
            $row = $sel->fetch(\PDO::FETCH_ASSOC) ?: [];
            if ((string)($row['post_type'] ?? '') !== 'image') { return false; }
            $files = array_filter(array_map('trim', explode(',', (string)($row['post_file'] ?? ''))));
            // Normalize provided order to existing items (relative paths)
            $want = [];
            $set = [];
            foreach ($order as $p) { $p = ltrim((string)$p, '/'); if ($p!=='' && in_array($p, $files, true) && !isset($set[$p])) { $want[] = $p; $set[$p]=true; } }
            // Append any leftovers not present in provided order
            foreach ($files as $p) { $p = ltrim($p,'/'); if (!isset($set[$p])) { $want[] = $p; } }
            $new = implode(',', $want);
            $up = $this->db->prepare('UPDATE i_user_posts SET post_file = :f WHERE post_id = :p LIMIT 1');
            return $up->execute([':f'=>$new, ':p'=>$postId]);
        } catch (\Throwable $__) { return false; }
    }

    public function RL_GetPostMediaPaths(int $postId): array
    {
        try {
            $st = $this->db->prepare('SELECT path FROM i_post_media WHERE post_id = :p');
            $st->execute([':p'=>$postId]);
            return $st->fetchAll(\PDO::FETCH_COLUMN) ?: [];
        } catch (\Throwable $__) { return []; }
    }

    /** Fetch the first cover media path for a post (role = cover). */
    public function RL_GetPostCoverPath(int $postId): string
    {
        if ($postId <= 0) { return ''; }
        try {
            $st = $this->db->prepare('SELECT path FROM i_post_media WHERE post_id = :p AND role = :r ORDER BY id ASC LIMIT 1');
            $st->execute([':p' => $postId, ':r' => 'cover']);
            $path = (string) ($st->fetchColumn() ?: '');
            return ltrim($path, '/');
        } catch (\Throwable $__) {
            return '';
        }
    }

    /** Fetch the first teaser media path for a post (role = teaser). */
    public function RL_GetPostTeaserPath(int $postId): string
    {
        if ($postId <= 0) { return ''; }
        try {
            $st = $this->db->prepare('SELECT path FROM i_post_media WHERE post_id = :p AND role = :r ORDER BY id ASC LIMIT 1');
            $st->execute([':p' => $postId, ':r' => 'teaser']);
            $path = (string) ($st->fetchColumn() ?: '');
            return ltrim($path, '/');
        } catch (\Throwable $__) {
            return '';
        }
    }

    public function RL_DeletePostCascade(int $postId, string $postType = 'image'): bool
    {
        try {
            $this->db->beginTransaction();
            $this->db->prepare('DELETE FROM i_comments WHERE item_id = :p')->execute([':p'=>$postId]);
            $this->db->prepare('DELETE FROM i_comment_liked WHERE c_liked_post_id = :p')->execute([':p'=>$postId]);
            $this->db->prepare("DELETE FROM i_post_liked WHERE liked_item_id = :p AND liked_item_type = 'post'")->execute([':p'=>$postId]);
            $this->db->prepare('DELETE FROM i_bookmarks WHERE item_id = :p AND item_type = :t')->execute([':p'=>$postId, ':t'=>$postType]);
            $this->db->prepare('DELETE FROM i_post_reports WHERE post_id = :p')->execute([':p'=>$postId]);
            $this->db->prepare('DELETE FROM i_post_media WHERE post_id = :p')->execute([':p'=>$postId]);
            $this->db->prepare('DELETE FROM i_user_posts WHERE post_id = :p LIMIT 1')->execute([':p'=>$postId]);
            $this->db->commit();
            return true;
        } catch (\Throwable $__) {
            if ($this->db->inTransaction()) { $this->db->rollBack(); }
            return false;
        }
    }
    /**
     * Purchased Premium Feed for a viewer.
     * Returns posts the viewer has unlocked (status='succeeded') via i_post_purchases.
     * Shaped like RL_FeedRelatedVisible() so post_view.php can render it.
     */
    public function RL_GetPurchasedPremiumFeed(int $userID, int $limit = 20, int $offset = 0): array
    {
        try {
            if ($userID <= 0) { return []; }
            $limit  = max(1, (int)$limit);
            $offset = max(0, (int)$offset);

            $sql = "
                SELECT
                    p.post_id,
                    p.post_owner_id,
                    p.post_type,
                    p.post_file,
                    p.audio_duration_seconds,
                    p.locked_preview_path,
                    p.locked_preview_type,
                    p.post_text,
                    p.post_visibility,
                    p.post_price,
                    p.comment_status,
                    p.like_status,
                    p.approval_status,
                    p.approval_notes,
                    p.approved_at,
                    p.approved_by,
                    p.post_created_time,

                    u.user_id         AS owner_id,
                    u.username        AS owner_username,
                    u.user_fullname   AS owner_fullname,
                    u.user_avatar     AS owner_avatar,
                    u.verified_status AS owner_verified,

                    rel_v2o.fr_status AS viewer_to_owner_status,
                    pp.latest_time    AS purchased_at
                FROM (
                    SELECT post_id, MAX(created_at) AS latest_time
                    FROM i_post_purchases
                    WHERE buyer_id = :uid AND status = 'succeeded'
                    GROUP BY post_id
                ) pp
                INNER JOIN i_user_posts p ON p.post_id = pp.post_id
                INNER JOIN i_users u      ON u.user_id = p.post_owner_id
                LEFT JOIN (
                    SELECT fr_two AS other_id,
                           SUBSTRING_INDEX(
                             GROUP_CONCAT(fr_status ORDER BY FIELD(fr_status,'subscriber','flwr','me') DESC SEPARATOR ','),
                             ',', 1
                           ) AS fr_status
                    FROM i_friends
                    WHERE fr_one = :uid_v2o
                    GROUP BY fr_two
                ) AS rel_v2o
                  ON rel_v2o.other_id = p.post_owner_id
                WHERE p.post_visibility = 'locked'
                ORDER BY pp.latest_time DESC
                LIMIT $offset, $limit
            ";

            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $userID, \PDO::PARAM_INT);
            $st->bindValue(':uid_v2o', $userID, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            $out = [];
            foreach ($rows as $row) {
                $ownerId = (int)$row['post_owner_id'];
                $out[] = [
                    'post_id'           => (int)$row['post_id'],
                    'post_owner_id'     => $ownerId,
                    'post_type'         => (string)$row['post_type'],
                    'post_file'         => (string)$row['post_file'],
                    'post_text'         => (string)$row['post_text'],
                    'post_visibility'   => (string)$row['post_visibility'],
                    'post_price'        => $row['post_price'] !== null ? (string)$row['post_price'] : null,
                    'comment_status'    => (string)$row['comment_status'],
                    'like_status'       => (string)$row['like_status'],
                    'post_created_time' => (int)$row['post_created_time'],

                    'owner_id'          => (int)$row['owner_id'],
                    'owner_username'    => (string)$row['owner_username'],
                    'owner_fullname'    => (string)$row['owner_fullname'],
                    'owner_avatar'      => (string)$row['owner_avatar'],
                    'owner_verified'    => (int)$row['owner_verified'],

                    'viewer_to_owner_status' => $row['viewer_to_owner_status'] !== null ? (string)$row['viewer_to_owner_status'] : null,
                    'is_owner'          => ($userID > 0 && $userID === $ownerId),
                ];
            }
            return $out;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) { $this->logError('RL_GetPurchasedPremiumFeed failed: ' . $e->getMessage()); }
            return [];
        }
    }
    /**
     * Insert cropped image post into i_user_posts table
     *
     * @param int $userID         ID of the user who owns the post
     * @param string $files       Comma-separated file names (e.g., "1.png,2.jpg")
     * @param string $postType    Type of post ('image' or 'video')
     * @param int $createdTime    UNIX timestamp when post is created
     * @return bool               Returns true on success, false on failure
     */
    public function RL_InsertCroppedImage(
        int $userID,
        string $files,
        string $postType,
        int $createdTime,
        string $postText,
        string $whoCanSee,
        ?int $price,
        string $commentStatus,
        string $likeStatus,
        ?int $audioDurationSeconds = null,
        ?int $podcastCategoryId = null,
        ?string $lockedPreviewPath = null,
        ?string $lockedPreviewType = null,
        ?string $approvalStatus = 'approved',
        ?int $approvedBy = null,
        ?int $approvedAt = null,
        ?string $approvalNotes = null,
        ?string $postTitle = null
    ): bool {
        try {
            $this->rlLastPostSqlError = null;
            $this->RL_EnsureUserPostsSchema();
            $columns = $this->RL_GetUserPostsColumns();
            $lockedPreviewTypeValue = null;
            $lockedPreviewTypeParam = null;
            if (isset($columns['locked_preview_type'])) {
                $lockedTypeSchema = strtolower((string) ($columns['locked_preview_type']['Type'] ?? ''));
                $rawPreviewType = is_string($lockedPreviewType) ? strtolower(trim($lockedPreviewType)) : '';
                if ($rawPreviewType === 'static' || $rawPreviewType === 'animated') {
                    $isNumericEnum = (strpos($lockedTypeSchema, 'int') !== false)
                        || (preg_match("/enum\\('\\s*0\\s*'\\s*,\\s*'\\s*1\\s*'|enum\\('\\s*1\\s*'\\s*,\\s*'\\s*0\\s*'/", $lockedTypeSchema) === 1);
                    if ($isNumericEnum) {
                        $lockedPreviewTypeValue = $rawPreviewType === 'animated' ? 1 : 0;
                        $lockedPreviewTypeParam = PDO::PARAM_INT;
                    } else {
                        $lockedPreviewTypeValue = $rawPreviewType;
                        $lockedPreviewTypeParam = PDO::PARAM_STR;
                    }
                }
            }
            $cols = [
                'post_owner_id' => ':userID',
                'post_type' => ':postType',
                'post_file' => ':postFile',
                'post_created_time' => ':createdTime',
                'post_text' => ':postText',
                'post_visibility' => ':whoCanSee',
                'post_price' => ':price',
                'comment_status' => ':commentStatus',
                'like_status' => ':likeStatus',
            ];

            if (isset($columns['post_title'])) {
                $cols['post_title'] = ':postTitle';
            }
            if (isset($columns['audio_duration_seconds'])) {
                $cols['audio_duration_seconds'] = ':audioDurationSeconds';
            }
            if (isset($columns['podcast_category_id'])) {
                $cols['podcast_category_id'] = ':podcastCategoryId';
            }
            if (isset($columns['locked_preview_path'])) {
                $cols['locked_preview_path'] = ':lockedPreviewPath';
            }
            if (isset($columns['locked_preview_type']) && $lockedPreviewTypeValue !== null) {
                $cols['locked_preview_type'] = ':lockedPreviewType';
            }
            if (isset($columns['approval_status'])) {
                $cols['approval_status'] = ':approvalStatus';
            }
            if (isset($columns['approval_notes'])) {
                $cols['approval_notes'] = ':approvalNotes';
            }
            if (isset($columns['approved_at'])) {
                $cols['approved_at'] = ':approvedAt';
            }
            if (isset($columns['approved_by'])) {
                $cols['approved_by'] = ':approvedBy';
            }

            $sql = 'INSERT INTO i_user_posts (' . implode(', ', array_keys($cols)) . ') VALUES (' . implode(', ', array_values($cols)) . ')';
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':userID', $userID, PDO::PARAM_INT);
            $stmt->bindValue(':postType', $postType, PDO::PARAM_STR);
            $stmt->bindValue(':postFile', $files, PDO::PARAM_STR);
            $stmt->bindValue(':createdTime', $createdTime, PDO::PARAM_INT);

            $stmt->bindValue(':postText', $postText, PDO::PARAM_STR);
            if (isset($cols['post_title'])) {
                $cleanTitle = trim(strip_tags((string) ($postTitle ?? '')));
                if ($cleanTitle === '') {
                    $stmt->bindValue(':postTitle', null, PDO::PARAM_NULL);
                } else {
                    $stmt->bindValue(':postTitle', function_exists('mb_substr') ? mb_substr($cleanTitle, 0, 255, 'UTF-8') : substr($cleanTitle, 0, 255), PDO::PARAM_STR);
                }
            }
            $stmt->bindValue(':whoCanSee', $whoCanSee, PDO::PARAM_STR);

            if ($price === null) {
                $stmt->bindValue(':price', null, PDO::PARAM_NULL);
            } else {
                $stmt->bindValue(':price', $price, PDO::PARAM_INT);
            }

            $stmt->bindValue(':commentStatus', $commentStatus, PDO::PARAM_STR);
            $stmt->bindValue(':likeStatus', $likeStatus, PDO::PARAM_STR);
            if (isset($cols['audio_duration_seconds'])) {
                if ($audioDurationSeconds === null) {
                    $stmt->bindValue(':audioDurationSeconds', null, PDO::PARAM_NULL);
                } else {
                    $stmt->bindValue(':audioDurationSeconds', $audioDurationSeconds, PDO::PARAM_INT);
                }
            }
            if (isset($cols['podcast_category_id'])) {
                if ($podcastCategoryId === null || $podcastCategoryId <= 0) {
                    $stmt->bindValue(':podcastCategoryId', null, PDO::PARAM_NULL);
                } else {
                    $stmt->bindValue(':podcastCategoryId', $podcastCategoryId, PDO::PARAM_INT);
                }
            }
            if (isset($cols['locked_preview_path'])) {
                if ($lockedPreviewPath === null || $lockedPreviewPath === '') {
                    $stmt->bindValue(':lockedPreviewPath', null, PDO::PARAM_NULL);
                } else {
                    $stmt->bindValue(':lockedPreviewPath', $lockedPreviewPath, PDO::PARAM_STR);
                }
            }
            if (isset($cols['locked_preview_type']) && $lockedPreviewTypeValue !== null) {
                $stmt->bindValue(':lockedPreviewType', $lockedPreviewTypeValue, $lockedPreviewTypeParam ?? PDO::PARAM_STR);
            }
            if (isset($cols['approval_status'])) {
                $normalizedApproval = strtolower(trim((string) ($approvalStatus ?? 'approved')));
                if (!in_array($normalizedApproval, ['pending', 'approved', 'rejected'], true)) {
                    $normalizedApproval = 'approved';
                }
                $stmt->bindValue(':approvalStatus', $normalizedApproval, PDO::PARAM_STR);
            }
            if (isset($cols['approval_notes'])) {
                if ($approvalNotes === null || $approvalNotes === '') {
                    $stmt->bindValue(':approvalNotes', null, PDO::PARAM_NULL);
                } else {
                    $stmt->bindValue(':approvalNotes', $approvalNotes, PDO::PARAM_STR);
                }
            }
            if (isset($cols['approved_at'])) {
                if ($approvedAt === null) {
                    $stmt->bindValue(':approvedAt', null, PDO::PARAM_NULL);
                } else {
                    $stmt->bindValue(':approvedAt', (int)$approvedAt, PDO::PARAM_INT);
                }
            }
            if (isset($cols['approved_by'])) {
                if ($approvedBy === null) {
                    $stmt->bindValue(':approvedBy', null, PDO::PARAM_NULL);
                } else {
                    $stmt->bindValue(':approvedBy', (int)$approvedBy, PDO::PARAM_INT);
                }
            }

            $ok = $stmt->execute();
            if ($ok) {
                $postId = (int) $this->db->lastInsertId();
                if ($postId > 0) {
                    $this->RL_SavePostHashtags($postId, $postText, $postTitle);
                }
            }
            return $ok;
        } catch (PDOException $e) {
            $this->rlLastPostSqlError = $e->getMessage();
            if (function_exists('logErrorToFile')) {
                logErrorToFile('RL_InsertCroppedImage Hatası: ' . $e->getMessage());
            }
            return false;
        }
    }
    /**
     * Insert cropped image post into i_user_posts table
     *
     * @param int $userID         ID of the user who owns the post
     * @param string $files       Comma-separated file names (e.g., "1.png,2.jpg")
     * @param string $postType    Type of post ('image' or 'video')
     * @param int $createdTime    UNIX timestamp when post is created
     * @param string|null $lockedPreviewPath Relative path to the blurred preview asset.
     * @param string|null $lockedPreviewType Preview type descriptor (static|animated)
     * @return bool               Returns true on success, false on failure
     */
    public function RL_InsertCroppedVideo(
        int $userID,
        string $files,
        string $postType,
        int $createdTime,
        string $postText,
        string $whoCanSee,
        ?int $price,
        string $commentStatus,
        string $likeStatus,
        ?int $audioDurationSeconds = null,
        ?int $podcastCategoryId = null,
        ?string $lockedPreviewPath = null,
        ?string $lockedPreviewType = null,
        ?string $approvalStatus = 'approved',
        ?int $approvedBy = null,
        ?int $approvedAt = null,
        ?string $approvalNotes = null,
        ?string $postTitle = null
    ): bool {
        try {
            $this->rlLastPostSqlError = null;
            $this->RL_EnsureUserPostsSchema();
            $columns = $this->RL_GetUserPostsColumns();
            $lockedPreviewTypeValue = null;
            $lockedPreviewTypeParam = null;
            if (isset($columns['locked_preview_type'])) {
                $lockedTypeSchema = strtolower((string) ($columns['locked_preview_type']['Type'] ?? ''));
                $rawPreviewType = is_string($lockedPreviewType) ? strtolower(trim($lockedPreviewType)) : '';
                if ($rawPreviewType === 'static' || $rawPreviewType === 'animated') {
                    $isNumericEnum = (strpos($lockedTypeSchema, 'int') !== false)
                        || (preg_match("/enum\\('\\s*0\\s*'\\s*,\\s*'\\s*1\\s*'|enum\\('\\s*1\\s*'\\s*,\\s*'\\s*0\\s*'/", $lockedTypeSchema) === 1);
                    if ($isNumericEnum) {
                        $lockedPreviewTypeValue = $rawPreviewType === 'animated' ? 1 : 0;
                        $lockedPreviewTypeParam = PDO::PARAM_INT;
                    } else {
                        $lockedPreviewTypeValue = $rawPreviewType;
                        $lockedPreviewTypeParam = PDO::PARAM_STR;
                    }
                }
            }
            $cols = [
                'post_owner_id' => ':userID',
                'post_type' => ':postType',
                'post_file' => ':postFile',
                'post_created_time' => ':createdTime',
                'post_text' => ':postText',
                'post_visibility' => ':whoCanSee',
                'post_price' => ':price',
                'comment_status' => ':commentStatus',
                'like_status' => ':likeStatus',
            ];

            if (isset($columns['post_title'])) {
                $cols['post_title'] = ':postTitle';
            }
            if (isset($columns['audio_duration_seconds'])) {
                $cols['audio_duration_seconds'] = ':audioDurationSeconds';
            }
            if (isset($columns['podcast_category_id'])) {
                $cols['podcast_category_id'] = ':podcastCategoryId';
            }
            if (isset($columns['locked_preview_path'])) {
                $cols['locked_preview_path'] = ':lockedPreviewPath';
            }
            if (isset($columns['locked_preview_type']) && $lockedPreviewTypeValue !== null) {
                $cols['locked_preview_type'] = ':lockedPreviewType';
            }
            if (isset($columns['approval_status'])) {
                $cols['approval_status'] = ':approvalStatus';
            }
            if (isset($columns['approval_notes'])) {
                $cols['approval_notes'] = ':approvalNotes';
            }
            if (isset($columns['approved_at'])) {
                $cols['approved_at'] = ':approvedAt';
            }
            if (isset($columns['approved_by'])) {
                $cols['approved_by'] = ':approvedBy';
            }

            $sql = 'INSERT INTO i_user_posts (' . implode(', ', array_keys($cols)) . ') VALUES (' . implode(', ', array_values($cols)) . ')';
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':userID', $userID, PDO::PARAM_INT);
            $stmt->bindValue(':postType', $postType, PDO::PARAM_STR);
            $stmt->bindValue(':postFile', $files, PDO::PARAM_STR);
            $stmt->bindValue(':createdTime', $createdTime, PDO::PARAM_INT);

            $stmt->bindValue(':postText', $postText, PDO::PARAM_STR);
            if (isset($cols['post_title'])) {
                $cleanTitle = trim(strip_tags((string) ($postTitle ?? '')));
                if ($cleanTitle === '') {
                    $stmt->bindValue(':postTitle', null, PDO::PARAM_NULL);
                } else {
                    $stmt->bindValue(':postTitle', function_exists('mb_substr') ? mb_substr($cleanTitle, 0, 255, 'UTF-8') : substr($cleanTitle, 0, 255), PDO::PARAM_STR);
                }
            }
            $stmt->bindValue(':whoCanSee', $whoCanSee, PDO::PARAM_STR);

            if ($price === null) {
                $stmt->bindValue(':price', null, PDO::PARAM_NULL);
            } else {
                $stmt->bindValue(':price', $price, PDO::PARAM_INT);
            }

            $stmt->bindValue(':commentStatus', $commentStatus, PDO::PARAM_STR);
            $stmt->bindValue(':likeStatus', $likeStatus, PDO::PARAM_STR);
            if (isset($cols['audio_duration_seconds'])) {
                if ($audioDurationSeconds === null) {
                    $stmt->bindValue(':audioDurationSeconds', null, PDO::PARAM_NULL);
                } else {
                    $stmt->bindValue(':audioDurationSeconds', $audioDurationSeconds, PDO::PARAM_INT);
                }
            }
            if (isset($cols['podcast_category_id'])) {
                if ($podcastCategoryId === null || $podcastCategoryId <= 0) {
                    $stmt->bindValue(':podcastCategoryId', null, PDO::PARAM_NULL);
                } else {
                    $stmt->bindValue(':podcastCategoryId', (int)$podcastCategoryId, PDO::PARAM_INT);
                }
            }
            if (isset($cols['locked_preview_path'])) {
                if ($lockedPreviewPath === null || $lockedPreviewPath === '') {
                    $stmt->bindValue(':lockedPreviewPath', null, PDO::PARAM_NULL);
                } else {
                    $stmt->bindValue(':lockedPreviewPath', $lockedPreviewPath, PDO::PARAM_STR);
                }
            }
            if (isset($cols['locked_preview_type']) && $lockedPreviewTypeValue !== null) {
                $stmt->bindValue(':lockedPreviewType', $lockedPreviewTypeValue, $lockedPreviewTypeParam ?? PDO::PARAM_STR);
            }
            if (isset($cols['approval_status'])) {
                $normalizedApproval = strtolower(trim((string) ($approvalStatus ?? 'approved')));
                if (!in_array($normalizedApproval, ['pending', 'approved', 'rejected'], true)) {
                    $normalizedApproval = 'approved';
                }
                $stmt->bindValue(':approvalStatus', $normalizedApproval, PDO::PARAM_STR);
            }
            if (isset($cols['approval_notes'])) {
                if ($approvalNotes === null || $approvalNotes === '') {
                    $stmt->bindValue(':approvalNotes', null, PDO::PARAM_NULL);
                } else {
                    $stmt->bindValue(':approvalNotes', $approvalNotes, PDO::PARAM_STR);
                }
            }
            if (isset($cols['approved_at'])) {
                if ($approvedAt === null) {
                    $stmt->bindValue(':approvedAt', null, PDO::PARAM_NULL);
                } else {
                    $stmt->bindValue(':approvedAt', (int)$approvedAt, PDO::PARAM_INT);
                }
            }
            if (isset($cols['approved_by'])) {
                if ($approvedBy === null) {
                    $stmt->bindValue(':approvedBy', null, PDO::PARAM_NULL);
                } else {
                    $stmt->bindValue(':approvedBy', (int)$approvedBy, PDO::PARAM_INT);
                }
            }

            $ok = $stmt->execute();
            if ($ok) {
                $postId = (int) $this->db->lastInsertId();
                if ($postId > 0) {
                    $this->RL_SavePostHashtags($postId, $postText, $postTitle);
                }
            }
            return $ok;
        } catch (PDOException $e) {
            $this->rlLastPostSqlError = $e->getMessage();
            if (function_exists('logErrorToFile')) {
                logErrorToFile('RL_InsertCroppedImage Hatası: ' . $e->getMessage());
            }
            return false;
        }
    }

    /**
     * Fetch the freshly inserted post as a single row shaped like RL_FeedRelatedVisible().
     *
     * @param int    $ownerId     Post owner user_id (the creator).
     * @param string $postFile    Exact post_file value inserted (e.g. 'uploads/files/2025-08-14/a.png,...').
     * @param int    $createdTime Exact post_created_time used at insert time.
     * @param int    $viewerId    Current viewer id (usually same as owner right after upload).
     *
     * @return array|null         Post row or null if not found.
     */
    public function RL_GetNewPost(
        int $ownerId,
        string $postFile,
        int $createdTime,
        int $viewerId
    ): ?array {
        $feedLang = isset($GLOBALS['currentLang']) && is_string($GLOBALS['currentLang']) ? strtolower((string) $GLOBALS['currentLang']) : 'eng';
        if ($feedLang === '') {
            $feedLang = 'eng';
        }
        try {
            if ($ownerId <= 0 || $createdTime <= 0 || $postFile === '') {
                return null;
            }

            $this->RL_EnsurePodcastCategoriesTable();

            $sql = "
                SELECT
                    p.post_id,
                    p.post_owner_id,
                    p.post_type,
                    p.post_file,
                    p.audio_duration_seconds,
                    p.podcast_category_id,
                    p.locked_preview_path,
                    p.locked_preview_type,
                    p.post_text,
                    p.post_visibility,
                    p.post_price,
                    p.comment_status,
                    p.like_status,
                    p.approval_status,
                    p.approval_notes,
                    p.approved_at,
                    p.approved_by,
                    p.post_created_time,

                    u.user_id         AS owner_id,
                    u.username        AS owner_username,
                    u.user_fullname   AS owner_fullname,
                    u.user_avatar     AS owner_avatar,
                    u.verified_status AS owner_verified,

                    rel_v2o.fr_status AS viewer_to_owner_status,

                    COALESCE(pct.name, pc.name)  AS podcast_category_name,
                    pc.slug  AS podcast_category_slug,
                    pc.status AS podcast_category_status
                FROM i_user_posts AS p
                INNER JOIN i_users AS u
                    ON u.user_id = p.post_owner_id
                LEFT JOIN i_podcast_categories AS pc
                    ON pc.id = p.podcast_category_id
                LEFT JOIN i_podcast_category_translations AS pct
                    ON pct.category_id = pc.id AND pct.language = :cat_lang
                /* Directional relation: viewer -> owner */
                LEFT JOIN (
                    SELECT fr_two AS other_id,
                        SUBSTRING_INDEX(
                            GROUP_CONCAT(fr_status
                            ORDER BY FIELD(fr_status, 'subscriber', 'flwr', 'me') DESC
                            SEPARATOR ','
                            ),
                            ',', 1
                        ) AS fr_status
                    FROM i_friends
                    WHERE fr_one = :viewer_id
                    GROUP BY fr_two
                ) AS rel_v2o
                ON rel_v2o.other_id = p.post_owner_id
                WHERE p.post_owner_id = :owner_id
                AND p.post_created_time = :ctime
                AND p.post_file = :pfile
                ORDER BY p.post_id DESC
                LIMIT 1
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':viewer_id', $viewerId, \PDO::PARAM_INT);
            $stmt->bindValue(':owner_id',  $ownerId,  \PDO::PARAM_INT);
            $stmt->bindValue(':ctime',     $createdTime, \PDO::PARAM_INT);
            $stmt->bindValue(':pfile',     $postFile, \PDO::PARAM_STR);
            $stmt->bindValue(':cat_lang',  $feedLang, \PDO::PARAM_STR);
            $stmt->execute();

            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                return null;
            }

            $ownerIdRow = (int) $row['post_owner_id'];

            // Shape output exactly like RL_FeedRelatedVisible()
            return [
                'post_id'           => (int) $row['post_id'],
                'post_owner_id'     => $ownerIdRow,
                'post_type'         => (string) $row['post_type'],
                'post_file'         => (string) $row['post_file'],
                'audio_duration_seconds' => $row['audio_duration_seconds'] !== null ? (int) $row['audio_duration_seconds'] : null,
                'podcast_category_id' => $row['podcast_category_id'] !== null ? (int) $row['podcast_category_id'] : null,
                'podcast_category_name' => isset($row['podcast_category_name']) ? (string) $row['podcast_category_name'] : null,
                'podcast_category_slug' => isset($row['podcast_category_slug']) ? (string) $row['podcast_category_slug'] : null,
                'podcast_category_status' => isset($row['podcast_category_status']) ? (string) $row['podcast_category_status'] : null,
                'locked_preview_path' => $row['locked_preview_path'] !== null ? (string) $row['locked_preview_path'] : '',
                'locked_preview_type' => $row['locked_preview_type'] !== null ? (string) $row['locked_preview_type'] : null,
                'post_text'         => (string) $row['post_text'],
                'post_visibility'   => (string) $row['post_visibility'],
                'post_price'        => $row['post_price'] !== null ? (string) $row['post_price'] : null,
                'comment_status'    => (string) $row['comment_status'],
                'like_status'       => (string) $row['like_status'],
                'post_created_time' => (int) $row['post_created_time'],

                'owner_id'          => (int) $row['owner_id'],
                'owner_username'    => (string) $row['owner_username'],
                'owner_fullname'    => (string) $row['owner_fullname'],
                'owner_avatar'      => (string) $row['owner_avatar'],
                'owner_verified'    => (int) $row['owner_verified'],

                'viewer_to_owner_status' => $row['viewer_to_owner_status'] !== null
                    ? (string) $row['viewer_to_owner_status']
                    : null,
                'is_owner' => ($viewerId > 0 && $viewerId === $ownerIdRow),
            ];
        } catch (\Throwable $e) {
            $this->logError('RL_GetNewPost failed: ' . $e->getMessage());
            return null;
        }
    }
    /**
     * Fetch a single post by ID, shaped like RL_FeedRelatedVisible()/RL_GetNewPost().
     *
     * @param int         $postId           Target post_id
     * @param int         $viewerId         Current viewer user_id (0 for guest)
     * @param string|null $expectedUsername Optional: enforce owner username match (case-insensitive). If not matched => null.
     *
     * @return array<string,mixed>|null
     */
    public function RL_GetPostById(
        int $postId,
        int $viewerId,
        ?string $expectedUsername = null
    ): ?array {
        $feedLang = isset($GLOBALS['currentLang']) && is_string($GLOBALS['currentLang']) ? strtolower((string) $GLOBALS['currentLang']) : 'eng';
        if ($feedLang === '') {
            $feedLang = 'eng';
        }
        try {
            if ($postId <= 0) {
                return null;
            }

            $this->RL_EnsurePodcastCategoriesTable();

            // NOTE: If you have soft-delete or publish-status columns (e.g., u.user_status / p.post_status), add them here with AND.
            $sql = "
                SELECT
                    p.post_id,
                    p.post_owner_id,
                    p.post_type,
                    p.post_file,
                    p.audio_duration_seconds,
                    p.podcast_category_id,
                    p.locked_preview_path,
                    p.locked_preview_type,
                    p.post_text,
                    p.post_visibility,
                    p.post_price,
                    p.comment_status,
                    p.like_status,
                    p.approval_status,
                    p.approval_notes,
                    p.approved_at,
                    p.approved_by,
                    p.post_created_time,

                    u.user_id         AS owner_id,
                    u.username        AS owner_username,
                    u.user_fullname   AS owner_fullname,
                    u.user_avatar     AS owner_avatar,
                    u.verified_status AS owner_verified,

                    COALESCE(pct.name, pc.name)  AS podcast_category_name,
                    pc.slug  AS podcast_category_slug,
                    pc.status AS podcast_category_status

                FROM i_user_posts AS p
                INNER JOIN i_users AS u
                    ON u.user_id = p.post_owner_id
                LEFT JOIN i_podcast_categories AS pc
                    ON pc.id = p.podcast_category_id
                LEFT JOIN i_podcast_category_translations AS pct
                    ON pct.category_id = pc.id AND pct.language = :cat_lang
                WHERE p.post_id = :pid
                LIMIT 1
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':pid', $postId, \PDO::PARAM_INT);
            $stmt->bindValue(':cat_lang', $feedLang, \PDO::PARAM_STR);
            $stmt->execute();

            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                return null;
            }

            // Optional username enforcement (for /posts/{id}/{username} routes)
            if ($expectedUsername !== null && $expectedUsername !== '') {
                if (strcasecmp($expectedUsername, (string) $row['owner_username']) !== 0) {
                    return null;
                }
            }
            $approvalStatus = strtolower((string)($row['approval_status'] ?? 'approved'));
            $isOwner = ($viewerId > 0 && $viewerId === (int)$row['post_owner_id']);
            $isAdminViewer = isset($GLOBALS['isAdminUser']) ? (bool)$GLOBALS['isAdminUser'] : false;
            if ($approvalStatus !== 'approved' && !$isOwner && !$isAdminViewer) {
                return null;
            }

            // Fetch viewer->owner relation once (same approach you used in RL_GetNewPost)
            $relSql = "
                SELECT fr_two AS other_id,
                    SUBSTRING_INDEX(
                        GROUP_CONCAT(fr_status
                            ORDER BY FIELD(fr_status, 'subscriber', 'flwr', 'me') DESC
                            SEPARATOR ','
                        ), ',', 1
                    ) AS fr_status
                FROM i_friends
                WHERE fr_one = :viewer_id AND fr_two = :owner_id
                GROUP BY fr_two
            ";
            $relStmt = $this->db->prepare($relSql);
            $relStmt->bindValue(':viewer_id', $viewerId, \PDO::PARAM_INT);
            $relStmt->bindValue(':owner_id',  (int)$row['post_owner_id'], \PDO::PARAM_INT);
            $relStmt->execute();
            $rel = $relStmt->fetch(\PDO::FETCH_ASSOC);

            $viewerToOwner = $rel['fr_status'] ?? null;
            $ownerIdRow    = (int) $row['post_owner_id'];

            // Podcast-specific visibility enforcement to avoid leaking previews in chat shares.
            $postTypeValue = strtolower((string)($row['post_type'] ?? ''));
            $postVisibilityValue = (string)($row['post_visibility'] ?? 'everyone');
            if ($postTypeValue === 'podcast' && $postVisibilityValue !== 'everyone' && !$isOwner && !$isAdminViewer) {
                $isSubscriber = ($viewerToOwner === 'subscriber');
                $purchased = false;
                $hasPrice = isset($row['post_price']) && $row['post_price'] !== null && $row['post_price'] !== '';
                if (
                    $viewerId > 0
                    && ($postVisibilityValue === 'locked' || $hasPrice)
                ) {
                    $purchased = method_exists($this, 'hasPurchasedPost') && $this->hasPurchasedPost($viewerId, (int)$row['post_id']);
                }
                if (!$isSubscriber && !$purchased) {
                    return null;
                }
            }

            // Shape the payload exactly like your feed/new-post rows
            $shaped = [
                'post_id'           => (int) $row['post_id'],
                'post_owner_id'     => $ownerIdRow,
                'post_type'         => (string) $row['post_type'],
                'post_file'         => (string) $row['post_file'],
                'audio_duration_seconds' => isset($row['audio_duration_seconds']) && $row['audio_duration_seconds'] !== null ? (int)$row['audio_duration_seconds'] : null,
                'podcast_category_id' => $row['podcast_category_id'] !== null ? (int)$row['podcast_category_id'] : null,
                'podcast_category_name' => isset($row['podcast_category_name']) ? (string)$row['podcast_category_name'] : null,
                'podcast_category_slug' => isset($row['podcast_category_slug']) ? (string)$row['podcast_category_slug'] : null,
                'podcast_category_status' => isset($row['podcast_category_status']) ? (string)$row['podcast_category_status'] : null,
                'locked_preview_path' => isset($row['locked_preview_path']) && $row['locked_preview_path'] !== null ? (string)$row['locked_preview_path'] : '',
                'locked_preview_type' => isset($row['locked_preview_type']) && $row['locked_preview_type'] !== null ? (string)$row['locked_preview_type'] : null,
                'post_text'         => (string) $row['post_text'],
                'post_visibility'   => (string) $row['post_visibility'],
                'post_price'        => $row['post_price'] !== null ? (string) $row['post_price'] : null,
                'comment_status'    => (string) $row['comment_status'],
                'like_status'       => (string) $row['like_status'],
                'approval_status'   => $approvalStatus,
                'approval_notes'    => isset($row['approval_notes']) && $row['approval_notes'] !== null ? (string)$row['approval_notes'] : null,
                'approved_at'       => isset($row['approved_at']) && $row['approved_at'] !== null ? (int)$row['approved_at'] : null,
                'approved_by'       => isset($row['approved_by']) && $row['approved_by'] !== null ? (int)$row['approved_by'] : null,
                'post_created_time' => (int) $row['post_created_time'],

                'owner_id'          => (int) $row['owner_id'],
                'owner_username'    => (string) $row['owner_username'],
                'owner_fullname'    => (string) $row['owner_fullname'],
                'owner_avatar'      => (string) $row['owner_avatar'],
                'owner_verified'    => (int) $row['owner_verified'],

                'viewer_to_owner_status' => $viewerToOwner !== null ? (string) $viewerToOwner : null,
                'is_owner'               => $isOwner,

                // Helpful for your locked/PPV check in the template:
                'viewer_id'             => $viewerId,
                'viewer_is_admin'       => $isAdminViewer,
            ];

            return $shaped;
        } catch (\Throwable $e) {
            $this->logError('RL_GetPostById failed: ' . $e->getMessage());
            return null;
        }
    }

    public function RL_GetPostData(int $postID): ?array
    {
        if ($postID <= 0) {
            return null;
        }

        try {
            $sql = "SELECT
                        post_id,
                        post_owner_id,
                        post_type,
                        post_file,
                        post_text,
                        post_visibility,
                        post_price,
                        comment_status,
                        like_status,
                        post_created_time
                    FROM i_user_posts
                    WHERE post_id = :post_id
                    LIMIT 1";

            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':post_id', $postID, \PDO::PARAM_INT);
            $stmt->execute();

            $data = $stmt->fetch(\PDO::FETCH_ASSOC);

            return $data !== false ? $data : null;
        } catch (\Throwable $e) {
            $this->logError('RL_GetPostById failed: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Toggle bookmark (varsa siler, yoksa ekler)
     *
     * @return array{bookmarked: bool, total: int}
     */
    public function RL_ToggleBookmark(int $userId, int $postId, string $itemType = 'image'): array
    {
        $itemType = ($itemType === 'video') ? 'video' : 'image';

        $sql = 'SELECT b_id FROM i_bookmarks WHERE uid_fk = :uid AND item_id = :pid AND item_type = :typ LIMIT 1';
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
        $stmt->bindValue(':pid', $postId, \PDO::PARAM_INT);
        $stmt->bindValue(':typ', $itemType, \PDO::PARAM_STR);
        $stmt->execute();
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        if ($row && isset($row['b_id'])) {
            $del = $this->db->prepare('DELETE FROM i_bookmarks WHERE b_id = :bid');
            $del->bindValue(':bid', (int) $row['b_id'], \PDO::PARAM_INT);
            $del->execute();
            $bookmarked = false;
        } else {
            $ins = $this->db->prepare(
                'INSERT INTO i_bookmarks (item_id, uid_fk, item_type, created_time) VALUES (:pid, :uid, :typ, :ts)'
            );
            $ins->bindValue(':pid', $postId, \PDO::PARAM_INT);
            $ins->bindValue(':uid', $userId, \PDO::PARAM_INT);
            $ins->bindValue(':typ', $itemType, \PDO::PARAM_STR);
            $ins->bindValue(':ts', time(), \PDO::PARAM_INT);
            $ins->execute();
            $bookmarked = true;
        }

        return [
            'bookmarked' => $bookmarked,
            'total'      => $this->RL_CountBookmarks($postId, $itemType),
        ];
    }

    /** Is the post bookmarked by the user? */
    public function RL_IsBookmarked(int $userId, int $postId, string $itemType = 'image'): bool
    {
        $itemType = ($itemType === 'video') ? 'video' : 'image';
        $sql = 'SELECT 1 FROM i_bookmarks WHERE uid_fk = :uid AND item_id = :pid AND item_type = :typ LIMIT 1';
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
        $stmt->bindValue(':pid', $postId, \PDO::PARAM_INT);
        $stmt->bindValue(':typ', $itemType, \PDO::PARAM_STR);
        $stmt->execute();
        return (bool) $stmt->fetchColumn();
    }

    /** Total number of bookmarks for the post. */
    public function RL_CountBookmarks(int $postId, string $itemType = 'image'): int
    {
        $itemType = ($itemType === 'video') ? 'video' : 'image';
        $sql = 'SELECT COUNT(*) FROM i_bookmarks WHERE item_id = :pid AND item_type = :typ';
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':pid', $postId, \PDO::PARAM_INT);
        $stmt->bindValue(':typ', $itemType, \PDO::PARAM_STR);
        $stmt->execute();
        return (int) $stmt->fetchColumn();
    }

    /** Count how many unique recipients received this post via DM (file='post:<id>'). */
    public function RL_CountPostShares(int $postId): int
    {
        $postId = (int)$postId; if ($postId <= 0) { return 0; }
        try {
            // Count DISTINCT recipients (user_two) so a person is counted once
            $st = $this->db->prepare("SELECT COUNT(DISTINCT user_two) FROM i_messages WHERE file = :f");
            $st->bindValue(':f', 'post:' . $postId, \PDO::PARAM_STR);
            $st->execute();
            return (int)$st->fetchColumn();
        } catch (\Throwable $__) { return 0; }
    }
}
