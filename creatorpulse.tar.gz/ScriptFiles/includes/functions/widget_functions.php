<?php
declare(strict_types=1);

trait WidgetFunctions {
    /**
     * Most popular posts by today's activity (views/likes/comments within [sinceTs, untilTs)).
     * Considers ALL posts (all-time), ranks by weighted activity counts in the window.
     * Defaults to "today" in Europe/Istanbul.
     *
     * @param int         $limit     number of posts
     * @param string      $timezone  day boundary TZ if sinceTs not provided
     * @param array       $weights   ['views'=>1,'likes'=>3,'comments'=>5]
     * @param int|null    $sinceTs   window start (unix). If null, start of today in TZ
     * @param int|null    $untilTs   window end (unix). If null, now
     * @return array<int, array<string,mixed>>
     */
    public function RL_GetMostPopularByActivity(
        int $limit = 1,
        ?string $timezone = null,
        array $weights = [],
        ?int $sinceTs = null,
        ?int $untilTs = null
    ): array {
        try {
            $limit = max(1, (int)$limit);
            $wViews    = isset($weights['views'])    ? (int)$weights['views']    : 1;
            $wLikes    = isset($weights['likes'])    ? (int)$weights['likes']    : 3;
            $wComments = isset($weights['comments']) ? (int)$weights['comments'] : 5;

            $tzName = $timezone ?: (method_exists($this, 'RL_GetPreferredTimezone') ? $this->RL_GetPreferredTimezone() : 'UTC');
            $tz  = new \DateTimeZone($tzName);
            $now = new \DateTimeImmutable('now', $tz);
            if ($sinceTs === null) { $sinceTs = $now->setTime(0,0,0)->getTimestamp(); }
            if ($untilTs === null) { $untilTs = time(); }

            // Derived tables (no CTE) + distinct named params to satisfy PDO (no reuse allowed)
            $sql = "
                SELECT
                  p.post_id,
                  p.post_owner_id,
                  p.post_type,
                  p.post_file,
                  p.post_text,
                  p.post_views,
                  p.post_visibility,
                  p.post_price,
                  p.comment_status,
                  p.like_status,
                  p.post_created_time,

                  u.user_id         AS owner_id,
                  u.username        AS owner_username,
                  u.user_fullname   AS owner_fullname,
                  u.user_avatar     AS owner_avatar,
                  u.verified_status AS owner_verified,

                  COALESCE(v.views_today,0)    AS views_today,
                  COALESCE(l.likes_today,0)    AS likes_today,
                  COALESCE(c.comments_today,0) AS comments_today,
                  (COALESCE(v.views_today,0)*$wViews + COALESCE(l.likes_today,0)*$wLikes + COALESCE(c.comments_today,0)*$wComments) AS score
                FROM (
                  SELECT vv.post_id FROM i_post_views vv WHERE vv.created_at >= :sv1 AND vv.created_at < :uv1 GROUP BY vv.post_id
                  UNION DISTINCT
                  SELECT ll.liked_item_id AS post_id FROM i_post_liked ll WHERE ll.liked_item_type = 'post' AND ll.liked_time >= :sl1 AND ll.liked_time < :ul1 GROUP BY ll.liked_item_id
                  UNION DISTINCT
                  SELECT cc.item_id AS post_id FROM i_comments cc WHERE cc.created_time >= :sc1 AND cc.created_time < :uc1 GROUP BY cc.item_id
                ) a
                JOIN i_user_posts p ON p.post_id = a.post_id AND p.post_visibility = 'everyone' AND (p.approval_status IS NULL OR p.approval_status = 'approved')
                JOIN i_users u ON u.user_id = p.post_owner_id
                LEFT JOIN (
                  SELECT vv.post_id, COUNT(*) AS views_today
                  FROM i_post_views vv
                  WHERE vv.created_at >= :sv2 AND vv.created_at < :uv2
                  GROUP BY vv.post_id
                ) v ON v.post_id = p.post_id
                LEFT JOIN (
                  SELECT ll.liked_item_id AS post_id, COUNT(*) AS likes_today
                  FROM i_post_liked ll
                  WHERE ll.liked_item_type = 'post' AND ll.liked_time >= :sl2 AND ll.liked_time < :ul2
                  GROUP BY ll.liked_item_id
                ) l ON l.post_id = p.post_id
                LEFT JOIN (
                  SELECT cc.item_id AS post_id, COUNT(*) AS comments_today
                  FROM i_comments cc
                  WHERE cc.created_time >= :sc2 AND cc.created_time < :uc2
                  GROUP BY cc.item_id
                ) c ON c.post_id = p.post_id
                ORDER BY score DESC, p.post_created_time DESC
                LIMIT :lim
            ";

            $st = $this->db->prepare($sql);
            // Bind distinct params for each occurrence
            $st->bindValue(':sv1', $sinceTs, \PDO::PARAM_INT);
            $st->bindValue(':uv1', $untilTs, \PDO::PARAM_INT);
            $st->bindValue(':sl1', $sinceTs, \PDO::PARAM_INT);
            $st->bindValue(':ul1', $untilTs, \PDO::PARAM_INT);
            $st->bindValue(':sc1', $sinceTs, \PDO::PARAM_INT);
            $st->bindValue(':uc1', $untilTs, \PDO::PARAM_INT);

            $st->bindValue(':sv2', $sinceTs, \PDO::PARAM_INT);
            $st->bindValue(':uv2', $untilTs, \PDO::PARAM_INT);
            $st->bindValue(':sl2', $sinceTs, \PDO::PARAM_INT);
            $st->bindValue(':ul2', $untilTs, \PDO::PARAM_INT);
            $st->bindValue(':sc2', $sinceTs, \PDO::PARAM_INT);
            $st->bindValue(':uc2', $untilTs, \PDO::PARAM_INT);
            $st->bindValue(':lim', $limit, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            if (!$rows) { return []; }

            $out = [];
            foreach ($rows as $row) {
                $files = [];
                $firstImage = '';
                $hasMulti = false;
                if (($row['post_type'] ?? '') === 'image') {
                    $files = array_values(array_filter(array_map('trim', explode(',', (string) ($row['post_file'] ?? ''))), static fn($p)=>$p!==''));
                    $firstImage = $files[0] ?? '';
                    $hasMulti = count($files) > 1;
                }
                $out[] = [
                    'post_id'            => (int)$row['post_id'],
                    'post_owner_id'      => (int)$row['post_owner_id'],
                    'post_type'          => (string)$row['post_type'],
                    'post_file'          => (string)$row['post_file'],
                    'post_files'         => $files,
                    'first_image'        => $firstImage,
                    'images_count'       => count($files),
                    'has_multiple_images'=> $hasMulti,
                    'post_text'          => (string)$row['post_text'],
                    'post_visibility'    => (string)$row['post_visibility'],
                    'post_price'         => $row['post_price'] !== null ? (string)$row['post_price'] : null,
                    'comment_status'     => (string)$row['comment_status'],
                    'like_status'        => (string)$row['like_status'],
                    'post_created_time'  => (int)$row['post_created_time'],
                    'post_views'         => (int)$row['post_views'],
                    'owner_id'           => (int)$row['owner_id'],
                    'owner_username'     => (string)$row['owner_username'],
                    'owner_fullname'     => (string)$row['owner_fullname'],
                    'owner_avatar'       => (string)$row['owner_avatar'],
                    'owner_verified'     => (int)$row['owner_verified'],
                    'likes_count_today'    => (int)$row['likes_today'],
                    'comments_count_today' => (int)$row['comments_today'],
                    'views_count_today'    => (int)$row['views_today'],
                    'score'                => (int)$row['score'],
                ];
            }
            return $out;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetMostPopularByActivity failed: ' . $e->getMessage());
            }
            return [];
        }
    }
}
