<?php
declare(strict_types=1);

trait PageCmsFunctions
{
    private array $allowedPageTags = [
        'p' => [],
        'h1' => [],
        'h2' => [],
        'h3' => [],
        'h4' => [],
        'h5' => [],
        'h6' => [],
        'strong' => [],
        'em' => [],
        'ul' => [],
        'ol' => [],
        'li' => [],
        'blockquote' => [],
        'code' => [],
        'pre' => [],
        'a' => ['href', 'target', 'rel'],
        'img' => ['src', 'alt'],
        'br' => [],
        'hr' => [],
    ];

    public function RL_GetPagesWithTranslations(array $languages = []): array
    {
        $sql = 'SELECT p.id, p.slug, p.is_active, p.sort_order, c.lang, c.title, c.content_html
                FROM i_pages AS p
                LEFT JOIN i_page_content AS c ON c.page_id = p.id
                ORDER BY p.sort_order ASC, p.id ASC';

        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetPagesWithTranslations failed: ' . $e->getMessage());
            }
            return [];
        }

        $pages = [];
        foreach ($rows as $row) {
            $id = (int) ($row['id'] ?? 0);
            if ($id <= 0) {
                continue;
            }
            if (!isset($pages[$id])) {
                $pages[$id] = [
                    'id' => $id,
                    'slug' => (string) ($row['slug'] ?? ''),
                    'is_active' => !empty($row['is_active']),
                    'sort_order' => (int) ($row['sort_order'] ?? 0),
                    'translations' => [],
                ];
            }
            $lang = isset($row['lang']) ? strtolower((string) $row['lang']) : '';
            if ($lang !== '') {
                $pages[$id]['translations'][$lang] = [
                    'title' => (string) ($row['title'] ?? ''),
                    'content' => (string) ($row['content_html'] ?? ''),
                ];
            }
        }

        // Ensure translation keys exist even if empty
        if ($languages) {
            foreach ($pages as &$page) {
                foreach ($languages as $code) {
                    $key = strtolower((string) $code);
                    if (!isset($page['translations'][$key])) {
                        $page['translations'][$key] = ['title' => '', 'content' => ''];
                    }
                }
            }
            unset($page);
        }

        return array_values($pages);
    }

    public function RL_BulkSavePages(array $pages, string $defaultLang): bool
    {
        return $this->persistPages($pages, $defaultLang, false, 'RL_BulkSavePages') === true;
    }

    /**
     * Persist CMS pages and return saved identifiers and slugs.
     *
     * @param array<int, array<string, mixed>> $pages
     * @return array<int, array{id:int, slug:string}>
     */
    public function RL_SavePagesDetailed(array $pages, string $defaultLang): array
    {
        $result = $this->persistPages($pages, $defaultLang, true, 'RL_SavePagesDetailed');
        return is_array($result) ? $result : [];
    }

    /**
     * Fetch a single active page by slug with language fallbacks.
     */
    public function RL_GetPageBySlug(string $slug, string $preferredLang, array $fallbackLangs = []): ?array
    {
        $slug = trim($slug);
        if ($slug === '') {
            return null;
        }

        $sequence = [];
        $preferred = strtolower(trim($preferredLang));
        if ($preferred !== '') {
            $sequence[] = $preferred;
        }
        foreach ($fallbackLangs as $langCode) {
            $langKey = strtolower(trim((string) $langCode));
            if ($langKey === '' || in_array($langKey, $sequence, true)) {
                continue;
            }
            $sequence[] = $langKey;
        }
        if (!$sequence) {
            $sequence = ['eng'];
        }

        $sql = 'SELECT p.id, p.slug, p.is_active, p.sort_order, c.lang, c.title, c.content_html
                FROM i_pages AS p
                LEFT JOIN i_page_content AS c ON c.page_id = p.id
                WHERE p.slug = :slug
                ORDER BY c.lang ASC';

        try {
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':slug', $slug, PDO::PARAM_STR);
            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetPageBySlug failed: ' . $e->getMessage());
            }
            return null;
        }

        if (!$rows) {
            return null;
        }

        $pageId = (int) ($rows[0]['id'] ?? 0);
        $isActive = !empty($rows[0]['is_active']);
        if ($pageId <= 0 || !$isActive) {
            return null;
        }

        $translations = [];
        foreach ($rows as $row) {
            $lang = isset($row['lang']) ? strtolower((string) $row['lang']) : '';
            if ($lang === '') {
                continue;
            }
            $translations[$lang] = [
                'title' => (string) ($row['title'] ?? ''),
                'content' => (string) ($row['content_html'] ?? ''),
            ];
        }

        $chosenLang = null;
        $chosenTitle = '';
        $chosenContent = '';
        foreach ($sequence as $langCode) {
            if (!isset($translations[$langCode])) {
                continue;
            }
            $payload = $translations[$langCode];
            if ($payload['title'] !== '' || $payload['content'] !== '') {
                $chosenLang = $langCode;
                $chosenTitle = $payload['title'];
                $chosenContent = $payload['content'];
                break;
            }
        }

        if ($chosenLang === null) {
            return null;
        }

        return [
            'id' => $pageId,
            'slug' => (string) $rows[0]['slug'],
            'sort_order' => (int) ($rows[0]['sort_order'] ?? 0),
            'title' => $chosenTitle,
            'content_html' => $chosenContent,
            'lang_used' => $chosenLang,
            'translations' => $translations,
        ];
    }

    /**
     * Return active pages with titles resolved for the requested language.
     *
     * @return array<int, array{id:int, slug:string, title:string, sort_order:int}>
     */
    public function RL_GetActivePagesForLang(string $lang, array $fallbackLangs = []): array
    {
        $lang = strtolower(trim($lang));
        $sequence = [];
        if ($lang !== '') {
            $sequence[] = $lang;
        }
        foreach ($fallbackLangs as $entry) {
            $candidate = strtolower(trim((string) $entry));
            if ($candidate === '' || in_array($candidate, $sequence, true)) {
                continue;
            }
            $sequence[] = $candidate;
        }
        if (!$sequence) {
            $sequence = ['eng'];
        }

        $pages = $this->RL_GetPagesWithTranslations($sequence);
        if (!$pages) {
            return [];
        }

        $results = [];
        foreach ($pages as $page) {
            if (empty($page['is_active'])) {
                continue;
            }
            $translations = isset($page['translations']) && is_array($page['translations']) ? $page['translations'] : [];
            $title = '';
            foreach ($sequence as $langCode) {
                $langCode = strtolower($langCode);
                if (!isset($translations[$langCode])) {
                    continue;
                }
                $candidate = (string) ($translations[$langCode]['title'] ?? '');
                if ($candidate !== '') {
                    $title = $candidate;
                    break;
                }
            }
            if ($title === '') {
                continue;
            }

            $results[] = [
                'id' => (int) ($page['id'] ?? 0),
                'slug' => (string) ($page['slug'] ?? ''),
                'title' => $title,
                'sort_order' => (int) ($page['sort_order'] ?? 0),
            ];
        }

        usort($results, static function (array $a, array $b): int {
            $orderA = $a['sort_order'] ?? 0;
            $orderB = $b['sort_order'] ?? 0;
            if ($orderA === $orderB) {
                return ($a['id'] ?? 0) <=> ($b['id'] ?? 0);
            }
            return $orderA <=> $orderB;
        });

        return $results;
    }

    public function RL_DeletePages(array $pageIds): bool
    {
        $ids = array_values(array_filter(array_map('intval', $pageIds))); // remove zeros
        if (!$ids) {
            return true;
        }

        try {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $stmt = $this->db->prepare("DELETE FROM i_pages WHERE id IN ($placeholders)");
            foreach ($ids as $idx => $id) {
                $stmt->bindValue($idx + 1, $id, PDO::PARAM_INT);
            }
            return $stmt->execute();
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_DeletePages failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    private function sanitizePageSlug(string $value): string
    {
        $value = trim($value);
        if ($value === '') {
            return '';
        }
        if (!function_exists('url_slug')) {
            return strtolower(preg_replace('/[^a-z0-9]+/i', '-', $value));
        }
        $slug = url_slug($value, ['delimiter' => '-', 'lowercase' => true]);
        return $slug !== '' ? $slug : strtolower(preg_replace('/[^a-z0-9]+/i', '-', $value));
    }

    private function ensureUniquePageSlug(string $slug, int $excludeId = 0): string
    {
        $base = $slug !== '' ? $slug : 'page';
        $candidate = $base;
        $suffix = 2;
        while (true) {
            try {
                $sql = 'SELECT COUNT(*) FROM i_pages WHERE slug = :slug' . ($excludeId > 0 ? ' AND id <> :id' : '');
                $stmt = $this->db->prepare($sql);
                $stmt->bindValue(':slug', $candidate, PDO::PARAM_STR);
                if ($excludeId > 0) {
                    $stmt->bindValue(':id', $excludeId, PDO::PARAM_INT);
                }
                $stmt->execute();
                $exists = (int) $stmt->fetchColumn() > 0;
                if (!$exists) {
                    return $candidate;
                }
            } catch (Throwable $e) {
                return $candidate;
            }
            $candidate = $base . '-' . $suffix;
            $suffix++;
        }
    }

    private function sanitizeCmsHtml(string $html): string
    {
        $html = trim($html);
        if ($html === '') {
            return '';
        }
        $html = preg_replace('#<\?(php)?#i', '', $html);
        $html = preg_replace('#<script(.*?)</script>#is', '', $html);

        $dom = new DOMDocument('1.0', 'UTF-8');
        libxml_use_internal_errors(true);
        $wrapped = '<div>' . $html . '</div>';
        if (function_exists('mb_encode_numericentity')) {
            $wrapped = mb_encode_numericentity($wrapped, [0x80, 0x10FFFF, 0, 0xFFFF], 'UTF-8');
        } elseif (function_exists('mb_convert_encoding')) {
            // Legacy fallback for environments without mb_encode_numericentity
            $wrapped = mb_convert_encoding($wrapped, 'HTML-ENTITIES', 'UTF-8');
        }
        $dom->loadHTML('<?xml encoding="UTF-8">' . $wrapped, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();

        $this->sanitizeCmsNode($dom->documentElement);

        $container = $dom->getElementsByTagName('div')->item(0);
        if (!$container) {
            $clean = $dom->saveHTML();
            return is_string($clean) ? trim($clean) : '';
        }

        $out = '';
        foreach ($container->childNodes as $child) {
            $out .= $dom->saveHTML($child);
        }

        return trim($out);
    }

    private function allowedImageSrcPrefixes(): array
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }

        $prefixes = [];
        $base = '';
        if (isset($GLOBALS['base_url']) && $GLOBALS['base_url'] !== '') {
            $base = rtrim((string) $GLOBALS['base_url'], '/');
        }

        if ($base === '' && isset($_SERVER['HTTP_HOST'])) {
            $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $host   = (string) ($_SERVER['HTTP_HOST'] ?? '');
            if ($host !== '') {
                $script = isset($_SERVER['SCRIPT_NAME']) ? str_replace('\\', '/', (string) $_SERVER['SCRIPT_NAME']) : '';
                $dir    = trim(dirname($script), '/');
                $base   = $scheme . '://' . $host;
                if ($dir !== '' && $dir !== '.') {
                    $base .= '/' . $dir;
                }
            }
        }

        if ($base !== '') {
            $prefixes[] = $base;
            $prefixes[] = $base . '/';
        }

        return $cache = $prefixes;
    }

    private function sanitizeCmsNode(DOMNode $node): void
    {
        if (!$node->hasChildNodes()) {
            return;
        }

        foreach (iterator_to_array($node->childNodes) as $child) {
            if ($child instanceof DOMElement) {
                $tag = strtolower($child->tagName);
                if (!array_key_exists($tag, $this->allowedPageTags)) {
                    $owner = $child->ownerDocument;
                    $rawHtml = '';
                    if ($owner instanceof DOMDocument) {
                        $rawHtml = (string) $owner->saveHTML($child);
                    } else {
                        $rawHtml = $child->textContent ?? '';
                    }
                    $textNode = $owner instanceof DOMDocument
                        ? $owner->createTextNode($rawHtml)
                        : new DOMText($rawHtml);
                    $node->replaceChild($textNode, $child);
                    continue;
                }

                // Remove event attributes and keep only allowed ones
                $allowedAttributes = $this->allowedPageTags[$tag];
                if ($child->hasAttributes()) {
                    foreach (iterator_to_array($child->attributes) as $attr) {
                        $attrName = strtolower($attr->name);
                        if (strpos($attrName, 'on') === 0 || $attrName === 'style') {
                            $child->removeAttributeNode($attr);
                            continue;
                        }
                        if (!in_array($attrName, $allowedAttributes, true)) {
                            $child->removeAttributeNode($attr);
                            continue;
                        }
                        $value = trim($attr->value);
                        if ($tag === 'a' && $attrName === 'href') {
                            if ($value === '' || preg_match('#^javascript:#i', $value)) {
                                $child->removeAttribute('href');
                                continue;
                            }
                        }
                        if ($tag === 'a' && $attrName === 'target') {
                            $allowedTargets = ['_self', '_blank', '_parent', '_top'];
                            if (!in_array(strtolower($value), $allowedTargets, true)) {
                                $child->setAttribute('target', '_self');
                            }
                        }
                        if ($tag === 'a' && $attrName === 'rel') {
                            $parts = array_map('trim', explode(' ', strtolower($value)));
                            $parts[] = 'noopener';
                            $parts[] = 'nofollow';
                            $parts = array_unique(array_filter($parts));
                            $child->setAttribute('rel', implode(' ', $parts));
                        }
                        if ($tag === 'img' && $attrName === 'src') {
                            if ($value === '' || preg_match('#^javascript:#i', $value)) {
                                $child->removeAttribute('src');
                                continue;
                            }
                            if (preg_match('#^https?://#i', $value)) {
                                $allowed = false;
                                foreach ($this->allowedImageSrcPrefixes() as $prefix) {
                                    if ($prefix !== '' && stripos($value, $prefix) === 0) {
                                        $allowed = true;
                                        break;
                                    }
                                }
                                if (!$allowed) {
                                    $child->removeAttribute('src');
                                    continue;
                                }
                            }
                        }
                    }
                }

                if ($tag === 'img' && !$child->hasAttribute('alt')) {
                    $child->setAttribute('alt', '');
                }

                $this->sanitizeCmsNode($child);
            } elseif ($child instanceof DOMComment) {
                $node->removeChild($child);
            }
        }
    }

    /**
     * @param array<int, array<string, mixed>> $pages
     * @return bool|array<int, array{id:int, slug:string}>
     */
    private function persistPages(array $pages, string $defaultLang, bool $withResult, string $context)
    {
        if (!$pages) {
            return $withResult ? [] : true;
        }

        try {
            $this->db->beginTransaction();
            $now = time();
            $results = [];

            foreach ($pages as $page) {
                $pageId = isset($page['id']) ? (int) $page['id'] : 0;
                $requestedSlug = isset($page['slug']) ? (string) $page['slug'] : '';
                $defaultTitle = isset($page['default_title']) ? (string) $page['default_title'] : '';
                $isActive = !empty($page['is_active']) ? 1 : 0;
                $sortOrder = isset($page['sort_order']) ? (int) $page['sort_order'] : 0;
                $translations = isset($page['translations']) && is_array($page['translations']) ? $page['translations'] : [];

                if ($defaultTitle === '') {
                    throw new InvalidArgumentException('default_title_required');
                }

                $slug = $this->sanitizePageSlug($requestedSlug !== '' ? $requestedSlug : $defaultTitle);
                $slug = $this->ensureUniquePageSlug($slug, $pageId);

                if ($pageId > 0) {
                    $stmt = $this->db->prepare('UPDATE i_pages SET slug = :slug, is_active = :active, sort_order = :sort, updated_at = :updated WHERE id = :id');
                    $stmt->bindValue(':slug', $slug, PDO::PARAM_STR);
                    $stmt->bindValue(':active', $isActive, PDO::PARAM_INT);
                    $stmt->bindValue(':sort', $sortOrder, PDO::PARAM_INT);
                    $stmt->bindValue(':updated', $now, PDO::PARAM_INT);
                    $stmt->bindValue(':id', $pageId, PDO::PARAM_INT);
                    $stmt->execute();

                    $del = $this->db->prepare('DELETE FROM i_page_content WHERE page_id = :pid');
                    $del->bindValue(':pid', $pageId, PDO::PARAM_INT);
                    $del->execute();
                } else {
                    $stmt = $this->db->prepare('INSERT INTO i_pages (slug, is_active, sort_order, created_at, updated_at) VALUES (:slug, :active, :sort, :created, :updated)');
                    $stmt->bindValue(':slug', $slug, PDO::PARAM_STR);
                    $stmt->bindValue(':active', $isActive, PDO::PARAM_INT);
                    $stmt->bindValue(':sort', $sortOrder, PDO::PARAM_INT);
                    $stmt->bindValue(':created', $now, PDO::PARAM_INT);
                    $stmt->bindValue(':updated', $now, PDO::PARAM_INT);
                    $stmt->execute();
                    $pageId = (int) $this->db->lastInsertId();
                    if ($pageId <= 0) {
                        throw new RuntimeException('page_insert_failed');
                    }
                }

                if ($translations) {
                    $insert = $this->db->prepare('INSERT INTO i_page_content (page_id, lang, title, content_html) VALUES (:pid, :lang, :title, :content)');
                    foreach ($translations as $langCode => $payload) {
                        $langCode = strtolower((string) $langCode);
                        $title = isset($payload['title']) ? trim((string) $payload['title']) : '';
                        $contentRaw = isset($payload['content']) ? (string) $payload['content'] : '';
                        if ($langCode === $defaultLang && $title === '') {
                            throw new InvalidArgumentException('default_title_required');
                        }
                        if ($title === '' && $contentRaw === '') {
                            continue;
                        }
                        $sanitizedContent = $this->sanitizeCmsHtml($contentRaw);
                        $insert->bindValue(':pid', $pageId, PDO::PARAM_INT);
                        $insert->bindValue(':lang', $langCode, PDO::PARAM_STR);
                        $insert->bindValue(':title', $title, PDO::PARAM_STR);
                        $insert->bindValue(':content', $sanitizedContent, PDO::PARAM_STR);
                        $insert->execute();
                    }
                }

                if ($withResult) {
                    $results[] = ['id' => $pageId, 'slug' => $slug];
                }
            }

            $this->db->commit();
            return $withResult ? $results : true;
        } catch (InvalidArgumentException $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            if (method_exists($this, 'logError')) {
                $this->logError($context . ' failed: ' . $e->getMessage());
            }
            return $withResult ? [] : false;
        }
    }
}
