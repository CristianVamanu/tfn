<?php
declare(strict_types=1);
trait LikeFunctions {
    /** Ensure i_post_liked schema matches current expectations. */
    private function RL_EnsurePostLikeTable(): void
    {
        static $ensured = false;
        if ($ensured) { return; }
        $ensured = true;

        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_post_liked (
                like_id INT NOT NULL AUTO_INCREMENT,
                liked_item_id INT DEFAULT NULL,
                liked_item_type ENUM('post','comment') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
                uid_fk INT DEFAULT NULL,
                liked_time INT DEFAULT NULL,
                PRIMARY KEY (like_id),
                KEY idx_item_type (liked_item_id, liked_item_type),
                KEY idx_user (uid_fk)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
        } catch (\Throwable $__) {
            return;
        }

        try {
            $columns = [];
            $stmt = $this->db->query('SHOW COLUMNS FROM i_post_liked');
            if ($stmt) {
                while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                    if (!is_array($row) || !isset($row['Field'])) { continue; }
                    $columns[$row['Field']] = $row;
                }
            }

            $execSafe = function(string $sql): void {
                try { $this->db->exec($sql); } catch (\Throwable $__) {}
            };

            if (!isset($columns['like_id'])) {
                $execSafe("ALTER TABLE i_post_liked ADD COLUMN like_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST");
            } else {
                $extra = strtolower((string)($columns['like_id']['Extra'] ?? ''));
                if (strpos($extra, 'auto_increment') === false) {
                    $execSafe("ALTER TABLE i_post_liked MODIFY like_id INT NOT NULL AUTO_INCREMENT");
                }
            }

            try {
                $hasPrimary = false;
                $idxStmt = $this->db->query("SHOW INDEX FROM i_post_liked WHERE Key_name = 'PRIMARY'");
                if ($idxStmt && $idxStmt->fetch()) { $hasPrimary = true; }
                if (!$hasPrimary) {
                    $execSafe("ALTER TABLE i_post_liked ADD PRIMARY KEY (like_id)");
                }
            } catch (\Throwable $__) {}

            if (!isset($columns['liked_item_type'])) {
                $execSafe("ALTER TABLE i_post_liked ADD COLUMN liked_item_type ENUM('post','comment') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post'");
            } else {
                $type = strtolower((string)($columns['liked_item_type']['Type'] ?? ''));
                if (strpos($type, "enum('post','comment')") === false) {
                    $execSafe("ALTER TABLE i_post_liked MODIFY liked_item_type ENUM('post','comment','image','video') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post'");
                }
            }

            try {
                $this->db->exec("UPDATE i_post_liked SET liked_item_type = 'post' WHERE liked_item_type IN ('image','video')");
            } catch (\Throwable $__) {}

            try {
                $this->db->exec("ALTER TABLE i_post_liked MODIFY liked_item_type ENUM('post','comment') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post'");
            } catch (\Throwable $__) {}

            try {
                $this->db->exec("DELETE t1 FROM i_post_liked t1
                                  INNER JOIN i_post_liked t2
                                    ON t1.liked_item_id = t2.liked_item_id
                                   AND t1.liked_item_type = t2.liked_item_type
                                   AND t1.uid_fk = t2.uid_fk
                                   AND t1.like_id > t2.like_id");
            } catch (\Throwable $__) {}

            try {
                $this->db->exec('ALTER TABLE i_post_liked ADD UNIQUE KEY uniq_post_like (liked_item_id, liked_item_type, uid_fk)');
            } catch (\Throwable $__) {}
        } catch (\Throwable $__) {
            // ignore schema introspection issues
        }
    }
    /* ===========================
     *  Live Like Helpers
     *  Table: i_live_likes (created on demand)
     *  Columns:
     *    id (PK, AI)
     *    live_id (int)
     *    uid_fk (int)
     *    liked_time (int)
     *  Unique: (live_id, uid_fk)
     * =========================== */

    private function ensureLiveLikesTable(): void
    {
        try {
            $sql = "CREATE TABLE IF NOT EXISTS i_live_likes (
                        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                        live_id INT UNSIGNED NOT NULL,
                        uid_fk INT UNSIGNED NOT NULL,
                        liked_time INT UNSIGNED NULL,
                        PRIMARY KEY (id),
                        UNIQUE KEY uniq_live_user (live_id, uid_fk),
                        KEY idx_live (live_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
            $this->db->exec($sql);
        } catch (\Throwable $__) {
            // best-effort; errors will be logged at call sites
        }
    }

    public function RL_HasLikedLive(int $userID, int $liveID): bool
    {
        if ($userID <= 0 || $liveID <= 0) { return false; }
        $this->ensureLiveLikesTable();
        try {
            $st = $this->db->prepare("SELECT id FROM i_live_likes WHERE live_id = :l AND uid_fk = :u LIMIT 1");
            $st->bindValue(':l', $liveID, \PDO::PARAM_INT);
            $st->bindValue(':u', $userID, \PDO::PARAM_INT);
            $st->execute();
            return (bool)$st->fetchColumn();
        } catch (\Throwable $e) {
            $this->logError('RL_HasLikedLive failed: ' . $e->getMessage());
            return false;
        }
    }

    public function RL_LikeLive(int $userID, int $liveID, int $time): bool
    {
        if ($userID <= 0 || $liveID <= 0) { return false; }
        $this->ensureLiveLikesTable();
        try {
            $st = $this->db->prepare("INSERT IGNORE INTO i_live_likes (live_id, uid_fk, liked_time) VALUES (:l,:u,:t)");
            $st->bindValue(':l', $liveID, \PDO::PARAM_INT);
            $st->bindValue(':u', $userID, \PDO::PARAM_INT);
            $st->bindValue(':t', $time,   \PDO::PARAM_INT);
            return $st->execute();
        } catch (\Throwable $e) {
            $this->logError('RL_LikeLive failed: ' . $e->getMessage());
            return false;
        }
    }

    public function RL_UnlikeLive(int $userID, int $liveID): bool
    {
        if ($userID <= 0 || $liveID <= 0) { return false; }
        $this->ensureLiveLikesTable();
        try {
            $st = $this->db->prepare("DELETE FROM i_live_likes WHERE live_id = :l AND uid_fk = :u");
            $st->bindValue(':l', $liveID, \PDO::PARAM_INT);
            $st->bindValue(':u', $userID, \PDO::PARAM_INT);
            return $st->execute();
        } catch (\Throwable $e) {
            $this->logError('RL_UnlikeLive failed: ' . $e->getMessage());
            return false;
        }
    }

    public function RL_CountLiveLikes(int $liveID): int
    {
        if ($liveID <= 0) { return 0; }
        $this->ensureLiveLikesTable();
        try {
            $st = $this->db->prepare("SELECT COUNT(*) FROM i_live_likes WHERE live_id = :l");
            $st->bindValue(':l', $liveID, \PDO::PARAM_INT);
            $st->execute();
            return (int)$st->fetchColumn();
        } catch (\Throwable $e) {
            $this->logError('RL_CountLiveLikes failed: ' . $e->getMessage());
            return 0;
        }
    }

    /** Toggle like for live; returns [likedNow, totalLikes] */
    public function RL_ToggleLiveLike(int $userID, int $liveID, int $time): array
    {
        // Avoid wrapping DDL (CREATE TABLE IF NOT EXISTS) in a transaction.
        // Ensure table exists before toggling to prevent implicit commits
        // that would otherwise break commit()/rollback() calls.
        $this->ensureLiveLikesTable();
        try {
            $likedNow = false;
            if ($this->RL_HasLikedLive($userID, $liveID)) {
                $this->RL_UnlikeLive($userID, $liveID);
                $likedNow = false;
            } else {
                $this->RL_LikeLive($userID, $liveID, $time);
                $likedNow = true;
            }
            $likes = $this->RL_CountLiveLikes($liveID);
            return [$likedNow, $likes];
        } catch (\Throwable $e) {
            $this->logError('RL_ToggleLiveLike failed: ' . $e->getMessage());
            return [false, 0];
        }
    }
    /**
     * Check if the user already liked an item.
     *
     * @param int    $userID
     * @param int    $itemID
     * @param string $itemType  'post' or 'comment'
     */
    public function RL_HasLiked(int $userID, int $itemID, string $itemType = 'post'): bool
    {
        $this->RL_EnsurePostLikeTable();
        try {
            $sql = "SELECT like_id
                    FROM i_post_liked
                    WHERE liked_item_id = :item
                    AND liked_item_type = :type
                    AND uid_fk = :uid
                    LIMIT 1";
            $st = $this->db->prepare($sql);
            $st->bindValue(':item', $itemID, \PDO::PARAM_INT);
            $st->bindValue(':type', $itemType, \PDO::PARAM_STR);
            $st->bindValue(':uid',  $userID, \PDO::PARAM_INT);
            $st->execute();
            return (bool) $st->fetchColumn();
        } catch (\Throwable $e) {
            $this->logError('RL_HasLiked failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Insert a like (one-way, no toggle).
     *
     * @param int    $userID
     * @param int    $itemID
     * @param int    $time
     * @param string $itemType
     */
    public function RL_LikePost(int $userID, int $itemID, int $time, string $itemType = 'post'): bool
    {
        $this->RL_EnsurePostLikeTable();
        try {
            $sql = "INSERT INTO i_post_liked (liked_item_id, liked_item_type, uid_fk, liked_time)
                    VALUES (:item, :type, :uid, :t)";
            $st = $this->db->prepare($sql);
            $st->bindValue(':item', $itemID, \PDO::PARAM_INT);
            $st->bindValue(':type', $itemType, \PDO::PARAM_STR);
            $st->bindValue(':uid',  $userID, \PDO::PARAM_INT);
            $st->bindValue(':t',    $time,   \PDO::PARAM_INT);
            return $st->execute();
        } catch (\Throwable $e) {
            $this->logError('RL_LikePost failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Remove a like (unlike).
     *
     * @param int    $userID
     * @param int    $itemID
     * @param string $itemType
     */
    public function RL_UnlikePost(int $userID, int $itemID, string $itemType = 'post'): bool
    {
        $this->RL_EnsurePostLikeTable();
        try {
            $sql = "DELETE FROM i_post_liked
                    WHERE liked_item_id = :item
                    AND liked_item_type = :type
                    AND uid_fk = :uid";
            $st = $this->db->prepare($sql);
            $st->bindValue(':item', $itemID, \PDO::PARAM_INT);
            $st->bindValue(':type', $itemType, \PDO::PARAM_STR);
            $st->bindValue(':uid',  $userID, \PDO::PARAM_INT);
            return $st->execute();
        } catch (\Throwable $e) {
            $this->logError('RL_UnlikePost failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Count total likes for an item.
     *
     * @param int    $itemID
     * @param string $itemType
     */
    public function RL_CountLikes(int $itemID, string $itemType = 'post'): int
    {
        $this->RL_EnsurePostLikeTable();
        try {
            $sql = "SELECT COUNT(*)
                    FROM i_post_liked
                    WHERE liked_item_id = :item
                    AND liked_item_type = :type";
            $st = $this->db->prepare($sql);
            $st->bindValue(':item', $itemID, \PDO::PARAM_INT);
            $st->bindValue(':type', $itemType, \PDO::PARAM_STR);
            $st->execute();
            return (int) $st->fetchColumn();
        } catch (\Throwable $e) {
            $this->logError('RL_CountLikes failed: ' . $e->getMessage());
            return 0;
        }
    }

    /**
     * Toggle like; returns [bool $likedNow, int $totalLikes].
     *
     * @param int    $userID
     * @param int    $itemID
     * @param int    $time
     * @param string $itemType
     * @return array{0: bool, 1: int}
     */
    public function RL_ToggleLike(int $userID, int $itemID, int $time, string $itemType = 'post'): array
    {
        $this->RL_EnsurePostLikeTable();
        try {
            $this->db->beginTransaction();

            if ($this->RL_HasLiked($userID, $itemID, $itemType)) {
                $this->RL_UnlikePost($userID, $itemID, $itemType);
                $likedNow = false;
            } else {
                $this->RL_LikePost($userID, $itemID, $time, $itemType);
                $likedNow = true;
            }

            $likes = $this->RL_CountLikes($itemID, $itemType);
            $this->db->commit();

            return [$likedNow, $likes];
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            $this->logError('RL_ToggleLike failed: ' . $e->getMessage());
            return [false, 0];
        }
    }

    /* ===========================
     *  Comment Like Helpers
     *  Table: i_comment_liked
     *  Columns:
     *    c_like_id (PK, AI)
     *    c_liked_post_id
     *    c_liked_comment_id
     *    liked_item_type ENUM('video','image') DEFAULT 'video'
     *    uid_fk
     *    liked_time
     * =========================== */

    /** Check if the user liked a specific comment. */
    public function RL_HasLikedComment(int $userID, int $postID, int $commentID, string $itemType = 'video'): bool
    {
        try {
            $sql = "SELECT c_like_id
                      FROM i_comment_liked
                     WHERE c_liked_post_id = :pid
                       AND c_liked_comment_id = :cid
                       AND liked_item_type = :type
                       AND uid_fk = :uid
                     LIMIT 1";
            $st = $this->db->prepare($sql);
            $st->bindValue(':pid',  $postID,    \PDO::PARAM_INT);
            $st->bindValue(':cid',  $commentID, \PDO::PARAM_INT);
            $st->bindValue(':type', $itemType,  \PDO::PARAM_STR);
            $st->bindValue(':uid',  $userID,    \PDO::PARAM_INT);
            $st->execute();
            return (bool) $st->fetchColumn();
        } catch (\Throwable $e) {
            $this->logError('RL_HasLikedComment failed: ' . $e->getMessage());
            return false;
        }
    }

    /** Add a like to a comment. */
    public function RL_LikeComment(int $userID, int $postID, int $commentID, int $time, string $itemType = 'video'): bool
    {
        try {
            $sql = "INSERT INTO i_comment_liked (c_liked_post_id, c_liked_comment_id, liked_item_type, uid_fk, liked_time)
                    VALUES (:pid, :cid, :type, :uid, :t)";
            $st = $this->db->prepare($sql);
            $st->bindValue(':pid',  $postID,    \PDO::PARAM_INT);
            $st->bindValue(':cid',  $commentID, \PDO::PARAM_INT);
            $st->bindValue(':type', $itemType,  \PDO::PARAM_STR);
            $st->bindValue(':uid',  $userID,    \PDO::PARAM_INT);
            $st->bindValue(':t',    $time,      \PDO::PARAM_INT);
            return $st->execute();
        } catch (\Throwable $e) {
            $this->logError('RL_LikeComment failed: ' . $e->getMessage());
            return false;
        }
    }

    /** Remove a like from a comment. */
    public function RL_UnlikeComment(int $userID, int $postID, int $commentID, string $itemType = 'video'): bool
    {
        try {
            $sql = "DELETE FROM i_comment_liked
                     WHERE c_liked_post_id = :pid
                       AND c_liked_comment_id = :cid
                       AND liked_item_type = :type
                       AND uid_fk = :uid";
            $st = $this->db->prepare($sql);
            $st->bindValue(':pid',  $postID,    \PDO::PARAM_INT);
            $st->bindValue(':cid',  $commentID, \PDO::PARAM_INT);
            $st->bindValue(':type', $itemType,  \PDO::PARAM_STR);
            $st->bindValue(':uid',  $userID,    \PDO::PARAM_INT);
            return $st->execute();
        } catch (\Throwable $e) {
            $this->logError('RL_UnlikeComment failed: ' . $e->getMessage());
            return false;
        }
    }

    /** Count total likes for a comment. */
    public function RL_CountCommentLikes(int $postID, int $commentID, string $itemType = 'video'): int
    {
        try {
            $sql = "SELECT COUNT(*)
                      FROM i_comment_liked
                     WHERE c_liked_post_id = :pid
                       AND c_liked_comment_id = :cid
                       AND liked_item_type = :type";
            $st = $this->db->prepare($sql);
            $st->bindValue(':pid',  $postID,    \PDO::PARAM_INT);
            $st->bindValue(':cid',  $commentID, \PDO::PARAM_INT);
            $st->bindValue(':type', $itemType,  \PDO::PARAM_STR);
            $st->execute();
            return (int) $st->fetchColumn();
        } catch (\Throwable $e) {
            $this->logError('RL_CountCommentLikes failed: ' . $e->getMessage());
            return 0;
        }
    }

    /**
     * Toggle like for a comment.
     * @return array{0: bool likedNow, 1: int totalLikes}
     */
    public function RL_ToggleCommentLike(int $userID, int $postID, int $commentID, int $time, string $itemType = 'video'): array
    {
        try {
            $this->db->beginTransaction();
            if ($this->RL_HasLikedComment($userID, $postID, $commentID, $itemType)) {
                $this->RL_UnlikeComment($userID, $postID, $commentID, $itemType);
                $likedNow = false;
            } else {
                $this->RL_LikeComment($userID, $postID, $commentID, $time, $itemType);
                $likedNow = true;
            }
            $likes = $this->RL_CountCommentLikes($postID, $commentID, $itemType);
            $this->db->commit();
            return [$likedNow, $likes];
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) { $this->db->rollBack(); }
            $this->logError('RL_ToggleCommentLike failed: ' . $e->getMessage());
            return [false, 0];
        }
    }

    /**
     * Resolve post owner id from i_user_posts.
     * Returns 0 if not found or on error.
     */
    public function RL_GetPostOwnerId(int $postID): int
    {
        if ($postID <= 0) { return 0; }
        try {
            $sql = "SELECT post_owner_id FROM i_user_posts WHERE post_id = :pid LIMIT 1";
            $st  = $this->db->prepare($sql);
            $st->bindValue(':pid', $postID, \PDO::PARAM_INT);
            $st->execute();
            return (int) $st->fetchColumn();
        } catch (\Throwable $e) {
            $this->logError('RL_GetPostOwnerId failed: ' . $e->getMessage());
            return 0;
        }
    }

    /**
     * Create one post_like notification for the given recipient.
     * object_id = post_id, parent_object_id = NULL
     * extra_data example: {"kind":"post","post_id":101}
     */
    public function RL_CreatePostLikeNotification(int $actorId, int $recipientId, int $postID, ?int $now = null): bool
    {
        $now = $now ?? time();
        if ($actorId <= 0 || $recipientId <= 0 || $postID <= 0) {
            return false;
        }
        if ($actorId === $recipientId) {
            // do not notify self-like (safety guard)
            return false;
        }
        try {
            $sql = "INSERT INTO i_notifications (recipient_id, actor_id, type, object_id, parent_object_id, extra_data, is_read, created_at)
                    VALUES (:rid, :aid, 'post_like', :oid, NULL, :extra, 0, :ts)";
            $st  = $this->db->prepare($sql);
            $extra = json_encode(['kind' => 'post', 'post_id' => $postID], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $st->bindValue(':rid',  $recipientId, \PDO::PARAM_INT);
            $st->bindValue(':aid',  $actorId,     \PDO::PARAM_INT);
            $st->bindValue(':oid',  $postID,      \PDO::PARAM_INT);
            $st->bindValue(':extra', (string)$extra, \PDO::PARAM_STR);
            $st->bindValue(':ts',   (int)$now,     \PDO::PARAM_INT);
            return $st->execute();
        } catch (\Throwable $e) {
            $this->logError('RL_CreatePostLikeNotification failed: ' . $e->getMessage());
            return false;
        }
    }
    /**
     * Delete a notification row by (recipient, actor, type, object_id[, parent_object_id]).
     *
     * For post likes, call with: RL_DeleteNotification($recipientId, $actorId, 'post_like', $postID)
     * For comment likes, include parent_object_id (post_id) if you store it: RL_DeleteNotification($recipientId, $actorId, 'comment_like', $commentID, $postID)
     */
    public function RL_DeleteNotification(
        int $recipientId,
        int $actorId,
        string $type,
        int $objectId,
        ?int $parentObjectId = null
    ): bool {
        try {
            if ($recipientId <= 0 || $actorId <= 0 || $objectId <= 0 || $type === '') {
                return false;
            }

            $sql = "DELETE FROM i_notifications
                    WHERE recipient_id = :rid
                      AND actor_id     = :aid
                      AND type         = :type
                      AND object_id    = :oid";

            if ($parentObjectId === null) {
                $sql .= " AND parent_object_id IS NULL";
            } else {
                $sql .= " AND parent_object_id = :poid";
            }

            $st = $this->db->prepare($sql);
            $st->bindValue(':rid',  $recipientId, \PDO::PARAM_INT);
            $st->bindValue(':aid',  $actorId,     \PDO::PARAM_INT);
            $st->bindValue(':type', $type,        \PDO::PARAM_STR);
            $st->bindValue(':oid',  $objectId,    \PDO::PARAM_INT);
            if ($parentObjectId !== null) {
                $st->bindValue(':poid', $parentObjectId, \PDO::PARAM_INT);
            }

            return $st->execute();
        } catch (\Throwable $e) {
            $this->logError('RL_DeleteNotification failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Resolve comment owner id from i_comments.
     * Returns 0 if not found or on error.
     */
    public function RL_GetCommentOwnerId(int $postID, int $commentID): int
    {
        if ($postID <= 0 || $commentID <= 0) { return 0; }
        try {
            $sql = "SELECT uid_fk FROM i_comments WHERE c_id = :cid AND item_id = :pid LIMIT 1";
            $st  = $this->db->prepare($sql);
            $st->bindValue(':cid', $commentID, \PDO::PARAM_INT);
            $st->bindValue(':pid', $postID,    \PDO::PARAM_INT);
            $st->execute();
            return (int) $st->fetchColumn();
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_GetCommentOwnerId failed: ' . $e->getMessage());
            }
            return 0;
        }
    }

    /**
     * Create one comment_like notification for the given recipient.
     * type=comment_like, object_id = comment_id, parent_object_id = post_id
     * extra_data example: {"kind":"comment","post_id":101,"comment_id":55}
     */
    public function RL_CreateCommentLikeNotification(int $actorId, int $recipientId, int $postID, int $commentID, ?int $now = null): bool
    {
        $now = $now ?? time();
        if ($actorId <= 0 || $recipientId <= 0 || $postID <= 0 || $commentID <= 0) {
            return false;
        }
        if ($actorId === $recipientId) {
            // do not notify self-like
            return false;
        }
        try {
            $sql = "INSERT INTO i_notifications (recipient_id, actor_id, type, object_id, parent_object_id, extra_data, is_read, created_at)
                    VALUES (:rid, :aid, 'comment_like', :oid, :poid, :extra, 0, :ts)";
            $st  = $this->db->prepare($sql);
            $extra = json_encode(['kind' => 'comment', 'post_id' => $postID, 'comment_id' => $commentID], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $st->bindValue(':rid',   $recipientId, \PDO::PARAM_INT);
            $st->bindValue(':aid',   $actorId,     \PDO::PARAM_INT);
            $st->bindValue(':oid',   $commentID,   \PDO::PARAM_INT);
            $st->bindValue(':poid',  $postID,      \PDO::PARAM_INT);
            $st->bindValue(':extra', (string)$extra, \PDO::PARAM_STR);
            $st->bindValue(':ts',    (int)$now,     \PDO::PARAM_INT);
            return $st->execute();
        } catch (\Throwable $e) {
            $this->logError('RL_CreateCommentLikeNotification failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Delete a comment_like notification helper.
     */
    public function RL_DeleteCommentLikeNotification(int $recipientId, int $actorId, int $postID, int $commentID): bool
    {
        return $this->RL_DeleteNotification($recipientId, $actorId, 'comment_like', $commentID, $postID);
    }
}
