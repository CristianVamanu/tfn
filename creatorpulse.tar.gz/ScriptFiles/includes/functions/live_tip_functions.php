<?php
declare(strict_types=1);

trait LiveTipFunctions
{
    private function ensureLiveTipEventsTable(): void
    {
        try {
            $sql = "CREATE TABLE IF NOT EXISTS i_live_tip_events (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                live_id INT UNSIGNED NOT NULL,
                buyer_name VARCHAR(120) NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                currency VARCHAR(12) NOT NULL,
                created_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                KEY idx_live_time (live_id, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
            $this->db->exec($sql);
        } catch (\Throwable $__) { /* ignore */ }
    }

    public function RL_InsertLiveTipEvent(int $liveId, string $buyerName, float $amount, string $currency, ?int $createdAt = null): bool
    {
        if ($liveId <= 0 || trim($buyerName) === '' || $amount <= 0) { return false; }
        $this->ensureLiveTipEventsTable();
        try {
            $st = $this->db->prepare('INSERT INTO i_live_tip_events (live_id, buyer_name, amount, currency, created_at) VALUES (:l,:b,:a,:c,:t)');
            $st->execute([
                ':l' => $liveId,
                ':b' => $buyerName,
                ':a' => $amount,
                ':c' => $currency,
                ':t' => $createdAt ?? time(),
            ]);
            return true;
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) { $this->logError('RL_InsertLiveTipEvent failed: ' . $e->getMessage()); }
            return false;
        }
    }

    /**
     * Fetch confirmed tips since $since (unix ts) for the live owner plus ephemeral events for this live.
     * Returns array of ['buyer'=>string,'amount'=>float,'currency'=>string,'ts'=>int]
     */
    public function RL_GetLiveTipsSince(int $liveId, int $since): array
    {
        $out = [];
        if ($liveId <= 0) { return $out; }
        try {
            // Resolve owner and started_at
            $st = $this->db->prepare('SELECT user_id, started_at FROM i_live_streams WHERE live_id = :l LIMIT 1');
            $st->execute([':l'=>$liveId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) { return $out; }
            $ownerId   = (int)($row['user_id'] ?? 0);
            $startedAt = (int)($row['started_at'] ?? 0);
            if ($since <= 0 || $since < $startedAt) { $since = $startedAt; }

            // Confirmed tips
            $q1 = $this->db->prepare('SELECT t.buyer_id, COALESCE(t.net_amount, t.amount) AS amount_base, t.currency, COALESCE(t.credited_at, t.created_at) AS ts,
                                             u.user_fullname, u.username
                                        FROM i_tip_payments t
                                        JOIN i_users u ON u.user_id = t.buyer_id
                                       WHERE t.recipient_id = :rid AND t.status = "succeeded" AND COALESCE(t.credited_at, t.created_at) > :since
                                       ORDER BY ts ASC
                                       LIMIT 50');
            $q1->execute([':rid'=>$ownerId, ':since'=>$since]);
            while ($r = $q1->fetch(\PDO::FETCH_ASSOC)) {
                $name = trim((string)($r['user_fullname'] ?? ''));
                if ($name === '') { $name = (string)($r['username'] ?? ''); }
                $out[] = [
                    'buyer'    => $name,
                    'amount'   => (float)$r['amount_base'],
                    'currency' => (string)$r['currency'],
                    'ts'       => (int)$r['ts'],
                ];
                $since = max($since, (int)$r['ts']);
            }

            // Ephemeral table
            $this->ensureLiveTipEventsTable();
            $q2 = $this->db->prepare('SELECT buyer_name, amount, currency, created_at AS ts
                                        FROM i_live_tip_events
                                       WHERE live_id = :lid AND created_at > :since
                                       ORDER BY created_at ASC
                                       LIMIT 50');
            $q2->execute([':lid'=>$liveId, ':since'=>$since]);
            while ($r = $q2->fetch(\PDO::FETCH_ASSOC)) {
                $out[] = [
                    'buyer'    => (string)$r['buyer_name'],
                    'amount'   => (float)$r['amount'],
                    'currency' => (string)$r['currency'],
                    'ts'       => (int)$r['ts'],
                ];
                $since = max($since, (int)$r['ts']);
            }

            // prune old ephemerals
            try { $this->db->prepare('DELETE FROM i_live_tip_events WHERE created_at < :t')->execute([':t'=>time()-600]); } catch (\Throwable $__) {}

            // Sort by ts
            usort($out, function($a,$b){ return ($a['ts'] <=> $b['ts']); });
            return $out;
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) { $this->logError('RL_GetLiveTipsSince failed: ' . $e->getMessage()); }
            return [];
        }
    }
}
