<?php
declare(strict_types=1);
trait NotificationFunctions {
    /** Render a human-readable message for a notification. */
    private function RL_FormatNotificationMessage(array $actors, string $type, ?int $objectId, array $extra): string
    {
        $names = [];
        foreach ($actors as $actor) {
            if (is_array($actor)) {
                if (!empty($actor['username'])) {
                    $names[] = (string) $actor['username'];
                    continue;
                }
                if (!empty($actor['handle'])) {
                    $names[] = (string) $actor['handle'];
                    continue;
                }
                if (!empty($actor['name'])) {
                    $names[] = (string) $actor['name'];
                    continue;
                }
            } elseif (is_string($actor) && $actor !== '') {
                $names[] = $actor;
            }
        }

        if ($names === []) {
            $names = ['Someone'];
        }

        $displayNames = array_slice($names, 0, 2);
        $othersCount = max(count($names) - 2, 0);
        $primary = $displayNames[0] ?? $names[0] ?? 'Someone';

        $kind = 'post';
        if (!empty($extra['kind'])) {
            $kind = (string) $extra['kind'];
        } elseif (!empty($extra['comment_id'])) {
            $kind = 'comment';
        }

        $fmtAmount = static function ($n): string {
            $f = (float) $n;
            if (abs($f - round($f)) < 1e-9) {
                return (string) round($f);
            }
            return number_format($f, 2, '.', '');
        };

        $curSymbol = static function (?string $c): string {
            $x = strtoupper((string) ($c ?? ''));
            if ($x === 'USD' || $x === '$' || $x === '') { return '$'; }
            if ($x === 'EUR' || $x === '€') { return '€'; }
            if ($x === 'GBP' || $x === '£') { return '£'; }
            if ($x === 'TRY' || $x === 'TL' || $x === '₺') { return '₺'; }
            if ($x === 'JPY' || $x === '¥') { return '¥'; }
            return $x;
        };

        switch ($type) {
            case 'post_like':
                if ($othersCount > 0) {
                    return sprintf(
                        '%s and %s others liked your %s.',
                        implode(', ', $displayNames),
                        number_format($othersCount),
                        $kind
                    );
                }
                return sprintf('%s liked your %s.', $primary, $kind);

            case 'comment':
                $excerpt = '';
                if (!empty($extra['comment_excerpt'])) {
                    $excerpt = ' “' . mb_strimwidth((string) $extra['comment_excerpt'], 0, 50, '…', 'UTF-8') . '”';
                }
                return sprintf('%s commented on your %s%s.', $primary, $kind, $excerpt);

            case 'comment_like':
                return sprintf('%s liked your comment.', $primary);

            case 'message_reaction':
                $reaction = strtolower((string) ($extra['reaction'] ?? ''));
                $reactionLabel = customLang('chat_reaction_' . $reaction, ucfirst($reaction ?: 'reaction'));
                $template = customLang('notification_message_reaction', '{user} reacted {reaction} to your message.');
                $message = str_replace(
                    ['{user}', '{reaction}'],
                    [$primary, $reactionLabel],
                    $template
                );
                if (!empty($extra['excerpt'])) {
                    $message .= ' "' . mb_strimwidth((string) $extra['excerpt'], 0, 50, '...', 'UTF-8') . '"';
                }
                return $message;

            case 'ebook_status':
                $status = strtolower((string)($extra['status'] ?? 'updated'));
                $title = trim((string)($extra['title'] ?? 'eBook'));
                if ($status === 'active') {
                    return strtr(customLang('notification_ebook_approved', 'Your eBook "{title}" was approved.'), ['{title}' => $title]);
                }
                if ($status === 'rejected') {
                    $text = strtr(customLang('notification_ebook_rejected', 'Your eBook "{title}" was rejected.'), ['{title}' => $title]);
                    $reason = trim((string)($extra['reason'] ?? ''));
                    return $reason !== '' ? $text . ' ' . $reason : $text;
                }
                return strtr(customLang('notification_ebook_updated', 'Your eBook "{title}" was updated.'), ['{title}' => $title]);

            case 'mention':
                return sprintf('%s mentioned you in a comment.', $primary);

            case 'follow':
                return sprintf('%s started following you.', $primary);

            case 'subscriber':
                return sprintf('%s subscribed to you.', $primary);

            case 'profile_view':
                return sprintf('%s viewed your profile.', $primary);

            case 'tip_payment':
                $amt  = isset($extra['amount']) ? (float) $extra['amount'] : 0.0;
                $curr = isset($extra['currency']) ? (string) $extra['currency'] : 'USD';
                $sym  = $curSymbol($curr);
                $amtTxt = $fmtAmount($amt) . ' ' . $sym;
                return sprintf('%s sent you %s tip.', $primary, $amtTxt);
            case 'tip_payment_receipt':
                $amtR  = isset($extra['amount']) ? (float) $extra['amount'] : 0.0;
                $currR = isset($extra['currency']) ? (string) $extra['currency'] : 'USD';
                $symR  = $curSymbol($currR);
                $amtTxtR = $fmtAmount($amtR) . ' ' . $symR;
                return sprintf('You tipped %s %s.', $primary, $amtTxtR);

            case 'subscription_payment':
                $amt  = isset($extra['amount']) ? (float) $extra['amount'] : null;
                $curr = isset($extra['currency']) ? (string) $extra['currency'] : 'USD';
                if ($amt !== null) {
                    $sym  = $curSymbol($curr);
                    $amtTxt = $fmtAmount($amt) . ' ' . $sym;
                    return sprintf('%s subscribed and paid %s.', $primary, $amtTxt);
                }
                return sprintf('%s subscribed to you.', $primary);

            case 'post_purchase':
                $amt  = isset($extra['amount']) ? (float) $extra['amount'] : 0.0;
                $curr = isset($extra['currency']) ? (string) $extra['currency'] : 'USD';
                $sym  = $curSymbol($curr);
                $amtTxt = $fmtAmount($amt) . ' ' . $sym;
                return sprintf('%s purchased your post for %s.', $primary, $amtTxt);

            case 'live_like':
                return sprintf('%s liked your live.', $primary);

            case 'creator_status':
                $state = strtolower((string) ($extra['status'] ?? 'pending'));
                $statusMsg = 'updated';
                if ($state === 'approved') { $statusMsg = 'approved'; }
                elseif ($state === 'rejected') { $statusMsg = 'rejected'; }
                elseif ($state === 'pending') { $statusMsg = 'under review'; }
                $base = sprintf('Your creator application was %s.', $statusMsg);
                if (!empty($extra['note'])) {
                    $base .= ' ' . (string) $extra['note'];
                }
                return $base;

            case 'podcast_ad_status':
                $statusValue = strtolower((string) ($extra['status'] ?? ''));
                $title = isset($extra['title']) ? trim((string) $extra['title']) : '';
                $title = $title !== '' ? $title : customLang('hero_ads_title', 'Podcast Hero Ads');
                $fallback = 'Your podcast hero ad was updated.';
                if ($statusValue === 'approved') {
                    $fallback = 'Podcast hero ad "{title}" was approved.';
                } elseif ($statusValue === 'rejected') {
                    $fallback = 'Podcast hero ad "{title}" was rejected.';
                } elseif ($statusValue === 'deleted') {
                    $fallback = 'Podcast hero ad "{title}" was removed.';
                } elseif ($statusValue === 'pending') {
                    $fallback = 'Podcast hero ad "{title}" is under review.';
                }
                $msg = customLang('notification_podcast_ad_status_' . $statusValue, $fallback);
                return str_replace('{title}', $title, $msg);

            case 'payout_status':
                $statusValue = isset($extra['status']) ? (string) $extra['status'] : 'pending';
                $statusNormalized = strtolower($statusValue);
                $statusLabel = customLang('settings_payout_status_' . $statusNormalized, ucfirst($statusNormalized));
                $methodLabel = isset($extra['method_label'])
                    ? (string) $extra['method_label']
                    : (isset($extra['method']) ? ucfirst((string) $extra['method']) : customLang('menu_payout_method', 'Payout method'));
                $base = sprintf('%s updated your payout method %s to %s.', $primary, $methodLabel, $statusLabel);
                if (!empty($extra['note'])) {
                    $base .= ' ' . (string) $extra['note'];
                }
                return $base;

            case 'withdrawal_status':
                $statusValue = isset($extra['status']) ? (string) $extra['status'] : 'pending';
                $statusNormalized = strtolower($statusValue);
                $statusLabel = customLang('withdrawal_status_' . $statusNormalized, ucfirst($statusNormalized));
                $identifier = '';
                if (!empty($extra['reference'])) {
                    $identifier = '#' . (string) $extra['reference'];
                } elseif (!empty($extra['payout_id'])) {
                    $identifier = '#' . (string) $extra['payout_id'];
                }
                $amountTxt = '';
                if (isset($extra['amount'])) {
                    $amountTxt = ' (' . $fmtAmount((float) $extra['amount']) . ' ' . $curSymbol(isset($extra['currency']) ? (string) $extra['currency'] : 'USD') . ')';
                }
                $base = sprintf('%s updated your withdrawal %s to %s%s.', $primary, $identifier !== '' ? $identifier : 'request', $statusLabel, $amountTxt);
                if (!empty($extra['note'])) {
                    $base .= ' ' . (string) $extra['note'];
                }
                return $base;

            case 'post_approval':
                $state = strtolower((string)($extra['status'] ?? 'approved'));
                if ($state === 'rejected') {
                    return customLang('notification_post_rejected', 'Your post was rejected.');
                }
                return customLang('notification_post_approved', 'Your post was approved.');

            default:
                return 'You have a new notification.';
        }
    }

    /** Latest notification meta for a user (created_at, type) */
    public function RL_GetLatestNotificationMeta(int $userId): array
    {
        try {
            $sql = 'SELECT
                        COALESCE(unread_meta.last_unread_ts, latest.last_ts, 0) AS last_ts,
                        COALESCE(unread_meta.unread_count, 0) AS unread_count,
                        COALESCE(unread_meta.last_unread_type, latest.last_type, "") AS last_type,
                        COALESCE(unread_meta.last_unread_is_read, latest.last_is_read, 0) AS last_is_read
                    FROM (
                        SELECT
                            MAX(created_at) AS last_ts,
                            (SELECT type FROM i_notifications WHERE recipient_id = :u2 ORDER BY created_at DESC, id DESC LIMIT 1) AS last_type,
                            (SELECT is_read FROM i_notifications WHERE recipient_id = :u3 ORDER BY created_at DESC, id DESC LIMIT 1) AS last_is_read
                        FROM i_notifications
                        WHERE recipient_id = :u1
                    ) AS latest
                    LEFT JOIN (
                        SELECT
                            MAX(created_at) AS last_unread_ts,
                            COUNT(*)        AS unread_count,
                            (SELECT type FROM i_notifications WHERE recipient_id = :u5 AND is_read = 0 ORDER BY created_at DESC, id DESC LIMIT 1) AS last_unread_type,
                            0 AS last_unread_is_read
                        FROM i_notifications
                        WHERE recipient_id = :u4 AND is_read = 0
                    ) AS unread_meta ON 1 = 1';
            $st = $this->db->prepare($sql);
            $st->bindValue(':u1', $userId, \PDO::PARAM_INT);
            $st->bindValue(':u2', $userId, \PDO::PARAM_INT);
            $st->bindValue(':u3', $userId, \PDO::PARAM_INT);
            $st->bindValue(':u4', $userId, \PDO::PARAM_INT);
            $st->bindValue(':u5', $userId, \PDO::PARAM_INT);
            $st->execute();
            $row = $st->fetch(\PDO::FETCH_ASSOC) ?: [];
            $returnTs = isset($row['last_ts']) ? (int)$row['last_ts'] : 0;
            return [
                'created_at'   => $returnTs,
                'type'         => isset($row['last_type']) ? (string)$row['last_type'] : '',
                'is_read'      => isset($row['last_is_read']) ? (int)$row['last_is_read'] : 0,
                'unread_count' => isset($row['unread_count']) ? (int)$row['unread_count'] : 0,
            ];
        } catch (\Throwable $__) { return ['created_at'=>0,'type'=>'','is_read'=>0,'unread_count'=>0]; }
    }
    /** Ensure notification.type enum has required custom types. Best-effort no-op if fails. */
    private function RL_EnsureNotificationPaymentTypes(): void
    {
        try {
            $col = $this->db->query("SHOW FULL COLUMNS FROM i_notifications LIKE 'type'")->fetch(\PDO::FETCH_ASSOC);
            if (!$col) {
                return;
            }
            $typeDef = (string) ($col['Type'] ?? '');
            if (stripos($typeDef, 'enum(') === false) {
                $typeDef = "enum('post_like','comment','comment_like','mention','follow','subscriber','profile_view','tip_payment','tip_payment_receipt','post_purchase','subscription_payment','live_like','creator_status','payout_status','withdrawal_status')";
            }
        $need = [
            "'tip_payment'",
            "'post_purchase'",
            "'subscription_payment'",
            "'live_like'",
            "'creator_status'",
            "'tip_payment_receipt'",
                "'payout_status'",
                "'withdrawal_status'",
                "'post_approval'",
                "'podcast_ad_status'",
                "'message_reaction'"
                ,"'ebook_status'"
            ];
            $missing = [];
            foreach ($need as $t) { if (strpos($typeDef, $t) === false) { $missing[] = $t; } }
            if (!$missing) { return; }
            // Build new enum list preserving existing order
            $inside = trim(substr($typeDef, 5), '()');
            $newDef = 'enum(' . $inside . ',' . implode(',', $missing) . ')';
            $collation = !empty($col['Collation']) ? (' COLLATE ' . $col['Collation']) : '';
            $sql = "ALTER TABLE i_notifications MODIFY COLUMN type $newDef$collation NOT NULL";
            $this->db->exec($sql);
        } catch (\Throwable $e) {
            // silent
        }
    }

    /** Create a notification row (generic). */
    private function RL_CreateNotification(int $recipientId, int $actorId, string $type, ?int $objectId, ?int $parentObjectId, array $extra, ?int $now = null): bool
    {
        if ($recipientId <= 0 || $actorId <= 0 || $type === '') { return false; }
        if ($recipientId === $actorId) { return false; }
        $now = $now ?? time();
        try {
            $stLast = $this->db->prepare('SELECT MAX(created_at) FROM i_notifications WHERE recipient_id = :rid');
            $stLast->bindValue(':rid', $recipientId, \PDO::PARAM_INT);
            $stLast->execute();
            $lastTs = (int) ($stLast->fetchColumn() ?: 0);
            if ($lastTs >= $now) {
                $now = $lastTs + 1;
            }
        } catch (\Throwable $__) {}
        try {
            $this->RL_EnsureNotificationPaymentTypes();
            $sql = "INSERT INTO i_notifications (recipient_id, actor_id, type, object_id, parent_object_id, extra_data, is_read, created_at)
                    VALUES (:rid, :aid, :type, :oid, :poid, :extra, 0, :ts)";
            $st  = $this->db->prepare($sql);
            $st->bindValue(':rid',  $recipientId, \PDO::PARAM_INT);
            $st->bindValue(':aid',  $actorId,     \PDO::PARAM_INT);
            $st->bindValue(':type', $type,        \PDO::PARAM_STR);
            if ($objectId !== null) { $st->bindValue(':oid',  $objectId, \PDO::PARAM_INT); } else { $st->bindValue(':oid', null, \PDO::PARAM_NULL); }
            if ($parentObjectId !== null) { $st->bindValue(':poid', $parentObjectId, \PDO::PARAM_INT); } else { $st->bindValue(':poid', null, \PDO::PARAM_NULL); }
            $extraPayload = is_array($extra) ? $extra : [];
            $st->bindValue(':extra', json_encode($extraPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
            $st->bindValue(':ts',   (int)$now, \PDO::PARAM_INT);
            $ok = $st->execute();
            if ($ok) {
                $this->RL_HandleNotificationDelivery(
                    $recipientId,
                    $actorId,
                    $type,
                    $objectId,
                    $parentObjectId,
                    $extraPayload,
                    (int) $now
                );
            }
            return $ok;
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) { $this->logError('RL_CreateNotification generic failed: ' . $e->getMessage()); }
            return false;
        }
    }

    /** Message reaction notification. */
    public function RL_CreateMessageReactionNotification(int $actorId, int $recipientId, int $messageId, string $reaction, string $excerpt = '', ?int $now = null): bool
    {
        $reaction = strtolower(trim($reaction));
        if ($messageId <= 0 || $reaction === '' || $actorId <= 0 || $recipientId <= 0 || $actorId === $recipientId) {
            return false;
        }

        try {
            $cleanup = $this->db->prepare('DELETE FROM i_notifications
                                            WHERE recipient_id = :rid
                                              AND actor_id = :aid
                                              AND type = "message_reaction"
                                              AND object_id = :mid');
            $cleanup->execute([
                ':rid' => $recipientId,
                ':aid' => $actorId,
                ':mid' => $messageId,
            ]);
        } catch (\Throwable $__) {}

        $extra = [
            'context' => 'message_reaction',
            'message_id' => $messageId,
            'reaction' => $reaction,
            'excerpt' => mb_substr(trim($excerpt), 0, 140),
        ];
        return $this->RL_CreateNotification($recipientId, $actorId, 'message_reaction', $messageId, null, $extra, $now);
    }

    public function RL_CreateEbookStatusNotification(int $actorId, int $recipientId, int $ebookId, string $status, string $title, string $reason = '', ?int $now = null): bool
    {
        if ($ebookId <= 0 || $actorId <= 0 || $recipientId <= 0) { return false; }
        $extra = ['context'=>'ebook_status','ebook_id'=>$ebookId,'status'=>strtolower(trim($status)),'title'=>mb_substr(trim($title),0,190),'reason'=>mb_substr(trim($reason),0,500)];
        return $this->RL_CreateNotification($recipientId,$actorId,'ebook_status',$ebookId,null,$extra,$now);
    }

    /** Tip payment succeeded (notify recipient). */
    public function RL_CreateTipPaymentNotification(int $buyerId, int $recipientId, int $postId, float $amountToCreator, string $currency, string $reference, ?int $now = null): bool
    {
        $extra = [
            'context'   => 'tip_payment',
            'post_id'   => $postId,
            'amount'    => (float)$amountToCreator,
            'currency'  => $currency,
            'reference' => $reference,
        ];
        return $this->RL_CreateNotification($recipientId, $buyerId, 'tip_payment', $postId, null, $extra, $now);
    }

    /** Tip payment succeeded (notify buyer with receipt). */
    public function RL_CreateTipReceiptNotification(int $buyerId, int $recipientId, int $postId, float $amount, string $currency, string $reference, ?int $now = null): bool
    {
        if ($buyerId <= 0 || $recipientId <= 0 || $buyerId === $recipientId) {
            return false;
        }
        $extra = [
            'context'   => 'tip_payment_receipt',
            'post_id'   => $postId,
            'amount'    => (float)$amount,
            'currency'  => $currency,
            'reference' => $reference,
        ];
        return $this->RL_CreateNotification($buyerId, $recipientId, 'tip_payment_receipt', $postId, null, $extra, $now);
    }

    /** Post purchase succeeded (notify recipient). */
    public function RL_CreatePostPurchaseNotification(int $buyerId, int $recipientId, int $postId, float $amountToCreator, string $currency, string $reference, ?int $now = null): bool
    {
        $extra = [
            'context'   => 'post_purchase',
            'post_id'   => $postId,
            'amount'    => (float)$amountToCreator,
            'currency'  => $currency,
            'reference' => $reference,
        ];
        return $this->RL_CreateNotification($recipientId, $buyerId, 'post_purchase', $postId, null, $extra, $now);
    }

    /** Subscription payment succeeded (notify recipient). */
    public function RL_CreateSubscriptionPaymentNotification(int $buyerId, int $recipientId, ?float $amountToCreator, string $currency, string $reference, array $meta = [], ?int $now = null): bool
    {
        $extra = array_merge([
            'context'   => 'subscription_payment',
            'amount'    => $amountToCreator !== null ? (float)$amountToCreator : null,
            'currency'  => $currency,
            'reference' => $reference,
        ], $meta);
        return $this->RL_CreateNotification($recipientId, $buyerId, 'subscription_payment', null, null, $extra, $now);
    }

    /** Live like notification (actor liked recipient's live). */
    public function RL_CreateLiveLikeNotification(int $actorId, int $recipientId, int $liveID, ?int $now = null): bool
    {
        $extra = [ 'kind' => 'live', 'live_id' => $liveID ];
        return $this->RL_CreateNotification($recipientId, $actorId, 'live_like', $liveID, null, $extra, $now);
    }
    /** Post approval status notification (admin -> owner). */
    public function RL_CreatePostApprovalNotification(int $ownerId, int $adminId, int $postId, string $status, ?string $note = null, ?int $now = null): bool
    {
        if ($ownerId <= 0 || $adminId <= 0 || $ownerId === $adminId || $postId <= 0) {
            return false;
        }
        $normalized = strtolower(trim($status));
        if (!in_array($normalized, ['approved','rejected','pending'], true)) {
            $normalized = 'approved';
        }
        $extra = [
            'context' => 'post_approval',
            'status'  => $normalized,
            'note'    => $note !== null && trim($note) !== '' ? trim($note) : null,
            'post_id' => $postId,
        ];
        return $this->RL_CreateNotification($ownerId, $adminId, 'post_approval', $postId, null, $extra, $now);
    }
    /** Creator onboarding status notification (admin -> user). */
    public function RL_CreateCreatorStatusNotification(int $recipientId, int $adminId, string $status, string $reason = ''): bool
    {
        $normalized = strtolower($status);
        if (!in_array($normalized, ['pending','approved','rejected'], true)) {
            $normalized = 'pending';
        }
        $extra = [
            'context' => 'creator_status',
            'status'  => $normalized,
            'note'    => $reason !== '' ? $reason : null,
        ];
        return $this->RL_CreateNotification($recipientId, $adminId, 'creator_status', null, null, $extra);
    }
    /**
     * Fetch notifications for the given user.
     * - Joins actor info from i_users.
     * - Groups consecutive post_like notifications for the same object within a time window.
     * - Returns a normalized array usable by your existing HTML list template.
     *
     * @param int $userID   Notification recipient user_id.
     * @param int $limit    Max items to return after grouping.
     * @param int $offset   Pagination offset (applied after grouping).
     * @return array<int, array<string, mixed>>
     */
    public function RL_GetMyNotifications(int $userID, int $limit = 20, int $offset = 0): array
    {
        try {
            // 1) Fetch raw notifications first (we take more than needed to allow grouping)
            $rawLimit = max($limit * 4, 80); // give room for grouping
            $sql = "
                SELECT
                    n.id,
                    n.recipient_id,
                    n.actor_id,
                    n.type,
                    n.object_id,
                    n.parent_object_id,
                    n.extra_data,
                    n.is_read,
                    n.created_at,
                    n.read_at,
                    u.username,
                    u.user_fullname,
                    u.user_avatar,
                    u.verified_status
                FROM i_notifications AS n
                INNER JOIN i_users AS u ON u.user_id = n.actor_id
                WHERE n.recipient_id = :uid
                  AND n.type <> 'message_reaction'
                ORDER BY n.created_at DESC, n.id DESC
                LIMIT :lim
            ";
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':uid', $userID, PDO::PARAM_INT);
            $stmt->bindValue(':lim', $rawLimit, PDO::PARAM_INT);
            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (!$rows) {
                return [];
            }

            // 2) Grouping config
            $likeWindowSeconds = 72 * 3600; // 72 hours window for grouping likes
            $grouped = [];
            $usedIds = [];

            // 3) Walk through rows and group post_like by (object_id) within window
            foreach ($rows as $i => $r) {
                if (isset($usedIds[$r['id']])) {
                    continue;
                }

                $type = (string) $r['type'];
                $objectId = isset($r['object_id']) ? (int) $r['object_id'] : null;
                $createdAt = (int) $r['created_at'];
                $extra = [];
                if (!empty($r['extra_data'])) {
                    $decoded = json_decode((string) $r['extra_data'], true);
                    if (is_array($decoded)) {
                        $extra = $decoded;
                    }
                }

                // Start a group with current row
                $groupActors = [[
                    'username' => (string) ($r['user_fullname'] ?: $r['username']),
                    // show handle (username) in UI-like message;
                    // but for avatar/name fields below we still pass actor[0] user info.
                    'handle'   => (string) $r['username'],
                    'avatar'   => (string) $r['user_avatar'],
                    'verified' => (int) $r['verified_status'],
                ]];
                $latestTs = $createdAt;

                if ($type === 'post_like' && $objectId) {
                    // Look ahead for same object within the time window to merge
                    for ($j = $i + 1; $j < count($rows); $j++) {
                        $r2 = $rows[$j];
                        if ((int) $r2['created_at'] < ($createdAt - $likeWindowSeconds)) {
                            break; // too old for grouping
                        }
                        if (
                            (string) $r2['type'] === 'post_like'
                            && (int) $r2['object_id'] === $objectId
                            && !isset($usedIds[$r2['id']])
                        ) {
                            $groupActors[] = [
                                'username' => (string) ($r2['user_fullname'] ?: $r2['username']),
                                'handle'   => (string) $r2['username'],
                                'avatar'   => (string) $r2['user_avatar'],
                                'verified' => (int) $r2['verified_status'],
                            ];
                            $latestTs = max($latestTs, (int) $r2['created_at']);
                            $usedIds[$r2['id']] = true;
    }
}

}

                // Build final, display-ready row
                // Choose first actor as the visible avatar/name in the list
                $first = $groupActors[0];
                $actorsForMessage = array_map(
                    static fn (array $a): string => (string) $a['handle'],
                    $groupActors
                );
                $message = $this->RL_FormatNotificationMessage($actorsForMessage, $type, $objectId, $extra);

                $grouped[] = [
                    // UI expects handle for title line
                    'username'        => $first['handle'],
                    // Kept for backward-compatibility but not used in notifications UI
                    'fullname'        => $first['username'],
                    // First element is the latest actor due to DESC order
                    'avatar'          => $first['avatar'],
                    // Explicit field for template to use latest actor avatar
                    'avatar_last'     => $first['avatar'],
                    'verified_status' => $first['verified'],
                    'last_message'    => $message,
                    'last_time'       => $latestTs, // UNIX timestamp; RelativeTime will format
                    'type'            => $type,
                    'object_id'       => $objectId,
                    'parent_object_id'=> isset($r['parent_object_id']) ? (int)$r['parent_object_id'] : null,
                    'extra'           => $extra,
                ];

                $usedIds[$r['id']] = true;

                if (count($grouped) >= ($limit + $offset)) {
                    break;
                }
            }

            // 4) Apply offset/limit after grouping
            $paged = array_slice($grouped, $offset, $limit);

            return $paged;
        } catch (Throwable $e) {
            $this->logError('RL_GetMyNotifications failed: ' . $e->getMessage());
            return [];
        }
    }

    /** Deliver notification via enabled channels (email/push). */
    private function RL_HandleNotificationDelivery(
        int $recipientId,
        int $actorId,
        string $type,
        ?int $objectId,
        ?int $parentObjectId,
        array $extra,
        int $createdAt
    ): void {
        try {
            $prefs = null;
            if (method_exists($this, 'RL_GetUserPreferences')) {
                static $prefCache = [];
                if (!isset($prefCache[$recipientId])) {
                    $prefCache[$recipientId] = (array) $this->RL_GetUserPreferences($recipientId);
                }
                $prefs = $prefCache[$recipientId];
            }

            $emailEnabled = $prefs === null || !array_key_exists('notify_email', $prefs) ? true : (bool) $prefs['notify_email'];
            $pushEnabled = $prefs === null || !array_key_exists('notify_push', $prefs) ? true : (bool) $prefs['notify_push'];
            $smsEnabled = $prefs !== null && array_key_exists('notify_sms', $prefs) ? (bool) $prefs['notify_sms'] : false;

            if (!method_exists($this, 'RL_GetUserDetails')) {
                return;
            }

            $recipient = (array) $this->RL_GetUserDetails($recipientId);
            if (isset($recipient['error'])) {
                return;
            }

            $email = '';
            $phone = '';
            foreach (['contact_email', 'user_email'] as $field) {
                if (!empty($recipient[$field]) && filter_var((string) $recipient[$field], FILTER_VALIDATE_EMAIL)) {
                    $email = (string) $recipient[$field];
                    break;
                }
            }

            if (!empty($recipient['user_phone'])) {
                $phoneCandidate = preg_replace('/[^0-9+]/', '', (string) $recipient['user_phone']);
                if (is_string($phoneCandidate) && $phoneCandidate !== '' && preg_match('/^\\+?[0-9]{8,20}$/', $phoneCandidate)) {
                    $phone = $phoneCandidate;
                }
            }
            $emailAvailable = $email !== '';
            $recipientName = (string) ($recipient['user_fullname'] ?? $recipient['username'] ?? '');
            if ($recipientName === '' && $emailAvailable) {
                $recipientName = $email;
            } elseif ($recipientName === '') {
                $recipientName = (string) ($recipient['username'] ?? 'User');
            }

            $actorNames = [];
            if ($actorId > 0) {
                $actor = (array) $this->RL_GetUserDetails($actorId);
                if (empty($actor['error'])) {
                    $name = (string) ($actor['user_fullname'] ?? $actor['username'] ?? '');
                    if ($name !== '') {
                        $actorNames[] = $name;
                    }
                }
            }

            $message = $this->RL_FormatNotificationMessage($actorNames, $type, $objectId, $extra);
            if ($message === '') {
                $message = customLang('notifications_email_fallback_message');
            }

            $pushTitle = customLang('notifications_push_title');
            if (!is_string($pushTitle) || $pushTitle === '' || $pushTitle === 'notifications_push_title') {
                $pushTitle = 'New notification';
            }

            if ($pushEnabled) {
                $this->RL_DispatchOneSignalPush($recipientId, $actorId, $type, $objectId, $extra, $createdAt, $pushTitle, $message);
            }

            if ($smsEnabled && $phone !== '') {
                $this->RL_DispatchSms($recipientId, $phone, $message);
            }

            global $base_url;
            $base = is_string($base_url) ? trim($base_url) : '';
            if ($base === '') {
                $base = '/';
            }
            $notificationsUrl = rtrim($base, '/') . '/';

            if (!$emailEnabled || !$emailAvailable) {
                return;
            }

            if (!class_exists('AdminMail', false)) {
                require_once __DIR__ . '/../helpers/mail_helper.php';
            }

            $mailSettings = [];
            try {
                $mailSettings = AdminMail::loadSettings($this->db);
            } catch (Throwable $mailError) {
                if (AdminMail::isConfigurationError($mailError)) {
                    return;
                }
                if (is_callable([$this, 'logError'])) {
                    $this->logError('RL_HandleNotificationDelivery mail settings failed: ' . $mailError->getMessage());
                }
                return;
            }

            try {
                [$mailer] = AdminMail::buildMailer($mailSettings);
            } catch (Throwable $mailBuildError) {
                if (AdminMail::isConfigurationError($mailBuildError)) {
                    return;
                }
                if (is_callable([$this, 'logError'])) {
                    $this->logError('RL_HandleNotificationDelivery mailer build failed: ' . $mailBuildError->getMessage());
                }
                return;
            }
            $mailer->clearAllRecipients();
            $mailer->clearReplyTos();
            $mailer->addAddress($email, $recipientName);
            $mailer->isHTML(false);

            $subject = sprintf(customLang('notifications_email_subject'), $message);
            $bodyLines = [];
            $bodyLines[] = sprintf(customLang('notifications_email_greeting'), $recipientName);
            $bodyLines[] = '';
            $bodyLines[] = sprintf(customLang('notifications_email_summary'), $message);
            $bodyLines[] = '';
            $bodyLines[] = sprintf(customLang('notifications_email_action'), $notificationsUrl);
            $bodyLines[] = '';
            $bodyLines[] = customLang('notifications_email_manage_hint');
            $body = implode("\n", $bodyLines);

            $mailer->Subject = $subject;
            $mailer->Body = $body;
            $mailer->AltBody = $body;

            try {
                $mailer->send();
            } catch (Throwable $mailSendError) {
                if (!AdminMail::isConfigurationError($mailSendError) && is_callable([$this, 'logError'])) {
                    $this->logError('RL_HandleNotificationDelivery send failed: ' . $mailSendError->getMessage());
                }
            } finally {
                if (method_exists($mailer, 'smtpClose')) {
                    $mailer->smtpClose();
                }
            }
        } catch (Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_HandleNotificationDelivery failed: ' . $e->getMessage());
            }
        }
    }

    private function RL_DispatchOneSignalPush(
        int $recipientId,
        int $actorId,
        string $type,
        ?int $objectId,
        array $extra,
        int $createdAt,
        string $title,
        ?string $body = null
    ): void {
        try {
            if ($recipientId <= 0) {
                return;
            }
            if (!function_exists('curl_init')) {
                return;
            }
            $config = $GLOBALS['oneSignalConfig'] ?? null;
            if (!is_array($config) || empty($config['active'])) {
                return;
            }
            $appId = (string)($config['app_id'] ?? '');
            $restKey = (string)($config['rest_api_key'] ?? '');
            if ($appId === '' || $restKey === '') {
                return;
            }

            $externalId = (string) $recipientId;
            global $base_url;
            $base = is_string($base_url) ? trim($base_url) : '';
            if ($base === '') { $base = '/'; }
            $url = rtrim($base, '/') . '/notifications';

            $payload = [
                'app_id' => $appId,
                'include_external_user_ids' => [$externalId],
                'channel_for_external_user_ids' => 'push',
                'headings' => ['en' => (string) $title],
                'contents' => ['en' => (string) ($body !== null ? $body : 'You have a new notification.')],
                'url' => $url,
                'data' => [
                    'type' => $type,
                    'actor_id' => $actorId,
                    'object_id' => $objectId,
                    'created_at' => $createdAt,
                ],
            ];
            if (!empty($extra)) {
                $payload['data']['meta'] = $extra;
            }

            $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($json === false) {
                return;
            }

            $handle = curl_init('https://api.onesignal.com/notifications');
            if ($handle === false) {
                return;
            }
            curl_setopt($handle, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json; charset=utf-8',
                'Authorization: Basic ' . $restKey,
            ]);
            curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($handle, CURLOPT_POST, true);
            curl_setopt($handle, CURLOPT_POSTFIELDS, $json);
            curl_setopt($handle, CURLOPT_TIMEOUT, 8);

            $responseBody = curl_exec($handle);
            $curlErrNo = curl_errno($handle);
            $curlError = $curlErrNo !== 0 ? curl_error($handle) : '';
            $status = (int) curl_getinfo($handle, CURLINFO_HTTP_CODE);
            curl_close($handle);

            if ($curlErrNo !== 0) {
                $this->RL_LogPushAttempt($recipientId, 'error', 'curl_' . $curlErrNo);
                if (method_exists($this, 'logError')) {
                    $this->logError('OneSignal curl error (' . $curlErrNo . '): ' . $curlError);
                }
                return;
            }

            if ($status < 200 || $status >= 300) {
                $errorLabel = 'http_' . $status;
                if (is_string($responseBody) && $responseBody !== '') {
                    $decoded = json_decode($responseBody, true);
                    if (is_array($decoded) && !empty($decoded['errors']) && is_array($decoded['errors'])) {
                        $detail = implode(',', array_map(static function ($v) {
                            return is_scalar($v) ? (string) $v : '';
                        }, $decoded['errors']));
                        $detail = trim($detail);
                        if ($detail !== '') {
                            $errorLabel .= ':' . substr($detail, 0, 128);
                        }
                    }
                }
                $this->RL_LogPushAttempt($recipientId, 'error', $errorLabel);
                if (method_exists($this, 'logError')) {
                    $this->logError('OneSignal push HTTP ' . $status . ' for user ' . $recipientId);
                }
                return;
            }

            $this->RL_LogPushAttempt($recipientId, 'success', null);
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('OneSignal push exception: ' . $e->getMessage());
            }
            $this->RL_LogPushAttempt($recipientId, 'error', 'exception');
        }
    }

    private function RL_LogPushAttempt(int $recipientId, string $status, ?string $error): void
    {
        try {
            static $tableReady = false;
            if (!$tableReady) {
                $this->db->exec('CREATE TABLE IF NOT EXISTS i_push_logs (
                    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    user_id INT UNSIGNED NULL,
                    channel VARCHAR(32) NOT NULL,
                    status VARCHAR(16) NOT NULL,
                    error VARCHAR(255) NULL,
                    created_at INT UNSIGNED NOT NULL,
                    PRIMARY KEY (id),
                    KEY idx_user_channel (user_id, channel)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
                $tableReady = true;
            }

            $stmt = $this->db->prepare('INSERT INTO i_push_logs (user_id, channel, status, error, created_at) VALUES (:uid, :ch, :st, :err, :ts)');
            if ($recipientId > 0) {
                $stmt->bindValue(':uid', $recipientId, \PDO::PARAM_INT);
            } else {
                $stmt->bindValue(':uid', null, \PDO::PARAM_NULL);
            }
            $stmt->bindValue(':ch', 'onesignal', \PDO::PARAM_STR);
            $stmt->bindValue(':st', $status === 'success' ? 'success' : 'error', \PDO::PARAM_STR);
            if ($error !== null && $error !== '') {
                $stmt->bindValue(':err', substr($error, 0, 250), \PDO::PARAM_STR);
            } else {
                $stmt->bindValue(':err', null, \PDO::PARAM_NULL);
            }
            $stmt->bindValue(':ts', time(), \PDO::PARAM_INT);
            $stmt->execute();
        } catch (Throwable $__) {
            // Fallback: ignore logging issues silently.
        }
    }

    private function RL_DispatchSms(int $recipientId, string $phone, string $body): void
    {
        try {
            $config = $GLOBALS['smsConfig'] ?? null;
            if (!is_array($config) || empty($config['active']) || ($config['provider'] ?? '') !== 'twilio') {
                return;
            }
            if (!function_exists('curl_init')) {
                return;
            }
            $twilio = isset($config['twilio']) && is_array($config['twilio']) ? $config['twilio'] : [];
            $sid    = isset($twilio['sid']) ? (string) $twilio['sid'] : '';
            $token  = isset($twilio['token']) ? (string) $twilio['token'] : '';
            $from   = isset($twilio['from']) ? (string) $twilio['from'] : '';
            if ($sid === '' || $token === '' || $from === '') {
                return;
            }
            $cleanPhone = preg_replace('/[^0-9+]/', '', $phone);
            if (!is_string($cleanPhone) || $cleanPhone === '' || !preg_match('/^\\+?[0-9]{8,20}$/', $cleanPhone)) {
                return;
            }
            $message = mb_substr((string) $body, 0, 320, 'UTF-8');
            if ($message === '') {
                return;
            }

            static $smsTableReady = false;
            if (!$smsTableReady) {
                $this->db->exec('CREATE TABLE IF NOT EXISTS i_sms_logs (
                    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    user_id INT UNSIGNED NULL,
                    phone VARCHAR(32) NOT NULL,
                    provider VARCHAR(32) NOT NULL DEFAULT "twilio",
                    status VARCHAR(16) NOT NULL,
                    message VARCHAR(320) NULL,
                    error_code VARCHAR(64) NULL,
                    error_message VARCHAR(255) NULL,
                    created_at INT UNSIGNED NOT NULL,
                    PRIMARY KEY (id),
                    KEY idx_user_status (user_id, status, created_at),
                    KEY idx_phone_time (phone, created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
                $smsTableReady = true;
            }

            $maxPerHour = isset($config['rate_limit_per_hour']) ? (int) $config['rate_limit_per_hour'] : 30;
            if ($maxPerHour > 0) {
                $since = time() - 3600;
                $rateStmt = $this->db->prepare('SELECT COUNT(*) FROM i_sms_logs WHERE phone = :ph AND created_at > :since');
                $rateStmt->bindValue(':ph', $cleanPhone, \PDO::PARAM_STR);
                $rateStmt->bindValue(':since', $since, \PDO::PARAM_INT);
                $rateStmt->execute();
                $count = (int) $rateStmt->fetchColumn();
                if ($count >= $maxPerHour) {
                    $this->RL_LogSms($recipientId, $cleanPhone, 'blocked', $message, 'rate_limit', 'Rate limit exceeded');
                    return;
                }
            }

            $endpoint = 'https://api.twilio.com/2010-04-01/Accounts/' . rawurlencode($sid) . '/Messages.json';
            $payload = http_build_query([
                'To'   => $cleanPhone,
                'From' => $from,
                'Body' => $message,
            ]);

            $ch = curl_init($endpoint);
            if ($ch === false) {
                $this->RL_LogSms($recipientId, $cleanPhone, 'error', $message, 'curl_init', 'Unable to init cURL');
                return;
            }
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($ch, CURLOPT_USERPWD, $sid . ':' . $token);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);

            $responseBody = curl_exec($ch);
            $curlErrNo = curl_errno($ch);
            $curlError = $curlErrNo !== 0 ? curl_error($ch) : '';
            $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($curlErrNo !== 0) {
                $this->RL_LogSms($recipientId, $cleanPhone, 'error', $message, 'curl_' . $curlErrNo, $curlError);
                return;
            }

            if ($status < 200 || $status >= 300) {
                $errorCode = 'http_' . $status;
                $errorMessage = '';
                if (is_string($responseBody) && $responseBody !== '') {
                    $decoded = json_decode($responseBody, true);
                    if (is_array($decoded)) {
                        if (!empty($decoded['code'])) {
                            $errorCode .= ':' . $decoded['code'];
                        }
                        if (!empty($decoded['message']) && is_string($decoded['message'])) {
                            $errorMessage = substr($decoded['message'], 0, 255);
                        }
                    }
                }
                $this->RL_LogSms($recipientId, $cleanPhone, 'error', $message, $errorCode, $errorMessage);
                return;
            }

            $this->RL_LogSms($recipientId, $cleanPhone, 'success', $message, null, null);
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_DispatchSms failed: ' . $e->getMessage());
            }
        }
    }

    private function RL_LogSms(int $recipientId, string $phone, string $status, string $message, ?string $errorCode, ?string $errorMessage): void
    {
        try {
            static $tableReady = false;
            if (!$tableReady) {
                $this->db->exec('CREATE TABLE IF NOT EXISTS i_sms_logs (
                    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    user_id INT UNSIGNED NULL,
                    phone VARCHAR(32) NOT NULL,
                    provider VARCHAR(32) NOT NULL DEFAULT "twilio",
                    status VARCHAR(16) NOT NULL,
                    message VARCHAR(320) NULL,
                    error_code VARCHAR(64) NULL,
                    error_message VARCHAR(255) NULL,
                    created_at INT UNSIGNED NOT NULL,
                    PRIMARY KEY (id),
                    KEY idx_user_status (user_id, status, created_at),
                    KEY idx_phone_time (phone, created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
                $tableReady = true;
            }

            $stmt = $this->db->prepare('INSERT INTO i_sms_logs (user_id, phone, provider, status, message, error_code, error_message, created_at) VALUES (:uid, :ph, :prov, :st, :msg, :errc, :errm, :ts)');
            if ($recipientId > 0) {
                $stmt->bindValue(':uid', $recipientId, \PDO::PARAM_INT);
            } else {
                $stmt->bindValue(':uid', null, \PDO::PARAM_NULL);
            }
            $stmt->bindValue(':ph', substr($phone, 0, 32), \PDO::PARAM_STR);
            $stmt->bindValue(':prov', 'twilio', \PDO::PARAM_STR);
            $stmt->bindValue(':st', $status === 'success' ? 'success' : $status, \PDO::PARAM_STR);
            $stmt->bindValue(':msg', $message !== '' ? substr($message, 0, 320) : null, $message !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
            $stmt->bindValue(':errc', $errorCode !== null && $errorCode !== '' ? substr($errorCode, 0, 64) : null, $errorCode !== null && $errorCode !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
            $stmt->bindValue(':errm', $errorMessage !== null && $errorMessage !== '' ? substr($errorMessage, 0, 255) : null, $errorMessage !== null && $errorMessage !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
            $stmt->bindValue(':ts', time(), \PDO::PARAM_INT);
            $stmt->execute();
        } catch (\Throwable $__) {
            // ignore logging failures
        }
    }
}
