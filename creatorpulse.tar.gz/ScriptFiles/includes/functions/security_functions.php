<?php
declare(strict_types=1);

trait SecurityFunctions
{
    private function RL_EnsureUserSecurityTable(): void
    {
        try {
            $sql = <<<SQL
                CREATE TABLE IF NOT EXISTS i_user_security (
                    user_id INT UNSIGNED NOT NULL,
                    totp_secret VARCHAR(64) NULL,
                    totp_confirmed TINYINT(1) NOT NULL DEFAULT 0,
                    pending_secret VARCHAR(64) NULL,
                    recovery_codes LONGTEXT NULL,
                    codes_generated_at INT UNSIGNED NULL,
                    totp_enabled_at INT UNSIGNED NULL,
                    updated_at INT UNSIGNED NOT NULL,
                    created_at INT UNSIGNED NOT NULL,
                    last_codes_downloaded_at INT UNSIGNED NULL,
                    last_codes_regen_at INT UNSIGNED NULL,
                    PRIMARY KEY (user_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
            SQL;
            $this->db->exec($sql);
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_EnsureUserSecurityTable failed: ' . $e->getMessage());
            }
        }
    }

    private function RL_EnsureSecurityEventsTable(): void
    {
        try {
            $sql = <<<SQL
                CREATE TABLE IF NOT EXISTS i_security_events (
                    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    user_id INT UNSIGNED NOT NULL,
                    event_type VARCHAR(64) NOT NULL,
                    event_meta TEXT NULL,
                    ip_address VARCHAR(45) NULL,
                    user_agent VARCHAR(255) NULL,
                    created_at INT UNSIGNED NOT NULL,
                    PRIMARY KEY (id),
                    INDEX idx_user_time (user_id, created_at),
                    INDEX idx_user_type (user_id, event_type)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
            SQL;
            $this->db->exec($sql);
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_EnsureSecurityEventsTable failed: ' . $e->getMessage());
            }
        }
    }

    private function RL_EnsureSessionDevicesTable(): void
    {
        try {
            $sql = <<<SQL
                CREATE TABLE IF NOT EXISTS i_session_devices (
                    session_key VARCHAR(64) NOT NULL,
                    user_id INT UNSIGNED NOT NULL,
                    device_label VARCHAR(120) NULL,
                    browser VARCHAR(80) NULL,
                    platform VARCHAR(80) NULL,
                    ip_address VARCHAR(45) NULL,
                    location VARCHAR(120) NULL,
                    user_agent TEXT NULL,
                    created_at INT UNSIGNED NOT NULL,
                    last_active INT UNSIGNED NOT NULL,
                    PRIMARY KEY (session_key),
                    INDEX idx_sd_user (user_id, last_active DESC)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
            SQL;
            $this->db->exec($sql);
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_EnsureSessionDevicesTable failed: ' . $e->getMessage());
            }
        }
    }

    private function RL_EnsurePasswordResetTable(): void
    {
        try {
            $sql = <<<SQL
                CREATE TABLE IF NOT EXISTS i_password_resets (
                    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    user_id INT UNSIGNED NOT NULL,
                    email VARCHAR(190) NOT NULL,
                    token_hash CHAR(64) NOT NULL,
                    ip_address VARCHAR(45) NULL,
                    user_agent VARCHAR(255) NULL,
                    created_at INT UNSIGNED NOT NULL,
                    expires_at INT UNSIGNED NOT NULL,
                    used_at INT UNSIGNED NULL,
                    metadata JSON NULL,
                    PRIMARY KEY (id),
                    UNIQUE KEY uniq_token_hash (token_hash),
                    INDEX idx_user_used (user_id, used_at),
                    INDEX idx_expires (expires_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
            SQL;
            $this->db->exec($sql);
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_EnsurePasswordResetTable failed: ' . $e->getMessage());
            }
        }
    }

    public function RL_GetUserSecurityProfile(int $userId, ?string $currentSessionKey = null): array
    {
        $this->RL_EnsureUserSecurityTable();
        $this->RL_EnsureSecurityEventsTable();
        $this->RL_EnsureSessionDevicesTable();

        $profile = [
            'two_factor_enabled' => false,
            'two_factor_pending' => false,
            'two_factor_enabled_at' => null,
            'backup_codes_available' => false,
            'backup_codes_generated_at' => null,
            'sessions' => [],
            'events' => [],
        ];

        try {
            $stmt = $this->db->prepare('SELECT * FROM i_user_security WHERE user_id = :uid LIMIT 1');
            $stmt->bindValue(':uid', $userId, PDO::PARAM_INT);
            $stmt->execute();
            if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $profile['two_factor_enabled'] = !empty($row['totp_confirmed']);
                $profile['two_factor_pending'] = !$profile['two_factor_enabled'] && !empty($row['pending_secret']);
                $profile['two_factor_enabled_at'] = isset($row['totp_enabled_at']) ? (int) $row['totp_enabled_at'] : null;
                $profile['backup_codes_available'] = !empty($row['recovery_codes']);
                $profile['backup_codes_generated_at'] = isset($row['codes_generated_at']) ? (int) $row['codes_generated_at'] : null;
            }
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetUserSecurityProfile fetch failed: ' . $e->getMessage());
            }
        }

        $profile['sessions'] = $this->RL_GetSecuritySessions($userId, $currentSessionKey);
        $profile['events'] = $this->RL_GetSecurityEvents($userId, 12);

        return $profile;
    }

    public function RL_UpdateUserPassword(int $userId, string $currentPassword, string $newPassword, bool $invalidateOthers = true): array
    {
        $userId = (int) $userId;
        if ($userId <= 0) {
            return ['ok' => false, 'error' => 'INVALID_USER'];
        }

        if (!$this->RL_SecurityRateLimitAllow($userId, 'password_change', 5, 3600)) {
            return ['ok' => false, 'error' => 'RATE_LIMIT'];
        }

        try {
            $stmt = $this->db->prepare('SELECT user_password FROM i_users WHERE user_id = :uid LIMIT 1');
            $stmt->bindValue(':uid', $userId, PDO::PARAM_INT);
            $stmt->execute();
            $currentHash = $stmt->fetchColumn();
            if (!$currentHash || !password_verify($currentPassword, (string) $currentHash)) {
                return ['ok' => false, 'error' => 'INVALID_CURRENT_PASSWORD'];
            }

            if (!$this->RL_IsPasswordStrong($newPassword)) {
                return ['ok' => false, 'error' => 'WEAK_PASSWORD'];
            }

            if (password_verify($newPassword, (string) $currentHash)) {
                return ['ok' => false, 'error' => 'PASSWORD_UNCHANGED'];
            }

            $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
            $update = $this->db->prepare('UPDATE i_users SET user_password = :pwd WHERE user_id = :uid LIMIT 1');
            $update->execute([
                ':pwd' => $newHash,
                ':uid' => $userId,
            ]);

            if ($invalidateOthers) {
                $cookieName = isset($GLOBALS['cookieName']) ? (string) $GLOBALS['cookieName'] : 'dizzyreel';
                $currentKey = isset($_COOKIE[$cookieName]) ? (string) $_COOKIE[$cookieName] : null;
                if ($currentKey !== null && $currentKey !== '') {
                    $this->RL_RevokeOtherSessions($userId, $currentKey);
                } else {
                    $this->RL_RevokeOtherSessions($userId, null);
                }
            }

            $this->RL_LogSecurityEvent($userId, 'password_changed', []);
            return ['ok' => true];
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_UpdateUserPassword failed: ' . $e->getMessage());
            }
            return ['ok' => false, 'error' => 'DB_ERROR'];
        }
    }

    public function RL_CreatePasswordResetRequest(int $userId, string $email, string $ip, string $userAgent): array
    {
        $userId = (int) $userId;
        $email = trim($email);
        if ($userId <= 0 || $email === '') {
            return ['ok' => false, 'error' => 'INVALID_REQUEST'];
        }

        $this->RL_EnsurePasswordResetTable();

        $ip = trim($ip);
        if ($ip === '') {
            $ip = $this->RL_DetectIpAddress();
        }
        if ($ip !== '') {
            $ip = substr($ip, 0, 45);
        }

        $userAgent = trim($userAgent);
        if ($userAgent === '') {
            $userAgent = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
        }
        $userAgent = mb_substr($userAgent, 0, 255, 'UTF-8');

        $windowStart = time() - 3600;

        try {
            $stmtUser = $this->db->prepare('SELECT COUNT(*) FROM i_password_resets WHERE user_id = :uid AND created_at >= :since');
            $stmtUser->execute([
                ':uid' => $userId,
                ':since' => $windowStart,
            ]);
            if ((int) ($stmtUser->fetchColumn() ?: 0) >= 5) {
                return ['ok' => false, 'error' => 'RATE_LIMIT'];
            }

            if ($ip !== '') {
                $stmtIp = $this->db->prepare('SELECT COUNT(*) FROM i_password_resets WHERE ip_address = :ip AND created_at >= :since');
                $stmtIp->execute([
                    ':ip' => $ip,
                    ':since' => $windowStart,
                ]);
                if ((int) ($stmtIp->fetchColumn() ?: 0) >= 5) {
                    return ['ok' => false, 'error' => 'RATE_LIMIT'];
                }
            }

            $rawToken = bin2hex(random_bytes(32));
            $tokenHash = hash('sha256', $rawToken);
            $now = time();
            $expiresAt = $now + 3600;

            $metadata = [
                'ip' => $ip ?: null,
                'ua_hash' => hash('sha256', $userAgent ?: 'na'),
            ];
            $metadataJson = json_encode($metadata, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

            $insert = $this->db->prepare(
                'INSERT INTO i_password_resets (user_id, email, token_hash, ip_address, user_agent, created_at, expires_at, metadata)
                 VALUES (:uid, :email, :token_hash, :ip, :ua, :created_at, :expires_at, :metadata)'
            );
            $insert->execute([
                ':uid' => $userId,
                ':email' => $email,
                ':token_hash' => $tokenHash,
                ':ip' => $ip !== '' ? $ip : null,
                ':ua' => $userAgent !== '' ? $userAgent : null,
                ':created_at' => $now,
                ':expires_at' => $expiresAt,
                ':metadata' => $metadataJson,
            ]);

            $resetId = (int) $this->db->lastInsertId();

            $this->RL_LogSecurityEvent($userId, 'password_reset_requested', [
                'reset_id' => $resetId,
                'ip' => $ip ?: null,
            ]);

            if (random_int(1, 10) === 1) {
                $this->RL_PurgeExpiredPasswordResets(100);
            }

            return [
                'ok' => true,
                'token' => $rawToken,
                'expires_at' => $expiresAt,
                'id' => $resetId,
            ];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_CreatePasswordResetRequest failed: ' . $e->getMessage());
            }
            return ['ok' => false, 'error' => 'DB_ERROR'];
        }
    }

    public function RL_FindValidPasswordReset(int $userId, string $token): ?array
    {
        $userId = (int) $userId;
        $token = trim($token);
        if ($userId <= 0 || $token === '') {
            return null;
        }

        $this->RL_EnsurePasswordResetTable();

        try {
            $tokenHash = hash('sha256', $token);
            $stmt = $this->db->prepare(
                'SELECT id, user_id, email, ip_address, user_agent, created_at, expires_at, used_at, metadata
                 FROM i_password_resets
                 WHERE user_id = :uid AND token_hash = :hash AND expires_at >= :now AND (used_at IS NULL OR used_at = 0)
                 LIMIT 1'
            );
            $stmt->execute([
                ':uid' => $userId,
                ':hash' => $tokenHash,
                ':now' => time(),
            ]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                return null;
            }

            $metadata = [];
            if (!empty($row['metadata'])) {
                $decoded = json_decode((string) $row['metadata'], true);
                if (is_array($decoded)) {
                    $metadata = $decoded;
                }
            }

            return [
                'id' => (int) $row['id'],
                'user_id' => (int) $row['user_id'],
                'email' => (string) $row['email'],
                'ip_address' => isset($row['ip_address']) ? (string) $row['ip_address'] : null,
                'user_agent' => isset($row['user_agent']) ? (string) $row['user_agent'] : null,
                'created_at' => isset($row['created_at']) ? (int) $row['created_at'] : 0,
                'expires_at' => isset($row['expires_at']) ? (int) $row['expires_at'] : 0,
                'metadata' => $metadata,
            ];
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_FindValidPasswordReset failed: ' . $e->getMessage());
            }
            return null;
        }
    }

    public function RL_CompletePasswordReset(int $resetId, int $userId, string $newPassword, ?string $currentSessionKey = null): array
    {
        $resetId = (int) $resetId;
        $userId = (int) $userId;
        if ($resetId <= 0 || $userId <= 0) {
            return ['ok' => false, 'error' => 'INVALID_REQUEST'];
        }

        if (!$this->RL_IsPasswordStrong($newPassword)) {
            return ['ok' => false, 'error' => 'WEAK_PASSWORD'];
        }

        $this->RL_EnsurePasswordResetTable();

        try {
            $this->db->beginTransaction();

            $stmt = $this->db->prepare(
                'SELECT id, user_id, used_at, expires_at
                 FROM i_password_resets
                 WHERE id = :id AND user_id = :uid
                 LIMIT 1
                 FOR UPDATE'
            );
            $stmt->execute([
                ':id' => $resetId,
                ':uid' => $userId,
            ]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                $this->db->rollBack();
                return ['ok' => false, 'error' => 'RESET_NOT_FOUND'];
            }

            $now = time();
            $usedAt = isset($row['used_at']) ? (int) $row['used_at'] : 0;
            $expiresAt = isset($row['expires_at']) ? (int) $row['expires_at'] : 0;
            if ($usedAt > 0 || $expiresAt < $now) {
                $this->db->rollBack();
                return ['ok' => false, 'error' => 'TOKEN_INVALID'];
            }

            $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
            if ($passwordHash === false) {
                $this->db->rollBack();
                return ['ok' => false, 'error' => 'HASH_FAILED'];
            }

            $updateUser = $this->db->prepare('UPDATE i_users SET user_password = :pwd WHERE user_id = :uid LIMIT 1');
            $updateUser->execute([
                ':pwd' => $passwordHash,
                ':uid' => $userId,
            ]);

            $markUsed = $this->db->prepare('UPDATE i_password_resets SET used_at = :used WHERE id = :id LIMIT 1');
            $markUsed->execute([
                ':used' => $now,
                ':id' => $resetId,
            ]);

            $this->db->commit();
        } catch (PDOException $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            if (method_exists($this, 'logError')) {
                $this->logError('RL_CompletePasswordReset failed: ' . $e->getMessage());
            }
            return ['ok' => false, 'error' => 'DB_ERROR'];
        }

        try {
            $this->RL_RevokeOtherSessions($userId, $currentSessionKey);
        } catch (\Throwable $__) {
            // best-effort; ignore revocation exceptions
        }

        $this->RL_LogSecurityEvent($userId, 'password_reset_completed', [
            'reset_id' => $resetId,
        ]);

        try {
            $cleanup = $this->db->prepare('DELETE FROM i_password_resets WHERE user_id = :uid AND used_at IS NULL AND id <> :id');
            $cleanup->execute([
                ':uid' => $userId,
                ':id' => $resetId,
            ]);
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_CompletePasswordReset cleanup failed: ' . $e->getMessage());
            }
        }

        if (random_int(1, 10) === 1) {
            $this->RL_PurgeExpiredPasswordResets(200);
        }

        return ['ok' => true];
    }

    public function RL_PurgeExpiredPasswordResets(int $limit = 100): void
    {
        $limit = max(1, (int) $limit);
        $this->RL_EnsurePasswordResetTable();

        try {
            $sql = sprintf(
                'DELETE FROM i_password_resets WHERE (expires_at < :now OR used_at IS NOT NULL) ORDER BY expires_at ASC LIMIT %d',
                $limit
            );
            $stmt = $this->db->prepare($sql);
            $stmt->execute([':now' => time()]);
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_PurgeExpiredPasswordResets failed: ' . $e->getMessage());
            }
        }
    }

    public function RL_IsPasswordAcceptable(string $password): bool
    {
        return $this->RL_IsPasswordStrong($password);
    }

    public function RL_PrepareTwoFactorSecret(int $userId): array
    {
        $userId = (int) $userId;
        if ($userId <= 0) {
            return ['ok' => false, 'error' => 'INVALID_USER'];
        }

        $this->RL_EnsureUserSecurityTable();

        try {
            $stmt = $this->db->prepare('SELECT totp_confirmed, pending_secret FROM i_user_security WHERE user_id = :uid LIMIT 1');
            $stmt->bindValue(':uid', $userId, PDO::PARAM_INT);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

            if (!empty($row['totp_confirmed'])) {
                return ['ok' => false, 'error' => 'ALREADY_ENABLED'];
            }

            $secretCandidate = !empty($row['pending_secret']) ? (string) $row['pending_secret'] : $this->RL_GenerateTotpSecret();
            $secret = $this->RL_NormalizeTotpSecret($secretCandidate);
            if ($secret === null) {
                $secret = $this->RL_NormalizeTotpSecret($this->RL_GenerateTotpSecret());
                if ($secret === null) {
                    return ['ok' => false, 'error' => 'SECRET_GENERATION_FAILED'];
                }
            }
            $now = time();

            $upsert = $this->db->prepare(
                'INSERT INTO i_user_security (user_id, pending_secret, updated_at, created_at)
                 VALUES (:uid, :secret, :updated, :created)
                 ON DUPLICATE KEY UPDATE pending_secret = VALUES(pending_secret), updated_at = VALUES(updated_at)'
            );
            $upsert->execute([
                ':uid' => $userId,
                ':secret' => $secret,
                ':updated' => $now,
                ':created' => $now,
            ]);

            return ['ok' => true, 'secret' => $secret];
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_PrepareTwoFactorSecret failed: ' . $e->getMessage());
            }
            return ['ok' => false, 'error' => 'DB_ERROR'];
        }
    }

    public function RL_EnableTwoFactor(int $userId, string $secret, string $code, bool $generateCodes = true): array
    {
        $userId = (int) $userId;
        if ($userId <= 0) {
            return ['ok' => false, 'error' => 'INVALID_USER'];
        }

        $secret = $this->RL_NormalizeTotpSecret($secret ?? '');
        $code = preg_replace('/\s+/', '', $code);
        if ($secret === null) {
            return ['ok' => false, 'error' => 'INVALID_SECRET'];
        }
        if (!preg_match('/^\d{6}$/', $code)) {
            return ['ok' => false, 'error' => 'INVALID_CODE'];
        }

        if (!$this->RL_VerifyTotpCode($secret, $code, 1)) {
            return ['ok' => false, 'error' => 'CODE_MISMATCH'];
        }

        $this->RL_EnsureUserSecurityTable();

        try {
            $existing = $this->db->prepare('SELECT totp_confirmed, pending_secret FROM i_user_security WHERE user_id = :uid LIMIT 1');
            $existing->bindValue(':uid', $userId, PDO::PARAM_INT);
            $existing->execute();
            $row = $existing->fetch(PDO::FETCH_ASSOC) ?: [];
            if (!empty($row['totp_confirmed'])) {
                return ['ok' => false, 'error' => 'ALREADY_ENABLED'];
            }
            if (!empty($row['pending_secret']) && !hash_equals((string) $row['pending_secret'], $secret)) {
                return ['ok' => false, 'error' => 'SECRET_MISMATCH'];
            }

            $now = time();
            $stmt = $this->db->prepare(
                'INSERT INTO i_user_security (user_id, totp_secret, totp_confirmed, pending_secret, totp_enabled_at, updated_at, created_at)
                 VALUES (:uid, :secret, 1, NULL, :enabled_at, :updated, :created)
                 ON DUPLICATE KEY UPDATE totp_secret = VALUES(totp_secret), totp_confirmed = 1, pending_secret = NULL, totp_enabled_at = VALUES(totp_enabled_at), updated_at = VALUES(updated_at)'
            );
            $stmt->execute([
                ':uid' => $userId,
                ':secret' => $secret,
                ':enabled_at' => $now,
                ':updated' => $now,
                ':created' => $now,
            ]);

            $plainCodes = [];
            if ($generateCodes) {
                $plainCodes = $this->RL_InternalGenerateAndStoreCodes($userId, $now);
            }

            $this->RL_LogSecurityEvent($userId, 'two_factor_enabled', []);
            return ['ok' => true, 'codes' => $plainCodes];
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_EnableTwoFactor failed: ' . $e->getMessage());
            }
            return ['ok' => false, 'error' => 'DB_ERROR'];
        }
    }

    public function RL_DisableTwoFactor(int $userId, string $code = '', string $password = ''): array
    {
        $userId = (int) $userId;
        if ($userId <= 0) {
            return ['ok' => false, 'error' => 'INVALID_USER'];
        }

        $this->RL_EnsureUserSecurityTable();

        try {
            $stmt = $this->db->prepare('SELECT totp_secret FROM i_user_security WHERE user_id = :uid AND totp_confirmed = 1 LIMIT 1');
            $stmt->bindValue(':uid', $userId, PDO::PARAM_INT);
            $stmt->execute();
            $secret = $stmt->fetchColumn();
            if (!$secret) {
                return ['ok' => false, 'error' => 'NOT_ENABLED'];
            }

            $code = preg_replace('/\s+/', '', $code);
            $codeValid = $code !== '' && $this->RL_VerifyTotpCode((string) $secret, $code, 1);
            $passwordValid = false;

            if (!$codeValid && $password !== '') {
                $pStmt = $this->db->prepare('SELECT user_password FROM i_users WHERE user_id = :uid LIMIT 1');
                $pStmt->bindValue(':uid', $userId, PDO::PARAM_INT);
                $pStmt->execute();
                $hash = $pStmt->fetchColumn();
                if ($hash && password_verify($password, (string) $hash)) {
                    $passwordValid = true;
                }
            }

            if (!$codeValid && !$passwordValid) {
                return ['ok' => false, 'error' => 'VERIFICATION_FAILED'];
            }

            $now = time();
            $update = $this->db->prepare(
                'UPDATE i_user_security
                 SET totp_secret = NULL,
                     totp_confirmed = 0,
                     pending_secret = NULL,
                     recovery_codes = NULL,
                     codes_generated_at = NULL,
                     updated_at = :updated,
                     last_codes_downloaded_at = NULL,
                     last_codes_regen_at = NULL,
                     totp_enabled_at = NULL
                 WHERE user_id = :uid LIMIT 1'
            );
            $update->execute([
                ':uid' => $userId,
                ':updated' => $now,
            ]);

            $this->RL_LogSecurityEvent($userId, 'two_factor_disabled', []);
            return ['ok' => true];
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_DisableTwoFactor failed: ' . $e->getMessage());
            }
            return ['ok' => false, 'error' => 'DB_ERROR'];
        }
    }

    public function RL_GenerateRecoveryCodes(int $userId, int $count = 10): array
    {
        $userId = (int) $userId;
        if ($userId <= 0) {
            return ['ok' => false, 'error' => 'INVALID_USER'];
        }

        if (!$this->RL_SecurityRateLimitAllow($userId, 'recovery_regen', 3, 3600)) {
            return ['ok' => false, 'error' => 'RATE_LIMIT'];
        }

        $this->RL_EnsureUserSecurityTable();

        try {
            $now = time();
            $codes = [];
            $hashed = [];
            for ($i = 0; $i < max(1, $count); $i++) {
                $code = $this->RL_GenerateRecoveryCodeValue();
                $codes[] = $code;
                $hashed[] = password_hash($code, PASSWORD_DEFAULT);
            }

            $store = $this->db->prepare(
                'INSERT INTO i_user_security (user_id, recovery_codes, codes_generated_at, last_codes_regen_at, updated_at, created_at)
                 VALUES (:uid, :codes, :generated, :regen, :updated, :created)
                 ON DUPLICATE KEY UPDATE recovery_codes = VALUES(recovery_codes), codes_generated_at = VALUES(codes_generated_at), last_codes_regen_at = VALUES(last_codes_regen_at), updated_at = VALUES(updated_at)'
            );
            $store->execute([
                ':uid' => $userId,
                ':codes' => json_encode($hashed, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                ':generated' => $now,
                ':regen' => $now,
                ':updated' => $now,
                ':created' => $now,
            ]);

            $this->RL_LogSecurityEvent($userId, 'recovery_codes_regenerated', []);
            return ['ok' => true, 'codes' => $codes];
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GenerateRecoveryCodes failed: ' . $e->getMessage());
            }
            return ['ok' => false, 'error' => 'DB_ERROR'];
        }
    }

    public function RL_RevokeSession(int $userId, string $sessionKey): bool
    {
        $userId = (int) $userId;
        $sessionKey = trim($sessionKey);
        if ($userId <= 0 || $sessionKey === '') {
            return false;
        }

        try {
            $del = $this->db->prepare('DELETE FROM i_sessions WHERE session_uid = :uid AND session_key = :key');
            $del->execute([
                ':uid' => $userId,
                ':key' => $sessionKey,
            ]);

            $meta = $this->db->prepare('DELETE FROM i_session_devices WHERE session_key = :key');
            $meta->execute([':key' => $sessionKey]);

            if ($del->rowCount() > 0) {
                $this->RL_LogSecurityEvent($userId, 'session_revoked', ['session_key' => $this->RL_MaskSessionKey($sessionKey)]);
            }
            return true;
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_RevokeSession failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    public function RL_RevokeOtherSessions(int $userId, ?string $currentSessionKey): int
    {
        $userId = (int) $userId;
        if ($userId <= 0) {
            return 0;
        }

        try {
            if ($currentSessionKey) {
                $stmt = $this->db->prepare('DELETE FROM i_sessions WHERE session_uid = :uid AND session_key <> :key');
                $stmt->execute([
                    ':uid' => $userId,
                    ':key' => $currentSessionKey,
                ]);
                $meta = $this->db->prepare('DELETE FROM i_session_devices WHERE user_id = :uid AND session_key <> :key');
                $meta->execute([
                    ':uid' => $userId,
                    ':key' => $currentSessionKey,
                ]);
            } else {
                $stmt = $this->db->prepare('DELETE FROM i_sessions WHERE session_uid = :uid');
                $stmt->execute([':uid' => $userId]);
                $meta = $this->db->prepare('DELETE FROM i_session_devices WHERE user_id = :uid');
                $meta->execute([':uid' => $userId]);
            }
            $count = isset($stmt) ? (int) $stmt->rowCount() : 0;
            if ($count > 0) {
                $this->RL_LogSecurityEvent($userId, 'sessions_revoked', ['count' => $count]);
            }
            return $count;
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_RevokeOtherSessions failed: ' . $e->getMessage());
            }
            return 0;
        }
    }

    public function RL_TouchSessionDevice(int $userId, string $sessionKey, array $context = []): void
    {
        $userId = (int) $userId;
        $sessionKey = trim($sessionKey);
        if ($userId <= 0 || $sessionKey === '') {
            return;
        }

        $this->RL_EnsureSessionDevicesTable();

        $ip = isset($context['ip']) ? (string) $context['ip'] : $this->RL_DetectIpAddress();
        $ua = isset($context['user_agent']) ? (string) $context['user_agent'] : ((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
        $client = $this->RL_ParseUserAgent($ua);
        $now = time();

        try {
            $stmt = $this->db->prepare(
                'INSERT INTO i_session_devices (session_key, user_id, device_label, browser, platform, ip_address, location, user_agent, created_at, last_active)
                 VALUES (:key, :uid, :device, :browser, :platform, :ip, :location, :ua, :created, :last)
                 ON DUPLICATE KEY UPDATE device_label = VALUES(device_label), browser = VALUES(browser), platform = VALUES(platform), ip_address = VALUES(ip_address), location = VALUES(location), user_agent = VALUES(user_agent), last_active = VALUES(last_active)'
            );
            $stmt->execute([
                ':key' => $sessionKey,
                ':uid' => $userId,
                ':device' => $client['device'],
                ':browser' => $client['browser'],
                ':platform' => $client['platform'],
                ':ip' => $ip,
                ':location' => $context['location'] ?? null,
                ':ua' => mb_substr($ua, 0, 1000, 'UTF-8'),
                ':created' => $now,
                ':last' => $now,
            ]);
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_TouchSessionDevice failed: ' . $e->getMessage());
            }
        }
    }

    private function RL_GetSecuritySessions(int $userId, ?string $currentSessionKey): array
    {
        $sessions = [];
        try {
            $stmt = $this->db->prepare(
                'SELECT s.session_key, s.session_time, d.device_label, d.browser, d.platform, d.ip_address, d.location, d.last_active
                 FROM i_sessions s
                 LEFT JOIN i_session_devices d ON d.session_key = s.session_key
                 WHERE s.session_uid = :uid
                 ORDER BY COALESCE(d.last_active, s.session_time) DESC
                 LIMIT 20'
            );
            $stmt->bindValue(':uid', $userId, PDO::PARAM_INT);
            $stmt->execute();
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $sessions[] = [
                    'session_key' => (string) ($row['session_key'] ?? ''),
                    'device' => $row['device_label'] ?? '',
                    'browser' => $row['browser'] ?? '',
                    'platform' => $row['platform'] ?? '',
                    'ip' => $row['ip_address'] ?? '',
                    'location' => $row['location'] ?? '',
                    'last_active' => isset($row['last_active']) ? (int) $row['last_active'] : (int) ($row['session_time'] ?? 0),
                    'session_time' => isset($row['session_time']) ? (int) $row['session_time'] : 0,
                    'current' => $currentSessionKey && hash_equals($currentSessionKey, (string) ($row['session_key'] ?? '')),
                ];
            }
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetSecuritySessions failed: ' . $e->getMessage());
            }
        }
        return $sessions;
    }

    private function RL_GetSecurityEvents(int $userId, int $limit = 10): array
    {
        $events = [];
        try {
            $stmt = $this->db->prepare(
                'SELECT event_type, event_meta, created_at FROM i_security_events
                 WHERE user_id = :uid AND event_type NOT LIKE "rate:%"
                 ORDER BY created_at DESC
                 LIMIT :lim'
            );
            $stmt->bindValue(':uid', $userId, PDO::PARAM_INT);
            $stmt->bindValue(':lim', max(1, $limit), PDO::PARAM_INT);
            $stmt->execute();
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $meta = [];
                if (!empty($row['event_meta'])) {
                    $decoded = json_decode((string) $row['event_meta'], true);
                    if (is_array($decoded)) {
                        $meta = $decoded;
                    }
                }
                $events[] = [
                    'type' => (string) ($row['event_type'] ?? ''),
                    'meta' => $meta,
                    'time' => isset($row['created_at']) ? (int) $row['created_at'] : 0,
                ];
            }
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetSecurityEvents failed: ' . $e->getMessage());
            }
        }
        return $events;
    }

    private function RL_LogSecurityEvent(int $userId, string $type, array $meta = []): void
    {
        $userId = (int) $userId;
        if ($userId <= 0) {
            return;
        }

        $this->RL_EnsureSecurityEventsTable();

        try {
            $stmt = $this->db->prepare(
                'INSERT INTO i_security_events (user_id, event_type, event_meta, ip_address, user_agent, created_at)
                 VALUES (:uid, :type, :meta, :ip, :agent, :created)'
            );
            $stmt->execute([
                ':uid' => $userId,
                ':type' => substr($type, 0, 64),
                ':meta' => $meta ? json_encode($meta, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : null,
                ':ip' => $this->RL_DetectIpAddress(),
                ':agent' => mb_substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255, 'UTF-8'),
                ':created' => time(),
            ]);
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_LogSecurityEvent failed: ' . $e->getMessage());
            }
        }
    }

    private function RL_SecurityRateLimitAllow(int $userId, string $action, int $max, int $window): bool
    {
        $userId = (int) $userId;
        if ($userId <= 0) {
            return false;
        }

        $this->RL_EnsureSecurityEventsTable();

        try {
            $since = time() - $window;
            $stmt = $this->db->prepare('SELECT COUNT(*) FROM i_security_events WHERE user_id = :uid AND event_type = :type AND created_at >= :since');
            $stmt->execute([
                ':uid' => $userId,
                ':type' => 'rate:' . $action,
                ':since' => $since,
            ]);
            $count = (int) $stmt->fetchColumn();
            if ($count >= $max) {
                return false;
            }

            $log = $this->db->prepare('INSERT INTO i_security_events (user_id, event_type, created_at) VALUES (:uid, :type, :created)');
            $log->execute([
                ':uid' => $userId,
                ':type' => 'rate:' . $action,
                ':created' => time(),
            ]);
            return true;
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_SecurityRateLimitAllow failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    private function RL_VerifyTotpCode(string $secret, string $code, int $window = 1): bool
    {
        $secret = strtoupper(preg_replace('/[^A-Z2-7]/', '', $secret));
        $code = preg_replace('/\s+/', '', $code);
        if ($secret === '' || !preg_match('/^\d{6}$/', $code)) {
            return false;
        }

        $timeSlice = (int) floor(time() / 30);
        for ($i = -$window; $i <= $window; $i++) {
            if (hash_equals($this->RL_GenerateTotpCode($secret, $timeSlice + $i), $code)) {
                return true;
            }
        }
        return false;
    }

    private function RL_GenerateTotpCode(string $secret, int $timeSlice): string
    {
        $binarySecret = $this->RL_Base32Decode($secret);
        if ($binarySecret === '') {
            return '000000';
        }
        $time = pack('N*', 0) . pack('N*', $timeSlice);
        $hash = hash_hmac('sha1', $time, $binarySecret, true);
        $offset = ord(substr($hash, -1)) & 0x0F;
        $part = substr($hash, $offset, 4);
        $value = unpack('N', $part)[1] & 0x7FFFFFFF;
        $otp = $value % 1000000;
        return str_pad((string) $otp, 6, '0', STR_PAD_LEFT);
    }

    public function RL_NormalizeTotpSecret(string $value): ?string
    {
        $value = strtoupper(str_replace([' ', '-'], '', trim($value)));
        if ($value === '') {
            return null;
        }
        if (preg_match('/^[A-Z2-7]+=*$/', $value)) {
            return rtrim($value, '=');
        }

        $binary = '';
        if (preg_match('/^[0-9A-F]+$/i', $value) && (strlen($value) % 2) === 0) {
            $binary = (string) (hex2bin($value) ?: '');
        }
        if ($binary === '') {
            $binary = $value;
        }

        $encoded = $this->RL_Base32Encode($binary);
        if ($encoded === '' || strlen($encoded) < 16) {
            return null;
        }
        return $encoded;
    }

    public function RL_RenderTwoFactorQr(string $otpauth, int $size = 360): ?string
    {
        $otpauth = trim($otpauth);
        if ($otpauth === '') {
            return null;
        }
        if (!class_exists('\BaconQrCode\Writer')) {
            return null;
        }
        try {
            $renderer = new \BaconQrCode\Renderer\ImageRenderer(
                new \BaconQrCode\Renderer\RendererStyle\RendererStyle($size, 8),
                new \BaconQrCode\Renderer\Image\PngImageBackEnd()
            );
            $writer = new \BaconQrCode\Writer($renderer);
            $png = $writer->writeString($otpauth);
            if ($png === '') {
                return null;
            }
            return 'data:image/png;base64,' . base64_encode($png);
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_RenderTwoFactorQr failed: ' . $e->getMessage());
            }
            return null;
        }
    }

    private function RL_GenerateTotpSecret(int $length = 32): string
    {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $bytes = random_bytes($length);
        $secret = '';
        $alphabetLength = strlen($alphabet);
        for ($i = 0; $i < $length; $i++) {
            $secret .= $alphabet[ord($bytes[$i]) % $alphabetLength];
        }
        return $secret;
    }

    private function RL_Base32Encode(string $binary): string
    {
        if ($binary === '') {
            return '';
        }
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $bits = '';
        $length = strlen($binary);
        for ($i = 0; $i < $length; $i++) {
            $bits .= str_pad(decbin(ord($binary[$i])), 8, '0', STR_PAD_LEFT);
        }
        $encoded = '';
        $bitsLength = strlen($bits);
        for ($i = 0; $i < $bitsLength; $i += 5) {
            $chunk = substr($bits, $i, 5);
            if (strlen($chunk) < 5) {
                $chunk = str_pad($chunk, 5, '0', STR_PAD_RIGHT);
            }
            $encoded .= $alphabet[bindec($chunk)];
        }
        return $encoded;
    }

    private function RL_Base32Decode(string $input): string
    {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $clean = strtoupper(preg_replace('/[^A-Z2-7]/', '', $input));
        if ($clean === '') {
            return '';
        }
        $bits = '';
        for ($i = 0, $len = strlen($clean); $i < $len; $i++) {
            $val = strpos($alphabet, $clean[$i]);
            if ($val === false) {
                continue;
            }
            $bits .= str_pad(decbin($val), 5, '0', STR_PAD_LEFT);
        }
        $binary = '';
        for ($i = 0, $len = strlen($bits); $i + 8 <= $len; $i += 8) {
            $binary .= chr(bindec(substr($bits, $i, 8)));
        }
        return $binary;
    }

    private function RL_IsPasswordStrong(string $password): bool
    {
        if (strlen($password) < 8) {
            return false;
        }
        $hasUpper = preg_match('/[A-Z]/', $password);
        $hasLower = preg_match('/[a-z]/', $password);
        $hasDigit = preg_match('/\d/', $password);
        $hasSymbol = preg_match('/[^A-Za-z0-9]/', $password);
        return $hasUpper && $hasLower && ($hasDigit || $hasSymbol);
    }

    private function RL_GenerateRecoveryCodeValue(): string
    {
        $bytes = random_bytes(4);
        $value = strtoupper(bin2hex($bytes));
        return substr($value, 0, 4) . '-' . substr($value, 4, 4);
    }

    private function RL_InternalGenerateAndStoreCodes(int $userId, int $timestamp): array
    {
        $codes = [];
        $hashes = [];
        for ($i = 0; $i < 10; $i++) {
            $code = $this->RL_GenerateRecoveryCodeValue();
            $codes[] = $code;
            $hashes[] = password_hash($code, PASSWORD_DEFAULT);
        }
        try {
            $stmt = $this->db->prepare(
                'UPDATE i_user_security SET recovery_codes = :codes, codes_generated_at = :ts, last_codes_downloaded_at = NULL, updated_at = :ts WHERE user_id = :uid LIMIT 1'
            );
            $stmt->execute([
                ':codes' => json_encode($hashes, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                ':ts' => $timestamp,
                ':uid' => $userId,
            ]);
        } catch (PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_InternalGenerateAndStoreCodes failed: ' . $e->getMessage());
            }
        }
        return $codes;
    }

    private function RL_DetectIpAddress(): string
    {
        $candidates = [
            $_SERVER['HTTP_CF_CONNECTING_IP'] ?? null,
            $_SERVER['HTTP_X_FORWARDED_FOR'] ?? null,
            $_SERVER['HTTP_X_REAL_IP'] ?? null,
            $_SERVER['REMOTE_ADDR'] ?? null,
        ];
        foreach ($candidates as $candidate) {
            if (!$candidate) {
                continue;
            }
            if (strpos($candidate, ',') !== false) {
                $parts = array_map('trim', explode(',', $candidate));
                $candidate = $parts[0];
            }
            if (filter_var($candidate, FILTER_VALIDATE_IP)) {
                return $candidate;
            }
        }
        return '0.0.0.0';
    }

    private function RL_ParseUserAgent(string $ua): array
    {
        $ua = trim($ua);
        $device = 'Desktop';
        $browser = 'Unknown';
        $platform = 'Unknown';

        if ($ua === '') {
            return ['device' => $device, 'browser' => $browser, 'platform' => $platform];
        }

        $lower = strtolower($ua);

        if (strpos($lower, 'iphone') !== false) { $device = 'iPhone'; $platform = 'iOS'; }
        elseif (strpos($lower, 'ipad') !== false) { $device = 'iPad'; $platform = 'iPadOS'; }
        elseif (strpos($lower, 'android') !== false) { $device = 'Android'; $platform = 'Android'; }
        elseif (strpos($lower, 'mac os x') !== false) { $platform = 'macOS'; }
        elseif (strpos($lower, 'windows') !== false) { $platform = 'Windows'; }
        elseif (strpos($lower, 'linux') !== false) { $platform = 'Linux'; }

        if (strpos($lower, 'edg/') !== false) { $browser = 'Edge'; }
        elseif (strpos($lower, 'chrome/') !== false) { $browser = 'Chrome'; }
        elseif (strpos($lower, 'safari/') !== false && strpos($lower, 'chrome/') === false) { $browser = 'Safari'; }
        elseif (strpos($lower, 'firefox/') !== false) { $browser = 'Firefox'; }

        if (in_array($device, ['Desktop', 'Unknown'], true)) {
            if (strpos($lower, 'mobile') !== false) {
                $device = 'Mobile';
            }
        }

        return [
            'device' => $device,
            'browser' => $browser,
            'platform' => $platform,
        ];
    }

    private function RL_MaskSessionKey(string $sessionKey): string
    {
        if (strlen($sessionKey) <= 8) {
            return $sessionKey;
        }
        return substr($sessionKey, 0, 4) . '…' . substr($sessionKey, -4);
    }
}
