<?php
declare(strict_types=1);
trait FeedFunctions {
    /**
     * Fetch posts joined with owner info and the viewer->owner relationship.
     *
     * NOTE:
     * - This method DOES NOT decide visibility. It only returns data required
     *   to make a decision in post.php (multi-language friendly).
     * - Relationship precedence we surface via a single status:
     *     'subscriber' > 'flwr' > 'me' (or NULL if no relation found).
     *
     * @param int $userID Current viewer user_id (0 or negative if guest).
     * @param int $limit  Pagination size.
     * @param int $offset Pagination offset.
     * @return array<int, array<string, mixed>>
     */
    public function RL_FeedWithRelations(int $userID, int $limit = 20, int $offset = 0): array
    {
        $feedLang = isset($GLOBALS['currentLang']) && is_string($GLOBALS['currentLang']) ? strtolower((string) $GLOBALS['currentLang']) : 'eng';
        if ($feedLang === '') {
            $feedLang = 'eng';
        }
        try {
            $limit  = max(1, (int) $limit);
            $offset = max(0, (int) $offset);

            if (method_exists($this, 'RL_EnsurePodcastCategoriesTable')) {
                $this->RL_EnsurePodcastCategoriesTable();
            }

            $sql = "
                SELECT
                    p.post_id,
                    p.post_owner_id,
                    p.post_type,
                    p.post_file,
                    p.audio_duration_seconds,
                    p.podcast_category_id,
                    p.locked_preview_path,
                    p.locked_preview_type,
                    p.post_text,
                    p.post_visibility,
                    p.post_price,
                    p.comment_status,
                    p.like_status,
                    p.approval_status,
                    p.approval_notes,
                    p.approved_at,
                    p.approved_by,
                    p.post_created_time,

                    u.user_id         AS owner_id,
                    u.username        AS owner_username,
                    u.user_fullname   AS owner_fullname,
                    u.user_avatar     AS owner_avatar,
                    u.verified_status AS owner_verified,

                    rel.fr_status     AS relation_status,

                    COALESCE(pct.name, pc.name)  AS podcast_category_name,
                    pc.slug  AS podcast_category_slug,
                    pc.status AS podcast_category_status
                FROM i_user_posts AS p
                INNER JOIN i_users AS u
                    ON u.user_id = p.post_owner_id
                LEFT JOIN i_podcast_categories AS pc
                    ON pc.id = p.podcast_category_id
                LEFT JOIN i_podcast_category_translations AS pct
                    ON pct.category_id = pc.id AND pct.language = :cat_lang
                LEFT JOIN (
                    /* Collapse relation to a single prioritized status per owner */
                    SELECT
                        rel_inner.other_id,
                        SUBSTRING_INDEX(
                            GROUP_CONCAT(
                                rel_inner.fr_status
                                ORDER BY FIELD(rel_inner.fr_status, 'subscriber', 'flwr', 'me') DESC
                                SEPARATOR ','
                            ),
                            ',', 1
                        ) AS fr_status
                    FROM (
                        SELECT fr_two AS other_id, fr_status
                        FROM i_friends
                        WHERE fr_one = :uid_rel1
                        UNION ALL
                        SELECT fr_one AS other_id, fr_status
                        FROM i_friends
                        WHERE fr_two = :uid_rel2
                    ) AS rel_inner
                    GROUP BY rel_inner.other_id
                ) AS rel
                    ON rel.other_id = p.post_owner_id
                WHERE ((p.approval_status IS NULL OR p.approval_status = 'approved') OR p.post_owner_id = :uid_self_filter)
                ORDER BY p.post_created_time DESC
                LIMIT $offset, $limit
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':uid_rel1', $userID, \PDO::PARAM_INT);
            $stmt->bindValue(':uid_rel2', $userID, \PDO::PARAM_INT);
            $stmt->bindValue(':uid_self_filter', $userID, \PDO::PARAM_INT);
            $stmt->bindValue(':cat_lang', $feedLang, \PDO::PARAM_STR);
            $stmt->execute();

            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            $feed = [];
            foreach ($rows as $row) {
                $ownerId = (int) $row['post_owner_id'];

                $feed[] = [
                    // Post fields
                    'post_id'           => (int) $row['post_id'],
                    'post_owner_id'     => $ownerId,
                    'post_type'         => (string) $row['post_type'],
                    'post_file'         => (string) $row['post_file'],
                    'audio_duration_seconds' => $row['audio_duration_seconds'] !== null ? (int) $row['audio_duration_seconds'] : null,
                    'podcast_category_id' => $row['podcast_category_id'] !== null ? (int) $row['podcast_category_id'] : null,
                    'podcast_category_name' => isset($row['podcast_category_name']) ? (string) $row['podcast_category_name'] : null,
                    'podcast_category_slug' => isset($row['podcast_category_slug']) ? (string) $row['podcast_category_slug'] : null,
                    'podcast_category_status' => isset($row['podcast_category_status']) ? (string) $row['podcast_category_status'] : null,
                    'locked_preview_path' => $row['locked_preview_path'] !== null ? (string) $row['locked_preview_path'] : '',
                    'locked_preview_type' => $row['locked_preview_type'] !== null ? (string) $row['locked_preview_type'] : null,
                    'post_text'         => (string) $row['post_text'],
                    'post_visibility'   => (string) $row['post_visibility'],
                    'post_price'        => $row['post_price'] !== null ? (string) $row['post_price'] : null,
                    'comment_status'    => (string) $row['comment_status'],
                    'like_status'       => (string) $row['like_status'],
                    'approval_status'   => isset($row['approval_status']) ? (string)$row['approval_status'] : 'approved',
                    'approval_notes'    => $row['approval_notes'] !== null ? (string)$row['approval_notes'] : null,
                    'approved_at'       => $row['approved_at'] !== null ? (int)$row['approved_at'] : null,
                    'approved_by'       => $row['approved_by'] !== null ? (int)$row['approved_by'] : null,
                    'post_created_time' => (int) $row['post_created_time'],

                    // Owner fields
                    'owner_id'          => (int) $row['owner_id'],
                    'owner_username'    => (string) $row['owner_username'],
                    'owner_fullname'    => (string) $row['owner_fullname'],
                    'owner_avatar'      => (string) $row['owner_avatar'],
                    'owner_verified'    => (int) $row['owner_verified'],

                    // Relationship
                    'relation_status'   => $row['relation_status'] !== null ? (string) $row['relation_status'] : null,

                    // Convenience flag for post.php (self check without language strings)
                    'is_owner'          => ($userID > 0 && $userID === $ownerId),
                ];
            }

            return $feed;
        } catch (\Throwable $e) {
            $this->logError('RL_FeedWithRelations failed: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Fetch posts ONLY from users who have a relation with the viewer (friend/follower/subscriber or self).
     *
     * Rules:
     *  - Returns posts where a relation exists in i_friends between $userID and post_owner_id (in either direction),
     *    or the post is owned by the viewer (self).
     *  - No visibility decision is made here; post.php will decide (multi-language friendly).
     *  - Relation precedence is surfaced via single status: 'subscriber' > 'flwr' > 'me'.
     *
     * @param int $userID Current viewer user_id (must be > 0 to build a related feed).
     * @param int $limit  Pagination size.
     * @param int $offset Pagination offset.
     * @return array<int, array<string, mixed>>
     */
    public function RL_FeedOnlyRelated(int $userID, int $limit = 20, int $offset = 0): array
    {
        $feedLang = isset($GLOBALS['currentLang']) && is_string($GLOBALS['currentLang']) ? strtolower((string) $GLOBALS['currentLang']) : 'eng';
        if ($feedLang === '') {
            $feedLang = 'eng';
        }
        try {
            if ($userID <= 0) {
                return [];
            }

            if (method_exists($this, 'RL_EnsurePodcastCategoriesTable')) {
                $this->RL_EnsurePodcastCategoriesTable();
            }

            $limit  = max(1, (int) $limit);
            $offset = max(0, (int) $offset);

            // Build relation map from i_friends (both directions), collapsed to one status per other_id
            $sql = "
                SELECT
                    p.post_id,
                    p.post_owner_id,
                    p.post_type,
                    p.post_file,
                    p.audio_duration_seconds,
                    p.podcast_category_id,
                    p.locked_preview_path,
                    p.locked_preview_type,
                    p.post_text,
                    p.post_visibility,
                    p.post_price,
                    p.comment_status,
                    p.like_status,
                    p.approval_status,
                    p.approval_notes,
                    p.approved_at,
                    p.approved_by,
                    p.post_created_time,

                    u.user_id         AS owner_id,
                    u.username        AS owner_username,
                    u.user_fullname   AS owner_fullname,
                    u.user_avatar     AS owner_avatar,
                    u.verified_status AS owner_verified,

                    rel.fr_status     AS relation_status,

                    COALESCE(pct.name, pc.name)  AS podcast_category_name,
                    pc.slug  AS podcast_category_slug,
                    pc.status AS podcast_category_status
                FROM i_user_posts AS p
                INNER JOIN i_users AS u
                    ON u.user_id = p.post_owner_id
                LEFT JOIN i_podcast_categories AS pc
                    ON pc.id = p.podcast_category_id
                LEFT JOIN i_podcast_category_translations AS pct
                    ON pct.category_id = pc.id AND pct.language = :cat_lang
                LEFT JOIN (
                    SELECT
                        rel_inner.other_id,
                        SUBSTRING_INDEX(
                            GROUP_CONCAT(
                                rel_inner.fr_status
                                ORDER BY FIELD(rel_inner.fr_status, 'subscriber', 'flwr', 'me') DESC
                                SEPARATOR ','
                            ),
                            ',', 1
                        ) AS fr_status
                    FROM (
                        SELECT fr_two AS other_id, fr_status
                        FROM i_friends
                        WHERE fr_one = :uid_rel1
                        UNION ALL
                        SELECT fr_one AS other_id, fr_status
                        FROM i_friends
                        WHERE fr_two = :uid_rel2
                    ) AS rel_inner
                    GROUP BY rel_inner.other_id
                ) AS rel
                    ON rel.other_id = p.post_owner_id
                WHERE (rel.other_id IS NOT NULL OR p.post_owner_id = :uid_self_owner)
                AND ((p.approval_status IS NULL OR p.approval_status = 'approved') OR p.post_owner_id = :uid_self_approval)
                ORDER BY p.post_created_time DESC
                LIMIT $offset, $limit
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':uid_rel1', $userID, \PDO::PARAM_INT);
            $stmt->bindValue(':uid_rel2', $userID, \PDO::PARAM_INT);
            $stmt->bindValue(':uid_self_owner', $userID, \PDO::PARAM_INT);
            $stmt->bindValue(':uid_self_approval', $userID, \PDO::PARAM_INT);
            $stmt->bindValue(':cat_lang', $feedLang, \PDO::PARAM_STR);
            $stmt->execute();

            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            $feed = [];
            foreach ($rows as $row) {
                $ownerId = (int) $row['post_owner_id'];
                $feed[] = [
                    'post_id'           => (int) $row['post_id'],
                    'post_owner_id'     => $ownerId,
                    'post_type'         => (string) $row['post_type'],
                    'post_file'         => (string) $row['post_file'],
                    'audio_duration_seconds' => $row['audio_duration_seconds'] !== null ? (int) $row['audio_duration_seconds'] : null,
                    'podcast_category_id' => $row['podcast_category_id'] !== null ? (int) $row['podcast_category_id'] : null,
                    'podcast_category_name' => isset($row['podcast_category_name']) ? (string) $row['podcast_category_name'] : null,
                    'podcast_category_slug' => isset($row['podcast_category_slug']) ? (string) $row['podcast_category_slug'] : null,
                    'podcast_category_status' => isset($row['podcast_category_status']) ? (string) $row['podcast_category_status'] : null,
                    'locked_preview_path' => $row['locked_preview_path'] !== null ? (string) $row['locked_preview_path'] : '',
                    'locked_preview_type' => $row['locked_preview_type'] !== null ? (string) $row['locked_preview_type'] : null,
                    'post_text'         => (string) $row['post_text'],
                    'post_visibility'   => (string) $row['post_visibility'],
                    'post_price'        => $row['post_price'] !== null ? (string) $row['post_price'] : null,
                    'comment_status'    => (string) $row['comment_status'],
                    'like_status'       => (string) $row['like_status'],
                    'approval_status'   => isset($row['approval_status']) ? (string)$row['approval_status'] : 'approved',
                    'approval_notes'    => $row['approval_notes'] !== null ? (string)$row['approval_notes'] : null,
                    'approved_at'       => $row['approved_at'] !== null ? (int)$row['approved_at'] : null,
                    'approved_by'       => $row['approved_by'] !== null ? (int)$row['approved_by'] : null,
                    'post_created_time' => (int) $row['post_created_time'],

                    'owner_id'          => (int) $row['owner_id'],
                    'owner_username'    => (string) $row['owner_username'],
                    'owner_fullname'    => (string) $row['owner_fullname'],
                    'owner_avatar'      => (string) $row['owner_avatar'],
                    'owner_verified'    => (int) $row['owner_verified'],

                    'relation_status'   => $row['relation_status'] !== null ? (string) $row['relation_status'] : null,
                    'is_owner'          => ($userID > 0 && $userID === $ownerId),
                ];
            }

            return $feed;
        } catch (\Throwable $e) {
            $this->logError('RL_FeedOnlyRelated failed: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Fetch posts visible to the viewer based on RELATION + VISIBILITY at SQL level.
     *
     * Rules:
     *  - Include ONLY posts where a directional relation exists (viewer -> owner) OR self.
     *  - If relation = 'subscriber'  -> allow owner's posts with visibility IN ('subscribers','followers','everyone').
     *  - If relation = 'flwr'        -> allow owner's posts with visibility IN ('followers','everyone').
     *  - Self (owner == viewer)      -> allow all posts by self.
     *  - NOTE: This function intentionally EXCLUDES unrelated users entirely (even 'everyone').
     *  - NOTE: Locked visibility is not included here; locked/paywall control should be handled separately.
     *
     * @param int $userID  Current viewer ID (>0 required)
     * @param int $limit   Pagination size
     * @param int $offset  Pagination offset
     * @return array<int, array<string,mixed>>
     */
    public function RL_FeedRelatedVisible(int $userID, int $limit = 20, int $offset = 0, ?string $postTypeFilter = null): array
    {
        $feedLang = isset($GLOBALS['currentLang']) && is_string($GLOBALS['currentLang']) ? strtolower((string) $GLOBALS['currentLang']) : 'eng';
        if ($feedLang === '') {
            $feedLang = 'eng';
        }
        try {
            if ($userID <= 0) {
                return [];
            }

            if (method_exists($this, 'RL_EnsurePodcastCategoriesTable')) {
                $this->RL_EnsurePodcastCategoriesTable();
            }

            $limit  = max(1, (int) $limit);
            $offset = max(0, (int) $offset);
            $postTypeFilter = $postTypeFilter !== null ? strtolower(trim((string) $postTypeFilter)) : null;
            if (!in_array($postTypeFilter, ['video', 'image', 'podcast'], true)) {
                $postTypeFilter = null;
            }

            $sql = "
                SELECT
                    p.post_id,
                    p.post_owner_id,
                    p.post_type,
                    p.post_file,
                    p.audio_duration_seconds,
                    p.podcast_category_id,
                    p.locked_preview_path,
                    p.locked_preview_type,
                    p.post_text,
                    p.post_visibility,
                    p.post_price,
                    p.comment_status,
                    p.like_status,
                    p.approval_status,
                    p.approval_notes,
                    p.approved_at,
                    p.approved_by,
                    p.post_created_time,

                    u.user_id         AS owner_id,
                    u.username        AS owner_username,
                    u.user_fullname   AS owner_fullname,
                    u.user_avatar     AS owner_avatar,
                    u.verified_status AS owner_verified,

                    rel_v2o.fr_status AS viewer_to_owner_status,

                    COALESCE(pct.name, pc.name)  AS podcast_category_name,
                    pc.slug  AS podcast_category_slug,
                    pc.status AS podcast_category_status
                FROM i_user_posts AS p
                INNER JOIN i_users AS u
                    ON u.user_id = p.post_owner_id
                LEFT JOIN i_podcast_categories AS pc
                    ON pc.id = p.podcast_category_id
                LEFT JOIN i_podcast_category_translations AS pct
                    ON pct.category_id = pc.id AND pct.language = :cat_lang
                /* Directional relation: viewer -> owner */
                LEFT JOIN (
                    SELECT fr_two AS other_id,
                        SUBSTRING_INDEX(
                            GROUP_CONCAT(fr_status ORDER BY FIELD(fr_status,'subscriber','flwr','me') DESC SEPARATOR ','),
                            ',', 1
                        ) AS fr_status
                    FROM i_friends
                    WHERE fr_one = :uid_v2o
                    GROUP BY fr_two
                ) AS rel_v2o
                    ON rel_v2o.other_id = p.post_owner_id
                WHERE (
                    /* self posts always allowed */
                    p.post_owner_id = :uid_self_view
                    OR (
                        /* require a relation in viewer->owner direction */
                        rel_v2o.other_id IS NOT NULL
                    )
                )
                AND ((p.approval_status IS NULL OR p.approval_status = 'approved') OR p.post_owner_id = :uid_self_approval)
            ";
            if ($postTypeFilter !== null) {
                $sql .= " AND p.post_type = :post_type";
            }
            $sql .= "
                ORDER BY p.post_created_time DESC
                LIMIT $offset, $limit
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':uid_v2o', $userID, \PDO::PARAM_INT);
            $stmt->bindValue(':uid_self_view', $userID, \PDO::PARAM_INT);
            $stmt->bindValue(':uid_self_approval', $userID, \PDO::PARAM_INT);
            $stmt->bindValue(':cat_lang', $feedLang, \PDO::PARAM_STR);
            if ($postTypeFilter !== null) {
                $stmt->bindValue(':post_type', $postTypeFilter, \PDO::PARAM_STR);
            }
            $stmt->execute();

            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            $feed = [];
            foreach ($rows as $row) {
                $ownerId = (int) $row['post_owner_id'];
                $feed[] = [
                    'post_id'           => (int) $row['post_id'],
                    'post_owner_id'     => $ownerId,
                    'post_type'         => (string) $row['post_type'],
                    'post_file'         => (string) $row['post_file'],
                    'audio_duration_seconds' => $row['audio_duration_seconds'] !== null ? (int) $row['audio_duration_seconds'] : null,
                    'podcast_category_id' => $row['podcast_category_id'] !== null ? (int) $row['podcast_category_id'] : null,
                    'podcast_category_name' => isset($row['podcast_category_name']) ? (string) $row['podcast_category_name'] : null,
                    'podcast_category_slug' => isset($row['podcast_category_slug']) ? (string) $row['podcast_category_slug'] : null,
                    'podcast_category_status' => isset($row['podcast_category_status']) ? (string) $row['podcast_category_status'] : null,
                    'locked_preview_path' => $row['locked_preview_path'] !== null ? (string) $row['locked_preview_path'] : '',
                    'locked_preview_type' => $row['locked_preview_type'] !== null ? (string) $row['locked_preview_type'] : null,
                    'post_text'         => (string) $row['post_text'],
                    'post_visibility'   => (string) $row['post_visibility'],
                    'post_price'        => $row['post_price'] !== null ? (string) $row['post_price'] : null,
                    'comment_status'    => (string) $row['comment_status'],
                    'like_status'       => (string) $row['like_status'],
                    'approval_status'   => isset($row['approval_status']) ? (string)$row['approval_status'] : 'approved',
                    'approval_notes'    => $row['approval_notes'] !== null ? (string)$row['approval_notes'] : null,
                    'approved_at'       => $row['approved_at'] !== null ? (int)$row['approved_at'] : null,
                    'approved_by'       => $row['approved_by'] !== null ? (int)$row['approved_by'] : null,
                    'post_created_time' => (int) $row['post_created_time'],

                    'owner_id'          => (int) $row['owner_id'],
                    'owner_username'    => (string) $row['owner_username'],
                    'owner_fullname'    => (string) $row['owner_fullname'],
                    'owner_avatar'      => (string) $row['owner_avatar'],
                    'owner_verified'    => (int) $row['owner_verified'],

                    'viewer_to_owner_status' => $row['viewer_to_owner_status'] !== null ? (string) $row['viewer_to_owner_status'] : null,
                    'is_owner'          => ($userID > 0 && $userID === $ownerId),
                ];
            }

            return $feed;
        } catch (\Throwable $e) {
            $this->logError('RL_FeedRelatedVisible failed: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Guest feed: return posts for configured admin accounts (recent first).
     *
     * @param int $limit
     * @param int $offset
     * @return array<int, array<string, mixed>>
     */
    public function RL_GetGuestFeedPosts(int $limit = 20, int $offset = 0): array
    {
        try {
            if (!method_exists($this, 'RL_GetGuestFeedConfig')) {
                return [];
            }

            $config = $this->RL_GetGuestFeedConfig();
            $mode = $config['guest_feed_mode'] ?? '';
            if ($mode !== 'admin_only') {
                if (method_exists($this, 'logError')) {
                    $this->logError('Guest feed disabled (mode=' . $mode . ')');
                }
                return [];
            }

            $limit = max(1, (int) $limit);
            $offset = max(0, (int) $offset);

            $adminIds = $config['guest_admin_ids'] ?? [];
            if (!is_array($adminIds)) {
                $adminIds = [];
            }
            $adminIds = array_values(array_unique(array_filter(array_map('intval', $adminIds), static fn(int $id): bool => $id > 0)));
            if ($adminIds === [] && method_exists($this, 'logError')) {
                $this->logError('Guest feed admin list empty; using public fallback (offset=' . $offset . ', limit=' . $limit . ')');
            }

                $formatRow = static function(array $row): array {
                    return [
                        'post_id'           => (int) $row['post_id'],
                        'post_owner_id'     => (int) $row['post_owner_id'],
                        'post_type'         => (string) $row['post_type'],
                        'post_file'         => (string) $row['post_file'],
                        'post_text'         => (string) $row['post_text'],
                        'post_visibility'   => (string) $row['post_visibility'],
                        'post_price'        => $row['post_price'] !== null ? (string) $row['post_price'] : null,
                        'comment_status'    => (string) $row['comment_status'],
                        'like_status'       => (string) $row['like_status'],
                        'approval_status'   => isset($row['approval_status']) ? (string)$row['approval_status'] : 'approved',
                        'approval_notes'    => $row['approval_notes'] !== null ? (string)$row['approval_notes'] : null,
                        'approved_at'       => $row['approved_at'] !== null ? (int)$row['approved_at'] : null,
                        'approved_by'       => $row['approved_by'] !== null ? (int)$row['approved_by'] : null,
                        'post_created_time' => (int) $row['post_created_time'],
                        'owner_id'          => (int) $row['owner_id'],
                        'owner_username'    => (string) $row['owner_username'],
                        'owner_fullname'    => (string) $row['owner_fullname'],
                        'owner_avatar'      => (string) $row['owner_avatar'],
                    'owner_verified'    => (int) $row['owner_verified'],
                    'viewer_to_owner_status' => null,
                    'relation_status'       => null,
                    'is_owner'              => false,
                ];
            };

            $feed = [];
            $capturedPostIds = [];
            $usedFallback = false;

            if ($adminIds !== []) {
                $idsSql = implode(',', array_map('intval', $adminIds));
                $sql = "
                    SELECT
                        p.post_id,
                        p.post_owner_id,
                        p.post_type,
                        p.post_file,
                        p.post_text,
                        p.post_visibility,
                        p.post_price,
                        p.comment_status,
                        p.like_status,
                        p.approval_status,
                        p.approval_notes,
                        p.approved_at,
                        p.approved_by,
                        p.post_created_time,

                        u.user_id         AS owner_id,
                        u.username        AS owner_username,
                        u.user_fullname   AS owner_fullname,
                        u.user_avatar     AS owner_avatar,
                        u.verified_status AS owner_verified
                    FROM i_user_posts AS p
                    INNER JOIN i_users AS u ON u.user_id = p.post_owner_id
                    WHERE p.post_owner_id IN ($idsSql) AND (p.approval_status IS NULL OR p.approval_status = 'approved')
                    ORDER BY p.post_created_time DESC
                    LIMIT $offset, $limit
                ";

                $stmt = $this->db->query($sql);
                $rows = $stmt ? $stmt->fetchAll(\PDO::FETCH_ASSOC) : [];
                foreach ($rows as $row) {
                    $feed[] = $formatRow($row);
                    $capturedPostIds[] = (int) $row['post_id'];
                }
                if (method_exists($this, 'logError')) {
                    $this->logError('Guest feed primary fetched ' . count($rows) . ' posts (offset=' . $offset . ', limit=' . $limit . ')');
                }
            }

            $needsFallback = ($adminIds === [] && $offset >= 0) || ($offset === 0 && count($feed) < $limit);

            if ($needsFallback) {
                $fallbackOffset = ($adminIds === []) ? $offset : 0;
                $remaining = $limit - count($feed);
                if ($remaining <= 0) { $remaining = $limit; }
                $fallbackLimit = $remaining + 1;

                $conditions = ["p.post_visibility = 'everyone'", "(p.approval_status IS NULL OR p.approval_status = 'approved')"];
                if ($adminIds !== []) {
                    $conditions[] = 'p.post_owner_id NOT IN (' . implode(',', array_map('intval', $adminIds)) . ')';
                }
                if ($capturedPostIds !== []) {
                    $conditions[] = 'p.post_id NOT IN (' . implode(',', array_map('intval', $capturedPostIds)) . ')';
                }
                $where = implode(' AND ', $conditions);

                $sqlFallback = "
                    SELECT
                        p.post_id,
                        p.post_owner_id,
                        p.post_type,
                        p.post_file,
                        p.post_text,
                        p.post_visibility,
                        p.post_price,
                        p.comment_status,
                        p.like_status,
                        p.approval_status,
                        p.approval_notes,
                        p.approved_at,
                        p.approved_by,
                        p.post_created_time,

                        u.user_id         AS owner_id,
                        u.username        AS owner_username,
                        u.user_fullname   AS owner_fullname,
                        u.user_avatar     AS owner_avatar,
                        u.verified_status AS owner_verified
                    FROM i_user_posts AS p
                    INNER JOIN i_users AS u ON u.user_id = p.post_owner_id
                    WHERE $where
                    ORDER BY p.post_created_time DESC
                    LIMIT $fallbackOffset, $fallbackLimit
                ";

                $stmtFallback = $this->db->query($sqlFallback);
                $fallbackRows = $stmtFallback ? $stmtFallback->fetchAll(\PDO::FETCH_ASSOC) : [];
                foreach ($fallbackRows as $row) {
                    $feed[] = $formatRow($row);
                }
                $usedFallback = true;
                if (method_exists($this, 'logError')) {
                    $this->logError('Guest feed fallback fetched ' . count($fallbackRows) . ' posts (remaining=' . $remaining . ', offset=' . $fallbackOffset . ')');
                }
            }

            if (count($feed) > $limit) {
                $feed = array_slice($feed, 0, $limit);
            }

            $finalCount = count($feed);
            if (method_exists($this, 'logError')) {
                $this->logError('Guest feed final count=' . $finalCount . ' (offset=' . $offset . ', limit=' . $limit . ', fallback=' . ($usedFallback ? 'yes' : 'no') . ')');
            }
            if ($offset === 0 && $finalCount <= 1 && method_exists($this, 'logError')) {
                $this->logError('Guest feed initial load still <=1 item after fallback. Admin IDs: ' . implode(',', $adminIds));
            }

            return $feed;
        } catch (\Throwable $e) {
            $this->logError('RL_GetGuestFeedPosts failed: ' . $e->getMessage());
            return [];
        }
    }
}
