<?php
declare(strict_types=1);

trait EbookFunctions
{
    private function RL_EnsureEbookTables(): void
    {
        try {
            $this->db->exec(
                "CREATE TABLE IF NOT EXISTS i_ebooks (
                    ebook_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    owner_id INT UNSIGNED NOT NULL,
                    title VARCHAR(190) NOT NULL,
                    slug VARCHAR(220) NOT NULL,
                    short_description VARCHAR(500) NULL,
                    description TEXT NULL,
                    cover_path VARCHAR(255) NULL,
                    file_path VARCHAR(255) NOT NULL,
                    file_name VARCHAR(190) NULL,
                    file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
                    sample_path VARCHAR(255) NULL,
                    isbn VARCHAR(32) NULL,
                    language_code VARCHAR(35) NOT NULL DEFAULT 'en',
                    page_count INT UNSIGNED NOT NULL DEFAULT 0,
                    publication_date DATE NULL,
                    version_label VARCHAR(40) NULL,
                    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                    currency VARCHAR(10) NOT NULL DEFAULT 'USD',
                    status VARCHAR(24) NOT NULL DEFAULT 'active',
                    moderation_note VARCHAR(500) NULL,
                    submitted_at INT UNSIGNED NULL,
                    approved_at INT UNSIGNED NULL,
                    approved_by INT UNSIGNED NULL,
                    featured TINYINT(1) NOT NULL DEFAULT 0,
                    download_limit INT UNSIGNED NOT NULL DEFAULT 5,
                    access_days INT UNSIGNED NOT NULL DEFAULT 0,
                    seo_title VARCHAR(190) NULL,
                    seo_description VARCHAR(320) NULL,
                    view_count INT UNSIGNED NOT NULL DEFAULT 0,
                    sales_count INT UNSIGNED NOT NULL DEFAULT 0,
                    rating_average DECIMAL(3,2) NOT NULL DEFAULT 0.00,
                    rating_count INT UNSIGNED NOT NULL DEFAULT 0,
                    download_count INT UNSIGNED NOT NULL DEFAULT 0,
                    created_at INT UNSIGNED NOT NULL,
                    updated_at INT UNSIGNED NULL,
                    PRIMARY KEY (ebook_id),
                    UNIQUE KEY uniq_ebook_slug (slug),
                    KEY idx_owner_status_created (owner_id, status, created_at),
                    KEY idx_status_created (status, created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
            );
            $this->db->exec(
                "CREATE TABLE IF NOT EXISTS i_ebook_purchases (
                    purchase_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    ebook_id INT UNSIGNED NOT NULL,
                    buyer_id INT UNSIGNED NOT NULL,
                    seller_id INT UNSIGNED NOT NULL,
                    provider VARCHAR(32) NOT NULL DEFAULT 'wallet',
                    reference VARCHAR(191) NOT NULL,
                    amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                    currency VARCHAR(10) NOT NULL DEFAULT 'USD',
                    status VARCHAR(32) NOT NULL DEFAULT 'succeeded',
                    raw_payload MEDIUMTEXT NULL,
                    created_at INT UNSIGNED NOT NULL,
                    updated_at INT UNSIGNED NULL,
                    PRIMARY KEY (purchase_id),
                    UNIQUE KEY uniq_buyer_ebook (buyer_id, ebook_id),
                    UNIQUE KEY uniq_provider_reference (provider, reference),
                    KEY idx_ebook (ebook_id),
                    KEY idx_seller (seller_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
            );
            $this->db->exec(
                "CREATE TABLE IF NOT EXISTS i_ebook_categories (
                    category_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    parent_id INT UNSIGNED NULL,
                    name VARCHAR(120) NOT NULL,
                    slug VARCHAR(140) NOT NULL,
                    description VARCHAR(500) NULL,
                    icon_key VARCHAR(100) NULL,
                    sort_order INT NOT NULL DEFAULT 0,
                    status VARCHAR(20) NOT NULL DEFAULT 'active',
                    created_at INT UNSIGNED NOT NULL,
                    updated_at INT UNSIGNED NULL,
                    PRIMARY KEY (category_id),
                    UNIQUE KEY uniq_ebook_category_slug (slug),
                    KEY idx_ebook_category_status_sort (status, sort_order)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
            );
            $this->db->exec(
                "CREATE TABLE IF NOT EXISTS i_ebook_category_map (
                    ebook_id INT UNSIGNED NOT NULL,
                    category_id INT UNSIGNED NOT NULL,
                    created_at INT UNSIGNED NOT NULL,
                    PRIMARY KEY (ebook_id, category_id),
                    KEY idx_ebook_category_map_category (category_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
            );
            $this->db->exec(
                "CREATE TABLE IF NOT EXISTS i_ebook_files (
                    file_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    ebook_id INT UNSIGNED NOT NULL,
                    version_label VARCHAR(40) NULL,
                    file_path VARCHAR(255) NOT NULL,
                    file_name VARCHAR(190) NULL,
                    file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
                    mime_type VARCHAR(120) NULL,
                    checksum_sha256 CHAR(64) NULL,
                    is_current TINYINT(1) NOT NULL DEFAULT 1,
                    created_by INT UNSIGNED NOT NULL,
                    created_at INT UNSIGNED NOT NULL,
                    PRIMARY KEY (file_id),
                    KEY idx_ebook_files_current (ebook_id, is_current),
                    KEY idx_ebook_files_created (ebook_id, created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
            );
            $this->db->exec(
                "CREATE TABLE IF NOT EXISTS i_ebook_entitlements (
                    entitlement_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    ebook_id INT UNSIGNED NOT NULL,
                    user_id INT UNSIGNED NOT NULL,
                    purchase_id INT UNSIGNED NULL,
                    source VARCHAR(32) NOT NULL DEFAULT 'purchase',
                    status VARCHAR(24) NOT NULL DEFAULT 'active',
                    download_limit INT UNSIGNED NOT NULL DEFAULT 5,
                    download_count INT UNSIGNED NOT NULL DEFAULT 0,
                    starts_at INT UNSIGNED NOT NULL,
                    expires_at INT UNSIGNED NULL,
                    revoked_at INT UNSIGNED NULL,
                    revoke_reason VARCHAR(255) NULL,
                    created_at INT UNSIGNED NOT NULL,
                    updated_at INT UNSIGNED NULL,
                    PRIMARY KEY (entitlement_id),
                    UNIQUE KEY uniq_ebook_entitlement_user (ebook_id, user_id),
                    KEY idx_ebook_entitlement_user_status (user_id, status),
                    KEY idx_ebook_entitlement_purchase (purchase_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
            );
            $this->db->exec(
                "CREATE TABLE IF NOT EXISTS i_ebook_downloads (
                    download_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    entitlement_id INT UNSIGNED NOT NULL,
                    ebook_id INT UNSIGNED NOT NULL,
                    user_id INT UNSIGNED NOT NULL,
                    file_id INT UNSIGNED NULL,
                    token_hash CHAR(64) NULL,
                    ip_address VARCHAR(64) NULL,
                    user_agent VARCHAR(500) NULL,
                    bytes_sent BIGINT UNSIGNED NOT NULL DEFAULT 0,
                    status VARCHAR(24) NOT NULL DEFAULT 'started',
                    created_at INT UNSIGNED NOT NULL,
                    completed_at INT UNSIGNED NULL,
                    PRIMARY KEY (download_id),
                    KEY idx_ebook_download_entitlement (entitlement_id, created_at),
                    KEY idx_ebook_download_user (user_id, created_at),
                    KEY idx_ebook_download_token (token_hash)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
            );
            $this->db->exec(
                "CREATE TABLE IF NOT EXISTS i_ebook_reviews (
                    review_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    ebook_id INT UNSIGNED NOT NULL,
                    user_id INT NOT NULL,
                    rating TINYINT UNSIGNED NOT NULL,
                    review_text TEXT NULL,
                    status VARCHAR(20) NOT NULL DEFAULT 'active',
                    verified_purchase TINYINT(1) NOT NULL DEFAULT 0,
                    created_at INT UNSIGNED NOT NULL,
                    updated_at INT UNSIGNED NOT NULL,
                    PRIMARY KEY (review_id),
                    UNIQUE KEY uniq_ebook_review_user (ebook_id, user_id),
                    KEY idx_ebook_review_status (ebook_id, status, created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
            );
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_ebook_wishlist (ebook_id INT UNSIGNED NOT NULL,user_id INT NOT NULL,created_at INT UNSIGNED NOT NULL,PRIMARY KEY(ebook_id,user_id),KEY idx_ebook_wishlist_user(user_id,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_ebook_coupons (coupon_id INT UNSIGNED NOT NULL AUTO_INCREMENT,code VARCHAR(64) NOT NULL,ebook_id INT UNSIGNED NULL,discount_type VARCHAR(16) NOT NULL DEFAULT 'percent',discount_value DECIMAL(10,2) NOT NULL,min_order DECIMAL(10,2) NOT NULL DEFAULT 0,max_uses INT UNSIGNED NOT NULL DEFAULT 0,used_count INT UNSIGNED NOT NULL DEFAULT 0,starts_at INT UNSIGNED NULL,ends_at INT UNSIGNED NULL,status VARCHAR(20) NOT NULL DEFAULT 'active',created_at INT UNSIGNED NOT NULL,updated_at INT UNSIGNED NULL,PRIMARY KEY(coupon_id),UNIQUE KEY uniq_ebook_coupon_code(code),KEY idx_ebook_coupon_status(status,starts_at,ends_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
            $this->RL_EnsureEbookLanguageTables();
            $this->RL_EnsureEbookColumns();
            $this->RL_EnsureEbookPurchaseColumns();
            $this->RL_EnsureInvoiceTables();
            $this->RL_MigrateLegacyEbookAccess();
            $this->RL_BackfillEbookInvoices();
        } catch (\Throwable $__) {
        }
    }

    private function RL_EnsureInvoiceTables(): void
    {
        try {
            $this->db->exec(
                "CREATE TABLE IF NOT EXISTS i_invoices (
                    invoice_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    invoice_number VARCHAR(64) NOT NULL,
                    source_type VARCHAR(40) NOT NULL,
                    source_id BIGINT UNSIGNED NOT NULL,
                    buyer_id INT UNSIGNED NOT NULL,
                    seller_id INT UNSIGNED NULL,
                    amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                    fee_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                    tax_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                    net_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                    currency VARCHAR(10) NOT NULL DEFAULT 'USD',
                    provider VARCHAR(32) NULL,
                    reference VARCHAR(191) NULL,
                    status VARCHAR(32) NOT NULL DEFAULT 'paid',
                    billing_snapshot MEDIUMTEXT NULL,
                    issued_at INT UNSIGNED NOT NULL,
                    paid_at INT UNSIGNED NULL,
                    created_at INT UNSIGNED NOT NULL,
                    updated_at INT UNSIGNED NULL,
                    PRIMARY KEY (invoice_id),
                    UNIQUE KEY uniq_invoice_number (invoice_number),
                    UNIQUE KEY uniq_invoice_source (source_type, source_id),
                    KEY idx_invoice_buyer_created (buyer_id, created_at),
                    KEY idx_invoice_seller_created (seller_id, created_at),
                    KEY idx_invoice_status_created (status, created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
            );
        } catch (\Throwable $__) {
        }
    }

    private function RL_EnsureEbookColumns(): void
    {
        try {
            $columns = [];
            $st = $this->db->query('SHOW COLUMNS FROM i_ebooks');
            if ($st) {
                foreach ($st->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $row) {
                    $field = strtolower((string)($row['Field'] ?? ''));
                    if ($field !== '') {
                        $columns[$field] = true;
                    }
                }
            }
            $definitions = [
                'short_description' => 'VARCHAR(500) NULL AFTER slug',
                'sample_path' => 'VARCHAR(255) NULL AFTER file_size',
                'isbn' => 'VARCHAR(32) NULL AFTER sample_path',
                'language_code' => "VARCHAR(35) NOT NULL DEFAULT 'en' AFTER isbn",
                'page_count' => 'INT UNSIGNED NOT NULL DEFAULT 0 AFTER language_code',
                'publication_date' => 'DATE NULL AFTER page_count',
                'version_label' => 'VARCHAR(40) NULL AFTER publication_date',
                'moderation_note' => 'VARCHAR(500) NULL AFTER status',
                'owner_hidden' => 'TINYINT(1) NOT NULL DEFAULT 0 AFTER status',
                'owner_hidden_at' => 'INT UNSIGNED NULL AFTER owner_hidden',
                'deleted_at' => 'INT UNSIGNED NULL AFTER owner_hidden_at',
                'deleted_by' => 'INT UNSIGNED NULL AFTER deleted_at',
                'submitted_at' => 'INT UNSIGNED NULL AFTER moderation_note',
                'approved_at' => 'INT UNSIGNED NULL AFTER submitted_at',
                'approved_by' => 'INT UNSIGNED NULL AFTER approved_at',
                'featured' => 'TINYINT(1) NOT NULL DEFAULT 0 AFTER approved_by',
                'download_limit' => 'INT UNSIGNED NOT NULL DEFAULT 5 AFTER featured',
                'access_days' => 'INT UNSIGNED NOT NULL DEFAULT 0 AFTER download_limit',
                'seo_title' => 'VARCHAR(190) NULL AFTER access_days',
                'seo_description' => 'VARCHAR(320) NULL AFTER seo_title',
                'view_count' => 'INT UNSIGNED NOT NULL DEFAULT 0 AFTER seo_description',
                'sales_count' => 'INT UNSIGNED NOT NULL DEFAULT 0 AFTER view_count',
                'rating_average' => 'DECIMAL(3,2) NOT NULL DEFAULT 0.00 AFTER sales_count',
                'rating_count' => 'INT UNSIGNED NOT NULL DEFAULT 0 AFTER rating_average',
            ];
            foreach ($definitions as $name => $definition) {
                if (!isset($columns[$name])) {
                    $this->db->exec("ALTER TABLE i_ebooks ADD COLUMN {$name} {$definition}");
                }
            }
            if (isset($columns['language_code'])) {
                try {
                    $this->db->exec("ALTER TABLE i_ebooks MODIFY language_code VARCHAR(35) NOT NULL DEFAULT 'en'");
                    $this->db->exec("UPDATE i_ebooks SET language_code = 'en' WHERE LOWER(language_code) = 'eng'");
                } catch (\Throwable $__) {
                }
            }
        } catch (\Throwable $__) {
        }
    }

    private function RL_NormalizeEbookLanguageTag(string $tag): string
    {
        $tag = trim($tag);
        if ($tag === '') {
            return '';
        }
        $tag = str_replace('_', '-', $tag);
        $legacy = ['eng' => 'en', 'tur' => 'tr', 'ger' => 'de', 'deu' => 'de', 'fre' => 'fr', 'fra' => 'fr', 'spa' => 'es', 'por' => 'pt'];
        $lower = strtolower($tag);
        if (isset($legacy[$lower])) {
            return $legacy[$lower];
        }
        if (!preg_match('/^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8}){0,3}$/', $tag)) {
            return '';
        }
        $parts = explode('-', $tag);
        $normalized = [];
        foreach ($parts as $index => $part) {
            if ($index === 0) {
                $normalized[] = strtolower($part);
            } elseif (strlen($part) === 4 && ctype_alpha($part)) {
                $normalized[] = ucfirst(strtolower($part));
            } elseif ((strlen($part) === 2 && ctype_alpha($part)) || (strlen($part) === 3 && ctype_digit($part))) {
                $normalized[] = strtoupper($part);
            } else {
                $normalized[] = strtolower($part);
            }
        }
        return substr(implode('-', $normalized), 0, 35);
    }

    private function RL_EbookLanguageSeedRows(): array
    {
        return [
            ['en', 'English', 'English'], ['tr', 'Turkish', 'Türkçe'], ['ar', 'Arabic', 'العربية'],
            ['de', 'German', 'Deutsch'], ['es', 'Spanish', 'Español'], ['fr', 'French', 'Français'],
            ['pt', 'Portuguese', 'Português'], ['it', 'Italian', 'Italiano'], ['ru', 'Russian', 'Русский'],
            ['zh-Hans', 'Chinese (Simplified)', '简体中文'], ['zh-Hant', 'Chinese (Traditional)', '繁體中文'],
            ['ja', 'Japanese', '日本語'], ['ko', 'Korean', '한국어'], ['hi', 'Hindi', 'हिन्दी'],
            ['ur', 'Urdu', 'اردو'], ['fa', 'Persian', 'فارسی'], ['nl', 'Dutch', 'Nederlands'],
            ['pl', 'Polish', 'Polski'], ['sv', 'Swedish', 'Svenska'], ['da', 'Danish', 'Dansk'],
            ['no', 'Norwegian', 'Norsk'], ['fi', 'Finnish', 'Suomi'], ['el', 'Greek', 'Ελληνικά'],
            ['he', 'Hebrew', 'עברית'], ['id', 'Indonesian', 'Bahasa Indonesia'], ['ms', 'Malay', 'Bahasa Melayu'],
            ['th', 'Thai', 'ไทย'], ['vi', 'Vietnamese', 'Tiếng Việt'], ['uk', 'Ukrainian', 'Українська'],
            ['ro', 'Romanian', 'Română'],
        ];
    }

    public function RL_EnsureEbookLanguageTables(): void
    {
        try {
            $this->db->exec(
                "CREATE TABLE IF NOT EXISTS i_ebook_languages (
                    language_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    language_tag VARCHAR(35) NOT NULL,
                    english_name VARCHAR(120) NOT NULL,
                    native_name VARCHAR(120) NOT NULL,
                    is_active TINYINT(1) NOT NULL DEFAULT 1,
                    is_default TINYINT(1) NOT NULL DEFAULT 0,
                    sort_order INT NOT NULL DEFAULT 0,
                    created_at INT UNSIGNED NOT NULL,
                    updated_at INT UNSIGNED NULL,
                    PRIMARY KEY (language_id),
                    UNIQUE KEY uniq_ebook_language_tag (language_tag),
                    KEY idx_ebook_language_active_sort (is_active, sort_order, english_name)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
            );
            $this->db->exec(
                "CREATE TABLE IF NOT EXISTS i_ebook_language_translations (
                    translation_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    language_id INT UNSIGNED NOT NULL,
                    locale_code VARCHAR(16) NOT NULL,
                    display_name VARCHAR(120) NOT NULL,
                    created_at INT UNSIGNED NOT NULL,
                    updated_at INT UNSIGNED NULL,
                    PRIMARY KEY (translation_id),
                    UNIQUE KEY uniq_ebook_language_translation (language_id, locale_code),
                    KEY idx_ebook_language_translation_locale (locale_code)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
            );
            $now = time();
            $seed = $this->db->prepare(
                "INSERT INTO i_ebook_languages
                    (language_tag, english_name, native_name, is_active, is_default, sort_order, created_at, updated_at)
                 VALUES (:tag, :english_name, :native_name, 1, :is_default, :sort_order, :created_at, :updated_at)
                 ON DUPLICATE KEY UPDATE
                    english_name = VALUES(english_name),
                    native_name = VALUES(native_name),
                    updated_at = VALUES(updated_at)"
            );
            $index = 0;
            foreach ($this->RL_EbookLanguageSeedRows() as $row) {
                $tag = $this->RL_NormalizeEbookLanguageTag((string)$row[0]);
                if ($tag === '') {
                    continue;
                }
                $seed->execute([
                    ':tag' => $tag,
                    ':english_name' => (string)$row[1],
                    ':native_name' => (string)$row[2],
                    ':is_default' => $tag === 'en' ? 1 : 0,
                    ':sort_order' => $index * 10,
                    ':created_at' => $now,
                    ':updated_at' => $now,
                ]);
                $index++;
            }
            $defaultCount = (int)$this->db->query("SELECT COUNT(*) FROM i_ebook_languages WHERE is_default = 1")->fetchColumn();
            if ($defaultCount <= 0) {
                $this->db->exec("UPDATE i_ebook_languages SET is_default = 1 WHERE language_tag = 'en' LIMIT 1");
            }
        } catch (\Throwable $__) {
        }
    }

    public function RL_DefaultEbookLanguageTag(): string
    {
        $this->RL_EnsureEbookLanguageTables();
        try {
            $tag = (string)$this->db->query("SELECT language_tag FROM i_ebook_languages WHERE is_default = 1 AND is_active = 1 ORDER BY language_id ASC LIMIT 1")->fetchColumn();
            return $tag !== '' ? $tag : 'en';
        } catch (\Throwable $__) {
            return 'en';
        }
    }

    public function RL_GetEbookLanguages(bool $activeOnly = true, string $locale = ''): array
    {
        $this->RL_EnsureEbookLanguageTables();
        $locale = preg_replace('/[^a-zA-Z0-9_-]/', '', $locale) ?: 'eng';
        try {
            $where = $activeOnly ? 'WHERE l.is_active = 1' : '';
            $st = $this->db->prepare(
                "SELECT l.*,
                        COALESCE(NULLIF(t.display_name, ''), l.native_name, l.english_name) AS display_name,
                        (SELECT COUNT(*) FROM i_ebooks e WHERE e.language_code = l.language_tag AND e.deleted_at IS NULL) AS ebook_count
                 FROM i_ebook_languages l
                 LEFT JOIN i_ebook_language_translations t ON t.language_id = l.language_id AND t.locale_code = :locale
                 {$where}
                 ORDER BY l.is_default DESC, l.sort_order ASC, l.english_name ASC"
            );
            $st->execute([':locale' => $locale]);
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $__) {
            return [];
        }
    }

    public function RL_GetEbookLanguageLabel(string $tag, string $locale = ''): string
    {
        $normalized = $this->RL_NormalizeEbookLanguageTag($tag);
        if ($normalized === '') {
            return '';
        }
        $this->RL_EnsureEbookLanguageTables();
        $locale = preg_replace('/[^a-zA-Z0-9_-]/', '', $locale) ?: 'eng';
        try {
            $st = $this->db->prepare(
                "SELECT COALESCE(NULLIF(t.display_name, ''), l.native_name, l.english_name, l.language_tag)
                 FROM i_ebook_languages l
                 LEFT JOIN i_ebook_language_translations t ON t.language_id = l.language_id AND t.locale_code = :locale
                 WHERE l.language_tag = :tag
                 LIMIT 1"
            );
            $st->execute([':locale' => $locale, ':tag' => $normalized]);
            $label = (string)$st->fetchColumn();
            return $label !== '' ? $label : strtoupper($normalized);
        } catch (\Throwable $__) {
            return strtoupper($normalized);
        }
    }

    public function RL_ValidateEbookLanguageTag(string $tag, bool $activeOnly = true): string
    {
        $normalized = $this->RL_NormalizeEbookLanguageTag($tag);
        if ($normalized === '') {
            return '';
        }
        $this->RL_EnsureEbookLanguageTables();
        try {
            $sql = 'SELECT language_tag FROM i_ebook_languages WHERE language_tag = :tag' . ($activeOnly ? ' AND is_active = 1' : '') . ' LIMIT 1';
            $st = $this->db->prepare($sql);
            $st->execute([':tag' => $normalized]);
            return (string)$st->fetchColumn();
        } catch (\Throwable $__) {
            return '';
        }
    }

    public function RL_SaveEbookLanguage(array $data, string $locale = 'eng'): array
    {
        $this->RL_EnsureEbookLanguageTables();
        $languageId = max(0, (int)($data['language_id'] ?? 0));
        $tag = $this->RL_NormalizeEbookLanguageTag((string)($data['language_tag'] ?? ''));
        $englishName = trim((string)($data['english_name'] ?? ''));
        $nativeName = trim((string)($data['native_name'] ?? ''));
        if ($tag === '' || $englishName === '' || $nativeName === '') {
            return ['ok' => false, 'error' => 'admin_ebook_language_required'];
        }
        $isActive = !empty($data['is_active']) ? 1 : 0;
        $isDefault = !empty($data['is_default']) ? 1 : 0;
        $sortOrder = (int)($data['sort_order'] ?? 0);
        $now = time();
        try {
            if ($languageId > 0) {
                $st = $this->db->prepare(
                    "UPDATE i_ebook_languages
                     SET language_tag = :tag, english_name = :english_name, native_name = :native_name,
                         is_active = :active, is_default = :is_default, sort_order = :sort_order, updated_at = :updated
                     WHERE language_id = :language_id"
                );
                $st->execute([
                    ':tag' => $tag,
                    ':english_name' => substr($englishName, 0, 120),
                    ':native_name' => substr($nativeName, 0, 120),
                    ':active' => $isActive,
                    ':is_default' => $isDefault,
                    ':sort_order' => $sortOrder,
                    ':updated' => $now,
                    ':language_id' => $languageId,
                ]);
            } else {
                $st = $this->db->prepare(
                    "INSERT INTO i_ebook_languages
                        (language_tag, english_name, native_name, is_active, is_default, sort_order, created_at, updated_at)
                     VALUES (:tag, :english_name, :native_name, :active, :is_default, :sort_order, :created, :updated)"
                );
                $st->execute([
                    ':tag' => $tag,
                    ':english_name' => substr($englishName, 0, 120),
                    ':native_name' => substr($nativeName, 0, 120),
                    ':active' => $isActive,
                    ':is_default' => $isDefault,
                    ':sort_order' => $sortOrder,
                    ':created' => $now,
                    ':updated' => $now,
                ]);
                $languageId = (int)$this->db->lastInsertId();
            }
            if ($isDefault === 1) {
                $this->db->prepare('UPDATE i_ebook_languages SET is_default = 0 WHERE language_id <> :language_id')->execute([':language_id' => $languageId]);
                $this->db->prepare('UPDATE i_ebook_languages SET is_active = 1 WHERE language_id = :language_id')->execute([':language_id' => $languageId]);
            }
            $displayName = trim((string)($data['display_name'] ?? ''));
            if ($displayName !== '' && $languageId > 0) {
                $locale = preg_replace('/[^a-zA-Z0-9_-]/', '', $locale) ?: 'eng';
                $tr = $this->db->prepare(
                    "INSERT INTO i_ebook_language_translations
                        (language_id, locale_code, display_name, created_at, updated_at)
                     VALUES (:language_id, :locale, :display_name, :created, :updated)
                     ON DUPLICATE KEY UPDATE display_name = VALUES(display_name), updated_at = VALUES(updated_at)"
                );
                $tr->execute([
                    ':language_id' => $languageId,
                    ':locale' => $locale,
                    ':display_name' => substr($displayName, 0, 120),
                    ':created' => $now,
                    ':updated' => $now,
                ]);
            }
            return ['ok' => true, 'language_id' => $languageId, 'language_tag' => $tag];
        } catch (\Throwable $__) {
            return ['ok' => false, 'error' => 'admin_ebook_language_duplicate'];
        }
    }

    public function RL_SetEbookLanguageDefault(int $languageId): array
    {
        $this->RL_EnsureEbookLanguageTables();
        if ($languageId <= 0) {
            return ['ok' => false, 'error' => 'invalid_request'];
        }
        try {
            $this->db->beginTransaction();
            $this->db->prepare('UPDATE i_ebook_languages SET is_default = 0')->execute();
            $this->db->prepare('UPDATE i_ebook_languages SET is_default = 1, is_active = 1, updated_at = :updated WHERE language_id = :language_id')->execute([
                ':updated' => time(),
                ':language_id' => $languageId,
            ]);
            $this->db->commit();
            return ['ok' => true];
        } catch (\Throwable $__) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            return ['ok' => false, 'error' => 'server_error'];
        }
    }

    public function RL_ToggleEbookLanguage(int $languageId): array
    {
        $this->RL_EnsureEbookLanguageTables();
        if ($languageId <= 0) {
            return ['ok' => false, 'error' => 'invalid_request'];
        }
        try {
            $st = $this->db->prepare('SELECT is_active, is_default FROM i_ebook_languages WHERE language_id = :language_id LIMIT 1');
            $st->execute([':language_id' => $languageId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                return ['ok' => false, 'error' => 'ebook_not_found'];
            }
            if ((int)$row['is_default'] === 1 && (int)$row['is_active'] === 1) {
                return ['ok' => false, 'error' => 'admin_ebook_language_default_active'];
            }
            $active = (int)$row['is_active'] === 1 ? 0 : 1;
            $this->db->prepare('UPDATE i_ebook_languages SET is_active = :active, updated_at = :updated WHERE language_id = :language_id')->execute([
                ':active' => $active,
                ':updated' => time(),
                ':language_id' => $languageId,
            ]);
            return ['ok' => true, 'is_active' => $active];
        } catch (\Throwable $__) {
            return ['ok' => false, 'error' => 'server_error'];
        }
    }

    public function RL_DeleteEbookLanguage(int $languageId): array
    {
        $this->RL_EnsureEbookLanguageTables();
        if ($languageId <= 0) {
            return ['ok' => false, 'error' => 'invalid_request'];
        }
        try {
            $st = $this->db->prepare(
                "SELECT l.is_default, l.language_tag,
                        (SELECT COUNT(*) FROM i_ebooks e WHERE e.language_code = l.language_tag AND e.deleted_at IS NULL) ebook_count
                 FROM i_ebook_languages l
                 WHERE l.language_id = :language_id
                 LIMIT 1"
            );
            $st->execute([':language_id' => $languageId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                return ['ok' => false, 'error' => 'ebook_not_found'];
            }
            if ((int)$row['is_default'] === 1) {
                return ['ok' => false, 'error' => 'admin_ebook_language_default_active'];
            }
            if ((int)$row['ebook_count'] > 0) {
                $this->db->prepare('UPDATE i_ebook_languages SET is_active = 0, updated_at = :updated WHERE language_id = :language_id')->execute([
                    ':updated' => time(),
                    ':language_id' => $languageId,
                ]);
                return ['ok' => true, 'deactivated' => true];
            }
            $this->db->prepare('DELETE FROM i_ebook_language_translations WHERE language_id = :language_id')->execute([':language_id' => $languageId]);
            $this->db->prepare('DELETE FROM i_ebook_languages WHERE language_id = :language_id')->execute([':language_id' => $languageId]);
            return ['ok' => true, 'deleted' => true];
        } catch (\Throwable $__) {
            return ['ok' => false, 'error' => 'server_error'];
        }
    }

    private function RL_MigrateLegacyEbookAccess(): void
    {
        try {
            $this->db->exec(
                "INSERT INTO i_ebook_entitlements
                    (ebook_id, user_id, purchase_id, source, status, download_limit, download_count, starts_at, expires_at, created_at, updated_at)
                 SELECT p.ebook_id, p.buyer_id, p.purchase_id, 'purchase', 'active',
                        COALESCE(NULLIF(e.download_limit, 0), 5), 0, p.created_at,
                        CASE WHEN e.access_days > 0 THEN p.created_at + (e.access_days * 86400) ELSE NULL END,
                        p.created_at, COALESCE(p.updated_at, p.created_at)
                 FROM i_ebook_purchases p
                 INNER JOIN i_ebooks e ON e.ebook_id = p.ebook_id
                 WHERE p.status IN ('succeeded', 'paid')
                 ON DUPLICATE KEY UPDATE
                    purchase_id = VALUES(purchase_id),
                    status = 'active',
                    updated_at = VALUES(updated_at)"
            );
        } catch (\Throwable $__) {
        }
    }

    private function RL_EnsureEbookPurchaseColumns(): void
    {
        try {
            $columns = [];
            $st = $this->db->query('SHOW COLUMNS FROM i_ebook_purchases');
            if ($st) {
                foreach ($st->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $row) {
                    $field = strtolower((string)($row['Field'] ?? ''));
                    if ($field !== '') {
                        $columns[$field] = true;
                    }
                }
            }
            $addColumn = function (string $name, string $definition) use (&$columns): void {
                if (!isset($columns[strtolower($name)])) {
                    $this->db->exec("ALTER TABLE i_ebook_purchases ADD COLUMN {$name} {$definition}");
                    $columns[strtolower($name)] = true;
                }
            };
            $addColumn('event', 'VARCHAR(64) NULL AFTER status');
            $addColumn('fee_amount', 'DECIMAL(10,2) NULL AFTER event');
            $addColumn('fee_currency', 'VARCHAR(10) NULL AFTER fee_amount');
            $addColumn('tax_amount', 'DECIMAL(10,2) NULL AFTER fee_currency');
            $addColumn('net_amount', 'DECIMAL(10,2) NULL AFTER tax_amount');
            $addColumn('credited_at', 'INT UNSIGNED NULL AFTER raw_payload');
        } catch (\Throwable $__) {
        }
    }

    private function RL_EbookEncodePayload($payload): string
    {
        $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
        if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
            $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
        }
        if (defined('JSON_PARTIAL_OUTPUT_ON_ERROR')) {
            $flags |= JSON_PARTIAL_OUTPUT_ON_ERROR;
        }
        $encoded = json_encode($payload, $flags);
        return $encoded !== false ? $encoded : '{}';
    }

    private function RL_CreateEbookInvoiceFromPurchaseRow(array $row): int
    {
        $purchaseId = (int)($row['purchase_id'] ?? 0);
        $buyerId = (int)($row['buyer_id'] ?? 0);
        $sellerId = (int)($row['seller_id'] ?? 0);
        $status = strtolower(trim((string)($row['status'] ?? '')));
        if ($purchaseId <= 0 || $buyerId <= 0 || $sellerId <= 0 || !in_array($status, ['succeeded', 'paid', 'completed'], true)) {
            return 0;
        }

        $this->RL_EnsureInvoiceTables();
        try {
            $amount = round((float)($row['amount'] ?? 0), 2);
            $feeAmount = round((float)($row['fee_amount'] ?? 0), 2);
            $taxAmount = round((float)($row['tax_amount'] ?? 0), 2);
            $netAmount = round((float)($row['net_amount'] ?? 0), 2);
            if ($netAmount <= 0) {
                $netAmount = max(0.0, $amount - max(0.0, $feeAmount) - max(0.0, $taxAmount));
            }
            $currency = strtoupper(trim((string)($row['currency'] ?? 'USD')));
            if ($currency === '') {
                $currency = 'USD';
            }
            $createdAt = (int)($row['created_at'] ?? 0);
            if ($createdAt <= 0) {
                $createdAt = time();
            }
            $invoiceStatus = in_array($status, ['succeeded', 'completed'], true) ? 'paid' : $status;
            $snapshot = [
                'ebook_id' => (int)($row['ebook_id'] ?? 0),
                'purchase_id' => $purchaseId,
                'event' => (string)($row['event'] ?? ''),
                'raw_payload' => (string)($row['raw_payload'] ?? ''),
            ];

            $st = $this->db->prepare(
                "INSERT INTO i_invoices
                    (invoice_number, source_type, source_id, buyer_id, seller_id, amount, fee_amount, tax_amount, net_amount,
                     currency, provider, reference, status, billing_snapshot, issued_at, paid_at, created_at, updated_at)
                 VALUES
                    (:invoice_number, 'ebook_purchase', :source_id, :buyer_id, :seller_id, :amount, :fee_amount, :tax_amount,
                     :net_amount, :currency, :provider, :reference, :status, :snapshot, :issued_at, :paid_at, :created_at, :updated_at)
                 ON DUPLICATE KEY UPDATE
                    buyer_id = VALUES(buyer_id),
                    seller_id = VALUES(seller_id),
                    amount = VALUES(amount),
                    fee_amount = VALUES(fee_amount),
                    tax_amount = VALUES(tax_amount),
                    net_amount = VALUES(net_amount),
                    currency = VALUES(currency),
                    provider = VALUES(provider),
                    reference = VALUES(reference),
                    status = VALUES(status),
                    billing_snapshot = VALUES(billing_snapshot),
                    paid_at = VALUES(paid_at),
                    updated_at = VALUES(updated_at)"
            );
            $st->execute([
                ':invoice_number' => 'EB-' . $purchaseId,
                ':source_id' => $purchaseId,
                ':buyer_id' => $buyerId,
                ':seller_id' => $sellerId,
                ':amount' => max(0.0, $amount),
                ':fee_amount' => max(0.0, $feeAmount),
                ':tax_amount' => max(0.0, $taxAmount),
                ':net_amount' => max(0.0, $netAmount),
                ':currency' => $currency,
                ':provider' => strtolower(trim((string)($row['provider'] ?? ''))),
                ':reference' => (string)($row['reference'] ?? ''),
                ':status' => $invoiceStatus,
                ':snapshot' => $this->RL_EbookEncodePayload($snapshot),
                ':issued_at' => $createdAt,
                ':paid_at' => time(),
                ':created_at' => $createdAt,
                ':updated_at' => time(),
            ]);
            $lookup = $this->db->prepare("SELECT invoice_id FROM i_invoices WHERE source_type = 'ebook_purchase' AND source_id = :source_id LIMIT 1");
            $lookup->execute([':source_id' => $purchaseId]);
            return (int)$lookup->fetchColumn();
        } catch (\Throwable $__) {
            return 0;
        }
    }

    public function RL_CreateEbookInvoiceForPurchase(int $purchaseId): int
    {
        $this->RL_EnsureEbookTables();
        if ($purchaseId <= 0) {
            return 0;
        }
        try {
            $st = $this->db->prepare('SELECT * FROM i_ebook_purchases WHERE purchase_id = :purchase LIMIT 1');
            $st->execute([':purchase' => $purchaseId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            return $row ? $this->RL_CreateEbookInvoiceFromPurchaseRow($row) : 0;
        } catch (\Throwable $__) {
            return 0;
        }
    }

    private function RL_BackfillEbookInvoices(): void
    {
        try {
            $this->RL_EnsureInvoiceTables();
            $st = $this->db->query(
                "SELECT p.*
                 FROM i_ebook_purchases p
                 LEFT JOIN i_invoices inv ON inv.source_type = 'ebook_purchase' AND inv.source_id = p.purchase_id
                 WHERE p.status IN ('succeeded', 'paid', 'completed')
                   AND inv.invoice_id IS NULL
                 ORDER BY p.purchase_id ASC
                 LIMIT 100"
            );
            foreach (($st ? $st->fetchAll(\PDO::FETCH_ASSOC) : []) ?: [] as $purchaseRow) {
                $this->RL_CreateEbookInvoiceFromPurchaseRow($purchaseRow);
            }
        } catch (\Throwable $__) {
        }
    }

    private function RL_EbookSlug(string $title, int $ownerId): string
    {
        $base = strtolower(trim($title));
        $base = preg_replace('/[^a-z0-9]+/i', '-', $base) ?: 'ebook';
        $base = trim((string) $base, '-');
        if ($base === '') {
            $base = 'ebook';
        }
        return substr($base, 0, 160) . '-' . $ownerId . '-' . substr(bin2hex(random_bytes(4)), 0, 8);
    }

    public function RL_CreateEbook(array $data): int
    {
        $this->RL_EnsureEbookTables();
        try {
            $ownerId = (int) ($data['owner_id'] ?? 0);
            $title = trim((string) ($data['title'] ?? ''));
            $filePath = trim((string) ($data['file_path'] ?? ''));
            if ($ownerId <= 0 || $title === '' || $filePath === '') {
                return 0;
            }
            $languageCode = $this->RL_ValidateEbookLanguageTag((string)($data['language_code'] ?? ''), true);
            if ($languageCode === '') {
                $languageCode = $this->RL_DefaultEbookLanguageTag();
            }
            $currency = strtoupper(preg_replace('/[^A-Z0-9]/', '', trim((string) ($data['currency'] ?? ($GLOBALS['currency'] ?? 'USD')))));
            if ($currency === '') {
                $currency = 'USD';
            }
            $price = round(max(0.0, (float) ($data['price'] ?? 0)), 2);
            $now = time();
            $st = $this->db->prepare(
                "INSERT INTO i_ebooks
                    (owner_id, title, slug, short_description, description, cover_path, file_path, file_name, file_size,
                     sample_path, isbn, language_code, page_count, publication_date, version_label, price, currency, status,
                     submitted_at, download_limit, access_days, created_at, updated_at)
                 VALUES
                    (:owner, :title, :slug, :short_description, :description, :cover, :file_path, :file_name, :file_size,
                     :sample_path, :isbn, :language_code, :page_count, :publication_date, :version_label, :price, :currency, :status,
                     :submitted_at, :download_limit, :access_days, :created, :updated)"
            );
            $ok = $st->execute([
                ':owner' => $ownerId,
                ':title' => $title,
                ':slug' => $this->RL_EbookSlug($title, $ownerId),
                ':short_description' => trim((string)($data['short_description'] ?? '')),
                ':description' => trim((string) ($data['description'] ?? '')),
                ':cover' => trim((string) ($data['cover_path'] ?? '')),
                ':file_path' => $filePath,
                ':file_name' => trim((string) ($data['file_name'] ?? '')),
                ':file_size' => max(0, (int) ($data['file_size'] ?? 0)),
                ':sample_path' => trim((string)($data['sample_path'] ?? '')),
                ':isbn' => trim((string)($data['isbn'] ?? '')),
                ':language_code' => $languageCode,
                ':page_count' => max(0, (int)($data['page_count'] ?? 0)),
                ':publication_date' => !empty($data['publication_date']) ? (string)$data['publication_date'] : null,
                ':version_label' => trim((string)($data['version_label'] ?? '1.0')) ?: '1.0',
                ':price' => $price,
                ':currency' => $currency,
                ':status' => in_array((string)($data['status'] ?? 'pending'), ['active', 'draft', 'pending', 'rejected', 'archived'], true) ? (string)$data['status'] : 'pending',
                ':submitted_at' => (string)($data['status'] ?? 'pending') === 'pending' ? $now : null,
                ':download_limit' => max(0, (int)($data['download_limit'] ?? 5)),
                ':access_days' => max(0, (int)($data['access_days'] ?? 0)),
                ':created' => $now,
                ':updated' => $now,
            ]);
            $ebookId = $ok ? (int)$this->db->lastInsertId() : 0;
            if ($ebookId > 0) {
                $file = $this->db->prepare(
                    "INSERT INTO i_ebook_files
                        (ebook_id, version_label, file_path, file_name, file_size, mime_type, checksum_sha256, is_current, created_by, created_at)
                     VALUES (:ebook, :version, :path, :name, :size, :mime, :checksum, 1, :creator, :created)"
                );
                $file->execute([
                    ':ebook' => $ebookId, ':version' => trim((string)($data['version_label'] ?? '1.0')) ?: '1.0',
                    ':path' => $filePath, ':name' => trim((string)($data['file_name'] ?? '')),
                    ':size' => max(0, (int)($data['file_size'] ?? 0)), ':mime' => trim((string)($data['mime_type'] ?? '')),
                    ':checksum' => trim((string)($data['checksum_sha256'] ?? '')) ?: null, ':creator' => $ownerId, ':created' => $now,
                ]);
            }
            return $ebookId;
        } catch (\Throwable $__) {
            return 0;
        }
    }

    public function RL_GetOwnerEbooks(int $ownerId): array
    {
        $this->RL_EnsureEbookTables();
        try {
            $st = $this->db->prepare("SELECT e.*,
                       (SELECT COUNT(*) FROM i_ebook_purchases p WHERE p.ebook_id=e.ebook_id AND p.status IN ('succeeded','paid','completed')) purchase_count,
                       (SELECT COUNT(*) FROM i_ebook_purchases p WHERE p.ebook_id=e.ebook_id AND p.status IN ('succeeded','paid','completed')) sales_count,
                       (SELECT COALESCE(SUM(COALESCE(p.net_amount, p.amount, 0)), 0) FROM i_ebook_purchases p WHERE p.ebook_id=e.ebook_id AND p.status IN ('succeeded','paid','completed')) net_revenue,
                       (SELECT COALESCE(SUM(COALESCE(p.amount, 0)), 0) FROM i_ebook_purchases p WHERE p.ebook_id=e.ebook_id AND p.status IN ('succeeded','paid','completed')) gross_revenue,
                       (SELECT p.currency FROM i_ebook_purchases p WHERE p.ebook_id=e.ebook_id AND p.status IN ('succeeded','paid','completed') ORDER BY p.created_at DESC LIMIT 1) revenue_currency
                FROM i_ebooks e WHERE e.owner_id = :owner AND e.deleted_at IS NULL
                ORDER BY e.updated_at DESC, e.ebook_id DESC");
            $st->execute([':owner' => $ownerId]);
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $__) { return []; }
    }

    public function RL_UpdateOwnerEbook(int $ebookId, int $ownerId, array $data): array
    {
        $this->RL_EnsureEbookTables();
        if ($ebookId <= 0 || $ownerId <= 0) { return ['ok'=>false,'error'=>'invalid_request']; }
        try {
            $st=$this->db->prepare('SELECT * FROM i_ebooks WHERE ebook_id=:ebook AND owner_id=:owner AND deleted_at IS NULL LIMIT 1');
            $st->execute([':ebook'=>$ebookId,':owner'=>$ownerId]); $row=$st->fetch(\PDO::FETCH_ASSOC);
            if(!$row){return ['ok'=>false,'error'=>'ebook_not_found'];}
            $title=trim((string)($data['title']??'')); if($title===''){return ['ok'=>false,'error'=>'ebook_title_required'];}
            $priceRaw = trim((string)($data['price'] ?? '0'));
            if ($priceRaw === '') {
                $priceRaw = '0';
            }
            $priceNormalized = str_replace(',', '.', $priceRaw);
            if (!preg_match('/^\d+(?:\.\d{1,2})?$/', $priceNormalized)) {
                return ['ok'=>false,'error'=>'ebook_price_invalid'];
            }
            $price = round((float)$priceNormalized, 2);
            $siteDataLocal = isset($GLOBALS['siteData']) && is_array($GLOBALS['siteData']) ? $GLOBALS['siteData'] : [];
            $ebookMinPrice = max(0.0, (float)($siteDataLocal['ebook_min_price'] ?? 0));
            $ebookMaxPrice = max($ebookMinPrice, (float)($siteDataLocal['ebook_max_price'] ?? 500));
            if ($price > 0 && ($price < $ebookMinPrice || $price > $ebookMaxPrice)) {
                return ['ok'=>false,'error'=>'ebook_price_out_of_range'];
            }
            $languageCode = $this->RL_ValidateEbookLanguageTag((string)($data['language_code'] ?? ''), true);
            if ($languageCode === '') {
                return ['ok'=>false,'error'=>'ebook_language_invalid'];
            }
            $status=(string)$row['status'];
            if($status==='active'){$status='pending';}
            elseif($status==='rejected'){$status='draft';}
            $now=time();
            $sql="UPDATE i_ebooks SET title=:title,short_description=:short_description,description=:description,
                  isbn=:isbn,language_code=:language,page_count=:pages,publication_date=:publication,
                  version_label=:version,price=:price,status=:status,moderation_note=NULL,
                  approved_at=NULL,approved_by=NULL,updated_at=:updated WHERE ebook_id=:ebook AND owner_id=:owner";
            $ok=$this->db->prepare($sql)->execute([
                ':title'=>$title,':short_description'=>substr(trim((string)($data['short_description']??'')),0,500),
                ':description'=>trim((string)($data['description']??'')),':isbn'=>substr(trim((string)($data['isbn']??'')),0,32),
                ':language'=>$languageCode,
                ':pages'=>max(0,(int)($data['page_count']??0)),':publication'=>trim((string)($data['publication_date']??''))?:null,
                ':version'=>substr(trim((string)($data['version_label']??'1.0')),0,40)?:'1.0',':price'=>$price,
                ':status'=>$status,':updated'=>$now,':ebook'=>$ebookId,':owner'=>$ownerId]);
            return ['ok'=>$ok,'status'=>$status];
        } catch(\Throwable $__){return ['ok'=>false,'error'=>'server_error'];}
    }

    public function RL_OwnerEbookAction(int $ebookId, int $ownerId, string $action): array
    {
        $this->RL_EnsureEbookTables(); $action=strtolower(trim($action));
        try {
            $st=$this->db->prepare("SELECT e.*,(SELECT COUNT(*) FROM i_ebook_purchases p WHERE p.ebook_id=e.ebook_id AND p.status IN ('succeeded','paid','completed')) purchase_count FROM i_ebooks e WHERE e.ebook_id=:ebook AND e.owner_id=:owner AND e.deleted_at IS NULL LIMIT 1");
            $st->execute([':ebook'=>$ebookId,':owner'=>$ownerId]); $row=$st->fetch(\PDO::FETCH_ASSOC);
            if(!$row){return ['ok'=>false,'error'=>'ebook_not_found'];} $now=time();
            if($action==='hide'||$action==='show'){
                $hidden=$action==='hide'?1:0;
                $this->db->prepare('UPDATE i_ebooks SET owner_hidden=:hidden,owner_hidden_at=:at,updated_at=:now WHERE ebook_id=:ebook AND owner_id=:owner')->execute([':hidden'=>$hidden,':at'=>$hidden?$now:null,':now'=>$now,':ebook'=>$ebookId,':owner'=>$ownerId]);
                return ['ok'=>true,'status'=>(string)$row['status'],'hidden'=>$hidden];
            }
            if($action==='submit'){
                if(!in_array((string)$row['status'],['draft','rejected'],true)){return ['ok'=>false,'error'=>'invalid_status_transition'];}
                $this->db->prepare("UPDATE i_ebooks SET status='pending',moderation_note=NULL,submitted_at=:submitted,updated_at=:updated WHERE ebook_id=:ebook AND owner_id=:owner")->execute([':submitted'=>$now,':updated'=>$now,':ebook'=>$ebookId,':owner'=>$ownerId]);
                return ['ok'=>true,'status'=>'pending'];
            }
            if($action==='archive'||$action==='delete'){
                if($action==='delete' && (int)$row['purchase_count']===0){
                    $this->db->prepare("UPDATE i_ebooks SET status='archived',deleted_at=:deleted,deleted_by=:deleted_by,owner_hidden=1,updated_at=:updated WHERE ebook_id=:ebook AND owner_id=:owner_id")->execute([':deleted'=>$now,':deleted_by'=>$ownerId,':updated'=>$now,':owner_id'=>$ownerId,':ebook'=>$ebookId]);
                    return ['ok'=>true,'deleted'=>1];
                }
                $this->db->prepare("UPDATE i_ebooks SET status='archived',owner_hidden=1,owner_hidden_at=:hidden_at,updated_at=:updated WHERE ebook_id=:ebook AND owner_id=:owner")->execute([':hidden_at'=>$now,':updated'=>$now,':ebook'=>$ebookId,':owner'=>$ownerId]);
                return ['ok'=>true,'status'=>'archived','archived_instead'=>(int)$row['purchase_count']>0?1:0];
            }
            return ['ok'=>false,'error'=>'invalid_request'];
        } catch(\Throwable $__){return ['ok'=>false,'error'=>'server_error'];}
    }

    public function RL_GetUserEbookLibrary(int $userId): array
    {
        $this->RL_EnsureEbookTables();
        try {
            $st = $this->db->prepare(
                "SELECT e.*, en.entitlement_id, en.purchase_id, en.download_limit AS entitlement_limit,
                        en.download_count AS entitlement_downloads, en.expires_at, en.status AS entitlement_status,
                        p.created_at AS purchased_at, u.username, u.user_fullname, u.user_avatar
                 FROM i_ebook_entitlements en
                 INNER JOIN i_ebooks e ON e.ebook_id = en.ebook_id
                 INNER JOIN i_users u ON u.user_id = e.owner_id
                 LEFT JOIN i_ebook_purchases p ON p.purchase_id = en.purchase_id
                 WHERE en.user_id = :user AND en.status = 'active'
                   AND (en.expires_at IS NULL OR en.expires_at > UNIX_TIMESTAMP())
                 ORDER BY COALESCE(p.created_at, en.created_at) DESC"
            );
            $st->execute([':user' => $userId]);
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $__) { return []; }
    }

    public function RL_GetEbookEntitlement(int $ebookId, int $userId): ?array
    {
        $this->RL_EnsureEbookTables();
        try {
            $st = $this->db->prepare("SELECT * FROM i_ebook_entitlements WHERE ebook_id=:ebook AND user_id=:user AND status='active' AND (expires_at IS NULL OR expires_at > UNIX_TIMESTAMP()) LIMIT 1");
            $st->execute([':ebook' => $ebookId, ':user' => $userId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (\Throwable $__) { return null; }
    }

    public function RL_LogEbookDownload(int $ebookId, int $userId, int $bytesSent = 0): bool
    {
        $this->RL_EnsureEbookTables();
        try {
            $entitlement = $this->RL_GetEbookEntitlement($ebookId, $userId);
            if (!$entitlement) { return false; }
            $now = time();
            $this->db->beginTransaction();
            $st = $this->db->prepare("UPDATE i_ebook_entitlements SET download_count=download_count+1,updated_at=:now WHERE entitlement_id=:id AND (download_limit=0 OR download_count<download_limit)");
            $st->execute([':now' => $now, ':id' => (int)$entitlement['entitlement_id']]);
            if ($st->rowCount() !== 1) { $this->db->rollBack(); return false; }
            $log = $this->db->prepare("INSERT INTO i_ebook_downloads (entitlement_id,ebook_id,user_id,ip_address,user_agent,bytes_sent,status,created_at,completed_at) VALUES (:entitlement,:ebook,:user,:ip,:agent,:bytes,'completed',:created,:completed)");
            $log->execute([':entitlement'=>(int)$entitlement['entitlement_id'],':ebook'=>$ebookId,':user'=>$userId,':ip'=>substr((string)($_SERVER['REMOTE_ADDR'] ?? ''),0,64),':agent'=>substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''),0,500),':bytes'=>max(0,$bytesSent),':created'=>$now,':completed'=>$now]);
            $this->db->prepare('UPDATE i_ebooks SET download_count=download_count+1,updated_at=:now WHERE ebook_id=:ebook')->execute([':now'=>$now,':ebook'=>$ebookId]);
            $this->db->commit(); return true;
        } catch (\Throwable $__) { if ($this->db->inTransaction()) { $this->db->rollBack(); } return false; }
    }

    public function RL_GetEbookReviews(int $ebookId, int $viewerId = 0, int $limit = 50): array
    {
        $this->RL_EnsureEbookTables();
        try {
            $st = $this->db->prepare("SELECT r.*,u.username,u.user_fullname,u.user_avatar FROM i_ebook_reviews r INNER JOIN i_users u ON u.user_id=r.user_id WHERE r.ebook_id=:ebook AND r.status='active' ORDER BY (r.user_id=:viewer) DESC,r.updated_at DESC LIMIT " . max(1, min(100, $limit)));
            $st->execute([':ebook' => $ebookId, ':viewer' => $viewerId]);
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $__) { return []; }
    }

    public function RL_SaveEbookReview(int $ebookId, int $userId, int $rating, string $reviewText): bool
    {
        $this->RL_EnsureEbookTables();
        $rating = max(1, min(5, $rating));
        $reviewText = trim(function_exists('mb_substr') ? mb_substr($reviewText, 0, 1500) : substr($reviewText, 0, 1500));
        try {
            $ebook = $this->RL_GetEbookById($ebookId, $userId);
            $canDownload = $ebook ? $this->RL_UserCanDownloadEbook($ebookId, $userId) : false;
            if (!$ebook || (int)($ebook['owner_id'] ?? 0) === $userId || !$canDownload) {
                return false;
            }
            $verified = $this->RL_GetEbookEntitlement($ebookId, $userId) ? 1 : 0;
            $now = time();
            $this->db->beginTransaction();
            $st = $this->db->prepare("INSERT INTO i_ebook_reviews (ebook_id,user_id,rating,review_text,status,verified_purchase,created_at,updated_at) VALUES (:ebook,:user,:rating,:body,'active',:verified,:created,:updated) ON DUPLICATE KEY UPDATE rating=VALUES(rating),review_text=VALUES(review_text),status='active',verified_purchase=VALUES(verified_purchase),updated_at=VALUES(updated_at)");
            $st->execute([':ebook'=>$ebookId,':user'=>$userId,':rating'=>$rating,':body'=>$reviewText,':verified'=>$verified,':created'=>$now,':updated'=>$now]);
            $avg = $this->db->prepare("SELECT COALESCE(AVG(rating),0) average_rating,COUNT(*) rating_count FROM i_ebook_reviews WHERE ebook_id=:ebook AND status='active'");
            $avg->execute([':ebook'=>$ebookId]);
            $summary = $avg->fetch(\PDO::FETCH_ASSOC) ?: [];
            $this->db->prepare('UPDATE i_ebooks SET rating_average=:average,rating_count=:count,updated_at=:updated WHERE ebook_id=:ebook')->execute([':average'=>round((float)($summary['average_rating'] ?? 0),2),':count'=>(int)($summary['rating_count'] ?? 0),':updated'=>$now,':ebook'=>$ebookId]);
            $this->db->commit();
            return true;
        } catch (\Throwable $__) {
            if ($this->db->inTransaction()) { $this->db->rollBack(); }
            return false;
        }
    }

    public function RL_IsEbookWishlisted(int $ebookId, int $userId): bool
    {
        $this->RL_EnsureEbookTables();
        try { $st=$this->db->prepare('SELECT 1 FROM i_ebook_wishlist WHERE ebook_id=:ebook AND user_id=:user LIMIT 1'); $st->execute([':ebook'=>$ebookId,':user'=>$userId]); return (bool)$st->fetchColumn(); } catch (\Throwable $__) { return false; }
    }

    public function RL_ToggleEbookWishlist(int $ebookId, int $userId): ?bool
    {
        $this->RL_EnsureEbookTables();
        if ($ebookId <= 0 || $userId <= 0 || !$this->RL_GetEbookById($ebookId, $userId)) { return null; }
        try {
            if ($this->RL_IsEbookWishlisted($ebookId, $userId)) { $st=$this->db->prepare('DELETE FROM i_ebook_wishlist WHERE ebook_id=:ebook AND user_id=:user'); $st->execute([':ebook'=>$ebookId,':user'=>$userId]); return false; }
            $st=$this->db->prepare('INSERT IGNORE INTO i_ebook_wishlist (ebook_id,user_id,created_at) VALUES (:ebook,:user,:created)'); $st->execute([':ebook'=>$ebookId,':user'=>$userId,':created'=>time()]); return true;
        } catch (\Throwable $__) { return null; }
    }

    public function RL_ValidateEbookCoupon(string $code, int $ebookId, float $amount): ?array
    {
        $this->RL_EnsureEbookTables();
        $code = strtoupper(trim($code));
        if ($code === '' || $ebookId <= 0 || $amount <= 0) { return null; }
        try {
            $st=$this->db->prepare("SELECT * FROM i_ebook_coupons WHERE code=:code AND status='active' AND (ebook_id IS NULL OR ebook_id=:ebook) AND (starts_at IS NULL OR starts_at<=:now) AND (ends_at IS NULL OR ends_at>=:now2) AND (max_uses=0 OR used_count<max_uses) LIMIT 1");
            $st->execute([':code'=>$code,':ebook'=>$ebookId,':now'=>time(),':now2'=>time()]); $row=$st->fetch(\PDO::FETCH_ASSOC); if(!$row || $amount < (float)$row['min_order']){return null;}
            $discount=(string)$row['discount_type']==='fixed'?(float)$row['discount_value']:$amount*((float)$row['discount_value']/100);
            $discount=round(min(max(0,$amount-0.01),max(0,$discount)),2); $row['discount_amount']=$discount; $row['final_amount']=round(max(0.01,$amount-$discount),2); return $row;
        } catch (\Throwable $__) { return null; }
    }

    private function RL_BuildEbookCatalogQuery(array $filters, array &$params): array
    {
        $where = ["e.status = 'active'", "e.owner_hidden = 0", "e.deleted_at IS NULL"];
        $query = trim((string)($filters['q'] ?? ''));
        if ($query !== '') {
            $query = function_exists('mb_substr') ? mb_substr($query, 0, 100) : substr($query, 0, 100);
            $where[] = "CONVERT(CONCAT_WS(' ', e.title, e.description, e.short_description, u.username, u.user_fullname) USING utf8mb4) COLLATE utf8mb4_general_ci LIKE :ebook_query";
            $params[':ebook_query'] = '%' . $query . '%';
        }
        $categoryId = max(0, (int)($filters['category'] ?? 0));
        if ($categoryId > 0) {
            $where[] = 'EXISTS (SELECT 1 FROM i_ebook_category_map ecm WHERE ecm.ebook_id = e.ebook_id AND ecm.category_id = :ebook_category)';
            $params[':ebook_category'] = $categoryId;
        }
        $price = strtolower(trim((string)($filters['price'] ?? 'all')));
        if ($price === 'free') {
            $where[] = 'e.price <= 0';
        } elseif ($price === 'paid') {
            $where[] = 'e.price > 0';
        }
        $language = strtolower(trim((string)($filters['language'] ?? '')));
        if ($language !== '') {
            $where[] = 'e.language_code = :ebook_language';
            $params[':ebook_language'] = substr($language, 0, 12);
        }
        $sorts = [
            'newest' => 'e.featured DESC, e.created_at DESC, e.ebook_id DESC',
            'popular' => 'e.featured DESC, e.sales_count DESC, e.created_at DESC',
            'rating' => 'e.featured DESC, e.rating_average DESC, e.rating_count DESC, e.created_at DESC',
            'price_low' => 'e.price ASC, e.created_at DESC',
            'price_high' => 'e.price DESC, e.created_at DESC',
        ];
        $sort = strtolower(trim((string)($filters['sort'] ?? 'newest')));
        return [$where, $sorts[$sort] ?? $sorts['newest']];
    }

    public function RL_GetEbooks(int $viewerId = 0, int $limit = 24, int $offset = 0, array $filters = []): array
    {
        $this->RL_EnsureEbookTables();
        try {
            $limit = max(1, min(60, $limit));
            $offset = max(0, $offset);
            $params = [':viewer' => $viewerId];
            [$where, $orderBy] = $this->RL_BuildEbookCatalogQuery($filters, $params);
            $sql = "SELECT e.*, u.username, u.user_fullname, u.user_avatar, u.verified_status,
                           CASE WHEN en.entitlement_id IS NULL THEN 0 ELSE 1 END AS viewer_purchased
                    FROM i_ebooks e
                    INNER JOIN i_users u ON u.user_id = e.owner_id
                    LEFT JOIN i_ebook_entitlements en
                        ON en.ebook_id = e.ebook_id AND en.user_id = :viewer AND en.status = 'active'
                        AND (en.expires_at IS NULL OR en.expires_at > UNIX_TIMESTAMP())
                    WHERE " . implode(' AND ', $where) . "
                    ORDER BY {$orderBy}
                    LIMIT {$limit} OFFSET {$offset}";
            $st = $this->db->prepare($sql);
            $st->execute($params);
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $__) {
            return [];
        }
    }

    public function RL_CountEbooks(array $filters = []): int
    {
        $this->RL_EnsureEbookTables();
        try {
            $params = [];
            [$where] = $this->RL_BuildEbookCatalogQuery($filters, $params);
            $st = $this->db->prepare(
                'SELECT COUNT(*) FROM i_ebooks e INNER JOIN i_users u ON u.user_id = e.owner_id WHERE ' . implode(' AND ', $where)
            );
            $st->execute($params);
            return (int)$st->fetchColumn();
        } catch (\Throwable $__) {
            return 0;
        }
    }

    public function RL_GetEbookCategories(bool $activeOnly = true): array
    {
        $this->RL_EnsureEbookTables();
        try {
            $sql = "SELECT c.*, COUNT(m.ebook_id) AS ebook_count
                    FROM i_ebook_categories c
                    LEFT JOIN i_ebook_category_map m ON m.category_id = c.category_id
                    LEFT JOIN i_ebooks e ON e.ebook_id = m.ebook_id AND e.status = 'active'";
            if ($activeOnly) {
                $sql .= " WHERE c.status = 'active'";
            }
            $sql .= ' GROUP BY c.category_id ORDER BY c.sort_order ASC, c.name ASC';
            $st = $this->db->query($sql);
            return $st ? ($st->fetchAll(\PDO::FETCH_ASSOC) ?: []) : [];
        } catch (\Throwable $__) {
            return [];
        }
    }

    public function RL_GetEbookById(int $ebookId, int $viewerId = 0): ?array
    {
        $this->RL_EnsureEbookTables();
        try {
            $st = $this->db->prepare(
                "SELECT e.*, u.username, u.user_fullname, u.user_avatar, u.user_cover, u.verified_status,
                        CASE WHEN en.entitlement_id IS NULL THEN 0 ELSE 1 END AS viewer_purchased
                 FROM i_ebooks e
                 INNER JOIN i_users u ON u.user_id = e.owner_id
                 LEFT JOIN i_ebook_entitlements en
                    ON en.ebook_id = e.ebook_id AND en.user_id = :viewer AND en.status = 'active'
                    AND (en.expires_at IS NULL OR en.expires_at > UNIX_TIMESTAMP())
                 WHERE e.ebook_id = :ebook
                 LIMIT 1"
            );
            $st->execute([':ebook' => $ebookId, ':viewer' => $viewerId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (\Throwable $__) {
            return null;
        }
    }

    public function RL_GetEbookBySlug(string $slug, int $viewerId = 0): ?array
    {
        $this->RL_EnsureEbookTables();
        $slug = strtolower(trim($slug));
        if ($slug === '') {
            return null;
        }
        try {
            $st = $this->db->prepare(
                "SELECT e.*, u.username, u.user_fullname, u.user_avatar, u.user_cover, u.verified_status,
                        CASE WHEN en.entitlement_id IS NULL THEN 0 ELSE 1 END AS viewer_purchased
                 FROM i_ebooks e
                 INNER JOIN i_users u ON u.user_id = e.owner_id
                 LEFT JOIN i_ebook_entitlements en
                    ON en.ebook_id = e.ebook_id AND en.user_id = :viewer AND en.status = 'active'
                    AND (en.expires_at IS NULL OR en.expires_at > UNIX_TIMESTAMP())
                 WHERE e.slug = :slug
                 LIMIT 1"
            );
            $st->execute([':slug' => $slug, ':viewer' => $viewerId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (\Throwable $__) {
            return null;
        }
    }

    public function RL_GetEbookCategoryLabels(int $ebookId): array
    {
        $this->RL_EnsureEbookTables();
        try {
            $st = $this->db->prepare(
                "SELECT c.category_id, c.name, c.slug
                 FROM i_ebook_categories c
                 INNER JOIN i_ebook_category_map m ON m.category_id = c.category_id
                 WHERE m.ebook_id = :ebook AND c.status = 'active'
                 ORDER BY c.sort_order ASC, c.name ASC"
            );
            $st->execute([':ebook' => $ebookId]);
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $__) {
            return [];
        }
    }

    public function RL_GetRelatedEbooks(int $ebookId, int $viewerId = 0, int $limit = 4): array
    {
        $this->RL_EnsureEbookTables();
        try {
            $limit = max(1, min(8, $limit));
            $st = $this->db->prepare(
                "SELECT DISTINCT e.*, u.username, u.user_fullname, u.user_avatar, u.verified_status,
                        CASE WHEN en.entitlement_id IS NULL THEN 0 ELSE 1 END AS viewer_purchased
                 FROM i_ebooks source
                 LEFT JOIN i_ebook_category_map source_map ON source_map.ebook_id = source.ebook_id
                 INNER JOIN i_ebooks e ON e.status = 'active' AND e.ebook_id <> source.ebook_id
                 INNER JOIN i_users u ON u.user_id = e.owner_id
                 LEFT JOIN i_ebook_category_map related_map ON related_map.ebook_id = e.ebook_id
                 LEFT JOIN i_ebook_entitlements en
                    ON en.ebook_id = e.ebook_id AND en.user_id = :viewer AND en.status = 'active'
                 WHERE source.ebook_id = :ebook
                   AND (e.owner_id = source.owner_id OR related_map.category_id = source_map.category_id)
                 ORDER BY e.featured DESC, e.sales_count DESC, e.created_at DESC
                 LIMIT {$limit}"
            );
            $st->execute([':ebook' => $ebookId, ':viewer' => $viewerId]);
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $__) {
            return [];
        }
    }

    public function RL_IncrementEbookView(int $ebookId): bool
    {
        $this->RL_EnsureEbookTables();
        try {
            $st = $this->db->prepare('UPDATE i_ebooks SET view_count = view_count + 1 WHERE ebook_id = :ebook');
            return $st->execute([':ebook' => $ebookId]);
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_UserCanDownloadEbook(int $ebookId, int $userId): bool
    {
        if ($ebookId <= 0 || $userId <= 0) {
            return false;
        }
        $ebook = $this->RL_GetEbookById($ebookId, $userId);
        if (!$ebook || (string) ($ebook['status'] ?? '') !== 'active') {
            return false;
        }
        if ((int) ($ebook['owner_id'] ?? 0) === $userId) {
            return true;
        }
        if ((float) ($ebook['price'] ?? 0) <= 0) {
            return true;
        }
        try {
            $st = $this->db->prepare(
                "SELECT entitlement_id
                 FROM i_ebook_entitlements
                 WHERE ebook_id = :ebook AND user_id = :user AND status = 'active'
                   AND (expires_at IS NULL OR expires_at > :now)
                   AND (download_limit = 0 OR download_count < download_limit)
                 LIMIT 1"
            );
            $st->execute([':ebook' => $ebookId, ':user' => $userId, ':now' => time()]);
            return (bool)$st->fetchColumn();
        } catch (\Throwable $__) {
            return (int) ($ebook['viewer_purchased'] ?? 0) === 1;
        }
    }

    private function RL_UpsertEbookEntitlement(int $ebookId, int $userId, ?int $purchaseId, string $source = 'purchase'): bool
    {
        if ($ebookId <= 0 || $userId <= 0) {
            return false;
        }
        try {
            $st = $this->db->prepare('SELECT download_limit, access_days FROM i_ebooks WHERE ebook_id = :ebook LIMIT 1');
            $st->execute([':ebook' => $ebookId]);
            $ebook = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$ebook) {
                return false;
            }
            $now = time();
            $limit = max(0, (int)($ebook['download_limit'] ?? 5));
            $days = max(0, (int)($ebook['access_days'] ?? 0));
            $expiresAt = $days > 0 ? $now + ($days * 86400) : null;
            $st = $this->db->prepare(
                "INSERT INTO i_ebook_entitlements
                    (ebook_id, user_id, purchase_id, source, status, download_limit, download_count, starts_at, expires_at, created_at, updated_at)
                 VALUES
                    (:ebook, :user, :purchase, :source, 'active', :download_limit, 0, :starts, :expires, :created, :updated)
                 ON DUPLICATE KEY UPDATE
                    purchase_id = COALESCE(VALUES(purchase_id), purchase_id),
                    source = VALUES(source),
                    status = 'active',
                    download_limit = VALUES(download_limit),
                    expires_at = VALUES(expires_at),
                    revoked_at = NULL,
                    revoke_reason = NULL,
                    updated_at = VALUES(updated_at)"
            );
            return $st->execute([
                ':ebook' => $ebookId,
                ':user' => $userId,
                ':purchase' => $purchaseId,
                ':source' => $source,
                ':download_limit' => $limit,
                ':starts' => $now,
                ':expires' => $expiresAt,
                ':created' => $now,
                ':updated' => $now,
            ]);
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_GrantEbookEntitlement(int $ebookId, int $userId, ?int $purchaseId = null, string $source = 'purchase'): bool
    {
        $this->RL_EnsureEbookTables();
        return $this->RL_UpsertEbookEntitlement($ebookId, $userId, $purchaseId, $source);
    }

    public function RL_RecordEbookPurchase(
        int $ebookId,
        int $buyerId,
        int $sellerId,
        string $provider,
        string $reference,
        float $amount,
        string $currency,
        string $status = 'pending',
        string $event = '',
        array $raw = []
    ): bool {
        $this->RL_EnsureEbookTables();
        try {
            $now = time();
            $st = $this->db->prepare(
                "INSERT INTO i_ebook_purchases
                    (ebook_id, buyer_id, seller_id, provider, reference, amount, currency, status, event, raw_payload, created_at, updated_at)
                 VALUES
                    (:ebook, :buyer, :seller, :provider, :reference, :amount, :currency, :status, :event, :payload, :created, :updated)
                 ON DUPLICATE KEY UPDATE
                    provider = VALUES(provider),
                    reference = VALUES(reference),
                    amount = VALUES(amount),
                    currency = VALUES(currency),
                    status = VALUES(status),
                    event = VALUES(event),
                    raw_payload = VALUES(raw_payload),
                    updated_at = VALUES(updated_at)"
            );
            $ok = $st->execute([
                ':ebook' => $ebookId,
                ':buyer' => $buyerId,
                ':seller' => $sellerId,
                ':provider' => strtolower(trim($provider)),
                ':reference' => $reference,
                ':amount' => round(max(0.0, $amount), 2),
                ':currency' => strtoupper($currency ?: 'USD'),
                ':status' => $status,
                ':event' => $event,
                ':payload' => $this->RL_EbookEncodePayload($raw),
                ':created' => $now,
                ':updated' => $now,
            ]);
            if ($ok && in_array($status, ['succeeded', 'paid'], true)) {
                $row = $this->RL_GetEbookPurchaseByReference($provider, $reference);
                if ($row) {
                    $this->RL_UpsertEbookEntitlement($ebookId, $buyerId, (int)$row['purchase_id'], 'purchase');
                    $this->RL_CreateEbookInvoiceFromPurchaseRow($row);
                }
            }
            return $ok;
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_GetEbookPurchaseByReference(string $provider, string $reference): ?array
    {
        $this->RL_EnsureEbookTables();
        try {
            $st = $this->db->prepare('SELECT * FROM i_ebook_purchases WHERE provider = :provider AND reference = :reference LIMIT 1');
            $st->execute([':provider' => strtolower(trim($provider)), ':reference' => $reference]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (\Throwable $__) {
            return null;
        }
    }

    public function RL_UpdateEbookPurchaseStatusByReference(string $provider, string $reference, string $status, string $event = '', array $raw = []): bool
    {
        $this->RL_EnsureEbookTables();
        try {
            $st = $this->db->prepare(
                "UPDATE i_ebook_purchases
                 SET status = :status, event = :event, raw_payload = :payload, updated_at = :updated
                 WHERE provider = :provider AND reference = :reference"
            );
            $ok = $st->execute([
                ':status' => $status,
                ':event' => $event,
                ':payload' => $this->RL_EbookEncodePayload($raw),
                ':updated' => time(),
                ':provider' => strtolower(trim($provider)),
                ':reference' => $reference,
            ]);
            if ($ok) {
                $row = $this->RL_GetEbookPurchaseByReference($provider, $reference);
                if ($row && in_array($status, ['succeeded', 'paid'], true)) {
                    $this->RL_UpsertEbookEntitlement((int)$row['ebook_id'], (int)$row['buyer_id'], (int)$row['purchase_id'], 'purchase');
                    $this->RL_CreateEbookInvoiceFromPurchaseRow($row);
                } elseif ($row && in_array($status, ['refunded', 'disputed', 'cancelled'], true)) {
                    $revoke = $this->db->prepare(
                        "UPDATE i_ebook_entitlements
                         SET status = 'revoked', revoked_at = :revoked, revoke_reason = :reason, updated_at = :updated
                         WHERE ebook_id = :ebook AND user_id = :user"
                    );
                    $revoke->execute([
                        ':revoked' => time(),
                        ':reason' => $status,
                        ':updated' => time(),
                        ':ebook' => (int)$row['ebook_id'],
                        ':user' => (int)$row['buyer_id'],
                    ]);
                    $this->db->prepare("UPDATE i_invoices SET status = :status, updated_at = :updated WHERE source_type = 'ebook_purchase' AND source_id = :source")
                        ->execute([':status' => $status, ':updated' => time(), ':source' => (int)$row['purchase_id']]);
                }
            }
            return $ok;
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_UpdateEbookPurchaseAmountsByReference(
        string $provider,
        string $reference,
        ?float $gross,
        ?string $currency,
        ?float $feeAmount,
        ?string $feeCurrency,
        ?float $taxAmount,
        ?float $netAmount
    ): bool {
        $this->RL_EnsureEbookTables();
        try {
            $st = $this->db->prepare(
                "UPDATE i_ebook_purchases
                 SET amount = COALESCE(:gross, amount),
                     currency = COALESCE(:currency, currency),
                     fee_amount = COALESCE(:fee_amount, fee_amount),
                     fee_currency = COALESCE(:fee_currency, fee_currency),
                     tax_amount = COALESCE(:tax_amount, tax_amount),
                     net_amount = COALESCE(:net_amount, net_amount),
                     updated_at = :updated
                 WHERE provider = :provider AND reference = :reference"
            );
            $ok = $st->execute([
                ':gross' => $gross,
                ':currency' => $currency !== null ? strtoupper($currency) : null,
                ':fee_amount' => $feeAmount,
                ':fee_currency' => $feeCurrency !== null ? strtoupper($feeCurrency) : null,
                ':tax_amount' => $taxAmount,
                ':net_amount' => $netAmount,
                ':updated' => time(),
                ':provider' => strtolower(trim($provider)),
                ':reference' => $reference,
            ]);
            if ($ok) {
                $row = $this->RL_GetEbookPurchaseByReference($provider, $reference);
                if ($row) {
                    $this->RL_CreateEbookInvoiceFromPurchaseRow($row);
                }
            }
            return $ok;
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_CreditRecipientForEbookPurchaseByReference(string $provider, string $reference): bool
    {
        $this->RL_EnsureEbookTables();
        try {
            $db = $this->db;
            $db->beginTransaction();
            $st = $db->prepare('SELECT * FROM i_ebook_purchases WHERE provider = :provider AND reference = :reference FOR UPDATE');
            $st->execute([':provider' => strtolower(trim($provider)), ':reference' => $reference]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                $db->rollBack();
                return false;
            }
            if ((int)($row['credited_at'] ?? 0) > 0) {
                $this->RL_CreateEbookInvoiceFromPurchaseRow($row);
                $db->commit();
                return true;
            }
            if ((string)($row['status'] ?? '') !== 'succeeded') {
                $db->rollBack();
                return false;
            }
            $sellerId = (int)($row['seller_id'] ?? 0);
            $amount = (float)($row['net_amount'] ?? 0);
            if ($amount <= 0) {
                $amount = (float)($row['amount'] ?? 0);
            }
            if ($sellerId <= 0 || $amount <= 0) {
                $db->rollBack();
                return false;
            }
            $db->prepare('UPDATE i_users SET earned = COALESCE(earned,0) + :amount WHERE user_id = :uid')
                ->execute([':amount' => $amount, ':uid' => $sellerId]);
            $now = time();
            $db->prepare('UPDATE i_ebook_purchases SET credited_at = :credited, updated_at = :updated WHERE provider = :provider AND reference = :reference')
                ->execute([':credited' => $now, ':updated' => $now, ':provider' => strtolower(trim($provider)), ':reference' => $reference]);
            $row['credited_at'] = $now;
            $row['updated_at'] = $now;
            $this->RL_UpsertEbookEntitlement((int)$row['ebook_id'], (int)$row['buyer_id'], (int)$row['purchase_id'], 'purchase');
            $this->RL_CreateEbookInvoiceFromPurchaseRow($row);
            $db->commit();
            return true;
        } catch (\Throwable $__) {
            try {
                if ($this->db->inTransaction()) {
                    $this->db->rollBack();
                }
            } catch (\Throwable $___) {
            }
            return false;
        }
    }

    public function RL_PurchaseEbookWithWallet(int $buyerId, int $ebookId, ?float $discountedAmount = null, string $couponCode = ''): array
    {
        $this->RL_EnsureEbookTables();
        $ebook = $this->RL_GetEbookById($ebookId, $buyerId);
        if (!$ebook || (string) ($ebook['status'] ?? '') !== 'active') {
            return ['ok' => false, 'error' => 'ebook_not_found'];
        }
        $sellerId = (int) ($ebook['owner_id'] ?? 0);
        if ($buyerId <= 0 || $sellerId <= 0) {
            return ['ok' => false, 'error' => 'login_required'];
        }
        if ($sellerId === $buyerId || (int) ($ebook['viewer_purchased'] ?? 0) === 1 || (float) ($ebook['price'] ?? 0) <= 0) {
            return ['ok' => true, 'already' => true];
        }
        $amount = round($discountedAmount === null ? (float)($ebook['price'] ?? 0) : max(0.0, $discountedAmount), 2);
        $currency = strtoupper((string) ($ebook['currency'] ?? ($GLOBALS['currency'] ?? 'USD')));
        $feePercent = isset($GLOBALS['paymentFeePercent']) ? max(0.0, (float)$GLOBALS['paymentFeePercent']) : 0.0;
        $feeFixed = isset($GLOBALS['paymentFeeFixed']) ? max(0.0, (float)$GLOBALS['paymentFeeFixed']) : 0.0;
        $taxPercent = isset($GLOBALS['paymentTaxPercent']) ? max(0.0, (float)$GLOBALS['paymentTaxPercent']) : 0.0;
        $feeAmount = round(($amount * ($feePercent / 100.0)) + $feeFixed, 2);
        $taxAmount = round($amount * ($taxPercent / 100.0), 2);
        $totalCharge = round($amount + $feeAmount + $taxAmount, 2);
        if ($totalCharge <= 0.0) {
            $totalCharge = $amount;
        }
        try {
            $db = $this->db;
            $db->beginTransaction();
            $st = $db->prepare("SELECT purchase_id FROM i_ebook_purchases WHERE buyer_id = :buyer AND ebook_id = :ebook AND status = 'succeeded' LIMIT 1 FOR UPDATE");
            $st->execute([':buyer' => $buyerId, ':ebook' => $ebookId]);
            if ($st->fetch(\PDO::FETCH_ASSOC)) {
                $db->commit();
                return ['ok' => true, 'already' => true];
            }
            $st = $db->prepare('SELECT wallet FROM i_users WHERE user_id = :uid FOR UPDATE');
            $st->execute([':uid' => $buyerId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                $db->rollBack();
                return ['ok' => false, 'error' => 'buyer_not_found'];
            }
            $balance = (float) ($row['wallet'] ?? 0);
            if ($balance < $totalCharge) {
                $db->rollBack();
                return ['ok' => false, 'error' => 'insufficient_wallet', 'balance' => $balance, 'required' => $totalCharge];
            }
            $reference = 'EBWALLET-' . $buyerId . '-' . $ebookId . '-' . time() . '-' . bin2hex(random_bytes(3));
            $db->prepare('UPDATE i_users SET wallet = :wallet WHERE user_id = :uid')
                ->execute([':wallet' => number_format($balance - $totalCharge, 2, '.', ''), ':uid' => $buyerId]);
            $db->prepare('UPDATE i_users SET earned = COALESCE(earned,0) + :amount WHERE user_id = :uid')
                ->execute([':amount' => $amount, ':uid' => $sellerId]);
            $now = time();
            $st = $db->prepare(
                "INSERT INTO i_ebook_purchases
                    (ebook_id, buyer_id, seller_id, provider, reference, amount, currency, status, event, fee_amount, fee_currency, tax_amount, net_amount, raw_payload, credited_at, created_at, updated_at)
                 VALUES
                    (:ebook, :buyer, :seller, 'wallet', :reference, :amount, :currency, 'succeeded', 'wallet_debited', :fee_amount, :fee_currency, :tax_amount, :net_amount, :payload, :credited, :created, :updated)
                 ON DUPLICATE KEY UPDATE
                    provider = VALUES(provider),
                    reference = VALUES(reference),
                    amount = VALUES(amount),
                    currency = VALUES(currency),
                    status = VALUES(status),
                    event = VALUES(event),
                    fee_amount = VALUES(fee_amount),
                    fee_currency = VALUES(fee_currency),
                    tax_amount = VALUES(tax_amount),
                    net_amount = VALUES(net_amount),
                    raw_payload = VALUES(raw_payload),
                    credited_at = VALUES(credited_at),
                    updated_at = VALUES(updated_at)"
            );
            $st->execute([
                ':ebook' => $ebookId,
                ':buyer' => $buyerId,
                ':seller' => $sellerId,
                ':reference' => $reference,
                ':amount' => $totalCharge,
                ':currency' => $currency,
                ':fee_amount' => $feeAmount,
                ':fee_currency' => $currency,
                ':tax_amount' => $taxAmount,
                ':net_amount' => $amount,
                ':payload' => $this->RL_EbookEncodePayload(['source' => 'wallet', 'coupon_code' => strtoupper(trim($couponCode))]),
                ':credited' => $now,
                ':created' => $now,
                ':updated' => $now,
            ]);
            $purchaseLookup = $db->prepare('SELECT purchase_id FROM i_ebook_purchases WHERE buyer_id = :buyer AND ebook_id = :ebook LIMIT 1');
            $purchaseLookup->execute([':buyer' => $buyerId, ':ebook' => $ebookId]);
            $purchaseId = (int)$purchaseLookup->fetchColumn();
            $this->RL_UpsertEbookEntitlement($ebookId, $buyerId, $purchaseId > 0 ? $purchaseId : null, 'purchase');
            if ($purchaseId > 0) {
                $invoiceLookup = $db->prepare('SELECT * FROM i_ebook_purchases WHERE purchase_id = :purchase LIMIT 1');
                $invoiceLookup->execute([':purchase' => $purchaseId]);
                $invoiceRow = $invoiceLookup->fetch(\PDO::FETCH_ASSOC);
                if ($invoiceRow) {
                    $this->RL_CreateEbookInvoiceFromPurchaseRow($invoiceRow);
                }
            }
            if (trim($couponCode) !== '') {
                $db->prepare("UPDATE i_ebook_coupons SET used_count=used_count+1,updated_at=:updated WHERE code=:code AND status='active' AND (max_uses=0 OR used_count<max_uses)")->execute([':updated'=>$now,':code'=>strtoupper(trim($couponCode))]);
            }
            $db->prepare('UPDATE i_ebooks SET sales_count = sales_count + 1, updated_at = :updated WHERE ebook_id = :ebook')
                ->execute([':updated' => $now, ':ebook' => $ebookId]);
            $db->commit();
            return ['ok' => true, 'reference' => $reference, 'new_balance' => round($balance - $totalCharge, 2)];
        } catch (\Throwable $e) {
            try {
                if ($this->db->inTransaction()) {
                    $this->db->rollBack();
                }
            } catch (\Throwable $__) {
            }
            return ['ok' => false, 'error' => 'wallet_purchase_failed'];
        }
    }

    public function RL_IncrementEbookDownload(int $ebookId): bool
    {
        $this->RL_EnsureEbookTables();
        try {
            $st = $this->db->prepare('UPDATE i_ebooks SET download_count = download_count + 1, updated_at = :updated WHERE ebook_id = :ebook');
            return $st->execute([':ebook' => $ebookId, ':updated' => time()]);
        } catch (\Throwable $__) {
            return false;
        }
    }
}
