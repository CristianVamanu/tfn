<?php
declare(strict_types=1);

trait LiveChatFunctions
{
    /** Return last message timestamp for a user in a live chat, or 0 if none */
    public function RL_GetLastLiveChatMessageTime(int $liveId, int $userId): int
    {
        try {
            $st = $this->db->prepare('SELECT created_at FROM i_live_chat_messages WHERE live_id = :l AND uid_fk = :u ORDER BY id DESC LIMIT 1');
            $st->execute([':l'=>$liveId, ':u'=>$userId]);
            return (int)($st->fetchColumn() ?: 0);
        } catch (\Throwable $__) { return 0; }
    }
    /**
     * Fetch live chat messages after a given message id.
     * Returns ['messages'=>[...], 'last_id'=>int]
     */
    public function RL_GetLiveChatMessagesSince(int $liveId, int $sinceId = 0, int $limit = 50): array
    {
        $limit = max(1, min(100, $limit));
        $sql = "SELECT m.id, m.uid_fk AS user_id, m.message, m.created_at,
                       u.username, u.user_fullname, u.verified_status
                FROM i_live_chat_messages m
                INNER JOIN i_users u ON u.user_id = m.uid_fk
                WHERE m.live_id = :l" . ($sinceId > 0 ? " AND m.id > :sid" : "") . "
                ORDER BY m.id ASC
                LIMIT " . (int)$limit;

        $st = $this->db->prepare($sql);
        $st->bindValue(':l', $liveId, \PDO::PARAM_INT);
        if ($sinceId > 0) { $st->bindValue(':sid', $sinceId, \PDO::PARAM_INT); }
        $st->execute();
        $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];

        $messages = [];
        $maxId = $sinceId;
        foreach ($rows as $r) {
            $uid = (int)($r['user_id'] ?? 0);
            // Reuse existing avatar helper
            if (method_exists($this, 'RL_userAvatar')) {
                $r['avatar'] = $this->RL_userAvatar($uid);
            } else {
                $r['avatar'] = 'uploads/user_avatars/default.jpeg';
            }
            $messages[] = $r;
            if (isset($r['id'])) { $maxId = max($maxId, (int)$r['id']); }
        }
        return ['messages' => $messages, 'last_id' => $maxId];
    }

    /** Insert a live chat message and return its id (or 0 on failure) */
    public function RL_InsertLiveChatMessage(int $liveId, int $userId, string $message, int $createdAt): int
    {
        try {
            $st = $this->db->prepare('INSERT INTO i_live_chat_messages (live_id, uid_fk, message, created_at) VALUES (:l,:u,:m,:t)');
            $st->execute([':l'=>$liveId, ':u'=>$userId, ':m'=>$message, ':t'=>$createdAt]);
            return (int)$this->db->lastInsertId();
        } catch (\Throwable $__) { return 0; }
    }
}
