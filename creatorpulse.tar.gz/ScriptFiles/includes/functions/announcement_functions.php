<?php

declare(strict_types=1);

trait AnnouncementFunctions
{
    /**
     * Fetch the currently active announcement if one exists.
     *
     * @param int|null $timestamp Optional reference timestamp (defaults to now, UTC)
     * @return array|null
     */
    public function RL_GetActiveAnnouncement(?int $timestamp = null): ?array
    {
        $now = $timestamp ?? time();

        try {
            /** @var PDO $db */
            $db = $this->getDb();
            $sql = "SELECT id, message, status, start_at, end_at, allow_close, title, cta_label, cta_url, image_path, created_at, updated_at
                    FROM i_announcements
                    WHERE status = 'active'
                      AND (start_at IS NULL OR start_at = 0 OR start_at <= :now_start)
                      AND (end_at IS NULL OR end_at = 0 OR end_at >= :now_end)
                    ORDER BY COALESCE(NULLIF(start_at, 0), created_at) DESC, id DESC
                    LIMIT 1";
            $stmt = $db->prepare($sql);
            $stmt->bindValue(':now_start', $now, PDO::PARAM_INT);
            $stmt->bindValue(':now_end', $now, PDO::PARAM_INT);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row === false) {
                return null;
            }
            return $row;
        } catch (Throwable $e) {
            if (defined('APP_DEBUG') && APP_DEBUG === true) {
                error_log('RL_GetActiveAnnouncement failed: ' . $e->getMessage());
            }
            return null;
        }
    }

    /**
     * Retrieve an announcement row by id.
     */
    public function RL_GetAnnouncementById(int $announcementId): ?array
    {
        if ($announcementId <= 0) {
            return null;
        }
        try {
            $db = $this->getDb();
            $stmt = $db->prepare('SELECT id, message, status, start_at, end_at, allow_close, title, cta_label, cta_url, image_path, created_at, updated_at FROM i_announcements WHERE id = :id LIMIT 1');
            $stmt->bindValue(':id', $announcementId, PDO::PARAM_INT);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row === false ? null : $row;
        } catch (Throwable $e) {
            if (defined('APP_DEBUG') && APP_DEBUG === true) {
                error_log('RL_GetAnnouncementById failed: ' . $e->getMessage());
            }
            return null;
        }
    }
}
