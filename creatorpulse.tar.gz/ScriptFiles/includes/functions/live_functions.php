<?php
declare(strict_types=1);

trait LiveFunctions
{
    private function ensureLiveViewersTable(): void
    {
        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_live_viewers (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                live_id INT UNSIGNED NOT NULL,
                session_key VARCHAR(64) NOT NULL,
                uid_fk INT UNSIGNED NULL,
                last_seen INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq (live_id, session_key),
                KEY idx_live (live_id),
                KEY idx_seen (last_seen)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;");
        } catch (\Throwable $__) {}
    }

    public function RL_GetLiveOwnerId(int $liveId): int
    {
        try {
            $st = $this->db->prepare('SELECT user_id FROM i_live_streams WHERE live_id = :l LIMIT 1');
            $st->execute([':l'=>$liveId]);
            return (int)($st->fetchColumn() ?: 0);
        } catch (\Throwable $__) { return 0; }
    }

    public function RL_CountLiveViewers(int $liveId, int $sinceTs, int $excludeUserId = 0): int
    {
        $this->ensureLiveViewersTable();
        try {
            $st = $this->db->prepare('SELECT COUNT(*) FROM i_live_viewers WHERE live_id = :l AND last_seen > :t AND (uid_fk IS NULL OR uid_fk <> :owner)');
            $st->execute([':l'=>$liveId, ':t'=>$sinceTs, ':owner'=>$excludeUserId]);
            return (int)$st->fetchColumn();
        } catch (\Throwable $__) { return 0; }
    }

    public function RL_PruneLiveViewers(int $olderThan): int
    {
        $this->ensureLiveViewersTable();
        try {
            $st = $this->db->prepare('DELETE FROM i_live_viewers WHERE last_seen <= :t');
            $st->execute([':t'=>$olderThan]);
            return (int)$st->rowCount();
        } catch (\Throwable $__) { return 0; }
    }

    public function RL_UpsertLiveViewer(int $liveId, string $sessionKey, int $uid, int $now): bool
    {
        $this->ensureLiveViewersTable();
        try {
            $st = $this->db->prepare('INSERT INTO i_live_viewers (live_id, session_key, uid_fk, last_seen) VALUES (:l,:s,:u,:t)
                            ON DUPLICATE KEY UPDATE last_seen = VALUES(last_seen), uid_fk = VALUES(uid_fk)');
            return $st->execute([':l'=>$liveId, ':s'=>$sessionKey, ':u'=>$uid, ':t'=>$now]);
        } catch (\Throwable $__) { return false; }
    }

    public function RL_GetLiveStatus(int $liveId): ?string
    {
        try {
            $st = $this->db->prepare('SELECT status FROM i_live_streams WHERE live_id = :l LIMIT 1');
            $st->execute([':l'=>$liveId]);
            $val = $st->fetchColumn();
            return $val !== false ? (string)$val : null;
        } catch (\Throwable $__) { return null; }
    }
    private function ensureLiveTable(): void
    {
        $sql = "
            CREATE TABLE IF NOT EXISTS i_live_streams (
                live_id     INT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id     INT UNSIGNED NOT NULL,
                title       VARCHAR(180) NOT NULL,
                audience    ENUM('everyone','followers','following','subscribers','only_me') NOT NULL DEFAULT 'everyone',
                status      ENUM('created','live','ended') NOT NULL DEFAULT 'created',
                created_at  INT UNSIGNED NOT NULL,
                started_at  INT UNSIGNED NULL,
                ended_at    INT UNSIGNED NULL,
                PRIMARY KEY (live_id),
                KEY idx_user (user_id),
                KEY idx_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
        ";
        try { $this->db->exec($sql); } catch (\Throwable $__) {}
        // Attempt to upgrade existing enum to include 'following'
        try {
            $col = $this->db->query("SHOW COLUMNS FROM i_live_streams LIKE 'audience'")->fetch(\PDO::FETCH_ASSOC);
            if ($col && isset($col['Type']) && strpos((string)$col['Type'], "'following'") === false) {
                $this->db->exec("ALTER TABLE i_live_streams MODIFY audience ENUM('everyone','followers','following','subscribers','only_me') NOT NULL DEFAULT 'everyone'");
            }
        } catch (\Throwable $__) {}
    }

    private function liveStreamCoverColumn(): ?string
    {
        static $cached = false;
        static $column = null;

        if ($cached !== false) {
            return $column;
        }

        $cached = true;

        $candidates = ['cover_path', 'cover', 'cover_image', 'thumbnail_path', 'thumbnail'];

        foreach ($candidates as $candidate) {
            try {
                $stmt = $this->db->prepare("SHOW COLUMNS FROM i_live_streams LIKE :col");
                $stmt->execute([':col' => $candidate]);
                if ($stmt->fetch(\PDO::FETCH_ASSOC)) {
                    $column = $candidate;
                    return $column;
                }
            } catch (\Throwable $__) {
                // Database may not allow SHOW COLUMNS; bail out gracefully.
                $column = null;
                return $column;
            }
        }

        $column = null;
        return $column;
    }

    /**
     * Create a live stream row and return its id
     * @return int live_id
     */
    public function RL_CreateLiveStream(int $userId, string $title, string $audience, string $status = 'created'): int
    {
        $this->ensureLiveTable();
        $title = trim($title);
        if ($title === '') { return 0; }
        $allowed = ['everyone','followers','following','subscribers','only_me'];
        if (!in_array($audience, $allowed, true)) { $audience = 'everyone'; }
        $allowedStatus = ['created','live','ended'];
        if (!in_array($status, $allowedStatus, true)) { $status = 'created'; }
        $now = time();
        $started = ($status === 'live') ? $now : null;
        $sql = "INSERT INTO i_live_streams (user_id, title, audience, status, created_at, started_at) VALUES (:u,:t,:a,:s,:c,:st)";
        $st = $this->db->prepare($sql);
        $st->bindValue(':u', $userId, \PDO::PARAM_INT);
        $st->bindValue(':t', $title, \PDO::PARAM_STR);
        $st->bindValue(':a', $audience, \PDO::PARAM_STR);
        $st->bindValue(':s', $status, \PDO::PARAM_STR);
        $st->bindValue(':c', $now, \PDO::PARAM_INT);
        if ($started === null) { $st->bindValue(':st', null, \PDO::PARAM_NULL); }
        else { $st->bindValue(':st', $started, \PDO::PARAM_INT); }
        if (!$st->execute()) { return 0; }
        return (int)$this->db->lastInsertId();
    }

    /**
     * Fetch live stream by id
     */
    public function RL_GetLiveById(int $liveId): ?array
    {
        $this->ensureLiveTable();
        $sql = "SELECT l.*, u.username, u.user_fullname, u.user_avatar, u.verified_status
                FROM i_live_streams l
                INNER JOIN i_users u ON u.user_id = l.user_id
                WHERE l.live_id = :id LIMIT 1";
        $st = $this->db->prepare($sql);
        $st->bindValue(':id', $liveId, \PDO::PARAM_INT);
        $st->execute();
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    public function RL_GetLiveList(int $viewerId = 0, int $limit = 12, int $offset = 0, array $statusFilter = ['live']): array
    {
        $this->ensureLiveTable();

        $limit = max(1, min($limit, 50));
        $offset = max(0, $offset);

        $allowedStatuses = ['created', 'live', 'ended'];
        $normalizedStatuses = [];
        foreach ($statusFilter as $status) {
            $status = strtolower(trim((string) $status));
            if ($status !== '' && in_array($status, $allowedStatuses, true)) {
                $normalizedStatuses[$status] = true;
            }
        }
        if (!$normalizedStatuses) {
            $normalizedStatuses = ['live' => true];
        }
        $statusList = array_keys($normalizedStatuses);

        $coverColumn = $this->liveStreamCoverColumn();

        $columns = [
            'l.live_id',
            'l.user_id',
            'l.title',
            'l.audience',
            'l.status',
            'l.created_at',
            'l.started_at',
            'l.ended_at',
            'u.username',
            'u.user_fullname',
            'u.user_avatar',
        ];

        if ($coverColumn) {
            $columns[] = 'l.' . $coverColumn . ' AS cover_path';
        } else {
            $columns[] = 'NULL AS cover_path';
        }

        $sql = 'SELECT ' . implode(', ', $columns)
             . ' FROM i_live_streams l'
             . ' INNER JOIN i_users u ON u.user_id = l.user_id'
             . ' WHERE l.status IN (' . implode(',', array_fill(0, count($statusList), '?')) . ')'
             . ' ORDER BY (l.status = "live") DESC, COALESCE(l.started_at, l.created_at) DESC, l.live_id DESC'
             . ' LIMIT ? OFFSET ?';

        $params = array_merge($statusList, [$limit, $offset]);

        try {
            $stmt = $this->db->prepare($sql);
            foreach ($statusList as $idx => $status) {
                $stmt->bindValue($idx + 1, $status, \PDO::PARAM_STR);
            }
            $stmt->bindValue(count($statusList) + 1, $limit, \PDO::PARAM_INT);
            $stmt->bindValue(count($statusList) + 2, $offset, \PDO::PARAM_INT);
            $stmt->execute();
            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Throwable $__) {
            return [];
        }

        $viewerId = max(0, (int) $viewerId);
        $result = [];

        foreach ($rows as $row) {
            $ownerId = (int) ($row['user_id'] ?? 0);
            $audience = strtolower((string) ($row['audience'] ?? 'everyone'));
            $status = strtolower((string) ($row['status'] ?? 'created'));

            if ($status === 'ended') {
                continue;
            }

            $canView = true;
            if ($ownerId <= 0) {
                $canView = false;
            } elseif ($audience === 'only_me' && $viewerId !== $ownerId) {
                $canView = false;
            } elseif ($audience === 'followers' && $viewerId !== $ownerId) {
                $canView = $viewerId > 0 && method_exists($this, 'RL_IsFollowing') && $this->RL_IsFollowing($viewerId, $ownerId);
            } elseif ($audience === 'subscribers' && $viewerId !== $ownerId) {
                $canView = $viewerId > 0 && method_exists($this, 'RL_IsSubscriber') && $this->RL_IsSubscriber($viewerId, $ownerId);
            } elseif ($audience === 'following' && $viewerId !== $ownerId) {
                $canView = $viewerId > 0 && method_exists($this, 'RL_IsFollowing') && $this->RL_IsFollowing($ownerId, $viewerId);
            }

            if (!$canView) {
                continue;
            }

            $result[] = [
                'live_id'         => (int) ($row['live_id'] ?? 0),
                'title'           => (string) ($row['title'] ?? ''),
                'audience'        => $audience,
                'status'          => $status,
                'cover'           => (string) ($row['cover_path'] ?? ''),
                'owner_id'        => $ownerId,
                'owner_username'  => (string) ($row['username'] ?? ''),
                'owner_fullname'  => (string) ($row['user_fullname'] ?? ''),
                'owner_avatar'    => (string) ($row['user_avatar'] ?? ''),
                'started_at'      => isset($row['started_at']) ? (int) $row['started_at'] : null,
                'created_at'      => isset($row['created_at']) ? (int) $row['created_at'] : null,
            ];
        }

        return $result;
    }

    /**
     * End a live stream (owner only). Returns true if updated.
     */
    public function RL_EndLiveStream(int $userId, int $liveId): bool
    {
        $this->ensureLiveTable();
        $sql = "UPDATE i_live_streams
                   SET status='ended', ended_at = :t
                 WHERE live_id = :id AND user_id = :u AND status <> 'ended'";
        $st = $this->db->prepare($sql);
        $st->bindValue(':t', time(), \PDO::PARAM_INT);
        $st->bindValue(':id', $liveId, \PDO::PARAM_INT);
        $st->bindValue(':u', $userId, \PDO::PARAM_INT);
        if (!$st->execute()) { return false; }
        return $st->rowCount() > 0;
    }
}
