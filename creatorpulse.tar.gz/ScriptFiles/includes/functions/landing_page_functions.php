<?php
declare(strict_types=1);

trait LandingPageFunctions
{
    private function normalizeLandingTheme(string $theme): string
    {
        $theme = strtolower(trim($theme));
        if ($theme === '') {
            $theme = 'welcome_default';
        }
        return preg_replace('/[^a-z0-9_-]/', '', $theme) ?: 'welcome_default';
    }

    private function normalizeLandingLangKey(string $lang): string
    {
        $lang = strtolower(trim($lang));
        $map = [
            'eng' => 'en',
            'en' => 'en',
            'english' => 'en',
            'tr' => 'tr',
            'tur' => 'tr',
            'trk' => 'tr',
            'turkish' => 'tr',
        ];
        if (isset($map[$lang])) {
            return $map[$lang];
        }
        if (strlen($lang) >= 2) {
            return substr($lang, 0, 2);
        }
        return $lang;
    }

    private function defaultLandingConfig(string $theme): array
    {
        return [
            'theme' => $theme,
            'image_list' => [
                'media_mode' => 'mixed',    // mixed|image|video
                'target' => 'profile',      // profile|post
                'show_views' => true,
                'show_likes' => true,
            ],
            'marquee' => [
                'list_count' => 4,
                'show_avatar' => true,
                'name_mode' => 'full',      // full|username
            ],
            'features' => [
                'items' => [],
            ],
            'samples' => [
                'tags' => [],
            ],
            'pricing' => [
                'sections' => [],
            ],
            'earnings_simulator' => [
                'default_followers' => 1000,
                'default_price' => 10.0,
                'conversion_rate' => 0.2,
            ],
            'simulator' => [
                'enabled' => true,
                'title_key' => 'simulator_title',
                'description_key' => 'simulator_description',
            ],
            'no_hassle' => [
                'items' => [],
                'ma_color' => '#4F86F7',
            ],
            'faqs' => [
                'managed_via' => 'settings',
            ],
            'footer_links' => [
                'href' => '',
                'target' => '_self',
                'rel' => '',
            ],
            'get_started' => [
                'data_ma_color' => '#FF3C3C',
            ],
            'footer_cta' => [
                'ma_color' => '#FF3C3C',
            ],
        ];
    }

    private function ensureLandingTablesPrepared(): void
    {
        static $ensured = false;
        if ($ensured || !isset($this->db)) {
            return;
        }
        $ensured = true;

        $tables = [
            'i_landing_pages' => [
                'create' => <<<'SQL'
CREATE TABLE IF NOT EXISTS i_landing_pages (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  theme VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  settings LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  created_at INT UNSIGNED NOT NULL,
  updated_at INT UNSIGNED NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_theme (theme)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL,
                'definition' => 'INT UNSIGNED NOT NULL AUTO_INCREMENT',
            ],
            'i_landing_sections' => [
                'create' => <<<'SQL'
CREATE TABLE IF NOT EXISTS i_landing_sections (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  theme VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  section_key VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  cfg_json LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  sort_order SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  updated_at INT UNSIGNED NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_theme_section (theme, section_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL,
                'definition' => 'INT UNSIGNED NOT NULL AUTO_INCREMENT',
            ],
            'i_landing_items' => [
                'create' => <<<'SQL'
CREATE TABLE IF NOT EXISTS i_landing_items (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  section_id INT UNSIGNED NOT NULL,
  item_type VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  post_id INT UNSIGNED DEFAULT NULL,
  media_type VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  media_path TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  thumb_path TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  meta_json LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  lang_json LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  sort_order SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  created_at INT UNSIGNED NOT NULL,
  updated_at INT UNSIGNED NOT NULL,
  PRIMARY KEY (id),
  KEY idx_section (section_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci;
SQL,
                'definition' => 'INT UNSIGNED NOT NULL AUTO_INCREMENT',
            ],
        ];

        foreach ($tables as $table => $info) {
            $createSql = $info['create'] ?? '';
            if ($createSql !== '') {
                try {
                    $this->db->exec($createSql);
                } catch (Throwable $e) {
                    if (method_exists($this, 'logError')) {
                        $this->logError('ensureLandingTablesPrepared create failed: ' . $table . ' · ' . $e->getMessage());
                    }
                }
            }
            $definition = $info['definition'] ?? '';
            if ($definition !== '') {
                $this->ensureLandingAutoIncrementColumn($table, $definition);
            }
        }
    }

    private function ensureLandingAutoIncrementColumn(string $table, string $definition, string $column = 'id'): void
    {
        if (!isset($this->db)) {
            return;
        }
        $baseDefinition = trim(preg_replace('/\s+AUTO_INCREMENT/i', '', $definition));
        if ($baseDefinition === '') {
            $baseDefinition = $definition;
        }

        try {
            $stmt = $this->db->query("SHOW COLUMNS FROM {$table} LIKE '{$column}'");
            $columnInfo = $stmt ? $stmt->fetch(PDO::FETCH_ASSOC) : false;
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('ensureLandingAutoIncrement inspect failed: ' . $table . '.' . $column . ' · ' . $e->getMessage());
            }
            return;
        }

        if (!$columnInfo) {
            try {
                $this->db->exec("ALTER TABLE {$table} ADD COLUMN `{$column}` {$baseDefinition}");
            } catch (Throwable $e) {
                if (method_exists($this, 'logError')) {
                    $this->logError('ensureLandingAutoIncrement add column failed: ' . $table . '.' . $column . ' · ' . $e->getMessage());
                }
                return;
            }
        }

        try {
            $this->db->exec("ALTER TABLE {$table} ADD PRIMARY KEY (`{$column}`)");
        } catch (Throwable $__) {
            // Already has a primary key.
        }

        $uniqueName = 'uniq_' . $table . '_' . $column;
        try {
            $this->db->exec("ALTER TABLE {$table} ADD UNIQUE KEY `{$uniqueName}` (`{$column}`)");
        } catch (Throwable $__) {
            // Unique key already exists or cannot be added.
        }

        try {
            $stmt = $this->db->query("SHOW COLUMNS FROM {$table} LIKE '{$column}'");
            $columnInfo = $stmt ? $stmt->fetch(PDO::FETCH_ASSOC) : false;
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('ensureLandingAutoIncrement refresh failed: ' . $table . '.' . $column . ' · ' . $e->getMessage());
            }
            return;
        }

        $hasAuto = $columnInfo && stripos((string) ($columnInfo['Extra'] ?? ''), 'auto_increment') !== false;
        if ($hasAuto) {
            return;
        }

        try {
            $this->db->exec("ALTER TABLE {$table} MODIFY `{$column}` {$definition}");
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('ensureLandingAutoIncrement modify failed: ' . $table . '.' . $column . ' · ' . $e->getMessage());
            }
        }
    }

    private function defaultLandingSectionConfig(string $sectionKey): array
    {
        switch ($sectionKey) {
            case 'image_list':
                return [
                    'media_mode' => 'mixed',
                    'target' => 'profile',
                    'show_views' => true,
                    'show_likes' => true,
                ];
            case 'marquee':
                return [
                    'list_count' => 4,
                    'show_avatar' => true,
                    'name_mode' => 'full',
                ];
            case 'samples':
                return [
                    'layout' => 'grid',
                ];
            case 'pricing':
                return [
                    'mode' => 'earning_cards_v1',
                ];
            case 'earnings_simulator':
                return [
                    'default_followers' => 1000,
                    'default_price' => 10.0,
                    'conversion_rate' => 0.2,
                ];
            case 'no_hassle':
                return [
                    'ma_color' => '#4F86F7',
                ];
            case 'footer_links':
                return [
                    'href' => '',
                    'target' => '_self',
                    'rel' => '',
                ];
            case 'get_started':
                return [
                    'data_ma_color' => '#FF3C3C',
                ];
            default:
                return [];
        }
    }

    private function normalizeSectionConfig(string $sectionKey, array $cfg): array
    {
        if ($sectionKey === 'image_list') {
            if (isset($cfg['mode']) && !isset($cfg['media_mode'])) {
                $cfg['media_mode'] = (string) $cfg['mode'];
                unset($cfg['mode']);
            }
            if (isset($cfg['link_target']) && !isset($cfg['target'])) {
                $cfg['target'] = (string) $cfg['link_target'];
                unset($cfg['link_target']);
            }
            if (!in_array($cfg['media_mode'] ?? 'mixed', ['mixed', 'image', 'video'], true)) {
                $cfg['media_mode'] = 'mixed';
            }
            if (!in_array($cfg['target'] ?? 'profile', ['profile', 'post'], true)) {
                $cfg['target'] = 'profile';
            }
            $cfg['show_views'] = !empty($cfg['show_views']);
            $cfg['show_likes'] = !empty($cfg['show_likes']);
        } elseif ($sectionKey === 'marquee') {
            if (isset($cfg['row_count']) && !isset($cfg['list_count'])) {
                $cfg['list_count'] = (int) $cfg['row_count'];
                unset($cfg['row_count']);
            }
            $cfg['list_count'] = max(1, min((int) ($cfg['list_count'] ?? 4), 10));
            $nameMode = isset($cfg['name_mode']) ? strtolower((string) $cfg['name_mode']) : 'full';
            if (!in_array($nameMode, ['full', 'username'], true)) {
                $nameMode = 'full';
            }
            $cfg['name_mode'] = $nameMode;
            $cfg['show_avatar'] = !empty($cfg['show_avatar']);
        } elseif ($sectionKey === 'pricing') {
            $mode = isset($cfg['mode']) ? trim((string) $cfg['mode']) : 'earning_cards_v1';
            if ($mode === '') {
                $mode = 'earning_cards_v1';
            }
            $cfg = ['mode' => $mode];
        } elseif ($sectionKey === 'earnings_simulator') {
            $followers = isset($cfg['default_followers']) ? (int) $cfg['default_followers'] : 1000;
            $followers = max(0, min($followers, 1000000));

            $price = isset($cfg['default_price']) ? (float) $cfg['default_price'] : 10.0;
            if (!is_finite($price)) {
                $price = 10.0;
            }
            $price = round($price, 2);
            if ($price < 1.0) {
                $price = 1.0;
            }
            if ($price > 1000.0) {
                $price = 1000.0;
            }

            $conversion = isset($cfg['conversion_rate']) ? (float) $cfg['conversion_rate'] : 0.2;
            if (!is_finite($conversion)) {
                $conversion = 0.2;
            }
            if ($conversion < 0.0) {
                $conversion = 0.0;
            }
            if ($conversion > 1.0) {
                $conversion = 1.0;
            }

            $cfg = [
                'default_followers' => $followers,
                'default_price' => $price,
                'conversion_rate' => $conversion,
            ];
        } elseif ($sectionKey === 'no_hassle') {
            $color = isset($cfg['ma_color']) ? trim((string) $cfg['ma_color']) : '';
            if ($color !== '' && !preg_match('/^#[0-9a-fA-F]{3,8}$/', $color)) {
                $color = '';
            }
            if ($color === '') {
                $color = '#4F86F7';
            }
            $cfg['ma_color'] = $color;
        } elseif ($sectionKey === 'footer_links') {
            $href = isset($cfg['href']) ? trim((string) $cfg['href']) : '';
            if ($href !== '' && mb_strlen($href) > 500) {
                $href = mb_substr($href, 0, 500);
            }
            $target = isset($cfg['target']) ? strtolower(trim((string) $cfg['target'])) : '_self';
            if (!in_array($target, ['_self', '_blank', '_parent', '_top'], true)) {
                $target = '_self';
            }
            $rel = isset($cfg['rel']) ? trim((string) $cfg['rel']) : '';
            if ($rel !== '' && mb_strlen($rel) > 200) {
                $rel = mb_substr($rel, 0, 200);
            }
            $cfg = [
                'href' => $href,
                'target' => $target,
                'rel' => $rel,
            ];
        } elseif ($sectionKey === 'get_started') {
            $color = isset($cfg['data_ma_color']) ? trim((string) $cfg['data_ma_color']) : '';
            if ($color !== '' && !preg_match('/^#[0-9a-fA-F]{3,8}$/', $color)) {
                $color = '';
            }
            if ($color === '') {
                $color = '#FF3C3C';
            }
            $cfg['data_ma_color'] = $color;
        }
        return $cfg;
    }

    public function RL_GetLandingConfig(string $theme = 'welcome_default'): array
    {
        $this->ensureLandingTablesPrepared();
        $theme = $this->normalizeLandingTheme($theme);
        $default = $this->defaultLandingConfig($theme);

        try {
            $stmt = $this->db->prepare('SELECT settings FROM i_landing_pages WHERE theme = :theme LIMIT 1');
            $stmt->bindValue(':theme', $theme, PDO::PARAM_STR);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row && !empty($row['settings'])) {
                $decoded = json_decode((string) $row['settings'], true);
                if (is_array($decoded)) {
                    $default = array_replace_recursive($default, $decoded);
                }
            } else {
                $this->RL_SaveLandingConfig($theme, $default);
            }
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetLandingConfig failed: ' . $e->getMessage());
            }
        }

        // Backward compatibility for older keys
        if (isset($default['image_list']['mode']) && !isset($default['image_list']['media_mode'])) {
            $default['image_list']['media_mode'] = (string) $default['image_list']['mode'];
            unset($default['image_list']['mode']);
        }
        if (isset($default['image_list']['link_target']) && !isset($default['image_list']['target'])) {
            $default['image_list']['target'] = (string) $default['image_list']['link_target'];
            unset($default['image_list']['link_target']);
        }

        if (isset($default['marquee']['row_count']) && !isset($default['marquee']['list_count'])) {
            $default['marquee']['list_count'] = (int) $default['marquee']['row_count'];
            unset($default['marquee']['row_count']);
        }
        $default['marquee']['list_count'] = max(1, min((int) ($default['marquee']['list_count'] ?? 4), 10));
        if (!isset($default['marquee']['name_mode'])) {
            $default['marquee']['name_mode'] = 'full';
        }
        if (!in_array($default['marquee']['name_mode'], ['full', 'username'], true)) {
            $default['marquee']['name_mode'] = 'full';
        }
        $default['marquee']['show_avatar'] = !empty($default['marquee']['show_avatar']);

        return $default;
    }

    public function RL_SaveLandingConfig(string $theme, array $config, ?int $activeOverride = null): bool
    {
        $this->ensureLandingTablesPrepared();
        $theme = $this->normalizeLandingTheme($theme);
        $now = time();
        try {
            $settingsJson = json_encode($config, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($settingsJson === false) {
                return false;
            }
            if ($activeOverride === null) {
                $active = 0;
                $stmtActive = $this->db->prepare('SELECT is_active FROM i_landing_pages WHERE theme = :theme LIMIT 1');
                $stmtActive->bindValue(':theme', $theme, PDO::PARAM_STR);
                $stmtActive->execute();
                $rowActive = $stmtActive->fetch(PDO::FETCH_ASSOC);
                if ($rowActive && array_key_exists('is_active', $rowActive)) {
                    $active = (int) $rowActive['is_active'];
                } else {
                    $active = $theme === 'welcome_default' ? 1 : 0;
                }
            } else {
                $active = $activeOverride ? 1 : 0;
            }
            $sql = 'INSERT INTO i_landing_pages (theme, is_active, settings, created_at, updated_at)
                    VALUES (:theme, :active, :settings, :created, :updated)
                    ON DUPLICATE KEY UPDATE
                        is_active = VALUES(is_active),
                        settings = VALUES(settings),
                        updated_at = VALUES(updated_at)';
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':theme', $theme, PDO::PARAM_STR);
            $stmt->bindValue(':active', $active, PDO::PARAM_INT);
            $stmt->bindValue(':settings', $settingsJson, PDO::PARAM_STR);
            $stmt->bindValue(':created', $now, PDO::PARAM_INT);
            $stmt->bindValue(':updated', $now, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_SaveLandingConfig failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    public function RL_SetActiveLandingTheme(string $theme): bool
    {
        $this->ensureLandingTablesPrepared();
        $theme = $this->normalizeLandingTheme($theme);
        try {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_SetActiveLandingTheme start: ' . $theme);
            }
            // Ensure the theme row exists before toggling.
            $this->RL_GetLandingConfig($theme);

            if (!$this->db->beginTransaction()) {
                if (method_exists($this, 'logError')) {
                    $this->logError('RL_SetActiveLandingTheme beginTransaction failed: ' . $theme);
                }
                return false;
            }

            $stmtReset = $this->db->prepare('UPDATE i_landing_pages SET is_active = 0');
            $stmtReset->execute();

            $stmtActivate = $this->db->prepare('UPDATE i_landing_pages SET is_active = 1, updated_at = :updated WHERE theme = :theme LIMIT 1');
            $stmtActivate->bindValue(':updated', time(), PDO::PARAM_INT);
            $stmtActivate->bindValue(':theme', $theme, PDO::PARAM_STR);
            $stmtActivate->execute();

            $this->db->commit();

            $rowCount = $stmtActivate->rowCount();
            if (method_exists($this, 'logError')) {
                $this->logError('RL_SetActiveLandingTheme commit: ' . $theme . ' rows=' . $rowCount);
            }

            return $rowCount > 0;
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            if (method_exists($this, 'logError')) {
                $this->logError('RL_SetActiveLandingTheme failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    public function RL_GetActiveLandingTheme(): string
    {
        try {
            $stmt = $this->db->query('SELECT theme FROM i_landing_pages WHERE is_active = 1 ORDER BY updated_at DESC LIMIT 1');
            $theme = $stmt ? $stmt->fetchColumn() : false;
            if (is_string($theme) && $theme !== '') {
                return $this->normalizeLandingTheme($theme);
            }
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetActiveLandingTheme failed: ' . $e->getMessage());
            }
        }

        // Ensure the default theme is available and active when nothing is configured.
        $this->RL_SetActiveLandingTheme('welcome_default');
        return 'welcome_default';
    }

    private function normalizeSectionItem(string $sectionKey, array $item): ?array
    {
        $now = time(); // not used but reserved if needed later

        if ($sectionKey === 'marquee') {
            $display  = trim((string) ($item['display'] ?? ''));
            $username = trim((string) ($item['username'] ?? ''));
            $avatar   = trim((string) ($item['avatar'] ?? ''));
            $verified = !empty($item['verified']);

            if ($display === '' && $username === '' && $avatar === '') {
                return null;
            }

            $meta = [
                'display'  => $display,
                'username' => $username,
                'avatar'   => $avatar,
                'verified' => $verified,
            ];
            $metaJson = json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($metaJson === false) { $metaJson = '{}'; }

            return [
                'type'       => 'manual',
                'post_id'    => null,
                'media_type' => null,
                'media_path' => null,
                'thumb_path' => null,
                'meta'       => $metaJson,
                'lang'       => null,
            ];
        }

        if ($sectionKey === 'features') {
            $icon  = trim((string) ($item['icon'] ?? ''));
            $color = trim((string) ($item['color'] ?? ''));
            if ($color !== '' && !preg_match('/^#[0-9a-fA-F]{3,8}$/', $color)) {
                $color = '';
            }
            $variant = isset($item['variant']) ? strtolower(trim((string) $item['variant'])) : 'light';
            if (!in_array($variant, ['light', 'dark', 'muted'], true)) {
                $variant = 'light';
            }

            $translations = [];
            if (isset($item['translations']) && is_array($item['translations'])) {
                foreach ($item['translations'] as $langCode => $payload) {
                    $langCode = strtolower(trim((string) $langCode));
                    if ($langCode === '') { continue; }
                    $title = isset($payload['title']) ? iN_CleanTranslationInput((string) $payload['title']) : '';
                    $desc  = isset($payload['desc']) ? iN_CleanTranslationInput((string) $payload['desc']) : '';
                    if ($title === '' && $desc === '') { continue; }
                    $translations[$langCode] = [
                        'title' => $title,
                        'desc'  => $desc,
                    ];
                }
            }

            $hasContent = ($icon !== '') || ($color !== '') || !empty($translations);
            if (!$hasContent && $variant === 'light') {
                return null;
            }

            $meta = [
                'icon'  => $icon,
                'color' => $color,
                'variant' => $variant,
            ];
            $metaJson = json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($metaJson === false) { $metaJson = '{}'; }

            $langJson = null;
            if ($translations) {
                $langJson = json_encode($translations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                if ($langJson === false) { $langJson = null; }
            }

            return [
                'type'       => 'manual',
                'post_id'    => null,
                'media_type' => null,
                'media_path' => null,
                'thumb_path' => null,
                'meta'       => $metaJson,
                'lang'       => $langJson,
            ];
        }

        if ($sectionKey === 'no_hassle') {
            $rawType = isset($item['item_type']) ? strtolower(trim((string) $item['item_type'])) : 'feature';
            if (!in_array($rawType, ['feature', 'badge'], true)) {
                $rawType = 'feature';
            }

            $icon = isset($item['icon']) ? trim((string) $item['icon']) : '';
            if ($icon !== '' && mb_strlen($icon) > 200) {
                $icon = mb_substr($icon, 0, 200);
            }

            $color = isset($item['color']) ? trim((string) $item['color']) : '';
            if ($color !== '' && !preg_match('/^#[0-9a-fA-F]{3,8}$/', $color)) {
                $color = '';
            }

            $translations = [];
            if (isset($item['translations']) && is_array($item['translations'])) {
                foreach ($item['translations'] as $langCode => $payload) {
                    $langCode = strtolower(trim((string) $langCode));
                    if ($langCode === '') { continue; }
                    $label = isset($payload['label']) ? iN_CleanTranslationInput((string) $payload['label']) : '';
                    if ($label === '') { continue; }
                    $translations[$langCode] = [
                        'label' => $label,
                    ];
                }
            }

            if (!$translations) {
                return null;
            }

            $meta = [
                'icon' => $icon,
                'data_ma_color' => $color,
            ];
            $metaJson = json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($metaJson === false) { $metaJson = '{}'; }

            $langJson = json_encode($translations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($langJson === false) { $langJson = null; }

            return [
                'type'       => $rawType,
                'post_id'    => null,
                'media_type' => null,
                'media_path' => null,
                'thumb_path' => null,
                'meta'       => $metaJson,
                'lang'       => $langJson,
            ];
        }

        if ($sectionKey === 'faqs') {
            $translations = [];
            if (isset($item['translations']) && is_array($item['translations'])) {
                foreach ($item['translations'] as $langCode => $payload) {
                    $langKey = $this->normalizeLandingLangKey((string) $langCode);
                    if ($langKey === '') { continue; }
                    $questionRaw = isset($payload['q']) ? (string) $payload['q'] : '';
                    $answerRaw = isset($payload['a']) ? (string) $payload['a'] : '';
                    $question = iN_CleanTranslationInput($questionRaw);
                    $answer = iN_CleanTranslationInput($answerRaw);
                    if ($question === '' && $answer === '') { continue; }
                    if ($question !== '' && mb_strlen($question) > 200) {
                        $question = mb_substr($question, 0, 200);
                    }
                    if ($answer !== '' && mb_strlen($answer) > 600) {
                        $answer = mb_substr($answer, 0, 600);
                    }
                    $translations[$langKey] = [
                        'q' => $question,
                        'a' => $answer,
                    ];
                }
            }

            if (!$translations) {
                return null;
            }

            $langJson = json_encode($translations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($langJson === false) {
                $langJson = null;
            }

            return [
                'type'       => 'faq',
                'post_id'    => null,
                'media_type' => null,
                'media_path' => null,
                'thumb_path' => null,
                'meta'       => '{}',
                'lang'       => $langJson,
            ];
        }

        if ($sectionKey === 'footer_links') {
            $href = isset($item['href']) ? trim((string) $item['href']) : '';
            $target = isset($item['target']) ? strtolower(trim((string) $item['target'])) : '_self';
            if (!in_array($target, ['_self', '_blank', '_parent', '_top'], true)) {
                $target = '_self';
            }
            $rel = isset($item['rel']) ? trim((string) $item['rel']) : '';

            if ($href !== '' && mb_strlen($href) > 500) {
                $href = mb_substr($href, 0, 500);
            }
            if ($rel !== '' && mb_strlen($rel) > 200) {
                $rel = mb_substr($rel, 0, 200);
            }

            $translations = [];
            if (isset($item['translations']) && is_array($item['translations'])) {
                foreach ($item['translations'] as $langCode => $payload) {
                    $langKey = $this->normalizeLandingLangKey((string) $langCode);
                    if ($langKey === '') { continue; }
                    $labelRaw = isset($payload['label']) ? (string) $payload['label'] : '';
                    $label = iN_CleanTranslationInput($labelRaw);
                    if ($label === '') {
                        continue;
                    }
                    if ($label !== '' && mb_strlen($label) > 120) {
                        $label = mb_substr($label, 0, 120);
                    }
                    $translations[$langKey] = [
                        'label' => $label,
                    ];
                }
            }

            if ($href === '' && !$translations) {
                return null;
            }

            $meta = [
                'href' => $href,
                'target' => $target,
                'rel' => $rel,
            ];
            $metaJson = json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($metaJson === false) { $metaJson = '{}'; }

            $langJson = null;
            if ($translations) {
                $langJson = json_encode($translations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                if ($langJson === false) { $langJson = null; }
            }

            return [
                'type'       => 'link',
                'post_id'    => null,
                'media_type' => null,
                'media_path' => null,
                'thumb_path' => null,
                'meta'       => $metaJson,
                'lang'       => $langJson,
            ];
        }

        if ($sectionKey === 'get_started') {
            $translations = [];
            if (isset($item['translations']) && is_array($item['translations'])) {
                foreach ($item['translations'] as $langCode => $payload) {
                    $langKey = $this->normalizeLandingLangKey((string) $langCode);
                    if ($langKey === '') { continue; }
                    $titleRaw = isset($payload['title']) ? (string) $payload['title'] : '';
                    $descRaw = isset($payload['desc']) ? (string) $payload['desc'] : '';
                    $buttonRaw = isset($payload['button']) ? (string) $payload['button'] : '';

                    $title = iN_CleanTranslationInput($titleRaw);
                    if ($title !== '' && mb_strlen($title) > 200) {
                        $title = mb_substr($title, 0, 200);
                    }

                    $description = iN_CleanTranslationInput($descRaw);
                    if ($description !== '' && mb_strlen($description) > 600) {
                        $description = mb_substr($description, 0, 600);
                    }

                    $button = iN_CleanTranslationInput($buttonRaw);
                    if ($button !== '' && mb_strlen($button) > 100) {
                        $button = mb_substr($button, 0, 100);
                    }

                    if ($title === '' && $description === '' && $button === '') {
                        continue;
                    }

                    $translations[$langKey] = [
                        'title' => $title,
                        'desc' => $description,
                        'button' => $button,
                    ];
                }
            }

            if (!$translations) {
                return null;
            }

            $langJson = json_encode($translations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($langJson === false) {
                $langJson = null;
            }

            return [
                'type'       => 'manual',
                'post_id'    => null,
                'media_type' => null,
                'media_path' => null,
                'thumb_path' => null,
                'meta'       => '{}',
                'lang'       => $langJson,
            ];
        }

        if ($sectionKey === 'samples') {
            $style = isset($item['style']) ? strtolower(trim((string) $item['style'])) : 'narrow';
            if (!in_array($style, ['narrow', 'wide'], true)) {
                $style = 'narrow';
            }

            $translations = [];
            if (isset($item['translations']) && is_array($item['translations'])) {
                foreach ($item['translations'] as $langCode => $payload) {
                    $langCode = strtolower(trim((string) $langCode));
                    if ($langCode === '') { continue; }
                    $label = isset($payload['label']) ? iN_CleanTranslationInput((string) $payload['label']) : '';
                    if ($label === '') { continue; }
                    $translations[$langCode] = [
                        'label' => $label,
                    ];
                }
            }

            if (!$translations) {
                return null;
            }

            $meta = [
                'style' => $style,
            ];
            $metaJson = json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($metaJson === false) { $metaJson = '{}'; }

            $langJson = json_encode($translations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($langJson === false) { $langJson = null; }

            return [
                'type'       => 'manual',
                'post_id'    => null,
                'media_type' => null,
                'media_path' => null,
                'thumb_path' => null,
                'meta'       => $metaJson,
                'lang'       => $langJson,
            ];
        }

        if ($sectionKey === 'pricing') {
            $badge = isset($item['badge']) ? iN_CleanTranslationInput((string) $item['badge']) : '';
            $highlight  = !empty($item['highlight']);
            $variant    = isset($item['variant']) ? strtolower(trim((string) $item['variant'])) : 'default';
            if (!in_array($variant, ['default', 'highlight', 'muted'], true)) {
                $variant = $highlight ? 'highlight' : 'default';
            }

            $ctaUrl = trim((string) ($item['cta_url'] ?? ''));
            if ($ctaUrl !== '' && !preg_match('#^(https?:)?//#i', $ctaUrl)) {
                $ctaUrl = '';
            }

            $features = [];
            if (isset($item['features']) && is_array($item['features'])) {
                foreach ($item['features'] as $feature) {
                    $clean = iN_CleanTranslationInput((string) $feature);
                    if ($clean !== '') {
                        $features[] = $clean;
                    }
                }
            }

            $translations = [];
            if (isset($item['translations']) && is_array($item['translations'])) {
                foreach ($item['translations'] as $langCode => $payload) {
                    $langCode = strtolower(trim((string) $langCode));
                    if ($langCode === '') { continue; }
                    $title = isset($payload['title']) ? iN_CleanTranslationInput((string) $payload['title']) : '';
                    $tagline = isset($payload['tagline']) ? iN_CleanTranslationInput((string) $payload['tagline']) : '';
                    $description = isset($payload['description']) ? iN_CleanTranslationInput((string) $payload['description']) : '';
                    $ctaLabel = isset($payload['cta_label']) ? iN_CleanTranslationInput((string) $payload['cta_label']) : '';
                    $translations[$langCode] = [
                        'title' => $title,
                        'tagline' => $tagline,
                        'description' => $description,
                        'cta_label' => $ctaLabel,
                    ];
                }
            }

            if ($badge === '' && !$highlight && $ctaUrl === '' && !$features && !$translations) {
                return null;
            }

            $meta = [
                'badge' => $badge !== '' ? $badge : null,
                'highlight' => $highlight,
                'variant' => $variant,
                'cta_url' => $ctaUrl,
                'features' => $features,
            ];
            $metaJson = json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($metaJson === false) { $metaJson = '{}'; }

            $langJson = null;
            if ($translations) {
                $langJson = json_encode($translations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                if ($langJson === false) { $langJson = null; }
            }

            return [
                'type'       => 'manual',
                'post_id'    => null,
                'media_type' => null,
                'media_path' => null,
                'thumb_path' => null,
                'meta'       => $metaJson,
                'lang'       => $langJson,
            ];
        }

        // Default/manual structure (used for legacy image-list manual entries)
        $display  = trim((string) ($item['display'] ?? ''));
        $username = trim((string) ($item['username'] ?? ''));
        $avatar   = trim((string) ($item['avatar'] ?? ''));
        $verified = !empty($item['verified']);
        $postId   = isset($item['post_id']) ? (int) $item['post_id'] : 0;
        $mediaType = isset($item['media_type']) ? (string) $item['media_type'] : null;
        $mediaPath = isset($item['media_path']) ? (string) $item['media_path'] : null;
        $thumbPath = isset($item['thumb_path']) ? (string) $item['thumb_path'] : null;

        if ($display === '' && $username === '' && $avatar === '' && $postId <= 0) {
            return null;
        }

        $meta = [
            'display'  => $display,
            'username' => $username,
            'avatar'   => $avatar,
            'verified' => $verified,
        ];
        $metaJson = json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($metaJson === false) { $metaJson = '{}'; }

        return [
            'type'       => $postId > 0 ? 'post' : 'manual',
            'post_id'    => $postId > 0 ? $postId : null,
            'media_type' => $mediaType,
            'media_path' => $mediaPath,
            'thumb_path' => $thumbPath,
            'meta'       => $metaJson,
            'lang'       => null,
        ];
    }

    public function RL_ListLandingThemes(): array
    {
        $this->ensureLandingTablesPrepared();
        try {
            $stmt = $this->db->query('SELECT theme, is_active, updated_at FROM i_landing_pages ORDER BY theme ASC');
            $rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
            $normalizedRows = array_map(static function ($row) {
                return [
                    'theme' => (string) ($row['theme'] ?? ''),
                    'is_active' => (int) ($row['is_active'] ?? 0),
                    'updated_at' => (int) ($row['updated_at'] ?? 0),
                ];
            }, $rows ?: []);

            $requiredThemes = ['welcome_default' => 1, 'guest_main' => 0];
            foreach ($requiredThemes as $slug => $defaultActive) {
                $exists = false;
                foreach ($normalizedRows as $row) {
                    if ($row['theme'] === $slug) {
                        $exists = true;
                        break;
                    }
                }
                if (!$exists) {
                    $this->RL_SaveLandingConfig($slug, $this->defaultLandingConfig($slug), $defaultActive);
                    $normalizedRows[] = [
                        'theme' => $slug,
                        'is_active' => $defaultActive,
                        'updated_at' => time(),
                    ];
                }
            }

            $currentActive = 'welcome_default';
            try {
                $currentActive = $this->RL_GetActiveLandingTheme();
            } catch (Throwable $e) {
                if (method_exists($this, 'logError')) {
                    $this->logError('RL_ListLandingThemes active detect failed: ' . $e->getMessage());
                }
            }
            $currentActive = $this->normalizeLandingTheme($currentActive);

            $foundActive = false;
            foreach ($normalizedRows as &$rowRef) {
                if ($this->normalizeLandingTheme($rowRef['theme']) === $currentActive) {
                    $rowRef['is_active'] = 1;
                    $foundActive = true;
                } else {
                    $rowRef['is_active'] = 0;
                }
            }
            unset($rowRef);

            if (!$foundActive) {
                $this->RL_SetActiveLandingTheme($currentActive);
                foreach ($normalizedRows as &$rowRef) {
                    $rowRef['is_active'] = $this->normalizeLandingTheme($rowRef['theme']) === $currentActive ? 1 : 0;
                }
                unset($rowRef);
            }

            return $normalizedRows;
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_ListLandingThemes failed: ' . $e->getMessage());
            }
            return [
                [
                    'theme' => 'welcome_default',
                    'is_active' => 1,
                    'updated_at' => time(),
                ],
            ];
        }
    }

    public function RL_GetLandingSectionConfig(string $theme, string $sectionKey, bool $autoCreate = true): array
    {
        $this->ensureLandingTablesPrepared();
        $theme = $this->normalizeLandingTheme($theme);
        $sectionKey = strtolower(trim($sectionKey));
        $default = $this->defaultLandingSectionConfig($sectionKey);

        try {
            $stmt = $this->db->prepare('SELECT id, cfg_json FROM i_landing_sections WHERE theme = :theme AND section_key = :section LIMIT 1');
            $stmt->bindValue(':theme', $theme, PDO::PARAM_STR);
            $stmt->bindValue(':section', $sectionKey, PDO::PARAM_STR);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row && !empty($row['cfg_json'])) {
                $decoded = json_decode((string) $row['cfg_json'], true);
                if (is_array($decoded)) {
                    $default = array_replace_recursive($default, $decoded);
                }
                $default = $this->normalizeSectionConfig($sectionKey, $default);
                return $default;
            }

            if ($autoCreate) {
                $this->RL_SaveLandingSectionConfig($theme, $sectionKey, $default);
            }
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetLandingSectionConfig failed: ' . $e->getMessage());
            }
        }

        $default = $this->normalizeSectionConfig($sectionKey, $default);
        return $default;
    }

    public function RL_SaveLandingSectionConfig(string $theme, string $sectionKey, array $cfg): bool
    {
        $this->ensureLandingTablesPrepared();
        $theme = $this->normalizeLandingTheme($theme);
        $sectionKey = strtolower(trim($sectionKey));
        $now = time();

        try {
            $json = json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($json === false) {
                return false;
            }

            $sql = 'INSERT INTO i_landing_sections (theme, section_key, cfg_json, sort_order, updated_at)
                    VALUES (:theme, :section, :cfg, 0, :now)
                    ON DUPLICATE KEY UPDATE cfg_json = VALUES(cfg_json), updated_at = VALUES(updated_at)';
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':theme', $theme, PDO::PARAM_STR);
            $stmt->bindValue(':section', $sectionKey, PDO::PARAM_STR);
            $stmt->bindValue(':cfg', $json, PDO::PARAM_STR);
            $stmt->bindValue(':now', $now, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_SaveLandingSectionConfig failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    private function fetchLandingSectionId(string $theme, string $sectionKey, bool $create = true): int
    {
        $this->ensureLandingTablesPrepared();
        $theme = $this->normalizeLandingTheme($theme);
        $sectionKey = strtolower(trim($sectionKey));

        try {
            $stmt = $this->db->prepare('SELECT id FROM i_landing_sections WHERE theme = :theme AND section_key = :section LIMIT 1');
            $stmt->bindValue(':theme', $theme, PDO::PARAM_STR);
            $stmt->bindValue(':section', $sectionKey, PDO::PARAM_STR);
            $stmt->execute();
            $id = (int) $stmt->fetchColumn();
            if ($id > 0) {
                return $id;
            }

            if (!$create) {
                return 0;
            }

            $defaultCfg = $this->defaultLandingSectionConfig($sectionKey);
            $this->RL_SaveLandingSectionConfig($theme, $sectionKey, $defaultCfg);

            $stmt->execute();
            return (int) $stmt->fetchColumn();
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('fetchLandingSectionId failed: ' . $e->getMessage());
            }
            return 0;
        }
    }

    public function RL_GetLandingSectionItems(string $theme, string $sectionKey, int $limit = 20): array
    {
        $this->ensureLandingTablesPrepared();
        $theme = $this->normalizeLandingTheme($theme);
        $sectionKey = strtolower(trim($sectionKey));
        $limit = max(1, min(60, $limit));

        try {
            $stmt = $this->db->prepare('SELECT id FROM i_landing_sections WHERE theme = :theme AND section_key = :section LIMIT 1');
            $stmt->bindValue(':theme', $theme, PDO::PARAM_STR);
            $stmt->bindValue(':section', $sectionKey, PDO::PARAM_STR);
            $stmt->execute();
            $section = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$section) {
                return [];
            }
            $sectionId = (int) ($section['id'] ?? 0);
            if ($sectionId <= 0) {
                return [];
            }

            $sql = 'SELECT id, item_type, post_id, media_type, media_path, thumb_path, meta_json, lang_json
                    FROM i_landing_items
                    WHERE section_id = :sid
                    ORDER BY sort_order ASC, id ASC
                    LIMIT :lim';
            $stmtItems = $this->db->prepare($sql);
            $stmtItems->bindValue(':sid', $sectionId, PDO::PARAM_INT);
            $stmtItems->bindValue(':lim', $limit, PDO::PARAM_INT);
            $stmtItems->execute();
            $rows = $stmtItems->fetchAll(PDO::FETCH_ASSOC) ?: [];
            foreach ($rows as &$row) {
                if (!empty($row['meta_json'])) {
                    $meta = json_decode((string) $row['meta_json'], true);
                    if (!is_array($meta)) { $meta = []; }
                    $row['meta'] = $meta;
                } else {
                    $row['meta'] = [];
                }
                if (!empty($row['lang_json'])) {
                    $langData = json_decode((string) $row['lang_json'], true);
                    if (!is_array($langData)) { $langData = []; }
                    $row['lang'] = $langData;
                } else {
                    $row['lang'] = [];
                }
            }
            unset($row);
            return $rows;
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetLandingSectionItems failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    public function RL_SaveLandingSectionItems(string $theme, string $sectionKey, array $items): bool
    {
        $this->ensureLandingTablesPrepared();
        $theme = $this->normalizeLandingTheme($theme);
        $sectionKey = strtolower(trim($sectionKey));
        $sectionId = $this->fetchLandingSectionId($theme, $sectionKey, true);
        if ($sectionId <= 0) {
            return false;
        }

        try {
            $this->db->beginTransaction();

            $existingStmt = $this->db->prepare('SELECT id FROM i_landing_items WHERE section_id = :sid');
            $existingStmt->execute([':sid' => $sectionId]);
            $existingIds = array_map('intval', $existingStmt->fetchAll(PDO::FETCH_COLUMN) ?: []);

            $updateStmt = $this->db->prepare('UPDATE i_landing_items
                SET item_type = :type, post_id = :post, media_type = :media, media_path = :media_path,
                    thumb_path = :thumb, meta_json = :meta, lang_json = :lang, sort_order = :sort, updated_at = :now
                WHERE id = :id AND section_id = :sid');

            $insertStmt = $this->db->prepare('INSERT INTO i_landing_items
                (section_id, item_type, post_id, media_type, media_path, thumb_path, meta_json, lang_json, sort_order, created_at, updated_at)
                VALUES (:sid, :type, :post, :media, :media_path, :thumb, :meta, :lang, :sort, :created, :updated)');

            $now = time();
            $keepIds = [];
            $sortOrder = 0;

            foreach ($items as $item) {
                $normalized = $this->normalizeSectionItem($sectionKey, $item);
                if ($normalized === null) {
                    continue;
                }

                $itemType  = $normalized['type'];
                $postId    = $normalized['post_id'];
                $mediaType = $normalized['media_type'];
                $mediaPath = $normalized['media_path'];
                $thumbPath = $normalized['thumb_path'];
                $metaJson  = $normalized['meta'];
                $langJson  = $normalized['lang'];

                $itemId = isset($item['id']) ? (int) $item['id'] : 0;
                $sortOrder++;

                if ($itemId > 0 && in_array($itemId, $existingIds, true)) {
                    $params = [
                        ':type' => [$itemType, PDO::PARAM_STR],
                        ':post' => [$postId, $postId !== null ? PDO::PARAM_INT : PDO::PARAM_NULL],
                        ':media' => [$mediaType, $mediaType !== null ? PDO::PARAM_STR : PDO::PARAM_NULL],
                        ':media_path' => [$mediaPath, $mediaPath !== null ? PDO::PARAM_STR : PDO::PARAM_NULL],
                        ':thumb' => [$thumbPath, $thumbPath !== null ? PDO::PARAM_STR : PDO::PARAM_NULL],
                        ':meta' => [$metaJson, PDO::PARAM_STR],
                        ':lang' => [$langJson, $langJson !== null ? PDO::PARAM_STR : PDO::PARAM_NULL],
                        ':sort' => [$sortOrder, PDO::PARAM_INT],
                        ':now' => [$now, PDO::PARAM_INT],
                        ':id' => [$itemId, PDO::PARAM_INT],
                        ':sid' => [$sectionId, PDO::PARAM_INT],
                    ];
                    foreach ($params as $name => $info) {
                        [$value, $type] = $info;
                        if ($type === PDO::PARAM_NULL) {
                            $updateStmt->bindValue($name, null, PDO::PARAM_NULL);
                        } else {
                            $updateStmt->bindValue($name, $value, $type);
                        }
                    }
                    $updateStmt->execute();
                    $updateStmt->closeCursor();
                } else {
                    $params = [
                        ':sid' => [$sectionId, PDO::PARAM_INT],
                        ':type' => [$itemType, PDO::PARAM_STR],
                        ':post' => [$postId, $postId !== null ? PDO::PARAM_INT : PDO::PARAM_NULL],
                        ':media' => [$mediaType, $mediaType !== null ? PDO::PARAM_STR : PDO::PARAM_NULL],
                        ':media_path' => [$mediaPath, $mediaPath !== null ? PDO::PARAM_STR : PDO::PARAM_NULL],
                        ':thumb' => [$thumbPath, $thumbPath !== null ? PDO::PARAM_STR : PDO::PARAM_NULL],
                        ':meta' => [$metaJson, PDO::PARAM_STR],
                        ':lang' => [$langJson, $langJson !== null ? PDO::PARAM_STR : PDO::PARAM_NULL],
                        ':sort' => [$sortOrder, PDO::PARAM_INT],
                        ':created' => [$now, PDO::PARAM_INT],
                        ':updated' => [$now, PDO::PARAM_INT],
                    ];
                    foreach ($params as $name => $info) {
                        [$value, $type] = $info;
                        if ($type === PDO::PARAM_NULL) {
                            $insertStmt->bindValue($name, null, PDO::PARAM_NULL);
                        } else {
                            $insertStmt->bindValue($name, $value, $type);
                        }
                    }
                    $insertStmt->execute();
                    $insertStmt->closeCursor();
                    $itemId = (int) $this->db->lastInsertId();
                }

                if ($itemId > 0) {
                    $keepIds[] = $itemId;
                }
            }

            if ($existingIds) {
                $idsToDelete = array_diff($existingIds, $keepIds);
                if ($idsToDelete) {
                    $placeholders = implode(',', array_fill(0, count($idsToDelete), '?'));
                    $deleteStmt = $this->db->prepare("DELETE FROM i_landing_items WHERE section_id = ? AND id IN ($placeholders)");
                    $deleteStmt->bindValue(1, $sectionId, PDO::PARAM_INT);
                    $idx = 2;
                    foreach ($idsToDelete as $delId) {
                        $deleteStmt->bindValue($idx++, (int) $delId, PDO::PARAM_INT);
                    }
                    $deleteStmt->execute();
                }
            }

            $this->db->commit();
            return true;
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            if (method_exists($this, 'logError')) {
                $this->logError('RL_SaveLandingSectionItems failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    public function RL_GetLandingImageList(string $theme, array $config, int $limit = 8): array
    {
        $items = $this->RL_GetLandingSectionItems($theme, 'image_list', $limit);
        $result = [];

        if ($items) {
            $postIds = [];
            foreach ($items as $row) {
                if (($row['item_type'] ?? '') === 'post' && !empty($row['post_id'])) {
                    $postIds[] = (int) $row['post_id'];
                }
            }
            $posts = [];
            if ($postIds) {
                $placeholders = implode(',', array_fill(0, count($postIds), '?'));
                $sql = "SELECT p.post_id, p.post_type, p.post_file, p.post_views, p.post_created_time,
                               u.username, u.user_fullname, u.verified_status,
                               COALESCE(l.likes_count, 0) AS likes_count
                        FROM i_user_posts AS p
                        INNER JOIN i_users AS u ON u.user_id = p.post_owner_id
                        LEFT JOIN (
                            SELECT liked_item_id AS post_id, COUNT(*) AS likes_count
                            FROM i_post_liked
                            WHERE liked_item_type = 'post'
                            GROUP BY liked_item_id
                        ) AS l ON l.post_id = p.post_id
                        WHERE p.post_id IN ($placeholders) AND (p.approval_status IS NULL OR p.approval_status = 'approved')";
                $stmt = $this->db->prepare($sql);
                foreach ($postIds as $i => $pid) {
                    $stmt->bindValue($i + 1, $pid, PDO::PARAM_INT);
                }
                $stmt->execute();
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
                foreach ($rows as $row) {
                    $entry = $this->buildWelcomeHeroEntry($row);
                    if ($entry !== null) {
                        $posts[$entry['post_id']] = $entry;
                    }
                }
            }

            foreach ($items as $row) {
                if (($row['item_type'] ?? '') === 'post') {
                    $pid = (int) ($row['post_id'] ?? 0);
                    if ($pid > 0 && isset($posts[$pid])) {
                        $result[] = $posts[$pid];
                    }
                } else {
                    $manual = $this->normalizeManualLandingItem($row);
                    if ($manual !== null) {
                        $result[] = $manual;
                    }
                }
                if (count($result) >= $limit) {
                    break;
                }
            }
        }

        if (count($result) < $limit) {
            $fallback = $this->RL_GetWelcomeHeroPosts($limit, ['media_mode' => $config['media_mode'] ?? 'mixed']);
            $result = array_slice(array_merge($result, $fallback), 0, $limit);
        }

        return $result;
    }

    public function RL_GetLandingMarquee(string $theme, array $config, int $limitPerList = 10): array
    {
        $theme = $this->normalizeLandingTheme($theme);
        $config = $this->normalizeSectionConfig('marquee', $config);

        $listCount = max(1, min((int) ($config['list_count'] ?? 4), 10));
        $showAvatar = !empty($config['show_avatar']);
        $nameMode = $config['name_mode'] ?? 'full';
        if (!in_array($nameMode, ['full', 'username'], true)) {
            $nameMode = 'full';
        }

        $limitPerList = max(1, (int) $limitPerList);
        $maxItems = $listCount * $limitPerList;
        $items = $this->RL_GetLandingSectionItems($theme, 'marquee', $maxItems);
        $lists = [];
        for ($i = 0; $i < $listCount; $i++) { $lists[$i] = []; }

        $index = 0;
        foreach ($items as $row) {
            $meta = isset($row['meta']) && is_array($row['meta']) ? $row['meta'] : [];
            $display = trim((string) ($meta['display'] ?? ''));
            $username = trim((string) ($meta['username'] ?? ''));
            $avatar = trim((string) ($meta['avatar'] ?? ''));
            $verified = !empty($meta['verified']);

            if ($display === '' && $username === '' && $avatar === '') {
                continue;
            }

            $label = $display;
            if ($nameMode === 'username') {
                $label = $username !== '' ? '@' . ltrim($username, '@') : ($display !== '' ? $display : 'Creator');
            } else {
                if ($label === '') {
                    $label = $username !== '' ? '@' . ltrim($username, '@') : 'Creator';
                }
            }

            $avatarUrl = $avatar !== '' ? $this->normalizeWelcomeMediaPath($avatar) : '';

            $lists[$index % $listCount][] = [
                'label' => $label,
                'username' => $username,
                'display' => $display,
                'avatar_url' => $avatarUrl,
                'verified' => $verified,
            ];

            $index++;
        }

        $fallbackLists = $this->buildFallbackMarqueeLists($listCount, $nameMode, $showAvatar);

        $hasItems = false;
        foreach ($lists as $list) {
            if (!empty($list)) { $hasItems = true; break; }
        }

        if (!$hasItems) {
            $userLists = $this->buildUserMarqueeLists($listCount, $nameMode, $showAvatar, $limitPerList);
            if (!empty($userLists)) {
                $lists = $userLists;
                $hasItems = true;
            }
        }

        if (!$hasItems) {
            $lists = $fallbackLists;
        } else {
            foreach ($lists as $idx => $list) {
                if (empty($list)) {
                    $lists[$idx] = $fallbackLists[$idx] ?? [];
                }
            }
        }

        return [
            'lists' => $lists,
            'show_avatar' => $showAvatar,
            'name_mode' => $nameMode,
        ];
    }

    private function buildUserMarqueeLists(int $listCount, string $nameMode, bool $showAvatar, int $limitPerList): array
    {
        $totalNeeded = $listCount * $limitPerList;
        $users = $this->fetchLandingMarqueeUsers($totalNeeded);
        if (empty($users)) {
            return [];
        }

        $lists = [];
        for ($i = 0; $i < $listCount; $i++) { $lists[$i] = []; }

        $userIndex = 0;
        foreach ($users as $user) {
            $listIndex = intdiv($userIndex, $limitPerList);
            if ($listIndex >= $listCount) {
                break;
            }

            $username = trim((string)($user['username'] ?? ''));
            $fullname = trim((string)($user['fullname'] ?? ''));
            $label = $nameMode === 'username'
                ? ($username !== '' ? '@' . ltrim($username, '@') : ($fullname !== '' ? $fullname : 'Creator'))
                : ($fullname !== '' ? $fullname : ($username !== '' ? '@' . ltrim($username, '@') : 'Creator'));

            $avatarUrl = '';
            if ($showAvatar) {
                $avatarCandidate = (string)($user['avatar'] ?? '');
                if ($avatarCandidate === '' && method_exists($this, 'RL_userAvatar')) {
                    $avatarCandidate = (string) $this->RL_userAvatar((int)($user['user_id'] ?? 0));
                }
                if ($avatarCandidate !== '') {
                    $avatarUrl = $this->normalizeWelcomeMediaPath($avatarCandidate);
                }
            }

            $lists[$listIndex][] = [
                'label'      => $label,
                'username'   => $username,
                'display'    => $fullname,
                'avatar_url' => $avatarUrl,
                'verified'   => !empty($user['verified'])
            ];

            $userIndex++;
        }

        return $lists;
    }

    private function fetchLandingMarqueeUsers(int $limit): array
    {
        try {
            $sql = 'SELECT user_id, username, user_fullname, user_avatar, verified_status
                    FROM i_users
                    WHERE user_type IN (1,2)
                    ORDER BY user_id DESC
                    LIMIT :lim';
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
            $out = [];
            foreach ($rows as $row) {
                $out[] = [
                    'user_id'  => (int)($row['user_id'] ?? 0),
                    'username' => (string)($row['username'] ?? ''),
                    'fullname' => (string)($row['user_fullname'] ?? ''),
                    'avatar'   => (string)($row['user_avatar'] ?? ''),
                    'verified' => (int)($row['verified_status'] ?? 0) === 1,
                ];
            }
            return $out;
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('fetchLandingMarqueeUsers failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    private function buildFallbackMarqueeLists(int $listCount, string $nameMode, bool $showAvatar): array
    {
        $fallbackNames = [
            ['Emily Johnson', 'Jason Miller', 'Sophia Carter', 'Liam Brooks', 'Olivia Reed'],
            ['Noah Bennett', 'Ava Mitchell', 'Ethan Collins', 'Mia Harper', 'Lucas Grant'],
            ['Isabella Hayes', 'Mason Turner', 'Charlotte Price', 'Elijah Cooper', 'Amelia Scott'],
            ['Harper Lewis', 'James Walker', 'Evelyn Ramirez', 'Benjamin Foster', 'Abigail Parker'],
        ];

        $thumbs = [];
        if (function_exists('themeThumbs')) {
            $thumbs = (array) themeThumbs();
        }
        if (count($thumbs) > 1) {
            shuffle($thumbs);
        }
        $thumbCount = count($thumbs);

        $lists = [];
        for ($i = 0; $i < $listCount; $i++) {
            $names = $fallbackNames[$i % count($fallbackNames)];
            $list = [];
            foreach ($names as $idx => $name) {
                $username = strtolower(str_replace(' ', '', $name));
                $label = $nameMode === 'username' ? '@' . $username : $name;
                $avatar = '';
                if ($showAvatar && $thumbCount > 0) {
                    $avatar = $thumbs[($i * count($names) + $idx) % $thumbCount] ?? '';
                }
                $list[] = [
                    'label' => $label,
                    'username' => $username,
                    'display' => $name,
                    'avatar_url' => $avatar,
                    'verified' => false,
                ];
            }
            $lists[] = $list;
        }

        return $lists;
    }

    public function RL_GetLandingFeatures(string $theme, string $lang, array $fallbackLangs = []): array
    {
        $theme = $this->normalizeLandingTheme($theme);
        $config = $this->RL_GetLandingSectionConfig($theme, 'features');
        $items  = $this->RL_GetLandingSectionItems($theme, 'features', 50);
        $features = [];

        $fallbackSequence = array_values(array_unique(array_merge([$lang], $fallbackLangs)));

        foreach ($items as $item) {
            $meta = is_array($item['meta'] ?? null) ? $item['meta'] : [];
            $icon  = trim((string) ($meta['icon'] ?? ''));
            $color = trim((string) ($meta['color'] ?? ''));
            if ($color !== '' && !preg_match('/^#[0-9a-fA-F]{3,8}$/', $color)) {
                $color = '';
            }
            $variant = isset($meta['variant']) ? strtolower((string) $meta['variant']) : 'light';
            if (!in_array($variant, ['light', 'dark', 'muted'], true)) {
                $variant = 'light';
            }

            $langPack = is_array($item['lang'] ?? null) ? $item['lang'] : [];
            $title = '';
            $desc  = '';
            foreach ($fallbackSequence as $candidate) {
                if (!isset($langPack[$candidate])) { continue; }
                $pack = $langPack[$candidate];
                $candTitle = trim((string) ($pack['title'] ?? ''));
                $candDesc  = trim((string) ($pack['desc'] ?? ''));
                if ($candTitle === '' && $candDesc === '') { continue; }
                if ($title === '') { $title = $candTitle; }
                if ($desc === '') { $desc = $candDesc; }
                if ($title !== '' && $desc !== '') { break; }
            }

            $features[] = [
                'icon'  => $icon,
                'color' => $color,
                'variant' => $variant,
                'title' => $title,
                'description' => $desc,
            ];
        }

        return [
            'config' => $config,
            'items'  => $features,
        ];
    }

    public function RL_GetLandingNoHassle(string $theme, string $lang, array $fallbackLangs = []): array
    {
        $theme = $this->normalizeLandingTheme($theme);
        $config = $this->RL_GetLandingSectionConfig($theme, 'no_hassle');
        $config = $this->normalizeSectionConfig('no_hassle', $config);
        $items  = $this->RL_GetLandingSectionItems($theme, 'no_hassle', 40);

        $fallbackSequence = array_values(array_unique(array_merge([$lang], $fallbackLangs)));

        $entries = [];
        foreach ($items as $item) {
            $rawType = isset($item['item_type']) ? strtolower((string) $item['item_type']) : 'feature';
            if (!in_array($rawType, ['feature', 'badge'], true)) {
                $rawType = 'feature';
            }

            $meta = is_array($item['meta'] ?? null) ? $item['meta'] : [];
            $icon = trim((string) ($meta['icon'] ?? ''));
            if ($icon !== '' && mb_strlen($icon) > 200) {
                $icon = mb_substr($icon, 0, 200);
            }
            $color = trim((string) ($meta['data_ma_color'] ?? ''));
            if ($color !== '' && !preg_match('/^#[0-9a-fA-F]{3,8}$/', $color)) {
                $color = '';
            }

            $langPack = is_array($item['lang'] ?? null) ? $item['lang'] : [];
            $label = '';
            foreach ($fallbackSequence as $candidate) {
                if (!isset($langPack[$candidate])) { continue; }
                $pack = $langPack[$candidate];
                $candidateLabel = trim((string) ($pack['label'] ?? ''));
                if ($candidateLabel === '') { continue; }
                $label = $candidateLabel;
                break;
            }

            if ($label === '') {
                continue;
            }

            $entries[] = [
                'type'  => $rawType,
                'icon'  => $icon,
                'color' => $color,
                'label' => $label,
            ];
        }

        return [
            'config' => $config,
            'items'  => $entries,
        ];
    }

    public function RL_GetLandingFooterLinks(string $theme, string $lang, array $fallbackLangs = []): array
    {
        $theme = $this->normalizeLandingTheme($theme);
        $config = $this->RL_GetLandingSectionConfig($theme, 'footer_links');
        $config = $this->normalizeSectionConfig('footer_links', $config);

        $items = $this->RL_GetLandingSectionItems($theme, 'footer_links', 20);

        $sequence = [];
        $primary = $this->normalizeLandingLangKey($lang);
        if ($primary !== '') {
            $sequence[] = $primary;
        }
        foreach ($fallbackLangs as $candidate) {
            $norm = $this->normalizeLandingLangKey((string) $candidate);
            if ($norm === '') { continue; }
            if (!in_array($norm, $sequence, true)) {
                $sequence[] = $norm;
            }
        }
        if (!$sequence) {
            $sequence = [$this->normalizeLandingLangKey('eng'), $this->normalizeLandingLangKey('tr')];
            $sequence = array_values(array_filter(array_unique($sequence)));
            if (!$sequence) {
                $sequence = ['en'];
            }
        }

        $links = [];
        foreach ($items as $item) {
            $meta = isset($item['meta']) && is_array($item['meta']) ? $item['meta'] : [];
            $href = trim((string) ($meta['href'] ?? ''));
            $target = strtolower((string) ($meta['target'] ?? '_self'));
            if (!in_array($target, ['_self', '_blank', '_parent', '_top'], true)) {
                $target = '_self';
            }
            $rel = trim((string) ($meta['rel'] ?? ''));

            $label = '';
            $langPool = isset($item['lang']) && is_array($item['lang']) ? $item['lang'] : [];
            foreach ($sequence as $code) {
                if (!isset($langPool[$code]) || !is_array($langPool[$code])) { continue; }
                $candidate = trim((string) ($langPool[$code]['label'] ?? ''));
                if ($candidate !== '') {
                    $label = $candidate;
                    break;
                }
            }

            if ($href === '' || $label === '') {
                continue;
            }

            $links[] = [
                'href' => $href,
                'target' => $target,
                'rel' => $rel,
                'label' => $label,
            ];
        }

        return [
            'config' => $config,
            'links' => $links,
        ];
    }

    public function RL_GetLandingGetStarted(string $theme, string $lang, array $fallbackLangs = []): array
    {
        $theme = $this->normalizeLandingTheme($theme);
        $config = $this->RL_GetLandingSectionConfig($theme, 'get_started');
        $config = $this->normalizeSectionConfig('get_started', $config);

        $items = $this->RL_GetLandingSectionItems($theme, 'get_started', 1);

        $sequence = [];
        $primary = $this->normalizeLandingLangKey($lang);
        if ($primary !== '') {
            $sequence[] = $primary;
        }
        foreach ($fallbackLangs as $candidate) {
            $norm = $this->normalizeLandingLangKey((string) $candidate);
            if ($norm === '') { continue; }
            if (!in_array($norm, $sequence, true)) {
                $sequence[] = $norm;
            }
        }
        if (!$sequence) {
            $sequence = [$this->normalizeLandingLangKey('eng'), $this->normalizeLandingLangKey('tr')];
            $sequence = array_values(array_filter(array_unique($sequence)));
            if (!$sequence) {
                $sequence = ['en'];
            }
        }

        $content = [
            'title' => '',
            'description' => '',
            'button' => '',
        ];

        $itemId = 0;
        if ($items) {
            $first = $items[0];
            $itemId = (int) ($first['id'] ?? 0);
            $langPool = is_array($first['lang'] ?? null) ? $first['lang'] : [];
            foreach ($sequence as $code) {
                if (!isset($langPool[$code]) || !is_array($langPool[$code])) {
                    continue;
                }
                $payload = $langPool[$code];
                if ($content['title'] === '' && isset($payload['title'])) {
                    $content['title'] = (string) $payload['title'];
                }
                if ($content['description'] === '' && isset($payload['desc'])) {
                    $content['description'] = (string) $payload['desc'];
                }
                if ($content['button'] === '' && isset($payload['button'])) {
                    $content['button'] = (string) $payload['button'];
                }
                if ($content['title'] !== '' && $content['description'] !== '' && $content['button'] !== '') {
                    break;
                }
            }
        }

        return [
            'config' => $config,
            'content' => $content,
            'item_id' => $itemId,
        ];
    }

    public function RL_GetLandingFaqs(string $theme, string $lang, array $fallbackLangs = []): array
    {
        $theme = $this->normalizeLandingTheme($theme);
        $primary = $this->normalizeLandingLangKey($lang);
        $sequence = [];
        if ($primary !== '') {
            $sequence[] = $primary;
        }
        foreach ($fallbackLangs as $candidate) {
            $norm = $this->normalizeLandingLangKey((string) $candidate);
            if ($norm === '') { continue; }
            if (!in_array($norm, $sequence, true)) {
                $sequence[] = $norm;
            }
        }
        if (!$sequence) {
            $sequence = [$this->normalizeLandingLangKey('eng'), $this->normalizeLandingLangKey('tr')];
            $sequence = array_values(array_filter(array_unique($sequence)));
            if (!$sequence) {
                $sequence = ['en'];
            }
        }

        $items = $this->RL_GetLandingSectionItems($theme, 'faqs', 80);
        $faqs = [];
        foreach ($items as $item) {
            $langPool = is_array($item['lang'] ?? null) ? $item['lang'] : [];
            $question = '';
            $answer = '';
            foreach ($sequence as $code) {
                if (!isset($langPool[$code]) || !is_array($langPool[$code])) {
                    continue;
                }
                $payload = $langPool[$code];
                if ($question === '' && isset($payload['q'])) {
                    $question = (string) $payload['q'];
                }
                if ($answer === '' && isset($payload['a'])) {
                    $answer = (string) $payload['a'];
                }
                if ($question !== '' && $answer !== '') {
                    break;
                }
            }

            if ($question === '' && $answer === '') {
                continue;
            }

            $faqs[] = [
                'id' => (int) ($item['id'] ?? 0),
                'question' => $question,
                'answer' => $answer,
                'translations' => $langPool,
            ];
        }

        return $faqs;
    }

    public function RL_GetLandingSamples(string $theme, string $lang, array $fallbackLangs = []): array
    {
        $theme = $this->normalizeLandingTheme($theme);
        $config = $this->RL_GetLandingSectionConfig($theme, 'samples');
        $items  = $this->RL_GetLandingSectionItems($theme, 'samples', 100);

        $fallbackSequence = array_values(array_unique(array_merge([$lang], $fallbackLangs)));

        $samples = [];
        foreach ($items as $item) {
            $meta = is_array($item['meta'] ?? null) ? $item['meta'] : [];
            $style = isset($meta['style']) ? strtolower((string) $meta['style']) : 'narrow';
            if (!in_array($style, ['narrow', 'wide'], true)) {
                $style = 'narrow';
            }

            $langPack = is_array($item['lang'] ?? null) ? $item['lang'] : [];
            $label = '';
            foreach ($fallbackSequence as $candidate) {
                if (!isset($langPack[$candidate])) { continue; }
                $pack = $langPack[$candidate];
                $candidateLabel = trim((string) ($pack['label'] ?? ''));
                if ($candidateLabel !== '') {
                    $label = $candidateLabel;
                    break;
                }
            }

            $samples[] = [
                'style' => $style,
                'label' => $label,
            ];
        }

        return [
            'config' => $config,
            'items'  => $samples,
        ];
    }

    public function RL_GetLandingPricing(string $theme, string $lang, array $fallbackLangs = []): array
    {
        $theme = $this->normalizeLandingTheme($theme);
        $config = $this->RL_GetLandingSectionConfig($theme, 'pricing');
        $config = $this->normalizeSectionConfig('pricing', $config);
        $items  = $this->RL_GetLandingSectionItems($theme, 'pricing', 50);

        $fallbackSequence = array_values(array_unique(array_merge([$lang], $fallbackLangs)));

        $plans = [];
        foreach ($items as $item) {
            $meta = is_array($item['meta'] ?? null) ? $item['meta'] : [];
            $badge     = isset($meta['badge']) ? trim((string) $meta['badge']) : '';
            $highlight  = !empty($meta['highlight']);
            $variant    = isset($meta['variant']) ? strtolower((string) $meta['variant']) : ($highlight ? 'highlight' : 'default');
            if (!in_array($variant, ['default', 'highlight', 'muted'], true)) {
                $variant = $highlight ? 'highlight' : 'default';
            }
            $ctaUrl = isset($meta['cta_url']) ? trim((string) $meta['cta_url']) : '';
            $features = [];
            if (isset($meta['features']) && is_array($meta['features'])) {
                foreach ($meta['features'] as $featureLine) {
                    $line = trim((string) $featureLine);
                    if ($line !== '') {
                        $features[] = $line;
                    }
                }
            }

            $langPack = is_array($item['lang'] ?? null) ? $item['lang'] : [];
            $title = '';
            $tagline = '';
            $description = '';
            $ctaLabel = '';
            foreach ($fallbackSequence as $candidate) {
                if (!isset($langPack[$candidate]) || !is_array($langPack[$candidate])) {
                    continue;
                }
                $pack = $langPack[$candidate];
                if ($title === '' && isset($pack['title'])) {
                    $title = trim((string) $pack['title']);
                }
                if ($tagline === '' && isset($pack['tagline'])) {
                    $tagline = trim((string) $pack['tagline']);
                }
                if ($description === '' && isset($pack['description'])) {
                    $description = trim((string) $pack['description']);
                }
                if ($ctaLabel === '' && isset($pack['cta_label'])) {
                    $ctaLabel = trim((string) $pack['cta_label']);
                }
                if ($title !== '' && $description !== '' && $ctaLabel !== '' && $tagline !== '') {
                    break;
                }
            }

            $plans[] = [
                'badge'       => $badge,
                'highlight'   => $highlight,
                'variant'     => $variant,
                'cta_url'     => $ctaUrl,
                'features'    => $features,
                'title'       => $title,
                'tagline'     => $tagline,
                'description' => $description,
                'cta_label'   => $ctaLabel,
            ];
        }

        return [
            'config' => $config,
            'items'  => $plans,
        ];
    }

    private function normalizeManualLandingItem(array $row): ?array
    {
        $mediaUrl = (string) ($row['media_path'] ?? '');
        if ($mediaUrl === '') {
            return null;
        }

        $type = (string) ($row['media_type'] ?? 'image');
        if ($type !== 'image' && $type !== 'video') {
            $type = 'image';
        }

        $thumb = (string) ($row['thumb_path'] ?? '');
        if ($type === 'video') {
            $thumb = $thumb ?: $this->videoPathToThumbnail($mediaUrl);
        }
        $imageUrl = $this->normalizeWelcomeMediaPath($type === 'video' ? $thumb : $mediaUrl);
        if ($imageUrl === '') {
            return null;
        }

        $meta = isset($row['meta']) && is_array($row['meta']) ? $row['meta'] : [];
        $username = (string) ($meta['username'] ?? '');
        $display = (string) ($meta['display'] ?? $username);
        if ($display === '' && $username === '') {
            $display = 'creator';
        }

        return [
            'post_id'        => (int) ($row['post_id'] ?? 0),
            'type'           => $type,
            'image_url'      => $imageUrl,
            'views'          => (int) ($meta['views'] ?? 0),
            'likes'          => (int) ($meta['likes'] ?? 0),
            'owner_username' => $username,
            'owner_display'  => $display,
            'owner_verified' => (bool) ($meta['verified'] ?? false),
        ];
    }

    public function RL_GetLangOverrides(array $keys, array $languages): array
    {
        $results = [];
        if (!$keys || !$languages) {
            return $results;
        }
        try {
            foreach ($languages as $lang) {
                $lang = trim((string) $lang);
                if ($lang === '') {
                    continue;
                }
                $placeholders = implode(',', array_fill(0, count($keys), '?'));
                $sql = 'SELECT lang_key, value FROM i_lang_overrides WHERE language = ? AND lang_key IN (' . $placeholders . ')';
                $stmt = $this->db->prepare($sql);
                $params = array_merge([$lang], $keys);
                $stmt->execute($params);
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                foreach ($rows as $row) {
                    $key = (string) ($row['lang_key'] ?? '');
                    $val = (string) ($row['value'] ?? '');
                    if ($key === '') {
                        continue;
                    }
                    $results[$lang][$key] = $val;
                }
            }
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetLangOverrides failed: ' . $e->getMessage());
            }
        }
        return $results;
    }

    public function RL_UpsertLangOverride(string $language, string $key, string $value): bool
    {
        $language = trim($language);
        $key = trim($key);
        if ($language === '' || $key === '') {
            return false;
        }
        try {
            $stmt = $this->db->prepare('INSERT INTO i_lang_overrides (language, lang_key, value, updated_at)
                VALUES (:lang, :key, :val, :time)
                ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = VALUES(updated_at)');
            $stmt->bindValue(':lang', $language, PDO::PARAM_STR);
            $stmt->bindValue(':key', $key, PDO::PARAM_STR);
            $stmt->bindValue(':val', $value, PDO::PARAM_STR);
            $stmt->bindValue(':time', time(), PDO::PARAM_INT);
            return $stmt->execute();
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_UpsertLangOverride failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    public function RL_DeleteLangOverride(string $language, string $key): bool
    {
        $language = trim($language);
        $key = trim($key);
        if ($language === '' || $key === '') {
            return false;
        }
        try {
            $stmt = $this->db->prepare('DELETE FROM i_lang_overrides WHERE language = :lang AND lang_key = :key');
            $stmt->bindValue(':lang', $language, PDO::PARAM_STR);
            $stmt->bindValue(':key', $key, PDO::PARAM_STR);
            $stmt->execute();
            return true;
        } catch (Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_DeleteLangOverride failed: ' . $e->getMessage());
            }
            return false;
        }
    }
}
