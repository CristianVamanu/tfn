<?php
declare(strict_types=1);
trait CountPostViewFunctions {

    public function RL_AddUniqueViewWithReason(
    int $postId,
    ?int $viewerUserId,
    ?string $viewerSessHex,
    string $source,
    int $dwellMs,
    float $visibleRatio
): array {
    // 1) Basic
    if ($postId <= 0) { return ['success' => false, 'reason' => 'bad_post']; }
    $source = in_array($source, ['feed','popup','reels'], true) ? $source : 'feed';
    $dwellMs = max(0, $dwellMs);
    $visibleRatio = max(0.0, min(1.0, $visibleRatio));
    $minDwell = 1200; $minRatio = 0.5;

    if ($dwellMs < $minDwell || $visibleRatio < $minRatio) {
        return ['success' => false, 'reason' => 'threshold'];
    }

    // 2) Owner
    $ownerId = $this->RL_GetPostOwnerId($postId);
    if ($ownerId <= 0) { return ['success' => false, 'reason' => 'post_not_found']; }
    if ($viewerUserId !== null && $viewerUserId === $ownerId) {
        return ['success' => false, 'reason' => 'owner_view'];
    }

    // 3) Identify
    $isLogged = $viewerUserId !== null && $viewerUserId > 0;
    if (!$isLogged) {
        if (empty($viewerSessHex) || !preg_match('/^[a-f0-9]{32}$/i', $viewerSessHex)) {
            return ['success' => false, 'reason' => 'invalid_session'];
        }
    }

    $now = time();
    $this->db->beginTransaction();
    try {
        if ($isLogged) {
            $sql = "INSERT IGNORE INTO i_post_views
                    (post_id, viewer_user_id, viewer_session, source, dwell_ms, visible_ratio, created_at)
                    VALUES (:pid, :uid, NULL, :src, :dwell, :ratio, :ts)";
            $st  = $this->db->prepare($sql);
            $st->bindValue(':pid',   $postId,       PDO::PARAM_INT);
            $st->bindValue(':uid',   $viewerUserId, PDO::PARAM_INT);
            $st->bindValue(':src',   $source,       PDO::PARAM_STR);
            $st->bindValue(':dwell', $dwellMs,      PDO::PARAM_INT);
            $st->bindValue(':ratio', $visibleRatio, PDO::PARAM_STR);
            $st->bindValue(':ts',    $now,          PDO::PARAM_INT);
        } else {
            $sql = "INSERT IGNORE INTO i_post_views
                    (post_id, viewer_user_id, viewer_session, source, dwell_ms, visible_ratio, created_at)
                    VALUES (:pid, NULL, UNHEX(:sesshex), :src, :dwell, :ratio, :ts)";
            $st  = $this->db->prepare($sql);
            $st->bindValue(':pid',     $postId,                    PDO::PARAM_INT);
            $st->bindValue(':sesshex', strtolower($viewerSessHex), PDO::PARAM_STR);
            $st->bindValue(':src',     $source,                    PDO::PARAM_STR);
            $st->bindValue(':dwell',   $dwellMs,                   PDO::PARAM_INT);
            $st->bindValue(':ratio',   $visibleRatio,              PDO::PARAM_STR);
            $st->bindValue(':ts',      $now,                       PDO::PARAM_INT);
        }

        $st->execute();
        $affected = $st->rowCount(); // INSERT IGNORE: 1 -> new record; 0 -> duplicate or ignored

        if ($affected === 1) {
            $up = $this->db->prepare("UPDATE i_user_posts SET post_views = post_views + 1 WHERE post_id = :pid LIMIT 1");
            $up->bindValue(':pid', $postId, PDO::PARAM_INT);
            $up->execute();
            $this->db->commit();
            return ['success' => true, 'reason' => 'inserted'];
        } else {
            $this->db->commit();
            return ['success' => false, 'reason' => 'duplicate_or_ignored'];
        }
    } catch (Throwable $e) {
        $this->db->rollBack();
        return ['success' => false, 'reason' => 'db_error'];
    }
}
}
