<?php
declare(strict_types=1);
trait CoreFunctions {

    /**
     * Validate and normalize a timezone ID; returns 'UTC' on failure.
     *
     * @param string|null $tz Timezone identifier
     * @return string         Valid timezone or 'UTC'
     */
    public function RL_NormalizeTimezone(?string $tz): string
    {
        $tz = is_string($tz) ? trim($tz) : '';
        if ($tz === '') { return 'UTC'; }
        try { new \DateTimeZone($tz); return $tz; } catch (\Throwable $e) { return 'UTC'; }
    }

    /**
     * Resolve preferred timezone.
     * Priority:
     * - User profile field (timezone|user_timezone|tz) if valid
     * - Site config 'site_timezone' if available
     * - PHP default timezone (ini) or 'UTC'
     *
     * @param int|null $userId Optional user ID to check profile settings
     * @return string          Resolved timezone identifier
     */
    public function RL_GetPreferredTimezone(?int $userId = null): string
    {
        // 1) Try user profile
        if ($userId !== null && $userId > 0 && method_exists($this, 'RL_GetUserDetails')) {
            try {
                $u = (array) $this->RL_GetUserDetails($userId);
                foreach (['timezone','user_timezone','tz'] as $k) {
                    if (!empty($u[$k])) {
                        $tz = $this->RL_NormalizeTimezone((string)$u[$k]);
                        if ($tz !== 'UTC' || (string)$u[$k] === 'UTC') { return $tz; }
                    }
                }
            } catch (\Throwable $e) { /* ignore */ }
        }

        // 2) Site config
        if (method_exists($this, 'RL_configs')) {
            try {
                $cfg = (array) $this->RL_configs();
                if (!empty($cfg['site_timezone'])) {
                    $tz = $this->RL_NormalizeTimezone((string)$cfg['site_timezone']);
                    if ($tz) { return $tz; }
                }
            } catch (\Throwable $e) { /* ignore */ }
        }

        // 3) PHP default
        $phpTz = @date_default_timezone_get();
        return $this->RL_NormalizeTimezone(is_string($phpTz) ? $phpTz : 'UTC');
    }
    /**
     * Append an error message to a local log file and mirror to error_log on failure.
     *
     * @param string $message Error message to record
     * @return void
     */
public function logError(string $message): void {
        $file = dirname(__DIR__) . '/functions_error.txt';
        $formattedMessage = date('Y-m-d H:i:s') . " - {$message}\n";

        if (file_put_contents($file, $formattedMessage, FILE_APPEND | LOCK_EX) === false) {
            error_log('Failed to write error log: ' . $formattedMessage);
        }
    }

}
