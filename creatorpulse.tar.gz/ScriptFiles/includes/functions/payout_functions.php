<?php
declare(strict_types=1);

trait PayoutFunctions
{
    private array $payoutAllowedMethods = ['bank', 'stripe', 'payoneer', 'paypal', 'other'];
    private array $payoutAllowedStatuses = ['pending','await','awaiting','processing','review','approved','verified','rejected','failed','none','completed','paid','canceled'];
    private ?bool $rlHasUserContactEmailColumn = null;

    private function RL_NormalizePayoutStatus(string $status): string
    {
        $normalized = strtolower(trim($status));
        if ($normalized === '') {
            return 'pending';
        }
        $aliases = [
            'await' => 'pending',
            'awaiting' => 'pending',
            'pending_update' => 'review',
            'needs_update' => 'review',
            'verified' => 'approved',
            'success' => 'approved',
            'succeeded' => 'approved',
            'complete' => 'completed',
            'declined' => 'rejected',
            'denied' => 'rejected',
            'failed' => 'failed',
            'cancelled' => 'canceled',
        ];
        if (isset($aliases[$normalized])) {
            $normalized = $aliases[$normalized];
        }
        if (!in_array($normalized, $this->payoutAllowedStatuses, true)) {
            return 'pending';
        }
        if ($normalized === 'verified') {
            $normalized = 'approved';
        }
        return $normalized;
    }

    private function RL_SanitizeAdminNote(?string $note, int $limit = 1000): ?string
    {
        if ($note === null) {
            return null;
        }
        $trimmed = trim($note);
        if ($trimmed === '') {
            return null;
        }
        if (function_exists('mb_substr')) {
            return mb_substr($trimmed, 0, $limit, 'UTF-8');
        }
        return substr($trimmed, 0, $limit);
    }

    private function RL_HasUserContactEmailColumn(): bool
    {
        if ($this->rlHasUserContactEmailColumn !== null) {
            return $this->rlHasUserContactEmailColumn;
        }

        try {
            $stmt = $this->db->query("SHOW COLUMNS FROM i_users LIKE 'contact_email'");
            $this->rlHasUserContactEmailColumn = $stmt && $stmt->fetch(PDO::FETCH_ASSOC) !== false;
        } catch (\Throwable $__) {
            $this->rlHasUserContactEmailColumn = false;
        }

        return $this->rlHasUserContactEmailColumn;
    }

    private function RL_EnsureUserPayoutsTable(): void
    {
        try {
            $sql = "CREATE TABLE IF NOT EXISTS i_user_payouts (
                payout_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id INT UNSIGNED NOT NULL,
                amount DECIMAL(12,2) NOT NULL,
                currency VARCHAR(10) NOT NULL DEFAULT 'USD',
                method VARCHAR(32) NOT NULL,
                destination_json LONGTEXT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'pending',
                reference VARCHAR(64) UNIQUE,
                notes TEXT NULL,
                admin_note TEXT NULL,
                requested_at INT UNSIGNED NOT NULL,
                processed_at INT UNSIGNED DEFAULT NULL,
                PRIMARY KEY (payout_id),
                KEY idx_user_status (user_id, status),
                KEY idx_user_time (user_id, requested_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
            $this->db->exec($sql);
        } catch (\Throwable $__) {
            // Best-effort ensure; suppress errors to avoid cascading failures
        }
    }

    private function RL_NormalizePayoutDetails(?array $decoded, string $fallbackMethod = 'none'): array
    {
        $defaultMethod = $fallbackMethod;
        $methods = [];
        if ($decoded && isset($decoded['methods']) && is_array($decoded['methods'])) {
            $methods = $decoded['methods'];
            if (isset($decoded['default_method']) && is_string($decoded['default_method'])) {
                $defaultMethod = strtolower($decoded['default_method']);
            }
        } elseif ($decoded && $decoded !== []) {
            // Legacy structure: treat as bank details
            $methods['bank'] = $decoded;
            $defaultMethod = 'bank';
        }

        $cleanMethods = [];
        $now = time();
        foreach ($methods as $method => $payload) {
            $key = strtolower((string) $method);
            if (!in_array($key, $this->payoutAllowedMethods, true)) {
                continue;
            }
            if (!is_array($payload)) {
                $payload = [];
            }
            if ($key === 'paypal' && empty($payload['email']) && !empty($payload['paypal_email'])) {
                $payload['email'] = (string) $payload['paypal_email'];
            }
            if ($key === 'payoneer' && empty($payload['email']) && !empty($payload['payoneer_email'])) {
                $payload['email'] = (string) $payload['payoneer_email'];
            }
            $payload['status'] = isset($payload['status']) && is_string($payload['status'])
                ? $this->RL_NormalizePayoutStatus($payload['status'])
                : 'pending';

            if (!isset($payload['updated_at']) || !is_numeric($payload['updated_at'])) {
                $payload['updated_at'] = $now;
            } else {
                $payload['updated_at'] = (int) $payload['updated_at'];
            }

            if (isset($payload['status_updated_at']) && is_numeric($payload['status_updated_at'])) {
                $payload['status_updated_at'] = (int) $payload['status_updated_at'];
            } else {
                $payload['status_updated_at'] = $payload['updated_at'];
            }

            if (isset($payload['reviewed_at']) && is_numeric($payload['reviewed_at'])) {
                $payload['reviewed_at'] = (int) $payload['reviewed_at'];
            } else {
                $payload['reviewed_at'] = null;
            }

            if (isset($payload['reviewed_by']) && is_numeric($payload['reviewed_by'])) {
                $payload['reviewed_by'] = (int) $payload['reviewed_by'];
            } else {
                $payload['reviewed_by'] = null;
            }

            if (isset($payload['admin_note'])) {
                $payload['admin_note'] = $this->RL_SanitizeAdminNote(
                    is_scalar($payload['admin_note']) ? (string) $payload['admin_note'] : ''
                );
            } else {
                $payload['admin_note'] = null;
            }

            $payload['requires_update'] = !empty($payload['requires_update']);

            if (isset($payload['history']) && !is_array($payload['history'])) {
                unset($payload['history']);
            }

            $cleanMethods[$key] = $payload;
        }

        if (!in_array($defaultMethod, array_keys($cleanMethods), true)) {
            $defaultMethod = array_key_first($cleanMethods) ?: $fallbackMethod;
        }

        $connected = [];
        foreach ($cleanMethods as $method => $payload) {
            $connected[$method] = $this->RL_IsPayoutMethodConnected($method, $payload);
        }

        return [
            'default_method'   => $defaultMethod,
            'methods'          => $cleanMethods,
            'connected'        => $connected,
        ];
    }

    private function RL_IsPayoutMethodConnected(string $method, array $payload): bool
    {
        $requiredKeys = [
            'bank'     => ['account_name', 'bank_name', 'iban'],
            'stripe'   => ['account_id'],
            'payoneer' => ['email'],
            'paypal'   => ['email'],
        ];
        $method = strtolower($method);
        if (!isset($requiredKeys[$method])) {
            return !empty($payload);
        }
        foreach ($requiredKeys[$method] as $key) {
            if (empty($payload[$key]) || !is_string($payload[$key])) {
                return false;
            }
        }
        return true;
    }

    private function RL_HasMeaningfulPayoutSubmission(string $method, array $details): bool
    {
        if (empty($details)) {
            return false;
        }

        $method = strtolower($method);
        $stringOrEmpty = static function ($value): string {
            if (is_string($value)) {
                return trim($value);
            }
            if (is_numeric($value)) {
                return trim((string) $value);
            }
            return '';
        };

        if ($method === 'bank') {
            $accountName = $stringOrEmpty($details['account_name'] ?? '');
            $bankName = $stringOrEmpty($details['bank_name'] ?? '');
            $iban = strtoupper($stringOrEmpty($details['iban'] ?? ''));
            $acct = $stringOrEmpty($details['account_number'] ?? '');
            if ($accountName === '' || $bankName === '') {
                return false;
            }
            return $iban !== '' || $acct !== '';
        }

        if ($method === 'paypal') {
            $email = $stringOrEmpty($details['email'] ?? $details['paypal_email'] ?? '');
            return $email !== '';
        }

        if ($method === 'stripe') {
            $accountId = $stringOrEmpty($details['account_id'] ?? '');
            return $accountId !== '';
        }

        if ($method === 'payoneer') {
            $email = $stringOrEmpty($details['email'] ?? $details['payoneer_email'] ?? '');
            return $email !== '';
        }

        if ($method === 'other') {
            $notes = $stringOrEmpty($details['notes'] ?? '');
            return $notes !== '';
        }

        $ignored = [
            'priority', 'status', 'status_updated_at', 'admin_note',
            'reviewed_at', 'reviewed_by', 'requires_update', 'updated_at',
        ];
        foreach ($details as $key => $value) {
            if (in_array($key, $ignored, true)) {
                continue;
            }
            if (is_array($value)) {
                foreach ($value as $nested) {
                    if ($stringOrEmpty($nested) !== '') {
                        return true;
                    }
                }
                continue;
            }
            if ($stringOrEmpty($value) !== '') {
                return true;
            }
        }

        return false;
    }

    public function RL_GetUserPayoutDetails(int $userId): array
    {
        try {
            $st = $this->db->prepare('SELECT payout_method, payout_details_json FROM i_users WHERE user_id = :uid LIMIT 1');
            $st->bindValue(':uid', $userId, PDO::PARAM_INT);
            $st->execute();
            $row = $st->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                return ['default_method' => 'none', 'methods' => [], 'connected' => []];
            }
            $decoded = null;
            if (!empty($row['payout_details_json'])) {
                $decoded = json_decode((string) $row['payout_details_json'], true);
                if (!is_array($decoded)) {
                    $decoded = [];
                }
            }
            $fallbackMethod = strtolower((string) ($row['payout_method'] ?? 'none'));
            return $this->RL_NormalizePayoutDetails($decoded, $fallbackMethod ?: 'none');
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_GetUserPayoutDetails failed: ' . $e->getMessage());
            }
            return ['default_method' => 'none', 'methods' => [], 'connected' => []];
        }
    }

    public function RL_SavePayoutMethodDetails(int $userId, string $method, array $details, bool $setDefault = false, ?string $status = null, array $options = []): bool
    {
        $method = strtolower($method);
        if (!in_array($method, $this->payoutAllowedMethods, true)) {
            return false;
        }
        $actor = isset($options['actor']) && $options['actor'] === 'admin' ? 'admin' : 'user';
        $timestamp = isset($options['timestamp']) && is_numeric($options['timestamp']) ? (int) $options['timestamp'] : time();
        $adminId = isset($options['admin_id']) && is_numeric($options['admin_id']) ? (int) $options['admin_id'] : null;
        $requiresUpdate = isset($options['requires_update']) ? (bool) $options['requires_update'] : null;
        $overrideNote = array_key_exists('admin_note', $options) ? $options['admin_note'] : null;
        $forceStatus = $status !== null ? $this->RL_NormalizePayoutStatus($status) : null;
        $preserveStatus = !empty($options['preserve_status']);

        $current = $this->RL_GetUserPayoutDetails($userId);
        $methods = is_array($current['methods']) ? $current['methods'] : [];
        $hadExistingPayload = array_key_exists($method, $methods) && is_array($methods[$method]);
        $payload = $hadExistingPayload ? $methods[$method] : [];
        $existingPayload = $payload;
        $statusBefore = isset($payload['status']) ? $this->RL_NormalizePayoutStatus((string) $payload['status']) : 'pending';

        if ($actor === 'user' && !$hadExistingPayload && !$this->RL_HasMeaningfulPayoutSubmission($method, $details)) {
            return true;
        }

        foreach ($details as $key => $value) {
            if ($key === 'priority') {
                $payload['priority'] = max(1, (int) $value);
                continue;
            }
            if ($key === 'status') {
                if ($actor === 'admin') {
                    $payload['status'] = $this->RL_NormalizePayoutStatus(is_string($value) ? $value : 'pending');
                }
                continue;
            }
            if (in_array($key, ['admin_note','reviewed_at','reviewed_by','status_updated_at','requires_update'], true)) {
                if ($actor !== 'admin') {
                    continue;
                }
                if ($key === 'admin_note') {
                    $payload['admin_note'] = $this->RL_SanitizeAdminNote(is_scalar($value) ? (string) $value : '');
                } elseif ($key === 'reviewed_at') {
                    $payload['reviewed_at'] = is_numeric($value) ? (int) $value : $timestamp;
                } elseif ($key === 'reviewed_by') {
                    $payload['reviewed_by'] = is_numeric($value) ? (int) $value : $adminId;
                } elseif ($key === 'status_updated_at' && is_numeric($value)) {
                    $payload['status_updated_at'] = (int) $value;
                } elseif ($key === 'requires_update') {
                    $payload['requires_update'] = (bool) $value;
                }
                continue;
            }
            $payload[$key] = is_string($value) ? trim($value) : $value;
        }
        if (!isset($payload['priority']) || !is_numeric($payload['priority'])) {
            $payload['priority'] = 1;
        } else {
            $payload['priority'] = max(1, (int) $payload['priority']);
        }
        $payload['updated_at'] = $timestamp;

        if ($actor === 'admin') {
            if ($forceStatus !== null) {
                $payload['status'] = $forceStatus;
            }
            $payload['status'] = isset($payload['status'])
                ? $this->RL_NormalizePayoutStatus((string) $payload['status'])
                : 'pending';

            if ($payload['status'] !== $statusBefore || $forceStatus !== null) {
                $payload['status_updated_at'] = $timestamp;
            } elseif (!isset($payload['status_updated_at']) || !is_numeric($payload['status_updated_at'])) {
                $payload['status_updated_at'] = $timestamp;
            } else {
                $payload['status_updated_at'] = (int) $payload['status_updated_at'];
            }

            if ($adminId !== null) {
                $payload['reviewed_by'] = $adminId;
            }
            if (!isset($payload['reviewed_at']) || !is_numeric($payload['reviewed_at'])) {
                $payload['reviewed_at'] = $timestamp;
            } else {
                $payload['reviewed_at'] = (int) $payload['reviewed_at'];
            }

            if ($requiresUpdate !== null) {
                $payload['requires_update'] = $requiresUpdate;
            } elseif (!isset($payload['requires_update'])) {
                $payload['requires_update'] = false;
            }
            if ($payload['status'] !== 'review' && $requiresUpdate === null) {
                $payload['requires_update'] = false;
            }

            $noteSource = $overrideNote;
            if ($noteSource === null && array_key_exists('admin_note', $details)) {
                $noteSource = $details['admin_note'];
            }
            if ($noteSource !== null) {
                $payload['admin_note'] = $this->RL_SanitizeAdminNote(is_scalar($noteSource) ? (string) $noteSource : '');
            } elseif (!isset($payload['admin_note'])) {
                $payload['admin_note'] = null;
            }
        } else {
            if ($preserveStatus) {
                $payload['status'] = $statusBefore;
                if (isset($existingPayload['status_updated_at']) && is_numeric($existingPayload['status_updated_at'])) {
                    $payload['status_updated_at'] = (int) $existingPayload['status_updated_at'];
                }
                if (isset($existingPayload['admin_note'])) {
                    $payload['admin_note'] = $existingPayload['admin_note'];
                }
                if (isset($existingPayload['reviewed_at']) && is_numeric($existingPayload['reviewed_at'])) {
                    $payload['reviewed_at'] = (int) $existingPayload['reviewed_at'];
                }
                if (isset($existingPayload['reviewed_by']) && is_numeric($existingPayload['reviewed_by'])) {
                    $payload['reviewed_by'] = (int) $existingPayload['reviewed_by'];
                }
                if (isset($existingPayload['requires_update'])) {
                    $payload['requires_update'] = (bool) $existingPayload['requires_update'];
                } else {
                    $payload['requires_update'] = false;
                }
                if (!isset($payload['status_updated_at']) || !is_numeric($payload['status_updated_at'])) {
                    $payload['status_updated_at'] = $timestamp;
                }
            } else {
                $payload['status'] = 'pending';
                $payload['status_updated_at'] = $timestamp;
                $payload['admin_note'] = null;
                $payload['reviewed_at'] = null;
                $payload['reviewed_by'] = null;
                $payload['requires_update'] = false;
            }
        }

        $methods[$method] = $payload;

        $defaultMethod = $current['default_method'];
        if ($setDefault) {
            $defaultMethod = $method;
        }

        $data = [
            'default_method' => $defaultMethod,
            'methods'        => $methods,
        ];
        try {
            $sql = 'UPDATE i_users SET payout_details_json = :json' . ($setDefault ? ', payout_method = :method_col' : '') . ' WHERE user_id = :uid LIMIT 1';
            $st = $this->db->prepare($sql);
            $st->bindValue(':json', json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
            if ($setDefault) {
                $st->bindValue(':method_col', in_array($method, ['bank','paypal','other'], true) ? $method : 'other');
            }
            $st->bindValue(':uid', $userId, PDO::PARAM_INT);
            return $st->execute();
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_SavePayoutMethodDetails failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    private function RL_EnsurePayoutReviewTable(): void
    {
        try {
            $sql = "CREATE TABLE IF NOT EXISTS i_user_payout_reviews (
                review_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id INT UNSIGNED NOT NULL,
                method VARCHAR(32) NOT NULL,
                admin_id INT UNSIGNED NOT NULL,
                status_before VARCHAR(32) NOT NULL,
                status_after VARCHAR(32) NOT NULL,
                admin_note TEXT NULL,
                payload_snapshot LONGTEXT NULL,
                created_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (review_id),
                KEY idx_user_method (user_id, method),
                KEY idx_admin (admin_id, created_at),
                KEY idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
            $this->db->exec($sql);
        } catch (\Throwable $__) {
            // ignore best-effort ensure
        }
    }

    public function RL_LogPayoutReview(
        int $userId,
        string $method,
        string $statusBefore,
        string $statusAfter,
        int $adminId,
        ?string $note = null,
        array $snapshot = []
    ): void {
        $this->RL_EnsurePayoutReviewTable();
        $methodKey = strtolower($method);
        $statusBefore = $this->RL_NormalizePayoutStatus($statusBefore);
        $statusAfter = $this->RL_NormalizePayoutStatus($statusAfter);
        $noteClean = $this->RL_SanitizeAdminNote($note);
        $payload = $snapshot ? json_encode($snapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
        try {
            $sql = 'INSERT INTO i_user_payout_reviews (user_id, method, admin_id, status_before, status_after, admin_note, payload_snapshot, created_at)
                    VALUES (:uid, :method, :admin, :before, :after, :note, :payload, :created)';
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $userId, PDO::PARAM_INT);
            $st->bindValue(':method', $methodKey, PDO::PARAM_STR);
            $st->bindValue(':admin', max(0, $adminId), PDO::PARAM_INT);
            $st->bindValue(':before', $statusBefore, PDO::PARAM_STR);
            $st->bindValue(':after', $statusAfter, PDO::PARAM_STR);
            if ($noteClean !== null) {
                $st->bindValue(':note', $noteClean, PDO::PARAM_STR);
            } else {
                $st->bindValue(':note', null, PDO::PARAM_NULL);
            }
            if ($payload !== null) {
                $st->bindValue(':payload', $payload, PDO::PARAM_STR);
            } else {
                $st->bindValue(':payload', null, PDO::PARAM_NULL);
            }
            $st->bindValue(':created', time(), PDO::PARAM_INT);
            $st->execute();
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_LogPayoutReview failed: ' . $e->getMessage());
            }
        }
    }

    public function RL_GetPayoutReviewHistory(int $userId, string $method, int $limit = 10, int $offset = 0): array
    {
        $this->RL_EnsurePayoutReviewTable();
        $limit = max(1, min(100, $limit));
        $offset = max(0, $offset);
        try {
            $sql = 'SELECT review_id, admin_id, status_before, status_after, admin_note, payload_snapshot, created_at
                    FROM i_user_payout_reviews
                    WHERE user_id = :uid AND method = :method
                    ORDER BY review_id DESC
                    LIMIT :lim OFFSET :off';
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $userId, PDO::PARAM_INT);
            $st->bindValue(':method', strtolower($method), PDO::PARAM_STR);
            $st->bindValue(':lim', $limit, PDO::PARAM_INT);
            $st->bindValue(':off', $offset, PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
            foreach ($rows as &$row) {
                $row['status_before'] = $this->RL_NormalizePayoutStatus((string) ($row['status_before'] ?? 'pending'));
                $row['status_after'] = $this->RL_NormalizePayoutStatus((string) ($row['status_after'] ?? 'pending'));
                $row['created_at'] = isset($row['created_at']) ? (int) $row['created_at'] : 0;
                if (!empty($row['payload_snapshot'])) {
                    $decoded = json_decode((string) $row['payload_snapshot'], true);
                    if (is_array($decoded)) {
                        $row['payload_snapshot'] = $decoded;
                    } else {
                        unset($row['payload_snapshot']);
                    }
                }
            }
            unset($row);
            return $rows;
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_GetPayoutReviewHistory failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    private function RL_GetPayoutMethodLabel(string $method): string
    {
        $key = strtolower($method);
        $map = [
            'bank'     => customLang('settings_payout_bank_title', 'Bank transfer'),
            'stripe'   => customLang('settings_payout_stripe_title', 'Stripe Connect'),
            'payoneer' => customLang('settings_payout_payoneer_title', 'Payoneer'),
            'paypal'   => 'PayPal',
            'other'    => customLang('settings_payout_other_title', 'Other method'),
        ];
        return $map[$key] ?? ucfirst(str_replace('_', ' ', $key));
    }

    private function RL_SendPayoutStatusEmail(int $userId, string $method, string $status, ?string $note = null): bool
    {
        if (!method_exists($this, 'RL_GetUserDetails')) {
            return false;
        }
        $user = (array) $this->RL_GetUserDetails($userId);
        if (isset($user['error'])) {
            return false;
        }
        $email = '';
        foreach (['contact_email', 'user_email'] as $field) {
            if (!empty($user[$field]) && filter_var((string) $user[$field], FILTER_VALIDATE_EMAIL)) {
                $email = (string) $user[$field];
                break;
            }
        }
        if ($email === '') {
            return false;
        }
        $recipientName = (string) ($user['user_fullname'] ?? $user['username'] ?? $email);

        if (!class_exists('AdminMail')) {
            require_once __DIR__ . '/../helpers/mail_helper.php';
        }

        try {
            $settings = AdminMail::loadSettings($this->db);
            [$mailer] = AdminMail::buildMailer($settings);
        } catch (\Throwable $e) {
            if (!AdminMail::isConfigurationError($e) && is_callable([$this, 'logError'])) {
                $this->logError('RL_SendPayoutStatusEmail init failed: ' . $e->getMessage());
            }
            return false;
        }

        $statusNormalized = $this->RL_NormalizePayoutStatus($status);
        $statusLabel = customLang('settings_payout_status_' . $statusNormalized, ucfirst($statusNormalized));
        $methodLabel = $this->RL_GetPayoutMethodLabel($method);

        global $base_url;
        $base = is_string($base_url) ? rtrim($base_url, '/') : '';
        $settingsUrl = ($base !== '' ? $base : '') . '/settings?tab=payout_methods';

        $subject = customLang('payout_status_email_subject', 'Your payout method was updated');
        $bodyLines = [];
        $bodyLines[] = sprintf(customLang('payout_status_email_greeting', 'Hi %s,'), $recipientName);
        $bodyLines[] = '';
        $bodyLines[] = sprintf(customLang('payout_status_email_summary', 'Your payout method %s is now %s.'), $methodLabel, $statusLabel);
        if ($note !== null && $note !== '') {
            $bodyLines[] = '';
            $bodyLines[] = customLang('payout_status_email_note_intro', 'Admin note:');
            $bodyLines[] = $note;
        }
        $bodyLines[] = '';
        $bodyLines[] = sprintf(customLang('payout_status_email_manage', 'Review your payout settings: %s'), $settingsUrl);
        $bodyLines[] = '';
        $bodyLines[] = customLang('payout_status_email_signature', '— The ReelsProject Team');

        $message = implode("\n", $bodyLines);

        try {
            $mailer->clearAllRecipients();
            $mailer->clearReplyTos();
            $mailer->addAddress($email, $recipientName);
            $mailer->Subject = $subject;
            $mailer->Body = $message;
            $mailer->AltBody = $message;
            $mailer->isHTML(false);
            $mailer->send();
            if (method_exists($mailer, 'smtpClose')) {
                $mailer->smtpClose();
            }
            return true;
        } catch (\Throwable $e) {
            if (!AdminMail::isConfigurationError($e) && is_callable([$this, 'logError'])) {
                $this->logError('RL_SendPayoutStatusEmail send failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    public function RL_CreatePayoutStatusNotification(int $userId, int $adminId, string $method, string $status, ?string $note = null, array $extra = []): bool
    {
        if (!method_exists($this, 'RL_CreateNotification')) {
            return false;
        }
        $statusNormalized = $this->RL_NormalizePayoutStatus($status);
        $payload = array_merge([
            'status' => $statusNormalized,
            'method' => strtolower($method),
            'method_label' => $this->RL_GetPayoutMethodLabel($method),
        ], is_array($extra) ? $extra : []);
        if ($note !== null && $note !== '') {
            $payload['note'] = $note;
        }
        try {
            return (bool) $this->RL_CreateNotification($userId, $adminId, 'payout_status', null, null, $payload);
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_CreatePayoutStatusNotification failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    private function RL_CreateWithdrawalStatusNotification(array $withdrawal, int $adminId): bool
    {
        if (!method_exists($this, 'RL_CreateNotification')) {
            return false;
        }

        $userId = isset($withdrawal['user_id']) ? (int) $withdrawal['user_id'] : 0;
        if ($userId <= 0) {
            return false;
        }

        $status = $this->RL_NormalizePayoutStatus((string) ($withdrawal['status'] ?? 'pending'));
        $payload = [
            'status'    => $status,
            'amount'    => isset($withdrawal['amount']) ? (float) $withdrawal['amount'] : 0.0,
            'currency'  => isset($withdrawal['currency']) ? (string) $withdrawal['currency'] : 'USD',
            'reference' => isset($withdrawal['reference']) ? (string) $withdrawal['reference'] : '',
            'payout_id' => isset($withdrawal['payout_id']) ? (int) $withdrawal['payout_id'] : 0,
        ];
        if (!empty($withdrawal['method'])) {
            $payload['method'] = strtolower((string) $withdrawal['method']);
        }
        if (!empty($withdrawal['admin_note'])) {
            $payload['note'] = (string) $withdrawal['admin_note'];
        }

        try {
            return (bool) $this->RL_CreateNotification(
                $userId,
                $adminId,
                'withdrawal_status',
                isset($withdrawal['payout_id']) ? (int) $withdrawal['payout_id'] : null,
                null,
                $payload
            );
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_CreateWithdrawalStatusNotification failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    public function RL_AdminUpdatePayoutMethodStatus(
        int $adminId,
        int $userId,
        string $method,
        string $status,
        ?string $note = null,
        array $options = []
    ): array {
        if ($adminId <= 0) {
            return ['ok' => false, 'error' => 'INVALID_ADMIN'];
        }
        $methodKey = strtolower($method);
        if (!in_array($methodKey, $this->payoutAllowedMethods, true)) {
            return ['ok' => false, 'error' => 'INVALID_METHOD'];
        }
        $timestamp = isset($options['timestamp']) && is_numeric($options['timestamp']) ? (int) $options['timestamp'] : time();
        $statusNormalized = $this->RL_NormalizePayoutStatus($status);
        $noteClean = $this->RL_SanitizeAdminNote($note);

        $current = $this->RL_GetUserPayoutDetails($userId);
        $existingPayload = $current['methods'][$methodKey] ?? [];
        $statusBefore = isset($existingPayload['status']) ? $this->RL_NormalizePayoutStatus((string) $existingPayload['status']) : 'pending';

        $requiresUpdate = isset($options['requires_update'])
            ? (bool) $options['requires_update']
            : ($statusNormalized === 'review' && $noteClean !== null);

        $setDefault = !empty($options['set_default']);
        $details = isset($options['details']) && is_array($options['details']) ? $options['details'] : [];

        $saveOk = $this->RL_SavePayoutMethodDetails(
            $userId,
            $methodKey,
            $details,
            $setDefault,
            $statusNormalized,
            [
                'actor' => 'admin',
                'timestamp' => $timestamp,
                'admin_id' => $adminId,
                'requires_update' => $requiresUpdate,
                'admin_note' => $noteClean,
            ]
        );
        if (!$saveOk) {
            return ['ok' => false, 'error' => 'DB_ERROR'];
        }

        $updatedContext = $this->RL_GetUserPayoutDetails($userId);
        $newPayload = $updatedContext['methods'][$methodKey] ?? [];
        $statusAfter = isset($newPayload['status']) ? (string) $newPayload['status'] : $statusNormalized;

        $this->RL_LogPayoutReview($userId, $methodKey, $statusBefore, $statusAfter, $adminId, $noteClean, $newPayload);

        $notifications = ['inapp' => false, 'email' => false];
        if (!empty($options['notify_inapp'])) {
            $notifications['inapp'] = $this->RL_CreatePayoutStatusNotification($userId, $adminId, $methodKey, $statusAfter, $noteClean);
        }
        if (!empty($options['notify_email'])) {
            $notifications['email'] = $this->RL_SendPayoutStatusEmail($userId, $methodKey, $statusAfter, $noteClean);
        }

        return [
            'ok'            => true,
            'status'        => $statusAfter,
            'method'        => $methodKey,
            'payload'       => $newPayload,
            'payout'        => $updatedContext,
            'notifications' => $notifications,
        ];
    }

    public function RL_ListPayoutVerificationQueue(array $filters = []): array
    {
        $statusFilter = $filters['status'] ?? 'open';
        $statuses = [];
        if ($statusFilter === 'all' || $statusFilter === null) {
            $statuses = [];
        } elseif (is_array($statusFilter)) {
            foreach ($statusFilter as $item) {
                $statuses[] = $this->RL_NormalizePayoutStatus((string) $item);
            }
            $statuses = array_values(array_unique($statuses));
        } elseif ($statusFilter === 'open') {
            $statuses = ['pending', 'review'];
        } else {
            $statuses = [$this->RL_NormalizePayoutStatus((string) $statusFilter)];
        }

        $methodFilter = isset($filters['method']) ? strtolower((string) $filters['method']) : null;
        if ($methodFilter !== null && !in_array($methodFilter, $this->payoutAllowedMethods, true)) {
            $methodFilter = null;
        }

        $limit = isset($filters['limit']) ? max(1, min(200, (int) $filters['limit'])) : 50;
        $offset = isset($filters['offset']) ? max(0, (int) $filters['offset']) : 0;
        $includeLogs = !empty($filters['include_logs']);
        $logsLimit = isset($filters['logs_limit']) ? max(1, min(20, (int) $filters['logs_limit'])) : 5;

        try {
            $columns = 'user_id, username, user_fullname, payout_method, payout_details_json, user_email';
            if ($this->RL_HasUserContactEmailColumn()) {
                $columns .= ', contact_email';
            }

            $sql = 'SELECT ' . $columns . '
                    FROM i_users
                    WHERE payout_details_json IS NOT NULL AND payout_details_json != ""';
            $rows = $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_ListPayoutVerificationQueue failed: ' . $e->getMessage());
            }
            return ['items' => [], 'total_items' => 0];
        }

        $matches = [];
        foreach ($rows as $row) {
            $decoded = [];
            if (!empty($row['payout_details_json'])) {
                $decoded = json_decode((string) $row['payout_details_json'], true);
                if (!is_array($decoded)) {
                    $decoded = [];
                }
            }
            $normalized = $this->RL_NormalizePayoutDetails($decoded, (string) ($row['payout_method'] ?? 'none'));
            foreach ($normalized['methods'] as $methodKey => $payload) {
                if ($methodFilter !== null && $methodKey !== $methodFilter) {
                    continue;
                }
                $status = $this->RL_NormalizePayoutStatus((string) ($payload['status'] ?? 'pending'));
                if (!empty($statuses) && !in_array($status, $statuses, true)) {
                    continue;
                }
                $item = [
                    'user_id'          => (int) ($row['user_id'] ?? 0),
                    'username'         => (string) ($row['username'] ?? ''),
                    'user_fullname'    => (string) ($row['user_fullname'] ?? ''),
                    'method'           => $methodKey,
                    'status'           => $status,
                    'updated_at'       => isset($payload['updated_at']) ? (int) $payload['updated_at'] : 0,
                    'status_updated_at'=> isset($payload['status_updated_at']) ? (int) $payload['status_updated_at'] : 0,
                    'requires_update'  => !empty($payload['requires_update']),
                    'admin_note'       => $payload['admin_note'] ?? null,
                    'reviewed_at'      => isset($payload['reviewed_at']) ? (int) $payload['reviewed_at'] : null,
                    'reviewed_by'      => isset($payload['reviewed_by']) ? (int) $payload['reviewed_by'] : null,
                    'priority'         => isset($payload['priority']) ? (int) $payload['priority'] : 1,
                    'connected'        => $this->RL_IsPayoutMethodConnected($methodKey, $payload),
                    'details'          => $payload,
                    'default_method'   => $normalized['default_method'],
                    'method_label'     => $this->RL_GetPayoutMethodLabel($methodKey),
                ];
                if ($includeLogs) {
                    $item['history'] = $this->RL_GetPayoutReviewHistory($item['user_id'], $methodKey, $logsLimit, 0);
                }
                $matches[] = $item;
            }
        }

        usort($matches, static function (array $a, array $b): int {
            $aTime = $a['status_updated_at'] ?? 0;
            $bTime = $b['status_updated_at'] ?? 0;
            if ($aTime === $bTime) {
                return $b['updated_at'] <=> $a['updated_at'];
            }
            return $bTime <=> $aTime;
        });

        $total = count($matches);
        $items = array_slice($matches, $offset, $limit);

        return [
            'items'        => $items,
            'total_items'  => $total,
            'applied'      => [
                'statuses' => $statuses,
                'method'   => $methodFilter,
                'offset'   => $offset,
                'limit'    => $limit,
            ],
        ];
    }

    public function RL_ListUserWithdrawals(int $userId, int $limit = 20, int $offset = 0): array
    {
        $this->RL_EnsureUserPayoutsTable();
        try {
            $sql = 'SELECT payout_id, amount, currency, method, status, reference, requested_at, processed_at, destination_json
                    FROM i_user_payouts
                    WHERE user_id = :uid
                    ORDER BY requested_at DESC
                    LIMIT :lim OFFSET :off';
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $userId, PDO::PARAM_INT);
            $st->bindValue(':lim', max(1, $limit), PDO::PARAM_INT);
            $st->bindValue(':off', max(0, $offset), PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
            foreach ($rows as &$row) {
                if (!isset($row['currency']) || $row['currency'] === '') {
                    $row['currency'] = 'USD';
                }
                if (!empty($row['destination_json'])) {
                    $decoded = json_decode((string) $row['destination_json'], true);
                    if (is_array($decoded)) {
                        $row['destination'] = $decoded;
                    }
                }
                $referenceRaw = isset($row['reference']) ? (string) $row['reference'] : '';
                if ($referenceRaw === '') {
                    $row['reference'] = 'REQ-' . str_pad((string) ($row['payout_id'] ?? ''), 6, '0', STR_PAD_LEFT);
                }
            }
            return $rows;
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_ListUserWithdrawals failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    public function RL_AdminListWithdrawalRequests(array $filters = []): array
    {
        $this->RL_EnsureUserPayoutsTable();

        $page = isset($filters['page']) ? max(1, (int) $filters['page']) : 1;
        $perPage = isset($filters['per']) ? max(10, min(200, (int) $filters['per'])) : 20;
        $offset = (int) (($page - 1) * $perPage);

        $statusFilter = isset($filters['status']) ? strtolower(trim((string) $filters['status'])) : '';
        $methodFilter = isset($filters['method']) ? strtolower(trim((string) $filters['method'])) : '';
        $searchFilter = isset($filters['search']) ? trim((string) $filters['search']) : '';

        $conditions = [];
        $paramValues = [];

        if ($statusFilter !== '' && $statusFilter !== 'all') {
            if ($statusFilter === 'open') {
                $conditions[] = "LOWER(p.status) IN ('pending','processing','review')";
            } else {
                $normalizedStatus = $this->RL_NormalizePayoutStatus($statusFilter);
                $conditions[] = 'LOWER(p.status) = :status';
                $paramValues[':status'] = $normalizedStatus;
            }
        }

        $allowedMethods = ['bank', 'stripe', 'payoneer', 'paypal', 'other'];
        if ($methodFilter !== '' && $methodFilter !== 'all') {
            if (in_array($methodFilter, $allowedMethods, true)) {
                $conditions[] = 'LOWER(p.method) = :method';
                $paramValues[':method'] = $methodFilter;
            }
        }

        if ($searchFilter !== '') {
            $conditions[] = '(
                LOWER(u.username) LIKE :query
                OR LOWER(u.user_fullname) LIKE :query
                OR LOWER(p.reference) LIKE :query
            )';
            $paramValues[':query'] = '%' . strtolower($searchFilter) . '%';
        }

        $whereSql = $conditions ? ('WHERE ' . implode(' AND ', $conditions)) : '';

        try {
            $countSql = 'SELECT COUNT(*)
                         FROM i_user_payouts p
                         LEFT JOIN i_users u ON u.user_id = p.user_id
                         ' . $whereSql;
            $countStmt = $this->db->prepare($countSql);
            foreach ($paramValues as $key => $value) {
                $countStmt->bindValue($key, $value, PDO::PARAM_STR);
            }
            $countStmt->execute();
            $total = (int) $countStmt->fetchColumn();

            $dataSql = 'SELECT
                    p.payout_id,
                    p.user_id,
                    p.amount,
                    p.currency,
                    p.method,
                    p.status,
                    p.reference,
                    p.notes,
                    p.admin_note,
                    p.requested_at,
                    p.processed_at,
                    p.destination_json,
                    u.username,
                    u.user_fullname,
                    u.user_email
                FROM i_user_payouts p
                LEFT JOIN i_users u ON u.user_id = p.user_id
                ' . $whereSql . '
                ORDER BY p.requested_at DESC, p.payout_id DESC
                LIMIT :limit OFFSET :offset';

            $stmt = $this->db->prepare($dataSql);
            foreach ($paramValues as $key => $value) {
                $stmt->bindValue($key, $value, PDO::PARAM_STR);
            }
            $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();

            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
            foreach ($rows as &$row) {
                $row['status'] = $this->RL_NormalizePayoutStatus((string) ($row['status'] ?? 'pending'));
                $row['method'] = strtolower((string) ($row['method'] ?? ''));
                $row['amount'] = isset($row['amount']) ? (float) $row['amount'] : 0.0;
                $row['currency'] = isset($row['currency']) && $row['currency'] !== '' ? (string) $row['currency'] : 'USD';
                $row['requested_at'] = isset($row['requested_at']) ? (int) $row['requested_at'] : 0;
                $row['processed_at'] = isset($row['processed_at']) ? (int) $row['processed_at'] : null;
                $referenceRaw = isset($row['reference']) ? (string) $row['reference'] : '';
                if ($referenceRaw === '') {
                    $row['reference'] = '';
                    $row['reference_display'] = 'REQ-' . str_pad((string) ($row['payout_id'] ?? ''), 6, '0', STR_PAD_LEFT);
                } else {
                    $row['reference'] = $referenceRaw;
                    $row['reference_display'] = $referenceRaw;
                }
                if (!empty($row['destination_json'])) {
                    $decoded = json_decode((string) $row['destination_json'], true);
                    if (is_array($decoded)) {
                        $row['destination'] = $decoded;
                    }
                }
            }
            unset($row);

            $pages = $perPage > 0 ? (int) max(1, ceil($total / $perPage)) : 1;

            return [
                'rows'    => $rows,
                'total'   => $total,
                'page'    => $page,
                'per'     => $perPage,
                'pages'   => $pages,
                'filters' => [
                    'status' => $statusFilter,
                    'method' => $methodFilter,
                    'search' => $searchFilter,
                ],
            ];
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_AdminListWithdrawalRequests failed: ' . $e->getMessage());
            }

            return [
                'rows'    => [],
                'total'   => 0,
                'page'    => $page,
                'per'     => $perPage,
                'pages'   => 1,
                'filters' => [
                    'status' => $statusFilter,
                    'method' => $methodFilter,
                    'search' => $searchFilter,
                ],
            ];
        }
    }

    public function RL_AdminGetWithdrawalDetails(int $payoutId): ?array
    {
        if ($payoutId <= 0) {
            return null;
        }

        $this->RL_EnsureUserPayoutsTable();

        try {
            $sql = 'SELECT
                        p.payout_id,
                        p.user_id,
                        p.amount,
                        p.currency,
                        p.method,
                        p.status,
                        p.reference,
                        p.notes,
                        p.admin_note,
                        p.requested_at,
                        p.processed_at,
                        p.destination_json,
                        u.username,
                        u.user_fullname,
                        u.user_email
                    FROM i_user_payouts p
                    LEFT JOIN i_users u ON u.user_id = p.user_id
                    WHERE p.payout_id = :pid
                    LIMIT 1';
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':pid', $payoutId, PDO::PARAM_INT);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                return null;
            }
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_AdminGetWithdrawalDetails failed: ' . $e->getMessage());
            }
            return null;
        }

        $row['payout_id'] = (int) ($row['payout_id'] ?? 0);
        $row['user_id'] = (int) ($row['user_id'] ?? 0);
        $row['amount'] = isset($row['amount']) ? (float) $row['amount'] : 0.0;
        $row['currency'] = isset($row['currency']) && $row['currency'] !== '' ? (string) $row['currency'] : 'USD';
        $row['method'] = isset($row['method']) ? strtolower((string) $row['method']) : '';
        $row['status'] = isset($row['status']) ? $this->RL_NormalizePayoutStatus((string) $row['status']) : 'pending';
        $referenceRaw = isset($row['reference']) ? (string) $row['reference'] : '';
        if ($referenceRaw === '') {
            $row['reference'] = '';
            $row['reference_display'] = 'REQ-' . str_pad((string) $row['payout_id'], 6, '0', STR_PAD_LEFT);
        } else {
            $row['reference'] = $referenceRaw;
            $row['reference_display'] = $referenceRaw;
        }
        $row['notes'] = isset($row['notes']) ? (string) $row['notes'] : '';
        $row['admin_note'] = isset($row['admin_note']) ? (string) $row['admin_note'] : '';
        $row['requested_at'] = isset($row['requested_at']) ? (int) $row['requested_at'] : 0;
        $row['processed_at'] = isset($row['processed_at']) && $row['processed_at'] !== null
            ? (int) $row['processed_at']
            : null;
        $row['username'] = isset($row['username']) ? (string) $row['username'] : '';
        $row['user_fullname'] = isset($row['user_fullname']) ? (string) $row['user_fullname'] : '';
        $row['user_email'] = isset($row['user_email']) ? (string) $row['user_email'] : '';

        if (!empty($row['destination_json'])) {
            $decoded = json_decode((string) $row['destination_json'], true);
            if (is_array($decoded)) {
                $row['destination'] = $decoded;
            }
        }

        unset($row['destination_json']);

        return $row;
    }

    public function RL_AdminUpdateWithdrawalStatus(int $adminId, int $payoutId, string $status, array $options = []): array
    {
        if ($adminId <= 0) {
            return ['ok' => false, 'error' => 'INVALID_ADMIN'];
        }
        if ($payoutId <= 0) {
            return ['ok' => false, 'error' => 'INVALID_PAYOUT'];
        }

        $current = $this->RL_AdminGetWithdrawalDetails($payoutId);
        if (!$current) {
            return ['ok' => false, 'error' => 'NOT_FOUND'];
        }

        $statusNormalized = $this->RL_NormalizePayoutStatus($status);
        $timestamp = isset($options['timestamp']) && is_numeric($options['timestamp']) ? (int) $options['timestamp'] : time();
        $adminNote = $this->RL_SanitizeAdminNote($options['admin_note'] ?? null);

        $processedAt = $current['processed_at'] ?? null;
        $finalStatuses = ['approved', 'completed', 'paid', 'rejected', 'failed', 'canceled', 'cancelled'];
        if (in_array($statusNormalized, $finalStatuses, true)) {
            $processedAt = $timestamp;
        } elseif (!empty($options['reset_processed'])) {
            $processedAt = null;
        }

        try {
            $sql = 'UPDATE i_user_payouts
                    SET status = :status,
                        admin_note = :admin_note,
                        processed_at = :processed_at
                    WHERE payout_id = :pid
                    LIMIT 1';
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':status', $statusNormalized, PDO::PARAM_STR);
            if ($adminNote !== null) {
                $stmt->bindValue(':admin_note', $adminNote, PDO::PARAM_STR);
            } else {
                $stmt->bindValue(':admin_note', null, PDO::PARAM_NULL);
            }
            if ($processedAt !== null) {
                $stmt->bindValue(':processed_at', $processedAt, PDO::PARAM_INT);
            } else {
                $stmt->bindValue(':processed_at', null, PDO::PARAM_NULL);
            }
            $stmt->bindValue(':pid', $payoutId, PDO::PARAM_INT);
            $stmt->execute();
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_AdminUpdateWithdrawalStatus failed: ' . $e->getMessage());
            }
            return ['ok' => false, 'error' => 'DB_ERROR'];
        }

        $updated = $this->RL_AdminGetWithdrawalDetails($payoutId);
        if (!$updated) {
            return ['ok' => false, 'error' => 'NOT_FOUND'];
        }

        $prevStatus = $this->RL_NormalizePayoutStatus((string) ($current['status'] ?? 'pending'));
        $newStatus = $this->RL_NormalizePayoutStatus((string) ($updated['status'] ?? 'pending'));
        $refundStatuses = ['rejected', 'failed', 'canceled', 'cancelled'];
        $amountValue = isset($updated['amount']) ? (float) $updated['amount'] : 0.0;
        if ($amountValue > 0) {
            $userIdForRefund = isset($updated['user_id']) ? (int) $updated['user_id'] : 0;
            if ($userIdForRefund > 0) {
                if (!in_array($prevStatus, $refundStatuses, true) && in_array($newStatus, $refundStatuses, true)) {
                    try {
                        $adj = $this->db->prepare('UPDATE i_users SET earned = earned + :amt WHERE user_id = :uid');
                        $adj->execute([
                            ':amt' => $amountValue,
                            ':uid' => $userIdForRefund,
                        ]);
                    } catch (\Throwable $e) {
                        if (is_callable([$this, 'logError'])) {
                            $this->logError('RL_AdminUpdateWithdrawalStatus refund failed: ' . $e->getMessage());
                        }
                    }
                }
                if (in_array($prevStatus, $refundStatuses, true) && !in_array($newStatus, $refundStatuses, true)) {
                    try {
                        $adj = $this->db->prepare('UPDATE i_users SET earned = earned - :amt WHERE user_id = :uid');
                        $adj->execute([
                            ':amt' => $amountValue,
                            ':uid' => $userIdForRefund,
                        ]);
                    } catch (\Throwable $e) {
                        if (is_callable([$this, 'logError'])) {
                            $this->logError('RL_AdminUpdateWithdrawalStatus re-deduct failed: ' . $e->getMessage());
                        }
                    }
                }
            }
        }
        $previousNote = isset($current['admin_note']) ? (string) $current['admin_note'] : '';
        $updatedNote = isset($updated['admin_note']) ? (string) $updated['admin_note'] : '';

        if ($prevStatus !== $newStatus || $previousNote !== $updatedNote) {
            $this->RL_CreateWithdrawalStatusNotification($updated, $adminId);
        }

        return [
            'ok'             => true,
            'status_before'  => $current['status'],
            'status_after'   => $updated['status'],
            'withdrawal'     => $updated,
        ];
    }

    public function RL_GetWithdrawalSummary(int $userId): array
    {
        $this->RL_EnsureUserPayoutsTable();
        $summary = [
            'total_requests'  => 0,
            'pending_amount'  => 0.0,
            'pending_count'   => 0,
            'completed_amount'=> 0.0,
            'completed_count' => 0,
            'rejected_count'  => 0,
            'last_processed'  => null,
            'last_requested'  => null,
        ];
        try {
            $sql = 'SELECT status, amount, requested_at, processed_at
                    FROM i_user_payouts
                    WHERE user_id = :uid';
            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $userId, PDO::PARAM_INT);
            $st->execute();
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                $summary['total_requests']++;
                $amount = (float) ($row['amount'] ?? 0);
                $status = strtolower((string) ($row['status'] ?? 'pending'));
                if (in_array($status, ['pending', 'processing', 'review'], true)) {
                    $summary['pending_amount'] += $amount;
                    $summary['pending_count']++;
                } elseif (in_array($status, ['paid', 'completed', 'approved', 'payed', 'success', 'succeeded'], true)) {
                    $summary['completed_amount'] += $amount;
                    $summary['completed_count']++;
                    $processed = isset($row['processed_at']) ? (int) $row['processed_at'] : 0;
                    if ($processed > 0 && ($summary['last_processed'] === null || $processed > $summary['last_processed'])) {
                        $summary['last_processed'] = $processed;
                    }
                } elseif (in_array($status, ['rejected', 'failed', 'declined', 'cancelled', 'canceled'], true)) {
                    $summary['rejected_count']++;
                }
                $requested = isset($row['requested_at']) ? (int) $row['requested_at'] : 0;
                if ($requested > 0 && ($summary['last_requested'] === null || $requested > $summary['last_requested'])) {
                    $summary['last_requested'] = $requested;
                }
            }
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_GetWithdrawalSummary failed: ' . $e->getMessage());
            }
        }
        return $summary;
    }

    public function RL_CreateWithdrawalRequest(
        int $userId,
        float $amount,
        string $currency,
        string $method,
        array $destinationSnapshot = [],
        array $options = []
    ): array {
        $this->RL_EnsureUserPayoutsTable();
        $amount = round($amount, 2);
        if ($amount <= 0) {
            return ['ok' => false, 'error' => 'INVALID_AMOUNT'];
        }
        $currency = strtoupper($currency ?: 'USD');
        $method = strtolower($method);
        if (!in_array($method, $this->payoutAllowedMethods, true)) {
            return ['ok' => false, 'error' => 'INVALID_METHOD'];
        }
        $db = $this->db;
        try {
            $db->beginTransaction();
            $st = $db->prepare('SELECT earned FROM i_users WHERE user_id = :uid FOR UPDATE');
            $st->execute([':uid' => $userId]);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                $db->rollBack();
                return ['ok' => false, 'error' => 'USER_NOT_FOUND'];
            }
            $balance = (float) ($row['earned'] ?? 0);
            $minimum = isset($options['minimum']) ? (float) $options['minimum'] : 0.0;
            if ($minimum > 0 && $amount < $minimum) {
                $db->rollBack();
                return ['ok' => false, 'error' => 'AMOUNT_BELOW_MINIMUM', 'minimum' => $minimum];
            }
            if ($amount > $balance) {
                $db->rollBack();
                return ['ok' => false, 'error' => 'INSUFFICIENT_FUNDS', 'balance' => $balance];
            }

            if (!empty($options['single_pending'])) {
                $pending = $db->prepare('SELECT payout_id FROM i_user_payouts WHERE user_id = :uid AND status IN ("pending","processing","review") LIMIT 1');
                $pending->execute([':uid' => $userId]);
                if ($pending->fetch(PDO::FETCH_ASSOC)) {
                    $db->rollBack();
                    return ['ok' => false, 'error' => 'PENDING_EXISTS'];
                }
            }

            $update = $db->prepare('UPDATE i_users SET earned = earned - :amt WHERE user_id = :uid');
            $update->execute([':amt' => $amount, ':uid' => $userId]);

            $reference = 'WD-' . $userId . '-' . time() . '-' . bin2hex(random_bytes(3));
            $insert = $db->prepare('INSERT INTO i_user_payouts
                (user_id, amount, currency, method, destination_json, status, reference, notes, requested_at)
                VALUES (:uid, :amt, :cur, :method, :dest, :status, :ref, :notes, :req)');
            $insert->execute([
                ':uid'   => $userId,
                ':amt'   => $amount,
                ':cur'   => $currency,
                ':method'=> $method,
                ':dest'  => $destinationSnapshot ? json_encode($destinationSnapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null,
                ':status'=> 'pending',
                ':ref'   => $reference,
                ':notes' => isset($options['note']) ? (string) $options['note'] : null,
                ':req'   => time(),
            ]);

            $payoutId = (int) $db->lastInsertId();
            $db->commit();

            $newBalance = $balance - $amount;
            if ($newBalance < 0) { $newBalance = 0.0; }

            return [
                'ok'         => true,
                'payout_id'  => $payoutId,
                'reference'  => $reference,
                'balance'    => $newBalance,
            ];
        } catch (\Throwable $e) {
            try { if ($db->inTransaction()) { $db->rollBack(); } } catch (\Throwable $__) {}
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_CreateWithdrawalRequest failed: ' . $e->getMessage());
            }
            return ['ok' => false, 'error' => 'DB_ERROR'];
        }
    }
}
