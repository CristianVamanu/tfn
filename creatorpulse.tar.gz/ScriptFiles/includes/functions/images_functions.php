<?php
declare(strict_types=1);
trait ImagesFunctions {
    /**
     * Fetch ALL posts with post_type = 'image' without enforcing relation/visibility.
     *
     * Notes:
     * - This does NOT filter by visibility or relationships; caller decides what to show.
     * - Kept return shape similar to other feed methods so templates can reuse the same keys.
     * - `relation_status` is always null here.
     *
     * @param int $userID  Current viewer id (used only to compute is_owner flag; 0 if guest)
     * @param int $limit   Pagination size
     * @param int $offset  Pagination offset
     * @return array<int, array<string, mixed>>
     */
    public function RL_FeedAllImages(int $userID = 0, int $limit = 20, int $offset = 0): array
    {
        try {
            $limit  = max(1, (int) $limit);
            $offset = max(0, (int) $offset);

            $sql = "
                SELECT
                    p.post_id,
                    p.post_owner_id,
                    p.post_type,
                    p.post_file,
                    p.post_text,
                    p.post_views,
                    p.post_visibility,
                    p.post_price,
                    p.comment_status,
                    p.like_status,
                    p.approval_status,
                    p.approval_notes,
                    p.approved_at,
                    p.approved_by,
                    p.post_created_time,

                    u.user_id         AS owner_id,
                    u.username        AS owner_username,
                    u.user_fullname   AS owner_fullname,
                    u.user_avatar     AS owner_avatar,
                    u.verified_status AS owner_verified
                FROM i_user_posts AS p
                INNER JOIN i_users AS u
                    ON u.user_id = p.post_owner_id
                WHERE p.post_type = 'image' AND p.post_visibility = 'everyone' AND (p.approval_status IS NULL OR p.approval_status = 'approved')
                ORDER BY p.post_created_time DESC
                LIMIT $offset, $limit
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->execute();

            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            $list = [];
            foreach ($rows as $row) {
                $ownerId = (int) $row['post_owner_id'];

                // Normalize comma-separated image list (keep original for BC)
                $files = array_values(
                    array_filter(
                        array_map('trim', explode(',', (string) ($row['post_file'] ?? ''))),
                        static fn($p) => $p !== ''
                    )
                );
                $firstFile = $files[0] ?? '';
                $hasMulti  = count($files) > 1;

                $list[] = [
                    // Post fields
                    'post_id'           => (int) $row['post_id'],
                    'post_owner_id'     => $ownerId,
                    'post_type'         => (string) $row['post_type'],
                    'post_file'         => (string) $row['post_file'], // original CSV string (backward compatibility)
                    'post_files'        => $files,                     // normalized array of paths
                    'first_image'       => $firstFile,                 // first image path for thumbnail
                    'images_count'      => count($files),              // number of images in this post
                    'has_multiple_images'=> $hasMulti,                 // convenience flag
                    'post_text'         => (string) $row['post_text'],
                    'post_visibility'   => (string) $row['post_visibility'],
                    'post_price'        => $row['post_price'] !== null ? (string) $row['post_price'] : null,
                    'comment_status'    => (string) $row['comment_status'],
                    'like_status'       => (string) $row['like_status'],
                    'approval_status'   => isset($row['approval_status']) ? (string)$row['approval_status'] : 'approved',
                    'approval_notes'    => $row['approval_notes'] !== null ? (string)$row['approval_notes'] : null,
                    'approved_at'       => $row['approved_at'] !== null ? (int)$row['approved_at'] : null,
                    'approved_by'       => $row['approved_by'] !== null ? (int)$row['approved_by'] : null,
                    'post_created_time' => (int) $row['post_created_time'],
                    'post_views'        => (int) $row['post_views'],

                    // Owner fields
                    'owner_id'          => (int) $row['owner_id'],
                    'owner_username'    => (string) $row['owner_username'],
                    'owner_fullname'    => (string) $row['owner_fullname'],
                    'owner_avatar'      => (string) $row['owner_avatar'],
                    'owner_verified'    => (int) $row['owner_verified'],

                    // No relation context in this query
                    'relation_status'   => null,

                    // Convenience flag
                    'is_owner'          => ($userID > 0 && $userID === $ownerId),
                ];
            }

            return $list;
        } catch (\Throwable $e) {
            $this->logError('RL_FeedAllImages failed: ' . $e->getMessage());
            return [];
        }
    }
}
