<?php
declare(strict_types=1);

trait PodcastAdFunctions
{
    private function RL_EnsurePodcastAdsTable(): void
    {
        static $ensured = false;
        static $translationsBackfilled = false;
        if ($ensured) {
            return;
        }
        $ensured = true;

        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_podcast_ads (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                title VARCHAR(150) NOT NULL,
                subtitle VARCHAR(255) NOT NULL,
                podcast_post_id INT UNSIGNED NOT NULL DEFAULT 0,
                package_id INT UNSIGNED NULL,
                payment_id INT UNSIGNED NULL,
                is_premium TINYINT(1) NOT NULL DEFAULT 0,
                daily_cap INT UNSIGNED NULL,
                total_cap INT UNSIGNED NULL,
                budget_amount DECIMAL(10,2) NULL,
                currency CHAR(3) NULL,
                cta_primary_label VARCHAR(80) NOT NULL,
                cta_primary_url VARCHAR(255) NOT NULL,
                cta_secondary_label VARCHAR(80) NULL,
                cta_secondary_url VARCHAR(255) NULL,
                cover_path VARCHAR(255) NULL,
                status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
                start_at INT NULL,
                end_at INT NULL,
                created_by INT NOT NULL,
                created_at INT NOT NULL,
                approved_by INT NULL,
                approved_at INT NULL,
                impressions INT NOT NULL DEFAULT 0,
                impressions_today INT NOT NULL DEFAULT 0,
                impressions_day_start INT NULL,
                clicks_primary INT NOT NULL DEFAULT 0,
                clicks_secondary INT NOT NULL DEFAULT 0,
                targeting_meta JSON NULL,
                PRIMARY KEY (id),
                KEY idx_package (package_id),
                KEY idx_payment (payment_id),
                KEY idx_podcast_post (podcast_post_id),
                KEY idx_status (status),
                KEY idx_status_dates (status, start_at, end_at),
                KEY idx_created_by (created_by)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
            // Ensure column exists on existing installs
            $this->db->exec("ALTER TABLE i_podcast_ads ADD COLUMN IF NOT EXISTS podcast_post_id INT UNSIGNED NOT NULL DEFAULT 0 AFTER subtitle");
            $this->db->exec("ALTER TABLE i_podcast_ads ADD INDEX IF NOT EXISTS idx_podcast_post (podcast_post_id)");
            $this->db->exec("ALTER TABLE i_podcast_ads ADD COLUMN IF NOT EXISTS package_id INT UNSIGNED NULL AFTER podcast_post_id");
            $this->db->exec("ALTER TABLE i_podcast_ads ADD COLUMN IF NOT EXISTS payment_id INT UNSIGNED NULL AFTER package_id");
            $this->db->exec("ALTER TABLE i_podcast_ads ADD COLUMN IF NOT EXISTS is_premium TINYINT(1) NOT NULL DEFAULT 0 AFTER payment_id");
            $this->db->exec("ALTER TABLE i_podcast_ads ADD COLUMN IF NOT EXISTS daily_cap INT UNSIGNED NULL AFTER is_premium");
            $this->db->exec("ALTER TABLE i_podcast_ads ADD COLUMN IF NOT EXISTS total_cap INT UNSIGNED NULL AFTER daily_cap");
            $this->db->exec("ALTER TABLE i_podcast_ads ADD COLUMN IF NOT EXISTS budget_amount DECIMAL(10,2) NULL AFTER total_cap");
            $this->db->exec("ALTER TABLE i_podcast_ads ADD COLUMN IF NOT EXISTS currency CHAR(3) NULL AFTER budget_amount");
            $this->db->exec("ALTER TABLE i_podcast_ads ADD COLUMN IF NOT EXISTS impressions_today INT NOT NULL DEFAULT 0 AFTER impressions");
            $this->db->exec("ALTER TABLE i_podcast_ads ADD COLUMN IF NOT EXISTS impressions_day_start INT NULL AFTER impressions_today");
            $this->db->exec("ALTER TABLE i_podcast_ads ADD COLUMN IF NOT EXISTS targeting_meta JSON NULL AFTER clicks_secondary");
            $this->db->exec("ALTER TABLE i_podcast_ads ADD INDEX IF NOT EXISTS idx_package (package_id)");
            $this->db->exec("ALTER TABLE i_podcast_ads ADD INDEX IF NOT EXISTS idx_payment (payment_id)");
        } catch (\Throwable $__) {
            // Best effort; queries using this table will fail gracefully.
        }
    }

    private function RL_EnsurePodcastAdPackagesTable(): void
    {
        static $ensured = false;
        static $translationsBackfilled = false;
        if ($ensured) {
            return;
        }
        $ensured = true;

        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_podcast_ad_packages (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                name VARCHAR(120) NOT NULL,
                description VARCHAR(255) NULL,
                price DECIMAL(10,2) NOT NULL,
                currency CHAR(3) NOT NULL DEFAULT 'USD',
                duration_days INT UNSIGNED NOT NULL DEFAULT 7,
                daily_cap INT UNSIGNED NULL,
                total_cap INT UNSIGNED NULL,
                premium_multiplier DECIMAL(6,2) NOT NULL DEFAULT 2.00,
                targeting_fee DECIMAL(10,2) NULL,
                status ENUM('active','inactive') NOT NULL DEFAULT 'active',
                sort_order INT NOT NULL DEFAULT 0,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NULL,
                PRIMARY KEY (id),
                KEY idx_status_sort (status, sort_order)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
        } catch (\Throwable $__) {
            // silent guard
        }

        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_podcast_ad_package_translations (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                package_id INT UNSIGNED NOT NULL,
                language VARCHAR(16) NOT NULL,
                name VARCHAR(120) NOT NULL,
                description VARCHAR(255) NULL,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_pkg_lang (package_id, language),
                KEY idx_pkg (package_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
        } catch (\Throwable $__) {
            // silent guard
        }

        if (!$translationsBackfilled) {
            $translationsBackfilled = true;
            try {
                $languages = $this->RL_LoadPackageLanguages();
                $defaultLang = $languages[0] ?? 'eng';
                $checkStmt = $this->db->query('SELECT COUNT(*) FROM i_podcast_ad_package_translations');
                $hasTranslations = $checkStmt && ((int) $checkStmt->fetchColumn() > 0);
                if (!$hasTranslations) {
                    $seedStmt = $this->db->query('SELECT id, name, description, created_at, updated_at FROM i_podcast_ad_packages');
                    $rows = $seedStmt ? $seedStmt->fetchAll(\PDO::FETCH_ASSOC) : [];
                    if ($rows) {
                        $ins = $this->db->prepare('INSERT INTO i_podcast_ad_package_translations (package_id, language, name, description, created_at, updated_at)
                            VALUES (:pid, :lang, :name, :description, :created, :updated)
                            ON DUPLICATE KEY UPDATE name = VALUES(name), description = VALUES(description), updated_at = VALUES(updated_at)');
                        foreach ($rows as $row) {
                            $pid = (int) ($row['id'] ?? 0);
                            if ($pid <= 0) { continue; }
                            $ins->bindValue(':pid', $pid, \PDO::PARAM_INT);
                            $ins->bindValue(':lang', $defaultLang, \PDO::PARAM_STR);
                            $ins->bindValue(':name', (string) ($row['name'] ?? ''), \PDO::PARAM_STR);
                            $ins->bindValue(':description', isset($row['description']) && $row['description'] !== '' ? (string) $row['description'] : null, isset($row['description']) && $row['description'] !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
                            $created = isset($row['created_at']) ? (int) $row['created_at'] : time();
                            $updated = isset($row['updated_at']) && (int) $row['updated_at'] > 0 ? (int) $row['updated_at'] : $created;
                            $ins->bindValue(':created', $created, \PDO::PARAM_INT);
                            $ins->bindValue(':updated', $updated, \PDO::PARAM_INT);
                            $ins->execute();
                        }
                    }
                }
            } catch (\Throwable $__) {
                // ignore backfill failure
            }
        }
    }

    private function RL_EnsurePodcastAdPaymentsTable(): void
    {
        static $ensured = false;
        if ($ensured) {
            return;
        }
        $ensured = true;

        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_podcast_ad_payments (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id INT UNSIGNED NOT NULL,
                package_id INT UNSIGNED NOT NULL,
                provider VARCHAR(32) NOT NULL,
                reference VARCHAR(191) NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                currency CHAR(3) NOT NULL,
                status ENUM('pending','paid','failed') NOT NULL DEFAULT 'pending',
                event VARCHAR(64) NULL,
                ad_id INT UNSIGNED NULL,
                token_hash CHAR(64) NULL,
                package_snapshot JSON NULL,
                daily_cap INT UNSIGNED NULL,
                total_cap INT UNSIGNED NULL,
                duration_days INT UNSIGNED NOT NULL DEFAULT 7,
                premium_selected TINYINT(1) NOT NULL DEFAULT 0,
                targeting_selected TINYINT(1) NOT NULL DEFAULT 0,
                consumed_at INT UNSIGNED NULL,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_provider_reference (provider, reference),
                KEY idx_user_status (user_id, status),
                KEY idx_ad (ad_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
        } catch (\Throwable $__) {
            // silent guard
        }
    }

    /**
     * Normalize timestamp values stored as integers or datetime strings.
     */
    private function RL_NormalizeAdTimestamp($value): ?int
    {
        if ($value === null) {
            return null;
        }

        if (is_int($value) || is_float($value) || (is_numeric($value) && ctype_digit((string) $value))) {
            $intVal = (int) $value;
            return $intVal > 0 ? $intVal : null;
        }

        if (is_string($value)) {
            $value = trim($value);
            if ($value === '') {
                return null;
            }
            $ts = @strtotime($value);
            return $ts && $ts > 0 ? $ts : null;
        }

        return null;
    }

    /**
     * Load and normalize available languages for podcast ads.
     *
     * @return array<int, string>
     */
    private function RL_LoadPackageLanguages(?array $languages = null): array
    {
        $langs = $languages ?? (function_exists('discoverAvailableLanguages') ? discoverAvailableLanguages() : ['eng']);
        if (!$langs) {
            return ['eng'];
        }
        $langs = array_map(static function ($lng) {
            return strtolower(trim((string) $lng));
        }, $langs);
        $langs = array_values(array_filter(array_unique($langs), static function ($lng) {
            return $lng !== '';
        }));
        return $langs ?: ['eng'];
    }

    /**
     * Insert or update translation rows for a package.
     */
    private function RL_SyncPodcastAdPackageTranslations(int $packageId, array $translations, int $timestamp): void
    {
        if ($packageId <= 0 || !$translations) {
            return;
        }
        try {
            $stmt = $this->db->prepare('DELETE FROM i_podcast_ad_package_translations WHERE package_id = :pid');
            $stmt->bindValue(':pid', $packageId, \PDO::PARAM_INT);
            $stmt->execute();
        } catch (\Throwable $__) {
            // ignore delete failure; we'll upsert below
        }

        try {
            $ins = $this->db->prepare('INSERT INTO i_podcast_ad_package_translations
                (package_id, language, name, description, created_at, updated_at)
                VALUES (:pid, :lang, :name, :description, :created, :updated)
                ON DUPLICATE KEY UPDATE name = VALUES(name), description = VALUES(description), updated_at = VALUES(updated_at)');
            foreach ($translations as $lang => $values) {
                $lng = strtolower(trim((string) $lang));
                if ($lng === '') {
                    continue;
                }
                $nameVal = '';
                $descVal = null;
                if (is_array($values)) {
                    $nameVal = trim((string) ($values['name'] ?? ''));
                    $descVal = isset($values['description']) ? trim((string) $values['description']) : null;
                } else {
                    $nameVal = trim((string) $values);
                }
                if ($nameVal === '') {
                    continue;
                }
                if (mb_strlen($nameVal) > 120) {
                    $nameVal = mb_substr($nameVal, 0, 120);
                }
                if ($descVal !== null && mb_strlen($descVal) > 255) {
                    $descVal = mb_substr($descVal, 0, 255);
                }
                $ins->bindValue(':pid', $packageId, \PDO::PARAM_INT);
                $ins->bindValue(':lang', $lng, \PDO::PARAM_STR);
                $ins->bindValue(':name', $nameVal, \PDO::PARAM_STR);
                $ins->bindValue(':description', $descVal !== null && $descVal !== '' ? $descVal : null, $descVal !== null && $descVal !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
                $ins->bindValue(':created', $timestamp, \PDO::PARAM_INT);
                $ins->bindValue(':updated', $timestamp, \PDO::PARAM_INT);
                $ins->execute();
            }
        } catch (\Throwable $__) {
            // ignore translation sync failures
        }
    }

    /**
     * Batch insert translation rows (used for backfills).
     */
    private function RL_InsertPackageTranslationRows(array $rows): void
    {
        if (!$rows) {
            return;
        }
        try {
            $ins = $this->db->prepare('INSERT INTO i_podcast_ad_package_translations
                (package_id, language, name, description, created_at, updated_at)
                VALUES (:pid, :lang, :name, :description, :created, :updated)
                ON DUPLICATE KEY UPDATE name = VALUES(name), description = VALUES(description), updated_at = VALUES(updated_at)');
            foreach ($rows as $row) {
                $pid = (int) ($row['package_id'] ?? 0);
                $lang = strtolower(trim((string) ($row['language'] ?? '')));
                if ($pid <= 0 || $lang === '') {
                    continue;
                }
                $name = isset($row['name']) ? trim((string) $row['name']) : '';
                $description = isset($row['description']) ? trim((string) $row['description']) : null;
                if ($name === '') {
                    continue;
                }
                if (mb_strlen($name) > 120) {
                    $name = mb_substr($name, 0, 120);
                }
                if ($description !== null && mb_strlen($description) > 255) {
                    $description = mb_substr($description, 0, 255);
                }
                $created = isset($row['created_at']) ? (int) $row['created_at'] : time();
                $updated = isset($row['updated_at']) ? (int) $row['updated_at'] : $created;
                $ins->bindValue(':pid', $pid, \PDO::PARAM_INT);
                $ins->bindValue(':lang', $lang, \PDO::PARAM_STR);
                $ins->bindValue(':name', $name, \PDO::PARAM_STR);
                $ins->bindValue(':description', $description !== null && $description !== '' ? $description : null, $description !== null && $description !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
                $ins->bindValue(':created', $created, \PDO::PARAM_INT);
                $ins->bindValue(':updated', $updated, \PDO::PARAM_INT);
                $ins->execute();
            }
        } catch (\Throwable $__) {
            // ignore insert failures during backfill
        }
    }

    private function RL_DetectPodcastCurrency(): string
    {
        $candidate = '';
        if (isset($GLOBALS['currency']) && is_string($GLOBALS['currency']) && $GLOBALS['currency'] !== '') {
            $candidate = (string) $GLOBALS['currency'];
        } elseif (isset($GLOBALS['default_currency']) && is_string($GLOBALS['default_currency']) && $GLOBALS['default_currency'] !== '') {
            $candidate = (string) $GLOBALS['default_currency'];
        }

        $candidate = strtoupper(trim($candidate));
        if ($candidate === '') {
            $candidate = 'USD';
        }
        return $candidate;
    }

    public function RL_ListPodcastAdPackages(?string $status = 'active', ?string $lang = null, ?array $languages = null): array
    {
        $this->RL_EnsurePodcastAdPackagesTable();
        $langNormalized = null;
        if ($lang === null && isset($GLOBALS['currentLang']) && is_string($GLOBALS['currentLang'])) {
            $lang = $GLOBALS['currentLang'];
        }
        if ($lang !== null) {
            $langNormalized = strtolower(trim((string) $lang));
            if ($langNormalized === '') {
                $langNormalized = null;
            }
        }
        $langOptions = $this->RL_LoadPackageLanguages($languages);
        $status = $status !== null ? strtolower(trim($status)) : null;
        $allowed = ['active', 'inactive'];
        $conditions = [];
        $params = [];

        if ($status !== null && in_array($status, $allowed, true)) {
            $conditions[] = 'status = :status';
            $params[':status'] = $status;
        }

        $where = $conditions ? ('WHERE ' . implode(' AND ', $conditions)) : '';
        $sql = 'SELECT pkg.*, ' . ($langNormalized ? 'COALESCE(pt.name, pkg.name) AS name, COALESCE(pt.description, pkg.description) AS description' : 'pkg.name, pkg.description') . '
                FROM i_podcast_ad_packages AS pkg';
        if ($langNormalized) {
            $sql .= ' LEFT JOIN i_podcast_ad_package_translations AS pt
                      ON pt.package_id = pkg.id AND pt.language = :lang';
        }
        $sql .= ' ' . $where . ' ORDER BY sort_order ASC, id ASC';

        try {
            $stmt = $this->db->prepare($sql);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value, \PDO::PARAM_STR);
            }
            if ($langNormalized) {
                $stmt->bindValue(':lang', $langNormalized, \PDO::PARAM_STR);
            }
            $stmt->execute();
            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            if ($rows && $langOptions) {
                $ids = array_values(array_filter(array_map(static fn($r) => (int) ($r['id'] ?? 0), $rows), static fn($v) => $v > 0));
                $translationMap = [];
                if ($ids) {
                    $placeholdersPkg = implode(',', array_fill(0, count($ids), '?'));
                    $placeholdersLang = implode(',', array_fill(0, count($langOptions), '?'));
                    $sqlTrans = 'SELECT package_id, language, name, description
                                 FROM i_podcast_ad_package_translations
                                 WHERE package_id IN (' . $placeholdersPkg . ')';
                    if ($langOptions) {
                        $sqlTrans .= ' AND language IN (' . $placeholdersLang . ')';
                    }
                    $stmtTrans = $this->db->prepare($sqlTrans);
                    $bindValues = array_merge($ids, $langOptions);
                    foreach ($bindValues as $idx => $val) {
                        $stmtTrans->bindValue($idx + 1, $val, is_int($val) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
                    }
                    $stmtTrans->execute();
                    while ($row = $stmtTrans->fetch(\PDO::FETCH_ASSOC)) {
                        $pid = (int) ($row['package_id'] ?? 0);
                        $lng = strtolower((string) ($row['language'] ?? ''));
                        if ($pid <= 0 || $lng === '') {
                            continue;
                        }
                        $translationMap[$pid][$lng] = [
                            'name'        => (string) ($row['name'] ?? ''),
                            'description' => isset($row['description']) ? (string) $row['description'] : '',
                        ];
                    }
                }

                $missingRows = [];
                $now = time();
                foreach ($rows as &$pkg) {
                    $pid = (int) ($pkg['id'] ?? 0);
                    if ($pid <= 0) {
                        continue;
                    }
                    $pkgTranslations = $translationMap[$pid] ?? [];
                    foreach ($langOptions as $lng) {
                        $lngKey = strtolower((string) $lng);
                        if (!isset($pkgTranslations[$lngKey])) {
                            $pkgTranslations[$lngKey] = [
                                'name'        => (string) ($pkg['name'] ?? ''),
                                'description' => isset($pkg['description']) ? (string) $pkg['description'] : '',
                            ];
                            $missingRows[] = [
                                'package_id'  => $pid,
                                'language'    => $lngKey,
                                'name'        => (string) ($pkg['name'] ?? ''),
                                'description' => isset($pkg['description']) ? (string) $pkg['description'] : '',
                                'created_at'  => isset($pkg['created_at']) ? (int) $pkg['created_at'] : $now,
                                'updated_at'  => isset($pkg['updated_at']) ? (int) $pkg['updated_at'] : $now,
                            ];
                        }
                    }
                    $pkg['translations'] = $pkgTranslations;
                }
                unset($pkg);

                if ($missingRows) {
                    $this->RL_InsertPackageTranslationRows($missingRows);
                }
            }
            return $rows;
        } catch (\Throwable $__) {
            return [];
        }
    }

    public function RL_GetPodcastAdPackageById(int $id, ?string $lang = null, ?array $languages = null): ?array
    {
        $this->RL_EnsurePodcastAdPackagesTable();
        $id = max(0, $id);
        if ($id <= 0) {
            return null;
        }
        try {
            $langNormalized = null;
            if ($lang === null && isset($GLOBALS['currentLang']) && is_string($GLOBALS['currentLang'])) {
                $lang = $GLOBALS['currentLang'];
            }
            if ($lang !== null) {
                $langNormalized = strtolower(trim((string) $lang));
                if ($langNormalized === '') {
                    $langNormalized = null;
                }
            }

            $sql = 'SELECT pkg.*, ' . ($langNormalized ? 'COALESCE(pt.name, pkg.name) AS name, COALESCE(pt.description, pkg.description) AS description' : 'pkg.name, pkg.description') . '
                    FROM i_podcast_ad_packages AS pkg';
            if ($langNormalized) {
                $sql .= ' LEFT JOIN i_podcast_ad_package_translations AS pt
                          ON pt.package_id = pkg.id AND pt.language = :lang';
            }
            $sql .= ' WHERE pkg.id = :id LIMIT 1';

            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':id', $id, \PDO::PARAM_INT);
            if ($langNormalized) {
                $stmt->bindValue(':lang', $langNormalized, \PDO::PARAM_STR);
            }
            $stmt->execute();
            $row = $stmt->fetch(\PDO::FETCH_ASSOC) ?: null;
            if ($row && $languages) {
                $langOptions = $this->RL_LoadPackageLanguages($languages);
                $transStmt = $this->db->prepare('SELECT language, name, description FROM i_podcast_ad_package_translations WHERE package_id = :pid');
                $transStmt->bindValue(':pid', $id, \PDO::PARAM_INT);
                $transStmt->execute();
                $map = [];
                while ($tr = $transStmt->fetch(\PDO::FETCH_ASSOC)) {
                    $lng = strtolower((string) ($tr['language'] ?? ''));
                    if ($lng === '') {
                        continue;
                    }
                    $map[$lng] = [
                        'name'        => (string) ($tr['name'] ?? ''),
                        'description' => isset($tr['description']) ? (string) $tr['description'] : '',
                    ];
                }
                $now = time();
                foreach ($langOptions as $lng) {
                    $lngKey = strtolower((string) $lng);
                    if (!isset($map[$lngKey])) {
                        $map[$lngKey] = [
                            'name'        => (string) ($row['name'] ?? ''),
                            'description' => isset($row['description']) ? (string) $row['description'] : '',
                        ];
                        $this->RL_InsertPackageTranslationRows([[
                            'package_id'  => $id,
                            'language'    => $lngKey,
                            'name'        => (string) ($row['name'] ?? ''),
                            'description' => isset($row['description']) ? (string) $row['description'] : '',
                            'created_at'  => isset($row['created_at']) ? (int) $row['created_at'] : $now,
                            'updated_at'  => isset($row['updated_at']) ? (int) $row['updated_at'] : $now,
                        ]]);
                    }
                }
                $row['translations'] = $map;
            }
            return $row ?: null;
        } catch (\Throwable $__) {
            return null;
        }
    }

    public function RL_SavePodcastAdPackage(array $data, ?int $id = null): ?int
    {
        $this->RL_EnsurePodcastAdPackagesTable();
        $id = $id !== null ? max(0, (int) $id) : null;

        $languages = $this->RL_LoadPackageLanguages($data['languages'] ?? null);
        $defaultLang = isset($data['default_lang']) ? strtolower(trim((string) $data['default_lang'])) : ($languages[0] ?? 'eng');
        if ($defaultLang === '') {
            $defaultLang = $languages[0] ?? 'eng';
        }
        if (!in_array($defaultLang, $languages, true)) {
            $languages[] = $defaultLang;
            $languages = $this->RL_LoadPackageLanguages($languages);
        }

        $translationsInput = [];
        if (isset($data['translations']) && is_array($data['translations'])) {
            $translationsInput = $data['translations'];
        }
        // Support name/description arrays for backward compatibility.
        if (isset($data['name']) && is_array($data['name'])) {
            foreach ($data['name'] as $lng => $val) {
                $langKey = strtolower(trim((string) $lng));
                if ($langKey === '') {
                    continue;
                }
                if (!isset($translationsInput[$langKey])) {
                    $translationsInput[$langKey] = [];
                }
                $translationsInput[$langKey]['name'] = (string) $val;
            }
        }
        if (isset($data['description']) && is_array($data['description'])) {
            foreach ($data['description'] as $lng => $val) {
                $langKey = strtolower(trim((string) $lng));
                if ($langKey === '') {
                    continue;
                }
                if (!isset($translationsInput[$langKey])) {
                    $translationsInput[$langKey] = [];
                }
                $translationsInput[$langKey]['description'] = (string) $val;
            }
        }

        $baseName = trim((string) ($translationsInput[$defaultLang]['name'] ?? ($data['name'] ?? '')));
        if ($baseName === '' && $translationsInput) {
            foreach ($translationsInput as $values) {
                if (is_array($values) && isset($values['name'])) {
                    $candidate = trim((string) $values['name']);
                    if ($candidate !== '') {
                        $baseName = $candidate;
                        break;
                    }
                }
            }
        }
        $baseDescription = isset($translationsInput[$defaultLang]['description'])
            ? trim((string) $translationsInput[$defaultLang]['description'])
            : trim((string) ($data['description'] ?? ''));

        $normalizedTranslations = [];
        foreach ($languages as $lng) {
            $lngKey = strtolower((string) $lng);
            $nameVal = isset($translationsInput[$lngKey]['name']) ? trim((string) $translationsInput[$lngKey]['name']) : $baseName;
            $descVal = isset($translationsInput[$lngKey]['description']) ? trim((string) $translationsInput[$lngKey]['description']) : $baseDescription;
            $normalizedTranslations[$lngKey] = [
                'name'        => $nameVal !== '' ? $nameVal : $baseName,
                'description' => $descVal,
            ];
        }

        $name = $baseName;
        $description = $baseDescription;
        if (mb_strlen($name) > 120) {
            $name = mb_substr($name, 0, 120);
        }
        if ($description !== '' && mb_strlen($description) > 255) {
            $description = mb_substr($description, 0, 255);
        }
        $price = round((float) ($data['price'] ?? 0), 2);
        $currency = strtoupper(trim((string) ($data['currency'] ?? $this->RL_DetectPodcastCurrency())));
        $durationDays = max(1, (int) ($data['duration_days'] ?? 7));
        $dailyCap = isset($data['daily_cap']) && $data['daily_cap'] !== '' ? max(0, (int) $data['daily_cap']) : null;
        $totalCap = isset($data['total_cap']) && $data['total_cap'] !== '' ? max(0, (int) $data['total_cap']) : null;
        $premiumMultiplier = (float) ($data['premium_multiplier'] ?? 1.0);
        if ($premiumMultiplier <= 0) {
            $premiumMultiplier = 1.0;
        }
        $targetingFee = isset($data['targeting_fee']) && $data['targeting_fee'] !== '' ? round((float) $data['targeting_fee'], 2) : null;
        $status = strtolower((string) ($data['status'] ?? 'active'));
        if (!in_array($status, ['active', 'inactive'], true)) {
            $status = 'active';
        }
        $sortOrder = isset($data['sort_order']) ? (int) $data['sort_order'] : 0;
        if ($sortOrder < 0) { $sortOrder = 0; }

        if ($name === '' || $price <= 0) {
            return null;
        }

        $now = time();

        try {
            if ($id !== null && $id > 0) {
                $sql = 'UPDATE i_podcast_ad_packages
                        SET name = :name,
                            description = :description,
                            price = :price,
                            currency = :currency,
                            duration_days = :duration_days,
                            daily_cap = :daily_cap,
                            total_cap = :total_cap,
                            premium_multiplier = :premium_multiplier,
                            targeting_fee = :targeting_fee,
                            status = :status,
                            sort_order = :sort_order,
                            updated_at = :updated_at
                        WHERE id = :id LIMIT 1';
                $stmt = $this->db->prepare($sql);
                $stmt->bindValue(':id', $id, \PDO::PARAM_INT);
            } else {
                $sql = 'INSERT INTO i_podcast_ad_packages
                        (name, description, price, currency, duration_days, daily_cap, total_cap, premium_multiplier, targeting_fee, status, sort_order, created_at, updated_at)
                        VALUES
                        (:name, :description, :price, :currency, :duration_days, :daily_cap, :total_cap, :premium_multiplier, :targeting_fee, :status, :sort_order, :created_at, NULL)';
                $stmt = $this->db->prepare($sql);
                $stmt->bindValue(':created_at', $now, \PDO::PARAM_INT);
            }

            $stmt->bindValue(':name', $name, \PDO::PARAM_STR);
            $stmt->bindValue(':description', $description !== '' ? $description : null, $description !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
            $stmt->bindValue(':price', $price);
            $stmt->bindValue(':currency', $currency, \PDO::PARAM_STR);
            $stmt->bindValue(':duration_days', $durationDays, \PDO::PARAM_INT);
            $stmt->bindValue(':daily_cap', $dailyCap, $dailyCap !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':total_cap', $totalCap, $totalCap !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':premium_multiplier', $premiumMultiplier);
            $stmt->bindValue(':targeting_fee', $targetingFee, $targetingFee !== null ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
            $stmt->bindValue(':status', $status, \PDO::PARAM_STR);
            $stmt->bindValue(':sort_order', $sortOrder, \PDO::PARAM_INT);
            if ($id !== null && $id > 0) {
                $stmt->bindValue(':updated_at', $now, \PDO::PARAM_INT);
            }

            if ($stmt->execute()) {
                if ($id !== null && $id > 0) {
                    $this->RL_SyncPodcastAdPackageTranslations($id, $normalizedTranslations, $now);
                    return $id;
                }
                $newId = (int) $this->db->lastInsertId();
                if ($newId > 0) {
                    $this->RL_SyncPodcastAdPackageTranslations($newId, $normalizedTranslations, $now);
                }
                return $newId;
            }
        } catch (\Throwable $__) {
            return null;
        }

        return null;
    }

    public function RL_DeletePodcastAdPackage(int $id): bool
    {
        $this->RL_EnsurePodcastAdPackagesTable();
        $id = max(0, $id);
        if ($id <= 0) {
            return false;
        }
        try {
            $delTrans = $this->db->prepare('DELETE FROM i_podcast_ad_package_translations WHERE package_id = :pid');
            $delTrans->bindValue(':pid', $id, \PDO::PARAM_INT);
            $delTrans->execute();
        } catch (\Throwable $__) {
            // ignore translation cleanup failure
        }
        try {
            $stmt = $this->db->prepare('DELETE FROM i_podcast_ad_packages WHERE id = :id LIMIT 1');
            $stmt->bindValue(':id', $id, \PDO::PARAM_INT);
            return $stmt->execute();
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_PurchasePodcastAdPackage(
        int $userId,
        int $packageId,
        string $provider = 'wallet',
        bool $premiumSelected = false,
        bool $targetingSelected = false
    ): array {
        $this->RL_EnsurePodcastAdPackagesTable();
        $this->RL_EnsurePodcastAdPaymentsTable();
        $this->RL_EnsurePodcastAdsTable();

        $userId = max(0, $userId);
        $packageId = max(0, $packageId);
        $provider = strtolower(trim($provider));
        if ($userId <= 0 || $packageId <= 0) {
            return ['ok' => false, 'error' => 'invalid_request'];
        }
        if ($provider !== 'wallet') {
            return ['ok' => false, 'error' => 'provider_unavailable'];
        }

        $package = $this->RL_GetPodcastAdPackageById($packageId);
        if (!$package || strtolower((string) ($package['status'] ?? '')) !== 'active') {
            return ['ok' => false, 'error' => 'package_unavailable'];
        }

        $currency = (string) ($package['currency'] ?? $this->RL_DetectPodcastCurrency());
        $currency = strtoupper($currency !== '' ? $currency : $this->RL_DetectPodcastCurrency());
        $basePrice = round((float) ($package['price'] ?? 0), 2);
        $premiumMultiplier = (float) ($package['premium_multiplier'] ?? 1.0);
        if ($premiumMultiplier <= 0) {
            $premiumMultiplier = 1.0;
        }
        $targetingFee = isset($package['targeting_fee']) ? (float) $package['targeting_fee'] : 0.0;

        $amount = $basePrice;
        if ($premiumSelected) {
            $amount = round($amount * $premiumMultiplier, 2);
        }
        if ($targetingSelected && $targetingFee > 0) {
            $amount = round($amount + $targetingFee, 2);
        }
        if ($amount <= 0) {
            $amount = $basePrice > 0 ? $basePrice : 1.00;
        }

        $dailyCap = isset($package['daily_cap']) ? (int) $package['daily_cap'] : null;
        $totalCap = isset($package['total_cap']) ? (int) $package['total_cap'] : null;
        $durationDays = isset($package['duration_days']) ? (int) $package['duration_days'] : 7;
        if ($durationDays <= 0) {
            $durationDays = 7;
        }

        $db = $this->db;
        $begun = false;
        try {
            try {
                if (!$db->inTransaction()) {
                    $begun = $db->beginTransaction() ? true : false;
                } else {
                    $begun = true;
                }
            } catch (\Throwable $__) {
                $begun = false;
            }

            $lock = $db->prepare("SELECT wallet FROM i_users WHERE user_id = :uid FOR UPDATE");
            $lock->execute([':uid' => $userId]);
            $walletRow = $lock->fetch(\PDO::FETCH_ASSOC);
            if (!$walletRow) {
                if ($begun && $db->inTransaction()) {
                    $db->rollBack();
                }
                return ['ok' => false, 'error' => 'user_not_found'];
            }
            $balance = (float) ($walletRow['wallet'] ?? 0);
            if ($balance < $amount) {
                if ($begun && $db->inTransaction()) {
                    $db->rollBack();
                }
                return [
                    'ok'      => false,
                    'error'   => 'insufficient_funds',
                    'balance' => $balance,
                    'required'=> $amount,
                ];
            }

            $newBalance = number_format(round($balance - $amount, 2), 2, '.', '');
            $upd = $db->prepare('UPDATE i_users SET wallet = :wallet WHERE user_id = :uid');
            $upd->execute([':wallet' => $newBalance, ':uid' => $userId]);

            try {
                $reference = 'PAD-' . strtoupper(bin2hex(random_bytes(6)));
            } catch (\Throwable $__) {
                $reference = 'PAD-' . strtoupper(dechex((int) (microtime(true) * 1000000)));
            }
            try {
                $token = bin2hex(random_bytes(16));
            } catch (\Throwable $__) {
                $token = sha1((string) microtime(true));
            }
            $tokenHash = hash('sha256', $token);

            $snapshot = [
                'package_id'         => $packageId,
                'name'               => (string) ($package['name'] ?? ''),
                'price'              => $basePrice,
                'currency'           => $currency,
                'duration_days'      => $durationDays,
                'daily_cap'          => $dailyCap,
                'total_cap'          => $totalCap,
                'premium_multiplier' => $premiumMultiplier,
                'targeting_fee'      => $targetingFee,
                'amount'             => $amount,
                'premium_selected'   => $premiumSelected,
                'targeting_selected' => $targetingSelected,
            ];

            $sql = "INSERT INTO i_podcast_ad_payments
                    (user_id, package_id, provider, reference, amount, currency, status, event, ad_id, token_hash, package_snapshot, daily_cap, total_cap, duration_days, premium_selected, targeting_selected, consumed_at, created_at, updated_at)
                    VALUES
                    (:uid, :package_id, :provider, :reference, :amount, :currency, 'paid', 'wallet_debited', NULL, :token_hash, :snapshot, :daily_cap, :total_cap, :duration_days, :premium_selected, :targeting_selected, NULL, :created_at, NULL)";
            $stmt = $db->prepare($sql);
            $now = time();
            $stmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
            $stmt->bindValue(':package_id', $packageId, \PDO::PARAM_INT);
            $stmt->bindValue(':provider', $provider, \PDO::PARAM_STR);
            $stmt->bindValue(':reference', $reference, \PDO::PARAM_STR);
            $stmt->bindValue(':amount', $amount);
            $stmt->bindValue(':currency', $currency, \PDO::PARAM_STR);
            $stmt->bindValue(':token_hash', $tokenHash, \PDO::PARAM_STR);
            $stmt->bindValue(':snapshot', json_encode($snapshot, JSON_UNESCAPED_UNICODE));
            $stmt->bindValue(':daily_cap', $dailyCap, $dailyCap !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':total_cap', $totalCap, $totalCap !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':duration_days', $durationDays, \PDO::PARAM_INT);
            $stmt->bindValue(':premium_selected', $premiumSelected ? 1 : 0, \PDO::PARAM_INT);
            $stmt->bindValue(':targeting_selected', $targetingSelected ? 1 : 0, \PDO::PARAM_INT);
            $stmt->bindValue(':created_at', $now, \PDO::PARAM_INT);
            $stmt->execute();

            $paymentId = (int) $db->lastInsertId();

            if ($begun && $db->inTransaction()) {
                $db->commit();
            }

            return [
                'ok'          => true,
                'payment_id'  => $paymentId,
                'reference'   => $reference,
                'token'       => $token,
                'amount'      => $amount,
                'currency'    => $currency,
                'package'     => $snapshot,
                'balance'     => (float) $newBalance,
            ];
        } catch (\Throwable $e) {
            try {
                if ($begun && $db->inTransaction()) {
                    $db->rollBack();
                }
            } catch (\Throwable $__) {
                // ignore rollback failure
            }
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    public function RL_ConsumePodcastAdPayment(int $paymentId, int $userId, string $token): ?array
    {
        $this->RL_EnsurePodcastAdPaymentsTable();
        $paymentId = max(0, $paymentId);
        $userId = max(0, $userId);
        if ($paymentId <= 0 || $userId <= 0 || $token === '') {
            return null;
        }
        $hash = hash('sha256', $token);
        $db = $this->db;
        $begun = false;
        try {
            try {
                if (!$db->inTransaction()) {
                    $begun = $db->beginTransaction() ? true : false;
                } else {
                    $begun = true;
                }
            } catch (\Throwable $__) {
                $begun = false;
            }

            $stmt = $db->prepare('SELECT * FROM i_podcast_ad_payments WHERE id = :id AND user_id = :uid LIMIT 1 FOR UPDATE');
            $stmt->bindValue(':id', $paymentId, \PDO::PARAM_INT);
            $stmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
            $stmt->execute();
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                if ($begun && $db->inTransaction()) {
                    $db->rollBack();
                }
                return null;
            }
            $status = strtolower((string) ($row['status'] ?? ''));
            if ($status !== 'paid' || !empty($row['ad_id']) || !empty($row['consumed_at'])) {
                if ($begun && $db->inTransaction()) {
                    $db->rollBack();
                }
                return null;
            }
            $storedHash = (string) ($row['token_hash'] ?? '');
            if ($storedHash !== '' && hash_equals($storedHash, $hash) === false) {
                if ($begun && $db->inTransaction()) {
                    $db->rollBack();
                }
                return null;
            }

            $now = time();
            $upd = $db->prepare('UPDATE i_podcast_ad_payments SET consumed_at = :consumed_at, updated_at = :updated_at, event = :event WHERE id = :id LIMIT 1');
            $upd->bindValue(':consumed_at', $now, \PDO::PARAM_INT);
            $upd->bindValue(':updated_at', $now, \PDO::PARAM_INT);
            $upd->bindValue(':event', 'consumed', \PDO::PARAM_STR);
            $upd->bindValue(':id', $paymentId, \PDO::PARAM_INT);
            $upd->execute();

            if ($begun && $db->inTransaction()) {
                $db->commit();
            }

            $snapshot = [];
            if (!empty($row['package_snapshot'])) {
                $decoded = json_decode((string) $row['package_snapshot'], true);
                if (is_array($decoded)) {
                    $snapshot = $decoded;
                }
            }
            $row['package_snapshot'] = $snapshot;

            return $row;
        } catch (\Throwable $e) {
            try {
                if ($begun && $db->inTransaction()) {
                    $db->rollBack();
                }
            } catch (\Throwable $__) {
                // ignore
            }
            return null;
        }
    }

    public function RL_AttachPodcastAdPaymentToAd(int $paymentId, int $userId, int $adId): bool
    {
        $this->RL_EnsurePodcastAdPaymentsTable();
        $paymentId = max(0, $paymentId);
        $userId = max(0, $userId);
        $adId = max(0, $adId);
        if ($paymentId <= 0 || $userId <= 0 || $adId <= 0) {
            return false;
        }
        try {
            $stmt = $this->db->prepare('UPDATE i_podcast_ad_payments SET ad_id = :ad_id, event = :event, updated_at = :updated_at WHERE id = :id AND user_id = :uid LIMIT 1');
            $stmt->bindValue(':ad_id', $adId, \PDO::PARAM_INT);
            $stmt->bindValue(':event', 'attached', \PDO::PARAM_STR);
            $stmt->bindValue(':updated_at', time(), \PDO::PARAM_INT);
            $stmt->bindValue(':id', $paymentId, \PDO::PARAM_INT);
            $stmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
            return $stmt->execute();
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_ResetPodcastAdPayment(int $paymentId, int $userId): void
    {
        $this->RL_EnsurePodcastAdPaymentsTable();
        $paymentId = max(0, $paymentId);
        $userId = max(0, $userId);
        if ($paymentId <= 0 || $userId <= 0) {
            return;
        }
        try {
            $stmt = $this->db->prepare("UPDATE i_podcast_ad_payments SET consumed_at = NULL, ad_id = NULL, event = 'paid', updated_at = :t WHERE id = :id AND user_id = :uid LIMIT 1");
            $stmt->bindValue(':t', time(), \PDO::PARAM_INT);
            $stmt->bindValue(':id', $paymentId, \PDO::PARAM_INT);
            $stmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
            $stmt->execute();
        } catch (\Throwable $__) {
            // ignore reset failures
        }
    }

    public function RL_CreatePodcastAd(int $userId, array $payload): int
    {
        $this->RL_EnsurePodcastAdsTable();
        $userId = max(0, $userId);
        if ($userId <= 0) {
            return 0;
        }

        $title = trim((string) ($payload['title'] ?? ''));
        $subtitle = trim((string) ($payload['subtitle'] ?? ''));
        $podcastPostId = isset($payload['podcast_post_id']) ? (int) $payload['podcast_post_id'] : 0;
        $packageId = isset($payload['package_id']) ? (int) $payload['package_id'] : null;
        $paymentId = isset($payload['payment_id']) ? (int) $payload['payment_id'] : null;
        $isPremium = !empty($payload['is_premium']) ? 1 : 0;
        $dailyCap = isset($payload['daily_cap']) ? (int) $payload['daily_cap'] : null;
        if ($dailyCap !== null && $dailyCap <= 0) {
            $dailyCap = null;
        }
        $totalCap = isset($payload['total_cap']) ? (int) $payload['total_cap'] : null;
        if ($totalCap !== null && $totalCap <= 0) {
            $totalCap = null;
        }
        $budgetAmount = isset($payload['budget_amount']) ? round((float) $payload['budget_amount'], 2) : null;
        if ($budgetAmount !== null && $budgetAmount <= 0) {
            $budgetAmount = null;
        }
        $currency = isset($payload['currency']) ? strtoupper(trim((string) $payload['currency'])) : $this->RL_DetectPodcastCurrency();
        if ($currency === '') {
            $currency = $this->RL_DetectPodcastCurrency();
        }
        $targetingMeta = null;
        if (!empty($payload['targeting_meta'])) {
            $meta = $payload['targeting_meta'];
            if (is_array($meta) || is_object($meta)) {
                $encodedMeta = json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                $targetingMeta = $encodedMeta !== false ? $encodedMeta : null;
            } elseif (is_string($meta)) {
                $targetingMeta = $meta;
            }
        }
        $ctaPrimaryLabel = trim((string) ($payload['cta_primary_label'] ?? ''));
        $ctaPrimaryUrl = trim((string) ($payload['cta_primary_url'] ?? ''));
        $ctaSecondaryLabel = trim((string) ($payload['cta_secondary_label'] ?? ''));
        $ctaSecondaryUrl = trim((string) ($payload['cta_secondary_url'] ?? ''));
        $coverPath = trim((string) ($payload['cover_path'] ?? ''));

        $status = strtolower((string) ($payload['status'] ?? 'pending'));
        $allowedStatus = ['pending', 'approved', 'rejected'];
        if (!in_array($status, $allowedStatus, true)) {
            $status = 'pending';
        }

        if ($title === '' || $ctaPrimaryLabel === '' || $ctaPrimaryUrl === '' || $podcastPostId <= 0) {
            return 0;
        }

        $truncate = static function (string $value, int $limit): string {
            if (function_exists('mb_substr')) {
                return mb_substr($value, 0, $limit);
            }
            return substr($value, 0, $limit);
        };

        $title = $truncate($title, 150);
        $subtitle = $truncate($subtitle, 255);
        $ctaPrimaryLabel = $truncate($ctaPrimaryLabel, 80);
        $ctaPrimaryUrl = $truncate($ctaPrimaryUrl, 255);
        $ctaSecondaryLabel = $ctaSecondaryLabel !== '' ? $truncate($ctaSecondaryLabel, 80) : '';
        $ctaSecondaryUrl = $ctaSecondaryUrl !== '' ? $truncate($ctaSecondaryUrl, 255) : '';
        $coverPath = $coverPath !== '' ? $truncate($coverPath, 255) : '';
        $podcastPostId = max(0, $podcastPostId);

        $startAt = $payload['start_at'] ?? null;
        $endAt = $payload['end_at'] ?? null;
        $startAt = is_numeric($startAt) ? (int) $startAt : null;
        $endAt = is_numeric($endAt) ? (int) $endAt : null;
        if ($startAt !== null && $startAt <= 0) {
            $startAt = null;
        }
        if ($endAt !== null && $endAt <= 0) {
            $endAt = null;
        }

        $createdAt = isset($payload['created_at']) && is_numeric($payload['created_at'])
            ? (int) $payload['created_at']
            : time();

        $approvedBy = null;
        $approvedAt = null;
        if ($status === 'approved') {
            $approvedBy = isset($payload['approved_by']) ? (int) $payload['approved_by'] : null;
            $approvedAt = isset($payload['approved_at']) && is_numeric($payload['approved_at'])
                ? (int) $payload['approved_at']
                : $createdAt;
        }

        try {
            $stmt = $this->db->prepare('INSERT INTO i_podcast_ads
                (title, subtitle, podcast_post_id, package_id, payment_id, is_premium, daily_cap, total_cap, budget_amount, currency, cta_primary_label, cta_primary_url, cta_secondary_label, cta_secondary_url, cover_path, status, start_at, end_at, created_by, created_at, approved_by, approved_at, impressions, impressions_today, impressions_day_start, clicks_primary, clicks_secondary, targeting_meta)
                VALUES
                (:title, :subtitle, :podcast_post_id, :package_id, :payment_id, :is_premium, :daily_cap, :total_cap, :budget_amount, :currency, :cta_primary_label, :cta_primary_url, :cta_secondary_label, :cta_secondary_url, :cover_path, :status, :start_at, :end_at, :created_by, :created_at, :approved_by, :approved_at, 0, 0, NULL, 0, 0, :targeting_meta)');

            $stmt->bindValue(':title', $title, \PDO::PARAM_STR);
            $stmt->bindValue(':subtitle', $subtitle, \PDO::PARAM_STR);
            $stmt->bindValue(':podcast_post_id', $podcastPostId, \PDO::PARAM_INT);
            $stmt->bindValue(':package_id', $packageId, $packageId !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':payment_id', $paymentId, $paymentId !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':is_premium', $isPremium, \PDO::PARAM_INT);
            $stmt->bindValue(':daily_cap', $dailyCap, $dailyCap !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':total_cap', $totalCap, $totalCap !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':budget_amount', $budgetAmount, $budgetAmount !== null ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
            $stmt->bindValue(':currency', $currency !== '' ? $currency : null, $currency !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
            $stmt->bindValue(':cta_primary_label', $ctaPrimaryLabel, \PDO::PARAM_STR);
            $stmt->bindValue(':cta_primary_url', $ctaPrimaryUrl, \PDO::PARAM_STR);
            $stmt->bindValue(':cta_secondary_label', $ctaSecondaryLabel !== '' ? $ctaSecondaryLabel : null, $ctaSecondaryLabel !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
            $stmt->bindValue(':cta_secondary_url', $ctaSecondaryUrl !== '' ? $ctaSecondaryUrl : null, $ctaSecondaryUrl !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
            $stmt->bindValue(':cover_path', $coverPath !== '' ? $coverPath : null, $coverPath !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
            $stmt->bindValue(':status', $status, \PDO::PARAM_STR);
            $stmt->bindValue(':start_at', $startAt, $startAt !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':end_at', $endAt, $endAt !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':created_by', $userId, \PDO::PARAM_INT);
            $stmt->bindValue(':created_at', $createdAt, \PDO::PARAM_INT);
            $stmt->bindValue(':approved_by', $approvedBy, $approvedBy !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':approved_at', $approvedAt, $approvedAt !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':targeting_meta', $targetingMeta, $targetingMeta !== null ? \PDO::PARAM_STR : \PDO::PARAM_NULL);

            if ($stmt->execute()) {
                return (int) $this->db->lastInsertId();
            }
        } catch (\Throwable $__) {
            return 0;
        }

        return 0;
    }

    public function RL_GetPodcastAdById(int $adId): ?array
    {
        $this->RL_EnsurePodcastAdsTable();
        if ($adId <= 0) {
            return null;
        }

        try {
            $stmt = $this->db->prepare('SELECT * FROM i_podcast_ads WHERE id = :id LIMIT 1');
            $stmt->bindValue(':id', $adId, \PDO::PARAM_INT);
            $stmt->execute();
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            return is_array($row) ? $row : null;
        } catch (\Throwable $__) {
            return null;
        }
    }

    public function RL_CountPodcastAdsByStatus(int $userId, string $status): int
    {
        $this->RL_EnsurePodcastAdsTable();
        $userId = max(0, $userId);
        $status = strtolower(trim($status));
        if ($userId <= 0 || !in_array($status, ['pending', 'approved', 'rejected'], true)) {
            return 0;
        }

        try {
            $stmt = $this->db->prepare('SELECT COUNT(*) FROM i_podcast_ads WHERE created_by = :uid AND status = :status');
            $stmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
            $stmt->bindValue(':status', $status, \PDO::PARAM_STR);
            $stmt->execute();
            return (int) $stmt->fetchColumn();
        } catch (\Throwable $__) {
            return 0;
        }
    }

    public function RL_CountPodcastAdsSince(int $userId, int $sinceTs): int
    {
        $this->RL_EnsurePodcastAdsTable();
        $userId = max(0, $userId);
        $sinceTs = max(0, $sinceTs);
        if ($userId <= 0 || $sinceTs <= 0) {
            return 0;
        }

        try {
            $stmt = $this->db->prepare('SELECT COUNT(*) FROM i_podcast_ads WHERE created_by = :uid AND created_at >= :since');
            $stmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
            $stmt->bindValue(':since', $sinceTs, \PDO::PARAM_INT);
            $stmt->execute();
            return (int) $stmt->fetchColumn();
        } catch (\Throwable $__) {
            return 0;
        }
    }

    public function RL_GetLatestPodcastAdByUser(int $userId): ?array
    {
        $this->RL_EnsurePodcastAdsTable();
        $userId = max(0, $userId);
        if ($userId <= 0) {
            return null;
        }

        try {
            $stmt = $this->db->prepare('SELECT * FROM i_podcast_ads WHERE created_by = :uid ORDER BY created_at DESC, id DESC LIMIT 1');
            $stmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
            $stmt->execute();
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            return is_array($row) ? $row : null;
        } catch (\Throwable $__) {
            return null;
        }
    }

    public function RL_UpdatePodcastAdStatus(int $adId, string $status, int $adminId = 0, ?int $approvedAt = null): bool
    {
        $this->RL_EnsurePodcastAdsTable();
        $adId = max(0, $adId);
        $adminId = max(0, $adminId);
        $status = strtolower(trim($status));
        if ($adId <= 0 || !in_array($status, ['pending', 'approved', 'rejected'], true)) {
            return false;
        }

        $approvedAt = $approvedAt ?? time();
        $approvedBy = ($status === 'approved' || $status === 'rejected') ? $adminId : null;
        $approvedTime = ($status === 'approved' || $status === 'rejected') ? $approvedAt : null;

        try {
            $stmt = $this->db->prepare('UPDATE i_podcast_ads SET status = :status, approved_by = :approved_by, approved_at = :approved_at WHERE id = :id LIMIT 1');
            $stmt->bindValue(':status', $status, \PDO::PARAM_STR);
            $stmt->bindValue(':approved_by', $approvedBy, $approvedBy !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':approved_at', $approvedTime, $approvedTime !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':id', $adId, \PDO::PARAM_INT);
            return $stmt->execute();
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_CreatePodcastAdStatusNotification(int $ownerId, int $adminId, int $adId, string $status, ?string $title = null): bool
    {
        $this->RL_EnsurePodcastAdsTable();
        $this->RL_EnsurePodcastAdNotificationType();
        $ownerId = max(0, $ownerId);
        $adminId = max(0, $adminId);
        $adId = max(0, $adId);
        $status = strtolower(trim($status));
        $allowed = ['pending', 'approved', 'rejected', 'deleted'];
        if ($ownerId <= 0 || $adminId <= 0 || $adId <= 0 || $ownerId === $adminId || !in_array($status, $allowed, true)) {
            return false;
        }
        $extra = [
            'context' => 'podcast_ad_status',
            'status'  => $status,
        ];
        if ($title !== null && trim($title) !== '') {
            $extra['title'] = trim($title);
        }

        try {
            return $this->RL_CreateNotification($ownerId, $adminId, 'podcast_ad_status', $adId, null, $extra);
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_CreatePodcastAdStatusNotification failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    private function RL_EnsurePodcastAdNotificationType(): void
    {
        try {
            $col = $this->db->query("SHOW FULL COLUMNS FROM i_notifications LIKE 'type'")->fetch(\PDO::FETCH_ASSOC);
            if (!$col) {
                return;
            }
            $typeDef = (string) ($col['Type'] ?? '');
            if (strpos($typeDef, 'podcast_ad_status') !== false) {
                return;
            }
            if (stripos($typeDef, 'enum(') === false) {
                return;
            }
            $inside = trim(substr($typeDef, 5), '()');
            $newDef = 'enum(' . $inside . ",'podcast_ad_status')";
            $collation = !empty($col['Collation']) ? (' COLLATE ' . $col['Collation']) : '';
            $sql = "ALTER TABLE i_notifications MODIFY COLUMN type $newDef$collation NOT NULL";
            $this->db->exec($sql);
        } catch (\Throwable $__) {
            // best effort; ignore if cannot alter
        }
    }

    public function RL_DeletePodcastAd(int $adId): bool
    {
        $this->RL_EnsurePodcastAdsTable();
        $adId = max(0, $adId);
        if ($adId <= 0) {
            return false;
        }

        $coverPath = '';
        try {
            $row = $this->RL_GetPodcastAdById($adId);
            if ($row && isset($row['cover_path'])) {
                $coverPath = (string) $row['cover_path'];
            }
        } catch (\Throwable $__) {
            $coverPath = '';
        }

        try {
            $stmt = $this->db->prepare('DELETE FROM i_podcast_ads WHERE id = :id LIMIT 1');
            $stmt->bindValue(':id', $adId, \PDO::PARAM_INT);
            $ok = $stmt->execute();
        } catch (\Throwable $__) {
            $ok = false;
        }

        if ($ok && $coverPath !== '') {
            try {
                if (function_exists('storage_delete')) {
                    storage_delete($coverPath);
                }
            } catch (\Throwable $__) {
                // Ignore cleanup failures
            }
        }

        return $ok;
    }

    public function RL_ListPodcastAds(array $filters = [], int $limit = 20, int $offset = 0): array
    {
        $this->RL_EnsurePodcastAdsTable();
        $this->RL_EnsurePodcastAdPackagesTable();
        $this->RL_EnsurePodcastAdPaymentsTable();
        $limit = max(1, min(200, $limit));
        $offset = max(0, $offset);

        $conditions = [];
        $params = [];

        if (!empty($filters['status']) && is_string($filters['status'])) {
            $status = strtolower(trim((string) $filters['status']));
            if (in_array($status, ['pending', 'approved', 'rejected'], true)) {
                $conditions[] = 'a.status = :status';
                $params[':status'] = $status;
            }
        }

        if (!empty($filters['created_by'])) {
            $uid = (int) $filters['created_by'];
            if ($uid > 0) {
                $conditions[] = 'a.created_by = :uid';
                $params[':uid'] = $uid;
            }
        }

        if (!empty($filters['q'])) {
            $search = '%' . trim((string) $filters['q']) . '%';
            $conditions[] = '(a.title LIKE :q OR a.subtitle LIKE :q)';
            $params[':q'] = $search;
        }

        $where = $conditions ? ('WHERE ' . implode(' AND ', $conditions)) : '';
        $sql = 'SELECT a.*, u.username, u.user_fullname, pkg.name AS package_name, pay.amount AS payment_amount, pay.currency AS payment_currency, pay.provider AS payment_provider, pay.status AS payment_status
                FROM i_podcast_ads a
                LEFT JOIN i_users u ON u.user_id = a.created_by
                LEFT JOIN i_podcast_ad_packages pkg ON pkg.id = a.package_id
                LEFT JOIN i_podcast_ad_payments pay ON pay.id = a.payment_id
                ' . $where . '
                ORDER BY a.created_at DESC, a.id DESC
                LIMIT :limit OFFSET :offset';

        try {
            $stmt = $this->db->prepare($sql);
            foreach ($params as $key => $val) {
                $paramType = \PDO::PARAM_STR;
                if (is_int($val)) {
                    $paramType = \PDO::PARAM_INT;
                }
                $stmt->bindValue($key, $val, $paramType);
            }
            $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
            $stmt->execute();
            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            return is_array($rows) ? $rows : [];
        } catch (\Throwable $__) {
            return [];
        }
    }

    public function RL_GetActivePodcastAds(int $limit = 5, ?int $now = null): array
    {
        $this->RL_EnsurePodcastAdsTable();
        $this->RL_EnsurePodcastAdPaymentsTable();
        $limit = max(1, min(10, $limit));
        $now = $now ?? time();
        $dayStart = strtotime('today', $now);
        $candidateLimit = min(50, max($limit * 3, $limit + 5));

        $sql = 'SELECT
                    a.id, a.title, a.subtitle, a.podcast_post_id, a.package_id, a.payment_id, a.is_premium,
                    a.daily_cap, a.total_cap, a.budget_amount, a.currency,
                    a.cta_primary_label, a.cta_primary_url,
                    a.cta_secondary_label, a.cta_secondary_url, a.cover_path,
                    a.start_at, a.end_at, a.impressions, a.impressions_today, a.impressions_day_start,
                    a.clicks_primary, a.clicks_secondary,
                    a.created_by, a.created_at, a.approved_at,
                    pay.status AS payment_status
                FROM i_podcast_ads a
                LEFT JOIN i_podcast_ad_payments pay ON pay.id = a.payment_id
                WHERE a.status IN (\'approved\', \'active\')
                  AND (pay.id IS NULL OR pay.status = \'paid\')
                ORDER BY a.is_premium DESC, a.created_at DESC
                LIMIT :limit';

        try {
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':limit', $candidateLimit, \PDO::PARAM_INT);
            $stmt->execute();
            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            if (!$rows) {
                return [];
            }

            $filtered = [];
            foreach ($rows as $row) {
                $startAt = $this->RL_NormalizeAdTimestamp($row['start_at'] ?? null);
                $endAt = $this->RL_NormalizeAdTimestamp($row['end_at'] ?? null);
                if ($startAt !== null && $startAt > $now) {
                    continue;
                }
                if ($endAt !== null && $endAt < $now) {
                    continue;
                }

                $impressions = isset($row['impressions']) ? (int) $row['impressions'] : 0;
                $impressionsToday = isset($row['impressions_today']) ? (int) $row['impressions_today'] : 0;
                $impressionsDayStart = isset($row['impressions_day_start']) ? (int) $row['impressions_day_start'] : 0;
                if ($impressionsDayStart < $dayStart) {
                    $impressionsDayStart = $dayStart;
                    $impressionsToday = 0;
                }

                $dailyCap = isset($row['daily_cap']) ? (int) $row['daily_cap'] : null;
                if ($dailyCap !== null && $dailyCap <= 0) {
                    $dailyCap = null;
                }
                if ($dailyCap !== null && $impressionsToday >= $dailyCap) {
                    continue;
                }

                $totalCap = isset($row['total_cap']) ? (int) $row['total_cap'] : null;
                if ($totalCap !== null && $totalCap <= 0) {
                    $totalCap = null;
                }
                if ($totalCap !== null && $impressions >= $totalCap) {
                    continue;
                }

                $row['start_at'] = $startAt;
                $row['end_at'] = $endAt;
                $row['impressions_today'] = $impressionsToday;
                $row['impressions_day_start'] = $impressionsDayStart;
                $filtered[] = $row;
            }

            if (!$filtered) {
                return [];
            }

            $premium = [];
            $standard = [];
            foreach ($filtered as $row) {
                if (!empty($row['is_premium'])) {
                    $premium[] = $row;
                } else {
                    $standard[] = $row;
                }
            }

            if (count($premium) > 1) {
                shuffle($premium);
            }
            if (count($standard) > 1) {
                shuffle($standard);
            }

            $ordered = array_merge($premium, $standard);
            return array_slice($ordered, 0, $limit);
        } catch (\Throwable $__) {
            return [];
        }
    }

    public function RL_RecordPodcastAdImpressions(array $adIds, int $increment = 1): int
    {
        $this->RL_EnsurePodcastAdsTable();
        $increment = max(1, $increment);
        $ids = [];
        foreach ($adIds as $id) {
            $id = (int) $id;
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }
        if (empty($ids)) {
            return 0;
        }

        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $now = time();
        $dayStart = strtotime('today');
        $rows = [];
        try {
            $stmt = $this->db->prepare('SELECT id, status, start_at, end_at, impressions, impressions_today, impressions_day_start, daily_cap, total_cap FROM i_podcast_ads WHERE id IN (' . $placeholders . ')');
            $idx = 1;
            foreach ($ids as $id) {
                $stmt->bindValue($idx, $id, \PDO::PARAM_INT);
                $idx++;
            }
            $stmt->execute();
            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $__) {
            return 0;
        }

        if (empty($rows)) {
            return 0;
        }

        $updated = 0;
        try {
            $upd = $this->db->prepare('UPDATE i_podcast_ads SET impressions = impressions + :inc, impressions_today = :today, impressions_day_start = :day_start WHERE id = :id LIMIT 1');
            foreach ($rows as $row) {
                $status = strtolower((string) ($row['status'] ?? ''));
                if (!in_array($status, ['approved', 'active'], true)) {
                    continue;
                }
                $startAt = $this->RL_NormalizeAdTimestamp($row['start_at'] ?? null);
                $endAt = $this->RL_NormalizeAdTimestamp($row['end_at'] ?? null);
                if (($startAt && $startAt > $now) || ($endAt && $endAt < $now)) {
                    continue;
                }

                $impressions = isset($row['impressions']) ? (int) $row['impressions'] : 0;
                $impressionsToday = isset($row['impressions_today']) ? (int) $row['impressions_today'] : 0;
                $impressionsDayStart = isset($row['impressions_day_start']) ? (int) $row['impressions_day_start'] : 0;
                if ($impressionsDayStart < $dayStart) {
                    $impressionsDayStart = $dayStart;
                    $impressionsToday = 0;
                }

                $dailyCap = isset($row['daily_cap']) ? (int) $row['daily_cap'] : null;
                if ($dailyCap !== null && $dailyCap <= 0) {
                    $dailyCap = null;
                }
                $totalCap = isset($row['total_cap']) ? (int) $row['total_cap'] : null;
                if ($totalCap !== null && $totalCap <= 0) {
                    $totalCap = null;
                }

                $remainingDaily = $dailyCap !== null ? max(0, $dailyCap - $impressionsToday) : $increment;
                $remainingTotal = $totalCap !== null ? max(0, $totalCap - $impressions) : $increment;
                $apply = min($increment, $remainingDaily, $remainingTotal);
                if ($apply <= 0) {
                    continue;
                }

                $upd->bindValue(':inc', $apply, \PDO::PARAM_INT);
                $upd->bindValue(':today', $impressionsToday + $apply, \PDO::PARAM_INT);
                $upd->bindValue(':day_start', $impressionsDayStart, \PDO::PARAM_INT);
                $upd->bindValue(':id', (int) $row['id'], \PDO::PARAM_INT);
                $upd->execute();
                $updated += (int) $upd->rowCount();
            }
        } catch (\Throwable $__) {
            return $updated;
        }

        return $updated;
    }

    public function RL_RecordPodcastAdClick(int $adId, string $which = 'primary'): bool
    {
        $this->RL_EnsurePodcastAdsTable();
        $adId = max(0, $adId);
        if ($adId <= 0) {
            return false;
        }

        $column = 'clicks_primary';
        if (strtolower($which) === 'secondary') {
            $column = 'clicks_secondary';
        }

        $sql = 'UPDATE i_podcast_ads SET ' . $column . ' = ' . $column . ' + 1 WHERE id = :id LIMIT 1';
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':id', $adId, \PDO::PARAM_INT);
            return $stmt->execute();
        } catch (\Throwable $__) {
            return false;
        }
    }
}
