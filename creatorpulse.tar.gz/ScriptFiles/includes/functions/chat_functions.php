<?php
declare(strict_types=1);

trait ConversationsFunctions
{
    /** Latest incoming message meta (from_id, message_time) to a user */
    public function RL_GetLatestIncomingMessageMeta(int $userId): array
    {
        $userId = (int)$userId;
        if ($userId <= 0) { return ['from_id'=>0,'message_time'=>0]; }
        try {
            $st = $this->db->prepare('SELECT user_one AS from_id, message_time FROM i_messages WHERE user_two = :u ORDER BY message_time DESC, message_id DESC LIMIT 1');
            $st->bindValue(':u', $userId, \PDO::PARAM_INT);
            $st->execute();
            $r = $st->fetch(\PDO::FETCH_ASSOC) ?: [];
            return [
                'from_id'      => (int)($r['from_id'] ?? 0),
                'message_time' => (int)($r['message_time'] ?? 0),
            ];
        } catch (\Throwable $__) {
            return ['from_id'=>0,'message_time'=>0];
        }
    }
    /** Mark all incoming messages from :with to :me as delivered+read */
    public function RL_MarkConversationRead(int $me, int $with, ?int $now = null): int
    {
        $me = (int)$me; $with = (int)$with; $now = (int)($now ?? time());
        if ($me <= 0 || $with <= 0) { return 0; }
        $this->RL_EnsureMessageStatusColumns();
        try {
            $st = $this->db->prepare('UPDATE i_messages
                                 SET delivered_at = IFNULL(delivered_at, :now), read_at = :now
                               WHERE user_two = :me AND user_one = :with
                                 AND (delivered_at IS NULL OR read_at IS NULL OR read_at = 0)');
            $st->bindValue(':now', $now, \PDO::PARAM_INT);
            $st->bindValue(':me',  $me,  \PDO::PARAM_INT);
            $st->bindValue(':with',$with,\PDO::PARAM_INT);
            $st->execute();
            return (int)$st->rowCount();
        } catch (\Throwable $__) { return 0; }
    }
    private function RL_EnsureMessageStatusColumns(): void
    {
        try {
            $col = $this->db->query("SHOW COLUMNS FROM i_messages LIKE 'delivered_at'")->fetch(\PDO::FETCH_ASSOC);
            if (!$col) {
                $this->db->exec("ALTER TABLE i_messages ADD COLUMN delivered_at INT NULL DEFAULT NULL AFTER message_time");
                $this->db->exec("ALTER TABLE i_messages ADD COLUMN read_at INT NULL DEFAULT NULL AFTER delivered_at");
                $this->db->exec("ALTER TABLE i_messages ADD INDEX idx_messages_to_time (user_two, message_time)");
            } else {
                // ensure read_at exists as well
                $col2 = $this->db->query("SHOW COLUMNS FROM i_messages LIKE 'read_at'")->fetch(\PDO::FETCH_ASSOC);
                if (!$col2) { $this->db->exec("ALTER TABLE i_messages ADD COLUMN read_at INT NULL DEFAULT NULL AFTER delivered_at"); }
            }
            // ensure composite index for fast seen marking
            try {
                $idx = $this->db->query("SHOW INDEX FROM i_messages WHERE Key_name = 'idx_messages_seen'")->fetch(\PDO::FETCH_ASSOC);
                if (!$idx) {
                    $this->db->exec("ALTER TABLE i_messages ADD INDEX idx_messages_seen (user_two, user_one, read_at)");
                }
            } catch (\Throwable $___) { /* ignore */ }
        } catch (\Throwable $__) { /* silent */ }
    }
    /**
     * Get the most recent unique chat partners for a user.
     * Returns up to $limit users ordered by latest message time (DESC).
     * Output rows: user_id, username, user_fullname, avatar
     */
    public function RL_GetRecentChatPartners(int $currentUser, int $limit = 3): array
    {
        $currentUser = (int)$currentUser; $limit = max(1, min(10, (int)$limit));
        if ($currentUser <= 0) { return []; }
        try {
            // Derived table to compute latest message time per partner (excluding self)
            $sql = "SELECT u.user_id, u.username, u.user_fullname, u.user_avatar AS avatar
                    FROM i_users u
                    INNER JOIN (
                      SELECT partner_id, MAX(message_time) AS last_time
                      FROM (
                        SELECT CASE WHEN user_one = :me_a THEN user_two ELSE user_one END AS partner_id,
                               message_time
                        FROM i_messages
                        WHERE user_one = :me_b OR user_two = :me_c
                      ) t
                      WHERE partner_id <> :me_d
                      GROUP BY partner_id
                    ) recent ON recent.partner_id = u.user_id
                    ORDER BY recent.last_time DESC
                    LIMIT " . (int)$limit;
            $st = $this->db->prepare($sql);
            $st->bindValue(':me_a', $currentUser, \PDO::PARAM_INT);
            $st->bindValue(':me_b', $currentUser, \PDO::PARAM_INT);
            $st->bindValue(':me_c', $currentUser, \PDO::PARAM_INT);
            $st->bindValue(':me_d', $currentUser, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            foreach ($rows as &$r) {
                $uid = (int)($r['user_id'] ?? 0);
                $r['avatar'] = $this->RL_userAvatar($uid);
                if (empty($r['user_fullname'])) { $r['user_fullname'] = $r['username'] ?? ''; }
            }
            unset($r);
            return $rows;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) { $this->logError('RL_GetRecentChatPartners failed: ' . $e->getMessage()); }
            return [];
        }
    }
    /**
     * Return both participants' basic info with safe fallbacks.
     * Uses existing RL_* helpers so behavior matches the rest of the app.
     *
     * @param int $currentUser Logged-in user id
     * @param int $targetUser  Other user id
     * @return array{self: ?array, other: ?array}
     */
    public function RL_GetConversationUsers(int $currentUser, int $targetUser): array
    {
        // Current user (self)
        $self = $this->RL_GetUserDetails($currentUser);
        if (isset($self['error'])) {
            $self = null;
        } else {
            $self['avatar'] = $this->RL_userAvatar((int) $self['user_id']);
            if (empty($self['user_fullname'])) {
                $self['user_fullname'] = $self['username'] ?? '';
            }
        }

        // Other participant
        $other = $this->RL_GetUserDetails($targetUser);
        if (isset($other['error'])) {
            $other = null;
        } else {
            $other['avatar'] = $this->RL_userAvatar((int) $other['user_id']);
            if (empty($other['user_fullname'])) {
                $other['user_fullname'] = $other['username'] ?? '';
            }
        }

        return [
            'self'  => $self,
            'other' => $other,
        ];
    }

    private function RL_IsConversationMessage(array $row, int $currentUser, int $targetUser): bool
    {
        $from = (int)($row['user_one'] ?? 0);
        $to = (int)($row['user_two'] ?? 0);
        return ($from === $currentUser && $to === $targetUser) || ($from === $targetUser && $to === $currentUser);
    }

    private function RL_GetMessageForAction(int $currentUser, int $messageId): array
    {
        $currentUser = (int)$currentUser;
        $messageId = (int)$messageId;
        if ($currentUser <= 0 || $messageId <= 0) {
            return ['error' => 'invalid_input'];
        }
        try {
            $st = $this->db->prepare('SELECT message_id, user_one, user_two, message, file, message_type, metadata, message_time, deleted_at, deleted_by FROM i_messages WHERE message_id = :mid LIMIT 1');
            $st->bindValue(':mid', $messageId, \PDO::PARAM_INT);
            $st->execute();
            $row = $st->fetch(\PDO::FETCH_ASSOC) ?: null;
            if (!$row) {
                return ['error' => 'not_found'];
            }
            if ((int)$row['user_one'] !== $currentUser && (int)$row['user_two'] !== $currentUser) {
                return ['error' => 'not_allowed'];
            }
            return $row;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetMessageForAction failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    private function RL_ChatStorageUrl(string $path): string
    {
        $path = trim($path);
        if ($path === '') {
            return '';
        }
        if (function_exists('storage_url')) {
            try {
                return (string)storage_url($path);
            } catch (\Throwable $__) {}
        }
        $base = isset($GLOBALS['base_url']) ? rtrim((string)$GLOBALS['base_url'], '/') : '';
        return ($base !== '' ? $base . '/' : '') . ltrim($path, '/');
    }

    private function RL_DecorateChatRows(array $rows, int $currentUser, int $targetUser): array
    {
        if (empty($rows)) {
            return [];
        }

        $messageIds = [];
        $replyIds = [];
        foreach ($rows as $row) {
            $mid = (int)($row['message_id'] ?? 0);
            if ($mid > 0) {
                $messageIds[] = $mid;
            }
            $rid = (int)($row['reply_to_message_id'] ?? 0);
            if ($rid > 0) {
                $replyIds[] = $rid;
            }
        }

        $deletedForMe = [];
        $reactionMap = [];
        $myReactionMap = [];
        $replyMap = [];
        $paidMediaMap = [];
        $paidUnlockMap = [];

        if (!empty($messageIds)) {
            $in = implode(',', array_map('intval', array_values(array_unique($messageIds))));
            try {
                $st = $this->db->prepare('SELECT message_id FROM i_chat_deletions WHERE user_id = :uid AND message_id IN (' . $in . ')');
                $st->bindValue(':uid', $currentUser, \PDO::PARAM_INT);
                $st->execute();
                foreach ($st->fetchAll(\PDO::FETCH_COLUMN, 0) ?: [] as $mid) {
                    $deletedForMe[(int)$mid] = true;
                }
            } catch (\Throwable $__) {}

            try {
                $st = $this->db->query('SELECT message_id, reaction, COUNT(*) AS total FROM i_chat_reactions WHERE message_id IN (' . $in . ') GROUP BY message_id, reaction ORDER BY total DESC, reaction ASC');
                foreach ($st->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $r) {
                    $mid = (int)($r['message_id'] ?? 0);
                    if ($mid <= 0) { continue; }
                    if (!isset($reactionMap[$mid])) { $reactionMap[$mid] = []; }
                    $reactionMap[$mid][] = [
                        'reaction' => (string)($r['reaction'] ?? ''),
                        'count' => (int)($r['total'] ?? 0),
                    ];
                }
            } catch (\Throwable $__) {}

            try {
                $st = $this->db->prepare('SELECT message_id, reaction FROM i_chat_reactions WHERE user_id = :uid AND message_id IN (' . $in . ')');
                $st->bindValue(':uid', $currentUser, \PDO::PARAM_INT);
                $st->execute();
                foreach ($st->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $r) {
                    $myReactionMap[(int)($r['message_id'] ?? 0)] = (string)($r['reaction'] ?? '');
                }
            } catch (\Throwable $__) {}

            try {
                $st = $this->db->query('SELECT paid_media_id, message_id, creator_id, recipient_id, file_path, preview_path, media_type, price, currency, status FROM i_chat_paid_media WHERE message_id IN (' . $in . ')');
                foreach ($st->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $r) {
                    $paidMediaMap[(int)($r['message_id'] ?? 0)] = $r;
                }
            } catch (\Throwable $__) {}

            try {
                $st = $this->db->prepare('SELECT paid_media_id, message_id FROM i_chat_paid_media_unlocks WHERE buyer_id = :uid AND status = "succeeded" AND message_id IN (' . $in . ')');
                $st->bindValue(':uid', $currentUser, \PDO::PARAM_INT);
                $st->execute();
                foreach ($st->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $r) {
                    $paidUnlockMap[(int)($r['message_id'] ?? 0)] = true;
                }
            } catch (\Throwable $__) {}
        }

        if (!empty($replyIds)) {
            $in = implode(',', array_map('intval', array_values(array_unique($replyIds))));
            try {
                $st = $this->db->query('SELECT message_id, user_one, user_two, message, file, message_type, deleted_at FROM i_messages WHERE message_id IN (' . $in . ')');
                foreach ($st->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $r) {
                    if (!$this->RL_IsConversationMessage($r, $currentUser, $targetUser)) {
                        continue;
                    }
                    $text = trim((string)($r['message'] ?? ''));
                    $file = trim((string)($r['file'] ?? ''));
                    if ((int)($r['deleted_at'] ?? 0) > 0) {
                        $text = 'Deleted message';
                    } elseif ($text === '' && $file !== '') {
                        $text = preg_match('/^post:\d+$/i', $file) ? 'Shared post' : 'Attachment';
                    }
                    $replyMap[(int)($r['message_id'] ?? 0)] = [
                        'message_id' => (int)($r['message_id'] ?? 0),
                        'from_id' => (int)($r['user_one'] ?? 0),
                        'is_outgoing' => (int)($r['user_one'] ?? 0) === $currentUser,
                        'message' => mb_substr($text, 0, 140),
                    ];
                }
            } catch (\Throwable $__) {}
        }

        $out = [];
        foreach ($rows as $row) {
            $mid = (int)($row['message_id'] ?? 0);
            if ($mid > 0 && isset($deletedForMe[$mid])) {
                continue;
            }

            $isDeleted = (int)($row['deleted_at'] ?? 0) > 0;
            if ($isDeleted) {
                $row['message'] = 'This message was deleted';
                $row['file'] = '';
                $row['file_kind'] = '';
            } else {
                $row = $this->RL_DecorateChatTipRow($row);
            }

            $replyTo = (int)($row['reply_to_message_id'] ?? 0);
            $row['reply'] = ($replyTo > 0 && isset($replyMap[$replyTo])) ? $replyMap[$replyTo] : null;
            $row['reactions'] = $reactionMap[$mid] ?? [];
            $row['my_reaction'] = $myReactionMap[$mid] ?? '';
            $row['is_deleted'] = $isDeleted;
            $row['can_delete_everyone'] = ((int)($row['from_id'] ?? $row['user_one'] ?? 0) === $currentUser) && !$isDeleted;
            if (isset($paidMediaMap[$mid]) && !$isDeleted) {
                $pm = $paidMediaMap[$mid];
                $creatorId = (int)($pm['creator_id'] ?? 0);
                $isOwner = $creatorId === $currentUser;
                $isUnlocked = $isOwner || isset($paidUnlockMap[$mid]);
                $filePath = (string)($pm['file_path'] ?? '');
                $previewPath = (string)($pm['preview_path'] ?? '');
                $row['message_type'] = 'paid_media';
                $row['paid_media'] = [
                    'paid_media_id' => (int)($pm['paid_media_id'] ?? 0),
                    'message_id' => $mid,
                    'creator_id' => $creatorId,
                    'recipient_id' => (int)($pm['recipient_id'] ?? 0),
                    'media_type' => (string)($pm['media_type'] ?? 'image'),
                    'price' => number_format((float)($pm['price'] ?? 0), 2, '.', ''),
                    'currency' => strtoupper((string)($pm['currency'] ?? 'USD')),
                    'is_owner' => $isOwner,
                    'is_unlocked' => $isUnlocked,
                    'file_url' => $isUnlocked ? $this->RL_ChatStorageUrl($filePath) : '',
                    'preview_url' => $previewPath !== '' ? $this->RL_ChatStorageUrl($previewPath) : '',
                    'status' => (string)($pm['status'] ?? 'active'),
                ];
                if (!$isUnlocked) {
                    $row['file'] = '';
                    $row['file_kind'] = '';
                } else {
                    $row['file'] = $filePath;
                    $row['file_kind'] = (string)($pm['media_type'] ?? '');
                }
            }
            $out[] = $row;
        }

        return $out;
    }

    public function RL_ReactToMessage(int $currentUser, int $messageId, string $reaction): array
    {
        $row = $this->RL_GetMessageForAction($currentUser, $messageId);
        if (isset($row['error'])) {
            return $row;
        }

        $reaction = trim($reaction);
        $allowed = ['heart', 'like', 'fire', 'laugh', 'wow', 'sad'];
        try {
            if ($reaction === '' || $reaction === 'none') {
                $st = $this->db->prepare('DELETE FROM i_chat_reactions WHERE message_id = :mid AND user_id = :uid');
                $st->execute([':mid' => $messageId, ':uid' => $currentUser]);
                return ['ok' => true, 'reaction' => ''];
            }
            if (!in_array($reaction, $allowed, true)) {
                return ['error' => 'invalid_reaction'];
            }
            $currentStmt = $this->db->prepare('SELECT reaction FROM i_chat_reactions WHERE message_id = :mid AND user_id = :uid LIMIT 1');
            $currentStmt->execute([':mid' => $messageId, ':uid' => $currentUser]);
            $currentReaction = (string)($currentStmt->fetchColumn() ?: '');
            if ($currentReaction === $reaction) {
                $st = $this->db->prepare('DELETE FROM i_chat_reactions WHERE message_id = :mid AND user_id = :uid');
                $st->execute([':mid' => $messageId, ':uid' => $currentUser]);
                return ['ok' => true, 'reaction' => '', 'removed' => true];
            }
            $now = time();
            $st = $this->db->prepare('INSERT INTO i_chat_reactions (message_id, user_id, reaction, created_at, updated_at)
                                      VALUES (:mid, :uid, :reaction, :now, NULL)
                                      ON DUPLICATE KEY UPDATE reaction = VALUES(reaction), updated_at = VALUES(created_at)');
            $st->execute([':mid' => $messageId, ':uid' => $currentUser, ':reaction' => $reaction, ':now' => $now]);
            $messageOwner = (int)($row['user_one'] ?? 0);
            if ($messageOwner > 0 && $messageOwner !== $currentUser && method_exists($this, 'RL_CreateMessageReactionNotification')) {
                $excerpt = trim((string)($row['message'] ?? ''));
                if ($excerpt === '' && !empty($row['file'])) {
                    $excerpt = (string)($row['message_type'] ?? 'attachment');
                }
                try {
                    $this->RL_CreateMessageReactionNotification($currentUser, $messageOwner, $messageId, $reaction, $excerpt, $now);
                } catch (\Throwable $notifyError) {
                    if (method_exists($this, 'logError')) {
                        $this->logError('message_reaction notification failed: ' . $notifyError->getMessage());
                    }
                }
            }
            return ['ok' => true, 'reaction' => $reaction, 'removed' => false];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_ReactToMessage failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    public function RL_DeleteChatMessage(int $currentUser, int $messageId, string $scope = 'self'): array
    {
        $row = $this->RL_GetMessageForAction($currentUser, $messageId);
        if (isset($row['error'])) {
            return $row;
        }
        $scope = $scope === 'everyone' ? 'everyone' : 'self';
        try {
            $now = time();
            if ($scope === 'everyone') {
                if ((int)$row['user_one'] !== $currentUser) {
                    return ['error' => 'not_allowed'];
                }
                $st = $this->db->prepare('UPDATE i_messages SET message = "", file = "", deleted_at = :now, deleted_by = :deleted_by WHERE message_id = :mid AND user_one = :sender');
                $st->execute([':now' => $now, ':deleted_by' => $currentUser, ':mid' => $messageId, ':sender' => $currentUser]);
                return ['ok' => true, 'scope' => 'everyone'];
            }

            $st = $this->db->prepare('INSERT INTO i_chat_deletions (message_id, user_id, deletion_scope, created_at)
                                      VALUES (:mid, :uid, "self", :now)
                                      ON DUPLICATE KEY UPDATE deletion_scope = VALUES(deletion_scope), created_at = VALUES(created_at)');
            $st->execute([':mid' => $messageId, ':uid' => $currentUser, ':now' => $now]);
            return ['ok' => true, 'scope' => 'self'];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_DeleteChatMessage failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    public function RL_ReportChatMessage(int $currentUser, int $messageId, string $reason, string $note = ''): array
    {
        $row = $this->RL_GetMessageForAction($currentUser, $messageId);
        if (isset($row['error'])) {
            return $row;
        }
        $reportedUser = ((int)$row['user_one'] === $currentUser) ? (int)$row['user_two'] : (int)$row['user_one'];
        $reason = trim($reason) !== '' ? mb_substr(trim($reason), 0, 80) : 'other';
        $note = mb_substr(trim($note), 0, 1000);
        try {
            $st = $this->db->prepare('INSERT INTO i_chat_reports (message_id, reporter_id, reported_user_id, reason, note, status, created_at)
                                      VALUES (:mid, :reporter, :reported, :reason, :note, "open", :now)');
            $st->execute([
                ':mid' => $messageId,
                ':reporter' => $currentUser,
                ':reported' => $reportedUser,
                ':reason' => $reason,
                ':note' => $note,
                ':now' => time(),
            ]);
            return ['ok' => true];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_ReportChatMessage failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    private function RL_EnsureConversationStateTable(): void
    {
        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS `i_chat_conversation_states` (
                `state_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id` int UNSIGNED NOT NULL,
                `partner_id` int UNSIGNED NOT NULL,
                `cleared_at` int UNSIGNED DEFAULT NULL,
                `deleted_at` int UNSIGNED DEFAULT NULL,
                `pinned_at` int UNSIGNED DEFAULT NULL,
                `muted_until` int UNSIGNED DEFAULT NULL,
                `created_at` int UNSIGNED NOT NULL,
                `updated_at` int UNSIGNED DEFAULT NULL,
                PRIMARY KEY (`state_id`),
                UNIQUE KEY `uniq_user_partner` (`user_id`,`partner_id`),
                KEY `idx_user_pinned` (`user_id`,`pinned_at`),
                KEY `idx_user_deleted` (`user_id`,`deleted_at`),
                KEY `idx_partner` (`partner_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_EnsureConversationStateTable failed: ' . $e->getMessage());
            }
        }
    }

    public function RL_GetConversationState(int $currentUser, int $targetUser): array
    {
        $currentUser = (int)$currentUser;
        $targetUser = (int)$targetUser;
        if ($currentUser <= 0 || $targetUser <= 0) {
            return ['cleared_at' => 0, 'deleted_at' => 0, 'pinned_at' => 0, 'muted_until' => 0];
        }
        $this->RL_EnsureConversationStateTable();
        try {
            $st = $this->db->prepare('SELECT cleared_at, deleted_at, pinned_at, muted_until
                                      FROM i_chat_conversation_states
                                      WHERE user_id = :user_id AND partner_id = :partner_id
                                      LIMIT 1');
            $st->execute([':user_id' => $currentUser, ':partner_id' => $targetUser]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                return ['cleared_at' => 0, 'deleted_at' => 0, 'pinned_at' => 0, 'muted_until' => 0];
            }
            return [
                'cleared_at' => (int)($row['cleared_at'] ?? 0),
                'deleted_at' => (int)($row['deleted_at'] ?? 0),
                'pinned_at' => (int)($row['pinned_at'] ?? 0),
                'muted_until' => (int)($row['muted_until'] ?? 0),
            ];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetConversationState failed: ' . $e->getMessage());
            }
            return ['cleared_at' => 0, 'deleted_at' => 0, 'pinned_at' => 0, 'muted_until' => 0];
        }
    }

    private function RL_ConversationVisibilityCutoff(int $currentUser, int $targetUser): int
    {
        $state = $this->RL_GetConversationState($currentUser, $targetUser);
        return max((int)($state['cleared_at'] ?? 0), (int)($state['deleted_at'] ?? 0));
    }

    private function RL_UpsertConversationState(int $currentUser, int $targetUser, array $fields): array
    {
        $currentUser = (int)$currentUser;
        $targetUser = (int)$targetUser;
        if ($currentUser <= 0 || $targetUser <= 0 || $currentUser === $targetUser) {
            return ['error' => 'invalid_input'];
        }
        $allowed = ['cleared_at', 'deleted_at', 'pinned_at', 'muted_until'];
        $payload = [];
        foreach ($allowed as $key) {
            if (array_key_exists($key, $fields)) {
                $value = $fields[$key];
                $payload[$key] = $value === null ? null : max(0, (int)$value);
            }
        }
        if (!$payload) {
            return ['error' => 'invalid_input'];
        }
        $this->RL_EnsureConversationStateTable();
        $now = time();
        $columns = array_keys($payload);
        $insertColumns = array_merge(['user_id', 'partner_id'], $columns, ['created_at', 'updated_at']);
        $placeholders = array_map(static function ($column) { return ':' . $column; }, $insertColumns);
        $updates = array_map(static function ($column) { return '`' . $column . '` = VALUES(`' . $column . '`)'; }, $columns);
        $updates[] = '`updated_at` = VALUES(`updated_at`)';
        $sql = 'INSERT INTO i_chat_conversation_states (`' . implode('`,`', $insertColumns) . '`)
                VALUES (' . implode(',', $placeholders) . ')
                ON DUPLICATE KEY UPDATE ' . implode(', ', $updates);
        try {
            $st = $this->db->prepare($sql);
            $st->bindValue(':user_id', $currentUser, \PDO::PARAM_INT);
            $st->bindValue(':partner_id', $targetUser, \PDO::PARAM_INT);
            foreach ($payload as $key => $value) {
                if ($value === null) {
                    $st->bindValue(':' . $key, null, \PDO::PARAM_NULL);
                } else {
                    $st->bindValue(':' . $key, $value, \PDO::PARAM_INT);
                }
            }
            $st->bindValue(':created_at', $now, \PDO::PARAM_INT);
            $st->bindValue(':updated_at', $now, \PDO::PARAM_INT);
            $st->execute();
            return ['ok' => true, 'state' => $this->RL_GetConversationState($currentUser, $targetUser)];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_UpsertConversationState failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    public function RL_ClearConversationForUser(int $currentUser, int $targetUser): array
    {
        return $this->RL_UpsertConversationState($currentUser, $targetUser, [
            'cleared_at' => time(),
            'deleted_at' => null,
        ]);
    }

    public function RL_DeleteConversationForUser(int $currentUser, int $targetUser): array
    {
        $now = time();
        return $this->RL_UpsertConversationState($currentUser, $targetUser, [
            'cleared_at' => $now,
            'deleted_at' => $now,
        ]);
    }

    public function RL_SetConversationPinned(int $currentUser, int $targetUser, bool $pinned): array
    {
        return $this->RL_UpsertConversationState($currentUser, $targetUser, [
            'pinned_at' => $pinned ? time() : null,
        ]);
    }

    public function RL_BlockConversationUser(int $currentUser, int $targetUser): array
    {
        $currentUser = (int)$currentUser;
        $targetUser = (int)$targetUser;
        if ($currentUser <= 0 || $targetUser <= 0 || $currentUser === $targetUser) {
            return ['error' => 'invalid_input'];
        }
        try {
            $st = $this->db->prepare('INSERT INTO i_user_blocks (blocker_id, blocked_id, source, reason, created_at)
                                      VALUES (:blocker, :blocked, "chat", "conversation_menu", :created_at)
                                      ON DUPLICATE KEY UPDATE source = VALUES(source), reason = VALUES(reason)');
            $st->execute([
                ':blocker' => $currentUser,
                ':blocked' => $targetUser,
                ':created_at' => time(),
            ]);
            return ['ok' => true];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_BlockConversationUser failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    public function RL_ReportConversation(int $currentUser, int $targetUser, string $reason, string $note = ''): array
    {
        $currentUser = (int)$currentUser;
        $targetUser = (int)$targetUser;
        $reason = trim($reason) !== '' ? mb_substr(trim($reason), 0, 80) : 'conversation';
        $note = mb_substr(trim($note), 0, 1000);
        if ($currentUser <= 0 || $targetUser <= 0 || $currentUser === $targetUser) {
            return ['error' => 'invalid_input'];
        }
        try {
            $meta = json_encode([
                'scope' => 'conversation',
                'reported_at' => time(),
            ], JSON_UNESCAPED_SLASHES);
            $st = $this->db->prepare('INSERT INTO i_chat_reports (message_id, reporter_id, reported_user_id, reason, note, status, metadata, created_at)
                                      VALUES (NULL, :reporter, :reported, :reason, :note, "open", :metadata, :created_at)');
            $st->execute([
                ':reporter' => $currentUser,
                ':reported' => $targetUser,
                ':reason' => $reason,
                ':note' => $note,
                ':metadata' => $meta,
                ':created_at' => time(),
            ]);
            return ['ok' => true, 'report_id' => (int)$this->db->lastInsertId()];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_ReportConversation failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    public function RL_BuildConversationDownload(int $currentUser, int $targetUser): array
    {
        $pair = $this->RL_GetConversationUsers($currentUser, $targetUser);
        $self = $pair['self'] ?? [];
        $other = $pair['other'] ?? [];
        $selfName = trim((string)($self['user_fullname'] ?? '')) ?: (string)($self['username'] ?? 'You');
        $otherName = trim((string)($other['user_fullname'] ?? '')) ?: (string)($other['username'] ?? 'User');
        $rows = $this->RL_GetConversationMessages($currentUser, $targetUser);
        $lines = [];
        $lines[] = 'CreatorPulse chat export';
        $lines[] = 'Conversation: ' . $selfName . ' / ' . $otherName;
        $lines[] = 'Exported at: ' . gmdate('c');
        $lines[] = str_repeat('-', 48);
        foreach ($rows as $row) {
            $sender = ((int)($row['from_id'] ?? 0) === $currentUser) ? $selfName : $otherName;
            $time = (int)($row['message_time'] ?? 0);
            $message = trim((string)($row['message'] ?? ''));
            if ($message === '' && !empty($row['file'])) {
                $message = '[Attachment] ' . (string)$row['file'];
            }
            if ($message === '') {
                $message = '[' . (string)($row['message_type'] ?? 'message') . ']';
            }
            $lines[] = '[' . ($time > 0 ? gmdate('Y-m-d H:i:s', $time) : 'unknown time') . '] ' . $sender . ': ' . $message;
        }
        $filenameUser = preg_replace('/[^a-z0-9_-]+/i', '-', (string)($other['username'] ?? $targetUser));
        $filenameUser = trim((string)$filenameUser, '-') ?: 'conversation';
        return [
            'ok' => true,
            'filename' => 'creatorpulse-chat-' . strtolower($filenameUser) . '-' . gmdate('Ymd-His') . '.txt',
            'content' => implode("\n", $lines) . "\n",
        ];
    }

    public function RL_CanReceiveChatTip(int $recipientId): bool
    {
        $recipientId = (int)$recipientId;
        if ($recipientId <= 0) {
            return false;
        }
        try {
            $st = $this->db->prepare("SELECT creator_status FROM i_users WHERE user_id = :uid LIMIT 1");
            $st->bindValue(':uid', $recipientId, \PDO::PARAM_INT);
            $st->execute();
            return strtolower((string)($st->fetchColumn() ?: '')) === 'approved';
        } catch (\Throwable $__) {
            return false;
        }
    }

    private function RL_FormatChatCurrency(float $amount, string $currencyCode = 'USD'): string
    {
        $currencyCode = strtoupper(substr(preg_replace('/[^A-Z]/i', '', $currencyCode) ?: 'USD', 0, 10));
        $currencySymbol = '';
        $currencyMap = [];
        if (isset($GLOBALS['currencies']) && is_array($GLOBALS['currencies'])) {
            $currencyMap = $GLOBALS['currencies'];
        } elseif (isset($GLOBALS['currencys']) && is_array($GLOBALS['currencys'])) {
            $currencyMap = $GLOBALS['currencys'];
        }
        if (isset($currencyMap[$currencyCode]) && is_string($currencyMap[$currencyCode])) {
            $currencySymbol = (string)$currencyMap[$currencyCode];
        }

        if (function_exists('dz_format_currency')) {
            try {
                $settings = isset($GLOBALS['currency_format_settings']) && is_array($GLOBALS['currency_format_settings'])
                    ? $GLOBALS['currency_format_settings']
                    : null;
                return dz_format_currency($amount, $currencyCode, $currencySymbol !== '' ? $currencySymbol : null, $settings);
            } catch (\Throwable $__) {}
        }

        $amountText = number_format($amount, 2, '.', '');
        if ($currencySymbol !== '' && $currencySymbol !== $currencyCode && mb_strlen($currencySymbol) <= 4) {
            return $currencySymbol . $amountText;
        }
        return $amountText . ' ' . $currencyCode;
    }

    private function RL_DecorateChatTipRow(array $row): array
    {
        if (strtolower((string)($row['message_type'] ?? '')) !== 'tip') {
            return $row;
        }

        $metadata = [];
        $rawMeta = $row['metadata'] ?? null;
        if (is_string($rawMeta) && trim($rawMeta) !== '') {
            $decoded = json_decode($rawMeta, true);
            if (is_array($decoded)) {
                $metadata = $decoded;
            }
        } elseif (is_array($rawMeta)) {
            $metadata = $rawMeta;
        }

        $message = (string)($row['message'] ?? '');
        $amount = isset($metadata['amount']) && is_numeric($metadata['amount']) ? (float)$metadata['amount'] : null;
        if ($amount === null && preg_match('/([0-9]+(?:[\\.,][0-9]+)?)/', $message, $match)) {
            $amount = (float)str_replace(',', '.', $match[1]);
        }

        $currency = isset($metadata['currency']) ? strtoupper((string)$metadata['currency']) : '';
        if ($currency === '' && preg_match('/\\b([A-Z]{3,10})\\b/', $message, $match)) {
            $currency = strtoupper((string)$match[1]);
        }
        if ($currency === '') {
            $currency = isset($GLOBALS['currency']) ? strtoupper((string)$GLOBALS['currency']) : 'USD';
        }

        $display = isset($metadata['amount_display']) && is_string($metadata['amount_display']) && trim($metadata['amount_display']) !== ''
            ? trim((string)$metadata['amount_display'])
            : $this->RL_FormatChatCurrency((float)($amount ?? 0), $currency);

        $row['tip'] = [
            'amount' => $amount !== null ? number_format((float)$amount, 2, '.', '') : '',
            'currency' => $currency,
            'amount_display' => $display,
            'provider' => isset($metadata['provider']) ? (string)$metadata['provider'] : 'wallet',
            'reference' => isset($metadata['reference']) ? (string)$metadata['reference'] : '',
        ];
        $row['message'] = 'Sent a tip: ' . $display;

        return $row;
    }

    public function RL_SendChatWalletTip(int $buyerId, int $recipientId, float $amount, string $currency = 'USD', ?string $reference = null): array
    {
        $buyerId = (int)$buyerId;
        $recipientId = (int)$recipientId;
        $amount = round((float)$amount, 2);
        $currency = strtoupper(substr(preg_replace('/[^A-Z]/i', '', $currency) ?: 'USD', 0, 3));
        if ($buyerId <= 0 || $recipientId <= 0 || $buyerId === $recipientId || $amount <= 0) {
            return ['error' => 'invalid_input'];
        }
        if (!$this->RL_CanReceiveChatTip($recipientId)) {
            return ['error' => 'recipient_not_creator'];
        }
        if ($amount < 1 || $amount > 500) {
            return ['error' => 'invalid_amount'];
        }
        if (!$reference) {
            try {
                $reference = 'CTIP' . strtoupper(bin2hex(random_bytes(8)));
            } catch (\Throwable $__) {
                $reference = 'CTIP' . strtoupper(substr(sha1((string)microtime(true) . ':' . $buyerId . ':' . $recipientId), 0, 16));
            }
        }

        $db = $this->db;
        try {
            $db->beginTransaction();

            $buyer = $db->prepare('SELECT wallet FROM i_users WHERE user_id = :buyer FOR UPDATE');
            $buyer->execute([':buyer' => $buyerId]);
            $buyerRow = $buyer->fetch(\PDO::FETCH_ASSOC);
            if (!$buyerRow) {
                $db->rollBack();
                return ['error' => 'buyer_not_found'];
            }
            $balance = (float)($buyerRow['wallet'] ?? 0);
            if ($balance < $amount) {
                $db->rollBack();
                return ['error' => 'insufficient_wallet', 'balance' => $balance, 'required' => $amount];
            }

            $recipient = $db->prepare("SELECT creator_status FROM i_users WHERE user_id = :recipient FOR UPDATE");
            $recipient->execute([':recipient' => $recipientId]);
            $recipientStatus = strtolower((string)($recipient->fetchColumn() ?: ''));
            if ($recipientStatus !== 'approved') {
                $db->rollBack();
                return ['error' => 'recipient_not_creator'];
            }

            $now = time();
            $newBalance = number_format($balance - $amount, 2, '.', '');
            $amountText = number_format($amount, 2, '.', '');
            $amountDisplay = $this->RL_FormatChatCurrency($amount, $currency);
            $meta = [
                'amount' => $amountText,
                'currency' => $currency,
                'amount_display' => $amountDisplay,
                'provider' => 'wallet',
                'reference' => $reference,
            ];
            $messageText = 'Sent a tip: ' . $amountDisplay;

            $db->prepare('UPDATE i_users SET wallet = :wallet WHERE user_id = :buyer_id')
                ->execute([':wallet' => $newBalance, ':buyer_id' => $buyerId]);
            $db->prepare('UPDATE i_users SET earned = COALESCE(earned,0) + :amount WHERE user_id = :recipient_id')
                ->execute([':amount' => $amountText, ':recipient_id' => $recipientId]);

            $message = $db->prepare('INSERT INTO i_messages (user_one, user_two, message, message_type, metadata, message_time, delivered_at, read_at)
                                     VALUES (:buyer_id, :recipient_id, :message, "tip", :metadata, :created_at, NULL, NULL)');
            $message->execute([
                ':buyer_id' => $buyerId,
                ':recipient_id' => $recipientId,
                ':message' => $messageText,
                ':metadata' => json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                ':created_at' => $now,
            ]);
            $messageId = (int)$db->lastInsertId();

            $tip = $db->prepare('INSERT INTO i_chat_tips (message_id, buyer_id, recipient_id, provider, reference, amount, currency, status, fee_amount, tax_amount, net_amount, raw_payload, credited_at, created_at, updated_at)
                                 VALUES (:message_id, :buyer_id, :recipient_id, "wallet", :reference, :amount, :currency, "succeeded", 0.00, 0.00, :net_amount, :payload, :credited_at, :created_at, NULL)');
            $tip->execute([
                ':message_id' => $messageId,
                ':buyer_id' => $buyerId,
                ':recipient_id' => $recipientId,
                ':reference' => $reference,
                ':amount' => $amountText,
                ':currency' => $currency,
                ':net_amount' => $amountText,
                ':payload' => json_encode(['source' => 'wallet'], JSON_UNESCAPED_SLASHES),
                ':credited_at' => $now,
                ':created_at' => $now,
            ]);

            $ledger = $db->prepare('INSERT INTO i_wallet_ledger (user_id, type, amount_minor, currency, ref_provider, ref_id, meta, created_at)
                                    VALUES (:user_id, "spend", :amount_minor, :currency, "chat_tip", :ref_id, :meta, :created_at)');
            $ledger->execute([
                ':user_id' => $buyerId,
                ':amount_minor' => (int)round($amount * 100),
                ':currency' => $currency,
                ':ref_id' => $reference,
                ':meta' => json_encode(['recipient_id' => $recipientId, 'message_id' => $messageId], JSON_UNESCAPED_SLASHES),
                ':created_at' => $now,
            ]);

            $db->commit();

            $tz = new \DateTimeZone($this->RL_GetPreferredTimezone($buyerId));
            $dt = (new \DateTimeImmutable('@' . $now))->setTimezone($tz);
            $row = [
                'message_id' => $messageId,
                'from_id' => $buyerId,
                'to_id' => $recipientId,
                'message' => $messageText,
                'message_type' => 'tip',
                'message_time' => $now,
                'message_time_hm' => $dt->format('H:i'),
                'direction' => 'outgoing',
                'avatar' => $this->RL_userAvatar($buyerId),
                'ymd' => $dt->format('Y-m-d'),
                'file' => '',
                'file_kind' => '',
                'reply_to_message_id' => 0,
                'delivered_at' => null,
                'read_at' => null,
                'deleted_at' => null,
                'deleted_by' => null,
            ];
            $decorated = $this->RL_DecorateChatRows([$row], $buyerId, $recipientId);
            return [
                'ok' => true,
                'reference' => $reference,
                'new_balance' => (float)$newBalance,
                'data' => $decorated[0] ?? $row,
            ];
        } catch (\Throwable $e) {
            try {
                if ($db->inTransaction()) {
                    $db->rollBack();
                }
            } catch (\Throwable $__) {}
            if (method_exists($this, 'logError')) {
                $this->logError('RL_SendChatWalletTip failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    public function RL_CanSendPaidChatMedia(int $creatorId): bool
    {
        return $this->RL_CanReceiveChatTip($creatorId);
    }

    public function RL_SendPaidChatMedia(int $creatorId, int $recipientId, string $fileRelative, string $mediaType, float $price, string $currency = 'USD'): array
    {
        $creatorId = (int)$creatorId;
        $recipientId = (int)$recipientId;
        $fileRelative = trim($fileRelative);
        $mediaType = in_array($mediaType, ['image', 'video'], true) ? $mediaType : 'image';
        $price = round((float)$price, 2);
        $currency = strtoupper(substr(preg_replace('/[^A-Z]/i', '', $currency) ?: 'USD', 0, 3));
        if ($creatorId <= 0 || $recipientId <= 0 || $creatorId === $recipientId || $fileRelative === '' || $price <= 0) {
            return ['error' => 'invalid_input'];
        }
        if (!empty($this->RL_GetChatBlockStatus($creatorId, $recipientId)['blocked'])) {
            return ['error' => 'user_blocked'];
        }
        if (!$this->RL_CanSendPaidChatMedia($creatorId)) {
            return ['error' => 'creator_required'];
        }
        if ($price < 1 || $price > 500) {
            return ['error' => 'invalid_price'];
        }

        try {
            $now = time();
            $priceText = number_format($price, 2, '.', '');
            $meta = [
                'price' => $priceText,
                'currency' => $currency,
                'media_type' => $mediaType,
            ];
            $messageText = 'Paid media';
            $st = $this->db->prepare('INSERT INTO i_messages (user_one, user_two, message, message_type, metadata, message_time, delivered_at, read_at, file)
                                      VALUES (:creator, :recipient, :message, "paid_media", :metadata, :created, NULL, NULL, "")');
            $st->execute([
                ':creator' => $creatorId,
                ':recipient' => $recipientId,
                ':message' => $messageText,
                ':metadata' => json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                ':created' => $now,
            ]);
            $messageId = (int)$this->db->lastInsertId();
            $this->RL_RegisterMessageRequestForMessage($creatorId, $recipientId, $messageId);

            $pm = $this->db->prepare('INSERT INTO i_chat_paid_media (message_id, creator_id, recipient_id, file_path, preview_path, media_type, price, currency, status, metadata, created_at, updated_at)
                                      VALUES (:message_id, :creator, :recipient, :file_path, NULL, :media_type, :price, :currency, "active", :metadata, :created, NULL)');
            $pm->execute([
                ':message_id' => $messageId,
                ':creator' => $creatorId,
                ':recipient' => $recipientId,
                ':file_path' => $fileRelative,
                ':media_type' => $mediaType,
                ':price' => $priceText,
                ':currency' => $currency,
                ':metadata' => json_encode(['source' => 'chat'], JSON_UNESCAPED_SLASHES),
                ':created' => $now,
            ]);

            try {
                $this->db->prepare(
                    'UPDATE i_messages
                       SET delivered_at = IFNULL(delivered_at, :now), read_at = :now
                     WHERE user_one = :other AND user_two = :me AND (read_at IS NULL OR read_at = 0)'
                )->execute([':now' => $now, ':other' => $recipientId, ':me' => $creatorId]);
            } catch (\Throwable $__) {}

            $tz = new \DateTimeZone($this->RL_GetPreferredTimezone($creatorId));
            $dt = (new \DateTimeImmutable('@' . $now))->setTimezone($tz);
            $row = [
                'message_id' => $messageId,
                'from_id' => $creatorId,
                'to_id' => $recipientId,
                'message' => $messageText,
                'message_type' => 'paid_media',
                'message_time' => $now,
                'message_time_hm' => $dt->format('H:i'),
                'direction' => 'outgoing',
                'avatar' => $this->RL_userAvatar($creatorId),
                'ymd' => $dt->format('Y-m-d'),
                'file' => '',
                'file_kind' => '',
                'reply_to_message_id' => 0,
                'delivered_at' => null,
                'read_at' => null,
                'deleted_at' => null,
                'deleted_by' => null,
            ];
            $decorated = $this->RL_DecorateChatRows([$row], $creatorId, $recipientId);
            return ['ok' => true, 'data' => $decorated[0] ?? $row];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_SendPaidChatMedia failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    public function RL_UnlockChatPaidMedia(int $buyerId, int $messageId, ?string $reference = null): array
    {
        $buyerId = (int)$buyerId;
        $messageId = (int)$messageId;
        if ($buyerId <= 0 || $messageId <= 0) {
            return ['error' => 'invalid_input'];
        }
        if (!$reference) {
            try {
                $reference = 'CPM' . strtoupper(bin2hex(random_bytes(8)));
            } catch (\Throwable $__) {
                $reference = 'CPM' . strtoupper(substr(sha1((string)microtime(true) . ':' . $buyerId . ':' . $messageId), 0, 16));
            }
        }

        $db = $this->db;
        try {
            $db->beginTransaction();

            $pmSt = $db->prepare('SELECT * FROM i_chat_paid_media WHERE message_id = :message_id AND status = "active" FOR UPDATE');
            $pmSt->execute([':message_id' => $messageId]);
            $paid = $pmSt->fetch(\PDO::FETCH_ASSOC);
            if (!$paid) {
                $db->rollBack();
                return ['error' => 'paid_media_not_found'];
            }

            $creatorId = (int)($paid['creator_id'] ?? 0);
            $recipientId = (int)($paid['recipient_id'] ?? 0);
            $amount = round((float)($paid['price'] ?? 0), 2);
            $currency = strtoupper((string)($paid['currency'] ?? 'USD'));
            if ($recipientId !== $buyerId || $creatorId <= 0 || $buyerId === $creatorId || $amount <= 0) {
                $db->rollBack();
                return ['error' => 'not_allowed'];
            }

            $existing = $db->prepare('SELECT unlock_id FROM i_chat_paid_media_unlocks WHERE paid_media_id = :paid_media_id AND buyer_id = :buyer_id AND status = "succeeded" LIMIT 1');
            $existing->execute([':paid_media_id' => (int)$paid['paid_media_id'], ':buyer_id' => $buyerId]);
            if ($existing->fetchColumn()) {
                $db->commit();
                return [
                    'ok' => true,
                    'already_unlocked' => true,
                    'media_url' => $this->RL_ChatStorageUrl((string)$paid['file_path']),
                    'media_type' => (string)$paid['media_type'],
                ];
            }

            $buyer = $db->prepare('SELECT wallet FROM i_users WHERE user_id = :buyer FOR UPDATE');
            $buyer->execute([':buyer' => $buyerId]);
            $buyerRow = $buyer->fetch(\PDO::FETCH_ASSOC);
            if (!$buyerRow) {
                $db->rollBack();
                return ['error' => 'buyer_not_found'];
            }
            $balance = (float)($buyerRow['wallet'] ?? 0);
            if ($balance < $amount) {
                $db->rollBack();
                return ['error' => 'insufficient_wallet', 'balance' => $balance, 'required' => $amount];
            }

            $now = time();
            $amountText = number_format($amount, 2, '.', '');
            $newBalance = number_format($balance - $amount, 2, '.', '');
            $db->prepare('UPDATE i_users SET wallet = :wallet WHERE user_id = :buyer_id')
                ->execute([':wallet' => $newBalance, ':buyer_id' => $buyerId]);
            $db->prepare('UPDATE i_users SET earned = COALESCE(earned,0) + :amount WHERE user_id = :creator_id')
                ->execute([':amount' => $amountText, ':creator_id' => $creatorId]);

            $unlock = $db->prepare('INSERT INTO i_chat_paid_media_unlocks (paid_media_id, message_id, buyer_id, creator_id, provider, reference, amount, currency, status, fee_amount, tax_amount, net_amount, raw_payload, unlocked_at, created_at, updated_at)
                                    VALUES (:paid_media_id, :message_id, :buyer_id, :creator_id, "wallet", :reference, :amount, :currency, "succeeded", 0.00, 0.00, :net_amount, :payload, :unlocked_at, :created_at, NULL)');
            $unlock->execute([
                ':paid_media_id' => (int)$paid['paid_media_id'],
                ':message_id' => $messageId,
                ':buyer_id' => $buyerId,
                ':creator_id' => $creatorId,
                ':reference' => $reference,
                ':amount' => $amountText,
                ':currency' => $currency,
                ':net_amount' => $amountText,
                ':payload' => json_encode(['source' => 'wallet'], JSON_UNESCAPED_SLASHES),
                ':unlocked_at' => $now,
                ':created_at' => $now,
            ]);

            $ledger = $db->prepare('INSERT INTO i_wallet_ledger (user_id, type, amount_minor, currency, ref_provider, ref_id, meta, created_at)
                                    VALUES (:user_id, "spend", :amount_minor, :currency, "chat_paid_media", :ref_id, :meta, :created_at)');
            $ledger->execute([
                ':user_id' => $buyerId,
                ':amount_minor' => (int)round($amount * 100),
                ':currency' => $currency,
                ':ref_id' => $reference,
                ':meta' => json_encode(['creator_id' => $creatorId, 'message_id' => $messageId, 'paid_media_id' => (int)$paid['paid_media_id']], JSON_UNESCAPED_SLASHES),
                ':created_at' => $now,
            ]);

            $db->commit();
            return [
                'ok' => true,
                'reference' => $reference,
                'new_balance' => (float)$newBalance,
                'media_url' => $this->RL_ChatStorageUrl((string)$paid['file_path']),
                'media_type' => (string)$paid['media_type'],
            ];
        } catch (\Throwable $e) {
            try {
                if ($db->inTransaction()) {
                    $db->rollBack();
                }
            } catch (\Throwable $__) {}
            if (method_exists($this, 'logError')) {
                $this->logError('RL_UnlockChatPaidMedia failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    /**
     * Get all messages between two users.
     * Returns normalized rows ready for foreach rendering.
     *
     * Each row fields:
     * - message_id (int)
     * - from_id (int)
     * - to_id (int)
     * - message (string)
     * - message_time (int, unix)
     * - message_time_iso (string|null)
     * - message_time_hm (string|null, e.g. 13:07)
     * - direction ("incoming"|"outgoing")
     * - avatar (string) => sender avatar (useful for incoming bubble)
     */
    public function RL_GetConversationMessages(int $currentUser, int $targetUser): array
    {
        $this->RL_EnsureMessageStatusColumns();
        try {
            $cutoff = $this->RL_ConversationVisibilityCutoff($currentUser, $targetUser);
            $sql = "SELECT message_id, user_one, user_two, message, message_type, metadata, message_time, delivered_at, read_at, file, reply_to_message_id, deleted_at, deleted_by
                    FROM i_messages
                    WHERE ((user_one = :me1 AND user_two = :other1)
                       OR (user_one = :other2 AND user_two = :me2))
                      AND (:cutoff1 = 0 OR message_time > :cutoff2)
                    ORDER BY message_time ASC";

            $st = $this->db->prepare($sql);
            $st->bindValue(':me1', $currentUser, \PDO::PARAM_INT);
            $st->bindValue(':other1', $targetUser, \PDO::PARAM_INT);
            $st->bindValue(':other2', $targetUser, \PDO::PARAM_INT);
            $st->bindValue(':me2', $currentUser, \PDO::PARAM_INT);
            $st->bindValue(':cutoff1', $cutoff, \PDO::PARAM_INT);
            $st->bindValue(':cutoff2', $cutoff, \PDO::PARAM_INT);
            $st->execute();

            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            // Prefetch both avatars once (avoid N+1)
            $users       = $this->RL_GetConversationUsers($currentUser, $targetUser);
            $avatarSelf  = $users['self']['avatar']  ?? 'uploads/user_avatars/default.jpeg';
            $avatarOther = $users['other']['avatar'] ?? 'uploads/user_avatars/default.jpeg';

            $out = [];
            foreach ($rows as $r) {
                $fromId = (int) ($r['user_one'] ?? 0);
                $toId   = (int) ($r['user_two'] ?? 0);
                $t      = (int) ($r['message_time'] ?? 0);
                $isOut  = ($fromId === $currentUser);

                $file   = (string)($r['file'] ?? '');
                $file   = trim($file);
                $ext    = $file !== '' ? strtolower(pathinfo($file, PATHINFO_EXTENSION)) : '';
                $kind   = '';
                if ($file !== '') {
                    if (in_array($ext, ['jpg','jpeg','png','gif','webp'], true)) { $kind = 'image'; }
                    elseif (in_array($ext, ['mp4','mov','m4v','webm','avi'], true)) { $kind = 'video'; }
                }

                $out[] = [
                    'message_id'      => (int) ($r['message_id'] ?? 0),
                    'from_id'         => $fromId,
                    'to_id'           => $toId,
                    'message'         => (string) ($r['message'] ?? ''),
                    'message_type'    => (string) ($r['message_type'] ?? 'text'),
                    'metadata'        => $r['metadata'] ?? null,
                    'message_time'    => $t,
                    'message_time_iso'=> $t > 0 ? gmdate('c', $t) : null,
                    'message_time_hm' => $t > 0 ? date('H:i', $t) : null,
                    'direction'       => $isOut ? 'outgoing' : 'incoming',
                    'avatar'          => $isOut ? $avatarSelf : $avatarOther,
                    'file'            => $file,
                    'file_kind'       => $kind,
                    'reply_to_message_id' => (int)($r['reply_to_message_id'] ?? 0),
                    'delivered_at'    => (int)($r['delivered_at'] ?? 0),
                    'read_at'         => (int)($r['read_at'] ?? 0),
                    'deleted_at'      => (int)($r['deleted_at'] ?? 0),
                    'deleted_by'      => (int)($r['deleted_by'] ?? 0),
                ];
            }

            return $this->RL_DecorateChatRows($out, $currentUser, $targetUser);
        } catch (\PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetConversationMessages failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    /**
     * Same as RL_GetConversationMessages but limited to the most recent $limit items (ordered ASC).
     */
    public function RL_GetConversationMessagesLimited(int $currentUser, int $targetUser, int $limit): array
    {
        $this->RL_EnsureMessageStatusColumns();
        $limit = max(1, (int) $limit);
        try {
            $cutoff = $this->RL_ConversationVisibilityCutoff($currentUser, $targetUser);
            $sql = "SELECT message_id, user_one, user_two, message, message_type, metadata, message_time, delivered_at, read_at, file, reply_to_message_id, deleted_at, deleted_by
                    FROM (
                        SELECT message_id, user_one, user_two, message, message_type, metadata, message_time, delivered_at, read_at, file, reply_to_message_id, deleted_at, deleted_by
                        FROM i_messages
                        WHERE ((user_one = :me1 AND user_two = :other1)
                           OR (user_one = :other2 AND user_two = :me2))
                          AND (:cutoff1 = 0 OR message_time > :cutoff2)
                        ORDER BY message_time DESC
                        LIMIT :lim
                    ) AS recent
                    ORDER BY message_time ASC";

            $st = $this->db->prepare($sql);
            $st->bindValue(':me1', $currentUser, \PDO::PARAM_INT);
            $st->bindValue(':other1', $targetUser, \PDO::PARAM_INT);
            $st->bindValue(':other2', $targetUser, \PDO::PARAM_INT);
            $st->bindValue(':me2', $currentUser, \PDO::PARAM_INT);
            $st->bindValue(':cutoff1', $cutoff, \PDO::PARAM_INT);
            $st->bindValue(':cutoff2', $cutoff, \PDO::PARAM_INT);
            $st->bindValue(':lim', $limit, \PDO::PARAM_INT);
            $st->execute();

            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            $users       = $this->RL_GetConversationUsers($currentUser, $targetUser);
            $avatarSelf  = $users['self']['avatar']  ?? 'uploads/user_avatars/default.jpeg';
            $avatarOther = $users['other']['avatar'] ?? 'uploads/user_avatars/default.jpeg';

            $out = [];
            foreach ($rows as $r) {
                $fromId = (int) ($r['user_one'] ?? 0);
                $toId   = (int) ($r['user_two'] ?? 0);
                $t      = (int) ($r['message_time'] ?? 0);
                $isOut  = ($fromId === $currentUser);

                $file   = trim((string)($r['file'] ?? ''));
                $ext    = $file !== '' ? strtolower(pathinfo($file, PATHINFO_EXTENSION)) : '';
                $kind   = '';
                if ($file !== '') {
                    if (in_array($ext, ['jpg','jpeg','png','gif','webp'], true)) { $kind = 'image'; }
                    elseif (in_array($ext, ['mp4','mov','m4v','webm','avi'], true)) { $kind = 'video'; }
                }

                $out[] = [
                    'message_id'      => (int) ($r['message_id'] ?? 0),
                    'from_id'         => $fromId,
                    'to_id'           => $toId,
                    'message'         => (string) ($r['message'] ?? ''),
                    'message_type'    => (string) ($r['message_type'] ?? 'text'),
                    'metadata'        => $r['metadata'] ?? null,
                    'message_time'    => $t,
                    'message_time_iso'=> $t > 0 ? gmdate('c', $t) : null,
                    'message_time_hm' => $t > 0 ? date('H:i', $t) : null,
                    'direction'       => $isOut ? 'outgoing' : 'incoming',
                    'avatar'          => $isOut ? $avatarSelf : $avatarOther,
                    'file'            => $file,
                    'file_kind'       => $kind,
                    'reply_to_message_id' => (int)($r['reply_to_message_id'] ?? 0),
                    'delivered_at'    => (int)($r['delivered_at'] ?? 0),
                    'read_at'         => (int)($r['read_at'] ?? 0),
                    'deleted_at'      => (int)($r['deleted_at'] ?? 0),
                    'deleted_by'      => (int)($r['deleted_by'] ?? 0),
                ];
            }

            return $this->RL_DecorateChatRows($out, $currentUser, $targetUser);
        } catch (\PDOException $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetConversationMessagesLimited failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    /**
     * Human-friendly day label: Today ("Bugün"), Yesterday ("Dün"),
     * or "N days ago" ("N gün önce"); falls back to a date string.
     *
     * @param int         $timestamp UNIX timestamp to format
     * @param string|null $timezone  Optional timezone ID; defaults to preferred timezone
     * @return string
     */
    private function RL_FormatDayLabel(int $timestamp, ?string $timezone = null): string
    {
        if ($timestamp <= 0) { return ''; }
        $tzName = $timezone ?: $this->RL_GetPreferredTimezone();
        $tz   = new \DateTimeZone($tzName);
        $now  = new \DateTimeImmutable('now', $tz);
        $dt   = (new \DateTimeImmutable('@' . $timestamp))->setTimezone($tz);

        // Compare by Y-m-d to avoid DST/time differences
        $todayYmd = $now->format('Y-m-d');
        $msgYmd   = $dt->format('Y-m-d');

        if ($msgYmd === $todayYmd) {
            return 'Bugün';
        }

        // Compute days difference
        $todayStart = $now->setTime(0,0,0);
        $msgStart   = $dt->setTime(0,0,0);
        $diffDays   = (int) $todayStart->diff($msgStart)->format('%r%a'); // negative for future, positive past
        $diffDays   = abs($diffDays);

        if ($diffDays === 1) {
            return 'Dün';
        }
        if ($diffDays > 1 && $diffDays <= 6) {
            return $diffDays . ' gün önce';
        }

        // Fallback explicit date to avoid locale issues
        return $dt->format('d.m.Y');
    }

    /**
     * Group messages by day with human labels for each group.
     * Example: [ [ 'label' => 'Bugün', 'ymd' => '2025-08-27', 'items' => [ ... ] ], ... ]
     *
     * @param int         $currentUser Current user ID
     * @param int         $targetUser  Target user ID
     * @param string|null $timezone    Optional timezone ID
     * @return array<int, array>
     */
    public function RL_GetConversationMessagesGrouped(int $currentUser, int $targetUser, ?string $timezone = null): array
    {
        $list = $this->RL_GetConversationMessages($currentUser, $targetUser);
        if (empty($list)) { return []; }

        $groups = [];
        foreach ($list as $row) {
            $t = (int) ($row['message_time'] ?? 0);
            $tzName = $timezone ?: $this->RL_GetPreferredTimezone($currentUser);
            $tz = new \DateTimeZone($tzName);
            $ymd = (new \DateTimeImmutable('@' . $t))->setTimezone($tz)->format('Y-m-d');
            if (!isset($groups[$ymd])) {
                $groups[$ymd] = [
                    'label' => $this->RL_FormatDayLabel($t, $timezone),
                    'ymd'   => $ymd,
                    'items' => [],
                ];
            }
            $groups[$ymd]['items'][] = $row;
        }

        // Ensure chronological order by date key
        ksort($groups, SORT_STRING);

        // Reindex as list
        return array_values($groups);
    }

    /**
     * Group only the last $limit messages.
     */
    public function RL_GetConversationMessagesGroupedLimited(int $currentUser, int $targetUser, int $limit, string $timezone = 'Europe/Istanbul'): array
    {
        $list = $this->RL_GetConversationMessagesLimited($currentUser, $targetUser, $limit);
        if (empty($list)) { return []; }

        $groups = [];
        foreach ($list as $row) {
            $t = (int) ($row['message_time'] ?? 0);
            $tz = new \DateTimeZone($timezone);
            $ymd = (new \DateTimeImmutable('@' . $t))->setTimezone($tz)->format('Y-m-d');
            if (!isset($groups[$ymd])) {
                $groups[$ymd] = [
                    'label' => $this->RL_FormatDayLabel($t, $timezone),
                    'ymd'   => $ymd,
                    'items' => [],
                ];
            }
            $groups[$ymd]['items'][] = $row;
        }
        ksort($groups, SORT_STRING);
        return array_values($groups);
    }

    /**
     * Backward compatible alias for grouped messages.
     */
    public function getConversationMessagesGrouped(int $currentUser, int $targetUser, ?string $timezone = null): array
    {
        return $this->RL_GetConversationMessagesGrouped($currentUser, $targetUser, $timezone);
    }

    // ---- Compatibility helpers (keep old names used in templates) ----

    /**
     * Backward compatible alias.
     */
    public function getConversationMessages(int $currentUser, int $targetUser): array
    {
        $currentUser = (int) $currentUser;
    $targetUser  = (int) $targetUser;

    if ($currentUser <= 0 || $targetUser <= 0) {
        if (method_exists($this, 'logError')) {
            $this->logError("RL_GetConversationMessages: invalid ids me={$currentUser} other={$targetUser}");
        }
        return [];
    }
        return $this->RL_GetConversationMessages($currentUser, $targetUser);
    }

    /**
     * Backward compatible: get a single user's minimal profile for headers.
     */
    public function getConversationUser(int $userID): ?array
    {
        $data = $this->RL_GetUserDetails($userID);
        if (isset($data['error'])) {
            return null;
        }
        $data['avatar'] = $this->RL_userAvatar((int) $data['user_id']);
        if (empty($data['user_fullname'])) {
            $data['user_fullname'] = $data['username'] ?? '';
        }
        return $data;
    }

    /**
     * Backward compatible: current user minimal profile.
     */
    public function getCurrentUser(int $userID): ?array
    {
        $data = $this->RL_GetUserDetails($userID);
        if (isset($data['error'])) {
            return null;
        }
        $data['avatar'] = $this->RL_userAvatar((int) $data['user_id']);
        if (empty($data['user_fullname'])) {
            $data['user_fullname'] = $data['username'] ?? '';
        }
        return $data;
    }

    public function RL_GetChatBlockStatus(int $currentUser, int $targetUser): array
    {
        $currentUser = (int)$currentUser;
        $targetUser = (int)$targetUser;
        if ($currentUser <= 0 || $targetUser <= 0) {
            return ['blocked' => false, 'direction' => ''];
        }
        try {
            $st = $this->db->prepare('SELECT blocker_id, blocked_id FROM i_user_blocks
                                      WHERE (blocker_id = :me1 AND blocked_id = :other1)
                                         OR (blocker_id = :other2 AND blocked_id = :me2)
                                      LIMIT 1');
            $st->execute([
                ':me1' => $currentUser,
                ':other1' => $targetUser,
                ':other2' => $targetUser,
                ':me2' => $currentUser,
            ]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                return ['blocked' => false, 'direction' => ''];
            }
            return [
                'blocked' => true,
                'direction' => ((int)$row['blocker_id'] === $currentUser) ? 'outgoing' : 'incoming',
            ];
        } catch (\Throwable $__) {
            return ['blocked' => false, 'direction' => ''];
        }
    }

    private function RL_UserFollowsForChat(int $followerId, int $followeeId): bool
    {
        try {
            $st = $this->db->prepare("SELECT 1 FROM i_friends WHERE fr_one = :one AND fr_two = :two AND fr_status IN ('flwr','subscriber') LIMIT 1");
            $st->execute([':one' => $followerId, ':two' => $followeeId]);
            return (bool)$st->fetchColumn();
        } catch (\Throwable $__) {
            return false;
        }
    }

    private function RL_HasEstablishedChatHistory(int $userA, int $userB, int $excludeMessageId = 0): bool
    {
        try {
            $sql = 'SELECT 1 FROM i_messages
                    WHERE ((user_one = :a1 AND user_two = :b1) OR (user_one = :b2 AND user_two = :a2))';
            if ($excludeMessageId > 0) {
                $sql .= ' AND message_id <> :exclude_id';
            }
            $sql .= ' LIMIT 1';
            $st = $this->db->prepare($sql);
            $st->bindValue(':a1', $userA, \PDO::PARAM_INT);
            $st->bindValue(':b1', $userB, \PDO::PARAM_INT);
            $st->bindValue(':b2', $userB, \PDO::PARAM_INT);
            $st->bindValue(':a2', $userA, \PDO::PARAM_INT);
            if ($excludeMessageId > 0) {
                $st->bindValue(':exclude_id', $excludeMessageId, \PDO::PARAM_INT);
            }
            $st->execute();
            return (bool)$st->fetchColumn();
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_GetMessageRequestState(int $currentUser, int $targetUser): array
    {
        $block = $this->RL_GetChatBlockStatus($currentUser, $targetUser);
        if (!empty($block['blocked'])) {
            return [
                'status' => $block['direction'] === 'outgoing' ? 'blocked_out' : 'blocked_in',
                'direction' => $block['direction'],
                'request_id' => 0,
            ];
        }
        try {
            $st = $this->db->prepare('SELECT request_id, sender_id, receiver_id, status, created_at, updated_at, acted_at
                                      FROM i_message_requests
                                      WHERE (sender_id = :me1 AND receiver_id = :other1)
                                         OR (sender_id = :other2 AND receiver_id = :me2)
                                      ORDER BY FIELD(status, "pending", "accepted", "declined", "blocked"), COALESCE(updated_at, created_at) DESC
                                      LIMIT 1');
            $st->execute([
                ':me1' => $currentUser,
                ':other1' => $targetUser,
                ':other2' => $targetUser,
                ':me2' => $currentUser,
            ]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                return ['status' => 'none', 'direction' => '', 'request_id' => 0];
            }
            return [
                'status' => (string)($row['status'] ?? 'none'),
                'direction' => ((int)$row['sender_id'] === $currentUser) ? 'outgoing' : 'incoming',
                'request_id' => (int)($row['request_id'] ?? 0),
                'sender_id' => (int)($row['sender_id'] ?? 0),
                'receiver_id' => (int)($row['receiver_id'] ?? 0),
            ];
        } catch (\Throwable $__) {
            return ['status' => 'none', 'direction' => '', 'request_id' => 0];
        }
    }

    public function RL_RegisterMessageRequestForMessage(int $senderId, int $receiverId, int $messageId): array
    {
        $senderId = (int)$senderId;
        $receiverId = (int)$receiverId;
        $messageId = (int)$messageId;
        if ($senderId <= 0 || $receiverId <= 0 || $messageId <= 0 || $senderId === $receiverId) {
            return ['status' => 'none'];
        }
        $block = $this->RL_GetChatBlockStatus($senderId, $receiverId);
        if (!empty($block['blocked'])) {
            return ['error' => 'user_blocked'];
        }
        $now = time();
        try {
            $reverse = $this->db->prepare('SELECT request_id FROM i_message_requests
                                           WHERE sender_id = :receiver AND receiver_id = :sender AND status = "pending"
                                           LIMIT 1');
            $reverse->execute([':receiver' => $receiverId, ':sender' => $senderId]);
            $reverseId = (int)($reverse->fetchColumn() ?: 0);
            if ($reverseId > 0) {
                $up = $this->db->prepare('UPDATE i_message_requests
                                          SET status = "accepted", last_message_id = :message_id, updated_at = :updated_at, acted_at = :acted_at
                                          WHERE request_id = :request_id');
                $up->execute([
                    ':message_id' => $messageId,
                    ':updated_at' => $now,
                    ':acted_at' => $now,
                    ':request_id' => $reverseId,
                ]);
                return ['status' => 'accepted', 'request_id' => $reverseId];
            }

            $existing = $this->db->prepare('SELECT request_id, status FROM i_message_requests
                                            WHERE sender_id = :sender AND receiver_id = :receiver
                                            LIMIT 1');
            $existing->execute([':sender' => $senderId, ':receiver' => $receiverId]);
            $row = $existing->fetch(\PDO::FETCH_ASSOC);
            if ($row && (string)$row['status'] === 'accepted') {
                return ['status' => 'accepted', 'request_id' => (int)$row['request_id']];
            }

            if ($this->RL_UserFollowsForChat($receiverId, $senderId) || $this->RL_HasEstablishedChatHistory($senderId, $receiverId, $messageId)) {
                return ['status' => 'none'];
            }

            if ($row) {
                $up = $this->db->prepare('UPDATE i_message_requests
                                          SET status = "pending", last_message_id = :message_id, updated_at = :updated_at, acted_at = NULL
                                          WHERE request_id = :request_id');
                $up->execute([
                    ':message_id' => $messageId,
                    ':updated_at' => $now,
                    ':request_id' => (int)$row['request_id'],
                ]);
                return ['status' => 'pending', 'request_id' => (int)$row['request_id']];
            }

            $ins = $this->db->prepare('INSERT INTO i_message_requests (sender_id, receiver_id, status, first_message_id, last_message_id, created_at, updated_at)
                                       VALUES (:sender, :receiver, "pending", :message_id, :message_id2, :created_at, :updated_at)');
            $ins->execute([
                ':sender' => $senderId,
                ':receiver' => $receiverId,
                ':message_id' => $messageId,
                ':message_id2' => $messageId,
                ':created_at' => $now,
                ':updated_at' => $now,
            ]);
            return ['status' => 'pending', 'request_id' => (int)$this->db->lastInsertId()];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_RegisterMessageRequestForMessage failed: ' . $e->getMessage());
            }
            return ['error' => 'request_failed'];
        }
    }

    public function RL_UpdateMessageRequestAction(int $actorId, int $requestId, string $action): array
    {
        $actorId = (int)$actorId;
        $requestId = (int)$requestId;
        $action = strtolower(trim($action));
        if ($actorId <= 0 || $requestId <= 0 || !in_array($action, ['accept', 'decline', 'block'], true)) {
            return ['error' => 'invalid_input'];
        }
        try {
            $st = $this->db->prepare('SELECT * FROM i_message_requests WHERE request_id = :request_id LIMIT 1');
            $st->execute([':request_id' => $requestId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row || (int)$row['receiver_id'] !== $actorId) {
                return ['error' => 'not_allowed'];
            }
            $now = time();
            $status = $action === 'accept' ? 'accepted' : ($action === 'block' ? 'blocked' : 'declined');
            $up = $this->db->prepare('UPDATE i_message_requests
                                      SET status = :status, updated_at = :updated_at, acted_at = :acted_at
                                      WHERE request_id = :request_id');
            $up->execute([
                ':status' => $status,
                ':updated_at' => $now,
                ':acted_at' => $now,
                ':request_id' => $requestId,
            ]);
            if ($action === 'block') {
                $block = $this->db->prepare('INSERT INTO i_user_blocks (blocker_id, blocked_id, source, reason, created_at)
                                             VALUES (:blocker, :blocked, "chat", "message_request", :created_at)
                                             ON DUPLICATE KEY UPDATE reason = VALUES(reason)');
                $block->execute([
                    ':blocker' => $actorId,
                    ':blocked' => (int)$row['sender_id'],
                    ':created_at' => $now,
                ]);
            }
            return ['status' => $status, 'request_id' => $requestId];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_UpdateMessageRequestAction failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    private function RL_ChatCallUserSummary(int $userId): array
    {
        $userId = (int)$userId;
        if ($userId <= 0) {
            return [
                'user_id' => 0,
                'username' => '',
                'name' => 'User',
                'avatar' => '',
                'avatar_url' => '',
                'cover' => '',
                'cover_url' => '',
                'verified' => false,
            ];
        }
        try {
            $row = method_exists($this, 'RL_GetUserDetails') ? $this->RL_GetUserDetails($userId) : [];
            if (isset($row['error']) || !is_array($row)) {
                $row = [];
            }
            $username = (string)($row['username'] ?? '');
            $name = trim((string)($row['user_fullname'] ?? ''));
            if ($name === '') {
                $name = $username !== '' ? $username : ('User #' . $userId);
            }
            $avatar = '';
            if (method_exists($this, 'RL_userAvatar')) {
                $avatar = (string)$this->RL_userAvatar($userId);
            } elseif (!empty($row['user_avatar'])) {
                $avatar = (string)$row['user_avatar'];
            }
            if ($avatar === '') {
                $avatar = 'uploads/user_avatars/default.jpeg';
            }
            $cover = '';
            if (method_exists($this, 'RL_GetUserCover')) {
                try {
                    $cover = (string)$this->RL_GetUserCover($userId);
                } catch (\Throwable $__) {
                    $cover = '';
                }
            } elseif (!empty($row['user_cover'])) {
                $cover = (string)$row['user_cover'];
            }
            $safeStorageUrl = static function (string $path): string {
                $path = trim($path);
                if ($path === '') {
                    return '';
                }
                if (preg_match('~^https?://~i', $path)) {
                    return $path;
                }
                if (function_exists('storage_url')) {
                    return (string)storage_url($path);
                }
                $base = isset($GLOBALS['base_url']) ? (string)$GLOBALS['base_url'] : '';
                return ($base !== '' ? rtrim($base, '/') . '/' : '') . ltrim($path, '/');
            };
            return [
                'user_id' => $userId,
                'username' => $username,
                'name' => $name,
                'avatar' => $avatar,
                'avatar_url' => $safeStorageUrl($avatar),
                'cover' => $cover,
                'cover_url' => $cover !== '' ? $safeStorageUrl($cover) : '',
                'verified' => (int)($row['verified_status'] ?? 0) === 1,
            ];
        } catch (\Throwable $__) {
            return [
                'user_id' => $userId,
                'username' => '',
                'name' => 'User #' . $userId,
                'avatar' => 'uploads/user_avatars/default.jpeg',
                'avatar_url' => function_exists('storage_url') ? (string)storage_url('uploads/user_avatars/default.jpeg') : 'uploads/user_avatars/default.jpeg',
                'cover' => '',
                'cover_url' => '',
                'verified' => false,
            ];
        }
    }

    private function RL_NormalizeChatCallRow(array $row, int $viewerId = 0): array
    {
        $callerId = (int)($row['caller_id'] ?? 0);
        $receiverId = (int)($row['receiver_id'] ?? 0);
        $viewerId = (int)$viewerId;
        $partnerId = $viewerId > 0 ? ($viewerId === $callerId ? $receiverId : $callerId) : 0;
        $partner = $partnerId > 0 ? $this->RL_ChatCallUserSummary($partnerId) : [];
        $caller = $this->RL_ChatCallUserSummary($callerId);
        $receiver = $this->RL_ChatCallUserSummary($receiverId);
        $acceptedAt = (int)($row['accepted_at'] ?? 0);
        $endedAt = (int)($row['ended_at'] ?? 0);
        $duration = (int)($row['duration_seconds'] ?? 0);
        if ($duration <= 0 && $acceptedAt > 0 && $endedAt > 0) {
            $duration = max(0, $endedAt - $acceptedAt);
        }

        return [
            'call_id' => (int)($row['call_id'] ?? 0),
            'caller_id' => $callerId,
            'receiver_id' => $receiverId,
            'partner_id' => $partnerId,
            'partner_name' => (string)($partner['name'] ?? ''),
            'partner_username' => (string)($partner['username'] ?? ''),
            'partner_avatar' => (string)($partner['avatar'] ?? ''),
            'partner_avatar_url' => (string)($partner['avatar_url'] ?? ''),
            'partner_cover' => (string)($partner['cover'] ?? ''),
            'partner_cover_url' => (string)($partner['cover_url'] ?? ''),
            'partner_verified' => (bool)($partner['verified'] ?? false),
            'caller_name' => (string)($caller['name'] ?? ''),
            'caller_username' => (string)($caller['username'] ?? ''),
            'caller_avatar' => (string)($caller['avatar'] ?? ''),
            'caller_avatar_url' => (string)($caller['avatar_url'] ?? ''),
            'caller_cover' => (string)($caller['cover'] ?? ''),
            'caller_cover_url' => (string)($caller['cover_url'] ?? ''),
            'caller_verified' => (bool)($caller['verified'] ?? false),
            'receiver_name' => (string)($receiver['name'] ?? ''),
            'receiver_username' => (string)($receiver['username'] ?? ''),
            'receiver_avatar' => (string)($receiver['avatar'] ?? ''),
            'receiver_avatar_url' => (string)($receiver['avatar_url'] ?? ''),
            'receiver_cover' => (string)($receiver['cover'] ?? ''),
            'receiver_cover_url' => (string)($receiver['cover_url'] ?? ''),
            'receiver_verified' => (bool)($receiver['verified'] ?? false),
            'direction' => $viewerId > 0 && $viewerId === $callerId ? 'outgoing' : 'incoming',
            'channel_name' => (string)($row['channel_name'] ?? ''),
            'call_type' => (string)($row['call_type'] ?? 'audio'),
            'billing_type' => (string)($row['billing_type'] ?? 'free'),
            'price' => isset($row['price']) ? (float)$row['price'] : 0.0,
            'currency' => strtoupper((string)($row['currency'] ?? 'USD')),
            'status' => (string)($row['status'] ?? 'ringing'),
            'started_at' => (int)($row['started_at'] ?? 0),
            'accepted_at' => $acceptedAt,
            'ended_at' => $endedAt,
            'duration_seconds' => $duration,
            'provider' => (string)($row['provider'] ?? 'agora'),
            'reference' => (string)($row['reference'] ?? ''),
        ];
    }

    public function RL_StartChatCall(int $callerId, int $receiverId, string $callType = 'audio', string $currency = 'USD'): array
    {
        $callerId = (int)$callerId;
        $receiverId = (int)$receiverId;
        $callType = strtolower(trim($callType));
        $currency = strtoupper(trim($currency) ?: 'USD');
        if ($callerId <= 0 || $receiverId <= 0 || $callerId === $receiverId || !in_array($callType, ['audio', 'video'], true)) {
            return ['error' => 'invalid_input'];
        }
        if (!empty($this->RL_GetChatBlockStatus($callerId, $receiverId)['blocked'])) {
            return ['error' => 'user_blocked'];
        }

        try {
            $now = time();
            $cleanup = $this->db->prepare('UPDATE i_chat_calls
                                           SET status = "missed", ended_at = :ended_at
                                           WHERE status = "ringing"
                                             AND started_at < :stale_before
                                             AND ((caller_id = :caller_a AND receiver_id = :receiver_a)
                                               OR (caller_id = :receiver_b AND receiver_id = :caller_b))');
            $cleanup->execute([
                ':ended_at' => $now,
                ':stale_before' => $now - 120,
                ':caller_a' => $callerId,
                ':receiver_a' => $receiverId,
                ':receiver_b' => $receiverId,
                ':caller_b' => $callerId,
            ]);

            $active = $this->db->prepare('SELECT * FROM i_chat_calls
                                          WHERE status IN ("ringing", "accepted")
                                            AND ((caller_id = :caller_a AND receiver_id = :receiver_a)
                                              OR (caller_id = :receiver_b AND receiver_id = :caller_b))
                                          ORDER BY call_id DESC
                                          LIMIT 1');
            $active->execute([
                ':caller_a' => $callerId,
                ':receiver_a' => $receiverId,
                ':receiver_b' => $receiverId,
                ':caller_b' => $callerId,
            ]);
            $existing = $active->fetch(\PDO::FETCH_ASSOC);
            if ($existing) {
                return ['error' => 'call_already_active', 'call' => $this->RL_NormalizeChatCallRow($existing, $callerId)];
            }

            $random = function_exists('random_bytes') ? substr(bin2hex(random_bytes(4)), 0, 8) : substr(md5((string)$now . $callerId . $receiverId), 0, 8);
            $channel = 'chat_' . min($callerId, $receiverId) . '_' . max($callerId, $receiverId) . '_' . $now . '_' . $random;
            $metadata = json_encode([
                'version' => 1,
                'created_by' => $callerId,
                'created_from' => 'messages',
            ], JSON_UNESCAPED_SLASHES);
            $ins = $this->db->prepare('INSERT INTO i_chat_calls
                (caller_id, receiver_id, channel_name, call_type, billing_type, price, currency, status, started_at, provider, reference, metadata)
                VALUES
                (:caller_id, :receiver_id, :channel_name, :call_type, "free", 0.00, :currency, "ringing", :started_at, "agora", :reference, :metadata)');
            $ins->execute([
                ':caller_id' => $callerId,
                ':receiver_id' => $receiverId,
                ':channel_name' => $channel,
                ':call_type' => $callType,
                ':currency' => $currency,
                ':started_at' => $now,
                ':reference' => 'chat:' . $callerId . ':' . $receiverId,
                ':metadata' => $metadata ?: '{}',
            ]);

            return $this->RL_GetChatCallForUser($callerId, (int)$this->db->lastInsertId());
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_StartChatCall failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    public function RL_GetChatCallForUser(int $viewerId, int $callId): array
    {
        $viewerId = (int)$viewerId;
        $callId = (int)$callId;
        if ($viewerId <= 0 || $callId <= 0) {
            return ['error' => 'invalid_input'];
        }
        try {
            $st = $this->db->prepare('SELECT * FROM i_chat_calls
                                      WHERE call_id = :call_id
                                        AND (caller_id = :viewer_a OR receiver_id = :viewer_b)
                                      LIMIT 1');
            $st->execute([
                ':call_id' => $callId,
                ':viewer_a' => $viewerId,
                ':viewer_b' => $viewerId,
            ]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                return ['error' => 'not_found'];
            }
            return ['call' => $this->RL_NormalizeChatCallRow($row, $viewerId)];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetChatCallForUser failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    public function RL_ListActiveChatCalls(int $viewerId, int $partnerId = 0): array
    {
        $viewerId = (int)$viewerId;
        $partnerId = (int)$partnerId;
        if ($viewerId <= 0) {
            return [];
        }
        try {
            $sql = 'SELECT * FROM i_chat_calls
                    WHERE status IN ("ringing", "accepted")
                      AND (caller_id = :viewer_a OR receiver_id = :viewer_b)';
            if ($partnerId > 0) {
                $sql .= ' AND (caller_id = :partner_a OR receiver_id = :partner_b)';
            }
            $sql .= ' ORDER BY call_id DESC LIMIT 10';
            $st = $this->db->prepare($sql);
            $st->bindValue(':viewer_a', $viewerId, \PDO::PARAM_INT);
            $st->bindValue(':viewer_b', $viewerId, \PDO::PARAM_INT);
            if ($partnerId > 0) {
                $st->bindValue(':partner_a', $partnerId, \PDO::PARAM_INT);
                $st->bindValue(':partner_b', $partnerId, \PDO::PARAM_INT);
            }
            $st->execute();
            $items = [];
            foreach ($st->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $row) {
                $items[] = $this->RL_NormalizeChatCallRow($row, $viewerId);
            }
            return $items;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_ListActiveChatCalls failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    public function RL_UpdateChatCallStatus(int $viewerId, int $callId, string $action): array
    {
        $viewerId = (int)$viewerId;
        $callId = (int)$callId;
        $action = strtolower(trim($action));
        if ($viewerId <= 0 || $callId <= 0 || !in_array($action, ['accept', 'reject', 'cancel', 'end', 'miss'], true)) {
            return ['error' => 'invalid_input'];
        }

        try {
            $res = $this->RL_GetChatCallForUser($viewerId, $callId);
            if (isset($res['error'])) {
                return $res;
            }
            $call = $res['call'];
            $status = (string)($call['status'] ?? '');
            $now = time();
            $newStatus = '';
            $params = [':call_id' => $callId];
            $sets = [];

            if ($action === 'accept') {
                if ((int)$call['receiver_id'] !== $viewerId || $status !== 'ringing') {
                    return ['error' => 'not_allowed'];
                }
                $newStatus = 'accepted';
                $sets[] = 'status = :status';
                $sets[] = 'accepted_at = :accepted_at';
                $params[':accepted_at'] = $now;
            } elseif ($action === 'reject') {
                if ((int)$call['receiver_id'] !== $viewerId || $status !== 'ringing') {
                    return ['error' => 'not_allowed'];
                }
                $newStatus = 'rejected';
                $sets[] = 'status = :status';
                $sets[] = 'ended_at = :ended_at';
                $params[':ended_at'] = $now;
            } elseif ($action === 'cancel') {
                if ((int)$call['caller_id'] !== $viewerId || $status !== 'ringing') {
                    return ['error' => 'not_allowed'];
                }
                $newStatus = 'canceled';
                $sets[] = 'status = :status';
                $sets[] = 'ended_at = :ended_at';
                $params[':ended_at'] = $now;
            } elseif ($action === 'miss') {
                if ($status !== 'ringing') {
                    return ['error' => 'not_allowed'];
                }
                $newStatus = 'missed';
                $sets[] = 'status = :status';
                $sets[] = 'ended_at = :ended_at';
                $params[':ended_at'] = $now;
            } else {
                if (!in_array($status, ['ringing', 'accepted'], true)) {
                    return ['error' => 'not_allowed'];
                }
                $newStatus = 'ended';
                $sets[] = 'status = :status';
                $sets[] = 'ended_at = :ended_at';
                $sets[] = 'duration_seconds = :duration_seconds';
                $acceptedAt = (int)($call['accepted_at'] ?? 0);
                $params[':ended_at'] = $now;
                $params[':duration_seconds'] = $acceptedAt > 0 ? max(0, $now - $acceptedAt) : 0;
            }

            $params[':status'] = $newStatus;
            $up = $this->db->prepare('UPDATE i_chat_calls SET ' . implode(', ', $sets) . ' WHERE call_id = :call_id');
            $up->execute($params);

            return $this->RL_GetChatCallForUser($viewerId, $callId);
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_UpdateChatCallStatus failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    public function RL_BuildChatCallJoinPayload(
        int $viewerId,
        int $callId,
        string $agoraAppId,
        ?string $agoraAppCert,
        int $expireSeconds = 3600,
        bool $allowTokenless = false
    ): array {
        $res = $this->RL_GetChatCallForUser($viewerId, $callId);
        if (isset($res['error'])) {
            return $res;
        }
        $call = $res['call'];
        if ((string)($call['status'] ?? '') !== 'accepted') {
            return ['error' => 'call_not_accepted', 'call' => $call];
        }
        $agoraAppId = trim($agoraAppId);
        if ($agoraAppId === '' || strlen($agoraAppId) !== 32 || !ctype_xdigit($agoraAppId)) {
            return ['error' => 'missing_agora_app_id'];
        }
        if (!function_exists('agora_build_join_payload')) {
            $helper = dirname(__DIR__) . '/helpers/agora.php';
            if (is_file($helper)) {
                require_once $helper;
            }
        }
        if (!function_exists('agora_build_join_payload')) {
            return ['error' => 'agora_helper_missing'];
        }

        $payload = agora_build_join_payload(
            $agoraAppId,
            $agoraAppCert,
            (string)$call['channel_name'],
            (string)$viewerId,
            'publisher',
            max(60, (int)$expireSeconds),
            [
                'publish_audio' => true,
                'publish_video' => (string)$call['call_type'] === 'video',
                'publish_data' => true,
            ]
        );
        $payload['allow_tokenless'] = $allowTokenless;

        return [
            'call' => $call,
            'agora' => $payload,
        ];
    }

    /**
     * Insert a message and return a UI-normalized row (matches front-end expectations).
     * Uses the same DB handle ($this->db) and avatar helpers as the rest of the trait.
     */
    public function RL_SendMessage(int $fromUser, int $toUser, string $text, int $replyToMessageId = 0): array
    {
        $this->RL_EnsureMessageStatusColumns();
        $fromUser = (int) $fromUser;
        $toUser   = (int) $toUser;
        $text     = trim($text);

        if ($fromUser <= 0 || $toUser <= 0 || $text === '') {
            return ['error' => 'invalid_input'];
        }
        if (!empty($this->RL_GetChatBlockStatus($fromUser, $toUser)['blocked'])) {
            return ['error' => 'user_blocked'];
        }
        if (mb_strlen($text) > 2000) {
            $text = mb_substr($text, 0, 2000);
        }

        try {
            $now = time();
            $replyToMessageId = (int)$replyToMessageId;
            if ($replyToMessageId > 0) {
                $replyRow = $this->RL_GetMessageForAction($fromUser, $replyToMessageId);
                if (isset($replyRow['error']) || !$this->RL_IsConversationMessage($replyRow, $fromUser, $toUser)) {
                    $replyToMessageId = 0;
                }
            }
            $sql = 'INSERT INTO i_messages (user_one, user_two, message, reply_to_message_id, message_time, delivered_at, read_at) VALUES (:u1, :u2, :msg, :reply_to, :ts, NULL, NULL)';
            $st  = $this->db->prepare($sql);
            $st->bindValue(':u1', $fromUser, \PDO::PARAM_INT);
            $st->bindValue(':u2', $toUser, \PDO::PARAM_INT);
            $st->bindValue(':msg', $text, \PDO::PARAM_STR);
            if ($replyToMessageId > 0) {
                $st->bindValue(':reply_to', $replyToMessageId, \PDO::PARAM_INT);
            } else {
                $st->bindValue(':reply_to', null, \PDO::PARAM_NULL);
            }
            $st->bindValue(':ts', $now, \PDO::PARAM_INT);
            $st->execute();
            $id = (int) $this->db->lastInsertId();
            $this->RL_RegisterMessageRequestForMessage($fromUser, $toUser, $id);

            // Since the sender is actively chatting, mark all messages from the recipient
            // to the sender as delivered+read (they are visible now).
            try {
                $this->db->prepare(
                    'UPDATE i_messages
                       SET delivered_at = IFNULL(delivered_at, :now), read_at = :now
                     WHERE user_one = :other AND user_two = :me AND (read_at IS NULL OR read_at = 0)'
                )->execute([':now' => $now, ':other' => $toUser, ':me' => $fromUser]);
            } catch (\Throwable $__) { /* ignore */ }

            $tz = new \DateTimeZone($this->RL_GetPreferredTimezone($fromUser));
            $dt = (new \DateTimeImmutable('@' . $now))->setTimezone($tz);

            $row = [
                'message_id'      => $id,
                'from_id'         => $fromUser,
                'to_id'           => $toUser,
                'message'         => $text,
                'message_time'    => $now,
                'message_time_hm' => $dt->format('H:i'),
                'direction'       => 'outgoing',
                'avatar'          => $this->RL_userAvatar($fromUser),
                'ymd'             => $dt->format('Y-m-d'),
                'reply_to_message_id' => $replyToMessageId,
                'delivered_at'    => null,
                'read_at'         => null,
                'deleted_at'      => null,
                'deleted_by'      => null,
            ];
            $decorated = $this->RL_DecorateChatRows([$row], $fromUser, $toUser);
            return $decorated[0] ?? $row;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_SendMessage failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    /**
     * Fetch messages newer than a timestamp between two users and normalize rows.
     * Returned rows have keys: message_id, message, message_time, message_time_hm, direction, avatar, ymd
     */
    public function RL_GetChatNewMessages(int $currentUser, int $targetUser, int $afterTs, ?string $timezone = null): array
    {
        $this->RL_EnsureMessageStatusColumns();
        $currentUser = (int) $currentUser;
        $targetUser  = (int) $targetUser;
        $afterTs     = max(0, (int) $afterTs);

        if ($currentUser <= 0 || $targetUser <= 0) {
            return [];
        }

        try {
            $sql = 'SELECT message_id, user_one, user_two, message, message_type, metadata, message_time, file, reply_to_message_id, delivered_at, read_at, deleted_at, deleted_by
                    FROM i_messages
                    WHERE ((user_one = :me1 AND user_two = :other1)
                       OR  (user_one = :other2 AND user_two = :me2))
                      AND message_time > :after
                    ORDER BY message_time ASC';
            $st = $this->db->prepare($sql);
            $st->bindValue(':me1', $currentUser, \PDO::PARAM_INT);
            $st->bindValue(':other1', $targetUser, \PDO::PARAM_INT);
            $st->bindValue(':other2', $targetUser, \PDO::PARAM_INT);
            $st->bindValue(':me2', $currentUser, \PDO::PARAM_INT);
            $st->bindValue(':after', $afterTs, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            $tzName = $timezone ?: $this->RL_GetPreferredTimezone($currentUser);
            $tz = new \DateTimeZone($tzName);
            $out = [];
            // Mark delivered/read for messages to me (this chat view is active)
            $idsToMark = [];
            foreach ($rows as $r) {
                $fromId = (int) ($r['user_one'] ?? 0);
                $dir    = ($fromId === $currentUser) ? 'outgoing' : 'incoming';
                $ts     = (int) ($r['message_time'] ?? 0);
                if ($dir === 'incoming') { $idsToMark[] = (int)$r['message_id']; }
                $dt     = (new \DateTimeImmutable('@' . $ts))->setTimezone($tz);
                $file   = (string)($r['file'] ?? '');
                $file   = trim($file);
                $ext    = $file !== '' ? strtolower(pathinfo($file, PATHINFO_EXTENSION)) : '';
                $kind   = '';
                if ($file !== '') {
                    if (in_array($ext, ['jpg','jpeg','png','gif','webp'], true)) { $kind = 'image'; }
                    elseif (in_array($ext, ['mp4','mov','m4v','webm','avi'], true)) { $kind = 'video'; }
                }
                $out[]  = [
                    'message_id'      => (int) ($r['message_id'] ?? 0),
                    'from_id'         => $fromId,
                    'to_id'           => (int)($r['user_two'] ?? 0),
                    'message'         => (string) ($r['message'] ?? ''),
                    'message_type'    => (string) ($r['message_type'] ?? 'text'),
                    'metadata'        => $r['metadata'] ?? null,
                    'message_time'    => $ts,
                    'message_time_hm' => $dt->format('H:i'),
                    'direction'       => $dir,
                    'avatar'          => $this->RL_userAvatar($fromId),
                    'ymd'             => $dt->format('Y-m-d'),
                    'file'            => $file,
                    'file_kind'       => $kind,
                    'reply_to_message_id' => (int)($r['reply_to_message_id'] ?? 0),
                    'delivered_at'    => isset($r['delivered_at']) ? (int)$r['delivered_at'] : 0,
                    'read_at'         => isset($r['read_at']) ? (int)$r['read_at'] : 0,
                    'deleted_at'      => (int)($r['deleted_at'] ?? 0),
                    'deleted_by'      => (int)($r['deleted_by'] ?? 0),
                ];
            }
            if (!empty($idsToMark)) {
                try {
                    $now = time();
                    // Only mark delivered here; read will be marked explicitly when conversation is confirmed seen
                    $in  = implode(',', array_map('intval', $idsToMark));
                    $this->db->exec("UPDATE i_messages SET delivered_at = IFNULL(delivered_at, $now) WHERE message_id IN ($in) AND user_two = " . (int)$currentUser);
                } catch (\Throwable $__) {}
            }
            return $this->RL_DecorateChatRows($out, $currentUser, $targetUser);
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetChatNewMessages failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    /**
     * Insert a file message (image/video) and return normalized row.
     * $fileRelative should be a web-relative path like 'uploads/files/YYYY-MM-DD/name.ext'
     */
    public function RL_SendFileMessage(int $fromUser, int $toUser, string $fileRelative, string $kind = ''): array
    {
        $this->RL_EnsureMessageStatusColumns();
        $fromUser = (int) $fromUser;
        $toUser   = (int) $toUser;
        $fileRelative = trim($fileRelative);
        if ($fromUser <= 0 || $toUser <= 0 || $fileRelative === '') {
            return ['error' => 'invalid_input'];
        }
        if (!empty($this->RL_GetChatBlockStatus($fromUser, $toUser)['blocked'])) {
            return ['error' => 'user_blocked'];
        }
        $ext  = strtolower(pathinfo($fileRelative, PATHINFO_EXTENSION));
        if ($kind === '') {
            if (in_array($ext, ['jpg','jpeg','png','gif','webp'], true)) { $kind = 'image'; }
            elseif (in_array($ext, ['mp4','mov','m4v','webm','avi'], true)) { $kind = 'video'; }
        }
        try {
            $now = time();
            $sql = 'INSERT INTO i_messages (user_one, user_two, message, message_time, delivered_at, read_at, file) VALUES (:u1, :u2, :msg, :ts, NULL, NULL, :file)';
            $st  = $this->db->prepare($sql);
            $st->bindValue(':u1', $fromUser, \PDO::PARAM_INT);
            $st->bindValue(':u2', $toUser, \PDO::PARAM_INT);
            $st->bindValue(':msg', '');
            $st->bindValue(':ts', $now, \PDO::PARAM_INT);
            $st->bindValue(':file', $fileRelative, \PDO::PARAM_STR);
            $st->execute();
            $id = (int) $this->db->lastInsertId();
            $this->RL_RegisterMessageRequestForMessage($fromUser, $toUser, $id);

            // Sender is in the conversation; mark recipient->sender older messages as seen now
            try {
                $this->db->prepare(
                    'UPDATE i_messages
                       SET delivered_at = IFNULL(delivered_at, :now), read_at = :now
                     WHERE user_one = :other AND user_two = :me AND (read_at IS NULL OR read_at = 0)'
                )->execute([':now' => $now, ':other' => $toUser, ':me' => $fromUser]);
            } catch (\Throwable $__) { /* ignore */ }

            $tz = new \DateTimeZone('Europe/Istanbul');
            $dt = (new \DateTimeImmutable('@' . $now))->setTimezone($tz);
            $row = [
                'message_id'      => $id,
                'from_id'         => $fromUser,
                'to_id'           => $toUser,
                'message'         => '',
                'message_time'    => $now,
                'message_time_hm' => $dt->format('H:i'),
                'direction'       => 'outgoing',
                'avatar'          => $this->RL_userAvatar($fromUser),
                'ymd'             => $dt->format('Y-m-d'),
                'file'            => $fileRelative,
                'file_kind'       => $kind,
                'reply_to_message_id' => 0,
                'delivered_at'    => null,
                'read_at'         => null,
                'deleted_at'      => null,
                'deleted_by'      => null,
            ];
            $decorated = $this->RL_DecorateChatRows([$row], $fromUser, $toUser);
            return $decorated[0] ?? $row;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_SendFileMessage failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    /**
     * Mark typing state between two users.
     * If $isTyping = true, upserts a row with current timestamp.
     * If $isTyping = false, deletes the row to clear the indicator.
     * Table schema:
     *   i_chat_typing(who_id INT, with_id INT, updated_at INT, PRIMARY KEY(who_id, with_id))
     */
    public function RL_SetTyping(int $whoId, int $withId, bool $isTyping): array
    {
        $whoId  = (int) $whoId;
        $withId = (int) $withId;

        if ($whoId <= 0 || $withId <= 0) {
            return ['error' => 'invalid_input'];
        }

        try {
            if ($isTyping) {
                $sql = "INSERT INTO i_chat_typing (who_id, with_id, updated_at)
                        VALUES (:who, :with, :ts)
                        ON DUPLICATE KEY UPDATE updated_at = VALUES(updated_at)";
                $st  = $this->db->prepare($sql);
                $st->bindValue(':who', $whoId, \PDO::PARAM_INT);
                $st->bindValue(':with', $withId, \PDO::PARAM_INT);
                $st->bindValue(':ts', time(), \PDO::PARAM_INT);
                $st->execute();
            } else {
                $sql = 'DELETE FROM i_chat_typing WHERE who_id = :who AND with_id = :with';
                $st  = $this->db->prepare($sql);
                $st->bindValue(':who', $whoId, \PDO::PARAM_INT);
                $st->bindValue(':with', $withId, \PDO::PARAM_INT);
                $st->execute();
            }
            return ['ok' => true, 'is_typing' => $isTyping];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_SetTyping failed: ' . $e->getMessage());
            }
            return ['error' => 'db_error'];
        }
    }

    /**
     * Return last N outgoing messages' status for a pair (from me to with).
     */
    public function RL_GetOutgoingMessageStatuses(int $me, int $with, int $limit = 40): array
    {
        $limit = max(1, min(100, (int)$limit));
        try {
            $st = $this->db->prepare('SELECT message_id, delivered_at, read_at FROM i_messages WHERE user_one = :me AND user_two = :with ORDER BY message_time DESC, message_id DESC LIMIT :lim');
            $st->bindValue(':me', $me, \PDO::PARAM_INT);
            $st->bindValue(':with', $with, \PDO::PARAM_INT);
            $st->bindValue(':lim', $limit, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            foreach ($rows as &$r) {
                $r = [
                    'message_id'   => (int)($r['message_id'] ?? 0),
                    'delivered_at' => (int)($r['delivered_at'] ?? 0),
                    'read_at'      => (int)($r['read_at'] ?? 0),
                ];
            }
            unset($r);
            return $rows;
        } catch (\Throwable $__) { return []; }
    }

    /**
     * Check if a user is currently typing to another user.
     * A row is considered active if updated_at is within the last $staleAfter seconds.
     */
    public function RL_IsTyping(int $whoId, int $withId, int $staleAfter = 8): bool
    {
        $whoId      = (int) $whoId;
        $withId     = (int) $withId;
        $staleAfter = max(1, (int) $staleAfter);
        if ($whoId <= 0 || $withId <= 0) { return false; }

        try {
            $st = $this->db->prepare('SELECT updated_at FROM i_chat_typing WHERE who_id = :who AND with_id = :with');
            $st->bindValue(':who', $whoId, \PDO::PARAM_INT);
            $st->bindValue(':with', $withId, \PDO::PARAM_INT);
            $st->execute();
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) { return false; }
            $updatedAt = (int) ($row['updated_at'] ?? 0);
            return ($updatedAt >= (time() - $staleAfter));
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_IsTyping failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    /**
     * Optional: prune stale typing rows older than $staleAfter seconds.
     * Returns affected rows count.
     */
    public function RL_PruneTyping(int $staleAfter = 30): int
    {
        $cutoff = time() - max(1, (int) $staleAfter);
        try {
            $st = $this->db->prepare('DELETE FROM i_chat_typing WHERE updated_at < :cutoff');
            $st->bindValue(':cutoff', $cutoff, \PDO::PARAM_INT);
            $st->execute();
            return (int) $st->rowCount();
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_PruneTyping failed: ' . $e->getMessage());
            }
            return 0;
        }
    }

    /**
     * Fetch messages older than a timestamp between two users.
     * Returns items sorted ASC by time for natural prepend rendering.
     */
    public function RL_GetChatOlderMessages(int $currentUser, int $targetUser, int $beforeTs, int $limit = 20, string $timezone = 'Europe/Istanbul'): array
    {
        $currentUser = (int) $currentUser;
        $targetUser  = (int) $targetUser;
        $beforeTs    = max(0, (int) $beforeTs);
        $limit       = max(1, min(100, (int) $limit));

        if ($currentUser <= 0 || $targetUser <= 0) { return []; }

        try {
            $cutoff = $this->RL_ConversationVisibilityCutoff($currentUser, $targetUser);
            $sql = 'SELECT message_id, user_one, user_two, message, message_type, metadata, message_time, file, reply_to_message_id, deleted_at, deleted_by
                    FROM i_messages
                    WHERE ((user_one = :me1 AND user_two = :other1)
                       OR  (user_one = :other2 AND user_two = :me2))
                      AND message_time < :before
                      AND (:cutoff1 = 0 OR message_time > :cutoff2)
                    ORDER BY message_time DESC
                    LIMIT ' . $limit;
            $st = $this->db->prepare($sql);
            $st->bindValue(':me1', $currentUser, \PDO::PARAM_INT);
            $st->bindValue(':other1', $targetUser, \PDO::PARAM_INT);
            $st->bindValue(':other2', $targetUser, \PDO::PARAM_INT);
            $st->bindValue(':me2', $currentUser, \PDO::PARAM_INT);
            $st->bindValue(':before', $beforeTs, \PDO::PARAM_INT);
            $st->bindValue(':cutoff1', $cutoff, \PDO::PARAM_INT);
            $st->bindValue(':cutoff2', $cutoff, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            if (!$rows) { return []; }

            $tz = new \DateTimeZone($timezone);
            $out = [];
            foreach ($rows as $r) {
                $fromId = (int) ($r['user_one'] ?? 0);
                $dir    = ($fromId === $currentUser) ? 'outgoing' : 'incoming';
                $ts     = (int) ($r['message_time'] ?? 0);
                $dt     = (new \DateTimeImmutable('@' . $ts))->setTimezone($tz);

                $file   = trim((string) ($r['file'] ?? ''));
                $ext    = $file !== '' ? strtolower(pathinfo($file, PATHINFO_EXTENSION)) : '';
                $kind   = '';
                if ($file !== '') {
                    if (in_array($ext, ['jpg','jpeg','png','gif','webp'], true)) { $kind = 'image'; }
                    elseif (in_array($ext, ['mp4','mov','m4v','webm','avi'], true)) { $kind = 'video'; }
                }

                $out[]  = [
                    'message_id'      => (int) ($r['message_id'] ?? 0),
                    'from_id'         => $fromId,
                    'to_id'           => (int)($r['user_two'] ?? 0),
                    'message'         => (string) ($r['message'] ?? ''),
                    'message_type'    => (string) ($r['message_type'] ?? 'text'),
                    'metadata'        => $r['metadata'] ?? null,
                    'message_time'    => $ts,
                    'message_time_hm' => $dt->format('H:i'),
                    'direction'       => $dir,
                    'avatar'          => $this->RL_userAvatar($fromId),
                    'ymd'             => $dt->format('Y-m-d'),
                    'file'            => $file,
                    'file_kind'       => $kind,
                    'reply_to_message_id' => (int)($r['reply_to_message_id'] ?? 0),
                    'deleted_at'      => (int)($r['deleted_at'] ?? 0),
                    'deleted_by'      => (int)($r['deleted_by'] ?? 0),
                ];
            }

            // Currently DESC, reverse to ASC for prepend in natural order
            return $this->RL_DecorateChatRows(array_reverse($out), $currentUser, $targetUser);
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetChatOlderMessages failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    /**
     * Build the right-side conversation details payload for the full messages page.
     *
     * Uses the existing user/profile/media schema:
     * - i_users + RL_GetUserCover for profile identity
     * - i_messages.file for shared images, videos and shared posts
     * - URL extraction from text messages for shared links
     */
    public function RL_GetConversationDetailsPayload(int $currentUser, int $targetUser, string $baseUrl = '', int $limit = 6): array
    {
        $currentUser = (int)$currentUser;
        $targetUser = (int)$targetUser;
        $limit = max(1, min(12, (int)$limit));
        $baseUrl = rtrim((string)$baseUrl, '/');

        if ($currentUser <= 0 || $targetUser <= 0) {
            return [
                'user' => null,
                'shared' => ['media' => [], 'links' => [], 'posts' => []],
                'counts' => ['media' => 0, 'links' => 0, 'posts' => 0],
            ];
        }

        $safeStorageUrl = static function (string $path) use ($baseUrl): string {
            $path = trim($path);
            if ($path === '') {
                return '';
            }
            if (function_exists('storage_url')) {
                try {
                    return (string)storage_url($path);
                } catch (\Throwable $__) {
                    // fall through
                }
            }
            return ($baseUrl !== '' ? $baseUrl : '') . '/' . ltrim($path, '/');
        };
        $formatPrice = static function ($price, string $currency): string {
            $currency = strtoupper(trim($currency) ?: 'USD');
            $symbol = $currency;
            $map = [];
            if (isset($GLOBALS['currencies']) && is_array($GLOBALS['currencies'])) {
                $map = $GLOBALS['currencies'];
            } elseif (isset($GLOBALS['currencys']) && is_array($GLOBALS['currencys'])) {
                $map = $GLOBALS['currencys'];
            }
            if (isset($map[$currency])) {
                $symbol = (string)$map[$currency];
            }
            $amount = number_format((float)$price, 2, '.', '');
            return mb_strlen($symbol) <= 4 ? ($symbol . $amount) : ($amount . ' ' . $currency);
        };

        $userPayload = null;
        try {
            $pair = $this->RL_GetConversationUsers($currentUser, $targetUser);
            $other = $pair['other'] ?? null;
            if (is_array($other)) {
                $username = (string)($other['username'] ?? '');
                $fullName = trim((string)($other['user_fullname'] ?? ''));
                if ($fullName === '') {
                    $fullName = $username;
                }
                $avatarRel = (string)($other['avatar'] ?? 'uploads/user_avatars/default.jpeg');
                $coverRel = '';
                if (method_exists($this, 'RL_GetUserCover')) {
                    try {
                        $coverRel = (string)$this->RL_GetUserCover($targetUser);
                    } catch (\Throwable $__) {
                        $coverRel = '';
                    }
                }
                $profileUrl = $username !== ''
                    ? (($baseUrl !== '' ? $baseUrl : '') . '/profile/' . rawurlencode($username))
                    : '#';

                $userPayload = [
                    'id' => $targetUser,
                    'fullname' => $fullName,
                    'username' => $username,
                    'avatar_url' => $safeStorageUrl($avatarRel),
                    'cover_url' => $coverRel !== '' ? $safeStorageUrl($coverRel) : '',
                    'profile_url' => $profileUrl,
                    'verified' => (int)($other['verified_status'] ?? 0) === 1,
                ];
            }
        } catch (\Throwable $__) {
            $userPayload = null;
        }

        $media = [];
        $links = [];
        $posts = [];
        $counts = ['media' => 0, 'links' => 0, 'posts' => 0];

        try {
            $sql = 'SELECT message_id, message, file, message_time
                    FROM i_messages
                    WHERE ((user_one = :me1 AND user_two = :other1)
                       OR  (user_one = :other2 AND user_two = :me2))
                      AND (
                            (file IS NOT NULL AND file <> "")
                         OR message REGEXP "https?://"
                      )
                    ORDER BY message_time DESC
                    LIMIT 300';
            $st = $this->db->prepare($sql);
            $st->bindValue(':me1', $currentUser, \PDO::PARAM_INT);
            $st->bindValue(':other1', $targetUser, \PDO::PARAM_INT);
            $st->bindValue(':other2', $targetUser, \PDO::PARAM_INT);
            $st->bindValue(':me2', $currentUser, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            $seenMedia = [];
            $seenLinks = [];
            $seenPosts = [];
            foreach ($rows as $row) {
                $messageId = (int)($row['message_id'] ?? 0);
                $message = (string)($row['message'] ?? '');
                $file = trim((string)($row['file'] ?? ''));
                $time = (int)($row['message_time'] ?? 0);

                if ($file !== '') {
                    if (preg_match('/^post:(\d+)$/i', $file, $m)) {
                        $postId = (int)$m[1];
                        if ($postId > 0 && !isset($seenPosts[$postId])) {
                            $seenPosts[$postId] = true;
                            $counts['posts']++;
                            if (count($posts) < $limit) {
                                $posts[] = [
                                    'id' => $postId,
                                    'message_id' => $messageId,
                                    'url' => ($baseUrl !== '' ? $baseUrl : '') . '/posts/' . $postId,
                                    'label' => 'Shared post',
                                    'time' => $time,
                                ];
                            }
                        }
                    } else {
                        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                        $type = '';
                        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)) {
                            $type = 'image';
                        } elseif (in_array($ext, ['mp4', 'mov', 'm4v', 'webm', 'avi'], true)) {
                            $type = 'video';
                        }

                        if ($type !== '' && !isset($seenMedia[$file])) {
                            $seenMedia[$file] = true;
                            $counts['media']++;
                            $media[] = [
                                'type' => $type,
                                'message_id' => $messageId,
                                'url' => $safeStorageUrl($file),
                                'label' => $type === 'video' ? 'Video' : 'Image',
                                'time' => $time,
                                'paid' => false,
                                'locked' => false,
                            ];
                        }
                    }
                }

                if ($message !== '' && preg_match_all('~https?://[^\s<>"\']+~i', $message, $matches)) {
                    foreach ($matches[0] as $url) {
                        $url = rtrim((string)$url, '.,);]');
                        if ($url === '' || isset($seenLinks[$url])) {
                            continue;
                        }
                        $seenLinks[$url] = true;
                        $counts['links']++;
                        if (count($links) < $limit) {
                            $host = parse_url($url, PHP_URL_HOST);
                            $links[] = [
                                'message_id' => $messageId,
                                'url' => $url,
                                'label' => $host ? (string)$host : $url,
                                'time' => $time,
                            ];
                        }
                    }
                }
            }

            $paidSql = 'SELECT pm.paid_media_id, pm.message_id, pm.creator_id, pm.recipient_id,
                               pm.file_path, pm.preview_path, pm.media_type, pm.price, pm.currency,
                               m.message_time, u.unlock_id
                        FROM i_chat_paid_media pm
                        INNER JOIN i_messages m ON m.message_id = pm.message_id
                        LEFT JOIN i_chat_deletions d ON d.message_id = m.message_id AND d.user_id = :deleted_user
                        LEFT JOIN i_chat_paid_media_unlocks u
                               ON u.paid_media_id = pm.paid_media_id
                              AND u.buyer_id = :buyer_id
                              AND u.status = "succeeded"
                        WHERE ((m.user_one = :p_me1 AND m.user_two = :p_other1)
                           OR  (m.user_one = :p_other2 AND m.user_two = :p_me2))
                          AND pm.status = "active"
                          AND (m.deleted_at IS NULL OR m.deleted_at = 0)
                          AND d.message_id IS NULL
                        ORDER BY m.message_time DESC, pm.message_id DESC
                        LIMIT 300';
            $pst = $this->db->prepare($paidSql);
            $pst->bindValue(':deleted_user', $currentUser, \PDO::PARAM_INT);
            $pst->bindValue(':buyer_id', $currentUser, \PDO::PARAM_INT);
            $pst->bindValue(':p_me1', $currentUser, \PDO::PARAM_INT);
            $pst->bindValue(':p_other1', $targetUser, \PDO::PARAM_INT);
            $pst->bindValue(':p_other2', $targetUser, \PDO::PARAM_INT);
            $pst->bindValue(':p_me2', $currentUser, \PDO::PARAM_INT);
            $pst->execute();
            foreach ($pst->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $paidRow) {
                $messageId = (int)($paidRow['message_id'] ?? 0);
                $paidId = (int)($paidRow['paid_media_id'] ?? 0);
                if ($messageId <= 0 || $paidId <= 0 || isset($seenMedia['paid:' . $paidId])) {
                    continue;
                }
                $seenMedia['paid:' . $paidId] = true;
                $creatorId = (int)($paidRow['creator_id'] ?? 0);
                $mediaType = (string)($paidRow['media_type'] ?? 'image');
                $currency = strtoupper((string)($paidRow['currency'] ?? 'USD'));
                $isUnlocked = $creatorId === $currentUser || (int)($paidRow['unlock_id'] ?? 0) > 0;
                $counts['media']++;
                $media[] = [
                    'type' => $mediaType === 'video' ? 'video' : 'image',
                    'message_id' => $messageId,
                    'paid_media_id' => $paidId,
                    'url' => $isUnlocked ? $safeStorageUrl((string)($paidRow['file_path'] ?? '')) : '',
                    'preview_url' => !$isUnlocked ? $safeStorageUrl((string)($paidRow['preview_path'] ?? '')) : '',
                    'label' => $isUnlocked ? ($mediaType === 'video' ? 'Paid video' : 'Paid image') : 'Locked media',
                    'time' => (int)($paidRow['message_time'] ?? 0),
                    'paid' => true,
                    'locked' => !$isUnlocked,
                    'price' => number_format((float)($paidRow['price'] ?? 0), 2, '.', ''),
                    'currency' => $currency,
                    'price_label' => $formatPrice($paidRow['price'] ?? 0, $currency),
                ];
            }

            usort($media, static function (array $a, array $b): int {
                return ((int)($b['time'] ?? 0) <=> (int)($a['time'] ?? 0));
            });
            $media = array_slice($media, 0, $limit);
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetConversationDetailsPayload failed: ' . $e->getMessage());
            }
        }

        return [
            'user' => $userPayload,
            'shared' => [
                'media' => $media,
                'links' => $links,
                'posts' => $posts,
            ],
            'counts' => $counts,
        ];
    }

    /**
     * Return a paginated asset list for the full-page conversation details panel.
     */
    public function RL_GetConversationAssetsPayload(int $currentUser, int $targetUser, string $type, string $baseUrl = '', int $limit = 24, int $offset = 0): array
    {
        $currentUser = (int)$currentUser;
        $targetUser = (int)$targetUser;
        $type = strtolower(trim($type));
        $limit = max(1, min(60, (int)$limit));
        $offset = max(0, min(1000, (int)$offset));
        $baseUrl = rtrim((string)$baseUrl, '/');
        $allowed = ['media', 'links', 'posts'];

        if ($currentUser <= 0 || $targetUser <= 0 || !in_array($type, $allowed, true)) {
            return [
                'type' => in_array($type, $allowed, true) ? $type : 'media',
                'items' => [],
                'total' => 0,
                'limit' => $limit,
                'offset' => $offset,
                'has_more' => false,
            ];
        }

        $safeStorageUrl = static function (string $path) use ($baseUrl): string {
            $path = trim($path);
            if ($path === '') {
                return '';
            }
            if (function_exists('storage_url')) {
                try {
                    return (string)storage_url($path);
                } catch (\Throwable $__) {
                    // fall through
                }
            }
            return ($baseUrl !== '' ? $baseUrl : '') . '/' . ltrim($path, '/');
        };
        $formatPrice = static function ($price, string $currency): string {
            $currency = strtoupper(trim($currency) ?: 'USD');
            $symbol = $currency;
            $map = [];
            if (isset($GLOBALS['currencies']) && is_array($GLOBALS['currencies'])) {
                $map = $GLOBALS['currencies'];
            } elseif (isset($GLOBALS['currencys']) && is_array($GLOBALS['currencys'])) {
                $map = $GLOBALS['currencys'];
            }
            if (isset($map[$currency])) {
                $symbol = (string)$map[$currency];
            }
            $amount = number_format((float)$price, 2, '.', '');
            return mb_strlen($symbol) <= 4 ? ($symbol . $amount) : ($amount . ' ' . $currency);
        };

        $items = [];
        try {
            $sql = 'SELECT message_id, message, file, message_time
                    FROM i_messages
                    WHERE ((user_one = :me1 AND user_two = :other1)
                       OR  (user_one = :other2 AND user_two = :me2))
                      AND (
                            (file IS NOT NULL AND file <> "")
                         OR message REGEXP "https?://"
                      )
                    ORDER BY message_time DESC, message_id DESC
                    LIMIT 500';
            $st = $this->db->prepare($sql);
            $st->bindValue(':me1', $currentUser, \PDO::PARAM_INT);
            $st->bindValue(':other1', $targetUser, \PDO::PARAM_INT);
            $st->bindValue(':other2', $targetUser, \PDO::PARAM_INT);
            $st->bindValue(':me2', $currentUser, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            $seen = [];
            foreach ($rows as $row) {
                $messageId = (int)($row['message_id'] ?? 0);
                $message = (string)($row['message'] ?? '');
                $file = trim((string)($row['file'] ?? ''));
                $time = (int)($row['message_time'] ?? 0);

                if (($type === 'media' || $type === 'posts') && $file !== '') {
                    if ($type === 'posts' && preg_match('/^post:(\d+)$/i', $file, $m)) {
                        $postId = (int)$m[1];
                        if ($postId > 0 && !isset($seen['post:' . $postId])) {
                            $seen['post:' . $postId] = true;
                            $items[] = [
                                'id' => $postId,
                                'message_id' => $messageId,
                                'url' => ($baseUrl !== '' ? $baseUrl : '') . '/posts/' . $postId,
                                'label' => 'Shared post',
                                'time' => $time,
                            ];
                        }
                    } elseif ($type === 'media') {
                        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                        $mediaType = '';
                        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)) {
                            $mediaType = 'image';
                        } elseif (in_array($ext, ['mp4', 'mov', 'm4v', 'webm', 'avi'], true)) {
                            $mediaType = 'video';
                        }
                        if ($mediaType !== '' && !isset($seen['media:' . $file])) {
                            $seen['media:' . $file] = true;
                            $items[] = [
                                'type' => $mediaType,
                                'message_id' => $messageId,
                                'url' => $safeStorageUrl($file),
                                'label' => $mediaType === 'video' ? 'Video' : 'Image',
                                'time' => $time,
                                'paid' => false,
                                'locked' => false,
                            ];
                        }
                    }
                }

                if ($type === 'links' && $message !== '' && preg_match_all('~https?://[^\s<>"\']+~i', $message, $matches)) {
                    foreach ($matches[0] as $url) {
                        $url = rtrim((string)$url, '.,);]');
                        if ($url === '' || isset($seen['link:' . $url])) {
                            continue;
                        }
                        $seen['link:' . $url] = true;
                        $host = parse_url($url, PHP_URL_HOST);
                        $items[] = [
                            'message_id' => $messageId,
                            'url' => $url,
                            'label' => $host ? (string)$host : $url,
                            'time' => $time,
                        ];
                    }
                }
            }

            if ($type === 'media') {
                $paidSql = 'SELECT pm.paid_media_id, pm.message_id, pm.creator_id, pm.recipient_id,
                                   pm.file_path, pm.preview_path, pm.media_type, pm.price, pm.currency,
                                   m.message_time, u.unlock_id
                            FROM i_chat_paid_media pm
                            INNER JOIN i_messages m ON m.message_id = pm.message_id
                            LEFT JOIN i_chat_deletions d ON d.message_id = m.message_id AND d.user_id = :deleted_user
                            LEFT JOIN i_chat_paid_media_unlocks u
                                   ON u.paid_media_id = pm.paid_media_id
                                  AND u.buyer_id = :buyer_id
                                  AND u.status = "succeeded"
                            WHERE ((m.user_one = :p_me1 AND m.user_two = :p_other1)
                               OR  (m.user_one = :p_other2 AND m.user_two = :p_me2))
                              AND pm.status = "active"
                              AND (m.deleted_at IS NULL OR m.deleted_at = 0)
                              AND d.message_id IS NULL
                            ORDER BY m.message_time DESC, pm.message_id DESC
                            LIMIT 500';
                $pst = $this->db->prepare($paidSql);
                $pst->bindValue(':deleted_user', $currentUser, \PDO::PARAM_INT);
                $pst->bindValue(':buyer_id', $currentUser, \PDO::PARAM_INT);
                $pst->bindValue(':p_me1', $currentUser, \PDO::PARAM_INT);
                $pst->bindValue(':p_other1', $targetUser, \PDO::PARAM_INT);
                $pst->bindValue(':p_other2', $targetUser, \PDO::PARAM_INT);
                $pst->bindValue(':p_me2', $currentUser, \PDO::PARAM_INT);
                $pst->execute();
                foreach ($pst->fetchAll(\PDO::FETCH_ASSOC) ?: [] as $paidRow) {
                    $messageId = (int)($paidRow['message_id'] ?? 0);
                    $paidId = (int)($paidRow['paid_media_id'] ?? 0);
                    if ($messageId <= 0 || $paidId <= 0 || isset($seen['paid:' . $paidId])) {
                        continue;
                    }
                    $seen['paid:' . $paidId] = true;
                    $creatorId = (int)($paidRow['creator_id'] ?? 0);
                    $mediaType = (string)($paidRow['media_type'] ?? 'image');
                    $currency = strtoupper((string)($paidRow['currency'] ?? 'USD'));
                    $isUnlocked = $creatorId === $currentUser || (int)($paidRow['unlock_id'] ?? 0) > 0;
                    $items[] = [
                        'type' => $mediaType === 'video' ? 'video' : 'image',
                        'message_id' => $messageId,
                        'paid_media_id' => $paidId,
                        'url' => $isUnlocked ? $safeStorageUrl((string)($paidRow['file_path'] ?? '')) : '',
                        'preview_url' => !$isUnlocked ? $safeStorageUrl((string)($paidRow['preview_path'] ?? '')) : '',
                        'label' => $isUnlocked ? ($mediaType === 'video' ? 'Paid video' : 'Paid image') : 'Locked media',
                        'time' => (int)($paidRow['message_time'] ?? 0),
                        'paid' => true,
                        'locked' => !$isUnlocked,
                        'price' => number_format((float)($paidRow['price'] ?? 0), 2, '.', ''),
                        'currency' => $currency,
                        'price_label' => $formatPrice($paidRow['price'] ?? 0, $currency),
                    ];
                }

                usort($items, static function (array $a, array $b): int {
                    return ((int)($b['time'] ?? 0) <=> (int)($a['time'] ?? 0));
                });
            }
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetConversationAssetsPayload failed: ' . $e->getMessage());
            }
            $items = [];
        }

        $total = count($items);
        $page = array_slice($items, $offset, $limit);

        return [
            'type' => $type,
            'items' => $page,
            'total' => $total,
            'limit' => $limit,
            'offset' => $offset,
            'has_more' => ($offset + $limit) < $total,
        ];
    }
}
