<?php

declare(strict_types=1);

/**
 * Follow / Unfollow data-layer helpers.
 *
 * Conventions:
 * - i_friends.fr_one = follower (actor)
 * - i_friends.fr_two = followee (target)
 * - i_friends.fr_status:
 *     'flwr'       -> follows
 *     'subscriber' -> paid subscriber (do NOT delete this on unfollow)
 *     'me'         -> self row bootstrap (ignored)
 */
trait FollowUnfollowFunctions
{

    /**
     * Returns true if $actorId follows $targetId (status = 'flwr').
     */
    public function RL_IsFollowing(int $actorId, int $targetId): bool
    {
        if ($actorId <= 0 || $targetId <= 0 || $actorId === $targetId) {
            return false;
        }
        $sql = "SELECT 1
                  FROM i_friends
                 WHERE fr_one = :one
                   AND fr_two = :two
                   AND fr_status = 'flwr'
                 LIMIT 1";
        $st = $this->db->prepare($sql);
        $st->bindValue(':one', $actorId, \PDO::PARAM_INT);
        $st->bindValue(':two', $targetId, \PDO::PARAM_INT);
        $st->execute();
        return (bool) $st->fetchColumn();
    }

    /** Returns true if $actorId is subscriber of $targetId (status = 'subscriber'). */
    public function RL_IsSubscriber(int $actorId, int $targetId): bool
    {
        if ($actorId <= 0 || $targetId <= 0 || $actorId === $targetId) {
            return false;
        }
        $sql = "SELECT 1 FROM i_friends WHERE fr_one = :one AND fr_two = :two AND fr_status = 'subscriber' LIMIT 1";
        $st = $this->db->prepare($sql);
        $st->bindValue(':one', $actorId, \PDO::PARAM_INT);
        $st->bindValue(':two', $targetId, \PDO::PARAM_INT);
        $st->execute();
        return (bool)$st->fetchColumn();
    }

    /**
     * Toggle follow (insert/delete 'flwr' relation).
     *
     * @return array{following: bool, followers: int, following_count: int}
     *         - following: current state after toggle (true = now following)
     *         - followers: target's follower count (flwr + subscriber)
     *         - following_count: actor's following count (flwr + subscriber)
     */
    public function RL_ToggleFollow(int $actorId, int $targetId, int $time): array
    {
        if ($actorId <= 0 || $targetId <= 0 || $actorId === $targetId) {
            return ['following' => false, 'followers' => 0, 'following_count' => 0];
        }

        $this->db->beginTransaction();
        try {
            // Check existing plain follow
            $sqlSel = "SELECT fr_id FROM i_friends
                       WHERE fr_one = :one AND fr_two = :two AND fr_status = 'flwr'
                       LIMIT 1";
            $stSel = $this->db->prepare($sqlSel);
            $stSel->execute([':one' => $actorId, ':two' => $targetId]);
            $rowId = (int) ($stSel->fetchColumn() ?: 0);

            if ($rowId > 0) {
                // UNFOLLOW: delete only 'flwr' row (keep any 'subscriber' rows intact)
                $stDel = $this->db->prepare("DELETE FROM i_friends WHERE fr_id = :id");
                $stDel->bindValue(':id', $rowId, \PDO::PARAM_INT);
                $stDel->execute();
                $following = false;
            } else {
                // FOLLOW: upsert 'flwr'
                $stIns = $this->db->prepare("
                    INSERT INTO i_friends (fr_one, fr_two, fr_time, fr_status)
                    VALUES (:one, :two, :time, 'flwr')
                ");
                $stIns->execute([
                    ':one'  => $actorId,
                    ':two'  => $targetId,
                    ':time' => $time,
                ]);
                $following = true;
            }

            // Recompute counts
            $followers = $this->RL_CountFollowers($targetId);      // target's followers
            $followingCount = $this->RL_CountFollowing($actorId);  // actor's following

            $this->db->commit();

            if ($following && method_exists($this, 'RL_CreateNotification')) {
                try {
                    $this->RL_CreateNotification(
                        $targetId,
                        $actorId,
                        'follow',
                        $actorId,
                        null,
                        ['kind' => 'follow'],
                        $time
                    );
                } catch (\Throwable $notifyError) {
                    if (method_exists($this, 'logError')) {
                        $this->logError('follow notification failed: ' . $notifyError->getMessage());
                    }
                }
            }

            return [
                'following'        => $following,
                'followers'        => $followers,
                'following_count'  => $followingCount,
            ];
        } catch (\Throwable $e) {
            $this->db->rollBack();
            if (method_exists($this, 'logError')) {
                $this->logError('RL_ToggleFollow failed: ' . $e->getMessage());
            }
            return ['following' => false, 'followers' => 0, 'following_count' => 0];
        }
    }

    /**
     * Followers of target = rows where fr_two = target AND status in ('flwr','subscriber').
     */
    public function RL_CountFollowers(int $targetId): int
    {
        if ($targetId <= 0) {
            return 0;
        }
        $sql = "SELECT COUNT(*)
                  FROM i_friends
                 WHERE fr_two = :uid
                   AND fr_status IN ('flwr','subscriber')";
        $st = $this->db->prepare($sql);
        $st->bindValue(':uid', $targetId, \PDO::PARAM_INT);
        $st->execute();
        return (int) $st->fetchColumn();
    }

    /**
     * Following count of actor = rows where fr_one = actor AND status in ('flwr','subscriber').
     */
    public function RL_CountFollowing(int $actorId): int
    {
        if ($actorId <= 0) {
            return 0;
        }
        $sql = "SELECT COUNT(*)
                  FROM i_friends
                 WHERE fr_one = :uid
                   AND fr_status IN ('flwr','subscriber')";
        $st = $this->db->prepare($sql);
        $st->bindValue(':uid', $actorId, \PDO::PARAM_INT);
        $st->execute();
        return (int) $st->fetchColumn();
    }
}
