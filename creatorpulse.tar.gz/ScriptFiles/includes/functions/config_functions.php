<?php
declare(strict_types=1);
trait ConfigFunctions {
    /**
     * Retrieve site configuration settings.
     *
     * This method fetches the configuration row from the d_site_configurations table.
     *
     * @return array Returns the configuration data as an associative array, or an array with an error message.
     */
    public function RL_configs(): array {
        try {
            $query = "SELECT * FROM `i_site_configurations` WHERE `id` = :id";
            $stmt = $this->db->prepare($query);

            $id = 1;
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();

            $data = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$data) {
                $this->logError("No configuration data found for ID: $id");
                return ['error' => "Configuration data couldn't be retrieved."];
            }

            return $data;
        } catch (PDOException $e) {
            $this->logError("RL_configs() failed: " . $e->getMessage());
            return ['error' => "An unexpected error occurred. Please try again later."];
        }
    }

    /**
     * Get a translation value by language code and key.
     *
     * If the exact key doesn't match, it will also try with underscores replaced by dashes.
     *
     * @param string $languageCode The language code (e.g., "en", "tr").
     * @param string $value The translation key to look up.
     * @return string Returns the translated value, or 'no' if not found.
     */
    public function RL_GetWord(string $languageCode, string $value): string {
        try {
            $query = "
                SELECT t.value
                FROM i_words t
                INNER JOIN i_languages l ON t.language_id = l.id
                WHERE l.code = :lang_code
                AND (t.w_key = :wkey OR REPLACE(t.w_key, '_', '-') = :wkey_dash)
                LIMIT 1
            ";

            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':lang_code', $languageCode, PDO::PARAM_STR);
            $stmt->bindParam(':wkey', $value, PDO::PARAM_STR);
            $stmt->bindParam(':wkey_dash', $value, PDO::PARAM_STR);
            $stmt->execute();

            $translation = $stmt->fetch(PDO::FETCH_ASSOC);

            return $translation['value'] ?? 'no';
        } catch (PDOException $e) {
            $this->logError("RL_GetWord() failed: " . $e->getMessage());
            return 'no';
        }
    }

    /**
     * Return guest feed configuration with normalized defaults.
     *
     * @return array{guest_feed_mode:string,guest_admin_ids:array<int>}
     */
    public function RL_GetGuestFeedConfig(): array {
        $defaults = [
            'guest_feed_mode'   => 'admin_only',
            'guest_admin_ids'   => [1],
        ];

        $config = (array)($this->RL_configs() ?? []);

        $mode = $defaults['guest_feed_mode'];
        if (isset($config['guest_feed_mode']) && is_string($config['guest_feed_mode'])) {
            $candidate = trim($config['guest_feed_mode']);
            if ($candidate !== '') {
                $mode = $candidate;
            }
        }

        $adminIdsRaw = $config['guest_admin_ids'] ?? $defaults['guest_admin_ids'];
        $adminIds = [];

        if (is_string($adminIdsRaw)) {
            $decoded = json_decode($adminIdsRaw, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                $adminIdsRaw = $decoded;
            } else {
                $adminIdsRaw = array_map('trim', explode(',', $adminIdsRaw));
            }
        }

        if (is_array($adminIdsRaw)) {
            foreach ($adminIdsRaw as $id) {
                if (is_numeric($id)) {
                    $adminIds[] = (int)$id;
                }
            }
        }

        $adminIds = array_values(array_unique(array_filter($adminIds, static fn($v) => $v > 0)));
        if ($adminIds === []) {
            $adminIds = $defaults['guest_admin_ids'];
        }

        return [
            'guest_feed_mode' => $mode,
            'guest_admin_ids' => $adminIds,
        ];
    }
}
