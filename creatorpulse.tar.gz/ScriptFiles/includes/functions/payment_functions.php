<?php
declare(strict_types=1);
trait PaymentFunctions {
    /**
     * Check if a user purchased a locked post.
     *
     * Replace this stub with your real purchase lookup.
     *
     * @param int $userID
     * @param int $postID
     * @return bool
     */
    public function hasPurchasedPost(int $userID, int $postID): bool
    {
        try {
            $q = "SELECT 1 FROM i_post_purchases WHERE buyer_id = :uid AND post_id = :pid AND status = 'succeeded' LIMIT 1";
            $st = $this->db->prepare($q);
            $st->execute([':uid' => $userID, ':pid' => $postID]);
            return (bool)$st->fetchColumn();
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Encode arbitrary payloads into JSON while tolerating invalid UTF-8 or partial data.
     */
    private function RL_EncodeJsonPayload($payload): string
    {
        $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
        if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
            $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
        }
        if (defined('JSON_PARTIAL_OUTPUT_ON_ERROR')) {
            $flags |= JSON_PARTIAL_OUTPUT_ON_ERROR;
        }

        $encoded = json_encode($payload, $flags);
        if ($encoded !== false) {
            return $encoded;
        }

        $fallback = [
            'error'   => 'json_encode_failed',
            'message' => function_exists('json_last_error_msg') ? json_last_error_msg() : 'unknown',
        ];

        $encodedFallback = json_encode($fallback, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return $encodedFallback !== false ? $encodedFallback : 'null';
    }

    // Ensure purchases table exists
    private function RL_EnsurePostPurchasesTable(): void
    {
        try {
            $sql = "CREATE TABLE IF NOT EXISTS i_post_purchases (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                buyer_id INT UNSIGNED NOT NULL,
                recipient_id INT UNSIGNED NOT NULL,
                post_id INT UNSIGNED NOT NULL,
                provider VARCHAR(32) NOT NULL,
                reference VARCHAR(191) NOT NULL,
                amount DECIMAL(10,2) NULL,
                currency VARCHAR(10) NULL,
                status VARCHAR(32) NOT NULL,
                event VARCHAR(64) NULL,
                fee_amount DECIMAL(10,2) NULL,
                fee_currency VARCHAR(10) NULL,
                tax_amount DECIMAL(10,2) NULL,
                net_amount DECIMAL(10,2) NULL,
                raw_payload MEDIUMTEXT NULL,
                unlocked_at INT UNSIGNED NULL,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_provider_ref (provider, reference),
                KEY idx_post (post_id),
                KEY idx_recipient (recipient_id),
                KEY idx_buyer (buyer_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
            $this->db->exec($sql);
        } catch (\Throwable $e) {}
    }

    public function RL_RecordPostPurchase(
        int $buyerId,
        int $recipientId,
        int $postId,
        string $provider,
        string $reference,
        float $amount,
        string $currency,
        string $status = 'pending',
        string $event = '',
        array $raw = []
    ): bool {
        $this->RL_EnsurePostPurchasesTable();
        try {
            $sql = "INSERT INTO i_post_purchases
                    (buyer_id, recipient_id, post_id, provider, reference, amount, currency, status, event, raw_payload, created_at, updated_at)
                    VALUES (:buyer, :rec, :post, :prov, :ref, :amt, :cur, :st, :ev, :raw, :t, NULL)
                    ON DUPLICATE KEY UPDATE amount=VALUES(amount), currency=VALUES(currency), status=VALUES(status), event=VALUES(event), raw_payload=VALUES(raw_payload), updated_at=VALUES(created_at)";
            $st = $this->db->prepare($sql);
            $t = time();
            return $st->execute([
                ':buyer'=>$buyerId, ':rec'=>$recipientId, ':post'=>$postId,
                ':prov'=>$provider, ':ref'=>$reference, ':amt'=>$amount, ':cur'=>$currency,
                ':st'=>$status, ':ev'=>$event, ':raw'=>json_encode($raw, JSON_UNESCAPED_UNICODE), ':t'=>$t
            ]);
        } catch (\Throwable $e) { return false; }
    }

    public function RL_UpdatePostPurchaseStatusByReference(string $provider, string $reference, string $status, string $event = '', array $raw = []): bool
    {
        $this->RL_EnsurePostPurchasesTable();
        try {
            $sql = "UPDATE i_post_purchases SET status=:st, event=:ev, raw_payload=:raw, updated_at=:t WHERE provider=:prov AND reference=:ref";
            $st = $this->db->prepare($sql);
            return $st->execute([':st'=>$status, ':ev'=>$event, ':raw'=>json_encode($raw, JSON_UNESCAPED_UNICODE), ':t'=>time(), ':prov'=>$provider, ':ref'=>$reference]);
        } catch (\Throwable $e) { return false; }
    }

    public function RL_UpdatePostPurchaseAmountsByReference(
        string $provider, string $reference, ?float $gross, ?string $currency, ?float $feeAmount, ?string $feeCurrency, ?float $taxAmount, ?float $netAmount
    ): bool {
        $this->RL_EnsurePostPurchasesTable();
        try {
            $sql = "UPDATE i_post_purchases
                    SET amount=COALESCE(:amt,amount), currency=COALESCE(:cur,currency), fee_amount=COALESCE(:fee,fee_amount), fee_currency=COALESCE(:feecur,fee_currency), tax_amount=COALESCE(:tax,tax_amount), net_amount=COALESCE(:net,net_amount), updated_at=:t
                    WHERE provider=:prov AND reference=:ref";
            $st = $this->db->prepare($sql);
            return $st->execute([':amt'=>$gross, ':cur'=>$currency, ':fee'=>$feeAmount, ':feecur'=>$feeCurrency, ':tax'=>$taxAmount, ':net'=>$netAmount, ':t'=>time(), ':prov'=>$provider, ':ref'=>$reference]);
        } catch (\Throwable $e) { return false; }
    }

    public function RL_GetPostPurchaseByReference(string $provider, string $reference): ?array
    {
        try {
            $st = $this->db->prepare("SELECT * FROM i_post_purchases WHERE provider=:prov AND reference=:ref LIMIT 1");
            $st->execute([':prov'=>$provider, ':ref'=>$reference]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (\Throwable $e) { return null; }
    }

    /** Check if the user already has a pending purchase for this post. */
    public function RL_HasPendingPostPurchase(int $buyerId, int $postId): bool
    {
        $this->RL_EnsurePostPurchasesTable();
        try {
            $st = $this->db->prepare("SELECT 1 FROM i_post_purchases WHERE buyer_id = :uid AND post_id = :pid AND status = 'pending' LIMIT 1");
            $st->execute([':uid'=>$buyerId, ':pid'=>$postId]);
            return (bool)$st->fetchColumn();
        } catch (\Throwable $e) { return false; }
    }

    public function RL_CreditRecipientForPurchaseByReference(string $provider, string $reference): bool
    {
        $this->RL_EnsurePostPurchasesTable();
        try {
            $db = $this->db; $db->beginTransaction();
            $st = $db->prepare("SELECT * FROM i_post_purchases WHERE provider=:prov AND reference=:ref FOR UPDATE");
            $st->execute([':prov'=>$provider, ':ref'=>$reference]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) { $db->rollBack(); return false; }
            if ((int)($row['unlocked_at'] ?? 0) > 0) { $db->commit(); return true; }
            if (($row['status'] ?? '') !== 'succeeded') { $db->rollBack(); return false; }
            $amount = (float)($row['net_amount'] ?? 0); if ($amount <= 0) { $amount = (float)($row['amount'] ?? 0); }
            $recipientId = (int)$row['recipient_id']; if ($recipientId <= 0 || $amount <= 0) { $db->rollBack(); return false; }
            $db->prepare("UPDATE i_users SET earned = COALESCE(earned,0) + :amt WHERE user_id=:uid")->execute([':amt'=>$amount, ':uid'=>$recipientId]);
            $t = time();
            $db->prepare("UPDATE i_post_purchases SET unlocked_at=:t, updated_at=:t WHERE provider=:prov AND reference=:ref")->execute([':t'=>$t, ':prov'=>$provider, ':ref'=>$reference]);
            $db->commit();
            return true;
        } catch (\Throwable $e) { try{ if($this->db->inTransaction()){$this->db->rollBack();} }catch(\Throwable $__){} return false; }
    }

    public function RL_TransferWalletForPurchase(
        int $buyerId, int $recipientId, int $postId, float $amount, string $currency = 'USD', ?float $feePercent = null, ?float $feeFixed = null, ?float $taxPercent = null
    ): array {
        $amount = round(max(0.0, (float)$amount), 2);
        if ($amount <= 0) { return ['ok'=>false,'error'=>'Invalid amount']; }
        $db = $this->db;
        try {
            $begun = false; try { if(!$db->inTransaction()){ $begun = $db->beginTransaction(); } else { $begun=true; } } catch(\Throwable $__){ $begun=false; }
            $st = $db->prepare("SELECT wallet FROM i_users WHERE user_id=:uid" . ($begun ? " FOR UPDATE" : ""));
            $st->execute([':uid'=>$buyerId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC); if(!$row){ if($begun && $db->inTransaction()){$db->rollBack();} return ['ok'=>false,'error'=>'Buyer not found']; }
            if ($feePercent === null || $feeFixed === null || $taxPercent === null) {
                $fp = isset($GLOBALS['paymentFeePercent']) ? (float)$GLOBALS['paymentFeePercent'] : 0.0;
                $ff = isset($GLOBALS['paymentFeeFixed'])   ? (float)$GLOBALS['paymentFeeFixed']   : 0.0;
                $tp = isset($GLOBALS['paymentTaxPercent']) ? (float)$GLOBALS['paymentTaxPercent'] : 0.0;
            } else { $fp=(float)$feePercent; $ff=(float)$feeFixed; $tp=(float)$taxPercent; }
            $fee = round(($amount * ($fp/100.0)) + $ff, 2);
            $tax = round(($amount * ($tp/100.0)), 2);
            $totalCharge = round($amount + $fee + $tax, 2);
            $balance = (float)($row['wallet'] ?? 0);
            if ($balance < $totalCharge) { if($begun && $db->inTransaction()){$db->rollBack();} return ['ok'=>false,'error'=>'Insufficient wallet balance','balance'=>$balance,'required'=>$totalCharge]; }
            $newBuyerBalance = round($balance - $totalCharge, 2);
            $formattedBuyerBalance = number_format($newBuyerBalance, 2, '.', '');
            $buyerWalletUpdate = $db->prepare('UPDATE i_users SET wallet = :wallet WHERE user_id = :uid');
            $buyerWalletUpdate->execute([':wallet' => $formattedBuyerBalance, ':uid' => $buyerId]);
            $db->prepare("UPDATE i_users SET earned = COALESCE(earned,0) + :amt WHERE user_id=:uid")->execute([':amt'=>$amount, ':uid'=>$recipientId]);
            $reference = 'PURWALLET-' . $buyerId . '-' . $recipientId . '-' . $postId . '-' . time() . '-' . bin2hex(random_bytes(3));
            $this->RL_RecordPostPurchase($buyerId, $recipientId, $postId, 'wallet', $reference, $totalCharge, $currency, 'succeeded', 'wallet_debited', ['source'=>'wallet']);
            $this->RL_UpdatePostPurchaseAmountsByReference('wallet', $reference, $totalCharge, $currency, $fee, $currency, $tax, $amount);
            // Mark unlocked_at immediately for wallet purchases
            try {
                $tNow = time();
                $mark = $db->prepare("UPDATE i_post_purchases SET unlocked_at = :t, updated_at = :t WHERE provider = :prov AND reference = :ref");
                $mark->execute([':t'=>$tNow, ':prov'=>'wallet', ':ref'=>$reference]);
            } catch (\Throwable $__) { /* best-effort */ }
            if ($begun && $db->inTransaction()) { $db->commit(); }
            $nb = (float) $formattedBuyerBalance;
            // Notify recipient (post purchase)
            if (method_exists($this, 'RL_CreatePostPurchaseNotification')) {
                $this->RL_CreatePostPurchaseNotification($buyerId, $recipientId, $postId, (float)$amount, (string)$currency, $reference);
            }
            return ['ok'=>true,'reference'=>$reference,'new_balance'=>(float)$nb];
        } catch (\Throwable $e) { try{ if($db->inTransaction()){$db->rollBack();} }catch(\Throwable $__){} return ['ok'=>false,'error'=>$e->getMessage()]; }
    }

    /** Ensure the ad payments table exists (idempotent). */
    private function RL_EnsureAdPaymentsTable(): void
    {
        try {
            $sql = "CREATE TABLE IF NOT EXISTS i_ad_payments (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                ad_id INT UNSIGNED NOT NULL,
                provider VARCHAR(32) NOT NULL,
                reference VARCHAR(191) NOT NULL,
                amount DECIMAL(10,2) NULL, -- gross amount
                currency VARCHAR(10) NULL,
                status VARCHAR(32) NOT NULL,
                event VARCHAR(64) NULL,
                payment_type VARCHAR(32) NOT NULL DEFAULT 'advertisement',
                object_id INT UNSIGNED NULL,
                fee_amount DECIMAL(10,2) NULL,
                fee_currency VARCHAR(10) NULL,
                tax_amount DECIMAL(10,2) NULL,
                net_amount DECIMAL(10,2) NULL,
                raw_payload MEDIUMTEXT NULL,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_provider_ref (provider, reference),
                KEY idx_ad (ad_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
            $this->db->exec($sql);
            // Try to add columns if table already existed without them
            try { $this->db->exec("ALTER TABLE i_ad_payments ADD COLUMN fee_amount DECIMAL(10,2) NULL"); } catch (\Throwable $e) {}
            try { $this->db->exec("ALTER TABLE i_ad_payments ADD COLUMN fee_currency VARCHAR(10) NULL"); } catch (\Throwable $e) {}
            try { $this->db->exec("ALTER TABLE i_ad_payments ADD COLUMN tax_amount DECIMAL(10,2) NULL"); } catch (\Throwable $e) {}
            try { $this->db->exec("ALTER TABLE i_ad_payments ADD COLUMN net_amount DECIMAL(10,2) NULL"); } catch (\Throwable $e) {}
            try { $this->db->exec("ALTER TABLE i_ad_payments ADD COLUMN payment_type VARCHAR(32) NOT NULL DEFAULT 'advertisement'"); } catch (\Throwable $e) {}
            try { $this->db->exec("ALTER TABLE i_ad_payments ADD COLUMN object_id INT UNSIGNED NULL"); } catch (\Throwable $e) {}
        } catch (\Throwable $e) {
            // silent; do not break main flow
        }
    }

    /**
     * Insert a payment row (pending) for an advertisement.
     */
    public function RL_RecordAdPayment(
        int $adId,
        string $provider,
        string $reference,
        float $amount,
        string $currency,
        string $status = 'pending',
        string $event = '',
        array $raw = [],
        string $paymentType = 'advertisement',
        ?int $objectId = null
    ): bool
    {
        $this->RL_EnsureAdPaymentsTable();
        try {
            $sql = "INSERT INTO i_ad_payments
                    (ad_id, provider, reference, amount, currency, status, event, payment_type, object_id, raw_payload, created_at, updated_at)
                    VALUES (:ad, :prov, :ref, :amt, :cur, :st, :ev, :ptype, :oid, :raw, :t, NULL)
                    ON DUPLICATE KEY UPDATE
                        amount = VALUES(amount),
                        currency = VALUES(currency),
                        status = VALUES(status),
                        event = VALUES(event),
                        payment_type = VALUES(payment_type),
                        object_id = VALUES(object_id),
                        raw_payload = VALUES(raw_payload),
                        updated_at = VALUES(created_at)";
            $st = $this->db->prepare($sql);
            $t  = time();
            $rawJson = json_encode($raw, JSON_UNESCAPED_UNICODE);
            return $st->execute([
                ':ad'  => $adId,
                ':prov'=> $provider,
                ':ref' => $reference,
                ':amt' => $amount,
                ':cur' => $currency,
                ':st'  => $status,
                ':ev'  => $event,
                ':ptype' => $paymentType,
                ':oid'   => $objectId ?? $adId,
                ':raw' => $rawJson,
                ':t'   => $t,
            ]);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** Update payment by provider+reference. */
    public function RL_UpdateAdPaymentStatusByReference(string $provider, string $reference, string $status, string $event = '', array $raw = []): bool
    {
        $this->RL_EnsureAdPaymentsTable();
        try {
            $sql = "UPDATE i_ad_payments
                    SET status = :st, event = :ev, raw_payload = :raw, updated_at = :t
                    WHERE provider = :prov AND reference = :ref";
            $st = $this->db->prepare($sql);
            $t  = time();
            $rawJson = json_encode($raw, JSON_UNESCAPED_UNICODE);
            return $st->execute([
                ':st'  => $status,
                ':ev'  => $event,
                ':raw' => $rawJson,
                ':t'   => $t,
                ':prov'=> $provider,
                ':ref' => $reference,
            ]);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** Update payment financial breakdown by provider+reference. */
    public function RL_UpdateAdPaymentAmountsByReference(
        string $provider,
        string $reference,
        ?float $gross,
        ?string $currency,
        ?float $feeAmount,
        ?string $feeCurrency,
        ?float $taxAmount,
        ?float $netAmount
    ): bool {
        $this->RL_EnsureAdPaymentsTable();
        try {
            $sql = "UPDATE i_ad_payments
                    SET amount = COALESCE(:amt, amount),
                        currency = COALESCE(:cur, currency),
                        fee_amount = COALESCE(:fee, fee_amount),
                        fee_currency = COALESCE(:feecur, fee_currency),
                        tax_amount = COALESCE(:tax, tax_amount),
                        net_amount = COALESCE(:net, net_amount),
                        updated_at = :t
                    WHERE provider = :prov AND reference = :ref";
            $st = $this->db->prepare($sql);
            $t  = time();
            return $st->execute([
                ':amt' => $gross,
                ':cur' => $currency,
                ':fee' => $feeAmount,
                ':feecur' => $feeCurrency,
                ':tax' => $taxAmount,
                ':net' => $netAmount,
                ':t' => $t,
                ':prov' => $provider,
                ':ref' => $reference,
            ]);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** Fetch a payment row by provider+reference. */
    public function RL_GetAdPaymentByReference(string $provider, string $reference): ?array
    {
        try {
            $sql = "SELECT * FROM i_ad_payments WHERE provider = :prov AND reference = :ref LIMIT 1";
            $st = $this->db->prepare($sql);
            $st->execute([':prov' => $provider, ':ref' => $reference]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Debit user's wallet to pay for an advertisement, record payment, and activate the ad.
     * Performs an atomic transaction with row-level lock to avoid race conditions.
     *
     * @return array{ok:bool,reference?:string,balance?:float,error?:string}
     */
    public function RL_DebitWalletForAd(int $userId, int $adId, float $amount, string $currency = 'USD'): array
    {
        $amount = round(max(0.0, (float)$amount), 2);
        if ($amount <= 0) { return ['ok' => false, 'error' => 'Invalid amount']; }

        /** @var PDO $db */
        $db = $this->db;
        try {
            $begun = false;
            try {
                if (!$db->inTransaction()) {
                    $begun = $db->beginTransaction() ? true : false;
                } else {
                    $begun = true;
                }
            } catch (\Throwable $__) {
                $begun = false; // proceed without explicit transaction (autocommit)
            }

            // Lock user's row
            $st = $db->prepare("SELECT wallet FROM i_users WHERE user_id = :uid FOR UPDATE");
            $st->execute([':uid' => $userId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                if ($begun && $db->inTransaction()) { $db->rollBack(); }
                return ['ok' => false, 'error' => 'User not found'];
            }
            $balance = (float)($row['wallet'] ?? 0);
            if ($balance < $amount) {
                if ($begun && $db->inTransaction()) { $db->rollBack(); }
                return ['ok' => false, 'error' => 'Insufficient wallet balance', 'balance' => $balance];
            }

            // Deduct
            $newBalance = round($balance - $amount, 2);
            $formattedBalance = number_format($newBalance, 2, '.', '');
            $updateWallet = $db->prepare('UPDATE i_users SET wallet = :wallet WHERE user_id = :uid');
            $updateWallet->execute([':wallet' => $formattedBalance, ':uid' => $userId]);

            // Generate internal reference
            $reference = 'WALLET-' . $userId . '-' . $adId . '-' . time() . '-' . bin2hex(random_bytes(3));

            // Record payment as succeeded
            $this->RL_RecordAdPayment(
                $adId,
                'wallet',
                $reference,
                $amount,
                $currency,
                'succeeded',
                'wallet_debited',
                ['source' => 'wallet', 'user_id' => $userId, 'ad_id' => $adId],
                'advertisement',
                $adId
            );
            // Store fee/tax/net as 0 for wallet (net = amount)
            $this->RL_UpdateAdPaymentAmountsByReference('wallet', $reference, $amount, $currency, 0.0, $currency, 0.0, $amount);

            // Activate advertisement
            if (method_exists($this, 'RL_UpdateAdvertisementStatus')) {
                $this->RL_UpdateAdvertisementStatus($adId, 'active');
            }

            if ($begun && $db->inTransaction()) { $db->commit(); }

            return ['ok' => true, 'reference' => $reference, 'balance' => (float) $formattedBalance];
        } catch (\Throwable $e) {
            if ($begun && $db->inTransaction()) { $db->rollBack(); }
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    // ===== Wallet top-ups =====

    private function RL_EnsureWalletTopupTable(): void
    {
        $driver = 'mysql';
        try {
            $driver = (string) $this->db->getAttribute(\PDO::ATTR_DRIVER_NAME);
        } catch (\Throwable $__) {
            $driver = 'mysql';
        }

        if ($driver === 'sqlite') {
            try {
                $this->db->exec(
                    "CREATE TABLE IF NOT EXISTS i_wallet_topups (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        provider TEXT NOT NULL,
                        reference TEXT NOT NULL,
                        amount_minor INTEGER NOT NULL,
                        currency TEXT NOT NULL,
                        status TEXT NOT NULL,
                        event TEXT NULL,
                        fee_minor INTEGER NULL,
                        tax_minor INTEGER NULL,
                        net_minor INTEGER NULL,
                        raw_payload TEXT NULL,
                        credited_at INTEGER NULL,
                        created_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
                        updated_at INTEGER NULL
                    )"
                );
                $this->db->exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_wallet_topups_provider_reference ON i_wallet_topups(provider, reference)");
                $this->db->exec("CREATE INDEX IF NOT EXISTS idx_wallet_topups_user_status_created ON i_wallet_topups(user_id, status, created_at)");
            } catch (\Throwable $__) {
                // silent guard for SQLite creation
            }
            return;
        }

        try {
            $sql = "CREATE TABLE IF NOT EXISTS i_wallet_topups (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id INT UNSIGNED NOT NULL,
                provider VARCHAR(32) NOT NULL,
                reference VARCHAR(191) NOT NULL,
                amount_minor BIGINT NOT NULL,
                currency CHAR(3) NOT NULL,
                status VARCHAR(32) NOT NULL,
                event VARCHAR(64) NULL,
                fee_minor BIGINT NULL,
                tax_minor BIGINT NULL,
                net_minor BIGINT NULL,
                raw_payload JSON NULL,
                credited_at INT UNSIGNED NULL,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_provider_reference (provider, reference),
                KEY idx_user_status_created (user_id, status, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
            $this->db->exec($sql);
            try { $this->db->exec("ALTER TABLE i_wallet_topups ADD COLUMN fee_minor BIGINT NULL"); } catch (\Throwable $__) {}
            try { $this->db->exec("ALTER TABLE i_wallet_topups ADD COLUMN tax_minor BIGINT NULL"); } catch (\Throwable $__) {}
            try { $this->db->exec("ALTER TABLE i_wallet_topups ADD COLUMN net_minor BIGINT NULL"); } catch (\Throwable $__) {}
            try { $this->db->exec("ALTER TABLE i_wallet_topups ADD COLUMN raw_payload JSON NULL"); } catch (\Throwable $__) {}
            try { $this->db->exec("ALTER TABLE i_wallet_topups ADD COLUMN credited_at INT UNSIGNED NULL"); } catch (\Throwable $__) {}
            try { $this->db->exec("ALTER TABLE i_wallet_topups ADD COLUMN created_at INT UNSIGNED NOT NULL DEFAULT UNIX_TIMESTAMP()"); } catch (\Throwable $__) {}
            try { $this->db->exec("ALTER TABLE i_wallet_topups ADD COLUMN updated_at INT UNSIGNED NULL"); } catch (\Throwable $__) {}
            try { $this->db->exec("ALTER TABLE i_wallet_topups ADD UNIQUE KEY uniq_provider_reference (provider, reference)"); } catch (\Throwable $__) {}
            try { $this->db->exec("ALTER TABLE i_wallet_topups ADD KEY idx_user_status_created (user_id, status, created_at)"); } catch (\Throwable $__) {}
        } catch (\Throwable $e) {
            // silent guard
        }
    }

    private function RL_EnsureWalletLedgerTable(): void
    {
        $driver = 'mysql';
        try {
            $driver = (string) $this->db->getAttribute(\PDO::ATTR_DRIVER_NAME);
        } catch (\Throwable $__) {
            $driver = 'mysql';
        }

        if ($driver === 'sqlite') {
            try {
                $this->db->exec(
                    "CREATE TABLE IF NOT EXISTS i_wallet_ledger (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        type TEXT NOT NULL,
                        amount_minor INTEGER NOT NULL,
                        currency TEXT NOT NULL,
                        ref_provider TEXT NOT NULL,
                        ref_id TEXT NOT NULL,
                        meta TEXT NULL,
                        created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
                    )"
                );
                $this->db->exec("CREATE INDEX IF NOT EXISTS idx_wallet_ledger_user_created ON i_wallet_ledger(user_id, created_at)");
                $this->db->exec("CREATE INDEX IF NOT EXISTS idx_wallet_ledger_ref ON i_wallet_ledger(ref_provider, ref_id)");
            } catch (\Throwable $__) {
                // silent guard for SQLite creation
            }
            return;
        }

        try {
            $sql = "CREATE TABLE IF NOT EXISTS i_wallet_ledger (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id INT UNSIGNED NOT NULL,
                type ENUM('topup','spend','refund') NOT NULL,
                amount_minor BIGINT NOT NULL,
                currency CHAR(3) NOT NULL,
                ref_provider VARCHAR(32) NOT NULL,
                ref_id VARCHAR(191) NOT NULL,
                meta JSON NULL,
                created_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                KEY idx_user_created (user_id, created_at),
                KEY idx_ref (ref_provider, ref_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
            $this->db->exec($sql);
            try { $this->db->exec("ALTER TABLE i_wallet_ledger ADD COLUMN meta JSON NULL"); } catch (\Throwable $__) {}
            try { $this->db->exec("ALTER TABLE i_wallet_ledger ADD KEY idx_user_created (user_id, created_at)"); } catch (\Throwable $__) {}
            try { $this->db->exec("ALTER TABLE i_wallet_ledger ADD KEY idx_ref (ref_provider, ref_id)"); } catch (\Throwable $__) {}
        } catch (\Throwable $e) {
            // silent guard
        }
    }

    public function RL_RecordWalletTopup(
        int $userId,
        string $provider,
        string $reference,
        int $amountMinor,
        string $currency,
        string $status = 'pending',
        string $event = '',
        array $raw = [],
        ?int $feeMinor = null,
        ?int $taxMinor = null,
        ?int $netMinor = null
    ): bool {
        $this->RL_EnsureWalletTopupTable();
        $driver = 'mysql';
        try {
            $driver = (string) $this->db->getAttribute(\PDO::ATTR_DRIVER_NAME);
        } catch (\Throwable $__) {
            $driver = 'mysql';
        }

        try {
            $sql = "INSERT INTO i_wallet_topups
                    (user_id, provider, reference, amount_minor, currency, status, event, fee_minor, tax_minor, net_minor, raw_payload, credited_at, created_at, updated_at)
                    VALUES (:user, :prov, :ref, :amt, :cur, :st, :ev, :fee, :tax, :net, :raw, :cred, :t, NULL)";
            if ($driver === 'sqlite') {
                $sql .= "
                    ON CONFLICT(provider, reference) DO UPDATE SET
                        amount_minor = excluded.amount_minor,
                        currency = excluded.currency,
                        status = CASE
                            WHEN i_wallet_topups.status = 'succeeded' THEN i_wallet_topups.status
                            ELSE excluded.status
                        END,
                        event = excluded.event,
                        fee_minor = excluded.fee_minor,
                        tax_minor = excluded.tax_minor,
                        net_minor = excluded.net_minor,
                        raw_payload = excluded.raw_payload,
                        updated_at = excluded.created_at,
                        credited_at = COALESCE(i_wallet_topups.credited_at, excluded.credited_at)";
            } else {
                $sql .= "
                    ON DUPLICATE KEY UPDATE
                        amount_minor = VALUES(amount_minor),
                        currency = VALUES(currency),
                        status = IF(status = 'succeeded', status, VALUES(status)),
                        event = VALUES(event),
                        fee_minor = VALUES(fee_minor),
                        tax_minor = VALUES(tax_minor),
                        net_minor = VALUES(net_minor),
                        raw_payload = VALUES(raw_payload),
                        updated_at = VALUES(created_at),
                        credited_at = COALESCE(credited_at, VALUES(credited_at))";
            }

            $st = $this->db->prepare($sql);
            $t = time();
            $rawJson = $this->RL_EncodeJsonPayload($raw);
            return $st->execute([
                ':user' => $userId,
                ':prov' => $provider,
                ':ref' => $reference,
                ':amt' => $amountMinor,
                ':cur' => $currency,
                ':st' => $status,
                ':ev' => $event,
                ':fee' => $feeMinor,
                ':tax' => $taxMinor,
                ':net' => $netMinor,
                ':raw' => $rawJson,
                ':cred' => null,
                ':t' => $t,
            ]);
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function RL_UpdateWalletTopupStatusByReference(string $provider, string $reference, string $status, string $event = '', array $raw = []): bool
    {
        $this->RL_EnsureWalletTopupTable();
        try {
            $sql = "UPDATE i_wallet_topups
                    SET status = :st,
                        event = :ev,
                        raw_payload = :raw,
                        updated_at = :t
                    WHERE provider = :prov AND reference = :ref";
            $st = $this->db->prepare($sql);
            $t = time();
            $rawJson = $this->RL_EncodeJsonPayload($raw);
            return $st->execute([
                ':st' => $status,
                ':ev' => $event,
                ':raw' => $rawJson,
                ':t' => $t,
                ':prov' => $provider,
                ':ref' => $reference,
            ]);
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function RL_UpdateWalletTopupAmountsByReference(
        string $provider,
        string $reference,
        ?int $amountMinor,
        ?int $feeMinor,
        ?int $taxMinor,
        ?int $netMinor,
        ?string $currency = null
    ): bool {
        $this->RL_EnsureWalletTopupTable();
        try {
            $driver = 'mysql';
            try {
                $driver = (string) $this->db->getAttribute(\PDO::ATTR_DRIVER_NAME);
            } catch (\Throwable $__) {
                $driver = 'mysql';
            }

            if ($driver === 'sqlite') {
                $sql = "UPDATE i_wallet_topups
                        SET amount_minor = COALESCE(:amt, amount_minor),
                            fee_minor = COALESCE(:fee, fee_minor),
                            tax_minor = COALESCE(:tax, tax_minor),
                            net_minor = COALESCE(:net, net_minor),
                            currency = CASE WHEN :cur_a IS NULL OR :cur_a = '' THEN currency ELSE :cur_b END,
                            updated_at = :t
                        WHERE provider = :prov AND reference = :ref";
            } else {
                $sql = "UPDATE i_wallet_topups
                        SET amount_minor = COALESCE(:amt, amount_minor),
                            fee_minor = COALESCE(:fee, fee_minor),
                            tax_minor = COALESCE(:tax, tax_minor),
                            net_minor = COALESCE(:net, net_minor),
                            currency = IF(:cur_a IS NULL OR :cur_a = '', currency, :cur_b),
                            updated_at = :t
                        WHERE provider = :prov AND reference = :ref";
            }
            $st = $this->db->prepare($sql);
            $t = time();
            $ok = $st->execute([
                ':amt' => $amountMinor,
                ':fee' => $feeMinor,
                ':tax' => $taxMinor,
                ':net' => $netMinor,
                ':cur_a' => $currency,
                ':cur_b' => $currency,
                ':t' => $t,
                ':prov' => $provider,
                ':ref' => $reference,
            ]);
            if (!$ok) {
                $errInfo = $st->errorInfo();
                $errMsg = is_array($errInfo) ? implode(' | ', array_filter(array_map('strval', $errInfo))) : 'unknown';
                if (method_exists($this, 'logError')) {
                    $this->logError('wallet_topup_amount_update_sql_error provider=' . $provider . ' ref=' . $reference . ' err=' . $errMsg);
                } else {
                    @file_put_contents(dirname(__DIR__) . '/functions_error.txt', date('c') . ' wallet_topup_amount_update_sql_error provider=' . $provider . ' ref=' . $reference . ' err=' . $errMsg . "\n", FILE_APPEND);
                }
            }
            return $ok;
        } catch (\Throwable $e) {
            $message = $e->getMessage();
            if (method_exists($this, 'logError')) {
                $this->logError('wallet_topup_amount_update_exception provider=' . $provider . ' ref=' . $reference . ' error=' . $message);
            } else {
                @file_put_contents(dirname(__DIR__) . '/functions_error.txt', date('c') . ' wallet_topup_amount_update_exception provider=' . $provider . ' ref=' . $reference . ' error=' . $message . "\n", FILE_APPEND);
            }
            return false;
        }
    }

    public function RL_GetWalletTopupByReference(string $provider, string $reference): ?array
    {
        $this->RL_EnsureWalletTopupTable();
        try {
            $sql = "SELECT * FROM i_wallet_topups WHERE provider = :prov AND reference = :ref LIMIT 1";
            $st = $this->db->prepare($sql);
            $st->execute([':prov' => $provider, ':ref' => $reference]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    public function RL_GetWalletTopupLimits(): array
    {
        try {
            $sql = 'SELECT wallet_topup_status, wallet_topup_minimum, wallet_topup_maximum FROM i_site_configurations ORDER BY id ASC LIMIT 1';
            $st = $this->db->query($sql);
            $row = $st ? $st->fetch(\PDO::FETCH_ASSOC) : false;
            $enabled = isset($row['wallet_topup_status']) && $row['wallet_topup_status'] === 'open';
            $min = isset($row['wallet_topup_minimum']) ? (float) $row['wallet_topup_minimum'] : 0.0;
            $max = isset($row['wallet_topup_maximum']) ? (float) $row['wallet_topup_maximum'] : 0.0;
            return ['enabled' => $enabled, 'min' => $min, 'max' => $max];
        } catch (\Throwable $e) {
            return ['enabled' => false, 'min' => 0.0, 'max' => 0.0];
        }
    }

    public function RL_CreditWalletTopupByReference(string $provider, string $reference): bool
    {
        $this->RL_EnsureWalletTopupTable();
        $this->RL_EnsureWalletLedgerTable();

        /** @var \PDO $db */
        $db = $this->db;
        $driver = 'mysql';
        try {
            $driver = (string) $db->getAttribute(\PDO::ATTR_DRIVER_NAME);
        } catch (\Throwable $__) {
            $driver = 'mysql';
        }

        $begun = false;
        try {
            if (!$db->inTransaction()) {
                $begun = $db->beginTransaction();
            }
        } catch (\Throwable $__) {
            $begun = false;
        }

        $rollbackAndLog = function (string $reason) use (&$begun, $db, $provider, $reference): bool {
            try {
                if ($begun && $db->inTransaction()) {
                    $db->rollBack();
                }
            } catch (\Throwable $__) {
                // ignore rollback failures
            }
            $debugLine = date('c') . ' wallet_topup_credit_skip provider=' . $provider . ' ref=' . $reference . ' reason=' . $reason . "\n";
            @file_put_contents(dirname(__DIR__) . '/wallet_credit_debug.log', $debugLine, FILE_APPEND);
            if (method_exists($this, 'logError')) {
                $this->logError('wallet_topup_credit_skip provider=' . $provider . ' ref=' . $reference . ' reason=' . $reason);
            }
            return false;
        };

        try {
            $selectSql = ($driver === 'sqlite')
                ? "SELECT * FROM i_wallet_topups WHERE provider = :prov AND reference = :ref"
                : "SELECT * FROM i_wallet_topups WHERE provider = :prov AND reference = :ref FOR UPDATE";
            $st = $db->prepare($selectSql);
            $st->execute([':prov' => $provider, ':ref' => $reference]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                return $rollbackAndLog('row_missing');
            }

            $existingCredit = (int) ($row['credited_at'] ?? 0);
            if ($existingCredit > 0) {
                if ($begun && $db->inTransaction()) { $db->commit(); }
                return true;
            }

            $status = (string) ($row['status'] ?? '');
            if (!in_array($status, ['succeeded', 'completed', 'approved'], true)) {
                return $rollbackAndLog('invalid_status_' . $status);
            }

            $creditMinor = (int) ($row['net_minor'] ?? 0);
            if ($creditMinor <= 0) {
                $creditMinor = (int) ($row['amount_minor'] ?? 0);
            }
            if ($creditMinor <= 0) {
                return $rollbackAndLog('credit_minor_zero');
            }

            $userId = (int) ($row['user_id'] ?? 0);
            if ($userId <= 0) {
                return $rollbackAndLog('invalid_user');
            }

            $currency = (string) ($row['currency'] ?? 'USD');
            $precision = $this->resolveCurrencyPrecision($currency);
            $scale = pow(10, $precision);
            if ($scale <= 0) { $scale = 100; }
            $creditDecimal = round($creditMinor / $scale, $precision);

            $lockSql = ($driver === 'sqlite')
                ? 'SELECT wallet FROM i_users WHERE user_id = :uid'
                : 'SELECT wallet FROM i_users WHERE user_id = :uid FOR UPDATE';
            $lockStmt = $db->prepare($lockSql);
            $lockStmt->execute([':uid' => $userId]);
            $walletValue = $lockStmt->fetchColumn();
            $currentWallet = is_numeric($walletValue)
                ? (float) $walletValue
                : (float) preg_replace('/[^0-9.\-]/', '', (string) $walletValue);
            $displayPrecision = max(2, $precision);
            $newWallet = round($currentWallet + $creditDecimal, $displayPrecision);
            $formattedWallet = number_format($newWallet, $displayPrecision, '.', '');

            $updWallet = $db->prepare('UPDATE i_users SET wallet = :wallet WHERE user_id = :uid');
            $updWallet->execute([':wallet' => $formattedWallet, ':uid' => $userId]);
            $walletRows = (int) $updWallet->rowCount();

            if (defined('APP_DEBUG') && APP_DEBUG === true) {
                @file_put_contents(
                    dirname(__DIR__) . '/payments_debug.log',
                    date('c') . ' WALLET_TOPUP_CREDIT provider=' . $provider . ' ref=' . $reference . ' user=' . $userId . ' old_wallet=' . $currentWallet . ' new_wallet=' . $formattedWallet . ' credit_minor=' . $creditMinor . ' updated_rows=' . $walletRows . "\n",
                    FILE_APPEND
                );
            }

            @file_put_contents(
                dirname(__DIR__) . '/wallet_credit_debug.log',
                date('c') . ' wallet_topup_credit provider=' . $provider . ' ref=' . $reference . ' user=' . $userId . ' old_wallet=' . $currentWallet . ' new_wallet=' . $formattedWallet . ' credit_minor=' . $creditMinor . ' updated_rows=' . $walletRows . "\n",
                FILE_APPEND
            );

            if ($walletRows === 0) {
                return $rollbackAndLog('wallet_update_no_rows');
            }

            $timestamp = time();
            $eventLabel = 'wallet_credited';
            $updateSql = ($driver === 'sqlite')
                ? "UPDATE i_wallet_topups
                   SET credited_at = COALESCE(credited_at, :cred_t),
                       updated_at = :upd_t,
                       event = CASE WHEN event IS NULL OR event = '' THEN :ev ELSE event END
                   WHERE provider = :prov AND reference = :ref"
                : "UPDATE i_wallet_topups
                   SET credited_at = COALESCE(credited_at, :cred_t),
                       updated_at = :upd_t,
                       event = IF(event IS NULL OR event = '', :ev, event)
                   WHERE provider = :prov AND reference = :ref";
            $updTopup = $db->prepare($updateSql);
            $updTopup->execute([
                ':cred_t' => $timestamp,
                ':upd_t' => $timestamp,
                ':ev' => $eventLabel,
                ':prov' => $provider,
                ':ref' => $reference,
            ]);

            $meta = [
                'topup_id' => (int) $row['id'],
                'provider' => $provider,
                'reference' => $reference,
            ];
            $metaJson = json_encode($meta, JSON_UNESCAPED_UNICODE);
            if ($metaJson === false) {
                $metaJson = json_encode(['topup_id' => (int) $row['id']], JSON_UNESCAPED_UNICODE);
            }

            $insLedger = $db->prepare(
                "INSERT INTO i_wallet_ledger (user_id, type, amount_minor, currency, ref_provider, ref_id, meta, created_at)
                 VALUES (:uid, 'topup', :amt, :cur, :prov, :ref, :meta, :t)"
            );
            $insLedger->execute([
                ':uid' => $userId,
                ':amt' => $creditMinor,
                ':cur' => $currency,
                ':prov' => $provider,
                ':ref' => $reference,
                ':meta' => $metaJson,
                ':t' => $timestamp,
            ]);

            if ($begun && $db->inTransaction()) {
                $db->commit();
            }

            return true;
        } catch (\Throwable $e) {
            try {
                if ($begun && $db->inTransaction()) {
                    $db->rollBack();
                }
            } catch (\Throwable $__) {
                // ignore rollback errors
            }
            if (method_exists($this, 'logError')) {
                $this->logError('wallet_topup_credit_exception provider=' . $provider . ' ref=' . $reference . ' error=' . $e->getMessage());
            }
            return false;
        }
    }

    // ===== Tips payments =====
    private function RL_EnsureTipPaymentsTable(): void
    {
        try {
            $sql = "CREATE TABLE IF NOT EXISTS i_tip_payments (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                buyer_id INT UNSIGNED NOT NULL,
                recipient_id INT UNSIGNED NOT NULL,
                post_id INT UNSIGNED NOT NULL,
                provider VARCHAR(32) NOT NULL,
                reference VARCHAR(191) NOT NULL,
                amount DECIMAL(10,2) NULL,
                currency VARCHAR(10) NULL,
                status VARCHAR(32) NOT NULL,
                event VARCHAR(64) NULL,
                fee_amount DECIMAL(10,2) NULL,
                fee_currency VARCHAR(10) NULL,
                tax_amount DECIMAL(10,2) NULL,
                net_amount DECIMAL(10,2) NULL,
                raw_payload MEDIUMTEXT NULL,
                credited_at INT UNSIGNED NULL,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_provider_ref (provider, reference),
                KEY idx_post (post_id),
                KEY idx_recipient (recipient_id),
                KEY idx_buyer (buyer_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
            $this->db->exec($sql);
            // add columns if missing (best-effort)
            try { $this->db->exec("ALTER TABLE i_tip_payments ADD COLUMN fee_amount DECIMAL(10,2) NULL"); } catch (\Throwable $e) {}
            try { $this->db->exec("ALTER TABLE i_tip_payments ADD COLUMN fee_currency VARCHAR(10) NULL"); } catch (\Throwable $e) {}
            try { $this->db->exec("ALTER TABLE i_tip_payments ADD COLUMN tax_amount DECIMAL(10,2) NULL"); } catch (\Throwable $e) {}
            try { $this->db->exec("ALTER TABLE i_tip_payments ADD COLUMN net_amount DECIMAL(10,2) NULL"); } catch (\Throwable $e) {}
            try { $this->db->exec("ALTER TABLE i_tip_payments ADD COLUMN credited_at INT UNSIGNED NULL"); } catch (\Throwable $e) {}
        } catch (\Throwable $e) {
            // silent
        }
    }

    /**
     * Count successful tip payments for a given post.
     * Returns integer count; safe default 0 on error.
     */
    public function RL_CountPostTips(int $postId): int
    {
        if ($postId <= 0) { return 0; }
        $this->RL_EnsureTipPaymentsTable();
        try {
            $st = $this->db->prepare("SELECT COUNT(*) FROM i_tip_payments WHERE post_id = :pid AND status = 'succeeded'");
            $st->execute([':pid' => $postId]);
            return (int) $st->fetchColumn();
        } catch (\Throwable $e) {
            return 0;
        }
    }

    public function RL_RecordTipPayment(
        int $buyerId,
        int $recipientId,
        int $postId,
        string $provider,
        string $reference,
        float $amount,
        string $currency,
        string $status = 'pending',
        string $event = '',
        array $raw = []
    ): bool {
        $this->RL_EnsureTipPaymentsTable();
        try {
            $sql = "INSERT INTO i_tip_payments
                    (buyer_id, recipient_id, post_id, provider, reference, amount, currency, status, event, raw_payload, created_at, updated_at)
                    VALUES (:buyer, :rec, :post, :prov, :ref, :amt, :cur, :st, :ev, :raw, :t, NULL)
                    ON DUPLICATE KEY UPDATE
                        amount = VALUES(amount),
                        currency = VALUES(currency),
                        status = VALUES(status),
                        event = VALUES(event),
                        raw_payload = VALUES(raw_payload),
                        updated_at = VALUES(created_at)";
            $st = $this->db->prepare($sql);
            $t = time();
            $rawJson = json_encode($raw, JSON_UNESCAPED_UNICODE);
            return $st->execute([
                ':buyer' => $buyerId,
                ':rec'   => $recipientId,
                ':post'  => $postId,
                ':prov'  => $provider,
                ':ref'   => $reference,
                ':amt'   => $amount,
                ':cur'   => $currency,
                ':st'    => $status,
                ':ev'    => $event,
                ':raw'   => $rawJson,
                ':t'     => $t,
            ]);
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function RL_UpdateTipPaymentStatusByReference(string $provider, string $reference, string $status, string $event = '', array $raw = []): bool
    {
        $this->RL_EnsureTipPaymentsTable();
        try {
            $sql = "UPDATE i_tip_payments
                    SET status = :st, event = :ev, raw_payload = :raw, updated_at = :t
                    WHERE provider = :prov AND reference = :ref";
            $st = $this->db->prepare($sql);
            $t = time();
            $rawJson = json_encode($raw, JSON_UNESCAPED_UNICODE);
            return $st->execute([
                ':st' => $status,
                ':ev' => $event,
                ':raw'=> $rawJson,
                ':t'  => $t,
                ':prov'=> $provider,
                ':ref' => $reference,
            ]);
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function RL_UpdateTipPaymentAmountsByReference(
        string $provider,
        string $reference,
        ?float $gross,
        ?string $currency,
        ?float $feeAmount,
        ?string $feeCurrency,
        ?float $taxAmount,
        ?float $netAmount
    ): bool {
        $this->RL_EnsureTipPaymentsTable();
        try {
            $sql = "UPDATE i_tip_payments
                    SET amount = COALESCE(:amt, amount),
                        currency = COALESCE(:cur, currency),
                        fee_amount = COALESCE(:fee, fee_amount),
                        fee_currency = COALESCE(:feecur, fee_currency),
                        tax_amount = COALESCE(:tax, tax_amount),
                        net_amount = COALESCE(:net, net_amount),
                        updated_at = :t
                    WHERE provider = :prov AND reference = :ref";
            $st = $this->db->prepare($sql);
            $t = time();
            return $st->execute([
                ':amt' => $gross,
                ':cur' => $currency,
                ':fee' => $feeAmount,
                ':feecur' => $feeCurrency,
                ':tax' => $taxAmount,
                ':net' => $netAmount,
                ':t' => $t,
                ':prov' => $provider,
                ':ref' => $reference,
            ]);
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function RL_GetTipPaymentByReference(string $provider, string $reference): ?array
    {
        try {
            $sql = "SELECT * FROM i_tip_payments WHERE provider = :prov AND reference = :ref LIMIT 1";
            $st = $this->db->prepare($sql);
            $st->execute([':prov' => $provider, ':ref' => $reference]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** Increment recipient earned for succeeded tip (idempotent). */
    public function RL_CreditRecipientForTipByReference(string $provider, string $reference): bool
    {
        $this->RL_EnsureTipPaymentsTable();
        try {
            $db = $this->db;
            $db->beginTransaction();
            $st = $db->prepare("SELECT * FROM i_tip_payments WHERE provider = :prov AND reference = :ref FOR UPDATE");
            $st->execute([':prov'=>$provider, ':ref'=>$reference]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) { $db->rollBack(); return false; }
            if ((int)($row['credited_at'] ?? 0) > 0) { $db->commit(); return true; }
            if (($row['status'] ?? '') !== 'succeeded') { $db->rollBack(); return false; }
            $amount = (float)($row['net_amount'] ?? 0);
            if ($amount <= 0) { $amount = (float)($row['amount'] ?? 0); }
            $recipientId = (int)$row['recipient_id'];
            if ($recipientId <= 0 || $amount <= 0) { $db->rollBack(); return false; }
            $upd = $db->prepare("UPDATE i_users SET earned = COALESCE(earned,0) + :amt WHERE user_id = :uid");
            $upd->execute([':amt'=>$amount, ':uid'=>$recipientId]);
            $mark= $db->prepare("UPDATE i_tip_payments SET credited_at = :t, updated_at = :t WHERE provider = :prov AND reference = :ref");
            $t = time();
            $mark->execute([':t'=>$t, ':prov'=>$provider, ':ref'=>$reference]);
            $db->commit();
            return true;
        } catch (\Throwable $e) {
            try { if ($this->db->inTransaction()) { $this->db->rollBack(); } } catch (\Throwable $__) {}
            return false;
        }
    }

    /** Wallet transfer for tips (buyer -> recipient earned)
     *  Deducts total = amount + fee + tax from buyer, credits recipient with base amount only.
     */
    public function RL_TransferWalletForTip(
        int $buyerId,
        int $recipientId,
        int $postId,
        float $amount,
        string $currency = 'USD',
        ?float $feePercent = null,
        ?float $feeFixed = null,
        ?float $taxPercent = null
    ): array
    {
        $amount = round(max(0.0, (float)$amount), 2);
        if ($amount <= 0) { return ['ok'=>false, 'error'=>'Invalid amount']; }
        $db = $this->db;
        try {
            $begun = false;
            try {
                if (!$db->inTransaction()) {
                    $begun = $db->beginTransaction() ? true : false;
                } else {
                    $begun = true;
                }
            } catch (\Throwable $__) {
                $begun = false; // proceed without explicit transaction
            }

            // Lock buyer row if transaction possible
            $st = $db->prepare("SELECT wallet FROM i_users WHERE user_id = :uid" . ($begun ? " FOR UPDATE" : ""));
            $st->execute([':uid'=>$buyerId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                if ($begun && $db->inTransaction()) { $db->rollBack(); }
                return ['ok'=>false,'error'=>'Buyer not found'];
            }
            // Resolve fee/tax with fallbacks to globals
            if ($feePercent === null || $feeFixed === null || $taxPercent === null) {
                $fp = isset($GLOBALS['paymentFeePercent']) ? (float)$GLOBALS['paymentFeePercent'] : 0.0;
                $ff = isset($GLOBALS['paymentFeeFixed'])   ? (float)$GLOBALS['paymentFeeFixed']   : 0.0;
                $tp = isset($GLOBALS['paymentTaxPercent']) ? (float)$GLOBALS['paymentTaxPercent'] : 0.0;
            } else {
                $fp = (float)$feePercent;
                $ff = (float)$feeFixed;
                $tp = (float)$taxPercent;
            }

            $fee = round(($amount * ($fp/100.0)) + $ff, 2);
            $tax = round(($amount * ($tp/100.0)), 2);
            $totalCharge = round($amount + $fee + $tax, 2);

            $balance = (float)($row['wallet'] ?? 0);
            if ($balance < $totalCharge) {
                if ($begun && $db->inTransaction()) { $db->rollBack(); }
                return ['ok'=>false,'error'=>'Insufficient wallet balance','balance'=>$balance, 'required'=>$totalCharge];
            }
            // Deduct buyer (total including fees + taxes)
            $newBuyerBalance = round($balance - $totalCharge, 2);
            $formattedBuyerBalance = number_format($newBuyerBalance, 2, '.', '');
            $buyerWalletUpdate = $db->prepare('UPDATE i_users SET wallet = :wallet WHERE user_id = :uid');
            $buyerWalletUpdate->execute([':wallet' => $formattedBuyerBalance, ':uid' => $buyerId]);
            // Credit recipient earned (base amount only)
            $db->prepare("UPDATE i_users SET earned = COALESCE(earned,0) + :amt WHERE user_id = :uid")->execute([':amt'=>$amount, ':uid'=>$recipientId]);
            $reference = 'TIPWALLET-' . $buyerId . '-' . $recipientId . '-' . $postId . '-' . time() . '-' . bin2hex(random_bytes(3));
            $this->RL_RecordTipPayment($buyerId, $recipientId, $postId, 'wallet', $reference, $totalCharge, $currency, 'succeeded', 'wallet_debited', ['source'=>'wallet']);
            $this->RL_UpdateTipPaymentAmountsByReference('wallet', $reference, $totalCharge, $currency, $fee, $currency, $tax, $amount);

            if ($begun && $db->inTransaction()) {
                $db->commit();
            }

            // New balance
            $nb = (float) $formattedBuyerBalance;
            // Notify recipient (tip payment)
            if (method_exists($this, 'RL_CreateTipPaymentNotification')) {
                $this->RL_CreateTipPaymentNotification($buyerId, $recipientId, $postId, (float)$amount, (string)$currency, $reference);
            }
            if (method_exists($this, 'RL_CreateTipReceiptNotification')) {
                $this->RL_CreateTipReceiptNotification($buyerId, $recipientId, $postId, (float)$amount, (string)$currency, $reference);
            }
            return ['ok'=>true,'reference'=>$reference,'new_balance'=>(float)$nb];
        } catch (\Throwable $e) {
            try { if ($db->inTransaction()) { $db->rollBack(); } } catch (\Throwable $__) {}
            return ['ok'=>false,'error'=>$e->getMessage()];
        }
    }

    /** Persist non-empty billing fields when they are newly provided or changed. */
    public function RL_UpdateUserBillingIfEmpty(int $userId, array $data): bool
    {
        try {
            $this->RL_EnsureUserBillingColumns();
            $q = $this->db->prepare("SELECT for_billing_first_name, for_billing_last_name, for_billing_country, for_billing_city, for_billing_state, for_billing_postcode, for_billing_address FROM i_users WHERE user_id = :uid LIMIT 1");
            $q->execute([':uid'=>$userId]);
            $cur = $q->fetch(\PDO::FETCH_ASSOC) ?: [];
            $fields = [
                'for_billing_first_name' => trim((string)($data['first_name'] ?? '')),
                'for_billing_last_name'  => trim((string)($data['last_name'] ?? '')),
                'for_billing_country'    => trim((string)($data['country'] ?? '')),
                'for_billing_city'       => trim((string)($data['city'] ?? '')),
                'for_billing_state'      => trim((string)($data['state'] ?? '')),
                'for_billing_postcode'   => trim((string)($data['postcode'] ?? '')),
                'for_billing_address'    => trim((string)($data['address'] ?? '')),
            ];
            $updates = [];
            $params  = [':uid' => $userId];
            foreach ($fields as $col => $val) {
                $val = trim($val);
                if ($val === '') {
                    continue;
                }
                $existing = trim((string)($cur[$col] ?? ''));
                if ($existing === $val) {
                    continue;
                }
                $updates[] = "$col = :$col";
                $params[":$col"] = $val;
            }
            if (!$updates) { return true; }
            $sql = "UPDATE i_users SET ".implode(', ', $updates)." WHERE user_id = :uid";
            $st = $this->db->prepare($sql);
            $updated = $st->execute($params);
            if ($updated) {
                $fieldMap = [
                    'for_billing_first_name' => 'billignDataFirstName',
                    'for_billing_last_name'  => 'billignDataLastName',
                    'for_billing_country'    => 'billignDataCountry',
                    'for_billing_city'       => 'billignDataCity',
                    'for_billing_state'      => 'billignDataState',
                    'for_billing_postcode'   => 'billignDataPostCode',
                    'for_billing_address'    => 'billignDataAddress',
                ];
                if (isset($GLOBALS['userData']) && is_array($GLOBALS['userData']) && (int)($GLOBALS['userData']['user_id'] ?? 0) === $userId) {
                    foreach ($fields as $col => $val) {
                        if ($val === '') { continue; }
                        $GLOBALS['userData'][$col] = $val;
                        if (isset($fieldMap[$col])) {
                            $GLOBALS[$fieldMap[$col]] = $val;
                        }
                    }
                } else {
                    foreach ($fields as $col => $val) {
                        if ($val === '' || !isset($fieldMap[$col])) { continue; }
                        $GLOBALS[$fieldMap[$col]] = $val;
                    }
                }
            }
            return $updated;
        } catch (\Throwable $e) {
            return false;
        }
    }

    private function RL_EnsureUserBillingColumns(): void
    {
        static $ensured = false;
        if ($ensured) { return; }
        $ensured = true;
        $columns = [
            'for_billing_first_name' => "VARCHAR(255) DEFAULT NULL",
            'for_billing_last_name'  => "VARCHAR(255) DEFAULT NULL",
            'for_billing_country'    => "TEXT DEFAULT NULL",
            'for_billing_city'       => "TEXT DEFAULT NULL",
            'for_billing_state'      => "TEXT DEFAULT NULL",
            'for_billing_postcode'   => "TEXT DEFAULT NULL",
            'for_billing_address'    => "LONGTEXT DEFAULT NULL",
        ];
        foreach ($columns as $col => $definition) {
            try {
                $this->db->exec("ALTER TABLE i_users ADD COLUMN $col $definition");
            } catch (\Throwable $__) {
                // Column already exists or cannot be added; keep going.
            }
        }
    }

    private function resolveCurrencyPrecision(string $currency): int
    {
        $currency = strtoupper($currency);
        $cryptoCurrencies = [
            'BTC', 'ETH', 'BCH', 'LTC', 'DOGE', 'XMR', 'SOL', 'ADA', 'MATIC', 'XRP',
            'USDT', 'USDC', 'DAI', 'BNB', 'TRX'
        ];
        if (in_array($currency, $cryptoCurrencies, true)) {
            return 8;
        }
        return 2;
    }
}
