<?php
declare(strict_types=1);
trait CommentFunctions {
    /** Ensure i_comments has modern columns and keys. */
    private function RL_EnsureCommentsSchema(): void
    {
        static $ensured = false;
        if ($ensured) { return; }
        $ensured = true;

        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_comments (
                c_id INT NOT NULL AUTO_INCREMENT,
                item_id INT DEFAULT NULL,
                uid_fk INT DEFAULT NULL,
                comment LONGTEXT,
                created_time INT DEFAULT NULL,
                updated_time INT UNSIGNED NULL DEFAULT NULL,
                PRIMARY KEY (c_id),
                KEY idx_item (item_id),
                KEY idx_user (uid_fk)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
        } catch (\Throwable $__) {
            // table may already exist or creation failed; proceed best-effort
        }

        try {
            $columns = [];
            $stmt = $this->db->query('SHOW COLUMNS FROM i_comments');
            if ($stmt) {
                while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                    if (!is_array($row) || !isset($row['Field'])) { continue; }
                    $columns[$row['Field']] = $row;
                }
            }

            $execSafe = function(string $sql): void {
                try { $this->db->exec($sql); } catch (\Throwable $__) {}
            };

            if (!isset($columns['c_id'])) {
                $execSafe('ALTER TABLE i_comments ADD COLUMN c_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST');
            } else {
                $extra = strtolower((string)($columns['c_id']['Extra'] ?? ''));
                if (strpos($extra, 'auto_increment') === false) {
                    $execSafe('ALTER TABLE i_comments MODIFY c_id INT NOT NULL AUTO_INCREMENT');
                }
            }

            try {
                $idxStmt = $this->db->query("SHOW INDEX FROM i_comments WHERE Key_name = 'PRIMARY'");
                $hasPrimary = $idxStmt && $idxStmt->fetch();
                if (!$hasPrimary) {
                    $execSafe('ALTER TABLE i_comments ADD PRIMARY KEY (c_id)');
                }
            } catch (\Throwable $__) {}

            if (!isset($columns['updated_time'])) {
                $execSafe('ALTER TABLE i_comments ADD COLUMN updated_time INT UNSIGNED NULL DEFAULT NULL AFTER created_time');
            }

            try { $execSafe('ALTER TABLE i_comments ADD KEY idx_item (item_id)'); } catch (\Throwable $__) {}
            try { $execSafe('ALTER TABLE i_comments ADD KEY idx_user (uid_fk)'); } catch (\Throwable $__) {}
        } catch (\Throwable $__) {
            // ignore schema inspection issues
        }
    }

    private function RL_EnsureCommentUpdatedTimeColumn(): void
    {
        $this->RL_EnsureCommentsSchema();
        try {
            $stmt = $this->db->query("SHOW COLUMNS FROM i_comments LIKE 'updated_time'");
            $col  = $stmt ? $stmt->fetch(\PDO::FETCH_ASSOC) : null;
            if (!$col) {
                $this->db->exec("ALTER TABLE i_comments ADD COLUMN updated_time INT UNSIGNED NULL DEFAULT NULL AFTER created_time");
            }
        } catch (\Throwable $__) {
            // Ignore; some hosts disallow SHOW or ALTER without rights.
        }
    }

    private function RL_EnsureCommentReportsTable(): void
    {
        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_comment_reports (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                comment_id INT UNSIGNED NOT NULL,
                reporter_id INT UNSIGNED NOT NULL,
                reason VARCHAR(255) NULL,
                created_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_comment_reporter (comment_id, reporter_id),
                KEY idx_comment (comment_id),
                KEY idx_reporter (reporter_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;");
        } catch (\Throwable $__) {
            // ignore
        }
    }

    /**
     * Insert a new comment for a post.
     *
     * @param int    $userID   Authenticated user id
     * @param int    $postID   Target post id (i_comments.item_id)
     * @param string $comment  Raw comment text (UTF-8)
     * @param int    $time     Unix timestamp
     * @return bool            True on success, false on failure
     */
    public function RL_AddComment(int $userID, int $postID, string $comment, int $time): bool
    {
        $this->RL_EnsureCommentsSchema();
        try {
            // Normalize whitespace; keep full Unicode
            $clean = preg_replace('/\s+/u', ' ', trim($comment));
            if ($clean === '') {
                return false;
            }

            // Soft cap to mitigate abuse; DB column is LONGTEXT but UX-wise we limit
            $maxLen = 5000;
            if (mb_strlen($clean, 'UTF-8') > $maxLen) {
                $clean = mb_substr($clean, 0, $maxLen, 'UTF-8');
            }

            $sql = "INSERT INTO i_comments (item_id, uid_fk, comment, created_time)
                    VALUES (:pid, :uid, :comment, :ctime)";
            $st = $this->db->prepare($sql);
            $st->bindValue(':pid',     $postID,  \PDO::PARAM_INT);
            $st->bindValue(':uid',     $userID,  \PDO::PARAM_INT);
            $st->bindValue(':comment', $clean,   \PDO::PARAM_STR);
            $st->bindValue(':ctime',   $time,    \PDO::PARAM_INT);

            return $st->execute();
        } catch (\Throwable $e) {
            $this->logError('RL_AddComment failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Update an existing comment text if the actor owns it.
     */
    public function RL_UpdateComment(int $commentId, int $actorId, string $newText, int $time): bool
    {
        if ($commentId <= 0 || $actorId <= 0) {
            return false;
        }

        $this->RL_EnsureCommentUpdatedTimeColumn();

        try {
            $sel = $this->db->prepare('SELECT uid_fk, comment FROM i_comments WHERE c_id = :cid LIMIT 1');
            $sel->bindValue(':cid', $commentId, \PDO::PARAM_INT);
            $sel->execute();
            $row = $sel->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                return false;
            }

            $ownerId = (int) ($row['uid_fk'] ?? 0);
            if ($ownerId !== $actorId) {
                return false;
            }

            $clean = preg_replace('/\s+/u', ' ', trim($newText));
            if ($clean === '') {
                return false;
            }
            $maxLen = 5000;
            if (mb_strlen($clean, 'UTF-8') > $maxLen) {
                $clean = mb_substr($clean, 0, $maxLen, 'UTF-8');
            }

            if ($clean === (string) ($row['comment'] ?? '')) {
                return true;
            }

            $up = $this->db->prepare('UPDATE i_comments SET comment = :comment, updated_time = :utime WHERE c_id = :cid LIMIT 1');
            $up->bindValue(':comment', $clean, \PDO::PARAM_STR);
            $up->bindValue(':utime',   $time,  \PDO::PARAM_INT);
            $up->bindValue(':cid',     $commentId, \PDO::PARAM_INT);
            return $up->execute();
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_UpdateComment failed: ' . $e->getMessage());
            }
            return false;
        }
    }
    /**
     * Get total number of comments for a post.
     *
     * @param int $postID Target post id (i_comments.item_id)
     * @return int       Total comments
     */
    public function RL_TotalComment(int $postID): int
    {
        $this->RL_EnsureCommentUpdatedTimeColumn();
        try {
            $sql = "SELECT COUNT(*) FROM i_comments WHERE item_id = :pid";
            $st  = $this->db->prepare($sql);
            $st->bindValue(':pid', $postID, \PDO::PARAM_INT);
            $st->execute();
            return (int) $st->fetchColumn();
        } catch (\Throwable $e) {
            $this->logError('RL_TotalComment failed: ' . $e->getMessage());
            return 0;
        }
    }
    public function RL_GetRecentCommentsForPost(int $postID, int $limit = 3): array
    {
        if ($postID <= 0) {
            return [];
        }

        $this->RL_EnsureCommentUpdatedTimeColumn();

        try {
            $limit = max(1, min(10, $limit));

            $sql = "
                SELECT
                    c.c_id,
                    c.item_id,
                    c.uid_fk,
                    c.comment,
                    c.created_time,
                    c.updated_time,
                    u.username AS username
                FROM i_comments AS c
                LEFT JOIN i_users AS u ON u.user_id = c.uid_fk
                WHERE c.item_id = :pid
                ORDER BY c.created_time DESC, c.c_id DESC
                LIMIT {$limit}
            ";

            $st = $this->db->prepare($sql);
            $st->bindValue(':pid', $postID, \PDO::PARAM_INT);
            $st->execute();

            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            if (!$rows) {
                return [];
            }

            $out = [];
            foreach ($rows as $r) {
                $uid = (int)($r['uid_fk'] ?? 0);

                // Avatar is always obtained via RL_userAvatar
                $avatar = '';
                if ($uid > 0 && method_exists($this, 'RL_userAvatar')) {
                    $avatar = $this->RL_userAvatar($uid);
                }

                $out[] = [
                    'c_id'         => (int)($r['c_id'] ?? 0),
                    'item_id'      => (int)($r['item_id'] ?? 0),
                    'uid_fk'       => $uid,
                    'comment'      => (string)($r['comment'] ?? ''),
                    'created_time' => (int)($r['created_time'] ?? 0),
                    'updated_time' => (int)($r['updated_time'] ?? 0),
                    'username'     => (string)($r['username'] ?? ''),
                    'avatar'       => $avatar,
                ];
            }

            return $out;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetRecentCommentsForPost failed: ' . $e->getMessage());
            }
            return [];
        }
    }
    /**
     * Fetch all comments for a post EXCEPT the latest N (default 3).
     * Ordered newest-to-oldest so it appends neatly after the initial 3.
     *
     * Portable for MySQL 5.7+ (no CTE, no LIMIT-bigint hacks).
     *
     * @param int      $postID     Target post id (i_comments.item_id)
     * @param int      $skipLastN  Number of newest comments to skip (default 3)
     * @param int|null $maxFetch   Safety cap; null = no cap. Default 500 for performance.
     * @return array<int, array{
     *   c_id:int,item_id:int,uid_fk:int,comment:string,created_time:int,
     *   username:string,avatar:string
     * }>
     */
    public function RL_GetCommentsExceptLatestN(
        int $postID,
        int $skipLastN = 3,
        ?int $maxFetch = 500
    ): array {
        if ($postID <= 0) {
            return [];
        }

        $this->RL_EnsureCommentUpdatedTimeColumn();

        try {
            $skip = max(0, $skipLastN);

            // 1) Fetch newest N comment IDs
            $sqlTop = "
                SELECT c_id
                FROM i_comments
                WHERE item_id = :pid
                ORDER BY created_time DESC, c_id DESC
                LIMIT :lim
            ";
            $stTop = $this->db->prepare($sqlTop);
            $stTop->bindValue(':pid', $postID, \PDO::PARAM_INT);
            $stTop->bindValue(':lim', $skip, \PDO::PARAM_INT);
            $stTop->execute();
            $topIds = $stTop->fetchAll(\PDO::FETCH_COLUMN, 0);

            if (!$topIds || count($topIds) === 0) {
                // There are no comments to skip; return all (respecting $maxFetch if set)
                $limitSql = ($maxFetch !== null && $maxFetch > 0) ? " LIMIT :cap" : "";
                $sqlAll = "
                    SELECT c.c_id, c.item_id, c.uid_fk, c.comment, c.created_time, c.updated_time, u.username AS username
                    FROM i_comments AS c
                    LEFT JOIN i_users AS u ON u.user_id = c.uid_fk
                    WHERE c.item_id = :pid
                    ORDER BY c.created_time DESC, c.c_id DESC
                    {$limitSql}
                ";
                $stAll = $this->db->prepare($sqlAll);
                $stAll->bindValue(':pid', $postID, \PDO::PARAM_INT);
                if ($limitSql !== "") {
                    $stAll->bindValue(':cap', $maxFetch, \PDO::PARAM_INT);
                }
                $stAll->execute();
                $rows = $stAll->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            } else {
                // 2) Fetch remaining comments NOT IN newest N
                // Build dynamic placeholders for IN list
                $placeholders = implode(',', array_fill(0, count($topIds), '?'));
                $limitSql     = ($maxFetch !== null && $maxFetch > 0) ? " LIMIT ?" : "";

                $sqlRest = "
                    SELECT c.c_id, c.item_id, c.uid_fk, c.comment, c.created_time, c.updated_time, u.username AS username
                    FROM i_comments AS c
                    LEFT JOIN i_users AS u ON u.user_id = c.uid_fk
                    WHERE c.item_id = ?
                    AND c.c_id NOT IN ($placeholders)
                    ORDER BY c.created_time DESC, c.c_id DESC
                    {$limitSql}
                ";

                $stRest = $this->db->prepare($sqlRest);

                // Bind params: first item_id, then IN list, then (optional) cap
                $bindIndex = 1;
                $stRest->bindValue($bindIndex++, $postID, \PDO::PARAM_INT);
                foreach ($topIds as $cid) {
                    $stRest->bindValue($bindIndex++, (int)$cid, \PDO::PARAM_INT);
                }
                if ($limitSql !== "") {
                    $stRest->bindValue($bindIndex++, $maxFetch, \PDO::PARAM_INT);
                }

                $stRest->execute();
                $rows = $stRest->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            }

            if (!$rows) {
                return [];
            }

            // Normalize & enrich (avatar via RL_userAvatar)
            $out = [];
            foreach ($rows as $r) {
                $uid    = (int)($r['uid_fk'] ?? 0);
                $avatar = ($uid > 0 && method_exists($this, 'RL_userAvatar')) ? $this->RL_userAvatar($uid) : '';

                $out[] = [
                    'c_id'         => (int)($r['c_id'] ?? 0),
                    'item_id'      => (int)($r['item_id'] ?? 0),
                    'uid_fk'       => $uid,
                    'comment'      => (string)($r['comment'] ?? ''),
                    'created_time' => (int)($r['created_time'] ?? 0),
                    'updated_time' => (int)($r['updated_time'] ?? 0),
                    'username'     => (string)($r['username'] ?? ''),
                    'avatar'       => $avatar,
                ];
            }

            return $out;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetCommentsExceptLatestN failed: ' . $e->getMessage());
            }
            return [];
        }
    }
    /**
     * Fetch ALL comments for a post (newest → oldest).
     * Envato/reviewer-safe: no hacks, LEFT JOIN, prepared statements.
     *
     * @param int        $postID
     * @param int|null   $limit   Optional safety cap (null = no limit)
     * @param int        $offset  Optional offset for pagination
     * @return array<int, array{
     *   c_id:int,item_id:int,uid_fk:int,comment:string,created_time:int,
     *   username:string,avatar:string
     * }>
     */
    public function RL_GetAllCommentsForPost(int $postID, ?int $limit = null, int $offset = 0): array
    {
        if ($postID <= 0) {
            return [];
        }

        $this->RL_EnsureCommentUpdatedTimeColumn();

        try {
            $sql = "
                SELECT
                    c.c_id,
                    c.item_id,
                    c.uid_fk,
                    c.comment,
                    c.created_time,
                    c.updated_time,
                    u.username AS username
                FROM i_comments AS c
                LEFT JOIN i_users AS u ON u.user_id = c.uid_fk
                WHERE c.item_id = :pid
                ORDER BY c.created_time DESC, c.c_id DESC
            ";

            // LIMIT/OFFSET (optional)
            $useLimit  = ($limit !== null && $limit > 0);
            $useOffset = ($offset > 0);
            if ($useLimit && $useOffset) {
                $sql .= " LIMIT :lim OFFSET :off";
            } elseif ($useLimit) {
                $sql .= " LIMIT :lim";
            } elseif ($useOffset) {
                // MySQL OFFSET requires LIMIT; when using offset, apply a small safe cap.
                $sql .= " LIMIT 1000000000 OFFSET :off";
            }

            $st = $this->db->prepare($sql);
            $st->bindValue(':pid', $postID, \PDO::PARAM_INT);
            if ($useLimit)  { $st->bindValue(':lim', (int)$limit, \PDO::PARAM_INT); }
            if ($useOffset) { $st->bindValue(':off', (int)$offset, \PDO::PARAM_INT); }

            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            if (!$rows) {
                return [];
            }

            $out = [];
            foreach ($rows as $r) {
                $uid    = (int)($r['uid_fk'] ?? 0);
                $avatar = ($uid > 0 && method_exists($this, 'RL_userAvatar')) ? $this->RL_userAvatar($uid) : '';

                $out[] = [
                    'c_id'         => (int)($r['c_id'] ?? 0),
                    'item_id'      => (int)($r['item_id'] ?? 0),
                    'uid_fk'       => $uid,
                    'comment'      => (string)($r['comment'] ?? ''),
                    'created_time' => (int)($r['created_time'] ?? 0),
                    'updated_time' => (int)($r['updated_time'] ?? 0),
                    'username'     => (string)($r['username'] ?? ''),
                    'avatar'       => $avatar,
                ];
            }

            return $out;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetAllCommentsForPost failed: ' . $e->getMessage());
            }
            return [];
        }
    }
    /**
     * Insert a new comment and return its primary key (c_id).
     * Returns 0 on failure. Non-breaking helper.
     */
    public function RL_AddCommentReturningId(int $userID, int $postID, string $comment, int $time): int
    {
        $this->RL_EnsureCommentsSchema();
        try {
            $this->RL_EnsureCommentUpdatedTimeColumn();

            $clean = preg_replace('/\s+/u', ' ', trim($comment));
            if ($clean === '') {
                return 0;
            }
            $maxLen = 5000;
            if (mb_strlen($clean, 'UTF-8') > $maxLen) {
                $clean = mb_substr($clean, 0, $maxLen, 'UTF-8');
            }

            $sql = "INSERT INTO i_comments (item_id, uid_fk, comment, created_time)
                    VALUES (:pid, :uid, :comment, :ctime)";
            $st = $this->db->prepare($sql);
            $st->bindValue(':pid', $postID, \PDO::PARAM_INT);
            $st->bindValue(':uid', $userID, \PDO::PARAM_INT);
            $st->bindValue(':comment', $clean, \PDO::PARAM_STR);
            $st->bindValue(':ctime', $time, \PDO::PARAM_INT);

            if (!$st->execute()) {
                return 0;
            }

            $id = (int) $this->db->lastInsertId();
            return $id > 0 ? $id : 0;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_AddCommentReturningId failed: ' . $e->getMessage());
            }
            return 0;
        }
    }

    /**
     * Fetch a single comment by its primary key (joined with username + avatar).
     */
    public function RL_GetCommentById(int $commentID): ?array
    {
        if ($commentID <= 0) {
            return null;
        }

        $this->RL_EnsureCommentUpdatedTimeColumn();
        try {
            $sql = "
                SELECT c.c_id, c.item_id, c.uid_fk, c.comment, c.created_time, c.updated_time, u.username AS username
                FROM i_comments AS c
                LEFT JOIN i_users AS u ON u.user_id = c.uid_fk
                WHERE c.c_id = :cid
                LIMIT 1
            ";
            $st = $this->db->prepare($sql);
            $st->bindValue(':cid', $commentID, \PDO::PARAM_INT);
            $st->execute();
            $r = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$r) {
                return null;
            }

            $uid    = (int)($r['uid_fk'] ?? 0);
            $avatar = ($uid > 0 && method_exists($this, 'RL_userAvatar')) ? $this->RL_userAvatar($uid) : '';

            return [
                'c_id'         => (int)($r['c_id'] ?? 0),
                'item_id'      => (int)($r['item_id'] ?? 0),
                'uid_fk'       => $uid,
                'comment'      => (string)($r['comment'] ?? ''),
                'created_time' => (int)($r['created_time'] ?? 0),
                'updated_time' => (int)($r['updated_time'] ?? 0),
                'username'     => (string)($r['username'] ?? ''),
                'avatar'       => $avatar,
            ];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetCommentById failed: ' . $e->getMessage());
            }
            return null;
        }
    }

    /**
     * Backward-compatible fallback: resolve inserted row by (postID, userID, created_time).
     */
    public function RL_GetCommentByComposite(int $postID, int $userID, int $ctime): ?array
    {
        if ($postID <= 0 || $userID <= 0 || $ctime <= 0) {
            return null;
        }

        $this->RL_EnsureCommentUpdatedTimeColumn();
        try {
            $sql = "
                SELECT c.c_id, c.item_id, c.uid_fk, c.comment, c.created_time, c.updated_time, u.username AS username
                FROM i_comments AS c
                LEFT JOIN i_users AS u ON u.user_id = c.uid_fk
                WHERE c.item_id = :pid AND c.uid_fk = :uid AND c.created_time = :ctime
                ORDER BY c.c_id DESC
                LIMIT 1
            ";
            $st = $this->db->prepare($sql);
            $st->bindValue(':pid', $postID, \PDO::PARAM_INT);
            $st->bindValue(':uid', $userID, \PDO::PARAM_INT);
            $st->bindValue(':ctime', $ctime, \PDO::PARAM_INT);
            $st->execute();
            $r = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$r) {
                return null;
            }

            $uid    = (int)($r['uid_fk'] ?? 0);
            $avatar = ($uid > 0 && method_exists($this, 'RL_userAvatar')) ? $this->RL_userAvatar($uid) : '';

            return [
                'c_id'         => (int)($r['c_id'] ?? 0),
                'item_id'      => (int)($r['item_id'] ?? 0),
                'uid_fk'       => $uid,
                'comment'      => (string)($r['comment'] ?? ''),
                'created_time' => (int)($r['created_time'] ?? 0),
                'updated_time' => (int)($r['updated_time'] ?? 0),
                'username'     => (string)($r['username'] ?? ''),
                'avatar'       => $avatar,
            ];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetCommentByComposite failed: ' . $e->getMessage());
            }
            return null;
        }
    }
    /**
     * Capture @mentions → unique, lowercase usernames.
     *
     * @param string $text Input text possibly containing @mentions
     * @param int    $max  Maximum usernames to capture
     * @return array<int,string>
     */
    public function RL_ParseMentions(string $text, int $max = 20): array
    {
        if ($text === '') {
            return [];
        }
        preg_match_all('/@([A-Za-z0-9_\.]{3,32})/u', $text, $m);
        if (empty($m[1])) {
            return [];
        }
        $usernames = array_slice($m[1], 0, max(1, $max));
        $usernames = array_values(array_unique(array_map(
            static fn($u) => mb_strtolower($u, 'UTF-8'),
            $usernames
        )));
        return $usernames;
    }

    /**
     * Convert usernames to user IDs in bulk.
     *
     * @param array<int,string> $usernames List of usernames
     * @return array<string,int>           Map: lowercase username => user_id
     */
    public function RL_UserIdsByUsernames(array $usernames): array
    {
        if (empty($usernames)) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($usernames), '?'));
        $sql = "SELECT user_id, username FROM i_users WHERE LOWER(username) IN ($placeholders)";
        $st  = $this->db->prepare($sql);

        $i = 1;
        foreach ($usernames as $u) {
            $st->bindValue($i++, mb_strtolower($u, 'UTF-8'), \PDO::PARAM_STR);
        }

        if (!$st->execute()) {
            return [];
        }
        $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        $map  = [];
        foreach ($rows as $r) {
            $uname = mb_strtolower((string)($r['username'] ?? ''), 'UTF-8');
            $uid   = (int)($r['user_id'] ?? 0);
            if ($uname !== '' && $uid > 0) {
                $map[$uname] = $uid;
            }
        }
        return $map;
    }

    /**
     * Create mention notifications (type=mention).
     * object_id: comment_id, parent_object_id: post_id
     * extra_data: {"context":"mentioned you in a comment","post_id":..,"comment_id":..}
     *
     * @param int   $actorId       User who mentioned others
     * @param array $recipientIds  Mentioned user IDs
     * @param int   $commentId     Related comment ID
     * @param int   $postId        Related post ID
     * @param int|null $now        Timestamp override
     * @return int                 Number of notifications created
     */
    public function RL_CreateMentionNotifications(
        int $actorId,
        array $recipientIds,
        int $commentId,
        int $postId,
        ?int $now = null
    ): int {
        $now = $now ?? time();
        if ($actorId <= 0 || $commentId <= 0 || $postId <= 0 || empty($recipientIds)) {
            return 0;
        }
        // Filter duplicates and self-mentions
        $recipientIds = array_values(array_unique(array_filter(
            $recipientIds,
            static fn($rid) => (int)$rid > 0 && (int)$rid !== $actorId
        )));
        if (empty($recipientIds)) {
            return 0;
        }

        $sql = "INSERT INTO i_notifications
                (recipient_id, actor_id, type, object_id, parent_object_id, extra_data, is_read, created_at)
                VALUES (:rid, :aid, 'mention', :oid, :poid, :extra, 0, :ts)";
        $st  = $this->db->prepare($sql);

        $inserted = 0;
        foreach ($recipientIds as $rid) {
            $extra = json_encode([
                'context'    => 'mentioned you in a comment',
                'post_id'    => $postId,
                'comment_id' => $commentId,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            $st->bindValue(':rid',  (int)$rid,       \PDO::PARAM_INT);
            $st->bindValue(':aid',  (int)$actorId,   \PDO::PARAM_INT);
            $st->bindValue(':oid',  (int)$commentId, \PDO::PARAM_INT);
            $st->bindValue(':poid', (int)$postId,    \PDO::PARAM_INT);
            $st->bindValue(':extra', (string)$extra, \PDO::PARAM_STR);
            $st->bindValue(':ts',   (int)$now,       \PDO::PARAM_INT);

            if ($st->execute()) {
                $inserted++;
            }
        }
        return $inserted;
    }
    public function RL_CreateCommentNotification(
        int $actorId,
        int $recipientId,
        int $postId,
        int $commentId,
        int $time
    ): bool {
        try {
            if ($actorId <= 0 || $recipientId <= 0 || $recipientId === $actorId || $postId <= 0 || $commentId <= 0) {
                return false;
            }

            $extra = json_encode([
                'context'    => 'commented on your post',
                'post_id'    => $postId,
                'comment_id' => $commentId,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            $sql = "INSERT INTO i_notifications
                    (recipient_id, actor_id, type, object_id, parent_object_id, extra_data, is_read, created_at)
                    VALUES (:rid, :aid, 'comment', :oid, :poid, :extra, 0, :ts)";

            $st = $this->db->prepare($sql);
            $st->bindValue(':rid',   (int) $recipientId, \PDO::PARAM_INT);
            $st->bindValue(':aid',   (int) $actorId,     \PDO::PARAM_INT);
            $st->bindValue(':oid',   (int) $commentId,   \PDO::PARAM_INT);
            $st->bindValue(':poid',  (int) $postId,      \PDO::PARAM_INT);
            $st->bindValue(':extra', (string) $extra,    \PDO::PARAM_STR);
            $st->bindValue(':ts',    (int) $time,        \PDO::PARAM_INT);

            $ok = $st->execute();
            if (!$ok) {
                $info = $st->errorInfo();
                $msg  = 'RL_CreateCommentNotification execute failed: ' . print_r($info, true);
                if (is_callable([$this, 'logError'])) {
                    $this->logError($msg);
                } else {
                    error_log($msg);
                }
            }
            return (bool) $ok;
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_CreateCommentNotification error: ' . $e->getMessage());
            } else {
                error_log('RL_CreateCommentNotification error: ' . $e->getMessage());
            }
            return false;
        }
    }

    public function RL_GetCommentOwnerIdSimple(int $commentId): int
    {
        if ($commentId <= 0) {
            return 0;
        }
        try {
            $st = $this->db->prepare('SELECT uid_fk FROM i_comments WHERE c_id = :cid LIMIT 1');
            $st->bindValue(':cid', $commentId, \PDO::PARAM_INT);
            $st->execute();
            return (int) ($st->fetchColumn() ?: 0);
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_GetCommentOwnerIdSimple failed: ' . $e->getMessage());
            }
            return 0;
        }
    }

    public function RL_GetCommentPostId(int $commentId): int
    {
        if ($commentId <= 0) {
            return 0;
        }
        try {
            $st = $this->db->prepare('SELECT item_id FROM i_comments WHERE c_id = :cid LIMIT 1');
            $st->bindValue(':cid', $commentId, \PDO::PARAM_INT);
            $st->execute();
            return (int) ($st->fetchColumn() ?: 0);
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_GetCommentPostId failed: ' . $e->getMessage());
            }
            return 0;
        }
    }

    public function RL_HasUserReportedComment(int $commentId, int $userId): bool
    {
        if ($commentId <= 0 || $userId <= 0) {
            return false;
        }
        $this->RL_EnsureCommentReportsTable();
        try {
            $st = $this->db->prepare('SELECT id FROM i_comment_reports WHERE comment_id = :cid AND reporter_id = :rid LIMIT 1');
            $st->bindValue(':cid', $commentId, \PDO::PARAM_INT);
            $st->bindValue(':rid', $userId, \PDO::PARAM_INT);
            $st->execute();
            return (bool) $st->fetchColumn();
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_HasUserReportedComment failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    public function RL_ToggleCommentReport(int $commentId, int $reporterId, ?string $reason, ?int $now = null): array
    {
        $now = (int) ($now ?? time());
        if ($commentId <= 0 || $reporterId <= 0) {
            return ['reported' => false];
        }

        $this->RL_EnsureCommentReportsTable();

        try {
            $sel = $this->db->prepare('SELECT id FROM i_comment_reports WHERE comment_id = :cid AND reporter_id = :rid LIMIT 1');
            $sel->bindValue(':cid', $commentId, \PDO::PARAM_INT);
            $sel->bindValue(':rid', $reporterId, \PDO::PARAM_INT);
            $sel->execute();
            $existingId = (int) ($sel->fetchColumn() ?: 0);
            if ($existingId > 0) {
                $del = $this->db->prepare('DELETE FROM i_comment_reports WHERE id = :id');
                $del->bindValue(':id', $existingId, \PDO::PARAM_INT);
                $del->execute();
                return ['reported' => false, 'comment_id' => $commentId];
            }

            $cleanReason = null;
            if ($reason !== null) {
                $cleanReason = trim((string) $reason);
                if ($cleanReason === '') {
                    $cleanReason = null;
                } elseif (mb_strlen($cleanReason, 'UTF-8') > 255) {
                    $cleanReason = mb_substr($cleanReason, 0, 255, 'UTF-8');
                }
            }

            $ins = $this->db->prepare('INSERT INTO i_comment_reports (comment_id, reporter_id, reason, created_at) VALUES (:cid, :rid, :reason, :created)');
            $ins->bindValue(':cid', $commentId, \PDO::PARAM_INT);
            $ins->bindValue(':rid', $reporterId, \PDO::PARAM_INT);
            $ins->bindValue(':reason', $cleanReason, \PDO::PARAM_STR);
            $ins->bindValue(':created', $now, \PDO::PARAM_INT);
            $ins->execute();

            return ['reported' => true, 'comment_id' => $commentId];
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_ToggleCommentReport failed: ' . $e->getMessage());
            }
            return ['reported' => false, 'comment_id' => $commentId];
        }
    }

    public function RL_DeleteComment(int $commentId, int $actorId, bool $force = false): array
    {
        if ($commentId <= 0 || $actorId <= 0) {
            return ['deleted' => false];
        }

        try {
            $sel = $this->db->prepare('SELECT item_id, uid_fk FROM i_comments WHERE c_id = :cid LIMIT 1');
            $sel->bindValue(':cid', $commentId, \PDO::PARAM_INT);
            $sel->execute();
            $row = $sel->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                return ['deleted' => false, 'error' => 'not_found'];
            }

            $postId  = (int) ($row['item_id'] ?? 0);
            $ownerId = (int) ($row['uid_fk'] ?? 0);

            $postOwnerId = 0;
            if ($postId > 0) {
                if (method_exists($this, 'RL_GetPostOwnerId')) {
                    $postOwnerId = (int) $this->RL_GetPostOwnerId($postId);
                } else {
                    $pst = $this->db->prepare('SELECT post_owner_id FROM i_user_posts WHERE post_id = :pid LIMIT 1');
                    $pst->bindValue(':pid', $postId, \PDO::PARAM_INT);
                    $pst->execute();
                    $postOwnerId = (int) ($pst->fetchColumn() ?: 0);
                }
            }

            $allowed = $force || ($actorId === $ownerId) || ($postOwnerId > 0 && $actorId === $postOwnerId);
            if (!$allowed) {
                return ['deleted' => false, 'error' => 'not_allowed', 'post_id' => $postId];
            }

            $beganTxn = false;
            try {
                $beganTxn = $this->db->beginTransaction();
            } catch (\Throwable $__) {
                $beganTxn = false;
            }

            $del = $this->db->prepare('DELETE FROM i_comments WHERE c_id = :cid LIMIT 1');
            $del->bindValue(':cid', $commentId, \PDO::PARAM_INT);
            $del->execute();
            if ($del->rowCount() <= 0) {
                if ($beganTxn && $this->db->inTransaction()) {
                    $this->db->rollBack();
                }
                return ['deleted' => false, 'error' => 'delete_failed'];
            }

            try {
                $likes = $this->db->prepare('DELETE FROM i_comment_liked WHERE c_liked_comment_id = :cid');
                $likes->bindValue(':cid', $commentId, \PDO::PARAM_INT);
                $likes->execute();
            } catch (\Throwable $__) {
                // keep going
            }

            try {
                $this->RL_EnsureCommentReportsTable();
                $reports = $this->db->prepare('DELETE FROM i_comment_reports WHERE comment_id = :cid');
                $reports->bindValue(':cid', $commentId, \PDO::PARAM_INT);
                $reports->execute();
            } catch (\Throwable $__) {
                // keep going
            }

            try {
                $notifs = $this->db->prepare("DELETE FROM i_notifications WHERE type IN ('comment','comment_like','mention') AND object_id = :cid");
                $notifs->bindValue(':cid', $commentId, \PDO::PARAM_INT);
                $notifs->execute();
            } catch (\Throwable $__) {
                // ignore
            }

            if ($beganTxn && $this->db->inTransaction()) {
                $this->db->commit();
            }

            return [
                'deleted'          => true,
                'post_id'          => $postId,
                'comment_owner_id' => $ownerId,
            ];
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_DeleteComment failed: ' . $e->getMessage());
            }
            return ['deleted' => false, 'error' => 'exception'];
        }
    }
}
