<?php
declare(strict_types=1);

trait BookmarksFunctions {
    /**
     * Fetch bookmarked image posts for a user.
     * Returns same shape as RL_FeedAllImages so layouts can be reused.
     *
     * @param int $userID Current user id (bookmarks owner)
     * @param int $limit  Page size
     * @param int $offset Offset
     * @return array<int, array<string,mixed>>
     */
    public function RL_FeedBookmarksImages(int $userID, int $limit = 20, int $offset = 0): array
    {
        try {
            if ($userID <= 0) { return []; }
            $limit  = max(1, (int) $limit);
            $offset = max(0, (int) $offset);

            $sql = "
                SELECT
                    p.post_id,
                    p.post_owner_id,
                    p.post_type,
                    p.post_file,
                    p.post_text,
                    p.post_views,
                    p.post_visibility,
                    p.post_price,
                    p.comment_status,
                    p.like_status,
                    p.post_created_time,

                    u.user_id         AS owner_id,
                    u.username        AS owner_username,
                    u.user_fullname   AS owner_fullname,
                    u.user_avatar     AS owner_avatar,
                    u.verified_status AS owner_verified,

                    b.created_time    AS bookmarked_time
                FROM i_bookmarks AS b
                INNER JOIN i_user_posts AS p
                    ON p.post_id = b.item_id AND p.post_type = 'image' AND (p.approval_status IS NULL OR p.approval_status = 'approved')
                INNER JOIN i_users AS u
                    ON u.user_id = p.post_owner_id
                WHERE b.uid_fk = :uid AND b.item_type = 'image'
                ORDER BY b.created_time DESC
                LIMIT $offset, $limit
            ";

            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $userID, \PDO::PARAM_INT);
            $st->execute();

            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            $list = [];
            foreach ($rows as $row) {
                $files = array_values(
                    array_filter(
                        array_map('trim', explode(',', (string) ($row['post_file'] ?? ''))),
                        static fn($p) => $p !== ''
                    )
                );
                $firstFile = $files[0] ?? '';
                $hasMulti  = count($files) > 1;

                $ownerId = (int) $row['post_owner_id'];
                $list[] = [
                    'post_id'            => (int) $row['post_id'],
                    'post_owner_id'      => $ownerId,
                    'post_type'          => (string) $row['post_type'],
                    'post_file'          => (string) $row['post_file'],
                    'post_files'         => $files,
                    'first_image'        => $firstFile,
                    'images_count'       => count($files),
                    'has_multiple_images'=> $hasMulti,
                    'post_text'          => (string) $row['post_text'],
                    'post_visibility'    => (string) $row['post_visibility'],
                    'post_price'         => $row['post_price'] !== null ? (string) $row['post_price'] : null,
                    'comment_status'     => (string) $row['comment_status'],
                    'like_status'        => (string) $row['like_status'],
                    'post_created_time'  => (int) $row['post_created_time'],
                    'post_views'         => (int) $row['post_views'],
                    'owner_id'           => (int) $row['owner_id'],
                    'owner_username'     => (string) $row['owner_username'],
                    'owner_fullname'     => (string) $row['owner_fullname'],
                    'owner_avatar'       => (string) $row['owner_avatar'],
                    'owner_verified'     => (int) $row['owner_verified'],
                    'relation_status'    => null,
                    'is_owner'           => ($userID > 0 && $userID === $ownerId),
                    'bookmarked_time'    => (int) $row['bookmarked_time'],
                ];
            }
            return $list;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_FeedBookmarksImages failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    /**
     * Fetch bookmarked video posts for a user (shape similar to RL_FeedAllVideos).
     */
    public function RL_FeedBookmarksVideos(int $userID, int $limit = 20, int $offset = 0): array
    {
        try {
            if ($userID <= 0) { return []; }
            $limit  = max(1, (int) $limit);
            $offset = max(0, (int) $offset);

            $sql = "
                SELECT
                    p.post_id,
                    p.post_owner_id,
                    p.post_type,
                    p.post_file,
                    p.post_text,
                    p.post_views,
                    p.post_visibility,
                    p.post_price,
                    p.comment_status,
                    p.like_status,
                    p.post_created_time,

                    u.user_id         AS owner_id,
                    u.username        AS owner_username,
                    u.user_fullname   AS owner_fullname,
                    u.user_avatar     AS owner_avatar,
                    u.verified_status AS owner_verified,

                    b.created_time    AS bookmarked_time
                FROM i_bookmarks AS b
                INNER JOIN i_user_posts AS p
                    ON p.post_id = b.item_id AND p.post_type = 'video' AND (p.approval_status IS NULL OR p.approval_status = 'approved')
                INNER JOIN i_users AS u
                    ON u.user_id = p.post_owner_id
                WHERE b.uid_fk = :uid AND b.item_type = 'video'
                ORDER BY b.created_time DESC
                LIMIT $offset, $limit
            ";

            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $userID, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            $list = [];
            foreach ($rows as $row) {
                $ownerId = (int) $row['post_owner_id'];
                $list[] = [
                    'post_id'           => (int) $row['post_id'],
                    'post_owner_id'     => $ownerId,
                    'post_type'         => (string) $row['post_type'],
                    'post_file'         => (string) $row['post_file'],
                    'post_text'         => (string) $row['post_text'],
                    'post_visibility'   => (string) $row['post_visibility'],
                    'post_price'        => $row['post_price'] !== null ? (string) $row['post_price'] : null,
                    'comment_status'    => (string) $row['comment_status'],
                    'like_status'       => (string) $row['like_status'],
                    'post_created_time' => (int) $row['post_created_time'],
                    'post_views'        => (int) $row['post_views'],
                    'owner_id'          => (int) $row['owner_id'],
                    'owner_username'    => (string) $row['owner_username'],
                    'owner_fullname'    => (string) $row['owner_fullname'],
                    'owner_avatar'      => (string) $row['owner_avatar'],
                    'owner_verified'    => (int) $row['owner_verified'],
                    'relation_status'   => null,
                    'is_owner'          => ($userID > 0 && $userID === $ownerId),
                    'bookmarked_time'   => (int) $row['bookmarked_time'],
                ];
            }
            return $list;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_FeedBookmarksVideos failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    /**
     * Fetch bookmarked posts mixed (images and videos) ordered by bookmark time desc.
     * The shape includes post_type and post_file; caller can decide how to render
     * (e.g., images -> first image, videos -> thumbnail via videoThumbNail()).
     */
    public function RL_FeedBookmarksMixed(int $userID, int $limit = 20, int $offset = 0): array
    {
        try {
            if ($userID <= 0) { return []; }
            $limit  = max(1, (int) $limit);
            $offset = max(0, (int) $offset);

            $sql = "
                SELECT
                    p.post_id,
                    p.post_owner_id,
                    p.post_type,
                    p.post_file,
                    p.post_text,
                    p.post_views,
                    p.post_visibility,
                    p.post_price,
                    p.comment_status,
                    p.like_status,
                    p.post_created_time,

                    u.user_id         AS owner_id,
                    u.username        AS owner_username,
                    u.user_fullname   AS owner_fullname,
                    u.user_avatar     AS owner_avatar,
                    u.verified_status AS owner_verified,

                    b.created_time    AS bookmarked_time,
                    b.item_type       AS bookmark_type
                FROM i_bookmarks AS b
                INNER JOIN i_user_posts AS p
                    ON p.post_id = b.item_id AND (p.approval_status IS NULL OR p.approval_status = 'approved')
                INNER JOIN i_users AS u
                    ON u.user_id = p.post_owner_id
                WHERE b.uid_fk = :uid
                ORDER BY b.created_time DESC
                LIMIT $offset, $limit
            ";

            $st = $this->db->prepare($sql);
            $st->bindValue(':uid', $userID, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            $list = [];
            foreach ($rows as $row) {
                $ownerId = (int) $row['post_owner_id'];
                $files = [];
                $firstFile = '';
                $hasMulti = false;
                if (($row['post_type'] ?? '') === 'image') {
                    $files = array_values(array_filter(array_map('trim', explode(',', (string) ($row['post_file'] ?? ''))), static fn($p)=>$p!==''));
                    $firstFile = $files[0] ?? '';
                    $hasMulti = count($files) > 1;
                }

                $list[] = [
                    'post_id'            => (int) $row['post_id'],
                    'post_owner_id'      => $ownerId,
                    'post_type'          => (string) $row['post_type'],
                    'post_file'          => (string) $row['post_file'],
                    'post_files'         => $files,
                    'first_image'        => $firstFile,
                    'images_count'       => count($files),
                    'has_multiple_images'=> $hasMulti,
                    'post_text'          => (string) $row['post_text'],
                    'post_visibility'    => (string) $row['post_visibility'],
                    'post_price'         => $row['post_price'] !== null ? (string) $row['post_price'] : null,
                    'comment_status'     => (string) $row['comment_status'],
                    'like_status'        => (string) $row['like_status'],
                    'post_created_time'  => (int) $row['post_created_time'],
                    'post_views'         => (int) $row['post_views'],
                    'owner_id'           => (int) $row['owner_id'],
                    'owner_username'     => (string) $row['owner_username'],
                    'owner_fullname'     => (string) $row['owner_fullname'],
                    'owner_avatar'       => (string) $row['owner_avatar'],
                    'owner_verified'     => (int) $row['owner_verified'],
                    'relation_status'    => null,
                    'is_owner'           => ($userID > 0 && $userID === $ownerId),
                    'bookmarked_time'    => (int) $row['bookmarked_time'],
                ];
            }
            return $list;
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_FeedBookmarksMixed failed: ' . $e->getMessage());
            }
            return [];
        }
    }
}
