<?php
declare(strict_types=1);

trait AdvertisementFunctions {
    /**
     * Insert a new advertisement row.
     * Returns inserted ad_id on success, 0 on failure.
     */
    public function RL_CreateAdvertisement(
        int $userId,
        string $title,
        string $description,
        string $mediaType,
        string $adMedia,
        int $targetImpressions = 0,
        float $pricePerImpression = 0.0,
        int $durationDays = 1,
        float $totalBudget = 0.0,
        string $status = 'draft',
        ?int $createdAt = null,
        ?string $adLink = null
    ): int {
        $allowedMedia = ['image','video'];
        if (!in_array($mediaType, $allowedMedia, true)) { $mediaType = 'image'; }

        $allowedStatus = ['draft','active','paused','ended'];
        if (!in_array($status, $allowedStatus, true)) { $status = 'draft'; }

        $title = trim($title);
        if ($title === '') { return 0; }

        $description = trim($description);
        $adMedia = trim($adMedia);
        if ($adMedia === '') { return 0; }

        $targetImpressions   = max(0, (int)$targetImpressions);
        $pricePerImpression  = max(0.0, (float)$pricePerImpression);
        $durationDays        = max(1, (int)$durationDays);
        $totalBudget         = max(0.0, (float)$totalBudget);
        $createdAt           = $createdAt ?? time();
        $adLink              = $this->RL_NormalizeAdLinkValue($adLink);

        try {
            /** @var PDO $db */
            $db = $this->getDb();
            $this->RL_EnsureAdLinkColumn();
            $sql = "INSERT INTO i_user_advertisements
                (user_id, title, description, media_type, ad_media, ad_link, target_impressions, price_per_impression, duration_days, total_budget, views, clicks, status, created_at, updated_at)
                VALUES
                (:user_id, :title, :description, :media_type, :ad_media, :ad_link, :target_impressions, :price_per_impression, :duration_days, :total_budget, 0, 0, :status, :created_at, NULL)";

            $stmt = $db->prepare($sql);
            $stmt->bindValue(':user_id', $userId, \PDO::PARAM_INT);
            $stmt->bindValue(':title', $title, \PDO::PARAM_STR);
            $stmt->bindValue(':description', $description, \PDO::PARAM_STR);
            $stmt->bindValue(':media_type', $mediaType, \PDO::PARAM_STR);
            $stmt->bindValue(':ad_media', $adMedia, \PDO::PARAM_STR);
            $stmt->bindValue(':ad_link', $adLink !== '' ? $adLink : null, $adLink !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
            $stmt->bindValue(':target_impressions', $targetImpressions, \PDO::PARAM_INT);
            $stmt->bindValue(':price_per_impression', $pricePerImpression);
            $stmt->bindValue(':duration_days', $durationDays, \PDO::PARAM_INT);
            $stmt->bindValue(':total_budget', $totalBudget);
            $stmt->bindValue(':status', $status, \PDO::PARAM_STR);
            $stmt->bindValue(':created_at', $createdAt, \PDO::PARAM_INT);

            if ($stmt->execute()) {
                return (int)$db->lastInsertId();
            }
        } catch (\Throwable $e) {
            // Optionally log error in debug environments
        }
        return 0;
    }

    /**
     * Fetch active advertisements suitable for the main feed and sidebar placements.
     *
     * @param int              $limit        Maximum number of ads requested (internally capped to 3).
     * @param array<int, int>  $excludeAdIds Ad ids that should be skipped (e.g. already rendered on page).
     * @param int|null         $viewerId     Optional viewer id to avoid showing own ads.
     *
     * @return array<int, array<string, mixed>> Normalised advertisement payloads.
     */
    public function RL_GetActiveAdvertisementsForFeed(int $limit, array $excludeAdIds = [], ?int $viewerId = null, ?string $mediaType = null): array
    {
        $limit = max(0, $limit);
        if ($limit <= 0) {
            return [];
        }

        // Rate-limit: never return more than 3 ads per request to keep feed lightweight.
        if ($limit > 3) {
            $limit = 3;
        }

        $viewerId = $viewerId !== null ? max(0, (int) $viewerId) : null;
        $mediaType = is_string($mediaType) ? strtolower(trim($mediaType)) : null;
        if (!in_array($mediaType, ['image', 'video'], true)) {
            $mediaType = null;
        }

        $exclude = [];
        foreach ($excludeAdIds as $candidate) {
            $candidate = (int) $candidate;
            if ($candidate > 0) {
                $exclude[$candidate] = $candidate;
            }
        }
        $exclude = array_values($exclude);

        try {
            /** @var \PDO $db */
            $db = $this->getDb();
            $this->RL_EnsureAdLinkColumn();
        } catch (\Throwable $e) {
            return [];
        }

        // Ensure metrics table exists before querying aggregated metrics (best-effort).
        $this->RL_EnsureAdMetricsTable();

        $conditions = ["a.status = 'active'", 'COALESCE(u.is_banned, 0) = 0'];
        $params = [];

        if (!empty($exclude)) {
            $placeholders = implode(', ', array_fill(0, count($exclude), '?'));
            $conditions[] = 'a.ad_id NOT IN (' . $placeholders . ')';
            $params = array_merge($params, $exclude);
        }

        if ($mediaType !== null) {
            $conditions[] = 'a.media_type = ?';
            $params[] = $mediaType;
        }

        $fetchLimit = $limit * 3;
        if ($fetchLimit < $limit) {
            $fetchLimit = $limit;
        } elseif ($fetchLimit > 30) {
            $fetchLimit = 30;
        }

        $sql = 'SELECT
                    a.ad_id,
                    a.user_id,
                    a.title,
                    a.description,
                    a.media_type,
                    a.ad_media,
                    a.target_impressions,
                    a.views,
                    a.clicks,
                    a.total_budget,
                    a.ad_link,
                    a.price_per_impression,
                    a.created_at,
                    a.updated_at,
                    COALESCE(p.total_spent, 0) AS spent_amount,
                    COALESCE(m.impressions, NULL) AS impressions_total,
                    COALESCE(m.clicks, NULL) AS clicks_total,
                    COALESCE(m.spend_total, 0) AS metrics_spend,
                    u.username,
                    u.user_fullname
                FROM i_user_advertisements a
                INNER JOIN i_users u ON u.user_id = a.user_id
                LEFT JOIN (
                    SELECT COALESCE(object_id, ad_id) AS ref_id, SUM(amount) AS total_spent
                    FROM i_ad_payments
                    WHERE payment_type = \'advertisement\'
                      AND status IN (\'succeeded\', \'paid\', \'completed\')
                    GROUP BY COALESCE(object_id, ad_id)
                ) p ON p.ref_id = a.ad_id
                LEFT JOIN (
                    SELECT ad_id, SUM(impressions) AS impressions, SUM(clicks) AS clicks, SUM(spend) AS spend_total
                    FROM i_ad_metrics
                    GROUP BY ad_id
                ) m ON m.ad_id = a.ad_id';

        if ($conditions) {
            $sql .= ' WHERE ' . implode(' AND ', $conditions);
        }

        $sql .= ' ORDER BY COALESCE(a.updated_at, a.created_at) DESC, a.ad_id DESC LIMIT ' . (int) $fetchLimit;

        try {
            $stmt = $db->prepare($sql);
            foreach ($params as $idx => $value) {
                $stmt->bindValue($idx + 1, $value, \PDO::PARAM_INT);
            }
            $stmt->execute();
            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            $this->RL_LogAdError('RL_GetActiveAdvertisementsForFeed', $e);
            return [];
        }

        if (empty($rows)) {
            return [];
        }

        $ads = [];
        foreach ($rows as $row) {
            $adId = (int) ($row['ad_id'] ?? 0);
            if ($adId <= 0) {
                continue;
            }

            $mediaType = strtolower((string) ($row['media_type'] ?? ''));
            $mediaList = $this->RL_NormalizeAdMediaList($mediaType, (string) ($row['ad_media'] ?? ''));
            if (empty($mediaList)) {
                continue;
            }

            $targetImpressions = max(0, (int) ($row['target_impressions'] ?? 0));
            $rawMetrics = (int) ($row['impressions_total'] ?? 0);
            if ($rawMetrics <= 0) {
                $rawMetrics = (int) ($row['views'] ?? 0);
            }
            $remainingImpressions = null;
            if ($targetImpressions > 0) {
                $remainingImpressions = max(0, $targetImpressions - $rawMetrics);
            }

            $totalBudget = isset($row['total_budget']) ? (float) $row['total_budget'] : 0.0;
            $adLink = $this->RL_NormalizeAdLinkValue($row['ad_link'] ?? null);
            $metricsSpend = isset($row['metrics_spend']) ? (float) $row['metrics_spend'] : 0.0;
            $consumedBudget = $metricsSpend > 0 ? round($metricsSpend, 4) : 0.0;

            $remainingBudgetRaw = $totalBudget - $consumedBudget;
            $remainingBudget = $remainingBudgetRaw > 0 ? round($remainingBudgetRaw, 4) : 0.0;

            $exhaustedByBudget = ($totalBudget > 0.0) && ($remainingBudgetRaw <= 0.0);
            $exhaustedByImpressions = ($targetImpressions > 0) && ($remainingImpressions !== null) && ($remainingImpressions <= 0);

            if ($exhaustedByBudget && $exhaustedByImpressions) {
                continue; // nothing left to serve
            }
            if ($exhaustedByBudget && $targetImpressions === 0) {
                continue;
            }
            if ($exhaustedByImpressions && $totalBudget <= 0.0) {
                continue;
            }

            $ads[] = [
                'ad_id'                => $adId,
                'user_id'              => (int) ($row['user_id'] ?? 0),
                'title'                => (string) ($row['title'] ?? ''),
                'description'          => (string) ($row['description'] ?? ''),
                'media_type'           => $mediaType !== 'video' ? 'image' : 'video',
                'media_items'          => $mediaList,
                'target_impressions'   => $targetImpressions,
                'impressions'          => $rawMetrics,
                'clicks'               => (int) ($row['clicks_total'] ?? ($row['clicks'] ?? 0)),
                'total_budget'         => $totalBudget,
                'spent_amount'         => $consumedBudget,
                'remaining_budget'     => $remainingBudget,
                'remaining_impressions'=> $remainingImpressions,
                'price_per_impression' => isset($row['price_per_impression']) ? (float) $row['price_per_impression'] : 0.0,
                'ad_link'              => $adLink,
                'username'             => (string) ($row['username'] ?? ''),
                'user_fullname'        => (string) ($row['user_fullname'] ?? ''),
                'created_at'           => isset($row['created_at']) ? (int) $row['created_at'] : null,
                'updated_at'           => isset($row['updated_at']) ? (int) $row['updated_at'] : null,
            ];

            if (count($ads) >= $limit) {
                break;
            }
        }

        return $ads;
    }

    /** Fetch a single advertisement by id (owner-agnostic). */
    public function RL_GetAdvertisementById(int $adId): ?array {
        try {
            $db = $this->getDb();
            $stmt = $db->prepare("SELECT * FROM i_user_advertisements WHERE ad_id = :id LIMIT 1");
            $stmt->bindValue(':id', $adId, \PDO::PARAM_INT);
            $stmt->execute();
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** Update advertisement status. */
    public function RL_UpdateAdvertisementStatus(int $adId, string $status): bool {
        $allowed = ['draft','active','paused','ended'];
        if (!in_array($status, $allowed, true)) { return false; }
        try {
            $db = $this->getDb();
            $stmt = $db->prepare("UPDATE i_user_advertisements SET status = :st, updated_at = :t WHERE ad_id = :id");
            $stmt->bindValue(':st', $status, \PDO::PARAM_STR);
            $stmt->bindValue(':t', time(), \PDO::PARAM_INT);
            $stmt->bindValue(':id', $adId, \PDO::PARAM_INT);
            return $stmt->execute();
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** Remove an advertisement row and best-effort delete its media files. */
    public function RL_DeleteAdvertisement(int $adId): bool {
        if ($adId <= 0) { return false; }
        try {
            $db = $this->getDb();
            $db->beginTransaction();

            $stmt = $db->prepare("SELECT media_type, ad_media FROM i_user_advertisements WHERE ad_id = :id LIMIT 1");
            $stmt->bindValue(':id', $adId, \PDO::PARAM_INT);
            $stmt->execute();
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$row) {
                $db->rollBack();
                return false;
            }

            $del = $db->prepare("DELETE FROM i_user_advertisements WHERE ad_id = :id LIMIT 1");
            $del->bindValue(':id', $adId, \PDO::PARAM_INT);
            $del->execute();
            $db->commit();

            $mediaType = (string)($row['media_type'] ?? '');
            $mediaList = (string)($row['ad_media'] ?? '');
            $this->RL_RemoveAdvertisementMediaFiles($mediaList, $mediaType);
            return true;
        } catch (\Throwable $e) {
            try { $this->getDb()->rollBack(); } catch (\Throwable $__) {}
            return false;
        }
    }

    /** Attempt to unlink advertisement media without throwing. */
    private function RL_RemoveAdvertisementMediaFiles(string $mediaPaths, string $mediaType): void {
        $mediaPaths = trim($mediaPaths);
        if ($mediaPaths === '') { return; }

        $paths = [];
        if ($mediaType === 'image') {
            $parts = array_map('trim', explode(',', $mediaPaths));
            foreach ($parts as $part) {
                if ($part !== '') { $paths[] = $part; }
            }
        } else {
            $paths[] = $mediaPaths;
        }

        if (empty($paths)) { return; }

        $projectRoot = dirname(__DIR__, 2);
        $uploadsRoot = $projectRoot . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR;

        foreach ($paths as $relPath) {
            $relPath = trim(str_replace(['\\', '..'], ['/', ''], $relPath), '/');
            if ($relPath === '') { continue; }

            $fullPath = $projectRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relPath);
            $realPath = @realpath($fullPath);

            if ($realPath === false) {
                continue;
            }

            $realPath = rtrim($realPath, DIRECTORY_SEPARATOR);
            if (strpos($realPath, $uploadsRoot) !== 0) {
                continue; // never delete outside uploads directory
            }

            if (is_file($realPath)) {
                @unlink($realPath);
            }
        }
    }

    /**
     * Normalise advertisement media payloads into a list of relative paths.
     *
     * @return array<int, string>
     */
    private function RL_NormalizeAdMediaList(string $mediaType, string $mediaPayload): array
    {
        $mediaPayload = trim($mediaPayload);
        if ($mediaPayload === '') {
            return [];
        }

        $mediaType = strtolower(trim($mediaType));
        if ($mediaType === 'image') {
            $parts = array_values(array_filter(array_map('trim', explode(',', $mediaPayload)), static function ($value): bool {
                return $value !== '';
            }));
            return $parts;
        }

        return [$mediaPayload];
    }

    private function RL_NormalizeAdLinkValue(?string $adLink): string
    {
        $link = trim((string) $adLink);
        if ($link === '') {
            return '';
        }

        if (!preg_match('#^https?://#i', $link)) {
            $link = 'https://' . $link;
        }

        if (!filter_var($link, FILTER_VALIDATE_URL)) {
            return '';
        }

        if (!preg_match('#^https?://#i', $link)) {
            return '';
        }

        return $link;
    }

    private function RL_EnsureAdLinkColumn(): void
    {
        static $ensured = false;
        if ($ensured) {
            return;
        }

        try {
            $db = $this->getDb();
            $db->exec("ALTER TABLE i_user_advertisements ADD COLUMN ad_link VARCHAR(255) DEFAULT NULL AFTER ad_media");
        } catch (\Throwable $__) {
            // Column already exists or cannot be added; ignore silently.
        }

        $ensured = true;
    }

    /**
     * Ensure the advertisement metrics table exists (idempotent).
     */
    public function RL_EnsureAdMetricsTable(): bool {
        static $ensured = false;
        if ($ensured) {
            return true;
        }

        try {
            /** @var \PDO $db */
            $db = $this->getDb();
            $sql = "CREATE TABLE IF NOT EXISTS i_ad_metrics (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                ad_id INT UNSIGNED NOT NULL,
                metric_date DATE NOT NULL,
                impressions INT UNSIGNED DEFAULT 0,
                clicks INT UNSIGNED DEFAULT 0,
                spend DECIMAL(10,4) DEFAULT 0.0000,
                UNIQUE KEY uniq_ad_date (ad_id, metric_date),
                KEY idx_ad_metrics_date (metric_date),
                KEY idx_ad_metrics_ad (ad_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

            $db->exec($sql);
            try {
                $db->exec('ALTER TABLE i_ad_metrics MODIFY spend DECIMAL(10,4) DEFAULT 0.0000');
            } catch (\Throwable $__) {
                // ignore when column already uses desired precision
            }
            $ensured = true;
            return true;
        } catch (\Throwable $e) {
            $this->RL_LogAdError('RL_EnsureAdMetricsTable', $e);
            return false;
        }
    }

    /**
     * Return all advertisements for a user ordered by status and recency.
     *
     * @return array<int, array<string, mixed>>
     */
    public function RL_ListUserAdvertisements(int $userId): array {
        $userId = max(0, $userId);
        if ($userId <= 0) {
            return [];
        }

        try {
            /** @var \PDO $db */
            $db = $this->getDb();
            $this->RL_EnsureAdLinkColumn();
            $stmt = $db->prepare(
                "SELECT ad_id, user_id, title, description, media_type, ad_media, target_impressions, price_per_impression,
                        duration_days, total_budget, views, clicks, status, created_at, updated_at
                 FROM i_user_advertisements
                 WHERE user_id = :uid
                 ORDER BY FIELD(status, 'active','paused','draft','ended'), created_at DESC"
            );
            $stmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
            $stmt->execute();
            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            if (empty($rows)) {
                return [];
            }

            $adIds = array_values(array_filter(array_map('intval', array_column($rows, 'ad_id'))));
            $spendMap = [];
            $currencyMap = [];

            if (!empty($adIds)) {
                $placeholders = implode(', ', array_fill(0, count($adIds), '?'));
                $sql = "SELECT COALESCE(object_id, ad_id) AS ref_id, SUM(amount) AS total_amount, MAX(currency) AS currency
                        FROM i_ad_payments
                        WHERE payment_type = 'advertisement'
                          AND status IN ('succeeded','paid','completed')
                          AND COALESCE(object_id, ad_id) IN ($placeholders)
                        GROUP BY COALESCE(object_id, ad_id)";
                $spendStmt = $db->prepare($sql);
                foreach ($adIds as $idx => $id) {
                    $spendStmt->bindValue($idx + 1, $id, \PDO::PARAM_INT);
                }
                $spendStmt->execute();
                $spendRows = $spendStmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
                foreach ($spendRows as $spendRow) {
                    $ref = (int) ($spendRow['ref_id'] ?? 0);
                    if ($ref <= 0) {
                        continue;
                    }
                    $amount = isset($spendRow['total_amount']) ? (float) $spendRow['total_amount'] : 0.0;
                    $currency = (string) ($spendRow['currency'] ?? '');
                    $spendMap[$ref] = $amount;
                    if ($currency !== '') {
                        $currencyMap[$ref] = strtoupper($currency);
                    }
                }

                if ($this->RL_EnsureAdMetricsTable()) {
                    $metricSql = "SELECT ad_id, SUM(impressions) AS impressions, SUM(clicks) AS clicks, SUM(spend) AS spend
                                  FROM i_ad_metrics
                                  WHERE ad_id IN ($placeholders)
                                  GROUP BY ad_id";
                    $metricStmt = $db->prepare($metricSql);
                    foreach ($adIds as $idx => $id) {
                        $metricStmt->bindValue($idx + 1, $id, \PDO::PARAM_INT);
                    }
                    $metricStmt->execute();
                    $metricRows = $metricStmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
                    $metricsMap = [];
                    foreach ($metricRows as $metricRow) {
                        $mid = (int) ($metricRow['ad_id'] ?? 0);
                        if ($mid <= 0) {
                            continue;
                        }
                        $metricsMap[$mid] = [
                            'impressions'  => (int) ($metricRow['impressions'] ?? 0),
                            'clicks'       => (int) ($metricRow['clicks'] ?? 0),
                            'spend'        => isset($metricRow['spend']) ? (float) $metricRow['spend'] : 0.0,
                            'has_metrics'  => true,
                        ];
                    }
                } else {
                    $metricsMap = [];
                }
            } else {
                $metricsMap = [];
            }

            $result = [];
            foreach ($rows as $row) {
                $adId = (int) ($row['ad_id'] ?? 0);
                $budget = isset($row['total_budget']) ? (float) $row['total_budget'] : 0.0;
                $metrics = $metricsMap[$adId] ?? null;
                $hasMetrics = $metrics ? !empty($metrics['has_metrics']) : false;
                $metricsSpend = $metrics ? (float) ($metrics['spend'] ?? 0.0) : 0.0;

                $spent = $hasMetrics ? $metricsSpend : ($spendMap[$adId] ?? 0.0);
                $spent = round($spent, 4);
                $remaining = $budget - $spent;
                if ($remaining < 0) {
                    $remaining = 0.0;
                }
                $remaining = round($remaining, 4);

                $viewsTotal = $metrics ? $metrics['impressions'] : (int) ($row['views'] ?? 0);
                $clicksTotal = $metrics ? $metrics['clicks'] : (int) ($row['clicks'] ?? 0);

                $row['total_budget'] = $budget;
                $row['spent_amount'] = $spent;
                $row['remaining_amount'] = $remaining;
                $row['views_total'] = $viewsTotal;
                $row['clicks_total'] = $clicksTotal;
                $row['currency_code'] = $currencyMap[$adId] ?? '';
                if ($row['currency_code'] === '') {
                    $row['currency_code'] = $this->RL_DetectSiteCurrency();
                }
                $row['ad_link'] = $this->RL_NormalizeAdLinkValue($row['ad_link'] ?? null);

                $result[] = $row;
            }

            return $result;
        } catch (\Throwable $e) {
            $this->RL_LogAdError('RL_ListUserAdvertisements', $e);
            return [];
        }
    }

    /**
     * Aggregate advertisement financial data for a user.
     *
     * @return array<string, mixed>
     */
    public function RL_GetAdvertisementFinancials(int $userId): array {
        $userId = max(0, $userId);
        if ($userId <= 0) {
            return [
                'active'          => 0,
                'paused'          => 0,
                'draft'           => 0,
                'ended'           => 0,
                'total_budget'    => 0.0,
                'total_spent'     => 0.0,
                'total_remaining' => 0.0,
                'currency_code'   => $this->RL_DetectSiteCurrency(),
            ];
        }

        try {
            /** @var \PDO $db */
            $db = $this->getDb();
            $stmt = $db->prepare(
                "SELECT
                    COUNT(*) AS total_ads,
                    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active_ads,
                    SUM(CASE WHEN status = 'paused' THEN 1 ELSE 0 END) AS paused_ads,
                    SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) AS draft_ads,
                    SUM(CASE WHEN status = 'ended' THEN 1 ELSE 0 END) AS ended_ads,
                    SUM(total_budget) AS total_budget
                 FROM i_user_advertisements
                 WHERE user_id = :uid"
            );
            $stmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
            $stmt->execute();
            $summaryRow = $stmt->fetch(\PDO::FETCH_ASSOC) ?: [];

            $totalBudget = isset($summaryRow['total_budget']) ? (float) $summaryRow['total_budget'] : 0.0;

            $metricsSpent = 0.0;
            $metricsAvailable = false;
            if ($this->RL_EnsureAdMetricsTable()) {
                $metricSpendStmt = $db->prepare(
                    "SELECT SUM(m.spend) AS total_spend
                     FROM i_ad_metrics m
                     INNER JOIN i_user_advertisements a ON a.ad_id = m.ad_id
                     WHERE a.user_id = :uid"
                );
                $metricSpendStmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
                $metricSpendStmt->execute();
                $metricSpendRow = $metricSpendStmt->fetch(\PDO::FETCH_ASSOC) ?: [];
                if (!empty($metricSpendRow) && $metricSpendRow['total_spend'] !== null) {
                    $metricsSpent = (float) $metricSpendRow['total_spend'];
                    $metricsAvailable = true;
                }
            }

            $paymentsSpent = 0.0;
            $currencyCode = '';
            $spendStmt = $db->prepare(
                "SELECT SUM(p.amount) AS total_spent, MAX(p.currency) AS currency
                 FROM i_ad_payments p
                 INNER JOIN i_user_advertisements a ON a.ad_id = COALESCE(p.object_id, p.ad_id)
                 WHERE a.user_id = :uid
                   AND p.payment_type = 'advertisement'
                   AND p.status IN ('succeeded','paid','completed')"
            );
            $spendStmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
            $spendStmt->execute();
            $spendRow = $spendStmt->fetch(\PDO::FETCH_ASSOC) ?: [];
            if (!empty($spendRow)) {
                $paymentsSpent = isset($spendRow['total_spent']) ? (float) $spendRow['total_spent'] : 0.0;
                $currencyCode = (string) ($spendRow['currency'] ?? '');
            }

            $totalSpent = $metricsAvailable ? $metricsSpent : $paymentsSpent;

            if ($currencyCode !== '') {
                $currencyCode = strtoupper($currencyCode);
            } else {
                $currencyCode = $this->RL_DetectSiteCurrency();
            }

            $totalSpent = round($totalSpent, 4);
            $remaining = $totalBudget - $totalSpent;
            if ($remaining < 0) {
                $remaining = 0.0;
            }
            $remaining = round($remaining, 4);

            return [
                'active'          => (int) ($summaryRow['active_ads'] ?? 0),
                'paused'          => (int) ($summaryRow['paused_ads'] ?? 0),
                'draft'           => (int) ($summaryRow['draft_ads'] ?? 0),
                'ended'           => (int) ($summaryRow['ended_ads'] ?? 0),
                'total_budget'    => $totalBudget,
                'total_spent'     => $totalSpent,
                'total_remaining' => $remaining,
                'currency_code'   => $currencyCode,
            ];
        } catch (\Throwable $e) {
            $this->RL_LogAdError('RL_GetAdvertisementFinancials', $e);
            return [
                'active'          => 0,
                'paused'          => 0,
                'draft'           => 0,
                'ended'           => 0,
                'total_budget'    => 0.0,
                'total_spent'     => 0.0,
                'total_remaining' => 0.0,
                'currency_code'   => $this->RL_DetectSiteCurrency(),
            ];
        }
    }

    /**
     * Build time-series data (views and spend) for a given range.
     *
     * @return array{labels:array<int,string>,views:array<int,int>,spend:array<int,float>}
     */
    public function RL_GetAdvertisementTimeSeries(int $userId, string $range): array {
        $userId = max(0, $userId);
        if ($userId <= 0) {
            return ['labels' => [], 'views' => [], 'spend' => []];
        }

        $range = strtolower(trim($range));
        if (!in_array($range, ['daily', 'weekly', 'monthly', 'yearly'], true)) {
            $range = 'daily';
        }

        $this->RL_EnsureAdMetricsTable();

        $now = new \DateTimeImmutable('today');
        $buckets = [];
        $labels = [];
        $startTimestamp = time();
        $startDate = $now;
        $bucketKeys = [];

        $makeRange = static function (\DateTimeImmutable $from, \DateTimeImmutable $to): string {
            if ($from->format('Y-m-d') === $to->format('Y-m-d')) {
                return $from->format('M j');
            }
            return $from->format('M j') . ' - ' . $to->format('M j');
        };

        switch ($range) {
            case 'weekly':
                $count = 12;
                $anchor = $now->modify('monday this week');
                for ($i = $count - 1; $i >= 0; $i--) {
                    $start = $anchor->modify('-' . $i . ' weeks');
                    $end = $start->modify('+6 days');
                    $key = $start->format('o-W');
                    $labels[$key] = $makeRange($start, $end);
                    $buckets[$key] = ['views' => 0, 'clicks' => 0, 'spend' => 0.0];
                    $bucketKeys[] = $key;
                    if ($i === $count - 1) {
                        $startDate = $start;
                    }
                }
                $startTimestamp = $startDate->setTime(0, 0)->getTimestamp();
                break;
            case 'monthly':
                $count = 12;
                $anchor = $now->modify('first day of this month');
                for ($i = $count - 1; $i >= 0; $i--) {
                    $start = $anchor->modify('-' . $i . ' months');
                    $end = $start->modify('last day of this month');
                    $key = $start->format('Y-m');
                    $labels[$key] = $start->format('M Y');
                    $buckets[$key] = ['views' => 0, 'clicks' => 0, 'spend' => 0.0];
                    $bucketKeys[] = $key;
                    if ($i === $count - 1) {
                        $startDate = $start;
                    }
                }
                $startTimestamp = $startDate->setTime(0, 0)->getTimestamp();
                break;
            case 'yearly':
                $count = 5;
                $anchor = $now->modify('first day of january this year');
                for ($i = $count - 1; $i >= 0; $i--) {
                    $start = $anchor->modify('-' . $i . ' years');
                    $key = $start->format('Y');
                    $labels[$key] = $key;
                    $buckets[$key] = ['views' => 0, 'clicks' => 0, 'spend' => 0.0];
                    $bucketKeys[] = $key;
                    if ($i === $count - 1) {
                        $startDate = $start;
                    }
                }
                $startTimestamp = $startDate->setTime(0, 0)->getTimestamp();
                break;
            case 'daily':
            default:
                $count = 14;
                for ($i = $count - 1; $i >= 0; $i--) {
                    $day = $now->modify('-' . $i . ' days');
                    $key = $day->format('Y-m-d');
                    $labels[$key] = $day->format('M j');
                    $buckets[$key] = ['views' => 0, 'clicks' => 0, 'spend' => 0.0];
                    $bucketKeys[] = $key;
                    if ($i === $count - 1) {
                        $startDate = $day;
                    }
                }
                $startTimestamp = $startDate->setTime(0, 0)->getTimestamp();
                break;
        }

        $endDate = $now->format('Y-m-d');
        $startDateStr = $startDate->format('Y-m-d');

        try {
            /** @var \PDO $db */
            $db = $this->getDb();

            $metricsCovered = false;
            if ($this->RL_EnsureAdMetricsTable()) {
                $metricSql = "SELECT m.metric_date, SUM(m.impressions) AS impressions, SUM(m.clicks) AS clicks, SUM(m.spend) AS spend
                              FROM i_ad_metrics m
                              INNER JOIN i_user_advertisements a ON a.ad_id = m.ad_id
                              WHERE a.user_id = :uid AND m.metric_date BETWEEN :start_date AND :end_date
                              GROUP BY m.metric_date";
                $metricStmt = $db->prepare($metricSql);
                $metricStmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
                $metricStmt->bindValue(':start_date', $startDateStr, \PDO::PARAM_STR);
                $metricStmt->bindValue(':end_date', $endDate, \PDO::PARAM_STR);
                $metricStmt->execute();
                $metricRows = $metricStmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];

                foreach ($metricRows as $row) {
                    $dateStr = (string) ($row['metric_date'] ?? '');
                    if ($dateStr === '') {
                        continue;
                    }
                    $date = \DateTimeImmutable::createFromFormat('Y-m-d', $dateStr) ?: null;
                    if (!$date) {
                        continue;
                    }

                    switch ($range) {
                        case 'weekly':
                            $bucketKey = $date->modify('monday this week')->format('o-W');
                            break;
                        case 'monthly':
                            $bucketKey = $date->format('Y-m');
                            break;
                        case 'yearly':
                            $bucketKey = $date->format('Y');
                            break;
                        case 'daily':
                        default:
                            $bucketKey = $date->format('Y-m-d');
                            break;
                    }

                    if (!isset($buckets[$bucketKey])) {
                        continue;
                    }
                    $metricsCovered = true;
                    $buckets[$bucketKey]['views'] += (int) ($row['impressions'] ?? 0);
                    $buckets[$bucketKey]['clicks'] += (int) ($row['clicks'] ?? 0);
                    $buckets[$bucketKey]['spend'] += isset($row['spend']) ? (float) $row['spend'] : 0.0;
                }
            }

            if (!$metricsCovered) {
                switch ($range) {
                    case 'weekly':
                        $groupExpr = "DATE_FORMAT(FROM_UNIXTIME(p.created_at), '%x-%v')";
                        break;
                    case 'monthly':
                        $groupExpr = "DATE_FORMAT(FROM_UNIXTIME(p.created_at), '%Y-%m')";
                        break;
                    case 'yearly':
                        $groupExpr = "DATE_FORMAT(FROM_UNIXTIME(p.created_at), '%Y')";
                        break;
                    case 'daily':
                    default:
                        $groupExpr = "DATE(FROM_UNIXTIME(p.created_at))";
                        break;
                }

                $fallbackSql = "SELECT {$groupExpr} AS bucket_key, SUM(p.amount) AS total_spend
                                 FROM i_ad_payments p
                                 INNER JOIN i_user_advertisements a ON a.ad_id = COALESCE(p.object_id, p.ad_id)
                                 WHERE a.user_id = :uid
                                   AND p.payment_type = 'advertisement'
                                   AND p.status IN ('succeeded','paid','completed')
                                   AND p.created_at >= :start_ts
                                 GROUP BY bucket_key";
                $fallbackStmt = $db->prepare($fallbackSql);
                $fallbackStmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
                $fallbackStmt->bindValue(':start_ts', $startTimestamp, \PDO::PARAM_INT);
                $fallbackStmt->execute();
                $fallbackRows = $fallbackStmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
                foreach ($fallbackRows as $row) {
                    $key = (string) ($row['bucket_key'] ?? '');
                    if ($key === '' || !isset($buckets[$key])) {
                        continue;
                    }
                    $buckets[$key]['spend'] = isset($row['total_spend']) ? (float) $row['total_spend'] : 0.0;
                }
            }
        } catch (\Throwable $e) {
            $this->RL_LogAdError('RL_GetAdvertisementTimeSeries', $e);
            return ['labels' => array_values($labels), 'views' => array_fill(0, count($labels), 0), 'spend' => array_fill(0, count($labels), 0.0)];
        }

        $orderedLabels = [];
        $views = [];
        $spend = [];
        $clicks = [];
        foreach ($bucketKeys as $key) {
            $orderedLabels[] = $labels[$key] ?? $key;
            $views[] = (int) ($buckets[$key]['views'] ?? 0);
            $clicks[] = (int) ($buckets[$key]['clicks'] ?? 0);
            $spend[] = round((float) ($buckets[$key]['spend'] ?? 0.0), 4);
        }

        return [
            'labels' => $orderedLabels,
            'views'  => $views,
            'clicks' => $clicks,
            'spend'  => $spend,
        ];
    }

    /**
     * Summarize total impressions and clicks for a user's advertisements.
     *
     * @return array{impressions:int,clicks:int}
     */
    public function RL_SummarizeAdMetrics(int $userId): array {
        $userId = max(0, $userId);
        if ($userId <= 0) {
            return ['impressions' => 0, 'clicks' => 0];
        }

        if (!$this->RL_EnsureAdMetricsTable()) {
            return ['impressions' => 0, 'clicks' => 0];
        }

        try {
            /** @var \PDO $db */
            $db = $this->getDb();
            $stmt = $db->prepare(
                "SELECT SUM(m.impressions) AS impressions, SUM(m.clicks) AS clicks
                 FROM i_ad_metrics m
                 INNER JOIN i_user_advertisements a ON a.ad_id = m.ad_id
                 WHERE a.user_id = :uid"
            );
            $stmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
            $stmt->execute();
            $row = $stmt->fetch(\PDO::FETCH_ASSOC) ?: [];

            return [
                'impressions' => (int) ($row['impressions'] ?? 0),
                'clicks'      => (int) ($row['clicks'] ?? 0),
            ];
        } catch (\Throwable $e) {
            $this->RL_LogAdError('RL_SummarizeAdMetrics', $e);
            return ['impressions' => 0, 'clicks' => 0];
        }
    }

    /**
     * Record a single advertisement impression and update aggregates.
     */
    public function RL_RecordAdImpression(int $adId, ?int $viewerId = null): bool
    {
        $adId = max(0, $adId);
        if ($adId <= 0) {
            return false;
        }

        if (!$this->RL_EnsureAdMetricsTable()) {
            return false;
        }

        try {
            /** @var \PDO $db */
            $db = $this->getDb();
        } catch (\Throwable $e) {
            return false;
        }

        $today = (new \DateTimeImmutable('today'))->format('Y-m-d');

        try {
            $db->beginTransaction();

            $priceStmt = $db->prepare('SELECT price_per_impression FROM i_user_advertisements WHERE ad_id = :ad LIMIT 1 FOR UPDATE');
            $priceStmt->bindValue(':ad', $adId, \PDO::PARAM_INT);
            $priceStmt->execute();
            $priceRow = $priceStmt->fetch(\PDO::FETCH_ASSOC);
            if (!$priceRow) {
                $db->rollBack();
                return false;
            }
            $pricePer = isset($priceRow['price_per_impression']) ? (float) $priceRow['price_per_impression'] : 0.0;
            $pricePer = round($pricePer, 4);

            $metricStmt = $db->prepare(
                'INSERT INTO i_ad_metrics (ad_id, metric_date, impressions, clicks, spend)
                 VALUES (:ad, :date, 1, 0, :spend)
                 ON DUPLICATE KEY UPDATE impressions = impressions + 1, spend = spend + VALUES(spend)'
            );
            $metricStmt->bindValue(':ad', $adId, \PDO::PARAM_INT);
            $metricStmt->bindValue(':date', $today, \PDO::PARAM_STR);
            $metricStmt->bindValue(':spend', number_format($pricePer, 4, '.', ''), \PDO::PARAM_STR);
            $metricStmt->execute();

            $update = $db->prepare('UPDATE i_user_advertisements SET views = views + 1 WHERE ad_id = :ad LIMIT 1');
            $update->bindValue(':ad', $adId, \PDO::PARAM_INT);
            $update->execute();

            $db->commit();
            return true;
        } catch (\Throwable $e) {
            try { $db->rollBack(); } catch (\Throwable $__) {}
            $this->RL_LogAdError('RL_RecordAdImpression', $e);
            return false;
        }
    }

    /**
     * Record a single click for an advertisement.
     */
    public function RL_RecordAdClick(int $adId, ?int $viewerId = null): bool
    {
        $adId = max(0, $adId);
        if ($adId <= 0) {
            return false;
        }

        if (!$this->RL_EnsureAdMetricsTable()) {
            return false;
        }

        try {
            /** @var \PDO $db */
            $db = $this->getDb();
        } catch (\Throwable $e) {
            return false;
        }

        $today = (new \DateTimeImmutable('today'))->format('Y-m-d');

        try {
            $db->beginTransaction();

            $adCheck = $db->prepare('SELECT ad_id FROM i_user_advertisements WHERE ad_id = :ad LIMIT 1 FOR UPDATE');
            $adCheck->bindValue(':ad', $adId, \PDO::PARAM_INT);
            $adCheck->execute();
            if (!$adCheck->fetchColumn()) {
                $db->rollBack();
                return false;
            }

            $metricStmt = $db->prepare(
                'INSERT INTO i_ad_metrics (ad_id, metric_date, impressions, clicks, spend)
                 VALUES (:ad, :date, 0, 1, 0)
                 ON DUPLICATE KEY UPDATE clicks = clicks + 1'
            );
            $metricStmt->bindValue(':ad', $adId, \PDO::PARAM_INT);
            $metricStmt->bindValue(':date', $today, \PDO::PARAM_STR);
            $metricStmt->execute();

            $update = $db->prepare('UPDATE i_user_advertisements SET clicks = clicks + 1 WHERE ad_id = :ad LIMIT 1');
            $update->bindValue(':ad', $adId, \PDO::PARAM_INT);
            $update->execute();

            $db->commit();
            return true;
        } catch (\Throwable $e) {
            try { $db->rollBack(); } catch (\Throwable $__) {}
            $this->RL_LogAdError('RL_RecordAdClick', $e);
            return false;
        }
    }

    /**
     * Update advertisement title and description for the owner.
     */
    public function RL_UpdateAdvertisementCopy(int $userId, int $adId, string $title, string $description, ?string $adLink = null): bool {
        $userId = max(0, $userId);
        $adId = max(0, $adId);
        if ($userId <= 0 || $adId <= 0) {
            return false;
        }

        if (function_exists('mb_substr')) {
            $title = trim(mb_substr($title, 0, 255));
            $description = trim(mb_substr($description, 0, 1000));
        } else {
            $title = trim(substr($title, 0, 255));
            $description = trim(substr($description, 0, 1000));
        }

        if ($title === '') {
            return false;
        }

        $adLink = $this->RL_NormalizeAdLinkValue($adLink);

        try {
            /** @var \PDO $db */
            $db = $this->getDb();
            $this->RL_EnsureAdLinkColumn();
            $stmt = $db->prepare(
                "UPDATE i_user_advertisements
                 SET title = :title, description = :description, ad_link = :ad_link, updated_at = :updated
                 WHERE ad_id = :ad AND user_id = :uid
                 LIMIT 1"
            );
            $stmt->bindValue(':title', $title, \PDO::PARAM_STR);
            $stmt->bindValue(':description', $description, \PDO::PARAM_STR);
            $stmt->bindValue(':ad_link', $adLink !== '' ? $adLink : null, $adLink !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
            $stmt->bindValue(':updated', time(), \PDO::PARAM_INT);
            $stmt->bindValue(':ad', $adId, \PDO::PARAM_INT);
            $stmt->bindValue(':uid', $userId, \PDO::PARAM_INT);

            return $stmt->execute() && $stmt->rowCount() > 0;
        } catch (\Throwable $e) {
            $this->RL_LogAdError('RL_UpdateAdvertisementCopy', $e);
            return false;
        }
    }

    /**
     * Update advertisement status for the owner with transition safeguards.
     */
    public function RL_UpdateAdvertisementStatusForOwner(int $userId, int $adId, string $status): bool {
        $userId = max(0, $userId);
        $adId = max(0, $adId);
        $status = strtolower(trim($status));

        if ($userId <= 0 || $adId <= 0 || !in_array($status, ['active', 'paused'], true)) {
            return false;
        }

        try {
            /** @var \PDO $db */
            $db = $this->getDb();
            $stmt = $db->prepare('SELECT status FROM i_user_advertisements WHERE ad_id = :ad AND user_id = :uid LIMIT 1');
            $stmt->bindValue(':ad', $adId, \PDO::PARAM_INT);
            $stmt->bindValue(':uid', $userId, \PDO::PARAM_INT);
            $stmt->execute();
            $current = $stmt->fetchColumn();

            if ($current === false) {
                return false;
            }

            $currentStatus = strtolower((string) $current);
            if ($currentStatus === 'ended') {
                return false;
            }

            if ($currentStatus === $status) {
                return true;
            }

            if ($currentStatus === 'draft') {
                if (!$this->RL_UserAdvertisementHasSuccessfulPayment($adId)) {
                    return false;
                }
            }

            $update = $db->prepare('UPDATE i_user_advertisements SET status = :status, updated_at = :updated WHERE ad_id = :ad AND user_id = :uid LIMIT 1');
            $update->bindValue(':status', $status, \PDO::PARAM_STR);
            $update->bindValue(':updated', time(), \PDO::PARAM_INT);
            $update->bindValue(':ad', $adId, \PDO::PARAM_INT);
            $update->bindValue(':uid', $userId, \PDO::PARAM_INT);

            return $update->execute() && $update->rowCount() > 0;
        } catch (\Throwable $e) {
            $this->RL_LogAdError('RL_UpdateAdvertisementStatusForOwner', $e);
            return false;
        }
    }

    /**
     * Helper: determine if advertisement has at least one successful payment.
     */
    private function RL_UserAdvertisementHasSuccessfulPayment(int $adId): bool {
        $adId = max(0, $adId);
        if ($adId <= 0) {
            return false;
        }

        try {
            /** @var \PDO $db */
            $db = $this->getDb();
            $stmt = $db->prepare(
                "SELECT 1 FROM i_ad_payments
                 WHERE payment_type = 'advertisement'
                   AND status IN ('succeeded','paid','completed')
                   AND COALESCE(object_id, ad_id) = :ad
                 LIMIT 1"
            );
            $stmt->bindValue(':ad', $adId, \PDO::PARAM_INT);
            $stmt->execute();
            return (bool) $stmt->fetchColumn();
        } catch (\Throwable $e) {
            $this->RL_LogAdError('RL_UserAdvertisementHasSuccessfulPayment', $e);
            return false;
        }
    }

    /**
     * Determine default site currency.
     */
    private function RL_DetectSiteCurrency(): string {
        $candidate = '';
        if (isset($GLOBALS['currency']) && is_string($GLOBALS['currency']) && $GLOBALS['currency'] !== '') {
            $candidate = (string) $GLOBALS['currency'];
        } elseif (isset($GLOBALS['default_currency']) && is_string($GLOBALS['default_currency']) && $GLOBALS['default_currency'] !== '') {
            $candidate = (string) $GLOBALS['default_currency'];
        }

        $candidate = strtoupper(trim($candidate));
        if ($candidate === '') {
            $candidate = 'USD';
        }
        return $candidate;
    }

    /**
     * Centralised advertisement error logger.
     */
    private function RL_LogAdError(string $context, \Throwable $e): void {
        $message = $context . ' failed: ' . $e->getMessage();
        if (method_exists($this, 'logError')) {
            $this->logError($message);
            return;
        }
        error_log($message);
    }
}
