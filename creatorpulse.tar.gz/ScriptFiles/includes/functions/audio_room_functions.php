<?php
declare(strict_types=1);

trait AudioRoomFunctions
{
    private function ensureAudioRoomTables(): void
    {
        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_audio_rooms (
                room_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                owner_id INT UNSIGNED NOT NULL,
                title VARCHAR(180) NOT NULL,
                description VARCHAR(500) NULL,
                audience ENUM('everyone','followers','following','subscribers','only_me') NOT NULL DEFAULT 'everyone',
                status ENUM('created','live','ended','cancelled') NOT NULL DEFAULT 'created',
                is_paid TINYINT(1) NOT NULL DEFAULT 0,
                entry_price DECIMAL(10,2) NULL,
                currency VARCHAR(10) NULL,
                agora_channel VARCHAR(128) NOT NULL,
                max_speakers INT UNSIGNED NULL,
                max_listeners INT UNSIGNED NULL,
                duration_seconds INT UNSIGNED NULL,
                auto_end_at INT UNSIGNED NULL,
                started_at INT UNSIGNED NULL,
                ended_at INT UNSIGNED NULL,
                end_reason VARCHAR(64) NULL,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NULL,
                PRIMARY KEY (room_id),
                UNIQUE KEY uniq_audio_room_channel (agora_channel),
                KEY idx_audio_room_owner_status (owner_id, status, created_at),
                KEY idx_audio_room_status_created (status, created_at),
                KEY idx_audio_room_audience_status (audience, status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

            $this->db->exec("CREATE TABLE IF NOT EXISTS i_audio_room_participants (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                room_id INT UNSIGNED NOT NULL,
                user_id INT UNSIGNED NULL,
                session_key VARCHAR(64) NOT NULL,
                role ENUM('host','moderator','speaker','listener') NOT NULL DEFAULT 'listener',
                mic_muted TINYINT(1) NOT NULL DEFAULT 1,
                hand_raised TINYINT(1) NOT NULL DEFAULT 0,
                chat_muted_until INT UNSIGNED NULL,
                removed_by INT UNSIGNED NULL,
                moderation_reason VARCHAR(255) NULL,
                status ENUM('joined','left','removed','banned') NOT NULL DEFAULT 'joined',
                joined_at INT UNSIGNED NOT NULL,
                last_seen INT UNSIGNED NOT NULL,
                left_at INT UNSIGNED NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_audio_room_session (room_id, session_key),
                KEY idx_audio_room_participants_room_status (room_id, status, last_seen),
                KEY idx_audio_room_participants_user (user_id, room_id),
                KEY idx_audio_room_participants_role (room_id, role, status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

            $this->ensureAudioRoomColumn('i_audio_rooms', 'duration_seconds', "ALTER TABLE i_audio_rooms ADD COLUMN duration_seconds INT UNSIGNED NULL AFTER max_listeners");
            $this->ensureAudioRoomColumn('i_audio_rooms', 'auto_end_at', "ALTER TABLE i_audio_rooms ADD COLUMN auto_end_at INT UNSIGNED NULL AFTER duration_seconds");
            $this->ensureAudioRoomColumn('i_audio_room_participants', 'chat_muted_until', "ALTER TABLE i_audio_room_participants ADD COLUMN chat_muted_until INT UNSIGNED NULL AFTER hand_raised");
            $this->ensureAudioRoomColumn('i_audio_room_participants', 'removed_by', "ALTER TABLE i_audio_room_participants ADD COLUMN removed_by INT UNSIGNED NULL AFTER chat_muted_until");
            $this->ensureAudioRoomColumn('i_audio_room_participants', 'moderation_reason', "ALTER TABLE i_audio_room_participants ADD COLUMN moderation_reason VARCHAR(255) NULL AFTER removed_by");

            $this->db->exec("CREATE TABLE IF NOT EXISTS i_audio_room_moderators (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                room_id INT UNSIGNED NOT NULL,
                user_id INT UNSIGNED NOT NULL,
                assigned_by INT UNSIGNED NOT NULL,
                created_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_audio_room_moderator (room_id, user_id),
                KEY idx_audio_room_moderators_user (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

            $this->db->exec("CREATE TABLE IF NOT EXISTS i_audio_room_speakers (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                room_id INT UNSIGNED NOT NULL,
                user_id INT UNSIGNED NOT NULL,
                invited_by INT UNSIGNED NULL,
                status ENUM('invited','active','muted','removed','left') NOT NULL DEFAULT 'active',
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_audio_room_speaker (room_id, user_id),
                KEY idx_audio_room_speakers_status (room_id, status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

            $this->db->exec("CREATE TABLE IF NOT EXISTS i_audio_room_speaker_requests (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                room_id INT UNSIGNED NOT NULL,
                user_id INT UNSIGNED NOT NULL,
                status ENUM('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
                requested_at INT UNSIGNED NOT NULL,
                reviewed_at INT UNSIGNED NULL,
                reviewed_by INT UNSIGNED NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_audio_room_speaker_request (room_id, user_id),
                KEY idx_audio_room_speaker_requests_status (room_id, status, requested_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

            $this->db->exec("CREATE TABLE IF NOT EXISTS i_audio_room_messages (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                room_id INT UNSIGNED NOT NULL,
                uid_fk INT UNSIGNED NOT NULL,
                message LONGTEXT NULL,
                message_type ENUM('chat','system','tip') NOT NULL DEFAULT 'chat',
                meta_json LONGTEXT NULL,
                created_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                KEY idx_audio_room_messages_created (room_id, created_at),
                KEY idx_audio_room_messages_id (room_id, id),
                KEY idx_audio_room_messages_user (uid_fk, room_id, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

            $this->db->exec("CREATE TABLE IF NOT EXISTS i_audio_room_tickets (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                room_id INT UNSIGNED NOT NULL,
                buyer_id INT UNSIGNED NOT NULL,
                owner_id INT UNSIGNED NOT NULL,
                provider VARCHAR(32) NOT NULL,
                reference VARCHAR(191) NOT NULL,
                amount DECIMAL(10,2) NULL,
                currency VARCHAR(10) NULL,
                status VARCHAR(32) NOT NULL,
                event VARCHAR(64) NULL,
                fee_amount DECIMAL(10,2) NULL,
                fee_currency VARCHAR(10) NULL,
                tax_amount DECIMAL(10,2) NULL,
                net_amount DECIMAL(10,2) NULL,
                raw_payload MEDIUMTEXT NULL,
                unlocked_at INT UNSIGNED NULL,
                credited_at INT UNSIGNED NULL,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_audio_room_ticket_provider_ref (provider, reference),
                KEY idx_audio_room_ticket_room_buyer (room_id, buyer_id, status),
                KEY idx_audio_room_ticket_owner (owner_id, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

            $this->db->exec("CREATE TABLE IF NOT EXISTS i_audio_room_tip_events (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                room_id INT UNSIGNED NOT NULL,
                buyer_id INT UNSIGNED NULL,
                recipient_id INT UNSIGNED NULL,
                buyer_name VARCHAR(120) NOT NULL,
                provider VARCHAR(32) NULL,
                reference VARCHAR(191) NULL,
                amount DECIMAL(10,2) NOT NULL,
                currency VARCHAR(12) NOT NULL,
                fee_amount DECIMAL(10,2) NULL,
                tax_amount DECIMAL(10,2) NULL,
                net_amount DECIMAL(10,2) NULL,
                status VARCHAR(32) NOT NULL DEFAULT 'succeeded',
                credited_at INT UNSIGNED NULL,
                created_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_audio_room_tip_event_payment (provider, reference),
                KEY idx_audio_room_tip_events_time (room_id, created_at),
                KEY idx_audio_room_tip_events_buyer (buyer_id),
                KEY idx_audio_room_tip_events_recipient (recipient_id, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

            $this->ensureAudioRoomColumn('i_audio_room_tip_events', 'recipient_id', "ALTER TABLE i_audio_room_tip_events ADD COLUMN recipient_id INT UNSIGNED NULL AFTER buyer_id");
            $this->ensureAudioRoomColumn('i_audio_room_tip_events', 'provider', "ALTER TABLE i_audio_room_tip_events ADD COLUMN provider VARCHAR(32) NULL AFTER buyer_name");
            $this->ensureAudioRoomColumn('i_audio_room_tip_events', 'reference', "ALTER TABLE i_audio_room_tip_events ADD COLUMN reference VARCHAR(191) NULL AFTER provider");
            $this->ensureAudioRoomColumn('i_audio_room_tip_events', 'fee_amount', "ALTER TABLE i_audio_room_tip_events ADD COLUMN fee_amount DECIMAL(10,2) NULL AFTER currency");
            $this->ensureAudioRoomColumn('i_audio_room_tip_events', 'tax_amount', "ALTER TABLE i_audio_room_tip_events ADD COLUMN tax_amount DECIMAL(10,2) NULL AFTER fee_amount");
            $this->ensureAudioRoomColumn('i_audio_room_tip_events', 'net_amount', "ALTER TABLE i_audio_room_tip_events ADD COLUMN net_amount DECIMAL(10,2) NULL AFTER tax_amount");
            $this->ensureAudioRoomColumn('i_audio_room_tip_events', 'status', "ALTER TABLE i_audio_room_tip_events ADD COLUMN status VARCHAR(32) NOT NULL DEFAULT 'succeeded' AFTER net_amount");
            $this->ensureAudioRoomColumn('i_audio_room_tip_events', 'credited_at', "ALTER TABLE i_audio_room_tip_events ADD COLUMN credited_at INT UNSIGNED NULL AFTER status");
            $this->ensureAudioRoomIndex('i_audio_room_tip_events', 'uniq_audio_room_tip_event_payment', "ALTER TABLE i_audio_room_tip_events ADD UNIQUE KEY uniq_audio_room_tip_event_payment (provider, reference)");
            $this->ensureAudioRoomIndex('i_audio_room_tip_events', 'idx_audio_room_tip_events_recipient', "ALTER TABLE i_audio_room_tip_events ADD KEY idx_audio_room_tip_events_recipient (recipient_id, created_at)");

            $this->db->exec("CREATE TABLE IF NOT EXISTS i_audio_room_usage_daily (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id INT UNSIGNED NOT NULL,
                usage_date DATE NOT NULL,
                used_seconds INT UNSIGNED NOT NULL DEFAULT 0,
                last_room_id INT UNSIGNED NULL,
                updated_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_audio_room_usage_user_date (user_id, usage_date),
                KEY idx_audio_room_usage_date (usage_date)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

            $this->db->exec("CREATE TABLE IF NOT EXISTS i_audio_room_bans (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                room_id INT UNSIGNED NOT NULL,
                user_id INT UNSIGNED NOT NULL,
                banned_by INT UNSIGNED NOT NULL,
                reason VARCHAR(255) NULL,
                created_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_audio_room_ban (room_id, user_id),
                KEY idx_audio_room_bans_user (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

            $this->db->exec("CREATE TABLE IF NOT EXISTS i_audio_room_moderation_actions (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                room_id INT UNSIGNED NOT NULL,
                user_id INT UNSIGNED NOT NULL,
                actor_id INT UNSIGNED NOT NULL,
                action ENUM('kick','ban','chat_mute','speaker_mute','remove_speaker','unmute_chat') NOT NULL,
                duration_seconds INT UNSIGNED NULL,
                expires_at INT UNSIGNED NULL,
                reason VARCHAR(255) NULL,
                created_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                KEY idx_audio_room_mod_actions_room_user (room_id, user_id, created_at),
                KEY idx_audio_room_mod_actions_expires (room_id, action, expires_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('ensureAudioRoomTables failed: ' . $e->getMessage());
            }
        }
    }

    private function ensureAudioRoomColumn(string $table, string $column, string $alterSql): void
    {
        try {
            $st = $this->db->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table AND COLUMN_NAME = :column");
            $st->execute([':table' => $table, ':column' => $column]);
            if ((int)$st->fetchColumn() === 0) {
                $this->db->exec($alterSql);
            }
        } catch (\Throwable $__) {}
    }

    private function ensureAudioRoomIndex(string $table, string $index, string $alterSql): void
    {
        try {
            $st = $this->db->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
                WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table AND INDEX_NAME = :index");
            $st->execute([':table' => $table, ':index' => $index]);
            if ((int)$st->fetchColumn() === 0) {
                $this->db->exec($alterSql);
            }
        } catch (\Throwable $__) {}
    }

    private function normalizeAudioRoomAudience(string $audience): string
    {
        $audience = strtolower(trim($audience));
        return in_array($audience, ['everyone','followers','following','subscribers','only_me'], true) ? $audience : 'everyone';
    }

    private function normalizeAudioRoomStatus(string $status): string
    {
        $status = strtolower(trim($status));
        return in_array($status, ['created','live','ended','cancelled'], true) ? $status : 'created';
    }

    private function generateAudioRoomChannel(int $ownerId): string
    {
        try {
            $suffix = bin2hex(random_bytes(5));
        } catch (\Throwable $__) {
            $suffix = substr(sha1((string)microtime(true) . ':' . $ownerId), 0, 10);
        }
        return 'audio_' . $ownerId . '_' . time() . '_' . $suffix;
    }

    public function RL_IsApprovedCreator(int $userId): bool
    {
        if ($userId <= 0) { return false; }
        try {
            $st = $this->db->prepare("SELECT creator_status FROM i_users WHERE user_id = :uid LIMIT 1");
            $st->execute([':uid' => $userId]);
            return strtolower((string)($st->fetchColumn() ?: '')) === 'approved';
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_CreateAudioRoom(
        int $ownerId,
        string $title,
        string $description = '',
        string $audience = 'everyone',
        bool $isPaid = false,
        ?float $entryPrice = null,
        ?string $currency = null,
        ?int $maxSpeakers = null,
        ?int $maxListeners = null,
        string $status = 'live',
        ?int $durationSeconds = null
    ): int {
        $this->ensureAudioRoomTables();
        $ownerId = max(0, $ownerId);
        $title = trim(strip_tags($title));
        $description = trim(strip_tags($description));
        if ($ownerId <= 0 || $title === '' || mb_strlen($title) < 3) { return 0; }
        if (mb_strlen($title) > 180) { $title = mb_substr($title, 0, 180); }
        if (mb_strlen($description) > 500) { $description = mb_substr($description, 0, 500); }

        $audience = $this->normalizeAudioRoomAudience($audience);
        $status = $this->normalizeAudioRoomStatus($status);
        $now = time();
        $startedAt = ($status === 'live') ? $now : null;
        $durationSeconds = ($durationSeconds !== null && $durationSeconds > 0) ? min($durationSeconds, 86400) : null;
        $autoEndAt = ($durationSeconds !== null && $startedAt !== null) ? ($startedAt + $durationSeconds) : null;
        $isPaidInt = $isPaid ? 1 : 0;
        $price = $isPaid ? max(0.0, (float)($entryPrice ?? 0.0)) : null;
        $currency = $isPaid ? strtoupper(trim((string)($currency ?: 'USD'))) : null;
        if ($isPaid && ($price === null || $price <= 0 || $currency === '')) { return 0; }
        $channel = $this->generateAudioRoomChannel($ownerId);

        try {
            $st = $this->db->prepare("INSERT INTO i_audio_rooms
                (owner_id, title, description, audience, status, is_paid, entry_price, currency, agora_channel, max_speakers, max_listeners, duration_seconds, auto_end_at, started_at, created_at, updated_at)
                VALUES (:owner, :title, :descr, :aud, :status, :paid, :price, :currency, :channel, :speakers, :listeners, :duration, :auto_end, :started, :created, :updated)");
            $st->bindValue(':owner', $ownerId, \PDO::PARAM_INT);
            $st->bindValue(':title', $title, \PDO::PARAM_STR);
            $st->bindValue(':descr', $description !== '' ? $description : null, $description !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
            $st->bindValue(':aud', $audience, \PDO::PARAM_STR);
            $st->bindValue(':status', $status, \PDO::PARAM_STR);
            $st->bindValue(':paid', $isPaidInt, \PDO::PARAM_INT);
            if ($price === null) { $st->bindValue(':price', null, \PDO::PARAM_NULL); } else { $st->bindValue(':price', $price); }
            $st->bindValue(':currency', $currency, $currency === null ? \PDO::PARAM_NULL : \PDO::PARAM_STR);
            $st->bindValue(':channel', $channel, \PDO::PARAM_STR);
            $st->bindValue(':speakers', $maxSpeakers && $maxSpeakers > 0 ? $maxSpeakers : null, $maxSpeakers && $maxSpeakers > 0 ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $st->bindValue(':listeners', $maxListeners && $maxListeners > 0 ? $maxListeners : null, $maxListeners && $maxListeners > 0 ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $st->bindValue(':duration', $durationSeconds, $durationSeconds === null ? \PDO::PARAM_NULL : \PDO::PARAM_INT);
            $st->bindValue(':auto_end', $autoEndAt, $autoEndAt === null ? \PDO::PARAM_NULL : \PDO::PARAM_INT);
            $st->bindValue(':started', $startedAt, $startedAt === null ? \PDO::PARAM_NULL : \PDO::PARAM_INT);
            $st->bindValue(':created', $now, \PDO::PARAM_INT);
            $st->bindValue(':updated', $now, \PDO::PARAM_INT);
            if (!$st->execute()) { return 0; }
            $roomId = (int)$this->db->lastInsertId();
            if ($roomId > 0) {
                $this->RL_SetAudioRoomSpeaker($roomId, $ownerId, $ownerId, 'active');
            }
            return $roomId;
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) { $this->logError('RL_CreateAudioRoom failed: ' . $e->getMessage()); }
            return 0;
        }
    }

    public function RL_GetAudioRoomById(int $roomId): ?array
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0) { return null; }
        try {
            $st = $this->db->prepare("SELECT r.*, u.username, u.user_fullname, u.user_avatar, u.verified_status, u.creator_status
                FROM i_audio_rooms r
                INNER JOIN i_users u ON u.user_id = r.owner_id
                WHERE r.room_id = :id
                LIMIT 1");
            $st->execute([':id' => $roomId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (\Throwable $__) {
            return null;
        }
    }

    public function RL_UserCanViewAudioRoom(int $viewerId, array $room): bool
    {
        $ownerId = (int)($room['owner_id'] ?? 0);
        if ($ownerId <= 0) { return false; }
        if ($viewerId === $ownerId) { return true; }

        $audience = $this->normalizeAudioRoomAudience((string)($room['audience'] ?? 'everyone'));
        if ($audience === 'everyone') { return true; }
        if ($viewerId <= 0 || $audience === 'only_me') { return false; }
        if ($audience === 'followers') {
            return method_exists($this, 'RL_IsFollowing') && $this->RL_IsFollowing($viewerId, $ownerId);
        }
        if ($audience === 'following') {
            return method_exists($this, 'RL_IsFollowing') && $this->RL_IsFollowing($ownerId, $viewerId);
        }
        if ($audience === 'subscribers') {
            return method_exists($this, 'RL_IsSubscriber') && $this->RL_IsSubscriber($viewerId, $ownerId);
        }
        return false;
    }

    public function RL_UserCanJoinAudioRoom(int $viewerId, int $roomId): array
    {
        $room = $this->RL_GetAudioRoomById($roomId);
        if (!$room) { return ['ok' => false, 'reason' => 'room_not_found']; }
        if ($this->RL_MaybeAutoEndAudioRoom($roomId)) {
            $room = $this->RL_GetAudioRoomById($roomId) ?: $room;
        }
        $status = strtolower((string)($room['status'] ?? ''));
        if ($status === 'ended' || $status === 'cancelled') { return ['ok' => false, 'reason' => 'room_ended', 'room' => $room]; }
        if ($viewerId > 0 && $this->RL_IsAudioRoomBanned($roomId, $viewerId)) {
            return ['ok' => false, 'reason' => 'banned', 'room' => $room];
        }
        if (!$this->RL_UserCanViewAudioRoom($viewerId, $room)) { return ['ok' => false, 'reason' => 'audience_restricted', 'room' => $room]; }

        $ownerId = (int)($room['owner_id'] ?? 0);
        $isPrivileged = $viewerId > 0 && ($viewerId === $ownerId || $this->RL_IsAudioRoomModerator($roomId, $viewerId));
        if ((int)($room['is_paid'] ?? 0) === 1 && !$isPrivileged && !$this->RL_UserHasAudioRoomTicket($roomId, $viewerId)) {
            return ['ok' => false, 'reason' => 'ticket_required', 'room' => $room];
        }

        return ['ok' => true, 'reason' => 'ok', 'room' => $room];
    }

    public function RL_MaybeAutoEndAudioRoom(int $roomId, ?int $now = null): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0) { return false; }
        $now = $now ?? time();
        try {
            $st = $this->db->prepare("UPDATE i_audio_rooms
                SET status = 'ended', ended_at = :ended, end_reason = 'duration_expired', updated_at = :updated
                WHERE room_id = :room AND status = 'live' AND auto_end_at IS NOT NULL AND auto_end_at > 0 AND auto_end_at <= :now");
            $st->execute([':ended' => $now, ':updated' => $now, ':room' => $roomId, ':now' => $now]);
            if ($st->rowCount() > 0) {
                $this->RL_CloseAudioRoomParticipants($roomId, 'left', $now);
                return true;
            }
        } catch (\Throwable $__) {}
        return false;
    }

    public function RL_GetAudioRoomList(int $viewerId = 0, int $limit = 12, int $offset = 0, array $statusFilter = ['live']): array
    {
        $this->ensureAudioRoomTables();
        $limit = max(1, min($limit, 50));
        $offset = max(0, $offset);
        $allowedStatuses = ['created','live','ended','cancelled'];
        $statuses = [];
        foreach ($statusFilter as $status) {
            $status = $this->normalizeAudioRoomStatus((string)$status);
            if (in_array($status, $allowedStatuses, true)) { $statuses[$status] = true; }
        }
        if (!$statuses) { $statuses = ['live' => true]; }
        $statusList = array_keys($statuses);

        try {
            $sql = "SELECT r.*, u.username, u.user_fullname, u.user_avatar, u.verified_status, u.creator_status
                FROM i_audio_rooms r
                INNER JOIN i_users u ON u.user_id = r.owner_id
                WHERE r.status IN (" . implode(',', array_fill(0, count($statusList), '?')) . ")
                ORDER BY (r.status = 'live') DESC, COALESCE(r.started_at, r.created_at) DESC, r.room_id DESC
                LIMIT ? OFFSET ?";
            $st = $this->db->prepare($sql);
            foreach ($statusList as $idx => $status) {
                $st->bindValue($idx + 1, $status, \PDO::PARAM_STR);
            }
            $st->bindValue(count($statusList) + 1, $limit, \PDO::PARAM_INT);
            $st->bindValue(count($statusList) + 2, $offset, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $__) {
            return [];
        }

        $out = [];
        foreach ($rows as $row) {
            if (!$this->RL_UserCanViewAudioRoom($viewerId, $row)) { continue; }
            $roomId = (int)($row['room_id'] ?? 0);
            $row['listener_count'] = $this->RL_CountAudioRoomParticipants($roomId, time() - 30, ['listener']);
            $row['speaker_count'] = $this->RL_CountAudioRoomParticipants($roomId, time() - 30, ['host','moderator','speaker']);
            $row['has_ticket'] = $viewerId > 0 ? $this->RL_UserHasAudioRoomTicket($roomId, $viewerId) : false;
            $out[] = $row;
        }
        return $out;
    }

    public function RL_EndAudioRoom(int $ownerId, int $roomId, string $reason = 'ended'): bool
    {
        $this->ensureAudioRoomTables();
        if ($ownerId <= 0 || $roomId <= 0) { return false; }
        try {
            $now = time();
            $st = $this->db->prepare("UPDATE i_audio_rooms
                SET status = 'ended', ended_at = :ended, end_reason = :reason, updated_at = :updated
                WHERE room_id = :room AND owner_id = :owner AND status <> 'ended'");
            $st->execute([':ended' => $now, ':reason' => mb_substr(trim($reason), 0, 64), ':updated' => $now, ':room' => $roomId, ':owner' => $ownerId]);
            if ($st->rowCount() > 0) {
                $this->RL_CloseAudioRoomParticipants($roomId, 'left', $now);
                return true;
            }
            return false;
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_EndAudioRoomAsManager(int $actorId, int $roomId, string $reason = 'ended'): bool
    {
        $this->ensureAudioRoomTables();
        if ($actorId <= 0 || $roomId <= 0) { return false; }
        $room = $this->RL_GetAudioRoomById($roomId);
        if (!$room) { return false; }
        $ownerId = (int)($room['owner_id'] ?? 0);
        if ($actorId !== $ownerId && !$this->RL_IsAudioRoomModerator($roomId, $actorId)) { return false; }
        try {
            $now = time();
            $st = $this->db->prepare("UPDATE i_audio_rooms
                SET status = 'ended', ended_at = :ended, end_reason = :reason, updated_at = :updated
                WHERE room_id = :room AND status <> 'ended'");
            $st->execute([':ended' => $now, ':reason' => mb_substr(trim($reason), 0, 64), ':updated' => $now, ':room' => $roomId]);
            if ($st->rowCount() > 0) {
                $this->RL_LogAudioRoomModerationAction($roomId, $ownerId, $actorId, 'kick', null, null, 'room_ended');
                $this->RL_InsertAudioRoomMessage($roomId, $actorId, 'Room ended.', 'system', ['event' => 'room_ended', 'actor_id' => $actorId]);
                $this->RL_CloseAudioRoomParticipants($roomId, 'left', $now);
                return true;
            }
            return strtolower((string)($room['status'] ?? '')) === 'ended';
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_CloseAudioRoomParticipants(int $roomId, string $status = 'left', ?int $now = null): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0) { return false; }
        $status = in_array($status, ['left','removed','banned'], true) ? $status : 'left';
        $now = $now ?? time();
        try {
            $st = $this->db->prepare("UPDATE i_audio_room_participants
                SET status = :status, left_at = COALESCE(left_at, :left_at), last_seen = :seen
                WHERE room_id = :room AND status = 'joined'");
            $st->execute([':status' => $status, ':left_at' => $now, ':seen' => $now, ':room' => $roomId]);
            return true;
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_UpsertAudioRoomParticipant(int $roomId, string $sessionKey, int $userId, string $role = 'listener', bool $micMuted = true, bool $handRaised = false, ?int $now = null): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || trim($sessionKey) === '') { return false; }
        $role = in_array($role, ['host','moderator','speaker','listener'], true) ? $role : 'listener';
        $now = $now ?? time();
        try {
            $st = $this->db->prepare("INSERT INTO i_audio_room_participants
                (room_id, user_id, session_key, role, mic_muted, hand_raised, status, joined_at, last_seen)
                VALUES (:room, :user, :session, :role, :muted, :hand, 'joined', :joined, :seen)
                ON DUPLICATE KEY UPDATE
                    user_id = VALUES(user_id),
                    role = VALUES(role),
                    mic_muted = VALUES(mic_muted),
                    hand_raised = VALUES(hand_raised),
                    status = 'joined',
                    last_seen = VALUES(last_seen),
                    left_at = NULL");
            return $st->execute([
                ':room' => $roomId,
                ':user' => $userId > 0 ? $userId : null,
                ':session' => $sessionKey,
                ':role' => $role,
                ':muted' => $micMuted ? 1 : 0,
                ':hand' => $handRaised ? 1 : 0,
                ':joined' => $now,
                ':seen' => $now,
            ]);
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_LeaveAudioRoomParticipant(int $roomId, string $sessionKey, ?int $now = null): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || trim($sessionKey) === '') { return false; }
        $now = $now ?? time();
        try {
            $st = $this->db->prepare("UPDATE i_audio_room_participants SET status = 'left', left_at = :left_at, last_seen = :seen WHERE room_id = :room AND session_key = :session");
            $st->execute([':left_at' => $now, ':seen' => $now, ':room' => $roomId, ':session' => $sessionKey]);
            return $st->rowCount() > 0;
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_TouchAudioRoomParticipant(int $roomId, string $sessionKey, int $userId, string $role = 'listener', ?int $now = null): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || trim($sessionKey) === '') { return false; }
        $role = in_array($role, ['host','moderator','speaker','listener'], true) ? $role : 'listener';
        $now = $now ?? time();
        try {
            $st = $this->db->prepare("INSERT INTO i_audio_room_participants
                (room_id, user_id, session_key, role, mic_muted, hand_raised, status, joined_at, last_seen)
                VALUES (:room, :user, :session, :role, 1, 0, 'joined', :joined, :seen)
                ON DUPLICATE KEY UPDATE
                    user_id = VALUES(user_id),
                    role = VALUES(role),
                    status = 'joined',
                    last_seen = VALUES(last_seen),
                    left_at = NULL");
            return $st->execute([
                ':room' => $roomId,
                ':user' => $userId > 0 ? $userId : null,
                ':session' => $sessionKey,
                ':role' => $role,
                ':joined' => $now,
                ':seen' => $now,
            ]);
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_UpdateAudioRoomParticipantMic(int $roomId, string $sessionKey, int $userId, bool $muted): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || trim($sessionKey) === '' || $userId <= 0) { return false; }
        try {
            $st = $this->db->prepare("UPDATE i_audio_room_participants
                SET mic_muted = :muted, last_seen = :seen
                WHERE room_id = :room AND session_key = :session AND user_id = :user AND status = 'joined'");
            $st->execute([
                ':muted' => $muted ? 1 : 0,
                ':seen' => time(),
                ':room' => $roomId,
                ':session' => $sessionKey,
                ':user' => $userId,
            ]);
            if ($st->rowCount() > 0) {
                return true;
            }

            $fallback = $this->db->prepare("UPDATE i_audio_room_participants
                SET mic_muted = :muted, last_seen = :seen
                WHERE room_id = :room AND user_id = :user AND status = 'joined'
                ORDER BY last_seen DESC
                LIMIT 1");
            $fallback->execute([
                ':muted' => $muted ? 1 : 0,
                ':seen' => time(),
                ':room' => $roomId,
                ':user' => $userId,
            ]);
            if ($fallback->rowCount() > 0) {
                return true;
            }

            $check = $this->db->prepare("SELECT COUNT(*) FROM i_audio_room_participants
                WHERE room_id = :room AND user_id = :user AND status = 'joined' AND mic_muted = :muted");
            $check->execute([
                ':room' => $roomId,
                ':user' => $userId,
                ':muted' => $muted ? 1 : 0,
            ]);
            return ((int)$check->fetchColumn()) > 0;
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_CountAudioRoomParticipants(int $roomId, int $sinceTs, array $roles = []): int
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0) { return 0; }
        $roles = array_values(array_intersect($roles, ['host','moderator','speaker','listener']));
        try {
            $params = [':room' => $roomId, ':since' => $sinceTs];
            $sql = "SELECT COUNT(*) FROM i_audio_room_participants WHERE room_id = :room AND status = 'joined' AND last_seen > :since";
            if ($roles) {
                $keys = [];
                foreach ($roles as $idx => $role) {
                    $key = ':role' . $idx;
                    $keys[] = $key;
                    $params[$key] = $role;
                }
                $sql .= " AND role IN (" . implode(',', $keys) . ")";
            }
            $st = $this->db->prepare($sql);
            $st->execute($params);
            return (int)$st->fetchColumn();
        } catch (\Throwable $__) {
            return 0;
        }
    }

    public function RL_IsAudioRoomModerator(int $roomId, int $userId): bool
    {
        if ($roomId <= 0 || $userId <= 0) { return false; }
        $this->ensureAudioRoomTables();
        try {
            $st = $this->db->prepare("SELECT 1 FROM i_audio_room_moderators WHERE room_id = :room AND user_id = :user LIMIT 1");
            $st->execute([':room' => $roomId, ':user' => $userId]);
            return (bool)$st->fetchColumn();
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_AssignAudioRoomModerator(int $roomId, int $userId, int $assignedBy): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || $userId <= 0 || $assignedBy <= 0) { return false; }
        try {
            $st = $this->db->prepare("INSERT INTO i_audio_room_moderators (room_id, user_id, assigned_by, created_at)
                VALUES (:room, :user, :by, :created)
                ON DUPLICATE KEY UPDATE assigned_by = VALUES(assigned_by)");
            return $st->execute([':room' => $roomId, ':user' => $userId, ':by' => $assignedBy, ':created' => time()]);
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_LogAudioRoomModerationAction(int $roomId, int $userId, int $actorId, string $action, ?int $durationSeconds = null, ?int $expiresAt = null, ?string $reason = null): bool
    {
        $this->ensureAudioRoomTables();
        $allowed = ['kick','ban','chat_mute','speaker_mute','remove_speaker','unmute_chat'];
        if ($roomId <= 0 || $userId <= 0 || $actorId <= 0 || !in_array($action, $allowed, true)) { return false; }
        try {
            $st = $this->db->prepare("INSERT INTO i_audio_room_moderation_actions
                (room_id, user_id, actor_id, action, duration_seconds, expires_at, reason, created_at)
                VALUES (:room, :user, :actor, :action, :duration, :expires, :reason, :created)");
            return $st->execute([
                ':room' => $roomId,
                ':user' => $userId,
                ':actor' => $actorId,
                ':action' => $action,
                ':duration' => $durationSeconds,
                ':expires' => $expiresAt,
                ':reason' => $reason ? mb_substr(trim($reason), 0, 255) : null,
                ':created' => time(),
            ]);
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_IsAudioRoomBanned(int $roomId, int $userId): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || $userId <= 0) { return false; }
        try {
            $st = $this->db->prepare("SELECT 1 FROM i_audio_room_bans WHERE room_id = :room AND user_id = :user LIMIT 1");
            $st->execute([':room' => $roomId, ':user' => $userId]);
            return (bool)$st->fetchColumn();
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_GetAudioRoomParticipantState(int $roomId, int $userId): array
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || $userId <= 0) { return []; }
        try {
            $st = $this->db->prepare("SELECT *
                FROM i_audio_room_participants
                WHERE room_id = :room AND user_id = :user
                ORDER BY last_seen DESC
                LIMIT 1");
            $st->execute([':room' => $roomId, ':user' => $userId]);
            return $st->fetch(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $__) {
            return [];
        }
    }

    public function RL_GetAudioRoomChatMuteRemaining(int $roomId, int $userId, ?int $now = null): int
    {
        $state = $this->RL_GetAudioRoomParticipantState($roomId, $userId);
        $until = (int)($state['chat_muted_until'] ?? 0);
        $now = $now ?? time();
        return $until > $now ? ($until - $now) : 0;
    }

    public function RL_SetAudioRoomChatMute(int $roomId, int $userId, int $actorId, int $minutes, ?string $reason = null): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || $userId <= 0 || $actorId <= 0) { return false; }
        $minutes = max(1, min(5, $minutes));
        $now = time();
        $expiresAt = $now + ($minutes * 60);
        try {
            $st = $this->db->prepare("UPDATE i_audio_room_participants
                SET chat_muted_until = :expires, mic_muted = 1, hand_raised = 0, removed_by = :actor,
                    moderation_reason = :reason, last_seen = :seen
                WHERE room_id = :room AND user_id = :user AND status = 'joined'");
            $st->execute([
                ':expires' => $expiresAt,
                ':actor' => $actorId,
                ':reason' => $reason ? mb_substr(trim($reason), 0, 255) : null,
                ':seen' => $now,
                ':room' => $roomId,
                ':user' => $userId,
            ]);
            $this->RL_SetAudioRoomSpeaker($roomId, $userId, $actorId, 'removed');
            $this->RL_LogAudioRoomModerationAction($roomId, $userId, $actorId, 'chat_mute', $minutes * 60, $expiresAt, $reason);
            return true;
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_ClearAudioRoomChatMute(int $roomId, int $userId, int $actorId): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || $userId <= 0 || $actorId <= 0) { return false; }
        try {
            $st = $this->db->prepare("UPDATE i_audio_room_participants
                SET chat_muted_until = NULL, moderation_reason = NULL, last_seen = :seen
                WHERE room_id = :room AND user_id = :user");
            $st->execute([':seen' => time(), ':room' => $roomId, ':user' => $userId]);
            $this->RL_LogAudioRoomModerationAction($roomId, $userId, $actorId, 'unmute_chat');
            return true;
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_KickAudioRoomParticipant(int $roomId, int $userId, int $actorId, bool $ban = false, ?string $reason = null): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || $userId <= 0 || $actorId <= 0) { return false; }
        $now = time();
        try {
            if ($ban) {
                $stBan = $this->db->prepare("INSERT INTO i_audio_room_bans (room_id, user_id, banned_by, reason, created_at)
                    VALUES (:room, :user, :by, :reason, :created)
                    ON DUPLICATE KEY UPDATE banned_by = VALUES(banned_by), reason = VALUES(reason), created_at = VALUES(created_at)");
                $stBan->execute([
                    ':room' => $roomId,
                    ':user' => $userId,
                    ':by' => $actorId,
                    ':reason' => $reason ? mb_substr(trim($reason), 0, 255) : null,
                    ':created' => $now,
                ]);
            }

            $st = $this->db->prepare("UPDATE i_audio_room_participants
                SET status = :status, mic_muted = 1, hand_raised = 0, removed_by = :actor,
                    moderation_reason = :reason, left_at = :left_at, last_seen = :seen
                WHERE room_id = :room AND user_id = :user AND status = 'joined'");
            $st->execute([
                ':status' => $ban ? 'banned' : 'removed',
                ':actor' => $actorId,
                ':reason' => $reason ? mb_substr(trim($reason), 0, 255) : null,
                ':left_at' => $now,
                ':seen' => $now,
                ':room' => $roomId,
                ':user' => $userId,
            ]);
            $this->RL_SetAudioRoomSpeaker($roomId, $userId, $actorId, $ban ? 'removed' : 'left');
            $this->RL_LogAudioRoomModerationAction($roomId, $userId, $actorId, $ban ? 'ban' : 'kick', null, null, $reason);
            return true;
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_GetAudioRoomParticipants(int $roomId, int $sinceTs, int $limit = 80): array
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0) { return []; }
        $limit = max(1, min($limit, 150));
        try {
            $st = $this->db->prepare("SELECT p.*, u.username, u.user_fullname, u.user_avatar, u.verified_status
                FROM i_audio_room_participants p
                LEFT JOIN i_users u ON u.user_id = p.user_id
                WHERE p.room_id = :room AND p.status = 'joined' AND p.last_seen > :since
                ORDER BY FIELD(p.role, 'host','moderator','speaker','listener'), p.last_seen DESC
                LIMIT :limit");
            $st->bindValue(':room', $roomId, \PDO::PARAM_INT);
            $st->bindValue(':since', $sinceTs, \PDO::PARAM_INT);
            $st->bindValue(':limit', $limit, \PDO::PARAM_INT);
            $st->execute();
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $__) {
            return [];
        }
    }

    public function RL_GetAudioRoomSpeakerRequests(int $roomId, string $status = 'pending', int $limit = 50): array
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0) { return []; }
        $status = strtolower(trim($status));
        if (!in_array($status, ['pending','approved','rejected','cancelled'], true)) { $status = 'pending'; }
        $limit = max(1, min($limit, 100));
        try {
            $st = $this->db->prepare("SELECT r.*, u.username, u.user_fullname, u.user_avatar, u.verified_status
                FROM i_audio_room_speaker_requests r
                INNER JOIN i_users u ON u.user_id = r.user_id
                WHERE r.room_id = :room AND r.status = :status
                ORDER BY r.requested_at ASC
                LIMIT :limit");
            $st->bindValue(':room', $roomId, \PDO::PARAM_INT);
            $st->bindValue(':status', $status, \PDO::PARAM_STR);
            $st->bindValue(':limit', $limit, \PDO::PARAM_INT);
            $st->execute();
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $__) {
            return [];
        }
    }

    public function RL_SetAudioRoomSpeaker(int $roomId, int $userId, ?int $invitedBy = null, string $status = 'active'): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || $userId <= 0) { return false; }
        $status = in_array($status, ['invited','active','muted','removed','left'], true) ? $status : 'active';
        $now = time();
        try {
            $st = $this->db->prepare("INSERT INTO i_audio_room_speakers (room_id, user_id, invited_by, status, created_at, updated_at)
                VALUES (:room, :user, :by, :status, :created, :updated)
                ON DUPLICATE KEY UPDATE invited_by = COALESCE(VALUES(invited_by), invited_by), status = VALUES(status), updated_at = VALUES(updated_at)");
            return $st->execute([':room' => $roomId, ':user' => $userId, ':by' => $invitedBy, ':status' => $status, ':created' => $now, ':updated' => $now]);
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_IsAudioRoomSpeaker(int $roomId, int $userId): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || $userId <= 0) { return false; }
        try {
            $st = $this->db->prepare("SELECT 1 FROM i_audio_room_speakers WHERE room_id = :room AND user_id = :user AND status IN ('invited','active','muted') LIMIT 1");
            $st->execute([':room' => $roomId, ':user' => $userId]);
            return (bool)$st->fetchColumn();
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_GetAudioRoomSpeakerStatus(int $roomId, int $userId): string
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || $userId <= 0) { return ''; }
        try {
            $st = $this->db->prepare("SELECT status FROM i_audio_room_speakers WHERE room_id = :room AND user_id = :user LIMIT 1");
            $st->execute([':room' => $roomId, ':user' => $userId]);
            return (string)($st->fetchColumn() ?: '');
        } catch (\Throwable $__) {
            return '';
        }
    }

    public function RL_SetAudioRoomSpeakerMuteState(int $roomId, int $userId, int $mutedBy, bool $muted): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || $userId <= 0 || $mutedBy <= 0) { return false; }
        try {
            $status = $muted ? 'removed' : 'active';
            $this->RL_SetAudioRoomSpeaker($roomId, $userId, $mutedBy, $status);
            if ($muted) {
                $st = $this->db->prepare("UPDATE i_audio_room_participants
                    SET role = 'listener', mic_muted = 1, hand_raised = 0, last_seen = :seen
                    WHERE room_id = :room AND user_id = :user AND status = 'joined'");
                $st->execute([':seen' => time(), ':room' => $roomId, ':user' => $userId]);
                $this->RL_LogAudioRoomModerationAction($roomId, $userId, $mutedBy, 'speaker_mute');
            }
            return true;
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_RequestAudioRoomSpeaker(int $roomId, int $userId): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || $userId <= 0) { return false; }
        try {
            $st = $this->db->prepare("INSERT INTO i_audio_room_speaker_requests (room_id, user_id, status, requested_at)
                VALUES (:room, :user, 'pending', :requested)
                ON DUPLICATE KEY UPDATE status = 'pending', requested_at = VALUES(requested_at), reviewed_at = NULL, reviewed_by = NULL");
            return $st->execute([':room' => $roomId, ':user' => $userId, ':requested' => time()]);
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_ReviewAudioRoomSpeakerRequest(int $roomId, int $userId, int $reviewedBy, string $decision): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || $userId <= 0 || $reviewedBy <= 0) { return false; }
        $decision = strtolower(trim($decision));
        if (!in_array($decision, ['approved','rejected','cancelled'], true)) { return false; }
        try {
            $now = time();
            $st = $this->db->prepare("UPDATE i_audio_room_speaker_requests
                SET status = :status, reviewed_at = :reviewed, reviewed_by = :by
                WHERE room_id = :room AND user_id = :user");
            $st->execute([':status' => $decision, ':reviewed' => $now, ':by' => $reviewedBy, ':room' => $roomId, ':user' => $userId]);
            if ($decision === 'approved') {
                $this->RL_SetAudioRoomSpeaker($roomId, $userId, $reviewedBy, 'active');
            }
            return true;
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_UserHasAudioRoomTicket(int $roomId, int $buyerId): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || $buyerId <= 0) { return false; }
        try {
            $st = $this->db->prepare("SELECT 1 FROM i_audio_room_tickets
                WHERE room_id = :room AND buyer_id = :buyer AND status = 'succeeded' AND unlocked_at IS NOT NULL
                LIMIT 1");
            $st->execute([':room' => $roomId, ':buyer' => $buyerId]);
            return (bool)$st->fetchColumn();
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_RecordAudioRoomTicket(int $roomId, int $buyerId, int $ownerId, string $provider, string $reference, ?float $amount, ?string $currency, string $status, ?string $event = null, array $rawPayload = []): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || $buyerId <= 0 || $ownerId <= 0 || trim($provider) === '' || trim($reference) === '') { return false; }
        $now = time();
        $payload = $rawPayload ? json_encode($rawPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
        try {
            $st = $this->db->prepare("INSERT INTO i_audio_room_tickets
                (room_id, buyer_id, owner_id, provider, reference, amount, currency, status, event, raw_payload, unlocked_at, created_at, updated_at)
                VALUES (:room, :buyer, :owner, :provider, :ref, :amount, :currency, :status, :event, :payload, :unlocked, :created, :updated)
                ON DUPLICATE KEY UPDATE
                    status = VALUES(status),
                    event = VALUES(event),
                    raw_payload = VALUES(raw_payload),
                    unlocked_at = COALESCE(i_audio_room_tickets.unlocked_at, VALUES(unlocked_at)),
                    updated_at = VALUES(updated_at)");
            return $st->execute([
                ':room' => $roomId,
                ':buyer' => $buyerId,
                ':owner' => $ownerId,
                ':provider' => strtolower(trim($provider)),
                ':ref' => trim($reference),
                ':amount' => $amount,
                ':currency' => $currency ? strtoupper($currency) : null,
                ':status' => strtolower(trim($status)),
                ':event' => $event,
                ':payload' => $payload,
                ':unlocked' => strtolower(trim($status)) === 'succeeded' ? $now : null,
                ':created' => $now,
                ':updated' => $now,
            ]);
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) { $this->logError('RL_RecordAudioRoomTicket failed: ' . $e->getMessage()); }
            return false;
        }
    }

    public function RL_UpdateAudioRoomTicketAmountsByReference(string $provider, string $reference, ?float $gross, ?string $currency, ?float $fee, ?string $feeCurrency, ?float $tax, ?float $net): bool
    {
        $this->ensureAudioRoomTables();
        try {
            $st = $this->db->prepare("UPDATE i_audio_room_tickets
                SET amount = COALESCE(:gross, amount),
                    currency = COALESCE(:currency, currency),
                    fee_amount = COALESCE(:fee, fee_amount),
                    fee_currency = COALESCE(:fee_currency, fee_currency),
                    tax_amount = COALESCE(:tax, tax_amount),
                    net_amount = COALESCE(:net, net_amount),
                    updated_at = :updated
                WHERE provider = :provider AND reference = :ref");
            $st->execute([
                ':gross' => $gross,
                ':currency' => $currency ? strtoupper($currency) : null,
                ':fee' => $fee,
                ':fee_currency' => $feeCurrency ? strtoupper($feeCurrency) : null,
                ':tax' => $tax,
                ':net' => $net,
                ':updated' => time(),
                ':provider' => strtolower(trim($provider)),
                ':ref' => trim($reference),
            ]);
            return $st->rowCount() > 0;
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_UpdateAudioRoomTicketStatusByReference(string $provider, string $reference, string $status, ?string $event = null, array $rawPayload = []): bool
    {
        $this->ensureAudioRoomTables();
        try {
            $payload = $rawPayload ? json_encode($rawPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
            $status = strtolower(trim($status));
            $now = time();
            $st = $this->db->prepare("UPDATE i_audio_room_tickets
                SET status = :status,
                    event = :event,
                    raw_payload = COALESCE(:payload, raw_payload),
                    unlocked_at = CASE WHEN :status_success = 1 THEN COALESCE(unlocked_at, :unlocked) ELSE unlocked_at END,
                    updated_at = :updated
                WHERE provider = :provider AND reference = :ref");
            $st->execute([
                ':status' => $status,
                ':event' => $event,
                ':payload' => $payload,
                ':status_success' => $status === 'succeeded' ? 1 : 0,
                ':unlocked' => $now,
                ':updated' => $now,
                ':provider' => strtolower(trim($provider)),
                ':ref' => trim($reference),
            ]);
            $updated = $st->rowCount() > 0;
            if ($updated && $status === 'succeeded') {
                $this->RL_CreateAudioRoomTicketInvoiceByReference($provider, $reference);
            }
            return $updated;
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_CreditRecipientForAudioRoomTicketByReference(string $provider, string $reference): bool
    {
        $this->ensureAudioRoomTables();
        $db = $this->db;
        try {
            $db->beginTransaction();
            $st = $db->prepare("SELECT * FROM i_audio_room_tickets WHERE provider = :provider AND reference = :ref FOR UPDATE");
            $st->execute([':provider' => strtolower(trim($provider)), ':ref' => trim($reference)]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) { $db->rollBack(); return false; }
            if ((int)($row['credited_at'] ?? 0) > 0) { $db->commit(); return true; }
            if ((int)($row['unlocked_at'] ?? 0) <= 0 || (string)($row['status'] ?? '') !== 'succeeded') { $db->rollBack(); return false; }
            $recipientId = (int)($row['owner_id'] ?? 0);
            $amount = isset($row['net_amount']) && $row['net_amount'] !== null ? (float)$row['net_amount'] : (float)($row['amount'] ?? 0);
            if ($recipientId <= 0 || $amount <= 0) { $db->rollBack(); return false; }
            $db->prepare("UPDATE i_users SET earned = COALESCE(earned,0) + :amount WHERE user_id = :uid")->execute([':amount' => $amount, ':uid' => $recipientId]);
            $db->prepare("UPDATE i_audio_room_tickets SET credited_at = :credited WHERE provider = :provider AND reference = :ref")
                ->execute([':credited' => time(), ':provider' => strtolower(trim($provider)), ':ref' => trim($reference)]);
            $db->commit();
            return true;
        } catch (\Throwable $__) {
            try { if ($db->inTransaction()) { $db->rollBack(); } } catch (\Throwable $___) {}
            return false;
        }
    }

    public function RL_TransferWalletForAudioRoomTicket(int $buyerId, int $roomId, float $grossAmount, float $netAmount, float $feeAmount, float $taxAmount, string $currency, ?string $reference = null): array
    {
        $this->ensureAudioRoomTables();
        $room = $this->RL_GetAudioRoomById($roomId);
        if (!$room) { return ['ok' => false, 'error' => 'Room not found']; }
        $ownerId = (int)($room['owner_id'] ?? 0);
        if ($buyerId <= 0 || $ownerId <= 0 || $buyerId === $ownerId || $grossAmount <= 0 || $netAmount <= 0) {
            return ['ok' => false, 'error' => 'Invalid ticket payment'];
        }
        if (!$reference) {
            try {
                $reference = 'ART' . strtoupper(bin2hex(random_bytes(8)));
            } catch (\Throwable $__) {
                $reference = 'ART' . strtoupper(substr(sha1((string)microtime(true) . ':' . $buyerId . ':' . $roomId), 0, 16));
            }
        }
        $db = $this->db;
        try {
            $db->beginTransaction();
            $st = $db->prepare("SELECT wallet FROM i_users WHERE user_id = :uid FOR UPDATE");
            $st->execute([':uid' => $buyerId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) { $db->rollBack(); return ['ok' => false, 'error' => 'Buyer not found']; }
            $balance = (float)($row['wallet'] ?? 0);
            if ($balance < $grossAmount) {
                $db->rollBack();
                return ['ok' => false, 'error' => 'Insufficient wallet balance', 'balance' => $balance, 'required' => $grossAmount];
            }

            $newBalance = number_format($balance - $grossAmount, 2, '.', '');
            $db->prepare("UPDATE i_users SET wallet = :wallet WHERE user_id = :uid")->execute([':wallet' => $newBalance, ':uid' => $buyerId]);
            $db->prepare("UPDATE i_users SET earned = COALESCE(earned,0) + :amount WHERE user_id = :uid")->execute([':amount' => $netAmount, ':uid' => $ownerId]);
            $db->commit();

            $this->RL_RecordAudioRoomTicket($roomId, $buyerId, $ownerId, 'wallet', $reference, $grossAmount, $currency, 'succeeded', 'wallet_debited', ['source' => 'wallet']);
            $this->RL_UpdateAudioRoomTicketAmountsByReference('wallet', $reference, $grossAmount, $currency, $feeAmount, $currency, $taxAmount, $netAmount);
            try {
                $this->db->prepare("UPDATE i_audio_room_tickets SET credited_at = COALESCE(credited_at, unlocked_at, :credited) WHERE provider = 'wallet' AND reference = :ref")
                    ->execute([':credited' => time(), ':ref' => $reference]);
            } catch (\Throwable $__) {}
            $this->RL_CreateAudioRoomTicketInvoiceByReference('wallet', $reference);

            return ['ok' => true, 'reference' => $reference, 'new_balance' => (float)$newBalance];
        } catch (\Throwable $e) {
            try { if ($db->inTransaction()) { $db->rollBack(); } } catch (\Throwable $__) {}
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    public function RL_GetAudioRoomUsageSeconds(int $userId, ?string $date = null): int
    {
        $this->ensureAudioRoomTables();
        if ($userId <= 0) { return 0; }
        $date = $date ?: date('Y-m-d');
        try {
            $st = $this->db->prepare("SELECT used_seconds FROM i_audio_room_usage_daily WHERE user_id = :uid AND usage_date = :day LIMIT 1");
            $st->execute([':uid' => $userId, ':day' => $date]);
            return (int)($st->fetchColumn() ?: 0);
        } catch (\Throwable $__) {
            return 0;
        }
    }

    public function RL_AddAudioRoomUsageSeconds(int $userId, int $seconds, ?int $roomId = null, ?string $date = null): bool
    {
        $this->ensureAudioRoomTables();
        if ($userId <= 0 || $seconds <= 0) { return false; }
        $date = $date ?: date('Y-m-d');
        try {
            $st = $this->db->prepare("INSERT INTO i_audio_room_usage_daily (user_id, usage_date, used_seconds, last_room_id, updated_at)
                VALUES (:uid, :day, :seconds, :room, :updated)
                ON DUPLICATE KEY UPDATE used_seconds = used_seconds + VALUES(used_seconds), last_room_id = VALUES(last_room_id), updated_at = VALUES(updated_at)");
            return $st->execute([':uid' => $userId, ':day' => $date, ':seconds' => $seconds, ':room' => $roomId, ':updated' => time()]);
        } catch (\Throwable $__) {
            return false;
        }
    }

    public function RL_GetAudioRoomRemainingSecondsForUser(int $userId, int $dailyMinutes, ?string $date = null): ?int
    {
        if ($userId <= 0 || $dailyMinutes <= 0 || $this->RL_IsApprovedCreator($userId)) { return null; }
        $limit = $dailyMinutes * 60;
        $used = $this->RL_GetAudioRoomUsageSeconds($userId, $date);
        return max(0, $limit - $used);
    }

    public function RL_InsertAudioRoomMessage(int $roomId, int $userId, string $message, string $type = 'chat', array $meta = []): int
    {
        $this->ensureAudioRoomTables();
        $message = trim($message);
        $type = in_array($type, ['chat','system','tip'], true) ? $type : 'chat';
        if ($roomId <= 0 || $userId <= 0 || ($message === '' && !$meta)) { return 0; }
        $metaJson = $meta ? json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
        try {
            $st = $this->db->prepare("INSERT INTO i_audio_room_messages (room_id, uid_fk, message, message_type, meta_json, created_at)
                VALUES (:room, :user, :message, :type, :meta, :created)");
            $st->execute([':room' => $roomId, ':user' => $userId, ':message' => $message, ':type' => $type, ':meta' => $metaJson, ':created' => time()]);
            return (int)$this->db->lastInsertId();
        } catch (\Throwable $__) {
            return 0;
        }
    }

    public function RL_GetAudioRoomMessagesSince(int $roomId, int $afterId = 0, int $limit = 50): array
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0) { return []; }
        $limit = max(1, min($limit, 100));
        try {
            $st = $this->db->prepare("SELECT m.*, u.username, u.user_fullname, u.user_avatar
                FROM i_audio_room_messages m
                INNER JOIN i_users u ON u.user_id = m.uid_fk
                WHERE m.room_id = :room AND m.id > :after
                ORDER BY m.id ASC
                LIMIT :limit");
            $st->bindValue(':room', $roomId, \PDO::PARAM_INT);
            $st->bindValue(':after', max(0, $afterId), \PDO::PARAM_INT);
            $st->bindValue(':limit', $limit, \PDO::PARAM_INT);
            $st->execute();
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $__) {
            return [];
        }
    }

    public function RL_InsertAudioRoomTipEvent(int $roomId, int $buyerId, string $buyerName, float $amount, string $currency, array $payment = []): bool
    {
        $this->ensureAudioRoomTables();
        if ($roomId <= 0 || $amount <= 0) { return false; }
        $buyerName = trim($buyerName);
        if ($buyerName === '' && $buyerId > 0) { $buyerName = 'User #' . $buyerId; }
        $provider = strtolower(trim((string)($payment['provider'] ?? '')));
        $reference = trim((string)($payment['reference'] ?? ''));
        $status = strtolower(trim((string)($payment['status'] ?? 'succeeded')));
        if ($status === '') { $status = 'succeeded'; }
        $createdAt = max(1, (int)($payment['created_at'] ?? time()));
        try {
            $st = $this->db->prepare("INSERT INTO i_audio_room_tip_events
                (room_id, buyer_id, recipient_id, buyer_name, provider, reference, amount, currency,
                 fee_amount, tax_amount, net_amount, status, credited_at, created_at)
                VALUES (:room, :buyer, :recipient, :name, :provider, :reference, :amount, :currency,
                        :fee, :tax, :net, :status, :credited, :created)
                ON DUPLICATE KEY UPDATE
                    room_id = VALUES(room_id), buyer_id = VALUES(buyer_id), recipient_id = VALUES(recipient_id),
                    buyer_name = VALUES(buyer_name), amount = VALUES(amount), currency = VALUES(currency),
                    fee_amount = VALUES(fee_amount), tax_amount = VALUES(tax_amount), net_amount = VALUES(net_amount),
                    status = VALUES(status), credited_at = VALUES(credited_at)");
            $saved = $st->execute([
                ':room' => $roomId,
                ':buyer' => $buyerId > 0 ? $buyerId : null,
                ':recipient' => !empty($payment['recipient_id']) ? (int)$payment['recipient_id'] : null,
                ':name' => $buyerName,
                ':provider' => $provider !== '' ? $provider : null,
                ':reference' => $reference !== '' ? $reference : null,
                ':amount' => $amount,
                ':currency' => strtoupper($currency),
                ':fee' => array_key_exists('fee_amount', $payment) ? (float)$payment['fee_amount'] : null,
                ':tax' => array_key_exists('tax_amount', $payment) ? (float)$payment['tax_amount'] : null,
                ':net' => array_key_exists('net_amount', $payment) ? (float)$payment['net_amount'] : $amount,
                ':status' => $status,
                ':credited' => !empty($payment['credited_at']) ? (int)$payment['credited_at'] : null,
                ':created' => $createdAt,
            ]);
            if ($saved && in_array($status, ['succeeded', 'paid', 'completed'], true)) {
                if ($provider !== '' && $reference !== '') {
                    $this->RL_CreateAudioRoomTipInvoiceByReference($provider, $reference);
                } else {
                    $eventId = (int)$this->db->lastInsertId();
                    if ($eventId > 0) {
                        $this->RL_CreateAudioRoomTipInvoice($eventId);
                    }
                }
            }
            return $saved;
        } catch (\Throwable $__) {
            return false;
        }
    }

    private function RL_EnsureAudioRoomInvoiceTable(): void
    {
        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_invoices (
                invoice_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                invoice_number VARCHAR(64) NOT NULL,
                source_type VARCHAR(40) NOT NULL,
                source_id BIGINT UNSIGNED NOT NULL,
                buyer_id INT UNSIGNED NOT NULL,
                seller_id INT UNSIGNED NULL,
                amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                gross_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                fee_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                tax_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                net_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                currency VARCHAR(10) NOT NULL DEFAULT 'USD',
                provider VARCHAR(32) NULL,
                reference VARCHAR(191) NULL,
                status VARCHAR(32) NOT NULL DEFAULT 'paid',
                billing_snapshot MEDIUMTEXT NULL,
                issued_at INT UNSIGNED NOT NULL,
                paid_at INT UNSIGNED NULL,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NULL,
                PRIMARY KEY (invoice_id),
                UNIQUE KEY uniq_invoice_number (invoice_number),
                UNIQUE KEY uniq_invoice_source (source_type, source_id),
                KEY idx_invoice_buyer_created (buyer_id, created_at),
                KEY idx_invoice_seller_created (seller_id, created_at),
                KEY idx_invoice_status_created (status, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
            $this->ensureAudioRoomColumn('i_invoices', 'gross_amount', "ALTER TABLE i_invoices ADD COLUMN gross_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER amount");
        } catch (\Throwable $__) {
        }
    }

    private function RL_SaveAudioRoomInvoice(array $data): int
    {
        $this->RL_EnsureAudioRoomInvoiceTable();
        $sourceId = (int)($data['source_id'] ?? 0);
        $buyerId = (int)($data['buyer_id'] ?? 0);
        $sellerId = (int)($data['seller_id'] ?? 0);
        $sourceType = trim((string)($data['source_type'] ?? ''));
        if ($sourceId <= 0 || $buyerId <= 0 || $sellerId <= 0 || $sourceType === '') {
            return 0;
        }
        $createdAt = max(1, (int)($data['created_at'] ?? time()));
        $status = strtolower(trim((string)($data['status'] ?? 'paid')));
        $invoiceStatus = in_array($status, ['succeeded', 'completed', 'paid'], true) ? 'paid' : $status;
        $snapshot = json_encode($data['snapshot'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        try {
            $st = $this->db->prepare("INSERT INTO i_invoices
                (invoice_number, source_type, source_id, buyer_id, seller_id, amount, gross_amount, fee_amount, tax_amount, net_amount,
                 currency, provider, reference, status, billing_snapshot, issued_at, paid_at, created_at, updated_at)
                VALUES
                (:number, :source_type, :source_id, :buyer, :seller, :amount, :gross, :fee, :tax, :net,
                 :currency, :provider, :reference, :status, :snapshot, :issued, :paid, :created, :updated)
                ON DUPLICATE KEY UPDATE
                    buyer_id = VALUES(buyer_id), seller_id = VALUES(seller_id), amount = VALUES(amount), gross_amount = VALUES(gross_amount),
                    fee_amount = VALUES(fee_amount), tax_amount = VALUES(tax_amount), net_amount = VALUES(net_amount),
                    currency = VALUES(currency), provider = VALUES(provider), reference = VALUES(reference),
                    status = VALUES(status), billing_snapshot = VALUES(billing_snapshot), paid_at = VALUES(paid_at),
                    updated_at = VALUES(updated_at)");
            $grossAmount = max(0, round((float)($data['amount'] ?? 0), 2));
            $st->execute([
                ':number' => (string)$data['invoice_number'],
                ':source_type' => $sourceType,
                ':source_id' => $sourceId,
                ':buyer' => $buyerId,
                ':seller' => $sellerId,
                ':amount' => $grossAmount,
                ':gross' => $grossAmount,
                ':fee' => max(0, round((float)($data['fee_amount'] ?? 0), 2)),
                ':tax' => max(0, round((float)($data['tax_amount'] ?? 0), 2)),
                ':net' => max(0, round((float)($data['net_amount'] ?? 0), 2)),
                ':currency' => strtoupper(trim((string)($data['currency'] ?? 'USD'))) ?: 'USD',
                ':provider' => strtolower(trim((string)($data['provider'] ?? ''))),
                ':reference' => trim((string)($data['reference'] ?? '')),
                ':status' => $invoiceStatus,
                ':snapshot' => $snapshot ?: null,
                ':issued' => $createdAt,
                ':paid' => $invoiceStatus === 'paid' ? $createdAt : null,
                ':created' => $createdAt,
                ':updated' => time(),
            ]);
            $lookup = $this->db->prepare('SELECT invoice_id FROM i_invoices WHERE source_type = :type AND source_id = :id LIMIT 1');
            $lookup->execute([':type' => $sourceType, ':id' => $sourceId]);
            return (int)$lookup->fetchColumn();
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) { $this->logError('RL_SaveAudioRoomInvoice failed: ' . $e->getMessage()); }
            return 0;
        }
    }

    public function RL_CreateAudioRoomTicketInvoice(int $ticketId): int
    {
        $this->ensureAudioRoomTables();
        if ($ticketId <= 0) { return 0; }
        try {
            $st = $this->db->prepare('SELECT * FROM i_audio_room_tickets WHERE id = :id LIMIT 1');
            $st->execute([':id' => $ticketId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row || !in_array(strtolower((string)$row['status']), ['succeeded', 'paid', 'completed'], true)) { return 0; }
            $gross = max(0, (float)($row['amount'] ?? 0));
            $fee = max(0, (float)($row['fee_amount'] ?? 0));
            $tax = max(0, (float)($row['tax_amount'] ?? 0));
            $net = $row['net_amount'] !== null ? max(0, (float)$row['net_amount']) : max(0, $gross - $fee - $tax);
            return $this->RL_SaveAudioRoomInvoice([
                'invoice_number' => 'AR-TKT-' . $ticketId,
                'source_type' => 'audio_room_ticket', 'source_id' => $ticketId,
                'buyer_id' => (int)$row['buyer_id'], 'seller_id' => (int)$row['owner_id'],
                'amount' => $gross, 'fee_amount' => $fee, 'tax_amount' => $tax, 'net_amount' => $net,
                'currency' => $row['currency'] ?? 'USD', 'provider' => $row['provider'] ?? '',
                'reference' => $row['reference'] ?? '', 'status' => $row['status'] ?? 'paid',
                'created_at' => (int)($row['created_at'] ?? time()),
                'snapshot' => ['room_id' => (int)$row['room_id'], 'ticket_id' => $ticketId, 'event' => (string)($row['event'] ?? '')],
            ]);
        } catch (\Throwable $__) { return 0; }
    }

    public function RL_CreateAudioRoomTicketInvoiceByReference(string $provider, string $reference): int
    {
        try {
            $st = $this->db->prepare('SELECT id FROM i_audio_room_tickets WHERE provider = :provider AND reference = :reference LIMIT 1');
            $st->execute([':provider' => strtolower(trim($provider)), ':reference' => trim($reference)]);
            return $this->RL_CreateAudioRoomTicketInvoice((int)$st->fetchColumn());
        } catch (\Throwable $__) { return 0; }
    }

    public function RL_CreateAudioRoomTipInvoice(int $eventId): int
    {
        $this->ensureAudioRoomTables();
        if ($eventId <= 0) { return 0; }
        try {
            $st = $this->db->prepare("SELECT e.*, r.owner_id AS room_owner_id,
                    tp.id AS tip_payment_id, tp.amount AS payment_amount, tp.fee_amount AS payment_fee,
                    tp.tax_amount AS payment_tax, tp.net_amount AS payment_net, tp.currency AS payment_currency,
                    tp.recipient_id AS payment_recipient_id, tp.created_at AS payment_created_at
                FROM i_audio_room_tip_events e
                LEFT JOIN i_audio_rooms r ON r.room_id = e.room_id
                LEFT JOIN i_tip_payments tp ON tp.provider = e.provider AND tp.reference = e.reference
                WHERE e.id = :id LIMIT 1");
            $st->execute([':id' => $eventId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row || !in_array(strtolower((string)$row['status']), ['succeeded', 'paid', 'completed'], true)) { return 0; }
            $sellerId = (int)($row['payment_recipient_id'] ?? $row['recipient_id'] ?? $row['room_owner_id'] ?? 0);
            $gross = $row['payment_amount'] !== null ? (float)$row['payment_amount'] : (float)$row['amount'];
            $fee = $row['payment_fee'] !== null ? (float)$row['payment_fee'] : (float)($row['fee_amount'] ?? 0);
            $tax = $row['payment_tax'] !== null ? (float)$row['payment_tax'] : (float)($row['tax_amount'] ?? 0);
            $net = $row['payment_net'] !== null ? (float)$row['payment_net'] : ($row['net_amount'] !== null ? (float)$row['net_amount'] : max(0, $gross - $fee - $tax));
            return $this->RL_SaveAudioRoomInvoice([
                'invoice_number' => 'AR-TIP-' . $eventId,
                'source_type' => 'audio_room_tip', 'source_id' => $eventId,
                'buyer_id' => (int)$row['buyer_id'], 'seller_id' => $sellerId,
                'amount' => $gross, 'fee_amount' => $fee, 'tax_amount' => $tax, 'net_amount' => $net,
                'currency' => $row['payment_currency'] ?? $row['currency'] ?? 'USD',
                'provider' => $row['provider'] ?? '', 'reference' => $row['reference'] ?? '',
                'status' => $row['status'] ?? 'paid',
                'created_at' => (int)($row['payment_created_at'] ?? $row['created_at'] ?? time()),
                'snapshot' => ['room_id' => (int)$row['room_id'], 'tip_event_id' => $eventId, 'tip_payment_id' => (int)($row['tip_payment_id'] ?? 0)],
            ]);
        } catch (\Throwable $__) { return 0; }
    }

    public function RL_CreateAudioRoomTipInvoiceByReference(string $provider, string $reference): int
    {
        try {
            $st = $this->db->prepare('SELECT id FROM i_audio_room_tip_events WHERE provider = :provider AND reference = :reference LIMIT 1');
            $st->execute([':provider' => strtolower(trim($provider)), ':reference' => trim($reference)]);
            return $this->RL_CreateAudioRoomTipInvoice((int)$st->fetchColumn());
        } catch (\Throwable $__) { return 0; }
    }

    public function RL_BackfillAudioRoomInvoices(): array
    {
        $result = ['tickets' => 0, 'tips' => 0];
        try {
            foreach ($this->db->query("SELECT id FROM i_audio_room_tickets WHERE status IN ('succeeded','paid','completed')") ?: [] as $row) {
                if ($this->RL_CreateAudioRoomTicketInvoice((int)$row['id']) > 0) { $result['tickets']++; }
            }
            foreach ($this->db->query("SELECT id FROM i_audio_room_tip_events WHERE status IN ('succeeded','paid','completed') AND buyer_id IS NOT NULL AND recipient_id IS NOT NULL") ?: [] as $row) {
                if ($this->RL_CreateAudioRoomTipInvoice((int)$row['id']) > 0) { $result['tips']++; }
            }
        } catch (\Throwable $__) {
        }
        return $result;
    }
}
