<?php
declare(strict_types=1);
trait UserFunctions {
    /**
     * Get the user ID associated with a session key.
     *
     * @param string $sessionKey The unique session key stored in the database.
     * @return int|false Returns the user ID if found, or false if not found or error occurs.
     */
    public function RL_GetUserIDFromSessionKey(string $sessionKey) {
        try {
            $query = "SELECT session_uid FROM i_sessions WHERE session_key = :session_key";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':session_key', $sessionKey, PDO::PARAM_STR);
            $stmt->execute();

            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($row) {
                return (int) $row['session_uid'];
            }
        } catch (PDOException $e) {
            $this->logError('RL_GetUserIDFromSessionKey failed: ' . $e->getMessage() . " | Query: " . $query);
        }

        return false;
    }

    /**
     * Retrieve detailed information for a specific user.
     *
     * @param int $userID The ID of the user to fetch.
     * @return array Returns an associative array of user data or an error message.
     */
    public function RL_GetUserDetails(int $userID): array {
        try {
            $query = "SELECT * FROM i_users WHERE user_id = :user_id LIMIT 1";
            $stmt = $this->db->prepare($query);
            $stmt->bindValue(':user_id', $userID, PDO::PARAM_INT);
            $stmt->execute();

            $data = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$data) {
                return ['error' => "User details couldn't be retrieved."];
            }

            // Fallback: Use username if full name is missing
            if (empty($data['user_fullname'])) {
                $data['user_fullname'] = $data['username'];
            }

            // Fallback: Use user_email if contact_email is missing
            if (empty($data['contact_email'])) {
                $data['contact_email'] = $data['user_email'];
            }

            return $data;
        } catch (PDOException $e) {
            $this->logError("RL_GetUserDetails() failed: " . $e->getMessage());
            return ['error' => "An unexpected error occurred. Please try again later."];
        }
    }

    public function RL_FindUserByEmail(string $email): ?array
    {
        $normalizedEmail = trim($email);
        if ($normalizedEmail === '') {
            return null;
        }

        try {
            $stmt = $this->db->prepare('SELECT user_id, user_email, user_fullname, username FROM i_users WHERE LOWER(user_email) = LOWER(:email) LIMIT 1');
            $stmt->bindValue(':email', $normalizedEmail, PDO::PARAM_STR);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                return null;
            }

            return [
                'user_id' => (int) $row['user_id'],
                'user_email' => (string) $row['user_email'],
                'user_fullname' => isset($row['user_fullname']) ? (string) $row['user_fullname'] : '',
                'username' => (string) $row['username'],
            ];
        } catch (PDOException $e) {
            $this->logError('RL_FindUserByEmail failed: ' . $e->getMessage());
            return null;
        }
    }

    /** Ensure preferences table exists (idempotent). */
    private function RL_EnsureUserPreferencesTable(): void
    {
        try {
            $sql = "CREATE TABLE IF NOT EXISTS i_user_preferences (
                user_id INT UNSIGNED NOT NULL PRIMARY KEY,
                prefs_json LONGTEXT NULL,
                updated_at INT UNSIGNED NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
            $this->db->exec($sql);
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_EnsureUserPreferencesTable failed: ' . $e->getMessage());
            }
        }
    }

    /** Default preferences applied when user has no stored record. */
    private function RL_UserPreferenceDefaults(): array
    {
        return [
            'feed_autoplay'            => true,
            'feed_muted'              => true,
            'notify_push'             => true,
            'notify_email'            => true,
            'notify_sms'              => false,
            'language'                => null,
        ];
    }

    /** Public accessor for default preferences so templates can reuse defaults. */
    public function RL_DefaultUserPreferences(): array
    {
        return $this->RL_UserPreferenceDefaults();
    }

    /** Retrieve stored user preferences merged with defaults. */
    public function RL_GetUserPreferences(int $userId): array
    {
        if ($userId <= 0) { return $this->RL_UserPreferenceDefaults(); }
        $this->RL_EnsureUserPreferencesTable();

        $defaults = $this->RL_UserPreferenceDefaults();
        $result = $defaults;

        try {
            $stmt = $this->db->prepare('SELECT prefs_json FROM i_user_preferences WHERE user_id = :uid LIMIT 1');
            $stmt->bindValue(':uid', $userId, PDO::PARAM_INT);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row && isset($row['prefs_json'])) {
                $decoded = json_decode((string) $row['prefs_json'], true);
                if (is_array($decoded)) {
                    foreach ($defaults as $key => $defaultValue) {
                        if (array_key_exists($key, $decoded)) {
                            $value = $decoded[$key];
                            if (is_bool($defaultValue)) {
                                $result[$key] = (bool) $value;
                            } elseif ($key === 'language') {
                                $result[$key] = is_string($value) ? trim($value) : null;
                                if ($result[$key] === '') { $result[$key] = null; }
                            } else {
                                $result[$key] = $value;
                            }
                        }
                    }
                }
            }
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_GetUserPreferences failed: ' . $e->getMessage());
            }
        }

        return $result;
    }

    /** Persist sanitized user preferences (upsert). */
    public function RL_UpdateUserPreferences(int $userId, array $preferences): array
    {
        $response = ['ok' => false, 'preferences' => []];
        if ($userId <= 0) {
            return $response;
        }

        $this->RL_EnsureUserPreferencesTable();
        $defaults = $this->RL_UserPreferenceDefaults();
        $current = $this->RL_GetUserPreferences($userId);

        $boolKeys = ['feed_autoplay','feed_muted','notify_push','notify_email','notify_sms'];

        foreach ($boolKeys as $key) {
            if (array_key_exists($key, $preferences)) {
                $current[$key] = (bool) $preferences[$key];
            }
        }

        if (array_key_exists('language', $preferences)) {
            $language = $preferences['language'];
            if (is_string($language)) {
                $language = trim($language);
                if ($language === '') {
                    $language = null;
                } else {
                    $language = strtolower(preg_replace('/[^a-z0-9_\-]/i', '', $language));
                }
            } else {
                $language = null;
            }
            $current['language'] = $language ?: null;
        }

        // Ensure only valid keys are stored
        $clean = [];
        foreach ($defaults as $key => $defaultValue) {
            if (array_key_exists($key, $current)) {
                if (is_bool($defaultValue)) {
                    $clean[$key] = (bool) $current[$key];
                } else {
                    $clean[$key] = $current[$key];
                }
            } else {
                $clean[$key] = $defaultValue;
            }
        }

        try {
            $json = json_encode($clean, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($json === false) {
                throw new \RuntimeException('Failed to encode preferences.');
            }

            $stmt = $this->db->prepare('INSERT INTO i_user_preferences (user_id, prefs_json, updated_at)
                VALUES (:uid, :prefs, :updated)
                ON DUPLICATE KEY UPDATE prefs_json = VALUES(prefs_json), updated_at = VALUES(updated_at)');
            $stmt->execute([
                ':uid'     => $userId,
                ':prefs'   => $json,
                ':updated' => time(),
            ]);

            $response['ok'] = true;
            $response['preferences'] = $clean;
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_UpdateUserPreferences failed: ' . $e->getMessage());
            }
            $response['error'] = $e->getMessage();
        }

        return $response;
    }

    /**
     * Retrieve the avatar path for a user.
     *
     * If the user has not set an avatar, returns the default avatar path.
     *
     * @param int $userID The ID of the user.
     * @return string The path to the user's avatar or the default avatar.
     */
    public function RL_userAvatar(int $userID): string {
        try {
            $query = "
                SELECT
                    user_avatar AS avatar
                FROM i_users
                WHERE user_id = :user_id
                LIMIT 1
            ";

            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':user_id', $userID, PDO::PARAM_INT);
            $stmt->execute();

            $data = $stmt->fetch(PDO::FETCH_ASSOC);

            return ($data && isset($data['avatar'])) ? $data['avatar'] : 'uploads/user_avatars/default.jpeg';
        } catch (PDOException $e) {
            $this->logError("RL_userAvatar() failed: " . $e->getMessage());
            return 'uploads/user_avatars/default.jpeg';
        }
    }

    /** Ensure verification requests table exists (idempotent). */
    private function RL_EnsureVerificationRequestsTable(): void
    {
        try {
            $sql = "CREATE TABLE IF NOT EXISTS i_verification_requests (
                request_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id INT UNSIGNED NOT NULL,
                documents LONGTEXT NULL,
                notes TEXT NULL,
                request_status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
                admin_id INT UNSIGNED NULL,
                admin_note TEXT NULL,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NULL,
                PRIMARY KEY (request_id),
                UNIQUE KEY uniq_user (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
            $this->db->exec($sql);
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_EnsureVerificationRequestsTable failed: ' . $e->getMessage());
            }
        }
    }

    /** Upsert a creator verification request and mark user as pending. */
    public function RL_SaveCreatorVerificationRequest(int $userId, array $documents, string $note = ''): array
    {
        $this->RL_EnsureVerificationRequestsTable();
        $now = time();
        try {
            $payload = $documents ? json_encode($documents, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
            $sql = "INSERT INTO i_verification_requests (user_id, documents, notes, request_status, created_at, updated_at)
                    VALUES (:uid, :docs, :notes, 'pending', :created_at, :updated_at)
                    ON DUPLICATE KEY UPDATE documents = VALUES(documents), notes = VALUES(notes), request_status = 'pending', admin_id = NULL, admin_note = NULL, updated_at = VALUES(updated_at)";
            $st = $this->db->prepare($sql);
            $st->execute([
                ':uid'        => $userId,
                ':docs'       => $payload,
                ':notes'      => $note !== '' ? $note : null,
                ':created_at' => $now,
                ':updated_at' => $now,
            ]);
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_SaveCreatorVerificationRequest failed: ' . $e->getMessage());
            }
        }

        $this->RL_UpdateCreatorStatus($userId, 'pending');
        return $this->RL_GetCreatorVerificationRequest($userId);
    }

    /** Fetch verification request for a user. */
    public function RL_GetCreatorVerificationRequest(int $userId): array
    {
        $this->RL_EnsureVerificationRequestsTable();
        try {
            $st = $this->db->prepare('SELECT * FROM i_verification_requests WHERE user_id = :uid LIMIT 1');
            $st->bindValue(':uid', $userId, PDO::PARAM_INT);
            $st->execute();
            $row = $st->fetch(PDO::FETCH_ASSOC) ?: [];
            if (!$row) { return []; }
            if (isset($row['documents'])) {
                $decoded = json_decode((string)$row['documents'], true);
                if (is_array($decoded)) {
                    $row['documents'] = $decoded;
                }
            }
            return $row;
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_GetCreatorVerificationRequest failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    /** Update creator status on i_users and track timestamp. */
    public function RL_UpdateCreatorStatus(int $userId, string $status): bool
    {
        $allowed = ['none','pending','approved','rejected'];
        if (!in_array($status, $allowed, true)) { return false; }
        try {
            $isVerified = ($status === 'approved') ? 1 : 0;
            $sql = 'UPDATE i_users
                    SET creator_status = :st,
                        verified_status = :verified,
                        creator_status_updated_at = :ts
                    WHERE user_id = :uid
                    LIMIT 1';
            $st = $this->db->prepare($sql);
            return $st->execute([
                ':st'       => $status,
                ':verified' => $isVerified,
                ':ts'       => time(),
                ':uid'      => $userId,
            ]);
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_UpdateCreatorStatus failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    /** Admin review action for a verification request. */
    public function RL_UpdateCreatorVerificationStatus(int $requestId, string $status, int $adminId = 0, string $adminNote = ''): bool
    {
        $this->RL_EnsureVerificationRequestsTable();
        $allowed = ['pending','approved','rejected'];
        if (!in_array($status, $allowed, true)) { return false; }
        try {
            $sql = 'UPDATE i_verification_requests SET request_status = :st, admin_id = :aid, admin_note = :note, updated_at = :ts WHERE request_id = :rid LIMIT 1';
            $st = $this->db->prepare($sql);
            $ok = $st->execute([
                ':st'   => $status,
                ':aid'  => $adminId > 0 ? $adminId : null,
                ':note' => $adminNote !== '' ? $adminNote : null,
                ':ts'   => time(),
                ':rid'  => $requestId,
            ]);
            if (!$ok) { return false; }

            $userId = 0;
            try {
                $st2 = $this->db->prepare('SELECT user_id FROM i_verification_requests WHERE request_id = :rid LIMIT 1');
                $st2->execute([':rid' => $requestId]);
                $userId = (int)($st2->fetchColumn() ?: 0);
            } catch (\Throwable $__) {}
            if ($userId > 0) {
                $targetStatus = $status;
                if ($status === 'approved') { $targetStatus = 'approved'; }
                elseif ($status === 'rejected') { $targetStatus = 'rejected'; }
                $this->RL_UpdateCreatorStatus($userId, $targetStatus);
            }
            return true;
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_UpdateCreatorVerificationStatus failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    /** List verification requests by status for admin usage. */
    public function RL_ListCreatorVerificationRequests(string $status = 'pending', int $limit = 50, int $offset = 0): array
    {
        $this->RL_EnsureVerificationRequestsTable();
        $allowed = ['pending','approved','rejected'];
        if (!in_array($status, $allowed, true)) { $status = 'pending'; }
        try {
            $sql = 'SELECT * FROM i_verification_requests WHERE request_status = :st ORDER BY updated_at DESC, request_id DESC LIMIT :lim OFFSET :off';
            $st = $this->db->prepare($sql);
            $st->bindValue(':st', $status, PDO::PARAM_STR);
            $st->bindValue(':lim', max(1, $limit), PDO::PARAM_INT);
            $st->bindValue(':off', max(0, $offset), PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
            foreach ($rows as &$row) {
                if (isset($row['documents'])) {
                    $decoded = json_decode((string)$row['documents'], true);
                    if (is_array($decoded)) {
                        $row['documents'] = $decoded;
                    }
                }
            }
            return $rows;
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_ListCreatorVerificationRequests failed: ' . $e->getMessage());
            }
            return [];
        }
    }

    /** Persist payout preferences on user profile. */
    public function RL_UpdateUserPayoutPreferences(int $userId, string $method, array $details = []): bool
    {
        $allowed = array_merge(['none'], property_exists($this, 'payoutAllowedMethods') ? (array) $this->payoutAllowedMethods : ['bank','paypal','other']);
        if (!in_array($method, $allowed, true)) {
            $method = 'none';
        }

        if (method_exists($this, 'RL_SavePayoutMethodDetails')) {
            if ($method === 'none') {
                $current = method_exists($this, 'RL_GetUserPayoutDetails') ? $this->RL_GetUserPayoutDetails($userId) : ['methods' => []];
                $data = [
                    'default_method' => 'none',
                    'methods'        => $current['methods'] ?? [],
                ];
                try {
                    $sql = 'UPDATE i_users SET payout_method = :method, payout_details_json = :details WHERE user_id = :uid LIMIT 1';
                    $st  = $this->db->prepare($sql);
                    return $st->execute([
                        ':method'  => 'none',
                        ':details' => json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                        ':uid'     => $userId,
                    ]);
                } catch (\Throwable $e) {
                    if (is_callable([$this, 'logError'])) {
                        $this->logError('RL_UpdateUserPayoutPreferences failed: ' . $e->getMessage());
                    }
                    return false;
                }
            }

            return $this->RL_SavePayoutMethodDetails($userId, $method, $details, true);
        }

        // Fallback legacy behaviour
        $payload = $details ? json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
        try {
            $sql = 'UPDATE i_users SET payout_method = :method, payout_details_json = :details WHERE user_id = :uid LIMIT 1';
            $st = $this->db->prepare($sql);
            return $st->execute([
                ':method'  => $method,
                ':details' => $payload,
                ':uid'     => $userId,
            ]);
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_UpdateUserPayoutPreferences failed: ' . $e->getMessage());
            }
            return false;
        }
    }

    /** Retrieve payout preferences. */
    public function RL_GetUserPayoutPreferences(int $userId): array
    {
        if (method_exists($this, 'RL_GetUserPayoutDetails')) {
            $ctx = $this->RL_GetUserPayoutDetails($userId);
            return [
                'method'  => $ctx['default_method'] ?? 'none',
                'details' => $ctx['methods'] ?? [],
            ];
        }

        try {
            $st = $this->db->prepare('SELECT payout_method, payout_details_json FROM i_users WHERE user_id = :uid LIMIT 1');
            $st->bindValue(':uid', $userId, PDO::PARAM_INT);
            $st->execute();
            $row = $st->fetch(PDO::FETCH_ASSOC) ?: [];
            if (!$row) { return ['method' => 'none', 'details' => []]; }
            $method = (string)($row['payout_method'] ?? 'none');
            $details = [];
            if (!empty($row['payout_details_json'])) {
                $decoded = json_decode((string)$row['payout_details_json'], true);
                if (is_array($decoded)) { $details = $decoded; }
            }
            return ['method' => $method, 'details' => $details];
        } catch (\Throwable $e) {
            if (is_callable([$this, 'logError'])) {
                $this->logError('RL_GetUserPayoutPreferences failed: ' . $e->getMessage());
            }
            return ['method' => 'none', 'details' => []];
        }
    }
}
