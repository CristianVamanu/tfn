<?php
declare(strict_types=1);

trait SubscriptionsFunctions {
    private function RL_EnsureSubscriptionRenewLogTable(): void
    {
        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS i_subscription_renewal_log (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                buyer_id INT UNSIGNED NOT NULL,
                recipient_id INT UNSIGNED NOT NULL,
                provider VARCHAR(32) NOT NULL,
                amount DECIMAL(10,2) NULL,
                currency VARCHAR(10) NULL,
                plan_interval VARCHAR(16) NULL,
                interval_count INT UNSIGNED NULL,
                period_start INT UNSIGNED NULL,
                attempt_at INT UNSIGNED NOT NULL,
                status VARCHAR(32) NOT NULL,
                reason VARCHAR(64) NULL,
                reference VARCHAR(191) NULL,
                extra JSON NULL,
                PRIMARY KEY (id),
                KEY idx_buyer (buyer_id),
                KEY idx_recipient (recipient_id),
                KEY idx_status (status),
                KEY idx_attempt_at (attempt_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;");
        } catch (\Throwable $__) {}
    }

    /** Lightweight logging for subscription renewals */
    public function RL_LogSubscriptionRenewAttempt(
        int $buyerId,
        int $recipientId,
        string $provider,
        float $amount,
        string $currency,
        string $planInterval,
        int $intervalCount,
        int $periodStart,
        string $status,
        string $reason = '',
        ?string $reference = null,
        array $extra = []
    ): bool {
        $this->RL_EnsureSubscriptionRenewLogTable();
        try {
            $st = $this->db->prepare("INSERT INTO i_subscription_renewal_log
                (buyer_id, recipient_id, provider, amount, currency, plan_interval, interval_count, period_start, attempt_at, status, reason, reference, extra)
                VALUES (:b,:r,:p,:a,:c,:i,:n,:ps,:t,:s,:re,:ref,:x)");
            $payload = $extra ? json_encode($extra, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
            return $st->execute([
                ':b' => $buyerId,
                ':r' => $recipientId,
                ':p' => $provider,
                ':a' => $amount,
                ':c' => $currency,
                ':i' => $planInterval,
                ':n' => $intervalCount,
                ':ps'=> $periodStart,
                ':t' => time(),
                ':s' => $status,
                ':re'=> ($reason !== '' ? $reason : null),
                ':ref'=> $reference,
                ':x' => $payload,
            ]);
        } catch (\Throwable $__) { return false; }
    }
    private function RL_EnsureSubscriptionPlansTable(): void
    {
        try {
            // New schema with auto-increment plan_id and unique(user_id)
            $sql = "CREATE TABLE IF NOT EXISTS i_users_subscription_plans (
                plan_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id INT UNSIGNED NOT NULL,
                price_weekly DECIMAL(10,2) NULL,
                price_monthly DECIMAL(10,2) NULL,
                price_halfyear DECIMAL(10,2) NULL,
                price_yearly DECIMAL(10,2) NULL,
                currency VARCHAR(10) NULL,
                updated_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (plan_id),
                UNIQUE KEY uniq_user (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
            $this->db->exec($sql);
            // Best-effort migrations for older installs (where PRIMARY KEY was user_id and no plan_id existed)
            try { $this->db->exec("ALTER TABLE i_users_subscription_plans ADD COLUMN plan_id INT UNSIGNED NULL FIRST"); } catch (\Throwable $e) {}
            try { $this->db->exec("ALTER TABLE i_users_subscription_plans DROP PRIMARY KEY"); } catch (\Throwable $e) {}
            try { $this->db->exec("ALTER TABLE i_users_subscription_plans MODIFY COLUMN plan_id INT UNSIGNED NOT NULL AUTO_INCREMENT, ADD PRIMARY KEY (plan_id)"); } catch (\Throwable $e) {}
            try { $this->db->exec("ALTER TABLE i_users_subscription_plans ADD UNIQUE KEY uniq_user (user_id)"); } catch (\Throwable $e) {}
        } catch (\Throwable $e) {}
    }

    public function RL_GetUserSubscriptionPlans(int $creatorId): array
    {
        $this->RL_EnsureSubscriptionPlansTable();
        try {
            $st = $this->db->prepare("SELECT * FROM i_users_subscription_plans WHERE user_id = :uid LIMIT 1");
            $st->execute([':uid' => $creatorId]);
            return $st->fetch(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) { return []; }
    }

    public function RL_SaveUserSubscriptionPlans(int $creatorId, array $data, string $currency = 'USD'): bool
    {
        $this->RL_EnsureSubscriptionPlansTable();
        try {
            $now = time();
            $sql = "INSERT INTO i_users_subscription_plans
                    (user_id, price_weekly, price_monthly, price_halfyear, price_yearly, currency, updated_at)
                    VALUES (:uid, :w, :m, :h, :y, :cur, :t)
                    ON DUPLICATE KEY UPDATE
                        price_weekly = VALUES(price_weekly),
                        price_monthly = VALUES(price_monthly),
                        price_halfyear = VALUES(price_halfyear),
                        price_yearly = VALUES(price_yearly),
                        currency = VALUES(currency),
                        updated_at = VALUES(updated_at)";
            $st = $this->db->prepare($sql);
            return $st->execute([
                ':uid' => $creatorId,
                ':w' => isset($data['weekly']) ? (float)$data['weekly'] : null,
                ':m' => isset($data['monthly']) ? (float)$data['monthly'] : null,
                ':h' => isset($data['halfyear']) ? (float)$data['halfyear'] : null,
                ':y' => isset($data['yearly']) ? (float)$data['yearly'] : null,
                ':cur' => $currency,
                ':t' => $now,
            ]);
        } catch (\Throwable $e) { return false; }
    }

    private function RL_EnsureSubscriptionsTable(): void
    {
        try {
            $sql = "CREATE TABLE IF NOT EXISTS i_subscription_payments (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                buyer_id INT UNSIGNED NOT NULL,
                recipient_id INT UNSIGNED NOT NULL,
                plan_interval VARCHAR(16) NOT NULL,
                interval_count INT UNSIGNED NOT NULL DEFAULT 1,
                provider VARCHAR(32) NOT NULL,
                reference VARCHAR(191) NOT NULL,
                provider_object_id VARCHAR(191) NULL,
                amount DECIMAL(10,2) NULL,
                currency VARCHAR(10) NULL,
                status VARCHAR(32) NOT NULL,
                event VARCHAR(64) NULL,
                current_period_end INT UNSIGNED NULL,
                started_at INT UNSIGNED NULL,
                cancelled_at INT UNSIGNED NULL,
                raw_payload MEDIUMTEXT NULL,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_provider_ref (provider, reference),
                KEY idx_provider_object (provider, provider_object_id),
                KEY idx_recipient (recipient_id),
                KEY idx_buyer (buyer_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
            $this->db->exec($sql);
            // Add missing columns if table existed before
            try { $this->db->exec("ALTER TABLE i_subscription_payments ADD COLUMN provider_object_id VARCHAR(191) NULL"); } catch (\Throwable $e) {}
            try { $this->db->exec("ALTER TABLE i_subscription_payments ADD KEY idx_provider_object (provider, provider_object_id)"); } catch (\Throwable $e) {}
        } catch (\Throwable $e) {}
    }

    public function RL_RecordSubscriptionPayment(
        int $buyerId,
        int $recipientId,
        string $planInterval,
        int $intervalCount,
        string $provider,
        string $reference,
        float $amount,
        string $currency,
        string $status = 'pending',
        string $event = '',
        array $raw = []
    ): bool {
        $this->RL_EnsureSubscriptionsTable();
        try {
            $sql = "INSERT INTO i_subscription_payments
                    (buyer_id, recipient_id, plan_interval, interval_count, provider, reference, amount, currency, status, event, raw_payload, created_at, updated_at)
                    VALUES (:buyer, :rec, :ival, :cnt, :prov, :ref, :amt, :cur, :st, :ev, :raw, :t, NULL)
                    ON DUPLICATE KEY UPDATE amount=VALUES(amount), currency=VALUES(currency), status=VALUES(status), event=VALUES(event), raw_payload=VALUES(raw_payload), updated_at=VALUES(created_at)";
            $st = $this->db->prepare($sql);
            return $st->execute([
                ':buyer'=>$buyerId, ':rec'=>$recipientId, ':ival'=>$planInterval, ':cnt'=>$intervalCount,
                ':prov'=>$provider, ':ref'=>$reference, ':amt'=>$amount, ':cur'=>$currency,
                ':st'=>$status, ':ev'=>$event, ':raw'=>json_encode($raw, JSON_UNESCAPED_UNICODE), ':t'=>time()
            ]);
        } catch (\Throwable $e) { return false; }
    }

    public function RL_UpdateSubscriptionStatusByReference(string $provider, string $reference, string $status, string $event = '', array $raw = [], ?int $cancelledAt = null): bool
    {
        $this->RL_EnsureSubscriptionsTable();
        try {
            $fields = "status = :st, event = :ev, raw_payload = :raw, updated_at = :t";
            $params = [
                ':st'   => $status,
                ':ev'   => $event,
                ':raw'  => json_encode($raw, JSON_UNESCAPED_UNICODE),
                ':t'    => time(),
                ':prov' => $provider,
                ':ref'  => $reference,
            ];
            if ($cancelledAt !== null) {
                $fields .= ", cancelled_at = CASE WHEN cancelled_at IS NULL OR cancelled_at = 0 THEN :cancelled ELSE cancelled_at END";
                $params[':cancelled'] = $cancelledAt;
            }
            $sql = "UPDATE i_subscription_payments SET $fields WHERE provider = :prov AND reference = :ref";
            $st = $this->db->prepare($sql);
            return $st->execute($params);
        } catch (\Throwable $e) { return false; }
    }

    /** Store provider-side subscription id (e.g., Stripe subscription id) for later cancellation. */
    public function RL_UpdateSubscriptionProviderObjectByReference(string $provider, string $reference, string $providerObjectId): bool
    {
        $this->RL_EnsureSubscriptionsTable();
        try {
            $sql = "UPDATE i_subscription_payments SET provider_object_id=:obj, updated_at=:t WHERE provider=:prov AND reference=:ref";
            $st = $this->db->prepare($sql);
            return $st->execute([':obj'=>$providerObjectId, ':t'=>time(), ':prov'=>$provider, ':ref'=>$reference]);
        } catch (\Throwable $e) { return false; }
    }

    /** Update subscription status by provider object id (e.g., Stripe sub id, PayPal sub id). */
    public function RL_UpdateSubscriptionStatusByProviderObject(string $provider, string $providerObjectId, string $status, string $event = '', array $raw = [], ?int $cancelledAt = null): bool
    {
        $this->RL_EnsureSubscriptionsTable();
        try {
            $fields = "status = :st, event = :ev, raw_payload = :raw, updated_at = :t";
            $params = [
                ':st'   => $status,
                ':ev'   => $event,
                ':raw'  => json_encode($raw, JSON_UNESCAPED_UNICODE),
                ':t'    => time(),
                ':prov' => $provider,
                ':obj'  => $providerObjectId,
            ];
            if ($cancelledAt !== null) {
                $fields .= ", cancelled_at = CASE WHEN cancelled_at IS NULL OR cancelled_at = 0 THEN :cancelled ELSE cancelled_at END";
                $params[':cancelled'] = $cancelledAt;
            }
            $sql = "UPDATE i_subscription_payments SET $fields WHERE provider = :prov AND provider_object_id = :obj";
            $st = $this->db->prepare($sql);
            return $st->execute($params);
        } catch (\Throwable $e) { return false; }
    }

    /** Fetch a subscription ledger row by provider + provider_object_id. */
    public function RL_GetSubscriptionByProviderObject(string $provider, string $providerObjectId): ?array
    {
        $this->RL_EnsureSubscriptionsTable();
        try {
            $st = $this->db->prepare("SELECT * FROM i_subscription_payments WHERE provider = :prov AND provider_object_id = :obj LIMIT 1");
            $st->execute([':prov'=>$provider, ':obj'=>$providerObjectId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (\Throwable $e) { return null; }
    }

    /** Attempt to cancel provider subscription and mark DB; does not change i_friends relation. */
    public function RL_CancelProviderSubscription(int $buyerId, int $creatorId): array
    {
        $this->RL_EnsureSubscriptionsTable();
        try {
            $st = $this->db->prepare("SELECT id, provider, reference, provider_object_id, status FROM i_subscription_payments
                                       WHERE buyer_id=:b AND recipient_id=:r AND status='succeeded'
                                       ORDER BY id DESC LIMIT 1");
            $st->execute([':b'=>$buyerId, ':r'=>$creatorId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            if (!$row) { return ['ok'=>false,'error'=>'ACTIVE_NOT_FOUND']; }
            $prov = (string)($row['provider'] ?? '');
            $ref  = (string)($row['reference'] ?? '');
            $obj  = (string)($row['provider_object_id'] ?? '');
            // Call provider if supported
            $okProvider = true; $msg='';
            if ($prov !== '') {
                require_once __DIR__ . '/../payments/PaymentFactory.php';
                $gw = PaymentFactory::make($prov);
                if ($obj !== '' && method_exists($gw, 'cancelSubscription')) {
                    $res = $gw->cancelSubscription($obj);
                    if (isset($res['error'])) { $okProvider = false; $msg = (string)$res['error']; }
                }
            }
            // Mark canceled in DB regardless of provider response
            $ts = time();
            $up = $this->db->prepare("UPDATE i_subscription_payments SET status='canceled', event='user_cancelled', cancelled_at=:cancelled_at, updated_at=:updated_at WHERE provider=:prov AND reference=:ref");
            $up->execute([
                ':cancelled_at' => $ts,
                ':updated_at'   => $ts,
                ':prov'         => $prov,
                ':ref'          => $ref
            ]);
            return ['ok'=>$okProvider, 'provider_ok'=>$okProvider, 'message'=>$msg];
        } catch (\Throwable $e) { return ['ok'=>false,'error'=>$e->getMessage()]; }
    }

    public function RL_GetUserActiveSubscriptions(int $buyerId, int $limit = 50): array
    {
        $buyerId = (int) $buyerId;
        $limit = max(1, min((int) $limit, 200));
        if ($buyerId <= 0) {
            return [];
        }
        $this->RL_EnsureSubscriptionsTable();
        try {
            $sql = "
                SELECT
                    latest.id AS ledger_id,
                    latest.recipient_id AS creator_id,
                    latest.plan_interval,
                    latest.interval_count,
                    latest.amount,
                    latest.currency,
                    latest.status,
                    latest.event,
                    latest.current_period_end,
                    latest.provider,
                    latest.reference,
                    latest.created_at,
                    latest.updated_at,
                    latest.cancelled_at,
                    f.fr_time AS subscribed_at,
                    f.fr_status,
                    u.username,
                    u.user_fullname,
                    u.user_avatar
                FROM (
                    SELECT p.*
                    FROM i_subscription_payments AS p
                    INNER JOIN (
                        SELECT recipient_id, MAX(id) AS max_id
                        FROM i_subscription_payments
                        WHERE buyer_id = :buyer_inner
                        GROUP BY recipient_id
                    ) AS sel ON sel.recipient_id = p.recipient_id AND sel.max_id = p.id
                    WHERE p.buyer_id = :buyer_inner_dupe
                ) AS latest
                LEFT JOIN i_friends AS f
                  ON f.fr_one = :buyer
                 AND f.fr_two = latest.recipient_id
                 AND f.fr_status = 'subscriber'
                LEFT JOIN i_users AS u ON u.user_id = latest.recipient_id
                ORDER BY COALESCE(latest.current_period_end, latest.created_at) DESC
                LIMIT :limit_rows
            ";
            $st = $this->db->prepare($sql);
            $st->bindValue(':buyer_inner', $buyerId, \PDO::PARAM_INT);
            $st->bindValue(':buyer_inner_dupe', $buyerId, \PDO::PARAM_INT);
            $st->bindValue(':buyer', $buyerId, \PDO::PARAM_INT);
            $st->bindValue(':limit_rows', $limit, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetUserActiveSubscriptions failed: ' . $e->getMessage());
            }
            return [];
        }

        $result = [];
        foreach ($rows as $row) {
            $creatorId = (int) ($row['creator_id'] ?? 0);
            $fullName = trim((string) ($row['user_fullname'] ?? ''));
            if ($fullName === '') {
                $fullName = (string) ($row['username'] ?? '');
            }
            $avatar = (string) ($row['user_avatar'] ?? '');
            if ($avatar === '' && method_exists($this, 'RL_userAvatar') && $creatorId > 0) {
                $avatar = $this->RL_userAvatar($creatorId);
            }
            if ($avatar === '') {
                $avatar = 'uploads/user_avatars/default.jpeg';
            }
            $planRaw = (string) ($row['plan_interval'] ?? '');
            $planLabel = $planRaw !== '' ? ucwords(str_replace(['_', '-'], ' ', $planRaw)) : 'Standard';
            $intervalCount = (int) ($row['interval_count'] ?? 1);
            if ($intervalCount > 1) {
                $planLabel .= ' x' . $intervalCount;
            }
            $statusRaw = strtolower(trim((string) ($row['status'] ?? '')));
            $cancelledAt = (int) ($row['cancelled_at'] ?? 0);
            $currentPeriodEnd = isset($row['current_period_end']) ? (int) $row['current_period_end'] : 0;
            $subscriberStatus = (string) ($row['fr_status'] ?? '');
            $inactiveStatuses = ['canceled', 'cancelled', 'incomplete_expired', 'unpaid'];
            if ($subscriberStatus === '') {
                if (in_array($statusRaw, $inactiveStatuses, true) || $cancelledAt > 0) {
                    continue;
                }
            }
            if ($statusRaw === '') {
                $statusRaw = 'active';
            }
            $result[] = [
                'id' => (int) ($row['ledger_id'] ?? 0),
                'creator_id' => $creatorId,
                'creator' => $fullName,
                'username' => (string) ($row['username'] ?? ''),
                'avatar' => $avatar,
                'plan' => $planLabel,
                'amount' => isset($row['amount']) ? (float) $row['amount'] : 0.0,
                'currency' => (string) ($row['currency'] ?? ''),
                'renews_at' => $currentPeriodEnd,
                'status' => $statusRaw,
                'status_label' => $statusRaw,
                'provider' => (string) ($row['provider'] ?? ''),
                'reference' => (string) ($row['reference'] ?? ''),
                'subscribed_at' => (int) ($row['subscribed_at'] ?? 0),
                'event' => (string) ($row['event'] ?? ''),
                'cancelled_at' => $cancelledAt,
                'access_until' => $cancelledAt > 0 ? $currentPeriodEnd : 0,
            ];
        }
        return $result;
    }


    public function RL_GetUserSubscriptionHistory(int $buyerId, int $limit = 30): array
    {
        $buyerId = (int) $buyerId;
        $limit = max(1, min((int) $limit, 200));
        if ($buyerId <= 0) {
            return [];
        }
        $this->RL_EnsureSubscriptionsTable();
        try {
            $sql = "
                SELECT
                    p.id,
                    p.recipient_id,
                    p.plan_interval,
                    p.amount,
                    p.currency,
                    p.status,
                    p.event,
                    p.created_at,
                    p.updated_at,
                    u.username,
                    u.user_fullname
                FROM i_subscription_payments AS p
                LEFT JOIN i_users AS u ON u.user_id = p.recipient_id
                WHERE p.buyer_id = :buyer
                ORDER BY p.created_at DESC, p.id DESC
                LIMIT :limit_rows
            ";
            $st = $this->db->prepare($sql);
            $st->bindValue(':buyer', $buyerId, \PDO::PARAM_INT);
            $st->bindValue(':limit_rows', $limit, \PDO::PARAM_INT);
            $st->execute();
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            if (method_exists($this, 'logError')) {
                $this->logError('RL_GetUserSubscriptionHistory failed: ' . $e->getMessage());
            }
            return [];
        }

        $history = [];
        foreach ($rows as $row) {
            $name = trim((string) ($row['user_fullname'] ?? ''));
            if ($name === '') {
                $name = (string) ($row['username'] ?? '');
            }
            $eventRaw = (string) ($row['event'] ?? '');
            $statusRaw = (string) ($row['status'] ?? '');
            $eventLabel = $eventRaw !== '' ? $eventRaw : ($statusRaw !== '' ? $statusRaw : 'update');
            $eventLabel = ucwords(str_replace(['_', '-'], ' ', $eventLabel));
            $history[] = [
                'id' => (int) ($row['id'] ?? 0),
                'creator_id' => (int) ($row['recipient_id'] ?? 0),
                'creator' => $name,
                'username' => (string) ($row['username'] ?? ''),
                'event' => $eventLabel,
                'event_raw' => $eventRaw,
                'status' => $statusRaw,
                'plan' => (string) ($row['plan_interval'] ?? ''),
                'amount' => isset($row['amount']) ? (float) $row['amount'] : null,
                'currency' => (string) ($row['currency'] ?? ''),
                'date' => (int) ($row['created_at'] ?? time()),
                'updated_at' => (int) ($row['updated_at'] ?? 0),
            ];
        }
        return $history;
    }

    public function RL_GetSubscriptionByReference(string $provider, string $reference): ?array
    {
        $this->RL_EnsureSubscriptionsTable();
        try {
            $st = $this->db->prepare("SELECT * FROM i_subscription_payments WHERE provider=:prov AND reference=:ref LIMIT 1");
            $st->execute([':prov'=>$provider, ':ref'=>$reference]);
            return $st->fetch(\PDO::FETCH_ASSOC) ?: null;
        } catch (\Throwable $e) { return null; }
    }

    /** List due subscriptions (current_period_end <= now and not cancelled) */
    public function RL_GetDueSubscriptions(int $now): array
    {
        $this->RL_EnsureSubscriptionsTable();
        try {
            $st = $this->db->prepare("SELECT * FROM i_subscription_payments WHERE current_period_end IS NOT NULL AND current_period_end <= :now AND (cancelled_at IS NULL OR cancelled_at = 0)");
            $st->execute([':now' => $now]);
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $__) { return []; }
    }

    /** List cancelled subscriptions whose access period has ended and should be downgraded. */
    public function RL_GetCancelledSubscriptionsDueForDowngrade(int $now): array
    {
        $this->RL_EnsureSubscriptionsTable();
        try {
            $sql = "SELECT * FROM i_subscription_payments
                    WHERE cancelled_at IS NOT NULL
                      AND cancelled_at > 0
                      AND current_period_end IS NOT NULL
                      AND current_period_end > 0
                      AND current_period_end <= :now";
            $st = $this->db->prepare($sql);
            $st->execute([':now' => $now]);
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $__) { return []; }
    }

    /** Update started_at and current_period_end for a ledger row by provider+reference */
    public function RL_UpdateSubscriptionPeriodByReference(string $provider, string $reference, int $startedAt, int $currentPeriodEnd): bool
    {
        $this->RL_EnsureSubscriptionsTable();
        try {
            $st = $this->db->prepare("UPDATE i_subscription_payments SET started_at = :sa, current_period_end = :cpe, updated_at = :t WHERE provider = :prov AND reference = :ref");
            return $st->execute([':sa'=>$startedAt, ':cpe'=>$currentPeriodEnd, ':t'=>time(), ':prov'=>$provider, ':ref'=>$reference]);
        } catch (\Throwable $__) { return false; }
    }

    /**
     * Attempt to renew a subscription from buyer wallet. Deducts amount, credits creator, records ledger and sets new period.
     * Returns ['ok'=>bool,'reference'=>?string,'started_at'=>int,'current_period_end'=>int]
     */
    public function RL_TryRenewWalletSubscription(
        int $buyerId,
        int $creatorId,
        float $amount,
        string $currency,
        string $planInterval,
        int $intervalCount,
        int $periodStartBase,
        float $feeFixed,
        float $feePercent,
        float $taxPercent
    ): array {
        $buyerId = (int)$buyerId; $creatorId = (int)$creatorId; $intervalCount = max(1,(int)$intervalCount);
        if ($buyerId <= 0 || $creatorId <= 0 || $amount <= 0) { return ['ok'=>false]; }
        try {
            $db = $this->db;
            $db->beginTransaction();
            // Lock buyer wallet
            $st = $db->prepare("SELECT wallet FROM i_users WHERE user_id = :uid FOR UPDATE");
            $st->execute([':uid'=>$buyerId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);
            $bal = (float)($row['wallet'] ?? 0);
            if ($bal < $amount) {
                // Log insufficient balance
                $this->RL_LogSubscriptionRenewAttempt(
                    $buyerId, $creatorId, 'wallet', $amount, $currency, $planInterval, $intervalCount, (int)$periodStartBase,
                    'failed', 'insufficient_wallet', null, ['wallet_balance'=>$bal, 'fee_fixed'=>$feeFixed, 'fee_percent'=>$feePercent, 'tax_percent'=>$taxPercent]
                );
                $db->rollBack();
                return ['ok'=>false,'error'=>'INSUFFICIENT'];
            }

            // Compute creator net (base)
            $den = 1.0 + ($feePercent/100.0) + ($taxPercent/100.0);
            $base = $amount - $feeFixed;
            $base = $den > 0.0 ? round($base / $den, 2) : round($amount, 2);
            if ($base < 0) { $base = round($amount, 2); }

            // Deduct and credit
            $db->prepare("UPDATE i_users SET wallet = wallet - :amt WHERE user_id = :uid")
               ->execute([':amt'=>$amount, ':uid'=>$buyerId]);
            $db->prepare("UPDATE i_users SET earned = COALESCE(earned,0) + :amt WHERE user_id = :uid")
               ->execute([':amt'=>$base, ':uid'=>$creatorId]);
            $db->commit();

            // New ledger row
            $ref = 'SUBWALLET-RENEW-' . $buyerId . '-' . $creatorId . '-' . time();
            $this->RL_RecordSubscriptionPayment($buyerId, $creatorId, (string)$planInterval, (int)$intervalCount, 'wallet', $ref, (float)$amount, (string)$currency, 'succeeded', 'wallet_renewed', ['source'=>'wallet']);

            // Compute next period
            $startedAt = (int)$periodStartBase;
            if ($startedAt <= 0) { $startedAt = time(); }
            $ival = strtolower((string)$planInterval);
            $dt = new \DateTime('@' . $startedAt); $dt->setTimezone(new \DateTimeZone('UTC'));
            if ($ival == 'weekly' || $ival == 'week') { $dt->modify('+' . $intervalCount . ' week'); }
            elseif ($ival == 'yearly' || $ival == 'year') { $dt->modify('+' . $intervalCount . ' year'); }
            elseif ($ival == 'halfyear') { $dt->modify('+' . (6 * $intervalCount) . ' month'); }
            else { $dt->modify('+' . $intervalCount . ' month'); }
            $cpe = $dt->getTimestamp();

            $this->RL_UpdateSubscriptionPeriodByReference('wallet', $ref, $startedAt, $cpe);
            // Ensure relationship is subscriber
            $this->RL_SetAsSubscriber($buyerId, $creatorId, $cpe);

            // Log success
            $this->RL_LogSubscriptionRenewAttempt(
                $buyerId, $creatorId, 'wallet', $amount, $currency, $planInterval, $intervalCount, (int)$periodStartBase,
                'renewed', 'wallet_renewed', $ref, ['net_base'=>$base]
            );
            return ['ok'=>true,'reference'=>$ref,'started_at'=>$startedAt,'current_period_end'=>$cpe];
        } catch (\Throwable $e) {
            // Log exception
            try {
                $this->RL_LogSubscriptionRenewAttempt(
                    (int)$buyerId, (int)$creatorId, 'wallet', (float)$amount, (string)$currency, (string)$planInterval, (int)$intervalCount, (int)$periodStartBase,
                    'failed', 'exception', null, ['error'=>$e->getMessage()]
                );
            } catch (\Throwable $__) {}
            try { if ($this->db->inTransaction()) { $this->db->rollBack(); } } catch (\Throwable $__) {}
            return ['ok'=>false,'error'=>$e->getMessage()];
        }
    }


    /** Check if buyer already has a pending subscription for this creator. */
    public function RL_HasPendingSubscription(int $buyerId, int $creatorId): bool
    {
        $this->RL_EnsureSubscriptionsTable();
        try {
            $st = $this->db->prepare(
                "SELECT 1 FROM i_subscription_payments 
                  WHERE buyer_id = :b AND recipient_id = :r AND status = 'pending' 
                  LIMIT 1"
            );
            $st->execute([':b'=>$buyerId, ':r'=>$creatorId]);
            return (bool)$st->fetchColumn();
        } catch (\Throwable $e) { return false; }
    }

    /** Promote follower to subscriber (idempotent). */
    public function RL_SetAsSubscriber(int $buyerId, int $creatorId, ?int $when = null): bool
    {
        $when = $when ?? time();
        try {
            $db = $this->db;
            if (!$db->inTransaction()) { $db->beginTransaction(); }
            // Fetch any existing relationship between buyer and creator
            $st = $db->prepare("SELECT fr_id, fr_status FROM i_friends WHERE fr_one = :one AND fr_two = :two LIMIT 1");
            $st->execute([':one' => $buyerId, ':two' => $creatorId]);
            $row = $st->fetch(\PDO::FETCH_ASSOC);

            if ($row) {
                // If already subscriber, nothing to do
                if ((string)$row['fr_status'] === 'subscriber') {
                    if ($db->inTransaction()) { $db->commit(); }
                    return true;
                }
                // Upgrade existing relationship (e.g., flwr) to subscriber
                $upd = $db->prepare("UPDATE i_friends SET fr_status = 'subscriber', fr_time = :t WHERE fr_id = :id");
                $ok = $upd->execute([':t' => $when, ':id' => (int)$row['fr_id']]);
                if ($db->inTransaction()) { $db->commit(); }
                return $ok;
            }

            // No relationship row exists; insert as subscriber
            $ins = $db->prepare("INSERT INTO i_friends (fr_one, fr_two, fr_time, fr_status) VALUES (:one, :two, :t, 'subscriber')");
            $ok = $ins->execute([':one' => $buyerId, ':two' => $creatorId, ':t' => $when]);
            if ($db->inTransaction()) { $db->commit(); }
            return $ok;
        } catch (\Throwable $e) {
            try { if ($this->db->inTransaction()) { $this->db->rollBack(); } } catch (\Throwable $__) {}
            return false;
        }
    }

    /**
     * Handle subscription cancellation. When $forceImmediate is false (default), the subscriber relation is kept
     * so access continues until the current period ends. When true, the relation is downgraded to follower instantly.
     */
    public function RL_CancelSubscription(int $buyerId, int $creatorId, ?int $when = null, bool $forceImmediate = false): bool
    {
        $when = $when ?? time();
        if (!$forceImmediate) {
            // Keep subscriber relationship intact (idempotent) until cron/webhook forces downgrade.
            return $this->RL_SetAsSubscriber($buyerId, $creatorId, $when);
        }

        try {
            $db = $this->db;
            $upd = $db->prepare("UPDATE i_friends
                                 SET fr_status = 'flwr', fr_time = :t
                                 WHERE fr_one = :one AND fr_two = :two AND fr_status = 'subscriber'");
            $upd->execute([':t' => $when, ':one' => $buyerId, ':two' => $creatorId]);

            if ($upd->rowCount() > 0) {
                return true;
            }

            // If there is a lingering subscriber row (e.g. duplicate entries), remove it
            $del = $db->prepare("DELETE FROM i_friends WHERE fr_one = :one AND fr_two = :two AND fr_status = 'subscriber'");
            $del->execute([':one' => $buyerId, ':two' => $creatorId]);
            return true;
        } catch (\Throwable $e) { return false; }
    }
}
