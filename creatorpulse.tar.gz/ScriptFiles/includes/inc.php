<?php

require_once __DIR__ . '/polyfills.php';

/**
 * Global Initialization and Core Configuration
 * This section handles error reporting, database connections,
 * class loading, and session start required for the entire system.
 */

// Bootstrap Composer autoload (vendor packaged for distribution)
$composerAutoload = __DIR__ . '/vendor/autoload.php';
if (file_exists($composerAutoload)) {
    $composerLoader = require_once $composerAutoload;

    if ($composerLoader instanceof \Composer\Autoload\ClassLoader) {
        $composerLoader->addPsr4('ReelsProject\\Services\\', __DIR__ . '/services/');
        $composerLoader->addPsr4('BaconQrCode\\', __DIR__ . '/vendor/bacon/bacon-qr-code/src/');
        $composerLoader->addPsr4('DASPRiD\\Enum\\', __DIR__ . '/vendor/dasprid/enum/src/');
    }
}

// --- Security headers (lightweight defaults) ---
// Applied centrally before any output. Conservative allowlist:
// - Same-origin for scripts/styles/images/fonts
// - data: for images and fonts only (for small embedded assets)
// Notes:
// - This will block framing by other sites (including embed/ routes)
// - External CDNs or third-party services will require explicit allowlisting
// Note: routes like themes/default/embed.php may override/remove CSP/XFO for embedding via header_remove() and their own frame-ancestors policy.

if (!function_exists('dz_csp_origin_from_url')) {
    /**
     * Normalize a URL into its origin (scheme + host [+ port]) for CSP directives.
     */
    function dz_csp_origin_from_url($url): ?string
    {
        $trimmed = trim((string) $url);
        if ($trimmed === '') {
            return null;
        }

        $parts = @parse_url($trimmed);
        if (!is_array($parts) || empty($parts['host'])) {
            return null;
        }

        $scheme = isset($parts['scheme']) && $parts['scheme'] !== '' ? $parts['scheme'] : 'https';
        $origin = $scheme . '://' . $parts['host'];

        if (!empty($parts['port'])) {
            $origin .= ':' . (int) $parts['port'];
        }

        return $origin;
    }
}

if (!function_exists('dz_csp_refresh_header')) {
    function dz_csp_refresh_header(): void
    {
        if (headers_sent()) {
            return;
        }

        $context = $GLOBALS['__core_csp_context'] ?? null;
        if (!is_array($context)) {
            return;
        }

        $connectContext = $context['connect'] ?? ["'self'"];
        if (is_array($connectContext)) {
            $connectParts = $connectContext;
        } else {
            $connectParts = preg_split('/\s+/', trim((string) $connectContext)) ?: [];
        }
        if (empty($connectParts)) { $connectParts = ["'self'"]; }

        $scriptParts = $context['script'] ?? ["'self'"];
        $styleParts = $context['style'] ?? ["'self'"];
        $fontParts  = $context['font'] ?? ["'self'", 'data:'];
        $imgParts   = $context['img'] ?? ["'self'", 'data:', 'blob:'];
        $mediaParts = $context['media'] ?? ["'self'", 'blob:'];
        $frameParts = $context['frame'] ?? ["'self'"];
        $workerParts = $context['worker'] ?? ["'self'", 'blob:'];

        if (!is_array($scriptParts)) { $scriptParts = ["'self'"]; }
        if (!is_array($styleParts)) { $styleParts = ["'self'"]; }
        if (!is_array($fontParts))  { $fontParts  = ["'self'", 'data:']; }
        if (!is_array($imgParts))   { $imgParts   = ["'self'", 'data:', 'blob:']; }
        if (!is_array($mediaParts)) { $mediaParts = ["'self'", 'blob:']; }
        if (!is_array($frameParts)) { $frameParts = ["'self'"]; }
        if (!is_array($workerParts)) { $workerParts = ["'self'", 'blob:']; }

        $connect = implode(' ', array_unique($connectParts));
        $scriptSrc = implode(' ', array_unique($scriptParts));
        $styleSrc = implode(' ', array_unique($styleParts));
        $fontSrc  = implode(' ', array_unique($fontParts));
        $imgSrc   = implode(' ', array_unique($imgParts));
        $mediaSrc = implode(' ', array_unique($mediaParts));
        $frameSrc = implode(' ', array_unique($frameParts));
        $workerSrc = implode(' ', array_unique($workerParts));

        header(
            "Content-Security-Policy: connect-src {$connect}; frame-ancestors 'self'; default-src 'self'; script-src {$scriptSrc}; style-src {$styleSrc}; img-src {$imgSrc}; font-src {$fontSrc}; media-src {$mediaSrc}; worker-src {$workerSrc}; object-src 'none'; base-uri 'self'; form-action 'self'; frame-src {$frameSrc};",
            true
        );
    }
}

if (!function_exists('dz_csp_register_source')) {
    function dz_csp_register_source(string $directive, string $source): void
    {
        $normalizedSource = trim($source);
        if ($normalizedSource === '') {
            return;
        }

        $map = [
            'img-src'    => 'img',
            'media-src'  => 'media',
            'style-src'  => 'style',
            'script-src' => 'script',
            'font-src'   => 'font',
            'frame-src'  => 'frame',
            'worker-src' => 'worker',
            'connect-src'=> 'connect',
        ];

        $directiveKey = strtolower($directive);
        if (!isset($map[$directiveKey])) {
            return;
        }

        if (!isset($GLOBALS['__core_csp_context']) || !is_array($GLOBALS['__core_csp_context'])) {
            $GLOBALS['__core_csp_context'] = [];
        }

        $contextKey = $map[$directiveKey];
        if (!isset($GLOBALS['__core_csp_context'][$contextKey]) || !is_array($GLOBALS['__core_csp_context'][$contextKey])) {
            $existing = $GLOBALS['__core_csp_context'][$contextKey] ?? [];
            if (!is_array($existing)) {
                $existing = preg_split('/\s+/', trim((string) $existing)) ?: [];
            }
            $GLOBALS['__core_csp_context'][$contextKey] = $existing;
        }

        if (!in_array($normalizedSource, $GLOBALS['__core_csp_context'][$contextKey], true)) {
            $GLOBALS['__core_csp_context'][$contextKey][] = $normalizedSource;
            dz_csp_refresh_header();
        }
    }
}

if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    // Allow overriding CSP connect-src via ENV var CSP_CONNECT_SRC (e.g., for Agora/WebRTC endpoints)
    $connect = getenv('CSP_CONNECT_SRC');
    if (!$connect) {
        // default: self only; override in .env when LIVE features need extra endpoints (e.g., wss:, *.agora.io)
        $connect = "'self'";
    }

    // Some admin tooling (TinyMCE, cropper overlays, etc.) still rely on inline style attributes.
    // Relax style-src for admin routes so those controls render correctly without globally enabling unsafe inline styles.
    $scriptSrcParts = [
        "'self'",
        "'sha256-Acz6wZGzeAKD74Hw2ROzFHI6cJXGNAZl9KdP4OW5YjA='",
        "'sha256-wK/L3mzNa3i0gdnPaOUnEQEempqiOhJjvOpYWL2LyhA='",
        // Allow GTM bootstrap inline when enabled (hash of the standard snippet)
        "'sha256-yjyozB+hjQZoTTQSJ9gMJwUv9dFpYObAb8AvLR7TlJ8='",
    ];
    // Allow Cloudflare Web Analytics beacon script if present.
    $cloudflareInsightsScript = 'https://static.cloudflareinsights.com';
    $cloudflareInsightsConnect = 'https://cloudflareinsights.com';
    $scriptSrcParts[] = $cloudflareInsightsScript;
    $styleSrcParts = ["'self'"];
    $fontSrcParts  = ["'self'", 'data:'];
    $requestPath   = (string)($_SERVER['REQUEST_URI'] ?? '');
    $scriptPath    = (string)($_SERVER['SCRIPT_NAME'] ?? ($_SERVER['PHP_SELF'] ?? ''));
    $forceInline   = getenv('CSP_ALLOW_INLINE_STYLES');
    $isAdminRoute  = (strpos($requestPath, '/admin/') !== false) || (strpos($scriptPath, '/admin/') !== false);
    $isInvoiceRoute = (strpos($requestPath, '/invoice/') !== false) || (strpos($scriptPath, '/invoice/') !== false);

    if (($forceInline && strtolower($forceInline) !== '0' && strtolower($forceInline) !== 'false') || $isAdminRoute || $isInvoiceRoute) {
        $styleSrcParts[] = "'unsafe-inline'";
    }

    if ($isInvoiceRoute) {
        $styleSrcParts[] = 'https://fonts.googleapis.com';
        $fontSrcParts[]  = 'https://fonts.gstatic.com';
    }

    $imgSrcParts   = ["'self'", 'data:', 'blob:'];
    $mediaSrcParts = ["'self'", 'blob:'];

    $connectParts = is_array($connect)
        ? $connect
        : array_values(array_filter(preg_split('/\s+/', trim((string) $connect)) ?: []));
    if (empty($connectParts)) {
        $connectParts = ["'self'"];
    }
    if (!in_array($cloudflareInsightsConnect, $connectParts, true)) {
        $connectParts[] = $cloudflareInsightsConnect;
    }

    $GLOBALS['__core_csp_context'] = [
        'connect' => $connectParts,
        'script'  => array_values(array_unique($scriptSrcParts)),
        'style'   => array_values(array_unique($styleSrcParts)),
        'font'    => array_values(array_unique($fontSrcParts)),
        'img'     => array_values(array_unique($imgSrcParts)),
        'media'   => array_values(array_unique($mediaSrcParts)),
        'frame'   => ["'self'"],
        // Agora RTC creates an audio processing worker from a same-page Blob URL.
        'worker'  => ["'self'", 'blob:'],
    ];

    dz_csp_refresh_header();
}

// Configure secure session cookie parameters before starting session
$__isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') === '443');
$sessionCookieLifetime = 31556926; // default ~1 year (matches remember-me cookie)
$envLifetimeRaw = getenv('SESSION_COOKIE_LIFETIME');
if ($envLifetimeRaw !== false && is_numeric($envLifetimeRaw)) {
    $sessionCookieLifetime = (int) $envLifetimeRaw;
}
if (function_exists('env')) {
    try {
        $envLifetime = env('SESSION_COOKIE_LIFETIME', (string) $sessionCookieLifetime);
        if (is_numeric($envLifetime)) {
            $sessionCookieLifetime = (int) $envLifetime;
        }
    } catch (Throwable $__) {
        // ignore
    }
}
if ($sessionCookieLifetime < 0) {
    $sessionCookieLifetime = 0;
}
if (function_exists('session_set_cookie_params')) {
    session_set_cookie_params([
        'lifetime' => $sessionCookieLifetime > 0 ? $sessionCookieLifetime : 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $__isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}
$__dzAppendImageDimensions = filter_var((string) getenv('DZ_ADD_IMAGE_DIMENSIONS'), FILTER_VALIDATE_BOOLEAN);
$__dzOutputOptimizer = static function (string $buffer) use ($__dzAppendImageDimensions): string {
    if ($buffer === '' || stripos($buffer, '<img') === false) {
        return $buffer;
    }

    $processor = static function (array $matches) use ($__dzAppendImageDimensions): string {
        $attrSegment = $matches[1];
        $selfClose = $matches[2] ?? '';
        $attrs = rtrim($attrSegment);
        $append = '';

        $hasLazyIgnore = stripos($attrs, 'data-lazy-ignore') !== false;
        $hasLoading = stripos($attrs, 'loading=') !== false;
        $hasDecoding = stripos($attrs, 'decoding=') !== false;
        $hasFetchPriority = stripos($attrs, 'fetchpriority=') !== false;
        $priorityHigh = preg_match('#\bdata-priority\s*=\s*["\']high["\']#i', $attrs) === 1
            || preg_match('#\bloading\s*=\s*["\']eager["\']#i', $attrs) === 1;
        $lazyApplied = false;

        if (!$hasLazyIgnore && !$hasLoading && !$priorityHigh) {
            $append .= ' loading="lazy"';
            $lazyApplied = true;
        }

        if (($lazyApplied || (!$hasLazyIgnore && $hasLoading && stripos($attrs, 'lazy') !== false))
            && !$hasFetchPriority && !$priorityHigh
        ) {
            $append .= ' fetchpriority="low"';
        }

        if (!$hasDecoding) {
            $append .= ' decoding="async"';
        }

        $skipDimensions = stripos($attrs, 'data-skip-image-dimensions') !== false
            || preg_match('#\bdata-lazy-dimensions\s*=\s*["\']skip["\']#i', $attrs) === 1;

        if (!$skipDimensions && preg_match('#\bclass\s*=\s*["\']([^"\']*)["\']#i', $attrs, $classMatch) === 1) {
            $classTokens = strtolower($classMatch[1]);
            if (strpos($classTokens, 'post-media') !== false
                || strpos($classTokens, 'post_media') !== false
                || strpos($classTokens, 'chat-share-card') !== false
                || strpos($classTokens, 'chat_bubble') !== false
                || strpos($classTokens, 'message_me') !== false
                || strpos($classTokens, 'message_media') !== false
                || strpos($classTokens, 'embed-media') !== false
                || strpos($classTokens, 'media-viewer') !== false
                || strpos($classTokens, 'reels_post_wrapper') !== false
                || strpos($classTokens, 'live-card__cover') !== false) {
                $skipDimensions = true;
            }
        }

        $hasWidth = preg_match('#\bwidth\s*=\s*["\']#i', $attrs) === 1;
        $hasHeight = preg_match('#\bheight\s*=\s*["\']#i', $attrs) === 1;
        if (!$skipDimensions
            && $__dzAppendImageDimensions
            && (!$hasWidth || !$hasHeight)
            && preg_match('#\bsrc\s*=\s*["\']([^"\']+)["\']#i', $attrs, $srcMatch) === 1
        ) {
            $src = $srcMatch[1];
            if ($src !== '' && stripos($src, 'data:') !== 0) {
                $dimensions = function_exists('resolve_image_dimensions')
                    ? resolve_image_dimensions($src)
                    : [null, null];
                if (!$hasWidth && !empty($dimensions[0])) {
                    $append .= ' width="' . (int) $dimensions[0] . '"';
                }
                if (!$hasHeight && !empty($dimensions[1])) {
                    $append .= ' height="' . (int) $dimensions[1] . '"';
                }
            }
        }

        if ($append === '') {
            return $matches[0];
        }

        $rebuilt = rtrim($attrs) . $append;
        $closing = $selfClose !== '' ? ' ' . trim($selfClose) : '';

        return '<img' . $rebuilt . $closing . '>';
    };

    $rewritten = preg_replace_callback('#<img\b([^>]*)\s*(/?)>#i', $processor, $buffer);

    return is_string($rewritten) ? $rewritten : $buffer;
};
ob_start($__dzOutputOptimizer);
session_start();

// Database connection and base setup
include_once 'connect.php';

include_once __DIR__ . "/functions.php";
require_once __DIR__ . '/helpers/lang-loader.php';
require_once __DIR__ . '/helpers/csrf_functions.php';
require_once __DIR__ . '/helpers/sanitize_functions.php';
require_once __DIR__ . '/helpers/validation_functions.php';
require_once __DIR__ . '/helpers/string_functions.php';
require_once __DIR__ . '/helpers/icon_helper.php';
require_once __DIR__ . '/helpers/image_functions.php';
require_once __DIR__ . '/helpers/relativeTime.php';
require_once __DIR__ . '/helpers/number_of_short.php';
require_once __DIR__ . '/helpers/currency.php';
require_once __DIR__ . '/helpers/currency_formatter.php';
require_once __DIR__ . '/helpers/countries.php';
require_once __DIR__ . '/helpers/cookie_functions.php';
require_once __DIR__ . '/helpers/theme_thumbs.php';
require_once __DIR__ . '/helpers/text_helpers.php'; // accessibility text helpers (dzShortCaption)
require_once __DIR__ . '/helpers/pagination.php';
require_once __DIR__ . '/helpers/mail_helper.php';
require_once __DIR__ . '/helpers/maintenance_guard.php';
require_once __DIR__ . '/helpers/social_login.php';
require_once __DIR__ . '/emojis.php';
require_once __DIR__ . '/storage/StorageManager.php';
require_once __DIR__ . '/helpers/storage_helpers.php';

$RL = new Reel_Data($db);

// `$loggedIn` is the canonical login state flag ('1' or '0').

// Error reporting: guard with APP_DEBUG
if (defined('APP_DEBUG') && APP_DEBUG === true) {
    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    ini_set('display_startup_errors', '0');
}

// Set default timezone (can be overridden later per user session)
date_default_timezone_set('UTC');

$hash          = isset($_COOKIE[$cookieName]) ? $_COOKIE[$cookieName] : null;
$sessionUserID = isset($_SESSION['iuid']) ? $_SESSION['iuid'] : null;

if (!empty($hash)) {
    try {
        $stmt = $db->prepare("SELECT * FROM i_sessions WHERE session_key = :hash LIMIT 1");
        $stmt->bindParam(':hash', $hash, PDO::PARAM_STR);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row && !empty($row['session_uid'])) {
            $sessionUserID         = $row['session_uid'];
            $_SESSION['iuid']      = $sessionUserID;

            if (isset($RL) && method_exists($RL, 'RL_TouchSessionDevice')) {
                $RL->RL_TouchSessionDevice((int) $sessionUserID, (string) $hash, [
                    'ip' => $_SERVER['REMOTE_ADDR'] ?? null,
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                ]);
            }
        } else {
            // Invalid/expired session: clear cookie + session locally and redirect home
            $hashToDelete = $hash;
            if (!empty($hashToDelete)) {
                try {
                    $stDel = $db->prepare("DELETE FROM i_sessions WHERE session_key = :k");
                    $stDel->execute([':k' => $hashToDelete]);
                } catch (Throwable $___) {}
            }
            if (function_exists('clearSecureCookie')) {
                clearSecureCookie($cookieName);
                clearSecureCookie('fb_access_token');
            } else {
                setcookie($cookieName, '', time() - 31556926, '/');
                setcookie('fb_access_token', '', time() - 3600, '/');
            }
            unset($_COOKIE[$cookieName]);
            session_destroy();
            header("Location: $base_url");
            exit();
        }
    } catch (PDOException $e) {
        if (APP_DEBUG === true) {
            echo '<pre>PDO Error: ' . htmlspecialchars($e->getMessage()) . '</pre>';
        }
        exit();
    }
}
/**
 * Convert bytes to MB with formatting
 *
 * @param int $size
 * @return string
 */
function convert_to_mb($size) {
    $mb_size = $size / 1048576;
    $format_size = number_format($mb_size, 2);
    return $format_size;
}

$siteData = $RL->RL_configs();
$maintenanceModStatus = $siteData['maintenance'] ?? 'off';
$siteName = $siteData['site_name'] ?? NULL;
$siteTitle = $siteData['site_title'] ?? NULL;
$siteDescription = $siteData['site_description'] ?? NULL;
$currentTheme = $siteData['site_theme'] ?? NULL;
$siteWhiteLogo = $siteData['logo_white'] ?? NULL;
$siteDarkLogo = $siteData['logo_dark'] ?? NULL;
$siteMobileWhiteLogo = $siteData['logo_mobile_white'] ?? NULL;
$siteMobileDarkLogo = $siteData['logo_mobile_dark'] ?? NULL;
$configuredLang = isset($siteData['site_language']) ? (string) $siteData['site_language'] : '';
$currentLang = strtolower(trim($configuredLang));
if ($currentLang === '') {
    $currentLang = 'eng';
}

$availableLanguages = function_exists('discoverAvailableLanguages') ? discoverAvailableLanguages() : ['eng'];
if (empty($availableLanguages)) {
    $availableLanguages = ['eng'];
}
if (!in_array($currentLang, $availableLanguages, true)) {
    $currentLang = $availableLanguages[0];
}

$gtmId = '';
$gtmIdEnv = '';
if (function_exists('env')) {
    $gtmIdEnv = (string) env('GTM_ID', '');
}
if ($gtmIdEnv === '') {
    $gtmIdEnv = (string) getenv('GTM_ID');
}
$gtmIdEnv = strtoupper(trim($gtmIdEnv));
$gtmIdDb = isset($siteData['gtm_id']) ? strtoupper(trim((string) $siteData['gtm_id'])) : '';
$gtmIdRaw = $gtmIdEnv !== '' ? $gtmIdEnv : $gtmIdDb;
if ($gtmIdRaw !== '' && preg_match('/^GTM-[A-Z0-9]+$/', $gtmIdRaw)) {
    $gtmId = $gtmIdRaw;
}
$gtmDisableAdmins = (int)($siteData['gtm_disable_admins'] ?? 0) === 1;
$gtmTrackingEnabled = $gtmId !== '';

$hasActiveSessionCookie = isset($_COOKIE[$cookieName]) && trim((string) $_COOKIE[$cookieName]) !== '';
if (!$hasActiveSessionCookie) {
    $guestLanguageCookie = defined('GUEST_LANGUAGE_COOKIE_NAME')
        ? GUEST_LANGUAGE_COOKIE_NAME
        : 'guest_language';
    $cookieLanguage = isset($_COOKIE[$guestLanguageCookie])
        ? strtolower(trim((string) $_COOKIE[$guestLanguageCookie]))
        : '';
    if ($cookieLanguage !== '' && in_array($cookieLanguage, $availableLanguages, true)) {
        $currentLang = $cookieLanguage;
    }
}

$premiumPostPriceMinimum = $siteData['premium_post_price_minimum'] ?? NULL;
$premiumPostPriceMaximum = $siteData['premium_post_price_maximum'] ?? NULL;
$lockedPreviewModeRaw = isset($siteData['locked_preview_mode']) ? strtolower((string) $siteData['locked_preview_mode']) : 'off';
$lockedPreviewModeImagesRaw = isset($siteData['locked_preview_mode_images']) ? strtolower((string) $siteData['locked_preview_mode_images']) : $lockedPreviewModeRaw;
$lockedPreviewModeVideosRaw = isset($siteData['locked_preview_mode_videos']) ? strtolower((string) $siteData['locked_preview_mode_videos']) : $lockedPreviewModeRaw;
$lockedPreviewModeImages = in_array($lockedPreviewModeImagesRaw, ['off', 'static', 'animated'], true) ? $lockedPreviewModeImagesRaw : 'off';
$lockedPreviewModeVideos = in_array($lockedPreviewModeVideosRaw, ['off', 'static', 'animated'], true) ? $lockedPreviewModeVideosRaw : 'off';
$enablePodcastPostsRaw = isset($siteData['podcast_posts_status']) ? strtolower((string) $siteData['podcast_posts_status']) : 'open';
$enablePodcastPosts = $enablePodcastPostsRaw === 'open';
$availableFileExtensions = $siteData['available_video_extensions'] ?? NULL;
$availableUploadFileSize = $siteData['available_file_upload_size'] ?? NULL;
$maximumVideoDuration = $siteData['maximum_video_duration'] ?? NULL;
$maximumAudioDuration = $siteData['maximum_audio_duration'] ?? NULL;
if (is_numeric($maximumAudioDuration)) {
    $maximumAudioDuration = (int) $maximumAudioDuration;
    if ($maximumAudioDuration > 0 && $maximumAudioDuration < 100000) {
        $maximumAudioDuration = $maximumAudioDuration * 60;
    }
}
$iconPath = $base_url."themes/{$currentTheme}/icons/";
$lang = loadLanguage($currentLang);
$rtlLanguages = ['ar'];
$applyLocaleState = static function ($lang) use ($rtlLanguages): array {
    $locale = strtolower((string) ($lang ?? 'eng'));
    if ($locale === '') {
        $locale = 'eng';
    }
    $isRTL = in_array($locale, $rtlLanguages, true);

    $GLOBALS['rtlLanguages'] = $rtlLanguages;
    $GLOBALS['currentLocale'] = $locale;
    $GLOBALS['isRTLLocale'] = $isRTL;

    return [$locale, $isRTL];
};

[$currentLocale, $isRTLLocale] = $applyLocaleState($currentLang);
$scrollLimitChat = $siteData['message_scroll_limit'] ?? '5';
$pageScrollLimit = $siteData['page_scroll_limit'] ?? '10';

$ffmpegPath = $siteData['ffmpeg_path'] ?? NULL;
$ffprobePath = $siteData['ffmpeg_probe_bin'] ?? NULL;

$subscriptionfee = $siteData['subscription_fee'] ?? '5';
$minimumWithdrawalAmount = isset($siteData['minimum_withdrawal_amount']) ? (float) $siteData['minimum_withdrawal_amount'] : 0.0;

$walletTopupStatusRaw = isset($siteData['wallet_topup_status']) ? strtolower((string) $siteData['wallet_topup_status']) : 'close';
$walletTopupEnabled = ($walletTopupStatusRaw === 'open');
$walletTopupMin = isset($siteData['wallet_topup_minimum']) ? (float) $siteData['wallet_topup_minimum'] : 10.0;
$walletTopupMax = isset($siteData['wallet_topup_maximum']) ? (float) $siteData['wallet_topup_maximum'] : 1000.0;

$walletTopupHasProviders = false;
$activePaymentProviders = [];
$hasActivePaymentProviders = false;

if (!class_exists('PaymentConfigResolver', false)) {
    $resolverPath = __DIR__ . '/payments/PaymentConfigResolver.php';
    if (is_string($resolverPath) && file_exists($resolverPath)) {
        require_once $resolverPath;
    }
}

$paymentsConfig = [];
if (class_exists('PaymentConfigResolver')) {
    $paymentsBaseUrl = isset($base_url) ? (string) $base_url : '';
    if ($paymentsBaseUrl === '') {
        $paymentsBaseUrl = (string) ($siteData['site_url'] ?? ($siteData['site_base_url'] ?? ''));
    }

    try {
        $paymentsConfig = PaymentConfigResolver::build(
            is_array($siteData) ? $siteData : [],
            $paymentsBaseUrl
        );
    } catch (\Throwable $th) {
        $paymentsConfig = [];
    }
}

if (is_array($paymentsConfig) && $paymentsConfig !== []) {
    $topupProviderKeys = [
        'stripe',
        'paypal',
        'nowpayments',
        'coinbase',
        'flutterwave',
        'paystack',
        'iyzico',
        'payu',
    ];
    foreach ($topupProviderKeys as $providerKey) {
        if (!empty($paymentsConfig[$providerKey]['enabled'])) {
            $activePaymentProviders[] = $providerKey;
        }
    }
}

$hasActivePaymentProviders = !empty($activePaymentProviders);
$walletTopupHasProviders = $hasActivePaymentProviders;

if ($walletTopupEnabled && !$walletTopupHasProviders) {
    $walletTopupEnabled = false;
}

if (!is_finite($walletTopupMin) || $walletTopupMin < 1.0) {
    $walletTopupMin = 1.0;
}
if (!is_finite($walletTopupMax) || $walletTopupMax < $walletTopupMin) {
    $walletTopupMax = $walletTopupMin;
}

$walletTopupLimits = [
    'enabled' => $walletTopupEnabled,
    'min' => $walletTopupMin,
    'max' => $walletTopupMax,
];

$GLOBALS['walletTopupEnabled'] = $walletTopupEnabled;
$GLOBALS['walletTopupMin'] = $walletTopupMin;
$GLOBALS['walletTopupMax'] = $walletTopupMax;
$GLOBALS['walletTopupLimits'] = $walletTopupLimits;
$GLOBALS['walletTopupHasProviders'] = $walletTopupHasProviders;
$GLOBALS['activePaymentProviders'] = $activePaymentProviders;
$GLOBALS['hasActivePaymentProviders'] = $hasActivePaymentProviders;

$socialLoginConfig = social_login_get_config($siteData);

$storageSiteConfig = $siteData;

if (function_exists('env')) {
    $envDriver = (string) env('STORAGE_DRIVER', '');
    if ($envDriver !== '') {
        $storageSiteConfig['storage_driver'] = $envDriver;
    }

    $envConfigJson = env('STORAGE_CONFIG_JSON', '');
    if (is_string($envConfigJson) && $envConfigJson !== '') {
        $decoded = json_decode($envConfigJson, true);
        if (is_array($decoded)) {
            $storageSiteConfig = array_merge($storageSiteConfig, $decoded);
        }
    }

    $envPublicBase = (string) env('STORAGE_PUBLIC_BASE_URL', '');
    if ($envPublicBase !== '') {
        $storageSiteConfig['storage_public_base_url'] = $envPublicBase;
    }

    $envVisibility = (string) env('STORAGE_DEFAULT_VISIBILITY', '');
    if ($envVisibility !== '') {
        $storageSiteConfig['storage_default_visibility'] = $envVisibility;
    }

    $envDefer = env('STORAGE_DEFER_NETWORK', null);
    if ($envDefer !== null && $envDefer !== '') {
        $storageSiteConfig['storage_defer_network'] = filter_var((string) $envDefer, FILTER_VALIDATE_BOOL);
    }
}

$localStorageRoot = null;
if (isset($uploadFile) && is_string($uploadFile) && $uploadFile !== '') {
    $localStorageRoot = dirname($uploadFile, 2);
}

$storageContext = [
    'base_url' => $base_url,
    'public_base_url' => $base_url,
    'local_root' => $localStorageRoot,
];

if (isset($storageSiteConfig['storage_default_visibility']) && $storageSiteConfig['storage_default_visibility'] !== '') {
    $storageContext['default_visibility'] = $storageSiteConfig['storage_default_visibility'];
}

if (isset($storageSiteConfig['storage_defer_network'])) {
    $storageContext['defer_network'] = (bool) $storageSiteConfig['storage_defer_network'];
}

try {
    StorageManager::boot($storageSiteConfig, $storageContext);
} catch (Throwable $storageBootstrapError) {
    if (function_exists('error_log')) {
        error_log('[StorageManager] Bootstrap fallback triggered: ' . $storageBootstrapError->getMessage());
    }

    StorageManager::boot([], $storageContext);
}

$__storageInstance = StorageManager::getInstance();
$__storagePublicBase = '';
$__storageIsRemote = false;

if ($__storageInstance instanceof StorageManager) {
    $__storagePublicBase = $__storageInstance->getPublicBaseUrl();
    $__storageIsRemote = $__storageInstance->isRemote();
}

$__storageOrigin = dz_csp_origin_from_url($__storagePublicBase);
$__siteOrigin = dz_csp_origin_from_url($base_url ?? '');

if ($__storageIsRemote && $__storageOrigin && (!$__siteOrigin || $__storageOrigin !== $__siteOrigin)) {
    dz_csp_register_source('img-src', $__storageOrigin);
    dz_csp_register_source('media-src', $__storageOrigin);
}

if (!function_exists('storage_manager')) {
    /**
     * @return StorageManager
     */
    function storage_manager()
    {
        return StorageManager::getInstance();
    }
}

if (!function_exists('storage_adapter')) {
    /**
     * @return StorageAdapterInterface
     */
    function storage_adapter()
    {
        return StorageManager::adapter();
    }
}

if (!function_exists('storage_url')) {
    /**
     * @param string $remoteKey
     * @param int|null $ttl
     * @return string
     */
    function storage_url(string $remoteKey, ?int $ttl = null)
    {
        return StorageManager::url($remoteKey, $ttl);
    }
}

$GLOBALS['storage_public_base'] = storage_manager()->getPublicBaseUrl();

$normalizeToggle = static function ($value, bool $default = false): bool {
    if ($value === null) {
        return $default;
    }
    $raw = strtolower(trim((string) $value));
    if ($raw === '') {
        return $default;
    }
    return in_array($raw, ['1', 'true', 'on', 'yes', 'enabled'], true);
};

$oneSignalAppIdDb       = isset($siteData['onesignal_app_id']) ? trim((string) $siteData['onesignal_app_id']) : '';
$oneSignalRestKeyDb     = isset($siteData['onesignal_rest_api_key']) ? (string) $siteData['onesignal_rest_api_key'] : '';
$oneSignalSafariWebIdDb = isset($siteData['onesignal_safari_web_id']) ? trim((string) $siteData['onesignal_safari_web_id']) : '';
$oneSignalAutoPromptDb  = isset($siteData['onesignal_auto_prompt']) ? $siteData['onesignal_auto_prompt'] : null;
$oneSignalWelcomeTitleDb   = isset($siteData['onesignal_welcome_title']) ? (string) $siteData['onesignal_welcome_title'] : '';
$oneSignalWelcomeMessageDb = isset($siteData['onesignal_welcome_message']) ? (string) $siteData['onesignal_welcome_message'] : '';

$envOneSignalAppId   = getenv('ONESIGNAL_APP_ID');
$envOneSignalRestKey = getenv('ONESIGNAL_REST_API_KEY');
$envOneSignalSafari  = getenv('ONESIGNAL_SAFARI_WEB_ID');
$envOneSignalAuto    = getenv('ONESIGNAL_AUTO_PROMPT');

$oneSignalAppId       = is_string($envOneSignalAppId) && $envOneSignalAppId !== '' ? trim($envOneSignalAppId) : $oneSignalAppIdDb;
$oneSignalRestKey     = is_string($envOneSignalRestKey) && $envOneSignalRestKey !== '' ? (string) $envOneSignalRestKey : $oneSignalRestKeyDb;
$oneSignalSafariWebId = is_string($envOneSignalSafari) && $envOneSignalSafari !== '' ? trim($envOneSignalSafari) : $oneSignalSafariWebIdDb;
$oneSignalAutoPrompt  = is_string($envOneSignalAuto) && $envOneSignalAuto !== ''
    ? $normalizeToggle($envOneSignalAuto, true)
    : $normalizeToggle($oneSignalAutoPromptDb, true);

$oneSignalWelcomeTitle   = $oneSignalWelcomeTitleDb;
$oneSignalWelcomeMessage = $oneSignalWelcomeMessageDb;

$oneSignalEnabledRaw = $siteData['onesignal_enabled'] ?? null;
$envOneSignalEnabled = getenv('ONESIGNAL_ENABLED');
if (is_string($envOneSignalEnabled) && $envOneSignalEnabled !== '') {
    $oneSignalEnabled = $normalizeToggle($envOneSignalEnabled, false);
} else {
    $oneSignalEnabled = $normalizeToggle($oneSignalEnabledRaw, false);
}

$oneSignalHasCredentials = ($oneSignalAppId !== '') && ($oneSignalRestKey !== '');
$oneSignalActive = $oneSignalEnabled && $oneSignalHasCredentials;

$oneSignalConfig = [
    'enabled'         => $oneSignalEnabled,
    'active'          => $oneSignalActive,
    'app_id'          => $oneSignalAppId,
    'rest_api_key'    => $oneSignalRestKey,
    'safari_web_id'   => $oneSignalSafariWebId,
    'auto_prompt'     => $oneSignalAutoPrompt,
    'welcome_title'   => $oneSignalWelcomeTitle,
    'welcome_message' => $oneSignalWelcomeMessage,
];

$oneSignalClientConfig = [
    'enabled'         => $oneSignalEnabled,
    'active'          => $oneSignalActive,
    'appId'           => $oneSignalAppId,
    'safariWebId'     => $oneSignalSafariWebId,
    'autoPrompt'      => $oneSignalAutoPrompt,
    'welcomeTitle'    => $oneSignalWelcomeTitle,
    'welcomeMessage'  => $oneSignalWelcomeMessage,
];

$GLOBALS['oneSignalConfig'] = $oneSignalConfig;
$GLOBALS['oneSignalClientConfig'] = $oneSignalClientConfig;

$smsEnabledRaw  = $siteData['sms_enabled'] ?? null;
$envSmsEnabled  = getenv('SMS_ENABLED');
$smsProviderRaw = $siteData['sms_provider'] ?? 'twilio';
$smsProvider    = is_string($smsProviderRaw) && $smsProviderRaw !== '' ? strtolower(trim($smsProviderRaw)) : 'twilio';

$dbTwilioSid   = isset($siteData['sms_twilio_sid']) ? (string) $siteData['sms_twilio_sid'] : '';
$dbTwilioToken = isset($siteData['sms_twilio_token']) ? (string) $siteData['sms_twilio_token'] : '';
$dbTwilioFrom  = isset($siteData['sms_twilio_from']) ? (string) $siteData['sms_twilio_from'] : '';
$dbSmsRate     = isset($siteData['sms_rate_limit_per_hour']) ? (int) $siteData['sms_rate_limit_per_hour'] : 30;

$envTwilioSid   = getenv('TWILIO_ACCOUNT_SID');
$envTwilioToken = getenv('TWILIO_AUTH_TOKEN');
$envTwilioFrom  = getenv('TWILIO_FROM');
$envSmsRate     = getenv('SMS_RATE_LIMIT_PER_HOUR');
$envSmsProvider = getenv('SMS_PROVIDER');

if (is_string($envSmsProvider) && $envSmsProvider !== '') {
    $smsProvider = strtolower(trim($envSmsProvider));
}

$twilioSid   = is_string($envTwilioSid) && $envTwilioSid !== '' ? trim($envTwilioSid) : $dbTwilioSid;
$twilioToken = is_string($envTwilioToken) && $envTwilioToken !== '' ? trim($envTwilioToken) : $dbTwilioToken;
$twilioFrom  = is_string($envTwilioFrom) && $envTwilioFrom !== '' ? trim($envTwilioFrom) : $dbTwilioFrom;

$smsRateLimit = $dbSmsRate > 0 ? $dbSmsRate : 30;
if (is_string($envSmsRate) && trim($envSmsRate) !== '') {
    $rate = (int) $envSmsRate;
    if ($rate > 0) {
        $smsRateLimit = $rate;
    }
}

if (is_string($envSmsEnabled) && $envSmsEnabled !== '') {
    $smsEnabled = $normalizeToggle($envSmsEnabled, false);
} else {
    $smsEnabled = $normalizeToggle($smsEnabledRaw, false);
}
$smsEnabledBool = $smsEnabled;

$smsHasCredentials = $smsProvider === 'twilio' && $twilioSid !== '' && $twilioToken !== '' && $twilioFrom !== '';
$smsActive = $smsEnabledBool && $smsHasCredentials;

$smsConfig = [
    'enabled' => $smsEnabledBool,
    'active'  => $smsActive,
    'provider'=> $smsProvider,
    'twilio'  => [
        'sid'   => $twilioSid,
        'token' => $twilioToken,
        'from'  => $twilioFrom,
    ],
    'rate_limit_per_hour' => $smsRateLimit,
];

$GLOBALS['smsConfig'] = $smsConfig;
unset($normalizeToggle);

$GLOBALS['__MAINTENANCE_MODE_STATUS'] = $maintenanceModStatus;

$isAdminUser = false;

$stripeSecret = $siteData['stripe_secret'] ?? NULL;
$stripeWebhookSecret = $siteData['stripe_webhook_secret'] ?? NULL;
$currency = $siteData['payments_currency'] ?? 'USD';
$currencyFormatSettings = dz_currency_normalize_settings($siteData);
$currencySymbolDefault = '';
if (isset($currencies) && is_array($currencies) && isset($currencies[strtoupper((string) $currency)])) {
    $currencySymbolDefault = (string) $currencies[strtoupper((string) $currency)];
} elseif (isset($currencys) && is_array($currencys) && isset($currencys[strtoupper((string) $currency)])) {
    $currencySymbolDefault = (string) $currencys[strtoupper((string) $currency)];
}
$currencyFormatClient = dz_currency_settings_for_js($currencyFormatSettings, (string) $currency, $currencySymbolDefault);
$GLOBALS['currency_format_settings'] = $currencyFormatSettings;
$GLOBALS['currency_format_client'] = $currencyFormatClient;
// Provider-specific currency codes (fallback to global payments currency)
$globalCurCode   = (string)$currency;
$stripeCurCode   = isset($siteData['stripe_currency']) ? (string)$siteData['stripe_currency'] : (string)$currency;
$paypalCurCode   = isset($siteData['paypal_currency']) ? (string)$siteData['paypal_currency'] : (string)$currency;
$nowpayCurCode   = isset($siteData['now_payment_currency']) ? (string)$siteData['now_payment_currency'] : (string)$currency;
$coinbaseCurCode = isset($siteData['coinbase_currency']) ? (string)$siteData['coinbase_currency'] : (string)$currency;
$flutterwaveCurCode = isset($siteData['flutterwave_currency']) ? (string)$siteData['flutterwave_currency'] : (string)$currency;
$paystackCurCode = isset($siteData['paystack_currency']) ? (string)$siteData['paystack_currency'] : (string)$currency;
$iyzicoCurCode   = isset($siteData['iyzico_currency']) ? (string)$siteData['iyzico_currency'] : (string)$currency;
$payuCurCode     = isset($siteData['payu_currency']) ? (string)$siteData['payu_currency'] : (string)$currency;
$imagePostsStatus = (string) ($siteData['image_posts_status'] ?? 'open');
$videoPostsStatus = (string) ($siteData['video_posts_status'] ?? 'open');
$adsStatus        = (string) ($siteData['ads_status'] ?? 'open');
$suggestedUsersStatus = (string) ($siteData['suggested_users_status'] ?? 'open');
$suggestedUsersLimit  = isset($siteData['suggested_users_limit']) ? (int) $siteData['suggested_users_limit'] : 5;
$suggestedUsersLimit = max(1, min(20, $suggestedUsersLimit));
$suggestedUsersReload = (string) ($siteData['suggested_users_reload'] ?? 'open');
$suggestedUsersModeRaw = (string) ($siteData['suggested_users_mode'] ?? 'creators');
$suggestedUsersMode = in_array($suggestedUsersModeRaw, ['creators', 'users', 'mixed'], true) ? $suggestedUsersModeRaw : 'creators';
$minimumAdsAmount = '10';

$paypalClientId                     = $siteData['paypal_client_id'] ?? null;
$paypalClientSecret                 = $siteData['paypal_client_secret'] ?? null;
$paypalEnv                          = $siteData['paypal_env'] ?? 'sandbox';

$nowpaymentsApiKey                  = $siteData['nowpayments_api_key'] ?? null;
// Optional NOWPayments webhook secret (DB fallback)
$nowpaymentsWebhookSecret           = $siteData['nowpayment_webhook_secret_key'] ?? ($siteData['nowpayments_webhook_secret'] ?? null);

$coinbaseCommerceApiKey             = $siteData['coinbase_commerce_api_key'] ?? null;
$coinbaseCommerceWebhookSecret      = $siteData['coinbase_commerce_webhook_secret'] ?? null;
$flutterwavePublicKey               = $siteData['flutterwave_public_key'] ?? null;
$flutterwaveSecretKey               = $siteData['flutterwave_secret_key'] ?? null;
$flutterwaveEncryptionKey           = $siteData['flutterwave_encryption_key'] ?? null;
$flutterwaveSecretHash              = $siteData['flutterwave_secret_hash'] ?? null;
$paystackPublicKey                  = $siteData['paystack_public_key'] ?? null;
$paystackSecretKey                  = $siteData['paystack_secret_key'] ?? null;
$paystackWebhookSecret              = $siteData['paystack_webhook_secret'] ?? null;
$paystackMerchantEmail              = $siteData['paystack_merchant_email'] ?? null;
$iyzicoApiKey                       = $siteData['iyzico_api_key'] ?? null;
$iyzicoSecretKey                    = $siteData['iyzico_secret_key'] ?? null;
$iyzicoWebhookSecret                = $siteData['iyzico_webhook_secret'] ?? null;
$payuPosId                          = $siteData['payu_merchant_pos_id'] ?? null;
$payuMerchantId                     = $siteData['payu_merchant_id'] ?? null;
$payuClientId                       = $siteData['payu_client_id'] ?? null;
$payuClientSecret                   = $siteData['payu_client_secret'] ?? null;
$payuSignatureKey                   = $siteData['payu_signature_key'] ?? null;
$payuApiBase                        = $siteData['payu_api_base'] ?? null;

// Payment method statuses (enum open/close; default: close). Backward compat: accept 1/0 and enable_*.
$__toBool = static function($v): bool {
    $s = strtolower((string)$v);
    if ($s === 'open') return true;
    if ($s === 'close') return false;
    return in_array($s, ['1','true','on','yes'], true);
};
$stripeStatus     = (string)($siteData['stripe_status']     ?? ($siteData['enable_stripe']     ?? 'close'));
$paypalStatus     = (string)($siteData['paypal_status']     ?? ($siteData['enable_paypal']     ?? 'close'));
$nowpaymentStatus = (string)($siteData['nowpayment_status'] ?? ($siteData['enable_nowpayments']?? 'close'));
$coinbaseStatus   = (string)($siteData['coinbase_status']   ?? ($siteData['enable_coinbase']   ?? 'close'));
$flutterwaveStatus = (string)($siteData['flutterwave_status'] ?? 'close');
$paystackStatus   = (string)($siteData['paystack_status']   ?? 'close');
$iyzicoStatus     = (string)($siteData['iyzico_status']     ?? 'close');
$payuStatus       = (string)($siteData['payu_status']       ?? 'close');
$enableImagePosts   = $__toBool($imagePostsStatus) ? 1 : 0;
$enableVideoPosts   = $__toBool($videoPostsStatus) ? 1 : 0;
$enableAds          = $__toBool($adsStatus) ? 1 : 0;
$enableSuggestedUsers = $__toBool($suggestedUsersStatus) ? 1 : 0;
$enableSuggestedUsersReload = $__toBool($suggestedUsersReload) ? 1 : 0;
$suggestedUsersConfig = [
    'enabled'     => (bool) $enableSuggestedUsers,
    'limit'       => $suggestedUsersLimit,
    'allow_reload'=> (bool) $enableSuggestedUsersReload,
    'mode'        => $suggestedUsersMode,
];
$GLOBALS['suggestedUsersConfig'] = $suggestedUsersConfig;
$enableStripe        = $__toBool($stripeStatus) ? 1 : 0;
$enablePaypal        = $__toBool($paypalStatus) ? 1 : 0;
$enableNowpayments   = $__toBool($nowpaymentStatus) ? 1 : 0;
$enableCoinbase      = $__toBool($coinbaseStatus) ? 1 : 0;
$enableFlutterwave   = $__toBool($flutterwaveStatus) ? 1 : 0;
$enablePaystack      = $__toBool($paystackStatus) ? 1 : 0;
$enableIyziCo        = $__toBool($iyzicoStatus) ? 1 : 0;
$enablePayu          = $__toBool($payuStatus) ? 1 : 0;
$postApprovalRequiredRaw = isset($siteData['post_approval_required'])
    ? strtolower((string)$siteData['post_approval_required'])
    : 'close';
$postApprovalRequired = ($postApprovalRequiredRaw === 'open');
try {
    $db->exec("ALTER TABLE i_user_posts ADD COLUMN IF NOT EXISTS approval_status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved'");
    $db->exec("ALTER TABLE i_user_posts ADD COLUMN IF NOT EXISTS approval_notes TEXT NULL");
    $db->exec("ALTER TABLE i_user_posts ADD COLUMN IF NOT EXISTS approved_at INT NULL");
    $db->exec("ALTER TABLE i_user_posts ADD COLUMN IF NOT EXISTS approved_by INT NULL");
    $db->exec("ALTER TABLE i_user_posts ADD INDEX idx_approval_status (approval_status, post_created_time)");
} catch (Throwable $__) {}
$siteAnnouncement = null;
try {
    $announcementRow = $RL->RL_GetActiveAnnouncement();
    if (is_array($announcementRow) && !empty($announcementRow['message'])) {
        $messageText = trim((string)($announcementRow['message'] ?? ''));
        $siteAnnouncement = [
            'id'          => (int)($announcementRow['id'] ?? 0),
            'message'     => $messageText,
            'allow_close' => (int)($announcementRow['allow_close'] ?? 1) === 1,
            'title'       => (string)($announcementRow['title'] ?? ''),
            'cta_label'   => (string)($announcementRow['cta_label'] ?? ''),
            'cta_url'     => (string)($announcementRow['cta_url'] ?? ''),
            'image_path'  => (string)($announcementRow['image_path'] ?? ''),
        ];
        if ($siteAnnouncement['id'] <= 0 || $siteAnnouncement['message'] === '') {
            $siteAnnouncement = null;
        }
    }
} catch (Throwable $e) {
    if (defined('APP_DEBUG') && APP_DEBUG === true) {
        error_log('Load announcement failed: ' . $e->getMessage());
    }
    $siteAnnouncement = null;
}

$GLOBALS['postApprovalRequired'] = (bool) $postApprovalRequired;


$globalCurCode  = isset($currency) ? (string)$currency : 'USD';
$stripeCurCode  = isset($siteData['stripe_currency']) ? (string)$siteData['stripe_currency'] : $globalCurCode;
$paypalCurCode  = isset($siteData['paypal_currency']) ? (string)$siteData['paypal_currency'] : $globalCurCode;
$nowpayCurCode  = isset($siteData['now_payment_currency']) ? (string)$siteData['now_payment_currency'] : $globalCurCode;
$coinbaseCurCode= isset($siteData['coinbase_currency']) ? (string)$siteData['coinbase_currency'] : $globalCurCode;
$flutterwaveCurCode= isset($siteData['flutterwave_currency']) ? (string)$siteData['flutterwave_currency'] : $globalCurCode;
$paystackCurCode = isset($siteData['paystack_currency']) ? (string)$siteData['paystack_currency'] : $globalCurCode;
$iyzicoCurCode   = isset($siteData['iyzico_currency']) ? (string)$siteData['iyzico_currency'] : $globalCurCode;
$payuCurCode     = isset($siteData['payu_currency']) ? (string)$siteData['payu_currency'] : $globalCurCode;

// Admin-defined fee & tax settings (apply to reporting/estimates)
$paymentFeePercent = isset($siteData['payment_fee_percent']) ? (float)$siteData['payment_fee_percent'] : 0.0; // e.g., 2.9
$paymentFeeFixed   = isset($siteData['payment_fee_fixed']) ? (float)$siteData['payment_fee_fixed'] : 0.0;     // e.g., 0.30
$paymentTaxPercent = isset($siteData['payment_tax_percent']) ? (float)$siteData['payment_tax_percent'] : 0.0; // e.g., 18.0

$scriptVersion = $siteData['script_version'] ?? NULL;
$version = generateRandomKey();

// --- Live Streaming (Agora) configuration (managed via admin panel) ---
// Note: Values are loaded from i_site_configurations via RL_configs().
// If not set yet, they remain null and frontend falls back to placeholders.

// --- DB defaults ---
$agoraAppId         = isset($siteData['agora_app_id']) ? (string)$siteData['agora_app_id'] : null;
$agoraAppCert       = isset($siteData['agora_app_certificate']) ? (string)$siteData['agora_app_certificate'] : null;
$agoraRegion        = isset($siteData['agora_region']) ? (string)$siteData['agora_region'] : 'GLOBAL';
$agoraTokenExpire   = isset($siteData['agora_token_expire_seconds']) ? (int)$siteData['agora_token_expire_seconds'] : 7200; // 2h
$agoraEnableRTM     = isset($siteData['agora_enable_rtm']) ? (bool)$siteData['agora_enable_rtm'] : false;
$agoraAllowTokenless= isset($siteData['agora_allow_tokenless']) ? (bool)$siteData['agora_allow_tokenless'] : false; // temp compat
$agoraSource        = 'db';
$configBool = static function ($value, bool $default = false): bool {
    if ($value === null) {
        return $default;
    }
    if (is_bool($value)) {
        return $value;
    }
    $normalized = strtolower(trim((string)$value));
    if ($normalized === '') {
        return $default;
    }
    return in_array($normalized, ['1', 'true', 'yes', 'on', 'enabled'], true);
};

$liveStreamingEnabled = $configBool($siteData['live_streaming_enabled'] ?? null, true);
$liveChatEnabled = $configBool($siteData['live_chat_enabled'] ?? null, true);
$liveViewerLimit = isset($siteData['live_viewer_limit']) ? (int)$siteData['live_viewer_limit'] : 0;
if ($liveViewerLimit < 0) { $liveViewerLimit = 0; }
$liveTitlePrefix = (string)($siteData['live_title_prefix'] ?? '');
$audioRoomsEnabled = $configBool($siteData['audio_rooms_enabled'] ?? null, true);
$audioRoomChatEnabled = $configBool($siteData['audio_room_chat_enabled'] ?? null, true);
$audioRoomPaidEnabled = $configBool($siteData['audio_room_paid_enabled'] ?? null, true);
$audioRoomCustomPriceEnabled = $configBool($siteData['audio_room_custom_price_enabled'] ?? null, true);
$audioRoomPricePresetsRaw = (string)($siteData['audio_room_price_presets'] ?? '5,10,15,20');
$audioRoomPricePresets = [];
foreach (preg_split('/[,;\s]+/', $audioRoomPricePresetsRaw) ?: [] as $presetValue) {
    if ($presetValue === '' || !is_numeric($presetValue)) {
        continue;
    }
    $amount = round((float)$presetValue, 2);
    if ($amount > 0) {
        $audioRoomPricePresets[] = $amount;
    }
}
if (!$audioRoomPricePresets) {
    $audioRoomPricePresets = [5.0, 10.0, 15.0, 20.0];
}
$audioRoomPriceMinimum = isset($siteData['audio_room_price_minimum']) ? (float)$siteData['audio_room_price_minimum'] : 1.0;
$audioRoomPriceMaximum = isset($siteData['audio_room_price_maximum']) ? (float)$siteData['audio_room_price_maximum'] : 500.0;
if ($audioRoomPriceMinimum < 0) { $audioRoomPriceMinimum = 0.0; }
if ($audioRoomPriceMaximum < $audioRoomPriceMinimum) { $audioRoomPriceMaximum = $audioRoomPriceMinimum; }
$audioRoomNonCreatorDailyMinutes = isset($siteData['audio_room_non_creator_daily_minutes']) ? (int)$siteData['audio_room_non_creator_daily_minutes'] : 60;
if ($audioRoomNonCreatorDailyMinutes < 0) { $audioRoomNonCreatorDailyMinutes = 0; }
$audioRoomMaxSpeakers = isset($siteData['audio_room_max_speakers']) ? (int)$siteData['audio_room_max_speakers'] : 12;
if ($audioRoomMaxSpeakers <= 0) { $audioRoomMaxSpeakers = 12; }
$audioRoomMaxListeners = isset($siteData['audio_room_max_listeners']) ? (int)$siteData['audio_room_max_listeners'] : 0;
if ($audioRoomMaxListeners < 0) { $audioRoomMaxListeners = 0; }
$audioRoomTitlePrefix = (string)($siteData['audio_room_title_prefix'] ?? '');
$ebooksEnabled = $configBool($siteData['ebooks_enabled'] ?? null, true);
$ebookCreatorUploadsEnabled = $configBool($siteData['ebook_creator_uploads_enabled'] ?? null, true);
$GLOBALS['ebooksEnabled'] = $ebooksEnabled;
$GLOBALS['ebookCreatorUploadsEnabled'] = $ebookCreatorUploadsEnabled;
$agoraReadOnlyToken = (string)($siteData['agora_readonly_token'] ?? '');
if ($agoraReadOnlyToken === '') {
    $agoraReadOnlyToken = null;
}

if (($liveStreamingEnabled || $audioRoomsEnabled) && function_exists('dz_csp_register_source')) {
    foreach ([
        'https://*.agora.io',
        'https://*.sd-rtn.com',
        'wss://*.agora.io',
        'wss://*.agora.io:*',
        'wss://*.sd-rtn.com',
        'wss://*.sd-rtn.com:*',
    ] as $agoraCspSource) {
        dz_csp_register_source('connect-src', $agoraCspSource);
    }
}


if (isset($_COOKIE[$cookieName])) {
    $loggedIn   = '1';
    $sessionKey = $_COOKIE[$cookieName];
    $userID = $RL->RL_GetUserIDFromSessionKey($sessionKey);
    if($userID){
        $userData = $RL->RL_GetUserDetails($userID);
        // If user is banned (optional column), force logout locally and redirect home
        if (isset($userData['is_banned']) && (int)$userData['is_banned'] === 1) {
            $hashToDelete = $_COOKIE[$cookieName] ?? null;
            if (!empty($hashToDelete)) {
                try {
                    $stDel = $db->prepare("DELETE FROM i_sessions WHERE session_key = :k");
                    $stDel->execute([':k' => $hashToDelete]);
                } catch (Throwable $___) {}
            }
            if (function_exists('clearSecureCookie')) {
                clearSecureCookie($cookieName);
                clearSecureCookie('fb_access_token');
            } else {
                setcookie($cookieName, '', time() - 31556926, '/');
                setcookie('fb_access_token', '', time() - 3600, '/');
            }
            unset($_COOKIE[$cookieName]);
            session_destroy();
            header("Location: $base_url");
            exit();
        }
        $avatarRelative = (string) $RL->RL_userAvatar($userID);
        if (function_exists('storage_resolve_media_url')) {
            $defaultUserAvatar = storage_resolve_media_url($avatarRelative, $base_url ?? '');
        } else {
            $defaultUserAvatar = (string)($base_url ?? '') . ltrim($avatarRelative, '/');
        }
        $dataUsername = $userData['username'] ?? null;
        $dataUserFullName = $userData['user_fullname'] ?? null;
        $dataUserBio = $userData['about_me'] ?? null;
        $subscriptionStatus = $userData['subscrition_status'] ?? NULL;
        $userWallet = $userData['wallet'] ?? '0';
        $userEarned = $userData['earned'] ?? '0';
        $billignDataFirstName = $userData['for_billing_first_name'] ?? NULL;
        $billignDataLastName = $userData['for_billing_last_name'] ?? NULL;
        $billignDataCountry = $userData['for_billing_country'] ?? NULL;
        $billignDataCity = $userData['for_billing_city'] ?? NULL;
        $billignDataState = $userData['for_billing_state'] ?? NULL;
        $billignDataPostCode = $userData['for_billing_postcode'] ?? NULL;
        $billignDataAddress = $userData['for_billing_address'] ?? NULL;
        $userMode = $userData['user_mode'] ?? NULL;
        $userTypeNumeric = isset($userData['user_type']) ? (int) $userData['user_type'] : 0;
        if (is_string($userMode) && $userMode !== '') {
            $normalizedMode = strtolower(trim($userMode));
            $walletAdminRoles = ['admin', 'owner', 'super_admin', 'superadmin', 'superuser'];
            if (in_array($normalizedMode, $walletAdminRoles, true)) {
                $isAdminUser = true;
            }
        }
        if (!$isAdminUser && $userTypeNumeric >= 3) {
            $isAdminUser = true;
        }
        $creatorStatus = strtolower((string)($userData['creator_status'] ?? 'none'));
        $creatorStatusUpdatedAt = isset($userData['creator_status_updated_at']) ? (int)$userData['creator_status_updated_at'] : 0;
        try {
            $creatorVerification = method_exists($RL, 'RL_GetCreatorVerificationRequest') ? $RL->RL_GetCreatorVerificationRequest((int)$userID) : [];
        } catch (Throwable $__) {
            $creatorVerification = [];
        }
        try {
            $creatorPayout = method_exists($RL, 'RL_GetUserPayoutPreferences') ? $RL->RL_GetUserPayoutPreferences((int)$userID) : ['method' => 'none', 'details' => []];
        } catch (Throwable $__) {
            $creatorPayout = ['method' => 'none', 'details' => []];
        }

        if (isset($GLOBALS['oneSignalClientConfig']) && is_array($GLOBALS['oneSignalClientConfig'])) {
            $clientCfg = $GLOBALS['oneSignalClientConfig'];
            $clientCfg['user'] = [
                'id'       => (int) $userID,
                'username' => isset($userData['username']) ? (string) $userData['username'] : '',
            ];
            $GLOBALS['oneSignalClientConfig'] = $clientCfg;
        }

        $defaultPayoutMethod    = 'none';
        $availablePayoutMethods = [];
        $connectedPayoutMethods = [];
        $userBankInfo           = [];
        $withdrawalRequests     = [];
        $withdrawalSummary      = [];
        $walletSummary          = ['available' => (float) ($userEarned ?? 0), 'currency' => $currency ?? 'USD'];

        try {
            if (method_exists($RL, 'RL_GetUserPayoutDetails')) {
                $payoutDetails = $RL->RL_GetUserPayoutDetails((int) $userID);
                $methodsRaw = isset($payoutDetails['methods']) && is_array($payoutDetails['methods']) ? $payoutDetails['methods'] : [];
                if ($methodsRaw) {
                    $userBankInfo = isset($methodsRaw['bank']) && is_array($methodsRaw['bank']) ? $methodsRaw['bank'] : [];
                }
                if (!empty($payoutDetails['default_method'])) {
                    $defaultPayoutMethod = (string) $payoutDetails['default_method'];
                }
                if (!empty($payoutDetails['connected']) && is_array($payoutDetails['connected'])) {
                    $connectedPayoutMethods = $payoutDetails['connected'];
                }

                $statusAllowList = ['pending', 'processing', 'review', 'approved', 'verified', 'rejected', 'failed', 'none'];
                $methodLabels = [
                    'bank'     => [
                        'label' => customLang('settings_payout_bank_title', 'Bank transfer'),
                        'description' => customLang('settings_payout_bank_desc', 'Receive funds directly to your bank account using the banking details you provided.'),
                    ],
                    'stripe'   => [
                        'label' => customLang('settings_payout_stripe_title', 'Stripe Connect'),
                        'description' => customLang('settings_payout_stripe_desc', 'Connect your Stripe account to receive payouts instantly.'),
                    ],
                    'payoneer' => [
                        'label' => customLang('settings_payout_payoneer_title', 'Payoneer'),
                        'description' => customLang('settings_payout_payoneer_desc', 'Link your Payoneer account for cross-border payouts.'),
                    ],
                    'paypal'   => [
                        'label' => 'PayPal',
                        'description' => customLang('settings_payout_paypal_desc', 'Accept payouts to your verified PayPal account in supported currencies.'),
                    ],
                ];

                $prioritySeed = 1;
                foreach ($methodLabels as $methodKey => $meta) {
                    $payload = isset($methodsRaw[$methodKey]) && is_array($methodsRaw[$methodKey]) ? $methodsRaw[$methodKey] : [];
                    $hasSubmission = false;
                    if (!empty($payload)) {
                        foreach ($payload as $fieldKey => $fieldValue) {
                            if (in_array($fieldKey, ['status','priority','updated_at','status_updated_at','admin_note','reviewed_at','reviewed_by','requires_update','history'], true)) {
                                continue;
                            }
                            if (is_array($fieldValue)) {
                                foreach ($fieldValue as $nestedValue) {
                                    if (is_string($nestedValue)) {
                                        if (trim($nestedValue) !== '') { $hasSubmission = true; break 2; }
                                    } elseif ($nestedValue !== null && $nestedValue !== '') {
                                        $hasSubmission = true; break 2;
                                    }
                                }
                                continue;
                            }
                            if (is_string($fieldValue)) {
                                if (trim($fieldValue) !== '') { $hasSubmission = true; break; }
                            } elseif ($fieldValue !== null && $fieldValue !== '') {
                                $hasSubmission = true; break;
                            }
                        }
                    }
                    if ($methodKey === 'paypal' && empty($payload['email']) && !empty($payload['paypal_email'])) {
                        $payload['email'] = (string) $payload['paypal_email'];
                    }
                    if ($methodKey === 'payoneer' && empty($payload['email']) && !empty($payload['payoneer_email'])) {
                        $payload['email'] = (string) $payload['payoneer_email'];
                    }
                    $connected = !empty($connectedPayoutMethods[$methodKey]);
                    $statusRaw = isset($payload['status']) && is_string($payload['status']) ? strtolower($payload['status']) : '';
                    if ($hasSubmission && in_array($statusRaw, $statusAllowList, true)) {
                        $status = $statusRaw;
                    } elseif ($hasSubmission) {
                        $status = 'pending';
                    } else {
                        $status = 'none';
                    }
                    $updatedAt = isset($payload['updated_at']) && is_numeric($payload['updated_at'])
                        ? (int) $payload['updated_at']
                        : null;
                    $priority = isset($payload['priority']) && is_numeric($payload['priority'])
                        ? (int) $payload['priority']
                        : $prioritySeed;

                    $payload['status'] = $status;
                    $payload['priority'] = $priority;
                    if ($updatedAt !== null) {
                        $payload['updated_at'] = $updatedAt;
                    }

                    $availablePayoutMethods[$methodKey] = [
                        'label'       => $meta['label'],
                        'description' => $meta['description'],
                        'connected'   => $connected,
                        'priority'    => $priority,
                        'status'      => $status,
                        'updated_at'  => $updatedAt,
                        'default'     => $defaultPayoutMethod === $methodKey,
                        'details'     => $payload,
                    ];

                    $prioritySeed++;
                }

                $creatorPayout = [
                    'method'  => $defaultPayoutMethod,
                    'details' => $methodsRaw,
                ];
            }
        } catch (Throwable $__) {
            $userBankInfo           = [];
            $availablePayoutMethods = [];
            $connectedPayoutMethods = [];
        }

        try {
            if (method_exists($RL, 'RL_ListUserWithdrawals')) {
                $withdrawalRequests = $RL->RL_ListUserWithdrawals((int) $userID, 50, 0);
                $withdrawalSummary  = method_exists($RL, 'RL_GetWithdrawalSummary')
                    ? $RL->RL_GetWithdrawalSummary((int) $userID)
                    : [];
            }
        } catch (Throwable $__) {
            $withdrawalRequests = [];
            $withdrawalSummary  = [];
        }

        try {
            $userPreferences = method_exists($RL, 'RL_GetUserPreferences') ? $RL->RL_GetUserPreferences((int) $userID) : [];
        } catch (Throwable $__) {
            $userPreferences = [];
        }

        if (!isset($userPreferences['language']) || $userPreferences['language'] === null) {
            $userPreferences['language'] = $currentLang ?? 'eng';
        }

        if (!empty($userPreferences['language']) && isset($currentLang) && $userPreferences['language'] !== $currentLang) {
            $currentLang = $userPreferences['language'];
            $lang = loadLanguage($currentLang);
            [$currentLocale, $isRTLLocale] = $applyLocaleState($currentLang);
        }
    }
} else {
    $loggedIn = '0';
    // Clear any existing session cookie
    clearSecureCookie($cookieName);

    $guestLanguageCookie = defined('GUEST_LANGUAGE_COOKIE_NAME')
        ? GUEST_LANGUAGE_COOKIE_NAME
        : 'guest_language';
    $guestLanguage = isset($_COOKIE[$guestLanguageCookie])
        ? strtolower(trim((string) $_COOKIE[$guestLanguageCookie]))
        : '';

    if (
        $guestLanguage !== '' &&
        in_array($guestLanguage, $availableLanguages, true) &&
        $guestLanguage !== $currentLang
    ) {
        $currentLang = $guestLanguage;
        $lang = loadLanguage($currentLang);
        [$currentLocale, $isRTLLocale] = $applyLocaleState($currentLang);
    }
}

if (!isset($userData)) {
    $userData = null;
}

if (!isset($userPreferences) || !is_array($userPreferences)) {
    try {
        $userPreferences = method_exists($RL, 'RL_DefaultUserPreferences') ? $RL->RL_DefaultUserPreferences() : [];
    } catch (Throwable $__) {
        $userPreferences = [];
    }
    if (!isset($userPreferences['language'])) {
        $userPreferences['language'] = $currentLang ?? 'eng';
    }
}

if (!isset($creatorStatus)) { $creatorStatus = 'none'; }
if (!isset($creatorStatusUpdatedAt)) { $creatorStatusUpdatedAt = 0; }
if (!isset($creatorVerification)) { $creatorVerification = []; }
if (!isset($creatorPayout)) { $creatorPayout = ['method' => 'none', 'details' => []]; }

$GLOBALS['isAdminUser'] = (bool) $isAdminUser;

if (isset($gtmTrackingEnabled)) {
    if ($gtmTrackingEnabled && $gtmDisableAdmins && $isAdminUser) {
        $gtmTrackingEnabled = false;
    }
    $GLOBALS['gtmId'] = $gtmId ?? '';
    $GLOBALS['gtmDisableAdmins'] = (bool) $gtmDisableAdmins;
    $GLOBALS['gtmTrackingEnabled'] = (bool) $gtmTrackingEnabled;

    if ($gtmTrackingEnabled && function_exists('dz_csp_register_source')) {
        dz_csp_register_source('script-src', 'https://www.googletagmanager.com');
        dz_csp_register_source('connect-src', 'https://www.googletagmanager.com');
        dz_csp_register_source('frame-src', 'https://www.googletagmanager.com');
        $gtmSnippetTmp = "(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','{$gtmId}');";
        $gtmHashTmp = base64_encode(hash('sha256', $gtmSnippetTmp, true));
        if ($gtmHashTmp !== '') {
            dz_csp_register_source('script-src', "'sha256-{$gtmHashTmp}'");
        }
    }
}

$maintenanceEtaRaw     = $siteData['maintenance_eta'] ?? null;
$maintenanceMessageRaw = isset($siteData['maintenance_message']) ? (string)$siteData['maintenance_message'] : '';

require_once __DIR__ . '/helpers/demo_admin_guards.php';

maintenance_guard([
    'status'      => $maintenanceModStatus,
    'eta'         => $maintenanceEtaRaw,
    'message'     => $maintenanceMessageRaw,
    'base_url'    => $base_url ?? '/',
    'theme'       => $currentTheme ?? 'default',
    'user_data'   => $userData,
    'user_mode'   => isset($userMode) ? $userMode : null,
    'locale'      => $currentLang ?? 'eng',
    'site_data'   => $siteData,
]);
?>
