<?php
declare(strict_types=1);

namespace CreatorPulse\Services;

use BaconQrCode\Renderer\GDLibRenderer;
use BaconQrCode\Writer;

final class QrRenderer
{
    /**
     * Render otpauth payload to PNG (white bg, black modules, quiet >= 4).
     */
    public static function renderPng(string $payload, int $size = 300, int $quiet = 4): string
    {
        $size = max(300, $size);
        $quiet = max(4, $quiet);

        $renderer = new GDLibRenderer($size, $quiet, 'png', 9);

        return (new Writer($renderer))->writeString($payload);
    }
}
