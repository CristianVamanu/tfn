<?php
declare(strict_types=1);

final class EnvLoader
{
    public static function load(string $path): void
    {
        if (!is_file($path) || !is_readable($path)) {
            return;
        }
        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#') || str_starts_with($line, ';')) {
                continue;
            }
            // Support KEY=VALUE and quoted values
            $parts = explode('=', $line, 2);
            if (count($parts) !== 2) { continue; }
            $key = trim($parts[0]);
            $val = trim($parts[1]);
            if ($val !== '' && ($val[0] === '"' || $val[0] === '\'')) {
                $val = trim($val, "\"' ");
            }
            // Do not overwrite if already set in process env
            if (getenv($key) === false) {
                putenv($key . '=' . $val);
                $_ENV[$key] = $val;
                $_SERVER[$key] = $val;
            }
        }
    }
}

if (!function_exists('env')) {
    /**
     * Lightweight env() helper without PHP 8-only type hints so it also works on PHP 7.4.
     *
     * @param string $key
     * @param mixed  $default
     * @return mixed
     */
    function env(string $key, $default = null)
    {
        $v = getenv($key);
        return ($v === false) ? $default : $v;
    }
}
