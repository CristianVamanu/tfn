Payments Quick Reference
========================

Stripe Webhooks and Modes
-------------------------

* Configure Stripe credentials via the Admin panel or set the environment variables `STRIPE_SECRET` and `STRIPE_WEBHOOK_SECRET`.
* Use `sk_test_...` + `whsec_...` for sandbox flows, `sk_live_...` + live signing secret for production.
* When `APP_DEBUG=true`, webhook traces are appended to `CreatorPulse/payments_debug.log`.
* Webhook verification always happens on the raw request body with a 5‑minute timestamp tolerance.

Flutterwave Setup
-----------------

* Env vars supported by `PaymentConfigResolver`:
  * `FLUTTERWAVE_PUBLIC_KEY`
  * `FLUTTERWAVE_SECRET_KEY`
  * `FLUTTERWAVE_ENCRYPTION_KEY`
  * `FLUTTERWAVE_SECRET_HASH` (used to validate `verif-hash` headers)
  * `FLUTTERWAVE_CURRENCY` (falls back to the site/global currency)
  * Optional: `FLUTTERWAVE_API_BASE` for custom endpoints.
* Webhook URL: `https://{your-domain}/request/webhooks.php?provider=flutterwave`.
* In the Flutterwave dashboard, set the **Secret Hash** to the same value stored in the Admin panel or `FLUTTERWAVE_SECRET_HASH`.
* Payment plans: Flutterwave supports `daily`, `weekly`, `monthly`, and `yearly` intervals. Half‑year or custom multiples are not exposed; users should select monthly/yearly plans when using Flutterwave subscriptions.

Sandbox Testing Checklist
-------------------------

### Wallet Top-ups

1. Enable at least one provider (Stripe/PayPal/Flutterwave/etc.) in **Admin → Settings → Payments**.
2. Configure the sandbox keys (e.g., `sk_test_` for Stripe, PayPal Sandbox REST App, Flutterwave test keys).
3. Trigger **Settings → Wallet Top-up** in the UI, choose the provider, and complete the checkout.
4. Confirm the corresponding webhook fires:
   * `request/webhooks.php?provider=stripe`
   * `?provider=paypal`
   * `?provider=flutterwave` (verifies `verif-hash`)
5. Verify that the wallet ledger row is marked `succeeded` (`RL_CreditWalletTopupByReference`).

### Tips / Live Tips

1. Open any post or live session, click **Send Tip**.
2. Test each enabled provider (Stripe Checkout, PayPal, Flutterwave). For crypto providers (NOWPayments/Coinbase), use the sandbox/test endpoints.
3. Ensure metadata contains `type=tip`, `buyer_id`, and Flutterwave receives `buyer_email/buyer_name`.
4. Verify that `RL_RecordTip` (via `RL_RecordTipPayment` / webhook) marks the tip as completed and notifications fire.

### Premium Post Purchases

1. Set a premium price on a post, then use **Unlock / Purchase** from another account.
2. Complete the checkout with each provider you intend to support (Stripe, PayPal, Flutterwave, crypto gateways).
3. Confirm `request/webhooks.php` updates the `i_post_purchases` entry to `succeeded`, including fee/tax/net breakdowns. For Flutterwave, the webhook delivers `data.amount`, `charged_amount`, and `app_fee`.
4. Validate that the post becomes accessible immediately after wallet or external provider completion.

### Subscriptions

1. Creator must have subscription plans enabled. For Flutterwave, only `weekly`, `monthly`, and `yearly` intervals are allowed.
2. Run through subscription checkout for Stripe, PayPal, and Flutterwave (which creates a payment plan via `/v3/payment-plans` + `/v3/payments`).
3. Webhooks to watch:
   * Stripe: `checkout.session.completed`, `invoice.payment_succeeded`, `customer.subscription.updated/deleted`.
   * PayPal: `BILLING.SUBSCRIPTION.*`.
   * Flutterwave: `charge.completed`, `subscription.activated`, `subscription.renewed`, `subscription.cancelled`.
4. Confirm `i_subscription_payments` rows transition from `pending` → `succeeded`, and cancellations downgrade access (`RL_UpdateSubscriptionStatusByReference`).

IyziCo Setup
-------------

* Env vars supported by `PaymentConfigResolver`:
  * `IYZICO_API_KEY`
  * `IYZICO_SECRET_KEY`
  * `IYZICO_WEBHOOK_SECRET`
  * Optional: `IYZICO_CURRENCY`, `IYZICO_API_BASE`
* Webhook URL: `https://{your-domain}/request/webhooks.php?provider=iyzico`
* Override the sandbox base URL via `IYZICO_API_BASE` if you need a non-default endpoint; leave empty to use the standard host.
* IyziCo requires a buyer email for checkout initialization and signs callbacks with the provided webhook secret/token.

PayU Setup
----------

* Env vars supported by `PaymentConfigResolver`:
  * `PAYU_MERCHANT_POS_ID`
  * `PAYU_MERCHANT_ID`
  * `PAYU_CLIENT_ID`
  * `PAYU_CLIENT_SECRET`
  * `PAYU_SIGNATURE_KEY` (Second Key)
  * Optional: `PAYU_CURRENCY`, `PAYU_API_BASE` (set to `https://secure.snd.payu.com` for sandbox)
* Webhook/notification URL: `https://{your-domain}/request/webhooks.php?provider=payu`
* The integration uses the REST Orders flow: obtains an access token, creates an order, and redirects to `redirectUri`.
* Subscriptions/recurring payments are not exposed in this integration; PayU calls will return an informative error if requested.

Testing Tips
------------

* For every provider, ensure both **success** and **failure/retry** paths are exercised. Failed webhook verification will log to `includes/functions_error.txt`.
* Use browser dev tools/network logs to capture checkout URLs when debugging provider responses.
* Always keep the Admin panel secrets masked (the backend only updates DB values when the masked field is cleared/replaced).
