<?php
declare(strict_types=1);

final class PaymentConfigResolver
{
    /**
     * Build a normalized payments config array from site config + optional overrides.
     *
     * Precedence for all secrets/keys is ENV → DB, consistently across providers.
     * Supported env vars:
     *   - Stripe: STRIPE_SECRET, STRIPE_WEBHOOK_SECRET
     *   - PayPal: PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, PAYPAL_ENV, PAYPAL_WEBHOOK_ID
     *   - NOWPayments: NOWPAYMENTS_API_KEY, NOWPAYMENTS_IPN_SECRET | NOWPAYMENTS_WEBHOOK_SECRET
     *   - Coinbase Commerce: COINBASE_COMMERCE_API_KEY, COINBASE_COMMERCE_WEBHOOK_SECRET
     *   - Paystack: PAYSTACK_PUBLIC_KEY, PAYSTACK_SECRET_KEY, PAYSTACK_WEBHOOK_SECRET, PAYSTACK_CURRENCY, PAYSTACK_MERCHANT_EMAIL
     *   - PayU: PAYU_MERCHANT_POS_ID, PAYU_MERCHANT_ID, PAYU_CLIENT_ID, PAYU_CLIENT_SECRET, PAYU_SIGNATURE_KEY (or PAYU_SECOND_KEY), PAYU_CURRENCY, PAYU_API_BASE
     *
     * @param array  $siteData  DB-backed configuration (from RL_configs())
     * @param string $baseUrl   Absolute base URL (ends with / ideally)
     * @param array  $overrides Optional context (e.g., success_url, cancel_url). Do not pass secrets here.
     *
     * Smoke test (unit-free):
     *   putenv('STRIPE_SECRET=env_sk'); $siteData['stripe_secret'] = 'db_sk';
     *   putenv('PAYPAL_CLIENT_ID=env_pid'); $siteData['paypal_client_id'] = 'db_pid';
     *   putenv('NOWPAYMENTS_API_KEY=env_np'); $siteData['nowpayments_api_key'] = 'db_np';
     *   $cfg = self::build($siteData, 'https://x/');
     *   // Expect ENV precedence:
     *   // $cfg['stripe']['secret_key'] === 'env_sk'
     *   // $cfg['paypal']['client_id']  === 'env_pid'
     *   // $cfg['nowpayments']['api_key'] === 'env_np'
     *   // Unset env → falls back to DB values.
     */
    public static function build(array $siteData, string $baseUrl, array $overrides = []): array
    {
        $baseNormalized = rtrim((string)$baseUrl, '/') . '/';

        // Currency
        $currency = 'USD';
        if (!empty($siteData['payments_currency'])) {
            $currency = (string)$siteData['payments_currency'];
        } elseif (!empty($siteData['site_currency'])) {
            $currency = (string)$siteData['site_currency'];
        }

        // Stripe — ENV → DB
        $stripeSecret = (string)(getenv('STRIPE_SECRET')
            ?: ($_ENV['STRIPE_SECRET'] ?? ($_SERVER['STRIPE_SECRET'] ?? '')));
        if ($stripeSecret === '' && isset($siteData['stripe_secret'])) {
            $stripeSecret = (string)$siteData['stripe_secret'];
        }

        // Webhook signing secret: ENV → DB
        $stripeWebhook = (string)(getenv('STRIPE_WEBHOOK_SECRET')
            ?: ($_ENV['STRIPE_WEBHOOK_SECRET'] ?? ($_SERVER['STRIPE_WEBHOOK_SECRET'] ?? '')));
        if ($stripeWebhook === '' && isset($siteData['stripe_webhook_secret'])) {
            $stripeWebhook = (string)$siteData['stripe_webhook_secret'];
        }

        // PayPal — ENV → DB
        $paypalClientId = (string)(getenv('PAYPAL_CLIENT_ID')
            ?: ($_ENV['PAYPAL_CLIENT_ID'] ?? ($_SERVER['PAYPAL_CLIENT_ID'] ?? '')));
        if ($paypalClientId === '' && isset($siteData['paypal_client_id'])) {
            $paypalClientId = (string)$siteData['paypal_client_id'];
        }
        $paypalClientSecret = (string)(getenv('PAYPAL_CLIENT_SECRET')
            ?: ($_ENV['PAYPAL_CLIENT_SECRET'] ?? ($_SERVER['PAYPAL_CLIENT_SECRET'] ?? '')));
        if ($paypalClientSecret === '' && isset($siteData['paypal_client_secret'])) {
            $paypalClientSecret = (string)$siteData['paypal_client_secret'];
        }
        $paypalEnv = (string)(getenv('PAYPAL_ENV')
            ?: ($_ENV['PAYPAL_ENV'] ?? ($_SERVER['PAYPAL_ENV'] ?? '')));
        if ($paypalEnv === '' && isset($siteData['paypal_env'])) {
            $paypalEnv = (string)$siteData['paypal_env'];
        }
        if ($paypalEnv === '') { $paypalEnv = 'sandbox'; }
        // Webhook ID: prefer env/config, fallback to DB (siteData) if present
        $paypalWebhookId    = (string)(getenv('PAYPAL_WEBHOOK_ID') ?: ($_ENV['PAYPAL_WEBHOOK_ID'] ?? ($_SERVER['PAYPAL_WEBHOOK_ID'] ?? '')));
        if ($paypalWebhookId === '' && isset($siteData['paypal_webhook_id'])) {
            $paypalWebhookId = (string)$siteData['paypal_webhook_id'];
        }

        // NOWPayments — ENV → DB
        $npApiKey = (string)(getenv('NOWPAYMENTS_API_KEY')
            ?: ($_ENV['NOWPAYMENTS_API_KEY'] ?? ($_SERVER['NOWPAYMENTS_API_KEY'] ?? '')));
        if ($npApiKey === '' && isset($siteData['nowpayments_api_key'])) {
            $npApiKey = (string)$siteData['nowpayments_api_key'];
        }
        // Webhook/IPN secret: ENV first (NOWPAYMENTS_IPN_SECRET or NOWPAYMENTS_WEBHOOK_SECRET), fallback to admin/DB
        $npWebhook = (string)(getenv('NOWPAYMENTS_IPN_SECRET')
            ?: ($_ENV['NOWPAYMENTS_IPN_SECRET'] ?? ($_SERVER['NOWPAYMENTS_IPN_SECRET'] ?? '')));
        if ($npWebhook === '') {
            $npWebhook = (string)(getenv('NOWPAYMENTS_WEBHOOK_SECRET')
                ?: ($_ENV['NOWPAYMENTS_WEBHOOK_SECRET'] ?? ($_SERVER['NOWPAYMENTS_WEBHOOK_SECRET'] ?? '')));
        }
        if ($npWebhook === '' && isset($siteData['nowpayment_webhook_secret_key'])) {
            $npWebhook = (string)$siteData['nowpayment_webhook_secret_key'];
        }
        if ($npWebhook === '' && isset($siteData['nowpayments_webhook_secret'])) {
            // Legacy fallback for installs that have not migrated column name yet
            $npWebhook = (string)$siteData['nowpayments_webhook_secret'];
        }
        $npModeEnv = (string)(getenv('NOWPAYMENTS_MODE')
            ?: ($_ENV['NOWPAYMENTS_MODE'] ?? ($_SERVER['NOWPAYMENTS_MODE'] ?? '')));
        $npMode = $npModeEnv !== '' ? strtolower($npModeEnv) : '';
        if ($npMode === '' && isset($siteData['nowpayment_mode'])) {
            $npMode = strtolower((string)$siteData['nowpayment_mode']);
        }

        // Coinbase Commerce — ENV → DB
        $cbApiKey = (string)(getenv('COINBASE_COMMERCE_API_KEY')
            ?: ($_ENV['COINBASE_COMMERCE_API_KEY'] ?? ($_SERVER['COINBASE_COMMERCE_API_KEY'] ?? '')));
        if ($cbApiKey === '' && isset($siteData['coinbase_commerce_api_key'])) {
            $cbApiKey = (string)$siteData['coinbase_commerce_api_key'];
        }
        // Secret priority: ENV first, then admin/DB fallback
        $cbWebhookSecretEnv = (string)(getenv('COINBASE_COMMERCE_WEBHOOK_SECRET')
            ?: ($_ENV['COINBASE_COMMERCE_WEBHOOK_SECRET'] ?? ($_SERVER['COINBASE_COMMERCE_WEBHOOK_SECRET'] ?? '')));
        $cbWebhookSecret = $cbWebhookSecretEnv !== ''
            ? $cbWebhookSecretEnv
            : (string)($siteData['coinbase_commerce_webhook_secret'] ?? '');

        // Flutterwave — ENV → DB
        $flutterwavePublic = isset($overrides['flutterwavePublicKey']) && $overrides['flutterwavePublicKey'] !== null
            ? (string)$overrides['flutterwavePublicKey']
            : (string)(getenv('FLUTTERWAVE_PUBLIC_KEY')
                ?: ($_ENV['FLUTTERWAVE_PUBLIC_KEY'] ?? ($_SERVER['FLUTTERWAVE_PUBLIC_KEY'] ?? '')));
        if ($flutterwavePublic === '' && isset($siteData['flutterwave_public_key'])) {
            $flutterwavePublic = (string)$siteData['flutterwave_public_key'];
        }
        $flutterwaveSecret = isset($overrides['flutterwaveSecretKey']) && $overrides['flutterwaveSecretKey'] !== null
            ? (string)$overrides['flutterwaveSecretKey']
            : (string)(getenv('FLUTTERWAVE_SECRET_KEY')
                ?: ($_ENV['FLUTTERWAVE_SECRET_KEY'] ?? ($_SERVER['FLUTTERWAVE_SECRET_KEY'] ?? '')));
        if ($flutterwaveSecret === '' && isset($siteData['flutterwave_secret_key'])) {
            $flutterwaveSecret = (string)$siteData['flutterwave_secret_key'];
        }
        $flutterwaveEncryption = isset($overrides['flutterwaveEncryptionKey']) && $overrides['flutterwaveEncryptionKey'] !== null
            ? (string)$overrides['flutterwaveEncryptionKey']
            : (string)(getenv('FLUTTERWAVE_ENCRYPTION_KEY')
                ?: ($_ENV['FLUTTERWAVE_ENCRYPTION_KEY'] ?? ($_SERVER['FLUTTERWAVE_ENCRYPTION_KEY'] ?? '')));
        if ($flutterwaveEncryption === '' && isset($siteData['flutterwave_encryption_key'])) {
            $flutterwaveEncryption = (string)$siteData['flutterwave_encryption_key'];
        }
        $flutterwaveSecretHash = isset($overrides['flutterwaveSecretHash']) && $overrides['flutterwaveSecretHash'] !== null
            ? (string)$overrides['flutterwaveSecretHash']
            : (string)(getenv('FLUTTERWAVE_SECRET_HASH')
                ?: ($_ENV['FLUTTERWAVE_SECRET_HASH'] ?? ($_SERVER['FLUTTERWAVE_SECRET_HASH'] ?? '')));
        if ($flutterwaveSecretHash === '' && isset($siteData['flutterwave_secret_hash'])) {
            $flutterwaveSecretHash = (string)$siteData['flutterwave_secret_hash'];
        }

        // URLs (allow overrides per-context)
        $successUrl = isset($overrides['success_url']) && $overrides['success_url'] !== null
            ? (string)$overrides['success_url']
            : ($baseNormalized . 'index.php?payment=success');
        $cancelUrl  = isset($overrides['cancel_url']) && $overrides['cancel_url'] !== null
            ? (string)$overrides['cancel_url']
            : ($baseNormalized . 'index.php?payment=cancel');

        // Provider enable/disable flags from DB (stripe_status/paypal_status/nowpayment_status/coinbase_status)
        // Backward compat: accept legacy enable_* if present
        $toBool = static function($v): bool {
            $s = strtolower((string)$v);
            if ($s === 'open') return true;
            if ($s === 'close') return false;
            if ($s === '') return false;
            return in_array($s, ['1','true','on','yes'], true);
        };
        $isStripeEnabled      = $toBool($siteData['stripe_status']     ?? ($siteData['enable_stripe']      ?? 'close'));
        $isPaypalEnabled      = $toBool($siteData['paypal_status']     ?? ($siteData['enable_paypal']      ?? 'close'));
        $isNowpaymentsEnabled = $toBool($siteData['nowpayment_status'] ?? ($siteData['enable_nowpayments'] ?? 'close'));
        $isCoinbaseEnabled    = $toBool($siteData['coinbase_status']   ?? ($siteData['enable_coinbase']    ?? 'close'));
        $isFlutterwaveEnabled = $toBool($siteData['flutterwave_status'] ?? 'close');
        $isPaystackEnabled    = $toBool($siteData['paystack_status'] ?? 'close');
        $isIyziCoEnabled      = $toBool($siteData['iyzico_status'] ?? 'close');
        $payuStatusEnv = getenv('PAYU_STATUS') ?: ($_ENV['PAYU_STATUS'] ?? ($_SERVER['PAYU_STATUS'] ?? ''));
        if (is_string($payuStatusEnv) && $payuStatusEnv !== '') {
            $isPayuEnabled = $toBool($payuStatusEnv);
        } else {
            $isPayuEnabled = $toBool($siteData['payu_status'] ?? 'close');
        }

        // Provider currencies: ENV → provider currency → global currency
        $stripeCurrency = (string)(getenv('STRIPE_CURRENCY') ?: ($_ENV['STRIPE_CURRENCY'] ?? ($_SERVER['STRIPE_CURRENCY'] ?? '')));
        if ($stripeCurrency === '' && isset($siteData['stripe_currency'])) { $stripeCurrency = (string)$siteData['stripe_currency']; }
        if ($stripeCurrency === '') { $stripeCurrency = $currency; }

        $paypalCurrency = (string)(getenv('PAYPAL_CURRENCY') ?: ($_ENV['PAYPAL_CURRENCY'] ?? ($_SERVER['PAYPAL_CURRENCY'] ?? '')));
        if ($paypalCurrency === '' && isset($siteData['paypal_currency'])) { $paypalCurrency = (string)$siteData['paypal_currency']; }
        if ($paypalCurrency === '') { $paypalCurrency = $currency; }

        $npCurrency = (string)(getenv('NOWPAYMENTS_CURRENCY') ?: (getenv('NOW_PAYMENT_CURRENCY') ?: ($_ENV['NOWPAYMENTS_CURRENCY'] ?? ($_SERVER['NOWPAYMENTS_CURRENCY'] ?? ''))));
        if ($npCurrency === '' && isset($siteData['now_payment_currency'])) { $npCurrency = (string)$siteData['now_payment_currency']; }
        if ($npCurrency === '') { $npCurrency = $currency; }

        $cbCurrency = (string)(getenv('COINBASE_CURRENCY') ?: ($_ENV['COINBASE_CURRENCY'] ?? ($_SERVER['COINBASE_CURRENCY'] ?? '')));
        if ($cbCurrency === '' && isset($siteData['coinbase_currency'])) { $cbCurrency = (string)$siteData['coinbase_currency']; }
        if ($cbCurrency === '') { $cbCurrency = $currency; }

        $flutterwaveCurrency = (string)(getenv('FLUTTERWAVE_CURRENCY') ?: ($_ENV['FLUTTERWAVE_CURRENCY'] ?? ($_SERVER['FLUTTERWAVE_CURRENCY'] ?? '')));
        if ($flutterwaveCurrency === '' && isset($siteData['flutterwave_currency'])) { $flutterwaveCurrency = (string)$siteData['flutterwave_currency']; }
        if ($flutterwaveCurrency === '') { $flutterwaveCurrency = $currency; }

        // IyziCo — ENV → DB
        $iyzicoApiKey = isset($overrides['iyzicoApiKey']) && $overrides['iyzicoApiKey'] !== null
            ? (string) $overrides['iyzicoApiKey']
            : (string)(getenv('IYZICO_API_KEY')
                ?: ($_ENV['IYZICO_API_KEY'] ?? ($_SERVER['IYZICO_API_KEY'] ?? '')));
        if ($iyzicoApiKey === '' && isset($siteData['iyzico_api_key'])) {
            $iyzicoApiKey = (string)$siteData['iyzico_api_key'];
        }
        $iyzicoSecretKey = isset($overrides['iyzicoSecretKey']) && $overrides['iyzicoSecretKey'] !== null
            ? (string) $overrides['iyzicoSecretKey']
            : (string)(getenv('IYZICO_SECRET_KEY')
                ?: ($_ENV['IYZICO_SECRET_KEY'] ?? ($_SERVER['IYZICO_SECRET_KEY'] ?? '')));
        if ($iyzicoSecretKey === '' && isset($siteData['iyzico_secret_key'])) {
            $iyzicoSecretKey = (string)$siteData['iyzico_secret_key'];
        }
        $iyzicoWebhookSecret = isset($overrides['iyzicoWebhookSecret']) && $overrides['iyzicoWebhookSecret'] !== null
            ? (string) $overrides['iyzicoWebhookSecret']
            : (string)(getenv('IYZICO_WEBHOOK_SECRET')
                ?: ($_ENV['IYZICO_WEBHOOK_SECRET'] ?? ($_SERVER['IYZICO_WEBHOOK_SECRET'] ?? '')));
        if ($iyzicoWebhookSecret === '' && isset($siteData['iyzico_webhook_secret'])) {
            $iyzicoWebhookSecret = (string)$siteData['iyzico_webhook_secret'];
        }
        $iyzicoCurrency = isset($overrides['iyzicoCurrency']) && $overrides['iyzicoCurrency'] !== null
            ? (string) $overrides['iyzicoCurrency']
            : (string)(getenv('IYZICO_CURRENCY') ?: ($_ENV['IYZICO_CURRENCY'] ?? ($_SERVER['IYZICO_CURRENCY'] ?? '')));
        if ($iyzicoCurrency === '' && isset($siteData['iyzico_currency'])) { $iyzicoCurrency = (string)$siteData['iyzico_currency']; }
        if ($iyzicoCurrency === '') { $iyzicoCurrency = $currency !== '' ? $currency : 'TRY'; }
        $iyzicoApiBase = isset($overrides['iyzicoApiBase']) && $overrides['iyzicoApiBase'] !== null
            ? (string) $overrides['iyzicoApiBase']
            : (string)(getenv('IYZICO_API_BASE') ?: ($_ENV['IYZICO_API_BASE'] ?? ($_SERVER['IYZICO_API_BASE'] ?? '')));
        if ($iyzicoApiBase === '' && isset($siteData['iyzico_api_base'])) {
            $iyzicoApiBase = (string) $siteData['iyzico_api_base'];
        }

        // Paystack — ENV → DB
        $paystackPublic = isset($overrides['paystackPublicKey']) && $overrides['paystackPublicKey'] !== null
            ? (string)$overrides['paystackPublicKey']
            : (string)(getenv('PAYSTACK_PUBLIC_KEY')
                ?: ($_ENV['PAYSTACK_PUBLIC_KEY'] ?? ($_SERVER['PAYSTACK_PUBLIC_KEY'] ?? '')));
        if ($paystackPublic === '' && isset($siteData['paystack_public_key'])) {
            $paystackPublic = (string)$siteData['paystack_public_key'];
        }
        $paystackSecret = isset($overrides['paystackSecretKey']) && $overrides['paystackSecretKey'] !== null
            ? (string)$overrides['paystackSecretKey']
            : (string)(getenv('PAYSTACK_SECRET_KEY')
                ?: ($_ENV['PAYSTACK_SECRET_KEY'] ?? ($_SERVER['PAYSTACK_SECRET_KEY'] ?? '')));
        if ($paystackSecret === '' && isset($siteData['paystack_secret_key'])) {
            $paystackSecret = (string)$siteData['paystack_secret_key'];
        }
        $paystackWebhook = isset($overrides['paystackWebhookSecret']) && $overrides['paystackWebhookSecret'] !== null
            ? (string)$overrides['paystackWebhookSecret']
            : (string)(getenv('PAYSTACK_WEBHOOK_SECRET')
                ?: ($_ENV['PAYSTACK_WEBHOOK_SECRET'] ?? ($_SERVER['PAYSTACK_WEBHOOK_SECRET'] ?? '')));
        if ($paystackWebhook === '' && isset($siteData['paystack_webhook_secret'])) {
            $paystackWebhook = (string)$siteData['paystack_webhook_secret'];
        }
        $paystackMerchantEmail = isset($overrides['paystackMerchantEmail']) && $overrides['paystackMerchantEmail'] !== null
            ? (string)$overrides['paystackMerchantEmail']
            : (string)(getenv('PAYSTACK_MERCHANT_EMAIL')
                ?: ($_ENV['PAYSTACK_MERCHANT_EMAIL'] ?? ($_SERVER['PAYSTACK_MERCHANT_EMAIL'] ?? '')));
        if ($paystackMerchantEmail === '' && isset($siteData['paystack_merchant_email'])) {
            $paystackMerchantEmail = (string)$siteData['paystack_merchant_email'];
        }

        $paystackCurrency = isset($overrides['paystackCurrency']) && $overrides['paystackCurrency'] !== null
            ? (string)$overrides['paystackCurrency']
            : (string)(getenv('PAYSTACK_CURRENCY')
                ?: ($_ENV['PAYSTACK_CURRENCY'] ?? ($_SERVER['PAYSTACK_CURRENCY'] ?? '')));
        if ($paystackCurrency === '' && isset($siteData['paystack_currency'])) { $paystackCurrency = (string)$siteData['paystack_currency']; }
        if ($paystackCurrency === '') { $paystackCurrency = $currency; }

        // PayU — ENV → DB
        $payuPosId = isset($overrides['payuPosId']) && $overrides['payuPosId'] !== null
            ? (string) $overrides['payuPosId']
            : (string)(getenv('PAYU_MERCHANT_POS_ID')
                ?: (getenv('PAYU_POS_ID') ?: ($_ENV['PAYU_MERCHANT_POS_ID'] ?? ($_SERVER['PAYU_MERCHANT_POS_ID'] ?? ''))));
        if ($payuPosId === '' && isset($siteData['payu_merchant_pos_id'])) {
            $payuPosId = (string)$siteData['payu_merchant_pos_id'];
        }
        $payuMerchantId = isset($overrides['payuMerchantId']) && $overrides['payuMerchantId'] !== null
            ? (string) $overrides['payuMerchantId']
            : (string)(getenv('PAYU_MERCHANT_ID') ?: ($_ENV['PAYU_MERCHANT_ID'] ?? ($_SERVER['PAYU_MERCHANT_ID'] ?? '')));
        if ($payuMerchantId === '' && isset($siteData['payu_merchant_id'])) {
            $payuMerchantId = (string)$siteData['payu_merchant_id'];
        }
        $payuClientId = isset($overrides['payuClientId']) && $overrides['payuClientId'] !== null
            ? (string) $overrides['payuClientId']
            : (string)(getenv('PAYU_CLIENT_ID') ?: ($_ENV['PAYU_CLIENT_ID'] ?? ($_SERVER['PAYU_CLIENT_ID'] ?? '')));
        if ($payuClientId === '' && isset($siteData['payu_client_id'])) {
            $payuClientId = (string)$siteData['payu_client_id'];
        }
        $payuClientSecret = isset($overrides['payuClientSecret']) && $overrides['payuClientSecret'] !== null
            ? (string) $overrides['payuClientSecret']
            : (string)(getenv('PAYU_CLIENT_SECRET') ?: ($_ENV['PAYU_CLIENT_SECRET'] ?? ($_SERVER['PAYU_CLIENT_SECRET'] ?? '')));
        if ($payuClientSecret === '' && isset($siteData['payu_client_secret'])) {
            $payuClientSecret = (string)$siteData['payu_client_secret'];
        }
        $payuSignatureKey = isset($overrides['payuSignatureKey']) && $overrides['payuSignatureKey'] !== null
            ? (string) $overrides['payuSignatureKey']
            : (string)(getenv('PAYU_SIGNATURE_KEY')
                ?: (getenv('PAYU_SECOND_KEY') ?: ($_ENV['PAYU_SIGNATURE_KEY'] ?? ($_SERVER['PAYU_SIGNATURE_KEY'] ?? ''))));
        if ($payuSignatureKey === '' && isset($siteData['payu_signature_key'])) {
            $payuSignatureKey = (string)$siteData['payu_signature_key'];
        }
        $payuCurrency = isset($overrides['payuCurrency']) && $overrides['payuCurrency'] !== null
            ? (string) $overrides['payuCurrency']
            : (string)(getenv('PAYU_CURRENCY') ?: ($_ENV['PAYU_CURRENCY'] ?? ($_SERVER['PAYU_CURRENCY'] ?? '')));
        if ($payuCurrency === '' && isset($siteData['payu_currency'])) { $payuCurrency = (string)$siteData['payu_currency']; }
        if ($payuCurrency === '') { $payuCurrency = $currency; }
        $payuApiBase = isset($overrides['payuApiBase']) && $overrides['payuApiBase'] !== null
            ? (string) $overrides['payuApiBase']
            : (string)(getenv('PAYU_API_BASE') ?: ($_ENV['PAYU_API_BASE'] ?? ($_SERVER['PAYU_API_BASE'] ?? '')));
        if ($payuApiBase === '' && isset($siteData['payu_api_base'])) {
            $payuApiBase = (string) $siteData['payu_api_base'];
        }

        return [
            'currency'    => $currency,
            'success_url' => $successUrl,
            'cancel_url'  => $cancelUrl,

            'stripe' => [
                'secret_key'     => $stripeSecret,
                'webhook_secret' => $stripeWebhook,
                'currency'       => $stripeCurrency,
                'enabled'        => $isStripeEnabled,
            ],

            'paypal' => [
                'client_id'     => $paypalClientId,
                'client_secret' => $paypalClientSecret,
                'environment'   => $paypalEnv, // sandbox | live
                'webhook_id'    => $paypalWebhookId,
                'currency'      => $paypalCurrency,
                'enabled'       => $isPaypalEnabled,
            ],

            'nowpayments' => [
                'api_key'        => $npApiKey,
                'webhook_secret' => $npWebhook,
                'currency'       => $npCurrency,
                'enabled'        => $isNowpaymentsEnabled,
                'mode'           => $npMode,
            ],

            'coinbase' => [
                'api_key'        => $cbApiKey,
                'webhook_secret' => $cbWebhookSecret,
                'currency'       => $cbCurrency,
                'enabled'        => $isCoinbaseEnabled,
            ],

            'flutterwave' => [
                'public_key'     => $flutterwavePublic,
                'secret_key'     => $flutterwaveSecret,
                'encryption_key' => $flutterwaveEncryption,
                'secret_hash'    => $flutterwaveSecretHash,
                'currency'       => $flutterwaveCurrency,
                'enabled'        => $isFlutterwaveEnabled,
            ],

            'paystack' => [
                'public_key'      => $paystackPublic,
                'secret_key'      => $paystackSecret,
                'webhook_secret'  => $paystackWebhook,
                'currency'        => $paystackCurrency,
                'merchant_email'  => $paystackMerchantEmail,
                'enabled'         => $isPaystackEnabled,
            ],

            'iyzico' => [
                'api_key'        => $iyzicoApiKey,
                'secret_key'     => $iyzicoSecretKey,
                'webhook_secret' => $iyzicoWebhookSecret,
                'currency'       => strtoupper($iyzicoCurrency),
                'api_base'       => $iyzicoApiBase,
                'enabled'        => $isIyziCoEnabled,
            ],

            'payu' => [
                'pos_id'        => $payuPosId,
                'merchant_id'   => $payuMerchantId,
                'client_id'     => $payuClientId,
                'client_secret' => $payuClientSecret,
                'signature_key' => $payuSignatureKey,
                'currency'      => strtoupper($payuCurrency),
                'api_base'      => $payuApiBase,
                'enabled'       => $isPayuEnabled,
            ],
        ];
    }
}
