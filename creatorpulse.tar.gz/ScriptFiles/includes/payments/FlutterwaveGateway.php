<?php
declare(strict_types=1);

class FlutterwaveGateway implements PaymentGatewayInterface
{
    private string $publicKey;
    private string $secretKey;
    private string $encryptionKey;
    private string $secretHash;
    private string $currency;
    private string $successUrl;
    private string $cancelUrl;
    private string $apiBase;

    public function __construct(array $config)
    {
        $provider = $config['flutterwave'] ?? [];
        $this->publicKey     = (string)($provider['public_key'] ?? '');
        $this->secretKey     = (string)($provider['secret_key'] ?? '');
        $this->encryptionKey = (string)($provider['encryption_key'] ?? '');
        $this->secretHash    = (string)($provider['secret_hash'] ?? '');
        $this->currency      = strtoupper((string)($provider['currency'] ?? ($config['currency'] ?? 'USD')));
        $this->successUrl    = (string)($config['success_url'] ?? '');
        $this->cancelUrl     = (string)($config['cancel_url'] ?? '');
        $apiBaseEnv = (string)(getenv('FLUTTERWAVE_API_BASE')
            ?: ($_ENV['FLUTTERWAVE_API_BASE'] ?? ($_SERVER['FLUTTERWAVE_API_BASE'] ?? '')));
        $this->apiBase = $apiBaseEnv !== '' ? rtrim($apiBaseEnv, '/') : 'https://api.flutterwave.com';
    }

    public function createOneTimePayment(float $amount, string $currency, array $metadata = []): array
    {
        if ($this->secretKey === '') {
            return ['error' => 'Flutterwave secret key is not configured.'];
        }
        $amount = max(0.01, $amount);
        $currency = $currency !== '' ? strtoupper($currency) : $this->currency;
        $txRef = $this->generateReference('FLW');
        $meta = $this->normalizeMetadata($metadata);
        $body = [
            'tx_ref'       => $txRef,
            'amount'       => number_format($amount, 2, '.', ''),
            'currency'     => $currency,
            'redirect_url' => $this->resolveRedirectUrl(),
        ];
        if (!empty($meta)) {
            $body['meta'] = $meta;
        }
        $customer = $this->resolveCustomer($metadata);
        if (!empty($customer)) {
            $body['customer'] = $customer;
        }
        $customizations = $this->buildCustomizations($metadata);
        if (!empty($customizations)) {
            $body['customizations'] = $customizations;
        }

        $resp = $this->postJson('/v3/payments', $body);
        $link = $resp['data']['link'] ?? ($resp['data']['checkout_url'] ?? '');
        if (!is_string($link) || $link === '') {
            $message = (string)($resp['message'] ?? ($resp['status'] ?? 'Flutterwave payment initialization failed'));
            return ['error' => $message, 'raw' => $resp];
        }

        return [
            'checkout_url' => $link,
            'reference'    => $txRef,
            'raw'          => $resp,
        ];
    }

    public function createSubscription(string $planName, float $amount, string $currency, string $interval, int $intervalCount = 1, array $metadata = []): array
    {
        if ($this->secretKey === '') {
            return ['error' => 'Flutterwave secret key is not configured.'];
        }
        $amount = max(0.01, $amount);
        $intervalKey = $this->normalizeInterval($interval);
        if (!in_array($intervalKey, ['daily', 'weekly', 'monthly', 'yearly'], true)) {
            return ['error' => 'Flutterwave payment plans support daily, weekly, monthly, or yearly intervals.'];
        }
        if ($intervalCount !== 1 && $intervalKey !== 'monthly') {
            return ['error' => 'Flutterwave payment plans only support interval counts for monthly cycles.'];
        }
        if ($intervalKey === 'monthly' && $intervalCount > 1) {
            return ['error' => 'Flutterwave does not support charging every ' . $intervalCount . ' months via a single plan.'];
        }

        $currency = $currency !== '' ? strtoupper($currency) : $this->currency;
        $plan = $this->createPaymentPlan($planName, $amount, $currency, $intervalKey);
        if (!empty($plan['error'])) {
            return $plan;
        }
        $planId = (int)($plan['id'] ?? 0);
        if ($planId <= 0) {
            return ['error' => 'Flutterwave plan creation failed.', 'raw' => $plan];
        }

        $txRef = $this->generateReference('FLWS');
        $meta = $this->normalizeMetadata($metadata);
        $meta['payment_plan_id'] = (string)$planId;
        $body = [
            'tx_ref'       => $txRef,
            'amount'       => number_format($amount, 2, '.', ''),
            'currency'     => $currency,
            'redirect_url' => $this->resolveRedirectUrl(),
            'payment_plan' => $planId,
        ];
        if (!empty($meta)) {
            $body['meta'] = $meta;
        }
        $customer = $this->resolveCustomer($metadata);
        if (!empty($customer)) {
            $body['customer'] = $customer;
        }
        $customizations = $this->buildCustomizations($metadata);
        if (!empty($customizations)) {
            $body['customizations'] = $customizations;
        }

        $payment = $this->postJson('/v3/payments', $body);
        $link = $payment['data']['link'] ?? '';
        if (!is_string($link) || $link === '') {
            $message = (string)($payment['message'] ?? 'Flutterwave subscription checkout failed.');
            return ['error' => $message, 'raw' => ['plan' => $plan, 'payment' => $payment]];
        }

        return [
            'checkout_url' => $link,
            'reference'    => $txRef,
            'raw'          => ['plan' => $plan, 'payment' => $payment],
        ];
    }

    public function verifyWebhook(array $headers, string $payload): array
    {
        @require_once __DIR__ . '/../helpers/webhooks_helper.php';
        $headerHash = $this->headerValue($headers, 'verif-hash');
        $secretHash = (string)(getenv('FLUTTERWAVE_SECRET_HASH')
            ?: ($_ENV['FLUTTERWAVE_SECRET_HASH'] ?? ($_SERVER['FLUTTERWAVE_SECRET_HASH'] ?? $this->secretHash)));
        if ($secretHash === '' || $headerHash === '' || !hash_equals($secretHash, $headerHash)) {
            return ['valid' => false, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => null];
        }

        $event = json_decode($payload, true);
        if (!is_array($event)) {
            return ['valid' => false, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => null];
        }
        $data = isset($event['data']) && is_array($event['data']) ? $event['data'] : [];
        $meta = isset($data['meta']) && is_array($data['meta']) ? $data['meta'] : [];
        $reference = (string)($data['tx_ref'] ?? ($data['reference'] ?? ($data['flw_ref'] ?? ($data['id'] ?? ''))));

        return [
            'valid'     => true,
            'event'     => strtolower((string)($event['event'] ?? '')),
            'reference' => $reference,
            'metadata'  => $meta,
            'raw'       => $event,
        ];
    }

    private function createPaymentPlan(string $name, float $amount, string $currency, string $interval): array
    {
        $body = [
            'name'     => $name !== '' ? $name : 'Subscription Plan',
            'amount'   => number_format($amount, 2, '.', ''),
            'currency' => $currency,
            'interval' => $interval,
            'duration' => 0,
        ];
        $resp = $this->postJson('/v3/payment-plans', $body);
        if (isset($resp['data']['id'])) {
            return ['id' => $resp['data']['id'], 'raw' => $resp];
        }
        $message = (string)($resp['message'] ?? 'Flutterwave payment plan error');
        return ['error' => $message, 'raw' => $resp];
    }

    private function resolveCustomer(array $metadata): array
    {
        $email = '';
        foreach (['buyer_email', 'customer_email', 'email'] as $key) {
            if (!empty($metadata[$key]) && is_string($metadata[$key])) {
                $email = trim((string)$metadata[$key]);
                break;
            }
        }
        $name = '';
        foreach (['buyer_name', 'customer_name', 'name'] as $key) {
            if (!empty($metadata[$key]) && is_string($metadata[$key])) {
                $name = trim((string)$metadata[$key]);
                break;
            }
        }
        $customer = [];
        if ($email !== '') {
            $customer['email'] = $email;
        }
        if ($name !== '') {
            $customer['name'] = $name;
        }
        if (!empty($metadata['phone'])) {
            $customer['phonenumber'] = (string)$metadata['phone'];
        }
        return $customer;
    }

    private function buildCustomizations(array $metadata): array
    {
        $custom = [];
        if (!empty($metadata['title'])) {
            $custom['title'] = (string)$metadata['title'];
        }
        if (!empty($metadata['description'])) {
            $custom['description'] = (string)$metadata['description'];
        }
        return $custom;
    }

    private function normalizeMetadata(array $metadata): array
    {
        $normalized = [];
        foreach ($metadata as $key => $value) {
            if (!is_string($key) || $key === '') {
                continue;
            }
            if (is_scalar($value)) {
                $normalized[$key] = (string)$value;
            }
        }
        return $normalized;
    }

    private function normalizeInterval(string $interval): string
    {
        $interval = strtolower($interval);
        return match ($interval) {
            'day', 'daily'   => 'daily',
            'week', 'weekly' => 'weekly',
            'year', 'yearly' => 'yearly',
            default          => 'monthly',
        };
    }

    private function resolveRedirectUrl(): string
    {
        if ($this->successUrl !== '') {
            return $this->successUrl;
        }
        if ($this->cancelUrl !== '') {
            return $this->cancelUrl;
        }
        return '/';
    }

    private function postJson(string $path, array $body): array
    {
        $url = $this->apiBase . $path;
        $payload = json_encode($body);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->secretKey,
        ]);
        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $errMsg = $errno ? curl_error($ch) : null;
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $decoded = is_string($response) ? json_decode($response, true) : null;
        if (!is_array($decoded)) {
            $decoded = [];
        }
        if ($errno && $errMsg) {
            $decoded['error'] = $errMsg;
        }
        $decoded['http_code'] = $status;
        return $decoded;
    }

    private function headerValue(array $headers, string $name): string
    {
        foreach ($headers as $key => $value) {
            if (strcasecmp((string)$key, $name) === 0) {
                return is_array($value) ? (string)reset($value) : (string)$value;
            }
        }
        if (class_exists('Headers') && method_exists('Headers', 'get')) {
            $fallback = Headers::get($name);
            if ($fallback !== null && $fallback !== '') {
                return (string)$fallback;
            }
        }
        return '';
    }

    private function generateReference(string $prefix): string
    {
        try {
            return $prefix . '-' . bin2hex(random_bytes(8));
        } catch (Throwable $__) {
            return $prefix . '-' . dechex((int)(microtime(true) * 1000000));
        }
    }
}
