<?php
declare(strict_types=1);

require_once __DIR__ . '/PaymentGatewayInterface.php';

class PaymentFactory
{
    public static function config(): array
    {
        // Always (re)load to avoid stale caches during config iteration/debug
        $cfg = require __DIR__ . '/config.php';
        return is_array($cfg) ? $cfg : [];
    }

    public static function make(string $provider): PaymentGatewayInterface
    {
        $p = strtolower(trim($provider));
        $cfg = self::config();
        switch ($p) {
            case 'stripe':
                require_once __DIR__ . '/StripeGateway.php';
                return new StripeGateway($cfg);
            case 'paypal':
                require_once __DIR__ . '/PayPalGateway.php';
                return new PayPalGateway($cfg);
            case 'iyzico':
            case 'iyzipay':
                require_once __DIR__ . '/IyziCoGateway.php';
                return new IyziCoGateway($cfg);
            case 'nowpayments':
                require_once __DIR__ . '/NowPaymentsGateway.php';
                return new NowPaymentsGateway($cfg);
            case 'coinbase':
            case 'coinbase_commerce':
                require_once __DIR__ . '/CoinbaseGateway.php';
                return new CoinbaseGateway($cfg);
            case 'flutterwave':
                require_once __DIR__ . '/FlutterwaveGateway.php';
                return new FlutterwaveGateway($cfg);
            case 'paystack':
                require_once __DIR__ . '/PaystackGateway.php';
                return new PaystackGateway($cfg);
            case 'payu':
                require_once __DIR__ . '/PayUGateway.php';
                return new PayUGateway($cfg);
            default:
                throw new InvalidArgumentException('Unsupported payment provider: ' . $provider);
        }
    }
}
