<?php
declare(strict_types=1);

/**
 * Lightweight IyziCo checkout integration without external SDK dependencies.
 * Uses Checkout Form Initialize to obtain a redirect URL and validates webhooks via HMAC.
 */
class IyziCoGateway implements PaymentGatewayInterface
{
    private string $apiKey;
    private string $secretKey;
    private string $webhookSecret;
    private string $currency;
    private string $successUrl;
    private string $cancelUrl;
    private string $apiBase;

    public function __construct(array $config)
    {
        $provider = $config['iyzico'] ?? [];
        $this->apiKey        = (string) ($provider['api_key'] ?? '');
        $this->secretKey     = (string) ($provider['secret_key'] ?? '');
        $this->webhookSecret = (string) ($provider['webhook_secret'] ?? '');
        $this->currency      = strtoupper((string) ($provider['currency'] ?? ($config['currency'] ?? 'TRY')));
        $this->successUrl    = (string) ($config['success_url'] ?? '');
        $this->cancelUrl     = (string) ($config['cancel_url'] ?? '');

        $apiBaseEnv = (string) (getenv('IYZICO_API_BASE')
            ?: ($_ENV['IYZICO_API_BASE'] ?? ($_SERVER['IYZICO_API_BASE'] ?? '')));
        $this->apiBase = $apiBaseEnv !== ''
            ? rtrim($apiBaseEnv, '/')
            : rtrim((string) ($provider['api_base'] ?? 'https://api.iyzipay.com'), '/');
    }

    public function createOneTimePayment(float $amount, string $currency, array $metadata = []): array
    {
        if ($this->apiKey === '' || $this->secretKey === '') {
            return ['checkout_url' => '', 'reference' => '', 'error' => 'IyziCo credentials are missing.'];
        }

        $amount = max(1.0, $amount);
        $currencyCode = $currency !== '' ? strtoupper($currency) : $this->currency;
        $email = $this->resolveEmail($metadata);
        if ($email === '') {
            return ['checkout_url' => '', 'reference' => '', 'error' => 'IyziCo requires a buyer email address.'];
        }

        $reference = $metadata['reference'] ?? $this->generateReference('IYZ');
        $buyerName = $this->resolveName($metadata);
        $buyerSurname = $this->resolveSurname($buyerName);
        $callbackUrl = $this->resolveRedirectUrl();
        $title = (string) ($metadata['title'] ?? 'Payment');

        $payload = [
            'locale'           => 'en',
            'conversationId'   => $reference,
            'price'            => $this->formatAmount($amount),
            'paidPrice'        => $this->formatAmount($amount),
            'currency'         => $currencyCode,
            'basketId'         => $reference,
            'paymentGroup'     => 'PRODUCT',
            'callbackUrl'      => $callbackUrl,
            'buyer'            => [
                'id'                 => (string) ($metadata['buyer_id'] ?? 'buyer'),
                'name'               => $buyerName,
                'surname'            => $buyerSurname,
                'gsmNumber'          => (string) ($metadata['phone'] ?? ''),
                'email'              => $email,
                'identityNumber'     => '11111111111',
                'registrationAddress'=> $this->resolveAddress($metadata),
                'city'               => (string) ($metadata['city'] ?? 'City'),
                'country'            => (string) ($metadata['country'] ?? 'Country'),
                'ip'                 => $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
            ],
            'shippingAddress'  => [
                'contactName' => $buyerName !== '' ? $buyerName . ' ' . $buyerSurname : 'Customer',
                'city'        => (string) ($metadata['city'] ?? 'City'),
                'country'     => (string) ($metadata['country'] ?? 'Country'),
                'address'     => $this->resolveAddress($metadata),
            ],
            'billingAddress'   => [
                'contactName' => $buyerName !== '' ? $buyerName . ' ' . $buyerSurname : 'Customer',
                'city'        => (string) ($metadata['city'] ?? 'City'),
                'country'     => (string) ($metadata['country'] ?? 'Country'),
                'address'     => $this->resolveAddress($metadata),
            ],
            'basketItems'      => [
                [
                    'id'        => $reference,
                    'name'      => $title !== '' ? $title : 'Payment',
                    'category1' => 'Digital',
                    'itemType'  => 'VIRTUAL',
                    'price'     => $this->formatAmount($amount),
                ],
            ],
        ];

        $resp = $this->postJson('/payment/iyzipos/checkoutform/initialize/auth/ecom', $payload);
        $status = strtolower((string) ($resp['status'] ?? ''));
        if ($status !== 'success') {
            $message = (string) ($resp['errorMessage'] ?? $resp['error'] ?? 'IyziCo initialization failed.');
            return [
                'checkout_url' => '',
                'reference'    => '',
                'error'        => $message,
                'raw'          => $resp,
                'http_code'    => $resp['http_code'] ?? null,
            ];
        }

        $token = (string) ($resp['token'] ?? '');
        $paymentPageUrl = (string) ($resp['paymentPageUrl'] ?? '');
        $checkoutUrl = $paymentPageUrl;
        if ($checkoutUrl === '' && $token !== '') {
            $checkoutUrl = rtrim($this->resolveMerchantBase(), '/') . '/pay?token=' . urlencode($token);
        }

        return [
            'checkout_url' => $checkoutUrl,
            'reference'    => $token !== '' ? $token : $reference,
            'raw'          => $resp,
        ];
    }

    public function createSubscription(string $planName, float $amount, string $currency, string $interval, int $intervalCount = 1, array $metadata = []): array
    {
        $meta = $metadata;
        $meta['subscription_interval'] = $interval;
        $meta['subscription_interval_count'] = $intervalCount;
        return $this->createOneTimePayment($amount, $currency, $meta);
    }

    public function verifyWebhook(array $headers, string $payload): array
    {
        $sigHeader = $this->headerValue($headers, 'x-iyzi-signature');
        if ($sigHeader === '') {
            $sigHeader = $this->headerValue($headers, 'x-iyzico-signature');
        }
        $secret = $this->webhookSecret !== '' ? $this->webhookSecret : $this->secretKey;
        if ($secret === '' || $sigHeader === '') {
            return ['valid' => false, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => null];
        }

        $computed = hash_hmac('sha256', (string) $payload, $secret);
        if (!hash_equals((string) $sigHeader, (string) $computed)) {
            return ['valid' => false, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => null];
        }

        $event = json_decode($payload, true);
        if (!is_array($event)) {
            return ['valid' => false, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => null];
        }

        $rawEvent = strtolower((string) ($event['iyziEventType'] ?? ($event['eventType'] ?? ($event['event'] ?? ''))));
        $reference = (string) ($event['token'] ?? ($event['paymentId'] ?? ($event['conversationId'] ?? '')));
        $meta = is_array($event['metadata'] ?? null) ? $event['metadata'] : [];
        $normalizedEvent = $rawEvent !== '' ? $rawEvent : (strtolower((string) ($event['status'] ?? '')) === 'success' ? 'payment_success' : '');
        if ($normalizedEvent === 'payment.completed' || $normalizedEvent === 'payment') {
            $normalizedEvent = 'payment_success';
        }

        return [
            'valid'     => true,
            'event'     => $normalizedEvent,
            'reference' => $reference,
            'metadata'  => $meta,
            'raw'       => $event,
        ];
    }

    private function resolveRedirectUrl(): string
    {
        if ($this->successUrl !== '') {
            return $this->successUrl;
        }
        return $this->cancelUrl !== '' ? $this->cancelUrl : '';
    }

    private function resolveMerchantBase(): string
    {
        if (strpos($this->apiBase, 'sandbox') !== false) {
            return 'https://sandbox-merchant.iyzipay.com';
        }
        return 'https://merchant.iyzipay.com';
    }

    private function resolveEmail(array $metadata): string
    {
        foreach (['buyer_email', 'customer_email', 'email'] as $key) {
            if (!empty($metadata[$key]) && is_string($metadata[$key])) {
                $candidate = trim((string) $metadata[$key]);
                if ($candidate !== '') {
                    return $candidate;
                }
            }
        }
        return '';
    }

    private function resolveName(array $metadata): string
    {
        foreach (['buyer_name', 'name'] as $key) {
            if (!empty($metadata[$key]) && is_string($metadata[$key])) {
                $candidate = trim((string) $metadata[$key]);
                if ($candidate !== '') {
                    return $candidate;
                }
            }
        }
        return '';
    }

    private function resolveSurname(string $name): string
    {
        $parts = array_filter(explode(' ', $name));
        if (count($parts) >= 2) {
            return array_pop($parts) ?: '';
        }
        return $name !== '' ? $name : 'User';
    }

    private function resolveAddress(array $metadata): string
    {
        foreach (['address', 'registrationAddress', 'billing_address'] as $key) {
            if (!empty($metadata[$key]) && is_string($metadata[$key])) {
                $candidate = trim((string) $metadata[$key]);
                if ($candidate !== '') {
                    return $candidate;
                }
            }
        }
        return 'Address not provided';
    }

    private function formatAmount(float $amount): string
    {
        return number_format($amount, 2, '.', '');
    }

    private function generateReference(string $prefix = 'IYZ'): string
    {
        return $prefix . '-' . bin2hex(random_bytes(6)) . '-' . time();
    }

    private function postJson(string $path, array $body): array
    {
        $url = (strpos($path, 'http') === 0) ? $path : ($this->apiBase . $path);
        $payload = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $rnd = bin2hex(random_bytes(8));
        $hashStr = $this->apiKey . $rnd . $this->secretKey . $payload;
        $signature = base64_encode(hash('sha1', $hashStr, true));

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: IYZWS ' . $this->apiKey . ':' . $signature,
            'x-iyzi-rnd-key: ' . $rnd,
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        $resp = curl_exec($ch);
        $errno = curl_errno($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($errno) {
            return ['error' => 'curl_error', 'errno' => $errno, 'http_code' => $httpCode];
        }

        $decoded = json_decode((string) $resp, true);
        if (!is_array($decoded)) {
            return ['error' => 'invalid_response', 'raw' => $resp, 'http_code' => $httpCode];
        }
        $decoded['http_code'] = $httpCode;
        return $decoded;
    }

    private function headerValue(array $headers, string $key): string
    {
        foreach ($headers as $k => $v) {
            if (strcasecmp((string) $k, $key) === 0) {
                return is_array($v) ? (string) reset($v) : (string) $v;
            }
        }
        if (class_exists('Headers')) {
            $val = \Headers::get($key);
            if ($val !== null) {
                return (string) $val;
            }
        }
        return '';
    }
}
