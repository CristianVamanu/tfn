<?php
declare(strict_types=1);

class CoinbaseGateway implements PaymentGatewayInterface
{
    private string $apiKey;
    private string $webhookSecret;
    private string $currency;
    private string $successUrl;
    private string $cancelUrl;
    private string $apiBase = 'https://api.commerce.coinbase.com';

    public function __construct(array $config)
    {
        $this->apiKey = (string)($config['coinbase']['api_key'] ?? '');
        $this->webhookSecret = (string)($config['coinbase']['webhook_secret'] ?? '');
        $this->currency = (string)($config['currency'] ?? 'USD');
        $this->successUrl = (string)($config['success_url'] ?? '');
        $this->cancelUrl = (string)($config['cancel_url'] ?? '');
        $envBase = (string) (getenv('COINBASE_COMMERCE_API_BASE')
            ?: ($_ENV['COINBASE_COMMERCE_API_BASE'] ?? ($_SERVER['COINBASE_COMMERCE_API_BASE'] ?? '')));
        if ($envBase !== '') {
            $this->apiBase = rtrim($envBase, '/');
        }
    }

    public function createOneTimePayment(float $amount, string $currency, array $metadata = []): array
    {
        $currencyCode = strtoupper($currency !== '' ? $currency : $this->currency);
        $precision = $this->resolvePrecision($currencyCode);
        $metadataPayload = $this->filterMetadata($metadata);

        $body = [
            'name' => (string)($metadata['title'] ?? 'Advertisement'),
            'description' => (string)($metadata['description'] ?? ''),
            'local_price' => ['amount' => number_format($amount, $precision, '.', ''), 'currency' => $currencyCode],
            'pricing_type' => 'fixed_price',
            'redirect_url' => $this->successUrl,
            'cancel_url' => $this->cancelUrl,
        ];
        if (!empty($metadataPayload)) {
            $body['metadata'] = $metadataPayload;
        }
        $resp = $this->postJson($this->apiBase . '/charges', $body);
        $url = '';
        if (isset($resp['data']['hosted_url'])) { $url = (string)$resp['data']['hosted_url']; }
        $ref = isset($resp['data']['id']) ? (string)$resp['data']['id'] : '';
        return ['checkout_url' => $url, 'reference' => $ref, 'raw' => $resp];
    }

    public function createSubscription(string $planName, float $amount, string $currency, string $interval, int $intervalCount = 1, array $metadata = []): array
    {
        // Coinbase Commerce does not natively manage subscriptions; implement off-platform logic
        return ['checkout_url' => $this->successUrl, 'reference' => 'COINBASE_SUBSCRIPTION_PLACEHOLDER', 'raw' => []];
    }

    /**
     * Estimate the fiat equivalent for a crypto amount using Coinbase public APIs.
     */
    public function estimateFiatAmount(float $amount, string $currencyFrom, string $currencyTo): ?float
    {
        $amount = (float) $amount;
        $currencyFrom = strtoupper(trim($currencyFrom));
        $currencyTo = strtoupper(trim($currencyTo));
        if ($amount <= 0.0 || $currencyFrom === '' || $currencyTo === '') {
            $this->trace('estimate_skip', ['reason' => 'invalid_input', 'amount' => $amount, 'from' => $currencyFrom, 'to' => $currencyTo]);
            return null;
        }

        if ($currencyFrom === $currencyTo) {
            return $amount;
        }

        $spotRate = $this->fetchSpotRate($currencyFrom, $currencyTo);
        if ($spotRate !== null) {
            $result = $amount * $spotRate;
            $this->trace('estimate_spot_ok', ['amount' => $amount, 'from' => $currencyFrom, 'to' => $currencyTo, 'rate' => $spotRate, 'result' => $result]);
            return $result;
        }

        $fallback = $this->fallbackEstimateAmount($amount, $currencyFrom, $currencyTo);
        if ($fallback !== null) {
            $this->trace('estimate_fallback_ok', ['amount' => $amount, 'from' => $currencyFrom, 'to' => $currencyTo, 'result' => $fallback]);
            return $fallback;
        }

        $this->trace('estimate_failed', ['amount' => $amount, 'from' => $currencyFrom, 'to' => $currencyTo]);
        return null;
    }

    private function trace(string $label, array $context = []): void
    {
        if (!defined('APP_DEBUG') || APP_DEBUG !== true) {
            return;
        }

        $path = dirname(__DIR__) . '/coinbase_trace.log';
        $line = date('c') . ' ' . $label;
        if (!empty($context)) {
            $line .= ' ' . json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
        @file_put_contents($path, $line . "\n", FILE_APPEND);
    }

    public function verifyWebhook(array $headers, string $payload): array
    {
        // Extract Coinbase signature header (case-insensitive)
        @require_once __DIR__ . '/../helpers/webhooks_helper.php';

        $sigHeader = '';
        if (is_array($headers)) {
            foreach ($headers as $key => $value) {
                if (strcasecmp((string) $key, 'X-CC-Webhook-Signature') === 0) {
                    $sigHeader = is_array($value) ? (string) reset($value) : (string) $value;
                    break;
                }
            }
        }

        if ($sigHeader === '' && class_exists('Headers') && method_exists('Headers', 'get')) {
            $fallback = Headers::get('X-CC-Webhook-Signature');
            if ($fallback !== null && $fallback !== '') {
                $sigHeader = (string) $fallback;
            }
        }

        // Resolve secret: ENV first, then DB/admin fallback
        $secret = (string) (getenv('COINBASE_COMMERCE_WEBHOOK_SECRET')
            ?: ($_ENV['COINBASE_COMMERCE_WEBHOOK_SECRET'] ?? ($_SERVER['COINBASE_COMMERCE_WEBHOOK_SECRET'] ?? '')));
        if ($secret === '') { $secret = $this->webhookSecret; }

        // Verify signature against raw request body
        $isValid = self::verifyCoinbaseWebhook($payload, (string) $sigHeader, (string) $secret);

        $event = json_decode($payload, true);
        $valid = $isValid && is_array($event) && isset($event['event']['type']);
        $out = ['valid' => $valid, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => $event];
        if (!$valid) { return $out; }
        $type = (string)$event['event']['type'];
        // Map success-like events to uniform event name; others pass through
        if ($type === 'charge:confirmed' || $type === 'charge:resolved') {
            $out['event'] = 'payment_success';
        } else {
            $out['event'] = $type;
        }
        $data = $event['event']['data'] ?? [];
        if (is_array($data)) {
            $out['reference'] = (string)($data['id'] ?? '');
            if (isset($data['metadata']) && is_array($data['metadata'])) {
                $filtered = $this->filterMetadata($data['metadata']);
                if (!empty($filtered)) {
                    $out['metadata'] = $filtered;
                }
            }
        }
        return $out;
    }

    /**
     * Verify Coinbase Commerce webhook signature using HMAC SHA-256.
     *
     * @param string $rawBody   Raw request body (exact bytes from php://input)
     * @param string $signature Value of X-CC-Webhook-Signature header (hex)
     * @param string $secret    Shared webhook signing secret
     */
    public static function verifyCoinbaseWebhook(string $rawBody, string $signature, string $secret): bool
    {
        $sig = trim($signature);
        if ($rawBody === '' || $sig === '' || $secret === '') {
            return false;
        }
        // Coinbase expects HMAC-SHA256 over raw body with the shared secret.
        $expected = hash_hmac('sha256', $rawBody, $secret, false); // hex output
        // Constant-time comparison
        return hash_equals(strtolower($expected), strtolower($sig));
    }

    /**
     * Allowed Coinbase Commerce webhook event types.
     * Adjust this list to whitelist more events if needed.
     *
     * Mini test checklist:
     * - Valid signature + charge:confirmed → event maps to payment_success
     * - Valid signature + charge:resolved  → event maps to payment_success
     * - Valid signature + charge:failed    → event stays as charge:failed
     * - Missing signature/secret/invalid HMAC → returns false (HTTP 400 upstream)
     */
    public static function allowedEventTypes(): array
    {
        return [
            'charge:confirmed',
            'charge:resolved',
            'charge:failed',
        ];
    }

    private function resolvePrecision(string $currency): int
    {
        $currency = strtoupper($currency);
        $fiatCurrencies = [
            'USD', 'EUR', 'GBP', 'AUD', 'CAD', 'NZD', 'JPY', 'CNY', 'CHF', 'SEK',
            'NOK', 'DKK', 'RUB', 'TRY', 'BRL', 'MXN', 'ARS', 'COP', 'CLP', 'HKD',
            'SGD', 'KRW', 'TWD', 'AED', 'SAR', 'QAR', 'BHD', 'KWD', 'INR', 'PLN',
            'CZK', 'HUF', 'ZAR',
        ];
        return in_array($currency, $fiatCurrencies, true) ? 2 : 8;
    }

    private function filterMetadata(array $metadata): array
    {
        $filtered = [];

        foreach ($metadata as $key => $value) {
            if (in_array($key, ['title', 'description'], true)) {
                continue;
            }

            if ($value === null) {
                continue;
            }

            if (is_bool($value)) {
                $value = $value ? '1' : '0';
            } elseif (!is_scalar($value)) {
                continue;
            }

            $stringValue = (string) $value;
            if ($stringValue === '') {
                continue;
            }

            $filtered[$key] = $stringValue;
        }

        return $filtered;
    }

    private function postJson(string $url, array $body): array
    {
        $userAgent = $this->buildUserAgent();

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'X-CC-Api-Key: ' . $this->apiKey,
            'X-CC-Version: 2018-03-22',
            'User-Agent: ' . $userAgent
        ]);
        $res = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($res === false) {
            $err = curl_error($ch);
            curl_close($ch);
            return ['error' => $err !== '' ? $err : 'cURL execution failed', 'http_code' => $httpCode > 0 ? $httpCode : null];
        }
        curl_close($ch);
        $j = json_decode($res, true);
        if (!is_array($j)) {
            return ['error' => 'Unexpected response from Coinbase Commerce', 'http_code' => $httpCode, 'raw' => $res];
        }
        if ($httpCode >= 400) {
            $message = (string)($j['message'] ?? ($j['error'] ?? 'Coinbase Commerce rejected the request'));
            return ['error' => $message, 'http_code' => $httpCode, 'raw' => $j];
        }
        return $j;
    }

    private function buildUserAgent(): string
    {
        static $ua = null;
        if ($ua !== null) {
            return $ua;
        }

        $base = $this->resolveBaseUrlForUserAgent();
        $ua = 'CreatorPulse-Coinbase/1.0 (+' . $base . ')';
        return $ua;
    }

    private function resolveBaseUrlForUserAgent(): string
    {
        $candidates = [$this->successUrl, $this->cancelUrl];
        foreach ($candidates as $candidate) {
            $normalized = $this->normalizeBaseUrl($candidate);
            if ($normalized !== null) {
                return $normalized;
            }
        }

        if (isset($GLOBALS['base_url']) && is_string($GLOBALS['base_url'])) {
            $normalized = $this->normalizeBaseUrl((string) $GLOBALS['base_url']);
            if ($normalized !== null) {
                return $normalized;
            }
        }

        return 'https://localhost';
    }

    private function normalizeBaseUrl(?string $url): ?string
    {
        if ($url === null || $url === '') {
            return null;
        }
        $parts = parse_url($url);
        if (!is_array($parts)) {
            return null;
        }
        $scheme = isset($parts['scheme']) ? strtolower($parts['scheme']) : 'https';
        $host = $parts['host'] ?? '';
        if ($host === '') {
            return null;
        }
        $port = isset($parts['port']) ? ':' . $parts['port'] : '';
        return $scheme . '://' . $host . $port;
    }

    private function fallbackEstimateAmount(float $amount, string $currencyFrom, string $currencyTo): ?float
    {
        $rate = $this->fetchExchangeRate($currencyFrom, $currencyTo);
        if ($rate === null) {
            return null;
        }
        return $amount * $rate;
    }

    private function fetchSpotRate(string $currencyFrom, string $currencyTo): ?float
    {
        $pair = strtoupper($currencyFrom) . '-' . strtoupper($currencyTo);
        $url = 'https://api.coinbase.com/v2/prices/' . rawurlencode($pair) . '/spot';
        $body = $this->simpleGet($url);
        if ($body === null) {
            return null;
        }

        $decoded = json_decode($body, true);
        if (!is_array($decoded) || !isset($decoded['data']) || !is_array($decoded['data'])) {
            return null;
        }
        $data = $decoded['data'];
        $amount = isset($data['amount']) && is_numeric($data['amount']) ? (float) $data['amount'] : null;
        $base = strtoupper((string) ($data['base'] ?? ''));
        $currency = strtoupper((string) ($data['currency'] ?? ''));
        if ($amount === null || $base === '' || $currency === '') {
            return null;
        }
        if ($base !== strtoupper($currencyFrom) || $currency !== strtoupper($currencyTo)) {
            return null;
        }
        return $amount;
    }

    private function fetchExchangeRate(string $currencyFrom, string $currencyTo): ?float
    {
        $currencyFrom = strtoupper($currencyFrom);
        $currencyTo = strtoupper($currencyTo);
        if ($currencyFrom === $currencyTo) {
            return 1.0;
        }

        $url = 'https://api.coinbase.com/v2/exchange-rates?currency=' . urlencode($currencyFrom);
        $body = $this->simpleGet($url);
        if ($body === null) {
            return null;
        }

        $decoded = json_decode($body, true);
        if (!is_array($decoded)) {
            return null;
        }
        $rates = $decoded['data']['rates'] ?? [];
        if (!is_array($rates)) {
            return null;
        }
        if (isset($rates[$currencyTo]) && is_numeric($rates[$currencyTo])) {
            return (float) $rates[$currencyTo];
        }
        return null;
    }

    private function simpleGet(string $url): ?string
    {
        $userAgent = $this->buildUserAgent();
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTPHEADER => ['User-Agent: ' . $userAgent],
        ]);
        $res = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = $res === false ? curl_error($ch) : '';
        curl_close($ch);

        if ($res === false || $httpCode >= 400) {
            $this->trace('http_error', ['url' => $url, 'code' => $httpCode, 'error' => $err]);
            return null;
        }

        return (string) $res;
    }
}
