<?php
declare(strict_types=1);

class NowPaymentsGateway implements PaymentGatewayInterface
{
    private string $apiKey;
    private string $currency;
    private string $successUrl;
    private string $cancelUrl;
    private string $webhookSecret = '';
    private string $apiBase = 'https://api.nowpayments.io';
    private string $mode = 'live';

    public function __construct(array $config)
    {
        $this->apiKey = (string)($config['nowpayments']['api_key'] ?? '');
        $this->currency = (string)($config['currency'] ?? 'USD');
        $this->successUrl = (string)($config['success_url'] ?? '');
        $this->cancelUrl = (string)($config['cancel_url'] ?? '');
        $this->webhookSecret = (string)($config['nowpayments']['webhook_secret'] ?? '');
        $modeConfig = strtolower((string)($config['nowpayments']['mode'] ?? ''));
        if (in_array($modeConfig, ['sandbox', 'live'], true)) {
            $this->mode = $modeConfig;
        }
        $envBase = (string)(getenv('NOWPAYMENTS_API_BASE')
            ?: ($_ENV['NOWPAYMENTS_API_BASE'] ?? ($_SERVER['NOWPAYMENTS_API_BASE'] ?? '')));
        if ($envBase !== '') {
            $this->apiBase = rtrim($envBase, '/');
        } else {
            $this->apiBase = $this->mode === 'sandbox'
                ? 'https://api-sandbox.nowpayments.io'
                : 'https://api.nowpayments.io';
        }
    }

    public function createOneTimePayment(float $amount, string $currency, array $metadata = []): array
    {
        if ($this->apiKey === '') {
            return [
                'checkout_url' => '',
                'reference' => '',
                'error' => 'NOWPayments API key is not configured.',
                'http_code' => 0,
                'mode' => $this->mode,
            ];
        }
        $currencyCode = strtoupper($currency !== '' ? $currency : $this->currency);
        $precision = $this->resolvePrecision($currencyCode);
        $orderId = $this->encodeMetadata($metadata);
        if ($orderId === '' && array_key_exists('ad_id', $metadata)) {
            $orderId = (string) $metadata['ad_id'];
        }

        $body = [
            'price_amount' => number_format($amount, $precision, '.', ''),
            'price_currency' => $currencyCode,
            'order_id' => $orderId,
            'order_description' => (string)($metadata['title'] ?? 'Advertisement'),
            'success_url' => $this->successUrl,
            'cancel_url' => $this->cancelUrl,
        ];
        if (!empty($metadata['crypto_currency'])) {
            $body['pay_currency'] = strtoupper((string) $metadata['crypto_currency']);
        }
        $resp = $this->postJson($this->apiBase . '/v1/invoice', $body);
        if (!empty($resp['error']) && $this->mode === 'live') {
            $errorLower = strtolower((string)$resp['error']);
            $rawCode = '';
            if (isset($resp['raw']) && is_array($resp['raw']) && isset($resp['raw']['code'])) {
                $rawCode = strtolower((string)$resp['raw']['code']);
            }
            if (strpos($errorLower, 'invalid api key') !== false || $rawCode === 'invalid_api_key') {
                $sandboxBase = 'https://api-sandbox.nowpayments.io';
                $retry = $this->postJson($sandboxBase . '/v1/invoice', $body);
                if (!empty($retry['invoice_url'])) {
                    $resp = $retry;
                    $resp['fallback_from'] = 'live';
                    $this->mode = 'sandbox';
                    $this->apiBase = $sandboxBase;
                } else {
                    $resp['fallback_attempted'] = true;
                    if (!empty($retry['error'])) {
                        $resp['fallback_error'] = $retry['error'];
                    }
                    if (!empty($retry['raw'])) {
                        $resp['fallback_raw'] = $retry['raw'];
                    }
                }
            }
        }
        return [
            'checkout_url' => (string)($resp['invoice_url'] ?? ''),
            'reference' => (string)($resp['id'] ?? ''),
            'raw' => $resp,
            'error' => $resp['error'] ?? null,
            'http_code' => $resp['http_code'] ?? null,
            'mode' => $this->mode,
        ];
    }

    public function createSubscription(string $planName, float $amount, string $currency, string $interval, int $intervalCount = 1, array $metadata = []): array
    {
        // NOWPayments supports recurring via IPN + your logic; returning placeholder
        return ['checkout_url' => $this->successUrl, 'reference' => 'NOWPAYMENTS_SUBSCRIPTION_PLACEHOLDER', 'raw' => []];
    }

    /**
     * Estimate the target currency amount for a given crypto amount using NOWPayments /v1/estimate.
     * Returns null on failure so callers can gracefully skip metadata enrichment.
     */
    public function estimateFiatAmount(float $amount, string $currencyFrom, string $currencyTo): ?float
    {
        $amount = (float) $amount;
        $currencyFrom = strtoupper(trim($currencyFrom));
        $currencyTo = strtoupper(trim($currencyTo));
        if ($amount <= 0.0 || $currencyFrom === '' || $currencyTo === '') {
            $this->trace('estimate_skip', ['reason' => 'invalid_input', 'amount' => $amount, 'from' => $currencyFrom, 'to' => $currencyTo]);
            return null;
        }

        $precisionFrom = $this->resolvePrecision($currencyFrom);
        $estimateBody = [
            'amount' => number_format($amount, $precisionFrom, '.', ''),
            'currency_from' => $currencyFrom,
            'currency_to' => $currencyTo,
        ];

        $resp = $this->postJson($this->apiBase . '/v1/estimate', $estimateBody);
        $this->trace('estimate_response', ['body' => $estimateBody, 'response' => $resp]);
        if (is_array($resp) && isset($resp['estimated_amount']) && is_numeric($resp['estimated_amount'])) {
            return (float) $resp['estimated_amount'];
        }

        $fallback = $this->fallbackEstimateAmount($amount, $currencyFrom, $currencyTo);
        if ($fallback !== null) {
            $this->trace('estimate_fallback_ok', ['amount' => $amount, 'from' => $currencyFrom, 'to' => $currencyTo, 'result' => $fallback]);
            return $fallback;
        }

        $this->trace('estimate_fallback_failed', ['amount' => $amount, 'from' => $currencyFrom, 'to' => $currencyTo]);
        return null;
    }

    private function trace(string $label, array $context = []): void
    {
        if (!defined('APP_DEBUG') || APP_DEBUG !== true) {
            return;
        }

        $path = dirname(__DIR__) . '/nowpayments_trace.log';
        $line = date('c') . ' ' . $label;
        if (!empty($context)) {
            $line .= ' ' . json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
        @file_put_contents($path, $line . "\n", FILE_APPEND);
    }

    public function verifyWebhook(array $headers, string $payload): array
    {
        // Load helpers for header parsing
        @require_once __DIR__ . '/../helpers/webhooks_helper.php';
        // NOWPayments: HMAC-SHA512 over raw body using the IPN secret
        $sigHeader = '';
        if (is_array($headers)) {
            foreach ($headers as $key => $value) {
                if (strcasecmp((string) $key, 'x-nowpayments-sig') === 0) {
                    $sigHeader = is_array($value) ? (string) reset($value) : (string) $value;
                    break;
                }
            }
        }
        if ($sigHeader === '' && class_exists('Headers') && method_exists('Headers', 'get')) {
            $fallback = Headers::get('x-nowpayments-sig');
            if ($fallback !== null && $fallback !== '') {
                $sigHeader = (string) $fallback;
            }
        }
        // Secret priority: ENV first
        $secret = (string) (getenv('NOWPAYMENTS_IPN_SECRET')
            ?: ($_ENV['NOWPAYMENTS_IPN_SECRET'] ?? ($_SERVER['NOWPAYMENTS_IPN_SECRET'] ?? '')));
        if ($secret === '') {
            $secret = (string) (getenv('NOWPAYMENTS_WEBHOOK_SECRET')
                ?: ($_ENV['NOWPAYMENTS_WEBHOOK_SECRET'] ?? ($_SERVER['NOWPAYMENTS_WEBHOOK_SECRET'] ?? '')));
        }
        // Fallback to admin/DB-configured secret if env not set
        if ($secret === '' && $this->webhookSecret !== '') {
            $secret = $this->webhookSecret;
        }

        $isValid = self::verifyNowPaymentsWebhook($payload, $sigHeader, $secret);
        if (!$isValid) {
            return ['valid' => false, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => null];
        }

        $event = json_decode($payload, true);
        $ok = is_array($event) && isset($event['payment_status']);
        if (!$ok) {
            return ['valid' => false, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => null];
        }

        $status = strtolower((string) $event['payment_status']);
        $orderId = (string)($event['order_id'] ?? '');
        $metadata = $this->decodeMetadataString($orderId);
        if (empty($metadata) && $orderId !== '') {
            $metadata = ['ad_id' => $orderId];
        }

        $out = [
            'valid'     => true,
            'event'     => ($status === 'finished') ? 'payment_success' : 'payment_update',
            'reference' => (string)($event['invoice_id'] ?? ''),
            'metadata'  => $metadata,
            'raw'       => $event,
        ];
        return $out;
    }

    /**
     * Verify NOWPayments webhook using HMAC SHA-512 over the raw body.
     *
     * Mini test checklist:
     * - Valid signature + status=finished → payment_success
     * - Missing/invalid signature or secret → HTTP 400 upstream
     * - Non-whitelisted statuses → 200 ignored upstream
     */
    public static function verifyNowPaymentsWebhook(string $rawBody, string $signature, string $secret): bool
    {
        $sig = trim((string) $signature);
        if ($rawBody === '' || $sig === '' || $secret === '') {
            return false;
        }
        $expected = hash_hmac('sha512', $rawBody, $secret, false); // hex
        return hash_equals(strtolower($expected), strtolower($sig));
    }

    private function encodeMetadata(array $metadata): string
    {
        $filtered = [];

        foreach ($metadata as $key => $value) {
            if (in_array($key, ['title', 'description'], true)) {
                continue;
            }

            if ($value === null) {
                continue;
            }

            if (is_bool($value)) {
                $value = $value ? '1' : '0';
            } elseif (!is_scalar($value)) {
                continue;
            }

            $stringValue = (string) $value;
            if ($stringValue === '') {
                continue;
            }

            $filtered[$key] = $stringValue;
        }

        if (empty($filtered)) {
            return '';
        }

        return http_build_query($filtered, '', '&', PHP_QUERY_RFC3986);
    }

    private function decodeMetadataString(string $value): array
    {
        if ($value === '' || strpos($value, '=') === false) {
            return [];
        }

        $decoded = [];
        parse_str($value, $decoded);

        if (!is_array($decoded) || empty($decoded)) {
            return [];
        }

        $sanitized = [];
        foreach ($decoded as $key => $entry) {
            if (is_array($entry) || $entry === null) {
                continue;
            }

            $sanitized[$key] = (string) $entry;
        }

        return $sanitized;
    }

    /** Allowed NOWPayments statuses we consume. */
    public static function allowedStatuses(): array
    {
        return ['finished'];
    }

    private function resolvePrecision(string $currency): int
    {
        $currency = strtoupper($currency);
        $fiatCurrencies = [
            'USD', 'EUR', 'GBP', 'AUD', 'CAD', 'NZD', 'JPY', 'CNY', 'CHF', 'SEK',
            'NOK', 'DKK', 'RUB', 'TRY', 'BRL', 'MXN', 'ARS', 'COP', 'CLP', 'HKD',
            'SGD', 'KRW', 'TWD', 'AED', 'SAR', 'QAR', 'BHD', 'KWD', 'INR', 'PLN',
            'CZK', 'HUF', 'ZAR',
        ];
        return in_array($currency, $fiatCurrencies, true) ? 2 : 8;
    }

    private function postJson(string $url, array $body): array
    {
        $userAgent = $this->buildUserAgent();

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'x-api-key: ' . $this->apiKey,
            'Content-Type: application/json',
            'User-Agent: ' . $userAgent
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        $res = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr = $res === false ? curl_error($ch) : '';
        curl_close($ch);

        if ($res === false) {
            return [
                'error' => $curlErr !== '' ? $curlErr : 'cURL execution failed',
                'http_code' => $httpCode > 0 ? $httpCode : null,
            ];
        }

        $decoded = json_decode($res, true);
        if (!is_array($decoded)) {
            return [
                'error' => 'Unexpected response from NOWPayments',
                'http_code' => $httpCode,
                'raw' => $res,
            ];
        }

        if ($httpCode >= 400) {
            $message = (string)($decoded['message'] ?? ($decoded['error'] ?? 'NOWPayments rejected the request'));
            return [
                'error' => $message,
                'http_code' => $httpCode,
                'raw' => $decoded,
            ];
        }

        return $decoded;
    }

    private function buildUserAgent(): string
    {
        static $ua = null;
        if ($ua !== null) {
            return $ua;
        }

        $base = $this->resolveBaseUrlForUserAgent();
        $ua = 'CreatorPulse-NOWPayments/1.0 (+'.$base.')';
        return $ua;
    }

    private function resolveBaseUrlForUserAgent(): string
    {
        $candidates = [$this->successUrl, $this->cancelUrl];
        foreach ($candidates as $candidate) {
            $normalized = $this->normalizeBaseUrl($candidate);
            if ($normalized !== null) {
                return $normalized;
            }
        }

        if (isset($GLOBALS['base_url']) && is_string($GLOBALS['base_url'])) {
            $normalized = $this->normalizeBaseUrl((string) $GLOBALS['base_url']);
            if ($normalized !== null) {
                return $normalized;
            }
        }

        return 'https://localhost';
    }

    private function normalizeBaseUrl(?string $url): ?string
    {
        if ($url === null || $url === '') {
            return null;
        }
        $parts = parse_url($url);
        if (!is_array($parts)) {
            return null;
        }
        $scheme = isset($parts['scheme']) ? strtolower($parts['scheme']) : 'https';
        $host = $parts['host'] ?? '';
        if ($host === '') {
            return null;
        }
        $port = isset($parts['port']) ? ':' . $parts['port'] : '';
        return $scheme . '://' . $host . $port;
    }

    private function fallbackEstimateAmount(float $amount, string $currencyFrom, string $currencyTo): ?float
    {
        $rate = $this->fetchExchangeRate($currencyFrom, $currencyTo);
        if ($rate === null) {
            return null;
        }
        return $amount * $rate;
    }

    private function fetchExchangeRate(string $currencyFrom, string $currencyTo): ?float
    {
        $currencyFrom = strtoupper($currencyFrom);
        $currencyTo = strtoupper($currencyTo);
        if ($currencyFrom === $currencyTo) {
            return 1.0;
        }

        $url = 'https://api.coinbase.com/v2/exchange-rates?currency=' . urlencode($currencyFrom);
        $body = $this->simpleGet($url);
        if ($body === null) {
            return null;
        }

        $decoded = json_decode($body, true);
        if (!is_array($decoded)) {
            return null;
        }
        $rates = $decoded['data']['rates'] ?? [];
        if (!is_array($rates)) {
            return null;
        }
        if (isset($rates[$currencyTo]) && is_numeric($rates[$currencyTo])) {
            return (float) $rates[$currencyTo];
        }
        return null;
    }

    private function simpleGet(string $url): ?string
    {
        $userAgent = $this->buildUserAgent();
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTPHEADER => ['User-Agent: ' . $userAgent],
        ]);
        $res = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = $res === false ? curl_error($ch) : '';
        curl_close($ch);

        if ($res === false || $httpCode >= 400) {
            $this->trace('fallback_http_error', ['url' => $url, 'code' => $httpCode, 'error' => $err]);
            return null;
        }

        return (string) $res;
    }
}
