<?php
declare(strict_types=1);

class PaystackGateway implements PaymentGatewayInterface
{
    private string $publicKey;
    private string $secretKey;
    private string $webhookSecret;
    private string $currency;
    private string $successUrl;
    private string $cancelUrl;
    private string $merchantEmail;
    private string $apiBase;

    public function __construct(array $config)
    {
        $provider = $config['paystack'] ?? [];
        $this->publicKey     = (string)($provider['public_key'] ?? '');
        $this->secretKey     = (string)($provider['secret_key'] ?? '');
        $this->webhookSecret = (string)($provider['webhook_secret'] ?? '');
        $this->currency      = strtoupper((string)($provider['currency'] ?? ($config['currency'] ?? 'NGN')));
        $this->merchantEmail = (string)($provider['merchant_email'] ?? '');
        $this->successUrl    = (string)($config['success_url'] ?? '');
        $this->cancelUrl     = (string)($config['cancel_url'] ?? '');

        $apiBaseEnv = (string)(getenv('PAYSTACK_API_BASE')
            ?: ($_ENV['PAYSTACK_API_BASE'] ?? ($_SERVER['PAYSTACK_API_BASE'] ?? '')));
        $this->apiBase = $apiBaseEnv !== '' ? rtrim($apiBaseEnv, '/') : 'https://api.paystack.co';
    }

    public function createOneTimePayment(float $amount, string $currency, array $metadata = []): array
    {
        if ($this->secretKey === '') {
            return ['checkout_url' => '', 'reference' => '', 'error' => 'Paystack secret key is not configured.'];
        }

        $amount = max(0.5, $amount);
        $currencyCode = $currency !== '' ? strtoupper($currency) : $this->currency;
        $email = $this->resolveEmail($metadata);
        if ($email === '') {
            return ['checkout_url' => '', 'reference' => '', 'error' => 'Paystack requires a buyer email address.'];
        }

        $reference = $this->generateReference('PSTK');
        $body = [
            'amount'       => $this->formatAmountMinor($amount),
            'currency'     => $currencyCode,
            'email'        => $email,
            'reference'    => $reference,
            'callback_url' => $this->resolveRedirectUrl(),
        ];

        $meta = $this->normalizeMetadata($metadata);
        if ($this->merchantEmail !== '') {
            $meta['merchant_email'] = $this->merchantEmail;
        }
        if (!empty($meta)) {
            $body['metadata'] = $meta;
        }

        $resp = $this->postJson('/transaction/initialize', $body);
        $data = is_array($resp['data'] ?? null) ? $resp['data'] : [];
        $checkoutUrl = (string)($data['authorization_url'] ?? '');
        $providerRef = (string)($data['reference'] ?? $reference);

        if ($checkoutUrl === '') {
            $message = (string)($resp['message'] ?? 'Paystack payment initialization failed.');
            return [
                'checkout_url' => '',
                'reference'    => '',
                'error'        => $message,
                'raw'          => $resp,
                'http_code'    => $resp['http_code'] ?? null,
            ];
        }

        return [
            'checkout_url' => $checkoutUrl,
            'reference'    => $providerRef !== '' ? $providerRef : $reference,
            'raw'          => $resp,
        ];
    }

    public function createSubscription(string $planName, float $amount, string $currency, string $interval, int $intervalCount = 1, array $metadata = []): array
    {
        // Lean implementation: rely on one-time checkout; recurring automation can be added later.
        $meta = $metadata;
        $meta['subscription_interval'] = $interval;
        $meta['subscription_interval_count'] = $intervalCount;
        return $this->createOneTimePayment($amount, $currency, $meta);
    }

    public function verifyWebhook(array $headers, string $payload): array
    {
        @require_once __DIR__ . '/../helpers/webhooks_helper.php';

        $sigHeader = $this->headerValue($headers, 'x-paystack-signature');
        $secret = (string)(getenv('PAYSTACK_WEBHOOK_SECRET')
            ?: ($_ENV['PAYSTACK_WEBHOOK_SECRET'] ?? ($_SERVER['PAYSTACK_WEBHOOK_SECRET'] ?? '')));
        if ($secret === '') {
            $secret = $this->webhookSecret !== '' ? $this->webhookSecret : $this->secretKey;
        }

        if ($secret === '' || $sigHeader === '') {
            return ['valid' => false, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => null];
        }

        $computed = hash_hmac('sha512', (string) $payload, $secret);
        if (!hash_equals((string) $sigHeader, (string) $computed)) {
            return ['valid' => false, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => null];
        }

        $event = json_decode($payload, true);
        if (!is_array($event)) {
            return ['valid' => false, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => null];
        }

        $data = is_array($event['data'] ?? null) ? $event['data'] : [];
        $reference = (string)($data['reference'] ?? '');
        $meta = is_array($data['metadata'] ?? null) ? $data['metadata'] : [];
        $rawEvent = strtolower((string)($event['event'] ?? ''));

        $normalizedEvent = $rawEvent;
        if ($rawEvent === 'charge.success') {
            $normalizedEvent = 'payment_success';
        }

        return [
            'valid'     => true,
            'event'     => $normalizedEvent,
            'reference' => $reference,
            'metadata'  => $meta,
            'raw'       => $event,
        ];
    }

    private function resolveRedirectUrl(): string
    {
        if ($this->successUrl !== '') {
            return $this->successUrl;
        }
        return $this->cancelUrl !== '' ? $this->cancelUrl : '';
    }

    private function normalizeMetadata(array $metadata): array
    {
        $meta = [];
        foreach (['type','ad_id','post_id','buyer_id','recipient_id','buyer_email','buyer_name','buyer_username','title','description'] as $key) {
            if (isset($metadata[$key]) && $metadata[$key] !== '' && !is_array($metadata[$key])) {
                $meta[$key] = (string)$metadata[$key];
            }
        }
        if (!empty($metadata['email'])) { $meta['email'] = (string)$metadata['email']; }
        if (!empty($metadata['phone'])) { $meta['phone'] = (string)$metadata['phone']; }
        return $meta;
    }

    private function resolveEmail(array $metadata): string
    {
        foreach (['buyer_email', 'customer_email', 'email'] as $key) {
            if (!empty($metadata[$key]) && is_string($metadata[$key])) {
                $candidate = trim((string)$metadata[$key]);
                if ($candidate !== '') {
                    return $candidate;
                }
            }
        }
        if (!empty($metadata['buyer_username'])) {
            $maybe = trim((string)$metadata['buyer_username']);
            if ($maybe !== '') {
                return $maybe . '@example.local';
            }
        }
        return '';
    }

    private function formatAmountMinor(float $amount): int
    {
        $minor = (int) round($amount * 100);
        if ($minor < 1) {
            $minor = 1;
        }
        return $minor;
    }

    private function postJson(string $path, array $body): array
    {
        $url = (strpos($path, 'http') === 0) ? $path : ($this->apiBase . $path);
        $payload = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->secretKey,
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        $resp = curl_exec($ch);
        $errno = curl_errno($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($errno) {
            return ['error' => 'curl_error', 'errno' => $errno, 'http_code' => $httpCode];
        }

        $decoded = json_decode((string)$resp, true);
        if (!is_array($decoded)) {
            return ['error' => 'invalid_response', 'raw' => $resp, 'http_code' => $httpCode];
        }
        $decoded['http_code'] = $httpCode;
        return $decoded;
    }

    private function generateReference(string $prefix = 'PSTK'): string
    {
        return $prefix . '-' . bin2hex(random_bytes(6)) . '-' . time();
    }

    private function headerValue(array $headers, string $key): string
    {
        foreach ($headers as $k => $v) {
            if (strcasecmp((string)$k, $key) === 0) {
                return is_array($v) ? (string) reset($v) : (string) $v;
            }
        }
        if (class_exists('Headers')) {
            $val = \Headers::get($key);
            if ($val !== null) {
                return (string)$val;
            }
        }
        return '';
    }
}
