<?php
declare(strict_types=1);

class StripeGateway implements PaymentGatewayInterface
{
    private string $secretKey;
    private string $webhookSecret;
    private string $currency;
    private string $successUrl;
    private string $cancelUrl;
    private bool $keyLooksInvalid = false;

    public function __construct(array $config)
    {
        $this->secretKey = (string)($config['stripe']['secret_key'] ?? '');
        $this->webhookSecret = (string)($config['stripe']['webhook_secret'] ?? '');
        $this->currency = (string)($config['currency'] ?? 'USD');
        $this->successUrl = (string)($config['success_url'] ?? '');
        $this->cancelUrl = (string)($config['cancel_url'] ?? '');
        if ($this->secretKey !== '' && str_starts_with($this->secretKey, 'pk_')) {
            // Developer provided publishable key instead of secret; fail fast with clear error
            $this->keyLooksInvalid = true;
        }
    }

    /**
     * Verify Stripe webhook signature using the signing secret.
     * This follows Stripe's spec: https://stripe.com/docs/webhooks/signatures
     *
     * - Builds the signed payload as: <timestamp>.<rawBody>
     * - Computes HMAC-SHA256 with the signing secret
     * - Compares against one of the v1 signatures present in the header
     * - Enforces a 5 minute tolerance for the timestamp to prevent replay
     */
    public static function verifyStripeWebhook(string $rawBody, string $sigHeader, string $secret): bool
    {
        // Basic presence checks
        if ($rawBody === '' || $sigHeader === '' || $secret === '') {
            if (\defined('APP_DEBUG') && APP_DEBUG === true) {
                // Log minimal info for troubleshooting (no secrets)
                @file_put_contents(\dirname(__DIR__, 2) . '/payments_debug.log', date('c') . ' STRIPE_WH missing_parts raw=' . strlen($rawBody) . " sigHeader=" . ($sigHeader !== '' ? '1' : '0') . " secret=" . ($secret !== '' ? '1' : '0') . "\n", FILE_APPEND);
            }
            return false;
        }

        // Parse header like: "t=1492774577,v1=5257a..." (may include multiple v1 entries)
        $parts = [];
        foreach (explode(',', $sigHeader) as $p) {
            $kv = explode('=', trim($p), 2);
            if (count($kv) === 2) {
                $k = strtolower($kv[0]);
                $v = trim($kv[1]);
                if (!isset($parts[$k])) { $parts[$k] = []; }
                $parts[$k][] = $v;
            }
        }

        $timestamps = $parts['t'] ?? [];
        $sigsV1     = $parts['v1'] ?? [];
        if (empty($timestamps) || empty($sigsV1)) {
            if (\defined('APP_DEBUG') && APP_DEBUG === true) {
                @file_put_contents(\dirname(__DIR__, 2) . '/payments_debug.log', date('c') . ' STRIPE_WH missing_t_or_v1' . "\n", FILE_APPEND);
            }
            return false;
        }

        // Use the first timestamp if multiple are present
        $ts = (int) $timestamps[0];
        // Tolerance (seconds) per Stripe recommendation
        $tolerance = 300;
        $now = time();
        if ($ts <= 0 || abs($now - $ts) > $tolerance) {
            if (\defined('APP_DEBUG') && APP_DEBUG === true) {
                @file_put_contents(\dirname(__DIR__, 2) . '/payments_debug.log', date('c') . ' STRIPE_WH ts_out_of_range ts=' . $ts . ' now=' . $now . "\n", FILE_APPEND);
            }
            return false;
        }

        $signedPayload = $ts . '.' . $rawBody;
        $expected = hash_hmac('sha256', $signedPayload, $secret);

        // Constant-time compare against any provided v1 signature
        foreach ($sigsV1 as $cand) {
            if (hash_equals($expected, $cand)) {
                return true;
            }
        }

        if (\defined('APP_DEBUG') && APP_DEBUG === true) {
            @file_put_contents(\dirname(__DIR__, 2) . '/payments_debug.log', date('c') . ' STRIPE_WH sig_mismatch' . "\n", FILE_APPEND);
        }
        return false;
    }

    public function createOneTimePayment(float $amount, string $currency, array $metadata = []): array
    {
        if ($this->keyLooksInvalid || $this->secretKey === '') {
            return ['error' => 'Invalid Stripe secret key (use sk_test_... or sk_live_...).'];
        }
        // Using Stripe Checkout Session via raw HTTP (no SDK dependency)
        if ($currency === '') { $currency = $this->currency; }
        $amountMinor = (int) round($amount * 100); // Stripe expects amount in cents
        $productName = (string) ($metadata['title'] ?? 'Advertisement');
        $data = [
            'mode' => 'payment',
            'ui_mode' => 'hosted',
            'success_url' => $this->successUrl,
            'cancel_url' => $this->cancelUrl,
            'line_items[0][price_data][currency]' => $currency,
            'line_items[0][price_data][product_data][name]' => $productName,
            'line_items[0][price_data][unit_amount]' => (string) $amountMinor,
            'line_items[0][quantity]' => '1',
        ];

        if (isset($metadata['description'])) {
            $data['line_items[0][price_data][product_data][description]'] = (string) $metadata['description'];
        }

        foreach ($this->normalizeMetadata($metadata) as $metaKey => $metaValue) {
            $data['metadata[' . $metaKey . ']'] = $metaValue;
        }

        $resp = $this->curl('https://api.stripe.com/v1/checkout/sessions', $data);
        $checkoutUrl = $resp['url'] ?? '';
        $reference = $resp['id'] ?? '';
        if ($checkoutUrl === '' && isset($resp['error']) && $resp['error']) {
            return ['error' => (string)$resp['error'], 'raw' => $resp];
        }
        return ['checkout_url' => $checkoutUrl, 'reference' => $reference, 'raw' => $resp];
    }

    public function createSubscription(string $planName, float $amount, string $currency, string $interval, int $intervalCount = 1, array $metadata = []): array
    {
        if ($currency === '') { $currency = $this->currency; }
        $amountMinor = (int) round($amount * 100);
        $interval = in_array($interval, ['day','week','month','year'], true) ? $interval : 'month';
        $productName = $metadata['title'] ?? $planName;
        $data = [
            'mode' => 'subscription',
            'success_url' => $this->successUrl,
            'cancel_url' => $this->cancelUrl,
            'line_items[0][price_data][currency]' => $currency,
            'line_items[0][price_data][product_data][name]' => $productName,
            'line_items[0][price_data][recurring][interval]' => $interval,
            'line_items[0][price_data][recurring][interval_count]' => (string)$intervalCount,
            'line_items[0][price_data][unit_amount]' => (string) $amountMinor,
            'line_items[0][quantity]' => '1',
        ];

        if (isset($metadata['description'])) {
            $data['line_items[0][price_data][product_data][description]'] = (string) $metadata['description'];
        }

        foreach ($this->normalizeMetadata($metadata) as $metaKey => $metaValue) {
            $data['metadata[' . $metaKey . ']'] = $metaValue;
        }
        $resp = $this->curl('https://api.stripe.com/v1/checkout/sessions', $data);
        return ['checkout_url' => $resp['url'] ?? '', 'reference' => $resp['id'] ?? '', 'raw' => $resp];
    }

    public function verifyWebhook(array $headers, string $payload): array
    {
        // Extract Stripe-Signature header case-insensitively
        @require_once __DIR__ . '/../helpers/webhooks_helper.php';

        $sigHeader = '';
        if (is_array($headers)) {
            foreach ($headers as $key => $value) {
                if (strcasecmp((string) $key, 'Stripe-Signature') === 0) {
                    $sigHeader = is_array($value) ? (string) reset($value) : (string) $value;
                    break;
                }
            }
        }

        if ($sigHeader === '' && class_exists('Headers') && method_exists('Headers', 'get')) {
            $fallback = Headers::get('Stripe-Signature');
            if ($fallback !== null && $fallback !== '') {
                $sigHeader = (string) $fallback;
            }
        }

        // Resolve signing secret: ENV first, then admin/DB fallback
        $secret = (string) (getenv('STRIPE_WEBHOOK_SECRET')
            ?: ($_ENV['STRIPE_WEBHOOK_SECRET'] ?? ($_SERVER['STRIPE_WEBHOOK_SECRET'] ?? '')));
        if ($secret === '') { $secret = $this->webhookSecret; }

        // Verify signature against raw payload; return early on failure
        $isValid = self::verifyStripeWebhook($payload, $sigHeader, $secret);
        if (!$isValid) {
            return ['valid' => false, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => null];
        }

        // Only parse JSON after signature verification
        $event = json_decode($payload, true);
        $ok = is_array($event) && isset($event['type']);
        if (!$ok) {
            return ['valid' => false, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => null];
        }

        $type = (string) $event['type'];
        $normalized = ($type === 'checkout.session.completed' || $type === 'invoice.payment_succeeded') ? 'payment_success' : $type;
        $out = [
            'valid'     => true,
            'event'     => $normalized,
            'reference' => '',
            'metadata'  => [],
            'raw'       => $event,
        ];

        $session = $event['data']['object'] ?? [];
        if (is_array($session)) {
            $out['reference'] = (string) ($session['id'] ?? '');
            if (isset($session['metadata']) && is_array($session['metadata'])) {
                $out['metadata'] = $session['metadata'];
            }
        }
        return $out;
    }

    /**
     * Allowed Stripe event types we actually consume.
     *
     * Mini test checklist:
     * - Valid signature + checkout.session.completed → payment_success
     * - Valid signature + invoice.payment_succeeded  → payment_success
     * - Missing/invalid signature or secret → HTTP 400 upstream
     * - Non-whitelisted types → 200 ignored upstream
     */
    public static function allowedEventTypes(): array
    {
        return [
            'checkout.session.completed',
            'invoice.payment_succeeded',
            // Subscription lifecycle events we act on
            'customer.subscription.deleted',
            'customer.subscription.updated',
        ];
    }

    /**
     * Normalize arbitrary payment metadata into the format Stripe expects.
     */
    private function normalizeMetadata(array $metadata): array
    {
        $normalized = [];

        foreach ($metadata as $key => $value) {
            if (in_array($key, ['title', 'description'], true)) {
                continue;
            }

            if ($value === null) {
                continue;
            }

            if (is_bool($value)) {
                $value = $value ? '1' : '0';
            } elseif (!is_scalar($value)) {
                continue;
            }

            $stringValue = (string) $value;
            if ($stringValue === '') {
                continue;
            }

            $normalized[$key] = $stringValue;
        }

        return $normalized;
    }

    private function curl(string $url, array $data): array
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->secretKey,
            'Content-Type: application/x-www-form-urlencoded'
        ]);
        $res = curl_exec($ch);
        $http = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($res === false) { $err = curl_error($ch); curl_close($ch); return ['error' => $err]; }
        curl_close($ch);
        $j = json_decode($res, true);
        if (is_array($j)) {
            // Normalize Stripe error payload to a simple 'error' string if present
            if (isset($j['error'])) {
                if (is_array($j['error']) && isset($j['error']['message'])) {
                    return ['error' => (string)$j['error']['message'], 'http' => $http, 'raw' => $j];
                }
                // If error not structured, cast to string
                return ['error' => is_string($j['error']) ? $j['error'] : 'Unknown Stripe error', 'http' => $http, 'raw' => $j];
            }
            $j['http'] = $http;
            return $j;
        }
        return ['raw' => $res, 'http' => $http];
    }

    /** Cancel a Stripe subscription by id. */
    public function cancelSubscription(string $subscriptionId): array
    {
        if ($this->keyLooksInvalid || $this->secretKey === '' || $subscriptionId === '') {
            return ['error' => 'Missing Stripe credentials or subscription id.'];
        }
        $ch = curl_init('https://api.stripe.com/v1/subscriptions/' . rawurlencode($subscriptionId));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->secretKey,
        ]);
        $res = curl_exec($ch);
        $http = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($res === false) { $err = curl_error($ch); curl_close($ch); return ['error' => $err]; }
        curl_close($ch);
        $j = json_decode($res, true);
        if ($http >= 200 && $http < 300) { return ['ok' => true, 'raw' => $j, 'http' => $http]; }
        return ['error' => is_array($j) && isset($j['error']['message']) ? (string)$j['error']['message'] : 'Stripe cancel failed', 'raw' => $j, 'http' => $http];
    }
}
