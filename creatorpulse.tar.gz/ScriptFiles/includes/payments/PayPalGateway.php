<?php
declare(strict_types=1);

class PayPalGateway implements PaymentGatewayInterface
{
    private string $clientId;
    private string $clientSecret;
    private string $currency;
    private string $successUrl;
    private string $cancelUrl;
    private string $baseUrl;
    private string $webhookId = '';
    private string $lastVerifyError = '';

    public function __construct(array $config)
    {
        $env = ($config['paypal']['environment'] ?? 'sandbox') === 'live' ? 'live' : 'sandbox';
        $this->baseUrl = $env === 'live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
        $this->clientId = (string)($config['paypal']['client_id'] ?? '');
        $this->clientSecret = (string)($config['paypal']['client_secret'] ?? '');
        $this->currency = (string)($config['currency'] ?? 'USD');
        $this->successUrl = (string)($config['success_url'] ?? '');
        $this->cancelUrl = (string)($config['cancel_url'] ?? '');
        $this->webhookId = (string)($config['paypal']['webhook_id'] ?? '');
    }

    public function createOneTimePayment(float $amount, string $currency, array $metadata = []): array
    {
        if ($currency === '') { $currency = $this->currency; }
        $token = $this->token();

        $description = isset($metadata['title']) ? (string) $metadata['title'] : '';
        $customId = $this->encodeMetadata($metadata);
        if ($customId === '' && array_key_exists('ad_id', $metadata)) {
            $customId = (string) $metadata['ad_id'];
        }
        $invoiceId = '';
        if (isset($metadata['reference']) && $metadata['reference'] !== '') {
            $invoiceId = substr((string) $metadata['reference'], 0, 127);
        }

        $purchaseUnit = [
            'amount' => [
                'currency_code' => $currency,
                'value' => number_format($amount, 2, '.', '')
            ],
        ];
        if ($customId !== '') {
            $purchaseUnit['custom_id'] = $customId;
        }
        if ($invoiceId !== '') {
            $purchaseUnit['invoice_id'] = $invoiceId;
        }

        $body = [
            'intent' => 'CAPTURE',
            'purchase_units' => [$purchaseUnit],
            'application_context' => [
                'return_url' => $this->successUrl,
                'cancel_url' => $this->cancelUrl
            ]
        ];

        if ($description !== '') {
            $body['purchase_units'][0]['description'] = $description;
        }
        $resp = $this->postJson($this->baseUrl . '/v2/checkout/orders', $body, $token);
        $approve = '';
        if (isset($resp['links']) && is_array($resp['links'])) {
            foreach ($resp['links'] as $l) { if (($l['rel'] ?? '') === 'approve') { $approve = (string)$l['href']; break; } }
        }
        return ['checkout_url' => $approve, 'reference' => (string)($resp['id'] ?? ''), 'raw' => $resp];
    }

    public function createSubscription(string $planName, float $amount, string $currency, string $interval, int $intervalCount = 1, array $metadata = []): array
    {
        // Implements: Product -> Plan (activate) -> Subscription (approval link)
        // Interval map: weekly|monthly|yearly|month (for halfyear the caller passes month+6)
        if ($currency === '') { $currency = $this->currency; }
        $token = $this->token();
        if ($token === '') { return ['error' => 'Unable to obtain PayPal access token']; }

        // 1) Create product (SERVICE)
        $prodBody = [
            'name'        => $planName ?: 'Creator Subscription',
            'type'        => 'SERVICE',
            'category'    => 'SOFTWARE',
            'description' => 'Recurring subscription plan created on demand.'
        ];
        $prod = $this->postJson($this->baseUrl . '/v1/catalogs/products', $prodBody, $token);
        $productId = isset($prod['id']) ? (string)$prod['id'] : '';
        if ($productId === '') { return ['error' => 'PayPal product creation failed', 'raw' => $prod]; }

        // 2) Create plan
        $unit = strtoupper($interval ?: 'MONTH');
        if (!in_array($unit, ['WEEK','MONTH','YEAR'], true)) { $unit = 'MONTH'; }
        if ($intervalCount < 1) { $intervalCount = 1; }
        $planBody = [
            'product_id' => $productId,
            'name'       => $planName ?: ('Plan ' . date('Y-m-d H:i')),
            'billing_cycles' => [[
                'frequency'      => ['interval_unit' => $unit, 'interval_count' => $intervalCount],
                'tenure_type'    => 'REGULAR',
                'sequence'       => 1,
                'total_cycles'   => 0,
                'pricing_scheme' => ['fixed_price' => ['value' => number_format($amount, 2, '.', ''), 'currency_code' => $currency]],
            ]],
            'payment_preferences' => [
                'auto_bill_outstanding' => true,
                'payment_failure_threshold' => 1
            ],
        ];
        $plan = $this->postJson($this->baseUrl . '/v1/billing/plans', $planBody, $token);
        $planId = isset($plan['id']) ? (string)$plan['id'] : '';
        if ($planId === '') { return ['error' => 'PayPal plan creation failed', 'raw' => $plan]; }

        // 3) Activate plan (required before subscribing)
        $ch = curl_init($this->baseUrl . '/v1/billing/plans/' . rawurlencode($planId) . '/activate');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['reason' => 'Activate for checkout']));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $token,
        ]);
        $actRes = curl_exec($ch);
        $actCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($actCode !== 204) { /* not fatal, but warn via payload */ }

        // 4) Create subscription (approval link)
        // Encode our metadata into custom_id for webhook correlation.
        $subscriptionMeta = $metadata;
        $subscriptionMeta['buyer_id'] = (string) ($metadata['buyer_id'] ?? '');
        $subscriptionMeta['recipient_id'] = (string) ($metadata['recipient_id'] ?? '');
        $subscriptionMeta['interval'] = (string) ($metadata['interval'] ?? $interval);
        $subscriptionMeta['interval_count'] = (string) ($metadata['interval_count'] ?? $intervalCount);
        $subscriptionMeta['type'] = 'subscription';
        $custom = $this->encodeMetadata($subscriptionMeta);
        $subBody = [
            'plan_id'  => $planId,
            'custom_id'=> $custom,
            'application_context' => [
                'brand_name'          => 'Subscription',
                'user_action'         => 'SUBSCRIBE_NOW',
                'return_url'          => $this->successUrl,
                'cancel_url'          => $this->cancelUrl
            ],
        ];
        $sub = $this->postJson($this->baseUrl . '/v1/billing/subscriptions', $subBody, $token);
        $subId = isset($sub['id']) ? (string)$sub['id'] : '';
        if ($subId === '') { return ['error' => 'PayPal subscription creation failed', 'raw' => $sub]; }
        $approve = '';
        if (isset($sub['links']) && is_array($sub['links'])) {
            foreach ($sub['links'] as $l) { if (($l['rel'] ?? '') === 'approve') { $approve = (string)$l['href']; break; } }
        }
        return ['checkout_url' => $approve, 'reference' => $subId, 'raw' => $sub];
    }

    /** Attempt to cancel a PayPal subscription by id (requires real plan/subscription integration). */
    public function cancelSubscription(string $subscriptionId): array
    {
        // Placeholder implementation; to fully support, use PayPal Subscriptions API:
        // POST /v1/billing/subscriptions/{id}/cancel with JSON {reason: 'User requested cancellation'}
        $token = $this->token();
        if ($subscriptionId === '' || $token === '') { return ['error' => 'Missing subscription id or access token']; }
        $url = $this->baseUrl . '/v1/billing/subscriptions/' . rawurlencode($subscriptionId) . '/cancel';
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['reason' => 'User requested cancellation']));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $token,
        ]);
        $res = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($res === false) { $err = curl_error($ch); curl_close($ch); return ['error'=>$err]; }
        curl_close($ch);
        if ($code === 204) { return ['ok' => true, 'http' => $code]; }
        $j = json_decode($res, true);
        return ['error' => 'PayPal cancel failed', 'http' => $code, 'raw' => $j ?: $res];
    }

    /**
     * Attempt to validate CHECKOUT.ORDER.APPROVED events by fetching the order when signature verification fails.
     *
     * @param array<string, mixed> $event
     *
     * @return array<string, mixed>|null
     */
    private function fallbackCheckoutOrderApproval(array $event): ?array
    {
        $resource = isset($event['resource']) && is_array($event['resource']) ? $event['resource'] : [];
        $orderId = (string) ($resource['id'] ?? '');
        if ($orderId === '') {
            return null;
        }

        $order = $this->fetchOrder($orderId);
        if (!is_array($order)) {
            return null;
        }

        $orderStatus = strtoupper((string) ($order['status'] ?? ''));
        if ($orderStatus !== 'APPROVED' && $orderStatus !== 'COMPLETED') {
            return null;
        }

        $customId = $this->extractCustomIdFromContexts($resource, $order);
        $metadata = $customId !== '' ? $this->decodeMetadataString($customId) : [];
        $cartId = $this->resolveCartIdFromOrder($order);
        if ($cartId !== '') {
            $metadata['reference'] = $cartId;
        } elseif (empty($metadata['reference'])) {
            $metadata['reference'] = $this->resolveReferenceFromContexts($resource, $order);
        }

        $reference = (string) ($metadata['reference'] ?? '');
        if ($reference === '') {
            return null;
        }

        if (!isset($metadata['type']) && isset($resource['purchase_units'][0]['custom_id'])) {
            $decoded = $this->decodeMetadataString((string) $resource['purchase_units'][0]['custom_id']);
            if (!empty($decoded)) {
                $metadata = array_merge($metadata, $decoded);
            }
        }

        if (!isset($metadata['provider_reference'])) {
            $metadata['provider_reference'] = $orderId;
        }
        if ($cartId !== '' && $metadata['provider_reference'] === $reference) {
            $metadata['provider_reference'] = $orderId;
        }

        $raw = $event;
        $raw['fallback_order'] = $order;

        return [
            'event' => (string) ($event['event_type'] ?? ''),
            'reference' => $reference,
            'metadata' => $metadata,
            'raw' => $raw,
        ];
    }

    /**
     * Fetch checkout order details from PayPal.
     *
     * @return array<string, mixed>|null
     */
    private function fetchOrder(string $orderId): ?array
    {
        if ($orderId === '') {
            return null;
        }
        $token = $this->token();
        if ($token === '') {
            return null;
        }

        $url = $this->baseUrl . '/v2/checkout/orders/' . rawurlencode($orderId);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $token,
        ]);
        $res = curl_exec($ch);
        if ($res === false) {
            curl_close($ch);
            return null;
        }
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code < 200 || $code >= 300) {
            return null;
        }

        $decoded = json_decode((string) $res, true);
        return is_array($decoded) ? $decoded : null;
    }
    /**
     * @param array<string, mixed> $order
     */
    private function resolveCartIdFromOrder(array $order): string
    {
        if (isset($order['payment_source']['paypal']['experience_context']['payment_options']['cart_id'])) {
            $cartId = (string) $order['payment_source']['paypal']['experience_context']['payment_options']['cart_id'];
            if ($cartId !== '') {
                return $cartId;
            }
        }
        $purchaseUnits = $order['purchase_units'] ?? [];
        if (is_array($purchaseUnits)) {
            foreach ($purchaseUnits as $unit) {
                if (!is_array($unit)) {
                    continue;
                }
                $options = $unit['payment_instruction']['disbursement_mode'] ?? null;
                if (is_array($options) && isset($options['cart_id'])) {
                    $cartCandidate = (string) $options['cart_id'];
                    if ($cartCandidate !== '') {
                        return $cartCandidate;
                    }
                }
            }
        }

        return '';
    }

    /**
     * @param array<string, mixed> $resource
     * @param array<string, mixed> $order
     */
    private function resolveReferenceFromContexts(array $resource, array $order): string
    {
        $candidates = [];
        if (isset($resource['purchase_units'][0]['invoice_id'])) {
            $candidates[] = (string) $resource['purchase_units'][0]['invoice_id'];
        }
        if (isset($resource['invoice_id'])) {
            $candidates[] = (string) $resource['invoice_id'];
        }
        if (isset($order['purchase_units'][0]['invoice_id'])) {
            $candidates[] = (string) $order['purchase_units'][0]['invoice_id'];
        }
        if (isset($order['id'])) {
            $candidates[] = (string) $order['id'];
        }

        foreach ($candidates as $candidate) {
            $candidate = trim($candidate);
            if ($candidate !== '') {
                return $candidate;
            }
        }

        return '';
    }

    /**
     * @param array<string, mixed> $resource
     * @param array<string, mixed> $order
     */
    private function extractCustomIdFromContexts(array $resource, array $order): string
    {
        $candidates = [];
        if (isset($resource['purchase_units'][0]['custom_id'])) {
            $candidates[] = (string) $resource['purchase_units'][0]['custom_id'];
        }
        if (isset($resource['custom_id'])) {
            $candidates[] = (string) $resource['custom_id'];
        }
        if (isset($order['purchase_units'][0]['custom_id'])) {
            $candidates[] = (string) $order['purchase_units'][0]['custom_id'];
        }
        if (isset($order['custom_id'])) {
            $candidates[] = (string) $order['custom_id'];
        }

        foreach ($candidates as $candidate) {
            $candidate = trim($candidate);
            if ($candidate !== '') {
                return $candidate;
            }
        }

        return '';
    }

    /**
     * Validate PayPal webhook via verify-webhook-signature, then map event.
     */
    public function verifyWebhook(array $headers, string $payload): array
    {
        $event = json_decode($payload, true);
        $isVerified = $this->verifyPayPalWebhook($headers, (string) $payload);
        $valid = $isVerified && is_array($event) && isset($event['event_type']);
        $out = ['valid' => $valid, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => $event];
        if (!$valid) {
            if (isset($event['event_type']) && $event['event_type'] === 'CHECKOUT.ORDER.APPROVED') {
                $fallback = $this->fallbackCheckoutOrderApproval($event);
                if ($fallback !== null) {
                    if (defined('APP_DEBUG') && APP_DEBUG === true) {
                        @file_put_contents(
                            dirname(__DIR__, 2) . '/payments_debug.log',
                            date('c') . ' PAYPAL_VERIFY_FALLBACK order=' . ($fallback['reference'] ?? '') . "\n",
                            FILE_APPEND
                        );
                    }
                    return $fallback + ['valid' => true];
                }
            }
            if ($this->lastVerifyError !== '') {
                $out['error'] = $this->lastVerifyError;
            }
            return $out;
        }
        $type = (string)$event['event_type'];
        // Treat CAPTURE completed as definitive success for one-time payments. ORDER.APPROVED means user approved but not yet captured.
        if ($type === 'PAYMENT.CAPTURE.COMPLETED') {
            $out['event'] = 'payment_success';
        } else {
            $out['event'] = $type; // informational for other events
        }
        $resource = $event['resource'] ?? [];
        if (is_array($resource)) {
            // For captures (one-time), resource has purchase_units[0].custom_id used for ads (ad_id)
            if (isset($resource['purchase_units'][0]['custom_id'])) {
                $out['reference'] = (string)($resource['id'] ?? '');
                $customId = (string)$resource['purchase_units'][0]['custom_id'];
                if ($customId !== '') {
                    $decoded = $this->decodeMetadataString($customId);
                    $out['metadata'] = !empty($decoded) ? $decoded : ['ad_id' => $customId];
                }
            }
            // For subscriptions: BILLING.SUBSCRIPTION.* events contain subscription in resource with custom_id
            if (isset($resource['custom_id'])) {
                $out['reference'] = (string)($resource['id'] ?? '');
                $decoded = $this->decodeMetadataString((string)$resource['custom_id']);
                if (!empty($decoded)) { $out['metadata'] = $decoded; }
            }
            // Prefer related order id so it matches the original checkout reference.
            $relatedIds = $resource['supplementary_data']['related_ids'] ?? [];
            if (isset($relatedIds['order_id'])) {
                $orderId = (string) $relatedIds['order_id'];
                if ($orderId !== '') {
                    $out['reference'] = $orderId;
                    if (!isset($out['metadata']['order_id'])) {
                        $out['metadata']['order_id'] = $orderId;
                    }
                }
            }
            if (isset($resource['id']) && $resource['id'] !== '') {
                $out['metadata']['capture_id'] = (string) $resource['id'];
            }
            // For sale completed with billing_agreement_id (legacy): map as reference
            if ($out['reference'] === '' && isset($resource['billing_agreement_id'])) {
                $out['reference'] = (string)$resource['billing_agreement_id'];
            }
        }

        // Auto-capture CAPTURE intent orders once the buyer approves checkout.
        if ($type === 'CHECKOUT.ORDER.APPROVED') {
            $orderId = (string)($out['reference'] ?? '');
            if ($orderId === '' && isset($resource['id'])) {
                $orderId = (string)$resource['id'];
            }
            if ($orderId !== '') {
                $out['reference'] = $orderId;
            }

            $intent = strtolower((string)($resource['intent'] ?? ''));
            if ($orderId !== '' && $intent === 'capture') {
                $captureResponse = $this->captureOrder($orderId);
                $out['raw']['capture'] = $captureResponse;

                $captureSucceeded = false;
                $captureId = '';
                $captureStatus = '';

                if (is_array($captureResponse)) {
                    $primaryCapture = [];
                    if (isset($captureResponse['purchase_units'][0]['payments']['captures'][0]) && is_array($captureResponse['purchase_units'][0]['payments']['captures'][0])) {
                        $primaryCapture = $captureResponse['purchase_units'][0]['payments']['captures'][0];
                        $captureStatus = strtoupper((string)($primaryCapture['status'] ?? ''));
                        $captureId = (string)($primaryCapture['id'] ?? '');
                    } else {
                        $captureStatus = strtoupper((string)($captureResponse['status'] ?? ''));
                    }

                    if ($captureStatus === 'COMPLETED') {
                        $captureSucceeded = true;
                    } else {
                        $errorName = strtoupper((string)($captureResponse['name'] ?? ''));
                        if (in_array($errorName, ['ORDER_ALREADY_CAPTURED', 'ORDER_ALREADY_COMPLETED'], true)) {
                            $captureSucceeded = true;
                        }
                    }

                    if ($captureSucceeded) {
                        if ($captureId !== '') {
                            $out['metadata']['capture_id'] = $captureId;
                        }
                        if (!empty($primaryCapture['seller_receivable_breakdown']) && is_array($primaryCapture['seller_receivable_breakdown'])) {
                            $out['raw']['capture_breakdown'] = $primaryCapture['seller_receivable_breakdown'];
                        }
                        $out['event'] = 'payment_success';
                    } else {
                        $out['raw']['capture_error'] = $captureResponse;
                    }
                } else {
                    $out['raw']['capture_error'] = $captureResponse;
                }
            }
        }

        if (($out['metadata']['type'] ?? '') === 'wallet_topup') {
            $metaReference = (string)($out['metadata']['reference'] ?? '');
            if ($metaReference !== '') {
                $providerReference = (string)($out['reference'] ?? '');
                if (
                    $providerReference !== ''
                    && $providerReference !== $metaReference
                    && !isset($out['metadata']['provider_reference'])
                ) {
                    $out['metadata']['provider_reference'] = $providerReference;
                }
                $out['reference'] = $metaReference;
            }
        }

        return $out;
    }

    private function encodeMetadata(array $metadata): string
    {
        $filtered = [];

        foreach ($metadata as $key => $value) {
            if (in_array($key, ['title', 'description'], true)) {
                continue;
            }

            if ($value === null) {
                continue;
            }

            if (is_bool($value)) {
                $value = $value ? '1' : '0';
            } elseif (!is_scalar($value)) {
                continue;
            }

            $stringValue = (string) $value;
            if ($stringValue === '') {
                continue;
            }

            $filtered[$key] = $stringValue;
        }

        if (empty($filtered)) {
            return '';
        }

        return http_build_query($filtered, '', '&', PHP_QUERY_RFC3986);
    }

    private function decodeMetadataString(string $value): array
    {
        if ($value === '' || strpos($value, '=') === false) {
            return [];
        }

        $decoded = [];
        parse_str($value, $decoded);

        if (!is_array($decoded) || empty($decoded)) {
            return [];
        }

        $sanitized = [];
        foreach ($decoded as $key => $entry) {
            if (is_array($entry) || $entry === null) {
                continue;
            }

            $sanitized[$key] = (string) $entry;
        }

        return $sanitized;
    }

    /**
     * Verify a PayPal webhook using the official REST endpoint.
     * - Collect required headers case-insensitively.
     * - POST to /v1/notifications/verify-webhook-signature with OAuth2 Bearer.
     * - Accept only verification_status SUCCESS (IPN uses VERIFIED; we accept that too for safety).
     */
    public function verifyPayPalWebhook(array $headers, string $rawBody): bool
    {
        $this->lastVerifyError = '';

        // Normalize header keys for case-insensitive access
        $h = [];
        foreach ($headers as $k => $v) { $h[strtolower((string) $k)] = (string) $v; }

        // Required pieces per PayPal docs
        $transmissionId   = $h['paypal-transmission-id']   ?? ($h['transmission-id']   ?? '');
        $transmissionTime = $h['paypal-transmission-time'] ?? ($h['transmission-time'] ?? '');
        $certUrl          = $h['paypal-cert-url']          ?? ($h['cert-url']          ?? '');
        $authAlgo         = $h['paypal-auth-algo']         ?? ($h['auth-algo']         ?? '');
        $transmissionSig  = $h['paypal-transmission-sig']  ?? ($h['transmission-sig']  ?? '');
        // Webhook ID: prefer header if present, else env var PAYPAL_WEBHOOK_ID
        // Priority: header → env/config → DB (resolver provides env first then DB)
        $headerWebhookId = $h['paypal-webhook-id'] ?? '';
        $webhookId = $headerWebhookId;
        if ($webhookId === '') { $webhookId = $this->webhookId; }
        if ($webhookId === '') {
            $webhookId = (string) (getenv('PAYPAL_WEBHOOK_ID') ?: ($_ENV['PAYPAL_WEBHOOK_ID'] ?? ($_SERVER['PAYPAL_WEBHOOK_ID'] ?? '')));
        }
        $resolvedWebhookId = $webhookId;

        // If any critical value missing, fail early
        if ($transmissionId === '' || $transmissionTime === '' || $certUrl === '' || $authAlgo === '' || $transmissionSig === '' || $webhookId === '' || $rawBody === '') {
            $this->lastVerifyError = 'missing_parts:webhook=' . $webhookId . ',header=' . $headerWebhookId;
            if (\defined('APP_DEBUG') && APP_DEBUG === true) {
                @file_put_contents(\dirname(__DIR__, 2) . '/payments_debug.log', date('c') . ' PAYPAL_WH missing_parts' . "\n", FILE_APPEND);
            }
            return false;
        }
        // Enforce clock-skew tolerance for transmission_time to prevent replay.
        $tolerance = 900; // Default: 15 minutes
        $enforceSkew = true;
        $toleranceEnv = getenv('PAYPAL_WEBHOOK_TOLERANCE')
            ?: ($_ENV['PAYPAL_WEBHOOK_TOLERANCE'] ?? ($_SERVER['PAYPAL_WEBHOOK_TOLERANCE'] ?? ''));
        if ($toleranceEnv !== null && $toleranceEnv !== '') {
            $trimmedTol = trim((string) $toleranceEnv);
            if ($trimmedTol === '0' || strtolower($trimmedTol) === 'off' || strtolower($trimmedTol) === 'disabled') {
                $enforceSkew = false;
            } elseif (is_numeric($trimmedTol)) {
                $tolerance = max(60, (int) $trimmedTol);
            }
        }
        $ts = strtotime($transmissionTime);
        $now = time();
        if ($ts === false) {
            $this->lastVerifyError = 'timestamp_parse_failed:webhook=' . $webhookId;
            if (\defined('APP_DEBUG') && APP_DEBUG === true) {
                @file_put_contents(\dirname(__DIR__, 2) . '/payments_debug.log', date('c') . ' PAYPAL_WH ts_parse_failed raw=' . $transmissionTime . "\n", FILE_APPEND);
            }
            return false;
        }
        $skew = abs($now - (int) $ts);
        if ($enforceSkew && $skew > $tolerance) {
            $this->lastVerifyError = 'timestamp_skew_' . $skew . ':webhook=' . $webhookId;
            if (\defined('APP_DEBUG') && APP_DEBUG === true) {
                @file_put_contents(\dirname(__DIR__, 2) . '/payments_debug.log', date('c') . ' PAYPAL_WH ts_out_of_range ts=' . $ts . ' now=' . $now . ' skew=' . $skew . ' tolerance=' . $tolerance . "\n", FILE_APPEND);
            }
            return false;
        }

        // Try to parse body once (PayPal expects JSON object here)
        $event = json_decode($rawBody, true);
        if (!is_array($event)) {
            $this->lastVerifyError = 'invalid_event_json';
            return false;
        }

        $token = $this->token();
        if ($token === '') {
            $this->lastVerifyError = 'missing_token:webhook=' . $webhookId;
            return false;
        }

        $url = $this->baseUrl . '/v1/notifications/verify-webhook-signature';
        $body = [
            'transmission_id'   => $transmissionId,
            'transmission_time' => $transmissionTime,
            'cert_url'          => $certUrl,
            'auth_algo'         => $authAlgo,       // required by PayPal
            'transmission_sig'  => $transmissionSig,
            'webhook_id'        => $webhookId,
            'webhook_event'     => $event,
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $token,
        ]);
        $res = curl_exec($ch);
        if ($res === false) {
            $curlErr = curl_error($ch);
            $this->lastVerifyError = 'curl_error' . ($curlErr !== '' ? ':' . $curlErr : '') . ':webhook=' . $webhookId;
            if (\defined('APP_DEBUG') && APP_DEBUG === true) {
                @file_put_contents(\dirname(__DIR__, 2) . '/payments_debug.log', date('c') . ' PAYPAL_WH curl_error' . "\n", FILE_APPEND);
            }
            curl_close($ch);
            return false;
        }
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code < 200 || $code >= 300) {
            $this->lastVerifyError = 'verify_http_' . $code . ':webhook=' . $webhookId;
            if (\defined('APP_DEBUG') && APP_DEBUG === true) {
                $bodySnippet = substr(is_string($res) ? $res : '', 0, 400);
                @file_put_contents(
                    \dirname(__DIR__, 2) . '/payments_debug.log',
                    date('c') . ' PAYPAL_WH http_code=' . $code . ' body=' . $bodySnippet . "\n",
                    FILE_APPEND
                );
            }
            return false;
        }
        $j = json_decode((string) $res, true);
        if (!is_array($j)) { return false; }

        $status = strtoupper((string)($j['verification_status'] ?? ''));
        $failureReason = '';
        if (isset($j['failure_reason'])) {
            if (is_array($j['failure_reason'])) {
                $failureReason = trim((string)($j['failure_reason']['name'] ?? $j['failure_reason']['description'] ?? ''));
            } else {
                $failureReason = trim((string)$j['failure_reason']);
            }
        }
        // PayPal REST returns SUCCESS/FAILURE; accept SUCCESS (and also VERIFIED for safety)
        if ($status === 'SUCCESS' || $status === 'VERIFIED') {
            return true;
        }

        $snippet = substr(json_encode($j, JSON_UNESCAPED_UNICODE), 0, 200);
        $reasonSuffix = $failureReason !== '' ? ':reason=' . $failureReason : '';
        $this->lastVerifyError = 'verify_status_' . $status . $reasonSuffix . ':webhook=' . $resolvedWebhookId . ',header=' . $headerWebhookId . ($snippet !== '' ? ':' . $snippet : '');
        if (\defined('APP_DEBUG') && APP_DEBUG === true) {
            $logLine = date('c') . ' PAYPAL_VERIFY_RESPONSE status=' . $status
                . ' failure_reason=' . ($failureReason !== '' ? $failureReason : 'n/a')
                . ' webhook=' . $resolvedWebhookId
                . ' header_id=' . $headerWebhookId
                . ' response=' . json_encode($j, JSON_UNESCAPED_UNICODE);
            @file_put_contents(\dirname(__DIR__, 2) . '/payments_debug.log', $logLine . "\n", FILE_APPEND);
        }
        return false;
    }

    /** Capture an approved PayPal order (optional utility). */
    public function captureOrder(string $orderId): array
    {
        $token = $this->token();
        if ($token === '') { return ['error' => 'Unable to obtain PayPal access token']; }
        $url = $this->baseUrl . '/v2/checkout/orders/' . rawurlencode($orderId) . '/capture';
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $token,
        ]);
        $res = curl_exec($ch);
        if ($res === false) { $err = curl_error($ch); curl_close($ch); return ['error' => $err]; }
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $j = json_decode($res, true);
        if (!is_array($j)) { return ['error' => 'Invalid PayPal capture response', 'http' => $code, 'raw' => $res]; }
        return $j + ['http' => $code];
    }

    private function token(): string
    {
        $ch = curl_init($this->baseUrl . '/v1/oauth2/token');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, 'grant_type=client_credentials');
        curl_setopt($ch, CURLOPT_USERPWD, $this->clientId . ':' . $this->clientSecret);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Accept: application/json', 'Accept-Language: en_US']);
        $res = curl_exec($ch);
        if ($res === false) { curl_close($ch); return ''; }
        curl_close($ch);
        $j = json_decode($res, true);
        return (string)($j['access_token'] ?? '');
    }

    private function postJson(string $url, array $body, string $token): array
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $token,
        ]);
        $res = curl_exec($ch);
        if ($res === false) { $err = curl_error($ch); curl_close($ch); return ['error' => $err]; }
        curl_close($ch);
        $j = json_decode($res, true);
        return is_array($j) ? $j : ['raw' => $res];
    }

    /**
     * Whitelisted PayPal subscription event types we act on.
     * Similar to StripeGateway::allowedEventTypes() but scoped to subscriptions.
     */
    public static function allowedSubscriptionEventTypes(): array
    {
        return [
            'BILLING.SUBSCRIPTION.ACTIVATED',
            'BILLING.SUBSCRIPTION.CANCELLED',
            'BILLING.SUBSCRIPTION.EXPIRED',
            'BILLING.SUBSCRIPTION.SUSPENDED',
            'BILLING.SUBSCRIPTION.RE-ACTIVATED',
            'BILLING.SUBSCRIPTION.UPDATED',
        ];
    }
}
