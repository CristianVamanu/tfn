<?php
// Minimal, maintainable configuration wrapper
// - Loads app bootstrap
// - Delegates normalization to PaymentConfigResolver

require_once __DIR__ . '/PaymentConfigResolver.php';

// Try to use globals when this file is required from a function scope
$g = $GLOBALS;

// If inc.php was not included in this scope, try to reuse global state; if not present, fetch from DB
if (!isset($g['siteData']) || !is_array($g['siteData'])) {
    // Try to include bootstrap once to make $RL available
    @require_once dirname(__DIR__) . '/inc.php';
}

$siteDataLocal = [];
if (isset($g['siteData']) && is_array($g['siteData'])) {
    $siteDataLocal = $g['siteData'];
} elseif (isset($RL) && method_exists($RL, 'RL_configs')) {
    $siteDataLocal = (array)$RL->RL_configs();
}

$baseUrlLocal = isset($g['base_url']) ? (string)$g['base_url'] : (isset($base_url) ? (string)$base_url : '');

// Build overrides from globals if available
$overrides = [
    // Stripe
    'stripeSecret'        => isset($g['stripeSecret']) ? (string)$g['stripeSecret'] : (isset($stripeSecret) ? (string)$stripeSecret : null),
    'stripeWebhookSecret' => isset($g['stripeWebhookSecret']) ? (string)$g['stripeWebhookSecret'] : (isset($stripeWebhookSecret) ? (string)$stripeWebhookSecret : null),
    // PayPal
    'paypalClientId'     => isset($g['paypalClientId']) ? (string)$g['paypalClientId'] : (isset($paypalClientId) ? (string)$paypalClientId : null),
    'paypalClientSecret' => isset($g['paypalClientSecret']) ? (string)$g['paypalClientSecret'] : (isset($paypalClientSecret) ? (string)$paypalClientSecret : null),
    'paypalEnv'          => isset($g['paypalEnv']) ? (string)$g['paypalEnv'] : (isset($paypalEnv) ? (string)$paypalEnv : null),
    // NOWPayments
    'nowpaymentsApiKey'  => isset($g['nowpaymentsApiKey']) ? (string)$g['nowpaymentsApiKey'] : (isset($nowpaymentsApiKey) ? (string)$nowpaymentsApiKey : null),
    // Coinbase Commerce
    'coinbaseApiKey'        => isset($g['coinbaseCommerceApiKey']) ? (string)$g['coinbaseCommerceApiKey'] : (isset($coinbaseCommerceApiKey) ? (string)$coinbaseCommerceApiKey : null),
    'coinbaseWebhookSecret' => isset($g['coinbaseCommerceWebhookSecret']) ? (string)$g['coinbaseCommerceWebhookSecret'] : (isset($coinbaseCommerceWebhookSecret) ? (string)$coinbaseCommerceWebhookSecret : null),
    // Flutterwave
    'flutterwavePublicKey'     => isset($g['flutterwavePublicKey']) ? (string)$g['flutterwavePublicKey'] : (isset($flutterwavePublicKey) ? (string)$flutterwavePublicKey : null),
    'flutterwaveSecretKey'     => isset($g['flutterwaveSecretKey']) ? (string)$g['flutterwaveSecretKey'] : (isset($flutterwaveSecretKey) ? (string)$flutterwaveSecretKey : null),
    'flutterwaveEncryptionKey' => isset($g['flutterwaveEncryptionKey']) ? (string)$g['flutterwaveEncryptionKey'] : (isset($flutterwaveEncryptionKey) ? (string)$flutterwaveEncryptionKey : null),
    'flutterwaveSecretHash'    => isset($g['flutterwaveSecretHash']) ? (string)$g['flutterwaveSecretHash'] : (isset($flutterwaveSecretHash) ? (string)$flutterwaveSecretHash : null),
    // Paystack
    'paystackPublicKey'    => isset($g['paystackPublicKey']) ? (string)$g['paystackPublicKey'] : (isset($paystackPublicKey) ? (string)$paystackPublicKey : null),
    'paystackSecretKey'    => isset($g['paystackSecretKey']) ? (string)$g['paystackSecretKey'] : (isset($paystackSecretKey) ? (string)$paystackSecretKey : null),
    'paystackWebhookSecret'=> isset($g['paystackWebhookSecret']) ? (string)$g['paystackWebhookSecret'] : (isset($paystackWebhookSecret) ? (string)$paystackWebhookSecret : null),
    'paystackCurrency'     => isset($g['paystackCurrency']) ? (string)$g['paystackCurrency'] : (isset($paystackCurrency) ? (string)$paystackCurrency : null),
    'paystackMerchantEmail'=> isset($g['paystackMerchantEmail']) ? (string)$g['paystackMerchantEmail'] : (isset($paystackMerchantEmail) ? (string)$paystackMerchantEmail : null),
    // PayU
    'payuPosId'        => isset($g['payuPosId']) ? (string)$g['payuPosId'] : (isset($payuPosId) ? (string)$payuPosId : null),
    'payuMerchantId'   => isset($g['payuMerchantId']) ? (string)$g['payuMerchantId'] : (isset($payuMerchantId) ? (string)$payuMerchantId : null),
    'payuClientId'     => isset($g['payuClientId']) ? (string)$g['payuClientId'] : (isset($payuClientId) ? (string)$payuClientId : null),
    'payuClientSecret' => isset($g['payuClientSecret']) ? (string)$g['payuClientSecret'] : (isset($payuClientSecret) ? (string)$payuClientSecret : null),
    'payuSignatureKey' => isset($g['payuSignatureKey']) ? (string)$g['payuSignatureKey'] : (isset($payuSignatureKey) ? (string)$payuSignatureKey : null),
    'payuCurrency'     => isset($g['payuCurrency']) ? (string)$g['payuCurrency'] : (isset($payuCurrency) ? (string)$payuCurrency : null),
    'payuApiBase'      => isset($g['payuApiBase']) ? (string)$g['payuApiBase'] : (isset($payuApiBase) ? (string)$payuApiBase : null),
    // IyziCo
    'iyzicoApiKey'        => isset($g['iyzicoApiKey']) ? (string)$g['iyzicoApiKey'] : (isset($iyzicoApiKey) ? (string)$iyzicoApiKey : null),
    'iyzicoSecretKey'     => isset($g['iyzicoSecretKey']) ? (string)$g['iyzicoSecretKey'] : (isset($iyzicoSecretKey) ? (string)$iyzicoSecretKey : null),
    'iyzicoWebhookSecret' => isset($g['iyzicoWebhookSecret']) ? (string)$g['iyzicoWebhookSecret'] : (isset($iyzicoWebhookSecret) ? (string)$iyzicoWebhookSecret : null),
    'iyzicoCurrency'      => isset($g['iyzicoCurrency']) ? (string)$g['iyzicoCurrency'] : (isset($iyzicoCurrency) ? (string)$iyzicoCurrency : null),
    'iyzicoApiBase'       => isset($g['iyzicoApiBase']) ? (string)$g['iyzicoApiBase'] : (isset($iyzicoApiBase) ? (string)$iyzicoApiBase : null),
    // URLs (context override)
    'success_url' => isset($g['paymentSuccessUrl']) ? (string)$g['paymentSuccessUrl'] : (isset($paymentSuccessUrl) ? (string)$paymentSuccessUrl : null),
    'cancel_url'  => isset($g['paymentCancelUrl'])  ? (string)$g['paymentCancelUrl']  : (isset($paymentCancelUrl)  ? (string)$paymentCancelUrl  : null),
];

return $GLOBALS['paymentConfig'] = PaymentConfigResolver::build(
    $siteDataLocal,
    $baseUrlLocal,
    $overrides
);
