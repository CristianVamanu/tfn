<?php
declare(strict_types=1);

class PayUGateway implements PaymentGatewayInterface
{
    private string $posId;
    private string $merchantId;
    private string $clientId;
    private string $clientSecret;
    private string $signatureKey;
    private string $currency;
    private string $successUrl;
    private string $cancelUrl;
    private string $apiBase;
    private string $webhookUrl;

    public function __construct(array $config)
    {
        $provider = $config['payu'] ?? [];
        $this->posId        = (string) ($provider['pos_id'] ?? '');
        $this->merchantId   = (string) ($provider['merchant_id'] ?? '');
        $this->clientId     = (string) ($provider['client_id'] ?? '');
        $this->clientSecret = (string) ($provider['client_secret'] ?? '');
        $signatureEnv = (string) (
            getenv('PAYU_SIGNATURE_KEY')
            ?: (getenv('PAYU_SECOND_KEY') ?: ($_ENV['PAYU_SIGNATURE_KEY'] ?? ($_SERVER['PAYU_SIGNATURE_KEY'] ?? '')))
        );
        $this->signatureKey = $signatureEnv !== '' ? $signatureEnv : (string) ($provider['signature_key'] ?? '');
        $this->currency     = strtoupper((string) ($provider['currency'] ?? ($config['currency'] ?? 'PLN')));
        $this->successUrl   = (string) ($config['success_url'] ?? '');
        $this->cancelUrl    = (string) ($config['cancel_url'] ?? '');
        $apiBaseEnv = (string) (getenv('PAYU_API_BASE') ?: ($_ENV['PAYU_API_BASE'] ?? ($_SERVER['PAYU_API_BASE'] ?? '')));
        $this->apiBase = $apiBaseEnv !== ''
            ? rtrim($apiBaseEnv, '/')
            : rtrim((string) ($provider['api_base'] ?? 'https://secure.payu.com'), '/');
        $this->webhookUrl = $this->resolveWebhookUrl();
    }

    public function createOneTimePayment(float $amount, string $currency, array $metadata = []): array
    {
        if ($this->posId === '' || $this->clientId === '' || $this->clientSecret === '' || $this->signatureKey === '') {
            return ['checkout_url' => '', 'reference' => '', 'error' => 'PayU credentials are missing.'];
        }

        $amount = max(0.5, $amount);
        $currencyCode = $currency !== '' ? strtoupper($currency) : $this->currency;
        $reference = (string) ($metadata['reference'] ?? $this->generateReference('PAYU'));
        $buyerEmail = $this->resolveEmail($metadata);
        if ($buyerEmail === '') {
            return ['checkout_url' => '', 'reference' => '', 'error' => 'PayU requires a buyer email address.'];
        }

        $productName = trim((string) ($metadata['title'] ?? $metadata['description'] ?? 'Payment'));
        if ($productName === '') { $productName = 'Payment'; }

        $metaJson = '';
        if (!empty($metadata)) {
            $metaJson = json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($metaJson !== null && strlen($metaJson) > 1500) {
                $metaJson = substr($metaJson, 0, 1500);
            }
        }

        $payload = [
            'notifyUrl'     => $this->webhookUrl,
            'continueUrl'   => $this->resolveRedirectUrl(),
            'customerIp'    => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            'merchantPosId' => $this->posId,
            'description'   => $productName,
            'additionalDescription' => $metaJson,
            'currencyCode'  => $currencyCode,
            'totalAmount'   => $this->formatAmountMinor($amount),
            'extOrderId'    => $reference,
            'products'      => [
                [
                    'name'      => $productName,
                    'unitPrice' => $this->formatAmountMinor($amount),
                    'quantity'  => '1',
                ],
            ],
            'buyer' => [
                'email'     => $buyerEmail,
                'phone'     => (string) ($metadata['phone'] ?? ''),
                'firstName' => (string) ($metadata['buyer_name'] ?? ($metadata['name'] ?? '')),
                'lastName'  => '',
                'language'  => 'en',
            ],
        ];

        $tokenResp = $this->obtainAccessToken();
        if (empty($tokenResp['access_token'])) {
            $message = (string) ($tokenResp['error_description'] ?? $tokenResp['error'] ?? 'Unable to authorize with PayU.');
            return ['checkout_url' => '', 'reference' => '', 'error' => $message, 'raw' => $tokenResp];
        }

        $resp = $this->postJson('/api/v2_1/orders', $payload, (string) $tokenResp['access_token']);
        $redirectUri = (string) ($resp['redirectUri'] ?? '');
        $orderId = (string) ($resp['orderId'] ?? '');
        $status = strtoupper((string) ($resp['status']['statusCode'] ?? ($resp['status'] ?? '')));

        if ($redirectUri === '' || $orderId === '' || ($status !== '' && $status !== 'SUCCESS')) {
            $message = (string) ($resp['status']['statusDesc'] ?? $resp['statusDescription'] ?? $resp['error'] ?? 'PayU order creation failed.');
            return [
                'checkout_url' => '',
                'reference'    => '',
                'error'        => $message,
                'raw'          => $resp,
                'http_code'    => $resp['http_code'] ?? null,
            ];
        }

        return [
            'checkout_url' => $redirectUri,
            'reference'    => $orderId !== '' ? $orderId : $reference,
            'raw'          => $resp,
        ];
    }

    public function createSubscription(string $planName, float $amount, string $currency, string $interval, int $intervalCount = 1, array $metadata = []): array
    {
        return [
            'checkout_url' => '',
            'reference'    => '',
            'raw'          => [],
            'error'        => 'PayU subscriptions are not supported in this integration.',
        ];
    }

    public function verifyWebhook(array $headers, string $payload): array
    {
        $sigHeader = $this->headerValue($headers, 'OpenPayu-Signature');
        if ($sigHeader === '') {
            $sigHeader = $this->headerValue($headers, 'OpenPayU-Signature');
        }
        $parsed = $this->parseSignatureHeader($sigHeader);
        $signature = (string) ($parsed['signature'] ?? '');
        $algorithm = strtolower((string) ($parsed['algorithm'] ?? 'md5'));

        if ($signature === '' || $this->signatureKey === '') {
            return ['valid' => false, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => null];
        }

        $computed = $this->computeSignature($payload, $algorithm);
        if ($computed === '' || !hash_equals($signature, $computed)) {
            // Try non-HMAC fallback for older docs
            $fallback = hash($algorithm ?: 'md5', $payload . $this->signatureKey);
            if ($fallback === '' || !hash_equals($signature, $fallback)) {
                return ['valid' => false, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => null];
            }
        }

        $event = json_decode($payload, true);
        if (!is_array($event)) {
            return ['valid' => false, 'event' => '', 'reference' => '', 'metadata' => [], 'raw' => null];
        }

        $order = [];
        if (isset($event['order']) && is_array($event['order'])) {
            $order = $event['order'];
        } elseif (isset($event['orders'][0]) && is_array($event['orders'][0])) {
            $order = $event['orders'][0];
        }

        $status = strtoupper((string) ($order['status'] ?? ''));
        $normalizedEvent = strtolower($status);
        if (in_array($status, ['COMPLETED', 'SUCCESS', 'SUCCESSFUL'], true)) {
            $normalizedEvent = 'payment_success';
        }

        $reference = (string) ($order['orderId'] ?? ($order['extOrderId'] ?? ''));
        $meta = $this->extractMetadata($order);

        return [
            'valid'     => true,
            'event'     => $normalizedEvent,
            'reference' => $reference,
            'metadata'  => $meta,
            'raw'       => $event,
        ];
    }

    private function obtainAccessToken(): array
    {
        $url = $this->apiBase . '/pl/standard/user/oauth/authorize';
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/x-www-form-urlencoded',
        ]);
        curl_setopt($ch, CURLOPT_USERPWD, $this->clientId . ':' . $this->clientSecret);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(['grant_type' => 'client_credentials']));
        $resp = curl_exec($ch);
        $errno = curl_errno($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($errno) {
            return ['error' => 'curl_error', 'errno' => $errno, 'http_code' => $httpCode];
        }
        $decoded = json_decode((string) $resp, true);
        if (!is_array($decoded)) {
            return ['error' => 'invalid_response', 'raw' => $resp, 'http_code' => $httpCode];
        }
        $decoded['http_code'] = $httpCode;
        return $decoded;
    }

    private function postJson(string $path, array $body, string $accessToken): array
    {
        $url = (strpos($path, 'http') === 0) ? $path : ($this->apiBase . $path);
        $payload = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $accessToken,
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        $resp = curl_exec($ch);
        $errno = curl_errno($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($errno) {
            return ['error' => 'curl_error', 'errno' => $errno, 'http_code' => $httpCode];
        }
        $decoded = json_decode((string) $resp, true);
        if (!is_array($decoded)) {
            return ['error' => 'invalid_response', 'raw' => $resp, 'http_code' => $httpCode];
        }
        $decoded['http_code'] = $httpCode;
        return $decoded;
    }

    private function formatAmountMinor(float $amount): string
    {
        $minor = (int) round($amount * 100);
        if ($minor < 1) {
            $minor = 1;
        }
        return (string) $minor;
    }

    private function resolveRedirectUrl(): string
    {
        if ($this->successUrl !== '') {
            return $this->successUrl;
        }
        return $this->cancelUrl !== '' ? $this->cancelUrl : '';
    }

    private function resolveWebhookUrl(): string
    {
        $base = $this->originFromUrl($this->successUrl);
        if ($base === '' && $this->cancelUrl !== '') {
            $base = $this->originFromUrl($this->cancelUrl);
        }
        if ($base !== '') {
            return rtrim($base, '/') . '/request/webhooks.php?provider=payu';
        }
        return '/request/webhooks.php?provider=payu';
    }

    private function originFromUrl(string $url): string
    {
        if ($url === '') {
            return '';
        }
        $parts = @parse_url($url);
        if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
            return '';
        }
        $origin = $parts['scheme'] . '://' . $parts['host'];
        if (!empty($parts['port'])) {
            $origin .= ':' . (int) $parts['port'];
        }
        return $origin;
    }

    private function generateReference(string $prefix = 'PAYU'): string
    {
        return $prefix . '-' . bin2hex(random_bytes(6)) . '-' . time();
    }

    private function resolveEmail(array $metadata): string
    {
        foreach (['buyer_email', 'customer_email', 'email'] as $key) {
            if (!empty($metadata[$key]) && is_string($metadata[$key])) {
                $candidate = trim((string) $metadata[$key]);
                if ($candidate !== '') {
                    return $candidate;
                }
            }
        }
        return '';
    }

    private function headerValue(array $headers, string $key): string
    {
        foreach ($headers as $k => $v) {
            if (strcasecmp((string) $k, $key) === 0) {
                return is_array($v) ? (string) reset($v) : (string) $v;
            }
        }
        if (class_exists('Headers')) {
            $val = \Headers::get($key);
            if ($val !== null) {
                return (string) $val;
            }
        }
        return '';
    }

    private function parseSignatureHeader(string $header): array
    {
        $parsed = [];
        foreach (explode(';', $header) as $part) {
            $pair = explode('=', trim($part), 2);
            if (count($pair) === 2) {
                $parsed[strtolower($pair[0])] = trim($pair[1], "\"' ");
            }
        }
        return $parsed;
    }

    private function computeSignature(string $payload, string $algorithm): string
    {
        $algo = $algorithm !== '' ? strtolower($algorithm) : 'md5';
        $supported = in_array($algo, hash_hmac_algos(), true);
        if ($supported) {
            return hash_hmac($algo, (string) $payload, $this->signatureKey);
        }
        return '';
    }

    private function extractMetadata(array $order): array
    {
        $candidates = [];
        if (!empty($order['additionalDescription'])) { $candidates[] = (string) $order['additionalDescription']; }
        if (!empty($order['description'])) { $candidates[] = (string) $order['description']; }
        foreach ($candidates as $candidate) {
            $decoded = json_decode($candidate, true);
            if (is_array($decoded)) {
                return $decoded;
            }
        }
        return [];
    }
}
