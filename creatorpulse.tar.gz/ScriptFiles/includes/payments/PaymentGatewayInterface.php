<?php
declare(strict_types=1);

interface PaymentGatewayInterface
{
    /**
     * Create a one-time payment (checkout session / invoice).
     *
     * @param float $amount
     * @param string $currency ISO currency code (e.g., USD)
     * @param array $metadata Arbitrary metadata (e.g., ['ad_id'=>123])
     * @return array{checkout_url:string,reference:string,raw:array}
     */
    public function createOneTimePayment(float $amount, string $currency, array $metadata = []): array;

    /**
     * Create a subscription payment.
     *
     * @param string $planName  Human-readable plan
     * @param float  $amount    Recurring amount
     * @param string $currency  ISO currency code
     * @param string $interval  Interval keyword (e.g., month, week)
     * @param int    $intervalCount How many intervals per charge (e.g., 1)
     * @param array  $metadata  Arbitrary metadata
     * @return array{checkout_url:string,reference:string,raw:array}
     */
    public function createSubscription(string $planName, float $amount, string $currency, string $interval, int $intervalCount = 1, array $metadata = []): array;

    /**
     * Verify incoming webhook signature and parse payload to a normalized event.
     * Return shape example: ['valid'=>true,'event'=>'payment_success','reference'=>'abc','metadata'=>['ad_id'=>123], 'raw'=>[]]
     *
     * @param array $headers
     * @param string $payload
     * @return array
     */
    public function verifyWebhook(array $headers, string $payload): array;
}

