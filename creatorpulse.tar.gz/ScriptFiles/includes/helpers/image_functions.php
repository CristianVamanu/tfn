<?php

/**
 * Correct the orientation of an image based on EXIF data.
 *
 * @param resource $image
 * @param string $source_path
 * @return resource
 */
function correctImageOrientation($image, $source_path)
{
    if (function_exists('exif_read_data')) {
        $exif = @exif_read_data($source_path);
        if ($exif && isset($exif['Orientation'])) {
            $orientation = $exif['Orientation'];
            switch ($orientation) {
                case 3:
                    $image = imagerotate($image, 180, 0);
                    break;
                case 6:
                    $image = imagerotate($image, -90, 0);
                    break;
                case 8:
                    $image = imagerotate($image, 90, 0);
                    break;
            }
        }
    }
    return $image;
}

/**
 * Crop and resize an image to the desired width and height.
 *
 * @param string $source_path
 * @param string $output_path
 * @param int $desired_width
 * @param int $desired_height
 * @param int $quality
 * @return bool
 */
function cropImage($source_path, $output_path, $desired_width, $desired_height, $quality = 90)
{
    list($original_width, $original_height, $image_type) = getimagesize($source_path);

    switch ($image_type) {
        case IMAGETYPE_JPEG:
            $source_image = imagecreatefromjpeg($source_path);
            $source_image = correctImageOrientation($source_image, $source_path);
            $original_width = imagesx($source_image);
            $original_height = imagesy($source_image);
            break;
        case IMAGETYPE_PNG:
            $source_image = imagecreatefrompng($source_path);
            break;
        case IMAGETYPE_GIF:
            $source_image = imagecreatefromgif($source_path);
            break;
        default:
            return false;
    }

    $original_aspect_ratio = $original_width / $original_height;
    $desired_aspect_ratio = $desired_width / $desired_height;

    if ($original_aspect_ratio > $desired_aspect_ratio) {
        $new_height = $desired_height;
        $new_width = (int)($original_width * ($desired_height / $original_height));
    } else {
        $new_width = $desired_width;
        $new_height = (int)($original_height * ($desired_width / $original_width));
    }

    $resized_image = imagecreatetruecolor($new_width, $new_height);
    imagecopyresampled($resized_image, $source_image, 0, 0, 0, 0, $new_width, $new_height, $original_width, $original_height);

    $crop_x = (int)(($new_width - $desired_width) / 2);
    $crop_y = (int)(($new_height - $desired_height) / 2);

    $final_image = imagecreatetruecolor($desired_width, $desired_height);
    imagecopyresampled($final_image, $resized_image, 0, 0, $crop_x, $crop_y, $desired_width, $desired_height, $desired_width, $desired_height);

    switch ($image_type) {
        case IMAGETYPE_JPEG:
            imagejpeg($final_image, $output_path, $quality);
            break;
        case IMAGETYPE_PNG:
            imagepng($final_image, $output_path);
            break;
        case IMAGETYPE_GIF:
            imagegif($final_image, $output_path);
            break;
    }

    imagedestroy($source_image);
    imagedestroy($resized_image);
    imagedestroy($final_image);

    return true;
}

// Note: The legacy uploadImage() helper has been removed to prevent misuse.
// Image uploads are handled via request endpoints with strict validation.
/**
 * Extracts the file extension from a given string.
 *
 * @param string $filename The full file name or path.
 * @return string The file extension in lowercase (without dot), or an empty string if none found.
 */
function getExtension(string $filename): string
{
    $position = strrpos($filename, '.');

    if ($position === false) {
        return '';
    }

    return strtolower(trim(substr($filename, $position + 1)));
}

/**
 * Generates a unique filename with a given prefix and extension.
 *
 * @param string $prefix     Prefix to use for the file name (default: 'image').
 * @param string $extension  File extension without dot (default: 'png').
 * @return string            A unique file name like image_643b2f8ee52a0.png
 */
function generateUniqueFilename(string $prefix = 'image', string $extension = 'png'): string
{
    return $prefix . '_' . uniqid('', true) . '.' . $extension;
}

if (!function_exists('resolve_image_dimensions')) {
    /**
     * Attempt to resolve intrinsic image dimensions for a public URL on the same origin.
     *
     * @return array{0: int|null, 1: int|null}
     */
    function resolve_image_dimensions(string $publicUrl): array
    {
        static $cache = [];
        $key = md5($publicUrl);
        if (isset($cache[$key])) {
            return $cache[$key];
        }

        if ($publicUrl === '') {
            return $cache[$key] = [null, null];
        }

        $url = $publicUrl;
        if (strpos($url, '://') === false && $url[0] !== '/') {
            $url = '/' . ltrim($url, '/');
        }

        $path = parse_url($url, PHP_URL_PATH);
        if (!is_string($path) || $path === '') {
            return $cache[$key] = [null, null];
        }

        $docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim((string) $_SERVER['DOCUMENT_ROOT'], '/') : '';
        if ($docRoot === '') {
            return $cache[$key] = [null, null];
        }

        $candidate = $docRoot . $path;
        if (!is_file($candidate)) {
            return $cache[$key] = [null, null];
        }

        $info = @getimagesize($candidate);
        if (is_array($info) && isset($info[0], $info[1]) && $info[0] > 0 && $info[1] > 0) {
            return $cache[$key] = [(int) $info[0], (int) $info[1]];
        }

        return $cache[$key] = [null, null];
    }
}

/**
 * Generates an avatar image URL from the user's name using the ui-avatars.com API.
 *
 * @param string $name   The full name or initials to be used in the avatar.
 * @param int    $length Number of initials to include (1 or 2 typically).
 * @return string        Generated avatar image URL.
 */
/**
 * Generate a local initials avatar (PNG) without external calls.
 *
 * - Uses GD to render up to 2-letter initials over a solid background.
 * - Deterministic background color derived from the name hash.
 * - Saves under uploads/user_avatars/initials/ and returns a web-relative path.
 *
 * Note: This replaces any runtime dependency on ui-avatars.com for offline compliance.
 *
 * @param string $name   Full name or username.
 * @param int    $length Number of initials to include (1 or 2 typically).
 * @param int    $size   Output image size (square), default 128px.
 * @return string        Relative path like uploads/user_avatars/initials/AB_xxx.png
 */
function get_avatar_url_by_name(string $name, int $length = 2, int $size = 128): string
{
    // Compute initials (basic ASCII fallback). For non-ASCII, this may not render perfectly with built-in GD fonts.
    $name = trim($name);
    $parts = preg_split('/\s+/', $name) ?: [];
    $letters = '';
    foreach ($parts as $p) {
        if ($p !== '') { $letters .= mb_substr($p, 0, 1, 'UTF-8'); }
        if (mb_strlen($letters, 'UTF-8') >= $length) { break; }
    }
    if ($letters === '') { $letters = mb_substr($name !== '' ? $name : 'U', 0, $length, 'UTF-8'); }
    $initials = mb_strtoupper($letters, 'UTF-8');

    // Paths
    $baseDir = dirname(__DIR__) . '/../uploads/user_avatars/initials/';
    if (!is_dir($baseDir)) {
        @mkdir($baseDir, 0755, true);
    }

    // Deterministic filename (name + size)
    $hash = substr(sha1($name . '|' . $size . '|' . $length), 0, 8);
    $file = $baseDir . 'initials_' . $hash . '.png';
    $rel  = 'uploads/user_avatars/initials/initials_' . $hash . '.png';

    if (is_file($file)) {
        return $rel;
    }

    // Create image
    $img = imagecreatetruecolor($size, $size);
    if (!$img) {
        return 'uploads/user_avatars/default.jpeg';
    }
    // Background color from name hash (pastel-ish palette)
    $h = hexdec(substr(sha1($name), 0, 6));
    $r = 160 + ($h % 96); // 160-255
    $g = 160 + (($h >> 3) % 96);
    $b = 160 + (($h >> 6) % 96);
    $bg = imagecolorallocate($img, $r, $g, $b);
    imagefilledrectangle($img, 0, 0, $size, $size, $bg);

    // Text color and font
    $fg = imagecolorallocate($img, 33, 33, 33); // dark gray text for contrast
    // Use built-in GD font (bitmap). For TTF, one could use imagettftext with a bundled font.
    $font = 5; // largest built-in bitmap font
    $text = $initials;
    $tw = imagefontwidth($font) * strlen($text);
    $th = imagefontheight($font);
    $x = (int) (($size - $tw) / 2);
    $y = (int) (($size - $th) / 2);
    imagestring($img, $font, max(0, $x), max(0, $y), $text, $fg);

    // Save PNG with alpha disabled (solid bg)
    imagealphablending($img, false);
    imagesavealpha($img, false);
    @imagepng($img, $file, 6);
    imagedestroy($img);

    if (!is_file($file)) {
        return 'uploads/user_avatars/default.jpeg';
    }
    return $rel;
}

/**
 * Creates a directory named by today's date inside the /uploads directory if it doesn't already exist.
 *
 * @return string The full path to the created (or existing) directory.
 */
function createTodayDirectory(): string
{
    $rootDirectory = dirname(__DIR__);
    $today = date('Y-m-d');
    $directoryPath = $rootDirectory . DIRECTORY_SEPARATOR . '../uploads/files/' . DIRECTORY_SEPARATOR . $today;

    if (!is_dir($directoryPath)) {
        // Use 0755 to avoid world-writable perms; ensure owner writeable
        mkdir($directoryPath, 0755, true);
    }

    return $directoryPath;
}

function applyFilterToImage($filePath, $filter)
{
    $image = imagecreatefrompng($filePath);
    if (!$image) return;

    // Preserve transparency support
    imagesavealpha($image, true);
    imagealphablending($image, false);

    switch ($filter) {
        case 'moon':
            imagefilter($image, IMG_FILTER_GRAYSCALE);
            imagefilter($image, IMG_FILTER_CONTRAST, -15);
            break;

        case 'gingham':
            imagefilter($image, IMG_FILTER_GRAYSCALE);
            imagefilter($image, IMG_FILTER_BRIGHTNESS, 15);
            break;

        case 'reyes':
            imagefilter($image, IMG_FILTER_BRIGHTNESS, 10);
            imagefilter($image, IMG_FILTER_CONTRAST, -20);
            break;

        case 'sepia':
            imagefilter($image, IMG_FILTER_GRAYSCALE);
            imagefilter($image, IMG_FILTER_COLORIZE, 90, 60, 40);
            break;

        case 'invert':
            imagefilter($image, IMG_FILTER_NEGATE);
            break;

        case 'brighten':
            imagefilter($image, IMG_FILTER_BRIGHTNESS, 20);
            break;

        case 'contrast':
            imagefilter($image, IMG_FILTER_CONTRAST, -25);
            break;
        case 'none':
        default:
            // No filter
            break;
    }

    // Save PNG with alpha channel
    imagealphablending($image, false);
    imagesavealpha($image, true);
    imagepng($image, $filePath);

    imagedestroy($image);
}

/**
 * Render an inline SVG icon or fallback to <img> tag.
 *
 * This function loads an SVG file and optionally forces all fill and stroke
 * attributes to `currentColor` to allow CSS-based coloring. If the file is not
 * an SVG or is not found, it returns a standard <img> tag.
 *
 * @param string $publicUrl  Public path to the image (e.g. '/assets/icon.svg')
 * @param bool   $forceMono  If true, replaces all colors with `currentColor`
 *
 * @return string Rendered SVG HTML or fallback <img> tag
 */
function renderVerifiedBadge(string $publicUrl, bool $forceMono = true): string
{
    static $cache = [];

    $assetUrl = icon_asset_url($publicUrl, $publicUrl);
    if ($assetUrl === '') {
        return '';
    }

    $realPath = $_SERVER['DOCUMENT_ROOT'] . parse_url($assetUrl, PHP_URL_PATH);

    if (isset($cache[$realPath][$forceMono])) {
        return $cache[$realPath][$forceMono];
    }

    if (!file_exists($realPath)) {
        return '';
    }

    $extension = strtolower(pathinfo($realPath, PATHINFO_EXTENSION));

    if ($extension !== 'svg') {
        $dimensions = resolve_image_dimensions($assetUrl);
        $widthAttr = $dimensions[0] ? ' width="' . (int) $dimensions[0] . '"' : '';
        $heightAttr = $dimensions[1] ? ' height="' . (int) $dimensions[1] . '"' : '';
        return $cache[$realPath][$forceMono] = '<img src="' . htmlspecialchars($assetUrl) . '" alt="verified icon" loading="lazy" decoding="async"' . $widthAttr . $heightAttr . '>';
    }

    $svgContent = file_get_contents($realPath);
    if (!$svgContent) {
        return '';
    }

    // Remove XML declaration if exists
    $svgContent = preg_replace('/<\?xml.*?\?>/i', '', $svgContent);
    // Also strip DOCTYPE and any <style> blocks to comply with CSP (no inline styles)
    $svgContent = preg_replace('/<!DOCTYPE[^>]*>/i', '', $svgContent);
    $svgContent = preg_replace('/<style\b[^>]*>[\s\S]*?<\/style>/i', '', $svgContent);

    // Rewrite inline style="..." attributes into individual SVG attributes
    // so they satisfy the policy without needing unsafe-inline.
    $allowedStyleAttributes = [
        'fill'              => 'fill',
        'stroke'            => 'stroke',
        'stroke-width'      => 'stroke-width',
        'stroke-linecap'    => 'stroke-linecap',
        'stroke-linejoin'   => 'stroke-linejoin',
        'stroke-miterlimit' => 'stroke-miterlimit',
        'stroke-dasharray'  => 'stroke-dasharray',
        'stroke-dashoffset' => 'stroke-dashoffset',
        'stroke-opacity'    => 'stroke-opacity',
        'fill-opacity'      => 'fill-opacity',
        'opacity'           => 'opacity',
        'stop-color'        => 'stop-color',
        'stop-opacity'      => 'stop-opacity',
        'font-family'       => 'font-family',
        'font-size'         => 'font-size',
        'font-weight'       => 'font-weight',
        'font-style'        => 'font-style',
    ];

    $svgContent = preg_replace_callback(
        '/\sstyle=("|\')([^"\']*)(\1)/i',
        function (array $matches) use ($allowedStyleAttributes, $forceMono) {
            $styleString = $matches[2];
            if ($styleString === '') {
                return '';
            }

            $attributes = [];
            $declarations = preg_split('/;/', (string) $styleString);
            foreach ($declarations as $declaration) {
                if ($declaration === null) {
                    continue;
                }
                $parts = explode(':', $declaration, 2);
                if (count($parts) !== 2) {
                    continue;
                }

                $property = strtolower(trim($parts[0]));
                $value = trim($parts[1]);
                if ($value === '') {
                    continue;
                }

                // Remove trailing !important which is meaningless on attributes.
                $value = preg_replace('/\s*!important\s*$/i', '', $value);
                if ($value === '') {
                    continue;
                }

                if (!isset($allowedStyleAttributes[$property])) {
                    continue;
                }

                $attrName = $allowedStyleAttributes[$property];

                // When monochrome output is requested, allow downstream
                // logic to inject currentColor rather than freezing values.
                if ($forceMono && ($attrName === 'fill' || $attrName === 'stroke')) {
                    continue;
                }

                $attributes[$attrName] = htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
            }

            if (!$attributes) {
                return '';
            }

            $chunks = [];
            foreach ($attributes as $attrName => $attrValue) {
                $chunks[] = $attrName . '="' . $attrValue . '"';
            }

            return ' ' . implode(' ', $chunks);
        },
        $svgContent
    );

    if ($forceMono) {
        // Remove any inline style attributes (CSP forbids inline styles)
        $svgContent = preg_replace('/\sstyle=("|\')[^"\']*(\1)/i', '', $svgContent);
        // Remove style-based fill/stroke declarations
        $svgContent = preg_replace(
            '/style=("|\')[^"\']*?(fill|stroke)\s*:\s*[^;"\']+;?[^"\']*(\1)/i',
            '',
            $svgContent
        );

        // Convert inline fill to currentColor
        $svgContent = preg_replace(
            '/\sfill="#?[a-fA-F0-9]{3,6}"/i',
            ' fill="currentColor"',
            $svgContent
        );

        // Convert inline stroke to currentColor
        $svgContent = preg_replace(
            '/\sstroke="#?[a-fA-F0-9]{3,6}"/i',
            ' stroke="currentColor"',
            $svgContent
        );

        // Add fill and stroke if missing in shape elements
        $svgContent = preg_replace_callback(
            '/<((path|rect|circle|polygon|ellipse|line)\b[^>]*)(?<!\/)>/i',
            function ($matches) {
                $tag = $matches[1];
                if (!preg_match('/fill="/i', $tag)) {
                    $tag .= ' fill="currentColor"';
                }
                if (!preg_match('/stroke="/i', $tag)) {
                    $tag .= ' stroke="currentColor"';
                }
                return '<' . trim($tag) . ' />';
            },
            $svgContent
        );
    }

    $svgContent = str_replace(["\r\n", "\r"], "\n", $svgContent);
    $svgContent = str_replace('"', "'", $svgContent);

    return $cache[$realPath][$forceMono] = $svgContent;
}
