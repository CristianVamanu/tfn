<?php
/**
 * Generate a secure CSRF token and store it in session.
 *
 * @return string
 */
function generateCsrfToken(): string {

    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

/**
 * Validate a submitted CSRF token against the session token.
 *
 * @param string|null $token
 * @return bool
 */
function checkCsrfToken(?string $token): bool {
    return isset($_SESSION['csrf_token']) && is_string($token) && hash_equals($_SESSION['csrf_token'], $token);
}
?>