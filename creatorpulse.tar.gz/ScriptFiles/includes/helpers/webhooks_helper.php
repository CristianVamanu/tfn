<?php
declare(strict_types=1);

final class Headers
{
    /**
     * Case-insensitive header fetch across SAPIs.
     * Never logs or exposes raw headers.
     */
    public static function get(string $name): ?string
    {
        $target = strtolower($name);
        // Prefer getallheaders when available (fast path)
        if (function_exists('getallheaders')) {
            foreach ((array) getallheaders() as $k => $v) {
                if (strtolower((string) $k) === $target) {
                    return is_array($v) ? (string) reset($v) : (string) $v;
                }
            }
        }
        // Fallback to $_SERVER
        $key = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
        if (isset($_SERVER[$key]) && $_SERVER[$key] !== '') {
            return (string) $_SERVER[$key];
        }
        return null;
    }
}

final class Webhooks
{
    private static ?string $raw = null;
    private static ?bool $debugEnabled = null;

    /** Read php://input exactly once and cache for reuse. */
    public static function rawBody(): string
    {
        if (self::$raw === null) {
            $raw = file_get_contents('php://input');
            self::$raw = is_string($raw) ? $raw : '';
        }
        return self::$raw;
    }

    /**
     * Returns true if a (provider,eventId) pair is already processed.
     * Requires $RL->getDb() to be available.
     */
    public static function alreadyProcessed(string $provider, string $eventId): bool
    {
        global $RL;
        if ($provider === '' || $eventId === '' || !isset($RL) || !method_exists($RL, 'getDb')) {
            return false;
        }
        $db = $RL->getDb();
        self::ensureTable($db);
        $st = $db->prepare('SELECT 1 FROM i_webhook_events WHERE provider = :p AND event_id = :e LIMIT 1');
        $st->execute([':p' => $provider, ':e' => $eventId]);
        return (bool) $st->fetchColumn();
    }

    /**
     * Determine whether verbose webhook logging should be enabled.
     * Prioritises APP_DEBUG but allows overriding via PAYMENTS_DEBUG_LOG=1.
     */
    public static function isDebugEnabled(): bool
    {
        if (self::$debugEnabled !== null) {
            return self::$debugEnabled;
        }

        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            self::$debugEnabled = true;
            return true;
        }

        $flag = getenv('PAYMENTS_DEBUG_LOG');
        if ($flag === false) {
            $flag = $_ENV['PAYMENTS_DEBUG_LOG'] ?? ($_SERVER['PAYMENTS_DEBUG_LOG'] ?? '');
        }
        if ($flag !== null && $flag !== '') {
            $value = strtolower(trim((string) $flag));
            self::$debugEnabled = !in_array($value, ['0', 'false', 'off', 'no'], true);
            return self::$debugEnabled;
        }

        self::$debugEnabled = false;
        return false;
    }

    /**
     * Append a line to payments_debug.log when debug is enabled.
     * Set $force to true to bypass the debug flag (for critical failures).
     */
    public static function debugLog(string $message, bool $force = false): void
    {
        if (!$force && !self::isDebugEnabled()) {
            return;
        }

        $logDir = dirname(__DIR__) . '/logs';
        if (!is_dir($logDir)) {
            @mkdir($logDir, 0755, true);
        }

        $path = $logDir . '/payments_debug.log';
        if (substr($message, -1) !== "\n") {
            $message .= "\n";
        }

        @file_put_contents($path, $message, FILE_APPEND);
    }

    /**
     * Idempotently marks a (provider,eventId) as processed.
     * Returns true if this call inserted a new row (i.e., first time seen).
     */
    public static function markProcessed(string $provider, string $eventId): bool
    {
        global $RL;
        if ($provider === '' || $eventId === '' || !isset($RL) || !method_exists($RL, 'getDb')) {
            return false;
        }
        $db = $RL->getDb();
        self::ensureTable($db);
        try {
            $db->beginTransaction();
        } catch (Throwable $__) {}
        $st = $db->prepare('INSERT IGNORE INTO i_webhook_events (provider, event_id, received_at) VALUES (:p,:e,:t)');
        $st->execute([':p' => $provider, ':e' => $eventId, ':t' => time()]);
        $inserted = $st->rowCount() > 0;
        try {
            $db->commit();
        } catch (Throwable $__) {}
        return $inserted;
    }

    /** Optional convenience. */
    public static function isAllowed(string $provider, string $eventType, array $allowList): bool
    {
        return $provider !== '' && $eventType !== '' && in_array($eventType, $allowList, true);
    }

    private static function ensureTable($db): void
    {
        $db->exec("CREATE TABLE IF NOT EXISTS i_webhook_events (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            provider VARCHAR(32) NOT NULL,
            event_id VARCHAR(191) NOT NULL,
            received_at INT NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY provider_event (provider, event_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
}
