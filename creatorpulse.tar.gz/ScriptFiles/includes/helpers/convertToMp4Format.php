<?php

/**
 * Converts a video file to MP4 format using FFmpeg (H.264 + AAC).
 *
 * @param string $ffmpegPath            Full path to the ffmpeg binary.
 * @param string $sourcePath            Full path to the input video file.
 * @param string $outputDir             Directory where the MP4 will be saved.
 * @param string $filenameWithoutExt    Name for the output file, without extension.
 * @return string|null                  Returns the output path on success, or null on failure.
 */
function convertToMp4Format(
    string $ffmpegPath,
    string $sourcePath,
    string $outputDir,
    string $filenameWithoutExt
): ?string {
    $outputPath = rtrim($outputDir, '/') . '/' . $filenameWithoutExt . '.mp4';

    // Build command safely: escape binary and all file path arguments
    $ffmpeg = escapeshellarg($ffmpegPath); // escapeshellarg keeps Windows paths with spaces intact
    $cmd = $ffmpeg . ' -i ' . escapeshellarg($sourcePath)
         . ' -c:v libx264 -preset fast -crf 23 -pix_fmt yuv420p'
         . ' -c:a aac -b:a 128k -strict -2 '
         . escapeshellarg($outputPath) . ' -y 2>&1';

    shell_exec($cmd);

    if (file_exists($outputPath) && filesize($outputPath) > 50000) {
        @unlink($sourcePath);
        return $outputPath;
    }

    return null;
}
?>
