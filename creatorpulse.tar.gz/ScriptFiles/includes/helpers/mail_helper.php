<?php
declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\Exception as PHPMailerException;
use PHPMailer\PHPMailer\PHPMailer;

final class AdminMail
{
    private function __construct()
    {
    }

    /**
     * Fetches SMTP settings row or throws if none exist.
     */
    public static function loadSettings(PDO $db): array
    {
        $stmt = $db->query('SELECT * FROM i_mail_settings WHERE id = 1 LIMIT 1');
        if ($stmt === false) {
            throw new RuntimeException('Unable to query mail settings.');
        }
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            throw new RuntimeException('smtp_not_configured');
        }
        return $row;
    }

    /**
     * Returns a configured PHPMailer instance along with normalised settings metadata.
     */
    public static function buildMailer(array $settings): array
    {
        $normalised = self::normaliseSettings($settings);

        $mailer = new PHPMailer(true);
        $mailer->CharSet = 'UTF-8';
        $mailer->isSMTP();
        $mailer->Host = $normalised['host'];
        $mailer->Port = $normalised['port'];
        $mailer->SMTPDebug = 0;
        $mailer->Timeout = 20;
        $mailer->SMTPAuth = $normalised['uses_auth'];
        if ($normalised['uses_auth']) {
            $mailer->Username = $normalised['username'];
            $mailer->Password = $normalised['password'];
        }

        if ($normalised['secure'] === 'tls') {
            $mailer->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mailer->SMTPAutoTLS = true;
        } elseif ($normalised['secure'] === 'ssl') {
            $mailer->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mailer->SMTPAutoTLS = false;
        } else {
            $mailer->SMTPSecure = '';
            $mailer->SMTPAutoTLS = false;
        }

        $fromEmail = $normalised['from_email'];
        $fromName = $normalised['from_name'];
        $mailer->setFrom($fromEmail, $fromName !== '' ? $fromName : null);
        $mailer->addReplyTo($fromEmail, $fromName !== '' ? $fromName : null);

        $normalised['password'] = $normalised['uses_auth'] ? '***' : '';

        return [$mailer, $normalised];
    }

    /**
     * Encrypts a plain password string for storage.
     */
    public static function encryptPassword(string $plainText): string
    {
        if ($plainText === '') {
            return '';
        }

        if (!extension_loaded('openssl')) {
            return base64_encode($plainText);
        }

        $iv = random_bytes(16);
        $cipher = openssl_encrypt($plainText, 'AES-256-CBC', self::cipherKey(), OPENSSL_RAW_DATA, $iv);
        if ($cipher === false) {
            throw new RuntimeException('encrypt_failed');
        }

        return base64_encode($iv . $cipher);
    }

    /**
     * Decrypts an encrypted password string.
     */
    public static function decryptPassword(?string $cipherText): string
    {
        if ($cipherText === null || $cipherText === '') {
            return '';
        }

        $decoded = base64_decode($cipherText, true);
        if ($decoded === false || strlen($decoded) < 17) {
            return '';
        }

        if (!extension_loaded('openssl')) {
            return $decoded;
        }

        $iv = substr($decoded, 0, 16);
        $cipher = substr($decoded, 16);
        if ($cipher === '') {
            return '';
        }

        $plain = openssl_decrypt($cipher, 'AES-256-CBC', self::cipherKey(), OPENSSL_RAW_DATA, $iv);
        if ($plain === false) {
            return '';
        }

        return $plain;
    }

    public static function isConfigurationError(Throwable $e): bool
    {
        if (!$e instanceof RuntimeException) {
            return false;
        }
        $msg = strtolower((string) $e->getMessage());
        if ($msg === 'smtp_not_configured') {
            return true;
        }
        return str_contains($msg, 'smtp host is not configured') ||
            str_contains($msg, 'smtp from email is not configured');
    }

    private static function normaliseSettings(array $settings): array
    {
        $host = trim((string) ($settings['host'] ?? ''));
        if ($host === '') {
            throw new RuntimeException('smtp_not_configured');
        }

        $isValidHost = filter_var($host, FILTER_VALIDATE_IP) !== false
            || strtolower($host) === 'localhost'
            || filter_var($host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) !== false;
        if (!$isValidHost) {
            throw new RuntimeException('SMTP host appears to be invalid.');
        }

        $port = (int) ($settings['port'] ?? 0);
        if ($port < 1 || $port > 65535) {
            if ($port < 1) {
                throw new RuntimeException('smtp_not_configured');
            }
            throw new RuntimeException('SMTP port must be between 1 and 65535.');
        }

        $secure = strtolower(trim((string) ($settings['secure'] ?? 'none')));
        if (!in_array($secure, ['tls', 'ssl', 'none'], true)) {
            throw new RuntimeException('SMTP security mode is invalid.');
        }

        $fromEmail = trim((string) ($settings['from_email'] ?? ''));
        if ($fromEmail === '' || filter_var($fromEmail, FILTER_VALIDATE_EMAIL) === false) {
            if ($fromEmail === '') {
                throw new RuntimeException('smtp_not_configured');
            }
            throw new RuntimeException('SMTP from email is invalid.');
        }

        $fromName = trim((string) ($settings['from_name'] ?? ''));
        $username = trim((string) ($settings['username'] ?? ''));
        $password = self::decryptPassword($settings['password_enc'] ?? '');
        $usesAuth = ($username !== '' || $password !== '');

        return [
            'host' => $host,
            'port' => $port,
            'secure' => $secure,
            'from_email' => $fromEmail,
            'from_name' => $fromName,
            'username' => $username,
            'uses_auth' => $usesAuth,
            'password' => $usesAuth ? $password : '',
        ];
    }

    private static function cipherKey(): string
    {
        static $cachedKey = null;
        if ($cachedKey !== null) {
            return $cachedKey;
        }

        $envKey = (string) (getenv('APP_KEY') ?: getenv('APP_SECRET') ?: getenv('ENCRYPTION_KEY') ?: '');
        if ($envKey === '') {
            $envKey = hash('sha256', __DIR__ . php_uname('n') . __FILE__);
        }

        $cachedKey = hash('sha256', $envKey, true);
        return $cachedKey;
    }
}
