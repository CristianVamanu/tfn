<?php

if (!defined('GUEST_LANGUAGE_COOKIE_NAME')) {
    define('GUEST_LANGUAGE_COOKIE_NAME', 'guest_language');
}

/**
 * Discover available language packs by scanning the langs directory.
 *
 * @return array<int, string>
 */
function discoverAvailableLanguages(): array
{
    static $cachedLanguages = null;

    if (is_array($cachedLanguages)) {
        return $cachedLanguages;
    }

    $languages = [];
    $langDirectory = realpath(__DIR__ . '/../../langs');

    if ($langDirectory && is_dir($langDirectory)) {
        $entries = scandir($langDirectory);
        if (is_array($entries)) {
            foreach ($entries as $entry) {
                if ($entry === '.' || $entry === '..') {
                    continue;
                }
                if (preg_match('/^([A-Za-z0-9_]+)\.php$/', $entry, $matches)) {
                    $languages[] = strtolower($matches[1]);
                }
            }
        }
    }

    if (empty($languages)) {
        $languages[] = 'eng';
    }

    $languages = array_values(array_unique($languages));
    sort($languages, SORT_NATURAL);

    $cachedLanguages = $languages;

    return $cachedLanguages;
}

/**
 * Return the human-readable/native name for a language pack code.
 *
 * @param string $languageCode Language pack code, for example "eng" or "tr".
 * @return string
 */
function languageDisplayName(string $languageCode): string
{
    $code = strtolower(trim($languageCode));
    $names = [
        'ar'  => 'العربية',
        'de'  => 'Deutsch',
        'eng' => 'English',
        'es'  => 'Español',
        'fr'  => 'Français',
        'pt'  => 'Português',
        'sk'  => 'Slovenčina',
        'tr'  => 'Türkçe',
    ];

    return $names[$code] ?? strtoupper($code);
}

/**
 * Prepare configuration details for rendering a language switcher control.
 *
 * @param string|null $currentLanguage Current language code.
 * @param string|null $baseUrl         Base URL to prefix the requests endpoint.
 *
 * @return array<string, mixed>
 */
function buildLanguageSwitcherData(?string $currentLanguage, ?string $baseUrl = null): array
{
    $languages = discoverAvailableLanguages();

    $activeLanguage = strtolower(trim((string) ($currentLanguage ?? 'eng')));
    if ($activeLanguage === '') {
        $activeLanguage = 'eng';
    }

    if (!in_array($activeLanguage, $languages, true)) {
        $activeLanguage = in_array('eng', $languages, true)
            ? 'eng'
            : (string) ($languages[0] ?? 'eng');
    }

    $base = (string) ($baseUrl ?? '');
    if ($base !== '') {
        $base = rtrim($base, '/') . '/';
    } else {
        $base = '/';
    }

    return [
        'options'      => $languages,
        'current'      => $activeLanguage,
        'current_label'=> languageDisplayName($activeLanguage),
        'labels'       => array_reduce($languages, static function (array $labels, string $language): array {
            $labels[$language] = languageDisplayName($language);
            return $labels;
        }, []),
        'endpoint'     => $base . 'request/requests.php',
        'wait_message' => customLang('language_switch_wait_message', 'Please wait, we are preparing the pages for your selected language...'),
        'title'        => customLang('language_switch_title', 'Choose language'),
        'label'        => strtoupper($activeLanguage),
    ];
}

/**
 * Load the language array based on language code.
 *
 * @param string $langCode The language code (e.g., 'eng', 'tr').
 * @return array The associative array of translations.
 */
function loadLanguage($langCode = 'eng')
{
    $langCode = strtolower(trim((string) $langCode));
    if ($langCode === '') {
        $langCode = 'eng';
    }
    $langFile = __DIR__ . '/../../langs/' . $langCode . '.php';

    if (!file_exists($langFile)) {
        echo '<pre>Language file not found: ' . $langFile . '</pre>';
        return [];
    }

    $translations = include $langFile;

    if (!is_array($translations)) {
        echo '<pre>Language file does not return an array: ' . $langFile . '</pre>';
        return [];
    }

    $audioRoomCatalogFile = __DIR__ . '/../../langs/features/audio_room_v2/_catalog.php';
    if (is_file($audioRoomCatalogFile)) {
        $audioRoomCatalog = include $audioRoomCatalogFile;
        if (is_array($audioRoomCatalog)) {
            $featureTranslations = $audioRoomCatalog[$langCode] ?? $audioRoomCatalog['eng'] ?? [];
            if (is_array($featureTranslations)) {
                $translations = array_replace($translations, $featureTranslations);
            }
        }
    }

    global $db;
    if (isset($db) && $db instanceof PDO) {
        try {
            $stmt = $db->prepare('SELECT lang_key, value FROM i_lang_overrides WHERE language = :lang');
            $stmt->bindValue(':lang', $langCode, PDO::PARAM_STR);
            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
            foreach ($rows as $row) {
                $key = (string) ($row['lang_key'] ?? '');
                if ($key === '') {
                    continue;
                }
                $translations[$key] = (string) ($row['value'] ?? '');
            }
        } catch (Throwable $e) {
            // Ignore silently; fall back to file-based translations.
            if (defined('APP_DEBUG') && APP_DEBUG === true) {
                error_log('loadLanguage override fetch failed: ' . $e->getMessage());
            }
        }
    }

    return $translations;
}

/**
 * Get the translated string for a given key.
 * If translation is missing, generate a fallback text from the key.
 * Also supports dynamic placeholders like {{sitename}}.
 *
 * @param string      $key      The language array key.
 * @param string|null $fallback Optional fallback when translation is missing.
 * @return string The translated or fallback string.
 */
function customLang($key, ?string $fallback = null, array $replacements = [])
{
    global $lang, $siteName, $base_url, $scriptVersion, $premiumPostPriceMinimum, $premiumPostPriceMaximum, $postPrice, $mediaSummary,$priceInt,$cur;

    // 1. Get translation if available
    if (isset($lang[$key])) {
        $text = $lang[$key];
    } else {
        // 2. Fallback to provided default or readable string from the key
        if ($fallback !== null) {
            $text = $fallback;
        } else {
            $text = ucwords(str_replace('_', ' ', preg_replace('/^.+?_/', '', $key)));
        }
    }

    // 3. Replace dynamic placeholders
    $placeholders = [
        '{{sitename}}'      => $siteName ?? '',
        '{{baseurl}}'       => $base_url ?? '',
        '{{scriptversion}}' => $scriptVersion ?? '',
        '{{year}}'          => date('Y'),
        '{{premiumPostPriceMinimum}}' => $premiumPostPriceMinimum ?? '',
        '{{premiumPostPriceMaximum}}' => $premiumPostPriceMaximum ?? '',
        '{{postPrice}}'               => $postPrice ?? '',
        '{{mediaSummary}}'                            => $mediaSummary ?? '',
        '{{currency}}' => $priceInt ?? '',
        '{{unlockPrice}}'=> $cur ?? '',
    ];

    $text = str_replace(array_keys($placeholders), array_values($placeholders), $text);

    if (!empty($replacements)) {
        foreach ($replacements as $placeholder => $value) {
            if (is_int($placeholder)) {
                $token = '{' . $placeholder . '}';
                $tokenAlt = '{{' . $placeholder . '}}';
            } else {
                $token = '{' . $placeholder . '}';
                $tokenAlt = '{{' . $placeholder . '}}';
            }
            $value = is_scalar($value) ? (string) $value : '';
            $text = str_replace([$token, $tokenAlt], $value, $text);
        }
    }

    return dAi_SanitizeHtmlSupport($text);
}
