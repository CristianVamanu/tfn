<?php
declare(strict_types=1);

/**
 * Minimal helpers to build Agora join context.
 * Includes an inline implementation of Agora RTC AccessToken2 (version 007).
 */

// Fast little-endian packers (avoid per-call closures)
function agora_pack_u16(int $v): string { return pack('v', $v & 0xFFFF); }
function agora_pack_u32(int $v): string { return pack('V', $v & 0xFFFFFFFF); }
function agora_pack_str(string $s): string { return agora_pack_u16(strlen($s)) . $s; }
function agora_pack_privs(array $privs): string {
    $buf = agora_pack_u16(count($privs));
    foreach ($privs as $k => $v) {
        $buf .= agora_pack_u16((int)$k) . agora_pack_u32((int)$v);
    }
    return $buf;
}
function agora_pack_service(int $type, string $serviceBody, array $privs): string {
    return agora_pack_u16($type) . agora_pack_privs($privs) . $serviceBody;
}
function agora_build_access_token2(string $appId, string $appCert, array $services, int $expireSeconds): string {
    if (strlen($appId) !== 32 || strlen($appCert) !== 32 || !ctype_xdigit($appId) || !ctype_xdigit($appCert)) {
        return '';
    }
    $issueTs = time();
    $validFor = max(60, $expireSeconds);
    try {
        $salt = random_int(1, 99999999);
    } catch (Throwable $e) {
        $salt = ($issueTs % 99999999) + 1;
    }

    ksort($services);
    $servicesBlob = agora_pack_u16(count($services));
    foreach ($services as $service) {
        $servicesBlob .= (string)$service;
    }

    $data = agora_pack_str($appId) . agora_pack_u32($issueTs) . agora_pack_u32($validFor) . agora_pack_u32($salt) . $servicesBlob;
    $intermediateKey = hash_hmac('sha256', $appCert, agora_pack_u32($issueTs), true);
    $signingKey = hash_hmac('sha256', $intermediateKey, agora_pack_u32($salt), true);
    $signature = hash_hmac('sha256', $data, $signingKey, true);
    $compressed = zlib_encode(agora_pack_str($signature) . $data, ZLIB_ENCODING_DEFLATE);
    if ($compressed === false) {
        return '';
    }
    return '007' . base64_encode($compressed);
}

/** Build a deterministic channel name for a live stream */
function agora_channel_name(int $liveId, int $ownerId): string {
    return 'live_' . $ownerId . '_' . $liveId;
}

/** Build a deterministic fallback channel name for an audio room. */
function agora_audio_room_channel_name(int $roomId, int $ownerId): string {
    return 'audio_' . $ownerId . '_' . $roomId;
}

/** Generate a pseudo token placeholder when no certificate is set. */
function agora_fake_token(string $appId, string $channel, string $uid, int $expireTs): string {
    $raw = $appId . '|' . $channel . '|' . $uid . '|' . $expireTs;
    return 'FAKE_' . substr(hash('sha256', $raw), 0, 40);
}

/**
 * Build join payload. In production, plug in Agora RTC token generator
 * with privileges for publisher (owner) or audience (viewer).
 */
function agora_build_join_payload(
    string $appId,
    ?string $appCert,
    string $channel,
    string $uid,
    string $role,
    int $expireSeconds,
    array $options = []
): array {
    $now = time();
    $expireTs = $now + max(60, $expireSeconds);
    // If certificate is missing, return a debug token (not usable against Agora)
    if (empty($appCert)) {
        $token = agora_fake_token($appId, $channel, $uid, $expireTs);
        $rtmToken = 'FAKE_RTM_' . substr(hash('sha256', $appId . '|' . $uid . '|' . $expireTs), 0, 40);
        return [
            'appId'   => $appId,
            'channel' => $channel,
            'uid'     => $uid,
            'role'    => $role,
            'token'   => $token,
            'rtm_token' => $rtmToken,
            'expire'  => $expireTs,
            'debug'   => true
        ];
    }
    // Privileges per role (Service RTC)
    // 1: JOIN, 2: PUBLISH_AUDIO, 3: PUBLISH_VIDEO, 4: PUBLISH_DATA
    $privileges = [1 => $expireTs];
    $roleCanPublish = ($role === 'host' || $role === 'publisher' || $role === 'speaker' || $role === 'moderator');
    $publishAudio = array_key_exists('publish_audio', $options) ? (bool)$options['publish_audio'] : $roleCanPublish;
    $publishVideo = array_key_exists('publish_video', $options) ? (bool)$options['publish_video'] : (($role === 'host' || $role === 'publisher'));
    $publishData = array_key_exists('publish_data', $options) ? (bool)$options['publish_data'] : $roleCanPublish;
    if ($publishAudio) {
        $privileges[2] = $expireTs;
    }
    if ($publishVideo) {
        $privileges[3] = $expireTs;
    }
    if ($publishData) {
        $privileges[4] = $expireTs;
    }

    // Service RTC (type = 1): channel, uid/account, privileges.
    $serviceRtc = agora_pack_service(1, agora_pack_str($channel) . agora_pack_str((string)$uid), $privileges);
    $token = agora_build_access_token2($appId, $appCert, [1 => $serviceRtc], max(60, $expireSeconds));

    // Also build RTM token (service type 2 with LOGIN privilege)
    $rtmPrivileges = [1 => $expireTs]; // 1: LOGIN
    $rtmService = agora_pack_service(2, agora_pack_str((string)$uid), $rtmPrivileges);
    $rtmToken = agora_build_access_token2($appId, $appCert, [2 => $rtmService], max(60, $expireSeconds));

    return [
        'appId'   => $appId,
        'channel' => $channel,
        'uid'     => $uid,
        'role'    => $role,
        'token'   => $token,
        'rtm_token' => $rtmToken,
        'expire'  => $expireTs,
        'debug'   => false
    ];
}

/** Build an Agora token payload for audio-only rooms. */
function agora_build_audio_room_join_payload(
    string $appId,
    ?string $appCert,
    string $channel,
    string $uid,
    string $role,
    int $expireSeconds
): array {
    $canPublishAudio = in_array($role, ['host','moderator','speaker'], true);
    return agora_build_join_payload($appId, $appCert, $channel, $uid, $role, $expireSeconds, [
        'publish_audio' => $canPublishAudio,
        'publish_video' => false,
        'publish_data'  => $canPublishAudio,
    ]);
}
