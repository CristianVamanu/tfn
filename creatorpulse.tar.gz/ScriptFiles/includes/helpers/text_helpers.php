<?php
/**
 * Text helpers for accessibility-friendly strings.
 *
 * - dzShortCaption: produce a safe, trimmed, emoji-free, truncated caption.
 *
 * Test checklist:
 * - Returns empty string on null/empty input
 * - Strips HTML tags and emojis
 * - Collapses whitespace
 * - Truncates to limit and appends … (ellipsis)
 * - Accepts arrays with keys: post_text, title, caption, text, description
 */

if (!function_exists('dzShortCaption')) {
    /**
     * Build a short, safe caption from a string or post-like array.
     *
     * @param mixed $input String caption or array with known text keys.
     * @param int   $limit Max characters before ellipsis (default: 80).
     *
     * @return string Safe, truncated caption (may be empty string).
     */
    function dzShortCaption($input, int $limit = 80): string
    {
        $s = '';
        if (is_array($input)) {
            // Try common content keys in order
            foreach (['post_text', 'title', 'caption', 'text', 'description'] as $k) {
                if (!empty($input[$k])) {
                    $s = (string) $input[$k];
                    break;
                }
            }
        } elseif (is_string($input)) {
            $s = $input;
        }

        if ($s === '') {
            return '';
        }

        // Normalize encoding to UTF-8
        if (function_exists('mb_convert_encoding')) {
            $s = mb_convert_encoding($s, 'UTF-8', 'auto');
        }

        // Decode entities, strip tags
        $s = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $s = strip_tags($s);

        // Remove common emoji and variation selectors
        // Note: conservative ranges to keep performance reasonable
        $s = preg_replace('/[\x{1F600}-\x{1F64F}\x{1F300}-\x{1F5FF}\x{1F680}-\x{1F6FF}\x{1F900}-\x{1F9FF}\x{1FA70}-\x{1FAFF}\x{2600}-\x{26FF}\x{2700}-\x{27BF}\x{200D}\x{FE0F}]/u', '', $s);

        // Collapse whitespace
        $s = trim(preg_replace('/\s+/u', ' ', $s));

        if ($s === '') {
            return '';
        }

        // Truncate with ellipsis if needed
        if (function_exists('mb_strlen') && function_exists('mb_substr')) {
            if (mb_strlen($s, 'UTF-8') > $limit) {
                $s = rtrim(mb_substr($s, 0, max(1, $limit - 1), 'UTF-8')) . '…';
            }
        } else {
            if (strlen($s) > $limit) {
                $s = rtrim(substr($s, 0, max(1, $limit - 1))) . '…';
            }
        }

        return $s;
    }
}

