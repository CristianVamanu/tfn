<?php

declare(strict_types=1);

if (!function_exists('storage_publish')) {
    /**
     * Publish a local file via the active storage adapter.
     *
     * @throws StorageException
     */
    function storage_publish(
        string $absolutePath,
        string $remoteKey,
        string $contentType,
        string $visibility = 'public',
        array $options = []
    ): StorageResult {
        $absolutePath = storage_normalize_absolute_path($absolutePath);
        $remoteKey = storage_normalize_remote_key($remoteKey);

        if (!is_file($absolutePath) || !is_readable($absolutePath)) {
            throw new StorageException('Source file missing for storage publish: ' . $absolutePath, 'source_missing');
        }

        $adapter = storage_adapter();
        $result = $adapter->put($absolutePath, $remoteKey, $contentType, $visibility, $options);

        try {
            if (storage_manager()->isRemote() && storage_keep_local_copy_enabled()) {
                storage_shadow_local_copy($absolutePath, $remoteKey);
            }
        } catch (Throwable $e) {
            if (function_exists('error_log')) {
                error_log('[Storage] shadow copy failed: ' . $e->getMessage());
            }
        }

        return $result;
    }
}

if (!function_exists('storage_publish_relative')) {
    /**
     * Publish a file referenced by its relative storage key.
     *
     * @throws StorageException
     */
    function storage_publish_relative(
        string $remoteKey,
        ?string $contentType = null,
        string $visibility = 'public',
        array $options = []
    ): StorageResult {
        $remoteKey = storage_normalize_remote_key($remoteKey);
        $absolutePath = storage_resolve_absolute_path($remoteKey);
        $contentType = $contentType ?? storage_guess_content_type($remoteKey);

        return storage_publish($absolutePath, $remoteKey, $contentType, $visibility, $options);
    }
}

if (!function_exists('storage_normalize_remote_key')) {
    function storage_normalize_remote_key(string $remoteKey): string
    {
        $normalized = preg_replace('#/+#', '/', str_replace('\\', '/', trim($remoteKey)));
        $normalized = ltrim((string) $normalized, '/');
        if ($normalized === '') {
            throw new StorageException('Remote key cannot be empty', 'invalid_key');
        }

        return $normalized;
    }
}

if (!function_exists('storage_normalize_absolute_path')) {
    function storage_normalize_absolute_path(string $absolutePath): string
    {
        $path = str_replace(['\\', '//'], DIRECTORY_SEPARATOR, $absolutePath);
        return $path;
    }
}

if (!function_exists('storage_resolve_absolute_path')) {
    function storage_resolve_absolute_path(string $remoteKey): string
    {
        $remoteKey = storage_normalize_remote_key($remoteKey);
        $baseCandidates = [];

        if (!empty($_SERVER['DOCUMENT_ROOT'])) {
            $baseCandidates[] = rtrim((string) $_SERVER['DOCUMENT_ROOT'], '/');
        }

        $projectRoot = realpath(__DIR__ . '/..');
        if ($projectRoot) {
            $baseCandidates[] = rtrim(dirname($projectRoot), '/');
            $baseCandidates[] = rtrim($projectRoot, '/');
        }

        foreach ($baseCandidates as $base) {
            if (!$base) {
                continue;
            }
            $candidate = $base . '/' . $remoteKey;
            if (is_file($candidate)) {
                return $candidate;
            }
        }

        // Fallback: assume project root
        $fallbackBase = $baseCandidates[0] ?? getcwd() ?: '.';

        return rtrim((string) $fallbackBase, '/') . '/' . $remoteKey;
    }
}

if (!function_exists('storage_guess_content_type')) {
    function storage_guess_content_type(string $remoteKey): string
    {
        $ext = strtolower(pathinfo($remoteKey, PATHINFO_EXTENSION));
        switch ($ext) {
            case 'jpg':
            case 'jpeg':
                return 'image/jpeg';
            case 'png':
                return 'image/png';
            case 'webp':
                return 'image/webp';
            case 'gif':
                return 'image/gif';
            case 'mp4':
                return 'video/mp4';
            case 'mov':
                return 'video/quicktime';
            case 'm4v':
                return 'video/x-m4v';
            case 'avi':
                return 'video/x-msvideo';
            case 'mp3':
                return 'audio/mpeg';
            case 'wav':
                return 'audio/wav';
            case 'svg':
                return 'image/svg+xml';
            case 'pdf':
                return 'application/pdf';
            default:
                return 'application/octet-stream';
        }
    }
}

if (!function_exists('storage_relative_from_url')) {
    function storage_relative_from_url(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        $candidates = [];

        if (!empty($GLOBALS['storage_public_base'])) {
            $candidates[] = rtrim((string) $GLOBALS['storage_public_base'], '/') . '/';
        }

        if (!empty($GLOBALS['base_url'])) {
            $candidates[] = rtrim((string) $GLOBALS['base_url'], '/') . '/';
        }

        foreach ($candidates as $base) {
            if ($base !== '' && stripos($url, $base) === 0) {
                return ltrim(substr($url, strlen($base)), '/');
            }
        }

        if (preg_match('#^(?:[a-z][a-z0-9+\-.]*:)?//#i', $url)) {
            $parsed = parse_url($url);
            if (!empty($parsed['path'])) {
                return ltrim((string) $parsed['path'], '/');
            }

            return '';
        }

        return ltrim($url, '/');
    }
}

if (!function_exists('storage_resolve_media_url')) {
    function storage_resolve_media_url(string $path, ?string $fallbackBase = null): string
    {
        $trimmed = trim($path);
        if ($trimmed === '') {
            return '';
        }

        $candidate = $trimmed;

        if (function_exists('storage_relative_from_url')) {
            $relative = storage_relative_from_url($trimmed);
            if ($relative !== '') {
                $candidate = $relative;
            }
        }

        if (function_exists('storage_url')) {
            $resolved = storage_url($candidate);
            if ($resolved !== '') {
                return $resolved;
            }
        }

        if ($fallbackBase === null && isset($GLOBALS['base_url'])) {
            $fallbackBase = (string) $GLOBALS['base_url'];
        }

        if (preg_match('#^(?:[a-z][a-z0-9+\-.]*:)?//#i', $trimmed) === 1) {
            return $trimmed;
        }

        $base = $fallbackBase !== null ? rtrim((string) $fallbackBase, '/') . '/' : '';

        return $base . ltrim($trimmed, '/');
    }
}

if (!function_exists('storage_delete')) {
    function storage_delete(string $path): bool
    {
        $raw = trim($path);
        if ($raw === '') {
            return false;
        }

        $candidate = $raw;
        if (function_exists('storage_relative_from_url')) {
            $rel = storage_relative_from_url($raw);
            if ($rel !== '') {
                $candidate = $rel;
            }
        }

        $candidate = ltrim(str_replace(['\\', '..//', '../'], ['/', '', ''], $candidate), '/');
        if ($candidate === '') {
            return false;
        }

        try {
            $adapter = storage_adapter();
            if ($adapter) {
                return $adapter->delete($candidate);
            }
        } catch (Throwable $e) {
            if (function_exists('error_log')) {
                error_log('[Storage] delete failed for ' . $candidate . ': ' . $e->getMessage());
            }
        }

        return false;
    }
}

if (!function_exists('storage_keep_local_copy_enabled')) {
    function storage_keep_local_copy_enabled(): bool
    {
        try {
            $config = storage_manager()->getResolvedConfig();
            if (isset($config['keep_local_copy'])) {
                return (bool) $config['keep_local_copy'];
            }
        } catch (Throwable $__) {}

        return true;
    }
}

if (!function_exists('storage_local_root')) {
    function storage_local_root(): string
    {
        static $cached = null;
        if ($cached !== null) {
            return $cached;
        }

        $root = '';
        if (isset($GLOBALS['uploadFile']) && is_string($GLOBALS['uploadFile']) && $GLOBALS['uploadFile'] !== '') {
            $root = dirname((string) $GLOBALS['uploadFile'], 2);
        } elseif (!empty($_SERVER['DOCUMENT_ROOT'])) {
            $root = rtrim((string) $_SERVER['DOCUMENT_ROOT'], '/');
        } else {
            $cwd = getcwd();
            $root = $cwd !== false ? rtrim($cwd, '/') : '.';
        }

        return $cached = $root !== '' ? $root : '.';
    }
}

if (!function_exists('storage_local_shadow_target')) {
    function storage_local_shadow_target(string $remoteKey): string
    {
        $normalized = storage_normalize_remote_key($remoteKey);
        $shadowKey = $normalized;
        if (strpos($normalized, 'uploads/') !== 0) {
            $shadowKey = 'uploads/mirror/' . ltrim($normalized, '/');
        }

        return rtrim(storage_local_root(), '/') . '/' . $shadowKey;
    }
}

if (!function_exists('storage_shadow_local_copy')) {
    function storage_shadow_local_copy(string $sourcePath, string $remoteKey): void
    {
        $sourceReal = realpath($sourcePath) ?: $sourcePath;
        $targetPath = storage_local_shadow_target($remoteKey);
        $targetReal = realpath($targetPath);
        if ($targetReal !== false && $sourceReal !== false && $sourceReal === $targetReal) {
            return;
        }

        $targetDir = dirname($targetPath);
        if (!is_dir($targetDir)) {
            @mkdir($targetDir, 0775, true);
        }

        if (!@copy($sourcePath, $targetPath)) {
            if (function_exists('error_log')) {
                error_log('[Storage] Failed to mirror file locally: ' . $sourcePath . ' -> ' . $targetPath);
            }
        }
    }
}

if (!function_exists('storage_assert_crypto_available')) {
    /**
     * Ensure a strong crypto backend is available before handling secrets.
     *
     * @throws RuntimeException when neither OpenSSL nor Sodium is available.
     */
    function storage_assert_crypto_available(): void
    {
        $opensslReady = extension_loaded('openssl') && function_exists('openssl_encrypt') && function_exists('openssl_decrypt');
        $sodiumReady  = extension_loaded('sodium') && function_exists('sodium_crypto_secretbox') && function_exists('sodium_crypto_secretbox_open');

        if ($opensslReady || $sodiumReady) {
            return;
        }

        throw new RuntimeException(
            'Storage encryption requires ext-openssl or ext-sodium. Enable one of these extensions to protect secrets at rest.'
        );
    }
}

if (!function_exists('storage_cipher_key')) {
    function storage_cipher_key(): string
    {
        static $cached = null;
        if ($cached !== null) {
            return $cached;
        }

        $candidates = [
            getenv('STORAGE_ENCRYPTION_KEY'),
            getenv('APP_KEY'),
            getenv('APP_SECRET'),
            getenv('ENCRYPTION_KEY'),
        ];

        $envKey = null;
        foreach ($candidates as $candidate) {
            if (is_string($candidate) && trim($candidate) !== '') {
                $envKey = trim($candidate);
                break;
            }
        }

        if ($envKey === null || $envKey === '') {
            throw new RuntimeException(
                'Missing STORAGE_ENCRYPTION_KEY. Ensure the installer generated it or define it manually in your environment.'
            );
        }

        if (stripos($envKey, 'base64:') === 0) {
            $decoded = base64_decode(substr($envKey, 7), true);
            if ($decoded !== false && $decoded !== '') {
                $envKey = $decoded;
            }
        }

        return $cached = hash('sha256', (string) $envKey, true);
    }
}

if (!function_exists('storage_encrypt_secret')) {
    function storage_encrypt_secret(string $plainText): string
    {
        return $plainText;
    }
}

if (!function_exists('storage_decrypt_secret')) {
    function storage_decrypt_secret(?string $cipherText): string
    {
        return (string) $cipherText;
    }
}
