<?php
/**
 * Icon helper utilities shared across front-end and admin layers.
 */

if (!function_exists('icon_asset_key')) {
    /**
     * Normalize an icon identifier to its canonical key (without extension).
     */
    function icon_asset_key(string $identifier): string
    {
        $id = trim($identifier);
        if ($id === '') {
            return '';
        }

        // If a URL or file path is supplied, reduce it to the filename.
        if (strpos($id, '/') !== false || strpos($id, '\\') !== false) {
            $path = (string) parse_url($id, PHP_URL_PATH);
            if ($path !== '') {
                $id = basename($path);
            }
        }

        // Strip query fragments and sanitize
        if (($pos = strpos($id, '?')) !== false) {
            $id = substr($id, 0, $pos);
        }
        if (($pos = strpos($id, '#')) !== false) {
            $id = substr($id, 0, $pos);
        }

        $id = preg_replace('~[^a-z0-9_.-]+~i', '', $id) ?? '';
        $id = preg_replace('~\.svg$~i', '', $id ?? '') ?? '';

        return strtolower($id);
    }
}

if (!function_exists('icon_asset_normalize_public_path')) {
    /**
     * Convert a stored icon path to a public URL relative to base_url when needed.
     */
    function icon_asset_normalize_public_path(string $path): string
    {
        $path = trim($path);
        if ($path === '') {
            return '';
        }

        if (preg_match('~^(?:https?:)?//~i', $path)) {
            return $path;
        }

        if (strncmp($path, '/', 1) === 0) {
            return $path;
        }

        $base = rtrim((string) ($GLOBALS['base_url'] ?? ''), '/');
        if ($base === '') {
            return '/' . ltrim($path, '/');
        }

        return $base . '/' . ltrim($path, '/');
    }
}

if (!function_exists('icon_theme_fallback')) {
    /**
     * Build the traditional theme icon URL fallback for a given key.
     */
    function icon_theme_fallback(string $key): string
    {
        $key = icon_asset_key($key);
        if ($key === '') {
            return '';
        }

        $fileName = $key . '.svg';
        $relative = 'themes/default/icons/' . $fileName;

        // Attempt to locate hashed/icon-versioned files (key-<hash>.svg) if the plain name is absent.
        $iconDir = dirname(__DIR__, 2) . '/themes/default/icons/';
        $plainPath = $iconDir . $fileName;
        if (!is_file($plainPath)) {
            $hashedMatches = glob($iconDir . $key . '-*.svg') ?: [];
            if (!empty($hashedMatches)) {
                $hashMatch = reset($hashedMatches);
                if (is_string($hashMatch) && $hashMatch !== '' && is_file($hashMatch)) {
                    $fileName = basename($hashMatch);
                    $relative = 'themes/default/icons/' . $fileName;
                }
            }
        }

        $iconPath = $GLOBALS['iconPath'] ?? '';
        if ($iconPath !== '') {
            return rtrim((string) $iconPath, '/') . '/' . $fileName;
        }

        $base = rtrim((string) ($GLOBALS['base_url'] ?? ''), '/');
        if ($base === '') {
            return '/' . $relative;
        }

        return $base . '/' . $relative;
    }
}

if (!function_exists('icon_asset_url')) {
    /**
     * Resolve an icon identifier to a public URL, preferring the i_icons table and alias lookups.
     *
     * @param string      $identifier Icon key, filename, or URL.
     * @param string|null $fallback   Fallback URL to return when no DB match exists.
     */
    function icon_asset_url(string $identifier, ?string $fallback = null): string
    {
        $key = icon_asset_key($identifier);

        if (!isset($GLOBALS['__iconAssetLoaded']) || $GLOBALS['__iconAssetLoaded'] !== true) {
            $GLOBALS['__iconAssetLoaded'] = true;
            $GLOBALS['__iconAssetMap']   = [];
            $GLOBALS['__iconAssetIdMap'] = [];

            try {
                $db = $GLOBALS['db'] ?? null;
                if ($db instanceof PDO) {
                    $stmt = $db->query('SELECT id, icon_key, file_path FROM i_icons');
                    if ($stmt) {
                        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
                        foreach ($rows as $row) {
                            $iconKey = icon_asset_key((string) ($row['icon_key'] ?? ''));
                            if ($iconKey === '') {
                                continue;
                            }
                            $path = (string) ($row['file_path'] ?? '');
                            $iconId = (int) ($row['id'] ?? 0);
                            $GLOBALS['__iconAssetMap'][$iconKey] = $path;
                            if ($iconId > 0) {
                                $GLOBALS['__iconAssetIdMap'][$iconId] = $path;
                            }
                        }
                    }

                    if (!empty($GLOBALS['__iconAssetIdMap'])) {
                        try {
                            $aliasStmt = $db->query('SELECT icon_id, alias_key FROM i_icon_aliases');
                            if ($aliasStmt) {
                                $aliasRows = $aliasStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
                                foreach ($aliasRows as $aliasRow) {
                                    $aliasKey = icon_asset_key((string) ($aliasRow['alias_key'] ?? ''));
                                    $iconId   = (int) ($aliasRow['icon_id'] ?? 0);
                                    if ($aliasKey === '' || !isset($GLOBALS['__iconAssetIdMap'][$iconId])) {
                                        continue;
                                    }
                                    $GLOBALS['__iconAssetMap'][$aliasKey] = $GLOBALS['__iconAssetIdMap'][$iconId];
                                }
                            }
                        } catch (Throwable $__) {
                            // Ignore alias load failures; fallbacks will cover.
                        }
                    }
                }
            } catch (Throwable $__) {
                // Ignore DB bootstrap failures; fallbacks below will handle resolution.
            }
        }

        $iconMap = $GLOBALS['__iconAssetMap'] ?? [];

        if ($key !== '' && isset($iconMap[$key]) && $iconMap[$key] !== '') {
            return icon_asset_normalize_public_path((string) $iconMap[$key]);
        }

        if (preg_match('~^(?:https?:)?//~i', $identifier) || strncmp($identifier, '/', 1) === 0) {
            return $identifier;
        }

        if ($fallback !== null && $fallback !== '') {
            return $fallback;
        }

        if ($key !== '') {
            $fallbackUrl = icon_theme_fallback($key);
            if ($fallbackUrl !== '') {
                return $fallbackUrl;
            }
        }

        return '';
    }
}

if (!function_exists('icon_asset_cache_reset')) {
    /**
     * Clear the cached icon lookup maps.
     */
    function icon_asset_cache_reset(): void
    {
        unset($GLOBALS['__iconAssetLoaded'], $GLOBALS['__iconAssetMap'], $GLOBALS['__iconAssetIdMap']);
    }
}

if (!function_exists('icon_public_url')) {
    /**
     * Resolve an icon key to its public URL while honouring optional fallback paths.
     */
    function icon_public_url(string $identifier, ?string $fallback = null): string
    {
        $key = icon_asset_key($identifier);
        $defaultFallback = $fallback;
        if ($defaultFallback === null) {
            $defaultFallback = icon_theme_fallback($key !== '' ? $key : $identifier);
        }

        // If identifier already contains slashes treat it as path/URL first.
        if (strpos($identifier, '/') !== false) {
            $resolved = icon_asset_url($identifier, $defaultFallback);
            if ($resolved !== '') {
                return $resolved;
            }
        }

        return icon_asset_url($key !== '' ? $key : $identifier, $defaultFallback);
    }
}

if (!function_exists('render_icon')) {
    /**
     * Convenience helper to render an SVG/icon via renderVerifiedBadge using DB resolution.
     */
    function render_icon(string $identifier, bool $forceMono = true, ?string $fallback = null): string
    {
        $url = icon_public_url($identifier, $fallback);
        if ($url === '') {
            return '';
        }

        return renderVerifiedBadge($url, $forceMono);
    }
}
