<?php
declare(strict_types=1);

/**
 * Discover available theme thumbnail images and return their public URLs.
 * Falls back to the generic placeholder when none are found.
 *
 * Conventions:
 * - Looks in `themes/{currentTheme}/assets/img/thumbs/`
 * - Accepts files with extensions: jpg, jpeg, png, webp, svg
 * - Returns absolute URLs using `$base_url`
 *
 * @return array<int, string>
 */
function themeThumbs(): array
{
    global $currentTheme, $base_url;

    $theme  = is_string($currentTheme) && $currentTheme !== '' ? $currentTheme : 'default';
    $webDir = 'themes/' . $theme . '/assets/img/thumbs/';

    // Resolve filesystem path for scanning relative to script root
    $fsDir = dirname(__DIR__, 2) . '/' . $webDir;
    $fsDir = str_replace(['\\'], '/', $fsDir);

    $allowed = ['jpg', 'jpeg', 'png', 'webp', 'svg'];
    $found   = [];

    if (@is_dir($fsDir)) {
        $items = @scandir($fsDir, SCANDIR_SORT_ASCENDING) ?: [];
        foreach ($items as $name) {
            if ($name === '.' || $name === '..') {
                continue;
            }
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if ($ext !== '' && in_array($ext, $allowed, true)) {
                $found[] = rtrim((string)$base_url, '/') . '/' . $webDir . $name;
            }
        }
    }

    if (!empty($found)) {
        return $found;
    }

    // Fallback to generic placeholder (theme asset)
    $placeholder = rtrim((string)$base_url, '/') . '/themes/' . $theme . '/assets/img/placeholder.svg';
    return [$placeholder];
}
