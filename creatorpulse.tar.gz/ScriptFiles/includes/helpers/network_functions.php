<?php

/**
 * Sanitize and decode SVG entities for proper HTML rendering.
 *
 * This function replaces escaped HTML entities with their actual characters
 * to allow safe and correct SVG code rendering in the frontend.
 *
 * @param string $svgCode The raw SVG code possibly containing escaped entities.
 * @return string Cleaned SVG code ready to be echoed into HTML.
 */
function SVGMe(string $svgCode): string
{
    $svgCode = str_replace('\&quot;', '"', $svgCode);
    $svgCode = str_replace('\"', '"', $svgCode);
    $svgCode = str_replace('\&lt;', '<', $svgCode);
    $svgCode = str_replace('\&gt;', '>', $svgCode);
    $svgCode = str_replace('\&amp;', '&', $svgCode);

    return $svgCode;
}

/**
 * Convert size strings like '512M', '2G', '1024K' to megabyte float value.
 *
 * This function accepts a size in bytes or in shorthand format (e.g. 512M, 2G, 1024K)
 * and converts it to a float representing the size in megabytes.
 *
 * @param int|string $size The size to convert. Can be numeric or a string with size unit suffix.
 * @return float Converted size in megabytes.
 */
function convert_to_mb_unit($size = 0): float
{
    if (is_string($size)) {
        $size = trim($size);
        $lastChar = strtolower($size[strlen($size) - 1]);

        switch ($lastChar) {
            case 'g':
                $size = floatval($size) * 1024 * 1024 * 1024; // GB to bytes
                break;
            case 'm':
                $size = floatval($size) * 1024 * 1024; // MB to bytes
                break;
            case 'k':
                $size = floatval($size) * 1024; // KB to bytes
                break;
            default:
                $size = floatval($size); // Assume bytes
                break;
        }
    }

    if (!is_numeric($size)) {
        trigger_error(
            'convert_to_mb_unit() expects a numeric or valid size string. Non-numeric value encountered.',
            E_USER_WARNING
        );
        return 0.0;
    }

    return round($size / (1024 * 1024), 2); // Convert bytes to MB
}

/**
 * Converts a file size value (e.g., 2M, 512K, 1.5G) to megabytes.
 *
 * This version is tailored for avatar upload size checks, converting any input
 * string or number into megabyte (MB) float value.
 *
 * @param int|string $size The input size, either numeric or a string like "2M", "512K".
 * @return float The size in megabytes.
 */
function convert_to_mb_unit_avatar($size = 0): float
{
    if (is_string($size)) {
        $size = trim($size);
        $lastChar = strtolower($size[strlen($size) - 1]);

        switch ($lastChar) {
            case 'g':
                $size = floatval($size) * 1024 * 1024 * 1024; // Convert GB to bytes
                break;
            case 'm':
                $size = floatval($size) * 1024 * 1024; // Convert MB to bytes
                break;
            case 'k':
                $size = floatval($size) * 1024; // Convert KB to bytes
                break;
            default:
                $size = floatval($size); // Assume already in bytes
                break;
        }
    }

    if (!is_numeric($size)) {
        trigger_error(
            'convert_to_mb_unit_avatar() expects a numeric or parsable size string.',
            E_USER_WARNING
        );
        return 0.0;
    }

    return round($size / (1024 * 1024), 2); // Convert bytes to MB
}

/**
 * Converts a byte value into a human-readable format (KB, MB, or GB).
 *
 * @param int|float $size The size in bytes.
 * @return string Formatted size with appropriate unit (e.g., "2 MB", "512 KB").
 */
function convert_to_mb($size = 0): string
{
    if (!is_numeric($size)) {
        trigger_error('convert_to_mb() expects a numeric value.', E_USER_WARNING);
        return '0';
    }

    if ($size >= 1073741824) {
        return round($size / 1073741824) . ' GB';
    }

    if ($size >= 1048576) {
        return round($size / 1048576) . ' MB';
    }

    if ($size >= 1024) {
        return round($size / 1024) . ' KB';
    }

    return (string) $size; // Return bytes as-is if less than 1KB
}


/**
 * Detects whether the current user agent is a mobile device.
 *
 * This function checks the HTTP_USER_AGENT string against a wide range of
 * patterns for mobile phones, tablets, and other handheld devices.
 *
 * @return bool Returns true if a mobile device is detected, false otherwise.
 */
function CheckDevice(): bool
{
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

    // First regex pattern covers common mobile user agents
    $mobilePattern1 = '/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i';

    // Second regex pattern covers less common and older devices
    $mobilePattern2 = '/^1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i';

    return preg_match($mobilePattern1, $userAgent) || preg_match($mobilePattern2, substr($userAgent, 0, 4));
}

/**
 * List of currency codes and their corresponding symbols or names.
 *
 * This array includes fiat and cryptocurrency symbols.
 * Used for displaying proper currency formatting in the system.
 */
$currencys = [
    // Fiat Currencies
    'USD' => '$',
    'AUD' => '$',
    'EUR' => '€',
    'BRL' => 'R$',
    'CAD' => '$',
    'CZK' => 'Kč',
    'DKK' => 'kr',
    'HKD' => '$',
    'HUF' => 'Ft',
    'INR' => '₹',
    'ILS' => '₪',
    'JPY' => '¥',
    'MYR' => 'RM',
    'MXN' => '$',
    'TWD' => 'NT$',
    'NZD' => '$',
    'NOK' => 'kr',
    'PHP' => '₱',
    'PLN' => 'zł',
    'GBP' => '£',
    'RUB' => 'руб',
    'SGD' => '$',
    'CHF' => 'CHF',
    'THB' => '฿',
    'TRY' => '₺',
    'ZAR' => 'R',
    'NGN' => '₦',
    'VND' => 'đ',
    'BDT' => '৳',
    'ARS' => '$',
    'BOB' => 'Bs',
    'CLF' => 'UF',
    'CLP' => '$',
    'COP' => '$',
    'CRC' => '₡',
    'CUC' => 'CUC',
    'CUP' => '$',
    'DOP' => '$',
    'GTQ' => 'Q',
    'HNL' => 'L',
    'NIO' => 'C$',
    'PYG' => '₲',

    // Cryptocurrencies
    'BTC'   => 'Bitcoin',
    'BCH'   => 'Bitcon Cash',
    'LTC'   => 'LiteCoin',
    'VLX'   => 'Velas',
    'APL'   => 'Apollo',
    'ASK'   => 'Permission',
    'BCN'   => 'Byte Coin',
    'BEAM'  => 'Beam',
    'BITSZ' => 'Bitsz',
    'BNB'   => 'BNB Coin',
    'DOGE'  => 'Doge Coin',
    'ETH'   => 'Etherium',
    'SOL'   => 'Solano',
    'SYS'   => 'Sys Coin',
    'TRX'   => 'Tron',
    'USDT'  => 'Tether USD',
    'LTCT'  => 'LiteCoin TestNET'
];
/**
 * Get the client's real IP address, considering possible proxy headers.
 *
 * This function checks for forwarded IP headers (like X-Forwarded-For)
 * and filters out private IP ranges.
 *
 * @return string Client IP address.
 */
function encode_ip(): string
{
    $clientIp = $_SERVER['REMOTE_ADDR'] ?? ($_ENV['REMOTE_ADDR'] ?? '');

    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $forwardedIps = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);

        foreach ($forwardedIps as $entry) {
            $entry = trim($entry);

            if (preg_match('/^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/', $entry, $matches)) {
                $ip = $matches[1];

                // Replace private IPs with the original client IP
                $privateRanges = [
                    '/^0\./',
                    '/^127\.0\.0\.1/',
                    '/^192\.168\./',
                    '/^172\.(1[6-9]|2[0-9]|3[0-1])\./',
                    '/^10\./',
                    '/^224\./',
                    '/^240\./'
                ];

                $filteredIp = preg_replace($privateRanges, $clientIp, $ip);

                if ($clientIp !== $filteredIp) {
                    $clientIp = $filteredIp;
                    break;
                }
            }
        }
    }

    return $clientIp;
}

/**
 * Gender list used for selection menus and labeling.
 *
 * @var array<string, string>
 */
$genderArray = [
    'male'   => 'Male',
    'female' => 'Female',
];

/**
 * Fetches data from a given URL using cURL.
 *
 * @param string $url The URL to fetch data from.
 * @return string|false The response content or false on failure.
 */
function dAi_fetchDataFromURL(string $url)
{
    if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
        return false;
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER    => true,
        CURLOPT_FOLLOWLOCATION    => true,
        CURLOPT_SSL_VERIFYHOST    => 2,
        CURLOPT_SSL_VERIFYPEER    => true,
        CURLOPT_USERAGENT         => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        CURLOPT_CONNECTTIMEOUT    => 5,
        CURLOPT_TIMEOUT           => 5,
        CURLOPT_HEADER            => false
    ]);

    $response = curl_exec($ch);

    // Optional: log or handle cURL errors if needed
    // $error = curl_error($ch);

    curl_close($ch);

    return $response;
}
/**
 * Generates a 4-digit numeric verification code.
 *
 * The first digit is guaranteed to be non-zero.
 *
 * @return string 4-digit verification code.
 */
function generateVerificationCode(): string
{
    $firstDigit = random_int(1, 9); // Use cryptographically secure RNG
    $remainingDigits = str_pad((string) random_int(0, 999), 3, '0', STR_PAD_LEFT);

    return $firstDigit . $remainingDigits;
}
/**
 * Format a number with grouped thousands and no decimals.
 *
 * @param float|int|string $number The number to format.
 * @return string Formatted number with thousands separator.
 */
function limitNumberFormat($number): string
{
    $number = is_numeric($number) ? (float) $number : 0;
    return number_format($number, 0, ',', '.');
}
?>