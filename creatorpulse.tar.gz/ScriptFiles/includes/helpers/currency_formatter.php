<?php
declare(strict_types=1);

/**
 * Normalize currency formatting settings from site configuration.
 *
 * @param array $siteData Configuration array (i_site_configurations).
 *
 * @return array{position:string,decimal_places:int,thousands_sep:string,decimal_sep:string}
 */
function dz_currency_normalize_settings(array $siteData): array
{
    $position = isset($siteData['currency_symbol_position'])
        ? strtolower((string) $siteData['currency_symbol_position'])
        : 'left';
    if (!in_array($position, ['left', 'right', 'left_space', 'right_space'], true)) {
        $position = 'left';
    }

    $decimalPlaces = isset($siteData['currency_decimal_places']) && is_numeric($siteData['currency_decimal_places'])
        ? (int) $siteData['currency_decimal_places']
        : 2;
    if ($decimalPlaces < 0) {
        $decimalPlaces = 0;
    } elseif ($decimalPlaces > 8) {
        $decimalPlaces = 8;
    }

    $thousandsSep = isset($siteData['currency_thousands_sep'])
        ? (string) $siteData['currency_thousands_sep']
        : ',';
    $decimalSep = isset($siteData['currency_decimal_sep'])
        ? (string) $siteData['currency_decimal_sep']
        : '.';

    $allowedThousands = [',', '.', ' ', ''];
    if (!in_array($thousandsSep, $allowedThousands, true)) {
        $thousandsSep = ',';
    }
    if (!in_array($decimalSep, ['.', ','], true)) {
        $decimalSep = '.';
    }
    if ($thousandsSep === $decimalSep) {
        $thousandsSep = '';
    }

    return [
        'position'        => $position,
        'decimal_places'  => $decimalPlaces,
        'thousands_sep'   => $thousandsSep,
        'decimal_sep'     => $decimalSep,
    ];
}

/**
 * Resolve precision for a currency code, honoring crypto minimum.
 */
function dz_currency_resolve_precision(string $currencyCode, int $decimalPlaces): int
{
    $currencyCode = strtoupper(trim($currencyCode));
    $precision = max(0, min(8, $decimalPlaces));
    $cryptoCurrencies = [
        'BTC', 'ETH', 'BCH', 'LTC', 'DOGE', 'XMR', 'SOL', 'ADA', 'MATIC', 'XRP',
        'USDT', 'USDC', 'DAI', 'BNB', 'TRX',
    ];

    if ($currencyCode !== '' && in_array($currencyCode, $cryptoCurrencies, true)) {
        return max($precision, 8);
    }

    return $precision;
}

/**
 * Format a numeric amount with currency symbol and positioning.
 *
 * @param float       $amount         Amount to format.
 * @param string|null $currencyCode   ISO currency code; defaults to global payments currency.
 * @param string|null $currencySymbol Symbol to use; falls back to $currencies map.
 * @param array|null  $settings       Normalized settings from dz_currency_normalize_settings().
 */
function dz_format_currency(float $amount, ?string $currencyCode = null, ?string $currencySymbol = null, ?array $settings = null): string
{
    $code = strtoupper(trim((string) ($currencyCode ?? '')));
    if ($code === '') {
        $code = isset($GLOBALS['currency']) ? strtoupper((string) $GLOBALS['currency']) : 'USD';
    }

    $settings = $settings ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
    $decimalPlaces = isset($settings['decimal_places']) ? (int) $settings['decimal_places'] : 2;
    $precision = dz_currency_resolve_precision($code, $decimalPlaces);

    $decimalSep = (string) ($settings['decimal_sep'] ?? '.');
    $thousandsSep = (string) ($settings['thousands_sep'] ?? ',');
    if ($decimalSep === '' || ($decimalSep !== '.' && $decimalSep !== ',')) {
        $decimalSep = '.';
    }
    if ($thousandsSep === $decimalSep) {
        $thousandsSep = '';
    }

    $symbol = trim((string) ($currencySymbol ?? ''));
    if ($symbol === '') {
        $map = [];
        if (isset($GLOBALS['currencies']) && is_array($GLOBALS['currencies'])) {
            $map = $GLOBALS['currencies'];
        } elseif (isset($GLOBALS['currencys']) && is_array($GLOBALS['currencys'])) {
            $map = $GLOBALS['currencys'];
        }
        $candidate = $map[$code] ?? '';
        if (is_string($candidate)) {
            $symbol = trim($candidate);
        }
    }

    $formatted = number_format((float) $amount, $precision, $decimalSep, $thousandsSep);
    $position = (string) ($settings['position'] ?? 'left');

    if ($symbol === '' || $symbol === $code || mb_strlen($symbol) > 4) {
        return $formatted . ' ' . $code;
    }

    switch ($position) {
        case 'left':
            return $symbol . $formatted;
        case 'left_space':
            return $symbol . ' ' . $formatted;
        case 'right':
            return $formatted . $symbol;
        case 'right_space':
            return $formatted . ' ' . $symbol;
        default:
            return $symbol . $formatted;
    }
}

/**
 * Format a numeric amount without appending the currency symbol.
 */
function dz_format_number(float $amount, ?string $currencyCode = null, ?array $settings = null): string
{
    $code = strtoupper(trim((string) ($currencyCode ?? '')));
    if ($code === '') {
        $code = isset($GLOBALS['currency']) ? strtoupper((string) $GLOBALS['currency']) : 'USD';
    }
    $settings = $settings ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
    $decimalPlaces = isset($settings['decimal_places']) ? (int) $settings['decimal_places'] : 2;
    $precision = dz_currency_resolve_precision($code, $decimalPlaces);

    $decimalSep = (string) ($settings['decimal_sep'] ?? '.');
    $thousandsSep = (string) ($settings['thousands_sep'] ?? ',');
    if ($decimalSep === '' || ($decimalSep !== '.' && $decimalSep !== ',')) {
        $decimalSep = '.';
    }
    if ($thousandsSep === $decimalSep) {
        $thousandsSep = '';
    }

    return number_format((float) $amount, $precision, $decimalSep, $thousandsSep);
}

/**
 * Prepare currency settings for front-end consumption.
 *
 * @param array $settings Normalized settings.
 * @param string $currencyCode Default currency code.
 * @param string|null $currencySymbol Default symbol.
 *
 * @return array<string, string|int>
 */
function dz_currency_settings_for_js(array $settings, string $currencyCode, ?string $currencySymbol = null): array
{
    return [
        'position'      => (string) ($settings['position'] ?? 'left'),
        'decimalPlaces' => (int) ($settings['decimal_places'] ?? 2),
        'decimalSep'    => (string) ($settings['decimal_sep'] ?? '.'),
        'thousandsSep'  => (string) ($settings['thousands_sep'] ?? ','),
        'code'          => strtoupper(trim($currencyCode)) ?: 'USD',
        'symbol'        => (string) ($currencySymbol ?? ''),
    ];
}
