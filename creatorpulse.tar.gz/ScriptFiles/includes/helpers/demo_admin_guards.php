<?php
declare(strict_types=1);

if (!function_exists('demo_guard_current_role')) {
    function demo_guard_current_role(): ?string
    {
        static $evaluated = false;
        static $role = null;

        if ($evaluated) {
            return $role;
        }

        $evaluated = true;
        $userId = (int)($GLOBALS['userData']['user_id'] ?? 0);

        if ($userId === 5) {
            $role = 'demo_admin';
        } elseif ($userId === 7) {
            $role = 'demo_creator';
        } else {
            $role = null;
        }

        return $role;
    }
}

if (!function_exists('is_demo_admin_sandbox')) {
    function is_demo_admin_sandbox(): bool
    {
        return demo_guard_current_role() !== null;
    }
}

if (!function_exists('demo_guard_default_message')) {
    function demo_guard_default_message(): string
    {
        $role = demo_guard_current_role();
        if ($role === 'demo_creator') {
            return 'Demo content creator cannot perform this action.';
        }
        if ($role === 'demo_admin') {
            return 'This action is disabled for demo administrators.';
        }
        return 'This action is disabled for demo accounts.';
    }
}

if (!function_exists('demo_guard_title')) {
    function demo_guard_title(): string
    {
        $role = demo_guard_current_role();
        if ($role === 'demo_creator') {
            return 'Demo Creator';
        }
        if ($role === 'demo_admin') {
            return 'Demo Admin';
        }
        return 'Demo Account';
    }
}

if (!function_exists('demo_admin_block_payload')) {
    function demo_admin_block_payload(string $scope = 'GENERAL'): array
    {
        return [
            'status'  => 'error',
            'code'    => 'DEMO_ADMIN_BLOCKED_' . strtoupper($scope),
            'message' => demo_guard_default_message(),
        ];
    }
}

if (!function_exists('demo_admin_guard_starts_with')) {
    function demo_admin_guard_starts_with(string $haystack, string $needle): bool
    {
        if ($needle === '') {
            return true;
        }

        return strpos($haystack, $needle) === 0;
    }
}

if (!function_exists('demo_admin_guard_ends_with')) {
    function demo_admin_guard_ends_with(string $haystack, string $needle): bool
    {
        $length = strlen($needle);
        if ($length === 0) {
            return true;
        }

        return substr($haystack, -$length) === $needle;
    }
}

if (!function_exists('demo_admin_guard_collect_action_hints')) {
    function demo_admin_guard_collect_action_hints(): array
    {
        $keys = [
            'p', 'action', 'task', 'do', 'mode', 'operation', 'op', 'cmd',
            'command', 'route', 'step', 'type', 'subaction', 'method', 'f',
        ];

        $hints = [];
        foreach ($keys as $key) {
            $value = $_POST[$key] ?? ($_GET[$key] ?? null);
            if ($value === null) {
                continue;
            }

            if (is_scalar($value)) {
                $normalized = strtolower(trim((string) $value));
                if ($normalized !== '') {
                    $hints[] = $normalized;
                }
            }
        }

        return array_values(array_unique($hints));
    }
}

if (!function_exists('demo_admin_guard_hint_has_mutation_signature')) {
    function demo_admin_guard_hint_has_mutation_signature(string $hint): bool
    {
        $blockedFragments = [
            'save',
            'update',
            'delete',
            'remove',
            'cancel',
            'toggle',
            'upload',
            'create',
            'follow',
            'unfollow',
            'like',
            'unlike',
            'comment',
            'subscribe',
            'withdraw',
            'payment',
            'pay',
            'charge',
            'tip',
            'send',
            'add',
            'block',
            'unblock',
            'approve',
            'reject',
            'ban',
            'unban',
            'process',
            'change',
            'setdefault',
            'set_default',
            'set',
            'store',
            'submit',
            'execute',
            'upgrade',
            'downgrade',
            'restore',
            'destroy',
            'enable',
            'disable',
            'activate',
            'deactivate',
            'generate',
            'revoke',
            'refund',
            'topup_create',
            'purchase_create',
            'checkout',
            'finalize',
            'start',
            'stop',
            'publish',
            'unpublish',
            'report_post',
            'report_comment',
        ];

        foreach ($blockedFragments as $fragment) {
            if ($fragment === '') {
                continue;
            }

            if (strpos($hint, $fragment) !== false) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('demo_admin_guard_hint_has_safe_signature')) {
    function demo_admin_guard_hint_has_safe_signature(string $hint): bool
    {
        $allowedPrefixes = [
            'get',
            'load',
            'fetch',
            'list',
            'render',
            'view',
            'preview',
            'lookup',
            'search',
            'filter',
            'calc',
            'calculate',
            'check',
            'validate',
            'show',
            'display',
        ];

        foreach ($allowedPrefixes as $prefix) {
            if ($prefix !== '' && demo_admin_guard_starts_with($hint, $prefix)) {
                return true;
            }
        }

        $allowedSuffixes = [
            '_modal',
            '_list',
            '_data',
            '_info',
            '_details',
            '_stats',
            '_status',
            '_peek',
            '_history',
            '_form',
            '_html',
            '_get',
            '_summary',
            '_options',
            '_lookup',
            '_preview',
            '_chart',
            '_graph',
            '_balance',
        ];

        foreach ($allowedSuffixes as $suffix) {
            if ($suffix !== '' && demo_admin_guard_ends_with($hint, $suffix)) {
                return true;
            }
        }

        $allowedContains = [
            'more',
            'modal',
            'list',
            'peek',
            'stats',
            'status',
            'history',
            'summary',
            'info',
            'detail',
            'preview',
            'lookup',
            'search',
            'check',
            'fetch',
            'load',
            'balance',
        ];

        foreach ($allowedContains as $fragment) {
            if ($fragment !== '' && strpos($hint, $fragment) !== false) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('demo_admin_guard_should_inject_client_runtime')) {
    function demo_admin_guard_should_inject_client_runtime(): bool
    {
        if (!is_demo_admin_sandbox()) {
            return false;
        }

        if (PHP_SAPI === 'cli') {
            return false;
        }

        $accept = (string)($_SERVER['HTTP_ACCEPT'] ?? '');
        if ($accept !== '' && stripos($accept, 'text/html') === false) {
            return false;
        }

        $script = (string)($_SERVER['SCRIPT_FILENAME'] ?? '');
        if ($script !== '' && strpos(str_replace('\\', '/', $script), '/request/') !== false) {
            return false;
        }

        return true;
    }
}

if (!function_exists('demo_admin_guard_runtime_asset_url')) {
    function demo_admin_guard_runtime_asset_url(): ?string
    {
        $relativeAsset = '/themes/default/js/demo_admin_guard_runtime.js?v=2';
        $baseUrl = $GLOBALS['base_url'] ?? null;
        if (is_string($baseUrl) && $baseUrl !== '') {
            return rtrim($baseUrl, '/') . $relativeAsset;
        }

        $docRoot = rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT'] ?? ''), '/');
        $projectRoot = str_replace('\\', '/', dirname(__DIR__, 2));
        $assetFsPath = $projectRoot . '/themes/default/js/demo_admin_guard_runtime.js';

        if ($docRoot !== '' && strpos($projectRoot, $docRoot) === 0) {
            $relativeRoot = substr($projectRoot, strlen($docRoot));
            $relativeRoot = $relativeRoot === '' ? '' : rtrim($relativeRoot, '/');
            $assetPath = $relativeRoot . '/themes/default/js/demo_admin_guard_runtime.js?v=2';
            if ($assetPath === '') {
                $assetPath = '/themes/default/js/demo_admin_guard_runtime.js?v=2';
            }
            if ($assetPath[0] !== '/') {
                $assetPath = '/' . $assetPath;
            }
            return $assetPath;
        }

        $scriptName = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
        if ($scriptName !== '') {
            $dir = rtrim(dirname($scriptName), '/');
            return ($dir === '' ? '' : $dir) . $relativeAsset;
        }

        return $relativeAsset;
    }
}

if (!function_exists('demo_admin_guard_schedule_client_runtime')) {
    function demo_admin_guard_schedule_client_runtime(): void
    {
        static $scheduled = false;
        if ($scheduled) {
            return;
        }

        if (!demo_admin_guard_should_inject_client_runtime()) {
            return;
        }

        $scheduled = true;

        register_shutdown_function(static function (): void {
            if (!demo_admin_guard_should_inject_client_runtime()) {
                return;
            }

            $assetUrl = demo_admin_guard_runtime_asset_url();
            if (!is_string($assetUrl) || $assetUrl === '') {
                return;
            }

            $escapedUrl = htmlspecialchars($assetUrl, ENT_QUOTES, 'UTF-8');
            echo '<script src="' . $escapedUrl . '" data-demo-admin-guard="1"></script>';
        });
    }
}

if (!function_exists('demo_admin_guard_should_allow_request')) {
    function demo_admin_guard_should_allow_request(string $method): bool
    {
        if ($method !== 'POST') {
            return false;
        }

        $script = (string)($_SERVER['SCRIPT_FILENAME'] ?? '');
        $normalizedScript = str_replace('\\', '/', $script);

        $explicitWhitelist = [
            'search',
            'create_new',
            'new_messages',
            'new_notifications',
            'menu',
            'wallet_topup_modal',
            'wallet_balance_get',
            'sendtipuser',
            'sendtip',
            'purchasepost',
            'getchatlist',
            'get_live_chat',
            'get_chat',
            'live_stats',
            'live_ping',
            'live_chat_fetch',
            'live_tips',
            'fetchnewmessages',
            'typingstatus',
            'typingping',
            'fetchmessagestatuses',
            'markreadconversation',
            'add_view',
            'explore_more',
            'feed_more',
            'premium_more',
            'profile_more',
            'getfullpost',
            'getmoreimage',
            'getmorebookmarks',
            'toggle_bookmark',
            'moreuser',
            'header_peek',
            'popup',
            'guest_update_language',
            'subscription_fees_calculate',
            'ads_feed_sidebar',
            'ads_feed_instream',
            'ads_dashboard_data',
            'ads_payment_webhook',
            'ads_track_impression',
            'ads_track_click',
            'report_reasons',
            // Allow demo admin to create posts (image/video/podcast)
            'uploadimage',
            'upload_temp_video',
            'finalize_reel',
            'upload_temp_podcast',
            'finalize_podcast',
            // Allow demo admin to create/display ads and complete payments
            'ads_upload_images',
            'ads_finalize_image',
            'ads_upload_temp_video',
            'ads_finalize_video',
            'ads_create_payment',
            // Allow podcast ad creation flow
            'podcast_ad_list_podcasts',
            'podcast_ad_packages',
            'podcast_ad_start_payment',
            'podcast_ad_submit',
            // Allow liking posts
            'like_post',
        ];

        $fileUploadWhitelist = [
            'uploadimage',
            'upload_temp_video',
            'upload_temp_podcast',
            'ads_upload_images',
            'ads_upload_temp_video',
        ];

        $actionHints = demo_admin_guard_collect_action_hints();
        if ($actionHints !== []) {
            foreach ($actionHints as $hint) {
                if (in_array($hint, $explicitWhitelist, true)) {
                    return true;
                }
            }

            if (!empty($_FILES)) {
                foreach ($actionHints as $hint) {
                    if (in_array($hint, $fileUploadWhitelist, true)) {
                        return true;
                    }
                }
                return false;
            }

            foreach ($actionHints as $hint) {
                if (demo_admin_guard_hint_has_mutation_signature($hint)) {
                    return false;
                }
            }

            foreach ($actionHints as $hint) {
                if (demo_admin_guard_hint_has_safe_signature($hint)) {
                    return true;
                }
            }
        } elseif (!empty($_FILES)) {
            return false;
        }

        $safeScriptFragments = [
            '/request/search-users.php',
        ];

        foreach ($safeScriptFragments as $fragment) {
            if ($fragment !== '' && strpos($normalizedScript, $fragment) !== false) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('demo_admin_guard_bootstrap')) {
    function demo_admin_guard_bootstrap(): void
    {
        if (!is_demo_admin_sandbox()) {
            return;
        }

        unset($GLOBALS['__demo_admin_guard_last_blocked']);

        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        if (!in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
            return;
        }

        if (demo_admin_guard_should_allow_request($method)) {
            return;
        }

        $script     = (string)($_SERVER['SCRIPT_FILENAME'] ?? '');
        $isAdminCtx = strpos($script, DIRECTORY_SEPARATOR . 'admin' . DIRECTORY_SEPARATOR) !== false;
        $isJsonHint = stripos((string)($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json') !== false
            || strcasecmp((string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''), 'XMLHttpRequest') === 0
            || strpos($script, DIRECTORY_SEPARATOR . 'request' . DIRECTORY_SEPARATOR) !== false;

        $GLOBALS['__demo_admin_guard_last_blocked'] = [
            'blocked'      => true,
            'scope'        => $isAdminCtx ? 'ADMIN' : 'FRONT',
            'should_flash' => !$isJsonHint,
        ];

        $payload = demo_admin_block_payload($isAdminCtx ? 'ADMIN' : 'FRONT');

        if (!headers_sent()) {
            header('X-Demo-Admin-Guard: blocked');
            $encodedMessage = rawurlencode((string)($payload['message'] ?? demo_guard_default_message()));
            header('X-Demo-Admin-Message: ' . $encodedMessage);
            header(
                $isJsonHint
                    ? 'Content-Type: application/json; charset=utf-8'
                    : 'Content-Type: text/html; charset=utf-8'
            );
        }
        http_response_code(200);

        if ($isJsonHint) {
            echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        } else {
            $escapedMessage = htmlspecialchars((string)($payload['message'] ?? ''), ENT_QUOTES, 'UTF-8');
            echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Access Restricted</title></head><body>'
                . '<div data-demo-admin-guard-message="' . $escapedMessage . '"></div>'
                . '<noscript><p>' . htmlspecialchars(demo_guard_default_message(), ENT_QUOTES, 'UTF-8') . '</p></noscript>'
                . '</body></html>';
        }
        exit;
    }
}

if (!function_exists('demo_admin_guard_render_flash')) {
    function demo_admin_guard_render_flash(): void
    {
        $message = $_SESSION['demo_admin_flash'] ?? '';
        if ($message === '') {
            return;
        }

        unset($_SESSION['demo_admin_flash']);

        $escapedMessage = htmlspecialchars((string) $message, ENT_QUOTES, 'UTF-8');
        echo '<div data-demo-admin-guard-message="' . $escapedMessage . '"></div>';
    }
}

demo_admin_guard_schedule_client_runtime();

register_shutdown_function(function (): void {
    if (!is_demo_admin_sandbox()) {
        return;
    }

    $state = $GLOBALS['__demo_admin_guard_last_blocked'] ?? null;
    if (!is_array($state) || empty($state['blocked']) || empty($state['should_flash'])) {
        return;
    }

    $_SESSION['demo_admin_flash'] = demo_guard_default_message();
    demo_admin_guard_render_flash();
    unset($GLOBALS['__demo_admin_guard_last_blocked']);
    if (isset($_SESSION['demo_admin_flash'])) {
        unset($_SESSION['demo_admin_flash']);
    }
});

demo_admin_guard_bootstrap();
