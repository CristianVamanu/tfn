<?php

/**
 * Generates a thumbnail image from a video file using FFmpeg.
 * The thumbnail is saved as a PNG in the same directory as the video.
 *
 * @param string $ffmpegPath  Full path to the ffmpeg binary.
 * @param string $videoPath   Full path to the input video file.
 * @return string|null        Returns the thumbnail path on success, or null on failure.
 */
function createVideoThumbnailInSameDir(string $ffmpegPath, string $videoPath): ?string
{
    if (!file_exists($videoPath)) {
        return null;
    }

    $directory = dirname($videoPath);
    $filenameWithoutExt = pathinfo($videoPath, PATHINFO_FILENAME);
    $thumbnailPath = $directory . '/' . $filenameWithoutExt . '.png';

    $ffmpeg = escapeshellarg($ffmpegPath);
    $attempts = ['00:00:01.000', '00:00:00.250', '00:00:00.000'];
    $maxThumbWidth = 640; // cap width so thumbnails stay lightweight
    // Quote the `if()` expression so ffmpeg doesn't treat commas as filter separators
    $scaleExpr = sprintf("if(gt(iw,%1\$d),%1\$d,iw)", $maxThumbWidth);
    $scaleFilter = "scale='" . $scaleExpr . "':-2";

    foreach ($attempts as $timestamp) {
        @unlink($thumbnailPath);
        $commands = [
            $ffmpeg . ' -y -ss ' . escapeshellarg($timestamp)
                . ' -i ' . escapeshellarg($videoPath)
                . ' -frames:v 1 -vf ' . escapeshellarg($scaleFilter)
                . ' -compression_level 100 -pred mixed '
                . escapeshellarg($thumbnailPath) . ' 2>&1',
            $ffmpeg . ' -y -ss ' . escapeshellarg($timestamp)
                . ' -i ' . escapeshellarg($videoPath)
                . ' -frames:v 1 -vf ' . escapeshellarg($scaleFilter)
                . ' ' . escapeshellarg($thumbnailPath) . ' 2>&1',
        ];

        foreach ($commands as $cmd) {
            shell_exec($cmd);
            if (file_exists($thumbnailPath) && filesize($thumbnailPath) > 1000) {
                return $thumbnailPath;
            }
            @unlink($thumbnailPath);
        }
    }

    return null;
}

?>
