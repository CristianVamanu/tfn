<?php
/**
 * Utility: Format large numbers into a short human-readable form.
 *
 * Examples:
 *   950        => "950"
 *   1200       => "1.2K"
 *   24500      => "24.5K"
 *   1542000    => "1.5M"
 *   983000000  => "983M"
 *   1520000000 => "1.5B"
 *
 * @param int|float $num The number to format.
 * @param int       $precision How many decimal places to show (default = 1).
 * @return string   Short formatted string.
 */
/**
 * @param int|float $num
 */
function number_format_short($num, int $precision = 1): string
{
    if (!is_numeric($num)) {
        $num = 0;
    }
    $num = (float) $num;

    if ($num < 1000) {
        return (string) $num;
    }

    // Define suffixes
    $suffixes = [
        12 => 'T', // trillion
        9  => 'B', // billion
        6  => 'M', // million
        3  => 'K', // thousand
    ];

    foreach ($suffixes as $power => $suffix) {
        if ($num >= pow(10, $power)) {
            $short = $num / pow(10, $power);
            // Round with given precision
            $formatted = number_format($short, $precision);
            // Remove unnecessary .0 (e.g., 1.0K -> 1K)
            $formatted = preg_replace('/\.0+$/', '', $formatted);
            return $formatted . $suffix;
        }
    }

    return (string) $num; // fallback
}
