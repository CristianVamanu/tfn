<?php
declare(strict_types=1);

/**
 * Relative time formatter (past & future)
 * - PSR-12 compliant
 * - Works with UNIX timestamps (int). Strings are parsed safely.
 * - Optional Intl support; falls back to simple English strings.
 */
final class RelativeTime
{
    private const SEC_PER_MIN = 60;
    private const SEC_PER_HOUR = 3600;
    private const SEC_PER_DAY = 86400;
    private const SEC_PER_WEEK = 604800;
    // Average month/year (same approach you used, but const + clear names)
    private const SEC_PER_MONTH = 2629800;   // ~30.44 days
    private const SEC_PER_YEAR  = 31557600;  // ~365.25 days

    /**
     * Format a timestamp relatively to "now".
     *
     * @param int|string $time    UNIX timestamp or parseable string
     * @param int|null   $now     UNIX timestamp for "now" (testing)
     * @param string     $locale  e.g., 'en', 'tr'
     * @param bool       $useIntl Use IntlDateFormatter when available
     */
    public static function format($time, ?int $now = null, string $locale = 'en', bool $useIntl = false): string
    {
        $ts = is_int($time) ? $time : strtotime((string) $time);
        if ($ts === false) {
            return 'unknown';
        }

        $now ??= time();
        $diff = $ts - $now;   // future > 0, past < 0
        $past = $diff < 0;
        $abs  = abs($diff);

        // Optional Intl path (natural language per locale)
        if ($useIntl && class_exists(\IntlDateFormatter::class)) {
            // Extremely short for recents
            if ($abs < self::SEC_PER_MIN) {
                if ($past) {
                    return self::txt('now', $locale);
                }
                $s = (int) floor($abs);
                return self::unit($s, 'second', $past, $locale);
            }

            // Fallback to manual relative units if IntlRelativeTimeFormatter is unavailable
        }

        // Plain English/TR-like fallback
        if ($abs < self::SEC_PER_MIN) {
            return $past ? self::txt('now', $locale) : self::txt('now', $locale);
        }
        if ($abs < self::SEC_PER_HOUR) {
            $m = (int) floor($abs / self::SEC_PER_MIN);
            return self::unit($m, 'minute', $past, $locale);
        }
        if ($abs < self::SEC_PER_DAY) {
            $h = (int) floor($abs / self::SEC_PER_HOUR);
            return self::unit($h, 'hour', $past, $locale);
        }
        if ($abs < self::SEC_PER_WEEK) {
            $d = (int) floor($abs / self::SEC_PER_DAY);
            // Special-cases for 1 day
            if ($d === 1) {
                return $past ? self::txt('yesterday', $locale) : self::txt('tomorrow', $locale);
            }
            return self::unit($d, 'day', $past, $locale);
        }
        if ($abs < self::SEC_PER_MONTH) {
            $w = (int) floor($abs / self::SEC_PER_WEEK);
            return self::unit($w, 'week', $past, $locale);
        }
        if ($abs < self::SEC_PER_YEAR) {
            $mo = (int) floor($abs / self::SEC_PER_MONTH);
            return self::unit($mo, 'month', $past, $locale);
        }

        $y = (int) floor($abs / self::SEC_PER_YEAR);
        return self::unit($y, 'year', $past, $locale);
    }

    /**
     * Map keys to language strings (minimal i18n).
     * Hook here into your customLang() if you prefer.
     *
     * @return string|array
     */
    private static function txt(string $key, string $locale, int $n = 0)
    {
        $en = [
            'now'       => 'just now',
            'yesterday' => 'yesterday',
            'tomorrow'  => 'tomorrow',
            'past'      => '%d %s ago',
            'future'    => 'in %d %s',
            'second'    => ['second', 'seconds'],
            'minute'    => ['minute', 'minutes'],
            'hour'      => ['hour', 'hours'],
            'day'       => ['day', 'days'],
            'week'      => ['week', 'weeks'],
            'month'     => ['month', 'months'],
            'year'      => ['year', 'years'],
        ];

        $tr = [
            'now'       => 'az önce',
            'yesterday' => 'dün',
            'tomorrow'  => 'yarın',
            'past'      => '%d %s önce',
            'future'    => '%d %s içinde',
            'second'    => ['saniye', 'saniye'],
            'minute'    => ['dakika', 'dakika'],
            'hour'      => ['saat', 'saat'],
            'day'       => ['gün', 'gün'],
            'week'      => ['hafta', 'hafta'],
            'month'     => ['ay', 'ay'],
            'year'      => ['yıl', 'yıl'],
        ];

        $dict = ($locale === 'tr') ? $tr : $en;

        return $dict[$key] ?? $key;
    }

    /**
     * Builds a singular/plural unit phrase for past/future.
     */
    private static function unit(int $n, string $unit, bool $past, string $locale): string
    {
        $label = self::txt($unit, $locale);
        // $label may be array [singular, plural] in English; in TR both same.
        if (is_array($label)) {
            $word = ($n === 1) ? $label[0] : $label[1];
        } else {
            $word = $label;
        }

        $mask = self::txt($past ? 'past' : 'future', $locale);
        return sprintf($mask, $n, $word);
    }
}

if (!function_exists('dz_relative_time_locale')) {
    /**
     * Resolve the current locale slug used for relative time rendering.
     */
    function dz_relative_time_locale(): string
    {
        static $resolved = null;

        if ($resolved !== null) {
            return $resolved;
        }

        $candidate = null;

        if (isset($GLOBALS['currentLang']) && is_string($GLOBALS['currentLang']) && $GLOBALS['currentLang'] !== '') {
            $candidate = strtolower((string) $GLOBALS['currentLang']);
        } elseif (isset($GLOBALS['currentLocale']) && is_string($GLOBALS['currentLocale']) && $GLOBALS['currentLocale'] !== '') {
            $candidate = strtolower((string) $GLOBALS['currentLocale']);
        }

        if ($candidate === null || $candidate === '') {
            $candidate = 'eng';
        }

        $resolved = $candidate;

        return $resolved;
    }
}

if (!function_exists('dz_relative_time_label')) {
    /**
     * Helper wrapper around RelativeTime::format that uses the active locale.
     */
    function dz_relative_time_label(int $timestamp, ?int $now = null): string
    {
        return RelativeTime::format($timestamp, $now, dz_relative_time_locale());
    }
}
