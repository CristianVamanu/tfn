<?php
/**
 * Validates an email address using format, length, character, TLD, and optional DNS checks.
 *
 * @param string  $email     The email address to validate.
 * @param bool    $checkDNS  Whether to perform DNS check on the domain.
 * @return bool              True if valid, false otherwise.
 */
function validateEmail($email, $checkDNS = false)
{
    // Valid TLD list (gTLDs and ccTLDs)
    $validTLDs = [
        // General TLDs (gTLD)
        'com', 'org', 'net', 'edu', 'gov', 'mil', 'int', 'info', 'biz', 'name', 'pro', 'xyz', 'online', 'site', 'club', 'tech', 'blog', 'app', 'io', 'guru', 'shop', 'co', 'art', 'design', 'solutions', 'me', 'news',
        // Country Code TLDs (ccTLD)
        'tr', 'us', 'uk', 'de', 'fr', 'jp', 'cn', 'ru', 'in', 'br', 'ca', 'au', 'es', 'it', 'mx', 'nl', 'se', 'no', 'fi', 'dk', 'pl', 'be', 'ch', 'at', 'gr', 'pt', 'ie', 'cz', 'hu', 'sk', 'si', 'bg', 'ro', 'lt', 'lv', 'ee', 'hr', 'rs', 'ba', 'mk', 'al', 'by', 'ua', 'ge', 'az', 'kg', 'kz', 'am', 'uz', 'mn', 'af', 'ir', 'ae', 'sa', 'qa', 'kw', 'om', 'bh', 'jo', 'lb', 'sy', 'eg', 'ma', 'tn', 'dz', 'ng', 'za', 'ke', 'gh', 'zw', 'tz', 'ug', 'rw', 'ls', 'mw', 'zm', 'mz', 'bw', 'sz', 'ao', 'na', 'cd', 'ci', 'sn', 'ml', 'gm', 'sl', 'lr', 'cm', 'ne', 'tg', 'bf', 'mr', 'dz', 'ly', 'sd', 'tn', 'so', 'et', 'dj', 'km', 'sc', 'mu', 'mg', 'cv', 'st', 'gw', 'gq', 'ga', 'cg', 'td', 'cf', 'bi', 'rw', 'mz', 'bw', 'sz',
        // New General TLDs
        'academy', 'agency', 'bargains', 'boutique', 'builders', 'business', 'camera', 'camp', 'capital', 'cards', 'care', 'cash', 'chat', 'cheap', 'church', 'city', 'clothing', 'community', 'company', 'computer', 'consulting', 'contractors', 'directory', 'domains', 'education', 'email', 'energy', 'engineering', 'enterprises', 'equipment', 'estate', 'events', 'experts', 'express', 'farm', 'finance', 'financial', 'fitness', 'flights', 'florist', 'foundation', 'fund', 'furniture', 'gallery', 'graphics', 'health', 'holiday', 'house', 'industries', 'institute', 'insurance', 'international', 'investments', 'kitchen', 'land', 'lighting', 'limited', 'ltd', 'loans', 'media', 'partners', 'photography', 'pictures', 'plumbing', 'productions', 'properties', 'recipes', 'rentals', 'repair', 'report', 'reviews', 'services', 'shoes', 'software', 'solar', 'solutions', 'supplies', 'support', 'systems', 'technology', 'tools', 'training', 'ventures', 'video', 'watch', 'webcam', 'works', 'world', 'zone'
    ];

    // Check if the email is empty
    if (empty($email)) {
        return false; // Email is required
    }

    // Check if the email length exceeds the maximum (254 characters)
    if (strlen($email) > 254) {
        return false; // Email is too long
    }

    // Validate the email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return false; // Invalid format
    }

    // Split the email into the local part and the domain part
    list($localPart, $domain) = explode('@', $email);

    // Check if the local part (before @) is too long (64 characters)
    if (strlen($localPart) > 64) {
        return false; // Local part is too long
    }

    // Check if there are consecutive dots in the local part
    if (strpos($localPart, '..') !== false) {
        return false; // Consecutive dots are not allowed
    }

    // Validate characters in the local part
    if (!preg_match('/^[A-Za-z0-9.!#$%&\'*+\/=?^_`{|}~-]+$/', $localPart)) {
        return false; // Invalid characters in the local part
    }

    // Validate the domain part
    if (!preg_match('/^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$/', $domain)) {
        return false; // Invalid domain
    }

    // Check if the domain is an IP address, which is not allowed
    if (filter_var($domain, FILTER_VALIDATE_IP)) {
        return false; // Domain cannot be an IP address
    }

    // Extract the TLD (after the last dot)
    $tld = substr(strrchr($domain, '.'), 1);
    if (!in_array($tld, $validTLDs)) {
        return false; // Invalid TLD
    }

    // Optionally, check the DNS MX or A records for the domain
    if ($checkDNS) {
        if (!checkdnsrr($domain, 'MX') && !checkdnsrr($domain, 'A')) {
            return false; // Domain does not have a valid email server
        }
    }

    // If all checks pass, return true
    return true;
}

/**
 * Validates a username based on character count, allowed characters, and spacing rules.
 *
 * @param string $username                             Username to validate.
 * @param int    $minChar                              Minimum character count allowed.
 * @param string $minCharMessage                       Error message for minimum character limit.
 * @param int    $maxChar                              Maximum character count allowed.
 * @param string $maxCharMessage                       Error message for maximum character limit.
 * @param string $charLimitMessage                     Error message for length limit violations.
 * @param string $lettersNumbersOnlyMessage            Error message for invalid characters.
 * @param string $noSpacesMessage                      Error message for space usage.
 * @param string $invalidCharMessage                   Error message for HTML or symbolic characters.
 * @return true|string                                 True if valid, otherwise error message.
 */
function validateUsername(
    string $username,
    int $minChar,
    string $minCharMessage,
    int $maxChar,
    string $maxCharMessage,
    string $charLimitMessage,
    string $lettersNumbersOnlyMessage,
    string $noSpacesMessage,
    string $invalidCharMessage
)
{
    // Check length constraints
    $usernameLength = mb_strlen($username, 'UTF-8');
    if ($usernameLength < $minChar || $usernameLength > $maxChar) {
        return replacePlaceholders(
            $charLimitMessage,
            [
                'minimumRegisterUsernameCharacter' => $minCharMessage,
                'maximumRegisterUsernameCharacter' => $maxCharMessage,
            ]
        );
    }

    // Allow only letters, numbers, and underscores
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        return $lettersNumbersOnlyMessage;
    }

    // Disallow spaces
    if (preg_match('/\s/', $username)) {
        return $noSpacesMessage;
    }

    // Disallow common invalid/special characters
    if (preg_match('/[\'";#%&*()=+<>\\\\]/', $username)) {
        return $invalidCharMessage;
    }

    // Ensure no HTML characters
    if (htmlspecialchars($username, ENT_QUOTES | ENT_HTML5, 'UTF-8') !== $username) {
        return $invalidCharMessage;
    }

    // If all checks pass, username is valid
    return true;
}

/**
 * Validates a password based on length, complexity, and allowed character set.
 *
 * @param string $password                    The password to validate.
 * @param int    $minLength                   Minimum length allowed.
 * @param int    $maxLength                   Maximum length allowed.
 * @param string $lengthErrorMessage          Error message for invalid length.
 * @param string $complexityErrorMessage      Error message for missing character types.
 * @param string $allowedCharactersMessage    Error message for disallowed characters.
 * @return true|string                        True if valid, or error message if not.
 */
function validatePassword(
    string $password,
    int $minLength,
    int $maxLength,
    string $lengthErrorMessage,
    string $complexityErrorMessage,
    string $allowedCharactersMessage
)
{
    $passwordLength = mb_strlen($password, 'UTF-8');

    // Check if password length is within limits
    if ($passwordLength < $minLength || $passwordLength > $maxLength) {
        return replacePlaceholders(
            $lengthErrorMessage,
            [
                'minimumRegisterPasswordCharacter' => $minLength,
                'maximumRegisterPasswordCharacter' => $maxLength
            ]
        );
    }

    // Check for at least one uppercase, one lowercase, and one digit
    if (
        !preg_match('/[A-Z]/', $password) ||
        !preg_match('/[a-z]/', $password) ||
        !preg_match('/[0-9]/', $password)
    ) {
        return $complexityErrorMessage;
    }

    // Validate allowed characters
    if (!preg_match('/^[a-zA-Z0-9@#\$%\^&\*\.\_\-\+\!\?\=\~\:\;]+$/', $password)) {
        return $allowedCharactersMessage;
    }

    return true;
}

/**
 * Checks whether a given value is considered empty.
 *
 * This function extends PHP's empty() behavior with additional custom logic.
 *
 * @param mixed $value The value to check.
 *
 * @return bool True if the value is considered empty, false otherwise.
 */
function is_value_empty($value): bool
{
    // Null or false is considered empty
    if (is_null($value) || $value === false) {
        return true;
    }

    // Empty string (after trimming) is considered empty
    if (is_string($value) && trim($value) === '') {
        return true;
    }

    // Empty array
    if (is_array($value) && count($value) === 0) {
        return true;
    }

    // Numeric 0 is NOT considered empty (valid input)
    if (is_numeric($value) && $value == 0) {
        return false;
    }

    // PHP 8.1+ Enum objects are NOT considered empty
    if (PHP_VERSION_ID >= 80100 && is_object($value) && enum_exists(get_class($value))) {
        return false;
    }

    // Objects with __toString method that return empty strings are considered empty
    if (is_object($value) && method_exists($value, '__toString') && trim((string) $value) === '') {
        return true;
    }

    // Fall back to PHP's empty()
    return empty($value);
}
?>
