<?php
const STRING_NEWLINES = ["\r\n", "\n\r", "\r", "\n"];
/**
 * Ensure a string is valid UTF-8, converting from common single-byte encodings when needed.
 *
 * @param string|null $string Source string.
 * @return string UTF-8 safe string (best effort).
 */
function ensureUtf8(?string $string): string
{
    if ($string === null || $string === '') {
        return '';
    }
    if (!function_exists('mb_check_encoding') || !function_exists('mb_convert_encoding')) {
        return $string;
    }
    if (mb_check_encoding($string, 'UTF-8')) {
        return $string;
    }
    $detected = function_exists('mb_detect_encoding')
        ? mb_detect_encoding($string, ['UTF-8', 'ISO-8859-1', 'ISO-8859-15', 'Windows-1250', 'Windows-1252', 'ASCII'], true)
        : 'UTF-8';
    if ($detected === false) {
        return mb_convert_encoding($string, 'UTF-8', 'UTF-8');
    }
    return mb_convert_encoding($string, 'UTF-8', $detected);
}

/**
 * Remove HTML entities from a string.
 *
 * This function strips any HTML entities such as &nbsp;, &amp;, etc.
 *
 * @param string $string The input string to clean.
 * @return string The cleaned string with HTML entities removed.
 */
function cleanString(string $string): string {
    $cleaned = preg_replace("/&#?[a-z0-9]+;/i", "", $string);
    if (!is_string($cleaned)) {
        $cleaned = '';
    }
    return ensureUtf8($cleaned);
}
/**
 * Secure string output by applying sanitization, optional formatting, and validation.
 *
 * @uses cleanString() from global helpers
 *
 * @param string  $string           The input string to secure.
 * @param bool    $br               Convert newlines to <br> tags.
 * @param int     $strip            If set to 1, strips slashes from the string.
 * @param bool    $cleanString      Whether to clean the string using cleanString().
 * @param bool    $validateUrl      If true, validates input as a URL.
 *
 * @return string|false             Returns sanitized string, or false if URL is invalid.
 */
function iN_HelpSecure(
    ?string $string,
    bool $br = true,
    int $strip = 0,
    bool $cleanString = true,
    bool $validateUrl = false
) {
    // Trim whitespace if input is not null
    $string = $string !== null ? trim($string) : '';

    // Validate URL format if requested
    if ($validateUrl) {
        if (!filter_var($string, FILTER_VALIDATE_URL)) {
            return false;
        }
    }

    // Clean string unless it's a URL
    if ($cleanString && !$validateUrl) {
        $string = cleanString($string);
    }

    // Normalize encoding before any escaping/printing
    $string = ensureUtf8($string);

    // Apply HTML escaping unless it's a URL
    if (!$validateUrl) {
        $string = htmlspecialchars($string, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    // Replace line breaks with <br> tags or remove them
    $lineBreaks = STRING_NEWLINES;
    $string = $br ? str_replace($lineBreaks, ' <br>', $string) : str_replace($lineBreaks, '', $string);

    // Optionally strip slashes
    if ($strip === 1) {
        $string = stripslashes($string);
    }

    // Fix double-escaped HTML entities
    $string = str_replace('&amp;#', '&#', $string);

    return $string;
}
/**
 * Sanitize input content as plain text for safe HTML output.
 *
 * This function ensures the content is UTF-8 encoded,
 * HTML-escaped and trimmed properly for safe rendering in browsers.
 *
 * @param string|null $content  The input string to sanitize.
 * @return string               The sanitized output.
 */
function sanitizeAsText(?string $content): string
{
    // Trim whitespace and ensure string is not null
    $content = $content !== null ? trim($content) : '';

    // Convert character encoding to UTF-8
    $content = ensureUtf8($content);

    // Escape special HTML characters to prevent XSS
    $content = htmlspecialchars($content, ENT_QUOTES | ENT_HTML5, 'UTF-8');

    // Final trim for extra safety
    return trim($content);
}

/**
 * Sanitize AI-generated content for HTML output.
 *
 * This function strips unwanted HTML tags while preserving essential ones,
 * normalizes whitespace, handles line breaks, and performs optional cleanup.
 *
 * @param string|null $string           The input string to sanitize.
 * @param bool        $br              Whether to convert newlines to <br> tags.
 * @param int         $strip           Whether to apply stripslashes (1 = yes).
 * @param bool        $cleanString     Whether to apply additional cleaning.
 * @param bool        $validate_url    If true, validate the string as a URL.
 * @return string|false                The cleaned HTML-safe string, or false on invalid URL.
 */
function iN_HelpSecureAi(
    ?string $string,
    bool $br = true,
    int $strip = 0,
    bool $cleanString = true,
    bool $validate_url = false
) {
    $string = $string !== null ? trim($string) : '';

    // If URL validation is requested, return false if not a valid URL
    if ($validate_url && !filter_var($string, FILTER_VALIDATE_URL)) {
        return false;
    }

    // Optionally clean the string with a custom function
    if ($cleanString && !$validate_url) {
        $string = cleanString($string);
    }

    // Only allow specific HTML tags
    $allowedTags = '<h2><h3><p><ul><li><strong><br>';
    $string = strip_tags($string, $allowedTags);

    $string = ensureUtf8($string);

    // Replace multiple whitespaces with a single space
    $string = preg_replace('/\s+/', ' ', $string);

    // Normalize line breaks
    $string = $br
        ? str_replace(STRING_NEWLINES, '<br>', $string)
        : str_replace(STRING_NEWLINES, '', $string);

    // Optionally remove backslashes
    if ($strip === 1) {
        $string = stripslashes($string);
    }

    // Normalize encoded ampersands
    $string = str_replace('&amp;#', '&#', $string);

    // Remove <p> wrapping around headings (e.g., <p><h2>...</h2></p> => <h2>...</h2>)
    $string = preg_replace('/<p>\s*(<h[1-6][^>]*>.*?<\/h[1-6]>)\s*<\/p>/i', '$1', $string);

    // Remove empty <p> tags
    $string = preg_replace('/<p>(\s|&nbsp;|<br>|<br\/?>)*<\/p>/i', '', $string);

    return trim($string);
}

/**
 * Sanitize SVG or string output for safe HTML embedding.
 *
 * This function trims, validates, and optionally sanitizes SVG or string data.
 * Useful for inline SVG output while preventing XSS unless explicitly allowed.
 *
 * @param string|null $string         The input string to sanitize.
 * @param bool        $br             Whether to convert newlines to <br> tags.
 * @param int         $strip          Whether to apply stripslashes (1 = yes).
 * @param bool        $cleanString    Whether to apply custom cleaning logic.
 * @param bool        $validate_url   If true, validates the string as a URL.
 * @param bool        $allow_svg      If false, encodes HTML to prevent SVG execution.
 * @return string|false               The sanitized string, or false on invalid URL.
 * @uses cleanString() from global helpers
 */
function SVG_HelpSecure(
    ?string $string,
    bool $br = true,
    int $strip = 0,
    bool $cleanString = true,
    bool $validate_url = false,
    bool $allow_svg = true
) {
    $string = $string !== null ? trim($string) : '';

    // If the string is expected to be a valid URL
    if ($validate_url && !filter_var($string, FILTER_VALIDATE_URL)) {
        return false;
    }

    // Apply basic XSS filtering
    if ($cleanString) {
        $string = cleanString($string);
    }

    $string = ensureUtf8($string);

    // Escape output unless SVG rendering is explicitly allowed
    if (!$allow_svg) {
        $string = htmlspecialchars($string, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    // Normalize newlines
    $string = $br
        ? str_replace(STRING_NEWLINES, '', $string)
        : str_replace(STRING_NEWLINES, '', $string);

    // Remove backslashes if required
    if ($strip === 1) {
        $string = stripslashes($string);
    }

    // Fix for double-encoded ampersands
    $string = str_replace('&amp;#', '&#', $string);

    return $string;
}

/**
 * Remove empty or redundant HTML tags from TinyMCE content.
 *
 * @param string $content The HTML content to be cleaned.
 * @return string The cleaned HTML content.
 */
function removeEmptyTags(string $content): string
{
    // Remove <p> tags that contain only whitespace or &nbsp;
    $content = preg_replace('/<p>\s*<\/p>/', '', $content);
    $content = preg_replace('/<p>(\s|&nbsp;)*<\/p>/i', '', $content);

    // Replace multiple <br> tags with a single one
    $content = preg_replace('/(<br\s*\/?>\s*)+/', '<br>', $content);

    // Remove any tags with no content inside (e.g., <div></div>, <span> </span>)
    $content = preg_replace('/<([a-z][a-z0-9]*)\b[^>]*>(\s|&nbsp;)*<\/\1>/i', '', $content);

    // Clean repeated empty paragraphs again
    $content = preg_replace('/(<p>\s*<\/p>\s*)+/', '', $content);

    return $content;
}

/**
 * Removes HTML tags and optionally cleans a string.
 *
 * @param string|null $string           The input string to clean.
 * @param bool        $br               Whether to replace new lines with space.
 * @param int         $strip            If 1, stripslashes is applied.
 * @uses cleanString() from global helpers
 * @param bool        $validateUrl      If true, only valid URLs are accepted.
 * @return string|false                 Cleaned string, or false if URL validation fails.
 */
function iN_RemoveHTML(
    ?string $string,
    bool $br = true,
    int $strip = 0,
    bool $cleanString = true,
    bool $validateUrl = false
) {
    $string = $string !== null ? trim($string) : '';

    // If URL validation is requested, return false on invalid URL
    if ($validateUrl && !filter_var($string, FILTER_VALIDATE_URL)) {
        return false;
    }

    // If cleaning is requested and it's not a URL
    if ($cleanString && !$validateUrl) {
        // Remove script tags completely
        $string = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $string);

        // Remove all HTML tags
        $string = strip_tags($string);

        // Custom string cleaning (assumes cleanString() exists in your system)
        $string = cleanString($string);
    }

    $string = ensureUtf8($string);

    // Escape remaining HTML entities
    if (!$validateUrl) {
        $string = htmlspecialchars($string, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    // Replace new lines with space or remove them
    $string = str_replace(STRING_NEWLINES, $br ? ' ' : '', $string);

    // Optionally strip slashes
    if ($strip === 1) {
        $string = stripslashes($string);
    }

    // Fix for encoded characters
    $string = str_replace('&amp;#', '&#', $string);

    return $string;
}

/**
 * Limits a given text to approximately three lines based on the given line length.
 *
 * This function breaks the input text into lines of roughly the specified character length
 * and ensures that no more than three lines are returned. It will append "..." if the text is truncated.
 *
 * @param string $text        The input text to limit.
 * @param int    $lineLength  Approximate maximum number of characters per line.
 * @return string             The resulting text limited to three lines.
 */
function limitTextToThreeLines(string $text, int $lineLength): string
{
    $lines = [];
    $currentLine = '';
    $words = explode(' ', $text);

    foreach ($words as $word) {
        $testLine = $currentLine === '' ? $word : $currentLine . ' ' . $word;

        if (mb_strlen($testLine, 'UTF-8') <= $lineLength) {
            $currentLine = $testLine;
        } else {
            $lines[] = $currentLine;
            $currentLine = $word;

            // If two full lines are already added, prepare to exit
            if (count($lines) >= 2) {
                $currentLine = rtrim($currentLine) . '...';
                break;
            }
        }
    }

    if (!empty($currentLine)) {
        $lines[] = $currentLine;
    }

    return implode("\n", array_slice($lines, 0, 3));
}
/**
 * Truncate text to a specific length and add ellipsis if exceeded.
 *
 * @param string $text   The text to truncate.
 * @param int    $length Maximum length of the truncated text.
 *
 * @return string
 */
function truncateText(string $text, int $length = 50): string
{
    if (mb_strlen($text, 'UTF-8') > $length) {
        return mb_substr($text, 0, $length, 'UTF-8') . '...';
    }

    return $text;
}
/**
 * Replaces placeholders in a string with values from the replacements array.
 *
 * Example:
 *   Input:  "Hello, {name}!"
 *   Output: "Hello, John!" (if replacements['name'] = 'John')
 *
 * @param string $string          The input string containing placeholders like {key}.
 * @param array  $replacements    Associative array of replacement values.
 * @param string $default         Default value to use if key is not found.
 * @return string                 String with placeholders replaced.
 */
function replacePlaceholders(string $string, array $replacements, string $default = 'undefined'): string {
    return preg_replace_callback('/{(.*?)}/', function ($matches) use ($replacements, $default) {
        $key = $matches[1];
        return isset($replacements[$key]) ? $replacements[$key] : $default;
    }, $string);
}

/**
 * Replaces placeholders in a string with values from the replacements array (with trim and strict key check).
 *
 * This function trims keys inside placeholders and uses array_key_exists to also allow null values.
 *
 * Example:
 *   Input:  "Hello, { name }!"
 *   Output: "Hello, John!" (if replacements['name'] = 'John')
 *
 * @param string $string          The input string with placeholders like { key }.
 * @param array  $replacements    Associative array of replacement values.
 * @param string $default         Default fallback if key not found.
 * @return string                 Modified string with replacements applied.
 */
function replacePlaceholdersPlus(string $string, array $replacements, string $default = 'undefined'): string {
    return preg_replace_callback('/{(.*?)}/', function ($matches) use ($replacements, $default) {
        $key = trim($matches[1]);
        return array_key_exists($key, $replacements) ? $replacements[$key] : $default;
    }, $string);
}

/**
 * Checks whether the given text contains any of the specified bad words.
 *
 * @param string $text      The input text to scan.
 * @param string $badWords  A comma-separated list of bad words to check against.
 * @return string|false     The first matched bad word, or false if none found.
 */
function checkBadWords(string $text, string $badWords)
{
    // Trim the input text
    $text = trim($text);

    // Convert the comma-separated bad words string into an array
    $badWordsArray = array_map('trim', explode(',', $badWords));

    // Check each bad word using a case-insensitive regular expression
    foreach ($badWordsArray as $word) {
        $regex = '/\b' . preg_quote(mb_strtolower($word, 'UTF-8'), '/') . '\b/ui';

        if (preg_match($regex, mb_strtolower($text, 'UTF-8'))) {
            return $word; // Return the matched word
        }
    }

    // Return false if no bad word is found
    return false;
}
/**
 * Secure output for support content by sanitizing and formatting text.
 *
 * This function ensures that strings are safely escaped for HTML output,
 * optionally preserves line breaks, and strips unwanted characters.
 *
 * @param string|null $string          The input string to sanitize.
 * @param bool        $br              Whether to convert newlines to <br> tags.
 * @param int         $strip           Whether to apply stripslashes.
 * @param bool        $cleanString     Whether to clean the string using cleanString().
 * @uses cleanString() from global helpers
 * @param bool        $validate_url    Whether to validate input as URL format.
 *
 * @return string|false Returns the sanitized string or false if URL is invalid.
 */
function iN_HelpSecureSupport(
    $string,
    bool $br = true,
    int $strip = 0,
    bool $cleanString = true,
    bool $validate_url = false
) {
    // Ensure input is string and trimmed
    $string = $string !== null ? trim($string) : '';

    // If URL validation is required and fails, return false
    if ($validate_url && !filter_var($string, FILTER_VALIDATE_URL)) {
        return false;
    }

    // Clean string if required (HTML/script removal, etc.)
    if ($cleanString && !$validate_url) {
        $string = cleanString($string); // Must be defined elsewhere in the project
    }

    $string = ensureUtf8($string);

    // Escape special characters for safe HTML output
    $string = htmlspecialchars($string, ENT_QUOTES | ENT_HTML5, 'UTF-8');

    // Convert line breaks to <br> or remove them entirely
    $lineBreakReplacement = $br ? ' <br>' : '';
    $string = str_replace(STRING_NEWLINES, $lineBreakReplacement, $string);

    // Optionally remove backslashes
    if ($strip === 1) {
        $string = stripslashes($string);
    }

    // Fix malformed ampersand-encoded HTML entities
    $string = str_replace('&amp;#', '&#', $string);

    return $string;
}
/**
 * Secure and optionally strip or sanitize the given string.
 *
 * @param string|null $string The input string to secure.
 * @param bool $br Whether to convert new lines to <br> tags.
 * @param int $strip 0 = no strip, 1 = stripslashes, 2 = strip slashes before quotes.
 * @param bool $cleanString Whether to apply cleanString() logic.
 * @uses cleanString() from global helpers
 * @param bool $validate_url If true, only allows valid URLs.
 * @return string|false The secured string or false if URL validation fails.
 */
function iN_HelpSecureStrip(
    ?string $string,
    bool $br = true,
    int $strip = 0,
    bool $cleanString = true,
    bool $validate_url = false
) {
    $string = $string !== null ? trim($string) : '';

    if ($validate_url && !filter_var($string, FILTER_VALIDATE_URL)) {
        return false;
    }

    if ($cleanString && !$validate_url) {
        $string = cleanString($string);
    }

    $string = ensureUtf8($string);

    if (!$validate_url) {
        $string = htmlspecialchars($string, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    $string = $br
        ? str_replace(STRING_NEWLINES, " <br>", $string)
        : str_replace(STRING_NEWLINES, "", $string);

    if ($strip === 1) {
        $string = stripslashes($string);
    } elseif ($strip === 2) {
        $string = preg_replace('/\\\\([\'"])/', '$1', $string);
    }

    $string = str_replace('&amp;#', '&#', $string);

    return $string;
}

function url_slug($str, $options = array()) {
    // Ensure string is UTF-8 and remove invalid characters
    if (!mb_detect_encoding($str, 'UTF-8', true)) {
        $str = mb_convert_encoding($str, 'UTF-8', mb_list_encodings());
    }

    // Default options
    $defaults = array(
        'delimiter' => '-',
        'limit' => null,
        'lowercase' => true,
        'replacements' => array(),
        'transliterate' => true
    );

    // Merge defaults with provided options
    $options = array_merge($defaults, $options);

    // Character map for transliteration
    $char_map = array(
        // Turkish
        'Ş' => 'S', 'İ' => 'I', 'Ç' => 'C', 'Ü' => 'U', 'Ö' => 'O', 'Ğ' => 'G',
        'ş' => 's', 'ı' => 'i', 'ç' => 'c', 'ü' => 'u', 'ö' => 'o', 'ğ' => 'g',

        // Arabic (Transliteration)
        'أ' => 'a', 'إ' => 'i', 'آ' => 'a', 'ا' => 'a', 'ب' => 'b', 'ت' => 't',
        'ث' => 'th', 'ج' => 'j', 'ح' => 'h', 'خ' => 'kh', 'د' => 'd', 'ذ' => 'dh',
        'ر' => 'r', 'ز' => 'z', 'س' => 's', 'ش' => 'sh', 'ص' => 's', 'ض' => 'd',
        'ط' => 't', 'ظ' => 'z', 'ع' => 'a', 'غ' => 'gh', 'ف' => 'f', 'ق' => 'q',
        'ك' => 'k', 'ل' => 'l', 'م' => 'm', 'ن' => 'n', 'ه' => 'h', 'و' => 'w',
        'ي' => 'y',

        // Japanese
        'あ' => 'a', 'い' => 'i', 'う' => 'u', 'え' => 'e', 'お' => 'o',
        'か' => 'ka', 'き' => 'ki', 'く' => 'ku', 'け' => 'ke', 'こ' => 'ko',
        'さ' => 'sa', 'し' => 'shi', 'す' => 'su', 'せ' => 'se', 'そ' => 'so',
        'た' => 'ta', 'ち' => 'chi', 'つ' => 'tsu', 'て' => 'te', 'と' => 'to',
        'な' => 'na', 'に' => 'ni', 'ぬ' => 'nu', 'ね' => 'ne', 'の' => 'no',
        'は' => 'ha', 'ひ' => 'hi', 'ふ' => 'fu', 'へ' => 'he', 'ほ' => 'ho',
        'ま' => 'ma', 'み' => 'mi', 'む' => 'mu', 'め' => 'me', 'も' => 'mo',
        'や' => 'ya', 'ゆ' => 'yu', 'よ' => 'yo', 'ら' => 'ra', 'り' => 'ri',
        'る' => 'ru', 'れ' => 're', 'ろ' => 'ro', 'わ' => 'wa', 'を' => 'wo',
        'ん' => 'n',

        // Chinese
        '你' => 'ni', '好' => 'hao', '是' => 'shi', '的' => 'de', '我' => 'wo',
        '们' => 'men', '有' => 'you', '在' => 'zai', '不' => 'bu', '和' => 'he',

        // Kurdish
        'Ç' => 'C', 'Ğ' => 'G', 'Î' => 'I', 'Ş' => 'S', 'Û' => 'U',
        'ç' => 'c', 'ê' => 'e', 'î' => 'i', 'ş' => 's', 'û' => 'u',

        // Other common accents
        'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A', 'Å' => 'A',
        'Æ' => 'AE', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
        'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O',
        'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U',
        'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y', 'ß' => 'ss', 'à' => 'a',
        'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a', 'æ' => 'ae',
        'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i',
        'í' => 'i', 'î' => 'i', 'ï' => 'i', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o',
        'ô' => 'o', 'õ' => 'o', 'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u',
        'û' => 'u', 'ü' => 'u', 'ý' => 'y', 'ÿ' => 'y'
    );

    // Custom replacements
    if (!empty($options['replacements'])) {
        $str = str_replace(array_keys($options['replacements']), $options['replacements'], $str);
    }

    // Transliterate if needed
    if ($options['transliterate']) {
        $str = str_replace(array_keys($char_map), $char_map, $str);
    }

    // Replace non-alphanumeric characters with the delimiter
    $str = preg_replace('/[^\p{L}\p{Nd}]+/u', $options['delimiter'], $str);

    // Remove duplicate delimiters
    $str = preg_replace('/(' . preg_quote($options['delimiter'], '/') . '){2,}/', '$1', $str);

    // Limit the length of the slug if a limit is set
    if (!empty($options['limit'])) {
        $str = mb_substr($str, 0, $options['limit'], 'UTF-8');
    }

    // Trim delimiters from the beginning and end
    $str = trim($str, $options['delimiter']);

    // Convert to lowercase if needed
    if ($options['lowercase']) {
        $str = mb_strtolower($str, 'UTF-8');
    }

    return $str;
}


function url_slug_plus($str, $options = array()) {
    // Ensure UTF-8 encoding
    if (!mb_detect_encoding($str, 'UTF-8', true)) {
        $str = mb_convert_encoding($str, 'UTF-8', mb_list_encodings());
    }

    // Basic XSS prevention: block strings that include <script>, onerror=, javascript:, etc.
    $lower = strtolower($str);
    if (preg_match('/<\s*script|on\w+\s*=|javascript:/i', $lower)) {
        return ''; // Empty slug for dangerous input
    }

    // Default options
    $defaults = array(
        'delimiter' => '_',
        'limit' => null,
        'lowercase' => true,
        'replacements' => array(),
        'transliterate' => true
    );

    $options = array_merge($defaults, $options);

    // Character map for transliteration
    $char_map = array(
        // Turkish
        'Ş' => 'S', 'İ' => 'I', 'Ç' => 'C', 'Ü' => 'U', 'Ö' => 'O', 'Ğ' => 'G',
        'ş' => 's', 'ı' => 'i', 'ç' => 'c', 'ü' => 'u', 'ö' => 'o', 'ğ' => 'g',

        // ARabic (Transliterasyon)
        'أ' => 'a', 'إ' => 'i', 'آ' => 'a', 'ا' => 'a', 'ب' => 'b', 'ت' => 't',
        'ث' => 'th', 'ج' => 'j', 'ح' => 'h', 'خ' => 'kh', 'د' => 'd', 'ذ' => 'dh',
        'ر' => 'r', 'ز' => 'z', 'س' => 's', 'ش' => 'sh', 'ص' => 's', 'ض' => 'd',
        'ط' => 't', 'ظ' => 'z', 'ع' => 'a', 'غ' => 'gh', 'ف' => 'f', 'ق' => 'q',
        'ك' => 'k', 'ل' => 'l', 'م' => 'm', 'ن' => 'n', 'ه' => 'h', 'و' => 'w',
        'ي' => 'y',

        // Japonca
        'あ' => 'a', 'い' => 'i', 'う' => 'u', 'え' => 'e', 'お' => 'o',
        'か' => 'ka', 'き' => 'ki', 'く' => 'ku', 'け' => 'ke', 'こ' => 'ko',
        'さ' => 'sa', 'し' => 'shi', 'す' => 'su', 'せ' => 'se', 'そ' => 'so',
        'た' => 'ta', 'ち' => 'chi', 'つ' => 'tsu', 'て' => 'te', 'と' => 'to',
        'な' => 'na', 'に' => 'ni', 'ぬ' => 'nu', 'ね' => 'ne', 'の' => 'no',
        'は' => 'ha', 'ひ' => 'hi', 'ふ' => 'fu', 'へ' => 'he', 'ほ' => 'ho',
        'ま' => 'ma', 'み' => 'mi', 'む' => 'mu', 'め' => 'me', 'も' => 'mo',
        'や' => 'ya', 'ゆ' => 'yu', 'よ' => 'yo', 'ら' => 'ra', 'り' => 'ri',
        'る' => 'ru', 'れ' => 're', 'ろ' => 'ro', 'わ' => 'wa', 'を' => 'wo',
        'ん' => 'n',

        // Chinese
        '你' => 'ni', '好' => 'hao', '是' => 'shi', '的' => 'de', '我' => 'wo',
        '们' => 'men', '有' => 'you', '在' => 'zai', '不' => 'bu', '和' => 'he',

        // Kurdish
        'Ç' => 'C', 'Ğ' => 'G', 'Î' => 'I', 'Ş' => 'S', 'Û' => 'U',
        'ç' => 'c', 'ê' => 'e', 'î' => 'i', 'ş' => 's', 'û' => 'u',

        // Other common accents
        'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A', 'Å' => 'A',
        'Æ' => 'AE', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
        'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O',
        'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U',
        'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y', 'ß' => 'ss', 'à' => 'a',
        'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a', 'æ' => 'ae',
        'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i',
        'í' => 'i', 'î' => 'i', 'ï' => 'i', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o',
        'ô' => 'o', 'õ' => 'o', 'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u',
        'û' => 'u', 'ü' => 'u', 'ý' => 'y', 'ÿ' => 'y'
    );

    // Custom replacements
    if (!empty($options['replacements'])) {
        $str = str_replace(array_keys($options['replacements']), $options['replacements'], $str);
    }

    // Transliterate if needed
    if ($options['transliterate']) {
        $str = str_replace(array_keys($char_map), $char_map, $str);
    }

    // Replace non-alphanumeric characters with the delimiter
    $str = preg_replace('/[^\p{L}\p{Nd}]+/u', $options['delimiter'], $str);

    // Remove duplicate delimiters
    $str = preg_replace('/(' . preg_quote($options['delimiter'], '/') . '){2,}/', '$1', $str);

    // Limit the length of the slug if a limit is set
    if (!empty($options['limit'])) {
        $str = mb_substr($str, 0, $options['limit'], 'UTF-8');
    }

    // Trim delimiters from the beginning and end
    $str = trim($str, $options['delimiter']);

    // Convert to lowercase if needed
    if ($options['lowercase']) {
        $str = mb_strtolower($str, 'UTF-8');
    }

    return $str;
}
/**
 * Convert a hexadecimal color code to RGBA format.
 *
 * Supports both 3-digit and 6-digit hex codes. Automatically strips the '#' character.
 * Useful for CSS color handling with opacity support.
 *
 * @param string $hexColor Hexadecimal color code (e.g. "#fff" or "#ffffff").
 * @param float|int $opacity Opacity value between 0 (transparent) and 1 (opaque).
 * @return string RGBA string (e.g. "rgba(255, 255, 255, 0.5)").
 */
function hexToRgba(string $hexColor, $opacity = 1): string
{
    // Remove '#' if present
    $hex = str_replace('#', '', $hexColor);

    // Validate hex format
    if (!preg_match('/^[a-fA-F0-9]{3}$|^[a-fA-F0-9]{6}$/', $hex)) {
        return 'rgba(0, 0, 0, 1)'; // fallback to black if invalid
    }

    // Expand shorthand format (e.g. "fff") to full form (e.g. "ffffff")
    if (strlen($hex) === 3) {
        $r = hexdec(str_repeat($hex[0], 2));
        $g = hexdec(str_repeat($hex[1], 2));
        $b = hexdec(str_repeat($hex[2], 2));
    } else {
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
    }

    // Clamp opacity to [0, 1]
    $opacity = max(0, min(1, (float) $opacity));

    return "rgba($r, $g, $b, $opacity)";
}

/**
 * Generate a linear gradient CSS string using a hex color and opacity.
 *
 * Converts the given hex color to RGBA format and uses it in a 135-degree gradient.
 *
 * @param string $hexColor Hexadecimal color code (e.g. "#ff0000").
 * @param float|int $opacity Opacity value between 0 (transparent) and 1 (opaque).
 * @return string Linear gradient string for CSS usage.
 */
function generateGradient(string $hexColor, $opacity): string
{
    $rgbaColor = hexToRgba($hexColor, $opacity);

    return "linear-gradient(135deg, {$rgbaColor} 0%, {$rgbaColor} 100%)";
}

function generateInvoiceNumber($username) {
    $prefix = strtoupper(substr($username, 0, 2));

    $hash = md5($username);
    $numericHash = preg_replace('/[^0-9]/', '', $hash);

    $invoiceNumberPart = substr($numericHash, 0, 5);

    $invoiceNumber = $prefix . $invoiceNumberPart;

    return $invoiceNumber;
}

function generateRandomKey($length = 5) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $charactersLength = strlen($characters);
    $randomKey = '';

    for ($i = 0; $i < $length; $i++) {
        $randomKey .= $characters[random_int(0, $charactersLength - 1)];
    }

    return $randomKey;
}
?>
