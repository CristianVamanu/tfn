<?php
// Local-only Agora overrides for development/testing.
// Do NOT commit this file to version control in production environments.

// Provide non-empty values here to override DB settings. Leave empty to fall back to DB.
$agoraAppId   = '';
$agoraAppCert = '';

// Booleans: set explicitly if you want to override; otherwise comment out to use DB value
$agoraEnableRTM = true;
//$agoraAllowTokenless = true; // For local debugging only; disable in production

