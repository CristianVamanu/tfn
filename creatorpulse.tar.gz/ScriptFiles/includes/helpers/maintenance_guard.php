<?php
declare(strict_types=1);

/**
 * Centralised maintenance-mode guard.
 *
 * @param array $options {
 *   @var string      $status       Maintenance switch ('on'/'off').
 *   @var mixed       $eta          Optional ETA timestamp (Unix seconds) or ISO string.
 *   @var string|null $message      Optional message to display.
 *   @var string      $base_url     Application base URL.
 *   @var string      $theme        Active theme slug.
 *   @var array|null  $user_data    Current user payload from inc.php (optional).
 *   @var string|null $user_mode    Current user mode (admin/moderator/user) if available.
 *   @var string|null $locale       Current locale code.
 *   @var array|null  $site_data    Full site configuration row (for logos etc.).
 * }
 */
function maintenance_guard(array $options): void
{
    $status = strtolower((string)($options['status'] ?? 'off'));
    if ($status !== 'on') {
        return;
    }

    if (maintenance_guard_should_bypass($options)) {
        return;
    }

    $now = time();
    $etaRaw = $options['eta'] ?? null;
    $etaTs  = null;
    if (is_numeric($etaRaw)) {
        $etaTs = (int) $etaRaw;
    } elseif (is_string($etaRaw) && $etaRaw !== '') {
        $parsed = strtotime($etaRaw);
        if ($parsed !== false) {
            $etaTs = $parsed;
        }
    }

    if ($etaTs !== null && $etaTs <= 0) {
        $etaTs = null;
    }

    $etaStatus = 'unset';
    if ($etaTs !== null) {
        $etaStatus = $etaTs > $now ? 'future' : 'elapsed';
    }

    $retryAfter = '600'; // default 10 minutes
    if ($etaStatus === 'future' && $etaTs !== null) {
        $retryAfter = gmdate('D, d M Y H:i:s', $etaTs) . ' GMT';
    }

    if (!headers_sent()) {
        header_remove('Pragma');
        header('Cache-Control: no-store, no-cache, must-revalidate', true);
        header('Pragma: no-cache', true);
        header('Retry-After: ' . $retryAfter, true);
        http_response_code(503);
    }

    $message   = isset($options['message']) ? trim((string)$options['message']) : '';
    $baseUrl   = (string)($options['base_url'] ?? '/');
    $themeSlug = maintenance_guard_sanitise_theme((string)($options['theme'] ?? 'default'));
    $siteData  = (array)($options['site_data'] ?? []);

    $responseIntent = maintenance_guard_detect_intent();

    if ($responseIntent === 'json') {
        $payload = [
            'status'       => 'maintenance',
            'message'      => $message !== '' ? $message : customLang('maintenance_json_message'),
            'eta'          => $etaTs,
            'eta_status'   => $etaStatus,
            'retry_after'  => ($etaStatus === 'future' && $etaTs !== null) ? $etaTs : $now + 600,
            'contact_url'  => maintenance_guard_primary_contact($siteData, $baseUrl),
        ];
        header('Content-Type: application/json; charset=utf-8', true);
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }

    $rootDir   = dirname(__DIR__, 2);
    $themeFile = $rootDir . '/themes/' . $themeSlug . '/maintenance.php';
    if (!is_file($themeFile)) {
        $themeFile = $rootDir . '/themes/default/maintenance.php';
    }

    $maintenanceData = [
        'baseUrl'        => $baseUrl,
        'themeSlug'      => $themeSlug,
        'message'        => $message,
        'etaTimestamp'   => $etaTs,
        'etaStatus'      => $etaStatus,
        'retryAfter'     => $retryAfter,
        'siteData'       => $siteData,
        'locale'         => (string)($options['locale'] ?? ''),
        'contactUrl'     => maintenance_guard_primary_contact($siteData, $baseUrl),
        'statusLinks'    => maintenance_guard_status_links($siteData, $baseUrl),
        'updatedAt'      => isset($siteData['maintenance_updated_at']) ? (int)$siteData['maintenance_updated_at'] : null,
        'updatedBy'      => isset($siteData['maintenance_updated_by']) ? (int)$siteData['maintenance_updated_by'] : null,
    ];

    // Provide variables to the view in local scope
    extract($maintenanceData, EXTR_SKIP);

    require $themeFile;
    exit;
}

/**
 * Detect the preferred response type for maintenance guard.
 */
function maintenance_guard_detect_intent(): string
{
    $accept     = (string)($_SERVER['HTTP_ACCEPT'] ?? '');
    $xhr        = (string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '');
    $scriptName = maintenance_guard_normalise_path((string)($_SERVER['SCRIPT_NAME'] ?? ($_SERVER['PHP_SELF'] ?? '')));

    if (stripos($accept, 'application/json') !== false) {
        return 'json';
    }

    if (strcasecmp($xhr, 'XMLHttpRequest') === 0) {
        return 'json';
    }

    if (preg_match('~/(api|request)/~', $scriptName)) {
        return 'json';
    }

    return 'html';
}

/** Determine whether the current request should bypass maintenance. */
function maintenance_guard_should_bypass(array $options): bool
{
    if (PHP_SAPI === 'cli' || PHP_SAPI === 'phpdbg') {
        return true;
    }

    $scriptName = maintenance_guard_normalise_path((string)($_SERVER['SCRIPT_NAME'] ?? ($_SERVER['PHP_SELF'] ?? '')));
    $requestUri = maintenance_guard_normalise_path(parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH) ?? '');

    // Allow administration, auth, login/logout even when maintenance is active.
    $bypassPrefixes = [
        '/admin',
        '/login',
        '/logout',
        '/auth/',
        '/install',
    ];

    foreach ($bypassPrefixes as $prefix) {
        if ($prefix === '/auth/') {
            if (strpos($requestUri, '/auth/') === 0 || strpos($scriptName, '/auth/') === 0) {
                return true;
            }
            continue;
        }
        if (strpos($requestUri, $prefix) === 0 || strpos($scriptName, $prefix) === 0) {
            return true;
        }
    }

    $bypassExact = [
        '/request/login.php',
        '/request/webhooks.php',
        '/request/contact.php',
    ];

    $bypassPublicRoutes = [
        '/contact',
    ];
    foreach ($bypassPublicRoutes as $route) {
        if ($requestUri === $route
            || str_ends_with($requestUri, $route)
            || str_ends_with($requestUri, $route . '/')
            || strpos($requestUri, $route . '/') === 0) {
            return true;
        }
    }
    // Non-rewrite and querystring variants (e.g. index.php?route=contact)
    $routeQueryKeys = ['route', 'page', 'view'];
    foreach ($routeQueryKeys as $key) {
        $value = $_GET[$key] ?? null;
        if (is_string($value) && strtolower($value) === 'contact') {
            return true;
        }
    }
    foreach ($bypassExact as $candidate) {
        if ($scriptName === $candidate
            || str_ends_with($scriptName, $candidate)
            || $requestUri === $candidate
            || str_ends_with($requestUri, $candidate)) {
            return true;
        }
    }

    // Allow already authenticated elevated users to bypass maintenance.
    $userMode = isset($options['user_mode']) ? strtolower((string)$options['user_mode']) : '';
    $userData = isset($options['user_data']) && is_array($options['user_data']) ? $options['user_data'] : [];

    if ($userMode !== '') {
        if (in_array($userMode, ['admin', 'moderator', 'owner', 'super_admin', 'superadmin', 'superuser'], true)) {
            return true;
        }
    } elseif ($userData !== []) {
        $uid  = isset($userData['user_id']) ? (int)$userData['user_id'] : 0;
        $type = isset($userData['user_type']) ? (int)$userData['user_type'] : 0;
        if ($uid === 1 || $type >= 2) {
            return true;
        }
    }

    return false;
}

/** Normalise a request path for comparisons. */
function maintenance_guard_normalise_path(string $path): string
{
    if ($path === '') {
        return '/';
    }
    $path = str_replace('\\', '/', $path);
    if ($path[0] !== '/') {
        $path = '/' . $path;
    }
    return rtrim($path, '/') === '' ? '/' : rtrim($path, '/');
}

/** Ensure theme slug is safe for filesystem usage. */
function maintenance_guard_sanitise_theme(string $theme): string
{
    if ($theme === '') {
        return 'default';
    }
    $clean = preg_replace('/[^a-zA-Z0-9_-]/', '', $theme) ?: 'default';
    return $clean;
}

/** Locate the primary contact/support URL if configured. */
function maintenance_guard_primary_contact(array $siteData, string $baseUrl): ?string
{
    foreach (['maintenance_support_url', 'maintenance_status_url', 'status_page_url', 'status_url', 'support_url', 'contact_url'] as $key) {
        if (!empty($siteData[$key]) && filter_var($siteData[$key], FILTER_VALIDATE_URL)) {
            return $siteData[$key];
        }
    }

    $contactPath = rtrim($baseUrl, '/') . '/contact';
    return $contactPath;
}

/** Build a stack of social/status link definitions. */
function maintenance_guard_status_links(array $siteData, string $baseUrl): array
{
    $candidates = [
        ['key' => 'maintenance_status_url',   'label' => customLang('maintenance_status_label_status'), 'icon' => 'status'],
        ['key' => 'status_page_url',          'label' => customLang('maintenance_status_label_status'), 'icon' => 'status'],
        ['key' => 'maintenance_twitter_url',  'label' => customLang('maintenance_status_label_twitter'), 'icon' => 'twitter'],
        ['key' => 'twitter_url',              'label' => customLang('maintenance_status_label_twitter'), 'icon' => 'twitter'],
        ['key' => 'maintenance_facebook_url', 'label' => customLang('maintenance_status_label_facebook'), 'icon' => 'facebook'],
        ['key' => 'facebook_url',             'label' => customLang('maintenance_status_label_facebook'), 'icon' => 'facebook'],
        ['key' => 'maintenance_instagram_url','label' => customLang('maintenance_status_label_instagram'), 'icon' => 'instagram'],
        ['key' => 'instagram_url',            'label' => customLang('maintenance_status_label_instagram'), 'icon' => 'instagram'],
        ['key' => 'maintenance_tiktok_url',   'label' => customLang('maintenance_status_label_tiktok'), 'icon' => 'tiktok'],
        ['key' => 'tiktok_url',               'label' => customLang('maintenance_status_label_tiktok'), 'icon' => 'tiktok'],
    ];

    $links = [];
    $seen = [];
    foreach ($candidates as $candidate) {
        $key = $candidate['key'];
        if (empty($siteData[$key]) || !is_string($siteData[$key])) {
            continue;
        }
        $url = trim($siteData[$key]);
        if ($url === '') {
            continue;
        }
        if (!preg_match('~^https?://~i', $url)) {
            if ($url[0] === '/') {
                $url = rtrim($baseUrl, '/') . $url;
            } else {
                continue;
            }
        }
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            continue;
        }
        $hash = strtolower($url);
        if (isset($seen[$hash])) {
            continue;
        }
        $seen[$hash] = true;
        $links[] = [
            'label' => $candidate['label'],
            'url'   => $url,
            'icon'  => $candidate['icon'],
        ];
    }

    return $links;
}
