<?php
declare(strict_types=1);

/**
 * Shared utilities for OAuth based social logins.
 */

if (!function_exists('social_login_get_config')) {
    /**
     * Return normalized social provider configuration merged with environment overrides.
     *
     * @param array|null $configFromDb Raw configuration row (optional, falls back to global $siteData).
     * @return array<string,array<string,mixed>>
     */
    function social_login_get_config(?array $configFromDb = null): array
    {
        static $cache = null;
        if ($cache !== null && $configFromDb === null) {
            return $cache;
        }

        if ($configFromDb === null) {
            $configFromDb = isset($GLOBALS['siteData']) && is_array($GLOBALS['siteData'])
                ? $GLOBALS['siteData']
                : [];
        }

        $providers = [
            'google' => [
                'label'        => 'Google',
                'status_key'   => 'google_status',
                'id_key'       => 'google_client_id',
                'secret_key'   => 'google_client_secret',
                'env_id'       => 'GOOGLE_CLIENT_ID',
                'env_secret'   => 'GOOGLE_CLIENT_SECRET',
            ],
            'facebook' => [
                'label'        => 'Facebook',
                'status_key'   => 'facebook_status',
                'id_key'       => 'facebook_app_id',
                'secret_key'   => 'facebook_app_secret',
                'env_id'       => 'FACEBOOK_APP_ID',
                'env_secret'   => 'FACEBOOK_APP_SECRET',
            ],
            'twitter' => [
                'label'        => 'Twitter',
                'status_key'   => 'twitter_status',
                'id_key'       => 'twitter_client_id',
                'secret_key'   => 'twitter_client_secret',
                'env_id'       => 'TWITTER_CLIENT_ID',
                'env_secret'   => 'TWITTER_CLIENT_SECRET',
            ],
        ];

        $resolveEnv = static function (string $key): string {
            if (!function_exists('env')) {
                return '';
            }
            $val = env($key, null);
            if ($val === null) {
                $val = $_ENV[$key] ?? ($_SERVER[$key] ?? '');
            }
            return is_string($val) ? trim($val) : '';
        };

        $resolved = [];
        foreach ($providers as $name => $meta) {
            $statusRaw = isset($configFromDb[$meta['status_key']]) ? strtolower((string)$configFromDb[$meta['status_key']]) : 'close';
            if (!in_array($statusRaw, ['open', 'close'], true)) {
                $statusRaw = 'close';
            }

            $idDb     = isset($configFromDb[$meta['id_key']]) ? trim((string)$configFromDb[$meta['id_key']]) : '';
            $secretDb = isset($configFromDb[$meta['secret_key']]) ? trim((string)$configFromDb[$meta['secret_key']]) : '';

            $idEnv     = $resolveEnv($meta['env_id']);
            $secretEnv = $resolveEnv($meta['env_secret']);

            $clientId     = $idEnv !== '' ? $idEnv : $idDb;
            $clientSecret = $secretEnv !== '' ? $secretEnv : $secretDb;

            $resolved[$name] = [
                'label'          => $meta['label'],
                'enabled'        => ($statusRaw === 'open'),
                'status_raw'     => $statusRaw,
                'client_id'      => $clientId,
                'client_secret'  => $clientSecret,
                'client_id_src'  => $idEnv !== '' ? 'env' : ($idDb !== '' ? 'db' : 'unset'),
                'client_secret_src' => $secretEnv !== '' ? 'env' : ($secretDb !== '' ? 'db' : 'unset'),
            ];
        }

        if ($configFromDb === null) {
            $cache = $resolved;
        } elseif ($cache === null) {
            $cache = $resolved;
        }

        return $resolved;
    }

    /**
     * Return true when the provider is enabled and credentials exist.
     */
    function social_login_is_enabled(string $provider, ?array $config = null): bool
    {
        $config = $config ?? social_login_get_config();
        if (!isset($config[$provider])) {
            return false;
        }
        if ($config[$provider]['enabled'] !== true) {
            return false;
        }
        return trim((string)($config[$provider]['client_id'] ?? '')) !== ''
            && trim((string)($config[$provider]['client_secret'] ?? '')) !== '';
    }

    /**
     * Build redirect URI for provider callback.
     */
    function social_login_redirect_uri(string $provider): string
    {
        $base = isset($GLOBALS['base_url']) ? (string)$GLOBALS['base_url'] : '/';
        return rtrim($base, '/') . '/auth/' . $provider;
    }

    /**
     * Generate and store a CSRF state token for provider.
     */
    function social_login_generate_state(string $provider): string
    {
        $state = bin2hex(random_bytes(16));
        $_SESSION['social_login_state'][$provider] = [
            'value'   => $state,
            'expires' => time() + 600, // 10 minutes
        ];
        return $state;
    }

    /**
     * Validate and consume stored state token.
     */
    function social_login_validate_state(string $provider, ?string $provided): bool
    {
        if (!isset($_SESSION['social_login_state'][$provider])) {
            return false;
        }
        $stored = $_SESSION['social_login_state'][$provider];
        unset($_SESSION['social_login_state'][$provider]);
        if (!is_array($stored) || !isset($stored['value'], $stored['expires'])) {
            return false;
        }
        if ((int)$stored['expires'] < time()) {
            return false;
        }
        $expected = (string)$stored['value'];
        if ($provided === null || $provided === '') {
            return false;
        }
        return hash_equals($expected, (string)$provided);
    }

    /**
     * Store PKCE code verifier for the provider (Twitter OAuth 2.0).
     */
    function social_login_store_code_verifier(string $provider, string $verifier): void
    {
        $_SESSION['social_login_code_verifier'][$provider] = $verifier;
    }

    /**
     * Retrieve and remove stored PKCE code verifier.
     */
    function social_login_take_code_verifier(string $provider): ?string
    {
        if (!isset($_SESSION['social_login_code_verifier'][$provider])) {
            return null;
        }
        $verifier = (string)$_SESSION['social_login_code_verifier'][$provider];
        unset($_SESSION['social_login_code_verifier'][$provider]);
        return $verifier;
    }

    /**
     * Provide a cached list of columns defined on i_users.
     *
     * @return array<int,string>
     */
    function social_login_user_columns(PDO $db): array
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }
        $cols = [];
        try {
            $stmt = $db->query('SHOW COLUMNS FROM i_users');
            if ($stmt !== false) {
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
                foreach ($rows as $row) {
                    if (isset($row['Field'])) {
                        $cols[] = (string)$row['Field'];
                    }
                }
            }
        } catch (Throwable $__) {
            // ignore
        }
        $cache = $cols;
        return $cols;
    }

    /**
     * Determine whether i_users contains the given column.
     */
    function social_login_user_column_exists(PDO $db, string $column): bool
    {
        return in_array($column, social_login_user_columns($db), true);
    }

    /**
     * Fetch an existing user by provider identifier.
     */
    function social_login_find_user_by_provider(PDO $db, string $provider, string $providerId): ?array
    {
        $column = $provider . '_id';
        if (!social_login_user_column_exists($db, $column)) {
            return null;
        }
        try {
            $stmt = $db->prepare("SELECT * FROM i_users WHERE {$column} = :pid LIMIT 1");
            $stmt->bindValue(':pid', $providerId, PDO::PARAM_STR);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (Throwable $__) {
            return null;
        }
    }

    /**
     * Fetch an existing user by email when available.
     */
    function social_login_find_user_by_email(PDO $db, ?string $email): ?array
    {
        if ($email === null || $email === '') {
            return null;
        }
        if (!social_login_user_column_exists($db, 'user_email')) {
            return null;
        }
        try {
            $stmt = $db->prepare('SELECT * FROM i_users WHERE user_email = :email LIMIT 1');
            $stmt->bindValue(':email', $email, PDO::PARAM_STR);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (Throwable $__) {
            return null;
        }
    }

    /**
     * Attach provider identifier to an existing user record.
     */
    function social_login_link_provider(PDO $db, int $userId, string $provider, string $providerId): void
    {
        $column = $provider . '_id';
        if (!social_login_user_column_exists($db, $column)) {
            return;
        }
        try {
            $stmt = $db->prepare("UPDATE i_users SET {$column} = :pid WHERE user_id = :uid LIMIT 1");
            $stmt->bindValue(':pid', $providerId, PDO::PARAM_STR);
            $stmt->bindValue(':uid', $userId, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Throwable $__) {
            // ignore
        }
    }

    /**
     * Generate a username candidate based on provided string.
     */
    function social_login_slugify(string $value): string
    {
        $value = strtolower(trim($value));
        $value = preg_replace('/[^a-z0-9]+/i', '_', $value) ?? '';
        $value = trim($value, '_');
        if ($value === '') {
            $value = 'member';
        }
        return substr($value, 0, 40);
    }

    /**
     * Produce a unique username using existing table data.
     */
    function social_login_generate_username(PDO $db, string $seed): string
    {
        $base = social_login_slugify($seed);
        if ($base === '') {
            $base = 'member';
        }

        $username = $base;
        $suffix = 0;
        $checkStmt = null;
        try {
            $checkStmt = $db->prepare('SELECT COUNT(*) FROM i_users WHERE username = :u');
        } catch (Throwable $__) {
            return $base ?: bin2hex(random_bytes(4));
        }

        while (true) {
            $candidate = $username;
            if ($suffix > 0) {
                $candidate = substr($base, 0, max(1, 40 - strlen((string)$suffix) - 1)) . '_' . $suffix;
            }
            $checkStmt->execute([':u' => $candidate]);
            $count = (int)$checkStmt->fetchColumn();
            if ($count === 0) {
                return $candidate;
            }
            $suffix++;
            if ($suffix > 5000) {
                return $candidate . '_' . bin2hex(random_bytes(2));
            }
        }
    }

    /**
     * Insert a new user record derived from social profile data.
     *
     * @param array<string,mixed> $profile
     */
    function social_login_create_user(PDO $db, string $provider, string $providerId, array $profile): ?int
    {
        $columns = social_login_user_columns($db);
        if ($columns === []) {
            return null;
        }

        $time = time();
        $usernameSeed = $profile['username'] ?? ($profile['email'] ?? ($profile['name'] ?? $provider . '_' . substr($providerId, 0, 6)));
        $username = social_login_generate_username($db, (string)$usernameSeed);
        $fullName = isset($profile['name']) ? trim((string)$profile['name']) : $username;
        $email    = isset($profile['email']) && $profile['email'] !== '' ? trim((string)$profile['email']) : null;
        $password = password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT);
        $defaultAvatar = 'uploads/user_avatars/default.jpeg';

        $data = [];
        $set = static function (&$data, array $columns, string $column, $value): void {
            if (in_array($column, $columns, true)) {
                $data[$column] = $value;
            }
        };

        $set($data, $columns, 'username', $username);
        $set($data, $columns, 'user_fullname', $fullName);
        $set($data, $columns, 'user_email', $email);
        $set($data, $columns, 'user_password', $password);
        $set($data, $columns, 'user_type', 1);
        $set($data, $columns, 'user_mode', 'user');
        $set($data, $columns, 'last_login_time', $time);
        $set($data, $columns, 'user_avatar', $defaultAvatar);
        $set($data, $columns, 'verified_status', 0);
        $set($data, $columns, 'subscrition_status', 'passive');
        $set($data, $columns, 'wallet', '0');
        $set($data, $columns, 'earned', '0');
        $set($data, $columns, 'who_can_send_message', 'everyone');
        $set($data, $columns, 'subscription_status', 'close');
        $set($data, $columns, $provider . '_id', $providerId);
        $set($data, $columns, 'is_banned', 0);
        $set($data, $columns, 'is_fake', 0);
        $set($data, $columns, 'created_at', $time);
        $set($data, $columns, 'updated_at', $time);

        if ($data === []) {
            return null;
        }

        $placeholders = [];
        foreach ($data as $column => $value) {
            $placeholders[$column] = ':' . $column;
        }

        $sql = 'INSERT INTO i_users (' . implode(', ', array_keys($data)) . ') VALUES (' . implode(', ', $placeholders) . ')';
        try {
            $stmt = $db->prepare($sql);
            foreach ($data as $column => $value) {
                if ($value === null) {
                    $stmt->bindValue(':' . $column, null, PDO::PARAM_NULL);
                } else {
                    $stmt->bindValue(':' . $column, $value);
                }
            }
            $stmt->execute();
            return (int)$db->lastInsertId();
        } catch (Throwable $__) {
            return null;
        }
    }

    /**
     * Start an authenticated session for the user.
     */
    function social_login_start_session(PDO $db, int $userId): void
    {
        $time = time();
        $secureHash = bin2hex(random_bytes(32));

        try {
            $stmt = $db->prepare('UPDATE i_users SET last_login_time = :time WHERE user_id = :uid');
            $stmt->execute([':time' => $time, ':uid' => $userId]);
        } catch (Throwable $__) {}

        $cookieName = $GLOBALS['cookieName'] ?? 'dizzyreel';
        if (function_exists('setSecureCookie')) {
            setSecureCookie($cookieName, $secureHash, 31556926);
        } else {
            setcookie($cookieName, $secureHash, time() + 31556926, '/');
        }

        try {
            $stmt = $db->prepare('INSERT INTO i_sessions (session_uid, session_key, session_time) VALUES (:uid, :hash, :stime)');
            $stmt->execute([
                ':uid'  => $userId,
                ':hash' => $secureHash,
                ':stime'=> $time,
            ]);
        } catch (Throwable $__) {}

        $_SESSION['iuid'] = $userId;
    }

    /**
     * Persist a flash message for next request.
     */
    function social_login_flash(string $type, string $message): void
    {
        $_SESSION['social_login_flash'][$type] = $message;
    }

    /**
     * Retrieve and remove a flash message.
     */
    function social_login_consume_flash(string $type): ?string
    {
        if (!isset($_SESSION['social_login_flash'][$type])) {
            return null;
        }
        $msg = (string)$_SESSION['social_login_flash'][$type];
        unset($_SESSION['social_login_flash'][$type]);
        return $msg;
    }

    /**
     * Finalize social login: find or create user and start session.
     *
     * @param array<string,mixed> $profile
     * @return array{status:string,user_id?:int,error?:string}
     */
    function social_login_finalize(PDO $db, string $provider, string $providerId, array $profile): array
    {
        $providerId = trim($providerId);
        if ($providerId === '') {
            return ['status' => 'error', 'error' => 'missing_provider_id'];
        }

        $user = social_login_find_user_by_provider($db, $provider, $providerId);
        if ($user === null) {
            $emailUser = social_login_find_user_by_email($db, $profile['email'] ?? null);
            if ($emailUser !== null) {
                $user = $emailUser;
                social_login_link_provider($db, (int)$user['user_id'], $provider, $providerId);
            }
        }

        if ($user === null) {
            $userId = social_login_create_user($db, $provider, $providerId, $profile);
            if ($userId === null) {
                return ['status' => 'error', 'error' => 'create_failed'];
            }
            $user = ['user_id' => $userId];
        }

        $userId = (int)$user['user_id'];
        if ($userId <= 0) {
            return ['status' => 'error', 'error' => 'invalid_user_id'];
        }

        social_login_link_provider($db, $userId, $provider, $providerId);
        social_login_start_session($db, $userId);

        return ['status' => 'success', 'user_id' => $userId];
    }

    /**
     * Helper for consistent HTTP requests (JSON expected).
     *
     * @param array<string,string> $headers
     * @return array{status:int,body:string,error?:string}
     */
    function social_login_http_request(string $method, string $url, string $body = '', array $headers = []): array
    {
        $method = strtoupper($method);
        $defaultHeaders = [];
        foreach ($headers as $key => $value) {
            $defaultHeaders[] = $key . ': ' . $value;
        }

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            if ($body !== '') {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
            }
            if ($defaultHeaders !== []) {
                curl_setopt($ch, CURLOPT_HTTPHEADER, $defaultHeaders);
            }
            curl_setopt($ch, CURLOPT_TIMEOUT, 15);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
            $responseBody = curl_exec($ch);
            $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $error = curl_errno($ch) ? curl_error($ch) : null;
            curl_close($ch);
            return [
                'status' => $status,
                'body'   => is_string($responseBody) ? $responseBody : '',
                'error'  => $error,
            ];
        }

        $context = stream_context_create([
            'http' => [
                'method'        => $method,
                'header'        => implode("\r\n", $defaultHeaders),
                'content'       => $body,
                'ignore_errors' => true,
                'timeout'       => 15,
            ],
        ]);
        $responseBody = @file_get_contents($url, false, $context);
        $status = 0;
        if (isset($http_response_header) && is_array($http_response_header)) {
            foreach ($http_response_header as $line) {
                if (preg_match('~^HTTP/[^\s]+\s+(\d+)~', $line, $m)) {
                    $status = (int)$m[1];
                    break;
                }
            }
        }
        return [
            'status' => $status,
            'body'   => is_string($responseBody) ? $responseBody : '',
        ];
    }
}
