<?php
declare(strict_types=1);

/**
 * Secure cookie helpers for consistent flags.
 * - HttpOnly: always true
 * - Secure: true when HTTPS is detected
 * - SameSite: Lax by default (suitable for most sessions)
 */
function setSecureCookie(string $name, string $value, int $ttlSeconds, string $path = '/'): bool
{
    $isHttps  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') === '443');
    $expires  = time() + $ttlSeconds;
    $options = [
        'expires'  => $expires,
        'path'     => $path,
        'domain'   => '',
        'secure'   => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ];
    return setcookie($name, $value, $options);
}

function clearSecureCookie(string $name, string $path = '/'): bool
{
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') === '443');
    $options = [
        'expires'  => time() - 3600,
        'path'     => $path,
        'domain'   => '',
        'secure'   => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ];
    return setcookie($name, '', $options);
}

