<?php
declare(strict_types=1);

/**
 * Reusable pagination renderer (CSP-safe, no inline JS)
 *
 * Usage:
 *   echo dz_render_pagination(
 *     $base_url . 'admin/index.php',
 *     ['page' => 'users', 'q' => $q, 'verified' => $verified, ...],
 *     $page,
 *     $pages,
 *     ['show_goto' => true]
 *   );
 */
function dz_render_pagination(string $basePath, array $params, int $page, int $pages, array $opts = []): string {
    if ($pages <= 1) { return ''; }

    $page = max(1, min($pages, $page));
    $radius = isset($opts['radius']) ? max(1, (int)$opts['radius']) : 1; // how many neighbors around current
    $showGoto = isset($opts['show_goto']) ? (bool)$opts['show_goto'] : false;

    $html = [];
    $html[] = '<nav class="dz-pagination" role="navigation" aria-label="Pagination">';

    // Build URL helper
    $makeUrl = function(int $target) use ($basePath, $params): string {
        $q = $params;
        $q['page_no'] = $target;
        $query = http_build_query($q);
        $url = rtrim($basePath, '?') . '?' . $query;
        return iN_HelpSecure($url, false);
    };

    // Control buttons (first/prev)
    $isFirst = ($page <= 1);
    $isLast  = ($page >= $pages);
    $firstHref = $isFirst ? '#' : $makeUrl(1);
    $prevHref  = $isFirst ? '#' : $makeUrl($page - 1);
    $nextHref  = $isLast  ? '#' : $makeUrl($page + 1);
    $lastHref  = $isLast  ? '#' : $makeUrl($pages);

    // Core block keeps controls + numbers together for responsive behavior
    $core = [];
    $core[] = '<a class="page-btn page-first'.($isFirst?' is-disabled':'').'"'.($isFirst?' aria-disabled="true" tabindex="-1"':'').' href="'.$firstHref.'" aria-label="First page">&laquo;</a>';
    $core[] = '<a class="page-btn page-prev'.($isFirst?' is-disabled':'').'"'.($isFirst?' aria-disabled="true" tabindex="-1"':'').' href="'.$prevHref.'" aria-label="Previous page">&lsaquo;</a>';

    // Numbers with ellipsis
    $core[] = '<ul class="page-list">';
    if ($pages <= (2 * $radius + 5)) {
        // show all
        for ($i = 1; $i <= $pages; $i++) {
            $core[] = page_link_item($i, $page === $i, $makeUrl($i));
        }
    } else {
        // Always show first
        $core[] = page_link_item(1, $page === 1, $makeUrl(1));
        // Left ellipsis
        $leftEdge = 2 + $radius;
        if ($page > $leftEdge) {
            $core[] = '<li class="page-ellipsis" aria-hidden="true">&hellip;</li>';
        }
        // Middle window
        $start = max(2, $page - $radius);
        $end   = min($pages - 1, $page + $radius);
        for ($i = $start; $i <= $end; $i++) {
            $core[] = page_link_item($i, $page === $i, $makeUrl($i));
        }
        // Right ellipsis
        $rightEdge = $pages - 1 - $radius;
        if ($page < $rightEdge) {
            $core[] = '<li class="page-ellipsis" aria-hidden="true">&hellip;</li>';
        }
        // Always show last
        $core[] = page_link_item($pages, $page === $pages, $makeUrl($pages));
    }
    $core[] = '</ul>';

    // Control buttons (next/last)
    $core[] = '<a class="page-btn page-next'.($isLast?' is-disabled':'').'"'.($isLast?' aria-disabled="true" tabindex="-1"':'').' href="'.$nextHref.'" aria-label="Next page">&rsaquo;</a>';
    $core[] = '<a class="page-btn page-last'.($isLast?' is-disabled':'').'"'.($isLast?' aria-disabled="true" tabindex="-1"':'').' href="'.$lastHref.'" aria-label="Last page">&raquo;</a>';

    $html[] = '<div class="page-core">' . implode("\n", $core) . '</div>';

    if ($showGoto) {
        // Build Go-to form (GET), preserving params except page_no which is input
        $html[] = '<form class="page-goto" method="get" action="'.iN_HelpSecure($basePath, false).'" role="search" aria-label="Go to page">';
        foreach ($params as $k => $v) {
            $k = htmlspecialchars((string)$k, ENT_QUOTES, 'UTF-8');
            $v = htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
            $html[] = '<input type="hidden" name="'.$k.'" value="'.$v.'" />';
        }
        $html[] = '<label class="sr-only" for="goto_page">Go to page</label>';
        $html[] = '<input class="goto-input" id="goto_page" type="number" name="page_no" min="1" max="'.(int)$pages.'" placeholder="e.g. '.min(10,$pages).'" />';
        $html[] = '<button class="goto-btn" type="submit">GO</button>';
        $html[] = '</form>';
    }

    $html[] = '</nav>';
    return implode("\n", $html);
}

function page_link_item(int $n, bool $active, string $href): string {
    $cls = 'page-link' . ($active ? ' is-active' : '');
    return '<li><a class="'.$cls.'" href="'.$href.'">'.(int)$n.'</a></li>';
}
