<?php
declare(strict_types=1);

// +----------------------------------------------------------------------
// | @author Mustafa Öztürk (mstfoztrk)
// | @author_url 1: http://www.dizzyscripts.com
// | @author_url 2: http://codecanyon.net/user/mstfoztrk
// | @author_email: socialmaterial@hotmail.com
// +----------------------------------------------------------------------
// | CreatorPulse – Monetize Short-Form Creators | Subscription, Paywall & Live Video PHP Platform
// | Copyright (c) 2021 mstfoztrk. All rights reserved.
// +----------------------------------------------------------------------

require_once __DIR__ . '/config/env_loader.php';
// Load .env from project root
EnvLoader::load(dirname(__DIR__) . '/.env');

// APP_DEBUG via env (default false)
define('APP_DEBUG', filter_var((string)env('APP_DEBUG', '0'), FILTER_VALIDATE_BOOL));

// --------------------------------------------------------------------------
// DATABASE CONFIGURATION
// --------------------------------------------------------------------------

define('DB_SERVER', (string) trim((string) env('DB_HOST', '')));
define('DB_USERNAME', (string) trim((string) env('DB_USERNAME', '')));
define('DB_PASSWORD', (string) env('DB_PASSWORD', ''));
define('DB_DATABASE', (string) trim((string) env('DB_DATABASE', '')));

// --------------------------------------------------------------------------
// DATABASE CONNECTION WITH PDO
// --------------------------------------------------------------------------
try {
    $dsn = 'mysql:host=' . DB_SERVER . ';dbname=' . DB_DATABASE . ';charset=utf8mb4';
    $db = new PDO($dsn, DB_USERNAME, DB_PASSWORD, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    $error = $e->getMessage();

    if (APP_DEBUG === true) {
        echo '<pre>
====================================================
 DATABASE CONNECTION ERROR
====================================================

We were unable to connect to your MySQL database using the
credentials provided in the connect.php file.

Error details:
' . htmlspecialchars($error) . '

Possible causes:
- Incorrect database name
- Invalid username or password
- Database does not exist on the server
- Database server is not running or refusing connection

 To fix this, open the file:
  /includes/connect.php

And check the following values:
  - DB_SERVER
  - DB_USERNAME
  - DB_PASSWORD
  - DB_DATABASE

Once you enter the correct credentials, reload the page.
====================================================
</pre>';
    }

    exit();
}

// --------------------------------------------------------------------------
// BASE URL DETECTION (DYNAMIC AND RELIABLE)
// --------------------------------------------------------------------------
$protocol        = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$rawHost         = isset($_SERVER['HTTP_HOST']) ? (string) $_SERVER['HTTP_HOST'] : '';
$rawHost         = trim($rawHost);
$host            = 'localhost';

if ($rawHost !== '') {
    // Allow only hostname, IPv6 wrapper, digits, dots, dashes, and ports.
    $sanitizedHost = preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', $rawHost);

    // Reject suspicious patterns (e.g., nested dots or empty value after strip).
    if ($sanitizedHost !== '' && !preg_match('/\.\./', $sanitizedHost)) {
        // Limit overall length to avoid header abuse.
        $sanitizedHost = substr($sanitizedHost, 0, 255);
        $host = $sanitizedHost;
    }
}

$documentRoot    = realpath($_SERVER['DOCUMENT_ROOT']);
$currentScript   = realpath($_SERVER['SCRIPT_FILENAME']);
$relativePath    = str_replace('\\', '/', str_replace($documentRoot, '', dirname($currentScript)));

$normalizedPath  = preg_replace(
    '#/(includes|request|themes|langs|src|ajax|admin|panel)(/.*)?$#i',
    '',
    $relativePath
);

$base_url = $protocol . '://' . $host . $normalizedPath . '/';

// Optional override: allow BASE_URL from environment to take precedence
try {
    $envBase = (string) env('BASE_URL', '');
    if ($envBase !== '' && filter_var($envBase, FILTER_VALIDATE_URL)) {
        $base_url = rtrim($envBase, '/') . '/';
    } else {
        // Optional DB fallback: if i_site_configurations.site_base_url exists and is valid, use it
        try {
            $res = $db->query("SELECT site_base_url FROM i_site_configurations WHERE id = 1 LIMIT 1");
            if ($res) {
                $row = $res->fetch(PDO::FETCH_ASSOC);
                if ($row && !empty($row['site_base_url']) && filter_var($row['site_base_url'], FILTER_VALIDATE_URL)) {
                    $base_url = rtrim((string)$row['site_base_url'], '/') . '/';
                }
            }
        } catch (Throwable $__) {
            // Column may not exist yet; ignore silently
        }
    }
} catch (Throwable $__) {
    // Ignore env override errors
}

// --------------------------------------------------------------------------
// FILE SYSTEM PATHS
// --------------------------------------------------------------------------
$serverDocumentRoot = $documentRoot;
$projectRoot        = realpath(dirname(__DIR__)); // actual project root (one level above /includes)
$relativePathFS     = str_replace($serverDocumentRoot, '', (string) $projectRoot);
$relativePathFS     = trim(str_replace('\\', '/', $relativePathFS), '/');
$fullUploadPath     = $serverDocumentRoot . ($relativePathFS ? "/$relativePathFS" : '');

// Canonical upload base path used across the app (keep inside project when installed in subfolder)
$uploadFile     = rtrim((string) $projectRoot, '/') . '/uploads/files/';

// --------------------------------------------------------------------------
// META BASE & COOKIE
// --------------------------------------------------------------------------
$metaBaseUrl = $base_url;
$cookieName  = 'creatorPulse';

// --------------------------------------------------------------------------
// OPTIONAL: CLOSE DB ON SHUTDOWN
// --------------------------------------------------------------------------
register_shutdown_function(function () use ($db) {
    if ($db instanceof PDO) {
        $db = null;
    }
});
