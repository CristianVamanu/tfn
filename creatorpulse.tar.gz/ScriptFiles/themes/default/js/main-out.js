(function () {
    'use strict';
    $(function () {
        $('.marker-animation').markerAnimation({
            delay: '.1s',
            duration: '2s',
            function: 'ease',
            repeat: true,
            cssFilter: function (css) {
                return css;
            },
        });
    });

    window.openSelectionModal = function () {
        document.getElementById('uploadChoiceModal').style.display = 'flex';
    };

    window.closeSelectionModal = function () {
        document.getElementById('uploadChoiceModal').style.display = 'none';
    };

    window.triggerCamera = function () {
        window.closeSelectionModal();
        document.getElementById('cameraInput').click();
    };

    window.triggerGallery = function () {
        window.closeSelectionModal();
        document.getElementById('galleryInput').click();
    };
    AOS.init();
    // Handle FAQ question clicks using delegated event
    $(document).on('click', '.faq-question', function () {
        var $currentItem = $(this).closest('.faq-item');
        var $icon = $(this).find('span');

        // If the clicked item is already open, close it
        if ($currentItem.hasClass('active')) {
            $currentItem.removeClass('active');
            $icon.text('+');
        } else {
            // Close any previously opened item
            $('.faq-item.active').removeClass('active').find('span').text('+');

            // Open the clicked item
            $currentItem.addClass('active');
            $icon.text('-');
        }
    });

    /**
     * Initialize marqueeSlider plugin if available
     */
    if (window.jQuery) {
        jQuery(function ($) {
            if (
                $('.marquee-slider').length > 0 &&
                typeof $.fn.marqueeSlider === 'function'
            ) {
                $('.marquee-slider').marqueeSlider([
                    { sensitivity: 0.1, repeatItems: true },
                    { sensitivity: 0.5, repeatItems: true },
                ]);
            }
        });
    }

    /**
     * Apply 3D hover rotation effect to tags inside the .features-tags-section
     */
    const section = document.querySelector('.features-tags-section');

    if (section) {
        const tags = section.querySelectorAll('.box-follow');

        section.addEventListener('mousemove', function (event) {
            const rect = section.getBoundingClientRect();
            const x = event.clientX - rect.left;
            const y = event.clientY - rect.top;
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;

            const rotateX = ((y - centerY) / centerY) * 20;
            const rotateY = ((x - centerX) / centerX) * 20;

            tags.forEach(function (tag) {
                tag.style.transform =
                    'rotateX(' + -rotateX + 'deg) rotateY(' + rotateY + 'deg)';
            });
        });

        section.addEventListener('mouseleave', function () {
            tags.forEach(function (tag) {
                tag.style.transform = 'rotateX(0deg) rotateY(0deg)';
            });
        });
    }
})();
