(function () {
  "use strict";

  function animateCounter(element, target, duration = 1000) {
    const rect = element.getBoundingClientRect();
    if (rect.bottom < 0 || rect.top > window.innerHeight) {
      element.textContent = target.toLocaleString('tr-TR');
      element.dataset.animated = "true";
      return;
    }

    let start = 0;
    let startTime = null;

    function updateCounter(timestamp) {
      if (!startTime) startTime = timestamp;
      const progress = timestamp - startTime;
      const increment = Math.min(progress / duration, 1);
      const current = Math.floor(increment * target);

      element.textContent = current.toLocaleString('tr-TR');

      if (progress < duration) {
        requestAnimationFrame(updateCounter);
      }
    }

    requestAnimationFrame(updateCounter);
  }


  const carousel = document.getElementById('carousel');
  if (!carousel) {
    return;
  }
  const baseItems = Array.from(document.querySelectorAll('.image-list li'));
  const viewIconTemplate = document.getElementById('viewIconTemplate');
  const viewIconMarkup = viewIconTemplate ? viewIconTemplate.innerHTML.trim() : '';
  const repeatFactor = 2;
  const imageElements = [];

  for (let i = 0; i < repeatFactor; i++) {
    baseItems.forEach(function (li) {
      const clone = li.cloneNode(true);
      imageElements.push(clone);
    });
  }

  const itemCount = imageElements.length;
  const angle = 360 / itemCount;
  const radius = 800;
  let currentAngle = 0;
  let hoveredItem = null;

  imageElements.forEach(function (li, i) {
    const url = li.getAttribute('data-img');
    const link = li.getAttribute('data-url');
    const views = li.getAttribute('data-views') || "0";
    const likes = li.getAttribute('data-likes') || "0";
    const username = li.getAttribute('data-username') || "unknown";
    const verified = li.getAttribute('data-verified') === "true";
    const showViews = (li.getAttribute('data-show-views') || 'true') === 'true';
    const showLikes = (li.getAttribute('data-show-likes') || 'true') === 'true';

    const item = document.createElement('div');
    item.className = 'carousel-item';
    item.dataset.index = i;
    item.dataset.views = views;
    item.dataset.likes = likes;
    item.dataset.showViews = showViews ? 'true' : 'false';
    item.dataset.showLikes = showLikes ? 'true' : 'false';

    const itemAngle = i * angle;
    item.style.transform = `rotateY(${itemAngle}deg) translateZ(${radius}px)`;

    const eyeIconHtml = `<span class="eye-icon">${viewIconMarkup}</span>`;

    item.innerHTML = `
      <img src="${url}" alt="" aria-hidden="true" />
      <div class="view-count">
        ${eyeIconHtml}
        <span class="view-number">0</span>
      </div>
      <div class="username-label">
        @${username}
        ${verified ? `<span class="verified-badge" title="Doğrulanmış Hesap"></span>` : ''}
      </div>
    `;

    if (!showViews) {
      item.classList.add('no-view-metric');
    }

    if (link) {
      item.addEventListener('click', function () {
        window.open(link, '_blank');
      });
    }

    item.addEventListener('mouseenter', function () {
      hoveredItem = item;
    });

    item.addEventListener('mouseleave', function () {
      hoveredItem = null;
    });

    // 👇 Prevent image dragging
    const img = item.querySelector('img');
    if (img) {
      img.addEventListener('dragstart', function (e) {
        e.preventDefault();
      });
    }

    carousel.appendChild(item);
  });

  let isDragging = false;
  let startX = 0;
  let rotationSpeed = 0.05;
  let initialBoost = true;
  let boostStartTime = performance.now();
  let targetSpeed = 0.05;

  // 👇 Mouse drag
  document.addEventListener('mousedown', function (e) {
    isDragging = true;
    startX = e.clientX;
  });

  document.addEventListener('mousemove', function (e) {
    if (!isDragging) return;
    const deltaX = e.clientX - startX;
    startX = e.clientX;
    currentAngle -= deltaX * 0.3;
    carousel.style.transform = `rotateY(${currentAngle}deg)`;
  });

  document.addEventListener('mouseup', function () {
    isDragging = false;
  });

  document.addEventListener('mouseleave', function () {
    isDragging = false;
  });

  // 👇 Mobile (touch) support
  let touchStartX = 0;

  carousel.addEventListener('touchstart', function (e) {
    if (e.touches.length === 1) {
      touchStartX = e.touches[0].clientX;
    }
  });

  carousel.addEventListener('touchmove', function (e) {
    if (e.touches.length === 1) {
      const touchX = e.touches[0].clientX;
      const deltaX = touchX - touchStartX;
      touchStartX = touchX;
      currentAngle -= deltaX * 0.3;
      carousel.style.transform = `rotateY(${currentAngle}deg)`;
    }
  });

  function updateOpacity() {
    const items = carousel.querySelectorAll('.carousel-item');
    const visibleItems = [];
    const screenCenter = window.innerWidth / 2;

    items.forEach(function (item) {
      const rect = item.getBoundingClientRect();
      if (rect.right >= 0 && rect.left <= window.innerWidth) {
        visibleItems.push({
          element: item,
          centerDistance: Math.abs((rect.left + rect.right) / 2 - screenCenter)
        });
      } else {
        item.dataset.targetOpacity = "0.2";
      }
    });

    if (visibleItems.length > 0) {
      visibleItems.sort(function (a, b) {
        return a.centerDistance - b.centerDistance;
      });

      visibleItems.forEach(function (itemObj, index) {
        const el = itemObj.element;
        if (index === 0) {
          el.dataset.targetOpacity = "1";
        } else if (index === 1 || index === 2) {
          el.dataset.targetOpacity = "0.6";
        } else {
          el.dataset.targetOpacity = "0.3";
        }

        const viewEl = el.querySelector('.view-number');
        const showViews = el.dataset.showViews !== 'false';
        const views = parseInt(el.dataset.views || "0");

        if (viewEl) {
          if (!showViews) {
            viewEl.textContent = '';
            viewEl.dataset.animated = "true";
          } else if (!viewEl.dataset.animated) {
            animateCounter(viewEl, views, 1000);
            viewEl.dataset.animated = "true";
          }
        }
      });

      if (hoveredItem) {
        items.forEach(function (item) {
          if (item === hoveredItem) {
            item.style.opacity = 1;
            item.style.transform = item.style.transform.replace(/scale\(.*?\)/, '') + ' scale(1.03)';
          } else {
            item.style.opacity = 0.6;
            item.style.transform = item.style.transform.replace(/scale\(.*?\)/, 'scale(1)');
          }
        });
      } else {
        items.forEach(function (item) {
          item.style.transform = item.style.transform.replace(/scale\(.*?\)/, 'scale(1)');
        });
      }
    }

    items.forEach(function (item) {
      const current = parseFloat(item.style.opacity || 1);
      const target = parseFloat(item.dataset.targetOpacity || 0.2);
      const newOpacity = current + (target - current) * 0.05;
      if (Math.abs(current - newOpacity) > 0.01) {
        item.style.opacity = newOpacity;
      }
    });
  }

  // Throttle updateOpacity to every 2 frames
  let frameCount = 0;
  function animateCarousel() {
    if (initialBoost) {
      const elapsed = performance.now() - boostStartTime;
      if (elapsed < 2000) {
        rotationSpeed = 0.5; // Fast initial spin
      } else {
        initialBoost = false;
      }
    }
    rotationSpeed += (targetSpeed - rotationSpeed) * 0.03;
    currentAngle -= rotationSpeed;
    carousel.style.transform = `rotateY(${currentAngle}deg)`;
    frameCount++;
    if (frameCount % 2 === 0) {
      updateOpacity();
    }
    requestAnimationFrame(animateCarousel);
  }

  animateCarousel();
  updateOpacity();

  carousel.addEventListener('mouseenter', function () {
    targetSpeed = 0;
  });

  carousel.addEventListener('mouseleave', function () {
    targetSpeed = 0.05;
  });

})();
