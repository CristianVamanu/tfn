'use strict';
(function(){
  // Utilities
  function qs(sel, root){ return (root||document).querySelector(sel); }
  function make(tag, cls){ var el=document.createElement(tag); if(cls) el.className=cls; return el; }
  function getCsrf(){ try { return document.querySelector("input[name='csrf_token']").value || ''; } catch(e){ return ''; } }
  function buildEndpoint(path){
    try {
      if (typeof window.buildUrl === 'function') {
        return window.buildUrl(path);
      }
    } catch(_){}
    try {
      var base = '';
      if (typeof site_url === 'string' && site_url) {
        base = site_url;
      } else if (typeof window.site_url === 'string' && window.site_url) {
        base = window.site_url;
      } else if (window.DZ && typeof window.DZ.__computeBase === 'function') {
        base = window.DZ.__computeBase('');
      } else {
        var origin = window.location.origin || ((window.location.protocol || 'http:') + '//' + (window.location.host || ''));
        var root = (window.location.pathname || '/').replace(/[^\/]*$/, '');
        base = origin + (root || '/');
      }
      return new URL(String(path || ''), base).toString();
    } catch(_) { return String(path || ''); }
  }

  function createSvgHeart(size){
    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox','0 0 48 48');
    svg.setAttribute('width', String(size));
    svg.setAttribute('height', String(size));
    var defs = document.createElementNS(svg.namespaceURI, 'defs');
    var grad = document.createElementNS(svg.namespaceURI, 'linearGradient');
    grad.setAttribute('id','live_heart_grad');
    grad.setAttribute('gradientTransform','rotate(35)');
    function stop(offset, color){ var s=document.createElementNS(svg.namespaceURI,'stop'); s.setAttribute('offset',offset); s.setAttribute('stop-color',color); return s; }
    grad.appendChild(stop('0%','#FF7A00'));
    grad.appendChild(stop('40%','#FF0169'));
    grad.appendChild(stop('100%','#D300C5'));
    defs.appendChild(grad);
    var g = document.createElementNS(svg.namespaceURI, 'g');
    var path = document.createElementNS(svg.namespaceURI,'path');
    path.setAttribute('fill','url(#live_heart_grad)');
    path.setAttribute('d','M34.6 3.1c-4.5 0-7.9 1.8-10.6 5.6-2.7-3.7-6.1-5.5-10.6-5.5C6 3.1 0 9.6 0 17.6c0 7.3 5.4 12 10.6 16.5.6.5 1.3 1.1 1.9 1.7l2.3 2c4.4 3.9 6.6 5.9 7.6 6.5.5.3 1.1.5 1.6.5s1.1-.2 1.6-.5c1-.6 2.8-2.2 7.8-6.8l2-1.8c.7-.6 1.3-1.2 2-1.7C42.7 29.6 48 25 48 17.6c0-8-6-14.5-13.4-14.5z');
    g.appendChild(path);
    svg.appendChild(defs); svg.appendChild(g);
    return svg;
  }

  // Spawn a mini burst of flying hearts from bottom-right of the player
  function spawnHearts($container, count){
    if (!$container) return;
    var n = Math.max(1, Math.min(8, count||3));
    for (var i=0;i<n;i++){
      (function(idx){
        setTimeout(function(){
          var h = make('span','f-heart');
          var size = 16 + Math.round(Math.random()*10); // 16-26px
          var tx = -10 - Math.round(Math.random()*40);  // left drift
          var dur = 1200 + Math.round(Math.random()*700);
          h.style.setProperty('--tx', tx + 'px');
          h.style.setProperty('--dur', dur + 'ms');
          h.style.setProperty('--scale', (0.9 + Math.random()*0.4).toFixed(2));
          h.appendChild(createSvgHeart(size));
          $container.appendChild(h);
          h.addEventListener('animationend', function(){ if (h && h.parentNode) h.parentNode.removeChild(h); });
        }, idx * 120);
      })(i);
    }
  }

  function bind(){
    var root = qs('.contents_box[data-live-id]');
    var likeBtn = qs('#liveLikeBtn', root);
    var chipBtn = qs('#liveLikeChip', root);
    var countEl = qs('#liveLikeCount', root);
    var totalEl = qs('#liveLikeTotal');
    var streamEl= qs('#liveHeartStream', root);
    if (!root) return;

    var liveIdEl = likeBtn || chipBtn;
    if (!liveIdEl) return;
    var liveId = parseInt(liveIdEl.getAttribute('data-live-id')||'0', 10) || 0;
    if (!liveId) return;

    var busy = false;
    function handle(ev, targetEl){
      ev.preventDefault();
      if (busy) return; busy = true;

      var isUnlike = (likeBtn && likeBtn.classList.contains('is-liked')) || (chipBtn && chipBtn.classList.contains('is-liked'));
      // On LIKE, launch hearts immediately for responsiveness
      if (!isUnlike) spawnHearts(streamEl, 4);

      // Optimistic UI update
      var n1 = countEl ? (parseInt((countEl.textContent||'').replace(/[^0-9]/g,'')||'0',10) || 0) : 0;
      var n2 = totalEl ? (parseInt((totalEl.textContent||'').replace(/[^0-9]/g,'')||'0',10) || 0) : n1;
      var prev = { n1: n1, n2: n2, liked: isUnlike };
      if (!isUnlike) {
        if (countEl) countEl.textContent = String(n1 + 1);
        if (totalEl) totalEl.textContent = String(n2 + 1);
        if (likeBtn) likeBtn.classList.add('is-liked');
        if (chipBtn) chipBtn.classList.add('is-liked');
      } else {
        if (countEl) countEl.textContent = String(Math.max(0, n1 - 1));
        if (totalEl) totalEl.textContent = String(Math.max(0, n2 - 1));
        if (likeBtn) likeBtn.classList.remove('is-liked');
        if (chipBtn) chipBtn.classList.remove('is-liked');
      }

      var fd = new FormData();
      fd.append('p','like_live');
      fd.append('live_id', String(liveId));
      fd.append('csrf_token', getCsrf());
      var endpoint = buildEndpoint('request/requests.php');
      fetch(endpoint, {
        method: 'POST',
        body: fd,
        credentials: 'same-origin'
      }).then(function(r){
        return r.text().then(function(txt){
          try { return JSON.parse(txt); }
          catch(_) { return { success:false, message: txt || ('HTTP '+r.status) }; }
        });
      })
        .then(function(j){
          if (j && j.success){
            if (j.liked) { if (likeBtn) likeBtn.classList.add('is-liked'); if (chipBtn) chipBtn.classList.add('is-liked'); }
            else { if (likeBtn) likeBtn.classList.remove('is-liked'); if (chipBtn) chipBtn.classList.remove('is-liked'); }
            if (typeof j.likes === 'number'){
              if (countEl) countEl.textContent = String(j.likes);
              if (totalEl) totalEl.textContent = String(j.likes);
            }
            likeBtn.setAttribute('aria-pressed', j.liked ? 'true' : 'false');
            // Broadcast to RTM so others (including owner) see hearts + count
            try {
              var ref = window.__agoraRtmRef;
              if (ref && ref.channel) {
                var msg = { type: 'live_like', liked: !!j.liked, likes: (typeof j.likes==='number'? j.likes : 0) };
                ref.channel.sendMessage({ text: JSON.stringify(msg) }).catch(function(){/* ignore */});
              }
            } catch(_){ /* ignore */ }
          } else {
            // On error, revert optimistic burst if needed (no-op)
            console.warn('like_live failed', j && j.message);
            // Revert optimistic UI
            if (countEl) countEl.textContent = String(prev.n1);
            if (totalEl) totalEl.textContent = String(prev.n2);
            if (prev.liked === false) { if (likeBtn) likeBtn.classList.remove('is-liked'); if (chipBtn) chipBtn.classList.remove('is-liked'); }
            else { if (likeBtn) likeBtn.classList.add('is-liked'); if (chipBtn) chipBtn.classList.add('is-liked'); }
          }
        })
        .catch(function(err){ console.error('live_like request failed:', err); })
        .finally(function(){ busy = false; });
    }

    if (likeBtn) likeBtn.addEventListener('click', function(ev){ handle(ev, likeBtn); });
    if (chipBtn) chipBtn.addEventListener('click', function(ev){ handle(ev, chipBtn); });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind);
  } else { bind(); }
})();
