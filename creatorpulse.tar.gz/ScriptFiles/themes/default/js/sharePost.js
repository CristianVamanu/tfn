'use strict';
(function(){
  // Debounce helper
  function debounce(fn, ms){ var t=null; return function(){ var a=arguments, s=this; clearTimeout(t); t=setTimeout(function(){ fn.apply(s,a); }, ms||250); }; }
  function qs(sel, root){ return (root||document).querySelector(sel); }
  function qsa(sel, root){ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }
  function ce(tag, cls){ var el=document.createElement(tag); if (cls) el.className=cls; return el; }
  function getCsrf(){ try { return document.querySelector("input[name='csrf_token']").value || ''; } catch(e){ return ''; } }
  var buildUrl = (window.DZ && window.DZ.buildUrl) || function(path){
    try { var base=(typeof window.site_url==='string'&&window.site_url)?window.site_url:(window.location.origin+window.location.pathname.replace(/[^\\/]*$/,'')); if(base.slice(-1)!=='/') base+='/'; return new URL(String(path||'').replace(/^\//,''), base).toString(); } catch(_) { return String(path||''); }
  };
  function toast(msg, type){
    try { window.DZ = window.DZ || {}; } catch(_){ window.DZ = {}; }
    if (typeof DZ.toast === 'function') { DZ.toast(String(msg||''), { type: type||'success' }); return; }
    // Lightweight toast (no alert fallback)
    var id='dz-toast-container';
    var c=document.getElementById(id);
    if(!c){ c=document.createElement('div'); c.id=id; c.className='dz-toast-container'; document.body.appendChild(c); }
    var el=document.createElement('div');
    el.className='dz-toast ' + (type==='error'?'is-error':(type==='info'?'is-info':'is-success'));
    el.textContent=String(msg||'');
    c.appendChild(el);
    requestAnimationFrame(function(){ el.classList.add('is-shown'); });
    setTimeout(function(){ el.classList.remove('is-shown'); setTimeout(function(){ if(el.parentNode){ el.parentNode.removeChild(el);} }, 220); }, 2200);
  }

  function openSharePopup(postId){
    var fd = new FormData();
    fd.append('p','popUp');
    fd.append('pop_type','sharePost');
    fd.append('post_id', String(postId||0));
    fd.append('csrf_token', getCsrf());
    fetch(buildUrl('request/requests.php'), { method:'POST', body: fd, credentials:'same-origin' })
      .then(function(r){ return r.json(); })
      .then(function(j){ if (j && j.status==='success' && j.html){ var root = document.getElementById('popup-root') || document.body; var wrap = document.createElement('div'); wrap.innerHTML = j.html; root.appendChild(wrap.firstElementChild); bindModal(); } })
      .catch(function(){ /* no-op */ });
  }

  // Attach to send buttons
  function onClickSend(e){
    if (e.type==='keydown' && e.key!=='Enter' && e.key!==' ') return;
    e.preventDefault(); e.stopPropagation();
    var post = this.closest('.post_');
    var pid = post ? parseInt(post.getAttribute('data-id')||'0',10) : 0;
    if (!pid) {
      try {
        var pf = this.closest('.post-footer') || this.closest('.post-footer-buttons');
        var pc = pf ? pf.querySelector('.p_comment[data-id]') : null;
        if (pc) { pid = parseInt(pc.getAttribute('data-id')||'0',10) || 0; }
      } catch(_){ }
    }
    if (!pid) return;
    openSharePopup(pid);
  }
  document.addEventListener('click', function(ev){ var t=ev.target.closest('.post-button-send, .p_send'); if (t) onClickSend.call(t, ev); });
  document.addEventListener('keydown', function(ev){ var t=ev.target.closest && ev.target.closest('.post-button-send, .p_send'); if (t) onClickSend.call(t, ev); });

  function bindModal(){
    var modal = document.getElementById('sharePostModal'); if (!modal) return;
    var list  = modal.querySelector('#shareList');
    var empty = modal.querySelector('#shareEmpty');
    var input = modal.querySelector('.share-search-input');
    var msgIn = modal.querySelector('#shareMessageInput');
    var sendB = modal.querySelector('#shareSendBtn');
    var copyB = modal.querySelector('#shareCopyBtn');
    var postId= parseInt((modal.querySelector('#sharePostId')||{}).value||'0',10)||0;
    var link  = (modal.querySelector('#shareUrl')||{}).value || '';
    var shareText = (modal.querySelector('#shareText')||{}).value || document.title || '';
    var selected = new Set();

    var searchActive = false;
    var suggestOffset = 0; var suggestPage = 10; var suggestDone = false; var isLoading = false;

    function renderUsers(items, replace){
      if (replace) list.innerHTML='';
      if (!items || !items.length){ if (replace){ empty.classList.remove('none'); } syncSendState(); return; }
      empty.classList.add('none');
      items.forEach(function(u){
        var el = ce('div','share-item'); el.setAttribute('data-id', String(u.user_id)); el.setAttribute('role','button'); el.setAttribute('tabindex','0'); el.setAttribute('aria-pressed', selected.has(u.user_id)?'true':'false');
        var av = ce('div','share-avatar'); var im = ce('img'); im.src = buildUrl(u.avatar||''); im.alt='@'+(u.username||''); av.appendChild(im); var chk=ce('div','share-check'); av.appendChild(chk);
        var nm = ce('div','share-name'); nm.textContent = u.fullname || u.username || ('User '+u.user_id);
        var ck = ce('div','share-check');
        el.appendChild(av); el.appendChild(nm);
        if (selected.has(u.user_id)) el.classList.add('is-selected');
        list.appendChild(el);
      });
      }

    var searchOffset = 0; var searchPage = 10; var searchDone = false; var searchQuery = '';
    function fetchSearch(replace){
      if (!searchQuery) return Promise.resolve();
      if (isLoading || searchDone) return Promise.resolve();
      isLoading = true;
      var fd = new FormData();
      fd.append('q', String(searchQuery||''));
      fd.append('offset', String(searchOffset));
      fd.append('limit', String(searchPage));
      fd.append('csrf_token', getCsrf());
      return fetch(buildUrl('request/search-users-dm.php'), { method:'POST', credentials:'same-origin', body: fd })
        .then(function(r){ return r.json(); })
        .then(function(j){
          var items = (j && j.status==='success' && Array.isArray(j.items)) ? j.items : [];
          renderUsers(items, !!replace && searchOffset===0);
          if (items.length === 0) { searchDone = true; }
          searchOffset += items.length;
        })
        .finally(function(){ isLoading = false; });
    }

    // Initial state: keep server-rendered suggestions; attach toggle behavior
    function buildItemPayload(el){
      var id = parseInt(el.getAttribute('data-id')||'0',10)||0; return { user_id:id, username: el.getAttribute('data-username')||'', fullname: (el.querySelector('.share-name')||{}).textContent||'', avatar: (function(){var im=el.querySelector('img'); return im?im.getAttribute('src')||'':'';})() };
    }

    function syncSendState(){
      sendB.disabled = (selected.size===0);
      try {
        var lab = (selected.size > 1) ? (window.I18N ? (I18N('share_send_separately')||'Send separately') : 'Send separately') : (window.I18N ? (I18N('chat_send')||'Send') : 'Send');
        sendB.textContent = lab;
      } catch(_){}
    }

    list.addEventListener('click', function(ev){ var it = ev.target.closest('.share-item'); if (!it) return; var id = parseInt(it.getAttribute('data-id')||'0',10)||0; if (!id) return; if (selected.has(id)) { selected.delete(id); it.classList.remove('is-selected'); it.setAttribute('aria-pressed','false'); } else { selected.add(id); it.classList.add('is-selected'); it.setAttribute('aria-pressed','true'); } syncSendState(); });
    list.addEventListener('keydown', function(ev){ if (ev.key==='Enter' || ev.key===' ') { var it=ev.target.closest('.share-item'); if (it){ ev.preventDefault(); it.click(); } } });

    input && input.addEventListener('input', debounce(function(){
      var q = input.value.trim();
      if (!q){
        // back to suggestions
        searchActive = false; suggestOffset = 0; suggestDone = false; list.innerHTML=''; searchQuery='';
        loadSuggestions(true);
        return;
      }
      searchActive = true; searchQuery = q; searchOffset = 0; searchDone = false; list.innerHTML='';
      fetchSearch(true);
    }, 300));

    function copyShareLink(){
      if (!link) return;
      if (navigator.clipboard && navigator.clipboard.writeText){
        navigator.clipboard.writeText(link).then(function(){ toast((window.I18N ? (I18N('share_link_copied') || 'Link copied') : 'Link copied')); });
      } else {
        var t=ce('input');
        t.value=link;
        document.body.appendChild(t);
        t.select();
        try{ document.execCommand('copy'); }catch(_){ }
        document.body.removeChild(t);
        toast((window.I18N ? (I18N('share_link_copied') || 'Link copied') : 'Link copied'));
      }
    }

    function externalShareUrl(type){
      var u = encodeURIComponent(link);
      var text = encodeURIComponent(shareText || document.title || '');
      var both = encodeURIComponent((shareText || document.title || '') + ' ' + link);
      if (type === 'facebook') return 'https://www.facebook.com/sharer/sharer.php?u=' + u;
      if (type === 'x') return 'https://twitter.com/intent/tweet?url=' + u + '&text=' + text;
      if (type === 'whatsapp') return 'https://api.whatsapp.com/send?text=' + both;
      if (type === 'telegram') return 'https://t.me/share/url?url=' + u + '&text=' + text;
      if (type === 'linkedin') return 'https://www.linkedin.com/sharing/share-offsite/?url=' + u;
      return '';
    }

    function handleExternalShare(type){
      if (!link) return;
      if (type === 'native') {
        if (navigator.share) {
          navigator.share({ title: document.title || shareText || '', text: shareText || '', url: link }).catch(function(){});
          return;
        }
        copyShareLink();
        return;
      }
      if (type === 'copy') {
        copyShareLink();
        return;
      }
      var url = externalShareUrl(type);
      if (!url) return;
      window.open(url, 'creatorpulse_share', 'noopener,noreferrer,width=720,height=640');
    }

    copyB && copyB.addEventListener('click', copyShareLink);
    qsa('[data-external-share]', modal).forEach(function(btn){
      if (btn.getAttribute('data-external-share') === 'native' && !navigator.share) {
        btn.classList.add('is-copy-fallback');
      }
      btn.addEventListener('click', function(){
        handleExternalShare(btn.getAttribute('data-external-share') || '');
      });
    });

    sendB && sendB.addEventListener('click', function(){
      if (!postId || selected.size===0) return;
      var to = Array.from(selected);
      var text=(msgIn && msgIn.value ? msgIn.value.trim() : '');
      var fd = new FormData();
      fd.append('p','sharePost');
      fd.append('post_id', String(postId));
      fd.append('to', JSON.stringify(to));
      fd.append('message', text);
      fd.append('csrf_token', getCsrf());
      fetch(buildUrl('request/chat.php'), { method:'POST', credentials:'same-origin', body: fd })
        .then(function(r){ return r.json(); })
        .then(function(j){
          if (j && j.status==='success'){
            toast('Sent');
            // If exactly one recipient, open chat to that user immediately
            if (to.length === 1) {
              openChatWith(to[0]);
            } else {
              try{ document.querySelector('.popUp-container')?.remove(); }catch(_){ }
            }
            // Update UI share count using server distinct total if provided
            try {
              var pid = postId;
              var post = document.querySelector('.post_[data-id="' + pid + '"]');
              if (post) {
                var c = post.querySelector('.total-send[data-role="share-count"]');
                if (c) {
                  if (typeof j.total === 'number') { c.textContent = String(j.total); }
                  else { var n = parseInt(c.textContent||'0',10)||0; c.textContent = String(n + to.length); }
                }
              }
            } catch(_){ }
          } else { toast('Failed to send', 'error'); }
        })
        .catch(function(){ toast('Failed to send', 'error'); });
    });

    function openChatWith(uid){
      var fd = new FormData();
      fd.append('p','get_live_chat');
      fd.append('id', String(uid||0));
      fd.append('csrf_token', getCsrf());
      fetch(buildUrl('request/requests.php'), { method:'POST', credentials:'same-origin', body: fd })
        .then(function(r){ return r.json(); })
        .then(function(res){
          if (res && res.status==='success' && res.html){
            try{ document.querySelector('.popUp-container')?.remove(); }catch(_){ }
            var box = document.querySelector('.current_message_box');
            var listBox = document.querySelector('.chat_list_box');
            if (box) { box.classList.remove('none'); }
            if (listBox) { listBox.innerHTML = res.html; }
            var ta = document.querySelector("textarea[name='post-text']"); if (ta) { ta.focus(); }
            try {
              if (typeof res.updated !== 'undefined' && parseInt(res.updated||0,10) > 0) {
                setTimeout(function(){ try { document.dispatchEvent(new CustomEvent('chat:refresh-status')); } catch(_){} }, 200);
              }
            } catch(_){ }
            try { document.dispatchEvent(new CustomEvent('chat:opened', { detail: { withId: res.chat_user_id || 0 } })); } catch(_){}
            // Ensure we scroll to bottom after content attaches and chat.js boots
            setTimeout(function(){ try{ var el = document.getElementById('chatScroll'); if (el) el.scrollTop = el.scrollHeight; }catch(_){ } }, 120);
            setTimeout(function(){ try{ var el2 = document.getElementById('chatScroll'); if (el2) el2.scrollTo({ top: el2.scrollHeight, behavior: 'smooth' }); }catch(_){ } }, 300);
          }
        });
    }

    // Safety: close via Escape inside modal
    modal.addEventListener('keydown', function(ev){ if (ev.key==='Escape'){ try{ document.querySelector('.popUp-container')?.remove(); }catch(_){ } } });

    // ---------- Suggestions loader ----------
    function loadSuggestions(replace){
      if (isLoading || suggestDone) return; isLoading = true;
      var fd = new FormData();
      fd.append('offset', String(suggestOffset));
      fd.append('limit', String(suggestPage));
      fd.append('csrf_token', getCsrf());
      fetch(buildUrl('request/share-suggest.php'), { method:'POST', credentials:'same-origin', body: fd })
        .then(function(r){ return r.json(); })
        .then(function(j){
          var items = (j && j.status==='success' && Array.isArray(j.items)) ? j.items : [];
          if (items.length === 0) {
            if (suggestOffset === 0 && !searchActive) {
              empty.classList.remove('none');
              empty.textContent = (window.I18N ? (I18N('share_no_friends')||'Hiç arkadaşınız yok') : 'Hiç arkadaşınız yok');
            }
            suggestDone = true; return;
          }
          renderUsers(items, !!replace && suggestOffset===0);
          suggestOffset += items.length;
          if (items.length < suggestPage) suggestDone = true;
        })
        .finally(function(){ isLoading = false; });
    }

    // Load first batch on open (suggestions)
    loadSuggestions(true);

    // Infinite scroll for both modes
    list.addEventListener('scroll', function(){
      try {
        var near = list.scrollHeight - list.scrollTop - list.clientHeight;
        if (near > 120) return;
        if (searchActive) { fetchSearch(false); }
        else {
          if (suggestDone && input && input.value && input.value.trim().length > 0) {
            // Suggestions finished, user typed a search; switch to search mode automatically
            searchActive = true; searchQuery = input.value.trim(); searchOffset = 0; searchDone = false; list.innerHTML='';
            fetchSearch(true);
          } else {
            loadSuggestions(false);
          }
        }
      } catch(_){ }
    });
  }
})();
