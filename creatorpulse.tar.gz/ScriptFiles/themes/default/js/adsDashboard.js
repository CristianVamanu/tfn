(function(){
  'use strict';

  var body = document.body;
  if (!body || body.dataset.layout !== 'advertisements') {
    return;
  }

  function onReady(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  onReady(function(){
    var I18N = window.I18N || function(key){ return key; };
    var showToast = typeof window.showToast === 'function'
      ? window.showToast
      : function(message, type){
          if (type === 'error') {
            console.error(message);
          } else {
            console.log(message);
          }
        };

    var buildUrl = typeof window.buildUrl === 'function'
      ? window.buildUrl
      : function(url){ return url; };

    var csrfInput = document.querySelector('input[name="csrf_token"]');
    if (!csrfInput) {
      return;
    }

    var csrfToken = csrfInput.value;
    var summaryRoot = document.querySelector('[data-ads-summary]');
    var summaryCards = summaryRoot ? Array.from(summaryRoot.querySelectorAll('[data-summary-card]')) : [];
    var chartCanvas = document.getElementById('adsPerformanceChart');
    var chartLoading = document.querySelector('[data-ads-chart-loading]');
    var chartError = document.querySelector('[data-ads-chart-error]');
    var rangeContainer = document.querySelector('[data-ads-range]');
    var rangeButtons = rangeContainer ? Array.from(rangeContainer.querySelectorAll('.ads-range-btn')) : [];
    var tableCard = document.querySelector('[data-ads-table]');
    var tableScroll = tableCard ? tableCard.querySelector('.table-card__scroll') : null;
    var tableBody = tableCard ? tableCard.querySelector('[data-ads-table-body]') : null;
    var tableSummary = tableCard ? tableCard.querySelector('[data-ads-table-summary]') : null;
    var tableEmpty = tableCard ? tableCard.querySelector('[data-ads-empty]') : null;
    var tableError = tableCard ? tableCard.querySelector('[data-ads-error]') : null;

    var editModal = document.getElementById('adsEditCopyModal');
    var editForm = editModal ? editModal.querySelector('[data-ads-edit-form]') : null;
    var editTitleInput = editModal ? editModal.querySelector('[data-ads-edit-title]') : null;
    var editDescriptionInput = editModal ? editModal.querySelector('[data-ads-edit-description]') : null;
    var editLinkInput = editModal ? editModal.querySelector('[data-ads-edit-link]') : null;
    var editSaveButton = editModal ? editModal.querySelector('[data-ads-edit-save]') : null;
    var editCancelButton = editModal ? editModal.querySelector('[data-ads-edit-cancel]') : null;
    var editCloseButton = editModal ? editModal.querySelector('[data-ads-edit-close]') : null;

    var dashboardData = null;
    var chartInstance = null;
    var chartDataStore = {};
    var currentRange = 'daily';
    var modalState = { adId: null, returnFocus: null };
    var currency = { code: '', symbol: '' };
    var currencyFormat = (window.DZ && window.DZ.currencyFormat) || {};
    var currencyPrecision = (typeof currencyFormat.decimalPlaces === 'number')
      ? Math.max(0, Math.min(8, currencyFormat.decimalPlaces))
      : 2;
    var pendingToggle = new Set();

    var STATUS_BADGE_CLASS = {
      active: 'status-badge--success',
      paused: 'status-badge--pending',
      draft: 'status-badge--neutral',
      ended: 'status-badge--danger'
    };

    function escapeHtml(value) {
      var div = document.createElement('div');
      div.textContent = value == null ? '' : String(value);
      return div.innerHTML;
    }

    function formatNumber(value, decimals) {
      var precision = typeof decimals === 'number' ? decimals : 0;
      var num = Number(value);
      if (!isFinite(num)) { num = 0; }
      var decimalSep = currencyFormat.decimalSep === ',' ? ',' : '.';
      var thousandsSep = typeof currencyFormat.thousandsSep === 'string' ? currencyFormat.thousandsSep : ',';
      var fixed = num.toFixed(precision);
      var parts = fixed.split('.');
      if (thousandsSep) {
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandsSep);
      }
      return parts.length > 1 ? parts[0] + decimalSep + parts[1] : parts[0];
    }

    function formatMoney(amount) {
      var num = Number(amount);
      if (!isFinite(num)) { num = 0; }
      var cfg = currencyFormat || {};
      var code = currency.code || cfg.code || 'USD';
      var symbol = currency.symbol || cfg.symbol || '';
      var decimalSep = cfg.decimalSep === ',' ? ',' : '.';
      var thousandsSep = typeof cfg.thousandsSep === 'string' ? cfg.thousandsSep : ',';
      if (thousandsSep === decimalSep) { thousandsSep = ''; }
      var precision = Math.min(Math.max(0, currencyPrecision), 8);
      var fixed = Math.abs(num).toFixed(precision);
      var parts = fixed.split('.');
      if (thousandsSep) {
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandsSep);
      }
      var joined = parts.length > 1 ? parts[0] + decimalSep + parts[1] : parts[0];
      if (num < 0) { joined = '-' + joined; }
      var position = (cfg.position || 'left').toLowerCase();
      var symValid = symbol && symbol !== code && symbol.length <= 4;
      if (!symValid) { return joined + (code ? ' ' + code : ''); }
      switch (position) {
        case 'left': return symbol + joined;
        case 'left_space': return symbol + ' ' + joined;
        case 'right': return joined + symbol;
        case 'right_space': return joined + ' ' + symbol;
        default: return symbol + joined;
      }
    }

    function normalizeAdLink(url) {
      if (!url) { return ''; }
      var trimmed = String(url).trim();
      if (trimmed === '') { return ''; }
      if (!/^https?:\/\//i.test(trimmed)) {
        trimmed = 'https://' + trimmed;
      }
      try {
        var parsed = new URL(trimmed);
        if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
          return '';
        }
        return parsed.toString();
      } catch (error) {
        return '';
      }
    }

    function translate(key, fallback, params) {
      var raw = I18N(key);
      if (!raw || raw === key) {
        raw = fallback || key;
      }
      if (params) {
        Object.keys(params).forEach(function(token){
          raw = raw.replace(new RegExp('\\{' + token + '\\}', 'g'), params[token]);
        });
      }
      return raw;
    }

    function toggleClass(el, className, force) {
      if (!el || !el.classList) { return; }
      if (force === undefined) {
        el.classList.toggle(className);
      } else if (force) {
        el.classList.add(className);
      } else {
        el.classList.remove(className);
      }
    }

    function setSummaryLoading(isLoading) {
      summaryCards.forEach(function(card){
        toggleClass(card, 'is-loading', isLoading);
        var amountEl = card.querySelector('[data-summary-value]');
        if (amountEl) {
          amountEl.textContent = isLoading ? I18N('ads_dashboard_loading') : amountEl.textContent;
        }
        var metaEl = card.querySelector('[data-summary-meta]');
        if (metaEl && isLoading) {
          metaEl.textContent = '';
        }
      });
    }

    function setChartLoadingState() {
      toggleClass(chartLoading, 'none', false);
      toggleClass(chartError, 'none', true);
    }

    function setChartErrorState() {
      toggleClass(chartLoading, 'none', true);
      toggleClass(chartError, 'none', false);
    }

    function setTableState(state) {
      if (!tableBody) { return; }
      if (state === 'loading') {
        tableBody.innerHTML = renderPlaceholderRow(I18N('ads_dashboard_loading'));
        if (tableSummary) {
          tableSummary.textContent = I18N('ads_dashboard_loading');
        }
        toggleClass(tableScroll, 'none', false);
        toggleClass(tableEmpty, 'none', true);
        toggleClass(tableError, 'none', true);
      } else if (state === 'empty') {
        tableBody.innerHTML = '';
        toggleClass(tableScroll, 'none', true);
        toggleClass(tableEmpty, 'none', false);
        toggleClass(tableError, 'none', true);
      } else if (state === 'error') {
        tableBody.innerHTML = '';
        toggleClass(tableScroll, 'none', true);
        toggleClass(tableEmpty, 'none', true);
        toggleClass(tableError, 'none', false);
        if (tableSummary) {
          tableSummary.textContent = I18N('ads_dashboard_fetch_failed');
        }
      } else if (state === 'data') {
        toggleClass(tableScroll, 'none', false);
        toggleClass(tableEmpty, 'none', true);
        toggleClass(tableError, 'none', true);
      }
    }

    function renderPlaceholderRow(text) {
      return '<div class="ads-grid ads-grid-row ads-placeholder-row"><div class="ads-cell-full">' + escapeHtml(text || '') + '</div></div>';
    }

    function buildRequest(action, extra) {
      var fd = new FormData();
      fd.append('p', action);
      fd.append('csrf_token', csrfToken);
      if (extra) {
        Object.keys(extra).forEach(function(key){
          fd.append(key, extra[key]);
        });
      }
      return fd;
    }

    function openAdCreationPopup(mode) {
      var popType = mode === 'video' ? 'createAdsVideo' : 'createAdsImage';
      var trigger = document.createElement('button');
      trigger.type = 'button';
      trigger.className = 'new_item';
      trigger.dataset.pop = popType;
      trigger.style.display = 'none';
      document.body.appendChild(trigger);
      try {
        var evt = new MouseEvent('click', { bubbles: true, cancelable: true });
        trigger.dispatchEvent(evt);
      } catch (err) {
        if (typeof window.jQuery === 'function') {
          window.jQuery(trigger).trigger('click');
        }
      }
      window.setTimeout(function(){ trigger.remove(); }, 0);
    }

    function fetchJson(url, formData) {
      return fetch(url, { method: 'POST', body: formData })
        .then(function(response){ return response.json(); });
    }

    function ensureChart(rangeKey, dataset) {
      if (!chartCanvas) { return; }
      if (typeof Chart === 'undefined') {
        setTimeout(function(){ ensureChart(rangeKey, dataset); }, 50);
        return;
      }

      if (!chartInstance) {
        var ctx = chartCanvas.getContext('2d');
        if (!ctx) {
          setChartErrorState();
          return;
        }
        chartInstance = new Chart(ctx, {
          type: 'line',
          data: {
            labels: dataset.labels || [],
            datasets: [
              {
                label: I18N('ads_dashboard_chart_views'),
                data: dataset.views || [],
                borderColor: '#1f4bd8',
                backgroundColor: 'rgba(31,75,216,0.12)',
                tension: 0.25,
                fill: true,
                yAxisID: 'y'
              },
              {
                label: 'Clicks',
                data: dataset.clicks || [],
                borderColor: '#7c3aed',
                backgroundColor: 'rgba(124,58,237,0.18)',
                borderDash: [6, 4],
                tension: 0.25,
                fill: false,
                yAxisID: 'y'
              },
              {
                label: I18N('ads_dashboard_chart_spend'),
                data: dataset.spend || [],
                borderColor: '#24b8c7',
                backgroundColor: 'rgba(36,184,199,0.15)',
                tension: 0.25,
                fill: true,
                yAxisID: 'y1'
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: {
              legend: { position: 'bottom' },
              tooltip: {
                callbacks: {
                  label: function(context){
                    var label = context.dataset.label || '';
                    var value = context.parsed.y;
                    if (context.dataset.yAxisID === 'y1') {
                      return label + ': ' + formatMoney(value);
                    }
                    return label + ': ' + formatNumber(value);
                  }
                }
              }
            },
            scales: {
              y: {
                beginAtZero: true,
                ticks: {
                  callback: function(value){ return formatNumber(value); }
                }
              },
              y1: {
                beginAtZero: true,
                position: 'right',
                grid: { drawOnChartArea: false },
                ticks: {
                  callback: function(value){ return formatMoney(value); }
                }
              }
            }
          }
        });
      } else {
        chartInstance.data.labels = dataset.labels || [];
        chartInstance.data.datasets[0].label = I18N('ads_dashboard_chart_views');
        chartInstance.data.datasets[0].data = dataset.views || [];
        chartInstance.data.datasets[1].label = 'Clicks';
        chartInstance.data.datasets[1].data = dataset.clicks || [];
        chartInstance.data.datasets[2].label = I18N('ads_dashboard_chart_spend');
        chartInstance.data.datasets[2].data = dataset.spend || [];
        chartInstance.update();
      }
    }

    function updateSummary(summary) {
      if (!summaryRoot || !summary) {
        return;
      }
      summaryCards.forEach(function(card){
        var key = card.getAttribute('data-summary-card');
        var amountEl = card.querySelector('[data-summary-value]');
        var metaEl = card.querySelector('[data-summary-meta]');
        if (amountEl) {
          if (key === 'budget' || key === 'spent' || key === 'remaining') {
            var field = key === 'budget' ? 'totalBudget' : (key === 'spent' ? 'totalSpent' : 'totalRemaining');
            amountEl.textContent = formatMoney(summary[field] || 0);
          } else {
            var fieldName = key === 'active' ? 'active' : 'paused';
            amountEl.textContent = formatNumber(summary[fieldName] || 0);
          }
        }
        if (metaEl) {
          if (key === 'budget') {
            metaEl.textContent = I18N('ads_dashboard_chart_views') + ': ' + formatNumber(summary.impressions || 0);
          } else if (key === 'spent') {
            metaEl.textContent = I18N('ads_dashboard_table_clicks') + ': ' + formatNumber(summary.clicks || 0);
          } else {
            metaEl.textContent = '';
          }
        }
        toggleClass(card, 'is-loading', false);
      });
    }

    function updateTableSummary(summary) {
      if (!tableSummary || !summary) {
        return;
      }
      var parts = [
        I18N('ads_dashboard_total_active') + ': ' + formatNumber(summary.active || 0),
        I18N('ads_dashboard_total_paused') + ': ' + formatNumber(summary.paused || 0),
        I18N('ads_dashboard_total_budget') + ': ' + formatMoney(summary.totalBudget || 0),
        I18N('ads_dashboard_total_spent') + ': ' + formatMoney(summary.totalSpent || 0),
        I18N('ads_dashboard_total_remaining') + ': ' + formatMoney(summary.totalRemaining || 0)
      ];
      tableSummary.textContent = parts.join(' | ');
    }

    function renderTable(ads) {
      if (!tableBody) {
        return;
      }
      if (!ads || ads.length === 0) {
        tableBody.innerHTML = '';
        setTableState('empty');
        return;
      }

      var fragment = document.createDocumentFragment();
      ads.forEach(function(ad){
        var row = document.createElement('div');
        row.className = 'ads-grid ads-grid-row';
        row.setAttribute('data-ad-id', String(ad.ad_id));
        row.appendChild(buildCampaignCell(ad));
        row.appendChild(buildBudgetCell(ad));
        row.appendChild(buildPerformanceCell(ad));
        row.appendChild(buildActionsCell(ad));
        fragment.appendChild(row);
      });

      tableBody.innerHTML = '';
      tableBody.appendChild(fragment);
      setTableState('data');
    }

    function buildStatusBadge(status) {
      var key = (status || '').toLowerCase();
      var cls = STATUS_BADGE_CLASS[key] || 'status-badge--neutral';
      var labelKey = 'ads_status_' + key;
      var fallback = key ? key.charAt(0).toUpperCase() + key.slice(1) : status;
      var text = translate(labelKey, fallback || labelKey);
      return '<span class="status-badge ' + cls + '" data-status-badge="1">' + escapeHtml(text) + '</span>';
    }

    function buildCampaignCell(ad) {
      var cell = document.createElement('div');
      cell.className = 'ads-campaign-cell';

      var title = document.createElement('div');
      title.className = 'ads-campaign-title';
      var safeTitle = (ad.title || '').trim();
      title.textContent = safeTitle !== '' ? safeTitle : translate('ads_dashboard_untitled', 'Untitled advertisement');
      cell.appendChild(title);

      var status = document.createElement('div');
      status.className = 'ads-campaign-status';
      status.innerHTML = buildStatusBadge(ad.status);
      cell.appendChild(status);

      var mediaType = (ad.media_type || '').toLowerCase();
      if (mediaType) {
        var mediaLabel = document.createElement('div');
        mediaLabel.className = 'ads-campaign-meta';
        mediaLabel.textContent = translate('ads_dashboard_media_' + mediaType, mediaType);
        cell.appendChild(mediaLabel);
      }

      if (ad.ad_link) {
        var linkWrap = document.createElement('div');
        linkWrap.className = 'ads-campaign-link-wrap';
        var link = document.createElement('a');
        link.className = 'ads-campaign-link';
        link.href = ad.ad_link;
        link.target = '_blank';
        link.rel = 'nofollow noopener';
        link.textContent = ad.ad_link.replace(/^https?:\/\//i, '');
        linkWrap.appendChild(link);
        cell.appendChild(linkWrap);
      }

      return cell;
    }

    function buildBudgetCell(ad) {
      var cell = document.createElement('div');
      cell.className = 'ads-budget-cell';

      var budget = Number(ad.total_budget) || 0;
      var spent = Number(ad.spent) || 0;
      var remainingRaw = Number(ad.remaining);
      var remaining = Number.isFinite(remainingRaw) ? remainingRaw : Math.max(0, budget - spent);

      var list = document.createElement('div');
      list.className = 'ads-budget-list';

      list.appendChild(createBudgetLine('ads_dashboard_budget_allocated', 'Allocated', formatMoney(budget)));
      list.appendChild(createBudgetLine('ads_dashboard_budget_spent', 'Spent', formatMoney(spent)));

      var meter = buildBudgetMeter(budget, spent);
      list.appendChild(meter);

      if (budget > 0) {
        var percentSpent = Math.round((spent / budget) * 100);
        percentSpent = Math.max(0, percentSpent);
        var spentMeta = document.createElement('div');
        spentMeta.className = 'ads-spent-meta';
        spentMeta.textContent = translate('ads_dashboard_spent_meta', '{percent}% of {budget}', {
          percent: String(Math.min(999, percentSpent)),
          budget: formatMoney(budget)
        });
        list.appendChild(spentMeta);

        if (percentSpent > 100) {
          var overMeta = document.createElement('div');
          overMeta.className = 'ads-spent-over';
          overMeta.textContent = translate('ads_dashboard_over_budget_meta', 'Over by {amount}', {
            amount: formatMoney(Math.max(0, spent - budget))
          });
          list.appendChild(overMeta);
        }
      } else if (spent > 0) {
        var noBudget = document.createElement('div');
        noBudget.className = 'ads-spent-meta';
        noBudget.textContent = translate('ads_dashboard_no_budget', 'Budget not set');
        list.appendChild(noBudget);
      }

      list.appendChild(createBudgetLine('ads_dashboard_budget_remaining', 'Remaining', formatMoney(Math.max(0, remaining))));

      if (budget > 0) {
        var remainingPercent = Math.max(0, 100 - Math.round((spent / budget) * 100));
        var remainingMeta = document.createElement('div');
        remainingMeta.className = 'ads-remaining-meta';
        remainingMeta.textContent = translate('ads_dashboard_remaining_meta', '{percent}% remaining', {
          percent: String(remainingPercent)
        });
        list.appendChild(remainingMeta);
      }

      cell.appendChild(list);
      return cell;
    }

    function createBudgetLine(labelKey, fallback, valueText) {
      var line = document.createElement('div');
      line.className = 'ads-budget-line';

      var label = document.createElement('span');
      label.className = 'ads-budget-label';
      label.textContent = translate(labelKey, fallback);
      line.appendChild(label);

      var value = document.createElement('span');
      value.className = 'ads-budget-value';
      value.textContent = valueText;
      line.appendChild(value);

      return line;
    }

    function buildBudgetMeter(budget, spent) {
      var meter = document.createElement('div');
      meter.className = 'ads-budget-meter';
      var fill = document.createElement('div');
      fill.className = 'ads-budget-meter__fill';

      var percent = 0;
      if (budget > 0) {
        percent = (spent / budget) * 100;
      } else {
        percent = spent > 0 ? 100 : 0;
      }
      fill.style.width = Math.min(100, Math.max(0, percent)) + '%';
      if (budget > 0 && percent > 100) {
        fill.classList.add('is-over');
      }

      meter.appendChild(fill);
      meter.setAttribute('aria-hidden', 'true');
      return meter;
    }

    function buildPerformanceCell(ad) {
      var cell = document.createElement('div');
      cell.className = 'ads-performance-cell';

      var list = document.createElement('div');
      list.className = 'ads-performance-list';
      list.appendChild(buildPerformanceMetric('ads_dashboard_metric_impressions', 'Total impressions', ad.views));
      list.appendChild(buildPerformanceMetric('ads_dashboard_metric_clicks', 'Total clicks', ad.clicks));
      cell.appendChild(list);

      return cell;
    }

    function buildPerformanceMetric(labelKey, fallback, value) {
      var line = document.createElement('div');
      line.className = 'ads-performance-line';

      var label = document.createElement('span');
      label.className = 'ads-performance-label';
      label.textContent = translate(labelKey, fallback);
      line.appendChild(label);

      var val = document.createElement('span');
      val.className = 'ads-performance-value';
      val.textContent = formatNumber(value);
      line.appendChild(val);

      return line;
    }

    function buildActionsCell(ad) {
      var cell = document.createElement('div');
      cell.className = 'ads-actions-cell';

      var wrapper = document.createElement('div');
      wrapper.className = 'ads-actions';

      var canToggle = ad.status === 'active' || ad.status === 'paused';
      var toggleGroup = document.createElement('div');
      toggleGroup.className = 'ads-toggle-group' + (canToggle ? '' : ' is-disabled');

      if (canToggle) {
        var toggleLabel = document.createElement('label');
        toggleLabel.className = 'el-switch el-switch-sm' + (ad.status === 'active' ? ' el-switch-green' : '');
        toggleLabel.setAttribute('aria-label', translate('ads_dashboard_toggle_hint', 'Toggle advertisement status'));

        var input = document.createElement('input');
        input.type = 'checkbox';
        input.className = 'ads-status-toggle';
        input.dataset.adId = String(ad.ad_id);
        input.checked = ad.status === 'active';
        toggleLabel.appendChild(input);

        var span = document.createElement('span');
        span.className = 'el-switch-style';
        toggleLabel.appendChild(span);
        toggleGroup.appendChild(toggleLabel);
      }

      var stateLabel = document.createElement('span');
      stateLabel.className = 'ads-toggle-label';
      stateLabel.textContent = translate('ads_status_' + ad.status, ad.status);
      toggleGroup.appendChild(stateLabel);

      wrapper.appendChild(toggleGroup);

      var editBtn = document.createElement('button');
      editBtn.type = 'button';
      editBtn.className = 'ads-action-btn ads-edit-btn';
      editBtn.dataset.adId = String(ad.ad_id);
      editBtn.textContent = translate('ads_dashboard_edit_copy', 'Edit advertisement');
      wrapper.appendChild(editBtn);

      cell.appendChild(wrapper);
      return cell;
    }

    function updateRowStatus(adId, status) {
      var row = tableBody ? tableBody.querySelector('[data-ad-id="' + adId + '"]') : null;
      if (!row) { return; }
      var statusContainer = row.querySelector('.ads-campaign-status');
      if (statusContainer) {
        statusContainer.innerHTML = buildStatusBadge(status);
      }
      var toggleEl = row.querySelector('.ads-status-toggle');
      if (toggleEl) {
        toggleEl.checked = status === 'active';
        toggleEl.disabled = !(status === 'active' || status === 'paused');
        var label = toggleEl.closest('.el-switch');
        if (label) {
          toggleClass(label, 'el-switch-green', status === 'active');
          label.setAttribute('aria-label', translate('ads_dashboard_toggle_hint', 'Toggle advertisement status'));
        }
      }
      var toggleGroup = row.querySelector('.ads-toggle-group');
      if (toggleGroup) {
        toggleGroup.classList.toggle('is-disabled', !(status === 'active' || status === 'paused'));
      }
      var stateLabel = row.querySelector('.ads-toggle-label');
      if (stateLabel) {
        stateLabel.textContent = translate('ads_status_' + status, status);
      }
    }

    function updateRowTitle(adId, title) {
      var row = tableBody ? tableBody.querySelector('[data-ad-id="' + adId + '"]') : null;
      if (!row) { return; }
      var titleCell = row.querySelector('.ads-campaign-title');
      if (titleCell) {
        var safeTitle = (title || '').trim();
        titleCell.textContent = safeTitle !== '' ? safeTitle : translate('ads_dashboard_untitled', 'Untitled advertisement');
      }
    }

    function updateRowLink(adId, link) {
      if (!tableBody) { return; }
      var row = tableBody.querySelector('[data-ad-id="' + adId + '"]');
      if (!row) { return; }
      var cell = row.querySelector('.ads-campaign-cell');
      if (!cell) { return; }
      var wrap = cell.querySelector('.ads-campaign-link-wrap');
      if (!link) {
        if (wrap) { wrap.remove(); }
        return;
      }
      if (!wrap) {
        wrap = document.createElement('div');
        wrap.className = 'ads-campaign-link-wrap';
        cell.appendChild(wrap);
      }
      var anchor = wrap.querySelector('.ads-campaign-link');
      if (!anchor) {
        anchor = document.createElement('a');
        anchor.className = 'ads-campaign-link';
        anchor.target = '_blank';
        anchor.rel = 'nofollow noopener';
        wrap.appendChild(anchor);
      }
      anchor.href = link;
      anchor.textContent = link.replace(/^https?:\/\//i, '');
    }

    function getAdById(adId) {
      if (!dashboardData || !dashboardData.ads) { return null; }
      for (var i = 0; i < dashboardData.ads.length; i++) {
        if (Number(dashboardData.ads[i].ad_id) === Number(adId)) {
          return dashboardData.ads[i];
        }
      }
      return null;
    }

    function adjustSummaryForStatusChange(prevStatus, nextStatus) {
      if (!dashboardData || !dashboardData.summary) {
        return;
      }
      var summary = dashboardData.summary;
      if (prevStatus === nextStatus) {
        return;
      }
      if (prevStatus === 'active') {
        summary.active = Math.max(0, (summary.active || 0) - 1);
      }
      if (prevStatus === 'paused') {
        summary.paused = Math.max(0, (summary.paused || 0) - 1);
      }
      if (nextStatus === 'active') {
        summary.active = (summary.active || 0) + 1;
      }
      if (nextStatus === 'paused') {
        summary.paused = (summary.paused || 0) + 1;
      }
    }

    function openEditModal(ad) {
      if (!editModal || !editTitleInput || !editDescriptionInput) { return; }
      modalState.adId = ad.ad_id;
      modalState.returnFocus = document.activeElement;
      editTitleInput.value = ad.title || '';
      editDescriptionInput.value = ad.description || '';
      if (editLinkInput) {
        editLinkInput.value = ad.ad_link || '';
      }
      toggleClass(editModal, 'none', false);
      setTimeout(function(){ editTitleInput.focus(); }, 0);
    }

    function closeEditModal() {
      if (!editModal) { return; }
      toggleClass(editModal, 'none', true);
      modalState.adId = null;
      if (editLinkInput) { editLinkInput.value = ''; }
      if (modalState.returnFocus && typeof modalState.returnFocus.focus === 'function') {
        modalState.returnFocus.focus();
      }
      modalState.returnFocus = null;
    }

    function bindModalEvents() {
      if (!editModal) { return; }
      editModal.addEventListener('click', function(event){
        if (event.target === editModal) {
          closeEditModal();
        }
      });
      if (editCancelButton) {
        editCancelButton.addEventListener('click', function(){ closeEditModal(); });
      }
      if (editCloseButton) {
        editCloseButton.addEventListener('click', function(){ closeEditModal(); });
      }
      document.addEventListener('keydown', function(event){
        if (event.key === 'Escape' && editModal && !editModal.classList.contains('none')) {
          closeEditModal();
        }
      });
      if (editForm && editSaveButton) {
        editForm.addEventListener('submit', function(event){
          event.preventDefault();
          if (!modalState.adId) {
            closeEditModal();
            return;
          }
          var title = (editTitleInput.value || '').trim();
          var description = (editDescriptionInput.value || '').trim();
          var linkRaw = editLinkInput ? editLinkInput.value || '' : '';
          var normalizedLink = normalizeAdLink(linkRaw);
          if (title === '') {
            showToast(I18N('ads_dashboard_copy_update_failed'), 'error');
            return;
          }
          if (!normalizedLink) {
            showToast(I18N('ads_enter_destination_url') || 'Please enter a valid destination URL.', 'error');
            return;
          }
          editSaveButton.disabled = true;
          var formData = buildRequest('ads_update_copy', {
            ad_id: modalState.adId,
            title: title,
            description: description,
            ad_link: normalizedLink
          });
          fetchJson(buildUrl('request/requests.php'), formData)
            .then(function(response){
              if (response && response.status === 'success' && response.data) {
                var ad = getAdById(modalState.adId);
                if (ad) {
                  ad.title = response.data.title;
                  ad.description = response.data.description;
                  ad.ad_link = response.data.ad_link || normalizedLink;
                  updateRowTitle(modalState.adId, ad.title);
                  updateRowLink(modalState.adId, ad.ad_link);
                }
                showToast(I18N('ads_dashboard_copy_updated'));
                closeEditModal();
              } else {
                showToast(I18N('ads_dashboard_copy_update_failed'), 'error');
              }
            })
            .catch(function(){
              showToast(I18N('ads_dashboard_copy_update_failed'), 'error');
            })
            .finally(function(){
              editSaveButton.disabled = false;
            });
        });
      }
    }

    function handleTableInteractions() {
      if (!tableBody) { return; }
      tableBody.addEventListener('change', function(event){
        var target = event.target;
        if (!target || !target.classList || !target.classList.contains('ads-status-toggle')) {
          return;
        }
        var adId = Number(target.dataset.adId);
        if (!adId || pendingToggle.has(adId)) {
          target.checked = !target.checked;
          return;
        }
        var ad = getAdById(adId);
        if (!ad) {
          target.checked = !target.checked;
          return;
        }
        var nextStatus = target.checked ? 'active' : 'paused';
        var prevStatus = ad.status;
        pendingToggle.add(adId);
        target.disabled = true;
        var formData = buildRequest('ads_update_status', {
          ad_id: adId,
          new_status: nextStatus
        });
        fetchJson(buildUrl('request/requests.php'), formData)
          .then(function(response){
            if (response && response.status === 'success') {
              ad.status = nextStatus;
              updateRowStatus(adId, nextStatus);
              adjustSummaryForStatusChange(prevStatus, nextStatus);
              updateSummary(dashboardData.summary);
              updateTableSummary(dashboardData.summary);
              showToast(I18N('ads_dashboard_status_updated'));
            } else {
              target.checked = prevStatus === 'active';
              updateRowStatus(adId, prevStatus);
              showToast(I18N('ads_dashboard_status_update_failed'), 'error');
            }
          })
          .catch(function(){
            target.checked = prevStatus === 'active';
            updateRowStatus(adId, prevStatus);
            showToast(I18N('ads_dashboard_status_update_failed'), 'error');
          })
          .finally(function(){
            pendingToggle.delete(adId);
            var current = tableBody.querySelector('.ads-status-toggle[data-ad-id="' + adId + '"]');
            if (current) {
              current.disabled = !(ad.status === 'active' || ad.status === 'paused');
            }
          });
      });

      tableBody.addEventListener('click', function(event){
        var button = event.target && event.target.closest('.ads-edit-btn');
        if (!button) {
          return;
        }
        var adId = Number(button.dataset.adId);
        var ad = getAdById(adId);
        if (!ad) {
          return;
        }
        openEditModal(ad);
      });
    }

    function setActiveRange(rangeKey) {
      currentRange = rangeKey;
      rangeButtons.forEach(function(btn){
        var isActive = btn.dataset.range === rangeKey;
        toggleClass(btn, 'is-active', isActive);
        btn.setAttribute('aria-selected', isActive ? 'true' : 'false');
      });
      if (chartDataStore[rangeKey]) {
        ensureChart(rangeKey, chartDataStore[rangeKey]);
      }
    }

    function bindRangeButtons() {
      if (!rangeContainer) { return; }
      rangeButtons.forEach(function(button){
        button.addEventListener('click', function(){
          var range = button.dataset.range || 'daily';
          if (range === currentRange) {
            return;
          }
          setActiveRange(range);
        });
      });
    }

    function bindCreateAdButtons() {
      var triggers = document.querySelectorAll('[data-ads-empty-cta]');
      if (!triggers.length) { return; }
      triggers.forEach(function(btn){
        btn.addEventListener('click', function(){
          var intent = (btn.getAttribute('data-ads-empty-cta') || 'image').toLowerCase();
          openAdCreationPopup(intent === 'video' ? 'video' : 'image');
        });
      });
    }

    function loadDashboard() {
      setSummaryLoading(true);
      setChartLoadingState();
      setTableState('loading');

      var formData = buildRequest('ads_dashboard_data');
      fetchJson(buildUrl('request/requests.php'), formData)
        .then(function(response){
          if (!response || response.status !== 'success' || !response.data) {
            throw new Error('bad-response');
          }
          dashboardData = response.data;
          chartDataStore = dashboardData.charts || {};
          currency.code = (dashboardData.currency && dashboardData.currency.code) || '';
          currency.symbol = (dashboardData.currency && dashboardData.currency.symbol) || '';
          if (dashboardData.currency_format) {
            currencyFormat = Object.assign({}, currencyFormat, dashboardData.currency_format);
            currencyPrecision = (typeof currencyFormat.decimalPlaces === 'number')
              ? Math.max(0, Math.min(8, currencyFormat.decimalPlaces))
              : currencyPrecision;
          }

          updateSummary(dashboardData.summary || {});
          setSummaryLoading(false);
          updateTableSummary(dashboardData.summary || {});
          renderTable(dashboardData.ads || []);

          var defaultRange = chartDataStore[currentRange] ? currentRange : 'daily';
          setActiveRange(defaultRange);
          ensureChart(defaultRange, chartDataStore[defaultRange] || { labels: [], views: [], clicks: [], spend: [] });

          toggleClass(chartLoading, 'none', true);
          toggleClass(chartError, 'none', true);
        })
        .catch(function(){
          setSummaryLoading(false);
          setChartErrorState();
          setTableState('error');
          showToast(I18N('ads_dashboard_fetch_failed'), 'error');
        });
    }

    bindModalEvents();
    bindRangeButtons();
    bindCreateAdButtons();
    handleTableInteractions();
    loadDashboard();
  });
})();
