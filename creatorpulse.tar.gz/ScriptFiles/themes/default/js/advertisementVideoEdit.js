(function ($, window, document) {
    "use strict";

    (function initAdsHelpTooltips($docReady) {
        if (!$docReady || window.__ADS_HELP_TOOLTIP_INIT__) {
            return;
        }
        window.__ADS_HELP_TOOLTIP_INIT__ = true;

        var activeTrigger = null;
        var activeTooltip = null;
        var hideTimer = null;
        var lastPointerX = null;
        var doc = document;
        var spacing = 12;

        function clearHideTimer() {
            if (hideTimer) {
                clearTimeout(hideTimer);
                hideTimer = null;
            }
        }

        function scheduleHide(delay) {
            clearHideTimer();
            if (!activeTooltip) {
                return;
            }
            var tooltipRef = activeTooltip;
            hideTimer = setTimeout(function () {
                if (tooltipRef === activeTooltip) {
                    removeTooltip();
                }
            }, typeof delay === 'number' ? delay : 0);
        }

        function ensureId(trigger) {
            var id = trigger.getAttribute('data-tooltip-id');
            if (!id) {
                id = 'ads-tooltip-' + Date.now() + '-' + Math.floor(Math.random() * 100000);
                trigger.setAttribute('data-tooltip-id', id);
            }
            return id;
        }

        function removeTooltip() {
            clearHideTimer();
            if (!activeTooltip) {
                return;
            }
            var tooltip = activeTooltip;
            var trigger = activeTrigger;
            activeTooltip = null;
            activeTrigger = null;
            lastPointerX = null;
            if (trigger) {
                trigger.setAttribute('aria-expanded', 'false');
                trigger.removeAttribute('aria-describedby');
            }
            tooltip.classList.remove('is-visible');
            setTimeout(function () {
                if (tooltip && tooltip.parentNode) {
                    tooltip.parentNode.removeChild(tooltip);
                }
            }, 160);
        }

        function positionTooltip(trigger, tooltip, originEvent) {
            if (!trigger || !tooltip) {
                return;
            }
            var rect = trigger.getBoundingClientRect();
            var vw = window.innerWidth || doc.documentElement.clientWidth || 0;
            var vh = window.innerHeight || doc.documentElement.clientHeight || 0;
            var referenceX;
            if (originEvent && typeof originEvent.clientX === 'number') {
                referenceX = originEvent.clientX;
            } else if (lastPointerX !== null) {
                referenceX = lastPointerX;
            } else {
                referenceX = rect.left + rect.width / 2;
            }
            var placement = 'bottom';
            var shouldHideForMeasure = !tooltip.classList.contains('is-visible');
            if (shouldHideForMeasure) {
                tooltip.style.visibility = 'hidden';
            }
            tooltip.style.top = '0px';
            tooltip.style.left = '0px';
            var tooltipRect = tooltip.getBoundingClientRect();
            var top = rect.bottom + spacing;
            if (top + tooltipRect.height > vh - spacing && rect.top - tooltipRect.height - spacing >= spacing) {
                top = rect.top - tooltipRect.height - spacing;
                placement = 'top';
            } else if (top + tooltipRect.height > vh - spacing) {
                top = Math.max(spacing, vh - tooltipRect.height - spacing);
            }
            var left = referenceX - tooltipRect.width / 2;
            var minLeft = spacing;
            var maxLeft = Math.max(spacing, vw - tooltipRect.width - spacing);
            if (left < minLeft) {
                left = minLeft;
            }
            if (left > maxLeft) {
                left = maxLeft;
            }
            tooltip.style.top = Math.round(top) + 'px';
            tooltip.style.left = Math.round(left) + 'px';
            tooltip.setAttribute('data-placement', placement);

            var anchorPx = referenceX - left;
            var tooltipWidth = tooltipRect.width || 0;
            var arrowGutter = 10;
            if (tooltipWidth > 0) {
                var clampedAnchor = Math.max(arrowGutter, Math.min(tooltipWidth - arrowGutter, anchorPx));
                tooltip.style.setProperty('--ads-tooltip-anchor', Math.round(clampedAnchor) + 'px');
                var originX = Math.round((clampedAnchor / tooltipWidth) * 10000) / 100;
                tooltip.style.setProperty('--ads-tooltip-origin-x', originX + '%');
            } else {
                tooltip.style.removeProperty('--ads-tooltip-anchor');
                tooltip.style.removeProperty('--ads-tooltip-origin-x');
            }
            tooltip.style.setProperty('--ads-tooltip-origin-y', placement === 'top' ? '100%' : '0%');

            if (shouldHideForMeasure) {
                tooltip.style.visibility = '';
            }
        }

        function showTooltip(trigger, originEvent) {
            if (!trigger) {
                return;
            }
            var text = trigger.getAttribute('data-tooltip');
            if (!text) {
                return;
            }
            if (originEvent && typeof originEvent.clientX === 'number') {
                lastPointerX = originEvent.clientX;
            } else {
                lastPointerX = null;
            }
            if (activeTrigger === trigger && activeTooltip) {
                positionTooltip(trigger, activeTooltip, originEvent);
                return;
            }
            removeTooltip();
            clearHideTimer();
            var tooltip = doc.createElement('div');
            tooltip.className = 'ads-tooltip';
            tooltip.setAttribute('role', 'tooltip');
            tooltip.textContent = text;
            var id = ensureId(trigger);
            tooltip.id = id;
            if (!trigger.hasAttribute('aria-haspopup')) {
                trigger.setAttribute('aria-haspopup', 'true');
            }
            if (!trigger.hasAttribute('aria-expanded')) {
                trigger.setAttribute('aria-expanded', 'false');
            }
            trigger.setAttribute('aria-describedby', id);
            trigger.setAttribute('aria-expanded', 'true');
            doc.body.appendChild(tooltip);
            activeTrigger = trigger;
            activeTooltip = tooltip;
            positionTooltip(trigger, tooltip, originEvent);
            requestAnimationFrame(function () {
                if (activeTooltip === tooltip) {
                    tooltip.classList.add('is-visible');
                }
            });
            tooltip.addEventListener('mouseenter', clearHideTimer, { passive: true });
            tooltip.addEventListener('mouseleave', function () {
                scheduleHide(120);
            });
        }

        function handleDocClick(event) {
            if (!activeTooltip) {
                return;
            }
            var target = event.target;
            if (activeTrigger && (activeTrigger === target || activeTrigger.contains(target))) {
                return;
            }
            if (activeTooltip && activeTooltip.contains(target)) {
                return;
            }
            removeTooltip();
        }

        function handleKeydown(event) {
            var key = event.key || event.keyCode;
            if (key === 'Escape' || key === 'Esc' || key === 27) {
                if (activeTooltip) {
                    removeTooltip();
                }
            }
        }

        function handleReposition() {
            if (activeTooltip && activeTrigger) {
                positionTooltip(activeTrigger, activeTooltip);
            }
        }

        $docReady(doc)
            .on('mouseenter.adsTooltip focusin.adsTooltip', '.ads-help-button', function (event) {
                showTooltip(this, event);
            })
            .on('mouseleave.adsTooltip', '.ads-help-button', function () {
                scheduleHide(140);
            })
            .on('focusout.adsTooltip', '.ads-help-button', function () {
                scheduleHide(0);
            })
            .on('click.adsTooltip', '.ads-help-button', function (event) {
                if (activeTrigger === this && activeTooltip) {
                    removeTooltip();
                    return;
                }
                showTooltip(this, event);
            });

        doc.addEventListener('keydown', handleKeydown, true);
        doc.addEventListener('click', handleDocClick, true);
        doc.addEventListener('touchstart', handleDocClick, true);
        window.addEventListener('scroll', handleReposition, true);
        window.addEventListener('resize', handleReposition, true);
    })($ || window.jQuery || window.$);

    /**
     * Authoring Notes
     * ---------------
     *
     * - Keep DOM selectors centralized under `VE.selectors`.
     * - Keep all HTML-generating helpers (`...HTML()` functions) side-effect free; they should only return strings.
     * - Keep UI state mutations inside small helpers (show/hide/html) for clarity and testability.
     * - Never rely on inline styles; CSS classes handle visibility (`.none`) and loaders.
     */

    /**
     * =====================
     * Module Configuration
     * =====================
     * Centralized selectors and endpoints to avoid scattering literals throughout the file.
     */

    // Namespace to avoid globals & collisions
    var VE = {
        selectors: {
            fileInput:    "#fileInput",
            createBox:    ".create_media_box",
            setContainer: ".set_video_container",
            finishContainer: ".finish_video_container",
            goBack:       "#goBack",
            goNext:       "#goNext",
            uploadBtn:    "#uploadBtn",
            popupWrapper: ".popup-wrapper"
        },
        endpoint: (typeof window.buildUrl === 'function')
            ? window.buildUrl('request/requests.php')
            : ((typeof window.site_url !== 'undefined' && window.site_url) ? (window.site_url + 'request/requests.php') : 'request/requests.php'),
        actionUpload: "ads_upload_temp_video" // advertisement temp upload (requests.php)
    };

    // Helpers
    /** Utility: show an element (visibility driven by CSS classes). */
    function show(el) { $(el).removeClass("none"); }
    /** Utility: hide an element (visibility driven by CSS classes). */
    function hide(el) { $(el).addClass("none"); }
    /** Utility: set inner HTML of a target container. */
    function html(el, content) { $(el).html(content); }
    /**
     * Remove native video UI for editor area and enforce inline playback.
     * This keeps the UX consistent across browsers and allows custom controls.
     */
    function stripNativeControls(){
        var $v = $(VE.selectors.setContainer).find('video');
        if(!$v.length) return;
        $v.each(function(){
            var el = this;
            // Remove native controls UI
            el.controls = false;
            el.removeAttribute('controls');
            // Force inline playback (iOS/Safari)
            el.setAttribute('playsinline', '');
            el.setAttribute('webkit-playsinline', '');
            // Reduce native UI affordances
            el.setAttribute('disablepictureinpicture', '');
            el.setAttribute('controlsList', 'nodownload noplaybackrate nofullscreen noremoteplayback');
            // Marker class for CSS targeting
            $(el).addClass('no-native-controls');
        });
    }
    // Loader helpers (no inline styles; styles come from style.css)
    /** Returns HTML for the editor-stage loader (string only; no side effects). */
    function veLoaderHTML(){
        return '' +
        '<div class="loading-container absolute">' +
        '<div class="loader">' +
        '<div></div><div></div><div></div><div></div><div></div><div></div>' +
        '<div></div><div></div><div></div><div></div><div></div><div></div>' +
        '</div>' +
        '<p class="loading-text"></p>' +
        '</div>';
    }
    /** Mount the editor-stage loader into the setContainer, if not already present. */
    function showLoader() {
        var $host = $(VE.selectors.setContainer);
        if (!$host.find('.loading-container').length) {
            $host.append(veLoaderHTML());
        }
    }
    /** Remove the editor-stage loader from the setContainer. */
    function hideLoader() {
        $(VE.selectors.setContainer).find('.loading-container').remove();
    }

    // Popup-level loader (shown during finalize on uploadBtn)
    /** Returns HTML for the popup-level loader shown during final submit. */
    function vePopupLoaderHTML(){
        return '' +
        '<div class="loading-container popup-loader absolute">' +
          '<div class="loader">' +
            '<div></div><div></div><div></div><div></div><div></div><div></div>' +
            '<div></div><div></div><div></div><div></div><div></div><div></div>' +
          '</div>' +
          '<p class="loading-text"></p>' +
        '</div>';
    }
    /** Mount the popup-level loader into `.popup-wrapper`, once. */
    function showPopupLoader(){
        var $host = $(VE.selectors.popupWrapper).first();
        if ($host.length && !$host.find('.popup-loader').length) {
            $host.append(vePopupLoaderHTML());
        }
    }
    /** Remove the popup-level loader from `.popup-wrapper`. */
    function hidePopupLoader(){
        $(VE.selectors.popupWrapper).find('.popup-loader').remove();
    }

    function ensureVisibilityNotice() {
        if (window.DZ && typeof window.DZ.openVisibilityNotice === 'function') {
            return window.DZ.openVisibilityNotice;
        }

        function escapeHtml(value) {
            return String(value == null ? '' : value)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        function closeVisibilityNotice() {
            var existing = document.querySelector('.popUp-container[data-modal="visibility-guard"]');
            if (existing && existing.parentNode) {
                existing.parentNode.removeChild(existing);
            }
        }

        function openVisibilityNotice(options) {
            var opts = options || {};
            closeVisibilityNotice();

            var modal = document.createElement('div');
            modal.className = 'popUp-container';
            modal.setAttribute('data-modal', 'visibility-guard');

            var i18nFn = (window.DZ && typeof window.DZ.i18n === 'function') ? window.DZ.i18n : function(){ return ''; };
            var defaultOk = i18nFn('ui_ok') || 'OK';
            var cancelLabel = opts.cancelLabel || i18nFn('menu_cancel') || 'Cancel';
            var confirmLabel = opts.confirmLabel || defaultOk;
            var title = opts.title ? escapeHtml(opts.title) : '';
            var message = escapeHtml(opts.message || '');

            var html = '<div class="pm-sheet-container"><div class="pm-sheet" role="dialog" aria-modal="true">';
            if (title) {
                html += '<div class="pm-header flex align_items_justify_content full-width">' + title + '</div><div class="aud-sep"></div>';
            }
            html += '<div class="pm-message">' + message + '</div><div class="aud-sep"></div>';
            html += '<button type="button" class="pm-item pm-confirm">' + escapeHtml(confirmLabel) + '</button>';
            html += '</div>';
            html += '<button type="button" class="pm-cancel">' + escapeHtml(cancelLabel) + '</button>';
            html += '</div>';
            modal.innerHTML = html;

            modal.addEventListener('click', function (event) {
                var target = event.target;
                if (target.classList.contains('pm-confirm')) {
                    closeVisibilityNotice();
                    if (typeof opts.onConfirm === 'function') {
                        if (opts.onConfirm() === false) {
                            return;
                        }
                    } else if (opts.redirectUrl) {
                        window.location.href = opts.redirectUrl;
                        return;
                    }
                    if (opts.redirectUrl) {
                        window.location.href = opts.redirectUrl;
                    }
                    return;
                }
                if (target.classList.contains('pm-cancel') || target === modal) {
                    closeVisibilityNotice();
                }
            });

            document.body.appendChild(modal);
            return modal;
        }

        window.DZ = window.DZ || {};
        window.DZ.openVisibilityNotice = openVisibilityNotice;
        window.DZ.closeVisibilityNotice = closeVisibilityNotice;
        return openVisibilityNotice;
    }

    const openVisibilityNotice = ensureVisibilityNotice();

    function parseGuardBool(value) {
        if (typeof value === 'boolean') {
            return value;
        }
        if (typeof value === 'number') {
            return value === 1;
        }
        if (typeof value === 'string') {
            var normalized = value.trim().toLowerCase();
            return normalized === '1' || normalized === 'true' || normalized === 'yes';
        }
        return false;
    }

    function getVisibilityContext($source) {
        if (!$source || !$source.length) {
            return null;
        }
        var $root = $source.closest('.popUp-container');
        if (!$root.length) {
            return null;
        }
        var data = $root.data() || {};
        return {
            isCreator: typeof data.isCreator !== 'undefined' ? parseGuardBool(data.isCreator) : true,
            paymentsActive: typeof data.paymentsActive !== 'undefined' ? parseGuardBool(data.paymentsActive) : true,
            hasCreatorFlag: typeof data.isCreator !== 'undefined',
            hasPaymentsFlag: typeof data.paymentsActive !== 'undefined',
            creatorUrl: data.creatorUrl || '',
            creatorMessage: data.creatorMessage || '',
            creatorAction: data.creatorAction || '',
            paymentsMessage: data.paymentsMessage || '',
            paymentsAction: data.paymentsAction || '',
            cancelLabel: data.guardCancel || ''
        };
    }

    function resolvePaymentContext() {
        var $root = $('.popUp-container').first();
        return getVisibilityContext($root.length ? $root : null);
    }

    // Toast helpers (server messages). Styles must live in style.css
    /** Build a toast container. `kind` can be `error`, `success`, or `info`. */
    function veToastHTML(text, kind){
        // kind: 'error' | 'success' | 'info'
        var k = kind || 'info';
        return '' +
        '<div class="ve-toast ve-toast-' + k + '" role="status" aria-live="polite">' +
            '<div class="ve-toast-body">' + $('<div/>').text(text).html() + '</div>' +
        '</div>';
    }
    /** Append a toast to the popup wrapper (or `<body>`) and auto-remove after 5s. */
    function showToast(text, kind){
        var $host = $(VE.selectors.popupWrapper).first();
        if(!$host.length){ $host = $(document.body); }
        var $t = $(veToastHTML(text, kind));
        $host.append($t);
        // auto remove after 5s
        setTimeout(function(){ $t.addClass('hide'); setTimeout(function(){ $t.remove(); }, 400); }, 5000);
    }

    // Icon helpers for play/pause button (no inline styles)
    /** SVG icon: play. */
    function vePlaySVG(){
        return '<svg viewBox="-1 0 12 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <title>play [#ffffff]</title> <desc>Created with Sketch.</desc> <defs> </defs> <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="Dribbble-Light-Preview" transform="translate(-65.000000, -3803.000000)" fill="#ffffff"> <g id="icons" transform="translate(56.000000, 160.000000)"> <path d="M18.074,3650.7335 L12.308,3654.6315 C10.903,3655.5815 9,3654.5835 9,3652.8985 L9,3645.1015 C9,3643.4155 10.903,3642.4185 12.308,3643.3685 L18.074,3647.2665 C19.306,3648.0995 19.306,3649.9005 18.074,3650.7335" id="play-[#ffffff]"> </path> </g> </g> </g> </g></svg>';
    }
    /** SVG icon: pause. */
    function vePauseSVG(){
        return '<svg viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" fill="none"><g fill="#ffffff"><rect x="2" y="1" width="3" height="10" rx="0.8"></rect><rect x="7" y="1" width="3" height="10" rx="0.8"></rect></g></svg>';
    }
    /** Set the play button state and swap the icon accordingly. */
    function setPlayButtonState($btn, state){ // state: 'play' | 'pause'
        if(state === 'pause'){
            $btn.attr('data-state','pause').html(vePauseSVG());
        }else{
            $btn.attr('data-state','play').html(vePlaySVG());
        }
    }

    // =========================
    // Editor (Timeline + Cover)
    // =========================
    // Internal state
    var veState = {
        duration: 0,
        startSec: 0,
        endSec: 0,
        coverDataURL: null,
        objectUrl: null
    };
    // Minimum selectable range length in seconds (kept consistent across inputs & dragging)
    var MIN_RANGE_SECONDS = 0.25;

    /**
     * Build the timeline editor panel (seek bar, handles, playhead, and inputs).
     * Returned string is inserted into `.set_video_container`.
     */
function buildEditorPanelHTML() {
    return `<div class="ve-controls"><div class="ve-timeline"><div class="ve-track"><canvas class="ve-canvas"></canvas><div class="ve-shade ve-shade-left"></div><div class="ve-shade ve-shade-right"></div><div class="ve-range-outline"></div><div class="ve-handle ve-handle-start" title="Start"></div><div class="ve-handle ve-handle-end" title="End"></div><div class="ve-playhead"></div></div><div class="ve-tick-dots"></div><div class="ve-ticks"><span class="ve-tick-start">0s</span><span class="ve-tick-mid">5s</span><span class="ve-tick-end">10s</span></div></div><div class="ve-fields full-width flex align_items"><label class="ve-label"><input type="range" class="ve-start-range" step="0.001" min="0" value="0"><input type="number" class="ve-start-number" step="0.001" min="0" value="0"></label><label class="ve-label"><input type="range" class="ve-end-range" step="0.001" min="0" value="0"><input type="number" class="ve-end-number" step="0.001" min="0" value="0"></label><button type="button" class="ve-play-range" data-state="play"><svg viewBox="-1 0 12 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <title>play [#ffffff]</title> <desc>Created with Sketch.</desc> <defs> </defs> <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="Dribbble-Light-Preview" transform="translate(-65.000000, -3803.000000)" fill="#ffffff"> <g id="icons" transform="translate(56.000000, 160.000000)"> <path d="M18.074,3650.7335 L12.308,3654.6315 C10.903,3655.5815 9,3654.5835 9,3652.8985 L9,3645.1015 C9,3643.4155 10.903,3642.4185 12.308,3643.3685 L18.074,3647.2665 C19.306,3648.0995 19.306,3649.9005 18.074,3650.7335" id="play-[#ffffff]"> </path> </g> </g> </g> </g></svg></button></div></div>`;
}

    /** Utility: resolve the primary `<video>` element inside the editor container. */
    function getVideoEl() {
        // Prefer #editVideo if present, else the first video in setContainer
        var $v = $(VE.selectors.setContainer).find("#editVideo");
        if (!$v.length) $v = $(VE.selectors.setContainer).find("video").first();
        return $v.length ? $v[0] : null;
    }

    /** Ensure the editor panel exists; append if not present. */
    function ensureEditorPanel() {
        var $host = $(VE.selectors.setContainer);
        if (!$host.find(".ve-controls").length) {
            $host.append(buildEditorPanelHTML());
        }
    }

    /**
     * Sync handle positions, shaded regions, and input fields from `veState` times.
     * This is the single source of truth for reflecting selection changes in the UI.
     */
    function fitHandlesFromTimes($root) {
        var startPct = (veState.startSec / veState.duration) * 100;
        var endPct = (veState.endSec / veState.duration) * 100;
        var $track = $root.find(".ve-track");
        var hw = 10; // reserved for CSS handle width
        $root.find(".ve-handle-start").css({ left: 'calc(' + startPct + '% - ' + (hw/2) + 'px)' });
        $root.find(".ve-handle-end").css({ left: 'calc(' + endPct + '% - ' + (hw/2) + 'px)' });
        $root.find(".ve-shade-left").css({ left: 0, width: startPct + '%' });
        $root.find(".ve-shade-right").css({ left: endPct + '%', right: 0 });
        $root.find(".ve-range-outline").css({ left: startPct + '%', right: (100 - endPct) + '%' });
        $root.find(".ve-start").val(veState.startSec.toFixed(2));
        $root.find(".ve-end").val(veState.endSec.toFixed(2));
        $root.find(".ve-tick-mid").text((veState.duration/2).toFixed(0) + 's');
        $root.find(".ve-tick-end").text((veState.duration).toFixed(0) + 's');
        $root.find('.ve-start-range').val(veState.startSec.toFixed(3));
        $root.find('.ve-end-range').val(veState.endSec.toFixed(3));
        $root.find('.ve-start-number').val(veState.startSec.toFixed(3));
        $root.find('.ve-end-number').val(veState.endSec.toFixed(3));
    }

    /** Set min/max/step attributes for range & number inputs based on video duration. */
    function setFieldBounds($root){
        var dur = veState.duration || 0;
        var $sr = $root.find('.ve-start-range');
        var $er = $root.find('.ve-end-range');
        var $sn = $root.find('.ve-start-number');
        var $en = $root.find('.ve-end-number');
        $sr.attr({ min: 0, max: dur, step: 0.001 });
        $er.attr({ min: 0.001, max: dur, step: 0.001 });
        $sn.attr({ min: 0, max: dur, step: 0.001 });
        $en.attr({ min: 0.001, max: dur, step: 0.001 });
    }

    /** Update the floating playhead position given a current time (in seconds). */
    function updatePlayhead($root, current){
        if (!veState.duration || !isFinite(veState.duration)) return;
        var pct = clamp((current / veState.duration) * 100, 0, 100);
        $root.find('.ve-playhead').css({ left: pct + '%' });
    }

    /** Compute a visually pleasant tick step for the timeline given total duration. */
    function niceStepFor(duration){
        // choose ~8-10 dots: steps 0.5,1,2,5,10
        var target = 9;
        var rough = duration / target;
        if (rough <= 0.5) return 0.5;
        if (rough <= 1) return 1;
        if (rough <= 2) return 2;
        if (rough <= 5) return 5;
        return Math.ceil(rough / 5) * 5; // 10,15,20...
    }

    /** Render timeline tick dots at regular intervals for easier visual navigation. */
    function renderTickDots($root){
        var dur = veState.duration || 0;
        var $dots = $root.find('.ve-tick-dots').empty();
        if (!dur || !isFinite(dur)) return;
        var step = niceStepFor(dur);
        for (var t = step; t < dur; t += step){
            var pct = (t / dur) * 100;
            var $d = $('<span class="ve-dot" />').css({ left: pct + '%' }).attr('data-t', t.toFixed(0)+'s');
            $dots.append($d);
        }
    }

    /** rAF-based playhead updater machinery (for smooth UI without layout thrash). */
    // Playhead visibility + rAF-driven smooth updater
    var playheadRAF = null;
    var playheadHideTimer = null;

    /** Soft-hide the playhead; used during handle drags to reduce visual noise. */
    function hidePlayhead($root){
        $root.find('.ve-playhead').addClass('is-hidden');
    }
    /** Reveal the playhead; typically after short inactivity post-drag. */
    function showPlayhead($root){
        $root.find('.ve-playhead').removeClass('is-hidden');
    }

    /** Start a requestAnimationFrame loop to keep the playhead in sync while playing. */
    function startPlayheadLoop(v, $root){
        stopPlayheadLoop();
        function step(){
            updatePlayhead($root, v.currentTime || 0);
            playheadRAF = window.requestAnimationFrame(step);
        }
        playheadRAF = window.requestAnimationFrame(step);
    }
    /** Stop the active requestAnimationFrame loop for the playhead. */
    function stopPlayheadLoop(){
        if (playheadRAF){
            window.cancelAnimationFrame(playheadRAF);
            playheadRAF = null;
        }
    }

    /** Math utility: clamp a number between two bounds. */
    function clamp(v, a, b){ return Math.min(Math.max(v, a), b); }

    /** Convert a clientX coordinate to a percentage across the timeline track. */
    function pctFromClientX($track, clientX){
        var rect = $track[0].getBoundingClientRect();
        var x = clamp(clientX - rect.left, 0, rect.width);
        return (x / rect.width) * 100;
    }

    /** Hidden off-DOM video used solely for frame-accurate seeking & canvas capture. */
    // A single hidden seeker video for frame capture
    var seeker = document.createElement("video");
    seeker.muted = true;
    seeker.playsInline = true;
    /** Promise-based seek helper to await the `seeked` event at time `t` (seconds). */
    function seekAsync(v, t){
        return new Promise(function(resolve){
            var done = function(){ v.removeEventListener('seeked', done); resolve(); };
            v.addEventListener('seeked', done, { once:true });
            var safeT = clamp(t, 0, Math.max(0, veState.duration - 0.05));
            v.currentTime = safeT;
        });
    }

    /**
     * Draw a strip of representative frames on the timeline canvas.
     * Note: Uses the hidden `seeker` video to avoid stalling the main player.
     */
    async function drawTimelineFrames($root, frameCount) {
        var $canvas = $root.find(".ve-canvas");
        var canvas = $canvas[0];
        var ctx = canvas.getContext("2d", { willReadFrequently: true });
        // Size canvas to track
        var trackRect = $root.find(".ve-track")[0].getBoundingClientRect();
        canvas.width = Math.max(800, Math.round(trackRect.width));
        canvas.height = Math.round(trackRect.height);

        ctx.fillStyle = "#111";
        ctx.fillRect(0,0,canvas.width,canvas.height);

        var cellW = Math.floor(canvas.width / frameCount);
        var cellH = canvas.height;
        var step = veState.duration / frameCount;

        for (var i=0;i<frameCount;i++){
            var time = i*step + step/2;
            await seekAsync(seeker, time);
            var vw = seeker.videoWidth, vh = seeker.videoHeight;
            if(!vw || !vh) continue;
            var scale = Math.min(cellW/vw, cellH/vh);
            var w = vw*scale, h = vh*scale;
            var ox = i*cellW + (cellW - w)/2;
            var oy = (cellH - h)/2;
            ctx.drawImage(seeker, ox, oy, w, h);
        }
    }

    /** Generate evenly spaced cover thumbnails (kept for potential future use). */
    async function generateCoverThumbs($root, count){
        var $c = $root.find(".ve-thumbs").empty();
        var step = veState.duration / (count+1);
        for (var i=1;i<=count;i++){
            var time = i*step;
            var url = await captureFrame(time, 240);
            var $img = $('<img/>', { src:url, alt:'Cover '+i, class:'ve-thumb' });
            if(i===1){ $img.addClass('active'); veState.coverDataURL = url; }
            $c.append($img);
        }
    }

    /** Capture a JPEG dataURL from the current video at `time` (seconds) and `width` px. */
    function captureFrame(time, width){
        return new Promise(async function(resolve){
            await seekAsync(seeker, time);
            var vw = seeker.videoWidth, vh = seeker.videoHeight;
            var scale = width / vw;
            var cw = Math.round(vw*scale), ch = Math.round(vh*scale);
            var c = document.createElement("canvas");
            c.width = cw; c.height = ch;
            var cctx = c.getContext("2d");
            cctx.drawImage(seeker, 0, 0, cw, ch);
            resolve(c.toDataURL("image/jpeg", 0.9));
        });
    }

    /**
     * Initialize the editor for the currently injected video:
     * - Creates panel if needed
     * - Binds metadata, play/pause, end-of-range checks
     * - Pre-renders timeline frames
     */
    // Initialize editor for current video in setContainer
    function initEditorForCurrentVideo(){
        var v = getVideoEl();
        if(!v) { return; }

        // Ensure panel
        ensureEditorPanel();
        var $root = $(VE.selectors.setContainer);
        stripNativeControls();
        setFieldBounds($root);

        // Keep play button state in sync with native controls and end-of-range
        var $btn = $root.find('.ve-play-range');
        setPlayButtonState($btn, 'play');
        v.addEventListener('pause', function(){ setPlayButtonState($btn, 'play'); });
        v.addEventListener('ended', function(){ setPlayButtonState($btn, 'play'); });

        // Bind seeker to same source
        if (v.currentSrc) {
            seeker.src = v.currentSrc;
        } else {
            var source = $(v).find("source").attr("src") || v.src || "";
            if (source) seeker.src = source;
        }

        v.onloadedmetadata = function(){
            veState.duration = v.duration || 0;
            if(!veState.duration || !isFinite(veState.duration)) return;
            veState.startSec = 0;
            veState.endSec = veState.duration;
            setFieldBounds($root);
            fitHandlesFromTimes($root);
            renderTickDots($root);
            updatePlayhead($root, 0);
            showPlayhead($root);
            drawTimelineFrames($root, 24).then(function(){
                // done
            });
            // generateCoverThumbs($root, 5); // Removed covers section
        };

        // If already loaded (Safari sometimes)
        if (v.readyState >= 1) {
            veState.duration = v.duration || 0;
            veState.startSec = 0;
            veState.endSec = veState.duration || 0;
            setFieldBounds($(VE.selectors.setContainer));
            fitHandlesFromTimes($(VE.selectors.setContainer));
            renderTickDots($(VE.selectors.setContainer));
            updatePlayhead($(VE.selectors.setContainer), v.currentTime || 0);
            showPlayhead($(VE.selectors.setContainer));
            drawTimelineFrames($(VE.selectors.setContainer), 24);
            // generateCoverThumbs($(VE.selectors.setContainer), 5); // Removed covers section
        }

        // Range stop check (keep timeupdate only for end-boundary enforcement)
        v.addEventListener("timeupdate", function(){
            if (veState.endSec && v.currentTime > veState.endSec) {
                v.pause();
                stopPlayheadLoop();
                var $btn = $(VE.selectors.setContainer).find('.ve-play-range');
                setPlayButtonState($btn, 'play');
            }
        });

        // Start/stop the rAF loop on play/pause/ended
        v.addEventListener('play', function(){
            startPlayheadLoop(v, $(VE.selectors.setContainer));
        });
        v.addEventListener('pause', function(){
            stopPlayheadLoop();
        });
        v.addEventListener('ended', function(){
            stopPlayheadLoop();
        });
    }

    // Expose to namespace
    VE.initEditorForCurrentVideo = initEditorForCurrentVideo;

    // Delegated events for editor UI
    // --- Range Handles: drag logic (pause during drag, keep within bounds, rAF throttled) ---
    var dragging = null; // 'start' | 'end'
    var draggingWasPlaying = false;
    var rafPending = false;
    $(document).on("pointerdown", ".ve-handle-start, .ve-handle-end", function(e){
        var $track = $(VE.selectors.setContainer).find(".ve-track");
        dragging = $(this).hasClass("ve-handle-start") ? "start" : "end";
        // If video was playing, pause during drag to avoid iOS audio policies and desync
        var v = getVideoEl();
        var $btn = $(VE.selectors.setContainer).find('.ve-play-range');
        draggingWasPlaying = false;
        if (v) {
            draggingWasPlaying = !v.paused && !v.ended;
            if (draggingWasPlaying) {
                v.pause();
                setPlayButtonState($btn, 'play');
            }
        }
        hidePlayhead($(VE.selectors.setContainer));
        if (typeof this.setPointerCapture === 'function') {
            try { this.setPointerCapture(e.pointerId); } catch(_) {}
        }
        // Prevent touch scrolling while dragging
        e.preventDefault();
        e.stopPropagation();
    });

    $(document).on("pointermove", function(e){
        if (!dragging) return;
        if (rafPending) return;
        rafPending = true;
        window.requestAnimationFrame(function(){
            var $root = $(VE.selectors.setContainer);
            var $track = $root.find(".ve-track");
            var pct = clamp(pctFromClientX($track, e.clientX), 0, 100);
            var sPct = (veState.startSec / veState.duration) * 100;
            var ePct = (veState.endSec / veState.duration) * 100;

            var minGapPct = (MIN_RANGE_SECONDS / veState.duration) * 100;

            if (dragging === "start") {
                sPct = Math.min(pct, ePct - minGapPct);
            } else {
                ePct = Math.max(pct, sPct + minGapPct);
            }
            veState.startSec = (sPct/100) * veState.duration;
            veState.endSec = (ePct/100) * veState.duration;
            fitHandlesFromTimes($root);
            var vcur = getVideoEl();
            if (vcur) updatePlayhead($root, vcur.currentTime || 0);
            rafPending = false;
        });
    });

    $(document).on("pointerup pointercancel", function(){
        if (!dragging) return;
        dragging = null;
        var v = getVideoEl();
        var $btn = $(VE.selectors.setContainer).find('.ve-play-range');
        if (v) {
            // Seek to start of selected range; do not auto-play to comply with mobile audio policies.
            v.currentTime = veState.startSec;
            // Require explicit user tap on the play button to start with sound reliably on iOS/Android.
            showPlayhead($(VE.selectors.setContainer));
            setPlayButtonState($btn, 'play');
        }
    });

    // --- Inputs: keep start in sync across range/number fields and enforce min gap ---
    // Start inputs (range or number)
    $(document).on('input', '.ve-start-range, .ve-start-number', function(){
        var $root = $(VE.selectors.setContainer);
        hidePlayhead($root);
        if (playheadHideTimer) { clearTimeout(playheadHideTimer); }
        var val = parseFloat($(this).val() || '0');
        var e = parseFloat($root.find('.ve-end-number').val() || $root.find('.ve-end-range').val() || veState.endSec);
        var s = clamp(Math.min(val, e - 0.25), 0, Math.max(0, veState.duration - 0.25));
        veState.startSec = s;
        // sync peers
        $root.find('.ve-start-range').val(s.toFixed(3));
        $root.find('.ve-start-number').val(s.toFixed(3));
        fitHandlesFromTimes($root);
        var vcur2 = getVideoEl();
        if (vcur2) updatePlayhead($root, vcur2.currentTime || 0);
        var v = getVideoEl();
        if (v && v.currentTime > veState.endSec) {
            v.pause();
            setPlayButtonState($(VE.selectors.setContainer).find('.ve-play-range'), 'play');
        }
        playheadHideTimer = setTimeout(function(){ showPlayhead($root); }, 300);
    });

    // --- Inputs: keep end in sync across range/number fields and enforce min gap ---
    // End inputs (range or number)
    $(document).on('input', '.ve-end-range, .ve-end-number', function(){
        var $root = $(VE.selectors.setContainer);
        hidePlayhead($root);
        if (playheadHideTimer) { clearTimeout(playheadHideTimer); }
        var val = parseFloat($(this).val() || String(veState.duration));
        var s = parseFloat($root.find('.ve-start-number').val() || $root.find('.ve-start-range').val() || veState.startSec);
        var e = clamp(Math.max(val, s + 0.25), 0.25, veState.duration);
        veState.endSec = e;
        // sync peers
        $root.find('.ve-end-range').val(e.toFixed(3));
        $root.find('.ve-end-number').val(e.toFixed(3));
        fitHandlesFromTimes($root);
        var vcur2 = getVideoEl();
        if (vcur2) updatePlayhead($root, vcur2.currentTime || 0);
        var v2 = getVideoEl();
        if (v2 && v2.currentTime > veState.endSec) {
            v2.pause();
            setPlayButtonState($(VE.selectors.setContainer).find('.ve-play-range'), 'play');
        }
        playheadHideTimer = setTimeout(function(){ showPlayhead($root); }, 300);
    });

    // --- Play selected range: explicit user gesture only (mobile-safe) ---
    $(document).on("click", ".ve-play-range", function(){
        var v = getVideoEl();
        if (!v) return;
        v.muted = false; // ensure audio is enabled for explicit user gesture
        var $btn = $(this);
        var state = $btn.attr('data-state') || 'play';

        // If currently in 'play' state, start playback from startSec and switch to pause icon
        if (state === 'play') {
            v.currentTime = veState.startSec;
            updatePlayhead($(VE.selectors.setContainer), veState.startSec);
            startPlayheadLoop(v, $(VE.selectors.setContainer));
            var p = v.play();
            if (p && typeof p.then === 'function') {
                p.then(function(){
                    setPlayButtonState($btn, 'pause');
                }).catch(function(){
                    // autoplay blocked or similar — keep as play icon
                    setPlayButtonState($btn, 'play');
                });
            } else {
                setPlayButtonState($btn, 'pause');
            }
        } else {
            // Pause requested
            stopPlayheadLoop();
            v.pause();
            setPlayButtonState($btn, 'play');
        }
    });

    // Removed delegated cover event handlers (.ve-regen and .ve-thumbs img)

    /** Reset to pre-upload state; used on errors or when user navigates back. */
    // Reset view back to initial (in case PHP error returns)
    function resetToInitial() {
        show(VE.selectors.createBox);
        hide(VE.selectors.setContainer);
        hide(VE.selectors.goBack);
        hide(VE.selectors.goNext);
        hide(VE.selectors.uploadBtn);
        hideLoader();
        var $in = $(VE.selectors.fileInput);
        if ($in.length) { $in.val(""); }
        html(VE.selectors.setContainer, "");
        veState.duration = 0; veState.startSec = 0; veState.endSec = 0;
    }

    /** Switch UI to the editing step (after a successful temporary upload). */
    // Prepare UI for editing state (after successful upload)
    function toEditingState() {
        hide(VE.selectors.createBox);
        show(VE.selectors.setContainer);
        show(VE.selectors.goBack);
        show(VE.selectors.goNext);
        // Share/Upload button stays hidden at this step; will be enabled in the finalize view.
        hide(VE.selectors.uploadBtn);
    }

    /** Switch UI to the finalize/publish step. */
    // Switch to finish step (publish view)
    function toFinishState() {
        // containers
        $(VE.selectors.setContainer).addClass('none');
        $(VE.selectors.finishContainer).removeClass('none');

        // header buttons
        show(VE.selectors.goBack);
        hide(VE.selectors.goNext);
        show(VE.selectors.uploadBtn);
    }

    /** Return from finalize view back to the editor view. */
    // Switch back to edit step
    function backToEditState() {
        // containers
        $(VE.selectors.finishContainer).addClass('none');
        $(VE.selectors.setContainer).removeClass('none');

        // header buttons
        show(VE.selectors.goBack);
        show(VE.selectors.goNext);
        hide(VE.selectors.uploadBtn);
    }

    function normalizeAdLink(link) {
        if (!link) { return ''; }
        var trimmed = String(link).trim();
        if (trimmed === '') { return ''; }
        if (!/^https?:\/\//i.test(trimmed)) {
            trimmed = 'https://' + trimmed;
        }
        try {
            var parsed = new URL(trimmed);
            if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
                return '';
            }
            return parsed.toString();
        } catch (err) {
            return '';
        }
    }

    /**
     * Gather the final payload to be sent on submit.
     * Includes: source URLs, trim times, text, visibility, pricing, and switches.
     */
    // Gather data for final submit (advertisement video finalize)
    function gatherFinishPayload(){
        // Video info
        var v = getVideoEl();
        var videoUrl = "";
        var posterUrl = "";
        if (v) {
            videoUrl = v.currentSrc || $(v).find('source').attr('src') || v.src || "";
            posterUrl = v.poster || "";
        }

        // Advertisement fields
        var title       = $(VE.selectors.finishContainer).find('input[name="ad_title"]').val() || "";
        var description = $(VE.selectors.finishContainer).find('textarea[name="ad_description"]').val() || "";
        var impressions = $(VE.selectors.finishContainer).find('input[name="target_impressions"]').val() || "0";
        var ppi         = $(VE.selectors.finishContainer).find('input[name="price_per_impression"]').val() || "0";
        var days        = $(VE.selectors.finishContainer).find('input[name="duration_days"]').val() || "1";
        var budget      = $(VE.selectors.finishContainer).find('input[name="total_budget"]').val() || "0";
        var status      = $(VE.selectors.finishContainer).find('select[name="ad_status"]').val() || 'draft';
        var adLinkRaw   = $(VE.selectors.finishContainer).find('input[name="ad_link"]').val() || "";
        var adLink      = normalizeAdLink(adLinkRaw);

        // CSRF
        var csrfToken = $('input[name="csrf_token"]').val() || "";

        return {
            p: 'ads_finalize_video',
            csrf_token: csrfToken,
            video_url: videoUrl,
            poster_url: posterUrl,
            ad_title: title,
            ad_description: description,
            ad_link: adLink,
            target_impressions: impressions,
            price_per_impression: ppi,
            duration_days: days,
            total_budget: budget,
            ad_status: status
        };
    }

    /** Build a minimal editor-stage video wrapper when backend returns only a URL. */
    // Build fallback video HTML if server returns only URL
    function buildVideoHTML(url, poster) {
        var p = poster ? ' poster="'+ poster +'"' : "";
        return '' +
        '<div class="video-edit-stage">' +
            '<video id="editVideo" class="edit-video no-native-controls" playsinline'+ p +'>' +
                '<source src="'+ url +'" type="video/mp4">' +
            '</video>' +
        '</div>';
    }

    /** Build a minimal feed card as a fallback when server does not return ready-made HTML. */
    // Build a minimal feed card if backend didn't return ready-made HTML
    function buildFeedCardHTML(videoUrl, poster){
        var p = poster ? ' poster="'+ poster +'"' : "";
        return '' +
        '<div class="post-card">' +
          '<div class="post-media">' +
            '<video class="post-video" playsinline controls'+ p +'>' +
              '<source src="'+ videoUrl +'" type="video/mp4">' +
            '</video>' +
          '</div>' +
        '</div>';
    }

    // =====================
    // Upload → Temp Preview
    // =====================
    // Handles file input, posts to PHP, and injects returned HTML/JSON.
    // Handle file selection -> AJAX upload to server
    $(document).on("change", VE.selectors.fileInput, function (e) {
        var files = e.target.files || (this.files ? this.files : null);
        if (!files || !files.length) { return; }

        // Only the first file is used at this step (multi-file support can be added later).
        var file = files[0];

        var formData = new FormData();
        formData.append("p", VE.actionUpload);
        formData.append("video", file);
        // Append CSRF token if present
        var csrfToken = $('input[name="csrf_token"]').val();
        if (csrfToken) {
            formData.append("csrf_token", csrfToken);
        }

        html(VE.selectors.setContainer, "");
        showLoader();
        toEditingState();

        $.ajax({
            url: VE.endpoint,
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,

            success: function (res) {
                var raw = res;
                if (typeof raw === "string") {
                    var s = raw.trim();
                    // 1) Pure HTML
                    if (s.charAt(0) === "<") {
                        hideLoader();
                        html(VE.selectors.setContainer, s);
                        stripNativeControls();
                        VE.initEditorForCurrentVideo();
                        show(VE.selectors.setContainer);
                        return;
                    }
                    // 2) JSON string
                    if (s.charAt(0) === "{" || s.charAt(0) === "[") {
                        try { res = JSON.parse(s); } catch (e) {
                            hideLoader();
                            showToast((I18N('ui_unexpected_response') || 'Unexpected response.'), 'error');
                            resetToInitial();
                            return;
                        }
                    } else {
                        hideLoader();
                        showToast((I18N('ui_unexpected_response') || 'Unexpected response.'), 'error');
                        resetToInitial();
                        return;
                    }
                }

                // 3) JSON object handling
                if (res && res.status === "success") {
                    if (res.html) {
                        hideLoader();
                        html(VE.selectors.setContainer, res.html);
                        stripNativeControls();
                        VE.initEditorForCurrentVideo();
                    } else if (res.video_url) {
                        hideLoader();
                        html(VE.selectors.setContainer, buildVideoHTML(res.video_url, res.poster || ""));
                        stripNativeControls();
                        VE.initEditorForCurrentVideo();
                    } else {
                        hideLoader();
                        if (res && res.message) { showToast(res.message, 'error'); }
                        resetToInitial();
                        return;
                    }
                    show(VE.selectors.setContainer);
                    return;
                }

                // JSON error or unknown structure: revert UI (server is responsible for messages)
                hideLoader();
                if (res && res.message) { showToast(res.message, (res.status && res.status !== 'success') ? 'error' : 'info'); }
                resetToInitial();
            },

            error: function (xhr) {
                hideLoader();
                var msg = 'Request failed. Please try again.';
                try {
                    if (xhr && xhr.responseText && xhr.responseText.trim().charAt(0) === '{') {
                        var j = JSON.parse(xhr.responseText);
                        if (j && j.message) msg = j.message;
                    }
                } catch(_) {}
                showToast(msg, 'error');
                resetToInitial();
            }
        });
    });

    // Navigation: Go Back — either to editor from finish step or to pre-upload state.
    $(document).on("click", VE.selectors.goBack, function () {
        // If user is at finish step, go back to edit; else reset to initial
        if (!$(VE.selectors.finishContainer).hasClass('none')) {
            backToEditState();
            return;
        }
        // Otherwise, full reset to initial (before upload)
        var $in = $(VE.selectors.fileInput);
        if ($in.length) { $in.val(""); }
        resetToInitial();
    });


    // Navigation: Go Next — proceed to finalize/publish UI.
    $(document).on("click", VE.selectors.goNext, function () {
        toFinishState();
    });

    // =====================
    // Visibility & Price (finish step) — parity with crop.js
    // =====================
    // Ensure hidden post_type input exists inside .advanced_settings_box
    (function ensurePostTypeHiddenInputForVideo(){
        var $box = $('.advanced_settings_box');
        if ($box.length && !$box.find("input[name='post_type']").length) {
            var activeType = $('.post-visiblity.active').data('type') || 'everyone';
            $('<input>', { type: 'hidden', name: 'post_type', value: String(activeType) }).appendTo($box);
        }
    })();

    // Click on visibility pill
    $(document).on('click', '.post-visiblity', function () {
        var $item = $(this);
        var type = String($item.data('type') || 'everyone');
        $('.post-visiblity').removeClass('active');
        $item.addClass('active');
        $("input[name='post_type']").val(type);

        if (type === 'locked') {
            $('.set-price-popup').removeClass('none');
        } else {
            // Hide and reset price UI when leaving locked
            $('.set-price-popup').addClass('none');
            $("input[name='set-price']").val('');
            var $priceSpan = $(".post-visiblity[data-type='locked'] .post-price");
            if ($priceSpan.length) { $priceSpan.text('($)'); }
            $('.set-price-popup .warn').removeClass('form-warning');
        }
    });

    // Save price (validate between min/max), keep 'locked' active
    $(document).on('click', '.set-price-done', function () {
        var raw = $("input[name='set-price']").val();
        var trimmed = $.trim(String(raw || ''));
        var min = parseInt($("input[name='min-price']").val(), 10);
        var max = parseInt($("input[name='max-price']").val(), 10);
        if (!Number.isFinite(min)) { min = 1; }
        if (!Number.isFinite(max)) { max = 500; }
        var amount = parseInt(trimmed, 10);
        var $warn = $('.set-price-popup .warn');

        if (!Number.isFinite(amount) || amount < min || amount > max) {
            $warn.addClass('form-warning');
            return;
        } else {
            $warn.removeClass('form-warning');
        }

        $('.set-price-popup').addClass('none');
        var $priceSpan = $(".post-visiblity[data-type='locked'] .post-price");
        if ($priceSpan.length) { $priceSpan.text('($' + amount + ')'); }

        $('.post-visiblity').removeClass('active');
        $(".post-visiblity[data-type='locked']").addClass('active');
        $("input[name='post_type']").val('locked');
    });

    // Clear price & revert selection
    $(document).on('click', '.set-price-clear', function () {
        $("input[name='set-price']").val('');
        var $priceSpan = $(".post-visiblity[data-type='locked'] .post-price");
        if ($priceSpan.length) { $priceSpan.text('($)'); }
        $(".post-visiblity[data-type='locked']").removeClass('active');
        $('.set-price-popup').addClass('none');

        var activeType = $('.post-visiblity.active').data('type');
        if (activeType) {
            $("input[name='post_type']").val(String(activeType));
        } else {
            $("input[name='post_type']").val('everyone');
            $(".post-visiblity[data-type='everyone']").addClass('active');
        }
        $('.set-price-popup .warn').removeClass('form-warning');
    });

    // Stabilize checkbox values to 'on'/'off' like crop.js does (for backend consistency)
    $(document).on('change', "input[name='hide_likes_view'], input[name='turn_on_off_comment']", function () {
        $(this).val($(this).is(':checked') ? 'on' : 'off');
    });

    // =====================
    // Finalize → Submit
    // =====================
    // Submits the finalized reel, injects new post into #posts, and closes popup on success.
    // Final submit: upload the finalized reel, append to #posts, show loader, close popup on success
    $(document).on('click', VE.selectors.uploadBtn, function(){
        var $btn = $(this);
        // prevent double submit
        if ($btn.prop('disabled')) { return; }
        $btn.prop('disabled', true).addClass('is-busy');
        showPopupLoader();

        var payload = gatherFinishPayload();
        // Client-side validation for ads (video)
        (function validateAndMaybeAbort(){
            function fail(msg){ hidePopupLoader(); showToast(msg, 'error'); $btn.prop('disabled', false).removeClass('is-busy'); throw new Error('abort'); }
            var MIN_AD_BUDGET = (window.MIN_AD_BUDGET && Number(window.MIN_AD_BUDGET)) || 10;
            if (!payload.ad_title || String(payload.ad_title).trim() === '') { fail(I18N('ads_enter_title') || 'Please enter a title.'); }
            if (!payload.ad_description || String(payload.ad_description).trim() === '') { fail(I18N('ads_enter_description') || 'Please enter a description.'); }
            if (!payload.video_url || String(payload.video_url).trim() === '') { fail(I18N('ads_missing_video_url') || 'Missing video URL.'); }
            if (!payload.ad_link || String(payload.ad_link).trim() === '') { fail(I18N('ads_enter_destination_url') || 'Please enter a valid destination URL.'); }
            var imp = parseFloat(payload.target_impressions || '0');
            var ppi = parseFloat(payload.price_per_impression || '0');
            var days = parseInt(payload.duration_days || '0', 10);
            if (!(imp > 0)) { fail(I18N('ads_target_impressions_gt_zero') || 'Target impressions must be greater than 0.'); }
            if (!(ppi > 0)) { fail(I18N('ads_ppi_gt_zero') || 'Price per impression must be greater than 0.'); }
            if (!(days >= 1)) { fail(I18N('ads_duration_days_min') || 'Duration (days) must be at least 1.'); }
            var bud = parseFloat(payload.total_budget || '0');
            if (!(bud > 0)) { bud = Math.round((imp * ppi) * 100) / 100; payload.total_budget = String(bud); }
            if (bud < MIN_AD_BUDGET) { var amt = '$' + (MIN_AD_BUDGET.toFixed ? MIN_AD_BUDGET.toFixed(2) : MIN_AD_BUDGET); fail(I18N('ui_min_total_budget', { amount: amt }) || ('Minimum total budget is ' + amt + '.')); }
        })();
        // Build FormData
        var fd = new FormData();
        Object.keys(payload).forEach(function(k){ fd.append(k, payload[k]); });

        $.ajax({
            url: VE.endpoint,
            type: 'POST',
            data: fd,
            processData: false,
            contentType: false,
            success: function(res){
                var raw = res, j = null;
                if (typeof raw === 'string') { var s = raw.trim(); if (s.charAt(0) === '{' || s.charAt(0) === '[') { try { j = JSON.parse(s); } catch(_) { j = null; } } }
                else if (typeof raw === 'object' && raw) { j = raw; }

                if (!j || j.status !== 'success') { hidePopupLoader(); showToast((j && j.message) ? j.message : (I18N('ui_unexpected_response') || 'Unexpected response.'), 'error'); return; }
                // Reveal payment options on success
                var adId = j.ad_id || 0;
                if (adId) {
                    $("input[name='ad_id']").val(String(adId));
                    var payContext = resolvePaymentContext();
                    var paymentsActive = true;
                    if (payContext && payContext.hasPaymentsFlag) {
                        paymentsActive = parseGuardBool(payContext.paymentsActive);
                    }
                    if (!paymentsActive) {
                        openVisibilityNotice({
                            message: (payContext && payContext.paymentsMessage) || (I18N('post_visibility_payments_disabled') || 'Payment methods are currently being improved. Please try again later.'),
                            confirmLabel: (payContext && payContext.paymentsAction) || (I18N('ui_ok') || 'OK'),
                            cancelLabel: (payContext && payContext.cancelLabel) || (I18N('menu_cancel') || 'Cancel')
                        });
                        return;
                    }
                    $('.payment_box').removeClass('none');
                    // Hide uploadBtn (avoid duplicate finalize)
                    $(VE.selectors.uploadBtn).addClass('none');
                    if (j.message) { showToast(j.message, 'success'); }
                }
            },
            error: function(xhr){
                hidePopupLoader();
                var msg = I18N('ui_request_failed_retry') || 'Request failed. Please try again.';
                try {
                    if (xhr && xhr.responseText && xhr.responseText.trim().charAt(0) === '{') {
                        var jj = JSON.parse(xhr.responseText);
                        if (jj && jj.message) msg = jj.message;
                    }
                } catch(_) {}
                showToast(msg, 'error');
            },
            complete: function(){
                $btn.prop('disabled', false).removeClass('is-busy');
                hidePopupLoader();
            }
        });
    });

    // ===== Auto-calc Total Budget (video ads) =====
    function resolveCurrency($box){
        var cfg = {
            code: ($box && $box.data('currencyCode')) || (window.DZ && DZ.currencyFormat && DZ.currencyFormat.code) || 'USD',
            symbol: ($box && $box.data('currencySymbol')) || (window.DZ && DZ.currencyFormat && DZ.currencyFormat.symbol) || '',
            precision: parseInt($box && $box.data('amountPrecision'), 10)
        };
        if (!isFinite(cfg.precision) || cfg.precision < 0) {
            var base = window.DZ && DZ.currencyFormat && typeof DZ.currencyFormat.decimalPlaces === 'number' ? DZ.currencyFormat.decimalPlaces : 2;
            cfg.precision = isFinite(base) && base >= 0 ? base : 2;
        }
        return cfg;
    }
    function formatDisplay(amount, cfg){
        if (window.DZ && typeof window.DZ.formatCurrency === 'function') {
            return window.DZ.formatCurrency(amount, cfg.code, cfg.symbol);
        }
        var v = Number(amount);
        if (!Number.isFinite(v)) v = 0;
        return v.toFixed(cfg.precision) + ' ' + (cfg.symbol || cfg.code);
    }
    function formatInput(amount, cfg){
        var v = Number(amount);
        if (!Number.isFinite(v)) v = 0;
        return v.toFixed(cfg.precision);
    }
    function recalcAdBudgetVideo(){
        var $box = $(VE.selectors.finishContainer);
        if (!$box.length) return;
        var curCfg = resolveCurrency($box);
        var imp = parseFloat($box.find("input[name='target_impressions']").val() || '0');
        var ppi = parseFloat($box.find("input[name='price_per_impression']").val() || '0');
        var auto = 0;
        if (Number.isFinite(imp) && Number.isFinite(ppi) && imp >= 0 && ppi >= 0) { auto = Math.round((imp * ppi) * 100) / 100; }
        var $hint = $box.find('.calc-hint .calc-value'); if ($hint.length) { $hint.text(formatDisplay(auto, curCfg)); }
        var $budget = $box.find("input[name='total_budget']"); if (!$budget.length) return;
        var manual = $budget.data('manual') === 1 || $budget.data('manual') === '1';
        var prevAuto = $budget.data('prevAuto');
        if (!manual || (typeof prevAuto !== 'undefined' && String($budget.val()) === String(prevAuto))) {
            var raw = formatInput(auto, curCfg);
            $budget.val(raw);
            $budget.data('prevAuto', raw);
        }
    }
    $(document).on('input', "input[name='total_budget']", function(){ $(this).data('manual', 1); });
    $(document).on('input change', "input[name='target_impressions'], input[name='price_per_impression']", recalcAdBudgetVideo);
    // Run once when finish container becomes visible
    $(document).on('click', VE.selectors.goNext, function(){ setTimeout(recalcAdBudgetVideo, 50); });

    // Start Payment for video ad
    $(document).on('click', '#startPayment', function(){
        var payContext = resolvePaymentContext();
        if (payContext && payContext.hasPaymentsFlag && !parseGuardBool(payContext.paymentsActive)) {
            openVisibilityNotice({
                message: (payContext && payContext.paymentsMessage) || (I18N('post_visibility_payments_disabled') || 'Payment methods are currently being improved. Please try again later.'),
                confirmLabel: (payContext && payContext.paymentsAction) || (I18N('ui_ok') || 'OK'),
                cancelLabel: (payContext && payContext.cancelLabel) || (I18N('menu_cancel') || 'Cancel')
            });
            return;
        }
        var adId = parseInt($("input[name='ad_id']").val() || '0', 10);
        if (!adId) { showToast((I18N('ads_no_draft_to_pay') || 'No draft advertisement to pay for.'), 'error'); return; }
        var provider = $("input[name='pay_provider']:checked").val() || 'stripe';
        var mode = $("input[name='pay_mode']:checked").val() || 'one_time';
        var fd = new FormData();
        fd.append('p', 'ads_create_payment');
        fd.append('csrf_token', $('input[name="csrf_token"]').val() || '');
        fd.append('provider', provider);
        fd.append('mode', mode);
        fd.append('ad_id', String(adId));

        showPopupLoader();
        $.ajax({
            url: VE.endpoint,
            type: 'POST',
            data: fd,
            processData: false,
            contentType: false,
            success: function(res){
                hidePopupLoader();
                var j = null; if (typeof res === 'string') { try { j = JSON.parse(res); } catch(_){} } else if (res && typeof res === 'object') { j = res; }
                if (!j || j.status !== 'success') { showToast((j && j.message) ? j.message : (I18N('ui_failed_to_start_payment') || 'Failed to start payment.'), 'error'); return; }
                if (j.provider === 'wallet') {
                    showToast(j.message || (I18N('ui_payment_completed_wallet') || 'Payment completed from wallet.'), 'success');
                    setTimeout(function(){ window.location.reload(); }, 1200);
                    return;
                }
                if (j.checkout_url) { window.location.href = j.checkout_url; return; }
                showToast((I18N('ui_payment_could_not_be_initiated') || 'Payment could not be initiated.'), 'error');
            },
            error: function(){ hidePopupLoader(); showToast((I18N('ui_payment_init_failed') || 'Payment init failed.'), 'error'); }
        });
    });

    // Enforce provider availability by mode (video ads)
    function toggleProvidersByModeVideo(){
        var mode = $("input[name='pay_mode']:checked").val() || 'one_time';
        var $np = $("input[name='pay_provider'][value='nowpayments']");
        var $cb = $("input[name='pay_provider'][value='coinbase']");
        var disallow = (mode === 'subscription');
        [$np, $cb].forEach(function($el){
            if (!$el.length) return;
            if (disallow) {
                $el.prop('disabled', true);
                if ($el.is(':checked')) { $("input[name='pay_provider'][value='stripe']").prop('checked', true); }
            } else {
                $el.prop('disabled', false);
            }
        });
    }
    $(document).on('change', "input[name='pay_mode']", toggleProvidersByModeVideo);
    toggleProvidersByModeVideo();

    resetToInitial();

})(jQuery, window, document);
