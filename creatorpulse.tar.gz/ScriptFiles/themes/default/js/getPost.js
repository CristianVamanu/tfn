(function ($) {
  "use strict";
  var buildUrl = (window.DZ && window.DZ.buildUrl) || function(path){
    try { var base=(typeof window.site_url==='string'&&window.site_url)?window.site_url:(window.location.origin+window.location.pathname.replace(/[^\/]*$/,'')); if(base.slice(-1)!=='/') base+='/'; return new URL(String(path||'').replace(/^\//,''), base).toString(); } catch(_) { return String(path||''); }
  };
  var I18N = (window.DZ && typeof DZ.i18n === 'function') ? DZ.i18n : function(){ return ''; };

  // ---- Lightweight toast helper (falls back to alert) ----
  function showToast(msg, type){
    try {
      if (window.DZ && typeof DZ.toast === 'function') {
        DZ.toast(String(msg||''), { type: type || 'info', duration: 2200 });
        return;
      }
    } catch(_){}
    try { if (type === 'error') { console.error(msg); } else { console.log(msg); } } catch(_){}
    try { alert(String(msg||'')); } catch(_){}
  }

  // ---- In-flight request and navigation state ----
  var pendingOpenReq = null;   // jqXHR for initial popup open
  var pendingNavReq  = null;   // jqXHR for next/prev loads
  var navInFlight    = false;  // prevents overlapping nav

  function abortOpenReq(){ try { if (pendingOpenReq && pendingOpenReq.abort) pendingOpenReq.abort(); } catch(_){} pendingOpenReq = null; }
  function abortNavReq(){  try { if (pendingNavReq  && pendingNavReq.abort)  pendingNavReq.abort();  } catch(_){} pendingNavReq  = null; }

  function setLoadingNav(isLoading){
    navInFlight = !!isLoading;
    try { $('.post-nav-prev, .post-nav-next').prop('disabled', !!isLoading).toggleClass('is-loading', !!isLoading); } catch(_){}
  }

  /**
   * getPost.js
   *
   * Minimal, robust popup navigation for "full post" view.
   * - No stored state (always derives order from the live DOM)
   * - Works with infinite scroll (order recalculated on every action)
   * - Swaps only the .full-post-inner content to avoid re-creating the overlay
   */

  /** Returns the HTML for the small loader overlay. */
  function veLoaderHTML() {
    return '' +
      '<div class="loading-container absolute">' +
        '<div class="loader">' +
          '<div></div><div></div><div></div><div></div><div></div><div></div>' +
          '<div></div><div></div><div></div><div></div><div></div><div></div>' +
        '</div>' +
        '<p class="loading-text"></p>' +
      '</div>';
  }

  /**
   * Read the current order of posts from the Explore grid.
   * Primary selector: .getFullPost[data-post-id]
   * Fallback: any element with [data-post-id] if the primary list is unavailable.
   * This is re-evaluated on each navigation to remain compatible with infinite scroll.
   */
  function getOrder() {
    var $items = $('.getFullPost[data-post-id]');
    if (!$items.length) { $items = $('[data-post-id]'); }
    return $items.map(function () {
      var pid = parseInt($(this).data('post-id'), 10);
      return isNaN(pid) ? null : pid;
    }).get();
  }

  /** Return the currently displayed post id from the popup. */
  function getCurrentId() {
    var cid = parseInt($('.full-post-inner').first().data('post-id'), 10);
    return Number.isNaN(cid) ? 0 : cid;
  }

  /** Enable/disable prev/next buttons based on the current position in order. */
  function setNavState() {
    var ids = getOrder();
    var cid = getCurrentId();
    var i   = ids.indexOf(cid);
    // If we cannot reliably determine order (e.g., mobile route with no tiles),
    // keep both buttons enabled rather than disabling them incorrectly.
    if (i === -1 || ids.length <= 1) {
      $('.post-nav-prev').prop('disabled', false);
      $('.post-nav-next').prop('disabled', false);
      return;
    }
    var atStart = (i <= 0);
    var atEnd   = (i === ids.length - 1);
    $('.post-nav-prev').prop('disabled', atStart);
    $('.post-nav-next').prop('disabled', atEnd);
  }

  /**
   * Fetch the target post markup and replace only the .full-post-inner content.
   * Keeps the overlay and chrome intact for better UX and performance.
   */
  // (Safari-specific scroll locking was reverted)
  // -------------------------
  // Simple LRU cache + prefetch for post HTML
  // -------------------------
  var CACHE_MAX = 6;
  var cacheMap = new Map();
  var cacheOrder = [];
  var prefetching = new Set();

  // Note: previous attempt to hard-freeze scroll when composer is open was reverted
  // to avoid side effects on desktop. We keep only soft-guards for navigation below.

  function cacheTouch(key){
    var i = cacheOrder.indexOf(key);
    if (i !== -1) cacheOrder.splice(i,1);
    cacheOrder.push(key);
    if (cacheOrder.length > CACHE_MAX) {
      var evict = cacheOrder.shift();
      cacheMap.delete(evict);
    }
  }
  function cacheGet(key){
    var val = cacheMap.get(key);
    if (val) cacheTouch(key);
    return val;
  }
  function cacheSet(key, val){ cacheMap.set(key, val); cacheTouch(key); }

  function parsePostPayload(html, fallbackId){
    var $parsed   = $('<div/>').html(html);
    var $newInner = $parsed.find('.full-post-inner').first();
    var $newPost  = $parsed.find('.post_').first();
    if ($newInner.length) {
      return { kind: 'inner', html: $('<div/>').append($newInner).html() };
    } else if ($newPost.length) {
      return { kind: 'body',  html: $('<div/>').append($newPost).html(), id: fallbackId };
    } else {
      return { kind: 'raw',   html: html, id: fallbackId };
    }
  }

  function applyCachedEntry(entry, targetId){
    var $inner = $('.full-post-inner').first();
    if (!$inner.length) return;
    if (entry.kind === 'inner') {
      // Full wrapper replacement
      $inner.replaceWith($(entry.html));
    } else if (entry.kind === 'body') {
      $inner.attr('data-post-id', String(targetId)).empty().append($(entry.html));
    } else {
      $inner.attr('data-post-id', String(targetId)).html(entry.html);
    }
    try { $('.nav-buttons').attr('data-current-id', String(targetId)); } catch(_){ }
    // Keep nav state in sync (no hard scroll-freeze)
    // no-op
  }

  function prefetchPost(postId){
    if (!postId) return;
    if (cacheGet(postId)) return;
    if (prefetching.has(postId)) return;
    var csrf = $('input[name="csrf_token"]').val();
    prefetching.add(postId);
    $.ajax({
      type: 'POST',
      url: buildUrl('request/requests.php'),
      data: { p: 'getFullPost', post_id: postId, csrf_token: csrf },
      dataType: 'json'
    }).done(function (res) {
      if (!res || res.status !== 'success' || !res.html) {
        showToast((res && res.message) || (I18N('ui_error') || 'Error'), 'error');
        return;
      }
      var entry = parsePostPayload(res.html, postId);
      cacheSet(postId, entry);
    }).always(function(){ prefetching.delete(postId); });
  }

  function prefetchNeighbors(currentId){
    var ids = getOrder();
    var i = ids.indexOf(currentId);
    if (i === -1) return;
    var prevId = (i > 0) ? ids[i-1] : null;
    var nextId = (i < ids.length-1) ? ids[i+1] : null;
    if (prevId) prefetchPost(prevId);
    if (nextId) prefetchPost(nextId);
  }

  function loadPost(targetId) {
    if (!targetId) { return; }

    var csrf   = $('input[name="csrf_token"]').val();
    var $inner = $('.full-post-inner').first();
    if (!$inner.length) { return; }

    // Concurrency guard
    if (navInFlight) { return; }
    setLoadingNav(true);
    abortNavReq();

    // Show a local loader while fetching the next/prev post
    var $loader = $(veLoaderHTML());
    $inner.append($loader);

    // If cached, render immediately
    var cached = cacheGet(targetId);
    if (cached) {
      try { applyCachedEntry(cached, targetId); } catch(_){ }
      setNavState();
      prefetchNeighbors(targetId);
      if (typeof $loader !== 'undefined') { $loader.remove(); }
      setLoadingNav(false);
      return;
    }

    pendingNavReq = $.ajax({
      type: 'POST',
      url: buildUrl('request/requests.php'),
      data: { p: 'getFullPost', post_id: targetId, csrf_token: csrf },
      dataType: 'json'
    }).done(function (res) {
      if (!res || res.status !== 'success' || !res.html) { return; }

      // Parse returned HTML and extract only what we need
      var entry = parsePostPayload(res.html, targetId);
      cacheSet(targetId, entry);
      applyCachedEntry(entry, targetId);
      setNavState();
      prefetchNeighbors(targetId);
      // no-op
    }).fail(function(xhr){
      // Ignore abort errors; notify others
      if (!(xhr && xhr.statusText === 'abort')) {
        showToast(I18N('ui_network_error') || 'Network error', 'error');
      }
    }).always(function () {
      // Remove loader if present
      if (typeof $loader !== 'undefined') { $loader.remove(); }
      setLoadingNav(false);
      abortNavReq();
    });
  }

  /**
   * Move to the previous or next post relative to the currently displayed one.
   * dir: "prev" | "next"
   */
  function go(dir) {
    var ids = getOrder();
    if (!ids.length) { return; }

    var cid = getCurrentId();
    if (!cid) { return; }

    var i = ids.indexOf(cid);

    // If the current id is not found in the order, walk the DOM list as a fallback.
    if (i === -1) {
      var $items = $('.getFullPost[data-post-id]');
      if ($items.length) {
        var target = null;
        $items.each(function (k) {
          var pid = parseInt($(this).data('post-id'), 10);
          if (pid === cid) {
            var j = (dir === 'next') ? k + 1 : k - 1;
            if (j >= 0 && j < $items.length) {
              target = parseInt($items.eq(j).data('post-id'), 10);
            }
            return false; // break
          }
        });
        if (target) { loadPost(target); }
      }
      return;
    }

    var j = (dir === 'next') ? i + 1 : i - 1;
    if (j < 0 || j >= ids.length) { return; }

    loadPost(ids[j]);
  }

  // -------------------------
  // Scroll/Swipe navigation helpers
  // -------------------------
  var scrollNavLock = false;      // prevents rapid-repeat navigation
  var scrollNavCooldown = 450;    // ms; tune to your liking
  var touchStartY = 0;
  var touchStartX = 0;
  var touchActive = false;

  // ----- Pull-To-Refresh (PTR) guard for mobile browsers -----
  // Prevents accidental page refresh when the popup scroll is at the very top
  // and user performs a strong downward scroll gesture.
  var ptrGuardInstalled = false;
  var ptrStartY = 0;
  var ptrStartX = 0;

  function onPtrTouchStart(e) {
    var t = e.touches && e.touches[0];
    if (!t) { return; }
    ptrStartY = t.clientY;
    ptrStartX = t.clientX;
  }

  function onPtrTouchMove(e) {
    var t = e.touches && e.touches[0];
    if (!t) { return; }
    var dy = t.clientY - ptrStartY; // +dy => pulling down
    var dx = t.clientX - ptrStartX;

    // Only consider mostly-vertical, downward pulls starting at/near top
    var mostlyVertical = Math.abs(dy) > Math.abs(dx) * 1.5;
    if (dy > 0 && mostlyVertical && atScrollEdge('up')) {
      // Critical: preventDefault in a non-passive listener to block PTR
      e.preventDefault();
    }
  }

  function installPTRGuard() {
    if (ptrGuardInstalled) { return; }
    var el = getScrollWrap().get(0);
    if (!el) { return; }
    el.addEventListener('touchstart', onPtrTouchStart, { passive: false });
    el.addEventListener('touchmove',  onPtrTouchMove,  { passive: false });
    ptrGuardInstalled = true;
  }

  function removePTRGuard() {
    if (!ptrGuardInstalled) { return; }
    var el = getScrollWrap().get(0);
    if (!el) { ptrGuardInstalled = false; return; }
    el.removeEventListener('touchstart', onPtrTouchStart, { passive: false });
    el.removeEventListener('touchmove',  onPtrTouchMove,  { passive: false });
    ptrGuardInstalled = false;
  }

  /** Return the scrollable wrapper inside the popup (if present). */
  function getScrollWrap() {
    var $wrap = $('.full-post-wrapper').first();
    if ($wrap.length) { return $wrap; }
    // Fallback: if wrapper class is different in some layouts, try the inner
    var $inner = $('.full-post-inner').first();
    return $inner.length ? $inner : $();
  }

  /** Is the scroll area at a given edge? dir: 'up' | 'down' */
  function atScrollEdge(dir) {
    var $wrap = getScrollWrap();
    if (!$wrap.length) { return false; }

    var el = $wrap.get(0);
    var top = $wrap.scrollTop();
    var max = el.scrollHeight - el.clientHeight;

    if (dir === 'up')   { return top <= 0; }
    if (dir === 'down') { return top >= (max - 1); }
    return false;
  }

  /** Gate to avoid spamming navigation while content is still loading */
  function tryNavigate(dir) {
    if (navInFlight) { return; }
    if (scrollNavLock) { return; }
    scrollNavLock = true;
    try { go(dir); } finally {
      setTimeout(function () { scrollNavLock = false; }, scrollNavCooldown);
    }
  }

  /** If comments are still loading or there is an explicit load-more, avoid edge navigation. */
  function hasPendingComments() {
    var $wrap = getScrollWrap();
    if (!$wrap.length) { return false; }

    // Common sentinels you use in markup; harmless if not present
    var pending = $wrap.find('.comments-loading:visible').length > 0
      || $wrap.find('.comment-load-more:visible').length > 0
      || $wrap.find('[data-more-comments="1"]:visible').length > 0;
    return pending;
  }

  /** Touch must begin within this many px from an edge to arm swipe-nav */
  var edgeStartZone = 20; // px

  // -------------------------
  // Event bindings
  // -------------------------

  // Open popup (existing flow; left intact)
  $(document).on("click", ".getFullPost", function () {
    var postID = $(this).data("post-id");
    var csrf   = $('input[name="csrf_token"]').val();
    var $tile  = $(".tile-" + postID);

    if (!csrf) { showToast(I18N('ui_missing_csrf') || 'Missing CSRF', 'error'); return; }

    // Abort any previous open request to avoid duplicates
    abortOpenReq();

    pendingOpenReq = $.ajax({
      type: 'POST',
      url: buildUrl('request/requests.php'),
      data: { p: 'getFullPost', post_id: postID, csrf_token: csrf },
      dataType: 'json',
      beforeSend: function () { if ($tile.length) { $tile.append(veLoaderHTML()); } }
    }).done(function (res) {
      if ($tile.length) { $tile.find(".loading-container").remove(); }
      if (!res || res.status !== 'success' || !res.html) {
        showToast((res && res.message) || (I18N('ui_error') || 'Error'), 'error');
        return;
      }

      var $root = $("#popup-root");
      var $html = $(res.html);

      if ($root.length) { $root.append($html); } else { $("body").append($html); }

      // Optional metadata (harmless if missing in your markup)
      $html.attr('data-current-id', String(postID));
      $html.find('.nav-buttons').attr('data-current-id', String(postID));

      setNavState();
      installPTRGuard();

      // Seed cache for the opened post and prefetch neighbors
      try {
        var entry = parsePostPayload(res.html, postID);
        cacheSet(postID, entry);
      } catch(_){}
      prefetchNeighbors(postID);
    }).fail(function () {
      if ($tile.length) { $tile.find(".loading-container").remove(); }
      showToast(I18N('ui_network_error') || 'Network error', 'error');
    }).always(function(){
      abortOpenReq();
    });
  });

  // Close popup (backdrop or close button)
  $(document).on('click', '.full-post-backdrop, .post-close', function () {
    removePTRGuard();
    abortNavReq();
    navInFlight = false;
    $('#popup-root').empty();
    // cleanup handled by DOM removal
  });

  // Navigation buttons
  $(document).on('click', '.post-nav-next', function (e) {
    e.preventDefault(); e.stopPropagation();
    tryNavigate('next');
  });
  $(document).on('click', '.post-nav-prev', function (e) {
    e.preventDefault(); e.stopPropagation();
    tryNavigate('prev');
  });

  // Keyboard navigation (only when popup exists)
  $(document).on('keydown', function (e) {
    if (!$('.full-post-inner').length) { return; }
    // If comment composer is open, ignore global navigation keys (do not prevent page interactions)
    if (isComposerOpen()) { return; }
    // Avoid when typing in text fields
    if ((function(){
      var ae = document.activeElement; if (!ae) return false; var t=(ae.tagName||'').toLowerCase();
      return (t==='input' || t==='textarea' || ae.isContentEditable);
    })()) { return; }

    if (e.key === 'ArrowUp')   { e.preventDefault(); tryNavigate('prev'); }
    if (e.key === 'ArrowDown') { e.preventDefault(); tryNavigate('next'); }
    if (e.key === 'PageUp')    { e.preventDefault(); tryNavigate('prev'); }
    if (e.key === 'PageDown')  { e.preventDefault(); tryNavigate('next'); }
    if (e.key === ' ')         { e.preventDefault(); tryNavigate(e.shiftKey ? 'prev' : 'next'); }
    if (e.key === 'Escape')    { e.preventDefault(); $('.full-post-container').remove(); }
  });

  // Wheel (mouse/trackpad) navigation: conservative edge behavior
  // Requires a deliberate second wheel at the edge within a short window.
  var edgeDownArmed = false;
  var edgeUpArmed   = false;
  var edgeArmWindow = 700; // ms to perform the second wheel to navigate
  var edgeArmTimer  = null;
  var lastEdgeDownTs = 0;   // timestamp when we first reached bottom edge
  var lastEdgeUpTs   = 0;   // timestamp when we first reached top edge
  var edgeHoldThreshold = 180; // ms: staying at edge this long allows single-step nav

  function disarmEdges() {
    edgeDownArmed = false;
    edgeUpArmed = false;
    if (edgeArmTimer) { clearTimeout(edgeArmTimer); edgeArmTimer = null; }
  }

  // Wheel gesture session gating: ensure only one navigation per continuous scroll
  var wheelSessionTimer = null;
  var wheelSessionIdle = 400; // ms without wheel events = session ended
  var wheelNavigatedThisSession = false;
  function markWheelActivity() {
    if (wheelSessionTimer) { clearTimeout(wheelSessionTimer); }
    // Start session if not active
    if (wheelNavigatedThisSession === false && wheelSessionTimer === null) {
      // no-op; we track navigation separately
    }
    wheelSessionTimer = setTimeout(function () {
      wheelNavigatedThisSession = false;
      wheelSessionTimer = null;
    }, wheelSessionIdle);
  }

  function isComposerOpen() {
    try {
      var $inner = $('.full-post-inner').first();
      if (!$inner.length) { return false; }
      return $inner.find('.make-comment.is-open:visible').length > 0;
    } catch(_) { return false; }
  }

  function isTyping() {
    var ae = document.activeElement;
    if (!ae) return false;
    var tag = (ae.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea' || ae.isContentEditable) return true;
    // role="textbox" gibi durumlar
    try { var r = (ae.getAttribute && ae.getAttribute('role')) || ''; if (r === 'textbox') return true; } catch(_){ }
    return false;
  }

  function isShortContent() {
    var $wrap = getScrollWrap();
    if (!$wrap.length) return false;
    var el = $wrap.get(0);
    if (!el) return false;
    return (el.scrollHeight <= (el.clientHeight + 1));
  }

  $(document).on('wheel', '.full-post-wrapper, .full-post-inner', function (e) {
    if (!$('.full-post-inner').length) { return; } // only when popup exists

    // If comment composer is open, allow normal scrolling but do not navigate
    if (isComposerOpen()) { return; }

    // Avoid navigating while typing in inputs/textareas
    if (isTyping()) { return; }

    var dy = e.originalEvent.deltaY || 0;
    // Adapt threshold based on deltaMode (0: pixel, 1: line, 2: page)
    var dm = e.originalEvent.deltaMode || 0;
    var threshold = (dm === 0) ? 20 : 3; // finer sensitivity for pixels (trackpad)
    if (Math.abs(dy) < threshold) { return; }

    // Mark/extend this wheel activity session window
    markWheelActivity();

    // If there are pending/continued comments, never auto-navigate
    if (hasPendingComments()) { disarmEdges(); return; }

    // If user left the edge (because content scrolled), disarm
    if (!atScrollEdge('down')) { edgeDownArmed = false; lastEdgeDownTs = 0; }
    if (!atScrollEdge('up'))   { edgeUpArmed = false;   lastEdgeUpTs = 0; }

    var shortContent = isShortContent();

    // Downwards intent at bottom edge
    if (dy > 0 && atScrollEdge('down')) {
      // Record time of arrival to the edge
      if (!lastEdgeDownTs) { lastEdgeDownTs = Date.now(); }
      // Short content or holding at edge long enough => single-step nav
      if (shortContent || (Date.now() - lastEdgeDownTs >= edgeHoldThreshold)) {
        e.preventDefault();
        disarmEdges();
        // Only one navigation per continuous wheel session
        if (!wheelNavigatedThisSession) {
          wheelNavigatedThisSession = true;
          tryNavigate('next');
        }
        return;
      }
      if (!edgeDownArmed) {
        // First nudge arms navigation; allow the natural bounce without preventDefault
        edgeDownArmed = true;
        if (edgeArmTimer) { clearTimeout(edgeArmTimer); }
        edgeArmTimer = setTimeout(disarmEdges, edgeArmWindow);
      } else {
        // Second nudge within window => navigate next
        e.preventDefault();
        disarmEdges();
        if (!wheelNavigatedThisSession) {
          wheelNavigatedThisSession = true;
          tryNavigate('next');
        }
      }
      return;
    }

    // Upwards intent at top edge
    if (dy < 0 && atScrollEdge('up')) {
      if (!lastEdgeUpTs) { lastEdgeUpTs = Date.now(); }
      if (shortContent || (Date.now() - lastEdgeUpTs >= edgeHoldThreshold)) {
        e.preventDefault();
        disarmEdges();
        if (!wheelNavigatedThisSession) {
          wheelNavigatedThisSession = true;
          tryNavigate('prev');
        }
        return;
      }
      if (!edgeUpArmed) {
        edgeUpArmed = true;
        if (edgeArmTimer) { clearTimeout(edgeArmTimer); }
        edgeArmTimer = setTimeout(disarmEdges, edgeArmWindow);
      } else {
        e.preventDefault();
        disarmEdges();
        if (!wheelNavigatedThisSession) {
          wheelNavigatedThisSession = true;
          tryNavigate('prev');
        }
      }
      return;
    }

    // Regular scrolling in the middle: reset arming state
    disarmEdges();
  });

  // No additional swallowing inside composer; allow its own internal scroll/gestures

  // Touch swipe (mobile): vertical swipe from edges navigates prev/next
  var touchStartedNearTop = false;
  var touchStartedNearBottom = false;

  $(document).on('touchstart', '.full-post-wrapper, .full-post-inner', function (e) {
    if (!$('.full-post-inner').length) { return; }
    if (isComposerOpen()) { return; }
    if (isTyping()) { return; }
    var t = e.originalEvent.touches && e.originalEvent.touches[0];
    if (!t) { return; }
    touchActive = true;
    touchStartY = t.clientY;
    touchStartX = t.clientX;

    // Determine if touch began near an edge (to avoid accidental nav while reading)
    var $wrap = getScrollWrap();
    if ($wrap.length) {
      var el = $wrap.get(0);
      var top = $wrap.scrollTop();
      var max = el.scrollHeight - el.clientHeight;
      touchStartedNearTop = (top <= edgeStartZone);
      touchStartedNearBottom = (max - top <= edgeStartZone);
    } else {
      touchStartedNearTop = touchStartedNearBottom = false;
    }
  });

  $(document).on('touchmove', '.full-post-wrapper, .full-post-inner', function (e) {
    if (isComposerOpen()) { return; }
    if (!touchActive) { return; }
  });

  $(document).on('touchend', '.full-post-wrapper, .full-post-inner', function (e) {
    if (!touchActive) { return; }
    touchActive = false;
    if (isComposerOpen()) { return; }
    if (isTyping()) { return; }

    var t = e.originalEvent.changedTouches && e.originalEvent.changedTouches[0];
    if (!t) { return; }

    var dy = t.clientY - touchStartY; // +dy = swipe down, -dy = swipe up
    var dx = t.clientX - touchStartX;

    var minSwipe = 40; // px; adjust as needed
    if (Math.abs(dy) < minSwipe || Math.abs(dy) <= Math.abs(dx)) { return; }

    // Avoid navigating if comments are loading/continuing
    if (hasPendingComments()) { return; }
    var shortContent = isShortContent();

    // Swipe up at bottom => next (only if gesture started near bottom and we are still at bottom)
    if (dy < 0 && ((touchStartedNearBottom && atScrollEdge('down')) || shortContent)) {
      tryNavigate('next');
      return;
    }

    // Swipe down at top => prev (only if gesture started near top and we are still at top)
    if (dy > 0 && ((touchStartedNearTop && atScrollEdge('up')) || shortContent)) {
      tryNavigate('prev');
      return;
    }
  });

})(jQuery);
