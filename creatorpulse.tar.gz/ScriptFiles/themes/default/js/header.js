(function () {
    "use strict";
  function baseUrl(){
    try {
      // Prefer global site_url injected by js.php (not always on window)
      var b = (typeof site_url !== 'undefined' && site_url) ||
              (typeof window.site_url !== 'undefined' && window.site_url) || '';
      if (b) { b = String(b); if (!/\/$/.test(b)) b += '/'; return b; }
      // Fallback: try to infer from current location but keep subpath
      var l = window.location;
      // Heuristic: attempt to detect app root by finding '/themes/' in any script tag
      var scripts = document.getElementsByTagName('script');
      for (var i=0;i<scripts.length;i++){
        var src = scripts[i].getAttribute('src') || '';
        var m = src.match(/^(https?:\/\/[^\s]+?)\/(?:[^\s]*?)themes\//i);
        if (m && m[1]) { return m[1].replace(/\/+$/,'/') + '/'; }
      }
      // As a safe fallback, use current page directory (keeps 
      // subpath like /ReelsProject/ on localhost setups)
      var base = l.origin + l.pathname.replace(/[^\/]*$/, '');
      if (base.slice(-1) !== '/') base += '/';
      return base;
    } catch(_) { return '/'; }
  }
  function localBuildUrl(path){
    var base = baseUrl();
    return base + String(path||'').replace(/^\/+/, '');
  }
  // Prefer the canonical global builder if available
  var buildUrl = (function(){ try { if (window.DZ && typeof DZ.buildUrl === 'function') return DZ.buildUrl; } catch(_){} return localBuildUrl; })();
  var REQUESTS_ENDPOINT = buildUrl('request/requests.php');

  // Safely inject popup HTML that may contain <script src="..."> tags.
  // - Removes any <script> tags from HTML string
  // - Appends remaining HTML into target container
  // - Dynamically loads external scripts (same-origin) in order, once per URL
  var __loadedScriptUrls = (function(){ try { return (window.__loadedScriptUrls = window.__loadedScriptUrls || {}); } catch(_) { return {}; } })();
  function loadScriptSequential(url){
    return new Promise(function(resolve, reject){
      try {
        // Already present or loaded
        if (__loadedScriptUrls[url]) { resolve(); return; }
        var exists = document.querySelector('script[src="' + url.replace(/"/g, '\\"') + '"]');
        if (exists) { __loadedScriptUrls[url] = true; resolve(); return; }
        var s = document.createElement('script');
        s.src = url; s.defer = true; s.async = false;
        s.onload = function(){ __loadedScriptUrls[url] = true; resolve(); };
        s.onerror = function(){ reject(new Error('Failed to load script: ' + url)); };
        (document.head || document.body || document.documentElement).appendChild(s);
      } catch (e) { reject(e); }
    });
  }
  function injectHTMLWithScripts(containerEl, html){
    try {
      var tmp = document.createElement('div');
      tmp.innerHTML = String(html || '');
      var scripts = tmp.querySelectorAll('script');
      var urls = [];
      for (var i=0;i<scripts.length;i++){
        var sc = scripts[i];
        var src = sc.getAttribute('src');
        if (src && !/^(?:https?:)?\/\//i.test(src)) { // relative -> make absolute via buildUrl
          try { src = buildUrl(src.replace(/^\/+/, '')); } catch(_){}
        }
        if (src) { urls.push(src); }
        sc.parentNode && sc.parentNode.removeChild(sc);
      }
      containerEl.innerHTML = '';
      while (tmp.firstChild) { containerEl.appendChild(tmp.firstChild); }
      // Load scripts in sequence
      var p = Promise.resolve();
      urls.forEach(function(u){ p = p.then(function(){ return loadScriptSequential(u); }); });
      return p;
    } catch (e) {
      containerEl.innerHTML = String(html || '');
      return Promise.resolve();
    }
  }
  try { window.DZ = window.DZ || {}; window.DZ.buildUrl = buildUrl; } catch(_) {}
    var I18N = (window.DZ && typeof DZ.i18n === 'function') ? DZ.i18n : function(){ return ''; };
    // Ensure global alias is present for any external callers
    if (typeof window.I18N !== 'function') { window.I18N = I18N; }

    (function initDzAlertDialog(){
        var overlayEl = null;
        var activeDialog = null;

        function ensureOverlay(){
            if (overlayEl) { return overlayEl; }
            overlayEl = document.createElement('div');
            overlayEl.className = 'dz-alert-dialog-overlay';
            overlayEl.setAttribute('aria-hidden', 'true');
            overlayEl.setAttribute('role', 'presentation');
            overlayEl.addEventListener('click', function (ev) {
                if (ev.target === overlayEl && activeDialog && activeDialog.dismissible !== false) {
                    closeDialog('cancel');
                }
            }, true);
            (document.body || document.documentElement).appendChild(overlayEl);
            return overlayEl;
        }

        function titleForTone(tone){
            var success = I18N('ui_success_title') || 'Success';
            var warning = I18N('ui_warning_title') || 'Heads up';
            var errorTitle = I18N('ui_error_title') || 'Something went wrong';
            var info = I18N('ui_info_title') || 'Notice';
            switch (tone) {
                case 'success': return success;
                case 'danger': return errorTitle;
                case 'warning': return warning;
                default: return info;
            }
        }

        function safeText(value){
            return (value === null || value === undefined) ? '' : String(value);
        }

        function closeDialog(reason){
            if (!activeDialog) { return; }
            var opts = activeDialog.opts || {};
            var overlay = ensureOverlay();
            overlay.setAttribute('aria-hidden', 'true');
            overlay.classList.remove('is-visible');
            overlay.innerHTML = '';
            var cb = null;
            if (reason === 'confirm' && typeof opts.onConfirm === 'function') {
                cb = opts.onConfirm;
            } else if (reason === 'cancel' && typeof opts.onCancel === 'function') {
                cb = opts.onCancel;
            }
            var resolveFocus = activeDialog.returnFocus;
            activeDialog = null;
            if (typeof resolveFocus === 'function') {
                setTimeout(function(){ try { resolveFocus(); } catch(_){} }, 0);
            }
            if (cb) {
                setTimeout(function(){ try { cb(); } catch(_){} }, 0);
            }
        }

        function showAlertDialog(options){
            var opts = options || {};
            var overlay = ensureOverlay();
            overlay.innerHTML = '';
            var tone = (opts.tone || 'info').toLowerCase();
            if (!/^(success|danger|warning|info|neutral)$/.test(tone)) {
                tone = 'info';
            }
            var dialog = document.createElement('div');
            dialog.className = 'dz-alert-dialog dz-alert-dialog--' + tone;
            dialog.setAttribute('role', 'alertdialog');
            dialog.setAttribute('aria-modal', 'true');

            var body = document.createElement('div');
            body.className = 'dz-alert-dialog__body';

            var title = safeText(opts.title || titleForTone(tone));
            if (title) {
                var titleEl = document.createElement('h3');
                titleEl.className = 'dz-alert-dialog__title';
                titleEl.textContent = title;
                body.appendChild(titleEl);
            }

            var messageEl = document.createElement('p');
            messageEl.className = 'dz-alert-dialog__message';
            messageEl.textContent = safeText(opts.message);
            body.appendChild(messageEl);
            dialog.appendChild(body);

            var actions = document.createElement('div');
            actions.className = 'dz-alert-dialog__actions';

            var confirmLabel = safeText(opts.confirmLabel || (I18N('ui_ok') || 'OK'));
            var cancelLabel = safeText(opts.cancelLabel || '');

            if (cancelLabel) {
                var cancelBtn = document.createElement('button');
                cancelBtn.type = 'button';
                cancelBtn.className = 'dz-alert-dialog__btn dz-alert-dialog__btn--ghost';
                cancelBtn.textContent = cancelLabel;
                cancelBtn.addEventListener('click', function(){ closeDialog('cancel'); });
                actions.appendChild(cancelBtn);
            }

            var confirmBtn = document.createElement('button');
            confirmBtn.type = 'button';
            confirmBtn.className = 'dz-alert-dialog__btn dz-alert-dialog__btn--primary';
            confirmBtn.textContent = confirmLabel || (I18N('ui_ok') || 'OK');
            confirmBtn.addEventListener('click', function(){ closeDialog('confirm'); });
            actions.appendChild(confirmBtn);

            dialog.appendChild(actions);
            overlay.appendChild(dialog);
            overlay.setAttribute('aria-hidden', 'false');
            overlay.classList.add('is-visible');

            var previousActive = document.activeElement;
            activeDialog = {
                opts: opts,
                dismissible: opts.dismissible !== false,
                returnFocus: function(){
                    if (previousActive && typeof previousActive.focus === 'function') {
                        previousActive.focus();
                    }
                }
            };
            requestAnimationFrame(function(){
                try { confirmBtn.focus(); } catch(_){}
            });
        }

        document.addEventListener('keydown', function(ev){
            if (ev.key === 'Escape' && activeDialog && activeDialog.dismissible !== false) {
                closeDialog('cancel');
            }
        }, true);

        try {
            window.DZ = window.DZ || {};
            window.DZ.showAlertDialog = showAlertDialog;
        } catch(_){}
    })();

    // Reference to the dynamic content container
    var clickBox = document.querySelector(".click_box");

    var CLICK_BOX_LOADER_DOTS = '<div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>';

    function renderClickBoxLoader(message) {
        var text = (typeof message === 'string' && message !== '') ? message : '';
        var textBlock = text ? '<p class="loading-text">' + text + '</p>' : '';
        return '' +
            '<div class="click-box-loader">' +
                '<div class="click-box-loader__panel" role="status" aria-live="polite" aria-busy="true">' +
                    '<div class="loader">' + CLICK_BOX_LOADER_DOTS + '</div>' +
                    textBlock +
                '</div>' +
            '</div>';
    }

    function getLoaderMessage(type) {
        var fallback = I18N('ui_logging_in_wait') || 'Logging in, please wait...';
        if (!type) { return fallback; }
        var normalized = String(type).toLowerCase();
        if (normalized === 'menu') {
            return I18N('ui_loading_menu') || 'Loading menu...';
        }
        if (normalized === 'new_messages') {
            return I18N('ui_loading_messages') || 'Loading messages...';
        }
        return fallback;
    }

    function positionClickBox(clickable) {
        if (!clickBox || !clickable || !document.body.contains(clickable)) return;

        requestAnimationFrame(function () {
            // Prevent any CSS transition flicker while we compute and move
            var prevTransition = clickBox.style.transition;
            clickBox.style.transition = "none";

            // Make measurable but not visible
            clickBox.style.visibility = "hidden";
            clickBox.style.display = "block";

            var wrapper = clickBox.querySelector(".click_box_wrapper");
            var boxWidth;

            if (wrapper) {
                var prevWTransition = wrapper.style.transition;
                var prevWVis = wrapper.style.visibility;
                var prevWDisp = wrapper.style.display;
                wrapper.style.transition = "none";
                wrapper.style.visibility = "hidden";
                wrapper.style.display = "block";
                boxWidth = Math.round(wrapper.getBoundingClientRect().width);
                wrapper.style.display = prevWDisp || "";
                wrapper.style.visibility = prevWVis || "";
                wrapper.style.transition = prevWTransition || "";
            } else {
                boxWidth = Math.round(clickBox.getBoundingClientRect().width);
            }

            var rect = clickable.getBoundingClientRect();

            // If the trigger is inside the header, use a small fixed top (0–10px)
            // so the dropdown hugs the header as intended. Otherwise, fallback
            // to document-based placement.
            var inHeader = !!clickable.closest('.site_header');
            var top;
            var left;

            if (inHeader) {
                // Use viewport-based positioning for stable behavior with sticky headers
                clickBox.style.position = "fixed";
                // Keep very small gap from top of viewport (aligns just under header)
                top = 65; // desired 0–10px according to design
                left = Math.round(rect.left + (rect.width / 2) - (boxWidth / 2));
            } else {
                // Fallback: absolute to document flow
                clickBox.style.position = "absolute";
                top = Math.round(rect.bottom + window.scrollY);
                left = Math.round(rect.left + window.scrollX + (rect.width / 2) - (boxWidth / 2));
            }

            // Clamp horizontal position within viewport
            if (left < 10) left = 10;
            var maxLeft = (inHeader ? window.innerWidth : window.innerWidth + window.scrollX) - boxWidth - 10;
            if (left > maxLeft) left = Math.max(10, maxLeft);

            clickBox.style.top = top + "px";
            clickBox.style.left = left + "px";
            clickBox.style.zIndex = "9999";

            // Force layout then restore transition
            void clickBox.offsetWidth;
            clickBox.style.transition = prevTransition || "";

            // Finally reveal
            clickBox.style.visibility = "";
            clickBox.classList.add("show");
        });
    }

    // Handle all clicks using event delegation
    document.addEventListener("click", function (e) {
        var target = e.target;

        // Get the closest element with the .get_box class
        var clickable = target.closest(".get_box");
        if (!clickable) {
            // If clicked inside the clickBox itself, do nothing
            if (clickBox.contains(target)) {
                return;
            }
            // Ignore clicks on the mobile search button or inside the search wrapper
            var isSearchBtn  = !!(target.closest && target.closest('.mobile-search-toggle'));
            var inSearchWrap = !!(target.closest && target.closest('.header_search_wrapper'));
            if (isSearchBtn || inSearchWrap) { return; }

            // Otherwise close the box
            clickBox.innerHTML = "";
            clickBox.classList.remove("show");
            clickBox.removeAttribute("style");
            document.querySelectorAll(".get_box").forEach(function (el) {
                el.classList.remove("active");
            });
            try { var hc0 = document.querySelector('.site_header_container'); if (hc0) hc0.classList.remove('search-expanded'); } catch(_){}
            return;
        }

        if (clickable.classList.contains("active")) {
            var dtOnToggle = clickable.getAttribute("data-type");
            // For SEARCH: do nothing on second click (keep it open)
            if (dtOnToggle === "search") {
                return; // inert on second click
            }
            // For others: behave as a toggle (close)
            clickBox.innerHTML = "";
            clickBox.classList.remove("show");
            clickBox.removeAttribute("style");
            clickable.classList.remove("active");
            try { var hcT = document.querySelector('.site_header_container'); if (hcT) hcT.classList.remove('search-expanded'); } catch(_){}
            return;
        }

        document.querySelectorAll(".get_box").forEach(function (el) {
            el.classList.remove("active");
        });
        clickable.classList.add("active");
        // Mark header as expanded when search is the trigger (for full-width overlay input)
        try {
            var hc = document.querySelector('.site_header_container');
            var dtNow = clickable.getAttribute('data-type');
            if (hc) { hc.classList.toggle('search-expanded', dtNow === 'search'); }
        } catch(_){}
        // Prepare box to avoid flicker from old position
        clickBox.classList.remove("show");
        clickBox.style.visibility = "hidden";
        clickBox.style.display = "block";

        var dataType = clickable.getAttribute("data-type");
        if (!dataType) {
            return;
        }

        function decodeUnicodeEscapes(str) {
            if (typeof str !== 'string' || str === '') {
                return str || '';
            }
            var result = '';
            var i = 0;
            var len = str.length;
            var fromCodePoint = typeof String.fromCodePoint === 'function'
                ? String.fromCodePoint
                : function (codePoint) {
                    if (codePoint <= 0xFFFF) {
                        return String.fromCharCode(codePoint);
                    }
                    codePoint -= 0x10000;
                    return String.fromCharCode(
                        (codePoint >> 10) + 0xD800,
                        (codePoint % 0x400) + 0xDC00
                    );
                };
            while (i < len) {
                var ch = str.charAt(i);
                if (ch === '\\' && str.charAt(i + 1) === 'u') {
                    var hex = str.substr(i + 2, 4);
                    if (/^[0-9a-fA-F]{4}$/.test(hex)) {
                        var code = parseInt(hex, 16);
                        i += 6;
                        if (code >= 0xD800 && code <= 0xDBFF && str.charAt(i) === '\\' && str.charAt(i + 1) === 'u') {
                            var lowHex = str.substr(i + 2, 4);
                            if (/^[0-9a-fA-F]{4}$/.test(lowHex)) {
                                var lowCode = parseInt(lowHex, 16);
                                if (lowCode >= 0xDC00 && lowCode <= 0xDFFF) {
                                    i += 6;
                                    var codePoint = ((code - 0xD800) << 10) + (lowCode - 0xDC00) + 0x10000;
                                    result += fromCodePoint(codePoint);
                                    continue;
                                }
                            }
                        }
                        result += String.fromCharCode(code);
                        continue;
                    }
                }
                result += ch;
                i += 1;
            }
            return result;
        }

        function decodeLooseHtmlResponse(rawPayload){
            if (typeof rawPayload !== 'string') { return null; }
            var trimmedPayload = rawPayload.trim();
            var match = trimmedPayload.match(/"html"\s*:\s*"([\s\S]*)"\s*\}\s*$/);
            if (!match) { return null; }
            var captured = match[1];
            var sanitized = captured.replace(/\\(?!["\\/bfnrtu]|u[0-9a-fA-F]{4})/g, '\\\\');
            try {
                return JSON.parse('["' + sanitized + '"]')[0];
            } catch (err) {
                try {
                    var manual = sanitized;
                    manual = manual.replace(/\\r/g, '\r')
                                   .replace(/\\n/g, '\n')
                                   .replace(/\\t/g, '\t')
                                   .replace(/\\\//g, '/')
                                   .replace(/\\"/g, '"')
                                   .replace(/\\\\/g, '\\');
                    manual = decodeUnicodeEscapes(manual);
                    return manual;
                } catch(_) {
                    return null;
                }
            }
        }

        // CSRF token from hidden input
        var csrfTokenInput = document.querySelector('input[name="csrf_token"]');
        var csrfToken = csrfTokenInput ? csrfTokenInput.value : null;

        if (!csrfToken) {
            try {
                window.DZ = window.DZ || {};
                var _I18N = (DZ && typeof DZ.i18n==='function') ? DZ.i18n : (typeof window.I18N==='function' ? window.I18N : function(){return '';});
                if (typeof DZ.toast==='function') {
                    DZ.toast(_I18N('ui_missing_csrf') || 'Missing CSRF', { type:'error', duration: 2200 });
                } else {
                    alert(_I18N('ui_missing_csrf') || 'Missing CSRF');
                }
            } catch(_) { alert('Missing CSRF'); }
            return;
        }

        // Create dynamic content container
        var tempContent = document.createElement("div");
        tempContent.className = "click_box_inner";
        var waitText = getLoaderMessage(dataType);
        tempContent.innerHTML = renderClickBoxLoader(waitText);

        // Clear and insert new content
        clickBox.innerHTML = "";
        clickBox.appendChild(tempContent);
        positionClickBox(clickable);

        // Send AJAX request to load content
        var xhr = new XMLHttpRequest();
        xhr.open("POST", REQUESTS_ENDPOINT, true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    var raw = xhr.responseText || '';
                    var trimmed = raw.trim();
                    if (trimmed.charCodeAt && trimmed.charCodeAt(0) === 0xFEFF) {
                        trimmed = trimmed.slice(1);
                    }
                    if (trimmed === '') {
                        var emptyMsg = I18N('ui_empty_response') || 'Empty response.';
                        tempContent.innerHTML = "<p class='error'>" + emptyMsg + "</p>";
                        positionClickBox(clickable);
                        return;
                    }
                    var firstChar = trimmed.charAt(0);
                    if (firstChar === '<') {
                        tempContent.innerHTML = raw;
                        positionClickBox(clickable);
                        return;
                    }
                    var response;
                    if (firstChar === '{' || firstChar === '[') {
                        try {
                            response = JSON.parse(trimmed);
                        } catch (e) {
                            var looseFromCatch = decodeLooseHtmlResponse(trimmed);
                            if (looseFromCatch) {
                                tempContent.innerHTML = looseFromCatch;
                                positionClickBox(clickable);
                                return;
                            }
                            var invJson = I18N('ui_invalid_server_response') || 'Invalid server response.';
                            tempContent.innerHTML = "<p class='error'>" + invJson + "</p>";
                            console.warn("Invalid JSON response for click box:", e, raw);
                            positionClickBox(clickable);
                            return;
                        }
                    } else {
                        var invFmt = I18N('ui_invalid_server_response') || 'Invalid server response.';
                        tempContent.innerHTML = "<p class='error'>" + invFmt + "</p>";
                        positionClickBox(clickable);
                        return;
                    }
                    if (response && response.status === "success" && response.html) {
                        tempContent.innerHTML = response.html;
                        positionClickBox(clickable);
                    } else {
                        var loose = decodeLooseHtmlResponse(trimmed);
                        if (loose) {
                            tempContent.innerHTML = loose;
                            positionClickBox(clickable);
                            return;
                        }
                        var errLabel = I18N('ui_error_label') || 'Error:';
                        var unk = I18N('ui_unknown_error') || 'Unknown error.';
                        tempContent.innerHTML = "<p class='error'>" + errLabel + " " + ((response && response.message) || unk) + "</p>";
                        positionClickBox(clickable);
                    }
                } else {
                    var displayMessage = '';
                    var rawBody = xhr.responseText || '';
                    if (rawBody) {
                        try {
                            var parsed = JSON.parse(rawBody);
                            if (parsed && typeof parsed === 'object') {
                                displayMessage = parsed.message_text || parsed.message || '';
                            }
                        } catch(_) {
                            var loose = decodeLooseHtmlResponse(rawBody.trim());
                            if (loose) {
                                tempContent.innerHTML = loose;
                                positionClickBox(clickable);
                                return;
                            }
                        }
                    }

                    if (!displayMessage) {
                        if (xhr.status === 401 || xhr.status === 403) {
                            displayMessage = I18N('ui_session_expired') || 'Your session has expired. Please refresh and sign in again.';
                        } else {
                            displayMessage = I18N('ui_server_error') || 'Server error. Please try again later.';
                        }
                    }

                    tempContent.innerHTML = "<p class='error'>" + displayMessage + "</p>";
                    positionClickBox(clickable);
                    try {
                        if (window.DZ && typeof DZ.toast === 'function') {
                            DZ.toast(displayMessage, { type: 'error', duration: 2600 });
                        }
                    } catch(_){ }
                }
            }
        };

        xhr.send("p=" + encodeURIComponent(dataType) + "&csrf_token=" + encodeURIComponent(csrfToken));

        // Removed delayed call to positionClickBox
    });

    // Close the box when clicking outside (delayed to preserve internal clicks)
    document.addEventListener("mousedown", function (e) {
        var clickTarget = e.target;
        var insideBox = clickBox && clickBox.contains(clickTarget);
        // Important: consider ANY toggle, not only the one already marked active.
        var clickingAnyToggle = !!(clickTarget.closest && (clickTarget.closest('.get_box') || clickTarget.closest('.mobile-search-toggle') || clickTarget.closest('.header_search_wrapper')));

        // Only close if not clicking inside the box AND not clicking any toggle
        if (!insideBox && !clickingAnyToggle) {
            setTimeout(function () {
                clickBox.innerHTML = "";
                clickBox.classList.remove("show");
                clickBox.removeAttribute("style");

                // Clear search input value if search box is being closed
                var searchInput = document.querySelector('.search_input.get_box[data-type="search"]');
                if (searchInput) {
                    searchInput.value = "";
                }

                document.querySelectorAll('.get_box').forEach(function (el) {
                    el.classList.remove('active');
                });
                try { var hc3 = document.querySelector('.site_header_container'); if (hc3) hc3.classList.remove('search-expanded'); } catch(_){}
            }, 50);
        }
    });

    // Close the box with the Escape key
    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape") {
            clickBox.innerHTML = "";
            clickBox.classList.remove("show");
            clickBox.removeAttribute("style");
            document.querySelectorAll(".get_box").forEach(function (el) {
                el.classList.remove("active");
            });
            try { var hc4 = document.querySelector('.site_header_container'); if (hc4) hc4.classList.remove('search-expanded'); } catch(_){}
        }
    });

    if (window.ResizeObserver) {
        var cbResizeObserver = new ResizeObserver(function () {
            var activeClickable = document.querySelector(".get_box.active");
            if (activeClickable && clickBox.classList.contains("show")) {
                positionClickBox(activeClickable);
            }
        });
        cbResizeObserver.observe(clickBox);
    }

    window.addEventListener("resize", function () {
        var activeClickable = document.querySelector(".get_box.active");
        if (activeClickable) {
            positionClickBox(activeClickable);
        }
    });
    $(document).on('keyup', '.search_input.get_box[data-type="search"]', function () {
        var keyword = $.trim($(this).val());
        var $resultsContainer = $('.click_box_new_search_results');
        var csrf_token = $('input[name="csrf_token"]').val();
        var creatorOnly = 0;
        try {
            var flag = document.querySelector('.search_bar_container');
            if (flag && flag.getAttribute('data-creator-only') === '1') {
                creatorOnly = 1;
            }
        } catch (_) {}

        var waitText2 = I18N('ui_logging_in_wait') || 'Logging in, please wait...';
        $resultsContainer.html(renderClickBoxLoader(waitText2));

        if (keyword.length === 0) {
            setTimeout(function() {
                $(".recent").show();
                $(".s_r").addClass('s_result');
            }, 1000);
            $resultsContainer.empty();
            return;
        }

        clearTimeout(this._searchTimer);
        this._searchTimer = setTimeout(function () {
            $(".recent").hide();
        $.ajax({
            type: 'POST',
            url: buildUrl('request/search-users.php'),
            dataType: 'text',
            cache: false,
            data: {
                user_search: keyword,
                csrf_token: csrf_token,
                creator_only: creatorOnly
            },
            success: function (payload) {
                var response = payload;
                if (typeof response === 'string') {
                    var trimmed = response.trim();
                    if (trimmed === '') {
                        $resultsContainer.empty();
                        return;
                    }
                    if (trimmed.charAt(0) === '<') {
                        $resultsContainer.html(trimmed);
                        $(".s_r").removeClass('s_result');
                        return;
                    }
                    if (trimmed.charAt(0) === '{' || trimmed.charAt(0) === '[') {
                        try {
                            response = JSON.parse(trimmed);
                        } catch (parseErr) {
                            console.error('Search response JSON parse failed:', parseErr, trimmed);
                            $resultsContainer.html(trimmed);
                            return;
                        }
                    }
                }
                if (response && response.status === 'success') {
                    var htmlPayload = response.html || '';
                    if (typeof htmlPayload === 'string' && htmlPayload !== '') {
                        try {
                            htmlPayload = atob(htmlPayload);
                        } catch (decodeErr) {
                            console.error('Search response decode failed:', decodeErr);
                            htmlPayload = response.html || '';
                        }
                    }
                    $resultsContainer.html(htmlPayload);
                    $(".s_r").removeClass('s_result');
                } else {
                    setTimeout(function() {
                        $(".recent").show();
                        $(".s_r").addClass('s_result');
                    }, 1000);
                    var message = (response && response.message) ? response.message : 'Unexpected response.';
                    console.warn(message);
                }
            },
            error: function (xhr, status, error) {
                console.error('Search AJAX error:', error, xhr && xhr.responseText);
            }
        });
        }, 300);
    });
    $(document).on('click', '.search-filter-toggle', function (e) {
        e.preventDefault();
        var $toggle = $(this);
        var $dropdown = $toggle.closest('.search-filter-dropdown');
        if (!$dropdown.length) { return; }
        var willOpen = !$dropdown.hasClass('is-open');
        $('.search-filter-dropdown.is-open').removeClass('is-open')
            .find('.search-filter-toggle').attr('aria-expanded', 'false');
        if (willOpen) {
            $dropdown.addClass('is-open');
            $toggle.attr('aria-expanded', 'true');
        }
    });
    $(document).on('click', function (e) {
        var $target = $(e.target);
        if ($target.closest('.search-filter-dropdown').length) { return; }
        $('.search-filter-dropdown.is-open').removeClass('is-open')
            .find('.search-filter-toggle').attr('aria-expanded', 'false');
    });
    $(document).on('click', '.search-filter-option', function () {
        var $btn = $(this);
        var $dropdown = $btn.closest('.search-filter-dropdown');
        if (!$dropdown.length) { return; }
        $dropdown.find('.search-filter-option').removeClass('active').attr('aria-selected', 'false');
        $btn.addClass('active').attr('aria-selected', 'true');
        var label = $.trim($btn.text());
        $dropdown.find('.search-filter-label').text(label);
        var creatorOnly = String($btn.data('creator-only') || '0');
        var $container = $('.search_bar_container').first();
        if ($container.length) {
            $container.attr('data-creator-only', creatorOnly === '1' ? '1' : '0');
        }
        var $input = $('.search_input.get_box[data-type="search"]').first();
        if ($input.length && $.trim($input.val()).length) {
            $input.trigger('keyup');
        }
        $dropdown.removeClass('is-open')
            .find('.search-filter-toggle').attr('aria-expanded', 'false');
    });
    $(document).on("click", ".new_item", function () {

        var $trigger    = $(this);
        var parentPopup = $trigger.closest('.popUp-container');
        var pop_type    = $trigger.data("pop");
        var csrf_token  = $('input[name="csrf_token"]').val() || "";

        $.ajax({
            type: "POST",
            url: buildUrl('request/requests.php'),
            data: {
            p: "popUp",
            pop_type: pop_type,
            csrf_token: csrf_token
            },
            dataType: "json",      // ← Expect the response in JSON format
            cache: false,
            success: function (res) {
            if (res && res.status === "success" && res.html) {
                if (parentPopup && parentPopup.length) {
                    parentPopup.remove();
                }
                var root = document.getElementById('popup-root');
                if (!root) { root = document.body; }
                injectHTMLWithScripts(root, res.html).catch(function(err){ console.warn('Popup scripts load failed:', err); });
            } else {
                console.warn("Unexpected response:", res);
                alert(res && res.message ? res.message : "Beklenmedik cevap.");
            }
            },
            error: function (xhr, status, error) {
            console.error("AJAX error:", status, error, xhr.responseText);
            alert("İstek başarısız oldu.");
            }
        });
    });
    $(document).on("click", ".close_pop", function(){
        $(".popUp-container").remove();
    });
    // Live tips summary calculation
    function formatMoney(n, cur, precision, symbol){
        if (window.DZ && typeof window.DZ.formatCurrency === 'function') {
            return window.DZ.formatCurrency(n, cur, symbol);
        }
        var dec;
        if (typeof precision === 'number' && isFinite(precision)) {
            dec = Math.max(0, precision);
        } else {
            var abs = Math.abs(n);
            dec = abs >= 0.01 || abs === 0 ? 2 : 4;
        }
        var factor = Math.pow(10, dec);
        var rounded = Math.round((n + Number.EPSILON) * factor) / factor;
        return rounded.toFixed(dec) + ' ' + (cur || 'USD');
    }
    function computeTipsSummary(){
        var $modal = $("#tipsModal");
        if(!$modal.length) return;
        var $form = $modal.find(".tips-form");
        var cur   = $form.data("currency") || 'USD';
        var curSymbol = $form.data('currency-symbol') || '';
        var basePrecision = parseInt($form.data('amount-precision'), 10);
        if (!isFinite(basePrecision)) { basePrecision = undefined; }
        var formType = ($form.data('form-type') || $form.attr('data-form-type') || '').toString();
        var pctFee= parseFloat($form.data("fee-percent")) || 0;
        var fixFee= parseFloat($form.data("fee-fixed"))   || 0;
        var pctTax= parseFloat($form.data("tax-percent")) || 0;

        var $inp  = $form.find('#tipAmount');
        var raw   = ($inp.val() || '').toString().trim();
        if (!raw && formType === 'purchase') {
            var fixedAttr = $form.data('fixed-amount') || $form.attr('data-fixed-amount') || '';
            if (!fixedAttr && $inp.attr('data-display')) {
                fixedAttr = $inp.attr('data-display');
            }
            if (fixedAttr) {
                raw = fixedAttr.toString();
            }
        }
        var normalized = raw.replace(/,/g, '.').replace(/[^0-9.]/g, '');
        if (normalized.split('.').length > 2) {
            var pieces = normalized.split('.');
            normalized = pieces.shift() + '.' + pieces.join('');
        }
        if(raw !== normalized){ $inp.val(normalized); }
        var min = parseFloat($inp.data('min') || 0) || 0;
        var max = parseFloat($inp.data('max') || 0) || 0;
        var amount = parseFloat(normalized || '0');
        if (!isFinite(amount)) { amount = 0; }
        if (amount <= 0 && formType === 'purchase') {
            var fixedAmount = parseFloat($form.data('fixed-amount') || $form.attr('data-fixed-amount') || '0');
            if (isFinite(fixedAmount) && fixedAmount > 0) {
                amount = fixedAmount;
            }
        }
        if(max > 0 && amount > max){ amount = max; }
        if(min > 0 && normalized !== '' && amount < min){ amount = min; }

        var fee, tax, total;
        if (formType === 'subscription') {
            var subFeePct = parseFloat($form.data('subscription-fee-percent')) || 0;
            fee = amount * (subFeePct / 100);
            tax = fixFee + (amount * (pctTax / 100));
            total = amount + fee + tax;
        } else {
            fee = (amount * (pctFee / 100)) + fixFee;
            tax = (amount * (pctTax / 100));
            total = amount + fee + tax;
        }

        $modal.find('.tips-subtotal-amount').text(formatMoney(amount, cur, basePrecision, curSymbol));
        $modal.find('.tips-fee-amount').text(formatMoney(fee, cur, basePrecision, curSymbol));
        $modal.find('.tips-taxes-amount').text(formatMoney(tax, cur, basePrecision, curSymbol));
        $modal.find('.tips-total-amount').text(formatMoney(total, cur, basePrecision, curSymbol));
    }
    $(document).on('input blur', '#tipsModal #tipAmount', function(){
        computeTipsSummary();
    });
    // Initialize when modal is inserted
    $(document).on('click', '.sendTip, .sendTipUser, .sendLiveTip', function(){
        // after AJAX success, allow a short delay then compute once
        setTimeout(computeTipsSummary, 100);
    });
    // Also initialize when purchase modal is opened
    $(document).on('click', '.unlockPost', function(){
        setTimeout(computeTipsSummary, 120);
    });
    /* Get Tips PopUp */
    $(document).on("click",".sendTip", function(){
        var postID = $(this).data("id");
        var csrf_token = $('input[name="csrf_token"]').val() || "";
        $.ajax({
            type: "POST",
            url: REQUESTS_ENDPOINT,
            data: {
            p: "sendTip",
            post_id: postID,
            csrf_token: csrf_token
            },
            dataType: "json",      // ← Expect the response in JSON format
            cache: false,
            success: function (res) {
            if (res && res.status === "success" && res.html) {
                var root = document.getElementById('popup-root');
                if (!root) { root = document.body; }
                injectHTMLWithScripts(root, res.html).catch(function(err){ console.warn('Popup scripts load failed:', err); });
            } else if (res && res.code === 'SELF_TIP_NOT_ALLOWED') {
                var selfMsg = (res && res.message) ? String(res.message) : (I18N('pay_tip_self_not_allowed') || 'You cannot send a tip to yourself.');
                if (typeof showTipInfoModal === 'function') {
                    showTipInfoModal(selfMsg);
                } else if (typeof showGlobalTipToast === 'function') {
                    showGlobalTipToast(selfMsg, 'info');
                } else {
                    try { alert(selfMsg); } catch(_) {}
                }
                return;
            } else {
                console.warn("Unexpected response:", res);
                alert(res && res.message ? res.message : "Beklenmedik cevap.");
            }
            },
            error: function (xhr, status, error) {
            console.error("AJAX error:", status, error, xhr.responseText);
            alert("İstek başarısız oldu.");
            }
        });
    });

    function walletUserIsLoggedIn(){
        var body = document.body;
        if (body && body.getAttribute('data-logged-in') === '1') {
            return true;
        }
        if (document.querySelector('meta[name="admin-csrf"]')) {
            return true;
        }
        return false;
    }

    function walletCsrfToken(){
        if (document.querySelector('meta[name="admin-csrf"]')) {
            var front = document.getElementById('frontendCsrfToken');
            if (front && front.value) {
                return front.value;
            }
        }
        var input = document.querySelector('input[name="csrf_token"]');
        return input ? (input.value || '') : '';
    }

    $(document).on('click', '.walletTopup', function(){
        if (!walletUserIsLoggedIn()) {
            return;
        }
        var csrfToken = walletCsrfToken();
        if (!csrfToken) {
            try { window.location.href = buildUrl('settings?tab=bank'); } catch(_) { window.location.href = 'settings?tab=bank'; }
            return;
        }
        $.ajax({
            type: "POST",
            url: REQUESTS_ENDPOINT,
            data: {
                p: "wallet_topup_modal",
                csrf_token: csrfToken
            },
            dataType: "json",
            cache: false,
            success: function(res){
                if (res && res.status === 'success' && res.html) {
                    var root = document.getElementById('popup-root');
                    if (!root) { root = document.body; }
                    injectHTMLWithScripts(root, res.html).catch(function(err){ console.warn('Popup scripts load failed:', err); });
                } else if (res && res.code === 'wallet_topup_no_providers' && res.html) {
                    var missingRoot = document.getElementById('popup-root');
                    if (!missingRoot) { missingRoot = document.body; }
                    injectHTMLWithScripts(missingRoot, res.html).catch(function(err){ console.warn('Popup scripts load failed:', err); });
                } else {
                    if (res && res.message && /login/i.test(String(res.message))) {
                        try { window.location.href = buildUrl('settings?tab=bank'); } catch(_) { window.location.href = 'settings?tab=bank'; }
                        return;
                    }
                    console.warn('Unexpected response:', res);
                    alert(res && res.message ? res.message : 'Beklenmedik cevap.');
                }
            },
            error: function(xhr, status, error){
                console.error('AJAX error:', status, error, xhr.responseText);
                alert('İstek başarısız oldu.');
            }
        });
    });

    /* Get Tips PopUp by recipient (Live/Profile Thanks) */
    $(document).on("click", ".sendTipUser, .sendLiveTip", function(){
        var recipientId = $(this).data("id");
        var liveId = 0; try { var $root = $(".contents_box[data-live-id]"); if ($root.length) { liveId = parseInt($root.attr('data-live-id')||'0',10)||0; } } catch(e){}
        var csrf_token = $('input[name="csrf_token"]').val() || "";
        $.ajax({
            type: "POST",
            url: REQUESTS_ENDPOINT,
            data: { p: "sendTipUser", recipient_id: recipientId, live_id: liveId, csrf_token: csrf_token },
            dataType: "json",
            cache: false,
            success: function(res){
                if (res && res.status === 'success' && res.html){
                    var root = document.getElementById('popup-root');
                    if (!root) { root = document.body; }
                    injectHTMLWithScripts(root, res.html).catch(function(err){ console.warn('Popup scripts load failed:', err); });
                } else if (res && res.code === 'SELF_TIP_NOT_ALLOWED') {
                    var selfTipMsg = (res && res.message) ? String(res.message) : (I18N('pay_tip_self_not_allowed') || 'You cannot send a tip to yourself.');
                    if (typeof showTipInfoModal === 'function') {
                        showTipInfoModal(selfTipMsg);
                    } else if (typeof showGlobalTipToast === 'function') {
                        showGlobalTipToast(selfTipMsg, 'info');
                    } else {
                        try { alert(selfTipMsg); } catch(_) {}
                    }
                    return;
                } else {
                    console.warn('Unexpected response:', res);
                    alert(res && res.message ? res.message : 'Beklenmedik cevap.');
                }
            },
            error: function(xhr, status, error){
                console.error('AJAX error:', status, error, xhr.responseText);
                alert('İstek başarısız oldu.');
            }
        });
    });
    /* Get Purchase PopUp */
    $(document).on("click",".unlockPost", function(){
        var postID = $(this).data("id");
        var csrf_token = $('input[name="csrf_token"]').val() || "";
        $.ajax({
            type: "POST",
            url: REQUESTS_ENDPOINT,
            data: {
            p: "purchasePost",
            post_id: postID,
            csrf_token: csrf_token
            },
            dataType: "json",
            cache: false,
            success: function (res) {
            if (res && res.status === "success" && res.html) {
                var root = document.getElementById('popup-root');
                if (!root) { root = document.body; }
                injectHTMLWithScripts(root, res.html).catch(function(err){ console.warn('Popup scripts load failed:', err); });
            } else {
                console.warn("Unexpected response:", res);
                alert(res && res.message ? res.message : "Beklenmedik cevap.");
            }
            },
            error: function (xhr, status, error) {
            console.error("AJAX error:", status, error, xhr.responseText);
            alert("İstek başarısız oldu.");
            }
        });
    });
    /* Get Purchase PopUp */
    $(document).on("click",".subscribeMe", function(){
        var postID = $(this).data("id");
        var csrf_token = $('input[name="csrf_token"]').val() || "";
        $.ajax({
            type: "POST",
            url: REQUESTS_ENDPOINT,
            data: {
            p: "subscribeMe",
            post_id: postID,
            csrf_token: csrf_token
            },
            dataType: "json",
            cache: false,
            success: function (res) {
            if (res && res.status === "success" && res.html) {
                var root = document.getElementById('popup-root');
                if (!root) { root = document.body; }
                injectHTMLWithScripts(root, res.html).catch(function(err){ console.warn('Popup scripts load failed:', err); });
            } else {
                console.warn("Unexpected response:", res);
                alert(res && res.message ? res.message : "Beklenmedik cevap.");
            }
            },
            error: function (xhr, status, error) {
            console.error("AJAX error:", status, error, xhr.responseText);
            alert("İstek başarısız oldu.");
            }
        });
    });

  // Cancel subscription
  $(document).on("click", ".unsubscribeMe", function(event){
        event.preventDefault();
        var $btn = $(this);
        var creatorId = parseInt($btn.data("id"), 10) || 0;
        var subscriptionId = parseInt($btn.data("subscriptionId"), 10) || 0;
        if (!creatorId) { return; }
        var csrf_token = $('input[name="csrf_token"]').val() || "";
        var confirmMessage = $btn.data("confirm") || (I18N('subscription_cancel_confirm') || 'Are you sure you want to cancel your subscription?');
        var confirmTitle = $btn.data("confirmTitle") || (I18N('subscription_cancel_confirm_title') || 'Cancel subscription?');
        var confirmLabel = $btn.data("confirmLabel") || (I18N('subscription_cancel_confirm_action') || (I18N('ui_confirm') || 'Confirm'));
        var cancelLabel = $btn.data("cancelLabel") || (I18N('subscription_cancel_keep_action') || (I18N('ui_cancel') || 'Cancel'));

        function toggleToSubscribe(){
            var subscribeLabel = $btn.data('label-subscribe') || (I18N('live_subscribe') || 'Subscribe');
            $btn.removeClass('unsubscribeMe').addClass('subscribeMe');
            $btn.attr('aria-label', subscribeLabel);
            var labelNode = $btn.find('.message_label');
            if (!labelNode.length) {
                labelNode = $('<span class="message_label"></span>');
                $btn.append(labelNode);
            }
            labelNode.text(subscribeLabel);
        }

        function showErrorFeedback(msg){
            var message = msg || (I18N('subscription_cancel_failed') || 'Unable to cancel subscription. Please try again.');
            if (window.DZ && typeof window.DZ.showAlertDialog === 'function') {
                window.DZ.showAlertDialog({
                    tone: 'danger',
                    title: I18N('ui_error_title') || 'Something went wrong',
                    message: message,
                    confirmLabel: I18N('ui_ok') || 'OK'
                });
            } else {
                alert(message);
            }
        }

        function showSuccessFeedback(text){
            var successMsg = text || (I18N('settings_subscription_cancel_success') || 'Subscription cancelled. You will keep access until the end of the current period.');
            var handled = false;
            try {
                if (window.DZ && typeof window.DZ.showAlertDialog === 'function') {
                    window.DZ.showAlertDialog({
                        tone: 'success',
                        title: I18N('ui_success_title') || 'Success',
                        message: successMsg,
                        confirmLabel: I18N('ui_ok') || 'OK',
                        onConfirm: function(){
                            showGlobalTipToast(successMsg, 'success');
                        }
                    });
                    handled = true;
                }
            } catch(_){}
            if (!handled) {
                showGlobalTipToast(successMsg, 'success');
            }
        }

        function performCancel(){
            var fd = new FormData();
            fd.append('p', 'cancelSubscription');
            fd.append('creator_id', String(creatorId));
            if (subscriptionId > 0) {
                fd.append('subscription_id', String(subscriptionId));
            }
            fd.append('csrf_token', csrf_token);
            $btn.prop('disabled', true).addClass('is-loading');
            fetch(REQUESTS_ENDPOINT, {
                method: 'POST',
                body: fd,
                credentials: 'same-origin'
            }).then(function(resp){
                return resp.json().catch(function(){ return null; });
            }).then(function(res){
                if (!res) {
                    throw new Error('invalid_response');
                }
                if (res.status === 'success') {
                    toggleToSubscribe();
                    showSuccessFeedback(res.message || '');
                    return;
                }
                throw new Error(res.message || '');
            }).catch(function(err){
                showErrorFeedback(err && err.message && err.message !== 'invalid_response' ? err.message : '');
            }).finally(function(){
                $btn.prop('disabled', false).removeClass('is-loading');
            });
        }

        if (window.DZ && typeof window.DZ.showAlertDialog === 'function') {
            window.DZ.showAlertDialog({
                tone: 'warning',
                title: confirmTitle,
                message: confirmMessage,
                confirmLabel: confirmLabel,
                cancelLabel: cancelLabel,
                onConfirm: performCancel
            });
        } else if (window.confirm(confirmMessage)) {
            performCancel();
        }
    });
})();

// --- Mobile Off-Canvas: Left sidebar and right widgets ---
(function(){
  'use strict';

  var leftBtnSel  = '.mobile-nav-btn-left';
  var rightBtnSel = '.mobile-nav-btn-right';
  var body        = document.body;
  var overlay;

  function hasRightPanel(){
    return !!document.querySelector('.content-right');
  }

  function updateRightButtonVisibility(){
    try {
      var btn = document.querySelector(rightBtnSel);
      if (!btn) return;
      var show = hasRightPanel();
      btn.classList.toggle('is-hidden', !show);
      // If the right drawer is open but there is no panel, close it
      if (!show && body.classList.contains('mobile-right-open')) {
        body.classList.remove('mobile-right-open');
      }
    } catch(_){}
  }

  function ensureOverlay(){
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.className = 'mobile-overlay';
      overlay.setAttribute('role', 'button');
      overlay.setAttribute('aria-label', I18N('ui_close_drawer') || 'Close menu overlay');
      overlay.setAttribute('aria-hidden', 'true');
      overlay.tabIndex = -1;
      (document.body || document.documentElement).appendChild(overlay);
      overlay.addEventListener('click', closeAll, true);
    }
    return overlay;
  }

  function showOverlay(){
    ensureOverlay();
    overlay.classList.add('show');
    overlay.setAttribute('aria-hidden', 'false');
  }

  function hideOverlay(){
    if (!overlay) { return; }
    overlay.classList.remove('show');
    overlay.setAttribute('aria-hidden', 'true');
  }

  var closeIconMarkup = null;
  function ensureCloseIconMarkup(){
    if (closeIconMarkup !== null) { return closeIconMarkup; }
    try {
      var tpl = document.getElementById('close-icon-template');
      var markup = '';
      if (tpl) {
        markup = (tpl.innerHTML || '').trim();
        var host = tpl.closest('[data-mobile-template]');
        if (host && host.parentNode) {
          host.parentNode.removeChild(host);
        } else if (tpl.parentNode) {
          tpl.parentNode.removeChild(tpl);
        }
      }
      closeIconMarkup = markup || '&times;';
      return closeIconMarkup;
    } catch(_){
      closeIconMarkup = '&times;';
      return closeIconMarkup;
    }
  }

  function ensureDrawerClose(panelSelector, closeFn){
    var panel = document.querySelector(panelSelector);
    if (!panel) { return; }
    if (panel.querySelector('.mobile-drawer-close')) { return; }
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'mobile-drawer-close flex align_items';
    btn.setAttribute('aria-label', I18N('ui_close_drawer') || 'Close menu');
    btn.innerHTML = ensureCloseIconMarkup();
    btn.addEventListener('click', function(ev){
      ev.preventDefault();
      closeFn();
    });
    panel.appendChild(btn);
  }

  function openLeft(){
    showOverlay();
    ensureDrawerClose('.sidebar.sidebar--left', closeLeft);
    body.classList.add('mobile-left-open');
  }
  function openRight(){
    showOverlay();
    ensureDrawerClose('.content-right', closeRight);
    body.classList.add('mobile-right-open');
  }
  function closeLeft(){ body.classList.remove('mobile-left-open'); maybeHideOverlay(); }
  function closeRight(){ body.classList.remove('mobile-right-open'); maybeHideOverlay(); }
  function closeAll(){ body.classList.remove('mobile-left-open','mobile-right-open'); maybeHideOverlay(); }
  function maybeHideOverlay(){
    if (!(body.classList.contains('mobile-left-open') || body.classList.contains('mobile-right-open'))) {
      hideOverlay();
    }
  }

  document.addEventListener('click', function(e){
    var t = e.target;
    var leftBtn  = t.closest(leftBtnSel);
    var rightBtn = t.closest(rightBtnSel);
    var searchBtn= t.closest('.mobile-search-toggle');
    if (leftBtn)  { e.preventDefault(); if (body.classList.contains('mobile-left-open')) closeLeft(); else openLeft(); }
    if (rightBtn) { e.preventDefault(); if (!hasRightPanel()) return; if (body.classList.contains('mobile-right-open')) closeRight(); else openRight(); }
    if (searchBtn) {
      e.preventDefault();
      try {
        var hc = document.querySelector('.site_header_container');
        if (hc) {
          var willOpen = !hc.classList.contains('search-expanded');
          hc.classList.toggle('search-expanded', willOpen);
          var inp = document.querySelector('.search_input.get_box[data-type="search"]');
          if (willOpen && inp) {
            // Open search results dropdown using existing delegated handler
            setTimeout(function(){ try { inp.focus(); inp.click(); } catch(_){} }, 0);
          } else {
            // Close any open dropdown
            try {
              var cb = document.querySelector('.click_box');
              if (cb) { cb.innerHTML=''; cb.classList.remove('show'); cb.removeAttribute('style'); }
              document.querySelectorAll('.get_box').forEach(function(el){ el.classList.remove('active'); });
            } catch(_){}
          }
        }
      } catch(_){}
    }
  }, true);

  // ESC closes drawers
  document.addEventListener('keydown', function(e){ if (e.key === 'Escape') { closeAll(); } }, true);
  window.addEventListener('resize', function(){
    if (window.innerWidth > 1024) {
      closeAll();
      try {
        document.querySelectorAll('.mobile-drawer-close').forEach(function(btn){
          btn.parentNode && btn.parentNode.removeChild(btn);
        });
      } catch(_){}
    }
  });

  // Initialize visibility once DOM is ready (script is deferred, but guard anyway)
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', updateRightButtonVisibility, { once: true });
  } else {
    updateRightButtonVisibility();
  }
  // Re-evaluate on resize (some layouts may inject/remove the panel with breakpoints)
  window.addEventListener('resize', function(){ updateRightButtonVisibility(); });
})();

// --- Header Badges + Sounds (messages/notifications) ---
(function () {
  'use strict';
  if (window.__headerBadgeInit) return; window.__headerBadgeInit = true;

  var MSG_SEL  = '.icon_button.has_badge.get_box[data-type="new_messages"] .badge_count';
  var NOT_SEL  = '.icon_button.has_badge.get_box[data-type="new_notifications"] .badge_count';

  // Use global util
  var buildUrl = (window.DZ && window.DZ.buildUrl) || function(path){
    try { var base=(typeof window.site_url==='string'&&window.site_url)?window.site_url:(window.location.origin+window.location.pathname.replace(/[^\/]*$/,'')); if(base.slice(-1)!=='/') base+='/'; return new URL(String(path||'').replace(/^\//,''), base).toString(); } catch(_) { return String(path||''); }
  };

  // LocalStorage keys (last seen vs last known from server)
  var LS = {
    msgSeen:   'dz_last_seen_msg_time',
    msgKnown:  'dz_last_known_msg_time',
    notSeen:   'dz_last_seen_notif_ts',
    notKnown:  'dz_last_known_notif_ts',
    notType:   'dz_last_known_notif_type',
    notSnd:    'dz_last_sounded_notif_ts',
    notUnread: 'dz_last_known_notif_unread'
  };

  var memoryStore = Object.create(null);
  function lsGetRaw(k){
    try {
      var v = window.localStorage.getItem(k);
      if (v !== null && v !== undefined) { return v; }
    } catch(_){}
    return Object.prototype.hasOwnProperty.call(memoryStore, k) ? memoryStore[k] : null;
  }
  function lsSetRaw(k, v){
    memoryStore[k] = v;
    try { window.localStorage.setItem(k, v); } catch(_){}
  }
  function lsGetInt(k){
    var v = lsGetRaw(k);
    var n = parseInt(v || '0', 10);
    return isNaN(n) ? 0 : n;
  }
  function lsSet(k, v){
    lsSetRaw(k, String(v));
  }

  // Preload sounds; unlock on first interaction
  var soundBase = buildUrl('uploads/notification_sounds/');
  var soundSrc = {
    newMessage: soundBase + 'new_message.mp3',
    newNotif:   soundBase + 'new_notification.mp3',
    subCash:    soundBase + 'cash.mp3'
  };
  // Warm up by creating elements once (helps iOS cache), but for real playback we clone
  var sounds = {
    newMessage: new Audio(soundSrc.newMessage),
    newNotif:   new Audio(soundSrc.newNotif),
    subCash:    new Audio(soundSrc.subCash)
  };
  Object.values(sounds).forEach(function (a) { try { a.preload = 'auto'; a.volume = 1.0; a.load && a.load(); } catch(_){} });
  var audioUnlocked = false;
  var pendingQueue = [];
  function primeAudio(){
    // Remove all unlock listeners (will re-add no more)
    document.removeEventListener('pointerdown', primeAudio, { capture: true });
    document.removeEventListener('click', primeAudio, { capture: true });
    document.removeEventListener('touchstart', primeAudio, { capture: true });
    document.removeEventListener('keydown', primeAudio, { capture: true });
    var unlockCount = 0;
    Object.values(sounds).forEach(function(a){
      try {
        a.muted = true;
        var p = a.play();
        if (p && typeof p.then === 'function') {
          p.then(function(){
            a.pause();
            a.currentTime = 0;
            a.muted = false;
            unlockCount++;
            if (unlockCount >= 1) {
              audioUnlocked = true;
              // Flush pending queue safely
              try { while (pendingQueue.length) { var fn = pendingQueue.shift(); if (typeof fn === 'function') fn(); } } catch(_){ pendingQueue.length = 0; }
            }
          }).catch(function(){ a.muted=false; });
        } else {
          a.pause(); a.currentTime=0; a.muted=false; unlockCount++; audioUnlocked = true; try { while (pendingQueue.length) { var fn = pendingQueue.shift(); if (typeof fn === 'function') fn(); } } catch(_){ pendingQueue.length = 0; }
        }
      } catch(_){}
    });
  }
  document.addEventListener('pointerdown', primeAudio, { capture: true, once: true });
  document.addEventListener('click',       primeAudio, { capture: true, once: true });
  document.addEventListener('touchstart',  primeAudio, { capture: true, once: true });
  document.addEventListener('keydown',     primeAudio, { capture: true, once: true });

  function playFX(kind){
    try {
      var src = soundSrc[kind];
      if (!src) return;
      var runner = function(){ try { var inst = new Audio(src); inst.volume = 1.0; var pr = inst.play(); if (pr && pr.catch) pr.catch(function(){}); } catch(_){} };
      if (!audioUnlocked) { pendingQueue.push(runner); return; }
      runner();
    } catch(_){}
  }

  function turnOn(sel){ var el = document.querySelector(sel); if (!el) return; el.classList.add('is-on','pulse'); }
  function turnOff(sel){ var el = document.querySelector(sel); if (!el) return; el.classList.remove('is-on','pulse'); }

  // When user opens the dropdown, mark as seen and turn off badge
  document.addEventListener('click', function(e){
    var btn = e.target.closest('.icon_button.has_badge.get_box');
    if (!btn) return;
    var type = btn.getAttribute('data-type');
    if (type === 'new_messages') {
      // Mark seen = last known
      lsSet(LS.msgSeen, lsGetInt(LS.msgKnown));
      turnOff(MSG_SEL);
    } else if (type === 'new_notifications') {
      lsSet(LS.notSeen, lsGetInt(LS.notKnown));
      turnOff(NOT_SEL);
      // Fire a one-off mark_seen request so backend sets is_read/read_at
      try {
        var csr = (document.querySelector('input[name=\"csrf_token\"]')||{}).value || '';
        var xhrSeen = new XMLHttpRequest();
        var absReq = buildUrl('request/requests.php');
        var payload = 'p=header_peek&mark_seen=1&csrf_token=' + encodeURIComponent(csr);
        xhrSeen.open('POST', absReq, true);
        xhrSeen.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhrSeen.send(payload);
      } catch(_){}
    }
  }, { capture: true });

  var lastPeek = { msg: 0, ntf: 0, typ: '' };
  var firstRun = true;
  var peekPending = false;
  var peekTimer = null;
  var peekBaseDelay = 10000;
  var peekMaxDelay = 60000;
  var peekCurrentDelay = peekBaseDelay;
  var peekForceOnComplete = false;
  var peekForceDelay = null;

  function schedulePeek(delay){
    if (peekTimer) { clearTimeout(peekTimer); peekTimer = null; }
    var wait = (typeof delay === 'number' && !isNaN(delay)) ? delay : peekCurrentDelay;
    if (wait < 0) { wait = 0; }
    peekTimer = setTimeout(function(){ peek(); }, wait);
  }

  function finalizePeek(success){
    peekPending = false;
    if (success) {
      peekCurrentDelay = peekBaseDelay;
    } else {
      var nextDelay = peekCurrentDelay * 2;
      if (!isFinite(nextDelay) || nextDelay <= 0) { nextDelay = peekBaseDelay; }
      if (nextDelay > peekMaxDelay) { nextDelay = peekMaxDelay; }
      peekCurrentDelay = nextDelay;
    }
    if (peekForceOnComplete) {
      var forced = peekForceDelay;
      peekForceOnComplete = false;
      peekForceDelay = null;
      schedulePeek((typeof forced === 'number' && !isNaN(forced)) ? forced : 0);
      return;
    }
    schedulePeek();
  }

  function requestPeek(delay){
    var wait = (typeof delay === 'number' && !isNaN(delay)) ? Math.max(0, delay) : 0;
    if (peekPending) {
      peekForceOnComplete = true;
      if (peekForceDelay === null || wait < peekForceDelay) { peekForceDelay = wait; }
      return;
    }
    schedulePeek(wait);
  }

  function peek(){
    if (peekTimer) { peekTimer = null; }
    try {
      if (peekPending) { return; }
      if (typeof document !== 'undefined' && typeof document.visibilityState === 'string' && document.visibilityState !== 'visible') { schedulePeek(); return; }
      if (typeof navigator !== 'undefined' && navigator.onLine === false) { schedulePeek(); return; }
      var body = document.body;
      if (!body || body.getAttribute('data-logged-in') !== '1') {
        schedulePeek();
        return;
      }
    } catch(_){}
    try {
      var csr = (document.querySelector('input[name="csrf_token"]')||{}).value || '';
      var xhr = new XMLHttpRequest();
      var settled = false;
      function finish(success){
        if (settled) { return; }
        settled = true;
        finalizePeek(success);
      }
      peekPending = true;
      // Always use absolute base_url to avoid relative path issues under nested routes like /profile/<user>
      var absReq = buildUrl('request/requests.php');
      xhr.open('POST', absReq, true);
      xhr.withCredentials = true;
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xhr.onreadystatechange = function(){
        if (xhr.readyState !== XMLHttpRequest.DONE) return;
        var success = false;
        if (xhr.status === 200) {
          var raw = xhr.responseText || '';
          if (raw.trim() !== '') {
            var j;
            try { j = JSON.parse(raw); } catch(_) { j = null; }
            if (j && j.status === 'ok') {
              success = true;
              var msgT = parseInt(j.last_msg_time||0,10)||0;
              var msgFrom = parseInt(j.last_msg_from||0,10)||0;
              var ntfT = parseInt(j.last_notif_ts||0,10)||0;
              var ntfType = String(j.last_notif_type||'');
              var ntfUnread = parseInt(j.notif_unread||0,10)||0;
              lastPeek.msg = msgT; lastPeek.ntf = ntfT; lastPeek.typ = ntfType;

              // Show badges if newer than last seen
              if (msgT > lsGetInt(LS.msgSeen)) { turnOn(MSG_SEL); } else { /* keep state until user opens */ }
              if (ntfUnread > 0 && ntfT > lsGetInt(LS.notSeen)) { turnOn(NOT_SEL); }
              if (ntfUnread <= 0) { turnOff(NOT_SEL); }

              // Sounds: prefer one-shot per new timestamp; also handle unseen-but-known case
              if (firstRun) {
                // Initialize known to avoid playing sounds immediately on page load
                lsSet(LS.msgKnown, msgT);
                lsSet(LS.notKnown, ntfT);
                lsSetRaw(LS.notType, ntfType);
                // Also mark seen = known, so we don't light up badges for old items
                if (lsGetInt(LS.msgSeen) === 0) { lsSet(LS.msgSeen, msgT); }
                if (lsGetInt(LS.notSeen) === 0) { lsSet(LS.notSeen, ntfT); }
                // And mark sounded = known to prevent playing old sounds on load
                if (lsGetInt(LS.notSnd) === 0) { lsSet(LS.notSnd, ntfT); }
                if (lsGetInt(LS.notUnread) === 0) { lsSet(LS.notUnread, ntfUnread); }
                firstRun = false;
              } else {
                if (msgT > lsGetInt(LS.msgKnown)) {
                  // Suppress self-send chime and active-conversation chime
                  var suppressSelf = false;
                  try {
                    if (window.DZ) {
                      var sentAt  = DZ.lastSentMessageAt || 0;
                      var sentTs  = DZ.lastSentMessageTs || 0;
                      var recent  = sentAt && ((Date.now() - sentAt) < 3500);
                      var sameTs  = sentTs && (parseInt(sentTs,10) === parseInt(msgT,10));
                      suppressSelf = !!(recent || sameTs);
                    }
                  } catch(_){}
                  var suppressActive = false;
                  try {
                    if (window.DZ) {
                      var activeId = parseInt(DZ.activeChatUserId || 0, 10) || 0;
                      // If user currently chatting with msgFrom, silence
                      if (activeId > 0 && msgFrom > 0 && activeId === msgFrom) { suppressActive = true; }
                    }
                  } catch(_){}
                  if (!suppressSelf && !suppressActive) { playFX('newMessage'); }
                  lsSet(LS.msgKnown, msgT);
                }
                // Only play when we truly have a newer timestamp than last known
                if (ntfT > lsGetInt(LS.notKnown)) {
                  // cash.mp3 for subscription + tip payments; else generic
                  if (ntfUnread > 0) {
                    var cashTypes = { subscriber:1, subscription_payment:1, tip_payment:1, tip_payment_receipt:1 };
                    if (cashTypes[ntfType]) { playFX('subCash'); }
                    else { playFX('newNotif'); }
                  }
                  lsSet(LS.notKnown, ntfT);
                  lsSet(LS.notSnd,   ntfT);
                  lsSetRaw(LS.notType, ntfType);
                }
                if (ntfUnread <= 0) {
                  lsSet(LS.notSeen, ntfT);
                  lsSet(LS.notKnown, ntfT);
                  lsSet(LS.notUnread, ntfUnread);
                } else if (ntfUnread > 0) {
                  turnOn(NOT_SEL);
                  // Play if unread count increased, even when timestamp didn't change
                  if (ntfUnread > lsGetInt(LS.notUnread)) {
                    var cashTypes2 = { subscriber:1, subscription_payment:1, tip_payment:1, tip_payment_receipt:1 };
                    if (cashTypes2[ntfType]) { playFX('subCash'); }
                    else { playFX('newNotif'); }
                  } else if (ntfT > lsGetInt(LS.notKnown)) {
                    var cashTypes3 = { subscriber:1, subscription_payment:1, tip_payment:1, tip_payment_receipt:1 };
                    if (cashTypes3[ntfType]) { playFX('subCash'); }
                    else { playFX('newNotif'); }
                  }
                  lsSet(LS.notKnown, ntfT);
                  lsSet(LS.notSnd,   ntfT);
                  lsSetRaw(LS.notType, ntfType);
                  lsSet(LS.notUnread, ntfUnread);
                }
              }
            }
          }
        }
        finish(success);
      };
      xhr.onerror = function(){ finish(false); };
      xhr.ontimeout = function(){ finish(false); };
      xhr.timeout = 12000;
      xhr.send('p=' + encodeURIComponent('header_peek') + '&csrf_token=' + encodeURIComponent(csr));
    } catch(_){
      if (peekPending) {
        finalizePeek(false);
      } else {
        schedulePeek();
      }
    }
  }

  // Kick off polling + faster refresh on focus/visibility
  var canPollNotifications = false;
  try {
    var pollBody = document.body;
    canPollNotifications = !!(pollBody && pollBody.getAttribute('data-logged-in') === '1');
  } catch(_){}

  if (canPollNotifications) {
    requestPeek(800);
    window.addEventListener('focus', function(){ requestPeek(250); }, true);
    document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'visible') { requestPeek(250); } }, true);
  }
})();

// --- Theme Switcher (System / Dark / Light) ---
(function(){
  'use strict';

  var THEME_KEY = 'theme'; // values: 'auto' | 'dark' | 'light'
  var THEME_COOKIE = 'theme_preference';
  var ALT_THEME_COOKIE = 'landing_theme_mode';

  function normalizeMode(mode){
    return (mode === 'dark' || mode === 'light') ? mode : 'auto';
  }

  function setCookie(name, value){
    try {
      var expires = new Date();
      expires.setFullYear(expires.getFullYear() + 1);
      var serialized = encodeURIComponent(String(value || '')) +
        '; path=/; expires=' + expires.toUTCString() + '; SameSite=Lax';
      document.cookie = name + '=' + serialized;
    } catch(_){}
  }

  function writeThemeCookie(mode){
    var m = normalizeMode(mode);
    setCookie(THEME_COOKIE, m);
    setCookie(ALT_THEME_COOKIE, m);
  }

  function readThemeCookie(){
    try {
      var cookies = document.cookie || '';
      var match = cookies.match(new RegExp('(?:^|;\\s*)' + THEME_COOKIE + '=([^;]+)'));
      if (match && match[1]) {
        var primary = decodeURIComponent(match[1]);
        if (primary === 'dark' || primary === 'light' || primary === 'auto') {
          return primary;
        }
      }
      match = cookies.match(new RegExp('(?:^|;\\s*)' + ALT_THEME_COOKIE + '=([^;]+)'));
      if (match && match[1]) {
        var legacy = decodeURIComponent(match[1]);
        if (legacy === 'dark' || legacy === 'light' || legacy === 'auto') {
          return legacy;
        }
      }
    } catch(_){}
    return null;
  }

  function getThemeFromStorage(){
    try { return localStorage.getItem(THEME_KEY) || 'auto'; } catch(_) { return 'auto'; }
  }

  function storedPreference(){
    var cookiePref = readThemeCookie();
    if (cookiePref !== null) { return normalizeMode(cookiePref); }
    return normalizeMode(getThemeFromStorage());
  }

  function applyTheme(mode){
    var m = normalizeMode(mode);
    try {
      document.documentElement.setAttribute('data-theme', m);
    } catch(_){}
    try {
      if (document.body) {
        document.body.setAttribute('data-theme', m);
      }
    } catch(_){}
    try {
      var docClass = document.documentElement.classList;
      if (docClass) {
        docClass.remove('theme-dark', 'theme-light');
        if (m === 'dark' || m === 'light') { docClass.add('theme-' + m); }
      }
    } catch(_){}
    try {
      if (document.body && document.body.classList) {
        document.body.classList.remove('theme-dark', 'theme-light');
        if (m === 'dark' || m === 'light') { document.body.classList.add('theme-' + m); }
      }
    } catch(_){}
    writeThemeCookie(m);
  }

  function setTheme(mode){
    var m = normalizeMode(mode);
    try { localStorage.setItem(THEME_KEY, m); } catch(_){}
    applyTheme(m);
  }

  function initTheme(){
    applyTheme(storedPreference());
    // react to system changes only if automatic
    try {
      var mq = window.matchMedia('(prefers-color-scheme: dark)');
      if (mq && mq.addEventListener) {
        mq.addEventListener('change', function(){
          if (storedPreference() === 'auto') { applyTheme('auto'); }
        });
      }
    } catch(_){}
  }

  function currentMark(mode){
    return (storedPreference() === normalizeMode(mode)) ? ' ✓' : '';
  }

  function closeAppearance(){
    var el = document.getElementById('appearance-modal');
    if (el && el.parentNode) { el.parentNode.removeChild(el); }
  }

  function openAppearance(){
    closeAppearance();
    var modal = document.createElement('div');
    modal.id = 'appearance-modal';
    modal.className = 'popUp-container';
    var tAuto = (typeof I18N==='function' ? (I18N('theme_system') || 'System') : 'System');
    var tDark = (typeof I18N==='function' ? (I18N('theme_dark')   || 'Dark')   : 'Dark');
    var tLight= (typeof I18N==='function' ? (I18N('theme_light')  || 'Light')  : 'Light');
    modal.innerHTML = (
      '<div class="pm-sheet-container">' +
        '<div class="pm-sheet" role="menu" aria-label="Switch appearance">' +
          '<button type="button" class="pm-item" data-mode="auto">' + tAuto + currentMark('auto') + '</button>' +
          '<div class="aud-sep"></div>' +
          '<button type="button" class="pm-item" data-mode="dark">' + tDark + currentMark('dark') + '</button>' +
          '<div class="aud-sep"></div>' +
          '<button type="button" class="pm-item" data-mode="light">' + tLight + currentMark('light') + '</button>' +
        '</div>' +
        '<button type="button" class="pm-cancel">' + (typeof I18N==='function' ? (I18N('menu_cancel') || 'Cancel') : 'Cancel') + '</button>' +
      '</div>'
    );

    modal.addEventListener('click', function(e){
      var t = e.target;
      if (t.classList.contains('pm-cancel')) { closeAppearance(); return; }
      var item = t.closest('.pm-item');
      if (item && item.hasAttribute('data-mode')){
        var mode = item.getAttribute('data-mode');
        setTheme(mode);
        try { if (window.DZ && typeof DZ.toast==='function') DZ.toast('Theme: ' + mode); } catch(_){}
        closeAppearance();
      }
      // click outside sheet closes
      if (t === modal) { closeAppearance(); }
    });

    document.body.appendChild(modal);

    // ESC to close
    setTimeout(function(){
      function esc(e){ if (e.key === 'Escape') { document.removeEventListener('keydown', esc, true); closeAppearance(); } }
      document.addEventListener('keydown', esc, true);
    }, 0);
  }

  function escapeHtml(str){
    return String(str || '').replace(/[&<>\"']/g, function(ch){
      switch (ch) {
        case '&': return '&amp;';
        case '<': return '&lt;';
        case '>': return '&gt;';
        case '"': return '&quot;';
        case "'": return '&#39;';
        default: return ch;
      }
    });
  }

  function readCsrfToken(){
    var el = document.querySelector('input[name="csrf_token"]');
    return el ? (el.value || '') : '';
  }

  function parseLanguageOptions(raw){
    var options = [];
    if (raw) {
      try {
        var parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          parsed.forEach(function(code){
            if (typeof code === 'string' && code) {
              var normalized = code.toLowerCase();
              if (!options.includes(normalized)) { options.push(normalized); }
            }
          });
        }
      } catch(_){}
    }
    return options;
  }

  function parseLanguageLabels(raw){
    var labels = {};
    if (raw) {
      try {
        var parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
          Object.keys(parsed).forEach(function(code){
            var normalized = String(code || '').toLowerCase();
            var label = String(parsed[code] || '').trim();
            if (normalized && label) { labels[normalized] = label; }
          });
        }
      } catch(_){ }
    }
    return labels;
  }

  function languageDisplayName(code){
    var normalized = String(code || '').trim().toLowerCase();
    var names = {
      ar: 'العربية',
      de: 'Deutsch',
      eng: 'English',
      es: 'Español',
      fr: 'Français',
      pt: 'Português',
      sk: 'Slovenčina',
      tr: 'Türkçe'
    };
    return names[normalized] || String(normalized || 'eng').toUpperCase();
  }

  function isGuestMode(){
    try {
      var body = document.body;
      if (!body) { return false; }
      var value = body.getAttribute('data-logged-in');
      if ((!value || value === '') && body.dataset) {
        value = body.dataset.loggedIn || '';
      }
      return String(value || '').trim() !== '1';
    } catch(_){
      return false;
    }
  }

  function updateLanguageLabel(btn, code){
    if (!btn) { return; }
    var normalized = String(code || '').trim().toLowerCase() || 'eng';
    var labels = parseLanguageLabels(btn.getAttribute('data-language-labels') || '');
    var nameLabel = btn.querySelector('.language_switcher_text');
    var codeLabel = btn.querySelector('[data-language-label]');
    if (nameLabel) { nameLabel.textContent = labels[normalized] || languageDisplayName(normalized); }
    if (codeLabel) { codeLabel.textContent = normalized.toUpperCase(); }
    btn.setAttribute('data-language-current', normalized);
  }

  function syncLanguageSwitcherLabels(){
    var buttons = document.querySelectorAll('.language_switcher');
    Array.prototype.forEach.call(buttons, function(btn){
      updateLanguageLabel(btn, btn.getAttribute('data-language-current') || 'eng');
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', syncLanguageSwitcherLabels, { once: true });
  } else {
    syncLanguageSwitcherLabels();
  }

  function setDocumentLanguage(code){
    try { document.documentElement.setAttribute('data-pref-language', code); } catch(_){}
    try { document.documentElement.setAttribute('lang', code); } catch(_){}
    try {
      window.DZ = window.DZ || {};
      var prefs = window.DZ.userPreferences || {};
      window.DZ.userPreferences = Object.assign({}, prefs, { language: code });
    } catch(_){}
  }

  var LANGUAGE_MODAL_ID = 'language-modal';

  function closeLanguagePicker(){
    var el = document.getElementById(LANGUAGE_MODAL_ID);
    if (el && el.parentNode) { el.parentNode.removeChild(el); }
  }

  function beginLanguageChange(modal, ctx, selected){
    if (!modal || !ctx) { return; }
    if (!selected) { return; }
    if (selected === ctx.current) {
      closeLanguagePicker();
      return;
    }

    var waitArea = modal.querySelector('[data-wait-area]');
    var cancelBtn = modal.querySelector('.pm-cancel');
    var items = modal.querySelectorAll('.pm-item');
    if (waitArea) {
      var waitText = ctx.waitMessage || '';
      waitArea.textContent = waitText ? (waitText + ' (' + selected.toUpperCase() + ')') : selected.toUpperCase();
      waitArea.removeAttribute('hidden');
    }
    if (cancelBtn) { cancelBtn.disabled = true; }
    Array.prototype.forEach.call(items, function(btn){ btn.disabled = true; });
    modal.dataset.processing = '1';

    var endpoint = ctx.endpoint;
    if (!endpoint) {
      try { endpoint = typeof window.buildUrl === 'function' ? window.buildUrl('request/requests.php') : ''; } catch(_){}
      if (!endpoint) { endpoint = 'request/requests.php'; }
    }

    var csrf = readCsrfToken();
    if (!csrf) {
      if (waitArea) { waitArea.textContent = 'CSRF token missing.'; }
      Array.prototype.forEach.call(items, function(btn){ btn.disabled = false; });
      if (cancelBtn) { cancelBtn.disabled = false; }
      delete modal.dataset.processing;
      return;
    }

    var fd = new FormData();
    var requestKey = (ctx && ctx.isGuest) ? 'guest_update_language' : 'settings_update_language';
    fd.set('p', requestKey);
    fd.set('csrf_token', csrf);
    fd.set('language', selected);

    fetch(endpoint, {
      method: 'POST',
      body: fd,
      credentials: 'same-origin'
    })
      .then(function(res){
        return res.json().catch(function(){ return { status: 'error', message: 'INVALID_RESPONSE' }; });
      })
      .then(function(payload){
        if (payload && payload.status === 'success') {
          var resolved = selected;
          if (payload.data && payload.data.language) {
            resolved = String(payload.data.language || '').toLowerCase();
          }
          updateLanguageLabel(ctx.button, resolved);
          setDocumentLanguage(resolved);
          if (ctx.button && ctx.button.dataset) { ctx.button.dataset.languageCurrent = resolved; }
          ctx.current = resolved;
          var successMessage = (payload && (payload.message || payload.success)) ||
            (typeof I18N === 'function' ? (I18N('language_switch_success') || 'Language updated.') : 'Language updated.');
          if (waitArea) {
            waitArea.textContent = successMessage;
            waitArea.removeAttribute('hidden');
          }
          try {
            if (typeof ensureDzToast === 'function') { ensureDzToast(); }
            if (window.DZ && typeof DZ.toast === 'function') {
              DZ.toast(successMessage, { type: 'success', duration: 2000 });
            }
          } catch(_){}
          setTimeout(function(){ window.location.reload(); }, 1500);
        } else {
          var message = (payload && (payload.message || payload.error)) || 'Language update failed.';
          if (waitArea) { waitArea.textContent = message; }
          try {
            if (typeof ensureDzToast === 'function') { ensureDzToast(); }
            if (window.DZ && typeof DZ.toast === 'function') {
              DZ.toast(message, { type: 'error', duration: 2600 });
            } else { alert(message); }
          } catch(_){}
          Array.prototype.forEach.call(items, function(btn){ btn.disabled = false; });
          if (cancelBtn) { cancelBtn.disabled = false; }
          if (waitArea) { waitArea.setAttribute('hidden', 'hidden'); }
          delete modal.dataset.processing;
        }
      })
      .catch(function(){
        if (waitArea) { waitArea.textContent = 'Network error.'; waitArea.removeAttribute('hidden'); }
        try {
          if (typeof ensureDzToast === 'function') { ensureDzToast(); }
          if (window.DZ && typeof DZ.toast === 'function') {
            DZ.toast('Network error.', { type: 'error', duration: 2600 });
          } else { alert('Network error.'); }
        } catch(_){}
        Array.prototype.forEach.call(items, function(btn){ btn.disabled = false; });
        if (cancelBtn) { cancelBtn.disabled = false; }
        delete modal.dataset.processing;
      });
  }

  function openLanguagePicker(btn){
    closeLanguagePicker();

    var dataset = btn ? (btn.getAttribute('data-language-options') || '') : '';
    var options = parseLanguageOptions(dataset);
    var current = (btn && btn.getAttribute('data-language-current')) || '';
    if (!current) {
      current = (document.documentElement.getAttribute('data-pref-language') || document.documentElement.getAttribute('lang') || 'eng').toLowerCase();
    }
    if (options.length === 0 && current) {
      options.push(current);
    }
    if (options.length === 0) {
      options = ['eng'];
    }
    if (options.indexOf(current) === -1) {
      current = options.indexOf('eng') !== -1 ? 'eng' : options[0];
    }

    var title = btn ? (btn.getAttribute('data-language-title') || '') : '';
    var waitMessage = btn ? (btn.getAttribute('data-language-wait-message') || '') : '';
    var endpoint = btn ? (btn.getAttribute('data-language-endpoint') || '') : '';
    var labels = parseLanguageLabels(btn ? (btn.getAttribute('data-language-labels') || '') : '');

    var cancelLabel = (typeof I18N === 'function' ? (I18N('menu_cancel') || 'Cancel') : 'Cancel');
    var sheetLabel = title || (typeof I18N === 'function' ? (I18N('language_switch_title') || 'Choose language') : 'Choose language');
    var itemsHtml = options.map(function(code){
      var displayName = labels[code] || String(code || '').toUpperCase();
      var mark = (code === current) ? ' ✓' : '';
      return '<button type="button" class="pm-item" data-lang="' + escapeHtml(code) + '">' + escapeHtml(displayName + mark) + '</button>';
    }).join('<div class="aud-sep"></div>');

    var modal = document.createElement('div');
    modal.id = LANGUAGE_MODAL_ID;
    modal.className = 'popUp-container';
    modal.innerHTML = (
      '<div class="pm-sheet-container">' +
        '<div class="pm-sheet" role="menu" aria-label="' + escapeHtml(sheetLabel) + '">' +
          itemsHtml +
        '</div>' +
        '<div class="pm-message language-switch-wait" data-wait-area hidden></div>' +
        '<button type="button" class="pm-cancel">' + escapeHtml(cancelLabel) + '</button>' +
      '</div>'
    );

    var context = {
      button: btn || null,
      endpoint: endpoint,
      waitMessage: waitMessage,
      current: current,
      isGuest: isGuestMode()
    };

    modal.addEventListener('click', function(e){
      var target = e.target;
      if (modal.dataset.processing === '1') {
        if (target.classList.contains('pm-cancel') || target === modal) {
          e.preventDefault();
        }
        return;
      }

      if (target.classList.contains('pm-cancel')) {
        closeLanguagePicker();
        return;
      }

      var item = target.closest('.pm-item');
      if (item && item.hasAttribute('data-lang')) {
        var selected = item.getAttribute('data-lang');
        beginLanguageChange(modal, context, selected);
        return;
      }

      if (target === modal) {
        closeLanguagePicker();
      }
    });

    setTimeout(function(){
      function esc(e){ if (e.key === 'Escape' && modal.dataset.processing !== '1') { document.removeEventListener('keydown', esc, true); closeLanguagePicker(); } }
      document.addEventListener('keydown', esc, true);
    }, 0);

    document.body.appendChild(modal);
  }

  // Wire sidebar entry
  document.addEventListener('click', function(e){
    var btn = e.target.closest('.switch_apperange');
    if (btn) {
      e.preventDefault();
      openAppearance();
    }
  });

  document.addEventListener('click', function(e){
    var btn = e.target.closest('.language_switcher');
    if (btn) {
      e.preventDefault();
      openLanguagePicker(btn);
    }
  });

  function showTipInfoModal(message){
    var existing = document.getElementById('selfTipNotice');
    if (existing) {
      try { existing.remove(); } catch(_) {}
    }

    var overlay = document.createElement('div');
    overlay.id = 'selfTipNotice';
    overlay.className = 'popUp-container flex align_items';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');

    var wrapper = document.createElement('div');
    wrapper.className = 'tips popup-wrapper';

    var closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'tips-close close_pop';
    closeBtn.setAttribute('aria-label', 'Close');
    closeBtn.innerHTML = '<span aria-hidden="true">&times;</span>';

    var body = document.createElement('div');
    body.className = 'tips-body';
    var paragraph = document.createElement('p');
    paragraph.className = 'tips-text';
    paragraph.style.margin = '0';
    paragraph.style.fontSize = '15px';
    paragraph.textContent = String(message || '');
    body.appendChild(paragraph);

    wrapper.appendChild(closeBtn);
    wrapper.appendChild(body);
    overlay.appendChild(wrapper);
    document.body.appendChild(overlay);

    var removeOverlay = function(){
      try { overlay.remove(); } catch(_) {}
      document.removeEventListener('keydown', escHandler, true);
    };

    closeBtn.addEventListener('click', removeOverlay);
    overlay.addEventListener('click', function(ev){
      if (ev.target === overlay) { removeOverlay(); }
    });

    function escHandler(ev){
      if (ev.key === 'Escape') { removeOverlay(); }
    }
    setTimeout(function(){ document.addEventListener('keydown', escHandler, true); }, 0);
  }

  (function(){
    var nativeAlert = window.alert;
    window.alert = function(msg){
      var text = String(msg || '');
      var lowered = text.toLowerCase();
      if (lowered && lowered.indexOf('tip to yourself') !== -1) {
        try { showTipInfoModal(text); return; } catch(_) {}
      }
      nativeAlert.call(window, msg);
    };
  })();

  function ensureGlobalTipToast(){
    if (typeof ensureDzToast === 'function') {
      try { ensureDzToast(); return; } catch(_){}
    }
    try {
      window.DZ = window.DZ || {};
      if (typeof window.DZ.toast === 'function') { return; }
      window.DZ.toast = function(msg, opts){
        try {
          var id = 'dz-toast-container';
          var c = document.getElementById(id);
          if (!c) {
            c = document.createElement('div');
            c.id = id;
            c.className = 'dz-toast-container';
            document.body.appendChild(c);
          }
          var el = document.createElement('div');
          el.className = 'dz-toast ' + ((opts && opts.type) ? ('is-' + opts.type) : 'is-info');
          el.textContent = String(msg || '');
          c.appendChild(el);
          requestAnimationFrame(function(){ el.classList.add('is-shown'); });
          setTimeout(function(){
            el.classList.remove('is-shown');
            setTimeout(function(){ el.remove(); }, 220);
          }, (opts && opts.duration) || 2600);
        } catch(_){}
      };
    } catch(_){}
  }

  function showGlobalTipToast(message, type){
    ensureGlobalTipToast();
    var displayed = false;
    try {
      if (window.DZ && typeof window.DZ.toast === 'function') {
        var kind = (type === 'success') ? 'success' : (type === 'error' ? 'error' : 'info');
        window.DZ.toast(String(message || ''), { type: kind, duration: 2600 });
        displayed = true;
      }
    } catch(_){}
    if (!displayed) {
      try {
        var containerId = 'dz-toast-container';
        var container = document.getElementById(containerId);
        if (!container) {
          container = document.createElement('div');
          container.id = containerId;
          container.className = 'dz-toast-container';
          document.body.appendChild(container);
        }
        var toast = document.createElement('div');
        toast.className = 'dz-toast ' + (type ? ('is-' + type) : 'is-info');
        toast.textContent = String(message || '');
        container.appendChild(toast);
        requestAnimationFrame(function(){ toast.classList.add('is-shown'); });
        setTimeout(function(){
          toast.classList.remove('is-shown');
          setTimeout(function(){ toast.remove(); }, 220);
        }, 2600);
        displayed = true;
      } catch(_){
        try { alert(String(message || '')); } catch(__) {}
      }
    }
    return displayed;
  }

  function getPendingSuccessMessage(flowType){
    var normalized = (flowType || '').toLowerCase();
    if (normalized === 'subscription') {
      return I18N('pay_subscription_success') || 'Subscription activated successfully.';
    }
    return I18N('pay_success_tip') || 'Tip completed successfully.';
  }

  function showPendingSuccessDialog(flowType){
    var successMsg = getPendingSuccessMessage(flowType);
    var handled = false;
    try {
      if (window.DZ && typeof window.DZ.showAlertDialog === 'function') {
        window.DZ.showAlertDialog({
          tone: 'success',
          title: I18N('ui_success_title') || 'Success',
          message: successMsg,
          confirmLabel: I18N('ui_ok') || 'OK',
          onConfirm: function(){
            showGlobalTipToast(successMsg, 'success');
          }
        });
        handled = true;
      }
    } catch(_){}
    if (!handled) {
      showGlobalTipToast(successMsg, 'success');
    }
  }

  function initGlobalPendingTipWatcher(){
    try {
      if (window.__pendingPaymentPollActive) { return; }
      if (window.__globalPendingTipWatcherInitialized) { return; }
      window.__globalPendingTipWatcherInitialized = true;
    } catch(_){}

    var raw = null;
    try { raw = window.sessionStorage.getItem('pending_payment'); } catch(_) {}
    if (!raw) { return; }

    var pending = null;
    try { pending = JSON.parse(raw); } catch(_) {}
    if (!pending || !pending.provider || !pending.reference) {
      try { window.sessionStorage.removeItem('pending_payment'); } catch(_){}
      return;
    }
    var createdAt = Number(pending.created_at || 0);
    var maxAgeMs = 10 * 60 * 1000; // 10 minutes
    if (!createdAt || (Date.now() - createdAt) > maxAgeMs) {
      try { window.sessionStorage.removeItem('pending_payment'); } catch(_){}
      return;
    }
    if ((pending.type || '').toLowerCase() === 'wallettopup' || (pending.type || '') === 'wallet_topup') {
      try { window.sessionStorage.removeItem('pending_payment'); } catch(_){}
      return;
    }

    try { window.__pendingPaymentPollActive = true; } catch(_){}

    var provider = pending.provider;
    var reference = pending.reference;
    var flowType = pending.type || 'tip';
    var notifiedProcessing = false;
    var attempts = 0;

    function poll(){
      attempts += 1;
      var fd = new FormData();
      fd.append('p', 'payment_status');
      fd.append('provider', provider);
      fd.append('reference', reference);
      fd.append('type', flowType);
      var csrf = readCsrfToken();
      if (csrf) {
        fd.append('csrf_token', csrf);
      }
      fetch(REQUESTS_ENDPOINT, { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function(r){ return r.json(); })
        .then(function(j){
          if (!j || j.status !== 'success') {
            if (attempts < 20) {
              setTimeout(poll, 6000);
            } else {
              try { window.__pendingPaymentPollActive = false; } catch(_){}
            }
            return;
          }
          if (!notifiedProcessing) {
            notifiedProcessing = true;
            showGlobalTipToast((typeof I18N === 'function' ? (I18N('pay_processing_message') || '') : '') || 'We are processing your payment. It may take a moment to finalize.', 'info');
          }
          var status = (j.payment_status || '').toLowerCase();
          if (status === 'succeeded') {
            try { window.sessionStorage.removeItem('pending_payment'); } catch(_){}
            try { window.__pendingPaymentPollActive = false; } catch(_){}
            if (flowType === 'purchase') {
              window.location.reload();
              return;
            }
            showPendingSuccessDialog(flowType);
            return;
          }
          if (status === 'failed' || status === 'canceled' || status === 'cancelled') {
            try { window.sessionStorage.removeItem('pending_payment'); } catch(_){}
            try { window.__pendingPaymentPollActive = false; } catch(_){}
            showGlobalTipToast((typeof I18N === 'function' ? (I18N('pay_failed_tip') || '') : '') || 'Tip payment could not be completed.', 'error');
            return;
          }
          if (attempts < 20) {
            setTimeout(poll, 4000);
          } else {
            try { window.__pendingPaymentPollActive = false; } catch(_){}
          }
        })
        .catch(function(){
          if (attempts < 20) {
            setTimeout(poll, 6000);
          } else {
            try { window.__pendingPaymentPollActive = false; } catch(_){}
          }
        });
    }

    setTimeout(poll, 800);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initGlobalPendingTipWatcher);
  } else {
    initGlobalPendingTipWatcher();
  }

  // Prevent blocking relationships:
  // - .blockUser[data-is-subscriber="1"] => target is your subscriber
  // - .blockUser[data-i-am-subscriber="1"] (or data-am-subscriber / data-is-subscribed-by-me) => you are subscribed to target
  $(document).on('click', '.blockUser', function(e){
    try {
      var $btn = $(this);
      var truthy = function(v){ v = String(v || '').toLowerCase(); return v==='1'||v==='true'||v==='yes'; };
      var targetIsMySubscriber = truthy($btn.data('is-subscriber'));
      var iAmSubscriber = truthy($btn.data('i-am-subscriber')) || truthy($btn.data('am-subscriber')) || truthy($btn.data('is-subscribed-by-me'));
      if (targetIsMySubscriber) {
        e.preventDefault();
        if (typeof ensureDzToast === 'function' && window.DZ && typeof DZ.toast === 'function') {
          ensureDzToast(); DZ.toast(I18N('cannot_block_subscriber') || 'You cannot block a subscriber.', { type:'error', duration: 2600 });
        } else { alert(I18N('cannot_block_subscriber') || 'You cannot block a subscriber.'); }
        return false;
      }
      if (iAmSubscriber) {
        e.preventDefault();
        if (typeof ensureDzToast === 'function' && window.DZ && typeof DZ.toast === 'function') {
          ensureDzToast(); DZ.toast(I18N('cannot_block_subscription_target') || 'You are subscribed to this profile; please cancel your subscription first.', { type:'error', duration: 2800 });
        } else { alert(I18N('cannot_block_subscription_target') || 'You are subscribed to this profile; please cancel your subscription first.'); }
        return false;
      }
    } catch(_){}
    // else: allow default behavior (actual block handler if implemented)
  });

  // Initialize on load
  try { initTheme(); } catch(_){}
})();

// --- Billing accordion toggle (Edit billing details) ---
(function(){
  'use strict';
  if (window.__globalBillingToggleAttached) { return; }
  window.__globalBillingToggleAttached = true;

  function findBillingPanel(button){
    if (!button) { return null; }
    var selector = button.getAttribute('data-billing-target') || '';
    if (selector) {
      try {
        var resolved = document.querySelector(selector);
        if (resolved) { return resolved; }
      } catch(_){}
      if (selector.charAt(0) === '#') {
        var byId = document.getElementById(selector.slice(1));
        if (byId) { return byId; }
      }
    }
    var summary = button.closest('[data-billing-summary]');
    if (summary) {
      var sibling = summary.nextElementSibling;
      while (sibling) {
        if (sibling.classList && sibling.classList.contains('tips-accordion--form')) {
          return sibling;
        }
        sibling = sibling.nextElementSibling;
      }
    }
    var form = button.closest('.tips-form');
    if (form) {
      var fallback = form.querySelector('.tips-accordion--form');
      if (fallback) { return fallback; }
    }
    return null;
  }

  document.addEventListener('click', function(ev){
    var toggle = ev.target && ev.target.closest ? ev.target.closest('[data-billing-edit]') : null;
    if (!toggle) { return; }
    var panel = findBillingPanel(toggle);
    if (!panel) { return; }
    ev.preventDefault();
    var summary = toggle.closest('[data-billing-summary]');
    var collapsed = panel.classList.contains('is-collapsed');
    if (collapsed) {
      panel.classList.remove('is-collapsed');
      panel.querySelectorAll('[data-billing-fields]').forEach(function(section){ section.removeAttribute('hidden'); });
      if (summary) { summary.setAttribute('hidden', 'hidden'); summary.classList.add('is-hidden'); }
    } else {
      panel.classList.add('is-collapsed');
      panel.querySelectorAll('[data-billing-fields]').forEach(function(section){ section.setAttribute('hidden', 'hidden'); });
      if (summary) { summary.removeAttribute('hidden'); summary.classList.remove('is-hidden'); }
    }
  }, true);
})();
