(function(){
  if (typeof window.fetch !== 'function') {
    return;
  }

  var form = document.getElementById('contactForm');
  if (!form) { return; }

  var layoutId = (document.body && document.body.getAttribute('data-layout')) || '';
  var maintenanceStatus = (document.body && document.body.getAttribute('data-maintenance-status')) || '';
  var isLoggedIn = (document.body && document.body.getAttribute('data-logged-in')) === '1';
  if (layoutId === 'contact' && maintenanceStatus === 'on' && !isLoggedIn) {
    var interactiveSelectors = ['.get_box', '.search_input', '.mobile-search-toggle'];
    var blocker = function(ev){
      ev.preventDefault();
      ev.stopPropagation();
      return false;
    };
    interactiveSelectors.forEach(function(selector){
      var nodes = document.querySelectorAll(selector);
      if (!nodes) { return; }
      nodes.forEach(function(el){
        try {
          el.setAttribute('aria-disabled', 'true');
          el.classList.add('maintenance-disabled');
          el.tabIndex = -1;
          el.addEventListener('click', blocker, true);
          el.addEventListener('keydown', blocker, true);
        } catch (_) {}
      });
    });
  }

  var subjectSelect = form.querySelector('select[name="subject"]');
  var msgTypeInput = form.querySelector('input[name="msg_type"]');
  var statusEl = document.getElementById('contactStatus');
  var isRecaptcha = form.dataset.recaptcha === '1';
  var recaptchaRequired = form.dataset.recaptchaRequired === '1';
  var isDisabled = form.dataset.disabled === '1';

  function showStatus(message, isError) {
    if (!statusEl) { return; }
    if (!message) {
      statusEl.textContent = '';
      statusEl.setAttribute('hidden', '');
      statusEl.classList.remove('is-error', 'is-success');
      return;
    }
    statusEl.textContent = message;
    statusEl.classList.toggle('is-error', !!isError);
    statusEl.classList.toggle('is-success', !isError);
    statusEl.removeAttribute('hidden');
  }

  function mapMessage(code, isSuccess) {
    var map = {
      'contact_success': form.dataset.successMessage,
      'contact_error_generic': form.dataset.errorGeneric,
      'contact_error_recaptcha': form.dataset.errorRecaptcha,
      'contact_error_rate_limit': form.dataset.errorRateLimit,
      'contact_error_guests_disabled': form.dataset.errorGuests,
      'contact_error_invalid_email': form.dataset.errorInvalidEmail,
      'contact_error_name_required': form.dataset.errorNameRequired,
      'contact_error_message_required': form.dataset.errorMessageRequired,
      'invalid_email': form.dataset.errorInvalidEmail,
      'invalid_csrf': form.dataset.errorGeneric
    };
    var text = map[code];
    if (!text) {
      text = isSuccess ? (form.dataset.successMessage || code) : (form.dataset.errorGeneric || code);
    }
    return text;
  }

  if (subjectSelect && msgTypeInput) {
    var updateMsgType = function(){
      var option = subjectSelect.options[subjectSelect.selectedIndex];
      var type = option ? option.getAttribute('data-type') || option.value : msgTypeInput.value;
      msgTypeInput.value = type;
    };
    subjectSelect.addEventListener('change', updateMsgType);
    updateMsgType();
  }

  if (isDisabled) {
    Array.prototype.forEach.call(form.querySelectorAll('input, textarea, select, button'), function(el){
      if (el.type !== 'hidden' && el.name !== 'csrf_token') {
        el.disabled = true;
      }
    });
    return;
  }

  form.addEventListener('submit', function(ev){
    ev.preventDefault();
    if (form.dataset.submitting === '1') { return; }

    var messageField = form.querySelector('textarea[name="message"]');
    if (messageField && messageField.value.trim() === '') {
      showStatus(form.dataset.errorMessageRequired, true);
      return;
    }

    if (isRecaptcha && recaptchaRequired) {
      if (!(window.grecaptcha && typeof window.grecaptcha.getResponse === 'function' && grecaptcha.getResponse().length)) {
        showStatus(form.dataset.errorRecaptcha, true);
        return;
      }
    }

    showStatus('', false);
    form.dataset.submitting = '1';
    var submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.setAttribute('aria-busy', 'true');
    }

    var fd = new FormData(form);

    fetch(form.action, {
      method: 'POST',
      body: fd,
      credentials: 'same-origin'
    })
      .then(function(response){
        return response.json().catch(function(){ return {}; });
      })
      .then(function(payload){
        if (payload && (payload.status === 'success' || payload.ok === true)) {
          var msg = mapMessage(payload.message || 'contact_success', true);
          showStatus(msg, false);
          if (messageField) { messageField.value = ''; }
          var nameField = form.querySelector('input[name="name"]');
          if (nameField && !nameField.readOnly) { nameField.value = ''; }
          var emailField = form.querySelector('input[name="email"]');
          if (emailField && !emailField.readOnly) { emailField.value = ''; }
          if (subjectSelect) {
            subjectSelect.selectedIndex = 0;
            if (typeof Event === 'function') {
              subjectSelect.dispatchEvent(new Event('change'));
            } else {
              var evt = document.createEvent('Event');
              evt.initEvent('change', true, true);
              subjectSelect.dispatchEvent(evt);
            }
          }
          if (isRecaptcha && window.grecaptcha && typeof window.grecaptcha.reset === 'function') {
            try { window.grecaptcha.reset(); } catch (_) {}
          }
        } else {
          var code = payload && payload.message ? payload.message : 'contact_error_generic';
          showStatus(mapMessage(code, false), true);
          if (isRecaptcha && window.grecaptcha && typeof window.grecaptcha.reset === 'function') {
            try { window.grecaptcha.reset(); } catch (_) {}
          }
        }
      })
      .catch(function(){
        showStatus(form.dataset.errorGeneric, true);
        if (isRecaptcha && window.grecaptcha && typeof window.grecaptcha.reset === 'function') {
          try { window.grecaptcha.reset(); } catch (_) {}
        }
      })
      .finally(function(){
        delete form.dataset.submitting;
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.removeAttribute('aria-busy');
        }
      });
  });
})();
