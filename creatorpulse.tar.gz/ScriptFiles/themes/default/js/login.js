(function ($) {
  'use strict';

  var buildUrl = (window.DZ && typeof window.DZ.buildUrl === 'function')
    ? window.DZ.buildUrl
    : function (path) {
        var base = (typeof window.site_url === 'string' && window.site_url)
          ? window.site_url
          : (window.location.origin + window.location.pathname.replace(/[^\/]*$/, ''));
        if (base.slice(-1) !== '/') {
          base += '/';
        }
        return base + String(path || '').replace(/^\/+/, '');
      };

  var resolveHomeUrl = function () {
    try {
      var url = buildUrl('');
      if (url) {
        return url;
      }
    } catch (_) {}
    if (typeof window.site_url === 'string' && window.site_url) {
      return window.site_url;
    }
    return '/';
  };

  $(document).on('submit', '.login-form', function (e) {
    e.preventDefault();

    var $form = $(this);
    var $btn = $form.find('.login-submit');
    var $warning = $form.find('#loginWarning');
    var $success = $form.find('#loginSuccess');
    var $loader = $form.find('.loading-container');
    var $loaderText = $loader.find('.loading-text');
    var loadingMessage = $form.data('loading-message') || 'Logging in please wait...';
    var successMessage = $form.data('success-message') || 'Login successful, redirecting to your feed.';
    var hideMessage = function ($element) {
      if (!$element || !$element.length) {
        return;
      }
      $element.removeAttr('style').text('').addClass('none');
    };
    var showMessage = function ($element, message) {
      if (!$element || !$element.length) {
        return;
      }
      $element.removeAttr('style').removeClass('none').text(message);
    };
    var showLoader = function (message) {
      if (!$loader || !$loader.length) {
        return;
      }
      $loader.removeClass('none');
      if ($loaderText && $loaderText.length) {
        $loaderText.text(message);
      }
    };
    var hideLoader = function () {
      if (!$loader || !$loader.length) {
        return;
      }
      $loader.addClass('none');
    };

    var username = $form.find('#username').val().trim();
    var password = $form.find('#password').val();
    var csrfToken = $form.find('input[name="csrf_token"]').val();
    var errorRequired = $form.data('error-required') || 'Please fill all fields.';
    var errorUnexpected = $form.data('error-unexpected') || 'Unexpected error occurred.';
    var errorLoginFailed = $form.data('error-login-failed') || 'Unable to sign in.';
    var requestSucceeded = false;
    var originalText = $btn.data('default-text');
    if (!originalText) {
      originalText = $btn.text();
      $btn.data('default-text', originalText);
    }
    var loadingText = $btn.data('loading-text') || 'Logging in...';

    hideMessage($warning);
    hideMessage($success);
    hideLoader();

    if (!username || !password) {
      showMessage($warning, errorRequired);
      return;
    }

    $.ajax({
      type: 'POST',
      url: buildUrl('request/login.php'),
      data: {
        my_username: username,
        lg_password: password,
        csrf_token: csrfToken
      },
      dataType: 'json',
      beforeSend: function () {
        requestSucceeded = false;
        showLoader(loadingMessage);
        $btn.prop('disabled', true).text(loadingText);
      },
      success: function (response) {
        if (response && response.status === 'success') {
          requestSucceeded = true;
          hideMessage($warning);
          var message = (response && response.message) ? response.message : successMessage;
          showMessage($success, message);
          showLoader(successMessage);
          $btn.text(originalText);
          setTimeout(function () {
            window.location.href = resolveHomeUrl();
          }, 600);
        } else {
          var message = (response && response.message) ? response.message : errorLoginFailed;
          hideLoader();
          showMessage($warning, message);
        }
      },
      error: function () {
        hideLoader();
        showMessage($warning, errorUnexpected);
      },
      complete: function () {
        if (!requestSucceeded) {
          $btn.prop('disabled', false).text(originalText);
        }
      }
    });
  });

})(jQuery);
