'use strict';
(function (window) {
  if (!window) { return; }
  window.DZ = window.DZ || {};
  if (typeof window.DZ.formatCurrency === 'function') { return; }

  function readCurrencyConfigFromDom() {
    try {
      var node = window.document ? window.document.getElementById('dz-currency-config') : null;
      if (!node) { return null; }
      var raw = node.getAttribute('data-json') || '';
      if (!raw) { return null; }
      var parsed = JSON.parse(raw);
      return (parsed && typeof parsed === 'object') ? parsed : null;
    } catch (_) {
      return null;
    }
  }

  var cfg = window.DZ.currencyFormat || readCurrencyConfigFromDom() || {};
  var position = (cfg.position || 'left');
  var decimalSep = (cfg.decimalSep === ',' ? ',' : '.');
  var thousandsSep = (typeof cfg.thousandsSep === 'string') ? cfg.thousandsSep : ',';
  if (thousandsSep === decimalSep) { thousandsSep = ''; }
  var basePrecision = (typeof cfg.decimalPlaces === 'number' ? cfg.decimalPlaces : 2);
  if (!isFinite(basePrecision) || basePrecision < 0) { basePrecision = 0; }
  if (basePrecision > 8) { basePrecision = 8; }
  var defaultCode = (cfg.code || 'USD').toString().toUpperCase();
  var defaultSymbol = (cfg.symbol || '').toString();
  var crypto = ['BTC','ETH','BCH','LTC','DOGE','XMR','SOL','ADA','MATIC','XRP','USDT','USDC','DAI','BNB','TRX'];

  function resolvePrecision(code) {
    var p = basePrecision;
    if (isNaN(p) || p < 0) { p = 0; }
    if (p > 8) { p = 8; }
    if (crypto.indexOf((code || '').toUpperCase()) !== -1) {
      p = Math.max(p, 8);
    }
    return p;
  }

  function formatNumber(amount, code) {
    var numeric = Number(amount);
    if (!isFinite(numeric)) { numeric = 0; }
    var precision = resolvePrecision(code || defaultCode);
    var fixed = numeric.toFixed(precision);
    var parts = fixed.split('.');
    if (thousandsSep) {
      parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandsSep);
    }
    if (parts.length > 1) {
      return parts[0] + decimalSep + parts[1];
    }
    return parts[0];
  }

  function applyPosition(formatted, symbol, code) {
    if (!symbol || symbol === code || symbol.length > 4) {
      return formatted + ' ' + code;
    }
    switch (position) {
      case 'left':
        return symbol + formatted;
      case 'left_space':
        return symbol + ' ' + formatted;
      case 'right':
        return formatted + symbol;
      case 'right_space':
        return formatted + ' ' + symbol;
      default:
        return symbol + formatted;
    }
  }

  function formatCurrency(amount, code, symbol) {
    var currencyCode = (code || '').toUpperCase() || defaultCode;
    var currencySymbol = (symbol || defaultSymbol || '').toString();
    if (!currencySymbol && cfg.symbols && cfg.symbols[currencyCode]) {
      currencySymbol = cfg.symbols[currencyCode];
    }
    return applyPosition(formatNumber(amount, currencyCode), currencySymbol, currencyCode);
  }

  window.DZ.formatNumber = formatNumber;
  window.DZ.formatCurrency = formatCurrency;
  window.DZ.currencyFormat = {
    position: position,
    decimalSep: decimalSep,
    thousandsSep: thousandsSep,
    decimalPlaces: basePrecision,
    code: defaultCode,
    symbol: defaultSymbol,
  };

  try {
    var cfgNode = window.document ? window.document.getElementById('dz-currency-config') : null;
    if (cfgNode && cfgNode.parentNode) {
      cfgNode.parentNode.removeChild(cfgNode);
    }
  } catch (_) { /* ignore */ }
})(window);
