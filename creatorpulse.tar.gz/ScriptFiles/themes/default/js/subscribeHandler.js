/* Subscription Handler: submit subscription form, start payment */
(function(){
  if (window.__subscribeHandlerBound) return;
  window.__subscribeHandlerBound = true;

  var buildUrl = (window.DZ && window.DZ.buildUrl) || function(path){
    try { var base=(typeof window.site_url==='string'&&window.site_url)?window.site_url:(window.location.origin+window.location.pathname.replace(/[^\/]*$/,'')); if(base.slice(-1)!=='/') base+='/'; return new URL(String(path||'').replace(/^\//,''), base).toString(); } catch(_) { return String(path||''); }
  };

  function getCsrf(){
    try { return document.querySelector('input[name="csrf_token"]').value || ''; } catch(e){ return ''; }
  }
  var I18N = (window.DZ && typeof DZ.i18n === 'function') ? DZ.i18n : function(){ return ''; };
  function fallbackCollectBilling(form){
    if (!form) { return {}; }
    return {
      billing_first_name: form.querySelector('#bill_first_name')?.value?.trim() || '',
      billing_last_name: form.querySelector('#bill_last_name')?.value?.trim() || '',
      billing_country: form.querySelector('#bill_country')?.value?.trim() || '',
      billing_city: form.querySelector('#bill_city')?.value?.trim() || '',
      billing_state: form.querySelector('#bill_state')?.value?.trim() || '',
      billing_postcode: form.querySelector('#bill_postcode')?.value?.trim() || '',
      billing_address: form.querySelector('#bill_address')?.value?.trim() || '',
    };
  }
  function fallbackBillingComplete(data){
    return !!(data && data.billing_first_name && data.billing_last_name && data.billing_country && data.billing_address);
  }
  var collectBilling = (typeof window.__collectTipsBilling === 'function') ? window.__collectTipsBilling : fallbackCollectBilling;
  var billingComplete = (typeof window.__tipsBillingComplete === 'function') ? window.__tipsBillingComplete : fallbackBillingComplete;
  var alertDialog = (typeof window.__tipsAlertDialog === 'function') ? window.__tipsAlertDialog : function(message, tone, onConfirm){
    var normalized = (tone || 'info');
    if (normalized === 'error') { normalized = 'danger'; }
    if (normalized === 'neutral') { normalized = 'info'; }
    var titleMap = {
      success: I18N('ui_success_title') || 'Success',
      danger: I18N('ui_error_title') || 'Something went wrong',
      warning: I18N('ui_warning_title') || 'Heads up',
      info: I18N('ui_info_title') || 'Notice'
    };
    var label = I18N('ui_ok') || 'OK';
    try {
      if (window.DZ && typeof window.DZ.showAlertDialog === 'function') {
        window.DZ.showAlertDialog({
          tone: normalized,
          title: titleMap[normalized] || titleMap.info,
          message: String(message || ''),
          confirmLabel: label,
          onConfirm: typeof onConfirm === 'function' ? onConfirm : null
        });
        return true;
      }
    } catch(_){}
    return false;
  };
  function showMsg(msg, tone){
    var resolvedTone = tone || 'danger';
    if (resolvedTone === 'error') { resolvedTone = 'danger'; }
    if (!/^(success|danger|warning|info|neutral)$/.test(resolvedTone)) {
      resolvedTone = 'neutral';
    }
    if (alertDialog(msg, resolvedTone)) {
      return;
    }
    try { alert(msg); } catch(e){}
  }

  function onSubmit(ev){
    const form = ev.target.closest('.tips-form[data-form-type="subscription"]');
    if(!form) return;
    ev.preventDefault();
    if (form.dataset.submitting === '1') return;

    const provider = form.querySelector('input[name="tip_provider"]:checked')?.value || '';
    const recipientId = parseInt(form.querySelector('input[name="recipient_id"]').value || '0', 10);
    const interval = form.querySelector('input[name="plan_interval"]:checked')?.value || '';
    const amtEl = form.querySelector('#tipAmount');
    const precision = normalizePrecision(parseInt(form.getAttribute('data-amount-precision'), 10));
    const amount = parseAmount(amtEl ? amtEl.value : '0', precision);
    if (!provider || !recipientId || !interval || amount <= 0){ showMsg(I18N('pay_error_choose_plan') || 'Please choose a plan and provider.', 'error'); return; }

    // Basic billing requirements (server re-checks anyway)
    const bf = collectBilling(form);
    if (!billingComplete(bf)){
      showMsg(I18N('pay_error_complete_billing') || 'Please complete your billing details.', 'error');
      return;
    }

    const fd = new FormData();
    fd.append('p', 'subscription_create_payment');
    fd.append('provider', provider);
    fd.append('recipient_id', String(recipientId));
    fd.append('plan_interval', interval);
    fd.append('amount', String(amount.toFixed(precision)));
    Object.entries(bf).forEach(([k,v]) => fd.append(k, v));
    fd.append('csrf_token', getCsrf());

    form.dataset.submitting = '1';
    const submitBtn = form.querySelector('.tips-cta');
    if (submitBtn) { submitBtn.disabled = true; submitBtn.classList.add('is-loading'); }

    fetch(buildUrl('request/requests.php'), { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(r => r.json()).then(j => {
        if (!j || j.status !== 'success') { showMsg(j && j.message ? j.message : (I18N('pay_error_init_failed') || 'Payment init failed.'), 'error'); return; }
        if (j.provider === 'wallet') {
          if (j.redirect_url) { window.location.href = j.redirect_url; return; }
          var walletMessage = I18N('pay_subscription_activated_wallet') || 'Subscription activated via wallet.';
          var finalizeSubscriptionSuccess = function(){
            document.querySelector('.tips-overlay')?.classList.remove('is-open');
            document.querySelector('.popUp-container')?.remove();
            try {
              if (window.DZ && typeof window.DZ.toast === 'function') {
                DZ.toast(walletMessage, { type: 'success', duration: 2800 });
              }
            } catch(_){}
          };
          if (!alertDialog(walletMessage, 'success', finalizeSubscriptionSuccess)) {
            finalizeSubscriptionSuccess();
          }
          return;
        }
        if (j.checkout_url) {
          // Persist pending info for possible later reconciliation if needed
          try {
            window.sessionStorage.setItem('pending_payment', JSON.stringify({
              type: 'subscription', provider: j.provider || provider, reference: j.reference || '',
              recipient_id: recipientId, created_at: Date.now()
            }));
          } catch(e){}
          window.location.href = j.checkout_url; return;
        }
        showMsg(I18N('pay_unexpected_response') || 'Unexpected response.', 'error');
      }).catch(e => { console.error(e); showMsg(I18N('pay_request_failed') || 'Request failed.', 'error'); })
      .finally(() => {
        if (form.isConnected) {
          delete form.dataset.submitting;
          if (submitBtn) { submitBtn.disabled = false; submitBtn.classList.remove('is-loading'); }
        }
      });
  }

  document.addEventListener('submit', function(ev){
    if (ev.target && ev.target.matches('.tips-form[data-form-type="subscription"]')) { onSubmit(ev); }
  });

  if (typeof window.__toggleBillingSection !== 'function') {
    window.__toggleBillingSection = function(form, forceOpen, accordionEl, summaryEl){
      if (!form) { return; }
      var accordion = accordionEl || form.querySelector('.tips-accordion--form');
      if (!accordion) { return; }
      var summary = summaryEl || form.querySelector('[data-billing-summary]');
      var fields = accordion.querySelectorAll('[data-billing-fields]');
      var isCollapsed = accordion.classList.contains('is-collapsed');
      var shouldOpen = (typeof forceOpen === 'boolean') ? forceOpen : isCollapsed;
      if (shouldOpen) {
        form.dataset.billingEditing = '1';
        if (summary) { summary.setAttribute('hidden', 'hidden'); summary.classList.add('is-hidden'); }
        fields.forEach(function(block){ block.removeAttribute('hidden'); });
        accordion.classList.remove('is-collapsed');
        var focusTarget = accordion.querySelector('[data-billing-fields] input, [data-billing-fields] select, [data-billing-fields] textarea');
        if (focusTarget && typeof focusTarget.focus === 'function') {
          setTimeout(function(){ try { focusTarget.focus(); } catch(_){ } }, 30);
        }
      } else {
        delete form.dataset.billingEditing;
        if (summary) { summary.removeAttribute('hidden'); summary.classList.remove('is-hidden'); }
        fields.forEach(function(block){ block.setAttribute('hidden', 'hidden'); });
        accordion.classList.add('is-collapsed');
      }
    };
  }


  // ----- Live summary for subscriptions (includes platform subscription fee + taxes) -----
  function normalizePrecision(p){
    if (typeof p === 'number' && isFinite(p) && p >= 0) { return p; }
    if (window.DZ && DZ.currencyFormat && typeof DZ.currencyFormat.decimalPlaces === 'number') {
      var base = DZ.currencyFormat.decimalPlaces;
      if (isFinite(base) && base >= 0) { return base; }
    }
    return 2;
  }
  function parseAmount(raw, precision){
    var decSep = (window.DZ && DZ.currencyFormat && DZ.currencyFormat.decimalSep === ',') ? ',' : '.';
    var thouSep = (window.DZ && DZ.currencyFormat && typeof DZ.currencyFormat.thousandsSep === 'string') ? DZ.currencyFormat.thousandsSep : ',';
    var str = (raw === null || raw === undefined) ? '' : String(raw);
    if (thouSep) {
      var escThou = thouSep.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      str = str.replace(new RegExp(escThou, 'g'), '');
    }
    if (decSep !== '.') {
      var escDec = decSep.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      str = str.replace(new RegExp(escDec, 'g'), '.');
    }
    str = str.replace(/[^0-9.+-]/g, '');
    var num = parseFloat(str);
    if (!isFinite(num)) { num = 0; }
    var prec = normalizePrecision(precision);
    return parseFloat(num.toFixed(prec));
  }
  function formatMoney(n, cur, symbol){
    if (window.DZ && typeof window.DZ.formatCurrency === 'function') {
      return window.DZ.formatCurrency(n, cur, symbol);
    }
    var prec = normalizePrecision();
    var v = (Math.round((n + Number.EPSILON) * Math.pow(10, prec)) / Math.pow(10, prec)).toFixed(prec);
    return v + ' ' + (cur || 'USD');
  }
  // Not used now; keep if monthly display needed later
function monthlyFactor(interval){ return 1; }

  function computeSubscriptionSummary(){
    var form = document.querySelector('#tipsModal .tips-form[data-form-type="subscription"]');
    if(!form) return;
    var cur = form.getAttribute('data-currency') || 'USD';
    var curSymbol = form.getAttribute('data-currency-symbol') || '';
    var basePrecision = normalizePrecision(parseInt(form.getAttribute('data-amount-precision'), 10));
    var taxPct = parseFloat(form.getAttribute('data-tax-percent') || '0') || 0;
    var fixFee = parseFloat(form.getAttribute('data-fee-fixed') || '0') || 0;
    var subFeePct = parseFloat(form.getAttribute('data-subscription-fee-percent') || '0') || 0;
    var amountEl = form.querySelector('#tipAmount');
    var intervalEl = form.querySelector('input[name="plan_interval"]:checked');
    if (!intervalEl) {
      // Ensure one is checked (first option) so we have a price to calculate
      var firstOpt = form.querySelector('input[name="plan_interval"]');
      if (firstOpt) { firstOpt.checked = true; intervalEl = firstOpt; }
    }
    var interval = intervalEl ? intervalEl.value : 'monthly';
    var priceEl = intervalEl; // radio holds data-price
    var base = parseAmount(priceEl ? (priceEl.getAttribute('data-price') || '0') : '0', basePrecision);
    var platformFee = base * (subFeePct/100);
    var percentTax = base * (taxPct/100);
    var tax = fixFee + percentTax;
    var totalPerCycle = base + platformFee + tax;

    var root = document.querySelector('#tipsModal');
    if(!root) return;
    var sub = root.querySelector('.tips-subtotal-amount'); if(sub) sub.textContent = formatMoney(base, cur, curSymbol);
    var fee = root.querySelector('.tips-fee-amount'); if(fee) fee.textContent = formatMoney(platformFee, cur, curSymbol);
    var tx = root.querySelector('.tips-taxes-amount'); if(tx) tx.textContent = formatMoney(tax, cur, curSymbol);
    var tot = root.querySelector('.tips-total-amount'); if(tot) tot.textContent = formatMoney(totalPerCycle, cur, curSymbol);
    // Set hidden amount to the actual per-cycle total (with decimals)
    if (amountEl) { amountEl.value = String(totalPerCycle.toFixed(basePrecision)); }
  }

  // Recompute on plan change / input focus blur
  document.addEventListener('change', function(ev){
    if (ev.target && (ev.target.matches('input[name="plan_interval"]') || ev.target.id === 'tipAmount')) {
      computeSubscriptionSummary();
    }
  });
  document.addEventListener('input', function(ev){
    if (ev.target && ev.target.id === 'tipAmount') { computeSubscriptionSummary(); }
  });
  // Auto-init when popup is inserted into DOM
  function tryInitSummary(){
    setTimeout(computeSubscriptionSummary, 60);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', tryInitSummary);
  } else { tryInitSummary(); }
  try {
    var mo = new MutationObserver(function(muts){
      for (var i=0;i<muts.length;i++){
        var nodes = muts[i].addedNodes || [];
        for (var j=0;j<nodes.length;j++){
          var n = nodes[j];
          if (n.nodeType === 1) {
            if (n.id === 'tipsModal' || (n.querySelector && n.querySelector('#tipsModal'))) {
              tryInitSummary();
              return;
            }
          }
        }
      }
    });
    mo.observe(document.body, {childList:true, subtree:true});
  } catch(e) {}
})();
