'use strict';
(function (window, document) {
  if (!window || !document) { return; }

  var buildUrl = (window.DZ && window.DZ.buildUrl) || function (path) {
    try {
      var base = (typeof window.site_url === 'string' && window.site_url) ? window.site_url : (window.location.origin + '/');
      if (base.slice(-1) !== '/') { base += '/'; }
      return new URL(String(path || '').replace(/^\//, ''), base).toString();
    } catch (_) {
      return String(path || '');
    }
  };

  var state = {
    ad: null,
    loading: null,
    shownIds: []
  };

  function getCsrfToken() {
    var el = document.querySelector('input[name="csrf_token"]');
    return el ? String(el.value || '') : '';
  }

  function encodeForm(data) {
    var parts = [];
    Object.keys(data).forEach(function (key) {
      if (data[key] === undefined || data[key] === null) { return; }
      parts.push(encodeURIComponent(key) + '=' + encodeURIComponent(data[key]));
    });
    return parts.join('&');
  }

  function track(adId, action) {
    if (!(adId > 0)) { return; }
    var p = action === 'click' ? 'ads_track_click' : 'ads_track_impression';
    var payload = { p: p, ad_id: adId, csrf_token: getCsrfToken() };
    if (window.fetch) {
      window.fetch(buildUrl('request/requests.php'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: encodeForm(payload),
        credentials: 'same-origin'
      }).catch(function () {});
    }
  }

  function loadAd() {
    if (state.ad) {
      return Promise.resolve(state.ad);
    }
    if (state.loading) {
      return state.loading;
    }
    var payload = {
      p: 'ads_video_slot',
      csrf_token: getCsrfToken()
    };
    if (state.shownIds.length) {
      payload.exclude = state.shownIds.join(',');
    }
    state.loading = window.fetch(buildUrl('request/requests.php'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: encodeForm(payload),
      credentials: 'same-origin'
    }).then(function (response) {
      if (!response.ok) { throw new Error('HTTP ' + response.status); }
      return response.json();
    }).then(function (json) {
      state.loading = null;
      state.ad = json && json.status === 'success' && json.ad ? json.ad : null;
      return state.ad;
    }).catch(function () {
      state.loading = null;
      return null;
    });
    return state.loading;
  }

  function createOverlay(video, ad) {
    var wrapper = video.closest('.video-wrapper');
    if (!wrapper || !ad || !ad.media_url) { return null; }

    var overlay = document.createElement('div');
    overlay.className = 'video-ad-overlay';
    overlay.innerHTML =
      '<div class="video-ad-panel">' +
        '<div class="video-ad-meta">' +
          '<span class="video-ad-badge"></span>' +
          '<strong class="video-ad-title"></strong>' +
        '</div>' +
        '<video class="video-ad-media" playsinline preload="metadata"></video>' +
        '<div class="video-ad-actions">' +
          '<a class="video-ad-cta" target="_blank" rel="nofollow noopener"></a>' +
          '<button type="button" class="video-ad-skip"></button>' +
        '</div>' +
      '</div>';

    var adVideo = overlay.querySelector('.video-ad-media');
    var title = overlay.querySelector('.video-ad-title');
    var badge = overlay.querySelector('.video-ad-badge');
    var cta = overlay.querySelector('.video-ad-cta');
    var skip = overlay.querySelector('.video-ad-skip');

    adVideo.src = ad.media_url;
    if (ad.poster_url) { adVideo.poster = ad.poster_url; }
    adVideo.muted = false;
    title.textContent = ad.title || ad.ad_label || 'Advertisement';
    badge.textContent = ad.sponsored_label || ad.ad_label || 'Sponsored';
    cta.textContent = ad.cta_label || 'Visit advertiser';
    cta.href = ad.target_url || '#';
    skip.textContent = ad.skip_label || 'Skip ad';
    skip.disabled = true;

    var countdown = 5;
    skip.textContent = (ad.skip_label || 'Skip ad') + ' ' + countdown;
    var timer = window.setInterval(function () {
      countdown -= 1;
      if (countdown <= 0) {
        window.clearInterval(timer);
        skip.disabled = false;
        skip.textContent = ad.skip_label || 'Skip ad';
      } else {
        skip.textContent = (ad.skip_label || 'Skip ad') + ' ' + countdown;
      }
    }, 1000);

    function cleanup() {
      window.clearInterval(timer);
      try { adVideo.pause(); } catch (_) {}
      overlay.remove();
    }

    cta.addEventListener('click', function () { track(parseInt(ad.ad_id, 10), 'click'); });
    skip.addEventListener('click', function () {
      cleanup();
      resumeContent(video);
    });
    adVideo.addEventListener('ended', function () {
      cleanup();
      resumeContent(video);
    });

    wrapper.appendChild(overlay);
    track(parseInt(ad.ad_id, 10), 'impression');
    var playPromise = adVideo.play();
    if (playPromise && typeof playPromise.catch === 'function') {
      playPromise.catch(function () {});
    }
    return overlay;
  }

  function resumeContent(video) {
    if (!video || video.ended) { return; }
    var wrapper = video.closest('.video-wrapper');
    if (wrapper) {
      wrapper.classList.remove('is-paused');
    }
    var promise = video.play();
    if (promise && typeof promise.catch === 'function') {
      promise.catch(function () {});
    }
  }

  function showVideoAd(video, slot) {
    if (!video || video.dataset.videoAdActive === '1') { return; }
    if (slot === 'pre' && video.dataset.videoAdPre === '1') { return; }
    if (slot === 'mid' && video.dataset.videoAdMid === '1') { return; }
    video.dataset.videoAdActive = '1';
    loadAd().then(function (ad) {
      video.dataset.videoAdActive = '0';
      if (!ad || !ad.media_url) { return; }
      if (slot === 'pre') { video.dataset.videoAdPre = '1'; }
      if (slot === 'mid') { video.dataset.videoAdMid = '1'; }
      try { video.pause(); } catch (_) {}
      createOverlay(video, ad);
    });
  }

  function onVideoIntent(event) {
    var video = event.target && event.target.closest ? event.target.closest('.video-wrapper video.post-media') : null;
    if (!video) { return; }
    window.setTimeout(function () {
      if (!video.muted) {
        showVideoAd(video, 'pre');
      }
    }, 120);
  }

  function bindVideo(video) {
    if (!video || video.__videoAdsBound) { return; }
    video.__videoAdsBound = true;
    video.addEventListener('timeupdate', function () {
      var duration = Number(video.duration || 0);
      if (duration < 30 || video.muted || video.dataset.videoAdMid === '1') { return; }
      if ((video.currentTime || 0) >= Math.max(12, duration * 0.45)) {
        showVideoAd(video, 'mid');
      }
    });
  }

  function init(root) {
    var scope = root && root.querySelectorAll ? root : document;
    var videos = scope.querySelectorAll('.video-wrapper video.post-media');
    for (var i = 0; i < videos.length; i += 1) {
      bindVideo(videos[i]);
    }
  }

  document.addEventListener('click', onVideoIntent, true);
  document.addEventListener('DOMContentLoaded', function () { init(document); });
  if (window.jQuery) {
    window.jQuery(document).on('posts:loaded', function (_event, payload) {
      init(payload && payload.root ? payload.root : document);
    });
  }
  window.VideoAds = { init: init };
})(window, document);
