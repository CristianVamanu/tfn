(function (window, $) {
  'use strict';
  var buildUrl = (window.DZ && window.DZ.buildUrl) || function(path){
    try { var base=(typeof window.site_url==='string'&&window.site_url)?window.site_url:(window.location.origin+window.location.pathname.replace(/[^\/]*$/,'')); if(base.slice(-1)!=='/') base+='/'; return new URL(String(path||'').replace(/^\//,''), base).toString(); } catch(_) { return String(path||''); }
  };

  var ProfileGrid = {
    busy: false,
    hasMore: false,
    cursor: { time: 0, id: 0 },
    startLayout: 'right',
    limit: 15,
    filter: 'all',
    view: 'grid',
    targetId: 0,
    $root: null,
    $sentinel: null,
    io: null,

    IO_ROOT_MARGIN: '1200px 0px 1200px 0px',
    IO_THRESHOLD: [0, 0.01],

    init: function () {
      this.$root = $('#profile-root');
      if (!this.$root.length) { return; }

      this.$sentinel = $('#profile-sentinel');
      if (this.$sentinel.length) { this.$sentinel.addClass('io-sentinel'); }

      // Read initial state from DOM
      this.cursor.time   = parseInt(this.$root.attr('data-cursor-time') || '0', 10);
      this.cursor.id     = parseInt(this.$root.attr('data-cursor-id')   || '0', 10);
      this.hasMore       = (this.$root.attr('data-has-more') === '1');
      this.limit         = parseInt(this.$root.attr('data-limit') || '15', 10);
      this.startLayout   = (this.$root.attr('data-start-layout') === 'left') ? 'left' : 'right';
      this.filter        = (this.$root.attr('data-filter') || 'all');
      this.view          = (this.$root.attr('data-view') === 'feed') ? 'feed' : 'grid';
      this.targetId      = parseInt(this.$root.attr('data-user-id') || '0', 10);

      // CSRF token
      var $csrf = $('input[name="csrf_token"]');
      this.csrf = $csrf.length ? ($csrf.val() || '') : '';

      this._setupObserver();
      // Tabs are plain links now; no JS hijack
      // this._bindTabs();
    },

    _setupObserver: function () {
      var self = this;
      if (!this.$sentinel.length) { return; }
      this.io = new IntersectionObserver(function (entries) {
        var e = entries && entries[0];
        if (!e) { return; }
        if (e.isIntersecting || e.intersectionRatio > 0) { self.loadMore(); }
      }, {
        root: null,
        rootMargin: this.IO_ROOT_MARGIN,
        threshold: this.IO_THRESHOLD
      });
      this.io.observe(this.$sentinel.get(0));
    },

    _bindTabs: function () {
      var self = this;
      $(document).on('click', '.profile-tab', function (ev) {
        ev.preventDefault();
        var $btn = $(this);
        var filt = ($btn.attr('data-filter') || 'all');
        if (filt === self.filter) { return; }
        $('.profile-tab').removeClass('is-active');
        $btn.addClass('is-active');
        self.switchFilter(filt);
      });
    },

    switchFilter: function (filt) {
      if (!this.$root.length) { return; }
      // Reset state
      this.filter = filt;
      this.cursor = { time: 0, id: 0 };
      this.startLayout = 'right';
      this.hasMore = true; // optimistic until server says no
      this.$root.attr('data-filter', filt);
      // No-op: navigation handled by anchors
      // Detach sentinel to preserve the node reference
      var $sent = this.$sentinel && this.$sentinel.length ? this.$sentinel.detach() : $('<div id="profile-sentinel" aria-hidden="true"></div>');
      // Clear all children under root
      this.$root.find('> *').remove();

      // Ensure proper container per filter
      if (filt === 'all') {
        // All -> mosaic, sentinel directly under root
        this.$root.append($sent);
      } else {
        // Non-All -> images/reels style grid container
        var $list = $('<div class="reels_container" id="profile-list"></div>');
        $list.append($sent);
        this.$root.append($list);
      }

      // Rebind sentinel ref and (re)observe
      if (this.io && this.$sentinel && this.$sentinel.length) {
        try { this.io.unobserve(this.$sentinel.get(0)); } catch (e) {}
      }
      this.$sentinel = $('#profile-sentinel');
      if (this.io && this.$sentinel && this.$sentinel.length) {
        try { this.io.observe(this.$sentinel.get(0)); } catch (e) {}
      }

      // Load first page (reusing loadMore with cursor=0)
      this.loadMore(true);
    },

    // Removed hash/localStorage recovery; server-side routing handles filter

    loadMore: function (isFirst) {
      if (this.busy || !this.hasMore) { return; }
      this.busy = true;
      var self = this;

      $.ajax({
        url: buildUrl('request/requests.php'),
        type: 'POST',
        dataType: 'json',
        data: {
          p: 'profile_more',
          target_id: this.targetId,
          filter: this.filter,
          view: this.view,
          cursor_time: this.cursor.time,
          cursor_id: this.cursor.id,
          limit: this.limit,
          start_layout: this.startLayout,
          csrf_token: this.csrf
        }
      }).done(function (res) {
        if (!res || res.status !== 'ok') { return; }
        if (res.html) {
      var $chunk = $(res.html);
      self.$sentinel.before($chunk);
        }
        // Stop if server indicates no more or no real tiles were returned
        self.hasMore = !!res.has_more;
        if ((typeof res.tile_count !== 'undefined' && parseInt(res.tile_count, 10) === 0)) {
          self.hasMore = false;
        } else if (res.html) {
          var txt = (typeof res.html === 'string') ? res.html : '';
          if (txt && txt.replace(/\s+/g, '').length < 40) {
            self.hasMore = false;
          }
        }
        if (res.next_cursor) {
          self.cursor.time = parseInt(res.next_cursor.time || '0', 10);
          self.cursor.id   = parseInt(res.next_cursor.id   || '0', 10);
        }
        if (res.next_start_layout) {
          self.startLayout = (res.next_start_layout === 'left') ? 'left' : 'right';
        }
      }).always(function () {
        self.busy = false;
      });
    }
  };

  $(function () { ProfileGrid.init(); });
  window.ProfileGrid = ProfileGrid;

})(window, jQuery);
