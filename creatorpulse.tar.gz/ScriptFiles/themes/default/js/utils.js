'use strict';
(function(){
  if (window.DZ && typeof window.DZ.buildUrl === 'function') { if (!window.buildUrl) window.buildUrl = window.DZ.buildUrl; return; }
  function buildUrl(path){
    try {
      var base = '';
      if (typeof window.site_url === 'string' && window.site_url) {
        base = window.site_url;
      } else if (window.DZ && typeof window.DZ.__computeBase === 'function') {
        base = window.DZ.__computeBase('');
      } else {
        var origin = window.location.origin || ((window.location.protocol || 'http:') + '//' + (window.location.host || ''));
        var pathRoot = (window.location.pathname || '/').replace(/[^\/]*$/, '');
        base = origin + (pathRoot || '/');
      }
      return new URL(String(path||''), base).toString();
    } catch(_) { return String(path||''); }
  }
  window.DZ = window.DZ || {};
  window.DZ.buildUrl = buildUrl;
  if (!window.buildUrl) window.buildUrl = buildUrl;
})();

(function(){
  var STORAGE_PREFIX = 'siteAnnouncement:';

  function storageAvailable() {
    try {
      if (!('localStorage' in window)) { return false; }
      var testKey = '__announcement__';
      window.localStorage.setItem(testKey, '1');
      window.localStorage.removeItem(testKey);
      return true;
    } catch (_) {
      return false;
    }
  }

  var canUseLocalStorage = storageAvailable();

  function cookieSet(name, value, days) {
    try {
      var expires = '';
      if (typeof days === 'number') {
        var date = new Date();
        date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
        expires = '; expires=' + date.toUTCString();
      }
      document.cookie = name + '=' + encodeURIComponent(String(value)) + expires + '; path=/';
    } catch (_) {}
  }

  function cookieHas(name) {
    try {
      var parts = document.cookie ? document.cookie.split(';') : [];
      for (var i = 0; i < parts.length; i++) {
        var part = parts[i].trim();
        if (part.indexOf(name + '=') === 0) {
          return true;
        }
      }
    } catch (_) {}
    return false;
  }

  function keyFor(id) {
    return STORAGE_PREFIX + String(id);
  }

  function isDismissed(id) {
    var key = keyFor(id);
    if (canUseLocalStorage) {
      try { return window.localStorage.getItem(key) === 'dismissed'; } catch (_) {}
    }
    return cookieHas(key);
  }

  function markDismissed(id) {
    var key = keyFor(id);
    if (canUseLocalStorage) {
      try {
        window.localStorage.setItem(key, 'dismissed');
        return;
      } catch (_) {}
    }
    cookieSet(key, '1', 30);
  }

  function initAnnouncements() {
    var banners = document.querySelectorAll('[data-site-announcement]');
    if (!banners.length) {
      return;
    }

    banners.forEach(function (banner) {
      var id = banner.getAttribute('data-announcement-id') || '';
      if (!id) {
        return;
      }

      if (isDismissed(id)) {
        banner.classList.add('site-announcement--hidden');
        return;
      }

      var dialog = banner.querySelector('.site-announcement__dialog');
      if (dialog) {
        dialog.setAttribute('tabindex', '-1');
        try { window.requestAnimationFrame(function(){ dialog.focus({ preventScroll: true }); }); } catch (_) {}
      }

      var allowClose = banner.getAttribute('data-allow-close') !== '0';
      var closeBtn = banner.querySelector('[data-announcement-dismiss]');

      if (allowClose && closeBtn) {
        closeBtn.addEventListener('click', function () {
          markDismissed(id);
          banner.classList.add('site-announcement--hidden');
        });
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAnnouncements);
  } else {
    initAnnouncements();
  }
})();

(function(){
  try {
    var body = document.body || document.documentElement;
    if (!body) { return; }
    var maintenanceStatus = (body.getAttribute('data-maintenance-status') || '').toLowerCase();
    var layout = (body.getAttribute('data-layout') || '').toLowerCase();
    if (!(maintenanceStatus === 'on' && layout === 'contact')) {
      return;
    }

    var blockPattern = /\/request\/requests\.php/i;

    if (typeof window.fetch === 'function' && !window.fetch.__maintenanceWrapped) {
      var originalFetch = window.fetch.bind(window);
      var wrappedFetch = function(input, init) {
        try {
          var url = typeof input === 'string' ? input : (input && typeof input.url === 'string' ? input.url : '');
          if (url && blockPattern.test(url)) {
            return Promise.reject(new Error('maintenance_mode_blocked'));
          }
        } catch (_) {}
        return originalFetch(input, init);
      };
      wrappedFetch.__maintenanceWrapped = true;
      wrappedFetch.__originalFetch = originalFetch;
      window.fetch = wrappedFetch;
    }

    if (window.jQuery && typeof window.jQuery.ajax === 'function' && !window.jQuery.ajax.__maintenanceWrapped) {
      var originalAjax = window.jQuery.ajax;
      window.jQuery.ajax = function(settings) {
        try {
          var url = settings && settings.url ? String(settings.url) : '';
          if (url && blockPattern.test(url)) {
            if (typeof settings.error === 'function') {
              settings.error(null, 'maintenance', 'Maintenance mode active');
            }
            if (window.jQuery && typeof window.jQuery.Deferred === 'function') {
              return window.jQuery.Deferred().reject(null, 'maintenance', 'Maintenance mode active').promise();
            }
            return Promise.reject(new Error('maintenance_mode_blocked'));
          }
        } catch (_) {}
        return originalAjax.apply(this, arguments);
      };
      window.jQuery.ajax.__maintenanceWrapped = true;
    }
  } catch (_) {}
})();

(function(){
  var CSRF_REGEX = /invalid\s+csrf\s+token/i;
  var REQUEST_FAIL_REGEX = /(istek\s+başarısız|request\s+failed)/i;
  var modalShown = false;

  function showCsrfModal(){
    if (modalShown) { return; }
    modalShown = true;
    var backdrop = document.createElement('div');
    backdrop.className = 'csrf-session-modal__backdrop';
    backdrop.setAttribute('role', 'dialog');
    backdrop.setAttribute('aria-modal', 'true');
    backdrop.setAttribute('aria-live', 'assertive');
    var dialog = document.createElement('div');
    dialog.className = 'csrf-session-modal';
    var i18nFn = (window.DZ && typeof DZ.i18n === 'function') ? DZ.i18n : (typeof window.I18N === 'function' ? window.I18N : function(){ return ''; });
    var titleText = i18nFn('session_expired_title');
    if (!titleText || titleText === 'session_expired_title') {
      titleText = 'Session expired';
    }
    var bodyText = i18nFn('session_expired_body');
    if (!bodyText || bodyText === 'session_expired_body') {
      bodyText = 'You were inactive for a while. Please reload this page to continue.';
    }
    var btnText = i18nFn('reload_page');
    if (!btnText || btnText === 'reload_page') {
      btnText = 'Reload page';
    }
    dialog.innerHTML = '<div class="csrf-session-modal__icon">!</div>' +
      '<h2>' + titleText + '</h2>' +
      '<p>' + bodyText + '</p>' +
      '<button type="button">' + btnText + '</button>';
    backdrop.appendChild(dialog);
    document.body.appendChild(backdrop);
    var btn = dialog.querySelector('button');
    if (btn) {
      btn.addEventListener('click', function(){ try { window.location.reload(); } catch(_) { window.location = window.location.href; } });
      setTimeout(function(){ try { btn.focus({ preventScroll: true }); } catch(_) { btn.focus && btn.focus(); } }, 50);
    }
  }

  try {
    window.DZ = window.DZ || {};
    if (typeof window.DZ.triggerSessionRefreshModal !== 'function') {
      window.DZ.triggerSessionRefreshModal = showCsrfModal;
    }
  } catch(_) {}

  function inspectPayload(payload){
    try {
      if (payload == null) { return false; }
      if (typeof payload === 'string') {
        if (CSRF_REGEX.test(payload) || REQUEST_FAIL_REGEX.test(payload)) { showCsrfModal(); return true; }
        try {
          return inspectPayload(JSON.parse(payload));
        } catch(_) {
          return false;
        }
      }
      if (typeof payload === 'object') {
        if (typeof payload.message === 'string' && (CSRF_REGEX.test(payload.message) || REQUEST_FAIL_REGEX.test(payload.message))) { showCsrfModal(); return true; }
        if (typeof payload.error === 'string' && (CSRF_REGEX.test(payload.error) || REQUEST_FAIL_REGEX.test(payload.error))) { showCsrfModal(); return true; }
        if (typeof payload.code === 'string' && (CSRF_REGEX.test(payload.code) || REQUEST_FAIL_REGEX.test(payload.code))) { showCsrfModal(); return true; }
      }
    } catch(_) {}
    return false;
  }

  function inspectResponseText(text){
    if (typeof text !== 'string') { return false; }
    if (CSRF_REGEX.test(text) || REQUEST_FAIL_REGEX.test(text)) { showCsrfModal(); return true; }
    return false;
  }

  if (typeof window.fetch === 'function' && !window.fetch.__csrfWrapped) {
    var originalFetch = window.fetch.bind(window);
    var wrappedFetch = function(input, init){
      return originalFetch(input, init).then(function(response){
        try {
          if (response && typeof response.clone === 'function') {
            response.clone().text().then(inspectResponseText).catch(function(){});
          }
          if (response && response.status === 403) {
            var headerMsg = '';
            try { headerMsg = response.headers && response.headers.get && response.headers.get('X-CSRF-Error') || ''; } catch(_) {}
            if (headerMsg && CSRF_REGEX.test(headerMsg)) { showCsrfModal(); }
          }
        } catch(_) {}
        return response;
      }).catch(function(err){
        try {
          if (err && typeof err.message === 'string' && CSRF_REGEX.test(err.message)) { showCsrfModal(); }
        } catch(_) {}
        throw err;
      });
    };
    wrappedFetch.__csrfWrapped = true;
    wrappedFetch.__originalFetch = originalFetch;
    window.fetch = wrappedFetch;
  }

  if (window.jQuery && typeof window.jQuery.ajax === 'function' && !window.jQuery.__csrfEventBound) {
    try {
      var $doc = window.jQuery(document);
      $doc.on('ajaxComplete.csrfGuard', function(_evt, xhr, settings){
        try {
          if (!xhr) { return; }
          if (typeof xhr.responseText === 'string' && inspectResponseText(xhr.responseText)) { return; }
          if (typeof xhr.responseJSON === 'object' && inspectPayload(xhr.responseJSON)) { return; }
        } catch(_) {}
      });
      $doc.on('ajaxError.csrfGuard', function(_evt, xhr){
        try {
          if (!xhr) { return; }
          if (typeof xhr.responseText === 'string' && inspectResponseText(xhr.responseText)) { return; }
          if (typeof xhr.responseJSON === 'object' && inspectPayload(xhr.responseJSON)) { return; }
        } catch(_) {}
      });
      window.jQuery.__csrfEventBound = true;
    } catch(_) {}
  }

  if (typeof XMLHttpRequest !== 'undefined' && !XMLHttpRequest.__csrfWrapped) {
    try {
      var originalSend = XMLHttpRequest.prototype.send;
      var originalOpen = XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open = function(method, url){
        this.__csrf_url = url;
        return originalOpen.apply(this, arguments);
      };
      XMLHttpRequest.prototype.send = function(){
        if (!this.__csrfHooked) {
          this.__csrfHooked = true;
          var self = this;
          var handleResponse = function(){
            try {
              if (self && typeof self.responseText === 'string') {
                if (inspectResponseText(self.responseText)) { return; }
              }
              if (self && typeof self.response === 'object') {
                inspectPayload(self.response);
              }
              if (self && (self.status === 401 || self.status === 403)) {
                inspectResponseText(self.responseText || '');
              }
            } catch(_) {}
          };
          self.addEventListener('loadend', handleResponse);
          self.addEventListener('error', handleResponse);
          self.addEventListener('abort', handleResponse);
        }
        return originalSend.apply(this, arguments);
      };
      XMLHttpRequest.__csrfWrapped = true;
    } catch(_) {}
  }
})();

(function(){
  function onReady(fn){
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  function focusMaintenanceShell(){
    var host = document.querySelector('[data-maintenance-auto-focus]');
    if (!host) { return; }
    try {
      host.focus({ preventScroll: true });
    } catch (_) {
      try { host.setAttribute('tabindex', host.getAttribute('tabindex') || '-1'); host.focus(); } catch (__) {}
    }
  }

  function initMaintenanceCountdown(){
    var container = document.querySelector('[data-maintenance-countdown]');
    if (!container) { return; }

    var target = parseInt(container.getAttribute('data-maintenance-target') || '', 10);
    if (!target || isNaN(target)) { return; }

    var daysEl   = container.querySelector('[data-maintenance-countdown-days] strong');
    var hoursEl  = container.querySelector('[data-maintenance-countdown-hours] strong');
    var minsEl   = container.querySelector('[data-maintenance-countdown-minutes] strong');
    var secsEl   = container.querySelector('[data-maintenance-countdown-seconds] strong');
    var etaText  = document.querySelector('[data-maintenance-eta-text]');
    var elapsed  = container.getAttribute('data-maintenance-elapsed') || '';

    function pad(value){ return value < 10 ? '0' + value : String(value); }

    function render(diff){
      if (typeof diff !== 'number' || diff < 0) { diff = 0; }
      var days = Math.floor(diff / 86400);
      var remainder = diff % 86400;
      var hours = Math.floor(remainder / 3600);
      remainder = remainder % 3600;
      var minutes = Math.floor(remainder / 60);
      var seconds = remainder % 60;

      if (daysEl) { daysEl.textContent = pad(days); }
      if (hoursEl) { hoursEl.textContent = pad(hours); }
      if (minsEl) { minsEl.textContent = pad(minutes); }
      if (secsEl) { secsEl.textContent = pad(seconds); }
    }

    function update(){
      var now = Math.floor(Date.now() / 1000);
      var diff = target - now;
      if (diff <= 0) {
        render(0);
        if (etaText && elapsed) { etaText.textContent = elapsed; }
        container.classList.add('maintenance-status-card__countdown--hidden');
        clearInterval(timer);
        return;
      }
      container.classList.remove('maintenance-status-card__countdown--hidden');
      render(diff);
    }

    render(Math.max(0, target - Math.floor(Date.now() / 1000)));
    var timer = setInterval(update, 1000);
  }

  function bindRetryButton(){
    var retryBtn = document.querySelector('[data-maintenance-retry]');
    if (!retryBtn) { return; }
    retryBtn.addEventListener('click', function(){
      try {
        window.location.reload();
      } catch (_) {
        window.location.href = window.location.href;
      }
    });
  }

  onReady(function(){
    focusMaintenanceShell();
    initMaintenanceCountdown();
    bindRetryButton();
  });
})();

(function(){
  'use strict';

  var doc = document;
  if (!doc) { return; }

  var MARK_ATTR = 'data-lazy-enhanced';
  // Media inside posts, messages, or viewers manage their own sizing; skip dimension forcing there.
  var SKIP_DIMENSION_SELECTOR = '.post-media-single, .post-media-swiper, .post-media-video, .embed-media, .media-viewer, .media-viewer__content, .media-viewer__zoom-surface, .chat_bubble, .chat-share-card, .chat_avatar, .message_me, .message_media, .message_me_media, .message-body__media, .reels_post_wrapper, .reels_post_wrapper_reels, .live-card__cover';

  function enforceNoDimensions(img){
    if (!img || img.__dzNoDimObserverActive) { return; }
    if (typeof MutationObserver !== 'function') { return; }

    var observer = new MutationObserver(function(mutations) {
      for (var i = 0; i < mutations.length; i++) {
        var mutation = mutations[i];
        var attr = mutation && mutation.attributeName;
        if (!attr || (attr !== 'width' && attr !== 'height')) { continue; }
        if (img.hasAttribute(attr)) {
          img.removeAttribute(attr);
        }
      }
    });

    observer.observe(img, { attributes: true, attributeFilter: ['width', 'height'], attributeOldValue: true });
    img.__dzNoDimObserverActive = true;
  }

  function isInSkipDimensionContext(node){
    if (!node || node.nodeType !== 1) { return false; }
    if (node.hasAttribute && (node.hasAttribute('data-skip-image-dimensions') || node.hasAttribute('data-lazy-dimensions') && node.getAttribute('data-lazy-dimensions') === 'skip')) {
      return true;
    }

    var el = node;
    while (el && el.nodeType === 1) {
      if (el.hasAttribute && el.hasAttribute('data-skip-image-dimensions')) { return true; }
      if (typeof el.getAttribute === 'function') {
        var attr = el.getAttribute('data-lazy-dimensions');
        if (attr && attr.toLowerCase && attr.toLowerCase() === 'skip') { return true; }
      }
      if (typeof el.matches === 'function' && el.matches(SKIP_DIMENSION_SELECTOR)) { return true; }
      el = el.parentElement;
    }
    return false;
  }

  function shouldPreferLazy(img){
    if (!img || img.nodeType !== 1 || img.tagName !== 'IMG') { return false; }
    if (img.dataset && img.dataset.lazyIgnore !== undefined) { return false; }
    if (img.hasAttribute('loading') && img.getAttribute('loading') === 'eager') { return false; }
    if (img.dataset && img.dataset.priority === 'high') { return false; }
    if (img.getAttribute('fetchpriority') === 'high') { return false; }
    return true;
  }

  function assignDimensions(img){
    if (!img || img.tagName !== 'IMG') { return; }
    if (isInSkipDimensionContext(img)) {
      if (img.hasAttribute('width')) { img.removeAttribute('width'); }
      if (img.hasAttribute('height')) { img.removeAttribute('height'); }
      enforceNoDimensions(img);
      return;
    }

    var lazyDimPref = '';
    if (img.dataset && typeof img.dataset.lazyDimensions === 'string') {
      lazyDimPref = img.dataset.lazyDimensions.toLowerCase();
    } else if (img.hasAttribute('data-lazy-dimensions')) {
      lazyDimPref = String(img.getAttribute('data-lazy-dimensions')).toLowerCase();
    }

    if (lazyDimPref !== 'auto') {
      if (img.hasAttribute('width')) { img.removeAttribute('width'); }
      if (img.hasAttribute('height')) { img.removeAttribute('height'); }
      enforceNoDimensions(img);
      return;
    }

    if (img.hasAttribute('width') && img.hasAttribute('height')) { return; }
    var w = img.naturalWidth;
    var h = img.naturalHeight;
    if (w && h) {
      if (!img.hasAttribute('width')) {
        img.setAttribute('width', String(w));
      }
      if (!img.hasAttribute('height')) {
        img.setAttribute('height', String(h));
        enforceNoDimensions(img);
      }
    }
  }

  function enhanceImage(img){
    if (!img || img.nodeType !== 1 || img.tagName !== 'IMG') { return; }
    if (img.dataset && img.dataset.lazyIgnore !== undefined) { return; }

    var alreadyProcessed = img.getAttribute(MARK_ATTR) === '1';

    if (!alreadyProcessed) {
      if (shouldPreferLazy(img) && !img.hasAttribute('loading')) {
        img.setAttribute('loading', 'lazy');
        if (!img.hasAttribute('fetchpriority')) {
          img.setAttribute('fetchpriority', 'low');
        }
      }
      if (!img.hasAttribute('decoding')) {
        img.setAttribute('decoding', 'async');
      }
      img.setAttribute(MARK_ATTR, '1');
    }

    if (img.complete) {
      assignDimensions(img);
    } else {
      img.addEventListener('load', function handleLoad() {
        assignDimensions(img);
      }, { once: true });
    }
  }

  function processContext(context){
    if (!context) { return; }
    if (context.tagName === 'IMG') {
      enhanceImage(context);
    }
    if (context.querySelectorAll) {
      var list = context.querySelectorAll('img');
      for (var i = 0; i < list.length; i++) {
        enhanceImage(list[i]);
      }
    }
  }

  function syncColorScheme(){
    try {
      var html = doc.documentElement;
      var body = doc.body;
      var attr = (html && html.getAttribute('data-theme')) || (body && body.getAttribute('data-theme')) || '';
      var normalized = (attr === 'dark' || attr === 'light') ? attr : '';
      if (!normalized && html && html.classList) {
        if (html.classList.contains('theme-dark')) { normalized = 'dark'; }
        else if (html.classList.contains('theme-light')) { normalized = 'light'; }
      }
      if (!normalized && body && body.classList) {
        if (body.classList.contains('theme-dark')) { normalized = 'dark'; }
        else if (body.classList.contains('theme-light')) { normalized = 'light'; }
      }
      if (!normalized) { return; }
      if (html && html.style && typeof html.style.setProperty === 'function') {
        html.style.setProperty('color-scheme', normalized);
      }
      if (body && body.style && typeof body.style.setProperty === 'function') {
        body.style.setProperty('color-scheme', normalized);
      }
    } catch (_) {}
  }

  function bootstrap(){
    processContext(doc);
    syncColorScheme();
  }

  if (doc.readyState === 'loading') {
    doc.addEventListener('DOMContentLoaded', function handleDOMContentLoaded() {
      bootstrap();
    }, { once: true });
  } else {
    bootstrap();
  }

  if (typeof window.MutationObserver === 'function') {
    var nodeObserver = new MutationObserver(function(records) {
      for (var i = 0; i < records.length; i++) {
        var record = records[i];
        if (!record || !record.addedNodes) { continue; }
        for (var j = 0; j < record.addedNodes.length; j++) {
          var node = record.addedNodes[j];
          if (node && node.nodeType === 1) {
            processContext(node);
          }
        }
      }
    });
    nodeObserver.observe(doc.documentElement, { childList: true, subtree: true });

    var themeObserver = new MutationObserver(function() {
      syncColorScheme();
    });
    if (doc.documentElement) {
      themeObserver.observe(doc.documentElement, { attributes: true, attributeFilter: ['data-theme', 'class'] });
    }
    if (doc.body) {
      themeObserver.observe(doc.body, { attributes: true, attributeFilter: ['data-theme', 'class'] });
    }
  }
})();
