'use strict';
(function(){
  function onReady(fn){ if (document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  onReady(function(){
    initThemeToggle();
    initMenuUnderline();
    initResponsiveNav();

    var simulatorSection = document.getElementById('earnings-simulator');
    var followersInput = document.getElementById('followers');
    var priceInput = document.getElementById('price');
    var followersCount = document.getElementById('followersCount');
    var priceCount = document.getElementById('priceCount');
    var monthlyEarning = document.getElementById('monthlyEarning');
    if (!followersInput || !priceInput || !followersCount || !priceCount || !monthlyEarning) return;

    var followersDefault = parseInt(followersInput.getAttribute('data-default-value') || followersInput.value || '0', 10);
    if (!isFinite(followersDefault)) { followersDefault = 0; }
    var priceDefault = parseFloat(priceInput.getAttribute('data-default-value') || priceInput.value || '0');
    if (!isFinite(priceDefault)) { priceDefault = 0; }

    var followersMin = parseInt(followersInput.min || '0', 10);
    var followersMax = parseInt(followersInput.max || '0', 10);
    var priceMin = parseFloat(priceInput.min || '0');
    var priceMax = parseFloat(priceInput.max || '0');

    var conversionAttr = monthlyEarning.getAttribute('data-conversion-rate')
      || (simulatorSection ? simulatorSection.getAttribute('data-conversion-rate') : null);
    var conversionRate = parseFloat(conversionAttr || '0.2');
    if (!isFinite(conversionRate)) { conversionRate = 0.2; }
    if (conversionRate < 0) { conversionRate = 0; }
    if (conversionRate > 1) { conversionRate = 1; }

    var currencySymbol = priceCount.dataset.currencySymbol || '';
    var currencyCode = priceCount.dataset.currencyCode || '';
    if (!currencyCode) {
      currencyCode = currencySymbol && currencySymbol.length <= 4 ? currencySymbol : 'USD';
    }

    function clamp(value, min, max) {
      if (isFinite(min) && value < min) { value = min; }
      if (isFinite(max) && value > max) { value = max; }
      return value;
    }

    var currencyCfg = (window.DZ && window.DZ.currencyFormat) || {};

    function formatCurrency(amount) {
      if (window.DZ && typeof window.DZ.formatCurrency === 'function') {
        return window.DZ.formatCurrency(amount, currencyCode, currencySymbol);
      }
      var settings = {
        decimalSep: currencyCfg.decimalSep === ',' ? ',' : '.',
        thousandsSep: typeof currencyCfg.thousandsSep === 'string' ? currencyCfg.thousandsSep : ',',
      };
      var numeric = Number(amount);
      if (!isFinite(numeric)) { numeric = 0; }
      var fixed = numeric.toFixed(2);
      var parts = fixed.split('.');
      if (settings.thousandsSep) {
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, settings.thousandsSep);
      }
      var joined = parts.length > 1 ? parts[0] + settings.decimalSep + parts[1] : parts[0];
      if (currencySymbol && currencySymbol !== currencyCode && currencySymbol.length <= 4) {
        return currencySymbol + (currencySymbol === '$' ? '' : ' ') + joined;
      }
      return joined + ' ' + currencyCode;
    }

    function formatNumber(value, decimals) {
      var precision = typeof decimals === 'number' ? decimals : 0;
      var settings = {
        decimalSep: currencyCfg.decimalSep === ',' ? ',' : '.',
        thousandsSep: typeof currencyCfg.thousandsSep === 'string' ? currencyCfg.thousandsSep : ',',
      };
      var numeric = Number(value);
      if (!isFinite(numeric)) { numeric = 0; }
      var fixed = numeric.toFixed(precision);
      var parts = fixed.split('.');
      if (settings.thousandsSep) {
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, settings.thousandsSep);
      }
      return parts.length > 1 ? parts[0] + settings.decimalSep + parts[1] : parts[0];
    }

    function calculate(){
      var followers = parseInt(followersInput.value || '0', 10);
      if (!isFinite(followers)) {
        followers = followersDefault;
      }
      followers = clamp(followers, followersMin, followersMax);

      var price = parseFloat(priceInput.value || '0');
      if (!isFinite(price)) {
        price = priceDefault;
      }
      price = clamp(price, priceMin, priceMax);

      var estimatedSubscribers = Math.round(followers * conversionRate);
      var estimatedIncome = estimatedSubscribers * price;
      followersCount.textContent = formatNumber(followers, 0);
      priceCount.textContent = formatCurrency(price);
      monthlyEarning.textContent = formatCurrency(estimatedIncome);
    }
    followersInput.addEventListener('input', calculate);
    priceInput.addEventListener('input', calculate);
    calculate();
  });
  function resolveColorValue(raw){
    if (!raw) { return ''; }
    var val = String(raw).trim();
    if (!val) { return ''; }
    if (val.toLowerCase().startsWith('var(')) {
      var match = val.match(/var\(\s*(--[^\s,)\}]+)(?:\s*,\s*([^)]+))?\s*\)/i);
      if (match && match[1]) {
        var cssVar = match[1].trim();
        try {
          var resolved = getComputedStyle(document.documentElement).getPropertyValue(cssVar);
          if (resolved && resolved.trim()) {
            return resolved.trim();
          }
        } catch(_) {}
        if (match[2]) {
          return match[2].trim();
        }
      }
    }
    return val;
  }
  function syncMarkerColors(mode){
    try {
      var nodes = document.querySelectorAll('.big-bold-list .marker-animation');
      if (!nodes || !nodes.length) { return; }
      var isDark = mode === 'dark';
      var hasjQuery = typeof window.jQuery === 'function';
      var canRefresh = Boolean(hasjQuery && window.jQuery.fn && typeof window.jQuery.fn.markerAnimation === 'function');
      nodes.forEach(function(node){
        var lightColor = node.getAttribute('data-ma_color_light') || node.getAttribute('data-ma_color');
        var darkColor = node.getAttribute('data-ma_color_dark') || 'var(--bg-elevated)';
        var target = resolveColorValue(isDark ? darkColor : lightColor);
        if (!target) { return; }
        var currentAttr = node.getAttribute('data-ma_color') || '';
        var jq = hasjQuery ? window.jQuery(node) : null;
        var currentData = jq ? (jq.data('ma_color') || '') : currentAttr;
        if (currentAttr.trim() === target && currentData.trim() === target) { return; }
        node.setAttribute('data-ma_color', target);
        if (jq) { jq.data('ma_color', target); }
        if (canRefresh && jq) {
          try {
            jq.markerAnimation('destroy');
            jq.markerAnimation();
          } catch(_) {}
        }
      });
    } catch (_) {}
  }
  function writeThemeCookie(mode){
    try {
      var val = (mode === 'dark' || mode === 'light') ? mode : 'auto';
      var expires = new Date();
      expires.setFullYear(expires.getFullYear() + 1);
      var serialized = encodeURIComponent(val) + '; path=/; expires=' + expires.toUTCString() + '; SameSite=Lax';
      document.cookie = 'theme_preference=' + serialized;
      document.cookie = 'landing_theme_mode=' + serialized;
    } catch (_) {}
  }

  function readThemeCookie(){
    try {
      var cookies = document.cookie || '';
      var match = cookies.match(/(?:^|;\s*)theme_preference=([^;]+)/);
      if (match && match[1]) {
        var primary = decodeURIComponent(match[1]);
        if (primary === 'dark' || primary === 'light') { return primary; }
        if (primary === 'auto') { return 'auto'; }
      }
      match = cookies.match(/(?:^|;\s*)landing_theme_mode=([^;]+)/);
      if (match && match[1]) {
        var legacy = decodeURIComponent(match[1]);
        if (legacy === 'dark' || legacy === 'light') { return legacy; }
        if (legacy === 'auto') { return 'auto'; }
      }
    } catch (_) {}
    return null;
  }

  function applyThemeMode(mode, ctx){
    var html = document.documentElement;
    var body = document.body;
    var next = mode === 'dark' ? 'dark' : 'light';
    if (html) {
      html.setAttribute('data-theme', next);
      html.classList.remove('theme-dark', 'theme-light');
      html.classList.add(next === 'dark' ? 'theme-dark' : 'theme-light');
    }
    if (body) {
      body.setAttribute('data-theme', next);
      body.classList.remove('theme-dark', 'theme-light');
      body.classList.add(next === 'dark' ? 'theme-dark' : 'theme-light');
    }
    if (ctx && ctx.toggle) {
      ctx.toggle.dataset.mode = next;
      ctx.toggle.textContent = next === 'dark' ? ctx.iconLight : ctx.iconDark;
      ctx.toggle.setAttribute('aria-label', next === 'dark' ? ctx.labelLight : ctx.labelDark);
    }
    if (ctx && ctx.storageKey) {
      try { localStorage.setItem(ctx.storageKey, next); } catch (_) {}
    }
    writeThemeCookie(next);
    syncMarkerColors(next);
  }

  function detectInitialTheme(ctx){
    var cookiePref = readThemeCookie();
    if (cookiePref === 'dark' || cookiePref === 'light') {
      return cookiePref;
    }
    try {
      var stored = localStorage.getItem(ctx.storageKey);
      if (stored === 'dark' || stored === 'light') { return stored; }
    } catch (_) {}
    var html = document.documentElement;
    var body = document.body;
    var attr = (html && html.getAttribute('data-theme')) || (body && body.getAttribute('data-theme')) || '';
    if (attr === 'dark' || attr === 'light') { return attr; }
    if ((html && html.classList.contains('theme-dark')) || (body && body.classList.contains('theme-dark'))) { return 'dark'; }
    if ((html && html.classList.contains('theme-light')) || (body && body.classList.contains('theme-light'))) { return 'light'; }
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) { return 'dark'; }
    return 'light';
  }

  function initThemeToggle(){
    var toggle = document.querySelector('[data-theme-toggle]');
    if (!toggle) { return; }
    var ctx = {
      toggle: toggle,
      storageKey: toggle.getAttribute('data-storage-key') || 'landing_theme_mode',
      labelLight: toggle.getAttribute('data-label-light') || 'Switch to light mode',
      labelDark: toggle.getAttribute('data-label-dark') || 'Switch to dark mode',
      iconLight: toggle.getAttribute('data-icon-light') || '☀️',
      iconDark: toggle.getAttribute('data-icon-dark') || '🌙'
    };
    var initial = detectInitialTheme(ctx);
    applyThemeMode(initial, ctx);
    toggle.addEventListener('click', function(){
      var next = toggle.dataset.mode === 'dark' ? 'light' : 'dark';
      applyThemeMode(next, ctx);
    });
  }

  function initMenuUnderline(){
    var links = document.querySelectorAll('.container-nav nav .menu-item[href^="#"]');
    if (!links.length) { return; }
    links.forEach(function(link){
      var href = link.getAttribute('href') || '';
      if (!href || href.length < 2 || href.charAt(0) !== '#') { return; }
      var targetId = href.slice(1);
      if (!targetId) { return; }
      var target = document.getElementById(targetId);
      if (!target) { return; }
      var color = null;
      if (target.hasAttribute('data-ma_color')) {
        color = target.getAttribute('data-ma_color');
      } else if (target.hasAttribute('data_ma_color')) {
        color = target.getAttribute('data_ma_color');
      }
      if (!color) {
        var marker = target.querySelector('[data-ma_color], [data_ma_color]');
        if (marker) {
          color = marker.getAttribute('data-ma_color') || marker.getAttribute('data_ma_color');
        }
      }
      if (!color) { return; }
      link.style.setProperty('--menu-underline-color', color);
    });
  }

  function initResponsiveNav(){
    var toggles = document.querySelectorAll('[data-nav-toggle]');
    if (!toggles.length) { return; }
    var mediaQuery = typeof window.matchMedia === 'function'
      ? window.matchMedia('(max-width: 1024px)')
      : { matches: false };
    toggles.forEach(function(toggle){
      var header = toggle.closest('.main-header');
      if (!header) { return; }
      var panel = header.querySelector('[data-nav-panel]');
      if (!panel) { return; }
      var controlledId = toggle.getAttribute('aria-controls') || '';
      var controlled = controlledId ? document.getElementById(controlledId) : null;
      var expanded = false;

      function setHiddenState(hidden){
        if (hidden) {
          panel.setAttribute('aria-hidden', 'true');
          if (controlled) { controlled.setAttribute('aria-hidden', 'true'); }
        } else {
          panel.removeAttribute('aria-hidden');
          if (controlled) { controlled.removeAttribute('aria-hidden'); }
        }
      }

      function syncBodyLock(lock){
        var body = document.body;
        if (!body) { return; }
        if (!mediaQuery.matches || !lock) {
          body.classList.remove('nav-locked');
        } else {
          body.classList.add('nav-locked');
        }
      }

      function applyState(force){
        var next = typeof force === 'boolean' ? force : !expanded;
        expanded = next;
        toggle.setAttribute('aria-expanded', next ? 'true' : 'false');
        header.classList.toggle('menu-open', next);
        if (mediaQuery.matches) {
          setHiddenState(!next);
        } else {
          setHiddenState(false);
        }
        syncBodyLock(next);
      }

      toggle.addEventListener('click', function(){
        applyState();
      });

      panel.addEventListener('click', function(evt){
        var anchor = evt.target.closest('a');
        if (anchor) {
          applyState(false);
        }
      });

      var handleEscape = function(evt){
        if (evt.key === 'Escape') {
          applyState(false);
        }
      };

      var handleDocumentClick = function(evt){
        if (!expanded || !mediaQuery.matches) { return; }
        if (toggle.contains(evt.target) || panel.contains(evt.target)) { return; }
        applyState(false);
      };

      document.addEventListener('keyup', handleEscape);
      document.addEventListener('click', handleDocumentClick);

      var handleChange = function(e){
        if (!e.matches) {
          setHiddenState(false);
          toggle.setAttribute('aria-expanded', 'false');
          header.classList.remove('menu-open');
          expanded = false;
          syncBodyLock(false);
        } else {
          setHiddenState(!expanded);
        }
      };

      if (typeof mediaQuery.addEventListener === 'function') {
        mediaQuery.addEventListener('change', handleChange);
      } else if (typeof mediaQuery.addListener === 'function') {
        mediaQuery.addListener(handleChange);
      }

      handleChange(mediaQuery);
    });
  }
})();
