(function ($) {
  "use strict";
  var buildUrl = (window.DZ && window.DZ.buildUrl) || function(path){
    try { var base=(typeof window.site_url==='string'&&window.site_url)?window.site_url:(window.location.origin+window.location.pathname.replace(/[^\/]*$/,'')); if(base.slice(-1)!=='/') base+='/'; return new URL(String(path||'').replace(/^\//,''), base).toString(); } catch(_) { return String(path||''); }
  };
  // Lightweight, CSP-safe HTML injector that also loads any external <script src> tags
  function injectHTMLWithScriptsInto(targetEl, html){
    try {
      var el = (targetEl && targetEl.nodeType === 1) ? targetEl : ($(targetEl).get(0) || null);
      if (!el) return Promise.resolve();
      var tmp = document.createElement('div');
      tmp.innerHTML = String(html || '');
      var scripts = tmp.querySelectorAll('script');
      var urls = [];
      for (var i=0;i<scripts.length;i++){
        var sc = scripts[i];
        var src = sc.getAttribute('src');
        if (src) {
          try { if (!/^(?:https?:)?\//i.test(src)) { src = buildUrl(src.replace(/^\/+/, '')); } } catch(_){ }
          urls.push(src);
        }
        if (sc.parentNode) sc.parentNode.removeChild(sc);
      }
      el.innerHTML = '';
      while (tmp.firstChild) { el.appendChild(tmp.firstChild); }
      // Load external scripts sequentially, skipping ones already present
      var p = Promise.resolve();
      urls.forEach(function(u){
        p = p.then(function(){
          return new Promise(function(resolve){
            try {
              var exists = document.querySelector('script[src="' + u.replace(/"/g, '\\"') + '"]');
              if (exists) { resolve(); return; }
              var s = document.createElement('script');
              s.src = u; s.defer = true; s.async = false;
              s.onload = function(){ resolve(); };
              s.onerror = function(){ console.warn('Failed to load script:', u); resolve(); };
              (document.head || document.body || document.documentElement).appendChild(s);
            } catch (e) { console.warn('Script load error:', u, e); resolve(); }
          });
        });
      });
      return p;
    } catch (e) {
      try { var el2 = (targetEl && targetEl.nodeType === 1) ? targetEl : ($(targetEl).get(0) || null); if (el2) el2.innerHTML = String(html || ''); } catch(_){}
      return Promise.resolve();
    }
  }
    window.DZ = window.DZ || {};
    var I18N = (window.DZ && typeof DZ.i18n === 'function') ? DZ.i18n : function(){ return ''; };
    /**
     * Dear customer,
     * This script will automatically initialize Swiper sliders for each post in your feed.
     * It works on initial page load and also when new posts are loaded via infinite scroll or AJAX.
     * You can adjust Swiper settings here if you want to customize the behavior.
     */

    var SWIPER_SELECTOR = ".post_ .post-body .post-media-swiper";
    var SELECTOR = '.textarea textarea , .chat_area textarea, textarea.write-comment';
    var IS_RTL_LOCALE = (document.documentElement && String(document.documentElement.dir || '').toLowerCase() === 'rtl');
    try {
        window.__IS_RTL_LOCALE__ = IS_RTL_LOCALE;
    } catch (_) {}
    /**
     * Initialize Swiper for a single container.
     * This runs only once per container to prevent duplicate sliders.
     */
    function initOne(container) {
        if (
            !container ||
            $(container).data("swiperInited") === 1 ||
            (container.classList && container.classList.contains("swiper-initialized"))
        ) {
            return; // Already initialized or invalid
        }

        if (window.DZ_DEBUG) { console.log('Initializing Swiper:', container); }
        if (typeof Swiper !== 'function') {
            setTimeout(function () { initOne(container); }, 150);
            return;
        }

        var slidesCount = $(container).find(".swiper-slide").length;
        var enableControls = slidesCount > 1;
        var paginationEl = $(container).find(".swiper-pagination").get(0);

        // Navigation elements (optional; only used if present and there are multiple slides)
        var nextEl = $(container).find(".swiper-button-next").get(0);
        var prevEl = $(container).find(".swiper-button-prev").get(0);

        if (IS_RTL_LOCALE) {
            container.setAttribute('dir', 'rtl');
        }

        // Create Swiper instance
        var swiper = new Swiper(container, {
            slidesPerView: 1,
            spaceBetween: 8,
            loop: false,
            rtl: IS_RTL_LOCALE,
            rtlTranslate: IS_RTL_LOCALE,
            allowTouchMove: enableControls,
            watchSlidesProgress: true,
            speed: 400,
            observer: true,
            observeParents: true,
            resizeObserver: true,
            pagination: (enableControls && paginationEl)
                ? {
                    el: paginationEl,
                    clickable: true,
                    dynamicBullets: true
                }
                : false,
            navigation: (enableControls && nextEl && prevEl)
                ? {
                    nextEl: nextEl,
                    prevEl: prevEl
                }
                : false,
            on: {
                init: function (sw) { sw.update(); },
                imagesReady: function (sw) { sw.update(); }
            }
        });
        // Optionally store instance for later access
        $(container).data("swiperInstance", swiper);

        // Mark as initialized
        $(container).data("swiperInited", 1);

        // Hide pagination/nav if there is only one slide
        if (!enableControls) {
            if (paginationEl) { $(paginationEl).hide(); }
            if (nextEl) { $(nextEl).hide(); }
            if (prevEl) { $(prevEl).hide(); }
        } else {
            if (paginationEl) { $(paginationEl).show(); }
            if (nextEl) { $(nextEl).show(); }
            if (prevEl) { $(prevEl).show(); }
        }
    }

    /**
     * Initialize all sliders inside a given root element.
     * If the root itself is a Swiper container, initialize it as well.
     */
    function initAll(root) {
        root = root || document;
        var $root = $(root);
        var $nodes = $root.is(SWIPER_SELECTOR) ? $root : $root.find(SWIPER_SELECTOR);
        $nodes.each(function () {
            initOne(this);
        });
    }

    // 1) Initial page load
  $(document).ready(function () {
    initAll();
    try { initProfileTabsArrows(); } catch(_){}
  });

    /**
     * 2) Automatic initialization when new posts are added (Infinite scroll, AJAX)
     */
    var mo = new MutationObserver(function (mutations) {
        mutations.forEach(function (m) {
            if (!m.addedNodes) return;
            m.addedNodes.forEach(function (node) {
                if (!(node instanceof HTMLElement)) return;

                // Initialize Swiper blocks added anywhere in DOM
                if ($(node).is(SWIPER_SELECTOR)) {
                    initOne(node);
                } else {
                    $(node).find(SWIPER_SELECTOR).each(function () {
                        initOne(this);
                    });
                }

                // Also initialize any newly added videos (progress/duration, IO autoplay)
                // Safe to call multiple times; DZ.initPostVideos guards against duplicates.
                try {
                  if (window.DZ && typeof window.DZ.initPostVideos === 'function') {
                    // Only touch scopes that actually include a video wrapper to avoid extra work
                    if ($(node).is('.video-wrapper, .video-wrapper *') || $(node).find('.video-wrapper').length) {
                      window.DZ.initPostVideos(node);
                    }
                  }
                } catch (_) { /* no-op */ }
            });
        });
    });

    if (document.body) {
    mo.observe(document.body, { childList: true, subtree: true });
  }

  // --- Mobile horizontal scroll for profile tabs with arrow helpers ---
  function initProfileTabsArrows(){
    var wrap = document.querySelector('.profile-tabs-scroll');
    if (!wrap) return;
    var viewport = wrap.querySelector('.tabs-viewport');
    var leftBtn = wrap.querySelector('.tabs-arrow--left');
    var rightBtn= wrap.querySelector('.tabs-arrow--right');
    if (!viewport || !leftBtn || !rightBtn) return;

    function hasOverflow(){
      try { return (viewport.scrollWidth - viewport.clientWidth) > 0; } catch(_) { return false; }
    }
    function updateArrows(){
      var overflow = hasOverflow();
      var maxScroll = Math.max(0, viewport.scrollWidth - viewport.clientWidth);
      var x = viewport.scrollLeft;
      // Even if no overflow, keep arrows as subtle hints (is-hidden -> low opacity + no clicks)
      if (!overflow) {
        leftBtn.classList.add('is-hidden');
        rightBtn.classList.add('is-hidden');
        wrap.classList.remove('can-left');
        wrap.classList.remove('can-right');
        return;
      }
      var atStart = (x <= 1);
      var atEnd   = (x >= maxScroll - 1);
      if (atStart) { leftBtn.classList.add('is-hidden'); } else { leftBtn.classList.remove('is-hidden'); }
      if (atEnd)   { rightBtn.classList.add('is-hidden'); } else { rightBtn.classList.remove('is-hidden'); }
      wrap.classList.toggle('can-left', !atStart);
      wrap.classList.toggle('can-right', !atEnd);
    }
    function scrollByAmount(dir){
      // Prefer snapping to the next/prev partially hidden tab for predictable motion
      try {
        var tabs = viewport.querySelectorAll('.profile-tab');
        var cl = viewport.clientLeft || 0; // mostly 0, but be robust
        var cw = viewport.clientWidth;
        var sl = viewport.scrollLeft;
        var rightEdge = sl + cw;
        var target = null;
        if (dir > 0) {
          for (var i = 0; i < tabs.length; i++) {
            var el = tabs[i];
            var elL = el.offsetLeft;
            var elR = elL + el.offsetWidth;
            if (elR > rightEdge + 2) { target = Math.max(0, elL - 8); break; }
          }
          if (target === null) {
            var maxScroll = Math.max(0, viewport.scrollWidth - cw);
            target = maxScroll;
          }
        } else {
          for (var j = tabs.length - 1; j >= 0; j--) {
            var el2 = tabs[j];
            var eL  = el2.offsetLeft;
            if (eL < sl - 2) { target = Math.max(0, eL - 8); break; }
          }
          if (target === null) { target = 0; }
        }
        var maxS = Math.max(0, viewport.scrollWidth - cw);
        if (target < 0) target = 0; if (target > maxS) target = maxS;
        viewport.scrollTo({ left: target, behavior: 'smooth' });
      } catch(_) {
        // Fallback: bounded relative scroll (~60% viewport)
        var amt = Math.round(viewport.clientWidth * 0.6);
        var aim = viewport.scrollLeft + dir * amt;
        var maxS2 = Math.max(0, viewport.scrollWidth - viewport.clientWidth);
        if (aim < 0) aim = 0; if (aim > maxS2) aim = maxS2;
        viewport.scrollTo({ left: aim, behavior: 'smooth' });
      }
    }
    leftBtn.addEventListener('click', function(e){ e.preventDefault(); scrollByAmount(-1); });
    rightBtn.addEventListener('click', function(e){ e.preventDefault(); scrollByAmount(1); });
    viewport.addEventListener('scroll', updateArrows, { passive: true });
    window.addEventListener('resize', updateArrows);
    // Watch size/content changes to keep arrows in sync
    try {
      var mo = new MutationObserver(function(){ updateArrows(); });
      mo.observe(viewport, { childList: true, subtree: true });
    } catch(_){}
    // Initial state (guard for late font/layout loads)
    [0, 80, 150, 300, 600, 1200, 2000].forEach(function(t){ setTimeout(updateArrows, t); });
    if (document.fonts && typeof document.fonts.ready === 'object') {
      try { document.fonts.ready.then(updateArrows); } catch(_){}
    }
    window.addEventListener('load', updateArrows, { once: true });
    window.addEventListener('orientationchange', function(){ setTimeout(updateArrows, 60); }, { passive: true });
  }

    // Public API: initialize swipers inside a specific root (single source of truth)
    if (typeof window !== "undefined") {
        window.DZ = window.DZ || {};
        window.DZ.initPostSwipers = function (root) {
            initAll(root || document);
        };
    }

    /**
     * 3) Manual trigger for custom infinite scroll scripts
     * Example:
     * $(document).trigger("posts:loaded", { root: containerElement });
     */
  $(document).on("posts:loaded", function (e, data) {
        var root = (data && data.root) ? data.root : document;
        initAll(root);
    });

    $(document).on('post:created', function (e, payload) {
        var rootEl = null;
        if (payload && payload.html) {
            if (payload.html instanceof $) {
                rootEl = payload.html.get(0);
            } else if (payload.html.nodeType === 1) {
                rootEl = payload.html;
            }
        }
        if (!rootEl && payload && payload.root) {
            rootEl = payload.root;
        }
        if (!rootEl && payload && payload.response && payload.response.post_id) {
            var candidate = document.getElementById('post-' + String(payload.response.post_id));
            if (candidate) {
                rootEl = candidate;
            }
        }
        if (!rootEl) {
            rootEl = document.getElementById('posts');
        }
        if (!rootEl) {
            return;
        }
        try {
            if (window.DZ && typeof window.DZ.initPostSwipers === 'function') {
                window.DZ.initPostSwipers(rootEl);
            } else {
                $(document).trigger('posts:loaded', { root: rootEl });
            }
        } catch (err) {
            console.warn('post:created Swiper init failed', err);
            $(document).trigger('posts:loaded', { root: rootEl });
        }
        // Fallback: always ensure direct init within the root
        initAll(rootEl);
        try {
            if (window.DZ && typeof window.DZ.initPostVideos === 'function') {
                window.DZ.initPostVideos(rootEl);
            }
        } catch (err2) {
            console.warn('post:created video init failed', err2);
        }
    });

    /**
   * Dear customer:
   * This function appends a chunk of post HTML into a target container
   * and initializes Swiper only inside that newly added area.
   * Use it from any AJAX success handler across your project.
   *
   * @param {Object} opts
   * @param {string|HTMLElement|jQuery} opts.html - The HTML to append (string or node)
   * @param {string|HTMLElement|jQuery} [opts.target="#posts"] - The container to append into
   */
  window.DZ = window.DZ || {};
  window.DZ.mountPosts = function mountPosts(opts) {
    if (!opts || !opts.html) { console.warn("DZ.mountPosts: no html provided."); return; }

    var $target = $(opts.target || "#posts");
    if (!$target.length) { console.warn("DZ.mountPosts: target not found."); return; }

    var $chunk = (opts.html instanceof $) ? opts.html
               : (opts.html.nodeType ? $(opts.html)
               : $(String(opts.html)));

    // Append and init only inside this chunk
    if (opts.prepend === true) {
      var firstPost = $target.find('.post_').first();
      if (firstPost.length) {
        $chunk.insertBefore(firstPost);
      } else {
        $target.prepend($chunk);
      }
    } else {
      $target.append($chunk);
    }

    var rootEl = $chunk.get(0) || $target.get(0);

    try {
      requestAnimationFrame(function () {
        if (window.DZ && typeof window.DZ.initPostSwipers === "function") {
          window.DZ.initPostSwipers(rootEl);
        } else {
          $(document).trigger("posts:loaded", { root: rootEl });
        }
        // Ensure video controls are also initialized for newly added posts
        if (typeof window.DZ !== 'undefined' && typeof window.DZ.initPostVideos === 'function') {
          DZ.initPostVideos(rootEl);
        } else {
          $(document).trigger('posts:loaded', { root: rootEl });
        }
      });
    } catch (e) {
      if (window.DZ && typeof window.DZ.initPostSwipers === "function") {
        window.DZ.initPostSwipers(rootEl);
      } else {
        $(document).trigger("posts:loaded", { root: rootEl });
      }
    }
  };

  // Measure & apply height
  function autoGrow(el) {
    var $el = $(el);

    // Optional override: <textarea data-max-height="240">
    var dataMax = parseInt($el.attr('data-max-height'), 10);
    var cssMax  = parseInt($el.css('max-height'), 10);
    var MAX     = (Number.isFinite(dataMax) ? dataMax :
                  (Number.isFinite(cssMax)  ? cssMax  : 200));
    var dataMin = parseInt($el.attr('data-min-height'), 10);
    var cssMin  = parseInt($el.css('min-height'), 10);
    var MIN     = (Number.isFinite(dataMin) ? dataMin :
                  (Number.isFinite(cssMin)  ? cssMin  : 0));
    var borderBox = $el.css('box-sizing') === 'border-box';
    var borderY = borderBox
      ? ((parseFloat($el.css('border-top-width')) || 0) + (parseFloat($el.css('border-bottom-width')) || 0))
      : 0;

    // Reset to auto first so scrollHeight is accurate
    el.style.height = 'auto';

    var need = Math.max(MIN, el.scrollHeight + borderY); // scrollHeight includes padding
    if (need <= MAX) {
      el.style.height = need + 'px';
      el.style.overflowY = 'hidden';
    } else {
      el.style.height = MAX + 'px';
      el.style.overflowY = 'auto';
    }
  }

  // Delegate to document so dynamically added areas also work
  $(document).on('input keyup change', SELECTOR, function () {
    var el = this;

    // rAF: coalesce rapid input for smoother resize
    if (el._rafId) {
      cancelAnimationFrame(el._rafId);
    }
    el._rafId = requestAnimationFrame(function () {
      autoGrow(el);
    });
  });

  // Resize on focus (helps prefilled values)
  $(document).on('focus', SELECTOR, function () {
    autoGrow(this);
  });

  // Initial pass for any prefilled textareas
  $(function () {
    $(SELECTOR).each(function () { autoGrow(this); });
  });

  /**
   * Emoji insertion for comment composer
   * - Delegated click on .make-comment-emoji-list .emoji
   * - Inserts at caret position inside the nearest textarea[name="post-text"]
   * - Works whether the user already typed text or starts with an emoji
   * - Keeps focus and selection; triggers autoGrow via input event
   */
  (function setupEmojiInsertion() {
    var TEXTAREA_SELECTOR = 'textarea[name="post-text"]';
    var LAST_TA = null; // remember last focused textarea in the UI

    // Track last focused post text area
    $(document).on('focus', TEXTAREA_SELECTOR, function () {
      LAST_TA = this;
    });

    function insertAtCursor(el, text) {
      if (!el) { return; }
      var value = el.value || '';
      var start = (typeof el.selectionStart === 'number') ? el.selectionStart : value.length;
      var end   = (typeof el.selectionEnd   === 'number') ? el.selectionEnd   : value.length;
      var scrollTop = el.scrollTop;

      // Compose new value
      var before = value.slice(0, start);
      var after  = value.slice(end);
      el.value = before + text + after;

      // Restore caret just after the inserted emoji
      var caret = start + text.length;
      if (el.setSelectionRange) {
        el.setSelectionRange(caret, caret);
      }
      // Restore scroll position (for long texts)
      el.scrollTop = scrollTop;

      // Focus and trigger events so autoGrow kicks in
      el.focus();
      // Fire input event for listeners (autoGrow uses this)
      try {
        var evt = new Event('input', { bubbles: true });
        el.dispatchEvent(evt);
      } catch (e) {
        // Fallback for older browsers
        $(el).trigger('input');
      }
    }

    // Delegated click handler for emoji buttons
    $(document).on('click', '.make-comment-emoji-list .emoji', function (e) {
      e.preventDefault();
      // chat.js handles the live chat when it is available. Keep this path as
      // a fallback for dynamically injected chat markup whose script has not
      // finished loading yet.
      var $chatArea = $(this).closest('.chat_input_area');
      if ($chatArea.length && window.__cpChatEmojiPickerBound) { return; }
      var emoji = $(this).text();

      // A chat emoji must always be inserted into the chat composer. Do this
      // before the feed's last-focused textarea fallback.
      var target = null;
      if ($chatArea.length) {
        var $chatTextarea = $chatArea.find('textarea[name="post-text"]').first();
        if ($chatTextarea.length) { target = $chatTextarea.get(0); }
      }

      // Prefer the last focused textarea if still in DOM and visible.
      if (!target && LAST_TA && document.body.contains(LAST_TA)) {
        target = LAST_TA;
      }

      if (!target) {
        // Try to find the nearest textarea within the current make-comment area
        var $area = $(this).closest('.make-comment-area, .make-comment');
        var $ta = $area.find(TEXTAREA_SELECTOR).first();
        if ($ta.length) { target = $ta.get(0); }
      }

      if (!target) {
        // As a final fallback, use the first matching textarea on the page
        var $fallback = $(TEXTAREA_SELECTOR).first();
        if ($fallback.length) { target = $fallback.get(0); }
      }

      if (target) {
        insertAtCursor(target, emoji);
      }
    });
  })();

  // Toggle emoji list per post: append on first click, remove on second click
  // Envato note: This handler is fully delegated and safe for dynamically added posts.
  $(document).on('click', '.get_emojis', function (e) {
    e.preventDefault();

    var $btn = $(this);
    var $chatArea = $btn.closest('.chat_input_area');
    // The chat controller owns its picker when it is ready. This delegated
    // handler remains a safe fallback during the short dynamic-load window.
    if ($chatArea.length && window.__cpChatEmojiPickerBound) { return; }
    var ID = $btn.data('id');
    var $composer = $btn.closest('.make-comment');
    var $wrapper = $chatArea.length
      ? $chatArea.find('.make-emoji-wrapper.get_emojis_' + ID).first()
      : $composer.find('.make-emoji-wrapper.get_emojis_' + ID).first();
    if (!$wrapper.length) {
      $wrapper = $('.make-emoji-wrapper.get_emojis_' + ID).first();
    }
    if (!$wrapper.length) { return; }

    // If the list already exists for this post, remove it (toggle behavior)
    var $existing = $wrapper.find('.make-comment-emoji-list').first();
    if ($existing.length) {
      $existing.remove();
      return; // Stop here; no network request needed
    }

    // Optionally close any other open emoji lists in the feed to keep UI clean
    $('.make-emoji-wrapper .make-comment-emoji-list').not($existing).remove();

    // Fetch and append the emoji list
    var csrfToken = $('input[name="csrf_token"]').val();
    var type = 'getEmojiList';

    // Prevent duplicate requests while loading
    if ($btn.data('loading') === 1) { return; }
    $btn.data('loading', 1).addClass('is-loading');

    $.ajax({
      type: 'POST',
      url: buildUrl('request/requests.php'),
      data: {
        p: type,
        csrf_token: csrfToken
      },
      dataType: 'json',
      success: function (response) {
        if (response && response.status === 'success' && response.html) {
          // Ensure we didn't open and immediately close before response
          // (i.e., user clicked again). If a list now exists, do not append.
          if (!$wrapper.find('.make-comment-emoji-list').length) {
            $wrapper.append(response.html);
          }
        }
      },
      complete: function () {
        $btn.data('loading', 0).removeClass('is-loading');
      }
    });
  });

  // Close any open emoji lists when clicking outside of them
  // Notes for Envato Review:
  // - We avoid closing when the click is inside `.make-comment-emoji-list` (the emoji panel)
  // - We also avoid closing when the click is on `.get_emojis` button itself (handled by its own toggle)
  $(document).on('click', function (e) {
    var $t = $(e.target);
    // If the click is inside emoji list, do nothing
    if ($t.closest('.make-comment-emoji-list').length) { return; }
    // If the click is on the toggle button, let the other handler take over
    if ($t.closest('.get_emojis').length) { return; }
    // Otherwise, close all open emoji lists
    $('.make-emoji-wrapper .make-comment-emoji-list').remove();
  });

  /**
   * Comment composer toggle per post
   *
   * Requirements:
   * - Clicking `.p_comment` toggles corresponding `.p_comment_{id}` panel inside the SAME `.post_`.
   * - Clicking on the dim/overlay area of `.make-comment` closes it.
   * - Clicking inside `.make-comment-area` (or its children) must NOT close it.
   * - Works for dynamically injected posts (delegated handlers).
   * - Adds basic ARIA attributes for accessibility.
   */

  (function setupCommentToggle() {
    function animateOpen($el) {
      if (!$el || !$el.length) { return; }
      $el.stop(true, true)
        .removeClass('none is-closing animate__fadeIn animate__fadeOut animate__slideInUp animate__slideOutDown')
        .attr('aria-hidden', 'false')
        .addClass('is-open')
        .css('display', 'block');
      $el.find('.make-comment-area').first()
        .removeClass('animate__fadeIn animate__fadeOut animate__slideInUp animate__slideOutDown');
    }

    function animateClose($el) {
      if (!$el || !$el.length) { return; }
      $el.stop(true, true)
        .removeClass('is-open is-closing animate__fadeIn animate__fadeOut animate__slideInUp animate__slideOutDown')
        .attr('aria-hidden', 'true')
        .addClass('none')
        .hide();
      $el.find('.make-comment-area').first()
        .removeClass('animate__fadeIn animate__fadeOut animate__slideInUp animate__slideOutDown');
    }

    // --- Public API & Event Hook: close comment composer from anywhere ---
    // Allows external scripts (e.g., post.js) to close a comment panel with animation.
    // Usage examples:
    //   DZ.closeCommentPanel($button, postId);
    //   $(document).trigger('comment:close', { origin: $button, postId: 123 });
    window.DZ = window.DZ || {};
    if (typeof DZ.closeCommentPanel !== 'function') {
      DZ.closeCommentPanel = function (originOrRoot, id) {
        var $ctx  = originOrRoot ? $(originOrRoot) : $(document);
        var $post = $ctx.closest('.post_');
        // If context is not inside a specific post, try to resolve by id
        if (!$post.length) {
          if (id) {
            $post = $('.post_').has('.p_comment_' + id).first();
          }
        }
        // As a final fallback, use the first visible panel in the DOM
        if (!$post.length) { $post = $('.post_').first(); }

        var $panel = id
          ? $post.find('.p_comment_' + id).first()
          : $post.find('.make-comment:visible').first();

        if ($panel.length) {
          animateClose($panel);
          // Keep ARIA in sync for its toggle button (if any)
          if (id) {
            $post.find('.p_comment[data-id="' + id + '"]').attr('aria-expanded', 'false');
          } else {
            $post.find('.p_comment[aria-expanded="true"]').attr('aria-expanded', 'false');
          }
        }
      };
    }

    // Optional event-based API for looser coupling
    // Example: $(document).trigger('comment:close', { origin: $btn, postId: 123 });
    $(document).on('comment:close', function (e, payload) {
      var origin = payload && (payload.origin || payload.root || null);
      var id     = payload && (payload.postId || payload.id || null);
      if (window.DZ && typeof DZ.closeCommentPanel === 'function') {
        DZ.closeCommentPanel(origin, id);
      }
    });

    /**
     * Instagram-style video toggle
     * - Click once: pause video and show play icon
     * - Click again: resume video and hide play icon
     * - Click on speaker icon (if added): unmute only that video
     * - Works for dynamically added videos (infinite scroll)
     */
    // Video initialization logic moved to DZ.initPostVideos
    // See below for DZ.initPostVideos definition and usage
    /**
     * Reusable function to initialize all post videos and their controls.
     * Can be called on initial page load and after new posts are appended.
     */
    window.DZ = window.DZ || {};
    if (typeof DZ.initPostVideos !== "function") {
      DZ.initPostVideos = (function () {
        // IntersectionObserver instance (singleton)
        var observer = null;
        var LONGFORM_SECONDS = 60;
        function isStandardWrapper($wrapper) {
          if (!$wrapper || !$wrapper.length) { return false; }
          var mode = String($wrapper.attr('data-video-mode') || '').toLowerCase();
          return mode === 'standard' || $wrapper.hasClass('video-wrapper--standard');
        }
        function isStandardByMeta(video) {
          var width = Number(video.videoWidth || 0);
          var height = Number(video.videoHeight || 0);
          var duration = Number(video.duration || 0);
          var isLandscape = width > 0 && height > 0 && width >= height;
          var isLong = duration > 0 && duration >= LONGFORM_SECONDS;
          return isLandscape || isLong;
        }
        function isSafariBrowser() {
          var ua = navigator.userAgent || '';
          return /safari/i.test(ua) && !/chrome|chromium|android/i.test(ua);
        }
        function getVideoFrameInfo(video) {
          if (typeof video.getVideoPlaybackQuality === 'function') {
            var quality = video.getVideoPlaybackQuality();
            return { count: Number(quality.totalVideoFrames || 0), supported: true };
          }
          if (typeof video.webkitDecodedFrameCount !== 'undefined') {
            return { count: Number(video.webkitDecodedFrameCount || 0), supported: true };
          }
          if (typeof video.mozDecodedFrames !== 'undefined') {
            return { count: Number(video.mozDecodedFrames || 0), supported: true };
          }
          return { count: 0, supported: false };
        }
        function applyPlaybackRate(video, speed) {
          var nextSpeed = isFinite(speed) && speed > 0 ? speed : 1;
          var preservePitch = nextSpeed === 1;
          if (typeof video.preservesPitch !== 'undefined') {
            video.preservesPitch = preservePitch;
          }
          if (typeof video.mozPreservesPitch !== 'undefined') {
            video.mozPreservesPitch = preservePitch;
          }
          if (typeof video.webkitPreservesPitch !== 'undefined') {
            video.webkitPreservesPitch = preservePitch;
          }
          if (typeof video.msPreservesPitch !== 'undefined') {
            video.msPreservesPitch = preservePitch;
          }
          video.playbackRate = nextSpeed;
          if (typeof video.defaultPlaybackRate !== 'undefined') {
            video.defaultPlaybackRate = nextSpeed;
          }
        }
        function guardHighSpeedPlayback(video, $control) {
          var $video = $(video);
          if ($video.data('speedGuard')) { return; }
          var supportsFrameCheck = false;
          var frameInfo = getVideoFrameInfo(video);
          var startFrames = frameInfo.count;
          supportsFrameCheck = frameInfo.supported || typeof video.requestVideoFrameCallback === 'function';
          if (!supportsFrameCheck) { return; }
          $video.data('speedGuard', 1);
          var startTime = Number(video.currentTime || 0);
          var frameRendered = false;
          if (typeof video.requestVideoFrameCallback === 'function') {
            video.requestVideoFrameCallback(function () {
              frameRendered = true;
            });
          }
          setTimeout(function () {
            $video.data('speedGuard', 0);
            if (video.paused || video.ended) { return; }
            var timeAdvanced = Number(video.currentTime || 0) - startTime;
            var latestInfo = getVideoFrameInfo(video);
            var framesAdvanced = latestInfo.count - startFrames;
            var noFrameSignal = (latestInfo.supported && framesAdvanced <= 0)
              || (typeof video.requestVideoFrameCallback === 'function' && !frameRendered);
            if (timeAdvanced > 0.2 && noFrameSignal) {
              applyPlaybackRate(video, 2);
              var $fallback = $control.find('.video-speed-option[data-speed="2"]').first();
              if ($fallback.length) {
                updateSpeedMenu($control, $fallback);
              }
              if (!$video.data('speedFallbackWarned')) {
                if (typeof ensureDzToast === 'function') { ensureDzToast(); }
                if (window.DZ && typeof DZ.toast === 'function') {
                  var warnMsg = (typeof I18N === 'function')
                    ? (I18N('video_speed_fallback') || '2.5x is not supported here. Switched to 2x.')
                    : '2.5x is not supported here. Switched to 2x.';
                  DZ.toast(warnMsg, { type: 'info', duration: 2600 });
                }
                $video.data('speedFallbackWarned', 1);
              }
            }
          }, 700);
        }
        function formatVideoTime(seconds) {
          if (!isFinite(seconds) || seconds < 0) { return '0:00'; }
          var total = Math.floor(seconds);
          var hours = Math.floor(total / 3600);
          var minutes = Math.floor((total % 3600) / 60);
          var secs = total % 60;
          if (hours > 0) {
            return hours + ':' + (minutes < 10 ? '0' + minutes : minutes) + ':' + (secs < 10 ? '0' + secs : secs);
          }
          return minutes + ':' + (secs < 10 ? '0' + secs : secs);
        }
        function updateSpeedMenu($control, $option) {
          if (!$control || !$control.length || !$option || !$option.length) { return; }
          var label = String($option.data('speedLabel') || '').trim();
          if (!label) { label = $.trim($option.text()); }
          $control.find('.video-speed-option').removeClass('is-active').attr('aria-checked', 'false');
          $option.addClass('is-active').attr('aria-checked', 'true');
          $control.find('.video-speed-toggle-text').text(label);
        }
        function setupSpeedMenu(video) {
          var $video = $(video);
          var $wrapper = $video.closest('.video-wrapper');
          if (!$wrapper.length) { return; }
          var $control = $wrapper.find('.video-speed-control').first();
          if (!$control.length || $control.data('speedInit')) { return; }
          var $defaultOption = $control.find('.video-speed-option[data-speed="1"]').first();
          if (!$defaultOption.length) {
            $defaultOption = $control.find('.video-speed-option').first();
          }
          var defaultSpeed = parseFloat($defaultOption.data('speed'));
          if (!isFinite(defaultSpeed) || defaultSpeed <= 0) { defaultSpeed = 1; }
          applyPlaybackRate(video, defaultSpeed);
          updateSpeedMenu($control, $defaultOption);
          $control.data('speedInit', 1);
        }
        function setupSeekBar(video) {
          var $video = $(video);
          var $wrapper = $video.closest('.video-wrapper');
          if (!$wrapper.length || $video.data('seekInit')) { return; }
          var $seek = $wrapper.find('.video-seek').first();
          if (!$seek.length) { return; }
          var $range = $seek.find('.video-seek-range').first();
          var $current = $seek.find('.video-seek-current').first();
          var $duration = $seek.find('.video-seek-duration').first();
          if (!$range.length) { return; }
          var rafId = null;
          var rafSupported = typeof window.requestAnimationFrame === 'function';
          var lastTimeupdateAt = 0;
          var lastTimeupdateValue = 0;
          var hasTimeupdate = false;
          var nowFn = (typeof window.performance !== 'undefined' && typeof window.performance.now === 'function')
            ? window.performance
            : Date;
          function getNow() {
            return typeof nowFn.now === 'function' ? nowFn.now() : nowFn.getTime();
          }
          function getPlaybackRate() {
            var rate = Number(video.playbackRate || 1);
            return isFinite(rate) && rate > 0 ? rate : 1;
          }
          function updateDuration() {
            var dur = Number(video.duration || 0);
            if (!isFinite(dur) || dur <= 0) { return; }
            $range.attr('max', dur);
            $duration.text(formatVideoTime(dur));
          }
          function setCurrent(value) {
            var cur = Number(value || 0);
            if (!isFinite(cur) || cur < 0) { cur = 0; }
            if (!$range.data('seeking')) {
              $range.val(cur);
            }
            $current.text(formatVideoTime(cur));
          }
          function updateCurrent() {
            setCurrent(video.currentTime || 0);
          }
          function syncTimeupdate() {
            lastTimeupdateValue = Number(video.currentTime || 0);
            if (!isFinite(lastTimeupdateValue) || lastTimeupdateValue < 0) { lastTimeupdateValue = 0; }
            lastTimeupdateAt = getNow();
            hasTimeupdate = true;
          }
          function rafTick() {
            rafId = null;
            if (video.paused || video.ended) { return; }
            if (!$range.data('seeking')) {
              if (hasTimeupdate) {
                var elapsed = (getNow() - lastTimeupdateAt) / 1000;
                var estimate = lastTimeupdateValue + (elapsed * getPlaybackRate());
                var dur = Number(video.duration || 0);
                if (isFinite(dur) && dur > 0 && estimate > dur) { estimate = dur; }
                if (estimate < 0) { estimate = 0; }
                setCurrent(estimate);
              } else {
                updateCurrent();
              }
            }
            rafId = window.requestAnimationFrame(rafTick);
          }
          function startRaf() {
            if (!rafSupported || rafId !== null) { return; }
            rafId = window.requestAnimationFrame(rafTick);
          }
          function stopRaf() {
            if (!rafSupported || rafId === null) { return; }
            window.cancelAnimationFrame(rafId);
            rafId = null;
          }
          if (!$range.data('seekHandlers')) {
            $range.on('pointerdown mousedown touchstart', function () {
              $range.data('seeking', true);
            });
            $range.on('pointerup mouseup touchend touchcancel', function () {
              $range.data('seeking', false);
              var finalValue = Number($range.val() || 0);
              if (isFinite(finalValue)) {
                video.currentTime = finalValue;
              }
            });
            $range.on('input', function () {
              var value = Number(this.value || 0);
              if (!isFinite(value)) { return; }
              $current.text(formatVideoTime(value));
              video.currentTime = value;
            });
            $range.on('change', function () {
              var value = Number(this.value || 0);
              $range.data('seeking', false);
              if (!isFinite(value)) { return; }
              video.currentTime = value;
            });
            $range.data('seekHandlers', 1);
          }
          video.addEventListener('loadedmetadata', updateDuration);
          video.addEventListener('durationchange', updateDuration);
          video.addEventListener('timeupdate', function () {
            if ($range.data('seeking')) { return; }
            syncTimeupdate();
            setCurrent(lastTimeupdateValue);
          });
          video.addEventListener('seeking', syncTimeupdate);
          video.addEventListener('seeked', syncTimeupdate);
          video.addEventListener('ratechange', syncTimeupdate);
          video.addEventListener('play', startRaf);
          video.addEventListener('playing', startRaf);
          video.addEventListener('pause', stopRaf);
          video.addEventListener('ended', stopRaf);
          if (video.readyState >= 1) {
            updateDuration();
            syncTimeupdate();
            setCurrent(lastTimeupdateValue);
          }
          if (!video.paused && !video.ended) {
            startRaf();
          }
          $video.data('seekInit', 1);
        }
        function ensureReelControls(video) {
          var $video = $(video);
          var $wrapper = $video.closest('.video-wrapper');
          if (isStandardWrapper($wrapper)) { return; }
          // Add sound toggle button if not already present
          if (!$video.siblings('.video-sound-toggle').length) {
            var $btn = $('<button>', {
              class: 'video-sound-toggle',
              'aria-label': 'Toggle sound',
              type: 'button'
            });
            $video.parent().append($btn);
          }
          // Add progress bar if not already present
          if (!$video.siblings('.video-progress-bar').length) {
            var $bar = $('<div>', { class: 'video-progress-bar' });
            $video.parent().append($bar);
          }
          // Add time label if not already present
          if (!$video.siblings('.video-time-label').length) {
            var $label = $('<div>', { class: 'video-time-label', text: '0:00' });
            $video.parent().append($label);
          }
          // Prevent duplicate event listeners (by marking as inited)
          if (!$video.data('videoInited')) {
            // Track video progress and update progress bar and time label (show remaining time, counting down)
            video.addEventListener('timeupdate', function () {
              if (!video.duration) return;
              var progress = (video.currentTime / video.duration) * 100;
              var $bar = $video.siblings('.video-progress-bar');
              $bar.css('width', progress + '%');
              // Update time label (show remaining time, counting down)
              var $label = $video.siblings('.video-time-label');
              var remaining = Math.floor(video.duration - video.currentTime);
              var min = Math.floor(remaining / 60);
              var sec = remaining % 60;
              $label.text(min + ':' + (sec < 10 ? '0' + sec : sec));
            });
            $video.data('videoInited', 1);
          }
        }
        function applyVideoMode(video, mode) {
          var $video = $(video);
          var $wrapper = $video.closest('.video-wrapper');
          if (!$wrapper.length) { return; }
          var nextMode = (mode === 'standard') ? 'standard' : 'reel';
          $wrapper.attr('data-video-mode', nextMode);
          if (nextMode === 'standard') {
            $wrapper.addClass('video-wrapper--standard').removeClass('video-wrapper--reel');
            if (typeof video.removeAttribute === 'function') {
              video.removeAttribute('loop');
            }
            video.loop = false;
            video.controls = true;
            video.setAttribute('controls', '');
            $wrapper.removeClass('is-paused');
            $video.siblings('.video-sound-toggle, .video-progress-bar, .video-time-label').remove();
            if (observer) { observer.unobserve(video); }
          } else {
            $wrapper.removeClass('video-wrapper--standard').addClass('video-wrapper--reel');
            if (!video.hasAttribute('loop')) {
              video.setAttribute('loop', '');
            }
            video.loop = true;
            video.controls = false;
            if (typeof video.removeAttribute === 'function') {
              video.removeAttribute('controls');
            }
            ensureReelControls(video);
            if (observer) { observer.observe(video); }
          }
        }
        function bindVideoMetadata(video) {
          var $video = $(video);
          if ($video.data('videoMetaBound')) { return; }
          var update = function () {
            var mode = isStandardByMeta(video) ? 'standard' : 'reel';
            applyVideoMode(video, mode);
          };
          video.addEventListener('loadedmetadata', update);
          video.addEventListener('durationchange', update);
          $video.data('videoMetaBound', 1);
          if (video.readyState >= 1) {
            update();
          }
        }
        // Helper to add controls and event listeners to a video
        function setupVideo(video) {
          var $video = $(video);
          var $wrapper = $video.closest('.video-wrapper');
          if (!$wrapper.length) { return; }
          if (!$wrapper.attr('data-video-mode')) {
            $wrapper.attr('data-video-mode', 'reel');
          }
          bindVideoMetadata(video);
          setupSpeedMenu(video);
          setupSeekBar(video);
          if (!isStandardWrapper($wrapper)) {
            ensureReelControls(video);
          }
        }
        // The main initializer function
        function initPostVideos(root) {
          // Normalize root to a jQuery scope; tolerate fragments/text nodes
          var $scope = (root && root.nodeType) ? $(root) : $(document);
          // Click-to-unmute, then play/pause toggle (delegated)
          if (!DZ._videoClickHandlerAttached) {
            $(document).on('click', '.video-wrapper video', function () {
              var video = this;
              var $wrapper = $(video).closest('.video-wrapper');
              if (isStandardWrapper($wrapper)) { return; }
              if (video.muted) {
                video.muted = false;
                return;
              }
              if (video.paused) {
                video.play();
                $wrapper.removeClass('is-paused');
              } else {
                video.pause();
                $wrapper.addClass('is-paused');
              }
            });
            DZ._videoClickHandlerAttached = true;
          }
          // Sound toggle button (delegated)
          if (!DZ._videoSoundToggleHandlerAttached) {
            $(document).on('click', '.video-sound-toggle', function (e) {
              e.stopPropagation();
              var $btn = $(this);
              var $video = $btn.closest('.video-wrapper').find('video').get(0);
              if ($video && isStandardWrapper($btn.closest('.video-wrapper'))) { return; }
              if (!$video) return;
              if ($video.muted) {
                $video.muted = false;
                $btn.addClass('sound-on');
              } else {
                $video.muted = true;
                $btn.removeClass('sound-on');
              }
            });
            DZ._videoSoundToggleHandlerAttached = true;
          }
          if (!DZ._videoSpeedHandlersAttached) {
            var closeSpeedMenus = function (except) {
              $('.video-speed-control').each(function () {
                if (except && this === except.get(0)) { return; }
                var $control = $(this);
                $control.removeClass('is-open');
                $control.find('.video-speed-toggle').attr('aria-expanded', 'false');
                $control.find('.video-speed-menu').attr('aria-hidden', 'true');
              });
            };
            $(document).on('click', '.video-speed-toggle', function (e) {
              e.stopPropagation();
              var $control = $(this).closest('.video-speed-control');
              var isOpen = $control.hasClass('is-open');
              closeSpeedMenus($control);
              if (!isOpen) {
                $control.addClass('is-open');
                $(this).attr('aria-expanded', 'true');
                $control.find('.video-speed-menu').attr('aria-hidden', 'false');
              }
            });
            $(document).on('click', '.video-speed-option', function (e) {
              e.stopPropagation();
              var $option = $(this);
              var $control = $option.closest('.video-speed-control');
              var $wrapper = $option.closest('.video-wrapper');
              var $video = $wrapper.find('video').get(0);
              var speed = parseFloat($option.data('speed'));
              if ($video && isFinite(speed) && speed > 0) {
                var wasPlaying = !$video.paused && !$video.ended;
                applyPlaybackRate($video, speed);
                if ($video.ended && $video.loop && !isStandardWrapper($wrapper)) {
                  $video.currentTime = 0;
                }
                if (wasPlaying && isSafariBrowser() && speed > 2) {
                  $video.pause();
                  $video.play().catch(() => {});
                }
                if (wasPlaying && $video.paused) {
                  $video.play().catch(() => {});
                }
                if (speed > 2) {
                  guardHighSpeedPlayback($video, $control);
                }
              }
              updateSpeedMenu($control, $option);
              $control.removeClass('is-open');
              $control.find('.video-speed-toggle').attr('aria-expanded', 'false');
              $control.find('.video-speed-menu').attr('aria-hidden', 'true');
            });
            $(document).on('click', '.video-speed-menu', function (e) {
              e.stopPropagation();
            });
            $(document).on('click', function () {
              closeSpeedMenus(null);
            });
            DZ._videoSpeedHandlersAttached = true;
          }
          // IntersectionObserver setup
          if ('IntersectionObserver' in window && !observer) {
            observer = new IntersectionObserver(function (entries) {
              entries.forEach(function (entry) {
                var video = entry.target;
                var $wrapper = $(video).closest('.video-wrapper');
                if (isStandardWrapper($wrapper)) { return; }
                if (entry.isIntersecting) {
                  video.play().catch(() => {});
                  $wrapper.removeClass('is-paused');
                } else {
                  video.pause();
                  $wrapper.addClass('is-paused');
                }
              });
            }, {
              threshold: 0.6
            });
          }
          // Find all videos to initialize
          var videos = $scope.find('.video-wrapper video').get();
          // If scope itself is a video
          if ($scope.is('.video-wrapper video')) {
            videos.push($scope.get(0));
          }
          // Setup for each video
          videos.forEach(function (video) {
            setupVideo(video);
            if (observer && !isStandardWrapper($(video).closest('.video-wrapper'))) {
              observer.observe(video);
            }
          });
        }
        return initPostVideos;
      })();
    }
    if (typeof DZ.initFeedFilters !== "function") {
      DZ.initFeedFilters = (function () {
        function resolveFilterBar(root) {
          var $root = (root && root.nodeType) ? $(root) : $(document);
          var $bar = $root.find('.feed-filter-bar').first();
          if (!$bar.length) {
            $bar = $('.feed-filter-bar').first();
          }
          return $bar;
        }
        function resolveFeedContainer($bar, root) {
          if (!$bar || !$bar.length) { return $(); }
          var target = String($bar.data('target') || '').trim();
          var $container = target ? $(target) : $();
          if (!$container.length) {
            var $root = (root && root.nodeType) ? $(root) : $(document);
            $container = $bar.closest('.content-left-container').find('.posts-container#posts').first();
            if (!$container.length) {
              $container = $root.find('.posts-container#posts').first();
            }
          }
          return $container;
        }
        function pausePostMedia($post) {
          if (!$post || !$post.length) { return; }
          $post.find('video').each(function () {
            try { this.pause(); } catch (e) { }
          });
          $post.find('audio').each(function () {
            try { this.pause(); } catch (e) { }
          });
        }
        function applyFilterToContainer($container, filter) {
          if (!$container || !$container.length) { return; }
          var normalized = String(filter || 'all').toLowerCase();
          var $posts = $container.find('.post_');
          if (normalized === 'all') {
            $posts.removeClass('feed-filtered-out');
            return;
          }
          $posts.each(function () {
            var $post = $(this);
            var type = String($post.data('type') || '').toLowerCase();
            if (type === normalized) {
              $post.removeClass('feed-filtered-out');
            } else {
              pausePostMedia($post);
              $post.addClass('feed-filtered-out');
            }
          });
        }
        function setActiveButton($bar, filter) {
          if (!$bar || !$bar.length) { return; }
          var normalized = String(filter || 'all').toLowerCase();
          $bar.find('.feed-filter-button').each(function () {
            var $btn = $(this);
            var btnFilter = String($btn.data('filter') || '').toLowerCase();
            var isActive = btnFilter === normalized;
            $btn.toggleClass('is-active', isActive);
            $btn.attr('aria-pressed', isActive ? 'true' : 'false');
          });
        }
        function initFeedFilters(root) {
          var $bar = resolveFilterBar(root);
          if (!$bar.length) { return; }
          var activeFilter = String($bar.attr('data-active-filter') || '').toLowerCase();
          if (!activeFilter) {
            var $activeBtn = $bar.find('.feed-filter-button.is-active').first();
            activeFilter = String($activeBtn.data('filter') || 'all').toLowerCase();
            $bar.attr('data-active-filter', activeFilter);
          }
          var useServerFilter = window.MainFeed && typeof MainFeed.setFilter === 'function';
          if (!useServerFilter) {
            var $container = resolveFeedContainer($bar, root);
            applyFilterToContainer($container, activeFilter);
          }
        }
        if (!DZ._feedFilterHandlerAttached) {
          $(document).on('click', '.feed-filter-button', function () {
            var $btn = $(this);
            var $bar = $btn.closest('.feed-filter-bar');
            var filter = String($btn.data('filter') || 'all').toLowerCase();
            $bar.attr('data-active-filter', filter);
            setActiveButton($bar, filter);
            var useServerFilter = window.MainFeed && typeof MainFeed.setFilter === 'function';
            if (useServerFilter) {
              MainFeed.setFilter(filter);
            } else {
              var $container = resolveFeedContainer($bar, document);
              applyFilterToContainer($container, filter);
            }
          });
          DZ._feedFilterHandlerAttached = true;
        }
        return initFeedFilters;
      })();
    }
    // Initialize videos on initial page load
    $(document).ready(function () {
      if (typeof DZ.initPostVideos === 'function') DZ.initPostVideos(document);
      if (typeof DZ.initFeedFilters === 'function') DZ.initFeedFilters(document);
    });

    // Initialize videos when new posts are loaded
    $(document).on('posts:loaded', function (e, data) {
      if (typeof DZ.initPostVideos === 'function') {
        var root = (data && data.root && data.root.nodeType) ? data.root : document;
        DZ.initPostVideos(root);
      }
      if (typeof DZ.initFeedFilters === 'function') {
        var rootFilter = (data && data.root && data.root.nodeType) ? data.root : document;
        DZ.initFeedFilters(rootFilter);
      }
    });
  $(document).on('click', '.p_comment', function (e) {
    e.preventDefault();

    var $btn  = $(this);
    var id    = $btn.data('id');
    var $post = $btn.closest('.post_');
    // Guard: comments disabled
    var cs = String(($post.data('comments') || 'on')).toLowerCase();
    if (cs === 'off') {
      ensureDzToast();
      DZ.toast('Comments are turned off for this post', { type: 'info', duration: 2000 });
      return;
    }
    if (typeof id === 'undefined') { return; }

    // Scope to current post to avoid cross-post interference
    var $target = $post.find('.p_comment_' + id).first();
      if (!$target.length) { return; }

      var isOpen = $target.is(':visible');

      // Optionally close other open comment panels in the same post
      $post.find('.make-comment').not($target).filter(':visible').each(function () {
        animateClose($(this));
      });

      if (isOpen) {
        animateClose($target);
        $btn.attr('aria-expanded', 'false');
      } else {
        animateOpen($target);
        $btn.attr('aria-expanded', 'true');

        requestAnimationFrame(function () {
          var $ta = $target.find('textarea[name="post-text"]').first();
          if ($ta.length) { $ta.focus(); }
        });
      }
    });

    // Reply button: open the composer for this post and prefill @username
    // .comment-reply must carry data-id (post id) and data-reply (username)
    $(document).on('click', '.comment-reply', function (e) {
      e.preventDefault();

      var $btn      = $(this);
      var id        = $btn.data('id');
      var replyName = $btn.data('reply');

      if (typeof id === 'undefined') { return; }

      // Resolve context and target panel within the same post
      var $post   = $btn.closest('.post_');
      var $target = $post.find('.p_comment_' + id).first();
      if (!$target.length) { return; }

      var wasOpen = $target.is(':visible');

      // Close any other open panels in the same post
      $post.find('.make-comment').not($target).filter(':visible').each(function () {
        animateClose($(this));
      });

      // Open if needed and update ARIA on its toggle
      if (!wasOpen) {
        animateOpen($target);
        $post.find('.p_comment[data-id="' + id + '"]').attr('aria-expanded', 'true');
      }

      requestAnimationFrame(function () {
        var $ta = $target.find('textarea[name="post-text"]').first();
        if ($ta.length) {
          var el       = $ta.get(0);
          var mention  = '@' + String(replyName || '').replace(/\s+/g, '');
          var current  = $ta.val() || '';
          var cleanReplyName = String(replyName || '').trim();

          $target
            .addClass('is-replying')
            .attr('data-reply-to', cleanReplyName);
          $target.find('[data-role="comment-reply-name"]').text(cleanReplyName);
          $target.find('[data-role="comment-reply-context"]').removeClass('none');

          if (mention && !current.includes(mention)) {
            if (typeof el.selectionStart === 'number' && typeof el.selectionEnd === 'number') {
              var start = el.selectionStart;
              var end   = el.selectionEnd;
              $ta.val(current.slice(0, start) + mention + ' ' + current.slice(end));
            } else {
              $ta.val((current ? (mention + ' ' + current) : (mention + ' ')));
            }
          }

          $ta.trigger('input').focus();
          try {
            var pos = $ta.val().length;
            if (el.setSelectionRange) { el.setSelectionRange(pos, pos); }
          } catch (err) {}
        }
      });
    });

    $(document).on('click', '[data-role="comment-reply-cancel"]', function (e) {
      e.preventDefault();
      var $panel = $(this).closest('.make-comment');
      if (!$panel.length) { return; }
      var replyName = String($panel.attr('data-reply-to') || '').trim();
      var mention = replyName ? ('@' + replyName.replace(/\s+/g, '')) : '';
      var $ta = $panel.find('textarea[name="post-text"]').first();

      if ($ta.length && mention) {
        var current = $ta.val() || '';
        var pattern = new RegExp('(^|\\s)' + mention.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*', 'g');
        $ta.val(current.replace(pattern, ' ').replace(/^\\s+/, '').replace(/\\s{2,}/g, ' ').trim());
        $ta.trigger('input').focus();
      }

      $panel.removeClass('is-replying').removeAttr('data-reply-to');
      $panel.find('[data-role="comment-reply-context"]').addClass('none');
      $panel.find('[data-role="comment-reply-name"]').text('');
    });

    // Close when clicking the overlay/background of the panel
    $(document).on('click', '.make-comment', function (e) {
      // If the click originated inside the content area, do nothing
      if ($(e.target).closest('.make-comment-area').length) { return; }

      var $panel = $(this);
      var $post  = $panel.closest('.post_');

      // Update ARIA on its related toggle button, if any
      var cls = $panel.attr('class') || '';
      var m   = cls.match(/p_comment_(\d+)/);
      if (m && m[1]) {
        $post.find('.p_comment[data-id="' + m[1] + '"]').attr('aria-expanded', 'false');
      }

      animateClose($panel);
    });
  })();
  $(document).on("click", ".more_menu", function (e) {
      e.stopPropagation();
      $(".sidebar_hide_more_menu_box").toggleClass("none");
  });

  $(document).on("click", function (e) {
      if (!$(e.target).closest('.sidebar_hide_more_menu_box, .more_menu').length) {
          $(".sidebar_hide_more_menu_box").addClass("none");
      }
  });

  $(document).on('click', '.getTheChat', function () {
    var id  = $(this).data('id');
    var csr = $('input[name="csrf_token"]').val();

    $.ajax({
      type: 'POST',
      url: buildUrl('request/requests.php'),
      dataType: 'json',
      data: {
        p: 'get_live_chat',
        id: id,
        csrf_token: csr
      },
      success: function (res) {
        if (res.status === 'success') {
          $(".current_message_box").removeClass("none");
          var box = $('.chat_list_box').get(0);
          injectHTMLWithScriptsInto(box, res.html).then(function(){
            $("textarea[name='post-text']").focus();
            try { document.dispatchEvent(new CustomEvent('chat:opened', { detail: { withId: res.chat_user_id || 0 } })); } catch(_){}
          });
          // If server returned updated>0, nudge chat status refresh in the active panel
          try {
            if (typeof res.updated !== 'undefined' && parseInt(res.updated||0,10) > 0) {
              setTimeout(function(){
                try { document.dispatchEvent(new CustomEvent('chat:refresh-status')); } catch(_){}
              }, 200);
            }
          } catch(_){}
        } else {
          console.warn(res.message || 'Load failed');
        }
      },
      error: function () {
        console.warn('Server error');
      }
    });
  });
  // ==========================
  // Post settings popup (sheet)
  // ==========================
  function hideAllPostMenus() {
    // Before hiding, restore original sheet content if we swapped it (share list)
    try {
      $('.post-menu-popup').each(function(){
        var $pp = $(this);
        var $sheet = $pp.find('.pm-sheet');
        var orig = $sheet.data('origHtml');
        if (typeof orig !== 'undefined') {
          $sheet.html(orig);
          $sheet.removeData('origHtml');
        }
        $pp.removeData('suppress-close');
      });
    } catch(_){ }
    $('.post-menu-popup').addClass('none').attr('aria-hidden', 'true');
    $('.post-settings-btn[aria-expanded="true"]').attr('aria-expanded', 'false');
  }

  $(document).on('click keydown', '.post-settings-btn', function (e) {
    if (e.type === 'keydown' && e.key !== 'Enter' && e.key !== ' ') return;
    e.preventDefault();
    e.stopPropagation();

    var $btn  = $(this);
    var postId = $btn.data('id');
    var $post = $btn.closest('.post_');
    var $popup = $post.find('#postMenuPopup-' + postId);
    if (!$popup.length) { $popup = $('#postMenuPopup-' + postId); }
    if (!$popup.length) return;

    // Hide others; then ensure this popup content is reset to original before showing
    hideAllPostMenus();
    try {
      var $sheetFix = $popup.find('.pm-sheet');
      var origFix = $sheetFix.data('origHtml');
      if (typeof origFix !== 'undefined') {
        $sheetFix.html(origFix);
        $sheetFix.removeData('origHtml');
      }
      $popup.removeData('suppress-close');
    } catch(_){ }
    $popup.removeClass('none').attr('aria-hidden', 'false');
    $btn.attr('aria-expanded', 'true');
  });

  // Background click closes (only if clicked outside the sheet container)
  $(document).on('click', '.post-menu-popup', function (e) {
    var $pp = $(this);
    // When share menu is transitioning content, suppress one close cycle
    if ($pp.data('suppress-close') === 1 || window.__dzShareClick === true) { if (e && e.preventDefault) e.preventDefault(); return; }
    var $t = $(e.target);
    // If click is within the container OR on any menu item, don't close
    if ($t.closest('.pm-sheet-container').length || $t.closest('.pm-item').length) return;
    hideAllPostMenus();
  });
  // Cancel button
  $(document).on('click', '.post-menu-popup .pm-cancel', function () { hideAllPostMenus(); });
  // Report popup cancel
  $(document).on('click', '.post-report-popup .pr-cancel', function(){
    $(this).closest('.post-report-popup').addClass('none').attr('aria-hidden','true');
  });
  // Report popup outside click
  $(document).on('click', '.post-report-popup', function(e){
    if ($(e.target).closest('.pr-sheet-container').length) return;
    $(this).addClass('none').attr('aria-hidden','true');
  });
  // Embed popup close interactions
  $(document).on('click', '.post-embed-popup .pe-cancel', function(){
    $(this).closest('.post-embed-popup').addClass('none').attr('aria-hidden','true');
  });
  $(document).on('click', '.post-embed-popup', function(e){
    if ($(e.target).closest('.pe-sheet-container').length) return;
    $(this).addClass('none').attr('aria-hidden','true');
  });
  // Visibility popup close interactions
  $(document).on('click', '.post-visibility-popup .pv-cancel', function(){
    $(this).closest('.post-visibility-popup').addClass('none').attr('aria-hidden','true');
  });
  $(document).on('click', '.post-visibility-popup', function(e){
    if ($(e.target).closest('.pv-sheet-container').length) return;
    $(this).addClass('none').attr('aria-hidden','true');
  });
  // Copy embed code (no double notifications)
  $(document).on('click', '.post-embed-popup .peb-copy', function(){
    var $btn = $(this);
    var $popup = $btn.closest('.post-embed-popup');
    var $ta = $popup.find('.peb-code');
    var code = ($ta.val() || '').toString();
    if (!code) return;
    var markCopied = function(){
      var orig = $btn.data('orig-label');
      if (!orig) { orig = ($btn.text()||'').toString(); $btn.data('orig-label', orig); }
      $btn.addClass('is-copied');
      $btn.text(I18N('ui_embed_copied') || 'Embed code copied');
      setTimeout(function(){ $btn.removeClass('is-copied'); $btn.text(orig); }, 1200);
      ensureDzToast(); DZ.toast(I18N('ui_embed_copied') || 'Embed code copied');
    };
    var fallbackCopy = function(){
      try {
        var tmp = document.createElement('textarea');
        tmp.value = code;
        document.body.appendChild(tmp);
        tmp.select();
        try { document.execCommand('copy'); } catch(_){}
        document.body.removeChild(tmp);
      } catch(_){}
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(code).then(function(){
        markCopied();
      }).catch(function(){
        fallbackCopy();
        markCopied();
      });
    } else {
      fallbackCopy();
      markCopied();
    }
  });
  // Choose a visibility option
  $(document).on('click', '.post-visibility-popup .pv-item', function(){
    var $btn = $(this);
    var $popup = $btn.closest('.post-visibility-popup');
    var $post = $popup.closest('.post_');
    var pid  = ($popup.data('post-id') || $post.data('id') || '').toString();
    var code = String($btn.data('code') || '').toLowerCase();
    var csrf = $("input[name='csrf_token']").val();
    if (!pid || !code || !csrf) { ensureDzToast(); DZ.toast(I18N('ui_missing_parameters') || 'Missing parameters'); return; }
    // If locked is chosen -> always open the price popup (show current price if > 0)
    if (code === 'locked') {
      var $pp = $post.find('#postPricePopup-' + pid);
      if (!$pp.length) { $pp = $('#postPricePopup-' + pid); }
      if ($pp.length) {
        $popup.addClass('none').attr('aria-hidden','true');
        $pp.removeClass('none').attr('aria-hidden','false');
        var minP = parseInt($post.data('min-price') || 1, 10) || 1;
        var maxP = parseInt($post.data('max-price') || 500, 10) || 500;
        var curPrice = parseInt($post.data('price') || 0, 10) || 0;
        var prefill = (curPrice > 0 ? curPrice : minP);
        var $inp = $pp.find('.pp-input');
        $inp.attr('min', String(minP)).attr('max', String(maxP)).val(prefill);
        return;
      }
    }
    if ($btn.data('busy') === true) return; $btn.data('busy', true);

    $.ajax({
      type:'POST', url: (typeof window.buildUrl==='function'?buildUrl('request/requests.php'):((typeof site_url!=='undefined'?site_url:'' )+'request/requests.php')), dataType:'json',
      data: { p:'update_post_visibility', post_id: pid, visibility: code, csrf_token: csrf }
    }).done(function(res){
      var ok = !!(res && res.status==='success');
      var msg = (res && (res.message||res.msg)) || '';
      ensureDzToast();
      if (ok) {
        DZ.toast(msg || (I18N('ui_visibility_updated') || 'Visibility updated'), { type:'success', duration: 2000 });
        $post.data('visibility', code);
        $popup.addClass('none').attr('aria-hidden','true');
      } else {
        DZ.toast(msg || (I18N('ui_error') || 'Error'), { type:'error', duration: 2400 });
      }
    }).fail(function(){ ensureDzToast(); DZ.toast(I18N('ui_network_error') || 'Network error', { type:'error', duration: 2200 }); })
      .always(function(){ $btn.data('busy', false); });
  });

  // Price popup interactions
  $(document).on('click', '.post-price-popup .pp-cancel', function(){
    $(this).closest('.post-price-popup').addClass('none').attr('aria-hidden','true');
  });
  $(document).on('click', '.post-price-popup', function(e){
    if ($(e.target).closest('.pp-sheet-container').length) return;
    $(this).addClass('none').attr('aria-hidden','true');
  });
  $(document).on('click', '.post-price-popup .pp-save', function(){
    var $pp = $(this).closest('.post-price-popup');
    var $post = $pp.closest('.post_');
    var pid = ($pp.data('post-id') || $post.data('id') || '').toString();
    var csrf = $("input[name='csrf_token']").val();
    var minP = parseInt($post.data('min-price') || 1, 10) || 1;
    var maxP = parseInt($post.data('max-price') || 500, 10) || 500;
    var price = parseInt(($pp.find('.pp-input').val() || '').toString(), 10) || 0;
    if (!pid || !csrf) { ensureDzToast(); DZ.toast(I18N('ui_missing_parameters') || 'Missing parameters'); return; }
    if (price < minP || price > maxP) { ensureDzToast(); DZ.toast((I18N('ui_price_range', { min: minP, max: maxP }) || ('Price must be between ' + minP + ' and ' + maxP)), { type:'error' }); return; }

    if ($(this).data('busy') === true) return; $(this).data('busy', true);
    $.ajax({
      type:'POST', url: (typeof window.buildUrl==='function'?buildUrl('request/requests.php'):((typeof site_url!=='undefined'?site_url:'' )+'request/requests.php')), dataType:'json',
      data: { p:'update_post_premium', post_id: pid, price: price, csrf_token: csrf }
    }).done(function(res){
      var ok = !!(res && res.status==='success');
      var msg = (res && (res.message||res.msg)) || '';
      ensureDzToast();
      if (ok) {
        DZ.toast(msg || (I18N('ui_visibility_updated') || 'Visibility updated'), { type:'success', duration: 2000 });
        $post.data('price', price);
        $post.data('visibility', 'locked');
        $pp.addClass('none').attr('aria-hidden','true');
      } else {
        DZ.toast(msg || (I18N('ui_error') || 'Error'), { type:'error', duration: 2400 });
      }
    }).fail(function(){ ensureDzToast(); DZ.toast(I18N('ui_network_error') || 'Network error', { type:'error', duration: 2200 }); })
      .always(function(){ $(this).data('busy', false); }.bind(this));
  });

  // Edit Post popup interactions
  $(document).on('click', '.post-edit-popup .pe-cancel', function(){
    $(this).closest('.post-edit-popup').addClass('none').attr('aria-hidden','true');
  });
  $(document).on('click', '.post-edit-popup', function(e){
    if ($(e.target).closest('.pe-sheet-container').length) return;
    $(this).addClass('none').attr('aria-hidden','true');
  });
  $(document).on('click', '.post-edit-popup .pe-save', function(){
    var $ep = $(this).closest('.post-edit-popup');
    var $post = $ep.closest('.post_');
    var pid = ($ep.data('post-id') || $post.data('id') || '').toString();
    var csrf = $("input[name='csrf_token']").val();
    var text = ($ep.find('.pe-text').val() || '').toString();
    if (!pid || !csrf) { ensureDzToast(); DZ.toast(I18N('ui_missing_parameters') || 'Missing parameters'); return; }
    if ($(this).data('busy') === true) return; $(this).data('busy', true);
    $.ajax({
      type:'POST', url:(typeof window.buildUrl==='function'?buildUrl('request/requests.php'):((typeof site_url!=='undefined'?site_url:'' )+'request/requests.php')), dataType:'json',
      data:{ p:'update_post_text', post_id: pid, text: text, csrf_token: csrf }
    }).done(function(res){
      var ok = !!(res && res.status==='success');
      var msg = (res && (res.message||res.msg)) || '';
      ensureDzToast();
      if (ok) {
        DZ.toast(msg || (I18N('ui_post_updated') || 'Post updated'), { type:'success', duration:2000 });
        var $textNode = $post.find('.post-body .post-text').first();
        var hasTextProp = (res && Object.prototype.hasOwnProperty.call(res, 'text'));
        var newText = hasTextProp ? String(res.text || '') : text;
        var trimmed = newText.trim();
        var newHtml = (res && typeof res.html === 'string')
          ? res.html
          : $('<div/>').text(newText).html().replace(/\n/g,'<br>');

        if ($textNode.length) {
          if (trimmed === '') { $textNode.remove(); }
          else { $textNode.html(newHtml); }
        } else if (trimmed !== '') {
          var $body = $post.find('.post-body').first();
          var $media = $body.children().first();
          $('<div class="post-text"></div>').html(newHtml).insertAfter($media);
        }
        $post.data('text', newText);
        $ep.addClass('none').attr('aria-hidden','true');
      } else {
        DZ.toast(msg || (I18N('ui_error') || 'Error'), { type:'error', duration:2400 });
      }
    }).fail(function(){ ensureDzToast(); DZ.toast(I18N('ui_network_error') || 'Network error', { type:'error', duration:2200 }); })
      .always(function(){ $(this).data('busy', false); }.bind(this));
  });
  // Delete Post popup interactions
  $(document).on('click', '.post-delete-popup .pd-cancel', function(){
    $(this).closest('.post-delete-popup').addClass('none').attr('aria-hidden','true');
  });
  $(document).on('click', '.post-delete-popup', function(e){
    if ($(e.target).closest('.pd-sheet-container').length) return;
    $(this).addClass('none').attr('aria-hidden','true');
  });
  $(document).on('click', '.post-delete-popup .pd-confirm', function(){
    var $pp = $(this).closest('.post-delete-popup');
    var $post = $pp.closest('.post_');
    var pid = ($pp.data('post-id') || $post.data('id') || '').toString();
    var csrf = $("input[name='csrf_token']").val();
    if (!pid || !csrf) { ensureDzToast(); DZ.toast(I18N('ui_missing_parameters') || 'Missing parameters'); return; }
    if ($(this).data('busy') === true) return; $(this).data('busy', true);
    $.ajax({
      type:'POST', url:(typeof window.buildUrl==='function'?buildUrl('request/requests.php'):((typeof site_url!=='undefined'?site_url:'' )+'request/requests.php')), dataType:'json',
      data:{ p:'delete_post', post_id: pid, csrf_token: csrf }
    }).done(function(res){
      var ok = !!(res && res.status==='success');
      var msg = (res && (res.message||res.msg)) || '';
      ensureDzToast();
      if (ok) {
        DZ.toast(msg || (I18N('ui_deleted') || 'Deleted'), { type:'success', duration: 2000 });
        $post.fadeOut(180, function(){ $(this).remove(); });
      } else {
        DZ.toast(msg || (I18N('ui_error') || 'Error'), { type:'error', duration:2200 });
      }
    }).fail(function(){ ensureDzToast(); DZ.toast(I18N('ui_network_error') || 'Network error', { type:'error', duration:2200 }); })
      .always(function(){ $(this).data('busy', false); }.bind(this));
  });
  // Choose a report reason
  $(document).on('click', '.post-report-popup .pr-item', function(){
    var $btn = $(this);
    var $popup = $btn.closest('.post-report-popup');
    var $post = $btn.closest('.post_');
    var code = $btn.data('code');
    var pid  = ($popup.data('post-id') || $post.data('id') || '').toString();
    var csrf = $("input[name='csrf_token']").val();
    if (!pid || !csrf) { ensureDzToast(); DZ.toast(I18N('ui_missing_parameters') || 'Missing parameters'); return; }
    if ($btn.data('busy') === true) return;
    $btn.data('busy', true);

    $.ajax({
      type:'POST', url: (typeof window.buildUrl==='function'?buildUrl('request/requests.php'):((typeof site_url!=='undefined'?site_url:'' )+'request/requests.php')), dataType:'json',
      data: { p:'report_post', post_id: pid, reason: code, csrf_token: csrf }
    }).done(function(res){
      var ok = !!(res && (res.status==='success' || res.success===true));
      var msg = (res && (res.message||res.msg)) || '';
      ensureDzToast();
      if (ok) {
        DZ.toast(msg || (I18N('ui_ok') || 'OK'), { type: 'success', duration: 2000 });
        // Update menu button text
        var $menuItem = $post.find('.post-menu-popup .pm-item[data-action="report"]').first();
        if ($menuItem.length && typeof res.reported !== 'undefined') {
          $menuItem.text(res.reported ? (I18N('ui_unreport') || 'Unreport') : (I18N('menu_report') || 'Report'));
        }
        $popup.addClass('none').attr('aria-hidden','true');
        hideAllPostMenus();
      } else {
        DZ.toast(msg || (I18N('ui_error') || 'Error'), { type:'error', duration: 2200 });
      }
    }).fail(function(){ ensureDzToast(); DZ.toast(I18N('ui_network_error') || 'Network error', { type:'error', duration: 2200 }); })
      .always(function(){ $btn.data('busy', false); });
  });

  // ESC to close
  $(document).on('keydown', function (e) { if (e.key === 'Escape') hideAllPostMenus(); });

  // Capture-phase guard: before jQuery delegated handlers run, mark the
  // popup to suppress a single background-close when clicking Share/Back.
  // We do NOT stop propagation here to avoid breaking other actions.
  try {
    document.addEventListener('click', function(ev){
      var t = ev.target;
      if (!t || !t.closest) return;
      var el = t.closest('.post-menu-popup .pm-item');
      if (!el) return;
      var act = String(el.getAttribute('data-action')||'').toLowerCase();
      if (act === 'share' || act === 'share-back') {
        try { window.__dzShareClick = true; } catch(_){ }
        setTimeout(function(){ try { window.__dzShareClick = false; } catch(_){ } }, 120);
        var pp = el.closest('.post-menu-popup');
        if (pp) {
          try {
            var $pp = $(pp);
            $pp.data('suppress-close', 1);
            // Safety: clear flag shortly after to avoid sticky state
            setTimeout(function(){ try { $pp.removeData('suppress-close'); } catch(_){ $pp.data('suppress-close', 0); } }, 200);
          } catch(_){ }
        }
      }
    }, { capture: true });
  } catch(_){ }

  // Action clicks
  function ensureDzToast(){
    window.DZ = window.DZ || {};
    if (typeof DZ.toast === 'function') return;
    // Lightweight, non-blocking toast (no alert fallbacks)
    function ensureContainer(){
      var id = 'dz-toast-container';
      var el = document.getElementById(id);
      if (!el) {
        el = document.createElement('div');
        el.id = id;
        el.className = 'dz-toast-container';
        document.body.appendChild(el);
      }
      return el;
    }
    DZ.toast = function(msg, opts){
      try {
        var container = ensureContainer();
        var opt  = opts || {};
        var kind = (opt.type === 'error' || opt.type === 'info') ? opt.type : 'success';
        var dur  = typeof opt.duration === 'number' ? Math.max(1000, opt.duration) : 2200;
        var el = document.createElement('div');
        el.className = 'dz-toast ' + (kind === 'error' ? 'is-error' : (kind === 'info' ? 'is-info' : 'is-success'));
        el.setAttribute('role', 'status');
        el.setAttribute('aria-live', 'polite');
        el.textContent = String(msg || '');
        container.appendChild(el);
        requestAnimationFrame(function(){ el.classList.add('is-shown'); });
        setTimeout(function(){
          el.classList.remove('is-shown');
          setTimeout(function(){ if (el && el.parentNode) el.parentNode.removeChild(el); }, 220);
        }, dur);
      } catch (_) {}
    };
  }

  $(document).on('click', '.post-menu-popup .pm-item', function (e) {
    var $item = $(this);
    try {
      // Keep popup open for in-menu actions and avoid outside-close race
      if ($item.is('button')) { e.preventDefault(); }
      if (e && typeof e.stopImmediatePropagation === 'function') { e.stopImmediatePropagation(); }
      e.stopPropagation();
    } catch(_){ }
    var action = $item.data('action');
    if (($item.is('[disabled]') || $item.attr('aria-disabled') === 'true') && action !== 'embed') return;
    var $popup = $item.closest('.post-menu-popup');
    var $post  = $item.closest('.post_');
    var url    = $item.data('url') || $post.find('.post-settings-btn').data('url');
    var keepOpen = false;

    switch (action) {
      case 'copy-link':
        if (url) {
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(url).then(function(){ ensureDzToast(); DZ.toast(I18N('ui_link_copied') || 'Link copied'); });
          } else {
            var tmp = document.createElement('input');
            tmp.value = url; document.body.appendChild(tmp); tmp.select(); try { document.execCommand('copy'); } catch(_){}
            document.body.removeChild(tmp); ensureDzToast(); DZ.toast(I18N('ui_link_copied') || 'Link copied');
          }
        }
        break;
      case 'share': {
        keepOpen = true;
        var isMobile = false;
        try {
          isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(String(navigator.userAgent||''));
          if (!isMobile && navigator.maxTouchPoints > 1) { isMobile = true; }
        } catch(_){ }

        if (isMobile && navigator.share && url) {
          navigator.share({ title: document.title, url: url }).catch(function(){});
          break;
        }

        if (!url) break;

        // Desktop (or no Web Share): show share destinations inline
        var $sheet = $popup.find('.pm-sheet');
        if (!$sheet.length) {
          // Fallback to copy if sheet not found
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(url).then(function(){ ensureDzToast(); DZ.toast(I18N('ui_link_copied') || 'Link copied'); });
          }
          break;
        }

        // Cache original content once
        if (typeof $sheet.data('origHtml') === 'undefined') {
          $sheet.data('origHtml', $sheet.html());
        }

        var title = document.title || '';
        var eUrl  = encodeURIComponent(url);
        var eTxt  = encodeURIComponent(title);
        var shareItems = [
          { name: 'WhatsApp',  href: 'https://wa.me/?text=' + encodeURIComponent((title? (title + ' ') : '') + url) },
          { name: 'Facebook',  href: 'https://www.facebook.com/sharer/sharer.php?u=' + eUrl },
          { name: 'X (Twitter)', href: 'https://twitter.com/intent/tweet?url=' + eUrl + '&text=' + eTxt },
          { name: 'Telegram',  href: 'https://t.me/share/url?url=' + eUrl + '&text=' + eTxt },
          { name: 'Reddit',    href: 'https://www.reddit.com/submit?url=' + eUrl + '&title=' + eTxt },
          { name: 'LinkedIn',  href: 'https://www.linkedin.com/sharing/share-offsite/?url=' + eUrl },
          { name: 'Tumblr',    href: 'https://www.tumblr.com/widgets/share/tool?canonicalUrl=' + eUrl + '&title=' + eTxt }
          // Note: Instagram does not provide a public web share URL for links
        ];

        var html = '';
        var sTitle = (typeof I18N === 'function' ? (I18N('menu_share_to') || 'Share to…') : 'Share to…');
        var backTxt = (typeof I18N === 'function' ? (I18N('nav_back') || 'Back') : 'Back');
        var copyTxt = (typeof I18N === 'function' ? (I18N('menu_copy_link') || 'Copy link') : 'Copy link');
        html += '<div class="pm-header flex align_items_justify_content full-width">' + sTitle + '</div>';
        for (var i=0; i<shareItems.length; i++) {
          var it = shareItems[i];
          html += '<a class="pm-item" href="' + it.href + '" target="_blank" rel="noopener noreferrer">' + it.name + '</a>';
          html += '<div class="pm-sep"></div>';
        }
        html += '<button type="button" class="pm-item" data-action="copy-link" data-url="' + (url.replace(/"/g,'&quot;')) + '">' + copyTxt + '</button>';
        html += '<div class="pm-sep"></div>';
        html += '<button type="button" class="pm-item pm-share-back" data-action="share-back">' + backTxt + '</button>';

        // Mark to suppress background close during DOM swap
        try { $popup.data('suppress-close', 1); } catch(_){ }
        // Defer DOM swap to next tick to avoid race with delegated handlers
        setTimeout(function(){
          $sheet.html(html);
          try { $popup.removeData('suppress-close'); } catch(_){ $popup.data('suppress-close', 0); }
        }, 0);
        break; }
      case 'share-back': {
        keepOpen = true;
        var $pp2 = $item.closest('.post-menu-popup');
        var $sheet2 = $pp2.find('.pm-sheet');
        var orig = $sheet2.data('origHtml');
        if (typeof orig !== 'undefined') {
          try { $pp2.data('suppress-close', 1); } catch(_){ }
          setTimeout(function(){
            $sheet2.html(orig);
            try { $pp2.removeData('suppress-close'); } catch(_){ $pp2.data('suppress-close', 0); }
          }, 0);
        } else {
          hideAllPostMenus();
        }
        break; }
      case 'save':
        var $save = $post.find('.book_post').first();
        if ($save.length) { $save.trigger('click'); }
        break;
      case 'open':
        if (url) { window.location.href = url; }
        break;
      case 'unfollow': {
        var csrfF = $("input[name='csrf_token']").val();
        var targetId = parseInt($post.data('owner-id'), 10) || 0;
        if (!targetId || !csrfF) { ensureDzToast(); DZ.toast(I18N('ui_missing_parameters') || 'Missing parameters'); break; }
        if ($item.data('busy') === true) break;
        $item.data('busy', true);
        $.ajax({
          type: 'POST',
          url: (typeof window.buildUrl==='function'?buildUrl('request/requests.php'):((typeof site_url!=='undefined'?site_url:'' )+'request/requests.php')),
          dataType: 'json',
          data: { p: 'toggle_follow', target_id: targetId, csrf_token: csrfF }
        }).done(function(res){
          var ok = !!(res && (res.status==='success' || res.success===true));
          var msg = (res && (res.message||res.msg)) || '';
          ensureDzToast();
          if (ok) {
            DZ.toast(msg || 'OK', { type: 'success', duration: 2000 });
            // Ensure button persists and reflects state
            var $sheet = $item.closest('.pm-sheet');
            var $btnUnf = $sheet.find('.pm-item[data-action="unfollow"]').first();
            if (!$btnUnf.length) {
              // Recreate after Report item (with separator)
              var $rep = $sheet.find('.pm-item[data-action="report"]').first();
              var $btn = $('<button/>', { 'class': 'pm-item', 'data-action': 'unfollow' });
              if ($rep.length) {
                $('<div class="pm-sep"></div>').insertAfter($rep);
                $btn.insertAfter($rep.next());
              } else {
                // fallback: append to top
                $sheet.prepend($btn);
              }
              $btnUnf = $btn;
            }
            if (typeof res.following !== 'undefined') {
              var txt = (window.DZ && DZ.i18n) ? (res.following ? DZ.i18n('live_unfollow') : DZ.i18n('live_follow')) : (res.following ? 'Unfollow' : 'Follow');
              $btnUnf.text(txt);
              $btnUnf.toggleClass('is-danger', !!res.following);
            }
            try { document.dispatchEvent(new CustomEvent('follow:changed', { detail: { targetId: targetId, following: !!res.following, followers: res.followers } })); } catch(_){}
          } else {
            DZ.toast(msg || 'Error', { type: 'error', duration: 2200 });
          }
        }).fail(function(){ ensureDzToast(); DZ.toast(I18N('ui_network_error') || 'Network error', { type:'error', duration: 2200 }); })
          .always(function(){ $item.data('busy', false); });
        break; }
      case 'report': {
        // If already reported -> toggle unreport quickly
        var currentText = ($item.text() || '').toLowerCase().trim();
        var csrf = $("input[name='csrf_token']").val();
        var pid  = ($post.data('id') || '').toString();
        if (!pid) { ensureDzToast(); DZ.toast(I18N('ui_missing_parameters') || 'Missing parameters'); break; }
        if (currentText === 'unreport') {
          if (!csrf) { ensureDzToast(); DZ.toast(I18N('ui_missing_csrf') || 'Missing CSRF'); break; }
          if ($item.data('busy') === true) break;
          $item.data('busy', true);
          $.ajax({
            type: 'POST',
            url: (typeof window.buildUrl==='function'?buildUrl('request/requests.php'):((typeof site_url!=='undefined'?site_url:'' )+'request/requests.php')),
            dataType: 'json',
            data: { p: 'report_post', post_id: pid, csrf_token: csrf }
          }).done(function (res) {
            var ok = !!(res && (res.status === 'success' || res.success === true));
            var msg = (res && (res.message || res.msg)) || '';
            ensureDzToast();
            if (ok) {
              DZ.toast(msg || 'OK', { type: 'success', duration: 2000 });
              if (typeof res.reported !== 'undefined') {
                $item.text(res.reported ? 'Unreport' : 'Report');
              }
            } else {
              DZ.toast(msg || 'Error', { type: 'error', duration: 2200 });
            }
          }).fail(function () {
            ensureDzToast(); DZ.toast(I18N('ui_network_error') || 'Network error', { type: 'error', duration: 2200 });
          }).always(function () { $item.data('busy', false); });
          break;
        }

        // Otherwise open reasons popup
        var $reportPopup = $post.find('#postReportPopup-' + pid);
        if (!$reportPopup.length) { $reportPopup = $('#postReportPopup-' + pid); }
        if (!$reportPopup.length) { break; }
        // Load reasons once
        var loaded = ($reportPopup.find('.pr-list').data('loaded') || 0);
        if (!loaded) {
          var csr = $("input[name='csrf_token']").val();
          $.ajax({
            type: 'POST', url: (typeof window.buildUrl==='function'?buildUrl('request/requests.php'):((typeof site_url!=='undefined'?site_url:'' )+'request/requests.php')), dataType: 'json',
            data: { p: 'report_reasons', csrf_token: csr }
          }).done(function (res) {
            if (res && res.status === 'success' && Array.isArray(res.reasons)) {
              var $list = $reportPopup.find('.pr-list');
              $list.empty();
              res.reasons.forEach(function (r, idx) {
                var btn = $('<button/>', { 'class': 'pr-item', 'data-code': r.code || ('code_' + idx), text: r.label || r.code });
                $list.append(btn);
                $list.append('<div class="pr-sep"></div>');
              });
              $list.data('loaded', 1);
            }
          });
        }
        // Show reasons popup and keep menu open state consistent
        $reportPopup.removeClass('none').attr('aria-hidden', 'false');
        break; }
      case 'who-can-see':
        // Open visibility sheet, load options once
        var pidV = ($post.data('id') || '').toString();
        var $visPopup = $post.find('#postVisibilityPopup-' + pidV);
        if (!$visPopup.length) { $visPopup = $('#postVisibilityPopup-' + pidV); }
        if (!$visPopup.length) { break; }
        var $vList = $visPopup.find('.pv-list');
        var loadedV = ($vList.data('loaded') || 0);
        if (!loadedV) {
          var csrV = $("input[name='csrf_token']").val();
          $.ajax({
            type:'POST', url: (typeof window.buildUrl==='function'?buildUrl('request/requests.php'):((typeof site_url!=='undefined'?site_url:'' )+'request/requests.php')), dataType:'json',
            data: { p:'get_visibility_options', csrf_token: csrV }
          }).done(function(res){
            if (res && res.status==='success' && Array.isArray(res.options)) {
              $vList.empty();
              var current = String($post.data('visibility') || '').toLowerCase();
              res.options.forEach(function(o, i){
                var code = o.code || ('opt_'+i);
                var $btn = $('<button/>', { 'class': 'pv-item', 'data-code': code, text: o.label || code });
                if (code === current) $btn.addClass('is-active');
                $vList.append($btn);
                $vList.append('<div class="pv-sep"></div>');
              });
              $vList.data('loaded', 1);
            }
          });
        } else {
          // refresh active marker from current attribute
          var curr = String($post.data('visibility')||'').toLowerCase();
          $vList.find('.pv-item').each(function(){
            var $b=$(this); $b.toggleClass('is-active', String($b.data('code'))===curr);
          });
        }
        $visPopup.removeClass('none').attr('aria-hidden','false');
        break;
      case 'edit': {
        var pidE = ($post.data('id') || '').toString();
        var $ep = $post.find('#postEditPopup-' + pidE);
        if (!$ep.length) { $ep = $('#postEditPopup-' + pidE); }
        if ($ep.length) {
          var raw = ($post.data('text') || '').toString();
          $ep.find('.pe-text').val(raw);
          $ep.removeClass('none').attr('aria-hidden','false');
        }
        break; }
      case 'toggle-comments': {
        var pidC = ($post.data('id') || '').toString();
        var csrfC = $("input[name='csrf_token']").val();
        if (!pidC || !csrfC) { ensureDzToast(); DZ.toast(I18N('ui_missing_parameters') || 'Missing parameters'); break; }
        if ($item.data('busy') === true) break; $item.data('busy', true);
        $.ajax({
          type:'POST', url:(typeof window.buildUrl==='function'?buildUrl('request/requests.php'):((typeof site_url!=='undefined'?site_url:'' )+'request/requests.php')), dataType:'json',
          data:{ p:'toggle_comments', post_id: pidC, csrf_token: csrfC }
        }).done(function(res){
          var ok = !!(res && res.status==='success');
          var msg = (res && (res.message||res.msg)) || '';
          ensureDzToast();
          if (ok) {
            if (res.label) { $item.text(res.label); }
            // Update post attribute for guards
            $post.data('comments', res.comment_status);
            var $existing = $post.find('.make-comment');
            if (res.comment_status === 'off') {
              // Remove composer if exists
              $existing.remove();
              // Hide comment button/count box
              var $cBox = $post.find('.post-footer .post-button-comment').closest('.post-button-box');
              $cBox.hide();
              DZ.toast('Comments disabled', { type:'success', duration: 1800 });
            } else {
              // Ensure composer exists (inject if needed)
              if (!$existing.length && res.html) {
                var $footer = $post.find('.post-footer').first();
                if ($footer.length) { $footer.after($(res.html)); }
              }
              // Show comment button/count box
              var $cBox2 = $post.find('.post-footer .post-button-comment').closest('.post-button-box');
              $cBox2.show();
              DZ.toast('Comments enabled', { type:'success', duration: 1800 });
            }
          } else {
            DZ.toast(msg || 'Error', { type:'error', duration: 2200 });
          }
        }).fail(function(){ ensureDzToast(); DZ.toast(I18N('ui_network_error') || 'Network error', { type:'error', duration: 2200 }); })
          .always(function(){ $item.data('busy', false); });
        break; }
      case 'delete': {
        var pidD = ($post.data('id') || '').toString();
        var $dp = $post.find('#postDeletePopup-' + pidD);
        if (!$dp.length) { $dp = $('#postDeletePopup-' + pidD); }
        if ($dp.length) { $dp.removeClass('none').attr('aria-hidden','false'); }
        break; }
      case 'embed':
        keepOpen = true;
        // If disabled in menu item, show info
        if ($item.is('[disabled]') || $item.attr('aria-disabled') === 'true') {
          ensureDzToast(); DZ.toast((I18N('embed_not_public') || 'Embedding is available for public posts only'), { type: 'info', duration: 2000 });
          break;
        }
        (function(){
          var pidE = ($post.data('id') || '').toString();
          var $menuPP = $item.closest('.post-menu-popup');
          try { $menuPP.data('suppress-close', 1); } catch(_){ }
          var $epb = $post.find('#postEmbedPopup-' + pidE);
          if (!$epb.length) { $epb = $('#postEmbedPopup-' + pidE); }
          if (!$epb.length) { $epb = $('#postEmbedPopup-' + pidE + ', .post-embed-popup[data-post-id="' + pidE + '"]'); }
          // If still not found (some templates may not include per-post embed markup), create a lightweight overlay under #popup-root/body
          if (!$epb.length) {
            var host = document.getElementById('popup-root') || document.body;
            var wrap = document.createElement('div');
            wrap.className = 'post-embed-popup';
            wrap.setAttribute('data-post-id', pidE);
            wrap.innerHTML = ''+
              '<div class="pe-sheet-container">'+
              '  <div class="pe-sheet">'+
              '    <div class="pe-header">'+
              '      <div class="pe-title">' + (I18N('embed_title') || 'Embed This Post') + '</div>'+
              '      <div class="pe-sub">' + (I18N('embed_subtitle') || 'Copy the code below to embed on your site.') + '</div>'+
              '    </div>'+
              '    <div class="pe-body">'+
              '      <textarea class="peb-code" rows="4" readonly></textarea>'+
              '      <div class="pp-actions"><button type="button" class="peb-copy">' + (I18N('embed_copy_code') || 'Copy embed code') + '</button></div>'+
              '    </div>'+
              '  </div>'+
              '  <button type="button" class="pe-cancel">' + (I18N('menu_cancel') || 'Cancel') + '</button>'+
              '</div>';
            host.appendChild(wrap);
            $epb = $(wrap);
          }
          var embedUrl = (typeof site_url !== 'undefined' ? site_url : '') + 'embed/' + pidE;
          var code = '<iframe src="' + embedUrl + '" width="400" height="700" frameborder="0" allow="accelerometer; autoplay; encrypted-media; picture-in-picture; web-share" allowfullscreen></iframe>';
          $epb.find('.peb-code').val(code);
          // Defer to next tick to avoid any close-race
          setTimeout(function(){
            $epb.removeClass('none').attr('aria-hidden', 'false');
            try { $menuPP.removeData('suppress-close'); } catch(_){ $menuPP.data('suppress-close', 0); }
          }, 0);
        })();
        break;
      default:
        break;
    }
    if (!keepOpen) {
      hideAllPostMenus();
    }
  });
  function resolveContext(scope) {
    if (!scope) { return document; }
    if (scope.jquery) { scope = scope[0]; }
    if (scope.nodeType === 1 || scope.nodeType === 9 || scope.nodeType === 11) {
      return scope;
    }
    return document;
  }

  function initLockedPreviewVideos(scope) {
    var context = resolveContext(scope);
    if (!context || typeof context.querySelectorAll !== 'function') {
      context = document;
    }
    var nodes = context.querySelectorAll('video.locked-preview--video');
    if (!nodes || !nodes.length) {
      return;
    }
    for (var i = 0; i < nodes.length; i++) {
      var video = nodes[i];
      if (!video) { continue; }
      var alreadyInit = false;
      if (video.dataset && video.dataset.lockedPreviewInit === '1') {
        alreadyInit = true;
      } else if (video.getAttribute && video.getAttribute('data-locked-preview-init') === '1') {
        alreadyInit = true;
      }
      if (alreadyInit) { continue; }
      if (video.dataset) {
        video.dataset.lockedPreviewInit = '1';
      } else {
        video.setAttribute('data-locked-preview-init', '1');
      }
      if (typeof video.removeAttribute === 'function') {
        video.removeAttribute('loop');
      }
      var loopsAttr = video.getAttribute('data-max-locked-loops');
      var maxLoops = parseInt(loopsAttr, 10);
      if (!isFinite(maxLoops) || maxLoops <= 0) {
        maxLoops = 2;
      }
      (function (vid, allowedLoops) {
        var completed = 0;
        var stopped = false;
        vid.addEventListener('ended', function () {
          completed += 1;
          if (completed < allowedLoops) {
            try { vid.currentTime = 0; } catch (_) {}
            var resume = vid.play();
            if (resume && typeof resume.catch === 'function') {
              resume.catch(function(){});
            }
            return;
          }
          if (stopped) { return; }
          stopped = true;
          try {
            vid.pause();
            vid.currentTime = 0;
            vid.removeAttribute('autoplay');
          } catch (_) {}
          vid.setAttribute('data-locked-preview-stopped', '1');
          if (vid.classList) {
            vid.classList.add('locked-preview--stopped');
          }
          var parent = null;
          if (typeof vid.closest === 'function') {
            parent = vid.closest('.locked-preview-media');
          }
          if (!parent) {
            var el = vid.parentElement;
            while (el && (!el.classList || !el.classList.contains('locked-preview-media'))) {
              el = el.parentElement;
            }
            parent = el;
          }
          if (parent && parent.classList) {
            parent.classList.add('locked-preview-media--stopped');
          }
        });
      })(video, maxLoops);
    }
  }

  function bootLockedPreviewVideos(scope) {
    try {
      initLockedPreviewVideos(scope || document);
    } catch (err) {
      console.warn('Locked preview bootstrap failed', err);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      bootLockedPreviewVideos(document);
    });
  } else {
    bootLockedPreviewVideos(document);
  }

  $(document).on('posts:loaded', function (ev, payload) {
    var root = payload && payload.root ? payload.root : null;
    bootLockedPreviewVideos(root || document);
  });

  $(document).on('click', '.getChatList', function () {
    var id  = $(this).data('id');
    var csr = $('input[name="csrf_token"]').val();

    $.ajax({
      type: 'POST',
      url: buildUrl('request/requests.php'),
      dataType: 'json',
      data: {
        p: 'getChatList',
        id: id,
        csrf_token: csr
      },
      beforeSend: function(){
        $(".chat_list_box").empty();
      },
      success: function (res) {
        if (res.status === 'success') {
          $(".current_message_box").removeClass("none");
          // Populate chat panel (CSP-safe, loads external scripts inside)
          var box = $('.chat_list_box').get(0);
          injectHTMLWithScriptsInto(box, res.html).then(function(){
            try { document.dispatchEvent(new CustomEvent('chat:opened', { detail: { withId: res.chat_user_id || 0 } })); } catch(_){}
          });
          // Leave auto-scroll etc. to chat.js
        } else {
          console.warn(res.message || 'Load failed');
        }
      },
      error: function () {
        console.warn('Server error');
      }
    });
  });
  // Avatars are rendered server-side using RL_GetNewMessages; no client fetch needed
  $(document).on("click",".back-to", function(){
    $(".chat_list_box").empty();
    $(".current_message_box").addClass("none");
    if (window.chatController && typeof window.chatController.destroy === 'function') {
      window.chatController.destroy();
    }
  });
})(jQuery);
