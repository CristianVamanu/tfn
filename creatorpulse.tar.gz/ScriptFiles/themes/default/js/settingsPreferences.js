(function(){
  'use strict';

  function tr(key, fallback){
    try {
      if (window.DZ && typeof DZ.i18n === 'function') {
        var value = DZ.i18n(key);
        if (value) { return value; }
      }
    } catch (_) {}
    return fallback || '';
  }

  function buildUrl(path){
    try { if (typeof window.buildUrl === 'function') { return window.buildUrl(path); } } catch (_) {}
    try {
      var base = '';
      if (typeof window.site_url === 'string' && window.site_url) {
        base = window.site_url;
      } else {
        var origin = window.location.origin || ((window.location.protocol || 'http:') + '//' + (window.location.host || ''));
        base = origin + (window.location.pathname ? window.location.pathname.replace(/[^\/]*$/, '') : '/');
      }
      return new URL(String(path || ''), base).toString();
    } catch (_) {
      return String(path || '');
    }
  }

  function ensureLocalToast(){
    window.DZ = window.DZ || {};
    if (typeof window.DZ.toast === 'function') { return; }

    function container(){
      var id = 'dz-toast-container';
      var el = document.getElementById(id);
      if (!el) {
        el = document.createElement('div');
        el.id = id;
        el.className = 'dz-toast-container';
        document.body.appendChild(el);
      }
      return el;
    }

    window.DZ.toast = function(msg, opts){
      try {
        var cfg = opts || {};
        var kind = cfg.type === 'error' ? 'error' : (cfg.type === 'info' ? 'info' : 'success');
        var dur  = typeof cfg.duration === 'number' ? Math.max(1000, cfg.duration) : 2400;
        var host = container();

        var el = document.createElement('div');
        el.className = 'dz-toast ' + (kind === 'error' ? 'is-error' : (kind === 'info' ? 'is-info' : 'is-success'));
        el.setAttribute('role', 'status');
        el.setAttribute('aria-live', 'polite');
        el.textContent = String(msg || '');
        host.appendChild(el);

        requestAnimationFrame(function(){ el.classList.add('is-shown'); });
        setTimeout(function(){
          el.classList.remove('is-shown');
          setTimeout(function(){ if (el && el.parentNode) { el.parentNode.removeChild(el); } }, 220);
        }, dur);
      } catch (err) {
        if (typeof window.console !== 'undefined' && console.warn) {
          console.warn('Toast fallback failed', err);
        }
        window.alert(String(msg || ''));
      }
    };
  }

  function showToast(message, type){
    ensureLocalToast();
    try {
      if (window.DZ && typeof DZ.toast === 'function') {
        DZ.toast(String(message || ''), { type: type || 'info', duration: 2400 });
      }
    } catch (_) {
      try {
        window.alert(String(message || ''));
      } catch (_) {}
    }
  }

  function clearAlert(el){
    if (!el) { return; }
    el.textContent = '';
    el.classList.remove('is-error', 'is-success');
    el.style.display = 'none';
  }

  function disableWhile(btn, work){
    if (!btn) { return work(); }
    var previous = btn.textContent;
    btn.disabled = true;
    btn.textContent = tr('saving', 'Saving...');
    var done = Promise.resolve().then(work);
    var reset = function(){ btn.disabled = false; btn.textContent = previous; };
    if (typeof done.finally === 'function') { return done.finally(reset); }
    return done.then(function(value){ reset(); return value; }, function(err){ reset(); throw err; });
  }

  function toBool(value){ return !!value; }

  function mergePreferences(raw){
    var current = (window.DZ && window.DZ.userPreferences) ? Object.assign({}, window.DZ.userPreferences) : {};
    var boolKeys = ['feed_autoplay','feed_muted','notify_push','notify_email','notify_sms'];
    if (raw && typeof raw === 'object') {
      boolKeys.forEach(function(key){
        if (Object.prototype.hasOwnProperty.call(raw, key)) {
          current[key] = toBool(raw[key]);
        }
      });
      if (Object.prototype.hasOwnProperty.call(raw, 'language') && typeof raw.language === 'string') {
        current.language = raw.language;
      }
    }
    return current;
  }

  function applyPreferenceAttributes(prefs){
    var root = document.documentElement;
    if (!root) { return; }
    var boolKeys = ['feed_autoplay','feed_muted','notify_push','notify_email','notify_sms'];
    boolKeys.forEach(function(key){
      var value = prefs && Object.prototype.hasOwnProperty.call(prefs, key) ? !!prefs[key] : false;
      root.setAttribute('data-pref-' + key.replace(/_/g, '-'), value ? 'on' : 'off');
    });
    if (prefs && typeof prefs.language === 'string' && prefs.language) {
      root.setAttribute('data-pref-language', prefs.language);
    } else {
      root.removeAttribute('data-pref-language');
    }
  }

  function onReady(fn){
    if (document.readyState !== 'loading') { fn(); }
    else { document.addEventListener('DOMContentLoaded', fn); }
  }

  onReady(function(){
    var form = document.getElementById('settings-preferences-form');
    applyPreferenceAttributes((window.DZ && window.DZ.userPreferences) || {});
    if (!form) { return; }
    var alertBox = form.querySelector('.creator-form__alert');
    var submitBtn = form.querySelector('button[type="submit"]');
    clearAlert(alertBox);

    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      clearAlert(alertBox);

      disableWhile(submitBtn, function(){
        var fd = new FormData(form);
        if (!fd.has('p')) { fd.set('p', 'settings_update_preferences'); }

        var action = form.getAttribute('action') || buildUrl('request/requests.php');
        return fetch(action, {
          method: 'POST',
          body: fd,
          credentials: 'same-origin'
        })
          .then(function(res){
            return res.json().catch(function(){ return { status: 'error', message: 'INVALID_RESPONSE' }; });
          })
          .then(function(payload){
            if (payload && payload.status === 'success') {
              var successMsg = payload && payload.message ? payload.message : tr('settings_preferences_updated', 'Preferences updated.');
              clearAlert(alertBox);
              showToast(successMsg, 'success');
              if (payload.data && payload.data.preferences) {
                window.DZ = window.DZ || {};
                window.DZ.userPreferences = mergePreferences(payload.data.preferences);
                applyPreferenceAttributes(window.DZ.userPreferences);
                if (typeof DZ.initPostVideos === 'function') {
                  DZ.initPostVideos(document);
                }
              }
            } else {
              var msg = (payload && (payload.message || payload.error)) || tr('save_failed', 'Save failed.');
              clearAlert(alertBox);
              showToast(msg, 'error');
            }
          })
          .catch(function(){
            var netMsg = tr('network_error', 'Network error.');
            clearAlert(alertBox);
            showToast(netMsg, 'error');
          });
      });
    });
  });
})();
