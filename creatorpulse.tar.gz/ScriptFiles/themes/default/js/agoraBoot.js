'use strict';
(function(){
  try { if (typeof window.DZ_RTC_DISABLED === 'undefined') { window.DZ_RTC_DISABLED = false; } } catch(_){ }
  try { if (typeof window.DZ_RTM_DISABLED === 'undefined') { window.DZ_RTM_DISABLED = false; } } catch(_){ }

  function check(){
    try { if (typeof window.AgoraRTC === 'undefined') { window.DZ_RTC_DISABLED = true; } } catch(_){ try { window.DZ_RTC_DISABLED = true; } catch(e){} }
    try { if (typeof window.AgoraRTM === 'undefined') { window.DZ_RTM_DISABLED = true; } } catch(_){ try { window.DZ_RTM_DISABLED = true; } catch(e){} }
    // Optional UX hint
    try {
      if (window.DZ_RTM_DISABLED) {
        var msg = (window.DZ && typeof DZ.i18n==='function') ? (DZ.i18n('rtm_unavailable_offline')||'') : '';
        if (msg && window.DZ && typeof DZ.toast==='function') { DZ.toast(msg, { type: 'info', duration: 2400 }); }
      }
    } catch(_){ }
  }

  if (document.readyState === 'complete') { setTimeout(check, 0); }
  else { window.addEventListener('load', function(){ setTimeout(check, 0); }); }
})();

