(function () {
  'use strict';

  var DESKTOP_BREAKPOINT = 769;

  function pageOffsetTop(element) {
    var rect = element.getBoundingClientRect();
    return rect.top + (window.pageYOffset || document.documentElement.scrollTop || 0);
  }

  function wheelDelta(event) {
    if (event.deltaMode === 1) { return event.deltaY * 16; }
    if (event.deltaMode === 2) { return event.deltaY * window.innerHeight; }
    return event.deltaY;
  }

  function canScroll(element, deltaY) {
    var max = Math.max(element.scrollHeight - element.clientHeight, 0);
    if (max <= 0) { return false; }
    return deltaY < 0 ? element.scrollTop > 0 : element.scrollTop < max - 1;
  }

  function setImportantStyle(element, property, value) {
    if (!element) { return; }
    element.style.setProperty(property, value, 'important');
  }

  function nestedScrollableElementHandles(event, boundary, deltaY) {
    var target = event.target;
    if (!target || !boundary || target === boundary) { return false; }
    if (target.nodeType === 3) { target = target.parentElement; }
    while (target && target !== boundary) {
      if (target.nodeType === 1) {
        var styles = window.getComputedStyle(target);
        var overflowY = styles ? styles.overflowY : '';
        if ((overflowY === 'auto' || overflowY === 'scroll' || overflowY === 'overlay') && canScroll(target, deltaY)) {
          return true;
        }
      }
      target = target.parentElement;
    }
    return false;
  }

  function syncCompactHeader() {
    var siteContainer = document.querySelector('.site_container');
    if (!siteContainer) { return; }
    var scrollY = window.pageYOffset || document.documentElement.scrollTop || 0;
    siteContainer.classList.toggle('cp-header-scrolled', scrollY > 0);
  }

  function scrollPanel(state, deltaY) {
    if (!state.inner || !deltaY) { return false; }
    state.maxScroll = Math.max(state.inner.scrollHeight - state.inner.clientHeight, 0);
    if (state.maxScroll <= 0) { return false; }
    var next = Math.max(0, Math.min(state.inner.scrollTop + deltaY, state.maxScroll));
    if (next === state.inner.scrollTop) { return false; }
    state.inner.scrollTop = next;
    return true;
  }

  function createSidebarController(options) {
    var state = {
      root: null,
      inner: null,
      lockStart: 0,
      maxScroll: 0,
      unlockedMaxScroll: 0,
      unlockedHeight: 0,
      lockedHeight: 0,
      lockLeft: 0,
      lockWidth: 0,
      rootWidth: 0,
      lockPoint: 0,
      shortContent: false,
      locked: false,
      enabled: false,
      manualActive: false,
      ticking: false
    };

    function setInnerHeight(height) {
      if (!state.inner || height <= 0) { return; }
      setImportantStyle(state.inner, 'height', height + 'px');
      setImportantStyle(state.inner, 'max-height', height + 'px');
      state.maxScroll = Math.max(state.inner.scrollHeight - state.inner.clientHeight, 0);
    }

    function captureRootMetrics() {
      if (!state.root || !state.inner) { return; }
      var rootRect = state.root.getBoundingClientRect();
      var innerRect = state.inner.getBoundingClientRect();
      state.rootWidth = rootRect.width;
      state.lockLeft = innerRect.left;
      state.lockWidth = innerRect.width;
    }

    function lockRootMetrics() {
      if (!state.root || state.rootWidth <= 0) { return; }
      setImportantStyle(state.root, 'box-sizing', 'border-box');
      setImportantStyle(state.root, 'width', state.rootWidth + 'px');
      setImportantStyle(state.root, 'min-width', state.rootWidth + 'px');
      setImportantStyle(state.root, 'flex-basis', state.rootWidth + 'px');
      setImportantStyle(state.root, 'flex', '0 0 ' + state.rootWidth + 'px');
    }

    function syncFixedMetrics() {
      if (!state.root || !state.inner) { return; }
      if (state.lockWidth <= 0) { captureRootMetrics(); }
      state.inner.style.setProperty('--' + options.prefix + '-lock-left', state.lockLeft + 'px');
      state.inner.style.setProperty('--' + options.prefix + '-lock-width', state.lockWidth + 'px');
      if (options.lockAtTopWhenShort && state.shortContent) {
        state.inner.style.setProperty('--' + options.prefix + '-lock-top', options.topOffset + 'px');
        state.inner.style.setProperty('--' + options.prefix + '-lock-bottom', 'auto');
      } else {
        state.inner.style.setProperty('--' + options.prefix + '-lock-top', 'auto');
        state.inner.style.setProperty('--' + options.prefix + '-lock-bottom', options.bottomGap + 'px');
      }
    }

    function unlock() {
      if (!state.locked || !state.inner) { return; }
      state.root.style.removeProperty('width');
      state.root.style.removeProperty('min-width');
      state.root.style.removeProperty('flex-basis');
      state.root.style.removeProperty('flex');
      state.root.style.removeProperty('box-sizing');
      state.inner.classList.remove(options.lockClass);
      state.inner.style.removeProperty('--' + options.prefix + '-lock-top');
      state.inner.style.removeProperty('--' + options.prefix + '-lock-left');
      state.inner.style.removeProperty('--' + options.prefix + '-lock-width');
      state.inner.style.removeProperty('--' + options.prefix + '-lock-bottom');
      state.locked = false;
      state.lockPoint = 0;
    }

    function resetInlineStyles() {
      if (!state.root || !state.inner) { return; }
      unlock();
      state.root.style.removeProperty('--' + options.prefix + '-space');
      state.root.style.removeProperty('width');
      state.root.style.removeProperty('min-width');
      state.root.style.removeProperty('flex-basis');
      state.root.style.removeProperty('flex');
      state.root.style.removeProperty('box-sizing');
      state.inner.style.removeProperty('height');
      state.inner.style.removeProperty('max-height');
      state.inner.style.removeProperty('box-sizing');
      state.inner.style.removeProperty('overflow-y');
      state.inner.style.removeProperty('overflow-x');
      state.inner.style.removeProperty('overscroll-behavior');
      state.inner.style.removeProperty('padding-bottom');
      state.inner.scrollTop = 0;
      state.lockLeft = 0;
      state.lockWidth = 0;
      state.rootWidth = 0;
      state.lockPoint = 0;
      state.shortContent = false;
      state.locked = false;
      state.manualActive = false;
    }

    function apply() {
      if (!state.enabled || !state.root || !state.inner) { return; }

      var scrollY = window.pageYOffset || document.documentElement.scrollTop || 0;
      var viewportBottom = window.innerHeight - options.bottomGap;
      var innerRect = state.inner.getBoundingClientRect();
      var reachedBottom = innerRect.bottom <= viewportBottom + 1;

      // Let the complete sidebar travel with the document first. It becomes
      // fixed only after its own bottom reaches the viewport bottom.
      if (!state.locked && (!reachedBottom || scrollY <= 0)) {
        return;
      }

      // When the user scrolls back up, release the fixed panel as soon as its
      // natural document position is visible again.
      if (state.locked && scrollY < state.lockPoint - 1) {
        unlock();
        return;
      }

      if (!state.locked) {
        captureRootMetrics();
        lockRootMetrics();
        state.inner.classList.add(options.lockClass);
        state.lockPoint = scrollY;
        state.locked = true;
      }

      state.root.style.setProperty('--' + options.prefix + '-space', state.inner.scrollHeight + options.bottomGap + 'px');
      syncFixedMetrics();
    }

    function bindWheelBridge() {
      // Keep document scrolling as the source of truth. The scroll handler
      // above mirrors that movement into the fixed panel after its threshold.
    }

    function collect() {
      state.root = document.querySelector(options.rootSelector);
      state.inner = state.root ? state.root.querySelector(options.innerSelector) : null;
      state.enabled = false;
      if (!state.root || !state.inner) { return; }
      resetInlineStyles();
      bindWheelBridge();
      if (window.innerWidth < DESKTOP_BREAKPOINT) { return; }

      captureRootMetrics();
      state.unlockedMaxScroll = 0;
      state.maxScroll = 0;
      state.lockStart = pageOffsetTop(state.root);
      state.shortContent = state.inner.scrollHeight <= Math.max(window.innerHeight - options.topOffset, 0);
      state.enabled = options.lockWithoutInternalScroll
        ? state.inner.scrollHeight > 0
        : state.inner.scrollHeight > window.innerHeight;
      if (!state.enabled) { return; }
      state.root.style.setProperty('--' + options.prefix + '-space', state.inner.scrollHeight + options.bottomGap + 'px');
      apply();
    }

    function onScroll() {
      if (state.ticking) { return; }
      state.ticking = true;
      requestAnimationFrame(function () {
        apply();
        state.ticking = false;
      });
    }

  window.addEventListener('resize', collect);
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('load', collect);
  window.addEventListener('scroll', syncCompactHeader, { passive: true });
  window.addEventListener('load', syncCompactHeader);
  syncCompactHeader();
  collect();
    setTimeout(collect, 600);
  }

  createSidebarController({
    rootSelector: '.sidebar.sidebar--left',
    innerSelector: '.sidebar__inner',
    prefix: 'cp-ls',
    lockClass: 'ls-locked',
    wheelAttribute: 'data-cp-left-wheel-bridge',
    topOffset: 72,
    bottomGap: 20
  });

  createSidebarController({
    rootSelector: '.content-right',
    innerSelector: '.content-right-container',
    prefix: 'cp-rs',
    lockClass: 'rs-locked',
    wheelAttribute: 'data-cp-right-wheel-bridge',
    topOffset: 72,
    // Keep the right panel aligned with the left panel when it locks.
    bottomGap: 20,
    lockWithoutInternalScroll: true,
    lockAtTopWhenShort: true
  });
})();
