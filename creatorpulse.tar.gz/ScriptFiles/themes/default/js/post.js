(function ($) {
  'use strict';
  var I18N =
    window.DZ && typeof DZ.i18n === 'function'
      ? DZ.i18n
      : function () {
          return '';
        };
  // Ensure DZ.toast exists even if main.js hasn't initialized it yet (fallback)
  function ensureDzToast() {
    window.DZ = window.DZ || {};
    if (typeof DZ.toast === 'function') {
      return;
    }

    // Only ensure a container; DO NOT inject any <style> (Envato policy)
    function ensureContainer() {
      var id = 'dz-toast-container';
      var el = document.getElementById(id);
      if (!el) {
        el = document.createElement('div');
        el.id = id;
        el.className = 'dz-toast-container'; // styled in external CSS
        document.body.appendChild(el);
      }
      return el;
    }

    /**
     * Show a small toast message near the top-right of the screen.
     * Relies on external CSS classes:
     *  .dz-toast-container, .dz-toast, .dz-toast.is-shown,
     *  .dz-toast.is-success, .dz-toast.is-error, .dz-toast.is-info
     * @param {string} msg
     * @param {{type?: 'success'|'error'|'info', duration?: number}} [opts]
     */
    DZ.toast = function (msg, opts) {
      try {
        var container = ensureContainer();
        var opt = opts || {};
        var kind =
          opt.type === 'error' || opt.type === 'info' ? opt.type : 'success';
        var dur =
          typeof opt.duration === 'number'
            ? Math.max(1000, opt.duration)
            : 2200;

        var el = document.createElement('div');
        el.className =
          'dz-toast ' +
          (kind === 'error'
            ? 'is-error'
            : kind === 'info'
              ? 'is-info'
              : 'is-success');
        el.setAttribute('role', 'status');
        el.setAttribute('aria-live', 'polite');
        el.textContent = String(msg || '');
        container.appendChild(el);

        // Enter (use CSS transition bound to .is-shown)
        requestAnimationFrame(function () {
          el.classList.add('is-shown');
        });

        // Leave
        setTimeout(function () {
          el.classList.remove('is-shown');
          setTimeout(function () {
            if (el && el.parentNode) {
              el.parentNode.removeChild(el);
            }
          }, 220); // keep in sync with CSS transition
        }, dur);
      } catch (err) {
        if (window.console && console.warn)
          console.warn('DZ.toast fallback failed:', err);
      }
    };
  }

  /**
   * -------------------------------------------------------------
   *  SVG Heart Like Effect + AJAX Toggle (Developer Notes)
   *  - On LIKE: plays bounce -> smooth sway while floating up -> fade out
   *  - On UNLIKE: no animation, only AJAX toggle
   *  - Architecture:
   *      .like-fx-layer     : absolute overlay inside each .post_
   *      .like-heart-wrap   : full-size overlay wrapper (100% x 100%)
   *      .like-heart-box    : fixed-size host (prevents clipping)
   *      .like-heart-svg    : Instagram-style heart SVG (gradient)
   *      .like-heart-core   : runs CSS bounce keyframes
   *      .like-heart-sway   : moved by requestAnimationFrame for silky sway
   *      .like-heart-tilt   : random static tilt (-20°, 0°, +20°)
   *  - Performance: only transforms & opacity are animated (GPU-friendly)
   *  - Dependencies: jQuery, CSS classes/keyframes defined in theme CSS
   * -------------------------------------------------------------
   */

  // Tunables (keep JS/CSS durations in sync)
  var SWAY_DURATION_MS = 1000; // match your float duration for sync feel
  var SWAY_AMPLITUDE_PX = 9; // lateral sway amplitude in pixels
  var SWAY_CYCLES = 1.25; // number of sine cycles during the float

  function createSvgHeart() {
    return (
      '<svg class="like-heart-svg" aria-label="Like" viewBox="0 0 48 48" width="128" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
      '<title>Like</title>' +
      '<defs>' +
      '<linearGradient gradientTransform="rotate(35)" id="ig_heart_gradient">' +
      '<stop offset="0%"  stop-color="#FF7A00"></stop>' +
      '<stop offset="40%" stop-color="#FF0169"></stop>' +
      '<stop offset="100%" stop-color="#D300C5"></stop>' +
      '</linearGradient>' +
      '</defs>' +
      '<g class="like-heart-sway">' +
      '<g class="like-heart-tilt">' +
      '<g class="like-heart-core">' +
      '<path d="M34.6 3.1c-4.5 0-7.9 1.8-10.6 5.6-2.7-3.7-6.1-5.5-10.6-5.5C6 3.1 0 9.6 0 17.6c0 7.3 5.4 12 10.6 16.5.6.5 1.3 1.1 1.9 1.7l2.3 2c4.4 3.9 6.6 5.9 7.6 6.5.5.3 1.1.5 1.6.5s1.1-.2 1.6-.5c1-.6 2.8-2.2 7.8-6.8l2-1.8c.7-.6 1.3-1.2 2-1.7C42.7 29.6 48 25 48 17.6c0-8-6-14.5-13.4-14.5z" fill="url(#ig_heart_gradient)"></path>' +
      '</g>' +
      '</g>' +
      '</g>' +
      '</svg>'
    );
  }

  /**
   * Smooth lateral sway using requestAnimationFrame.
   * - Sine-based trajectory with light damping for a natural feel.
   * - Stops automatically if the element is detached from the DOM.
   * @param {HTMLElement} el          Element to translate on X axis.
   * @param {number}      durationMs  Total duration in ms.
   * @param {number}      amplitudePx Peak horizontal offset in px.
   * @param {number}      cycles      Number of sine cycles.
   */
  function runSway(el, durationMs, amplitudePx, cycles) {
    var start = null,
      stopped = false;

    function step(ts) {
      if (stopped) return;
      if (!start) start = ts;
      var t = (ts - start) / durationMs;
      if (t > 1) t = 1;

      // sin(2π * cycles * t) with slight damping so motion settles near the end
      var x = Math.sin(t * Math.PI * 2 * cycles) * amplitudePx * (1 - 0.15 * t);
      el.style.transform = 'translateX(' + x.toFixed(2) + 'px)';

      if (t < 1) requestAnimationFrame(step);
    }

    // Stop gracefully if the element is removed
    var observer = new MutationObserver(function () {
      if (!document.body.contains(el)) {
        stopped = true;
        observer.disconnect();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });

    requestAnimationFrame(step);
  }

  function requestEndpoint() {
    return typeof window.buildUrl === 'function'
      ? buildUrl('request/requests.php')
      : (typeof site_url !== 'undefined' ? site_url : '') +
          'request/requests.php';
  }

  function getCsrfToken() {
    return $("input[name='csrf_token']").val() || '';
  }

  function updateCommentCountUI($context, total) {
    if (typeof total === 'undefined' || total === null) {
      return;
    }
    var count = Number(total);
    if (Number.isNaN(count) || count < 0) {
      count = 0;
    }
    var $postRoot =
      $context && $context.length ? $context.closest('.post_') : $();
    if ((!$postRoot || !$postRoot.length) && $context && $context.length) {
      var postId = $context.data('post-id');
      if (postId) {
        $postRoot = $('.post_[data-id="' + postId + '"]').first();
        if (!$postRoot.length) {
          $postRoot = $('#post-' + postId);
        }
      }
    }
    if (!$postRoot || !$postRoot.length) {
      return;
    }

    var $counter = $postRoot.find('.total-comment.commentCount').first();
    if ($counter.length) {
      var commentLabel =
        count === 1
          ? (I18N('comment_singular') || I18N('comment') || 'Comment')
          : (I18N('comments') || 'Comments');
      var $mv = $counter.find('.metric-value').first();
      if ($mv.length) {
        $mv.text(String(count));
        $counter.find('.metric-label').first().text(' ' + commentLabel);
      } else {
        $counter.text(String(count) + ' ' + commentLabel);
      }
    }
  }

  function setCommentReportState($comment, $btn, reported) {
    var flag = reported ? '1' : '0';
    if ($btn && $btn.length) {
      $btn.attr('data-reported', flag);
      $btn.toggleClass('is-reported', reported);
      var label = reported
        ? I18N('ui_unreport') || I18N('menu_unreport') || 'Unreport'
        : I18N('menu_report') || 'Report';
      $btn.text(label);
    }
    if ($comment && $comment.length) {
      $comment.attr('data-comment-reported', flag);
    }
  }

  function openCommentPopup($popup) {
    if (!$popup || !$popup.length) {
      return;
    }
    $popup.removeClass('none').attr('aria-hidden', 'false');
    $('body').addClass('comment-popup-visible');
    var $textarea = $popup.find('textarea').first();
    if ($textarea.length) {
      setTimeout(function () {
        $textarea.trigger('focus');
      }, 20);
    }
  }

  function closeCommentPopup($popup) {
    if (!$popup || !$popup.length) {
      return;
    }
    $popup.addClass('none').attr('aria-hidden', 'true');
    if (
      $(
        '.comment-edit-popup:not(.none), .comment-delete-popup:not(.none), .comment-report-popup:not(.none)',
      ).length === 0
    ) {
      $('body').removeClass('comment-popup-visible');
    }
  }

  function closeAllCommentPopups() {
    $('.comment-edit-popup, .comment-delete-popup, .comment-report-popup').each(
      function () {
        closeCommentPopup($(this));
      },
    );
  }

  // Delegated handler supports dynamically injected posts as well
  $(document).on('click', '.post_ .p_like', function () {
    var $btn = $(this);
    var $post = $btn.closest('.post_');
    var $layer = $post.find('.like-fx-layer'); // may be missing; AJAX still proceeds

    // Read params
    var postId = $btn.attr('post-id');
    var csrfToken = $("input[name='csrf_token']").val();
    if (!postId || !csrfToken) {
      console.warn('Missing post-id or CSRF token.');
      return;
    }

    // Prevent rapid double submissions per button
    if ($btn.data('likeBusy') === true) return;
    $btn.data('likeBusy', true);

    // Determine UNLIKE (no animation) vs LIKE (play animation)
    var isUnlike = $btn.hasClass('is-liked');

    // LIKE animation (skipped for UNLIKE)
    if (!isUnlike && $layer.length) {
      var $wrap = $('<div/>', { class: 'like-heart-wrap' });
      var $box = $('<div/>', {
        class: 'like-heart-box flex align_items_justify_content',
      });
      var $svg = $(createSvgHeart());

      // Pick a random tilt angle
      var tilts = [-20, 0, 20];
      var tilt = tilts[Math.floor(Math.random() * tilts.length)];
      $svg
        .find('.like-heart-tilt')[0]
        .style.setProperty('--tilt', tilt + 'deg');

      // Mount nodes
      $box.append($svg);
      $wrap.append($box);
      $layer.append($wrap);

      // Kick CSS bounce + float; JS drives sway
      /* eslint-disable no-unused-expressions */
      $wrap[0]
        .offsetHeight; /* reflow */ /* eslint-enable no-unused-expressions */
      $wrap.addClass('run'); // float + fade (CSS)
      $svg.find('.like-heart-core').addClass('run'); // bounce (CSS)
      runSway(
        $svg.find('.like-heart-sway')[0],
        SWAY_DURATION_MS,
        SWAY_AMPLITUDE_PX,
        SWAY_CYCLES,
      ); // sway (RAF)

      // Cleanup overlay after animations end
      $wrap.on('animationend webkitAnimationEnd oAnimationEnd', function () {
        setTimeout(
          function () {
            $(this).remove();
          }.bind(this),
          2000,
        );
      });
    }

    // AJAX: toggle like/unlike on the server
    $.ajax({
      type: 'POST',
      url:
        typeof window.buildUrl === 'function'
          ? buildUrl('request/requests.php')
          : (typeof site_url !== 'undefined' ? site_url : '') +
            'request/requests.php',
      dataType: 'json',
      data: {
        p: 'like_post',
        post_id: postId,
        csrf_token: csrfToken,
      },
    })
      .done(function (res) {
        if (res && res.success) {
          // Update the counter (prefer .metric-value span if present)
          var $countEl = $btn.closest('.post-button-box').find('.total-like');
          var $mv = $countEl.find('.metric-value').first();
          if ($mv.length) {
            $mv.text(String(res.likes));
          } else {
            // Legacy: build string preserving any cached label
            if (!$countEl.data('like-label')) {
              var parts = ($countEl.text() || '').trim().split(/\s+/);
              if (parts.length > 1) parts.shift(); // drop numeric head once
              $countEl.data('like-label', parts.join(' '));
            }
            var label = $countEl.data('like-label');
            $countEl.text(String(res.likes) + (label ? ' ' + label : ''));
          }

          // Icon state: flip class according to server result
          if (res.liked) $btn.addClass('is-liked');
          else $btn.removeClass('is-liked');
        } else {
          console.warn(
            res && res.message ? res.message : 'Like request failed.',
          );
        }
      })
      .fail(function (xhr) {
        console.error(
          'AJAX error:',
          xhr && xhr.responseText ? xhr.responseText : xhr,
        );
      })
      .always(function () {
        $btn.data('likeBusy', false);
      });
  });
  // Delegated handler: submit a new comment
  $(document).on('click', '.sendComment', function () {
    var $btn = $(this);
    var postId = $btn.data('post-id');
    var $composer = $btn.closest('.make-comment');
    var $ta = $composer.find(".write-comment[data-post-id='" + postId + "']").first();
    if (!$ta.length) {
      $ta = $(".write-comment[data-post-id='" + postId + "']").first();
    }
    var csrf = $("input[name='csrf_token']").val();

    if (!postId || !$ta.length) {
      console.warn('Comment box not found.');
      return;
    }
    if (!csrf) {
      console.warn('Missing CSRF token.');
      return;
    }

    // NOTE: Do not block empty text here; let the server validate to get translated message
    var raw = ($ta.val() || '').toString();

    // Prevent rapid double submissions for this button
    if ($btn.data('cBusy') === true) {
      return;
    }
    $btn.data('cBusy', true);

    var commentSuccess = function (res) {
      ensureDzToast();
      DZ.toast((res && (res.message || res.msg)) || I18N('ui_ok') || 'OK', {
        type: 'success',
        duration: 2200,
      });

      $ta.val('');
      if ($composer.length) {
        $composer
          .removeClass('is-replying')
          .removeAttr('data-reply-to')
          .find('[data-role="comment-reply-context"]')
          .addClass('none');
        $composer.find('[data-role="comment-reply-name"]').text('');
      }

      if (res && res.html) {
        var $postRoot = $btn.closest('.post_');
        var $list = $postRoot
          .find(
            ".comments-list[data-post-id='" +
              postId +
              "'], " +
              ".post-comments-container[data-post-id='" +
              postId +
              "'], " +
              ".post-comments[data-post-id='" +
              postId +
              "']",
          )
          .first();
        if (!$list.length) {
          $list = $postRoot.find('.post-comments').first();
        }

        if ($list.length) {
          var $node = $(res.html);
          $node.hide();
          $list.append($node);
          $node.fadeIn(150);
        } else {
          var $fallbackComposer = $postRoot.find('.make-comment').first();
          if ($fallbackComposer.length) {
            $fallbackComposer.before(res.html);
          }
        }
      }

      $ta.trigger('input').focus();

      if (typeof res.total_comments !== 'undefined') {
        updateCommentCountUI($btn, res.total_comments);
      }
    };

    var toastError = function (message) {
      ensureDzToast();
      DZ.toast(message || I18N('ui_error') || 'Error', {
        type: 'error',
        duration: 2600,
      });
    };

    $.ajax({
      type: 'POST',
      url:
        typeof window.buildUrl === 'function'
          ? buildUrl('request/requests.php')
          : (typeof site_url !== 'undefined' ? site_url : '') +
            'request/requests.php',
      dataType: 'json',
      data: {
        p: 'add_comment',
        post_id: postId,
        comment: raw,
        csrf_token: csrf,
      },
    })
      .done(function (res) {
        var ok = !!(res && (res.status === 'success' || res.success === true));
        if (ok) {
          commentSuccess(res);
        } else {
          toastError((res && (res.message || res.msg)) || '');
        }
      })
      .fail(function (xhr, textStatus, errorThrown) {
        var errText = xhr && xhr.responseText ? xhr.responseText : '';

        ensureDzToast();
        DZ.toast(I18N('ui_network_error') || 'Network error', {
          type: 'error',
          duration: 2600,
        });
        console.error('AJAX error:', errText || xhr, textStatus, errorThrown);
      })
      .always(function () {
        $btn.data('cBusy', false);
      });
  });

  // Submit comments with Enter while preserving Shift+Enter for line breaks.
  $(document).on('keydown', '.write-comment', function (e) {
    if (e.key !== 'Enter' || e.shiftKey || e.isComposing) {
      return;
    }

    e.preventDefault();
    var $textarea = $(this);
    var postId = $textarea.data('post-id');
    var $composer = $textarea.closest('.make-comment');
    var $sendButton = $composer.find(".sendComment[data-post-id='" + postId + "']").first();

    if (!$sendButton.length) {
      $sendButton = $(".sendComment[data-post-id='" + postId + "']").first();
    }

    if ($sendButton.length && $sendButton.data('cBusy') !== true) {
      $sendButton.trigger('click');
    }
  });

  // Delegated handler: load all remaining comments (excluding the first 3 already shown)
  $(document).on('click', '.seeAllComment', function () {
    var $btn = $(this);
    var postId = $btn.data('id');
    // Normalize postId to digits only to avoid issues like " 42" or "42\n"
    postId = String(postId || '').trim();
    postId = postId.match(/\d+/) ? postId.match(/\d+/)[0] : '';
    var csrf = $("input[name='csrf_token']").val();

    if (!postId) {
      console.warn('seeAllComment: missing post id');
      return;
    }
    if (!csrf) {
      console.warn('seeAllComment: missing CSRF token');
      return;
    }

    if ($btn.data('busy') === true) {
      return;
    }
    $btn.data('busy', true);

    $.ajax({
      type: 'POST',
      url:
        typeof window.buildUrl === 'function'
          ? buildUrl('request/requests.php')
          : (typeof site_url !== 'undefined' ? site_url : '') +
            'request/requests.php',
      dataType: 'json',
      data: {
        p: 'get_comments',
        post_id: postId,
        csrf_token: csrf,
      },
    })
      .done(function (res) {
        var ok = !!(res && (res.status === 'success' || res.success === true));
        var msg = (res && (res.message || res.msg)) || '';

        if (ok) {
          // Append returned comments into the dedicated container for this post (robust lookup)
          var $root = $btn.closest('.post_');
          var numericId = (postId || '').toString();

          // Primary: target by #comments-<id> .post-comments or by .post-comment-<id>
          var $host = $(
            '#comments-' +
              numericId +
              ' .post-comments, .post-comment-' +
              numericId,
          ).first();

          // Secondary: search within the current post block
          if (!$host.length && $root.length) {
            $host = $root
              .find(
                '#comments-' +
                  numericId +
                  ' .post-comments, .post-comment-' +
                  numericId,
              )
              .first();
          }

          // Tertiary: try #post-<id> root then its .post-comments
          if (!$host.length) {
            var $postRoot = $('#post-' + numericId);
            if ($postRoot.length) {
              var $inner = $postRoot.find('.post-comments').first();
              if ($inner.length) {
                $host = $inner;
              }
            }
          }

          if ($host.length) {
            if (res.html) {
              var $nodes = $(res.html);
              $nodes.hide();
              $host.append($nodes);
              $nodes.fadeIn(150);
            } else {
              // No remaining comments to append (avoid misleading warning)
              console.info(
                'seeAllComment: no more comments for post',
                numericId,
              );
            }
          } else {
            console.warn(
              'seeAllComment: container not found in DOM for post',
              numericId,
              'tried:',
              '.post-comment-' + numericId,
              '#comments-' + numericId,
            );
          }

          // Hide the trigger button after successful load
          $btn.slideUp(120);

          ensureDzToast();
          if (msg) {
            DZ.toast(msg, { type: 'success', duration: 2000 });
          }
        } else {
          ensureDzToast();
          DZ.toast(msg || I18N('ui_error') || 'Error', {
            type: 'error',
            duration: 2600,
          });
        }
      })
      .fail(function (xhr) {
        var errText = xhr && xhr.responseText ? xhr.responseText : '';
        ensureDzToast();
        DZ.toast(I18N('ui_network_error') || 'Network error', {
          type: 'error',
          duration: 2600,
        });
        console.error('seeAllComment AJAX error:', errText || xhr);
      })
      .always(function () {
        $btn.data('busy', false);
      });
  });
  // Delegated handler: save/unsave (bookmark) a post
  $(document).on('click', '.book_post', function () {
    var $btn = $(this);
    var postId = $btn.data('id');
    var type = $btn.data('type') || 'image';
    var csrf = $("input[name='csrf_token']").val();

    if (!postId || !csrf) {
      console.warn('bookmark: missing params');
      return;
    }
    if ($btn.data('busy') === true) {
      return;
    }
    $btn.data('busy', true);

    // --- Optimistic UI: toggle immediately, revert on failure/mismatch ---
    var wasSaved = $btn.hasClass('p_saved');
    var optimisticState = !wasSaved; // what user expects after this click

    function applyState(toSaved) {
      if (toSaved) {
        $btn.removeClass('p_save').addClass('p_saved');
        swapIcon(true);
      } else {
        $btn.removeClass('p_saved').addClass('p_save');
        swapIcon(false);
      }
    }

    // Helper: swap icon between save.svg <-> saved.svg (robust for <img> inside)
    function swapIcon(toSaved) {
      var $img = $btn.find('img').first();
      if ($img.length) {
        var src = $img.attr('src') || '';
        // If custom paths are used, just replace the filename part
        if (toSaved) {
          $img.attr('src', src.replace(/save\.svg(\?.*)?$/i, 'saved.svg$1'));
        } else {
          $img.attr('src', src.replace(/saved\.svg(\?.*)?$/i, 'save.svg$1'));
        }
        // For caching issues, you may append a tiny cache-buster if needed
      }
    }

    // Apply optimistic change now
    applyState(optimisticState);

    $.ajax({
      type: 'POST',
      url:
        typeof window.buildUrl === 'function'
          ? buildUrl('request/requests.php')
          : (typeof site_url !== 'undefined' ? site_url : '') +
            'request/requests.php',
      dataType: 'json',
      data: {
        p: 'toggle_bookmark',
        post_id: postId,
        item_type: type,
        csrf_token: csrf,
      },
    })
      .done(function (res) {
        var ok = !!(res && (res.status === 'success' || res.success === true));
        var msg = (res && (res.message || res.msg)) || '';

        if (ok && res && typeof res.bookmarked !== 'undefined') {
          // If server result differs from optimistic state, correct the UI
          if (res.bookmarked !== optimisticState) {
            applyState(res.bookmarked);
          }
          ensureDzToast();
          if (msg) {
            DZ.toast(msg, { type: 'success', duration: 2000 });
          }
        } else {
          // Unknown response -> revert to previous state
          applyState(wasSaved);
          ensureDzToast();
          DZ.toast(msg || I18N('ui_error') || 'Error', {
            type: 'error',
            duration: 2400,
          });
        }
      })
      .fail(function (xhr) {
        // Revert optimistic change on network error
        applyState(wasSaved);
        ensureDzToast();
        DZ.toast(I18N('ui_network_error') || 'Network error', {
          type: 'error',
          duration: 2400,
        });
        console.error('bookmark AJAX error:', (xhr && xhr.responseText) || xhr);
      })
      .always(function () {
        $btn.data('busy', false);
      });
  });
  // Delegated handler: like/unlike a comment
  $(document).on('click', '.like_comment', function () {
    var $btn = $(this);
    var csrf = $("input[name='csrf_token']").val();
    var pid = $btn.data('id'); // post id
    var cid = $btn.data('comment'); // comment id
    var type = $btn.data('type') || 'video'; // optional, defaults to 'video'

    if (!csrf || !pid || !cid) {
      console.warn('like_comment: missing params');
      return;
    }
    if ($btn.data('busy') === true) {
      return;
    }
    $btn.data('busy', true);

    $.ajax({
      type: 'POST',
      url:
        typeof window.buildUrl === 'function'
          ? buildUrl('request/requests.php')
          : (typeof site_url !== 'undefined' ? site_url : '') +
            'request/requests.php',
      dataType: 'json',
      data: {
        p: 'like_comment',
        post_id: pid,
        comment_id: cid,
        item_type: type,
        csrf_token: csrf,
      },
    })
      .done(function (res) {
        if (res && res.success) {
          // Toggle button state
          if (res.liked) {
            $btn.addClass('is-liked');
          } else {
            $btn.removeClass('is-liked');
          }

          // If you show a side heart icon per comment, toggle a state class on it
          var $heart = $('.c_comment_' + cid);
          if ($heart.length) {
            if (res.liked) {
              $heart.addClass('is-liked');
            } else {
              $heart.removeClass('is-liked');
            }
          }

          // Optional: if you have a like count per comment, update it here:
          // Example selectors you might be using:
          //   .comment-like-count[data-comment-id="<cid>"]
          var $count = $('[data-comment-id="' + cid + '"].comment-like-count');
          if ($count.length && typeof res.likes !== 'undefined') {
            var n = Number(res.likes);
            if (isNaN(n) || n <= 0) {
              // Hide numeric text for zero/invalid by clearing content
              $count.text('');
            } else {
              $count.text(String(n));
            }
          }
        } else {
          ensureDzToast();
          DZ.toast((res && res.message) || 'Error', {
            type: 'error',
            duration: 2400,
          });
        }
      })
      .fail(function (xhr) {
        ensureDzToast();
        DZ.toast('Network error', { type: 'error', duration: 2400 });
        console.error(
          'like_comment AJAX error:',
          (xhr && xhr.responseText) || xhr,
        );
      })
      .always(function () {
        $btn.data('busy', false);
      });
  });

  // Delegated handler: report/unreport a comment (popup with reasons)
  $(document).on('click', '.comment-report', function () {
    var $btn = $(this);
    if ($btn.data('busy') === true) {
      return;
    }

    var $comment = $btn.closest('.post-comment');
    var commentId =
      $btn.data('comment-id') ||
      ($comment.length ? $comment.data('comment-id') : null);
    var postId =
      $btn.data('post-id') ||
      ($comment.length ? $comment.data('post-id') : null);

    if (!commentId || !postId) {
      ensureDzToast();
      DZ.toast(I18N('ui_missing_parameters') || 'Missing parameters.', {
        type: 'error',
        duration: 2200,
      });
      return;
    }

    var reported =
      String(
        $btn.attr('data-reported') ||
          ($comment.length ? $comment.attr('data-comment-reported') : '0'),
      ) === '1';

    if (reported) {
      var csrfToggle = getCsrfToken();
      if (!csrfToggle) {
        ensureDzToast();
        DZ.toast(I18N('ui_missing_csrf') || 'Missing CSRF token.', {
          type: 'error',
          duration: 2200,
        });
        return;
      }
      $btn.data('busy', true);
      $.ajax({
        type: 'POST',
        url: requestEndpoint(),
        dataType: 'json',
        data: {
          p: 'report_comment',
          comment_id: commentId,
          post_id: postId,
          csrf_token: csrfToggle,
        },
      })
        .done(function (res) {
          var ok = !!(
            res &&
            (res.status === 'success' || res.success === true)
          );
          var msg = (res && (res.message || res.msg)) || '';
          ensureDzToast();
          if (ok) {
            var $commentRef = $comment.length
              ? $comment
              : $('#comment-' + commentId);
            setCommentReportState($commentRef, $btn, !!res.reported);
            DZ.toast(
              msg ||
                (res.reported
                  ? I18N('comment_reported') || 'Comment reported.'
                  : I18N('comment_report_removed') || 'Report removed.'),
              { type: res.reported ? 'success' : 'info', duration: 2200 },
            );
          } else {
            DZ.toast(msg || I18N('ui_error') || 'Error', {
              type: 'error',
              duration: 2400,
            });
          }
        })
        .fail(function (xhr) {
          ensureDzToast();
          DZ.toast(I18N('ui_network_error') || 'Network error', {
            type: 'error',
            duration: 2400,
          });
          if (window.console && console.error) {
            console.error(
              'report_comment AJAX error:',
              xhr && xhr.responseText ? xhr.responseText : xhr,
            );
          }
        })
        .always(function () {
          $btn.data('busy', false);
        });
      return;
    }

    var $popup = $('#commentReportPopup-' + commentId);
    if (!$popup.length && $comment.length) {
      $popup = $comment.find('#commentReportPopup-' + commentId);
    }
    if (!$popup.length) {
      return;
    }

    var $list = $popup.find('.cr-list');
    var loaded = Number($list.data('loaded') || 0);
    var loading = Number($list.data('loading') || 0);
    if (!loaded && !loading) {
      var csrfReasons = getCsrfToken();
      if (!csrfReasons) {
        ensureDzToast();
        DZ.toast(I18N('ui_missing_csrf') || 'Missing CSRF token.', {
          type: 'error',
          duration: 2200,
        });
      } else {
        $list.data('loading', 1);
        $.ajax({
          type: 'POST',
          url: requestEndpoint(),
          dataType: 'json',
          data: { p: 'report_reasons', csrf_token: csrfReasons },
        })
          .done(function (res) {
            if (res && res.status === 'success' && Array.isArray(res.reasons)) {
              $list.empty();
              res.reasons.forEach(function (r, idx) {
                var code = r.code || 'code_' + idx;
                var label = r.label || code;
                var $item = $('<button/>', {
                  class: 'cr-item',
                  'data-code': code,
                  text: label,
                });
                $list.append($item);
                if (idx !== res.reasons.length - 1) {
                  $list.append('<div class="cr-sep"></div>');
                }
              });
              $list.data('loaded', 1);
            } else {
              $list.data('loaded', 0);
              ensureDzToast();
              DZ.toast((res && res.message) || I18N('ui_error') || 'Error', {
                type: 'error',
                duration: 2200,
              });
            }
          })
          .fail(function (xhr) {
            $list.data('loaded', 0);
            ensureDzToast();
            DZ.toast(I18N('ui_network_error') || 'Network error', {
              type: 'error',
              duration: 2200,
            });
            if (window.console && console.error) {
              console.error(
                'report_reasons AJAX error:',
                xhr && xhr.responseText ? xhr.responseText : xhr,
              );
            }
          })
          .always(function () {
            $list.data('loading', 0);
          });
      }
    }

    openCommentPopup($popup);
  });

  $(document).on('click', '.comment-report-popup .cr-cancel', function () {
    closeCommentPopup($(this).closest('.comment-report-popup'));
  });

  $(document).on('click', '.comment-report-popup', function (ev) {
    var $target = $(ev.target);
    if ($target.closest('.cr-sheet-container').length === 0) {
      closeCommentPopup($(this));
    }
  });

  $(document).on('click', '.comment-report-popup .cr-item', function () {
    var $item = $(this);
    var $popup = $item.closest('.comment-report-popup');
    if ($popup.data('busy') === true) {
      return;
    }

    var code = $item.data('code');
    var commentId = $popup.data('comment-id');
    var postId = $popup.data('post-id');
    var csrf = getCsrfToken();

    if (!code || !commentId || !postId || !csrf) {
      ensureDzToast();
      DZ.toast(I18N('ui_missing_parameters') || 'Missing parameters.', {
        type: 'error',
        duration: 2200,
      });
      return;
    }

    $popup.data('busy', true);

    $.ajax({
      type: 'POST',
      url: requestEndpoint(),
      dataType: 'json',
      data: {
        p: 'report_comment',
        comment_id: commentId,
        post_id: postId,
        reason: code,
        csrf_token: csrf,
      },
    })
      .done(function (res) {
        var ok = !!(res && (res.status === 'success' || res.success === true));
        var msg = (res && (res.message || res.msg)) || '';
        ensureDzToast();
        if (ok) {
          var $comment = $('#comment-' + commentId);
          var $btn = $comment.length
            ? $comment.find('.comment-report').first()
            : $('.comment-report[data-comment-id="' + commentId + '"]').first();
          setCommentReportState($comment, $btn, !!res.reported);
          DZ.toast(msg || I18N('comment_reported') || 'Comment reported.', {
            type: 'success',
            duration: 2200,
          });
          closeCommentPopup($popup);
        } else {
          DZ.toast(msg || I18N('ui_error') || 'Error', {
            type: 'error',
            duration: 2400,
          });
        }
      })
      .fail(function (xhr) {
        ensureDzToast();
        DZ.toast(I18N('ui_network_error') || 'Network error', {
          type: 'error',
          duration: 2400,
        });
        if (window.console && console.error) {
          console.error(
            'report_comment AJAX error:',
            xhr && xhr.responseText ? xhr.responseText : xhr,
          );
        }
      })
      .always(function () {
        $popup.data('busy', false);
      });
  });

  // Delegated handler: open comment edit popup
  $(document).on('click', '.comment-edit', function () {
    var $btn = $(this);
    var $comment = $btn.closest('.post-comment');
    var commentId =
      $btn.data('comment-id') ||
      ($comment.length ? $comment.data('comment-id') : null);
    if (!commentId) {
      return;
    }
    var $popup = $('#commentEditPopup-' + commentId);
    if (!$popup.length) {
      return;
    }
    var text = $comment.attr('data-comment-text') || '';
    $popup.find('.ce-text').val(text);
    openCommentPopup($popup);
  });

  $(document).on('click', '.comment-edit-popup .ce-cancel', function () {
    closeCommentPopup($(this).closest('.comment-edit-popup'));
  });

  $(document).on('click', '.comment-edit-popup .ce-save', function () {
    var $btn = $(this);
    if ($btn.data('busy') === true) {
      return;
    }

    var $popup = $btn.closest('.comment-edit-popup');
    var commentId = $popup.data('comment-id');
    var postId = $popup.data('post-id');
    var $comment = $('#comment-' + commentId);
    var raw = ($popup.find('.ce-text').val() || '').toString();
    var trimmed = raw.replace(/\s+/g, ' ').trim();
    var csrf = getCsrfToken();

    if (!commentId || !postId || !csrf) {
      ensureDzToast();
      DZ.toast(I18N('ui_missing_parameters') || 'Missing parameters.', {
        type: 'error',
        duration: 2200,
      });
      return;
    }

    if (trimmed === '') {
      ensureDzToast();
      DZ.toast(I18N('error_empty_comment') || 'Comment cannot be empty.', {
        type: 'error',
        duration: 2200,
      });
      return;
    }

    $btn.data('busy', true);

    $.ajax({
      type: 'POST',
      url: requestEndpoint(),
      dataType: 'json',
      data: {
        p: 'update_comment',
        comment_id: commentId,
        post_id: postId,
        comment: raw,
        csrf_token: csrf,
      },
    })
      .done(function (res) {
        var ok = !!(
          res &&
          (res.status === 'success' ||
            res.comment_updated === true ||
            res.success === true)
        );
        var msg = (res && (res.message || res.msg)) || '';
        ensureDzToast();
        if (ok) {
          closeCommentPopup($popup);
          if ($comment.length) {
            if (res && res.html) {
              var $node = $(res.html);
              $comment.replaceWith($node);
            } else {
              if (typeof res.comment_text_html !== 'undefined') {
                $comment.find('.comment-text').html(res.comment_text_html);
              }
              var plainForAttr =
                typeof res.comment_text_plain !== 'undefined'
                  ? res.comment_text_plain
                  : trimmed;
              $comment.attr('data-comment-text', plainForAttr || '');
              if (res.updated_time) {
                $comment.attr('data-comment-updated', '1');
                $comment.attr('data-comment-updated-time', res.updated_time);
                if (!$comment.find('.comment-edited').length) {
                  var $meta = $comment.find('.comment-meta');
                  if ($meta.length) {
                    $('<span/>', {
                      class: 'comment-edited',
                      text: I18N('comment_edited') || 'Edited',
                    }).appendTo($meta);
                  }
                }
              } else {
                $comment.attr('data-comment-updated', '0');
                $comment.removeAttr('data-comment-updated-time');
                $comment.find('.comment-edited').remove();
              }
            }
          }
          DZ.toast(msg || I18N('comment_updated') || 'Comment updated.', {
            type: 'success',
            duration: 2000,
          });
        } else {
          DZ.toast(
            msg ||
              I18N('comment_update_failed') ||
              'Failed to update the comment.',
            { type: 'error', duration: 2400 },
          );
        }
      })
      .fail(function (xhr) {
        ensureDzToast();
        DZ.toast(I18N('ui_network_error') || 'Network error', {
          type: 'error',
          duration: 2400,
        });
        if (window.console && console.error) {
          console.error(
            'update_comment AJAX error:',
            xhr && xhr.responseText ? xhr.responseText : xhr,
          );
        }
      })
      .always(function () {
        $btn.data('busy', false);
      });
  });

  // Delegated handler: open comment delete confirm popup
  $(document).on('click', '.comment-delete', function () {
    var $btn = $(this);
    var $comment = $btn.closest('.post-comment');
    var commentId =
      $btn.data('comment-id') ||
      ($comment.length ? $comment.data('comment-id') : null);
    if (!commentId) {
      return;
    }
    var $popup = $('#commentDeletePopup-' + commentId);
    if (!$popup.length) {
      return;
    }
    openCommentPopup($popup);
  });

  $(document).on('click', '.comment-delete-popup .cd-cancel', function () {
    closeCommentPopup($(this).closest('.comment-delete-popup'));
  });

  $(document).on('click', '.comment-delete-popup .cd-confirm', function () {
    var $btn = $(this);
    if ($btn.data('busy') === true) {
      return;
    }

    var $popup = $btn.closest('.comment-delete-popup');
    var commentId = $popup.data('comment-id');
    var postId = $popup.data('post-id');
    var csrf = getCsrfToken();
    var $comment = $('#comment-' + commentId);

    if (!commentId || !postId || !csrf) {
      ensureDzToast();
      DZ.toast(I18N('ui_missing_parameters') || 'Missing parameters.', {
        type: 'error',
        duration: 2200,
      });
      return;
    }

    $btn.data('busy', true);

    $.ajax({
      type: 'POST',
      url: requestEndpoint(),
      dataType: 'json',
      data: {
        p: 'delete_comment',
        comment_id: commentId,
        post_id: postId,
        csrf_token: csrf,
      },
    })
      .done(function (res) {
        var ok = !!(
          res &&
          (res.status === 'success' ||
            res.deleted === true ||
            res.success === true)
        );
        var msg = (res && (res.message || res.msg)) || '';
        ensureDzToast();
        if (ok) {
          if ($comment.length && typeof res.total_comments !== 'undefined') {
            updateCommentCountUI($comment, res.total_comments);
          } else if (typeof res.total_comments !== 'undefined') {
            updateCommentCountUI($popup, res.total_comments);
          }
          closeCommentPopup($popup);
          if ($comment.length) {
            $comment.fadeOut(160, function () {
              $(this).remove();
            });
          }
          DZ.toast(msg || I18N('comment_deleted') || 'Comment deleted.', {
            type: 'success',
            duration: 2000,
          });
        } else {
          DZ.toast(
            msg ||
              I18N('comment_delete_failed') ||
              'Failed to delete the comment.',
            { type: 'error', duration: 2400 },
          );
        }
      })
      .fail(function (xhr) {
        ensureDzToast();
        DZ.toast(I18N('ui_network_error') || 'Network error', {
          type: 'error',
          duration: 2400,
        });
        if (window.console && console.error) {
          console.error(
            'delete_comment AJAX error:',
            xhr && xhr.responseText ? xhr.responseText : xhr,
          );
        }
      })
      .always(function () {
        $btn.data('busy', false);
      });
  });

  $(document).on(
    'click',
    '.comment-edit-popup, .comment-delete-popup',
    function (ev) {
      var $target = $(ev.target);
      if ($target.closest('.ce-sheet, .cd-sheet').length === 0) {
        closeCommentPopup($(this));
      }
    },
  );

  $(document).on('keydown', function (ev) {
    if (ev.key === 'Escape') {
      closeAllCommentPopups();
    }
  });
})(jQuery);

(function ($) {
  'use strict';

  function formatTime(seconds) {
    var sec = Math.max(0, Math.floor(seconds || 0));
    var m = Math.floor(sec / 60);
    var s = sec % 60;
    return m + ':' + String(s).padStart(2, '0');
  }

  function initPodcastPlayer($card) {
    if (!$card.length || $card.data('podcast-ready') === true) {
      return;
    }
    var audio = $card.find('.podcast-audio-element').get(0);
    if (!audio) {
      return;
    }
    var $play = $card.find('.podcast-btn.play');
    var $rew = $card.find('.podcast-btn.rewind');
    var $fwd = $card.find('.podcast-btn.forward');
    var $track = $card.find('.podcast-progress-fill');
    var $thumb = $card.find('.podcast-progress-thumb');
    var $time = $card.find('.podcast-time');
    var $bar = $card.find('.podcast-progress-track');

    function updateProgress() {
      var dur = audio.duration || 0;
      var cur = audio.currentTime || 0;
      var pct = dur > 0 ? Math.min(100, Math.max(0, (cur / dur) * 100)) : 0;
      $track.css('width', pct + '%');
      $thumb.css('left', pct + '%');
      if ($time.length) {
        $time.text(formatTime(cur) + ' / ' + (dur ? formatTime(dur) : '--:--'));
      }
    }

    audio.addEventListener('timeupdate', updateProgress);
    audio.addEventListener('loadedmetadata', updateProgress);
    audio.addEventListener('play', function () {
      // Pause any other podcast audio elements
      document
        .querySelectorAll('.podcast-audio-element')
        .forEach(function (el) {
          if (el !== audio && !el.paused) {
            el.pause();
          }
        });
      $card.addClass('is-playing');
    });
    audio.addEventListener('pause', function () {
      $card.removeClass('is-playing');
    });

    if ($play.length) {
      $play.on('click', function () {
        if (audio.paused) {
          audio.play();
        } else {
          audio.pause();
        }
      });
    }
    function nudge(offset) {
      var dur = audio.duration || 0;
      var tgt = (audio.currentTime || 0) + offset;
      if (dur > 0) {
        tgt = Math.max(0, Math.min(dur, tgt));
      }
      audio.currentTime = tgt;
    }
    if ($rew.length) {
      $rew.on('click', function () {
        nudge(-10);
      });
    }
    if ($fwd.length) {
      $fwd.on('click', function () {
        nudge(10);
      });
    }

    if ($bar.length) {
      $bar.on('click', function (ev) {
        var rect = this.getBoundingClientRect();
        var ratio = (ev.clientX - rect.left) / rect.width;
        ratio = Math.max(0, Math.min(1, ratio));
        if (audio.duration) {
          audio.currentTime = audio.duration * ratio;
        }
      });
    }

    updateProgress();
    $card.data('podcast-ready', true);
  }

  function initAllPodcasts(scope) {
    var $root = scope ? $(scope) : $(document);
    $root.find('.podcast-player-card').each(function () {
      initPodcastPlayer($(this));
    });
  }

  $(document).ready(function () {
    initAllPodcasts(document);
  });

  $(document).on('post:created', function (ev, payload) {
    if (payload && payload.root) {
      initAllPodcasts(payload.root);
    }
  });

  // Feed filter / infinite scroll injects new posts via `posts:loaded`.
  // Re-bind podcast controls for newly inserted podcast cards.
  $(document).on('posts:loaded', function (ev, payload) {
    if (payload && payload.root) {
      initAllPodcasts(payload.root);
      return;
    }
    initAllPodcasts(document);
  });
})(jQuery);
