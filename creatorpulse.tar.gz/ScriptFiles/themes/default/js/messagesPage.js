(function () {
  'use strict';

  if (!document.body || document.body.getAttribute('data-layout') !== 'messages') {
    return;
  }

  var page = document.querySelector('.messages-page');
  var thread = document.querySelector('[data-messages-thread]');
  var details = document.querySelector('[data-messages-details]');
  var detailsShell = details ? details.closest('[data-messages-details-shell]') : null;
  var sidebar = document.querySelector('[data-messages-sidebar]');
  var drawerBackdrop = document.querySelector('[data-messages-drawer-close]');
  var searchInput = document.querySelector('.messages-page__search input');
  var noResults = document.querySelector('[data-messages-no-results]');
  var activeConversationButton = null;
  var threadObserver = null;
  var assetsModal = null;
  var threadSearchMatches = [];
  var threadSearchIndex = -1;
  var lastDrawerTrigger = null;
  var mobileMessagesQuery = window.matchMedia ? window.matchMedia('(max-width: 820px)') : null;
  if (!page || !thread) {
    return;
  }

  function isMobileMessagesLayout() {
    return mobileMessagesQuery ? mobileMessagesQuery.matches : window.innerWidth <= 820;
  }

  function setDrawerOpen(isOpen, trigger) {
    if (!sidebar || !drawerBackdrop || !page) {
      return;
    }
    if (!isMobileMessagesLayout()) {
      isOpen = false;
    }
    if (isOpen && trigger) {
      lastDrawerTrigger = trigger;
    }
    page.classList.toggle('messages-page--drawer-open', isOpen);
    drawerBackdrop.hidden = !isOpen;
    sidebar.setAttribute('aria-hidden', isOpen ? 'false' : (isMobileMessagesLayout() ? 'true' : 'false'));
    document.documentElement.classList.toggle('messages-page-drawer-lock', isOpen);
    document.body.classList.toggle('messages-page-drawer-lock', isOpen);
    if (isOpen) {
      window.setTimeout(function () {
        var focusTarget = searchInput || sidebar.querySelector('[data-message-conversation]') || sidebar;
        if (focusTarget && typeof focusTarget.focus === 'function') {
          focusTarget.focus({ preventScroll: true });
        }
      }, 40);
    } else if (lastDrawerTrigger && typeof lastDrawerTrigger.focus === 'function' && document.contains(lastDrawerTrigger)) {
      lastDrawerTrigger.focus({ preventScroll: true });
    }
  }

  function closeDrawer() {
    setDrawerOpen(false);
  }

  function syncDrawerForViewport() {
    if (!sidebar || !drawerBackdrop) {
      return;
    }
    if (!isMobileMessagesLayout()) {
      closeDrawer();
      sidebar.setAttribute('aria-hidden', 'false');
      return;
    }
    sidebar.setAttribute('aria-hidden', page.classList.contains('messages-page--drawer-open') ? 'false' : 'true');
    if (!page.classList.contains('messages-page--chat-open') && !activeConversationButton) {
      setDrawerOpen(true);
    }
  }

  function buildUrl(path) {
    if (window.DZ && typeof window.DZ.buildUrl === 'function') {
      return window.DZ.buildUrl(path);
    }
    try {
      var base = (typeof window.site_url === 'string' && window.site_url)
        ? window.site_url
        : (window.location.origin + window.location.pathname.replace(/[^\/]*$/, ''));
      if (base.slice(-1) !== '/') {
        base += '/';
      }
      return new URL(String(path || '').replace(/^\//, ''), base).toString();
    } catch (_) {
      return String(path || '');
    }
  }

  function i18n(key, fallback, params) {
    try {
      if (window.DZ && typeof window.DZ.i18n === 'function') {
        var value = window.DZ.i18n(key, params);
        if (value) {
          return value;
        }
      }
    } catch (_) {}
    try {
      var el = document.querySelector('meta[name="i18n.' + key + '"]');
      var text = el ? (el.getAttribute('content') || '') : '';
      if (text && params && typeof params === 'object') {
        Object.keys(params).forEach(function (name) {
          text = text.replace(new RegExp('\\{' + name + '\\}', 'g'), String(params[name]));
        });
      }
      return text || fallback || key;
    } catch (_) {
      return fallback || key;
    }
  }

  function iconTemplate(name) {
    try {
      var wrap = document.getElementById('messages-page-icon-templates');
      if (!wrap) {
        return '';
      }
      var node = wrap.querySelector('[data-icon="' + name + '"]');
      return node ? (node.innerHTML || '') : '';
    } catch (_) {
      return '';
    }
  }

  function csrfToken() {
    var token = document.querySelector('input[name="csrf_token"]');
    return token ? token.value : '';
  }

  function currentUrl() {
    try {
      return new URL(window.location.href);
    } catch (_) {
      return null;
    }
  }

  function requestedConversationId() {
    var url = currentUrl();
    if (!url) {
      return 0;
    }
    return parseInt(url.searchParams.get('chat') || url.searchParams.get('with') || '0', 10) || 0;
  }

  function setConversationUrl(id) {
    if (!window.history || typeof window.history.replaceState !== 'function') {
      return;
    }
    var url = currentUrl();
    if (!url) {
      return;
    }
    if (id > 0) {
      url.searchParams.set('chat', String(id));
    } else {
      url.searchParams.delete('chat');
      url.searchParams.delete('with');
    }
    window.history.replaceState({}, '', url.pathname + url.search + url.hash);
  }

  function setDetailsVisible(isVisible) {
    if (!detailsShell || !page) {
      return;
    }
    if (isVisible) {
      detailsShell.hidden = false;
      page.classList.remove('messages-page--details-hidden');
    } else {
      detailsShell.hidden = true;
      page.classList.add('messages-page--details-hidden');
    }
  }

  function setLoading() {
    thread.classList.add('is-loading');
    thread.classList.remove('has-chat');
    thread.innerHTML = '<div class="messages-page__loader"><span></span><strong>' + escapeHtml(i18n('messages_loading_conversation', 'Loading conversation')) + '</strong></div>';
  }

  function setError() {
    thread.classList.remove('is-loading');
    thread.classList.remove('has-chat');
    setDetailsVisible(false);
    thread.innerHTML = '<div class="messages-page__thread-empty"><span class="messages-page__thread-icon" aria-hidden="true"></span><strong>' + escapeHtml(i18n('messages_conversation_load_failed', 'Conversation could not be loaded')) + '</strong><p>' + escapeHtml(i18n('messages_try_again', 'Please try again.')) + '</p></div>';
  }

  function resetThread() {
    stopThreadObserver();
    closeConversationMenu();
    closeThreadSearch();
    try {
      if (window.chatController && typeof window.chatController.destroy === 'function') {
        window.chatController.destroy();
      }
    } catch (_) {}

    page.classList.remove('messages-page--chat-open');
    closeDrawer();
    setDetailsVisible(false);
    activeConversationButton = null;
    setConversationUrl(0);
    thread.classList.remove('is-loading');
    thread.classList.remove('has-chat');
    thread.innerHTML = '<div class="messages-page__thread-empty" data-messages-thread-empty><span class="messages-page__thread-icon" aria-hidden="true"></span><strong>' + escapeHtml(i18n('messages_select_conversation_title', 'Select a conversation')) + '</strong><p>' + escapeHtml(i18n('messages_select_conversation_info', 'Your full conversation will open here.')) + '</p></div>';
    document.querySelectorAll('[data-message-conversation].is-active').forEach(function (el) {
      el.classList.remove('is-active');
      var row = el.closest('.messages-page__conversation');
      if (row) {
        row.classList.remove('is-active');
      }
    });
  }

  function scriptUrl(src) {
    try {
      var url = /^(?:https?:)?\//i.test(src) ? new URL(src, window.location.origin) : new URL(src.replace(/^\/+/, ''), buildUrl(''));
      if (url.pathname.indexOf('/js/chat.js') !== -1) {
        url.searchParams.set('messagesPageBoot', String(Date.now()));
      }
      return url.toString();
    } catch (_) {
      return src;
    }
  }

  function injectHTMLWithScripts(target, html) {
    var tmp = document.createElement('div');
    tmp.innerHTML = String(html || '');
    var scripts = Array.prototype.slice.call(tmp.querySelectorAll('script'));
    var urls = [];

    scripts.forEach(function (script) {
      var src = script.getAttribute('src');
      if (src) {
        urls.push(scriptUrl(src));
      }
      if (script.parentNode) {
        script.parentNode.removeChild(script);
      }
    });

    target.innerHTML = '';
    while (tmp.firstChild) {
      target.appendChild(tmp.firstChild);
    }

    return urls.reduce(function (chain, url) {
      return chain.then(function () {
        return new Promise(function (resolve) {
          var script = document.createElement('script');
          script.src = url;
          script.defer = true;
          script.async = false;
          script.onload = resolve;
          script.onerror = function () {
            console.warn('Failed to load script:', url);
            resolve();
          };
          (document.head || document.body || document.documentElement).appendChild(script);
        });
      });
    }, Promise.resolve());
  }

  function updateDetails(button, payload) {
    if (!details) {
      return;
    }
    setDetailsVisible(true);
    var data = payload && payload.user ? payload : null;
    var user = data ? data.user : null;
    var name = (user && user.fullname) || button.getAttribute('data-name') || i18n('unknown_user', 'User');
    var username = (user && user.username) || button.getAttribute('data-username') || '';
    var avatar = (user && user.avatar_url) || button.getAttribute('data-avatar') || '';
    var cover = (user && user.cover_url) || '';
    var href = (user && user.profile_url) || (username ? buildUrl('profile/' + encodeURIComponent(username)) : '#');
    var safeName = escapeHtml(name);
    var safeUsername = escapeHtml(username);
    var safeAvatar = escapeAttr(avatar);
    var safeCover = escapeAttr(cover);
    var safeHref = escapeAttr(href);
    var shared = data && data.shared ? data.shared : { media: [], links: [], posts: [] };
    var counts = data && data.counts ? data.counts : { media: 0, links: 0, posts: 0 };
    var activeTab = chooseDefaultDetailsTab(counts);

    details.innerHTML = ''
      + '<div class="messages-page__profile-card">'
      + '  <a class="messages-page__details-cover' + (safeCover ? '' : ' is-empty') + '" href="' + safeHref + '">'
      +      (safeCover ? '<img src="' + safeCover + '" alt="">' : '')
      + '  </a>'
      + '  <a class="messages-page__details-avatar" href="' + safeHref + '"><img src="' + safeAvatar + '" alt="' + escapeAttr(name) + '"></a>'
      + '  <strong>' + safeName + '</strong>'
      +    (username ? '<a class="messages-page__details-username" href="' + safeHref + '">@' + safeUsername + '</a>' : '')
      + '  <a class="messages-page__details-action" href="' + safeHref + '">' + escapeHtml(i18n('view_profile', 'View profile')) + '</a>'
      + '</div>'
      + '<div class="messages-page__shared-summary" role="tablist" aria-label="' + escapeAttr(i18n('messages_shared_content_label', 'Shared conversation content')) + '">'
      + renderDetailsTab('media', i18n('messages_detail_media', 'Media'), counts.media, activeTab)
      + renderDetailsTab('links', i18n('messages_detail_links', 'Links'), counts.links, activeTab)
      + renderDetailsTab('posts', i18n('messages_detail_posts', 'Posts'), counts.posts, activeTab)
      + '</div>'
      + '<div class="messages-page__detail-panes">'
      + renderSharedMedia(shared.media || [], counts.media, activeTab)
      + renderSharedLinks(shared.links || [], counts.links, activeTab)
      + renderSharedPosts(shared.posts || [], counts.posts, activeTab)
      + '</div>';
  }

  function chooseDefaultDetailsTab(counts) {
    counts = counts || {};
    if (Number(counts.media || 0) > 0) {
      return 'media';
    }
    if (Number(counts.links || 0) > 0) {
      return 'links';
    }
    if (Number(counts.posts || 0) > 0) {
      return 'posts';
    }
    return 'media';
  }

  function renderDetailsTab(key, label, count, activeTab) {
    var isActive = key === activeTab;
    return '<button type="button" class="messages-page__detail-tab' + (isActive ? ' is-active' : '') + '" data-messages-detail-tab="' + escapeAttr(key) + '" role="tab" aria-selected="' + (isActive ? 'true' : 'false') + '">'
      + '<strong>' + Number(count || 0) + '</strong>'
      + '<span>' + escapeHtml(label) + '</span>'
      + '</button>';
  }

  function detailPaneAttrs(key, activeTab) {
    return ' data-messages-detail-pane="' + escapeAttr(key) + '" role="tabpanel"' + (key === activeTab ? '' : ' hidden');
  }

  function renderSectionHeader(title, count, type) {
    var total = Number(count || 0);
    return '<div class="messages-page__shared-header">'
      + '<strong>' + escapeHtml(title) + '</strong>'
      + '<span>' + total + '</span>'
      + (total > 0 ? '<button type="button" data-messages-assets-open="' + escapeAttr(type) + '">' + escapeHtml(i18n('see_all', 'See all')) + '</button>' : '')
      + '</div>';
  }

  function renderMediaItem(item) {
    item = item || {};
    var itemType = String(item.type || 'image');
    var messageId = Number(item.message_id || 0);
    var label = escapeAttr(item.label || itemType || i18n('messages_detail_media', 'Media'));
    var priceLabel = escapeHtml(item.price_label || item.price || '');

    if (item.locked) {
      return '<button type="button" class="messages-page__media-item messages-page__media-item--locked" data-messages-open-chat-message="' + messageId + '">'
        + '<div class="messages-page__media-lock" aria-hidden="true">' + iconTemplate('locked') + '</div>'
        + '<strong>' + escapeHtml(i18n('chat_paid_media_locked_badge', 'Locked')) + '</strong>'
        + '<small>' + escapeHtml(priceLabel ? i18n('chat_paid_media_unlock_button', 'Unlock {price}', { price: priceLabel }) : i18n('messages_open_message', 'Open message')) + '</small>'
        + '</button>';
    }

    var url = escapeAttr(item.url || '#');
    var paidBadge = item.paid ? '<span class="messages-page__media-badge">' + escapeHtml(i18n('messages_paid_badge', 'Paid')) + '</span>' : '';
    var content = itemType === 'video'
      ? '<video src="' + url + '" muted preload="metadata"></video><span class="messages-page__media-badge">' + escapeHtml(i18n('chat_preview_video', 'Video')) + '</span>' + paidBadge
      : '<img src="' + url + '" alt="' + label + '">' + paidBadge;
    return '<a class="messages-page__media-item messages-page__media-item--' + escapeAttr(itemType) + '" href="' + url + '" target="_blank" rel="noopener noreferrer" data-messages-media-message="' + messageId + '">' + content + '</a>';
  }

  function renderSharedMedia(items, count, activeTab) {
    items = Array.isArray(items) ? items : [];
    var html = '<section class="messages-page__shared-section messages-page__detail-pane"' + detailPaneAttrs('media', activeTab) + '>' + renderSectionHeader(i18n('messages_recent_media', 'Recent media'), count, 'media');
    if (!items.length) {
      return html + '<div class="messages-page__shared-empty">' + escapeHtml(i18n('messages_no_shared_media', 'No shared media yet.')) + '</div></section>';
    }
    html += '<div class="messages-page__media-grid">';
    items.slice(0, 6).forEach(function (item) {
      html += renderMediaItem(item);
    });
    return html + '</div></section>';
  }

  function renderSharedLinks(items, count, activeTab) {
    items = Array.isArray(items) ? items : [];
    var html = '<section class="messages-page__shared-section messages-page__detail-pane"' + detailPaneAttrs('links', activeTab) + '>' + renderSectionHeader(i18n('messages_detail_links', 'Links'), count, 'links');
    if (!items.length) {
      return html + '<div class="messages-page__shared-empty">' + escapeHtml(i18n('messages_no_shared_links', 'No shared links yet.')) + '</div></section>';
    }
    html += '<div class="messages-page__link-list">';
    items.slice(0, 6).forEach(function (item) {
      var url = escapeAttr(item.url || '#');
      var label = escapeHtml(item.label || item.url || i18n('messages_link_fallback', 'Link'));
      html += '<a class="messages-page__link-item" href="' + url + '" target="_blank" rel="noopener noreferrer"><span>' + label + '</span><small>' + escapeHtml(item.url || '') + '</small></a>';
    });
    return html + '</div></section>';
  }

  function renderSharedPosts(items, count, activeTab) {
    items = Array.isArray(items) ? items : [];
    var html = '<section class="messages-page__shared-section messages-page__detail-pane"' + detailPaneAttrs('posts', activeTab) + '>' + renderSectionHeader(i18n('messages_shared_posts', 'Shared posts'), count, 'posts');
    if (!items.length) {
      return html + '<div class="messages-page__shared-empty">' + escapeHtml(i18n('messages_no_shared_posts', 'No shared posts yet.')) + '</div></section>';
    }
    html += '<div class="messages-page__post-list">';
    items.slice(0, 4).forEach(function (item) {
      var url = escapeAttr(item.url || '#');
      var label = escapeHtml(item.label || i18n('messages_shared_post_fallback', 'Shared post'));
      html += '<a class="messages-page__post-item" href="' + url + '" target="_blank" rel="noopener noreferrer"><span>#' + Number(item.id || 0) + '</span><strong>' + label + '</strong></a>';
    });
    return html + '</div></section>';
  }

  function activateDetailsTab(button) {
    var panel = button.closest('[data-messages-details]');
    var tab = button.getAttribute('data-messages-detail-tab') || 'media';
    if (!panel) {
      return;
    }

    panel.querySelectorAll('[data-messages-detail-tab]').forEach(function (item) {
      var active = item === button;
      item.classList.toggle('is-active', active);
      item.setAttribute('aria-selected', active ? 'true' : 'false');
    });

    panel.querySelectorAll('[data-messages-detail-pane]').forEach(function (pane) {
      pane.hidden = pane.getAttribute('data-messages-detail-pane') !== tab;
    });
  }

  function assetsTitle(type) {
    if (type === 'links') {
      return i18n('messages_shared_links', 'Shared links');
    }
    if (type === 'posts') {
      return i18n('messages_shared_posts', 'Shared posts');
    }
    return i18n('messages_shared_media', 'Shared media');
  }

  function openAssetsModal(type) {
    var targetId = activeConversationButton ? parseInt(activeConversationButton.getAttribute('data-id') || '0', 10) : 0;
    if (!targetId) {
      return;
    }
    type = ['media', 'links', 'posts'].indexOf(type) !== -1 ? type : 'media';
    closeAssetsModal();

    assetsModal = document.createElement('div');
    assetsModal.className = 'messages-assets-modal';
    assetsModal.setAttribute('role', 'dialog');
    assetsModal.setAttribute('aria-modal', 'true');
    assetsModal.innerHTML = ''
      + '<div class="messages-assets-modal__panel">'
      + '  <div class="messages-assets-modal__header">'
      + '    <div><strong>' + escapeHtml(assetsTitle(type)) + '</strong><span>' + escapeHtml(i18n('messages_loading_shared_items', 'Loading shared conversation items')) + '</span></div>'
      + '    <button type="button" class="messages-assets-modal__close" data-messages-assets-close aria-label="' + escapeAttr(i18n('close', 'Close')) + '">&times;</button>'
      + '  </div>'
      + '  <div class="messages-assets-modal__body"><div class="messages-page__loader"><span></span><strong>' + escapeHtml(i18n('loading', 'Loading')) + '</strong></div></div>'
      + '</div>';
    document.body.appendChild(assetsModal);

    var body = new URLSearchParams();
    body.set('p', 'get_conversation_assets');
    body.set('id', String(targetId));
    body.set('type', type);
    body.set('limit', '48');
    body.set('offset', '0');
    body.set('csrf_token', csrfToken());

    fetch(buildUrl('request/requests.php'), {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body
    })
      .then(function (response) { return response.json(); })
      .then(function (res) {
        if (!res || res.status !== 'success' || !res.assets) {
          throw new Error((res && res.message) || i18n('messages_assets_load_failed', 'Assets could not be loaded'));
        }
        renderAssetsModal(type, res.assets);
      })
      .catch(function () {
        if (!assetsModal) {
          return;
        }
        var modalBody = assetsModal.querySelector('.messages-assets-modal__body');
        if (modalBody) {
          modalBody.innerHTML = '<div class="messages-assets-modal__empty">' + escapeHtml(i18n('messages_shared_items_load_failed', 'Shared items could not be loaded.')) + '</div>';
        }
      });
  }

  function renderAssetsModal(type, payload) {
    if (!assetsModal) {
      return;
    }
    var items = Array.isArray(payload.items) ? payload.items : [];
    var total = Number(payload.total || items.length || 0);
    var headerHint = assetsModal.querySelector('.messages-assets-modal__header span');
    var modalBody = assetsModal.querySelector('.messages-assets-modal__body');
    if (headerHint) {
      headerHint.textContent = i18n('messages_shared_items_count', '{count} shared items', { count: total });
    }
    if (!modalBody) {
      return;
    }
    if (!items.length) {
      modalBody.innerHTML = '<div class="messages-assets-modal__empty">' + escapeHtml(i18n('messages_no_shared_items', 'No shared items yet.')) + '</div>';
      return;
    }

    if (type === 'links') {
      modalBody.innerHTML = '<div class="messages-assets-modal__links">'
        + items.map(function (item) {
          var url = escapeAttr(item.url || '#');
          var label = escapeHtml(item.label || item.url || i18n('messages_link_fallback', 'Link'));
          return '<a class="messages-page__link-item" href="' + url + '" target="_blank" rel="noopener noreferrer"><span>' + label + '</span><small>' + escapeHtml(item.url || '') + '</small></a>';
        }).join('')
        + '</div>';
      return;
    }

    if (type === 'posts') {
      modalBody.innerHTML = '<div class="messages-assets-modal__posts">'
        + items.map(function (item) {
          var url = escapeAttr(item.url || '#');
          var label = escapeHtml(item.label || i18n('messages_shared_post_fallback', 'Shared post'));
          return '<a class="messages-page__post-item" href="' + url + '" target="_blank" rel="noopener noreferrer"><span>#' + Number(item.id || 0) + '</span><strong>' + label + '</strong></a>';
        }).join('')
        + '</div>';
      return;
    }

    modalBody.innerHTML = '<div class="messages-assets-modal__media">'
      + items.map(function (item) {
        return renderMediaItem(item);
      }).join('')
      + '</div>';
  }

  function closeAssetsModal() {
    if (assetsModal && assetsModal.parentNode) {
      assetsModal.parentNode.removeChild(assetsModal);
    }
    assetsModal = null;
  }

  function activeConversationId() {
    return activeConversationButton ? parseInt(activeConversationButton.getAttribute('data-id') || '0', 10) : 0;
  }

  function closeConversationMenu() {
    if (!thread) {
      return;
    }
    thread.querySelectorAll('[data-chat-conversation-menu]').forEach(function (menu) {
      menu.hidden = true;
    });
    thread.querySelectorAll('[data-chat-menu-toggle]').forEach(function (toggle) {
      toggle.setAttribute('aria-expanded', 'false');
      toggle.classList.remove('is-active');
    });
  }

  function setThreadSearchToggle(open) {
    if (!thread) {
      return;
    }
    thread.querySelectorAll('[data-chat-thread-search-toggle]').forEach(function (toggle) {
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      toggle.classList.toggle('is-active', !!open);
    });
  }

  function toggleConversationMenu(button) {
    var wrap = button.closest('.chat_header_more');
    var menu = wrap ? wrap.querySelector('[data-chat-conversation-menu]') : null;
    if (!menu) {
      return;
    }
    var willOpen = menu.hidden;
    closeConversationMenu();
    if (willOpen) {
      closeThreadSearch();
    }
    menu.hidden = !willOpen;
    button.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
    button.classList.toggle('is-active', !!willOpen);
    if (willOpen) {
      updatePinMenuLabel();
    }
  }

  function updatePinMenuLabel() {
    if (!thread) {
      return;
    }
    var pinButton = thread.querySelector('[data-chat-menu-action="pin"]');
    var label = pinButton ? pinButton.querySelector('em') : null;
    var row = activeConversationButton ? activeConversationButton.closest('.messages-page__conversation') : null;
    if (!pinButton || !label) {
      return;
    }
    var isPinned = !!(row && row.classList.contains('is-pinned'));
    label.textContent = isPinned
      ? (pinButton.getAttribute('data-chat-unpin-label') || i18n('chat_menu_unpin', 'Unpin this chat'))
      : (pinButton.getAttribute('data-chat-pin-label') || i18n('chat_menu_pin', 'Pin this chat'));
  }

  function resetThreadSearchHighlights() {
    threadSearchMatches.forEach(function (row) {
      row.classList.remove('chat_search_match', 'is-current');
    });
    threadSearchMatches = [];
    threadSearchIndex = -1;
  }

  function threadSearchPanel() {
    return thread ? thread.querySelector('[data-chat-thread-search]') : null;
  }

  function updateThreadSearchCount() {
    var countNode = thread ? thread.querySelector('[data-chat-thread-search-count]') : null;
    if (!countNode) {
      return;
    }
    countNode.textContent = threadSearchMatches.length
      ? (threadSearchIndex + 1) + '/' + threadSearchMatches.length
      : '0/0';
  }

  function selectThreadSearchMatch(index) {
    if (!threadSearchMatches.length) {
      threadSearchIndex = -1;
      updateThreadSearchCount();
      return;
    }
    threadSearchMatches.forEach(function (row) {
      row.classList.remove('is-current');
    });
    threadSearchIndex = (index + threadSearchMatches.length) % threadSearchMatches.length;
    var row = threadSearchMatches[threadSearchIndex];
    row.classList.add('is-current');
    row.scrollIntoView({ behavior: 'smooth', block: 'center' });
    updateThreadSearchCount();
  }

  function runThreadSearch() {
    if (!thread) {
      return;
    }
    var input = thread.querySelector('[data-chat-thread-search-input]');
    var query = normalizeText(input ? input.value : '');
    resetThreadSearchHighlights();
    if (query === '') {
      updateThreadSearchCount();
      return;
    }
    thread.querySelectorAll('.chat_message_row').forEach(function (row) {
      var haystack = normalizeText(row.textContent || '');
      if (haystack.indexOf(query) !== -1) {
        row.classList.add('chat_search_match');
        threadSearchMatches.push(row);
      }
    });
    selectThreadSearchMatch(0);
  }

  function openThreadSearch() {
    var panel = threadSearchPanel();
    if (!panel) {
      return;
    }
    closeConversationMenu();
    panel.hidden = false;
    setThreadSearchToggle(true);
    var input = panel.querySelector('[data-chat-thread-search-input]');
    if (input) {
      input.focus();
      input.select();
      runThreadSearch();
    }
  }

  function closeThreadSearch() {
    var panel = threadSearchPanel();
    if (panel) {
      panel.hidden = true;
    }
    setThreadSearchToggle(false);
    resetThreadSearchHighlights();
    updateThreadSearchCount();
  }

  function toggleThreadSearch() {
    var panel = threadSearchPanel();
    if (!panel) {
      return;
    }
    if (!panel.hidden) {
      closeThreadSearch();
      return;
    }
    openThreadSearch();
  }

  function focusConversationDetails() {
    closeConversationMenu();
    if (!details) {
      return;
    }
    details.classList.add('is-focused');
    if (typeof details.scrollIntoView === 'function' && window.innerWidth <= 1180) {
      details.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    window.setTimeout(function () {
      details.classList.remove('is-focused');
    }, 1300);
  }

  function toggleConversationDetails() {
    closeConversationMenu();
    if (!details || !detailsShell) {
      return;
    }
    if (!activeConversationId()) {
      showMessagesToast(i18n('messages_select_first', 'Select a conversation first.'), 'error');
      return;
    }
    var willShow = !!detailsShell.hidden;
    setDetailsVisible(willShow);
    if (willShow) {
      focusConversationDetails();
    }
  }

  function showMessagesToast(message, type) {
    var toast = document.querySelector('.messages-page__toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'messages-page__toast';
      document.body.appendChild(toast);
    }
    toast.textContent = message || '';
    toast.classList.toggle('is-error', type === 'error');
    toast.classList.add('is-visible');
    window.clearTimeout(showMessagesToast._timer);
    showMessagesToast._timer = window.setTimeout(function () {
      toast.classList.remove('is-visible');
    }, 2600);
  }

  function confirmConversationAction(options) {
    options = options || {};
    return new Promise(function (resolve) {
      var modal = document.createElement('div');
      modal.className = 'messages-action-modal';
      modal.setAttribute('role', 'dialog');
      modal.setAttribute('aria-modal', 'true');
      modal.innerHTML = ''
        + '<div class="messages-action-modal__panel">'
        + '  <span class="messages-action-modal__icon" aria-hidden="true">' + escapeHtml(options.icon || '!') + '</span>'
        + '  <strong>' + escapeHtml(options.title || i18n('messages_confirm_default_title', 'Are you sure?')) + '</strong>'
        + '  <p>' + escapeHtml(options.text || i18n('messages_confirm_default_text', 'This action cannot be undone.')) + '</p>'
        + '  <div class="messages-action-modal__actions">'
        + '    <button type="button" data-modal-cancel>' + escapeHtml(options.cancelLabel || i18n('menu_cancel', 'Cancel')) + '</button>'
        + '    <button type="button" class="' + (options.danger ? 'is-danger' : '') + '" data-modal-confirm>' + escapeHtml(options.confirmLabel || i18n('continue', 'Continue')) + '</button>'
        + '  </div>'
        + '</div>';
      document.body.appendChild(modal);
      function close(value) {
        if (modal.parentNode) {
          modal.parentNode.removeChild(modal);
        }
        resolve(value);
      }
      modal.addEventListener('click', function (event) {
        if (event.target === modal || event.target.closest('[data-modal-cancel]')) {
          event.preventDefault();
          close(false);
          return;
        }
        if (event.target.closest('[data-modal-confirm]')) {
          event.preventDefault();
          close(true);
        }
      });
      var confirm = modal.querySelector('[data-modal-confirm]');
      if (confirm) {
        confirm.focus();
      }
    });
  }

  function promptConversationReport() {
    return new Promise(function (resolve) {
      var modal = document.createElement('div');
      modal.className = 'messages-action-modal messages-action-modal--form';
      modal.setAttribute('role', 'dialog');
      modal.setAttribute('aria-modal', 'true');
      modal.innerHTML = ''
        + '<div class="messages-action-modal__panel">'
        + '  <span class="messages-action-modal__icon" aria-hidden="true">!</span>'
        + '  <strong>' + escapeHtml(i18n('messages_report_chat_title', 'Report chat')) + '</strong>'
        + '  <p>' + escapeHtml(i18n('messages_report_chat_text', 'Tell us what is wrong with this conversation.')) + '</p>'
        + '  <label class="messages-action-modal__field"><span>' + escapeHtml(i18n('chat_report_reason_label', 'Reason')) + '</span><select data-report-reason>'
        + '    <option value="spam">' + escapeHtml(i18n('chat_report_reason_spam', 'Spam')) + '</option>'
        + '    <option value="harassment">' + escapeHtml(i18n('chat_report_reason_harassment', 'Harassment')) + '</option>'
        + '    <option value="unsafe_content">' + escapeHtml(i18n('chat_report_reason_unsafe_content', 'Unsafe content')) + '</option>'
        + '    <option value="scam">' + escapeHtml(i18n('chat_report_reason_scam_short', 'Scam')) + '</option>'
        + '    <option value="other">' + escapeHtml(i18n('chat_report_reason_other', 'Other')) + '</option>'
        + '  </select></label>'
        + '  <label class="messages-action-modal__field"><span>' + escapeHtml(i18n('chat_report_note_label', 'Note')) + '</span><textarea data-report-note maxlength="1000" placeholder="' + escapeAttr(i18n('messages_report_optional_details', 'Optional details')) + '"></textarea></label>'
        + '  <div class="messages-action-modal__actions">'
        + '    <button type="button" data-modal-cancel>' + escapeHtml(i18n('menu_cancel', 'Cancel')) + '</button>'
        + '    <button type="button" class="is-danger" data-modal-confirm>' + escapeHtml(i18n('chat_action_report', 'Report')) + '</button>'
        + '  </div>'
        + '</div>';
      document.body.appendChild(modal);
      function close(value) {
        if (modal.parentNode) {
          modal.parentNode.removeChild(modal);
        }
        resolve(value);
      }
      modal.addEventListener('click', function (event) {
        if (event.target === modal || event.target.closest('[data-modal-cancel]')) {
          event.preventDefault();
          close(null);
          return;
        }
        if (event.target.closest('[data-modal-confirm]')) {
          event.preventDefault();
          close({
            reason: modal.querySelector('[data-report-reason]')?.value || 'other',
            note: modal.querySelector('[data-report-note]')?.value || ''
          });
        }
      });
      var select = modal.querySelector('[data-report-reason]');
      if (select) {
        select.focus();
      }
    });
  }

  function postConversationEndpoint(endpoint, extra) {
    var targetId = activeConversationId();
    if (!targetId) {
      return Promise.reject(new Error('No active conversation'));
    }
    var body = new URLSearchParams();
    body.set('p', endpoint);
    body.set('to', String(targetId));
    body.set('csrf_token', csrfToken());
    Object.keys(extra || {}).forEach(function (key) {
      body.set(key, String(extra[key]));
    });
    return fetch(buildUrl('request/chat.php'), {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body
    }).then(function (response) {
      return response.json();
    }).then(function (res) {
      if (!res || res.status !== 'success') {
        throw new Error((res && res.message) || 'Action failed');
      }
      return res;
    });
  }

  function postConversationAction(action, extra) {
    var targetId = activeConversationId();
    if (!targetId) {
      return Promise.reject(new Error('No active conversation'));
    }
    var body = new URLSearchParams();
    body.set('p', 'conversationAction');
    body.set('to', String(targetId));
    body.set('action', action);
    body.set('csrf_token', csrfToken());
    Object.keys(extra || {}).forEach(function (key) {
      body.set(key, String(extra[key]));
    });
    return fetch(buildUrl('request/chat.php'), {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body
    }).then(function (response) {
      return response.json();
    }).then(function (res) {
      if (!res || res.status !== 'success') {
        throw new Error((res && res.message) || 'Action failed');
      }
      return res;
    });
  }

  function setActiveConversationPinned(pinned, pinnedAt) {
    var row = activeConversationButton ? activeConversationButton.closest('.messages-page__conversation') : null;
    if (!row) {
      return;
    }
    row.classList.toggle('is-pinned', !!pinned);
    row.setAttribute('data-pinned-at', pinned ? String(pinnedAt || Math.floor(Date.now() / 1000)) : '0');
    var chip = row.querySelector('.messages-page__pin-chip');
    if (pinned && !chip) {
      chip = document.createElement('span');
      chip.className = 'messages-page__pin-chip';
      chip.textContent = i18n('messages_pinned_chip', 'Pinned');
      activeConversationButton.appendChild(chip);
    }
    if (!pinned && chip && chip.parentNode) {
      chip.parentNode.removeChild(chip);
    }
    moveConversationRow(row, !!pinned);
    updatePinMenuLabel();
  }

  function moveConversationRow(row, pinned) {
    var list = row ? row.parentNode : null;
    if (!row || !list) {
      return;
    }
    var rows = Array.prototype.slice.call(list.children).filter(function (child) {
      return child.classList && child.classList.contains('messages-page__conversation');
    });
    if (pinned) {
      var firstRow = rows.find(function (child) {
        return child !== row;
      });
      list.insertBefore(row, firstRow || null);
      return;
    }
    var firstUnpinned = rows.find(function (child) {
      return child !== row && !child.classList.contains('is-pinned');
    });
    if (firstUnpinned) {
      list.insertBefore(row, firstUnpinned);
    }
  }

  function clearActiveThreadMessages() {
    var chatScroll = thread ? thread.querySelector('#chatScroll') : null;
    if (!chatScroll) {
      return;
    }
    chatScroll.querySelectorAll('.chat_message_row, .chat_meta').forEach(function (node) {
      if (node.parentNode) {
        node.parentNode.removeChild(node);
      }
    });
    resetThreadSearchHighlights();
    updateActiveConversationPreview(i18n('chat_message_empty_preview', 'New conversation'));
  }

  async function runConversationStateAction(action) {
    if (action === 'pin') {
      var row = activeConversationButton ? activeConversationButton.closest('.messages-page__conversation') : null;
      var shouldPin = !(row && row.classList.contains('is-pinned'));
      var res = await postConversationAction(shouldPin ? 'pin' : 'unpin');
      var state = res.state || {};
      setActiveConversationPinned(shouldPin, state.pinned_at || 0);
      showMessagesToast(shouldPin ? i18n('messages_toast_chat_pinned', 'Chat pinned.') : i18n('messages_toast_chat_unpinned', 'Chat unpinned.'));
      return;
    }
    if (action === 'clear') {
      var confirmedClear = await confirmConversationAction({
        icon: '!',
        title: i18n('messages_clear_chat_title', 'Clear chat?'),
        text: i18n('messages_clear_chat_text', 'Messages will be cleared for you. The other person will still keep their copy.'),
        confirmLabel: i18n('chat_menu_clear', 'Clear Chat'),
        danger: true
      });
      if (!confirmedClear) {
        return;
      }
      await postConversationAction('clear');
      clearActiveThreadMessages();
      showMessagesToast(i18n('messages_toast_chat_cleared', 'Chat cleared.'));
      return;
    }
    if (action === 'delete') {
      var confirmedDelete = await confirmConversationAction({
        icon: '!',
        title: i18n('messages_delete_chat_title', 'Delete chat?'),
        text: i18n('messages_delete_chat_text', 'This conversation will be removed from your inbox until a new message arrives.'),
        confirmLabel: i18n('chat_menu_delete', 'Delete Chat'),
        danger: true
      });
      if (!confirmedDelete) {
        return;
      }
      await postConversationAction('delete');
      var activeRow = activeConversationButton ? activeConversationButton.closest('.messages-page__conversation') : null;
      resetThread();
      if (activeRow && activeRow.parentNode) {
        activeRow.parentNode.removeChild(activeRow);
      }
      showMessagesToast(i18n('messages_toast_chat_deleted', 'Chat deleted.'));
      return;
    }
    if (action === 'block') {
      var confirmedBlock = await confirmConversationAction({
        icon: '!',
        title: i18n('messages_block_user_title', 'Block this user?'),
        text: i18n('messages_block_user_text', 'They will not be able to continue messaging you from this conversation.'),
        confirmLabel: i18n('chat_menu_block', 'Block'),
        danger: true
      });
      if (!confirmedBlock) {
        return;
      }
      await postConversationAction('block');
      var blockedRow = activeConversationButton ? activeConversationButton.closest('.messages-page__conversation') : null;
      resetThread();
      if (blockedRow) {
        blockedRow.classList.add('is-request');
      }
      showMessagesToast(i18n('messages_toast_user_blocked', 'User blocked.'));
      return;
    }
  }

  async function runConversationUtilityAction(action) {
    if (action === 'download') {
      var res = await postConversationEndpoint('downloadConversation');
      var content = String(res.content || '');
      var filename = String(res.filename || 'creatorpulse-chat.txt');
      window.__lastConversationDownload = { filename: filename, content: content };
      var blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
      var url = URL.createObjectURL(blob);
      var link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      window.setTimeout(function () {
        URL.revokeObjectURL(url);
        if (link.parentNode) {
          link.parentNode.removeChild(link);
        }
      }, 100);
      showMessagesToast(i18n('messages_toast_download_prepared', 'Chat download prepared.'));
      return;
    }
    if (action === 'report') {
      var payload = await promptConversationReport();
      if (!payload) {
        return;
      }
      await postConversationEndpoint('reportConversation', payload);
      showMessagesToast(i18n('messages_toast_report_sent', 'Report sent.'));
      return;
    }
  }

  function handleConversationMenuAction(button) {
    var action = button.getAttribute('data-chat-menu-action') || '';
    closeConversationMenu();
    if (action === 'info') {
      toggleConversationDetails();
      return;
    }
    if (action === 'search') {
      openThreadSearch();
      return;
    }
    if (!activeConversationId()) {
      showMessagesToast(i18n('messages_select_first', 'Select a conversation first.'), 'error');
      return;
    }
    if (['clear', 'delete', 'pin', 'block'].indexOf(action) !== -1) {
      runConversationStateAction(action).catch(function () {
        showMessagesToast(i18n('messages_action_failed', 'Action could not be completed.'), 'error');
      });
      return;
    }
    if (['download', 'report'].indexOf(action) !== -1) {
      runConversationUtilityAction(action).catch(function () {
        showMessagesToast(i18n('messages_action_failed', 'Action could not be completed.'), 'error');
      });
      return;
    }
    showMessagesToast(i18n('messages_action_failed', 'Action could not be completed.'), 'error');
  }

  function focusChatMessage(messageId) {
    messageId = Number(messageId || 0);
    if (!messageId || !thread) {
      return;
    }
    closeAssetsModal();
    var selector = '.chat_message_row[data-mid="' + String(messageId).replace(/"/g, '') + '"]';
    var row = thread.querySelector(selector);
    if (!row) {
      return;
    }
    row.scrollIntoView({ behavior: 'smooth', block: 'center' });
    row.classList.add('messages-page__message-focus');
    window.setTimeout(function () {
      row.classList.remove('messages-page__message-focus');
    }, 1800);
  }

  function unlockActiveRequestConversation() {
    var banner = thread ? thread.querySelector('[data-message-request-banner]') : null;
    if (banner && banner.parentNode) {
      banner.parentNode.removeChild(banner);
    }
    var inputArea = thread ? thread.querySelector('.chat_input_area') : null;
    if (inputArea) {
      inputArea.classList.remove('is-locked');
      inputArea.querySelectorAll('textarea, input, button').forEach(function (node) {
        node.disabled = false;
      });
      inputArea.querySelectorAll('.is-disabled').forEach(function (node) {
        node.classList.remove('is-disabled');
      });
    }
    if (activeConversationButton) {
      activeConversationButton.querySelectorAll('.messages-page__request-chip').forEach(function (chip) {
        if (chip.parentNode) {
          chip.parentNode.removeChild(chip);
        }
      });
      var row = activeConversationButton.closest('.messages-page__conversation');
      if (row) {
        row.classList.remove('is-request');
      }
    }
  }

  function removeActiveRequestConversation() {
    var row = activeConversationButton ? activeConversationButton.closest('.messages-page__conversation') : null;
    resetThread();
    if (row && row.parentNode) {
      row.parentNode.removeChild(row);
    }
  }

  function handleMessageRequestAction(button) {
    var requestId = parseInt(button.getAttribute('data-request-id') || '0', 10);
    var action = button.getAttribute('data-message-request-action') || '';
    if (!requestId || ['accept', 'decline', 'block'].indexOf(action) === -1) {
      return;
    }
    button.disabled = true;
    var body = new URLSearchParams();
    body.set('p', 'messageRequestAction');
    body.set('request_id', String(requestId));
    body.set('action', action);
    body.set('csrf_token', csrfToken());
    fetch(buildUrl('request/chat.php'), {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body
    })
      .then(function (response) { return response.json(); })
      .then(function (res) {
        if (!res || res.status !== 'success') {
          throw new Error((res && res.message) || 'Request action failed');
        }
        if (action === 'accept') {
          unlockActiveRequestConversation();
        } else {
          removeActiveRequestConversation();
        }
      })
      .catch(function () {
        button.disabled = false;
      });
  }

  function escapeHtml(value) {
    return String(value || '').replace(/[&<>"']/g, function (ch) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[ch] || ch;
    });
  }

  function escapeAttr(value) {
    return escapeHtml(value).replace(/`/g, '&#096;');
  }

  function openConversation(button) {
    var id = parseInt(button.getAttribute('data-id') || '0', 10);
    if (!id) {
      return;
    }

    document.querySelectorAll('[data-message-conversation].is-active').forEach(function (el) {
      el.classList.remove('is-active');
      var row = el.closest('.messages-page__conversation');
      if (row) {
        row.classList.remove('is-active');
      }
    });
    button.classList.add('is-active');
    activeConversationButton = button;
    var activeRow = button.closest('.messages-page__conversation');
    if (activeRow) {
      activeRow.classList.add('is-active');
    }
    setConversationUrl(id);
    page.classList.add('messages-page--chat-open');
    closeDrawer();
    setDetailsVisible(true);
    updateDetails(button, null);
    setLoading();

    var body = new URLSearchParams();
    body.set('p', 'get_live_chat');
    body.set('id', String(id));
    body.set('csrf_token', csrfToken());

    fetch(buildUrl('request/requests.php'), {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body
    })
      .then(function (response) { return response.json(); })
      .then(function (res) {
        if (!res || res.status !== 'success') {
          throw new Error((res && res.message) || 'Load failed');
        }
        thread.classList.remove('is-loading');
        thread.classList.add('has-chat');
        updateDetails(button, res.details || null);
        return injectHTMLWithScripts(thread, res.html || '').then(function () {
          var textarea = thread.querySelector("textarea[name='post-text']");
          if (textarea) {
            textarea.focus();
          }
          try {
            document.dispatchEvent(new CustomEvent('chat:opened', { detail: { withId: res.chat_user_id || id } }));
          } catch (_) {}
          if (window.innerWidth <= 560) {
            thread.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
          watchThreadMessages();
        });
      })
      .catch(function (err) {
        console.warn(err);
        setError();
      });
  }

  document.addEventListener('click', function (event) {
    var menuToggle = event.target.closest('[data-chat-menu-toggle]');
    if (menuToggle) {
      event.preventDefault();
      event.stopPropagation();
      toggleConversationMenu(menuToggle);
      return;
    }

    var menuAction = event.target.closest('[data-chat-menu-action]');
    if (menuAction) {
      event.preventDefault();
      event.stopPropagation();
      handleConversationMenuAction(menuAction);
      return;
    }

    var threadSearchToggle = event.target.closest('[data-chat-thread-search-toggle]');
    if (threadSearchToggle) {
      event.preventDefault();
      event.stopPropagation();
      toggleThreadSearch();
      return;
    }

    var threadSearchClose = event.target.closest('[data-chat-thread-search-close]');
    if (threadSearchClose) {
      event.preventDefault();
      closeThreadSearch();
      return;
    }

    var threadSearchPrev = event.target.closest('[data-chat-thread-search-prev]');
    if (threadSearchPrev) {
      event.preventDefault();
      selectThreadSearchMatch(threadSearchIndex - 1);
      return;
    }

    var threadSearchNext = event.target.closest('[data-chat-thread-search-next]');
    if (threadSearchNext) {
      event.preventDefault();
      selectThreadSearchMatch(threadSearchIndex + 1);
      return;
    }

    if (thread && !event.target.closest('.chat_header_more')) {
      closeConversationMenu();
    }

    var close = event.target.closest('.messages-page__thread .back-prev-chat, .messages-page__thread .getChatList');
    if (close) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      if (isMobileMessagesLayout()) {
        setDrawerOpen(true, close);
        return;
      }
      resetThread();
      return;
    }

    var drawerClose = event.target.closest('[data-messages-drawer-close]');
    if (drawerClose) {
      event.preventDefault();
      closeDrawer();
      return;
    }

    var detailsTab = event.target.closest('[data-messages-detail-tab]');
    if (detailsTab) {
      event.preventDefault();
      activateDetailsTab(detailsTab);
      return;
    }

    var assetsOpen = event.target.closest('[data-messages-assets-open]');
    if (assetsOpen) {
      event.preventDefault();
      openAssetsModal(assetsOpen.getAttribute('data-messages-assets-open') || 'media');
      return;
    }

    var assetsClose = event.target.closest('[data-messages-assets-close]');
    if (assetsClose || (assetsModal && event.target === assetsModal)) {
      event.preventDefault();
      closeAssetsModal();
      return;
    }

    var openChatMessage = event.target.closest('[data-messages-open-chat-message]');
    if (openChatMessage) {
      event.preventDefault();
      focusChatMessage(openChatMessage.getAttribute('data-messages-open-chat-message'));
      return;
    }

    var requestAction = event.target.closest('[data-message-request-action]');
    if (requestAction) {
      event.preventDefault();
      handleMessageRequestAction(requestAction);
      return;
    }

    var button = event.target.closest('[data-message-conversation]');
    if (!button) {
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    openConversation(button);
  }, true);

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      if (assetsModal) {
        closeAssetsModal();
        return;
      }
      if (page.classList.contains('messages-page--drawer-open')) {
        closeDrawer();
        return;
      }
      closeConversationMenu();
      closeThreadSearch();
    }
  });

  document.addEventListener('input', function (event) {
    if (event.target && event.target.matches('[data-chat-thread-search-input]')) {
      runThreadSearch();
    }
  });

  document.addEventListener('keydown', function (event) {
    if (!event.target || !event.target.matches('[data-chat-thread-search-input]')) {
      return;
    }
    if (event.key === 'Enter') {
      event.preventDefault();
      selectThreadSearchMatch(threadSearchIndex + (event.shiftKey ? -1 : 1));
    }
  });

  function normalizeText(value) {
    return String(value || '').toLocaleLowerCase().trim();
  }

  function stopThreadObserver() {
    if (threadObserver) {
      try {
        threadObserver.disconnect();
      } catch (_) {}
      threadObserver = null;
    }
  }

  function extractMessagePreview(row) {
    if (!row) {
      return '';
    }
    if (row.querySelector('.chat_paid_media')) {
      return i18n('chat_preview_sent_paid_media', 'Sent paid media');
    }
    var clone = row.cloneNode(true);
    clone.querySelectorAll('.chat_status, .tick_icon, .chat_message_actions, .chat_reactions, .chat_reaction_rail, .chat_action_menu, .chat_reply_quote, svg, img, video, source').forEach(function (node) {
      if (node.parentNode) {
        node.parentNode.removeChild(node);
      }
    });
    var text = clone.textContent || '';
    text = text.replace(/\s+/g, ' ').trim();
    if (text !== '') {
      return text.length > 92 ? text.slice(0, 89) + '...' : text;
    }
    if (row.querySelector('img')) {
      return 'Sent an image';
    }
    if (row.querySelector('video')) {
      return 'Sent a video';
    }
    if (row.querySelector('.chat-share-card')) {
      return 'Shared a post';
    }
    return 'Sent an attachment';
  }

  function updateActiveConversationPreview(text) {
    if (!activeConversationButton || !text) {
      return;
    }
    var preview = activeConversationButton.querySelector('.messages-page__preview');
    var time = activeConversationButton.querySelector('time');
    var row = activeConversationButton.closest('.messages-page__conversation');
    var list = row ? row.parentNode : null;

    if (preview) {
      preview.textContent = text;
    }
    if (time) {
      time.textContent = 'just now';
    }
    if (row && list) {
      var firstRow = Array.prototype.slice.call(list.children).find(function (child) {
        return child !== row && child.classList && child.classList.contains('messages-page__conversation');
      });
      list.insertBefore(row, firstRow || list.firstChild);
      row.setAttribute('data-search-text', normalizeText([
        activeConversationButton.getAttribute('data-name') || '',
        activeConversationButton.getAttribute('data-username') || '',
        text
      ].join(' ')));
    }
  }

  function watchThreadMessages() {
    stopThreadObserver();
    var chatScroll = thread.querySelector('#chatScroll');
    if (!chatScroll) {
      return;
    }
    threadObserver = new MutationObserver(function (mutations) {
      mutations.forEach(function (mutation) {
        Array.prototype.slice.call(mutation.addedNodes || []).forEach(function (node) {
          if (!node || node.nodeType !== 1) {
            return;
          }
          var row = node.classList && node.classList.contains('chat_message_row')
            ? node
            : (node.querySelector ? node.querySelector('.chat_message_row') : null);
          if (row) {
            updateActiveConversationPreview(extractMessagePreview(row));
          }
        });
      });
    });
    threadObserver.observe(chatScroll, { childList: true, subtree: false });
  }

  function filterConversations() {
    if (!searchInput) {
      return;
    }
    var query = normalizeText(searchInput.value);
    var visible = 0;

    document.querySelectorAll('.messages-page__conversation').forEach(function (row) {
      var haystack = row.getAttribute('data-search-text') || row.textContent || '';
      var match = query === '' || normalizeText(haystack).indexOf(query) !== -1;
      row.hidden = !match;
      if (match) {
        visible += 1;
      }
    });

    if (noResults) {
      noResults.hidden = !(query !== '' && visible === 0);
    }
  }

  if (searchInput) {
    searchInput.addEventListener('input', filterConversations);
    searchInput.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        searchInput.value = '';
        filterConversations();
      }
    });
  }

  if (mobileMessagesQuery && typeof mobileMessagesQuery.addEventListener === 'function') {
    mobileMessagesQuery.addEventListener('change', syncDrawerForViewport);
  } else if (mobileMessagesQuery && typeof mobileMessagesQuery.addListener === 'function') {
    mobileMessagesQuery.addListener(syncDrawerForViewport);
  } else {
    window.addEventListener('resize', syncDrawerForViewport);
  }

  function openInitialConversation() {
    var id = requestedConversationId();
    if (!id) {
      return;
    }
    var selector = '[data-message-conversation][data-id="' + String(id).replace(/"/g, '') + '"]';
    var button = document.querySelector(selector);
    if (button) {
      openConversation(button);
    } else {
      setConversationUrl(0);
    }
  }

  openInitialConversation();
  syncDrawerForViewport();
})();
