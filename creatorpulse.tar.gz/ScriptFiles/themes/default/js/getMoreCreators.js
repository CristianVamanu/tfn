(function () {
  "use strict";

  var container  = document.getElementById("creators-container");
  var sentinel   = document.getElementById("creators-sentinel");
  var loadingEl  = document.getElementById("creators-loading");
  if (!container || !sentinel) { return; }

  var limit   = parseInt(container.getAttribute("data-limit")  || "24", 10);
  var offset  = parseInt(container.getAttribute("data-offset") || "24", 10);
  var loading = false;
  var hasMore = true;

  function setLoading(v){
    loading = !!v;
    if (!loadingEl) return;
    loadingEl.classList.toggle("none", !v);
  }

  function fetchMore() {
    if (loading || !hasMore) return;
    setLoading(true);

    var csrf = (document.querySelector('input[name="csrf_token"]') || {}).value || "";
    var body = new URLSearchParams();
    body.set("p", "moreUser");
    body.set("limit", String(limit));
    body.set("offset", String(offset));
    body.set("csrf_token", csrf);

    var endpoint = (typeof window.buildUrl === 'function')
      ? window.buildUrl('request/requests.php')
      : ((typeof window.site_url !== 'undefined' && window.site_url) ? (window.site_url + 'request/requests.php') : 'request/requests.php');
    fetch(endpoint, {
      method: "POST",
      headers: {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"},
      body: body.toString()
    })
    .then(function(r){ return r.json(); })
    .then(function(res){
      if (res && res.status === "ok" && res.html) {
        var temp = document.createElement("div");
        temp.innerHTML = res.html;
        // append children in a doc fragment
        var frag = document.createDocumentFragment();
        Array.prototype.slice.call(temp.children).forEach(function(el){ frag.appendChild(el); });
        container.appendChild(frag);

        offset  = parseInt(res.next_offset || offset, 10);
        hasMore = !!res.has_more;
        container.setAttribute("data-offset", String(offset));
      } else {
        hasMore = false;
      }
    })
    .catch(function(){ /* swallow; keep UX smooth */ })
    .finally(function(){ setLoading(false); });
  }

  // Observer
  var io = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if (entry.isIntersecting) { fetchMore(); }
    });
  }, {root: null, rootMargin: "600px 0px", threshold: 0}); // early prefetch

  io.observe(sentinel);
})();
