(function ($) {
  'use strict';

  // ===== ONE-STEP REELS (scroll-root aware + cooldown + animated snap) ===
  // Works whether the page scrolls the window or an inner container.

  var WHEEL_THRESHOLD   = 20;   // sum of deltaY before firing one step
  var SWIPE_THRESHOLD   = 50;   // px between touchstart and touchend
  var SCROLL_IDLE_MS    = 80;   // debounce for scroll-settled
  var STEP_COOLDOWN_MS  = 900;  // pause after a snap
  var SCROLL_ANIM_MS    = 480;  // a bit slower to make motion visible

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function getPreference(key, fallback) {
    try {
      var prefs = (window.DZ && window.DZ.userPreferences) ? window.DZ.userPreferences : {};
      if (Object.prototype.hasOwnProperty.call(prefs, key)) {
        if (typeof fallback === 'boolean') { return !!prefs[key]; }
        if (typeof fallback === 'string') { return (typeof prefs[key] === 'string') ? prefs[key] : fallback; }
        return prefs[key];
      }
    } catch (_) {}
    return fallback;
  }

  function isScrollable(el) {
    if (!el) { return false; }
    var cs = window.getComputedStyle(el);
    var oy = cs.overflowY;
    return (oy === 'auto' || oy === 'scroll') && (el.scrollHeight > el.clientHeight + 1);
  }

  function findScrollRoot(sampleEl) {
    var n = sampleEl ? sampleEl.parentElement : null;
    while (n && n !== document.body && n !== document.documentElement) {
      if (isScrollable(n)) { return n; }
      n = n.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }

  function offsetTopWithin(el, root) {
    var y = 0, n = el;
    while (n && n !== root && n !== document.body) {
      y += n.offsetTop;
      n = n.offsetParent;
    }
    return y;
  }

  function computeTops($posts, root) {
    // Compute each post's absolute scroll target within the actual scroll root
    var tops = [];
    var isWindow = (!root || root === document.scrollingElement || root === document.documentElement || root === document.body);
    $posts.each(function () {
      var postRect = this.getBoundingClientRect();
      var baseScroll = currentScroll(root);
      if (isWindow) {
        tops.push(baseScroll + postRect.top);
      } else {
        var rootRect = root.getBoundingClientRect();
        tops.push(baseScroll + (postRect.top - rootRect.top));
      }
    });
    return tops;
  }

  function currentScroll(root) {
    if (!root || root === document.scrollingElement || root === document.documentElement || root === document.body) {
      return window.scrollY || document.documentElement.scrollTop || 0;
    }
    return root.scrollTop;
  }

  // -------- animated scrolling (requestAnimationFrame; consistent on Safari/Chrome/Opera) ----
  function animateScrollTo(root, to, duration) {
    var start = currentScroll(root);
    var change = to - start;
    if (change === 0 || duration <= 0) {
      if (!root || root === document.scrollingElement || root === document.documentElement || root === document.body) {
        window.scrollTo(0, to);
      } else { root.scrollTop = to; }
      return Promise.resolve();
    }
    var startTime = null;
    // easeInOutQuad
    function ease(t) { return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; }
    return new Promise(function (resolve) {
      function step(ts) {
        if (startTime === null) { startTime = ts; }
        var p = Math.min(1, (ts - startTime) / duration);
        var v = start + change * ease(p);
        if (!root || root === document.scrollingElement || root === document.documentElement || root === document.body) {
          window.scrollTo(0, v);
        } else { root.scrollTop = v; }
        if (p < 1) { requestAnimationFrame(step); } else { resolve(); }
      }
      requestAnimationFrame(step);
    });
  }

  function indexNearest(tops, y) {
    var best = 0, dist = Infinity;
    for (var i = 0; i < tops.length; i++) {
      var d = Math.abs(tops[i] - y);
      if (d < dist) { dist = d; best = i; }
    }
    return best;
  }

  function init() {
    var $posts = $('.reels_post_wrapper');
    if ($posts.length === 0) { return; }

    var scrollRoot = findScrollRoot($posts.get(0));
    const contentEl = document.querySelector('.main-content');
    const headerEl  = document.querySelector('.sidebar_header');

    function getContentOffset(){
      var pad = 0;
      if (contentEl) {
        var cs = window.getComputedStyle(contentEl);
        pad = parseFloat(cs.paddingTop) || 0;
      }
      // Include visible sidebar header height (if not display:none)
      var headerH = 0;
      if (headerEl && headerEl.offsetParent !== null) {
        // header is visible in layout
        var r = headerEl.getBoundingClientRect();
        headerH = r.height || 0;
      }
      return pad + headerH; // 🔑 compensate both padding and header
    }

    document.documentElement.setAttribute('data-reelsjs', '1');
    document.documentElement.setAttribute('data-reels-root', scrollRoot === window ? 'window' : (scrollRoot.tagName || 'el'));

    var tops = computeTops($posts, scrollRoot);
    var activeIndex = indexNearest(tops, currentScroll(scrollRoot));
    var wheelBucket = 0;
    var scrollingTO = null;
    var touchStartY = 0, touchActive = false;
    var isSnapping = false;        // programmatic scroll in progress
    var cooldownUntil = 0;         // timestamp until which we ignore new steps

    function calcTargetY(idx) {
      idx = clamp(idx, 0, tops.length - 1);
      var baseY = tops[idx];
      var vpH = (!scrollRoot || scrollRoot === document.scrollingElement || scrollRoot === document.documentElement || scrollRoot === document.body)
                ? window.innerHeight : scrollRoot.clientHeight;
      var postEl = $posts.get(idx);
      var postH = postEl ? postEl.getBoundingClientRect().height : vpH;
      var y = baseY - (vpH - postH) / 2; // center align
      return Math.max(0, Math.round(y));
    }

    function setCssSnapDuringAnimation(isAnimating) {
      if (!scrollRoot) return;
      if (isAnimating) {
        scrollRoot.classList.add('reels-snapping'); // CSS disables snap when this class exists
      } else {
        scrollRoot.classList.remove('reels-snapping');
      }
    }

    function now() { return (window.performance && performance.now) ? performance.now() : Date.now(); }
    function inCooldown() { return now() < cooldownUntil; }
    function startCooldown() { cooldownUntil = now() + STEP_COOLDOWN_MS; }

    function onVideoClick(e) {
      var v = e.currentTarget || e.target;
      if (!v || !v.pause || !v.play) { return; }
      try {
        if (v.paused) { v.play().catch(function () {}); }
        else { v.pause(); }
      } catch (_) {}
    }

    function playOnly(index) {
      var allowAutoplay = getPreference('feed_autoplay', true);
      var firstVideo = $posts.find('video.post-media').get(0);
      if (firstVideo) {
        var attrPref = (firstVideo.dataset.prefAutoplay || '').toLowerCase();
        if (attrPref === 'off') { allowAutoplay = false; }
        else if (attrPref === 'on') { allowAutoplay = true; }
      }
      if (!allowAutoplay) {
        $posts.each(function () {
          var pauseVideo = $(this).find('video.post-media').get(0);
          if (pauseVideo && !pauseVideo.paused) {
            try { pauseVideo.pause(); } catch (_) {}
          }
        if (pauseVideo) {
            pauseVideo.removeAttribute('autoplay');
            pauseVideo.dataset.prefAutoplay = 'off';
          }
        });
        return;
      }
      $posts.each(function (i) {
        var v = $(this).find('video.post-media').get(0);
        if (!v) { return; }
        v.dataset.prefAutoplay = 'on';
        try { if (i === index) { if (v.paused) { v.play().catch(function () {}); } } else { if (!v.paused) { v.pause(); } } } catch (_) {}
      });
    }

    function snapTo(index) {
        index = clamp(index, 0, tops.length - 1);
        if (index === activeIndex) { return; }

        var y = calcTargetY(index);
        isSnapping = true;

        playOnly(index);
        wheelBucket = 0;
        setCssSnapDuringAnimation(true); // 🔑 temporarily disable CSS snap

        animateScrollTo(scrollRoot, y, SCROLL_ANIM_MS).then(function () {
            activeIndex = index;
            startCooldown();
            isSnapping = false;
            // hard-set the exact final Y to avoid any 1-2px wobble
            if (!scrollRoot || scrollRoot === document.scrollingElement || scrollRoot === document.documentElement || scrollRoot === document.body) {
              window.scrollTo(0, y);
            } else { scrollRoot.scrollTop = y; }
            setTimeout(function(){ setCssSnapDuringAnimation(false); }, 30); // re-enable after paint
        });
        }

    function refreshAndPin(toIndex) {
      tops = computeTops($posts, scrollRoot);
      snapTo(toIndex);
    }

    // Initial align (no animation to avoid startup wobble)
    (function instantFirstAlign() {
      var y = calcTargetY(activeIndex);
      if (!scrollRoot || scrollRoot === document.scrollingElement || scrollRoot === document.documentElement || scrollRoot === document.body) {
        window.scrollTo(0, y);
      } else { scrollRoot.scrollTop = y; }
      playOnly(activeIndex);
      startCooldown();
      // Bind click-to-toggle on current and future videos
      $('video.post-media').each(function () {
        this.removeEventListener('click', onVideoClick);
        this.addEventListener('click', onVideoClick);
      });
      // Delegation fallback (if posts are injected later)
      document.addEventListener('click', function (ev) {
        var t = ev.target;
        if (t && t.matches && t.matches('video.post-media')) { onVideoClick(ev); }
      }, { capture: true });
      if (scrollRoot) { scrollRoot.classList.remove('reels-snapping'); }
    })();

    // ---- Wheel/trackpad on the actual scroll root ----------------------
    function onWheel(e) {
      // Allow inner scrollables inside a post
      var t = e.target;
      while (t && t !== scrollRoot && t !== document.body) {
        if (isScrollable(t)) { return; }
        t = t.parentElement;
      }
      e.preventDefault();
      if (isSnapping || inCooldown()) { return; }
      wheelBucket += e.deltaY;
      if (Math.abs(wheelBucket) >= WHEEL_THRESHOLD) {
        var dir = wheelBucket > 0 ? 1 : -1;
        wheelBucket = 0;
        var next = clamp(activeIndex + dir, 0, tops.length - 1);
        if (next !== activeIndex) { snapTo(next); }
      }
    }

    var wheelOpts = { passive: false, capture: true };
    (scrollRoot || window).addEventListener('wheel', onWheel, wheelOpts);
    document.addEventListener('wheel', onWheel, wheelOpts);

    // ---- Touch swipe on the root ---------------------------------------
    function onTouchStart(e) {
      if (e.touches && e.touches.length === 1) { touchActive = true; touchStartY = e.touches[0].clientY; }
    }
    function onTouchMove(e) {
      if (!touchActive) { return; }
      var t = e.target;
      while (t && t !== scrollRoot && t !== document.body) {
        if (isScrollable(t)) { return; }
        t = t.parentElement;
      }
      e.preventDefault();
    }
    function onTouchEnd(e) {
      if (!touchActive || isSnapping || inCooldown()) { touchActive = false; return; }
      var endY = (e.changedTouches && e.changedTouches[0]) ? e.changedTouches[0].clientY : touchStartY;
      var dy = endY - touchStartY; touchActive = false;
      if (Math.abs(dy) < SWIPE_THRESHOLD) { return; }
      var dir = dy < 0 ? 1 : -1;
      var next = clamp(activeIndex + dir, 0, tops.length - 1);
      if (next !== activeIndex) { snapTo(next); }
    }

    (scrollRoot || window).addEventListener('touchstart', onTouchStart, { passive: true, capture: true });
    (scrollRoot || window).addEventListener('touchmove', onTouchMove, { passive: false, capture: true });
    (scrollRoot || window).addEventListener('touchend', onTouchEnd, { passive: true, capture: true });

    // ---- Scroll watchdog on the root -----------------------------------
    function onScroll() {
      if (isSnapping || inCooldown()) { return; }
      clearTimeout(scrollingTO);
      scrollingTO = setTimeout(function () {
        tops = computeTops($posts, scrollRoot);
        var nearest = indexNearest(tops, currentScroll(scrollRoot));
        setCssSnapDuringAnimation(true);
        if (nearest !== activeIndex) { snapTo(nearest); } // snap to the actually nearest card
      }, SCROLL_IDLE_MS);
    }

    (scrollRoot || window).addEventListener('scroll', onScroll, { passive: true, capture: true });

    // ---- Re-measure on resize / video metadata -------------------------
    $(window).on('resize', function () { refreshAndPin(activeIndex); });
    $('video.post-media').each(function () {
      this.addEventListener('loadedmetadata', function () { refreshAndPin(activeIndex); });
    });
  }

  $(window).on('load', init);
})(jQuery);
