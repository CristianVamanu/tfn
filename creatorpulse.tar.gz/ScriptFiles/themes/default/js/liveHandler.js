/* Live popup interactions: audience dropdown + Go Live */
'use strict';
(function(){
  if (window.__liveHandlerBound) return; // avoid double binding
  window.__liveHandlerBound = true;

  var buildUrl = (window.DZ && window.DZ.buildUrl) || function(path){
    try { var base=(typeof window.site_url==='string'&&window.site_url)?window.site_url:(window.location.origin+window.location.pathname.replace(/[^\/]*$/,'')); if(base.slice(-1)!=='/') base+='/'; return new URL(String(path||'').replace(/^\//,''), base).toString(); } catch(_) { return String(path||''); }
  };

  function qs(sel, root){ return (root||document).querySelector(sel); }
  function qsa(sel, root){ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }
  function getCsrf(){ try { return qs('input[name="csrf_token"]').value || ''; } catch(e){ return ''; } }
  var I18N = (window.DZ && typeof DZ.i18n === 'function') ? DZ.i18n : function(){ return ''; };
  var bodyEl = document.body || null;
  var globalLiveEnabled = true;
  var defaultTitlePrefix = '';
  try {
    if (bodyEl) {
      globalLiveEnabled = bodyEl.getAttribute('data-live-stream-enabled') !== '0';
      defaultTitlePrefix = (bodyEl.getAttribute('data-live-title-prefix') || '').trim();
    }
  } catch(_){}
  function ensureDzToast(){
    window.DZ = window.DZ || {};
    if (typeof DZ.toast === 'function') return;
    function ensureContainer(){
      var id = 'dz-toast-container';
      var el = document.getElementById(id);
      if (!el) { el = document.createElement('div'); el.id = id; el.className = 'dz-toast-container'; document.body.appendChild(el); }
      return el;
    }
    DZ.toast = function(msg, opts){
      try {
        var container = ensureContainer();
        var opt  = opts || {};
        var kind = (opt.type === 'error' || opt.type === 'info') ? opt.type : 'success';
        var dur  = typeof opt.duration === 'number' ? Math.max(1000, opt.duration) : 2200;
        var el = document.createElement('div');
        el.className = 'dz-toast ' + (kind === 'error' ? 'is-error' : (kind === 'info' ? 'is-info' : 'is-success'));
        el.setAttribute('role','status'); el.setAttribute('aria-live','polite');
        el.textContent = String(msg || '');
        container.appendChild(el);
        requestAnimationFrame(function(){ el.classList.add('is-shown'); });
        setTimeout(function(){ el.classList.remove('is-shown'); setTimeout(function(){ if (el && el.parentNode) el.parentNode.removeChild(el); }, 220); }, dur);
      } catch(_) {}
    };
  }

  function setGoState(){
    var popup = qs('.popUp-container');
    if(!popup) return;
    var tEl = qs('#liveTitle', popup);
    var btn = qs('#goLiveBtn', popup);
    if(!tEl || !btn) return;
    var t = (tEl.value || '').trim();
    var ok = t.length >= 3;
    if (!globalLiveEnabled) {
      btn.disabled = true;
      btn.classList.add('disabled');
      btn.setAttribute('aria-disabled', 'true');
      return;
    }
    btn.disabled = !ok;
    if (ok) {
      btn.classList.remove('disabled');
      btn.removeAttribute('aria-disabled');
    } else {
      btn.classList.add('disabled');
      btn.setAttribute('aria-disabled', 'true');
    }
  }

  // Toggle audience popup (mini modal inside live popup)
  document.addEventListener('click', function(ev){
    var tgt = ev.target;
    var popup = qs('.popUp-container');
    if(!popup) return;
    var overlay = qs('#audiencePopup', popup);
    var toggle = qs('#audienceToggle', popup);
    if(!overlay || !toggle) return;

    // Open popup
    if (toggle.contains(tgt)) {
      ev.preventDefault();
      overlay.classList.remove('none');
      return;
    }

    // Option clicked inside popup
    if (overlay.contains(tgt) && tgt.classList && (tgt.classList.contains('audienceOption') || tgt.classList.contains('aud-item'))) {
      var val = tgt.getAttribute('data-value') || 'everyone';
      var label = qs('#audienceLabel', popup);
      var hidden = qs('#liveAudience', popup);
      if (hidden) hidden.value = val;
      if (label) label.textContent = (tgt.textContent || 'Everyone').trim();
      // Active state
      qsa('.audienceOption', overlay).forEach(function(el){ el.classList.remove('active'); });
      if (tgt.classList.contains('audienceOption')) { tgt.classList.add('active'); }
      overlay.classList.add('none');
      return;
    }

    // Close via overlay click (outside container)
    if (!overlay.classList.contains('none')) {
      var container = qs('.aud-sheet-container', overlay) || qs('.set-price-popup-container', overlay);
      if (tgt === overlay || (!container.contains(tgt) && overlay.contains(tgt))) {
        overlay.classList.add('none');
        return;
      }
    }
  });

  // Cancel button inside popup
  document.addEventListener('click', function(ev){
    var tgt = ev.target;
    if (tgt && tgt.id === 'audienceCancel') {
      var popup = qs('.popUp-container');
      var overlay = popup ? qs('#audiencePopup', popup) : null;
      if (overlay) overlay.classList.add('none');
    }
  });

  // Enable/disable button on input
  document.addEventListener('input', function(ev){
    if (ev.target && ev.target.id === 'liveTitle') { setGoState(); }
  });
  document.addEventListener('blur', function(ev){
    if (ev.target && ev.target.id === 'liveTitle') { setGoState(); }
  }, true);

  (function applyDefaultPrefixOnce(){
    if (!globalLiveEnabled) { return; }
    if (!defaultTitlePrefix) { return; }
    var popup = qs('.popUp-container');
    if (!popup) { return; }
    var tEl = qs('#liveTitle', popup);
    if (!tEl) { return; }
    if ((tEl.value || '').trim() !== '') { return; }
    var prefix = defaultTitlePrefix;
    var lastChar = prefix.slice(-1);
    if (prefix && lastChar !== ' ') {
      if (lastChar === ':' || lastChar === '-' || lastChar === '—') {
        prefix += ' ';
      } else {
        prefix += ' ';
      }
    }
    tEl.value = prefix;
    setGoState();
  })();

  // Go Live click
  document.addEventListener('click', function(ev){
    var tgt = ev.target;
    if (!tgt || tgt.id !== 'goLiveBtn') return;
    ev.preventDefault();
    if (!globalLiveEnabled) {
      ensureDzToast();
      var disabledMsg = I18N('live_stream_disabled_hint') || 'Live streaming is currently disabled.';
      DZ.toast(disabledMsg, { type: 'info' });
      return;
    }
    var popup = qs('.popUp-container');
    if(!popup) return;
    var titleEl = qs('#liveTitle', popup);
    var audEl   = qs('#liveAudience', popup);
    if(!titleEl || !audEl) return;
    var title = (titleEl.value || '').trim();
    if (title.length < 3) { return; }
    var audience = audEl.value || 'everyone';
    tgt.disabled = true; tgt.classList.add('disabled');

    var fd = new FormData();
    fd.append('p','create_live');
    fd.append('title', title);
    fd.append('audience', audience);
    fd.append('csrf_token', getCsrf());

    fetch(buildUrl('request/requests.php'), { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(r => r.json())
      .then(j => {
        if (j && j.status === 'success' && j.url) { window.location.href = j.url; return; }
        ensureDzToast();
        var msgCode = (j && typeof j.message === 'string') ? j.message : '';
        var msg = msgCode ? (I18N(msgCode) || msgCode) : (I18N('live_create_failed') || 'Create live failed.');
        DZ.toast(msg, { type: 'error' });
        tgt.disabled = false; tgt.classList.remove('disabled');
      })
      .catch(() => {
        ensureDzToast();
        var msg = I18N('live_request_failed') || 'Request failed.';
        DZ.toast(msg, { type: 'error' });
        tgt.disabled = false; tgt.classList.remove('disabled');
      });
  });

  // End Live: Stop Agora (if any) + notify backend
  document.addEventListener('click', function(ev){
    var tgt = ev.target;
    if (!(tgt && tgt.id === 'endLiveBtn')) return;
    ev.preventDefault();

    // Resolve live id from page container
    var root = qs('.contents_box[data-live-id]') || qs('[data-live-id]');
    var liveId = 0;
    try { liveId = parseInt((root && root.getAttribute('data-live-id')) || '0', 10) || 0; } catch(e){}
    if (!liveId) { ensureDzToast(); var m1 = I18N('live_session_not_found') || 'Live session not found.'; DZ.toast(m1, { type: 'error' }); return; }

    // Disable button UI
    var prevTxt = (tgt.textContent || '').trim();
    tgt.classList.add('disabled');
    tgt.setAttribute('aria-disabled', 'true');
    tgt.textContent = (I18N('live_ending') || 'Ending…');

    (async function(){
      try {
        var fd = new FormData();
        fd.append('p','end_live');
        fd.append('live_id', String(liveId));
        fd.append('csrf_token', getCsrf());
        var res = await fetch(buildUrl('request/requests.php'), { method:'POST', body: fd, credentials:'same-origin' });
        var j = await res.json();
        if (!j || j.status !== 'success') {
          var errMsg = (j && j.message) ? j.message : (I18N('live_end_failed') || 'End live failed');
          throw new Error(errMsg);
        }
        // Broadcast to RTM channel so viewers can auto-redirect
        try {
          var rtmRef = window.__agoraRtmRef;
          if (rtmRef && rtmRef.channel) {
            var redirBase = (typeof window.buildUrl === 'function') ? window.buildUrl('') : ((typeof window.site_url !== 'undefined' && window.site_url) ? window.site_url : (window.location.origin + '/'));
            var redirMsg = { type: 'live_ended', redirect: (typeof j.redirect === 'string' && j.redirect) ? j.redirect : redirBase };
            try { await rtmRef.channel.sendMessage({ text: JSON.stringify(redirMsg) }); } catch(_){ /* ignore */ }
            try { await rtmRef.channel.sendMessage({ text: 'LIVE_ENDED' }); } catch(_){ /* legacy fallback */ }
          }
        } catch(_){ /* ignore */ }
        // Attempt to gracefully leave Agora (RTC/RTM), if present
        try { if (window.agoraLeave) { await window.agoraLeave(); } } catch(e){}
        // Redirect user (owner)
        var redir = (j.redirect && typeof j.redirect === 'string') ? j.redirect : ((typeof window.buildUrl === 'function') ? window.buildUrl('') : ((typeof window.site_url !== 'undefined' && window.site_url) ? window.site_url : (window.location.origin + '/')));
        window.location.href = redir;
      } catch (e) {
        ensureDzToast();
        var dmsg = String(e && e.message ? e.message : (I18N('live_end_failed') || 'End live failed'));
        DZ.toast(dmsg, { type: 'error' });
        tgt.classList.remove('disabled');
        tgt.removeAttribute('aria-disabled');
        tgt.textContent = prevTxt || (I18N('live_end_button') || 'End Live');
      }
    })();
  });

  // Simple local chat append (placeholder UI only)
  document.addEventListener('submit', function(ev){
    var form = ev.target;
    if (!form || form.id !== 'liveChatForm') return;
    // If dedicated liveChat is active or RTM is active, skip placeholder
    if (window.__rtmActive || window.__liveChatBound) return;
    ev.preventDefault();
    var input = document.getElementById('liveChatInput');
    var body  = document.getElementById('liveChatBody');
    if (!input || !body) return;
    var t = (input.value || '').trim();
    if (!t) return;
    var div = document.createElement('div');
    div.className = 'live-chat-msg';
    var from = document.createElement('span'); from.className = 'from'; from.textContent = 'You';
    var msg  = document.createElement('span'); msg.className = 'msg'; msg.textContent = ' ' + t;
    div.appendChild(from); div.appendChild(msg);
    body.appendChild(div);
    input.value = '';
    body.scrollTop = body.scrollHeight;
  });

  // Initialize state when popup inserted
  function tryInit(){ setTimeout(setGoState, 60); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', tryInit);
  tryInit();
  try {
    var mo = new MutationObserver(function(muts){
      for (var i=0;i<muts.length;i++){
        var nodes = muts[i].addedNodes || [];
        for (var j=0;j<nodes.length;j++){
          var n = nodes[j];
          if (n.nodeType === 1 && (n.classList.contains('popUp-container') || (n.querySelector && n.querySelector('.popUp-container')))) {
            tryInit();
            return;
          }
        }
      }
    });
    mo.observe(document.body, { childList: true, subtree: true });
  } catch(e){}
})();
