(function () {
  "use strict";
  var I18N = (window.DZ && typeof DZ.i18n === 'function') ? DZ.i18n : function(){ return ''; };
  // Delegate to support dynamically loaded cards
  document.addEventListener("click", function (ev) {
    var btn = ev.target.closest(".follow_this_user");
    if (!btn) return;

    var targetId = parseInt(btn.getAttribute("data-id") || "0", 10);
    if (!targetId) return;

    // Prevent double-clicks
    if (btn.dataset.loading === "1") return;
    btn.dataset.loading = "1";

    var csrf = (document.querySelector('input[name="csrf_token"]') || {}).value || "";
    var body = new URLSearchParams();
    body.set("p", "follow_unfollow");
    body.set("target_id", String(targetId));
    body.set("csrf_token", csrf);

    var endpoint = (typeof window.buildUrl === 'function')
      ? window.buildUrl('request/requests.php')
      : ((typeof window.site_url !== 'undefined' && window.site_url) ? (window.site_url + 'request/requests.php') : 'request/requests.php');
    fetch(endpoint, {
      method: "POST",
      headers: {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"},
      body: body.toString()
    })
    .then(function(r){ return r.json(); })
    .then(function(res){
      if (!res || res.status !== "success") return;

      var following = !!res.following;

      // --- Update button state (no PHP in JS) ---
      btn.classList.toggle("is-following", following);
      btn.setAttribute("aria-pressed", following ? "true" : "false");

      // Preferred markup: <span class="follow_me">[icon]</span><span class="follow_label">Follow</span>
      // If .follow_label exists, just update its text.
      var labelEl = btn.querySelector(".follow_label");
      if (labelEl) {
        labelEl.textContent = following ? (I18N('live_following') || 'Following') : (I18N('live_follow') || 'Follow');
      } else {
        // Fallback: try to replace/append the text node after the icon span without touching the icon SVG
        var iconEl = btn.querySelector(".follow_me");
        if (iconEl) {
          // Find next text node sibling; if none, append a label span
          var sib = iconEl.nextSibling;
          // skip over empty text nodes
          while (sib && sib.nodeType === 3 && sib.nodeValue.trim() === "") {
            sib = sib.nextSibling;
          }
          if (sib && sib.nodeType === 3) {
            // Update existing text node (keep a leading space)
            sib.nodeValue = " " + (following ? (I18N('live_following') || 'Following') : (I18N('live_follow') || 'Follow'));
          } else {
            // Create a proper label span and append
            var s = document.createElement("span");
            s.className = "follow_label";
            s.textContent = following ? (I18N('live_following') || 'Following') : (I18N('live_follow') || 'Follow');
            // Ensure a space between icon and label
            iconEl.insertAdjacentText("afterend", " ");
            iconEl.insertAdjacentElement("afterend", s);
          }
        } else {
          // As a last resort, set button text (will remove icon only if icon wasn't present)
          btn.textContent = following ? (I18N('live_following') || 'Following') : (I18N('live_follow') || 'Follow');
        }
      }

      // --- Update counters in the same card (Followers & Following numbers) ---
      var card = btn.closest(".creator-info-wrapper");
      if (card) {
        var wrappers = card.querySelectorAll(".creator-pff-wrapper");
        wrappers.forEach(function(wrap){
          var label = (wrap.querySelector(".ppf-count") || {}).textContent || "";
          var firstLine = wrap.querySelector(":scope > div:first-child");
          if (!firstLine) return;

          if (/followers/i.test(label) && typeof res.followers_total === "number") {
            firstLine.textContent = String(res.followers_total);
          }
          if (/following/i.test(label) && typeof res.following_total === "number") {
            firstLine.textContent = String(res.following_total);
          }
        });
      }
    })
    .catch(function(){ /* swallow */ })
    .finally(function(){ btn.dataset.loading = "0"; });
  });
})();
