(function () {
  'use strict';

  function qs(selector, root) {
    return (root || document).querySelector(selector);
  }

  function csrf() {
    var input = qs('input[name="csrf_token"]');
    return input ? input.value : '';
  }

  function request(formData) {
    var page = qs('.ebooks-page');
    var endpoint = (page && page.getAttribute('data-request-url')) || 'request/requests.php';
    return fetch(endpoint, {
      method: 'POST',
      body: formData,
      credentials: 'same-origin'
    }).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (json) {
        json.httpStatus = response.status;
        return json;
      });
    });
  }

  function setMessage(node, message, isError) {
    if (!node) { return; }
    node.textContent = message || '';
    node.classList.toggle('is-error', !!isError);
    node.classList.toggle('is-success', !!message && !isError);
  }

  function withLoading(button, loading, label) {
    if (!button) { return; }
    if (!button.dataset.originalLabel) {
      button.dataset.originalLabel = button.textContent;
    }
    button.disabled = !!loading;
    button.textContent = loading ? (label || '...') : button.dataset.originalLabel;
  }

  function pageLabel(name, fallback) {
    var page = qs('.ebooks-page');
    return (page && page.getAttribute(name)) || fallback;
  }

  function closeOwnerActionSheet(trigger) {
    var popup = trigger && trigger.closest ? trigger.closest('.post-menu-popup') : null;
    if (!popup) { return; }
    popup.classList.add('none');
    popup.setAttribute('aria-hidden', 'true');
    var popupId = popup.id || '';
    var menuId = popupId.indexOf('postMenuPopup-') === 0 ? popupId.slice(14) : '';
    var button = menuId ? qs('.post-settings-btn[data-id="' + menuId + '"]') : null;
    if (button) { button.setAttribute('aria-expanded', 'false'); }
  }

  function escapeHtml(value) {
    var div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    return div.innerHTML;
  }

  function setModal(open) {
    var modal = qs('[data-ebook-modal]');
    if (!modal) { return; }
    modal.classList.toggle('is-open', !!open);
    modal.setAttribute('aria-hidden', open ? 'false' : 'true');
    document.body.classList.toggle('ebook-modal-open', !!open);
    if (open) {
      window.setTimeout(function () {
        var firstInput = qs('input[name="title"]', modal);
        if (firstInput) { firstInput.focus(); }
      }, 80);
    }
  }

  function formatFileSize(bytes) {
    var size = Number(bytes || 0);
    if (!size) { return ''; }
    if (size < 1024) { return size + ' B'; }
    if (size < 1024 * 1024) { return Math.round(size / 1024) + ' KB'; }
    return (size / (1024 * 1024)).toFixed(size >= 10 * 1024 * 1024 ? 0 : 1) + ' MB';
  }

  function initEbookFileFields(root) {
    Array.prototype.slice.call((root || document).querySelectorAll('[data-ebook-file-field]')).forEach(function (field) {
      var input = qs('input[type="file"]', field);
      var trigger = qs('[data-ebook-file-trigger]', field);
      var nameNode = qs('[data-ebook-file-name]', field);
      var clear = qs('[data-ebook-file-clear]', field);
      var preview = qs('[data-ebook-cover-preview]', field);
      if (!input || !trigger || field.dataset.fileFieldReady === '1') { return; }
      field.dataset.fileFieldReady = '1';
      if (preview && !preview.dataset.placeholderHtml) {
        preview.dataset.placeholderHtml = preview.innerHTML;
      }

      function resetPreview() {
        if (preview && preview.dataset.previewUrl) {
          URL.revokeObjectURL(preview.dataset.previewUrl);
          delete preview.dataset.previewUrl;
        }
        if (preview && preview.dataset.placeholderHtml) {
          preview.innerHTML = preview.dataset.placeholderHtml;
        }
      }

      function renderSelected() {
        var file = input.files && input.files[0] ? input.files[0] : null;
        trigger.classList.toggle('has-file', !!file);
        if (clear) { clear.hidden = !file; }
        if (!file) {
          resetPreview();
          if (nameNode) { nameNode.textContent = field.getAttribute('data-empty-label') || 'No file selected'; }
          return;
        }
        if (nameNode) {
          var size = formatFileSize(file.size);
          nameNode.textContent = file.name + (size ? ' · ' + size : '');
        }
        if (preview && file.type && file.type.indexOf('image/') === 0) {
          resetPreview();
          var url = URL.createObjectURL(file);
          preview.dataset.previewUrl = url;
          preview.innerHTML = '<img src="' + url + '" alt="">';
        }
      }

      trigger.addEventListener('click', function () {
        input.click();
      });
      input.addEventListener('change', renderSelected);
      if (clear) {
        clear.addEventListener('click', function (event) {
          event.preventDefault();
          input.value = '';
          renderSelected();
          trigger.focus();
        });
      }
    });
  }

  function setPurchaseModal(open, card) {
    var modal = qs('[data-ebook-purchase-modal]');
    if (!modal) { return; }
    var form = qs('[data-ebook-payment-form]', modal);
    var message = qs('[data-ebook-payment-message]', modal);
    if (open && card) {
      var ebookId = card.getAttribute('data-ebook-id') || '';
      var title = card.getAttribute('data-ebook-title') || '';
      var creator = card.getAttribute('data-ebook-creator') || '';
      var price = card.getAttribute('data-ebook-price-display') || '';
      var cover = card.getAttribute('data-ebook-cover') || '';
      var idInput = qs('input[name="ebook_id"]', form);
      if (idInput) { idInput.value = ebookId; }
      var titleNode = qs('[data-ebook-purchase-title]', modal);
      var creatorNode = qs('[data-ebook-purchase-creator]', modal);
      var priceNode = qs('[data-ebook-purchase-price]', modal);
      var coverNode = qs('[data-ebook-purchase-cover]', modal);
      if (titleNode) { titleNode.textContent = title; }
      if (creatorNode) { creatorNode.textContent = creator; }
      if (priceNode) { priceNode.textContent = price; }
      if (coverNode) {
        if (!coverNode.dataset.placeholderHtml) {
          coverNode.dataset.placeholderHtml = coverNode.innerHTML;
        }
        coverNode.innerHTML = cover
          ? '<img src="' + escapeHtml(cover) + '" alt="' + escapeHtml(title) + '">'
          : coverNode.dataset.placeholderHtml;
      }
      setMessage(message, '', false);
    }
    modal.classList.toggle('is-open', !!open);
    modal.setAttribute('aria-hidden', open ? 'false' : 'true');
    document.body.classList.toggle('ebook-purchase-modal-open', !!open);
    if (open) {
      window.setTimeout(function () {
        var firstProvider = qs('input[name="provider"]:checked', modal) || qs('input[name="provider"]', modal);
        if (firstProvider) { firstProvider.focus(); }
      }, 80);
    }
  }

  function setOwnerEditModal(open, payload) {
    var modal=qs('[data-owner-edit-modal]'); if(!modal){return;}
    var form=qs('[data-owner-edit-form]',modal);
    if(open&&payload&&form){Object.keys(payload).forEach(function(key){var field=qs('[name="'+key+'"]',form);if(field){field.value=payload[key]==null?'':payload[key];}});}
    modal.classList.toggle('is-open',!!open); modal.setAttribute('aria-hidden',open?'false':'true');
    document.body.classList.toggle('ebook-owner-modal-open',!!open);
    if(open){window.setTimeout(function(){var input=qs('[name="title"]',form);if(input){input.focus();}},60);}
  }

  function initOwnerCatalogFilters() {
    var page = qs('.settings-my-ebooks');
    if (!page) { return; }
    var search = qs('[data-owner-catalog-search]', page);
    var status = qs('[data-owner-catalog-status]', page);
    var results = qs('[data-owner-catalog-results]', page);
    var empty = qs('[data-owner-catalog-empty]', page);
    var rows = Array.prototype.slice.call(page.querySelectorAll('tr[data-owner-ebook-id]'));
    var clearButtons = Array.prototype.slice.call(page.querySelectorAll('[data-owner-catalog-clear]'));
    if (!search || !status || !rows.length) { return; }

    function normalize(value) {
      return String(value || '').toLocaleLowerCase();
    }

    function render() {
      var query = normalize(search.value).trim();
      var selectedStatus = status.value || 'all';
      var visible = 0;
      rows.forEach(function (row) {
        var matchesQuery = !query || normalize(row.getAttribute('data-owner-search')).indexOf(query) !== -1;
        var rowStatus = row.getAttribute('data-owner-status') || 'draft';
        var rowHidden = row.getAttribute('data-owner-hidden') === '1';
        var matchesStatus = selectedStatus === 'all' || rowStatus === selectedStatus || (selectedStatus === 'hidden' && rowHidden);
        var show = matchesQuery && matchesStatus;
        row.hidden = !show;
        if (show) { visible += 1; }
      });
      if (empty) { empty.hidden = visible !== 0; }
      var active = query !== '' || selectedStatus !== 'all';
      clearButtons.forEach(function (button) {
        button.disabled = !active;
        button.hidden = !active;
      });
      if (results) {
        var label = visible === 1
          ? (page.getAttribute('data-results-single-label') || '1 eBook shown')
          : (page.getAttribute('data-results-label') || '{count} eBooks shown').replace('{count}', String(visible));
        results.textContent = label;
      }
    }

    function clear() {
      search.value = '';
      status.value = 'all';
      render();
      search.focus();
    }

    search.addEventListener('input', render);
    status.addEventListener('change', render);
    clearButtons.forEach(function (button) {
      button.addEventListener('click', function (event) {
        event.preventDefault();
        clear();
      });
    });
    render();
  }

  initOwnerCatalogFilters();

  document.addEventListener('click', function (event) {
    var ownerEdit=event.target.closest('[data-owner-edit]');
    if(ownerEdit){event.preventDefault();closeOwnerActionSheet(ownerEdit);try{setOwnerEditModal(true,JSON.parse(ownerEdit.getAttribute('data-ebook')||'{}'));}catch(e){}return;}
    if(event.target.closest('[data-owner-edit-close]')){event.preventDefault();setOwnerEditModal(false);return;}
    var ownerAction=event.target.closest('[data-owner-action]');
    if(ownerAction){event.preventDefault();closeOwnerActionSheet(ownerAction);var item=ownerAction.closest('[data-owner-ebook-id]');if(!item){return;}var action=ownerAction.getAttribute('data-owner-action')||'';
      var confirmText=action==='delete'?pageLabel('data-delete-confirm-label','Delete this eBook?'):(action==='archive'?pageLabel('data-archive-confirm-label','Archive this eBook?'):'');
      if(confirmText&&!window.confirm(confirmText)){return;} var od=new FormData();od.append('p','ebook_owner_action');od.append('ebook_id',item.getAttribute('data-owner-ebook-id')||'');od.append('owner_action',action);od.append('csrf_token',csrf());withLoading(ownerAction,true,'...');
      request(od).then(function(res){if(res&&res.status==='success'){window.location.reload();return;}window.alert((res&&res.message)||pageLabel('data-update-failed-label','The eBook could not be updated.'));}).catch(function(){window.alert(pageLabel('data-update-failed-label','The eBook could not be updated.'));}).finally(function(){withLoading(ownerAction,false);});return;}
    var wish = event.target.closest('[data-ebook-wishlist]');
    if (wish) { event.preventDefault(); var wd=new FormData();wd.append('p','ebook_wishlist_toggle');wd.append('ebook_id',wish.getAttribute('data-ebook-id')||'');wd.append('csrf_token',csrf());request(wd).then(function(res){if(res&&res.status==='success'){wish.classList.toggle('is-active',!!res.wishlisted);wish.setAttribute('aria-pressed',res.wishlisted?'true':'false');var label=qs('span',wish);if(label){label.textContent=res.message||'';}}});return; }
    var couponButton = event.target.closest('[data-ebook-coupon-apply]');
    if (couponButton) { event.preventDefault(); var couponForm=couponButton.closest('form');var cd=new FormData();cd.append('p','ebook_coupon_validate');cd.append('ebook_id',qs('input[name="ebook_id"]',couponForm)?.value||'');cd.append('coupon_code',qs('input[name="coupon_code"]',couponForm)?.value||'');var cm=qs('[data-ebook-coupon-message]',couponForm);request(cd).then(function(res){setMessage(cm,res&&res.status==='success'?(res.code+' - '+res.final_display):((res&&res.message)||'Invalid coupon.'),!(res&&res.status==='success'));});return; }
    var downloadButton = event.target.closest('[data-secure-ebook-download]');
    if (downloadButton) {
      event.preventDefault();
      if (downloadButton.dataset.loading === '1') { return; }
      var downloadData = new FormData();
      downloadData.append('p', 'ebook_download_prepare');
      downloadData.append('ebook_id', downloadButton.getAttribute('data-ebook-id') || '');
      downloadData.append('csrf_token', csrf());
      downloadButton.dataset.loading = '1';
      downloadButton.setAttribute('aria-busy', 'true');
      request(downloadData).then(function (response) {
        if (response && response.status === 'success' && response.download_url) {
          window.location.href = response.download_url;
          return;
        }
        window.alert((response && response.message) || pageLabel('data-download-failed-label', 'Download could not be started.'));
      }).catch(function () {
        window.alert(pageLabel('data-download-failed-label', 'Download could not be started.'));
      }).finally(function () {
        delete downloadButton.dataset.loading;
        downloadButton.removeAttribute('aria-busy');
      });
      return;
    }
    if (event.target.closest('[data-ebook-modal-open]')) {
      event.preventDefault();
      setModal(true);
      return;
    }
    if (event.target.closest('[data-ebook-modal-close]')) {
      event.preventDefault();
      setModal(false);
    }
    if (event.target.closest('[data-ebook-purchase-close]')) {
      event.preventDefault();
      setPurchaseModal(false);
    }
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      setModal(false);
      setPurchaseModal(false);
      setOwnerEditModal(false);
    }
  });

  var ownerEditForm=qs('[data-owner-edit-form]');
  if(ownerEditForm){ownerEditForm.addEventListener('submit',function(event){event.preventDefault();var message=qs('.ebooks-owner-modal__message',ownerEditForm);var submit=qs('[type="submit"]',ownerEditForm);setMessage(message,'',false);withLoading(submit,true,'...');request(new FormData(ownerEditForm)).then(function(res){if(res&&res.status==='success'){setMessage(message,res.message||'Saved.',false);window.setTimeout(function(){window.location.reload();},450);return;}setMessage(message,(res&&res.message)||pageLabel('data-update-failed-label','The eBook could not be updated.'),true);}).catch(function(){setMessage(message,pageLabel('data-update-failed-label','The eBook could not be updated.'),true);}).finally(function(){withLoading(submit,false);});});}

  var form = qs('#ebooks-create-form');
  if (form) {
    initEbookFileFields(form);
    var publishAction = 'submit';
    form.addEventListener('click', function (event) {
      var actionButton = event.target.closest('[data-publish-action]');
      if (actionButton) { publishAction = actionButton.getAttribute('data-publish-action') || 'submit'; }
    });
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      var message = qs('#ebooks-form-message');
      var submit = qs('button[type="submit"]', form);
      var data = new FormData(form);
      data.set('publish_action', publishAction);
      setMessage(message, '', false);
      withLoading(submit, true, '...');
      request(data).then(function (response) {
        if (response && response.status === 'success') {
          setMessage(message, response.message || pageLabel('data-published-label', 'eBook published.'), false);
          setTimeout(function () { window.location.reload(); }, 650);
          return;
        }
        setMessage(message, (response && response.message) || pageLabel('data-upload-failed-label', 'Upload failed.'), true);
      }).catch(function () {
        setMessage(message, pageLabel('data-upload-failed-label', 'Upload failed.'), true);
      }).finally(function () {
        withLoading(submit, false);
      });
    });
  }

  if (window.location.hash === '#add-ebook' && qs('[data-ebook-modal]')) {
    setModal(true);
  }

  document.addEventListener('click', function (event) {
    var button = event.target.closest('.ebook-purchase-btn');
    if (!button) { return; }
    event.preventDefault();
    var id = button.getAttribute('data-ebook-id');
    if (!id) { return; }
    var card = button.closest('.ebook-card');
    var previous = card ? qs('.ebook-card__notice', card) : null;
    if (previous) { previous.remove(); }
    setPurchaseModal(true, card);
  });

  var paymentForm = qs('[data-ebook-payment-form]');
  if (paymentForm) {
    paymentForm.addEventListener('submit', function (event) {
      event.preventDefault();
      var submit = qs('button[type="submit"]', paymentForm);
      var message = qs('[data-ebook-payment-message]');
      var data = new FormData(paymentForm);
      if (!data.get('csrf_token')) {
        data.set('csrf_token', csrf());
      }
      setMessage(message, '', false);
      withLoading(submit, true, pageLabel('data-payment-start-label', 'Starting payment...'));
      request(data).then(function (response) {
        if (response && response.status === 'success') {
          if (response.checkout_url) {
            try {
              window.sessionStorage.setItem('pending_ebook_payment', JSON.stringify({
                provider: response.provider || data.get('provider'),
                reference: response.reference || '',
                ebook_id: data.get('ebook_id') || ''
              }));
            } catch (ignore) {}
            setMessage(message, pageLabel('data-redirecting-label', 'Redirecting to payment...'), false);
            window.location.href = response.checkout_url;
            return;
          }
          setMessage(message, response.message || pageLabel('data-published-label', 'eBook published.'), false);
          window.setTimeout(function () {
            window.location.href = response.redirect_url || window.location.href;
          }, 650);
          return;
        }
        var err = (response && response.message) || pageLabel('data-purchase-failed-label', 'Purchase failed.');
        setMessage(message, err, true);
        if (response && response.code === 'insufficient_wallet' && message) {
          var topup = document.createElement('button');
          topup.type = 'button';
          topup.className = 'ebooks-payment-topup walletTopup';
          topup.textContent = pageLabel('data-topup-label', 'Add funds');
          message.appendChild(topup);
        }
      }).catch(function () {
        setMessage(message, pageLabel('data-purchase-failed-label', 'Purchase failed.'), true);
      }).finally(function () {
        withLoading(submit, false);
      });
    });
  }

  var reviewForm = qs('[data-ebook-review-form]');
  if (reviewForm) {
    reviewForm.addEventListener('click', function (event) {
      var star = event.target.closest('[data-review-rating]');
      if (!star) { return; }
      var selected = parseInt(star.getAttribute('data-review-rating') || '0', 10);
      var ratingInput = qs('input[name="rating"]', reviewForm);
      if (ratingInput) { ratingInput.value = String(selected); }
      reviewForm.querySelectorAll('[data-review-rating]').forEach(function (item) {
        var itemRating = parseInt(item.getAttribute('data-review-rating') || '0', 10);
        item.classList.toggle('is-active', itemRating <= selected);
        item.setAttribute('aria-checked', itemRating === selected ? 'true' : 'false');
      });
    });
    reviewForm.addEventListener('submit', function (event) {
      event.preventDefault();
      var submit = qs('button[type="submit"]', reviewForm);
      var message = qs('[data-ebook-review-message]', reviewForm);
      withLoading(submit, true, '...');
      setMessage(message, '', false);
      var reviewData = new FormData(reviewForm);
      if (parseInt(reviewData.get('rating') || '0', 10) < 1) { setMessage(message, 'Choose a rating from 1 to 5.', true); withLoading(submit, false); return; }
      request(reviewData).then(function (response) {
        if (response && response.status === 'success') { setMessage(message, response.message || 'Saved.', false); window.setTimeout(function(){ window.location.reload(); }, 500); return; }
        setMessage(message, (response && response.message) || 'Review could not be saved.', true);
      }).catch(function(){ setMessage(message, 'Review could not be saved.', true); }).finally(function(){ withLoading(submit, false); });
    });
  }

  try {
    var pending = JSON.parse(window.sessionStorage.getItem('pending_ebook_payment') || 'null');
    if (pending && pending.provider && pending.reference) {
      var statusData = new FormData();
      statusData.append('p', 'ebook_payment_status');
      statusData.append('provider', pending.provider);
      statusData.append('reference', pending.reference);
      request(statusData).then(function (response) {
        if (response && response.status === 'success' && response.payment_status === 'succeeded') {
          window.sessionStorage.removeItem('pending_ebook_payment');
          window.location.href = window.location.pathname;
        }
      });
    }
  } catch (ignore) {}
})();
