(function (win, doc) {
  'use strict';

  var ACTIVE_CLASS = 'media-viewer--active';
  var LOCK_CLASS = 'media-viewer--locked';
  var ROOT_DATA_ATTR = 'data-media-viewer-root';
  var TRIGGER_ATTR = 'data-media-viewer-trigger';
  var TEMPLATE_ATTR = 'data-media-viewer-template';
  var CONTENT_ATTR = 'data-media-viewer-content';
  var VIEWPORT_ATTR = 'data-media-viewer-viewport';
  var OVERLAY_ATTR = 'data-media-viewer-overlay';
  var DISMISS_ATTR = 'data-media-viewer-dismiss';
  var MESSAGES_WRAPPER_SELECTOR = '.messages_box_wrapper';
  var MESSAGES_HIDDEN_CLASS = 'messages_box_wrapper--viewer-lock';

  var cssEscape = (win.CSS && typeof win.CSS.escape === 'function') ? win.CSS.escape : function (value) {
    return String(value || '').replace(/[^a-zA-Z0-9_\-]/g, '\\$&');
  };

  var MOBILE_VIEWPORT_QUERY = (typeof win.matchMedia === 'function') ? win.matchMedia('(max-width: 1024px)') : null;
  var COARSE_POINTER_QUERY = (typeof win.matchMedia === 'function') ? win.matchMedia('(pointer: coarse)') : null;
  var META_I18N = (win.DZ && typeof win.DZ.i18n === 'function') ? win.DZ.i18n : null;

  function clampValue(value, min, max) {
    if (value < min) {
      return min;
    }
    if (value > max) {
      return max;
    }
    return value;
  }

  function translate(key, fallback) {
    var result = '';
    try {
      if (META_I18N) {
        result = META_I18N(key) || '';
      }
    } catch (_) {
      result = '';
    }
    if (result === undefined || result === null || result === '') {
      return fallback;
    }
    return result;
  }

  function createCustomEvent(name, detail, cancelable) {
    if (typeof win.CustomEvent === 'function') {
      return new win.CustomEvent(name, { detail: detail, cancelable: !!cancelable });
    }
    var event = doc.createEvent('CustomEvent');
    event.initCustomEvent(name, true, !!cancelable, detail);
    return event;
  }

  function dispatch(target, name, detail, cancelable) {
    if (!target) { return createCustomEvent(name, detail, cancelable); }
    var event = createCustomEvent(name, detail, cancelable);
    target.dispatchEvent(event);
    return event;
  }

  function ready(fn) {
    if (doc.readyState === 'loading') {
      doc.addEventListener('DOMContentLoaded', fn, { once: true });
    } else {
      fn();
    }
  }

  function toggleLock(isLocked) {
    var method = isLocked ? 'add' : 'remove';
    [doc.documentElement, doc.body].forEach(function (el) {
      if (el && el.classList) {
        el.classList[method](LOCK_CLASS);
      }
    });
  }

  function toggleMessagesWidget(isHidden) {
    var wrappers = doc.querySelectorAll(MESSAGES_WRAPPER_SELECTOR);
    if (!wrappers || !wrappers.length) {
      return;
    }
    wrappers.forEach(function (wrapper) {
      if (!wrapper || !wrapper.classList) {
        return;
      }
      if (isHidden) {
        wrapper.classList.add(MESSAGES_HIDDEN_CLASS);
      } else {
        wrapper.classList.remove(MESSAGES_HIDDEN_CLASS);
      }
    });
  }

  function isElementVisible(el) {
    if (!el) {
      return false;
    }
    if (el.hidden || el.getAttribute('aria-hidden') === 'true') {
      return false;
    }
    if (typeof win.getComputedStyle === 'function') {
      try {
        var cs = win.getComputedStyle(el);
        if (cs && (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0')) {
          return false;
        }
      } catch (_) {
        return true;
      }
    }
    return true;
  }

  function createRoot() {
    var root = doc.createElement('div');
    root.className = 'media-viewer';
    root.setAttribute(ROOT_DATA_ATTR, '1');
    root.setAttribute('aria-hidden', 'true');

    var overlay = doc.createElement('div');
    overlay.className = 'media-viewer__overlay';
    overlay.setAttribute(OVERLAY_ATTR, '1');
    root.appendChild(overlay);

    var viewport = doc.createElement('div');
    viewport.className = 'media-viewer__viewport';
    viewport.setAttribute(VIEWPORT_ATTR, '1');
    viewport.setAttribute('role', 'dialog');
    viewport.setAttribute('aria-modal', 'true');
    viewport.setAttribute('tabindex', '-1');
    viewport.setAttribute('aria-label', translate('viewer.image', 'Image'));
    root.appendChild(viewport);

    var closeLabel = translate('viewer.close', 'Close');
    var prevLabel = translate('viewer.prev', 'Previous');
    var nextLabel = translate('viewer.next', 'Next');

    var closeBtn = doc.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'media-viewer__close';
    closeBtn.setAttribute(DISMISS_ATTR, '1');
    closeBtn.setAttribute('aria-label', closeLabel);
    closeBtn.textContent = closeLabel;
    viewport.appendChild(closeBtn);

    var content = doc.createElement('div');
    content.className = 'media-viewer__content';
    content.setAttribute(CONTENT_ATTR, '1');
    viewport.appendChild(content);

    var prevBtn = doc.createElement('button');
    prevBtn.type = 'button';
    prevBtn.className = 'media-viewer__nav media-viewer__nav--prev';
    prevBtn.setAttribute('aria-label', prevLabel);
    prevBtn.textContent = '‹';
    prevBtn.setAttribute('title', prevLabel);
    viewport.appendChild(prevBtn);

    var nextBtn = doc.createElement('button');
    nextBtn.type = 'button';
    nextBtn.className = 'media-viewer__nav media-viewer__nav--next';
    nextBtn.setAttribute('aria-label', nextLabel);
    nextBtn.textContent = '›';
    nextBtn.setAttribute('title', nextLabel);
    viewport.appendChild(nextBtn);

    return root;
  }

  function MediaViewer() {
    this.root = null;
    this.overlay = null;
    this.viewport = null;
    this.content = null;
    this.closeBtn = null;
    this.prevBtn = null;
    this.nextBtn = null;
    this.viewerZoom = null;
    this.isMounted = false;
    this.overlayListenerAttached = false;
    this.closeListenerAttached = false;
    this.prevListenerAttached = false;
    this.nextListenerAttached = false;
    this.lastActive = null;
    this.currentPayload = null;
    this.currentGallery = null;
    this.focusableElements = [];

    this.onOverlayClick = this.onOverlayClick.bind(this);
    this.onCloseClick = this.onCloseClick.bind(this);
    this.onKeydown = this.onKeydown.bind(this);
    this.onPrevClick = this.onPrevClick.bind(this);
    this.onNextClick = this.onNextClick.bind(this);
  }

  MediaViewer.prototype.mount = function () {
    if (this.isMounted && this.root && doc.body.contains(this.root)) {
      return;
    }

    if (!this.root) {
      this.root = doc.querySelector('[' + ROOT_DATA_ATTR + ']') || createRoot();
    }

    if (!this.root.parentNode) {
      (doc.body || doc.documentElement).appendChild(this.root);
    }

    this.overlay = this.root.querySelector('[' + OVERLAY_ATTR + ']');
    this.viewport = this.root.querySelector('[' + VIEWPORT_ATTR + ']');
    this.content = this.root.querySelector('[' + CONTENT_ATTR + ']');
    this.closeBtn = this.root.querySelector('[' + DISMISS_ATTR + ']');
    this.prevBtn = this.root.querySelector('.media-viewer__nav--prev');
    this.nextBtn = this.root.querySelector('.media-viewer__nav--next');

    if (this.overlay && !this.overlayListenerAttached) {
      this.overlay.addEventListener('click', this.onOverlayClick);
      this.overlayListenerAttached = true;
    }

    if (this.closeBtn && !this.closeListenerAttached) {
      this.closeBtn.addEventListener('click', this.onCloseClick);
      this.closeListenerAttached = true;
    }

    if (this.prevBtn && !this.prevListenerAttached) {
      this.prevBtn.addEventListener('click', this.onPrevClick);
      this.prevListenerAttached = true;
    }

    if (this.nextBtn && !this.nextListenerAttached) {
      this.nextBtn.addEventListener('click', this.onNextClick);
      this.nextListenerAttached = true;
    }

    this.updateNavState();

    this.isMounted = true;
  };

  MediaViewer.prototype.isOpen = function () {
    return !!(this.root && this.root.classList.contains(ACTIVE_CLASS));
  };

  MediaViewer.prototype.open = function (payload) {
    this.mount();

    if (!this.root) {
      return false;
    }

    var detail = { viewer: this, payload: payload || {} };
    var beforeEvent = dispatch(this.root, 'mediaViewer:beforeopen', detail, true);
    if (beforeEvent.defaultPrevented) {
      return false;
    }

    this.currentPayload = detail.payload;

    if (this.content && !detail.payload.keepExisting) {
      this.content.innerHTML = '';
    }

    this.render(detail.payload);

    this.root.classList.add(ACTIVE_CLASS);
    this.root.setAttribute('aria-hidden', 'false');

    this.lastActive = (doc.activeElement && typeof doc.activeElement.focus === 'function') ? doc.activeElement : null;

    toggleLock(true);
    toggleMessagesWidget(true);

    this.focusInitialElement();

    doc.addEventListener('keydown', this.onKeydown, true);

    dispatch(this.root, 'mediaViewer:open', detail, false);
    return true;
  };

  MediaViewer.prototype.close = function () {
    if (!this.isOpen()) {
      return false;
    }

    var detail = { viewer: this, payload: this.currentPayload };
    var beforeEvent = dispatch(this.root, 'mediaViewer:beforeclose', detail, true);
    if (beforeEvent.defaultPrevented) {
      return false;
    }

    this.root.classList.remove(ACTIVE_CLASS);
    this.root.setAttribute('aria-hidden', 'true');
    toggleLock(false);
    toggleMessagesWidget(false);

    doc.removeEventListener('keydown', this.onKeydown, true);

    dispatch(this.root, 'mediaViewer:close', detail, false);

    if (this.content && (!detail.payload || detail.payload.keepOnClose !== true)) {
      this.content.innerHTML = '';
    }

    this.destroyViewerZoom();
    this.currentGallery = null;
    this.updateNavState();
    this.refreshFocusableElements();

    if (this.lastActive && typeof this.lastActive.focus === 'function') {
      try {
        this.lastActive.focus({ preventScroll: true });
      } catch (_) {
        this.lastActive.focus();
      }
    }

    this.lastActive = null;
    this.currentPayload = null;
    return true;
  };

  MediaViewer.prototype.refreshFocusableElements = function () {
    if (!this.viewport) {
      this.focusableElements = [];
      return;
    }
    var selectors = 'a[href], area[href], button:not([disabled]):not([hidden]), input:not([disabled]):not([hidden]), select:not([disabled]):not([hidden]), textarea:not([disabled]):not([hidden]), iframe, [tabindex]:not([tabindex="-1"])';
    var nodeList = this.viewport.querySelectorAll(selectors);
    var focusables = [];
    for (var i = 0; i < nodeList.length; i += 1) {
      var el = nodeList[i];
      if (!el) {
        continue;
      }
      if (el.disabled || el.getAttribute('aria-disabled') === 'true') {
        continue;
      }
      if (!isElementVisible(el)) {
        continue;
      }
      if (el.tabIndex < 0 && !el.hasAttribute('tabindex')) {
        continue;
      }
      focusables.push(el);
    }
    this.focusableElements = focusables;
  };

  MediaViewer.prototype.focusInitialElement = function () {
    this.refreshFocusableElements();
    var target = null;
    if (this.closeBtn && isElementVisible(this.closeBtn) && !this.closeBtn.disabled) {
      target = this.closeBtn;
    } else if (this.focusableElements.length) {
      target = this.focusableElements[0];
    }
    if (target) {
      try {
        target.focus({ preventScroll: true });
      } catch (_) {
        target.focus();
      }
      return target;
    }
    if (this.viewport) {
      try {
        this.viewport.focus({ preventScroll: true });
      } catch (_) {
        this.viewport.focus();
      }
      return this.viewport;
    }
    return null;
  };

  MediaViewer.prototype.handleTabKey = function (evt) {
    this.refreshFocusableElements();
    if (!this.focusableElements.length) {
      evt.preventDefault();
      if (this.viewport) {
        try {
          this.viewport.focus({ preventScroll: true });
        } catch (_) {
          this.viewport.focus();
        }
      }
      return;
    }
    var first = this.focusableElements[0];
    var last = this.focusableElements[this.focusableElements.length - 1];
    var active = doc.activeElement;
    if (evt.shiftKey) {
      if (active === first || !this.viewport.contains(active)) {
        evt.preventDefault();
        try {
          last.focus({ preventScroll: true });
        } catch (_) {
          last.focus();
        }
      }
    } else {
      if (active === last) {
        evt.preventDefault();
        try {
          first.focus({ preventScroll: true });
        } catch (_) {
          first.focus();
        }
      }
    }
  };

  MediaViewer.prototype.onPrevClick = function (evt) {
    evt.preventDefault();
    evt.stopPropagation();
    this.goToPrevious();
  };

  MediaViewer.prototype.onNextClick = function (evt) {
    evt.preventDefault();
    evt.stopPropagation();
    this.goToNext();
  };

  MediaViewer.prototype.destroyViewerZoom = function () {
    if (this.viewerZoom && typeof this.viewerZoom.destroy === 'function') {
      this.viewerZoom.destroy();
    }
    this.viewerZoom = null;
  };

  MediaViewer.prototype.isMobileViewport = function () {
    if (MOBILE_VIEWPORT_QUERY) {
      return MOBILE_VIEWPORT_QUERY.matches;
    }
    try {
      return win.innerWidth <= 1024;
    } catch (_) {
      return false;
    }
  };

  MediaViewer.prototype.isTouchPreferred = function () {
    if (COARSE_POINTER_QUERY && COARSE_POINTER_QUERY.matches) {
      return true;
    }
    if (typeof win.navigator !== 'undefined' && typeof win.navigator.maxTouchPoints === 'number' && win.navigator.maxTouchPoints > 0) {
      return true;
    }
    return 'ontouchstart' in win;
  };

  MediaViewer.prototype.shouldEnableViewerZoom = function () {
    return this.isMobileViewport() && this.isTouchPreferred();
  };

  MediaViewer.prototype.updateNavState = function () {
    if (!this.prevBtn || !this.nextBtn) {
      return;
    }
    var gallery = this.currentGallery;
    var hasGallery = !!(gallery && Array.isArray(gallery.items) && gallery.items.length);
    var hasMultiple = hasGallery && gallery.items.length > 1;

    if (!hasGallery || !hasMultiple) {
      this.prevBtn.hidden = true;
      this.nextBtn.hidden = true;
      this.prevBtn.disabled = true;
      this.nextBtn.disabled = true;
      this.prevBtn.setAttribute('aria-hidden', 'true');
      this.nextBtn.setAttribute('aria-hidden', 'true');
      this.refreshFocusableElements();
      return;
    }

    this.prevBtn.hidden = false;
    this.nextBtn.hidden = false;
    this.prevBtn.removeAttribute('aria-hidden');
    this.nextBtn.removeAttribute('aria-hidden');
    this.prevBtn.disabled = gallery.index <= 0;
    this.nextBtn.disabled = gallery.index >= gallery.items.length - 1;
    this.prevBtn.setAttribute('aria-disabled', this.prevBtn.disabled ? 'true' : 'false');
    this.nextBtn.setAttribute('aria-disabled', this.nextBtn.disabled ? 'true' : 'false');
    this.refreshFocusableElements();
  };

  MediaViewer.prototype.goToGalleryIndex = function (index) {
    var gallery = this.currentGallery;
    if (!gallery || !Array.isArray(gallery.items) || !gallery.items.length) {
      return false;
    }
    var nextIndex = clampValue(typeof index === 'number' ? index : parseInt(index, 10) || 0, 0, gallery.items.length - 1);
    if (nextIndex === gallery.index) {
      return false;
    }
    gallery.index = nextIndex;
    this.renderGallery(gallery);
    return true;
  };

  MediaViewer.prototype.goRelative = function (step) {
    if (!this.currentGallery) {
      return false;
    }
    return this.goToGalleryIndex((this.currentGallery.index || 0) + step);
  };

  MediaViewer.prototype.goToPrevious = function () {
    return this.goRelative(-1);
  };

  MediaViewer.prototype.goToNext = function () {
    return this.goRelative(1);
  };

  MediaViewer.prototype.createMediaNode = function (descriptor) {
    if (!descriptor) {
      return null;
    }
    if (descriptor.type === 'video') {
      if (!descriptor.alt) {
        descriptor.alt = translate('viewer.video', 'Video');
      }
      var video = doc.createElement('video');
      video.controls = true;
      video.preload = 'metadata';
      video.setAttribute('playsinline', 'playsinline');
      video.setAttribute('controls', 'controls');
      video.removeAttribute('autoplay');
      if (descriptor.poster) {
        video.setAttribute('poster', descriptor.poster);
      }
      var sources = Array.isArray(descriptor.sources) ? descriptor.sources : [];
      if (sources.length) {
        sources.forEach(function (source) {
          if (!source || !source.src) {
            return;
          }
          var sourceEl = doc.createElement('source');
          sourceEl.src = source.src;
          if (source.type) {
            sourceEl.type = source.type;
          }
          video.appendChild(sourceEl);
        });
      } else if (descriptor.src) {
        video.src = descriptor.src;
      }
      if (descriptor.alt) {
        video.setAttribute('aria-label', descriptor.alt);
      }
      return video;
    }
    var img = doc.createElement('img');
    if (descriptor.src) {
      img.src = descriptor.src;
    }
    if (descriptor.srcset) {
      img.setAttribute('srcset', descriptor.srcset);
    }
    if (descriptor.sizes) {
      img.setAttribute('sizes', descriptor.sizes);
    }
    img.alt = descriptor.alt || translate('viewer.image', 'Image');
    img.decoding = 'async';
    img.loading = 'eager';
    return img;
  };

  MediaViewer.prototype.renderGallery = function (gallery) {
    if (!this.content) {
      return false;
    }
    var items = Array.isArray(gallery.items) ? gallery.items : [];
    if (!items.length) {
      this.currentGallery = null;
      this.content.innerHTML = '';
      this.updateNavState();
      return false;
    }

    var clampedIndex = clampValue(typeof gallery.index === 'number' ? gallery.index : parseInt(gallery.index, 10) || 0, 0, items.length - 1);
    gallery.index = clampedIndex;
    this.currentGallery = gallery;

    this.destroyViewerZoom();
    this.content.innerHTML = '';
    var descriptor = items[clampedIndex];
    if (!descriptor) {
      this.updateNavState();
      return false;
    }

    var stage = doc.createElement('div');
    stage.className = 'media-viewer__stage';
    var mediaNode = this.createMediaNode(descriptor);
    if (mediaNode) {
      stage.appendChild(mediaNode);
    }
    this.content.appendChild(stage);

    if (this.viewport) {
      if (descriptor && descriptor.type === 'video') {
        this.viewport.setAttribute('aria-label', translate('viewer.video', 'Video'));
      } else {
        this.viewport.setAttribute('aria-label', translate('viewer.image', 'Image'));
      }
    }

    if (descriptor && descriptor.type === 'image' && mediaNode && this.shouldEnableViewerZoom()) {
      this.viewerZoom = new ViewerZoom(this, stage, mediaNode, descriptor);
    }

    var captionPieces = [];
    if (items.length > 1) {
      captionPieces.push(String(clampedIndex + 1) + ' / ' + String(items.length));
    }
    if (descriptor.caption) {
      captionPieces.push(descriptor.caption);
    } else if (descriptor.alt) {
      captionPieces.push(descriptor.alt);
    }
    if (captionPieces.length) {
      var meta = doc.createElement('div');
      meta.className = 'media-viewer__meta';
      meta.textContent = captionPieces.join(' - ');
      this.content.appendChild(meta);
    }

    this.updateNavState();
    this.refreshFocusableElements();
    return true;
  };

  function ViewerZoom(viewer, stage, media, descriptor) {
    this.viewer = viewer;
    this.stage = stage;
    this.media = media;
    this.descriptor = descriptor || {};
    this.scale = 1;
    this.minScale = 1;
    this.maxScale = 3;
    this.translateX = 0;
    this.translateY = 0;
    this.baseWidth = 0;
    this.baseHeight = 0;
    this.activePointers = [];
    this.pointers = Object.create(null);
    this.pinchStartDistance = 0;
    this.pinchStartScale = 1;
    this.singleStart = null;
    this.startTranslateX = 0;
    this.startTranslateY = 0;
    this.velocityX = 0;
    this.velocityY = 0;
    this.lastMoveTime = 0;
    this.inertiaFrame = 0;
    this.lastTapTime = 0;
    this.lastTapPos = null;
    this.moved = false;
    this.blockClick = false;
    this.resetBtn = null;
    this.prevPanX = null;
    this.prevPanY = null;

    this.onPointerDown = this.onPointerDown.bind(this);
    this.onPointerMove = this.onPointerMove.bind(this);
    this.onPointerUp = this.onPointerUp.bind(this);
    this.onPointerCancel = this.onPointerCancel.bind(this);
    this.onClick = this.onClick.bind(this);
    this.onResetClick = this.onResetClick.bind(this);
    this.onResize = this.onResize.bind(this);

    this.init();
  }

  ViewerZoom.prototype.init = function () {
    var stageStyle = this.stage.style;
    var mediaStyle = this.media.style;
    if (stageStyle) {
      stageStyle.touchAction = 'none';
    }
    if (mediaStyle) {
      mediaStyle.touchAction = 'none';
      mediaStyle.willChange = 'transform';
    }
    this.zoomInLabel = translate('viewer.zoom_in', 'Zoom in');
    this.zoomOutLabel = translate('viewer.zoom_out', 'Zoom out');
    this.stage.classList.add('media-viewer__zoom-stage');
    this.stage.setAttribute('data-zoom-in-label', this.zoomInLabel);
    this.stage.setAttribute('data-zoom-out-label', this.zoomOutLabel);
    this.createResetButton();
    this.recomputeBase();
    this.applyTransform(false);
    this.updateResetVisibility();

    this.stage.addEventListener('pointerdown', this.onPointerDown);
    this.stage.addEventListener('pointermove', this.onPointerMove);
    this.stage.addEventListener('pointerup', this.onPointerUp);
    this.stage.addEventListener('pointercancel', this.onPointerCancel);
    this.stage.addEventListener('pointerleave', this.onPointerCancel);
    this.stage.addEventListener('click', this.onClick, true);
    win.addEventListener('resize', this.onResize);
  };

  ViewerZoom.prototype.destroy = function () {
    this.cancelInertia();
    if (this.stage) {
      this.stage.removeEventListener('pointerdown', this.onPointerDown);
      this.stage.removeEventListener('pointermove', this.onPointerMove);
      this.stage.removeEventListener('pointerup', this.onPointerUp);
      this.stage.removeEventListener('pointercancel', this.onPointerCancel);
      this.stage.removeEventListener('pointerleave', this.onPointerCancel);
      this.stage.removeEventListener('click', this.onClick, true);
    }
    win.removeEventListener('resize', this.onResize);
    if (this.resetBtn && this.resetBtn.parentNode) {
      this.resetBtn.removeEventListener('click', this.onResetClick);
      this.resetBtn.parentNode.removeChild(this.resetBtn);
    }
    if (this.stage && this.stage.classList) {
      this.stage.classList.remove('media-viewer__zoom-stage');
    }
    if (this.media && this.media.style) {
      this.media.style.transform = '';
      this.media.style.transition = '';
      this.media.style.touchAction = '';
      this.media.style.willChange = '';
    }
    if (this.stage && this.stage.style) {
      this.stage.style.touchAction = '';
    }
    this.resetBtn = null;
    this.stage = null;
    this.media = null;
    this.viewer = null;
    this.pointers = Object.create(null);
    this.activePointers = [];
  };

  ViewerZoom.prototype.createResetButton = function () {
    var btn = doc.createElement('button');
    btn.type = 'button';
    btn.className = 'media-viewer__reset';
    var label = translate('viewer.reset', 'Reset');
    btn.textContent = label;
    btn.setAttribute('aria-label', label);
    btn.hidden = true;
    btn.addEventListener('click', this.onResetClick);
    this.stage.appendChild(btn);
    this.resetBtn = btn;
  };

  ViewerZoom.prototype.onResetClick = function (evt) {
    evt.preventDefault();
    evt.stopPropagation();
    this.reset(true);
  };

  ViewerZoom.prototype.recomputeBase = function () {
    if (!this.media) {
      return;
    }
    var prevTransform = this.media.style.transform;
    this.media.style.transform = '';
    var rect = this.media.getBoundingClientRect();
    this.baseWidth = rect.width || 1;
    this.baseHeight = rect.height || 1;
    this.media.style.transform = prevTransform || '';
  };

  ViewerZoom.prototype.onResize = function () {
    this.recomputeBase();
    this.applyBounds();
    this.applyTransform(false);
  };

  ViewerZoom.prototype.onPointerDown = function (evt) {
    if (evt.pointerType && evt.pointerType === 'mouse') {
      return;
    }
    this.cancelInertia();
    this.moved = false;
    this.blockClick = false;
    this.velocityX = 0;
    this.velocityY = 0;

    this.pointers[evt.pointerId] = { x: evt.clientX, y: evt.clientY };
    if (this.activePointers.indexOf(evt.pointerId) === -1) {
      this.activePointers.push(evt.pointerId);
    }

    if (this.activePointers.length === 1) {
      this.singleStart = { x: evt.clientX, y: evt.clientY };
      this.startTranslateX = this.translateX;
      this.startTranslateY = this.translateY;
      this.lastMoveTime = evt.timeStamp || Date.now();
      this.prevPanX = evt.clientX;
      this.prevPanY = evt.clientY;
    } else if (this.activePointers.length === 2) {
      this.initPinch();
    }

    try { this.stage.setPointerCapture(evt.pointerId); } catch (_) {}
    evt.preventDefault();
    evt.stopPropagation();
  };

  ViewerZoom.prototype.onPointerMove = function (evt) {
    if (!this.pointers[evt.pointerId]) {
      return;
    }
    this.pointers[evt.pointerId].x = evt.clientX;
    this.pointers[evt.pointerId].y = evt.clientY;

    if (this.activePointers.length === 2) {
      this.handlePinch();
    } else if (this.activePointers.length === 1 && this.scale > 1.01) {
      this.handlePan(evt);
    }

    evt.preventDefault();
    evt.stopPropagation();
  };

  ViewerZoom.prototype.onPointerUp = function (evt) {
    if (this.pointers[evt.pointerId]) {
      delete this.pointers[evt.pointerId];
    }
    var idx = this.activePointers.indexOf(evt.pointerId);
    if (idx !== -1) {
      this.activePointers.splice(idx, 1);
    }
    try { this.stage.releasePointerCapture(evt.pointerId); } catch (_) {}

    if (evt.pointerType === 'touch' && this.activePointers.length === 0) {
      var now = evt.timeStamp || Date.now();
      var pos = { x: evt.clientX, y: evt.clientY };
      if (this.lastTapTime && (now - this.lastTapTime) < 280 && this.lastTapPos) {
        var dx = pos.x - this.lastTapPos.x;
        var dy = pos.y - this.lastTapPos.y;
        var dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 30) {
          this.toggleDoubleTap(pos.x, pos.y);
          this.lastTapTime = 0;
          this.lastTapPos = null;
          evt.preventDefault();
          evt.stopPropagation();
          this.blockClick = true;
          return;
        }
      }
      this.lastTapTime = now;
      this.lastTapPos = pos;
    }

    if (this.activePointers.length === 1) {
      var remaining = this.pointers[this.activePointers[0]];
      if (remaining) {
        this.singleStart = { x: remaining.x, y: remaining.y };
        this.startTranslateX = this.translateX;
        this.startTranslateY = this.translateY;
        this.prevPanX = remaining.x;
        this.prevPanY = remaining.y;
        this.lastMoveTime = evt.timeStamp || Date.now();
      }
    }

    if (this.activePointers.length === 0) {
      if (this.scale > 1.01) {
        this.startInertia();
      } else {
        this.reset(false);
      }
    }

    if (this.moved) {
      this.blockClick = true;
    }
  };

  ViewerZoom.prototype.onPointerCancel = function (evt) {
    if (evt && this.pointers[evt.pointerId]) {
      delete this.pointers[evt.pointerId];
    }
    var idx = evt ? this.activePointers.indexOf(evt.pointerId) : -1;
    if (idx !== -1) {
      this.activePointers.splice(idx, 1);
    }
    if (evt) {
      try { this.stage.releasePointerCapture(evt.pointerId); } catch (_) {}
    }
    if (this.activePointers.length === 1) {
      var remain = this.pointers[this.activePointers[0]];
      if (remain) {
        this.singleStart = { x: remain.x, y: remain.y };
        this.startTranslateX = this.translateX;
        this.startTranslateY = this.translateY;
        this.prevPanX = remain.x;
        this.prevPanY = remain.y;
        this.lastMoveTime = (evt && (evt.timeStamp || Date.now())) || Date.now();
      }
    }
    if (this.activePointers.length === 0) {
      if (this.scale > 1.01) {
        this.startInertia();
      } else {
        this.reset(false);
      }
    }
  };

  ViewerZoom.prototype.onClick = function (evt) {
    if (this.blockClick) {
      evt.preventDefault();
      evt.stopPropagation();
      this.blockClick = false;
    }
  };

  ViewerZoom.prototype.initPinch = function () {
    if (this.activePointers.length < 2) {
      return;
    }
    var a = this.pointers[this.activePointers[0]];
    var b = this.pointers[this.activePointers[1]];
    if (!a || !b) {
      return;
    }
    var dx = a.x - b.x;
    var dy = a.y - b.y;
    this.pinchStartDistance = Math.sqrt(dx * dx + dy * dy) || 1;
    this.pinchStartScale = this.scale;
  };

  ViewerZoom.prototype.handlePinch = function () {
    if (this.activePointers.length < 2) {
      return;
    }
    var a = this.pointers[this.activePointers[0]];
    var b = this.pointers[this.activePointers[1]];
    if (!a || !b) {
      return;
    }
    var dx = a.x - b.x;
    var dy = a.y - b.y;
    var distance = Math.sqrt(dx * dx + dy * dy) || 1;
    if (!this.pinchStartDistance) {
      this.initPinch();
    }
    var scale = this.pinchStartScale * (distance / (this.pinchStartDistance || distance));
    this.zoomTo(scale, (a.x + b.x) / 2, (a.y + b.y) / 2, false);
    this.moved = true;
    this.velocityX = 0;
    this.velocityY = 0;
    this.prevPanX = null;
    this.prevPanY = null;
  };

  ViewerZoom.prototype.handlePan = function (evt) {
    var pointer = this.pointers[evt.pointerId];
    if (!pointer || !this.singleStart) {
      return;
    }
    var dx = pointer.x - this.singleStart.x;
    var dy = pointer.y - this.singleStart.y;
    this.translateX = this.startTranslateX + dx;
    this.translateY = this.startTranslateY + dy;
    this.applyBounds();
    this.applyTransform(false);

    var now = evt.timeStamp || Date.now();
    var deltaTime = now - this.lastMoveTime;
    var deltaX = (this.prevPanX != null) ? (pointer.x - this.prevPanX) : 0;
    var deltaY = (this.prevPanY != null) ? (pointer.y - this.prevPanY) : 0;
    if (deltaTime > 0 && deltaTime < 120) {
      this.velocityX = deltaX / deltaTime * 16;
      this.velocityY = deltaY / deltaTime * 16;
    }
    this.lastMoveTime = now;
    this.prevPanX = pointer.x;
    this.prevPanY = pointer.y;
    this.moved = true;
  };

  ViewerZoom.prototype.toggleDoubleTap = function (clientX, clientY) {
    if (this.scale > 1.05) {
      this.reset(true);
      this.stage.setAttribute('data-zoom-action', this.zoomInLabel);
    } else {
      this.zoomTo(2, clientX, clientY, true);
      this.stage.setAttribute('data-zoom-action', this.zoomOutLabel);
    }
  };

  ViewerZoom.prototype.zoomTo = function (targetScale, clientX, clientY, animate) {
    var newScale = clampValue(targetScale, this.minScale, this.maxScale);
    var prevScale = this.scale;
    this.scale = newScale;
    if (clientX != null && clientY != null) {
      var stageRect = this.stage.getBoundingClientRect();
      var centerX = stageRect.left + stageRect.width / 2;
      var centerY = stageRect.top + stageRect.height / 2;
      var offsetX = clientX - centerX;
      var offsetY = clientY - centerY;
      this.translateX -= offsetX * (this.scale - prevScale) / this.scale;
      this.translateY -= offsetY * (this.scale - prevScale) / this.scale;
    }
    this.applyBounds();
    this.applyTransform(animate);
    this.updateResetVisibility();
    if (this.viewer && typeof this.viewer.refreshFocusableElements === 'function') {
      this.viewer.refreshFocusableElements();
    }
    if (this.stage) {
      this.stage.setAttribute('data-zoom-action', this.scale > 1.01 ? this.zoomOutLabel : this.zoomInLabel);
    }
  };

  ViewerZoom.prototype.applyBounds = function () {
    if (!this.stage) {
      return;
    }
    var stageRect = this.stage.getBoundingClientRect();
    var scaledWidth = this.baseWidth * this.scale;
    var scaledHeight = this.baseHeight * this.scale;
    var maxX = Math.max(0, (scaledWidth - stageRect.width) / 2);
    var maxY = Math.max(0, (scaledHeight - stageRect.height) / 2);
    this.translateX = clampValue(this.translateX, -maxX, maxX);
    this.translateY = clampValue(this.translateY, -maxY, maxY);
  };

  ViewerZoom.prototype.applyTransform = function (animate) {
    if (!this.media) {
      return;
    }
    this.media.style.transition = animate ? 'transform 180ms ease' : 'none';
    this.media.style.transform = 'translate3d(' + this.translateX + 'px, ' + this.translateY + 'px, 0) scale(' + this.scale + ')';
    this.updateResetVisibility();
  };

  ViewerZoom.prototype.updateResetVisibility = function () {
    if (!this.resetBtn) {
      return;
    }
    var zoomed = this.scale > 1.02;
    this.resetBtn.hidden = !zoomed;
  };

  ViewerZoom.prototype.reset = function (animate) {
    this.cancelInertia();
    this.scale = 1;
    this.translateX = 0;
    this.translateY = 0;
    this.velocityX = 0;
    this.velocityY = 0;
    this.applyTransform(!!animate);
    this.updateResetVisibility();
    if (this.viewer && typeof this.viewer.refreshFocusableElements === 'function') {
      this.viewer.refreshFocusableElements();
    }
    this.prevPanX = null;
    this.prevPanY = null;
    if (this.stage) {
      this.stage.setAttribute('data-zoom-action', this.zoomInLabel || translate('viewer.zoom_in', 'Zoom in'));
    }
  };

  ViewerZoom.prototype.startInertia = function () {
    if (!this.stage || !this.media) {
      return;
    }
    if (this.scale <= 1.01) {
      this.reset(true);
      return;
    }
    var self = this;
    var friction = 0.90;
    function step() {
      self.translateX += self.velocityX;
      self.translateY += self.velocityY;
      self.applyBounds();
      self.applyTransform(false);
      self.velocityX *= friction;
      self.velocityY *= friction;
      if (Math.abs(self.velocityX) > 0.3 || Math.abs(self.velocityY) > 0.3) {
        self.inertiaFrame = win.requestAnimationFrame(step);
      } else {
        self.cancelInertia();
        self.applyBounds();
        self.applyTransform(false);
      }
    }
    if (Math.abs(this.velocityX) > 0.3 || Math.abs(this.velocityY) > 0.3) {
      this.inertiaFrame = win.requestAnimationFrame(step);
    } else {
      this.cancelInertia();
      this.applyBounds();
      this.applyTransform(false);
    }
  };

  ViewerZoom.prototype.cancelInertia = function () {
    if (this.inertiaFrame) {
      win.cancelAnimationFrame(this.inertiaFrame);
      this.inertiaFrame = 0;
    }
    this.velocityX = 0;
    this.velocityY = 0;
  };

  MediaViewer.prototype.render = function (payload) {
    if (!this.content) {
      return;
    }

    var detail = { viewer: this, payload: payload || {} };
    var renderPayload = detail.payload;
    var templateId = renderPayload.template || renderPayload.source || '';
    var hasRendered = false;

    if (renderPayload.gallery && Array.isArray(renderPayload.gallery.items)) {
      hasRendered = this.renderGallery(renderPayload.gallery);
    } else {
      this.currentGallery = null;
      this.updateNavState();
    }

    if (!hasRendered && templateId) {
      var selector = '[' + TEMPLATE_ATTR + '="' + cssEscape(templateId) + '"]';
      var templateEl = doc.querySelector(selector);
      if (templateEl) {
        if (templateEl.tagName && templateEl.tagName.toLowerCase() === 'template' && 'content' in templateEl) {
          this.content.appendChild(templateEl.content.cloneNode(true));
        } else {
          this.content.appendChild(templateEl.cloneNode(true));
        }
        hasRendered = true;
      }
    }

    if (!hasRendered && typeof renderPayload.html === 'string') {
      this.content.innerHTML = renderPayload.html;
      hasRendered = true;
    }

    if (!hasRendered && renderPayload.node && renderPayload.node.nodeType) {
      var nodeToInsert = renderPayload.clone === true ? renderPayload.node.cloneNode(true) : renderPayload.node;
      this.content.appendChild(nodeToInsert);
      hasRendered = true;
    }

    if (!hasRendered && renderPayload.fragment && renderPayload.fragment.nodeType === 11) {
      this.content.appendChild(renderPayload.fragment.cloneNode(true));
      hasRendered = true;
    }

    if (!hasRendered && typeof renderPayload.placeholder === 'string') {
      this.content.innerHTML = renderPayload.placeholder;
    }

    dispatch(this.root, 'mediaViewer:render', detail, false);
    this.refreshFocusableElements();
  };

  MediaViewer.prototype.setContent = function (content, options) {
    if (!this.content) {
      return;
    }
    var opts = options || {};
    if (!opts.append) {
      this.content.innerHTML = '';
    }
    if (content == null) {
      this.refreshFocusableElements();
      return;
    }
    if (typeof content === 'string') {
      this.content.innerHTML = content;
      this.refreshFocusableElements();
      return;
    }
    if (content.nodeType) {
      this.content.appendChild(opts.clone === true ? content.cloneNode(true) : content);
    }
    this.refreshFocusableElements();
  };

  MediaViewer.prototype.onOverlayClick = function (evt) {
    if (evt.target === this.overlay) {
      this.close();
    }
  };

  MediaViewer.prototype.onCloseClick = function (evt) {
    evt.preventDefault();
    this.close();
  };

  MediaViewer.prototype.onKeydown = function (evt) {
    if (!this.isOpen()) {
      return;
    }
    var key = evt.key || evt.code;
    if (key === 'Tab') {
      this.handleTabKey(evt);
      return;
    }
    if (key === 'ArrowLeft' || key === 'Left') {
      if (this.goToPrevious()) {
        evt.preventDefault();
        evt.stopPropagation();
      }
      return;
    }
    if (key === 'ArrowRight' || key === 'Right') {
      if (this.goToNext()) {
        evt.preventDefault();
        evt.stopPropagation();
      }
      return;
    }
    if (evt.key === 'Escape' || evt.key === 'Esc') {
      evt.preventDefault();
      this.close();
    }
  };

  MediaViewer.prototype.destroy = function () {
    this.close();
    if (this.overlay && this.overlayListenerAttached) {
      this.overlay.removeEventListener('click', this.onOverlayClick);
      this.overlayListenerAttached = false;
    }
    if (this.closeBtn && this.closeListenerAttached) {
      this.closeBtn.removeEventListener('click', this.onCloseClick);
      this.closeListenerAttached = false;
    }
    if (this.prevBtn && this.prevListenerAttached) {
      this.prevBtn.removeEventListener('click', this.onPrevClick);
      this.prevListenerAttached = false;
    }
    if (this.nextBtn && this.nextListenerAttached) {
      this.nextBtn.removeEventListener('click', this.onNextClick);
      this.nextListenerAttached = false;
    }
    if (this.root && this.root.parentNode) {
      this.root.parentNode.removeChild(this.root);
    }
    this.root = null;
    this.overlay = null;
    this.viewport = null;
    this.content = null;
    this.closeBtn = null;
    this.prevBtn = null;
    this.nextBtn = null;
    this.destroyViewerZoom();
    this.isMounted = false;
    this.lastActive = null;
    this.currentPayload = null;
    this.currentGallery = null;
    this.focusableElements = [];
  };

  var mediaViewer = new MediaViewer();
  var triggerHandlerBound = false;
  var triggerHandler = function (evt) {
    var trigger = evt.target.closest('[' + TRIGGER_ATTR + ']');
    if (!trigger) {
      return;
    }
    if (trigger.hasAttribute('data-media-viewer-disabled')) {
      return;
    }

    var detail = {
      viewer: mediaViewer,
      trigger: trigger,
      payload: {
        trigger: trigger,
        source: trigger.getAttribute(TRIGGER_ATTR) || '',
        template: trigger.getAttribute(TEMPLATE_ATTR) || '',
        dataset: trigger.dataset
      }
    };

    var triggerEvent = dispatch(trigger, 'mediaViewer:trigger', detail, true);
    if (triggerEvent.defaultPrevented) {
      return;
    }

    evt.preventDefault();
    mediaViewer.open(detail.payload);
  };

  function bindTriggerHandler() {
    if (triggerHandlerBound) {
      return;
    }
    doc.addEventListener('click', triggerHandler);
    triggerHandlerBound = true;
  }

  function unbindTriggerHandler() {
    if (!triggerHandlerBound) {
      return;
    }
    doc.removeEventListener('click', triggerHandler);
    triggerHandlerBound = false;
  }

  ready(function () {
    mediaViewer.mount();
    unbindTriggerHandler();
    bindTriggerHandler();
  });

  win.DZ = win.DZ || {};
  win.DZ.mediaViewer = {
    mount: function () {
      mediaViewer.mount();
      return mediaViewer;
    },
    open: function (payload) {
      return mediaViewer.open(payload);
    },
    close: function () {
      return mediaViewer.close();
    },
    isOpen: function () {
      return mediaViewer.isOpen();
    },
    setContent: function (content, options) {
      mediaViewer.setContent(content, options);
      return mediaViewer;
    },
    getRoot: function () {
      mediaViewer.mount();
      return mediaViewer.root;
    },
    destroy: function () {
      unbindTriggerHandler();
      mediaViewer.destroy();
    }
  };

  // ===== Post Media Single Swiper Integration ============================
  (function setupPostMediaSingleIntegration() {
    if (!doc || !doc.querySelectorAll) {
      return;
    }

    var SINGLE_CONTAINER_CLASS = 'post-media-single';
    var SWIPER_CONTAINER_CLASS = 'post-media-swiper';
    var CONTAINER_SELECTOR = '.' + SINGLE_CONTAINER_CLASS + ', .' + SWIPER_CONTAINER_CLASS;
    var SLIDE_SELECTOR = '.swiper-slide';
    var MEDIA_SELECTOR = 'img, video';
    var IMAGE_TAG = 'IMG';
    var VIDEO_TAG = 'VIDEO';

    var containerRecords = new WeakMap();
    var slideRegistry = new WeakMap();
    var activeLightGallery = null;
    var activeLightGalleryRecord = null;
    var activeLightGalleryLabels = null;
    var THUMB_STRIP_CLASS = 'dz-lg-thumb-strip';
    var THUMB_LIST_CLASS = 'dz-lg-thumb-list';
    var THUMB_ITEM_CLASS = 'dz-lg-thumb-item';
    var THUMB_BUTTON_CLASS = 'dz-lg-thumb';
    var THUMB_IMG_CLASS = 'dz-lg-thumb-img';
    var THUMB_FALLBACK_CLASS = 'dz-lg-thumb-fallback';
    var activeLightGalleryThumbStrip = null;
    var activeLightGalleryThumbList = null;
    var activeLightGalleryThumbButtons = [];

    function isLightGalleryReady() {
      return typeof win.lightGallery === 'function';
    }

    function getLightGalleryPlugins() {
      var plugins = [];
      if (typeof win.lgZoom === 'function') {
        plugins.push(win.lgZoom);
      }
      if (typeof win.lgVideo === 'function') {
        plugins.push(win.lgVideo);
      }
      return plugins;
    }

    function destroyActiveLightGallery() {
      detachCustomThumbnails();
      if (activeLightGallery) {
        if (activeLightGallery.LGel && typeof activeLightGallery.LGel.off === 'function') {
          activeLightGallery.LGel.off('.dzLgLabels');
        }
        if (typeof activeLightGallery.off === 'function') {
          activeLightGallery.off('.dzLgLabels');
        }
      }
      activeLightGalleryLabels = null;
      if (activeLightGalleryRecord) {
        releaseSwiperDisable(activeLightGalleryRecord);
        activeLightGalleryRecord = null;
      }
      if (activeLightGallery && typeof activeLightGallery.destroy === 'function') {
        activeLightGallery.destroy(true);
      }
      activeLightGallery = null;
    }

    function detachCustomThumbnails() {
      if (activeLightGallery && typeof activeLightGallery.off === 'function') {
        activeLightGallery.off('lgAfterSlide.dzThumbs');
        activeLightGallery.off('lgBeforeClose.dzThumbs');
      }
      if (activeLightGallery && activeLightGallery.LGel && typeof activeLightGallery.LGel.off === 'function') {
        activeLightGallery.LGel.off('lgAfterSlide.dzThumbs');
      }
      if (activeLightGalleryThumbButtons && activeLightGalleryThumbButtons.length) {
        activeLightGalleryThumbButtons.forEach(function (button) {
          if (!button) { return; }
          if (button.__dzThumbClickHandler) {
            button.removeEventListener('click', button.__dzThumbClickHandler);
            delete button.__dzThumbClickHandler;
          }
        });
      }
      activeLightGalleryThumbButtons = [];
      if (activeLightGalleryThumbStrip && activeLightGalleryThumbStrip.parentNode) {
        activeLightGalleryThumbStrip.parentNode.removeChild(activeLightGalleryThumbStrip);
      }
      activeLightGalleryThumbStrip = null;
      activeLightGalleryThumbList = null;
    }

    function attachCustomThumbnails(instance, items, descriptors, initialIndex) {
      detachCustomThumbnails();
      if (!instance || !items || items.length < 2) {
        return;
      }

      var outer = instance.outer && typeof instance.outer.get === 'function'
        ? instance.outer.get()
        : null;
      if (!outer) {
        return;
      }

      var components = outer.querySelector('.lg-components') || outer;
      var strip = doc.createElement('div');
      strip.className = THUMB_STRIP_CLASS;
      strip.setAttribute('role', 'presentation');

      var list = doc.createElement('ul');
      list.className = THUMB_LIST_CLASS;
      list.setAttribute('role', 'list');
      list.setAttribute('tabindex', '0');
      list.setAttribute('aria-label', translate('viewer.thumbnails', 'Gallery thumbnails'));
      strip.appendChild(list);
      components.appendChild(strip);

      activeLightGalleryThumbStrip = strip;
      activeLightGalleryThumbList = list;

      var buttons = [];
      items.forEach(function (item, index) {
        var li = doc.createElement('li');
        li.className = THUMB_ITEM_CLASS;
        li.setAttribute('role', 'presentation');

        var btn = doc.createElement('button');
        btn.type = 'button';
        btn.className = THUMB_BUTTON_CLASS;
        btn.dataset.index = String(index);

        var descriptor = descriptors && descriptors[index] ? descriptors[index] : null;
        var labelSource = '';
        if (descriptor) {
          var rawLabel = descriptor.caption || descriptor.alt || descriptor.title || descriptor.label || '';
          labelSource = typeof rawLabel === 'string' ? rawLabel.trim() : '';
        }
        if (!labelSource) {
          labelSource = translate('viewer.thumbnail_label', 'Open slide') + ' ' + (index + 1);
        }
        btn.setAttribute('aria-label', labelSource);

        var thumbSrc = '';
        if (item && item.thumb) {
          thumbSrc = item.thumb;
        } else if (item && item.poster) {
          thumbSrc = item.poster;
        } else if (item && item.src) {
          thumbSrc = item.src;
        }

        if (thumbSrc) {
          var img = doc.createElement('img');
          img.className = THUMB_IMG_CLASS;
          img.src = thumbSrc;
          img.alt = labelSource;
          btn.appendChild(img);
        } else {
          var fallback = doc.createElement('span');
          fallback.className = THUMB_FALLBACK_CLASS;
          fallback.textContent = String(index + 1);
          btn.appendChild(fallback);
        }

        var clickHandler = function (event) {
          event.preventDefault();
          if (typeof instance.slide === 'function') {
            instance.slide(index, false, true, false);
          }
        };
        btn.__dzThumbClickHandler = clickHandler;
        btn.addEventListener('click', clickHandler);

        li.appendChild(btn);
        list.appendChild(li);
        buttons.push(btn);
      });

      activeLightGalleryThumbButtons = buttons;

      var updateActiveThumb = function (index) {
        if (!activeLightGalleryThumbButtons.length) {
          return;
        }
        var numericIndex = typeof index === 'number'
          ? index
          : parseInt(index, 10);
        if (!Number.isFinite(numericIndex)) {
          numericIndex = 0;
        }
        var safeIndex = clampValue(
          numericIndex,
          0,
          activeLightGalleryThumbButtons.length - 1
        );
        activeLightGalleryThumbButtons.forEach(function (button, idx) {
          if (!button) {
            return;
          }
          var isActive = idx === safeIndex;
          if (isActive) {
            button.setAttribute('aria-current', 'true');
            button.classList.add('is-active');
            if (activeLightGalleryThumbList) {
              var targetOffset = button.offsetLeft - (activeLightGalleryThumbList.clientWidth - button.clientWidth) / 2;
              var nextScroll = Math.max(0, targetOffset);
              if (typeof activeLightGalleryThumbList.scrollTo === 'function') {
                activeLightGalleryThumbList.scrollTo({ left: nextScroll, behavior: 'smooth' });
              } else {
                activeLightGalleryThumbList.scrollLeft = nextScroll;
              }
            }
          } else {
            button.removeAttribute('aria-current');
            button.classList.remove('is-active');
          }
        });
      };

      var startingIndex = typeof initialIndex === 'number'
        ? initialIndex
        : (typeof instance.index === 'number' ? instance.index : 0);
      updateActiveThumb(startingIndex);

      if (typeof instance.on === 'function') {
        instance.on('lgAfterSlide.dzThumbs', function (event) {
          var detail = event && event.detail ? event.detail : null;
          var rawIndex = detail && Object.prototype.hasOwnProperty.call(detail, 'index') ? detail.index : undefined;
          var parsedIndex = typeof rawIndex === 'number' ? rawIndex : parseInt(rawIndex, 10);
          if (!Number.isFinite(parsedIndex)) {
            parsedIndex = typeof instance.index === 'number' ? instance.index : 0;
          }
          updateActiveThumb(parsedIndex);
        });
        instance.on('lgBeforeClose.dzThumbs', detachCustomThumbnails);
      }

      if (instance && instance.LGel && typeof instance.LGel.on === 'function') {
        instance.LGel.on('lgAfterSlide.dzThumbs', function (evt) {
          var detail = evt && evt.detail ? evt.detail : null;
          var rawIndex = detail && Object.prototype.hasOwnProperty.call(detail, 'index') ? detail.index : undefined;
          var parsedIndex = typeof rawIndex === 'number' ? rawIndex : parseInt(rawIndex, 10);
          if (!Number.isFinite(parsedIndex)) {
            parsedIndex = typeof instance.index === 'number' ? instance.index : 0;
          }
          updateActiveThumb(parsedIndex);
        });
      }
    }

    function escapeHtml(value) {
      return String(value || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
    }

    function getLightGalleryLabels() {
      return {
        close: translate('viewer.close', 'Close'),
        next: translate('viewer.next', 'Next'),
        prev: translate('viewer.prev', 'Previous'),
        zoomIn: translate('viewer.zoom_in', 'Zoom in'),
        zoomOut: translate('viewer.zoom_out', 'Zoom out'),
        play: translate('viewer.play', 'Play'),
        pause: translate('viewer.pause', 'Pause'),
        fullscreen: translate('viewer.fullscreen', 'Fullscreen'),
        reset: translate('viewer.reset', 'Reset')
      };
    }

    function requestFrame(callback) {
      if (typeof callback !== 'function') {
        return;
      }
      if (typeof win.requestAnimationFrame === 'function') {
        win.requestAnimationFrame(callback);
      } else {
        win.setTimeout(callback, 16);
      }
    }

    function applyVideoButtonLabels(instance, index, labels) {
      if (!instance || !labels || typeof instance.getSlideItem !== 'function') {
        return;
      }
      var slide;
      try {
        slide = instance.getSlideItem(index);
      } catch (_) {
        slide = null;
      }
      if (!slide || typeof slide.find !== 'function') {
        return;
      }
      var buttonQuery = slide.find('.lg-video-play-button');
      var buttonEl = buttonQuery && typeof buttonQuery.get === 'function' ? buttonQuery.get() : null;
      if (buttonEl) {
        buttonEl.setAttribute('aria-label', labels.play);
        buttonEl.setAttribute('title', labels.play);
        buttonEl.setAttribute('data-dz-play-label', labels.play);
        buttonEl.setAttribute('data-dz-pause-label', labels.pause);
      }
      var videoQuery = slide.find('video.lg-video-object');
      var videoEl = videoQuery && typeof videoQuery.get === 'function' ? videoQuery.get() : null;
      if (videoEl && !videoEl.__dzLgLabelled) {
        videoEl.__dzLgLabelled = true;
        var updateState = function () {
          var isPlaying = !videoEl.paused && !videoEl.ended;
          var labelTarget = buttonQuery && typeof buttonQuery.get === 'function' ? buttonQuery.get() : null;
          if (!labelTarget) {
            var fallbackQuery = slide.find('.lg-video-play-button');
            labelTarget = fallbackQuery && typeof fallbackQuery.get === 'function' ? fallbackQuery.get() : null;
          }
          if (labelTarget) {
            var label = isPlaying ? labels.pause : labels.play;
            labelTarget.setAttribute('aria-label', label);
            labelTarget.setAttribute('title', label);
          }
        };
        videoEl.addEventListener('play', updateState);
        videoEl.addEventListener('pause', updateState);
        videoEl.addEventListener('ended', updateState);
        updateState();
      }
    }

    function descriptorToLightGalleryItem(descriptor) {
      if (!descriptor || !descriptor.src) {
        return null;
      }
      var item = {
        src: descriptor.src
      };

      var mediaNode = descriptor.media;
      var thumb = '';
      if (mediaNode) {
        thumb = extractDataValue(mediaNode, ['thumb', 'thumbnail', 'preview', 'poster', 'image']) || mediaNode.getAttribute('data-thumb') || '';
      }

      if (descriptor.type === 'image') {
        item.thumb = thumb || descriptor.src;
      } else if (descriptor.type === 'video') {
        var sources = Array.isArray(descriptor.sources) ? descriptor.sources.filter(function (source) {
          return source && source.src;
        }) : [];
        if (!sources.length && descriptor.src) {
          sources.push({ src: descriptor.src, type: '' });
        }
        var primarySrc = sources.length ? sources[0].src : descriptor.src;
        item.type = 'video';
        item.src = primarySrc;
        item.poster = descriptor.poster || thumb || '';
        item.thumb = thumb || descriptor.poster || '';
        item.video = {
          source: sources.map(function (source) {
            return {
              src: source.src,
              type: source.type || ''
            };
          }),
          attributes: {
            preload: 'metadata',
            controls: true,
            playsinline: true
          }
        };
      }

      item.subHtml = '';

      return item;
    }

    function openWithLightGallery(container, galleryData, record) {
      if (!isLightGalleryReady()) {
        return false;
      }
      if (!galleryData || !Array.isArray(galleryData.items) || !galleryData.items.length) {
        return false;
      }

      var dynamicItems = [];
      for (var i = 0; i < galleryData.items.length; i += 1) {
        var lgItem = descriptorToLightGalleryItem(galleryData.items[i]);
        if (lgItem) {
          dynamicItems.push(lgItem);
        }
      }

      if (!dynamicItems.length) {
        return false;
      }

      destroyActiveLightGallery();

      var labels = getLightGalleryLabels();
      activeLightGalleryLabels = labels;

      var root = container || doc.body || doc.documentElement;
      var plugins = getLightGalleryPlugins();
      if (record) {
        requestSwiperDisable(record);
        activeLightGalleryRecord = record;
      }

      var baseStrings = {
        closeGallery: labels.close,
        toggleMaximize: labels.fullscreen,
        previousSlide: labels.prev,
        nextSlide: labels.next,
        download: 'Download',
        playVideo: labels.play,
        mediaLoadingFailed: 'Oops... Failed to load content...'
      };
      var zoomStrings = {
        zoomIn: labels.zoomIn,
        zoomOut: labels.zoomOut,
        viewActualSize: labels.reset
      };

      var initialIndex = clampValue(galleryData.index || 0, 0, dynamicItems.length - 1);

      var isRTLLocale = doc && doc.documentElement && String(doc.documentElement.dir || '').toLowerCase() === 'rtl';

      try {
        activeLightGallery = win.lightGallery(root, {
          dynamic: true,
          dynamicEl: dynamicItems,
          index: initialIndex,
          download: false,
          thumbnail: false,
          // Use a non-placeholder key so LightGallery skips its console warning while we run the GPL build locally.
          licenseKey: '0000-0000-000-0001',
          plugins: plugins,
          preload: dynamicItems.length > 1 ? 2 : 1,
          rtl: isRTLLocale,
          strings: baseStrings,
          zoomPluginStrings: zoomStrings,
          mobileSettings: {
            showCloseIcon: true,
            controls: true,
            rtl: isRTLLocale
          }
        });
      } catch (_) {
        detachCustomThumbnails();
        activeLightGalleryLabels = null;
        if (record && activeLightGalleryRecord === record) {
          releaseSwiperDisable(record);
          activeLightGalleryRecord = null;
        }
        activeLightGallery = null;
        return false;
      }

      if (!activeLightGallery) {
        detachCustomThumbnails();
        activeLightGalleryLabels = null;
        if (record && activeLightGalleryRecord === record) {
          releaseSwiperDisable(record);
          activeLightGalleryRecord = null;
        }
        return false;
      }

      if (typeof activeLightGallery.openGallery === 'function') {
        activeLightGallery.openGallery(initialIndex);
      }

      attachCustomThumbnails(activeLightGallery, dynamicItems, galleryData.items, initialIndex);

      var scheduleVideoLabels = function (targetIndex) {
        requestFrame(function () {
          applyVideoButtonLabels(activeLightGallery, targetIndex, labels);
        });
      };

      if (activeLightGallery && activeLightGallery.LGel && typeof activeLightGallery.LGel.on === 'function') {
        activeLightGallery.LGel.on('lgHasVideo.dzLgLabels', function (evt) {
          if (evt && evt.detail) {
            var raw = evt.detail.index;
            var parsed = typeof raw === 'number' ? raw : parseInt(raw, 10);
            if (Number.isFinite(parsed)) {
              scheduleVideoLabels(parsed);
            }
          }
        });
        activeLightGallery.LGel.on('lgAfterSlide.dzLgLabels', function (evt) {
          if (evt && evt.detail) {
            var raw = evt.detail.index;
            var parsed = typeof raw === 'number' ? raw : parseInt(raw, 10);
            if (Number.isFinite(parsed)) {
              scheduleVideoLabels(parsed);
            }
          }
        });
      }

      scheduleVideoLabels(initialIndex);

      if (typeof activeLightGallery.on === 'function') {
        activeLightGallery.on('lgAfterClose.dzLgLabels', function () {
          destroyActiveLightGallery();
        });
      }

      return true;
    }

    var maxWidthMediaQuery = (typeof win.matchMedia === 'function') ? win.matchMedia('(max-width: 1024px)') : null;
    var coarsePointerMediaQuery = (typeof win.matchMedia === 'function') ? win.matchMedia('(pointer: coarse)') : null;

    function isSupportedContainer(container) {
      if (!container || !container.classList) {
        return false;
      }
      return container.classList.contains(SINGLE_CONTAINER_CLASS) || container.classList.contains(SWIPER_CONTAINER_CLASS);
    }

    function addMediaQueryListener(mq, handler) {
      if (!mq || typeof handler !== 'function') {
        return;
      }
      if (typeof mq.addEventListener === 'function') {
        mq.addEventListener('change', handler);
      } else if (typeof mq.addListener === 'function') {
        mq.addListener(handler);
      }
    }

    function isTouchLike() {
      if (coarsePointerMediaQuery && coarsePointerMediaQuery.matches) {
        return true;
      }
      if (typeof win.navigator !== 'undefined' && typeof win.navigator.maxTouchPoints === 'number' && win.navigator.maxTouchPoints > 0) {
        return true;
      }
      return 'ontouchstart' in win;
    }

    function isMobileMode() {
      var widthMatch = maxWidthMediaQuery ? maxWidthMediaQuery.matches : (win.innerWidth <= 1024);
      return widthMatch || isTouchLike();
    }

    function getSwiperInstance(container) {
      if (!container) {
        return null;
      }
      if (container.swiper) {
        return container.swiper;
      }
      if (win.jQuery) {
        try {
          var instance = win.jQuery(container).data('swiperInstance');
          if (instance) {
            return instance;
          }
        } catch (_) {}
      }
      return null;
    }

    function applySwiperDisabled(record, disabled) {
      var instance = record ? record.swiper : null;
      var shouldDisable = !!disabled;
      if (!instance) {
        record.pendingDisabled = shouldDisable;
        return;
      }
      if (record.swiperDisabled === shouldDisable) {
        return;
      }
      record.swiperDisabled = shouldDisable;
      instance.allowTouchMove = !shouldDisable;
      instance.allowClick = !shouldDisable;
      if (instance.params) {
        instance.params.allowTouchMove = !shouldDisable;
        instance.params.allowClick = !shouldDisable;
      }
      if (typeof instance.update === 'function') {
        instance.update();
      }
    }

    function requestSwiperDisable(record) {
      if (!record) {
        return;
      }
      record.disableCount += 1;
      if (record.disableCount === 1) {
        applySwiperDisabled(record, true);
      }
    }

    function releaseSwiperDisable(record) {
      if (!record || record.disableCount === 0) {
        return;
      }
      record.disableCount -= 1;
      if (record.disableCount === 0) {
        applySwiperDisabled(record, false);
      }
    }

    function assignSwiper(record, swiper) {
      if (!record || !swiper || record.swiper === swiper) {
        return;
      }
      record.swiper = swiper;
      if (!record.swiperEventsLinked && typeof swiper.on === 'function') {
        record.swiperEventsLinked = true;
      }
      if (record.pendingDisabled !== null) {
        applySwiperDisabled(record, record.pendingDisabled);
        record.pendingDisabled = null;
      }
    }

    function watchForSwiper(record) {
      if (!record) {
        return;
      }
      assignSwiper(record, getSwiperInstance(record.container));
      if (record.swiper) {
        return;
      }
      if (win.MutationObserver && !record.swiperObserver) {
        var attrObserver = new MutationObserver(function () {
          var instance = getSwiperInstance(record.container);
          if (instance) {
            assignSwiper(record, instance);
            attrObserver.disconnect();
            record.swiperObserver = null;
          }
        });
        attrObserver.observe(record.container, { attributes: true, attributeFilter: ['class'] });
        record.swiperObserver = attrObserver;
      }

      var attempts = 0;
      (function retry() {
        if (record.swiper) {
          return;
        }
        var instance = getSwiperInstance(record.container);
        if (instance) {
          assignSwiper(record, instance);
          return;
        }
        if (attempts < 40) {
          attempts += 1;
          win.setTimeout(retry, 160);
        }
      })();
    }

    function observeContainer(record) {
      if (!win.MutationObserver || !record || record.observer) {
        return;
      }
      var observer = new MutationObserver(function (mutations) {
        mutations.forEach(function (mutation) {
          if (!mutation.addedNodes) {
            return;
          }
          for (var i = 0; i < mutation.addedNodes.length; i += 1) {
            var node = mutation.addedNodes[i];
            if (!node || node.nodeType !== 1) {
              continue;
            }
            if (node.classList && node.classList.contains('swiper-slide')) {
              registerSlide(record, node);
            } else if (node.querySelectorAll) {
              var nested = node.querySelectorAll(SLIDE_SELECTOR);
              for (var j = 0; j < nested.length; j += 1) {
                registerSlide(record, nested[j]);
              }
            }
          }
        });
      });
      observer.observe(record.container, { childList: true, subtree: true });
      record.observer = observer;
    }

    function ensureRecord(container) {
      var existing = containerRecords.get(container);
      if (existing) {
        return existing;
      }
      var record = {
        container: container,
        swiper: null,
        swiperEventsLinked: false,
        swiperObserver: null,
        pendingDisabled: null,
        swiperDisabled: false,
        disableCount: 0,
        observer: null
      };
      containerRecords.set(container, record);
      observeContainer(record);
      watchForSwiper(record);
      return record;
    }

    function registerContainer(container) {
      if (!container || !container.querySelector) {
        return;
      }
      if (!isSupportedContainer(container)) {
        return;
      }
      if (!container.querySelector('.swiper-wrapper')) {
        return;
      }
      var record = ensureRecord(container);
      registerSlides(record);
    }

    function registerSlides(record) {
      if (!record || !record.container) {
        return;
      }
      var slides = record.container.querySelectorAll(SLIDE_SELECTOR);
      for (var i = 0; i < slides.length; i += 1) {
        registerSlide(record, slides[i]);
      }
    }

    function registerSlide(record, slide) {
      if (!record || !slide || slideRegistry.has(slide)) {
        return;
      }
      var media = slide.querySelector(MEDIA_SELECTOR);
      if (!media) {
        slideRegistry.set(slide, null);
        return;
      }
      var tagName = media.tagName ? media.tagName.toUpperCase() : '';
      if (tagName === IMAGE_TAG) {
        slideRegistry.set(slide, { type: 'image', slide: slide, media: media, record: record });
      } else {
        slideRegistry.set(slide, { type: tagName === VIDEO_TAG ? 'video' : 'other', slide: slide, media: media, record: record });
      }
    }

    function scanForContainers(root) {
      var scope = root || doc;
      if (!scope) {
        return;
      }
      var candidates = [];
      if (scope.nodeType === 1 && isSupportedContainer(scope)) {
        candidates.push(scope);
      }
      if (scope.querySelectorAll) {
        var found = scope.querySelectorAll(CONTAINER_SELECTOR);
        for (var i = 0; i < found.length; i += 1) {
          candidates.push(found[i]);
        }
      }
      for (var j = 0; j < candidates.length; j += 1) {
        registerContainer(candidates[j]);
      }
    }

    function setupGlobalObserver() {
      if (!win.MutationObserver || !doc.body) {
        return null;
      }
      var observer = new MutationObserver(function (mutations) {
        mutations.forEach(function (mutation) {
          if (!mutation.addedNodes) {
            return;
          }
          for (var i = 0; i < mutation.addedNodes.length; i += 1) {
            var node = mutation.addedNodes[i];
            if (!node || node.nodeType !== 1) {
              continue;
            }
            scanForContainers(node);
          }
        });
      });
      observer.observe(doc.body, { childList: true, subtree: true });
      return observer;
    }

    function handleModeChange() {
      // LightGallery handles pinch/zoom; legacy zoom hooks retired.
    }

    function extractDataValue(el, keys) {
      if (!el) {
        return '';
      }
      var dataset = el.dataset || {};
      for (var i = 0; i < keys.length; i += 1) {
        var key = keys[i];
        var camel = key.replace(/-([a-z])/g, function (_, chr) { return chr.toUpperCase(); });
        if (dataset[camel]) {
          return dataset[camel];
        }
        if (dataset[key]) {
          return dataset[key];
        }
        var attr = el.getAttribute('data-' + key);
        if (attr) {
          return attr;
        }
        var hyphen = key.replace(/[A-Z]/g, function (chr) { return '-' + chr.toLowerCase(); });
        if (hyphen !== key) {
          var attrHyphen = el.getAttribute('data-' + hyphen);
          if (attrHyphen) {
            return attrHyphen;
          }
        }
      }
      return '';
    }

    function uniquePush(list, value) {
      if (!value) {
        return;
      }
      for (var i = 0; i < list.length; i += 1) {
        if (list[i] && list[i].src === value.src) {
          return;
        }
      }
      list.push(value);
    }

    function describeImage(media) {
      var src = extractDataValue(media, ['full', 'src', 'original', 'image', 'url', 'large', 'preview', 'full-src', 'image-src', 'imageUrl']) || media.currentSrc || media.getAttribute('src');
      if (!src) {
        return null;
      }
      var alt = media.getAttribute('alt') || extractDataValue(media, ['alt', 'label']) || '';
      if (!alt) {
        alt = translate('viewer.image', 'Image');
      }
      return {
        type: 'image',
        src: src,
        srcset: extractDataValue(media, ['srcset']) || media.getAttribute('srcset') || '',
        sizes: extractDataValue(media, ['sizes']) || media.getAttribute('sizes') || '',
        alt: alt,
        caption: extractDataValue(media, ['caption', 'title']) || media.getAttribute('title') || ''
      };
    }

    function describeVideo(media) {
      var videoAlt = extractDataValue(media, ['alt', 'label']) || media.getAttribute('aria-label') || '';
      if (!videoAlt) {
        videoAlt = translate('viewer.video', 'Video');
      }
      var descriptor = {
        type: 'video',
        sources: [],
        poster: media.getAttribute('poster') || extractDataValue(media, ['poster', 'thumb', 'thumbnail']) || '',
        alt: videoAlt,
        caption: extractDataValue(media, ['caption', 'title']) || media.getAttribute('title') || ''
      };

      var sourceNodes = media.querySelectorAll('source');
      for (var i = 0; i < sourceNodes.length; i += 1) {
        var node = sourceNodes[i];
        var src = node.getAttribute('src');
        if (!src) {
          continue;
        }
        uniquePush(descriptor.sources, {
          src: src,
          type: node.getAttribute('type') || ''
        });
      }

      var dataSource = extractDataValue(media, ['video', 'video-src', 'video-url', 'videoSrc', 'videoUrl', 'videoFile', 'src', 'source', 'stream', 'url', 'file']);
      if (dataSource) {
        uniquePush(descriptor.sources, { src: dataSource, type: media.getAttribute('type') || '' });
      }

      var inlineSrc = media.getAttribute('src');
      if (inlineSrc) {
        uniquePush(descriptor.sources, { src: inlineSrc, type: media.getAttribute('type') || '' });
      }

      if (descriptor.sources.length) {
        descriptor.src = descriptor.sources[0].src;
      } else if (inlineSrc) {
        descriptor.src = inlineSrc;
      }

      if (!descriptor.src && !descriptor.sources.length) {
        return null;
      }

      return descriptor;
    }

    function describeStandaloneMedia(container, media) {
      var descriptor = null;
      var tagName = media && media.tagName ? media.tagName.toUpperCase() : '';
      if (tagName === IMAGE_TAG) {
        descriptor = describeImage(media);
      } else if (tagName === VIDEO_TAG) {
        descriptor = describeVideo(media);
      }
      if (!descriptor) {
        return null;
      }
      descriptor.media = media;
      descriptor.container = container;
      descriptor.slide = null;
      return descriptor;
    }

    function describeSlideForViewer(slide) {
      if (!slide) {
        return null;
      }
      var media = slide.querySelector(MEDIA_SELECTOR);
      if (!media) {
        return null;
      }
      var tagName = media.tagName ? media.tagName.toUpperCase() : '';
      var descriptor = null;
      if (tagName === IMAGE_TAG) {
        descriptor = describeImage(media);
      } else if (tagName === VIDEO_TAG) {
        descriptor = describeVideo(media);
      }
      if (!descriptor) {
        return null;
      }
      descriptor.slide = slide;
      descriptor.media = media;
      descriptor.container = slide.closest(CONTAINER_SELECTOR) || null;
      return descriptor;
    }

    function buildGallery(container, targetSlide, targetMedia) {
      var items = [];
      var activeIndex = 0;
      if (!container) {
        return { items: items, index: activeIndex };
      }

      var slideNodes = container.querySelectorAll(SLIDE_SELECTOR);
      if (slideNodes.length) {
        for (var i = 0; i < slideNodes.length; i += 1) {
          var candidate = describeSlideForViewer(slideNodes[i]);
          if (!candidate) {
            continue;
          }
          items.push(candidate);
          if (targetSlide && slideNodes[i] === targetSlide) {
            activeIndex = items.length - 1;
          }
        }
      } else {
        var mediaNodes = container.querySelectorAll(MEDIA_SELECTOR);
        for (var j = 0; j < mediaNodes.length; j += 1) {
          var mediaDescriptor = describeStandaloneMedia(container, mediaNodes[j]);
          if (!mediaDescriptor) {
            continue;
          }
          items.push(mediaDescriptor);
          if (targetMedia && mediaNodes[j] === targetMedia) {
            activeIndex = items.length - 1;
          }
        }
      }

      return { items: items, index: activeIndex };
    }

    function openMediaInViewer(node) {
      if (!node) {
        return false;
      }
      var slide = node.closest ? node.closest(SLIDE_SELECTOR) : null;
      var media = null;
      if (slide) {
        media = slide.querySelector(MEDIA_SELECTOR);
      }
      if (!media && node.matches && node.matches(MEDIA_SELECTOR)) {
        media = node;
      }
      if (!media && node.querySelector) {
        media = node.querySelector(MEDIA_SELECTOR);
      }
      if (!media) {
        return false;
      }

      var container = (slide ? slide.closest(CONTAINER_SELECTOR) : null) || media.closest(CONTAINER_SELECTOR);
      if (!container) {
        return false;
      }

      var galleryData = buildGallery(container, slide, media);
      if (!galleryData.items.length) {
        return false;
      }

      var record = containerRecords.get(container) || null;
      if (!record && container.querySelector && container.querySelector('.swiper-wrapper')) {
        record = ensureRecord(container);
      }

      if (openWithLightGallery(container, galleryData, record)) {
        return true;
      }

      if (record && activeLightGalleryRecord === record) {
        releaseSwiperDisable(record);
        activeLightGalleryRecord = null;
      }

      return mediaViewer.open({
        source: 'post-media-single',
        gallery: {
          container: container,
          items: galleryData.items,
          index: galleryData.index
        }
      });
    }

    function handleMediaClick(evt) {
      if (!evt || (evt.button !== undefined && evt.button !== 0)) {
        return;
      }
      if (evt.defaultPrevented) {
        return;
      }
      var target = evt.target;
      if (!target || !target.closest) {
        return;
      }
      if (target.closest('.lg-container') || target.closest('[' + ROOT_DATA_ATTR + ']')) {
        return;
      }
      var media = target.closest(MEDIA_SELECTOR);
      if (!media) {
        return;
      }
      var opened = openMediaInViewer(media);
      if (!opened) {
        return;
      }
      evt.preventDefault();
      evt.stopPropagation();
    }


    ready(function () {
      scanForContainers();
      setupGlobalObserver();
      handleModeChange();
      doc.addEventListener('click', handleMediaClick, true);
      addMediaQueryListener(maxWidthMediaQuery, handleModeChange);
      addMediaQueryListener(coarsePointerMediaQuery, handleModeChange);
    });
  })();
})(window, document);
