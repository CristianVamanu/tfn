/* eslint-env jquery */
(function ($) {
  'use strict';

  var buildUrl = (window.DZ && typeof window.DZ.buildUrl === 'function')
    ? window.DZ.buildUrl
    : function (path) {
        var base = (typeof window.site_url === 'string' && window.site_url)
          ? window.site_url
          : (window.location.origin + window.location.pathname.replace(/[^\/]*$/, ''));
        if (base.slice(-1) !== '/') {
          base += '/';
        }
        return base + String(path || '').replace(/^\/+/, '');
      };

  $(document).on('submit', '.reset-password-form', function (event) {
    event.preventDefault();

    var $form = $(this);
    var $button = $form.find('.login-submit');
    var $warning = $form.find('#resetWarning');
    var $success = $form.find('#resetSuccess');

    var uid = parseInt($form.find('input[name="uid"]').val(), 10) || 0;
    var token = ($form.find('input[name="token"]').val() || '').trim();
    var password = $form.find('input[name="new_password"]').val();
    var confirmPassword = $form.find('input[name="confirm_password"]').val();
    var csrfToken = $form.find('input[name="csrf_token"]').val();

    var errorRequired = $form.data('error-required') || 'Please fill all fields.';
    var errorMismatch = $form.data('error-mismatch') || 'Passwords do not match.';
    var errorStrength = $form.data('error-strength') || 'Please choose a stronger password.';
    var errorToken = $form.data('error-token') || 'The reset link is invalid or has expired.';
    var errorUnexpected = $form.data('error-unexpected') || 'Unexpected error occurred.';
    var successMessage = $form.data('success') || $form.data('success-message') || 'Your password has been updated.';
    var loadingText = $form.data('loading-text') || 'Processing...';
    var originalText = $button.data('default-text');
    if (!originalText) {
      originalText = $button.text();
      $button.data('default-text', originalText);
    }

    var resetMessages = function () {
      [$warning, $success].forEach(function ($el) {
        if ($el && $el.length) {
          $el.addClass('none').text('');
        }
      });
    };
    var showMessage = function ($el, message) {
      if ($el && $el.length) {
        $el.removeClass('none').text(message);
      }
    };

    resetMessages();

    if (!uid || !token || !password || !confirmPassword) {
      showMessage($warning, errorRequired);
      return;
    }

    if (password !== confirmPassword) {
      showMessage($warning, errorMismatch);
      return;
    }

    var requestData = {
      p: 'reset_password_submit',
      uid: uid,
      token: token,
      new_password: password,
      confirm_password: confirmPassword,
      csrf_token: csrfToken
    };

    $.ajax({
      type: 'POST',
      url: buildUrl('request/requests.php'),
      dataType: 'json',
      data: requestData,
      beforeSend: function () {
        $button.prop('disabled', true).text(loadingText);
      },
      success: function (response) {
        if (response && response.status === 'success') {
          var message = response.message || successMessage;
          showMessage($success, message);
          setTimeout(function () {
            var redirect = response.redirect ? String(response.redirect) : 'login';
            window.location.href = buildUrl(redirect);
          }, 1000);
        } else {
          var message = (response && response.message) ? response.message : errorUnexpected;
          if (message === 'token_invalid') {
            message = errorToken;
          }
          if (message === 'weak_password') {
            message = errorStrength;
          }
          showMessage($warning, message);
        }
      },
      error: function () {
        showMessage($warning, errorUnexpected);
      },
      complete: function () {
        $button.prop('disabled', false).text(originalText);
      }
    });
  });
})(jQuery);
