/* Tips Handler: submit tips form, start payment */
(function(){
  var alreadyBound = window.__tipsHandlerBound === true;
  if (!alreadyBound) {
    window.__tipsHandlerBound = true;
  }
  var buildUrl = (window.DZ && window.DZ.buildUrl) || function(path){
    try { var base=(typeof window.site_url==='string'&&window.site_url)?window.site_url:(window.location.origin+window.location.pathname.replace(/[^\/]*$/,'')); if(base.slice(-1)!=='/') base+='/'; return new URL(String(path||'').replace(/^\//,''), base).toString(); } catch(_) { return String(path||''); }
  };
  var I18N = (window.DZ && typeof DZ.i18n === 'function') ? DZ.i18n : function(){ return ''; };
  function getCsrf(){ return document.querySelector('input[name="csrf_token"]')?.value || ''; }
  function getString(val){ return (val === null || val === undefined) ? '' : String(val); }

  function alertDialog(message, tone, onConfirm){
    var resolved = 'info';
    if (tone === 'error') { resolved = 'danger'; }
    else if (tone === 'success') { resolved = 'success'; }
    else if (tone === 'warning') { resolved = 'warning'; }
    var label = I18N('ui_ok') || 'OK';
    try {
      if (window.DZ && typeof window.DZ.showAlertDialog === 'function') {
        window.DZ.showAlertDialog({
          tone: resolved,
          title: (resolved === 'danger') ? (I18N('ui_error_title') || 'Something went wrong') :
                 (resolved === 'success' ? (I18N('ui_success_title') || 'Success') :
                  (resolved === 'warning' ? (I18N('ui_warning_title') || 'Heads up') : (I18N('ui_info_title') || 'Notice'))),
          message: getString(message),
          confirmLabel: label,
          onConfirm: typeof onConfirm === 'function' ? onConfirm : null
        });
        return true;
      }
    } catch(_){}
    return false;
  }
  try { window.__tipsAlertDialog = alertDialog; } catch(_){}

  function resolveBillingAccordion(button, form){
    if (!button) { return null; }
    var selector = button.getAttribute('data-billing-target') || '';
    if (selector) {
      var id = selector.charAt(0) === '#' ? selector.slice(1) : selector;
      if (id) {
        var targetById = document.getElementById(id);
        if (targetById) { return targetById; }
      }
      try {
        var targetBySelector = document.querySelector(selector);
        if (targetBySelector) { return targetBySelector; }
      } catch(_){}
    }
    var summary = button.closest('[data-billing-summary]');
    if (summary) {
      var sibling = summary.nextElementSibling;
      while (sibling) {
        if (sibling.classList && sibling.classList.contains('tips-accordion--form')) {
          return sibling;
        }
        sibling = sibling.nextElementSibling;
      }
    }
    if (form) {
      var fallback = form.querySelector('.tips-accordion--form');
      if (fallback) { return fallback; }
    }
    return null;
  }
  try { window.__resolveBillingAccordion = resolveBillingAccordion; } catch(_){}

  function toggleBillingSection(form, forceOpen, accordionEl, summaryEl){
    if (!form) { return; }
    var accordion = accordionEl || null;
    if (!accordion) {
      accordion = form.querySelector('.tips-accordion--form');
    }
    if (!accordion) { return; }
    var summary = summaryEl || null;
    if (!summary) {
      summary = form.querySelector('[data-billing-summary]');
    }
    var fields = accordion.querySelectorAll('[data-billing-fields]');
    var isCollapsed = true;
    isCollapsed = accordion.classList.contains('is-collapsed');
    var shouldOpen = (typeof forceOpen === 'boolean') ? forceOpen : isCollapsed;
    if (shouldOpen) {
      form.dataset.billingEditing = '1';
      if (summary) {
        summary.setAttribute('hidden', 'hidden');
        summary.classList.add('is-hidden');
      }
      fields.forEach(function(block){ block.removeAttribute('hidden'); });
      if (accordion) {
        accordion.classList.remove('is-collapsed');
      }
      var focusTarget = fields ? fields.querySelector('input, select, textarea') : null;
      if (focusTarget && typeof focusTarget.focus === 'function') {
        setTimeout(function(){ try { focusTarget.focus(); } catch(_){ } }, 30);
      }
    } else {
      delete form.dataset.billingEditing;
      if (summary) {
        summary.removeAttribute('hidden');
        summary.classList.remove('is-hidden');
      }
      fields.forEach(function(block){ block.setAttribute('hidden', 'hidden'); });
      if (accordion) {
        accordion.classList.add('is-collapsed');
      }
    }
  }
  try { window.__toggleBillingSection = toggleBillingSection; } catch(_){}

  var BILLING_FIELD_KEYS = [
    'billing_first_name',
    'billing_last_name',
    'billing_country',
    'billing_city',
    'billing_state',
    'billing_postcode',
    'billing_address'
  ];

  function readBillingInputs(form){
    var data = {};
    BILLING_FIELD_KEYS.forEach(function(key){
      var selectorId = '#'+key.replace('billing_', 'bill_');
      var input = form ? form.querySelector(selectorId) : null;
      data[key] = input ? getString(input.value).trim() : '';
    });
    return data;
  }

  function parseSavedBilling(form){
    if (!form) { return null; }
    if (typeof form.__savedBilling === 'undefined') {
      var raw = form.getAttribute('data-billing-json') || '';
      if (!raw) {
        form.__savedBilling = null;
      } else {
        try { form.__savedBilling = JSON.parse(raw); }
        catch(_){ form.__savedBilling = null; }
      }
    }
    return form.__savedBilling;
  }

  function isBillingComplete(data){
    return !!(data && data.billing_first_name && data.billing_last_name && data.billing_country && data.billing_address);
  }

  function collectBilling(form){
    if (!form) { return readBillingInputs(form); }
    var editing = form.dataset.billingEditing === '1' || !(form.getAttribute('data-billing-json') || '').length;
    var data = editing ? readBillingInputs(form) : null;
    if (!editing) {
      var saved = parseSavedBilling(form) || {};
      data = {};
      BILLING_FIELD_KEYS.forEach(function(key){
        var value = saved[key];
        if (typeof value === 'undefined') {
          var fallbackKey = key.replace('billing_', '');
          value = saved[fallbackKey];
        }
        data[key] = getString(value).trim();
      });
      if (!isBillingComplete(data)) {
        var live = readBillingInputs(form);
        data = Object.assign({}, live, data);
      }
    }
    return data;
  }
  try {
    window.__collectTipsBilling = collectBilling;
    window.__tipsBillingComplete = isBillingComplete;
  } catch(_){}
  // Unified tooltip inside tips modal; falls back to global toast
  function ensureDzToast(){
    window.DZ = window.DZ || {};
    if (typeof DZ.toast === 'function') return;
    DZ.toast = function(msg, opts){
      try {
        var id='dz-toast-container'; var c=document.getElementById(id);
        if(!c){ c=document.createElement('div'); c.id=id; c.className='dz-toast-container'; document.body.appendChild(c); }
        var el=document.createElement('div'); el.className='dz-toast is-info'; el.textContent=String(msg||'');
        c.appendChild(el); requestAnimationFrame(function(){ el.classList.add('is-shown'); });
        setTimeout(function(){ el.classList.remove('is-shown'); setTimeout(function(){ el.remove(); }, 220); }, (opts&&opts.duration)||2200);
      } catch(e){}
    };
  }
  function showMsg(msg, type){
    var m = document.getElementById('tipsModal');
    var box = m ? m.querySelector('.tips-alert') : null;
    var kind = (type==='success'||type==='error') ? type : 'info';
    if (alertDialog(msg, kind)) { return; }
    if (box){
      box.className = 'tips-alert is-shown ' + (kind==='error'?'is-error':(kind==='success'?'is-success':'is-info'));
      box.textContent = String(msg||'');
      // auto-hide after a while
      clearTimeout(box.__hideTimer); box.__hideTimer = setTimeout(function(){ box.classList.remove('is-shown'); }, 3500);
      return;
    }
    ensureDzToast();
    DZ.toast(String(msg||''), { type: kind==='error'?'error':(kind==='success'?'success':'info'), duration: 2800 });
  }
  function normalizePrecision(p){
    if (typeof p === 'number' && isFinite(p) && p >= 0) { return p; }
    if (window.DZ && DZ.currencyFormat && typeof DZ.currencyFormat.decimalPlaces === 'number') {
      var base = DZ.currencyFormat.decimalPlaces;
      if (isFinite(base) && base >= 0) { return base; }
    }
    return 2;
  }
  function parseAmount(raw, precision, decSep, thouSep){
    var dec = decSep || (window.DZ && DZ.currencyFormat && DZ.currencyFormat.decimalSep) || '.';
    var thou = (typeof thouSep === 'string') ? thouSep : ((window.DZ && DZ.currencyFormat && DZ.currencyFormat.thousandsSep) || ',');
    var str = (raw === null || raw === undefined) ? '' : String(raw);
    if (thou) {
      var escThou = thou.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      str = str.replace(new RegExp(escThou, 'g'), '');
    }
    if (dec && dec !== '.') {
      var escDec = dec.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      str = str.replace(new RegExp(escDec, 'g'), '.');
    }
    str = str.replace(/[^0-9.+-]/g, '');
    var num = parseFloat(str);
    if (!isFinite(num)) { num = 0; }
    var prec = normalizePrecision(precision);
    return parseFloat(num.toFixed(prec));
  }
  function onSubmit(ev){
    const form = ev.target.closest('.tips-form');
    if(!form) return;
    if (form.dataset.formType === 'wallet_topup') { return; }
    ev.preventDefault();
    if (form.dataset.submitting === '1') { return; }
    const amountInput = form.querySelector('#tipAmount');
    const precision = normalizePrecision(parseInt(form.dataset.amountPrecision, 10));
    const decSep = (window.DZ && DZ.currencyFormat && DZ.currencyFormat.decimalSep === ',') ? ',' : '.';
    const thouSep = (window.DZ && DZ.currencyFormat && typeof DZ.currencyFormat.thousandsSep === 'string') ? DZ.currencyFormat.thousandsSep : ',';
    const formType = (form.dataset.formType || 'tip');

    let amount = 0;
    if (formType === 'purchase') {
      const fixedRaw = form.dataset.fixedAmount || (amountInput ? amountInput.dataset.display : '') || '';
      amount = parseAmount(fixedRaw, precision, decSep, thouSep);
    } else {
      const amountRaw = amountInput ? amountInput.value : '';
      amount = parseAmount(amountRaw, precision, decSep, thouSep);
    }

    const min = parseAmount(amountInput?.dataset.min || '1', precision, decSep, thouSep);
    const max = parseAmount(amountInput?.dataset.max || '500', precision, decSep, thouSep);
    if (!amount || amount < min || amount > max){ showMsg(I18N('pay_error_invalid_amount') || 'Please enter a valid amount.', 'error'); return; }
    const provider = form.querySelector('input[name="tip_provider"]:checked')?.value || '';
    if (!provider){ showMsg(I18N('pay_error_select_provider') || 'Select a payment provider.', 'error'); return; }
    const postId = parseInt(form.querySelector('input[name="post_id"]').value || '0', 10);
    const recipientId = parseInt(form.querySelector('input[name="recipient_id"]').value || '0', 10);
    if (!recipientId){ showMsg(I18N('pay_error_missing_recipient') || 'Missing recipient.', 'error'); return; }

    // Billing
    const bf = collectBilling(form);
    if (!isBillingComplete(bf)){
      showMsg(I18N('pay_error_complete_billing') || 'Please complete your billing details.', 'error');
      return;
    }

    const fd = new FormData();
    let endpoint = 'tips_create_payment';
    if (formType === 'purchase') endpoint = 'purchase_create_payment';
    fd.append('p', endpoint);
    fd.append('provider', provider);
    fd.append('post_id', String(postId));
    fd.append('recipient_id', String(recipientId));
    fd.append('amount', String(amount.toFixed(precision)));
    Object.entries(bf).forEach(([k,v])=> fd.append(k, v));
    fd.append('csrf_token', getCsrf());

    // lock UI to prevent double-submit
    form.dataset.submitting = '1';
    const submitBtn = form.querySelector('.tips-cta');
    if (submitBtn) { submitBtn.disabled = true; submitBtn.classList.add('is-loading'); }

    fetch(buildUrl('request/requests.php'), { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(r => r.json()).then(j => {
        if (!j || j.status !== 'success') { showMsg(j && j.message ? j.message : (I18N('pay_error_init_failed') || 'Payment init failed.'), 'error'); return; }
        if (j.provider === 'wallet') {
          if (formType === 'purchase' && j.redirect_url) {
            window.location.href = j.redirect_url;
            return;
          }
          var walletMsg = formType === 'purchase'
            ? (I18N('pay_success_wallet_purchase') || 'Purchase completed from wallet.')
            : (I18N('pay_success_wallet_tip') || 'Tip sent from wallet successfully.');
          var finalizeWalletSuccess = function(){
            document.querySelector('.tips-overlay')?.classList.remove('is-open');
            document.querySelector('.popUp-container')?.remove();
            ensureDzToast();
            DZ.toast(walletMsg, { type: 'success', duration: 2800 });
            try {
              if (formType === 'tip') {
                var buyerName = form.querySelector('input[name="buyer_name"]')?.value || '';
                var currency = form.dataset.currency || 'USD';
                var ref = window.__agoraRtmRef;
                var liveHidden = form.querySelector('input[name="live_id"]');
                var liveId = liveHidden ? parseInt(liveHidden.value||'0',10)||0 : 0;
                if (ref && ref.channel) {
                  var payload = { type: 'live_tip', buyer: buyerName, amount: amount, currency: currency };
                  ref.channel.sendMessage({ text: JSON.stringify(payload) }).catch(function(){});
                } else if (typeof window.maybeLiveTip === 'function') {
                  window.maybeLiveTip(buyerName, amount, currency);
                }
                if (liveId > 0) {
                  var afd = new FormData();
                  afd.append('p','announce_live_tip');
                  afd.append('live_id', String(liveId));
                  afd.append('buyer', buyerName || '');
                  afd.append('amount', String(amount.toFixed(precision)));
                  afd.append('currency', currency);
                  afd.append('csrf_token', getCsrf());
                  fetch(buildUrl('request/requests.php'), { method:'POST', body: afd, credentials:'same-origin' }).catch(function(){});
                }
              }
            } catch(_){}
          };
          if (!alertDialog(walletMsg, 'success', finalizeWalletSuccess)) {
            finalizeWalletSuccess();
          }
          return;
        }
        if (j.checkout_url) {
          // Persist pending payment info to reconcile after returning from provider
          try {
            var pending = {
              type: formType,
              provider: j.provider || (form.querySelector('input[name="tip_provider"]:checked')?.value || ''),
              reference: j.reference || '',
              post_id: parseInt(form.querySelector('input[name="post_id"]').value || '0', 10) || null,
              recipient_id: parseInt(form.querySelector('input[name="recipient_id"]').value || '0', 10) || null,
              created_at: Date.now()
            };
            // enrich with tip context
            pending.amount = amount;
            pending.currency = (typeof j.currency === 'string' && j.currency !== '') ? j.currency : (form.dataset.currency || 'USD');
            if (j && typeof j.total_amount !== 'undefined') {
              var totalParsed = parseFloat(j.total_amount);
              if (!isNaN(totalParsed)) { pending.total = totalParsed; }
            }
            if (j && typeof j.fee_amount !== 'undefined') {
              var feeParsed = parseFloat(j.fee_amount);
              if (!isNaN(feeParsed)) { pending.fee = feeParsed; }
            }
            if (j && typeof j.tax_amount !== 'undefined') {
              var taxParsed = parseFloat(j.tax_amount);
              if (!isNaN(taxParsed)) { pending.tax = taxParsed; }
            }
            try { pending.buyer = form.querySelector('input[name="buyer_name"]').value || ''; } catch(_){ }
            window.sessionStorage.setItem('pending_payment', JSON.stringify(pending));
          } catch(e) { /* ignore */ }
          window.location.href = j.checkout_url; return;
        }
        showMsg(I18N('pay_unexpected_response') || 'Unexpected response.', 'error');
      }).catch(e => { console.error(e); showMsg(I18N('pay_request_failed') || 'Request failed.', 'error'); })
      .finally(() => {
        // unlock if still on page
        if (form.isConnected) {
          delete form.dataset.submitting;
          if (submitBtn) { submitBtn.disabled = false; submitBtn.classList.remove('is-loading'); }
        }
      });
  }

  if (!alreadyBound) {
    document.addEventListener('submit', function(ev){
      if (ev.target && ev.target.matches('.tips-form') && ev.target.dataset.formType !== 'wallet_topup') { onSubmit(ev); }
    });
  }

  // On page load: if we have a pending payment (external provider), poll status and inform user
  function startPendingPoll(){
    var raw = null;
    try { raw = window.sessionStorage.getItem('pending_payment'); } catch(e) {}
    if (!raw) return;
    var pending = null; try { pending = JSON.parse(raw); } catch(e) {}
    if (!pending || !pending.provider || !pending.reference) { return; }
    if ((pending.type || '') === 'wallet_topup') { return; }
    if (window.__pendingPaymentPollActive) { return; }
    window.__pendingPaymentPollActive = true;

    var shown = false;
    function poll(){
      var fd = new FormData();
      fd.append('p', 'payment_status');
      fd.append('provider', pending.provider);
      fd.append('reference', pending.reference);
      fd.append('type', pending.type || 'purchase');
      var csrf = getCsrf();
      if (csrf) {
        fd.append('csrf_token', csrf);
      }
      fetch(buildUrl('request/requests.php'), { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(r => r.json()).then(function(j){
          if (!j || j.status !== 'success') return;
          if (!shown) { shown = true; showMsg(I18N('pay_processing_message') || 'We are processing your payment. It may take a moment to finalize.', 'info'); }
          if (j.payment_status === 'succeeded'){
            try { window.sessionStorage.removeItem('pending_payment'); } catch(e) {}
            window.__pendingPaymentPollActive = false;
            if ((pending.type || 'purchase') === 'purchase') {
              // Reload to reflect unlocked content
              window.location.reload();
            } else {
              var tipSuccessMsg = I18N('pay_success_tip') || 'Tip completed successfully.';
              var toastAfterConfirm = function(){
                ensureDzToast();
                DZ.toast(tipSuccessMsg, { type: 'success', duration: 2800 });
              };
              if (!alertDialog(tipSuccessMsg, 'success', toastAfterConfirm)) {
                toastAfterConfirm();
              }
              // Notify live channel + server announce
              try {
                var ref = window.__agoraRtmRef;
                if (ref && ref.channel) {
                  var msg = { type: 'live_tip', buyer: pending.buyer || '', amount: pending.amount || 0, currency: pending.currency || 'USD' };
                  ref.channel.sendMessage({ text: JSON.stringify(msg) }).catch(function(){});
                } else if (typeof window.maybeLiveTip === 'function') {
                  window.maybeLiveTip(pending.buyer || '', pending.amount || 0, pending.currency || 'USD');
                }
                // Server announce for polling
                try {
                  var liveIdInput = document.querySelector('#tipsModal input[name="live_id"]');
                  var liveId = liveIdInput ? parseInt(liveIdInput.value||'0',10)||0 : 0;
                  if (liveId > 0) {
                    var afd = new FormData();
                    afd.append('p','announce_live_tip');
                    afd.append('live_id', String(liveId));
                    afd.append('buyer', pending.buyer || '');
                    afd.append('amount', String(pending.amount || 0));
                    afd.append('currency', pending.currency || 'USD');
                    afd.append('csrf_token', getCsrf());
                    fetch(buildUrl('request/requests.php'), { method:'POST', body: afd, credentials:'same-origin' }).catch(function(){});
                  }
                } catch(_){ }
              } catch(_){}
            }
          } else {
            // Keep polling for a short period
            if (j.payment_status === 'failed' || j.payment_status === 'canceled' || j.payment_status === 'cancelled') {
              try { window.sessionStorage.removeItem('pending_payment'); } catch(e) {}
              window.__pendingPaymentPollActive = false;
              showMsg(I18N('pay_failed_tip') || 'Tip payment could not be completed.', 'error');
              return;
            }
            setTimeout(poll, 4000);
          }
        }).catch(function(){ setTimeout(poll, 6000); });
    }
    // Kick off poll shortly after load
    setTimeout(poll, 800);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startPendingPoll);
  } else {
    startPendingPoll();
  }
})();
