(function(){
  'use strict';

  var I18N = (window.DZ && typeof window.DZ.i18n === 'function') ? window.DZ.i18n : null;

  function i18n(key, fallback) {
    if (I18N) {
      try {
        var value = I18N(key);
        if (typeof value === 'string' && value) { return value; }
      } catch (_) {}
    }
    return fallback;
  }

  function buildUrl(path){
    try {
      if (typeof window.buildUrl === 'function') {
        return window.buildUrl(path);
      }
      if (typeof window.DZ === 'object' && typeof window.DZ.buildUrl === 'function') {
        return window.DZ.buildUrl(path);
      }
      var origin = window.location.origin || ((window.location.protocol || 'http:') + '//' + (window.location.host || ''));
      return new URL(String(path || ''), origin + '/').toString();
    } catch(_) { return String(path || ''); }
  }

  function handleJson(response) {
    return response.json().catch(function(){
      return { status: 'error', message: 'INVALID_RESPONSE' };
    });
  }

  function setAlert(el, type, msg, options) {
    if (!el) { return; }
    var allowHtml = options && options.allowHtml;
    if (allowHtml) {
      el.innerHTML = msg || '';
    } else {
      el.textContent = msg || '';
    }
    el.classList.remove('is-error', 'is-success');
    if (type === 'success') {
      el.classList.add('is-success');
    } else if (type === 'error') {
      el.classList.add('is-error');
    }
  }

  function clearAlert(el) {
    if (!el) { return; }
    el.textContent = '';
    el.classList.remove('is-error', 'is-success');
  }

  function disableWhile(btn, fn) {
    var promise;
    if (!btn) {
      try {
        promise = Promise.resolve(fn());
      } catch (err) {
        promise = Promise.reject(err);
      }
      return promise;
    }
    var previousDisabled = btn.disabled;
    var previousText = btn.textContent;
    btn.disabled = true;
    btn.textContent = i18n('saving', 'Saving...');
    try {
      promise = Promise.resolve(fn());
    } catch (err) {
      promise = Promise.reject(err);
    }
    var reset = function(){
      btn.disabled = previousDisabled;
      btn.textContent = previousText;
    };
    return promise.then(function(result){ reset(); return result; }, function(err){ reset(); throw err; });
  }

  function formatDateTime(value) {
    var fallback = i18n('settings_payout_never_updated', 'Not updated yet');
    if (value === null || value === undefined || value === '') {
      return fallback;
    }
    var numeric = Number(value);
    if (!isFinite(numeric)) { return fallback; }
    if (numeric > 0 && numeric < 1e12) {
      numeric = numeric * 1000;
    }
    try {
      var date = new Date(numeric);
      if (!isFinite(date.getTime())) { return fallback; }
      var locale = document.documentElement && document.documentElement.lang ? document.documentElement.lang : undefined;
      var formatter = new Intl.DateTimeFormat(locale || undefined, { dateStyle: 'short', timeStyle: 'short' });
      return formatter.format(date);
    } catch(_) {
      return fallback;
    }
  }

  var STATUS_BADGES = {
    approved: 'status-badge--success',
    pending: 'status-badge--pending',
    processing: 'status-badge--pending',
    review: 'status-badge--pending',
    rejected: 'status-badge--danger',
    failed: 'status-badge--danger',
    none: 'status-badge--neutral'
  };

  function normalizeStatus(value) {
    if (typeof value !== 'string' || value === '') { return 'pending'; }
    var normalized = value.trim().toLowerCase();
    if (normalized === 'verified') { normalized = 'approved'; }
    if (!STATUS_BADGES.hasOwnProperty(normalized)) {
      return 'pending';
    }
    return normalized;
  }

  function badgeClass(status) {
    var normalized = normalizeStatus(status);
    return STATUS_BADGES[normalized] || 'status-badge--pending';
  }

  function statusLabel(status) {
    var normalized = normalizeStatus(status);
    var fallback = normalized.replace(/_/g, ' ');
    fallback = fallback.charAt(0).toUpperCase() + fallback.slice(1);
    return i18n('settings_payout_status_' + normalized, fallback);
  }

  function connectionLabel(state) {
    if (state === 'connected') {
      return i18n('settings_payout_connected', 'Connected');
    }
    return i18n('settings_payout_not_connected', 'Not connected');
  }

  function parseJsonAttribute(node, attr) {
    if (!node) { return null; }
    var raw = node.getAttribute(attr);
    if (!raw) { return null; }
    try { return JSON.parse(raw); } catch (_) { return null; }
  }

  function normalizeContext(raw) {
    if (!raw || typeof raw !== 'object') { return null; }
    var context = {
      default_method: typeof raw.default_method === 'string' ? raw.default_method : 'none',
      methods: {},
      connected: {}
    };
    if (raw.methods && typeof raw.methods === 'object') {
      Object.keys(raw.methods).forEach(function(key){
        if (!Object.prototype.hasOwnProperty.call(raw.methods, key)) { return; }
        var methodKey = String(key);
        var payload = raw.methods[key];
        if (!payload || typeof payload !== 'object') { payload = {}; }
        var copy = Object.assign({}, payload);
        copy.status = normalizeStatus(copy.status || 'pending');
        if (copy.updated_at !== undefined && copy.updated_at !== null) {
          copy.updated_at = Number(copy.updated_at);
        }
        if (copy.priority !== undefined && copy.priority !== null) {
          copy.priority = Number(copy.priority);
        }
        if (copy.status_updated_at !== undefined && copy.status_updated_at !== null) {
          copy.status_updated_at = Number(copy.status_updated_at);
        } else if (copy.updated_at !== undefined && copy.updated_at !== null) {
          copy.status_updated_at = Number(copy.updated_at);
        } else {
          copy.status_updated_at = null;
        }
        if (copy.admin_note !== undefined && copy.admin_note !== null) {
          copy.admin_note = String(copy.admin_note);
        } else {
          copy.admin_note = '';
        }
        copy.requires_update = !!copy.requires_update;
        context.methods[methodKey] = copy;
      });
    }
    if (raw.connected && typeof raw.connected === 'object') {
      Object.keys(raw.connected).forEach(function(key){
        if (!Object.prototype.hasOwnProperty.call(raw.connected, key)) { return; }
        context.connected[String(key)] = !!raw.connected[key];
      });
    } else {
      Object.keys(context.methods).forEach(function(methodKey){
        var payload = context.methods[methodKey] || {};
        context.connected[methodKey] = inferConnection(methodKey, payload);
      });
    }
    return context;
  }

  function inferConnection(method, payload) {
    if (!payload || typeof payload !== 'object') { return false; }
    switch (String(method)) {
      case 'bank':
        return !!(payload.account_name && payload.bank_name && (payload.iban || payload.account_number));
      case 'stripe':
        return !!payload.account_id;
      case 'paypal':
      case 'payoneer':
        return !!payload.email;
      case 'other':
        return !!payload.notes;
      default:
        return !!Object.keys(payload).length;
    }
  }

  var payoutContext = null;

  function dispatchContext(raw) {
    var ctx = normalizeContext(raw);
    if (!ctx) { return; }
    payoutContext = ctx;
    window.dispatchEvent(new CustomEvent('settings:payout-context', { detail: ctx }));
  }

  function formatSummary(connected, total, templateEl) {
    total = total || 0;
    if (templateEl) {
      var template = templateEl.getAttribute('data-payout-summary-template');
      if (template && template.indexOf('{') > -1) {
        return template.replace('{connected}', connected).replace('{total}', total || 0);
      }
    }
    return i18n('settings_payout_methods_summary_template', 'Connected methods: {connected}/{total}')
      .replace('{connected}', connected)
      .replace('{total}', total || 0);
  }

  function applyContextToMethods(context) {
    if (!context) { return; }
    var summary = document.querySelector('[data-payout-summary="methods"]');
    if (summary) {
      var methods = context.methods || {};
      var connectedMap = context.connected || {};
      var connectedCount = 0;
      Object.keys(connectedMap).forEach(function(key){ if (connectedMap[key]) { connectedCount++; } });
      var totalMethods = Object.keys(methods).length;
      if (!totalMethods) {
        totalMethods = document.querySelectorAll('.payout-method-card').length;
      }
      var titleEl = summary.querySelector('[data-payout-summary-connected="true"]');
      if (titleEl) {
        titleEl.textContent = formatSummary(connectedCount, totalMethods, titleEl);
      }
      var defaultMethod = context.default_method || 'none';
      var defaultNameEl = summary.querySelector('[data-payout-default-name="true"]');
      if (defaultNameEl) {
        var cardTitle = document.querySelector('.payout-method-card[data-method="' + defaultMethod + '"] .payout-method-card__title');
        defaultNameEl.textContent = cardTitle ? cardTitle.textContent.trim() : defaultMethod;
      }
      var defaultStatusEl = summary.querySelector('[data-payout-default-status="true"]');
      if (defaultStatusEl) {
        var defaultStatus = (methods[defaultMethod] && methods[defaultMethod].status) ? methods[defaultMethod].status : 'pending';
        defaultStatus = normalizeStatus(defaultStatus);
        defaultStatusEl.textContent = statusLabel(defaultStatus);
        defaultStatusEl.className = 'status-badge ' + badgeClass(defaultStatus) + ' payout-summary-card__status';
      }
      var defaultReviewedEl = summary.querySelector('[data-payout-default-reviewed="true"]');
      if (defaultReviewedEl) {
        var defaultPayload = methods[defaultMethod] || {};
        defaultReviewedEl.textContent = formatDateTime(defaultPayload.status_updated_at || defaultPayload.updated_at);
      }
    }

    var cards = document.querySelectorAll('.payout-method-card');
    if (!cards.length) { return; }
    cards.forEach(function(card){
      var methodKey = card.getAttribute('data-method');
      if (!methodKey) { return; }
      var methodData = context.methods && context.methods[methodKey] ? context.methods[methodKey] : {};
      var connected = context.connected && Object.prototype.hasOwnProperty.call(context.connected, methodKey)
        ? !!context.connected[methodKey]
        : inferConnection(methodKey, methodData);
      var statusSource = methodData && typeof methodData.status === 'string' && methodData.status
        ? methodData.status
        : (connected ? 'pending' : 'none');
      var status = normalizeStatus(statusSource);
      card.setAttribute('data-status', status);
      card.setAttribute('data-connected', connected ? '1' : '0');

      var statusBadge = card.querySelector('[data-payout-status="true"]');
      if (statusBadge) {
        statusBadge.textContent = statusLabel(status);
        statusBadge.className = 'status-badge ' + badgeClass(status) + ' payout-method-card__status-badge';
      }

      var connectionEl = card.querySelector('[data-payout-connection="true"]');
      if (connectionEl) {
        connectionEl.textContent = connected ? connectionLabel('connected') : connectionLabel('disconnected');
        connectionEl.classList.toggle('is-connected', connected);
        connectionEl.classList.toggle('is-disconnected', !connected);
      }

      var chip = card.querySelector('[data-payout-default-chip="true"]');
      var isDefault = context.default_method === methodKey;
      if (chip) {
        if (isDefault) {
          chip.removeAttribute('hidden');
        } else {
          chip.setAttribute('hidden', 'hidden');
        }
      }

      var radio = card.querySelector('[data-payout-default-radio="true"]');
      if (radio) {
        radio.checked = isDefault;
      }

      var priorityInput = card.querySelector('[data-payout-priority="true"]');
      if (priorityInput && methodData.priority !== undefined) {
        priorityInput.value = methodData.priority;
      }

      var statusStamp = card.querySelector('[data-status-updated-stamp]');
      if (statusStamp) {
        statusStamp.textContent = formatDateTime(methodData.status_updated_at || methodData.updated_at);
      }

      var noteContainer = card.querySelector('[data-admin-note-container]');
      if (noteContainer) {
        var noteText = noteContainer.querySelector('[data-admin-note]');
        var noteValue = methodData.admin_note || '';
        if (noteValue && noteText) {
          noteText.textContent = noteValue;
          noteContainer.removeAttribute('hidden');
        } else {
          if (noteText) { noteText.textContent = ''; }
          noteContainer.setAttribute('hidden', '');
        }
      }

      var updateBanner = card.querySelector('[data-update-request]');
      if (updateBanner) {
        if (methodData.requires_update) {
          updateBanner.removeAttribute('hidden');
        } else {
          updateBanner.setAttribute('hidden', '');
        }
      }
    });
  }

  function getMethodLabel(method) {
    var select = document.getElementById('creator-payout-method');
    if (select) {
      var option = select.querySelector('option[value="' + method + '"]');
      if (option) {
        return option.textContent.trim();
      }
    }
    var cardTitle = document.querySelector('.payout-method-card[data-method="' + method + '"] .payout-method-card__title');
    if (cardTitle) {
      return cardTitle.textContent.trim();
    }
    return method;
  }

  function populateCreatorFields(form, method, data) {
    if (!form || !data) { return; }
    function setValue(name, value) {
      var field = form.querySelector('[name="' + name + '"]');
      if (!field) { return; }
      field.value = value || '';
    }
    if (method === 'bank') {
      setValue('account_name', data.account_name || '');
      setValue('bank_name', data.bank_name || '');
      setValue('iban', data.iban || '');
      setValue('account_number', data.account_number || '');
      setValue('swift', data.swift || '');
      setValue('bank_notes', data.notes || '');
    } else if (method === 'paypal') {
      setValue('paypal_email', data.email || data.paypal_email || '');
    } else if (method === 'stripe') {
      setValue('stripe_account_id', data.account_id || '');
      setValue('stripe_email', data.email || '');
    } else if (method === 'payoneer') {
      setValue('payoneer_email', data.email || data.payoneer_email || '');
    } else if (method === 'other') {
      setValue('payout_notes', data.notes || '');
    }
  }

  function applyContextToCreator(context, options) {
    var summary = document.querySelector('[data-payout-summary="creator"]');
    if (!summary) { return; }
    var form = document.getElementById('creator-payout-form');
    var selectedMethod = (options && options.method) || (form && form.getAttribute('data-selected-method')) || (context && context.default_method) || 'none';
    if (form) {
      form.setAttribute('data-selected-method', selectedMethod);
    }

    if (form && context && context.methods && typeof context.methods === 'object') {
      form.__parsedMethods = form.__parsedMethods || {};
      Object.keys(context.methods).forEach(function(key){
        if (!Object.prototype.hasOwnProperty.call(context.methods, key)) { return; }
        var methodKey = String(key);
        var payload = context.methods[key] || {};
        form.__parsedMethods[methodKey] = Object.assign({}, form.__parsedMethods[methodKey] || {}, payload);
      });
    }

    var methodsData = context && context.methods ? context.methods : {};
    var methodData = methodsData[selectedMethod] || null;
    if (!methodData && form) {
      if (!form.__parsedMethods) {
        form.__parsedMethods = parseJsonAttribute(form, 'data-methods') || {};
      }
      if (form.__parsedMethods && form.__parsedMethods[selectedMethod]) {
        methodData = form.__parsedMethods[selectedMethod];
      }
    }

    var connected = false;
    if (context && context.connected && Object.prototype.hasOwnProperty.call(context.connected, selectedMethod)) {
      connected = !!context.connected[selectedMethod];
    } else if (methodData) {
      connected = inferConnection(selectedMethod, methodData);
    }
    var status = 'none';
    if (selectedMethod !== 'none') {
      if (methodData && typeof methodData.status === 'string' && methodData.status) {
        status = normalizeStatus(methodData.status);
      } else if (connected) {
        status = 'pending';
      } else {
        status = 'none';
      }
    }

    var labelEl = summary.querySelector('[data-payout-method-label="true"]');
    if (labelEl) {
      labelEl.textContent = getMethodLabel(selectedMethod);
    }
    var statusEl = summary.querySelector('[data-payout-status="true"]');
    if (statusEl) {
      statusEl.textContent = statusLabel(status);
      statusEl.className = 'status-badge ' + badgeClass(status) + ' payout-summary-card__status';
    }
    var connectionEl = summary.querySelector('[data-payout-connection="true"]');
    if (connectionEl) {
      connectionEl.textContent = connected ? connectionLabel('connected') : connectionLabel('disconnected');
      connectionEl.classList.toggle('is-connected', connected);
      connectionEl.classList.toggle('is-disconnected', !connected);
    }
    var updatedEl = summary.querySelector('[data-status-updated-stamp]');
    if (updatedEl) {
      updatedEl.textContent = formatDateTime(methodData && (methodData.status_updated_at || methodData.updated_at));
    }

    var reviewBanner = summary.querySelector('[data-payout-review-banner]');
    if (reviewBanner) {
      var pendingStates = ['pending', 'processing', 'review'];
      if (selectedMethod !== 'none' && pendingStates.indexOf(status) !== -1) {
        var template = reviewBanner.getAttribute('data-payout-review-template');
        if (!template || typeof template !== 'string' || !template.length) {
          template = i18n('creator_payout_pending_review', 'Your {method} payout method was submitted for approval. Please wait until it is reviewed.');
        }
        var msg = template.replace('{method}', getMethodLabel(selectedMethod));
        reviewBanner.textContent = msg;
        reviewBanner.removeAttribute('hidden');
      } else {
        reviewBanner.setAttribute('hidden', 'hidden');
        reviewBanner.textContent = '';
      }
    }

    var noteContainer = summary.querySelector('[data-payout-admin-note-container]');
    if (noteContainer) {
      var noteText = summary.querySelector('[data-payout-admin-note]');
      var noteValue = methodData && methodData.admin_note ? String(methodData.admin_note) : '';
      if (noteValue) {
        if (noteText) { noteText.textContent = noteValue; }
        noteContainer.removeAttribute('hidden');
      } else {
        if (noteText) { noteText.textContent = ''; }
        noteContainer.setAttribute('hidden', '');
      }
    }

    var updateBanner = summary.querySelector('[data-payout-update-banner]');
    if (updateBanner) {
      if (methodData && methodData.requires_update) {
        updateBanner.removeAttribute('hidden');
      } else {
        updateBanner.setAttribute('hidden', '');
      }
    }

    if (form && options && options.syncFields && methodData) {
      populateCreatorFields(form, selectedMethod, methodData);
      if (form.__parsedMethods) {
        form.__parsedMethods[selectedMethod] = Object.assign({}, form.__parsedMethods[selectedMethod] || {}, methodData);
      }
    }
  }

  function applyContextToBank(context) {
    var card = document.querySelector('[data-bank-status="true"]');
    if (!card || !context || !context.methods || typeof context.methods !== 'object') {
      return;
    }
    var bankData = context.methods.bank || null;
    if (!bankData || typeof bankData !== 'object') {
      return;
    }

    var normalizedStatus = normalizeStatus(bankData.status || 'pending');
    var statusBadge = card.querySelector('[data-bank-status-label]');
    if (statusBadge) {
      statusBadge.textContent = statusLabel(normalizedStatus);
      statusBadge.className = 'status-badge ' + badgeClass(normalizedStatus);
    }

    var reviewed = card.querySelector('[data-bank-reviewed]');
    if (reviewed) {
      reviewed.textContent = formatDateTime(bankData.status_updated_at || bankData.updated_at);
    }

    var noteBox = card.querySelector('[data-bank-admin-note]');
    if (noteBox) {
      var noteText = card.querySelector('[data-bank-admin-note-text]');
      var noteValue = bankData.admin_note ? String(bankData.admin_note) : '';
      if (noteValue) {
        if (noteText) { noteText.textContent = noteValue; }
        noteBox.removeAttribute('hidden');
      } else {
        if (noteText) { noteText.textContent = ''; }
        noteBox.setAttribute('hidden', '');
      }
    }

    var updateBanner = card.querySelector('[data-bank-update]');
    if (updateBanner) {
      if (bankData.requires_update) {
        updateBanner.removeAttribute('hidden');
      } else {
        updateBanner.setAttribute('hidden', '');
      }
    }
  }

  window.addEventListener('settings:payout-context', function(ev){
    var ctx = ev.detail;
    applyContextToMethods(ctx);
    applyContextToCreator(ctx, { syncFields: true });
    applyContextToBank(ctx);
  });

  function onReady(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn, { once: true });
    } else {
      fn();
    }
  }

  function initBankForms() {
    var detailsForm = document.getElementById('bank-details-form');
    if (detailsForm) {
      detailsForm.addEventListener('submit', function(ev){
        ev.preventDefault();
        var alertBox = detailsForm.querySelector('.creator-form__alert');
        clearAlert(alertBox);
        var submitBtn = detailsForm.querySelector('button[type="submit"]');
        disableWhile(submitBtn, function(){
          var fd = new FormData(detailsForm);
          return fetch(buildUrl('request/requests.php'), {
            method: 'POST',
            credentials: 'same-origin',
            body: fd
          }).then(handleJson).then(function(res){
            if (res && res.status === 'success') {
              setAlert(alertBox, 'success', res.message || i18n('saved_ok', 'Bank information updated.'));
              if (res.payout) {
                dispatchContext(res.payout);
              }
            } else {
              var msg = (res && (res.message || res.error)) || i18n('server_error', 'Unable to save right now.');
              setAlert(alertBox, 'error', msg);
            }
          }).catch(function(){
            setAlert(alertBox, 'error', i18n('network_error', 'Network error.'));
          });
        }).catch(function(){ /* swallow */ });
      });
    }

    var withdrawForm = document.getElementById('bank-withdrawal-form');
    if (withdrawForm) {
      withdrawForm.addEventListener('submit', function(ev){
        ev.preventDefault();
        var alertBox = withdrawForm.querySelector('.creator-form__alert');
        clearAlert(alertBox);
        var submitBtn = withdrawForm.querySelector('button[type="submit"]');
        disableWhile(submitBtn, function(){
          var fd = new FormData(withdrawForm);
          return fetch(buildUrl('request/requests.php'), {
            method: 'POST',
            credentials: 'same-origin',
            body: fd
          }).then(handleJson).then(function(res){
            if (res && res.status === 'success') {
              setAlert(alertBox, 'success', res.message || i18n('withdraw_success', 'Withdrawal request submitted.'));
              window.setTimeout(function(){ window.location.reload(); }, 1500);
            } else {
              var msg = (res && (res.message || res.error)) || i18n('server_error', 'Unable to submit request.');
              setAlert(alertBox, 'error', msg);
            }
          }).catch(function(){
            setAlert(alertBox, 'error', i18n('network_error', 'Network error.'));
          });
        }).catch(function(){ /* swallow */ });
      });
    }
  }

  function initPayoutMethodsForm() {
    var form = document.getElementById('payout-methods-form');
    if (!form) { return; }

    var initialContext = parseJsonAttribute(form, 'data-context');
    if (initialContext) {
      dispatchContext(initialContext);
    }

    var lastClicked = null;
    form.addEventListener('click', function(ev){
      var button = ev.target.closest('button[name="action"]');
      if (!button) { return; }
      lastClicked = button;
      var confirmText = button.getAttribute('data-confirm');
      if (confirmText && !window.confirm(confirmText)) {
        ev.preventDefault();
        ev.stopPropagation();
        lastClicked = null;
      }
    });

    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var alertBox = form.querySelector('.creator-form__alert');
      clearAlert(alertBox);
      var submitBtn = lastClicked || form.querySelector('button.btn-primary') || form.querySelector('button[type="submit"]');
      var inlineMessage = null;
      if (lastClicked) {
        var hostCard = lastClicked.closest('.payout-method-card');
        if (hostCard) {
          inlineMessage = hostCard.querySelector('[data-payout-inline-message]');
          if (inlineMessage) {
            inlineMessage.setAttribute('hidden', 'hidden');
            clearAlert(inlineMessage);
          }
        }
      }
      disableWhile(submitBtn, function(){
        var fd = new FormData(form);
        if (lastClicked && lastClicked.name) {
          fd.set(lastClicked.name, lastClicked.value);
        }
        return fetch(buildUrl('request/requests.php'), {
          method: 'POST',
          credentials: 'same-origin',
          body: fd
        }).then(handleJson).then(function(res){
          if (res && res.status === 'success') {
            var isInline = lastClicked && typeof lastClicked.value === 'string' && /^(connect:|configure:)/.test(lastClicked.value);
            if (isInline && inlineMessage) {
              var rawMsg = (res && res.message) || i18n('settings_payout_method_configure', 'Update this payout method in the creator payout settings.');
              var linkLabel = i18n('settings_payout_creator_link', 'creator payout settings');
              var creatorUrl = buildUrl('settings?tab=creator_payout');
              var textBefore = rawMsg;
              var textAfter = '';
              if (typeof rawMsg === 'string') {
                var idx = rawMsg.indexOf(linkLabel);
                if (idx !== -1) {
                  textBefore = rawMsg.slice(0, idx);
                  textAfter = rawMsg.slice(idx + linkLabel.length);
                } else {
                  textBefore = rawMsg ? (rawMsg + ' ') : '';
                }
              } else {
                textBefore = '';
              }
              inlineMessage.removeAttribute('hidden');
              inlineMessage.classList.remove('is-error', 'is-success');
              inlineMessage.classList.add('is-success');
              inlineMessage.textContent = '';
              if (textBefore) {
                inlineMessage.append(document.createTextNode(textBefore));
              }
              var anchor = document.createElement('a');
              anchor.href = creatorUrl;
              anchor.textContent = linkLabel;
              anchor.classList.add('payout-inline-link');
              inlineMessage.appendChild(anchor);
              if (textAfter) {
                inlineMessage.append(document.createTextNode(textAfter));
              }
              clearAlert(alertBox);
            } else {
              setAlert(alertBox, 'success', res.message || i18n('saved_ok', 'Payout method preferences updated.'));
            }
            var context = res.payout || res.data;
            if (context) {
              dispatchContext(context);
            }
          } else {
            var msg = (res && (res.message || res.error)) || i18n('server_error', 'Unable to save right now.');
            var isInlineError = lastClicked && typeof lastClicked.value === 'string' && /^(connect:|configure:)/.test(lastClicked.value);
            if (isInlineError && inlineMessage) {
              inlineMessage.removeAttribute('hidden');
              setAlert(inlineMessage, 'error', msg);
              clearAlert(alertBox);
            } else {
              setAlert(alertBox, 'error', msg);
            }
          }
        }).catch(function(){
          var msg = i18n('network_error', 'Network error.');
          var isInlineError = lastClicked && typeof lastClicked.value === 'string' && /^(connect:|configure:)/.test(lastClicked.value);
          if (isInlineError && inlineMessage) {
            inlineMessage.removeAttribute('hidden');
            setAlert(inlineMessage, 'error', msg);
            clearAlert(alertBox);
          } else {
            setAlert(alertBox, 'error', msg);
          }
        }).finally(function(){
          lastClicked = null;
        });
      }).catch(function(){ lastClicked = null; });
    });
  }

  function initCreatorPayoutForm() {
    var form = document.getElementById('creator-payout-form');
    if (!form) { return; }

    if (!form.__parsedMethods) {
      form.__parsedMethods = parseJsonAttribute(form, 'data-methods') || {};
    }

    var select = form.querySelector('#creator-payout-method');
    var groups = form.querySelectorAll('.payout-method-fields');

    function showGroup(method) {
      groups.forEach(function(group){
        var groupMethod = group.getAttribute('data-method');
        if (!groupMethod) { return; }
        var match = groupMethod === method;
        group.hidden = !match;
        if (match) {
          group.removeAttribute('hidden');
        } else {
          group.setAttribute('hidden', 'hidden');
        }
      });
      form.setAttribute('data-selected-method', method);
    }

    if (select) {
      showGroup(select.value);
      select.addEventListener('change', function(){
        var method = select.value;
        showGroup(method);
        var context = payoutContext;
        if (!context) {
          context = normalizeContext({
            default_method: method,
            methods: form.__parsedMethods || {},
            connected: {}
          });
        }
        applyContextToCreator(context, { method: method });
      });
    }

    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var alertBox = form.querySelector('.creator-form__alert');
      clearAlert(alertBox);
      var submitBtn = form.querySelector('button[type="submit"]');
      disableWhile(submitBtn, function(){
        var fd = new FormData(form);
        return fetch(buildUrl('request/requests.php'), {
          method: 'POST',
          credentials: 'same-origin',
          body: fd
        }).then(handleJson).then(function(res){
          if (res && res.status === 'success') {
            setAlert(alertBox, 'success', res.message || i18n('saved_ok', 'Payout preferences updated.'));
            if (res.data && res.data.method && form.__parsedMethods) {
              form.__parsedMethods[res.data.method] = Object.assign({}, form.__parsedMethods[res.data.method] || {}, res.data.details || {});
            }
            var context = res.payout || null;
            if (!context && res.data) {
              context = {
                default_method: res.data.method || select && select.value || 'none',
                methods: Object.assign({}, form.__parsedMethods),
                connected: {}
              };
            }
            if (context) {
              dispatchContext(context);
            } else {
              applyContextToCreator(payoutContext, { method: select ? select.value : 'none', syncFields: true });
            }
          } else {
            var msg = (res && (res.message || res.error)) || i18n('server_error', 'Unable to save right now.');
            setAlert(alertBox, 'error', msg);
          }
        }).catch(function(){
          setAlert(alertBox, 'error', i18n('network_error', 'Network error.'));
        });
      }).catch(function(){ /* swallow */ });
    });

    applyContextToCreator(payoutContext || normalizeContext({
      default_method: form.getAttribute('data-selected-method') || 'none',
      methods: form.__parsedMethods || {},
      connected: {}
    }), { method: form.getAttribute('data-selected-method') || 'none' });
  }

  onReady(function(){
    initBankForms();
    initPayoutMethodsForm();
    initCreatorPayoutForm();
  });
})();
