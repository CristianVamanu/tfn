'use strict';
(function(){
  if (window.__liveChatBound) return; window.__liveChatBound = true;

  var bodyEl = document.body || null;
  var chatGloballyEnabled = true;
  try {
    if (bodyEl) {
      chatGloballyEnabled = bodyEl.getAttribute('data-live-chat-enabled') !== '0';
    }
  } catch(_){ }
  if (!chatGloballyEnabled) {
    return;
  }

  function qs(sel, root){ return (root||document).querySelector(sel); }
  function qsa(sel, root){ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }
  function getCsrf(){ try { return document.querySelector("input[name='csrf_token']").value || ''; } catch(e){ return ''; } }
  var I18N = (window.DZ && typeof DZ.i18n === 'function') ? DZ.i18n : function(){ return ''; };
  function buildEndpoint(path){
    try {
      if (typeof window.buildUrl === 'function') {
        return window.buildUrl(path);
      }
    } catch(_){}
    try {
      var base = '';
      if (typeof site_url === 'string' && site_url) {
        base = site_url;
      } else if (typeof window.site_url === 'string' && window.site_url) {
        base = window.site_url;
      } else if (window.DZ && typeof window.DZ.__computeBase === 'function') {
        base = window.DZ.__computeBase('');
      } else {
        var origin = window.location.origin || ((window.location.protocol || 'http:') + '//' + (window.location.host || ''));
        var root = (window.location.pathname || '/').replace(/[^\/]*$/, '');
        base = origin + (root || '/');
      }
      return new URL(String(path || ''), base).toString();
    } catch(_) { return String(path || ''); }
  }

  function bind(){
    // Mark as live page to drive CSS-only layout changes (Envato: no inline JS)
    try { document.body.classList.add('is-live-page'); } catch(_){ }
    var root = qs('.contents_box[data-live-id]');
    if (!root) return;
    var liveId = parseInt(root.getAttribute('data-live-id')||'0',10)||0;
    if (!liveId) return;

    var body = qs('#liveChatBody');
    var form = qs('#liveChatForm');
    var input= qs('#liveChatInput');
    if (!body || !form || !input) return;

    var lastId = 0;
    var seen = new Set(); // render dedupe by message id
    var pollMs = 1500;
    var timer = null;
    var sending = false;
    var cooldownUntil = 0;

    function atBottom(){
      try { return (body.scrollHeight - (body.scrollTop + body.clientHeight)) < 48; } catch(_){ return true; }
    }
    function scrollToBottom(){ try { body.scrollTop = body.scrollHeight; } catch(_){} }

    function renderMsg(m){
      // m: { id, user_id, username, user_fullname, avatar, message, created_at }
      var row = document.createElement('div'); row.className = 'live-chat-msg';
      var img = document.createElement('img'); img.className = 'live-chat-avatar'; img.alt='';
      img.src = (typeof site_url==='string'? site_url : '/') + (m.avatar || 'uploads/user_avatars/default.jpeg');
      var box = document.createElement('div'); box.className = 'live-chat-text';
      var head = document.createElement('div');
      var from = document.createElement('span'); from.className = 'from';
      try {
        var fbUser = (window.DZ && DZ.i18n) ? (DZ.i18n('chat_user_fallback') || 'User') : 'User';
        from.textContent = (m.user_fullname || m.username || fbUser);
      } catch(_){ from.textContent = (m.user_fullname || m.username || 'User'); }
      var msg = document.createElement('div'); msg.className = 'msg';
      msg.textContent = String(m.message || '');
      head.appendChild(from);
      box.appendChild(head);
      box.appendChild(msg);
      row.appendChild(img);
      row.appendChild(box);
      return row;
    }

    function appendIfNew(m){
      var mid = parseInt(m && m.id ? m.id : 0, 10) || 0;
      if (!mid) return false;
      if (seen.has(mid)) return false;
      seen.add(mid);
      var wasAtBottom = atBottom();
      var node = renderMsg(m);
      body.appendChild(node);
      if (mid > lastId) lastId = mid;
      if (wasAtBottom) scrollToBottom();
      return true;
    }

    function updateCooldownUi(){
      var now = Date.now();
      var left = Math.ceil((cooldownUntil - now)/1000);
      var btn = form.querySelector('button[type="submit"]');
      if (cooldownUntil > now) {
        input.disabled = true; if (btn) { btn.disabled = true; btn.textContent = (I18N('chat_wait_seconds', { seconds: left }) || ('Wait ' + left + 's')); }
      } else {
        input.disabled = false; if (btn) { btn.disabled = false; btn.textContent = (I18N('chat_send') || 'Send'); }
      }
    }

    function sendMessage(ev){
      ev.preventDefault();
      if (sending) return;
      var now = Date.now();
      if (cooldownUntil > now) { updateCooldownUi(); return; }
      var text = (input.value || '').trim();
      if (!text) return;
      sending = true;
      var fd = new FormData();
      fd.append('p','live_chat_send');
      fd.append('live_id', String(liveId));
      fd.append('message', text);
      fd.append('csrf_token', getCsrf());
      fetch(buildEndpoint('request/requests.php'), { method:'POST', body: fd, credentials:'same-origin' })
        .then(function(r){ return r.text().then(function(t){ try { return JSON.parse(t); } catch(_){ return {status:'error', message:t||('HTTP '+r.status)}; } }); })
        .then(function(j){
          if (j && j.status === 'success' && j.message){
            input.value = '';
            cooldownUntil = Date.now() + 3000;
            updateCooldownUi();
            // Append only if not already pulled by poller
            appendIfNew(j.message);
          } else if (j && j.message === 'COOLDOWN'){
            var retryMs = (typeof j.retry_after === 'number' ? j.retry_after*1000 : 3000);
            cooldownUntil = Date.now() + retryMs;
            updateCooldownUi();
          } else if (j && j.message === 'ENDED'){
            input.disabled = true; var btn=form.querySelector('button[type="submit"]'); if (btn) { btn.disabled = true; btn.textContent=(I18N('chat_ended') || 'Ended'); }
          } else {
            // Login/CSRF or other server errors
            console.warn('live_chat_send failed', j);
          }
        })
        .catch(function(err){ console.error('live_chat_send error', err); })
        .finally(function(){ sending = false; });
    }

    function poll(){
      if (document.hidden) return; // pause when hidden
      var url = buildEndpoint('request/requests.php?p=live_chat_fetch');
      var fd = new FormData();
      fd.append('live_id', String(liveId));
      fd.append('since_id', String(lastId));
      fd.append('limit', '50');
      fetch(url, { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function(r){ return r.text().then(function(t){ try { return JSON.parse(t); } catch(_){ return {status:'error'}; } }); })
        .then(function(j){
          if (!j || j.status !== 'success' || !Array.isArray(j.messages)) return;
          if (!j.messages.length) return;
          j.messages.forEach(function(m){ appendIfNew(m); });
        })
        .catch(function(err){ console.error('live_chat_fetch error', err); });
    }

    form.addEventListener('submit', sendMessage);
    // Subtle UX: while interacting with live chat, dim/disable floating DM widget
    var host = qs('.live-chat');
    function addFocus(){ try { document.body.classList.add('live-chat-focus'); } catch(_){} }
    function removeFocus(){ try { document.body.classList.remove('live-chat-focus'); } catch(_){} }
    input.addEventListener('focus', addFocus);
    input.addEventListener('blur', removeFocus);
    if (host) {
      host.addEventListener('mouseenter', addFocus);
      host.addEventListener('mouseleave', removeFocus);
    }
    // Initial load: grab recent backlog
    (function initial(){ poll(); setTimeout(scrollToBottom, 50); })();
    timer = setInterval(poll, pollMs);

    document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(poll, 200); });
    // Keep cooldown UI ticking
    setInterval(updateCooldownUi, 250);
  }

  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', bind); }
  else { bind(); }
})();
