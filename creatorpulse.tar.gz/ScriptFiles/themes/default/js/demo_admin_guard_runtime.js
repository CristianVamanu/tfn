(function () {
  'use strict';

  if (window.__DemoAdminGuardRuntimeInstalled) {
    return;
  }
  window.__DemoAdminGuardRuntimeInstalled = true;

  var headerFlag = 'x-demo-admin-guard';
  var headerMessage = 'x-demo-admin-message';
  var fallbackMessage = 'This action is disabled for demo accounts.';

  function decodeHeaderValue(value) {
    if (!value) { return ''; }
    try {
      return decodeURIComponent(value);
    } catch (_) {
      return value;
    }
  }

  function getI18n(key, fallback) {
    try {
      if (window.DZ && typeof window.DZ.i18n === 'function') {
        var value = window.DZ.i18n(key);
        if (typeof value === 'string' && value.trim() !== '') {
          return value;
        }
      }
    } catch (_) {}
    return fallback;
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function escapeAttr(value) {
    return escapeHtml(value);
  }

  function getPopupHost() {
    if (typeof document === 'undefined') {
      return null;
    }
    var root = document.getElementById('popup-root');
    if (!root || !root.appendChild) {
      root = document.body || document.documentElement || null;
    }
    return root && root.appendChild ? root : null;
  }

  function fallbackNotify(msg) {
    if (!msg) { return; }
    var message = String(msg || '').trim() || fallbackMessage;
    try {
      if (window.DZ && typeof window.DZ.toast === 'function') {
        window.DZ.toast(message, { type: 'error', duration: 2600 });
        return;
      }
      if (window.toast && typeof window.toast.error === 'function') {
        window.toast.error(message);
        return;
      }
      if (typeof document !== 'undefined' && document.createElement) {
        var toast = document.createElement('div');
        toast.textContent = message;
        toast.setAttribute('role', 'alert');
        toast.style.position = 'fixed';
        toast.style.left = '50%';
        toast.style.bottom = '24px';
        toast.style.transform = 'translateX(-50%)';
        toast.style.maxWidth = '90%';
        toast.style.zIndex = '99999';
        toast.style.background = 'rgba(0,0,0,0.85)';
        toast.style.color = '#fff';
        toast.style.padding = '10px 16px';
        toast.style.borderRadius = '10px';
        toast.style.fontSize = '14px';
        toast.style.lineHeight = '1.45';
        toast.style.boxShadow = '0 6px 18px rgba(0,0,0,0.25)';
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 160ms ease';
        (document.body || document.documentElement).appendChild(toast);
        requestAnimationFrame(function () { toast.style.opacity = '1'; });
        setTimeout(function () {
          toast.style.opacity = '0';
          setTimeout(function () {
            if (toast && toast.parentNode) { toast.parentNode.removeChild(toast); }
          }, 220);
        }, 2600);
        return;
      }
    } catch (_) {}
    try { console.warn('[DemoAdminGuard]', message); } catch (_) {}
  }

  function showPopup(msg) {
    var message = String(msg || '').trim();
    if (message === '') {
      message = fallbackMessage;
    }
    if (typeof document === 'undefined' || !document.createElement) {
      return false;
    }

    var host = getPopupHost();
    if (!host) {
      return false;
    }

    var existing = host.querySelector('.popUp-container[data-demo-admin-modal="1"]');
    if (existing) {
      var textNode = existing.querySelector('[data-demo-admin-guard-text]');
      if (textNode) {
        textNode.textContent = message;
      }
      var focusBtn = existing.querySelector('.demo-admin-guard-confirm');
      if (focusBtn) {
        try { focusBtn.focus(); } catch (_) {}
      }
      return true;
    }

    try {
      var overlay = document.createElement('div');
      overlay.className = 'popUp-container flex align_items demo-admin-guard-modal';
      overlay.setAttribute('data-demo-admin-modal', '1');

      var wrapper = document.createElement('div');
      wrapper.className = 'tips popup-wrapper demo-admin-guard-popup';
      wrapper.setAttribute('role', 'dialog');
      wrapper.setAttribute('aria-modal', 'true');

      var titleId = 'demoAdminGuardTitle';
      var messageId = 'demoAdminGuardMessage';
      wrapper.setAttribute('aria-labelledby', titleId);
      wrapper.setAttribute('aria-describedby', messageId);

      var closeLabel = getI18n('menu_close', getI18n('ui_close', 'Close'));
      var title = buildTitle(message);
      var confirmLabel = getI18n('ui_ok', 'Tamam');

      var closeBtn = document.createElement('button');
      closeBtn.type = 'button';
      closeBtn.className = 'tips-close close_pop';
      closeBtn.setAttribute('aria-label', escapeAttr(closeLabel));
      closeBtn.innerHTML = '<span aria-hidden="true">&times;</span>';

      var header = document.createElement('header');
      header.className = 'tips-header';

      var heading = document.createElement('h2');
      heading.className = 'tips-title';
      heading.id = titleId;
      heading.textContent = title;
      header.appendChild(heading);

      var body = document.createElement('div');
      body.className = 'tips-summary demo-admin-guard-body';

      var paragraph = document.createElement('p');
      paragraph.className = 'tips-note demo-admin-guard-message';
      paragraph.id = messageId;
      paragraph.setAttribute('data-demo-admin-guard-text', '');
      paragraph.textContent = message;
      body.appendChild(paragraph);

      var actions = document.createElement('div');
      actions.className = 'tips-actions';

      var confirmBtn = document.createElement('button');
      confirmBtn.type = 'button';
      confirmBtn.className = 'tips-cta demo-admin-guard-confirm';
      confirmBtn.textContent = confirmLabel;
      actions.appendChild(confirmBtn);

      wrapper.appendChild(closeBtn);
      wrapper.appendChild(header);
      wrapper.appendChild(body);
      wrapper.appendChild(actions);
      overlay.appendChild(wrapper);

      var removePopup = function () {
        try { document.removeEventListener('keydown', handleKeydown, true); } catch (_) {}
        if (overlay && overlay.parentNode) {
          overlay.parentNode.removeChild(overlay);
        }
      };

      var handleKeydown = function (event) {
        if (event && event.key === 'Escape') {
          event.preventDefault();
          removePopup();
        }
      };

      closeBtn.addEventListener('click', removePopup);
      confirmBtn.addEventListener('click', removePopup);
      overlay.addEventListener('click', function (event) {
        if (event.target === overlay) {
          removePopup();
        }
      });
      document.addEventListener('keydown', handleKeydown, true);

      host.appendChild(overlay);

      setTimeout(function () {
        try { confirmBtn.focus(); } catch (_) {}
      }, 0);

      return true;
    } catch (err) {
      return false;
    }
  }

  function presentMessage(msg) {
    if (!showPopup(msg)) {
      fallbackNotify(msg);
    }
  }

  function handleHeaders(getter) {
    if (typeof getter !== 'function') { return; }
    try {
      var flag = getter(headerFlag);
      if (!flag) { return; }
      var raw = getter(headerMessage) || '';
      var msg = decodeHeaderValue(raw) || fallbackMessage;
      presentMessage(msg);
    } catch (_) {}
  }

  if (typeof window.fetch === 'function') {
    var originalFetch = window.fetch;
    window.fetch = function () {
      return originalFetch.apply(this, arguments).then(function (response) {
        try {
          if (response && response.headers && typeof response.headers.get === 'function') {
            handleHeaders(function (name) {
              return response.headers.get(String(name));
            });
          }
        } catch (_) {}
        return response;
      });
    };
  }

  if (window.XMLHttpRequest && window.XMLHttpRequest.prototype) {
    var proto = window.XMLHttpRequest.prototype;
    var originalSend = proto.send;
    proto.send = function () {
      if (!this.__demoAdminGuardHooked) {
        this.addEventListener('load', function () {
          handleHeaders(function (name) {
            return this.getResponseHeader ? this.getResponseHeader(String(name)) : null;
          }.bind(this));
        }, true);
        this.__demoAdminGuardHooked = true;
      }
      return originalSend.apply(this, arguments);
    };
  }

  function flushInlineMessages() {
    try {
      var nodes = document.querySelectorAll('[data-demo-admin-guard-message]');
      if (!nodes || !nodes.length) { return; }
      nodes.forEach(function (node) {
        var attr = node.getAttribute('data-demo-admin-guard-message');
        var msg = attr || node.getAttribute('data-message') || node.textContent || '';
        msg = String(msg || '').trim();
        presentMessage(msg || fallbackMessage);
        node.parentNode && node.parentNode.removeChild(node);
      });
    } catch (_) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', flushInlineMessages, { once: true });
  } else {
    flushInlineMessages();
  }
})();
