'use strict';
(function(window, $){
  if (!$ || !window) return;
  var buildUrl = (window.DZ && window.DZ.buildUrl) || function(path){
    try { var base=(typeof window.site_url==='string'&&window.site_url)?window.site_url:(window.location.origin+window.location.pathname.replace(/[^\/]*$/,'')); if(base.slice(-1)!=='/') base+='/'; return new URL(String(path||'').replace(/^\//,''), base).toString(); } catch(_) { return String(path||''); }
  };

  var Premium = {
    busy: false,
    hasMore: false,
    offset: 0,
    limit: 20,
    $root: null,
    $sentinel: null,
    io: null,

    init: function(){
      this.$root = $('#premium-root');
      if (!this.$root.length) return;
      this.$sentinel = $('#premium-sentinel');
      this.offset = parseInt(this.$root.attr('data-offset')||'0',10)||0;
      this.limit  = parseInt(this.$root.attr('data-limit')||'20',10)||20;
      this.hasMore= (this.$root.attr('data-has-more') === '1');
      var self=this;
      if ('IntersectionObserver' in window && this.$sentinel.length) {
        this.io = new IntersectionObserver(function(entries){
          var e = entries && entries[0];
          if (!e) return; if (e.isIntersecting || e.intersectionRatio>0) self.loadMore();
        }, { root:null, rootMargin:'1200px 0px 1200px 0px', threshold:[0,0.01] });
        this.io.observe(this.$sentinel.get(0));
      }
      // Fallback minimal scroll check
      var ticking=false, self=this;
      function onScroll(){ if (ticking) return; ticking=true; setTimeout(function(){ ticking=false; self._fallbackTick(); }, 180); }
      window.addEventListener('scroll', onScroll, { passive:true });
      window.addEventListener('resize', onScroll, { passive:true });
    },

    _fallbackTick: function(){
      if (!this.hasMore || this.busy) return;
      var doc = document.documentElement; var st = (window.pageYOffset||doc.scrollTop)-(doc.clientTop||0);
      var vh = window.innerHeight||doc.clientHeight; var full = Math.max(doc.scrollHeight, doc.offsetHeight, doc.clientHeight);
      if (full - (st+vh) < 1400) this.loadMore();
    },

    loadMore: function(){
      if (this.busy || !this.hasMore) return; this.busy=true;
      var self=this; var csr = $('input[name="csrf_token"]').val()||'';
      $.ajax({
        url: buildUrl('request/requests.php'),
        type: 'POST', dataType:'json',
        data: { p:'premium_more', offset:this.offset, limit:this.limit, csrf_token: csr }
      }).done(function(res){
        if (!res || res.status!=='ok') return;
        if (res.html) {
          var $chunk=$(res.html);
          self.$sentinel.before($chunk);
          $(document).trigger('posts:loaded',{root:self.$root.get(0)});
        }
        self.offset = parseInt(res.next_offset || self.offset,10);
        self.hasMore = !!res.has_more;
        // Nudge any IO logic for videos in new posts
      }).always(function(){ self.busy=false; });
    }
  };

  $(function(){ Premium.init(); });
  window.PremiumFeed = Premium;
})(window, window.jQuery);
