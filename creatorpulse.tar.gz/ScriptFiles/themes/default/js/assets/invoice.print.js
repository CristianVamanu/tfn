(function () {
  'use strict';

  /**
   * Binds the invoice print button to the browser print dialog.
   *
   * @param {string} buttonSelector The CSS selector for the print trigger.
   * @returns {void}
   */
  function bindInvoicePrint(buttonSelector) {
    if (typeof window === 'undefined') {
      return;
    }

    var button = document.querySelector(buttonSelector);
    if (!button) {
      return;
    }

    button.addEventListener('click', function handlePrintClick(event) {
      event.preventDefault();
      window.print();
    });
  }

  document.addEventListener('DOMContentLoaded', function handlePrintReady() {
    bindInvoicePrint('.js-invoice-print');
  });
})();
