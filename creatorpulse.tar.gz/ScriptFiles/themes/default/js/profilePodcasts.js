(function ($) {
  'use strict';

  var currentAudio = null;

  function formatTime(sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    var m = Math.floor(sec / 60);
    var s = sec % 60;
    return m + ':' + (s < 10 ? '0' + s : s);
  }

  function stopCurrent(except) {
    if (currentAudio && currentAudio !== except) {
      try { currentAudio.pause(); } catch (_) {}
    }
  }

  function bindPodcastNode($ctx) {
    if (!$ctx || !$ctx.length) { return; }
    var audio = $ctx.find('audio').get(0);
    if (!audio) { return; }
    var $play = $ctx.find('.podcast-row-play, .pp-hero-play');
    var $time = $ctx.find('.podcast-row-time');
    var $label = $play.find('.pp-hero-label');
    var playLabel = ($play.attr('data-play-label') || ($label.text() || '')).trim();
    var pauseLabel = ($play.attr('data-pause-label') || '').trim();

    if ($play.length) {
      $play.on('click', function () {
        if (audio.paused) {
          stopCurrent(audio);
          audio.play().catch(function(){});
        } else {
          audio.pause();
        }
      });
    }

    audio.addEventListener('play', function () {
      stopCurrent(audio);
      currentAudio = audio;
      $('.podcast-row, .profile-podcast-hero').removeClass('is-playing');
      $ctx.addClass('is-playing');
      if (pauseLabel !== '') {
        if ($label.length) { $label.text(pauseLabel); } else { $play.text(pauseLabel); }
      }
    });

    audio.addEventListener('pause', function () {
      $ctx.removeClass('is-playing');
      if (currentAudio === audio) { currentAudio = null; }
      if (playLabel !== '') {
        if ($label.length) { $label.text(playLabel); } else { $play.text(playLabel); }
      }
    });

    audio.addEventListener('timeupdate', function () {
      if ($time && $time.length) {
        var cur = audio.currentTime || 0;
        var dur = audio.duration || 0;
        var label = formatTime(cur);
        if (dur && isFinite(dur)) {
          label += ' / ' + formatTime(dur);
        }
        $time.text(label);
      }
    });
  }

  $(function () {
    $('.profile-podcast-hero').each(function () { bindPodcastNode($(this)); });
    $('.podcast-row').each(function () { bindPodcastNode($(this)); });
  });

})(jQuery);
