'use strict';
(function () {
  var body = document.body || document.documentElement;
  if (!body) { return; }
  var layout = (body.getAttribute('data-layout') || '').toLowerCase();
  var hasPopupTrigger = !!document.querySelector('[data-pop="podcastHeroAd"]');
  var hasDetailsButtons = !!document.querySelector('.podcast-ads-details');
  if (layout !== 'podcasts' && !hasPopupTrigger && !hasDetailsButtons) { return; }

  function buildRequestUrl(path) {
    try {
      if (typeof buildUrl === 'function') {
        return buildUrl(path);
      }
    } catch (_) {}
    return path;
  }

  function showToast(message, tone) {
    var msg = String(message || '');
    var type = tone || 'info';
    try {
      if (window.DZ && typeof window.DZ.toast === 'function') {
        window.DZ.toast(msg, { type: type, duration: 2600 });
        return;
      }
    } catch (_) {}
    if (msg) { alert(msg); }
  }

  function setAlert(message, tone) {
    var alertBox = document.getElementById('podcastAdAlert');
    if (!alertBox) { return; }
    alertBox.textContent = message || '';
    alertBox.classList.remove('none');
    alertBox.classList.toggle('is-error', tone === 'error');
    alertBox.classList.toggle('is-success', tone === 'success');
  }

  function clearAlert() {
    var alertBox = document.getElementById('podcastAdAlert');
    if (!alertBox) { return; }
    alertBox.textContent = '';
    alertBox.classList.add('none');
    alertBox.classList.remove('is-error');
    alertBox.classList.remove('is-success');
  }

  function updateStatusBadge(status, note) {
    var statusBox = document.querySelector('.podcast-ad-status');
    if (!statusBox) {
      var form = document.getElementById('podcastAdForm');
      if (!form) { return; }
      statusBox = document.createElement('div');
      statusBox.className = 'podcast-ad-status flex align_items gap';
      var parent = form.parentNode;
      if (parent && parent.insertBefore) {
        parent.insertBefore(statusBox, form);
      }
    }
    statusBox.setAttribute('data-status', status);
    statusBox.innerHTML = '';
    var badge = document.createElement('span');
    badge.className = 'badge badge--' + status;
    badge.textContent = (status || '').charAt(0).toUpperCase() + (status || '').slice(1);
    statusBox.appendChild(badge);
    if (note) {
      var noteEl = document.createElement('span');
      noteEl.className = 'status-note';
      noteEl.textContent = note;
      statusBox.appendChild(noteEl);
    }
  }

  function renderSelectedPodcast(pod) {
    var host = document.getElementById('podcastAdSelected');
    if (!host) { return; }
    host.classList.remove('none');
    host.innerHTML = '';
    var cover = document.createElement('div');
    cover.className = 'podcast-ad-selected__cover';
    if (pod.cover) {
      var img = document.createElement('img');
      img.src = pod.cover;
      img.alt = pod.title || '';
      img.loading = 'lazy';
      cover.appendChild(img);
    } else {
      cover.textContent = '🎧';
    }
    var titleWrap = document.createElement('div');
    titleWrap.className = 'podcast-ad-selected__title';
    titleWrap.textContent = pod.title || '--';
    var clearBtn = document.createElement('button');
    clearBtn.type = 'button';
    clearBtn.className = 'podcast-ad-selected__clear';
    clearBtn.textContent = '×';
    clearBtn.addEventListener('click', function () {
      host.classList.add('none');
      host.innerHTML = '';
      var hidden = document.getElementById('podcastAdPostId');
      if (hidden) { hidden.value = ''; }
    });
    host.appendChild(cover);
    host.appendChild(titleWrap);
    host.appendChild(clearBtn);
  }

  function fetchPodcastsList(csrf, onDone) {
    var fd = new FormData();
    fd.append('p', 'podcast_ad_list_podcasts');
    fd.append('csrf_token', csrf || '');
    fetch(buildRequestUrl('request/requests.php'), { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (res) {
        return res.json().catch(function(){ return {}; });
      })
      .then(function (data) {
        if (!data || data.status !== 'success' || !Array.isArray(data.podcasts)) {
          throw new Error((data && data.message) || 'Error');
        }
        onDone(data.podcasts);
      })
      .catch(function () {
        showToast(I18N('ui_network_error') || 'Network error', 'error');
      });
  }

  var packageListEl = null;
  var packageSummaryEl = null;
  var packageContainer = null;
  var packageToggle = null;
  var breakdownEl = null;
  var breakdownPlan = null;
  var breakdownPrice = null;
  var breakdownBalance = null;
  var breakdownAfter = null;
  var walletBalanceEl = null;
  var walletBalance = 0;
  var walletCurrency = '';
  var walletCurrencySymbol = '';
  var walletPrecision = null;
  var currencyPosition = (window.DZ && DZ.currencyFormat && DZ.currencyFormat.position) || '';
  var datasetFormat = null;
  var packagesData = {};
  var selectedPackageId = null;
  var detailsModal = null;
  var detailsCloseButtons = [];
  var detailsMap = {};

  function refreshPackageElements() {
    packageListEl = document.getElementById('podcastAdPackageList');
    packageSummaryEl = document.getElementById('podcastAdPaymentSummary');
    packageContainer = document.getElementById('podcastAdPackages');
    packageToggle = document.getElementById('podcastAdPlanToggle');
    breakdownEl = document.getElementById('podcastAdBreakdown');
    breakdownPlan = document.getElementById('podcastAdBreakdownPlan');
    breakdownPrice = document.getElementById('podcastAdBreakdownPrice');
    breakdownBalance = document.getElementById('podcastAdBreakdownBalance');
    breakdownAfter = document.getElementById('podcastAdBreakdownAfter');
    walletBalanceEl = document.getElementById('podcastAdWalletBalance');
    if (walletBalanceEl) {
      var b = parseFloat(walletBalanceEl.getAttribute('data-balance') || '0');
      if (!isNaN(b)) { walletBalance = b; }
      walletCurrency = (walletBalanceEl.getAttribute('data-currency') || '').toUpperCase();
      walletCurrencySymbol = walletBalanceEl.getAttribute('data-currency-symbol') || '';
      var prec = parseInt(walletBalanceEl.getAttribute('data-amount-precision'), 10);
      if (isFinite(prec) && prec >= 0) { walletPrecision = prec; }
      currencyPosition = walletBalanceEl.getAttribute('data-currency-position') || currencyPosition;
      var cfgRaw = walletBalanceEl.getAttribute('data-currency-config') || '';
      if (!datasetFormat && cfgRaw) {
        try { datasetFormat = JSON.parse(cfgRaw); } catch (_) { datasetFormat = null; }
      }
      if (!datasetFormat) {
        datasetFormat = {
          code: walletCurrency,
          symbol: walletCurrencySymbol,
          position: currencyPosition,
          precision: walletPrecision,
          decimalPlaces: walletPrecision,
          decimalSep: walletBalanceEl.getAttribute('data-decimal-sep') || undefined,
          thousandsSep: walletBalanceEl.getAttribute('data-thousands-sep') || undefined,
        };
      }
      walletBalanceEl.textContent = formatMoney(walletBalance, walletCurrency, walletCurrencySymbol, walletPrecision);
    }
    if (packageContainer && !currencyPosition) {
      currencyPosition = packageContainer.getAttribute('data-currency-position') || currencyPosition;
      if (!datasetFormat) {
        var cfgRawPkg = packageContainer.getAttribute('data-currency-config') || '';
        if (cfgRawPkg) {
          try { datasetFormat = JSON.parse(cfgRawPkg); } catch (_) { datasetFormat = null; }
        }
      }
    }
  }

  function setPaymentFields(pkgId, paymentId, token) {
    var pkgInput = document.getElementById('podcastAdPackageId');
    var payInput = document.getElementById('podcastAdPaymentId');
    var tokenInput = document.getElementById('podcastAdPaymentToken');
    if (pkgInput) { pkgInput.value = pkgId || ''; }
    if (payInput) { payInput.value = paymentId || ''; }
    if (tokenInput) { tokenInput.value = token || ''; }
  }

  function clearPaymentState() {
    setPaymentFields('', '', '');
    if (packageSummaryEl) {
      packageSummaryEl.classList.add('none');
      packageSummaryEl.textContent = '';
    }
    if (breakdownEl) {
      breakdownEl.classList.add('none');
    }
  }

  function selectPackage(cardEl) {
    if (!cardEl || !packageListEl) { return; }
    var pkgId = parseInt(String(cardEl.getAttribute('data-podcast-package-id') || '0'), 10);
    if (!(pkgId > 0)) { return; }
    selectedPackageId = pkgId;
    clearPaymentState();
    setPaymentFields(pkgId, '', '');
    var cards = packageListEl.querySelectorAll('[data-podcast-package-id]');
    cards.forEach(function (node) {
      node.classList.toggle('is-active', node === cardEl);
      node.setAttribute('aria-pressed', node === cardEl ? 'true' : 'false');
    });
    updateBreakdown();
  }

  function resolveCurrency(cfg) {
    var baseCfg = datasetFormat || (window.DZ && DZ.currencyFormat) || {};
    var code = (cfg && cfg.code) || baseCfg.code || walletCurrency || 'USD';
    var symbol = (cfg && cfg.symbol) || baseCfg.symbol || walletCurrencySymbol || '';
    var position = (cfg && cfg.position) || baseCfg.position || currencyPosition || 'left';
    var precision = parseInt(cfg && cfg.precision, 10);
    if (!isFinite(precision) || precision < 0) {
      var base = (walletPrecision !== null ? walletPrecision : (typeof baseCfg.decimalPlaces === 'number' ? baseCfg.decimalPlaces : 2));
      precision = isFinite(base) && base >= 0 ? base : 2;
    }
    var decimalSep = (cfg && cfg.decimalSep) || baseCfg.decimalSep || '.';
    var thousandsSep = (cfg && cfg.thousandsSep) || baseCfg.thousandsSep || ',';
    if (thousandsSep === decimalSep) { thousandsSep = ''; }
    return { code: code, symbol: symbol, precision: precision, position: position, decimalSep: decimalSep, thousandsSep: thousandsSep };
  }
  function applyPosition(value, cfg) {
    var symbol = cfg.symbol || '';
    var code = cfg.code || '';
    var pos = cfg.position || 'left';
    if (!symbol || symbol === code || symbol.length > 4) {
      return value + ' ' + code;
    }
    switch (pos) {
      case 'left': return symbol + value;
      case 'left_space': return symbol + ' ' + value;
      case 'right': return value + symbol;
      case 'right_space': return value + ' ' + symbol;
      default: return symbol + value;
    }
  }
  function formatMoney(amount, currency, symbol, precision) {
    var cfgInput = {
      code: currency,
      symbol: symbol,
      precision: precision,
      position: currencyPosition,
    };
    if (datasetFormat) {
      cfgInput.code = cfgInput.code || datasetFormat.code;
      cfgInput.symbol = cfgInput.symbol || datasetFormat.symbol;
      cfgInput.position = cfgInput.position || datasetFormat.position;
      if (typeof cfgInput.precision !== 'number' && typeof datasetFormat.precision === 'number') {
        cfgInput.precision = datasetFormat.precision;
      }
      if (!cfgInput.decimalSep && datasetFormat.decimalSep) { cfgInput.decimalSep = datasetFormat.decimalSep; }
      if (!cfgInput.thousandsSep && datasetFormat.thousandsSep) { cfgInput.thousandsSep = datasetFormat.thousandsSep; }
    }
    var cfg = resolveCurrency(cfgInput);
    var v = Number(amount);
    if (!isFinite(v)) { v = 0; }
    var parts = Math.abs(v).toFixed(cfg.precision).split('.');
    if (cfg.thousandsSep) {
      parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, cfg.thousandsSep);
    }
    var formatted = parts.length > 1 ? (parts[0] + cfg.decimalSep + parts[1]) : parts[0];
    if (v < 0) { formatted = '-' + formatted; }
    return applyPosition(formatted, cfg);
  }

  function updateBreakdown() {
    if (!breakdownEl || !selectedPackageId || !packagesData[selectedPackageId]) { return; }
    var pkg = packagesData[selectedPackageId];
    var amount = pkg.price;
    var premium = document.getElementById('podcastAdPremium');
    var targeting = document.getElementById('podcastAdTargeting');
    if (premium && premium.checked) { amount = amount * pkg.premium_multiplier; }
    if (targeting && targeting.checked) { amount = amount + (pkg.targeting_fee || 0); }
    amount = parseFloat(amount.toFixed(2));
    var after = (walletBalance - amount);
    if (breakdownPlan) { breakdownPlan.textContent = pkg.name || '—'; }
    if (breakdownPrice) { breakdownPrice.textContent = formatMoney(amount, pkg.currency); }
    if (breakdownBalance) { breakdownBalance.textContent = formatMoney(walletBalance, pkg.currency); }
    if (breakdownAfter) {
      breakdownAfter.textContent = formatMoney(after, pkg.currency);
      breakdownAfter.classList.toggle('text-danger', after < 0);
    }
    breakdownEl.classList.remove('none');
  }

  function renderPackages(packages) {
    refreshPackageElements();
    if (!packageListEl) { return; }
    packageListEl.innerHTML = '';
    packagesData = {};
    if (!packages || !packages.length) {
      packageListEl.innerHTML = '<div class=\"podcast-ad-package__empty\">' + (I18N('hero_ads_package_empty') || 'No packages available.') + '</div>';
      return;
    }
    packages.forEach(function (pkg, idx) {
      var card = document.createElement('button');
      card.type = 'button';
      card.className = 'podcast-ad-package';
      card.setAttribute('data-podcast-package-id', pkg.id);
      card.setAttribute('aria-pressed', 'false');
      var price = (typeof pkg.price === 'number' ? pkg.price : parseFloat(pkg.price || '0')) || 0;
      var currency = (pkg.currency || 'USD').toUpperCase();
      var priceLabel = formatMoney(price, currency);
      var duration = parseInt(pkg.duration_days, 10) || 0;
      var dailyCap = pkg.daily_cap;
      var totalCap = pkg.total_cap;
      var premiumMult = pkg.premium_multiplier || 1;
      var targetingFee = pkg.targeting_fee || 0;
      packagesData[pkg.id] = {
        id: pkg.id,
        name: pkg.name || '',
        price: price,
        currency: currency,
        duration_days: duration,
        daily_cap: dailyCap,
        total_cap: totalCap,
        premium_multiplier: premiumMult,
        targeting_fee: targetingFee
      };
      card.innerHTML = '' +
        '<div class=\"podcast-ad-package__title\">' + (pkg.name || '') + '</div>' +
        '<div class=\"podcast-ad-package__price\">' + priceLabel + '</div>' +
        '<div class=\"podcast-ad-package__meta\">' +
          (duration ? '<span>' + duration + ' ' + (I18N('hero_ads_package_days') || 'days') + '</span>' : '') +
          (dailyCap ? '<span>' + (I18N('hero_ads_package_daily') || 'Daily') + ': ' + dailyCap + '</span>' : '') +
          (totalCap ? '<span>' + (I18N('hero_ads_package_total') || 'Total') + ': ' + totalCap + '</span>' : '') +
        '</div>' +
        '<div class=\"podcast-ad-package__addons\">' +
          '<span>' + (I18N('hero_ads_package_premium_short') || 'Premium x') + premiumMult + '</span>' +
        (targetingFee ? '<span>' + (I18N('hero_ads_package_targeting') || 'Targeting') + ' +' + targetingFee + '</span>' : '') +
        '</div>' +
        (pkg.description ? '<div class=\"podcast-ad-package__desc\">' + pkg.description + '</div>' : '');
      packageListEl.appendChild(card);
      if (idx === 0) {
        selectPackage(card);
        updateBreakdown();
      }
    });
  }

  function initDetailsModal() {
    detailsModal = document.getElementById('podcastAdsDetailsModal');
    if (!detailsModal) { return; }
    detailsMap = {
      pickerCover: document.getElementById('podcastAdsDetailsPodcastCover'),
      podcastTitle: document.getElementById('podcastAdsDetailsPodcastTitle'),
      podcastLink: document.getElementById('podcastAdsDetailsPodcastLink'),
      coverWrap: document.getElementById('podcastAdsDetailsCover'),
      title: document.getElementById('podcastAdsDetailsTitle'),
      subtitle: document.getElementById('podcastAdsDetailsSubtitle'),
      package: document.getElementById('podcastAdsDetailsPackage'),
      premium: document.getElementById('podcastAdsDetailsPremium'),
      targeting: document.getElementById('podcastAdsDetailsTargeting'),
      start: document.getElementById('podcastAdsDetailsStart'),
      end: document.getElementById('podcastAdsDetailsEnd'),
      daysLeft: document.getElementById('podcastAdsDetailsDaysLeft'),
      dailyCap: document.getElementById('podcastAdsDetailsDailyCap'),
      totalCap: document.getElementById('podcastAdsDetailsTotalCap'),
      impressions: document.getElementById('podcastAdsDetailsImpressions'),
      clicks: document.getElementById('podcastAdsDetailsClicks'),
      amount: document.getElementById('podcastAdsDetailsAmount'),
      amountPill: document.getElementById('podcastAdsDetailsAmountPill'),
      premiumBadge: document.getElementById('podcastAdsDetailsPremiumBadge'),
      targetingBadge: document.getElementById('podcastAdsDetailsTargetingBadge'),
      deleteBtn: document.querySelector('[data-podcast-ad-delete]'),
      csrf: document.getElementById('podcastAdsCsrf')
    };
    detailsCloseButtons = Array.from(document.querySelectorAll('[data-podcast-ad-details-close]'));
    detailsCloseButtons.forEach(function(btn){
      btn.addEventListener('click', function(ev){
        ev.preventDefault();
        ev.stopPropagation();
        if (ev.stopImmediatePropagation) { ev.stopImmediatePropagation(); }
        closeDetails();
      });
    });
    detailsModal.addEventListener('click', function(ev){
      if (ev.target === detailsModal) {
        closeDetails();
      }
    });
    if (detailsMap.deleteBtn) {
      detailsMap.deleteBtn.addEventListener('click', function(ev){
        ev.preventDefault();
        var note = detailsModal ? (detailsModal.getAttribute('data-actions-note') || '') : '';
        if (note) {
          showToast(note, 'info');
        }
      });
    }
  }

  function formatNumber(n) {
    var num = Number(n) || 0;
    return num.toLocaleString(undefined, { maximumFractionDigits: 0 });
  }

  function setText(id, value) {
    var el = detailsMap[id];
    if (!el) { return; }
    el.textContent = value || '—';
  }

  function setCover(src) {
    var wrap = detailsMap.coverWrap;
    if (!wrap) { return; }
    wrap.innerHTML = '';
    if (src) {
      var img = document.createElement('img');
      img.src = src;
      img.alt = '';
      img.loading = 'lazy';
      wrap.appendChild(img);
    } else {
      wrap.textContent = '🎧';
    }
  }

  function setPickerCover(src) {
    var wrap = detailsMap.pickerCover;
    if (!wrap) { return; }
    wrap.innerHTML = '';
    if (src) {
      var img = document.createElement('img');
      img.src = src;
      img.alt = '';
      img.loading = 'lazy';
      wrap.appendChild(img);
    } else {
      wrap.textContent = '🎧';
    }
  }

  function setLink(href) {
    var link = detailsMap.podcastLink;
    if (!link) { return; }
    if (href) {
      link.classList.remove('none');
      link.href = href;
    } else {
      link.classList.add('none');
      link.removeAttribute('href');
    }
  }

  function populateDetails(data) {
    if (!detailsModal) { return; }
    var payload = data || {};
    setPickerCover(payload.cover);
    setText('podcastTitle', payload.podcastTitle || '--');
    setLink(payload.postUrl || '');
    setCover(payload.cover);
    setText('title', payload.title || '--');
    setText('subtitle', payload.subtitle || '--');
    setText('package', payload.package || '--');
    setText('premium', payload.premium ? '✓' : '—');
    setText('targeting', payload.targeting ? '✓' : '—');
    if (detailsMap.premiumBadge) { detailsMap.premiumBadge.classList.toggle('none', !payload.premium); }
    if (detailsMap.targetingBadge) { detailsMap.targetingBadge.classList.toggle('none', !payload.targeting); }
    setText('start', payload.start ? payload.start : '—');
    setText('end', payload.end ? payload.end : '—');
    setText('daysLeft', typeof payload.daysLeft === 'number' ? String(payload.daysLeft) : '—');
    setText('dailyCap', (payload.dailyCap || payload.dailyCap === 0) ? String(payload.dailyCap) : '∞');
    setText('totalCap', (payload.totalCap || payload.totalCap === 0) ? String(payload.totalCap) : '∞');
    setText('impressions', formatNumber(payload.impressions || 0));
    setText('clicks', formatNumber(payload.clicks || 0));
    var amountValue = payload.amount ? (payload.currency ? payload.currency + ' ' + payload.amount : payload.amount) : '—';
    setText('amount', amountValue);
    if (detailsMap.amountPill) {
      detailsMap.amountPill.textContent = amountValue;
    }
    var del = detailsMap.deleteBtn;
    if (del) {
      del.dataset.adId = payload.adId || '';
      del.disabled = !(payload && payload.adId);
      del.classList.remove('is-busy');
    }
    detailsModal.classList.remove('none');
    detailsModal.setAttribute('aria-hidden', 'false');
  }

  function closeDetails() {
    if (!detailsModal) { return; }
    detailsModal.classList.add('none');
    detailsModal.setAttribute('aria-hidden', 'true');
    var del = detailsMap.deleteBtn;
    if (del) {
      del.classList.remove('is-busy');
    }
    detailsModal.style.display = 'none';
  }

  function decodeDetails(raw) {
    if (!raw) { return {}; }
    var text = raw;
    try {
      var textarea = document.createElement('textarea');
      textarea.innerHTML = raw;
      text = textarea.value || textarea.textContent || raw;
    } catch (_) {}
    try {
      return JSON.parse(text);
    } catch (_) {
      return {};
    }
  }

  function handleDelete(adId) {
    var del = detailsMap.deleteBtn;
    var csrfInput = detailsMap.csrf || document.getElementById('podcastAdsCsrf');
    var csrf = csrfInput ? (csrfInput.value || '') : '';
    if (!adId || !csrf) {
      showToast(I18N('hero_ads_invalid') || 'Missing data', 'error');
      return;
    }
    if (del) {
      del.disabled = true;
      del.classList.add('is-busy');
    }
    var fd = new FormData();
    fd.append('p', 'podcast_ad_delete');
    fd.append('csrf_token', csrf);
    fd.append('ad_id', adId);

    fetch(buildRequestUrl('request/requests.php'), { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (res) {
        var status = res.status;
        return res.json().catch(function(){ return {}; }).then(function (data) {
          return { status: status, data: data };
        });
      })
      .then(function (payload) {
        var data = (payload && payload.data) ? payload.data : {};
        var ok = data && data.status === 'success';
        var msg = (data && data.message) || '';
        if (ok) {
          showToast(msg || 'Deleted', 'success');
          closeDetails();
          var tableBtn = document.querySelector('.podcast-ads-details[data-ad-id=\"' + adId + '\"]');
          if (tableBtn) {
            tableBtn.disabled = true;
            tableBtn.classList.add('is-disabled');
          }
        } else {
          showToast(msg || 'Error', 'error');
        }
      })
      .catch(function () {
        showToast(I18N('ui_network_error') || 'Network error', 'error');
      })
      .finally(function () {
        if (del) {
          del.disabled = false;
          del.classList.remove('is-busy');
        }
      });
  }

  if (hasDetailsButtons) {
    initDetailsModal();
    document.addEventListener('click', function(ev){
      var btn = ev.target.closest('.podcast-ads-details');
      if (!btn) { return; }
      ev.preventDefault();
      if (!detailsModal) { initDetailsModal(); }
      var raw = (btn.dataset && btn.dataset.adDetails) ? btn.dataset.adDetails : (btn.getAttribute('data-ad-details') || '');
      var parsed = decodeDetails(raw);
      populateDetails(parsed);
      if (detailsModal) {
        detailsModal.classList.remove('none');
        detailsModal.style.display = '';
        detailsModal.setAttribute('aria-hidden', 'false');
      }
    });

    document.addEventListener('click', function(ev){
      var delBtn = ev.target.closest('[data-podcast-ad-delete]');
      if (!delBtn) { return; }
      ev.preventDefault();
      var targetId = delBtn.dataset.adId || '';
      handleDelete(targetId);
    });
  }

  function loadPackages(csrf) {
    refreshPackageElements();
    if (!packageListEl) { return; }
    if (packageContainer && packageContainer.getAttribute('data-loaded') === '1') {
      return;
    }
    if (!packageListEl) { return; }
    var fd = new FormData();
    fd.append('p', 'podcast_ad_packages');
    fd.append('csrf_token', csrf || '');
    fetch(buildRequestUrl('request/requests.php'), { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (res) { return res.json().catch(function(){ return {}; }); })
      .then(function (data) {
        if (!data || data.status !== 'success' || !Array.isArray(data.packages)) {
          throw new Error('packages_failed');
        }
        renderPackages(data.packages);
        if (packageContainer) {
          packageContainer.setAttribute('data-loaded', '1');
        }
      })
      .catch(function () {
        packageListEl.innerHTML = '<div class=\"podcast-ad-package__empty\">' + (I18N('hero_ads_payment_failed') || 'Unable to load packages.') + '</div>';
      });
  }

  function startPaymentIfNeeded(csrf) {
    if (!csrf) {
      return Promise.reject(new Error('missing_csrf'));
    }
    var pkgInput = document.getElementById('podcastAdPackageId');
    var payInput = document.getElementById('podcastAdPaymentId');
    var tokenInput = document.getElementById('podcastAdPaymentToken');
    if (pkgInput && payInput && tokenInput && pkgInput.value && payInput.value && tokenInput.value) {
      return Promise.resolve(true);
    }
    if (!(selectedPackageId > 0)) {
      setAlert(I18N('hero_ads_package_required') || 'Select a package first.', 'error');
      return Promise.reject(new Error('package_required'));
    }

    var fd = new FormData();
    fd.append('p', 'podcast_ad_start_payment');
    fd.append('csrf_token', csrf);
    fd.append('package_id', String(selectedPackageId));
    fd.append('provider', 'wallet');
    var premium = document.getElementById('podcastAdPremium');
    if (premium && premium.checked) { fd.append('premium_selected', '1'); }
    var targeting = document.getElementById('podcastAdTargeting');
    if (targeting && targeting.checked) { fd.append('targeting_selected', '1'); }

    return fetch(buildRequestUrl('request/requests.php'), { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (res) {
        var status = res.status;
        return res.json().catch(function(){ return {}; }).then(function (data) { return { status: status, data: data }; });
      })
      .then(function (payload) {
        var data = payload && payload.data ? payload.data : {};
        if (!data || data.status !== 'success' || !data.payment_id || !data.payment_token) {
          var msg = (data && data.message) || (I18N('hero_ads_payment_failed') || 'Payment failed.');
          setAlert(msg, 'error');
          showToast(msg, 'error');
          throw new Error('payment_failed');
        }
        setPaymentFields(selectedPackageId, data.payment_id, data.payment_token);
        if (typeof data.balance === 'number') {
          walletBalance = data.balance;
          if (walletBalanceEl) {
            walletBalanceEl.setAttribute('data-balance', String(data.balance));
            walletBalanceEl.textContent = formatMoney(walletBalance, walletCurrency);
          }
        }
        if (packageSummaryEl) {
          var amount = data.amount ? parseFloat(data.amount) : null;
          var currency = (data.currency || walletCurrency || '').toUpperCase();
          var summary = I18N('hero_ads_payment_success') || 'Payment received. Complete your ad.';
          if (!isNaN(amount) && currency) {
            summary += ' (' + formatMoney(amount, currency, (data.currency_symbol || ''), (data.precision || null)) + ')';
          }
          packageSummaryEl.textContent = summary;
          packageSummaryEl.classList.remove('none');
        }
        updateBreakdown();
        return true;
      });
  }

  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form || form.id !== 'podcastAdForm') { return; }
    e.preventDefault();
    clearAlert();
    refreshPackageElements();
    var podcastIdInput = form.querySelector('#podcastAdPostId');
    if (!podcastIdInput || !podcastIdInput.value) {
      setAlert(I18N('hero_ads_select_podcast') || 'Please select a podcast.', 'error');
      return;
    }
    if (!(selectedPackageId > 0)) {
      setAlert(I18N('hero_ads_package_required') || 'Select a package first.', 'error');
      return;
    }
    var submitBtn = form.querySelector('.podcast-ad-submit');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.classList.add('is-busy');
    }

    var csrf = (form.querySelector('input[name=\"csrf_token\"]') || {}).value || '';

    var doSubmit = function () {
      var actionUrl = form.getAttribute('action') || buildRequestUrl('request/requests.php');
      var fd = new FormData(form);
      fetch(actionUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (res) {
          var status = res.status;
          return res.json().catch(function () { return {}; }).then(function (data) {
            return { status: status, data: data };
          });
        })
        .then(function (payload) {
          var data = payload && payload.data ? payload.data : {};
          var ok = data && data.status === 'success';
          var msg = (data && data.message) || '';
          if (ok) {
            setAlert(msg || '', 'success');
            showToast(msg || '', 'success');
            updateStatusBadge('pending', msg || '');
            form.reset();
          } else {
            setAlert(msg || 'Error', 'error');
            showToast(msg || 'Error', 'error');
          }
        })
        .catch(function () {
          setAlert('Network error', 'error');
          showToast('Network error', 'error');
        })
        .finally(function () {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.classList.remove('is-busy');
          }
        });
    };

    startPaymentIfNeeded(csrf)
      .then(doSubmit)
      .catch(function () {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.classList.remove('is-busy');
        }
      });
  });

  document.addEventListener('click', function (e) {
    var pickBtn = e.target.closest('#podcastAdSelectBtn');
    if (!pickBtn) { return; }
    e.preventDefault();
    refreshPackageElements();
    var form = document.getElementById('podcastAdForm');
    var csrf = form ? (form.querySelector('input[name=\"csrf_token\"]') || {}).value : '';
    if (!csrf) {
      showToast(I18N('ui_missing_csrf') || 'Missing CSRF', 'error');
      return;
    }
    pickBtn.disabled = true;
    fetchPodcastsList(csrf, function (pods) {
      pickBtn.disabled = false;
      var picker = document.getElementById('podcastAdPicker');
      var list = document.getElementById('podcastAdPickerList');
      if (!picker || !list) { return; }
      list.innerHTML = '';
      if (!pods.length) {
        list.innerHTML = '<div class=\"podcast-ad-picker__empty\">' + (I18N('page_podcasts_empty') || 'No podcasts') + '</div>';
      } else {
        pods.forEach(function (pod) {
          var item = document.createElement('div');
          item.className = 'podcast-ad-picker__item';
          var cover = document.createElement('div');
          cover.className = 'podcast-ad-picker__cover';
          if (pod.cover) {
            var img = document.createElement('img');
            img.src = pod.cover;
            img.alt = pod.title || '';
            img.loading = 'lazy';
            cover.appendChild(img);
          } else {
            cover.textContent = '🎧';
          }
          var meta = document.createElement('div');
          meta.className = 'podcast-ad-picker__meta';
          var title = document.createElement('div');
          title.className = 'podcast-ad-picker__title';
          title.textContent = pod.title || '--';
          var btnSel = document.createElement('button');
          btnSel.type = 'button';
          btnSel.className = 'podcast-ad-picker__select';
          btnSel.textContent = I18N('select') || 'Select';
          var selectPod = function () {
            var hidden = document.getElementById('podcastAdPostId');
            if (hidden) { hidden.value = pod.id; }
            renderSelectedPodcast(pod);
            picker.classList.add('none');
          };
          btnSel.addEventListener('click', selectPod);
          item.addEventListener('click', function (ev) {
            if (ev.target === btnSel) { return; }
            selectPod();
          });
          meta.appendChild(title);
          item.appendChild(cover);
          item.appendChild(meta);
          item.appendChild(btnSel);
          list.appendChild(item);
        });
        if (pods.length === 1) {
          var hidden = document.getElementById('podcastAdPostId');
          if (hidden) { hidden.value = pods[0].id; }
          renderSelectedPodcast(pods[0]);
          picker.classList.add('none');
        }
      }
      picker.classList.remove('none');
    });
  });

  document.addEventListener('click', function (e) {
    var card = e.target.closest('.podcast-ad-package');
    if (!card || !packageListEl || !packageListEl.contains(card)) { return; }
    e.preventDefault();
    selectPackage(card);
  });

  document.addEventListener('click', function (ev) {
    var close = ev.target.closest('#podcastAdPickerClose');
    if (close) {
      ev.preventDefault();
      var picker = document.getElementById('podcastAdPicker');
      if (picker) { picker.classList.add('none'); }
    }
  });

  document.addEventListener('click', function (ev) {
    var toggle = ev.target.closest('#podcastAdPlanToggle');
    if (!toggle) { return; }
    ev.preventDefault();
    refreshPackageElements();
    if (packageContainer) {
      packageContainer.classList.toggle('none');
      if (packageContainer.getAttribute('data-loaded') !== '1') {
        var form = document.getElementById('podcastAdForm');
        var csrf = form ? (form.querySelector('input[name=\"csrf_token\"]') || {}).value : '';
        if (csrf) { loadPackages(csrf); }
      }
    }
  });

  document.addEventListener('change', function(ev){
    var chk = ev.target.closest('#podcastAdPremium, #podcastAdTargeting');
    if (!chk) { return; }
    updateBreakdown();
  });

  // Ensure packages load when popup trigger is clicked (even outside podcasts layout)
  // Guard: block default popup loader for non-approved creators before it fires
  document.addEventListener('click', function (ev) {
    var trigger = ev.target.closest('.new_item[data-pop=\"podcastHeroAd\"][data-creator-approved=\"0\"]');
    if (!trigger) { return; }
    ev.preventDefault();
    ev.stopPropagation();
    if (typeof ev.stopImmediatePropagation === 'function') { ev.stopImmediatePropagation(); }
    var lockModal = document.getElementById('podcastAdCreatorLock');
    if (lockModal) { lockModal.classList.remove('none'); }
  }, true);

  document.addEventListener('click', function (ev) {
    var openBtn = ev.target.closest('[data-pop=\"podcastHeroAd\"]');
    if (!openBtn) { return; }
    var creatorOk = openBtn.getAttribute('data-creator-approved') === '1';
    if (!creatorOk) {
      ev.preventDefault();
      if (typeof ev.stopImmediatePropagation === 'function') { ev.stopImmediatePropagation(); }
      var lockModal = document.getElementById('podcastAdCreatorLock');
      if (lockModal) { lockModal.classList.remove('none'); }
      return;
    }
    packageRetryCount = 0;
    setTimeout(function(){ initPackages(true); }, 80);
  });

  document.addEventListener('click', function (ev) {
    var closeBtn = ev.target.closest('.podcast-ad-creator-lock__close');
    if (!closeBtn) { return; }
    ev.preventDefault();
    if (typeof ev.stopImmediatePropagation === 'function') { ev.stopImmediatePropagation(); }
    var lockModal = document.getElementById('podcastAdCreatorLock');
    if (lockModal) { lockModal.classList.add('none'); }
  }, true);

  document.addEventListener('click', function (ev) {
    var payBtn = ev.target.closest('#podcastAdPayBtn');
    if (!payBtn) { return; }
    ev.preventDefault();
    showToast(I18N('hero_ads_payment_required') || 'Payment will run when you submit.', 'info');
  });

  document.addEventListener('click', function (e) {
    var btn = e.target.closest('.podcast-ad-delete');
    if (!btn) { return; }
    e.preventDefault();
    var form = document.getElementById('podcastAdForm');
    var csrf = form ? (form.querySelector('input[name=\"csrf_token\"]') || {}).value : '';
    var adId = btn.getAttribute('data-ad-id') || (form ? form.getAttribute('data-delete-id') : '');
    if (!adId) { return; }

    var fd = new FormData();
    fd.append('p', 'podcast_ad_delete');
    fd.append('csrf_token', csrf || '');
    fd.append('ad_id', adId);

    fetch(buildRequestUrl('request/requests.php'), { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (res) {
        var status = res.status;
        return res.json().catch(function () { return {}; }).then(function (data) {
          return { status: status, data: data };
        });
      })
      .then(function (payload) {
        var data = payload && payload.data ? payload.data : {};
        var ok = data && data.status === 'success';
        var msg = (data && data.message) || '';
        if (ok) {
          setAlert(msg || '', 'success');
          showToast(msg || '', 'success');
          updateStatusBadge('deleted', msg || '');
          btn.disabled = true;
          btn.classList.add('is-disabled');
        } else {
          setAlert(msg || 'Error', 'error');
          showToast(msg || 'Error', 'error');
        }
      })
      .catch(function () {
        setAlert('Network error', 'error');
        showToast('Network error', 'error');
      });
  });

  // Track "See podcast" CTA clicks before getFullPost handles popup
  document.addEventListener('click', function (ev) {
    var link = ev.target.closest('.podcasts-hero__actions .getFullPost');
    if (!link) { return; }
    var track = link.getAttribute('data-track-url');
    if (track) {
      try { fetch(track, { credentials: 'same-origin' }); } catch (_) {}
    }
  });

  // Save / Like handlers for podcast rows
  function ensureCsrfToken() {
    var el = document.querySelector('input[name="csrf_token"]');
    return el ? (el.value || '') : '';
  }

  function toggleBookmark(postId, btn) {
    var csrf = ensureCsrfToken();
    if (!csrf || !(postId > 0)) { return; }
    if (btn.getAttribute('data-busy') === '1') { return; }
    btn.setAttribute('data-busy', '1');
    btn.classList.toggle('is-active');

    var fd = new FormData();
    fd.append('p', 'toggle_bookmark');
    fd.append('post_id', String(postId));
    fd.append('item_type', 'image');
    fd.append('csrf_token', csrf);

    fetch(buildRequestUrl('request/requests.php'), { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (res) { return res.json().catch(function(){ return {}; }); })
      .then(function (data) {
        if (data && data.success) {
          btn.classList.toggle('is-active', !!data.bookmarked);
        } else {
          btn.classList.toggle('is-active');
        }
      })
      .catch(function () {
        btn.classList.toggle('is-active');
      })
      .finally(function () {
        btn.removeAttribute('data-busy');
      });
  }

  function toggleLike(postId, btn) {
    var csrf = ensureCsrfToken();
    if (!csrf || !(postId > 0)) { return; }
    if (btn.getAttribute('data-busy') === '1') { return; }
    btn.setAttribute('data-busy', '1');
    btn.classList.toggle('is-active');

    var fd = new FormData();
    fd.append('p', 'like_post');
    fd.append('post_id', String(postId));
    fd.append('csrf_token', csrf);

    fetch(buildRequestUrl('request/requests.php'), { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (res) { return res.json().catch(function(){ return {}; }); })
      .then(function (data) {
        if (data && data.success !== false && typeof data.liked !== 'undefined') {
          btn.classList.toggle('is-active', !!data.liked);
        } else {
          btn.classList.toggle('is-active');
        }
      })
      .catch(function () {
        btn.classList.toggle('is-active');
      })
      .finally(function () {
        btn.removeAttribute('data-busy');
      });
  }

  document.addEventListener('click', function (ev) {
    var saveBtn = ev.target.closest('.podcast-row__icon-btn[data-action="podcast-save"]');
    if (saveBtn) {
      ev.preventDefault();
      var pid = parseInt(saveBtn.getAttribute('data-post-id') || '0', 10) || 0;
      toggleBookmark(pid, saveBtn);
      return;
    }
    var likeBtn = ev.target.closest('.podcast-row__icon-btn[data-action="podcast-like"]');
    if (likeBtn) {
      ev.preventDefault();
      var pidL = parseInt(likeBtn.getAttribute('data-post-id') || '0', 10) || 0;
      toggleLike(pidL, likeBtn);
      return;
    }
  });

  // Inline podcast player for recent list
  var inlineAudio = null;
  var inlineCurrentRow = null;
  var inlineDurationLabel = null;
  var inlineDurationTotal = 0;
  var inlineCurrentUrl = '';
  var inlineTrackTimes = {};
  var inlinePendingSeek = null;

  function formatTime(secs) {
    var s = Math.max(0, Math.floor(secs || 0));
    var m = Math.floor(s / 60);
    var r = s % 60;
    return m + ':' + (r < 10 ? '0' + r : r);
  }

  function updateInlineDuration(current, total) {
    if (!inlineDurationLabel) { return; }
    var totalVal = typeof total === 'number' && total > 0 ? total : (inlineDurationTotal || null);
    var curVal = typeof current === 'number' && current >= 0 ? current : 0;
    if (totalVal) {
      inlineDurationLabel.textContent = formatTime(curVal) + ' / ' + formatTime(totalVal);
    } else {
      inlineDurationLabel.textContent = formatTime(curVal);
    }
  }

  function ensureInlineAudio() {
    if (inlineAudio) { return inlineAudio; }
    inlineAudio = new Audio();
    inlineAudio.preload = 'metadata';
    inlineAudio.addEventListener('ended', function () {
      if (inlineCurrentRow) {
        inlineCurrentRow.classList.remove('is-playing');
        inlineTrackTimes[inlineCurrentUrl] = 0;
        updateInlineDuration(inlineDurationTotal || inlineAudio.duration, inlineDurationTotal || inlineAudio.duration);
        inlineCurrentRow = null;
      }
    });
    inlineAudio.addEventListener('pause', function () {
      if (inlineCurrentRow) {
        inlineCurrentRow.classList.remove('is-playing');
        inlineTrackTimes[inlineCurrentUrl] = inlineAudio.currentTime || 0;
        updateInlineDuration(inlineAudio.currentTime, inlineAudio.duration);
      }
    });
    inlineAudio.addEventListener('play', function () {
      if (inlineCurrentRow) {
        inlineCurrentRow.classList.add('is-playing');
      }
    });
    inlineAudio.addEventListener('timeupdate', function () {
      if (!inlineCurrentRow) { return; }
      inlineTrackTimes[inlineCurrentUrl] = inlineAudio.currentTime || 0;
      updateInlineDuration(inlineAudio.currentTime, inlineAudio.duration);
    });
    inlineAudio.addEventListener('loadedmetadata', function () {
      if (!inlineCurrentRow) { return; }
      var total = inlineAudio.duration;
      if (total && total > 0) {
        inlineDurationTotal = total;
      }
      if (inlinePendingSeek !== null) {
        var target = inlinePendingSeek;
        inlinePendingSeek = null;
        var dur = inlineAudio.duration || inlineDurationTotal || target;
        inlineAudio.currentTime = Math.min(target, dur || target);
        updateInlineDuration(inlineAudio.currentTime, dur);
      } else {
        updateInlineDuration(0, inlineDurationTotal);
      }
    });
    return inlineAudio;
  }

  document.addEventListener('click', function (ev) {
    var trigger = ev.target.closest('.podcast-row__play');
    if (!trigger) { return; }
    ev.preventDefault();
    if (typeof ev.stopPropagation === 'function') { ev.stopPropagation(); }
    if (typeof ev.stopImmediatePropagation === 'function') { ev.stopImmediatePropagation(); }

    var row = trigger.closest('.podcast-row');
    if (!row) { return; }

    var audioUrl = row.getAttribute('data-audio-url') || '';
    var durationSec = parseInt(row.getAttribute('data-duration-sec') || '0', 10) || 0;
    inlineDurationTotal = durationSec > 0 ? durationSec : 0;
    inlineDurationLabel = row.querySelector('.podcast-row__duration');
    if (inlineDurationLabel && inlineDurationTotal) {
      updateInlineDuration(0, inlineDurationTotal);
    }

    if (!audioUrl) {
      var postUrl = row.getAttribute('data-post-url');
      if (postUrl) {
        window.location.href = postUrl;
      }
      return;
    }

    var player = ensureInlineAudio();
    if (inlineCurrentRow && inlineCurrentRow !== row) {
      inlineCurrentRow.classList.remove('is-playing');
    }

    var sameTrack = inlineCurrentRow === row && inlineCurrentUrl === audioUrl;

    if (sameTrack && !player.paused) {
      player.pause();
      return;
    }

    inlineCurrentRow = row;

    try {
      if (!sameTrack) {
        inlineCurrentUrl = audioUrl;
        player.src = audioUrl;
        var resumeAt = inlineTrackTimes[audioUrl] || 0;
        inlinePendingSeek = resumeAt > 0 ? resumeAt : null;
        updateInlineDuration(resumeAt, inlineDurationTotal || player.duration);
      } else {
        updateInlineDuration(player.currentTime, inlineDurationTotal || player.duration);
      }

      player.play().catch(function () {
        var postUrl = row.getAttribute('data-post-url');
        if (postUrl) { window.location.href = postUrl; }
      });
    } catch (_) {
      var postUrl = row.getAttribute('data-post-url');
      if (postUrl) { window.location.href = postUrl; }
    }
  });


  function initHeroSlider() {
    var hero = document.querySelector('.podcasts-hero--ads');
    if (!hero) { return; }
    var wrapper = hero.querySelector('.podcasts-hero__slides');
    if (!wrapper) { return; }
    var slides = wrapper.querySelectorAll('.podcasts-hero__slide');
    if (!slides.length) { return; }
    var progressBars = Array.prototype.slice.call(hero.querySelectorAll('.podcasts-hero__progress-bar'));

    var navPrev = document.querySelector('.podcasts-hero__nav--prev');
    var navNext = document.querySelector('.podcasts-hero__nav--next');
    var slideCount = slides.length;
    var autoDelay = 5200;
    var autoTimer = null;
    var progressStartedAt = 0;
    var progressElapsed = 0;
    var remainingMs = autoDelay;

    if (slideCount <= 1) {
      if (navPrev) { navPrev.setAttribute('disabled', 'disabled'); }
      if (navNext) { navNext.setAttribute('disabled', 'disabled'); }
    }

    function setHeroBg(url) {
      if (!hero) { return; }
      var safe = url ? String(url) : '';
      var val = safe ? ('url(\"' + safe.replace(/\"/g, '\\\"') + '\")') : '';
      hero.style.setProperty('--podcasts-hero-bg', val);
    }

    function applyBgFrom(slide) {
      var cover = slide ? slide.getAttribute('data-cover') : '';
      setHeroBg(cover);
    }

    function getActiveBar() {
      return progressBars[activeIndex] || null;
    }

    function setBarFill(bar, pct, durationMs) {
      if (!bar) { return; }
      var safePct = Math.max(0, Math.min(100, pct));
      bar.style.setProperty('--progress-duration', (durationMs || 0) + 'ms');
      bar.style.setProperty('--progress-fill', safePct + '%');
    }

    function resetAllBars() {
      progressBars.forEach(function (bar) {
        setBarFill(bar, 0, 0);
      });
    }

    function startProgressBar(resetAll) {
      var bar = getActiveBar();
      if (!bar) { return; }
      if (resetAll) {
        resetAllBars();
      } else {
        setBarFill(bar, 0, 0);
      }
      progressStartedAt = Date.now();
      progressElapsed = 0;
      // Force reflow before animating
      void bar.offsetWidth;
      setBarFill(bar, 100, autoDelay);
    }

    function pauseProgressBar(elapsedOverride) {
      var bar = getActiveBar();
      if (!bar) { return; }
      var elapsed = typeof elapsedOverride === 'number' ? elapsedOverride : (progressStartedAt ? (Date.now() - progressStartedAt) : 0);
      progressElapsed = Math.max(0, Math.min(elapsed, autoDelay));
      remainingMs = Math.max(0, autoDelay - progressElapsed);
      var pct = Math.max(0, Math.min(100, (progressElapsed / autoDelay) * 100));
      setBarFill(bar, pct, 0);
    }

    function resumeProgressBar() {
      var bar = getActiveBar();
      if (!bar) { return; }
      if (remainingMs <= 0) {
        setBarFill(bar, 100, 0);
        return;
      }
      var pct = Math.max(0, Math.min(100, (progressElapsed / autoDelay) * 100));
      setBarFill(bar, pct, 0);
      progressStartedAt = Date.now();
      // Force reflow before animating remaining
      void bar.offsetWidth;
      setBarFill(bar, 100, remainingMs);
    }

    function stopAuto() {
      if (autoTimer) {
        clearTimeout(autoTimer);
        autoTimer = null;
      }
      if (progressStartedAt) {
        var elapsed = Date.now() - progressStartedAt;
        remainingMs = Math.max(0, autoDelay - elapsed);
        pauseProgressBar(elapsed);
        progressStartedAt = 0;
      }
    }

    function startAuto(resetAll) {
      if (slideCount <= 1) {
        resetAllBars();
        return;
      }
      stopAuto();
      remainingMs = autoDelay;
      startProgressBar(!!resetAll);
      progressStartedAt = Date.now();
      autoTimer = setTimeout(function () {
        setActive(activeIndex + 1);
      }, remainingMs);
    }

    function resumeAuto() {
      if (slideCount <= 1) {
        resetAllBars();
        return;
      }
      if (!progressStartedAt && remainingMs <= 0) {
        setActive(activeIndex + 1);
        return;
      }
      stopAuto();
      resumeProgressBar();
      if (remainingMs <= 0) {
        setActive(activeIndex + 1);
        return;
      }
      progressStartedAt = Date.now();
      autoTimer = setTimeout(function () {
        setActive(activeIndex + 1);
      }, remainingMs);
    }

    function syncActive(idx) {
      if (idx < 0) { idx = 0; }
      if (idx >= slideCount) { idx = 0; }
      slides.forEach(function (slide, i) {
        var isCurrent = i === idx;
        slide.classList.toggle('is-active', isCurrent);
        slide.setAttribute('aria-hidden', isCurrent ? 'false' : 'true');
      });
      var current = slides[idx] || slides[0];
      applyBgFrom(current);
    }

    // Manual, reliable slider (no Swiper dependency)
    var activeIndex = 0;
    slides.forEach(function (slide, idx) {
      if (slide.classList.contains('is-active')) {
        activeIndex = idx;
      }
    });

    // Seed background from data attribute or first slide cover
    var initialCover = hero.getAttribute('data-hero-bg') || (slides[activeIndex] ? slides[activeIndex].getAttribute('data-cover') : '');
    setHeroBg(initialCover);

    function setActive(idx) {
      var wrappedToStart = false;
      if (idx < 0) {
        idx = slideCount - 1;
      } else if (idx >= slideCount) {
        idx = 0;
        wrappedToStart = true;
      }
      activeIndex = idx;
      syncActive(activeIndex);
      if (slideCount > 1) {
        startAuto(wrappedToStart);
      } else {
        resetAllBars();
      }
    }

    if (slideCount > 1) {
      if (navPrev) {
        navPrev.addEventListener('click', function (ev) {
          ev.preventDefault();
          setActive(activeIndex - 1);
        });
      }
      if (navNext) {
        navNext.addEventListener('click', function (ev) {
          ev.preventDefault();
          setActive(activeIndex + 1);
        });
      }

      startAuto();
      hero.addEventListener('mouseenter', stopAuto);
      hero.addEventListener('mouseleave', function () {
        if (slideCount > 1) {
          resumeAuto();
        }
      });
    }

    setActive(activeIndex);
  }

  var packageRetryCount = 0;
  function initPackages(force) {
    refreshPackageElements();
    var form = document.getElementById('podcastAdForm');
    if (!form) {
      if (packageRetryCount < 5) {
        packageRetryCount++;
        setTimeout(function(){ initPackages(force); }, 80);
      }
      return;
    }
    if (!packageListEl) {
      if (packageRetryCount < 5) {
        packageRetryCount++;
        setTimeout(function(){ initPackages(force); }, 80);
      }
      return;
    }
    if (!force && packageContainer && packageContainer.getAttribute('data-loaded') === '1') {
      return;
    }
    var csrf = (form.querySelector('input[name=\"csrf_token\"]') || {}).value || '';
    if (!csrf) { return; }
    loadPackages(csrf);
  }

  function initPodcastAds() {
    initHeroSlider();
    initPackages();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPodcastAds);
  } else {
    initPodcastAds();
  }

  // Observer to catch late-inserted popup DOM and load packages
  var observer;
  function observePopupInsertion() {
    if (observer) { return; }
    observer = new MutationObserver(function(mutations){
      mutations.forEach(function(m){
        var nodes = m.addedNodes || [];
        for (var i = 0; i < nodes.length; i++) {
          var n = nodes[i];
          if (n.nodeType === 1 && n.querySelector && n.querySelector('#podcastAdPackageList')) {
            packageRetryCount = 0;
            initPackages(true);
            return;
          }
        }
      });
    });
    observer.observe(document.body || document.documentElement, { childList: true, subtree: true });
  }
  observePopupInsertion();
})();
