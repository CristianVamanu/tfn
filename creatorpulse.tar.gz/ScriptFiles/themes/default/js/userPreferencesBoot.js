(function(){
  'use strict';

  var win = typeof window !== 'undefined' ? window : {};

  function readJsonScript(id){
    var el = document.getElementById(id);
    if (!el) { return {}; }
    var text = '';
    if (typeof el.textContent === 'string') { text = el.textContent; }
    else if (typeof el.innerText === 'string') { text = el.innerText; }
    var result = {};
    if (text) {
      try {
        var parsed = JSON.parse(text);
        if (parsed && typeof parsed === 'object') {
          result = parsed;
        }
      } catch (_) {
        result = {};
      }
    }
    if (el.parentNode) {
      el.parentNode.removeChild(el);
    }
    return result;
  }

  function merge(target, source){
    var output = {};
    var assign = function(obj){
      if (!obj || typeof obj !== 'object') { return; }
      for (var key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) {
          output[key] = obj[key];
        }
      }
    };
    assign(target);
    assign(source);
    return output;
  }

  var existing = (win.DZ && typeof win.DZ === 'object' && win.DZ.userPreferences && typeof win.DZ.userPreferences === 'object')
    ? win.DZ.userPreferences
    : {};
  var fromScript = readJsonScript('dz-user-preferences-data');

  if (!win.DZ || typeof win.DZ !== 'object') {
    win.DZ = {};
  }

  win.DZ.userPreferences = merge(existing, fromScript);
})();
