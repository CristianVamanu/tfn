'use strict';
(function (window, $) {
  if (!window || !$) { return; }

  var buildUrl = (window.DZ && window.DZ.buildUrl) || function (path) {
    try {
      var base = (typeof window.site_url === 'string' && window.site_url) ? window.site_url : (window.location.origin + window.location.pathname.replace(/[^\/]*$/, ''));
      if (base.slice(-1) !== '/') { base += '/'; }
      return new URL(String(path || '').replace(/^\//, ''), base).toString();
    } catch (_) {
      return String(path || '');
    }
  };

  var Feed = {
    busy: false,
    hasMore: true,
    offset: 0,
    limit: 20,
    endpoint: 'feed_more',
    filter: 'all',
    $root: null,
    $sentinel: null,
    $loader: null,
    $emptyState: null,
    io: null,
    itemsLoaded: 0,
    adInterval: 5,
    nextAdThreshold: 5,
    fetchingAd: false,
    filterToken: 0,

    init: function () {
      this.$root = $('#posts');
      this.$sentinel = $('#feed-sentinel');
      if (!this.$root.length || !this.$sentinel.length) { return; }

      var filterAttr = this.$root.data('feed-filter');
      if (filterAttr) {
        this.filter = this._normalizeFilter(filterAttr);
      } else {
        var $bar = $('.feed-filter-bar').first();
        if ($bar.length) {
          this.filter = this._normalizeFilter($bar.data('active-filter'));
        }
      }

      this.offset = this.$root.find('.post_').length || 0;
      this.itemsLoaded = this._countFeedPosts();
      this._syncExistingEmptyState();

      var endpointAttr = this.$root.data('feed-endpoint');
      if (endpointAttr) {
        this.endpoint = String(endpointAttr);
      }

      var limitAttr = parseInt(this.$root.data('feed-limit'), 10);
      if (!isNaN(limitAttr) && limitAttr > 0) {
        this.limit = limitAttr;
      }

      var intervalAttr = parseInt(this.$root.data('ad-interval'), 10);
      if (!isNaN(intervalAttr) && intervalAttr > 0) {
        this.adInterval = intervalAttr;
      }
      this.nextAdThreshold = this._computeNextAdThreshold();

      var hasMoreAttr = this.$sentinel.data('has-more');
      if (typeof hasMoreAttr !== 'undefined') {
        this.hasMore = (hasMoreAttr === true || hasMoreAttr === 1 || hasMoreAttr === '1');
      } else {
        this.hasMore = true;
      }
      if (typeof hasMoreAttr === 'undefined' && this.itemsLoaded === 0 && this.$emptyState && this.$emptyState.length) {
        this.hasMore = false;
      }

      var self = this;
      if ('IntersectionObserver' in window) {
        this.io = new IntersectionObserver(function (entries) {
          var entry = entries && entries[0];
          if (!entry) { return; }
          if (entry.isIntersecting || entry.intersectionRatio > 0) { self.loadMore(); }
        }, { root: null, rootMargin: '1200px 0px 1200px 0px', threshold: [0, 0.01] });
        this.io.observe(this.$sentinel.get(0));
      }

      var ticking = false;
      function onScroll() {
        if (ticking) { return; }
        ticking = true;
        setTimeout(function () {
          ticking = false;
          self._fallbackTick();
        }, 180);
      }
      window.addEventListener('scroll', onScroll, { passive: true });
      window.addEventListener('resize', onScroll, { passive: true });

      this._registerNewAds(this.$root);
      this._maybeInsertAd();
    },

    _fallbackTick: function () {
      if (!this.hasMore || this.busy) { return; }
      var doc = document.documentElement;
      var st = (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
      var vh = window.innerHeight || doc.clientHeight;
      var full = Math.max(doc.scrollHeight, doc.offsetHeight, doc.clientHeight);
      if (full - (st + vh) < 1400) { this.loadMore(); }
    },

    loadMore: function () {
      if (this.busy || !this.hasMore) { return; }
      this.busy = true;
      var self = this;
      var token = this.filterToken;
      var csr = $('input[name="csrf_token"]').val() || '';
      var payload = { p: this.endpoint, offset: this.offset, limit: this.limit, csrf_token: csr };
      if (this.filter && this.filter !== 'all') {
        payload.filter = this.filter;
      }
      $.ajax({
        url: buildUrl('request/requests.php'),
        type: 'POST',
        dataType: 'json',
        data: payload
      }).done(function (res) {
        if (token !== self.filterToken) { return; }
        if (!res || res.status !== 'ok') {
          self.hasMore = false;
          if (self.itemsLoaded === 0) {
            self._showEmptyState();
          }
          return;
        }
        var html = res.html ? $.trim(res.html) : '';
        if (html) {
          self._removeEmptyState();
          var $chunk = $(html);
          self.$sentinel.before($chunk);
          $(document).trigger('posts:loaded', { root: self.$root.get(0) });
          self._registerNewAds($chunk);
          self._updateItemCount($chunk);
          self._maybeInsertAd();
        }
        self.offset = parseInt(res.next_offset || self.offset, 10);
        self.hasMore = !!res.has_more;
        if (!html && !self.hasMore && self.itemsLoaded === 0) {
          self._showEmptyState();
        }
      }).always(function () {
        if (token !== self.filterToken) { return; }
        self._removeLoader();
        self.busy = false;
      });
    },

    setFilter: function (filter) {
      var normalized = this._normalizeFilter(filter);
      if (normalized === this.filter && this.offset === 0 && this.$root.find('.post_').length) {
        return;
      }
      this.busy = false;
      this.filter = normalized;
      this.filterToken += 1;
      this.offset = 0;
      this.itemsLoaded = 0;
      this.hasMore = true;
      this.nextAdThreshold = this._computeNextAdThreshold();
      this._clearFeed();
      this._showLoader();
      this.loadMore();
    },

    _normalizeFilter: function (filter) {
      var value = String(filter || 'all').toLowerCase();
      if (value === 'reels') { value = 'video'; }
      var allowed = { all: true, video: true, image: true, podcast: true };
      return allowed[value] ? value : 'all';
    },

    _getLoadingLabel: function () {
      var label = this.$root.data('loading-label');
      if (!label) {
        var $bar = $('.feed-filter-bar').first();
        label = $bar.data('loading-label');
      }
      return label || 'Loading...';
    },

    _showLoader: function () {
      if (this.$loader && this.$loader.length) { return; }
      this._removeEmptyState();
      var text = this._getLoadingLabel();
      this.$loader = $('<div>', { class: 'feed-loading', role: 'status', 'aria-live': 'polite' })
        .append($('<span>', { class: 'feed-loading__spinner', 'aria-hidden': 'true' }))
        .append($('<span>', { class: 'feed-loading__label', text: text }));
      this.$sentinel.before(this.$loader);
    },

    _removeLoader: function () {
      if (!this.$loader || !this.$loader.length) { return; }
      this.$loader.remove();
      this.$loader = null;
    },

    _getEmptyStateCopy: function () {
      var key = this.filter || 'all';
      var title = this.$root.attr('data-empty-title-' + key) || this.$root.attr('data-empty-title-all') || 'No posts yet';
      var subtitle = this.$root.attr('data-empty-subtitle-' + key) || this.$root.attr('data-empty-subtitle-all') || '';
      var cta = this.$root.attr('data-empty-cta') || '';
      return { title: title, subtitle: subtitle, cta: cta };
    },

    _getEmptyStateIcon: function () {
      var template = document.getElementById('feed-empty-icon-template');
      return template ? $.trim(template.innerHTML || '') : '';
    },

    _syncExistingEmptyState: function () {
      if (!this.$root || !this.$root.length) { return; }
      var $states = this.$root.children('.empty-state.no-posts, .feed-empty-state');
      if (!$states.length) {
        this.$emptyState = null;
        return;
      }
      this.$emptyState = $states.first();
      $states.not(this.$emptyState).remove();
    },

    _showEmptyState: function () {
      this._syncExistingEmptyState();
      if (this.$emptyState && this.$emptyState.length) { return; }
      var copy = this._getEmptyStateCopy();
      var $state = $('<div>', { class: 'empty-state no-posts feed-empty-state full-width flex align_items flexBoxColumn gap' });
      $state.append($('<div>', { class: 'empty-state__icon flex align_items', html: this._getEmptyStateIcon() }));
      $state.append($('<div>', { class: 'empty-state__title flex align_items', text: copy.title }));

      var $body = $('<div>', { class: 'empty-state__body flex align_items flexBoxColumn gap' });
      if (copy.subtitle) {
        $body.append($('<p>', { class: 'empty-state__subtitle', text: copy.subtitle }));
      }
      if (copy.cta) {
        $body.append($('<button>', { type: 'button', class: 'empty-state__cta new_item', 'data-pop': 'createNew', text: copy.cta }));
      }
      $state.append($body);

      this.$emptyState = $state;
      this.$sentinel.before($state);
    },

    _removeEmptyState: function () {
      if (this.$emptyState && this.$emptyState.length) {
        this.$emptyState.remove();
      }
      this.$emptyState = null;
    },

    _pauseMediaInRoot: function () {
      if (!this.$root || !this.$root.length) { return; }
      this.$root.find('video, audio').each(function () {
        try { this.pause(); } catch (_) { }
      });
    },

    _clearFeed: function () {
      this._pauseMediaInRoot();
      this._removeLoader();
      this._removeEmptyState();
      this.$root.children().not(this.$sentinel).remove();
    },

    _countFeedPosts: function () {
      return this.$root.find('.post_').filter(function () {
        return !this.getAttribute('data-ad-id');
      }).length;
    },

    _updateItemCount: function ($chunk) {
      if (!$chunk || !$chunk.length) { return; }
      var delta = 0;
      $chunk.each(function () {
        if (this.nodeType !== 1) { return; }
        var $el = $(this);
        if ($el.hasClass('post_') && !this.getAttribute('data-ad-id')) { delta++; }
        $el.find('.post_').each(function () {
          if (!this.getAttribute('data-ad-id')) { delta++; }
        });
      });
      if (delta > 0) {
        this.itemsLoaded += delta;
      }
    },

    _computeNextAdThreshold: function () {
      if (this.adInterval <= 0) { return Infinity; }
      var threshold = this.adInterval;
      if (this.itemsLoaded >= threshold) {
        threshold = (Math.floor(this.itemsLoaded / this.adInterval) + 1) * this.adInterval;
      }
      return threshold;
    },

    _maybeInsertAd: function () {
      if (this.filter && this.filter !== 'all') { return; }
      if (this.adInterval <= 0 || this.fetchingAd) { return; }
      if (this.itemsLoaded < this.nextAdThreshold) { return; }

      this.fetchingAd = true;
      var shown = (window.AdsFeedSlots && typeof window.AdsFeedSlots.getShownAdIds === 'function')
        ? window.AdsFeedSlots.getShownAdIds()
        : [];
      var csr = $('input[name="csrf_token"]').val() || '';
      var payload = {
        p: 'ads_feed_instream',
        limit: 1,
        csrf_token: csr
      };
      if (shown && shown.length) {
        payload.exclude = shown.join(',');
      }

      var self = this;
      $.ajax({
        url: buildUrl('request/requests.php'),
        type: 'POST',
        dataType: 'json',
        data: payload
      }).done(function (resp) {
        if (!resp || resp.status !== 'success') { return; }
        if (resp.html) {
          var $ad = $(resp.html);
          if ($ad.length) {
            self.$sentinel.before($ad);
            self._registerNewAds($ad);
            if (window.AdsFeedSlots && typeof window.AdsFeedSlots.markShown === 'function' && Array.isArray(resp.adIds)) {
              window.AdsFeedSlots.markShown(resp.adIds);
            }
          }
        }
      }).always(function () {
        self.fetchingAd = false;
        self.nextAdThreshold = self._computeNextAdThreshold();
      });
    },

    _registerNewAds: function ($scope) {
      if (!window.AdsFeedSlots || typeof window.AdsFeedSlots.registerAds !== 'function') { return; }
      $scope.each(function () {
        window.AdsFeedSlots.registerAds(this);
      });
    }
  };

  $(function () { Feed.init(); });
  window.MainFeed = Feed;
})(window, window.jQuery);
