(function () {
    'use strict';

    var FALLBACK_SECONDS = 12;

    function revealGate(container) {
        if (!container || container.classList.contains('is-teaser-locked')) {
            return;
        }
        container.classList.add('is-teaser-locked');
        var media = container.querySelector('[data-premium-teaser-media="1"]');
        if (media && typeof media.pause === 'function') {
            try { media.pause(); } catch (e) {}
        }
    }

    function bindTeaser(container) {
        if (!container || container.dataset.premiumTeaserBound === '1') {
            return;
        }
        var media = container.querySelector('[data-premium-teaser-media="1"]');
        if (!media) {
            revealGate(container);
            return;
        }

        container.dataset.premiumTeaserBound = '1';
        container.classList.remove('is-teaser-locked');

        var fallbackTimer = null;
        var clearFallback = function () {
            if (fallbackTimer) {
                window.clearTimeout(fallbackTimer);
                fallbackTimer = null;
            }
        };

        media.addEventListener('play', function () {
            clearFallback();
            if (!Number.isFinite(media.duration) || media.duration <= 0) {
                fallbackTimer = window.setTimeout(function () {
                    revealGate(container);
                }, FALLBACK_SECONDS * 1000);
            }
        });

        media.addEventListener('pause', clearFallback);
        media.addEventListener('ended', function () {
            clearFallback();
            revealGate(container);
        });

        media.addEventListener('timeupdate', function () {
            if (!Number.isFinite(media.duration) || media.duration <= 0) {
                return;
            }
            if (media.currentTime >= Math.max(0, media.duration - 0.25)) {
                revealGate(container);
            }
        });

        media.addEventListener('error', function () {
            clearFallback();
            revealGate(container);
        });
    }

    function bindAll(root) {
        var scope = root && root.querySelectorAll ? root : document;
        scope.querySelectorAll('.locked-preview-media[data-premium-teaser="1"]').forEach(bindTeaser);
    }

    document.addEventListener('DOMContentLoaded', function () {
        bindAll(document);
    });

    document.addEventListener('posts:loaded', function (event) {
        bindAll(event && event.target ? event.target : document);
    });

    if (window.jQuery) {
        window.jQuery(document).on('posts:loaded', function () {
            bindAll(document);
        });
    }

    window.PremiumTeaser = {
        bind: bindAll
    };
})();
