'use strict';
(function (window, document) {
  if (!window || !document) { return; }

  var buildUrl = (window.DZ && window.DZ.buildUrl) || function (path) {
    try {
      var base = (typeof window.site_url === 'string' && window.site_url) ? window.site_url : (window.location.origin + window.location.pathname.replace(/[^\/]*$/, ''));
      if (base.slice(-1) !== '/') { base += '/'; }
      return new URL(String(path || '').replace(/^\//, ''), base).toString();
    } catch (_) {
      return String(path || '');
    }
  };

  var state = {
    shownIds: [],
    impressionSent: {},
    clickSent: {},
    observer: null,
    busySidebar: false
  };

  function hasShown(id) {
    return state.shownIds.indexOf(id) !== -1;
  }

  function addShown(id) {
    if (!hasShown(id)) {
      state.shownIds.push(id);
    }
  }

  function getCsrfToken() {
    var el = document.querySelector('input[name="csrf_token"]');
    return el ? String(el.value || '') : '';
  }

  function encodeForm(data) {
    var parts = [];
    for (var key in data) {
      if (!Object.prototype.hasOwnProperty.call(data, key)) { continue; }
      var value = data[key];
      if (value === undefined || value === null) { continue; }
      parts.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
    }
    return parts.join('&');
  }

  function postRequest(payload) {
    var body = encodeForm(payload);
    if (window.fetch) {
      return window.fetch(buildUrl('request/requests.php'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body,
        credentials: 'same-origin'
      }).then(function (response) {
        if (!response.ok) { throw new Error('HTTP ' + response.status); }
        return response.json();
      });
    }

    if (window.jQuery && typeof window.jQuery.ajax === 'function') {
      return window.jQuery.ajax({
        url: buildUrl('request/requests.php'),
        method: 'POST',
        data: payload,
        dataType: 'json'
      });
    }

    return Promise.reject(new Error('No fetch available'));
  }

  function ensureObserver() {
    if (state.observer || !('IntersectionObserver' in window)) { return; }
    state.observer = new window.IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry || !entry.target) { return; }
        if (entry.isIntersecting || entry.intersectionRatio > 0) {
          var id = parseInt(entry.target.getAttribute('data-ad-id'), 10);
          if (id > 0) {
            state.observer.unobserve(entry.target);
            trackImpression(id);
          }
        }
      });
    }, { root: null, rootMargin: '240px 0px 240px 0px', threshold: [0, 0.2] });
  }

  function registerElement(el) {
    if (!el) { return; }
    var id = parseInt(el.getAttribute('data-ad-id'), 10);
    if (!(id > 0)) { return; }
    addShown(id);
    attachClickTracking(el, id);
    if (state.observer) {
      state.observer.observe(el);
    } else if ('IntersectionObserver' in window) {
      ensureObserver();
      if (state.observer) {
        state.observer.observe(el);
      }
    } else {
      // Fallback: track immediately if no observer support
      trackImpression(id);
    }
  }

  function closestClickable(target) {
    if (!target) { return null; }
    if (typeof target.closest === 'function') {
      return target.closest('[data-ad-clickable]');
    }
    var node = target;
    while (node) {
      if (node.getAttribute && node.getAttribute('data-ad-clickable') !== null) {
        return node;
      }
      node = node.parentNode;
    }
    return null;
  }

  function attachClickTracking(el, adId) {
    if (!el || !(adId > 0)) { return; }
    if (el.__adsClickBound) { return; }
    el.__adsClickBound = true;
    el.addEventListener('click', function (event) {
      var clickable = closestClickable(event.target);
      if (!clickable) { return; }
      trackClick(adId);
    });
  }

  function trackImpression(adId) {
    if (state.impressionSent[adId]) { return; }
    state.impressionSent[adId] = true;
    postRequest({
      p: 'ads_track_impression',
      ad_id: adId,
      csrf_token: getCsrfToken()
    }).catch(function () {
      state.impressionSent[adId] = false;
    });
  }

  function trackClick(adId) {
    if (state.clickSent[adId]) { return; }
    state.clickSent[adId] = true;
    postRequest({
      p: 'ads_track_click',
      ad_id: adId,
      csrf_token: getCsrfToken()
    }).catch(function () {
      state.clickSent[adId] = false;
    });
  }

  function renderSidebarCard(ad) {
    if (!ad || !(ad.ad_id > 0)) { return null; }
    var template = document.getElementById('sponsor-sidebar-card-template');
    var card = null;
    if (template && 'content' in template) {
      card = template.content.firstElementChild.cloneNode(true);
    }
    if (!card) {
      card = document.createElement('article');
      card.className = 'sponsor-card sponsor-sponsored';
      card.innerHTML = '<div class="sponsor-card-media" data-ad-media></div>' +
        '<div class="sponsor-card-body">' +
        '<span class="sponsor-card-badge"></span>' +
        '<a class="sponsor-card-title" data-ad-clickable="1" target="_blank" rel="nofollow noopener"></a>' +
        '<p class="sponsor-card-description"></p>' +
        '<a class="sponsor-card-cta" data-ad-clickable="1" target="_blank" rel="nofollow noopener"></a>' +
        '</div>';
    }

    card.setAttribute('data-ad-id', ad.ad_id);
    card.setAttribute('data-media-type', ad.media_type || 'image');

    var mediaHost = card.querySelector('[data-ad-media]');
    if (mediaHost) {
      var mediaUrl = '';
      if (ad.media_urls && ad.media_urls.length) {
        mediaUrl = ad.media_urls[0];
      }
      mediaHost.innerHTML = '';
      if (ad.media_type === 'video') {
        var video = document.createElement('video');
        video.className = 'sponsor-card-video';
        video.setAttribute('playsinline', '');
        video.setAttribute('preload', 'metadata');
        video.setAttribute('controls', '');
        video.setAttribute('data-ad-clickable', '1');
        if (ad.video_thumb_url) {
          video.setAttribute('poster', ad.video_thumb_url);
        }
        video.src = mediaUrl;
        mediaHost.appendChild(video);
      } else {
        var link = document.createElement('a');
        link.className = 'sponsor-card-media-link';
        link.href = ad.cta_url;
        link.target = '_blank';
        link.rel = 'nofollow noopener';
        link.setAttribute('data-ad-clickable', '1');
        var img = document.createElement('img');
        img.className = 'sponsor-card-image';
        img.src = mediaUrl;
        img.loading = 'lazy';
        var alt = ad.owner_fullname || (ad.owner_username ? '@' + ad.owner_username : (ad.title || 'Advertisement'));
        img.alt = alt;
        link.appendChild(img);
        mediaHost.appendChild(link);
      }
    }

    var titleEl = card.querySelector('.sponsor-card-title');
    if (titleEl) {
      titleEl.textContent = ad.title || ad.owner_fullname || (ad.owner_username ? '@' + ad.owner_username : '');
      titleEl.href = ad.cta_url;
    }

    var descEl = card.querySelector('.sponsor-card-description');
    if (descEl) {
      if (ad.description) {
        descEl.textContent = ad.description;
        descEl.style.display = '';
      } else {
        descEl.textContent = '';
        descEl.style.display = 'none';
      }
    }

    var badgeEl = card.querySelector('.sponsor-card-badge');
    if (badgeEl && ad.sponsored_label) {
      badgeEl.textContent = ad.sponsored_label;
    }

    var ctaEl = card.querySelector('.sponsor-card-cta');
    if (ctaEl) {
      ctaEl.textContent = ad.cta_label || '';
      ctaEl.href = ad.cta_url;
    }

    return card;
  }

  function fetchSidebarAds(wrapper) {
    if (state.busySidebar) { return; }
    state.busySidebar = true;
    var payload = {
      p: 'ads_feed_sidebar',
      limit: 3,
      csrf_token: getCsrfToken()
    };
    if (state.shownIds.length) {
      payload.exclude = state.shownIds.join(',');
    }
    postRequest(payload).then(function (res) {
      if (!res || res.status !== 'success' || !Array.isArray(res.ads)) { return; }
      res.ads.forEach(function (ad) {
        if (!ad || hasShown(ad.ad_id)) { return; }
        var card = renderSidebarCard(ad);
        if (!card) { return; }
        wrapper.appendChild(card);
        registerElement(card);
      });
    }, function () {
      // silent failure
    }).then(function () {
      state.busySidebar = false;
    });
  }

  function initSidebar() {
    var container = document.querySelector('.content-right-container');
    if (!container) { return; }
    var cardsWrapper = container.querySelector('#sponsor-sidebar-cards') || container.querySelector('#ads-sidebar-cards');
    if (!cardsWrapper) { return; }

    var initialCards = cardsWrapper.querySelectorAll('.sponsor-card[data-ad-id], .ads-card[data-ad-id]');
    for (var i = 0; i < initialCards.length; i += 1) {
      registerElement(initialCards[i]);
    }

    ensureObserver();
    fetchSidebarAds(cardsWrapper);
  }

  function registerAds(root) {
    if (!root) { return; }
    var elements = root.querySelectorAll ? root.querySelectorAll('.sponsor-sponsored[data-ad-id], .ads-sponsored[data-ad-id]') : [];
    for (var i = 0; i < elements.length; i += 1) {
      registerElement(elements[i]);
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    ensureObserver();
    initSidebar();
  });

  window.AdsFeedSlots = {
    registerAds: registerAds,
    getShownAdIds: function () { return state.shownIds.slice(); },
    markShown: function (ids) {
      if (!ids || !ids.length) { return; }
      for (var i = 0; i < ids.length; i += 1) {
        var id = parseInt(ids[i], 10);
        if (id > 0) { addShown(id); }
      }
    }
  };
})(window, document);
