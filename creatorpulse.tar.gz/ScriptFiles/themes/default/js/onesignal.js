'use strict';
(function(){
  var configEl = document.getElementById('dz-onesignal-config');
  if (!configEl) { return; }
  var raw = configEl.textContent || configEl.innerText || '';
  if (!raw) { return; }
  var config;
  try {
    config = JSON.parse(raw);
  } catch (_) {
    return;
  }
  if (!config || !config.enabled || !config.active || !config.appId) {
    return;
  }

  var notifyPref = config.notifyPush;
  var autoPrompt = !!config.autoPrompt;
  if (typeof notifyPref === 'boolean' && !notifyPref) {
    autoPrompt = false;
  }

  window.OneSignal = window.OneSignal || [];
  var OneSignal = window.OneSignal;

  var userInfo = config.user || {};
  var externalId = '';
  if (userInfo && Object.prototype.hasOwnProperty.call(userInfo, 'id')) {
    if (typeof userInfo.id === 'number' && userInfo.id > 0) {
      externalId = String(userInfo.id);
    } else if (userInfo.id) {
      externalId = String(userInfo.id);
    }
  }
  var username = '';
  if (userInfo && userInfo.username) {
    username = String(userInfo.username);
  }

  var api = window.DZOneSignal = window.DZOneSignal || {};
  api.prompt = function(){
    try {
      if (OneSignal && OneSignal.Slidedown && typeof OneSignal.Slidedown.promptPush === 'function') {
        OneSignal.Slidedown.promptPush();
      } else if (OneSignal && typeof OneSignal.showSlidedownPrompt === 'function') {
        OneSignal.showSlidedownPrompt();
      }
    } catch (_) {}
  };
  api.autoPrompt = autoPrompt;
  api.config = config;

  function runInit(){
    var options = {
      appId: config.appId,
      promptOptions: {
        slidedown: {
          enabled: autoPrompt
        }
      }
    };
    if (config.safariWebId) {
      options.safari_web_id = config.safariWebId;
    }

    try {
      if (typeof OneSignal.init === 'function') {
        OneSignal.init(options);
      } else if (typeof OneSignal.initialize === 'function') {
        OneSignal.initialize(options);
      } else {
        return;
      }
    } catch (_) {
      return;
    }

    if (config.welcomeTitle || config.welcomeMessage) {
      try {
        OneSignal.Slidedown = OneSignal.Slidedown || {};
        if (!OneSignal.Slidedown.options) {
          OneSignal.Slidedown.options = {};
        }
        OneSignal.Slidedown.options.welcome = OneSignal.Slidedown.options.welcome || {};
        if (config.welcomeTitle) {
          OneSignal.Slidedown.options.welcome.title = String(config.welcomeTitle);
        }
        if (config.welcomeMessage) {
          OneSignal.Slidedown.options.welcome.message = String(config.welcomeMessage);
        }
      } catch (_) {}
    }

    if (externalId) {
      try { OneSignal.login(externalId); } catch (_) {}
      try { OneSignal.sendTag('uid', externalId); } catch (_) {}
      if (username) {
        try { OneSignal.sendTag('username', username); } catch (_) {}
      }
    }
  }

  OneSignal.push(runInit);
})();
