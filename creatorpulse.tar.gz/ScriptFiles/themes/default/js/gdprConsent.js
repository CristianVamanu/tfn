'use strict';

(function () {
  var STORAGE_KEY = 'gdprConsentState';
  var COOKIE_KEY = 'gdprConsentState';
  var ALLOW_DAYS = 365;
  var DISMISS_DAYS = 1;
  var DEFAULT_PREFERENCES = {
    necessary: true,
    analytics: false,
    marketing: false
  };

  function storageAvailable() {
    try {
      if (!('localStorage' in window)) {
        return false;
      }
      var testKey = '__gdpr_test__';
      window.localStorage.setItem(testKey, '1');
      window.localStorage.removeItem(testKey);
      return true;
    } catch (_) {
      return false;
    }
  }

  var canUseStorage = storageAvailable();

  function readCookie(name) {
    try {
      var cookies = document.cookie ? document.cookie.split(';') : [];
      for (var i = 0; i < cookies.length; i++) {
        var part = cookies[i].trim();
        if (part.indexOf(name + '=') === 0) {
          return decodeURIComponent(part.substring(name.length + 1));
        }
      }
    } catch (_) {
    }
    return null;
  }

  function writeCookie(name, value, days) {
    try {
      var expires = '';
      if (typeof days === 'number') {
        var date = new Date();
        date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
        expires = ';expires=' + date.toUTCString();
      }
      document.cookie = name + '=' + encodeURIComponent(value) + expires + ';path=/';
    } catch (_) {
    }
  }

  function clearPersistence() {
    try {
      if (canUseStorage) {
        window.localStorage.removeItem(STORAGE_KEY);
      }
    } catch (_) {
    }
    writeCookie(COOKIE_KEY, '', -1);
  }

  function normalizePreferences(raw) {
    var prefs = {
      necessary: true,
      analytics: false,
      marketing: false
    };

    if (raw && typeof raw === 'object') {
      if (typeof raw.analytics === 'boolean') {
        prefs.analytics = raw.analytics;
      }
      if (typeof raw.marketing === 'boolean') {
        prefs.marketing = raw.marketing;
      }
    }

    return prefs;
  }

  function persistConsent(type, days, preferences) {
    var now = Date.now();
    var expiresAt = now + days * 24 * 60 * 60 * 1000;
    var payload = {
      type: type,
      expires: expiresAt
    };

    if (preferences) {
      payload.preferences = normalizePreferences(preferences);
    }

    var serialized = JSON.stringify(payload);

    if (canUseStorage) {
      try {
        window.localStorage.setItem(STORAGE_KEY, serialized);
      } catch (_) {
      }
    }

    writeCookie(COOKIE_KEY, serialized, days);
  }

  function readConsent() {
    var raw = null;

    if (canUseStorage) {
      try {
        raw = window.localStorage.getItem(STORAGE_KEY);
      } catch (_) {
      }
    }

    if (!raw) {
      raw = readCookie(COOKIE_KEY);
    }

    if (!raw) {
      return null;
    }

    try {
      return JSON.parse(raw);
    } catch (_) {
      return null;
    }
  }

  function shouldShowBanner() {
    var state = readConsent();
    if (!state || typeof state.expires !== 'number') {
      return true;
    }
    var now = Date.now();
    if (now >= state.expires) {
      clearPersistence();
      return true;
    }
    return false;
  }

  function hideBanner(banner) {
    if (!banner) {
      return;
    }
    banner.classList.remove('gdpr-banner--visible');
    window.setTimeout(function () {
      banner.setAttribute('hidden', '');
    }, 220);
  }

  function showSettings(settings) {
    if (!settings) {
      return;
    }
    settings.removeAttribute('hidden');
    window.requestAnimationFrame(function () {
      settings.classList.add('gdpr-settings--visible');
    });
  }

  function closeSettings(settings) {
    if (!settings) {
      return;
    }
    settings.classList.remove('gdpr-settings--visible');
    window.setTimeout(function () {
      settings.setAttribute('hidden', '');
    }, 220);
  }

  function applyPreferencesToUI(settings, preferences) {
    if (!settings) {
      return;
    }
    var prefs = normalizePreferences(preferences);
    var toggles = settings.querySelectorAll('[data-gdpr-toggle]');
    for (var i = 0; i < toggles.length; i++) {
      var toggle = toggles[i];
      var key = toggle.getAttribute('data-gdpr-toggle');
      if (key === 'necessary') {
        toggle.checked = true;
        continue;
      }
      if (Object.prototype.hasOwnProperty.call(prefs, key)) {
        toggle.checked = prefs[key];
      }
    }
  }

  function collectPreferencesFromUI(settings) {
    var prefs = normalizePreferences(null);
    if (!settings) {
      return prefs;
    }
    var toggles = settings.querySelectorAll('[data-gdpr-toggle]');
    for (var i = 0; i < toggles.length; i++) {
      var toggle = toggles[i];
      var key = toggle.getAttribute('data-gdpr-toggle');
      if (key === 'necessary') {
        continue;
      }
      prefs[key] = toggle.checked === true;
    }
    return prefs;
  }

  function resolvePreferences(state) {
    if (state && state.preferences) {
      return state.preferences;
    }
    if (state && state.type === 'allow') {
      return {
        necessary: true,
        analytics: true,
        marketing: true
      };
    }
    if (state && state.type === 'deny') {
      return {
        necessary: true,
        analytics: false,
        marketing: false
      };
    }
    return DEFAULT_PREFERENCES;
  }

  function handleAcceptAll(banner, settings) {
    var prefs = {
      necessary: true,
      analytics: true,
      marketing: true
    };
    persistConsent('allow', ALLOW_DAYS, prefs);
    hideBanner(banner);
    closeSettings(settings);
  }

  function handleRejectAll(banner, settings) {
    var prefs = {
      necessary: true,
      analytics: false,
      marketing: false
    };
    persistConsent('deny', ALLOW_DAYS, prefs);
    hideBanner(banner);
    closeSettings(settings);
  }

  function handleSavePreferences(banner, settings) {
    var prefs = collectPreferencesFromUI(settings);
    persistConsent('custom', ALLOW_DAYS, prefs);
    hideBanner(banner);
    closeSettings(settings);
  }

  function handleDismiss(banner) {
    persistConsent('dismiss', DISMISS_DAYS);
    hideBanner(banner);
  }

  function init() {
    var banner = document.querySelector('[data-gdpr-banner]');
    if (!banner) {
      return;
    }

    if (!shouldShowBanner()) {
      return;
    }

    var settings = document.querySelector('[data-gdpr-settings]');

    banner.removeAttribute('hidden');
    window.requestAnimationFrame(function () {
      banner.classList.add('gdpr-banner--visible');
    });

    var acceptButtons = document.querySelectorAll('[data-gdpr-accept]');
    for (var i = 0; i < acceptButtons.length; i++) {
      var btn = acceptButtons[i];
      btn.addEventListener('click', function () {
        handleAcceptAll(banner, settings);
      });
    }

    var manageBtn = banner.querySelector('[data-gdpr-manage]');
    if (manageBtn) {
      manageBtn.addEventListener('click', function () {
        if (!settings) {
          handleDismiss(banner);
          return;
        }
        var state = readConsent();
        applyPreferencesToUI(settings, resolvePreferences(state));
        showSettings(settings);
      });
    }

    if (settings) {
      var rejectBtn = settings.querySelector('[data-gdpr-reject]');
      if (rejectBtn) {
        rejectBtn.addEventListener('click', function () {
          handleRejectAll(banner, settings);
        });
      }

      var saveBtn = settings.querySelector('[data-gdpr-save]');
      if (saveBtn) {
        saveBtn.addEventListener('click', function () {
          handleSavePreferences(banner, settings);
        });
      }

      var closeButtons = settings.querySelectorAll('[data-gdpr-settings-close]');
      for (var j = 0; j < closeButtons.length; j++) {
        var closeBtn = closeButtons[j];
        closeBtn.addEventListener('click', function () {
          closeSettings(settings);
        });
      }

      document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && settings.classList.contains('gdpr-settings--visible')) {
          event.preventDefault();
          closeSettings(settings);
        }
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
}());
