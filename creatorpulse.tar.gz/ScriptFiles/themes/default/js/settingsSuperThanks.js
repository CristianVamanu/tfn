(function(){
  'use strict';

  function onReady(fn) {
    if (document.readyState !== 'loading') {
      fn();
    } else {
      document.addEventListener('DOMContentLoaded', fn);
    }
  }

  function parseJsonAttr(el, attr) {
    if (!el) { return null; }
    var raw = el.getAttribute(attr);
    if (!raw) { return null; }
    try {
      return JSON.parse(raw);
    } catch (err) {
      if (window.DZ_DEBUG) {
        console.warn('settingsSuperThanks: failed to parse', attr, err);
      }
      return null;
    }
  }

  function toggleFallback(canvas, success) {
    if (!canvas) { return; }
    var fb = canvas.nextElementSibling;
    if (!fb || !fb.classList || !fb.classList.contains('chart-fallback')) { return; }
    if (success) {
      fb.classList.add('is-hidden');
    } else {
      fb.classList.remove('is-hidden');
    }
  }

  function buildCurrencyFormatter() {
    var cfg = (window.DZ && window.DZ.currencyFormat) || {};
    var code = (cfg.code || 'USD').toString().toUpperCase();
    var symbol = (cfg.symbol || '').toString();
    var decimalSep = cfg.decimalSep === ',' ? ',' : '.';
    var thousandsSep = typeof cfg.thousandsSep === 'string' ? cfg.thousandsSep : ',';
    var basePrecision = typeof cfg.decimalPlaces === 'number' ? cfg.decimalPlaces : 2;

    return function formatCurrency(amount) {
      if (window.DZ && typeof window.DZ.formatCurrency === 'function') {
        return window.DZ.formatCurrency(amount, code, symbol);
      }
      var numeric = Number(amount);
      if (!isFinite(numeric)) { numeric = 0; }
      var precision = Math.min(Math.max(0, basePrecision), 8);
      var fixed = numeric.toFixed(precision);
      var parts = fixed.split('.');
      if (thousandsSep) {
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandsSep);
      }
      var joined = parts.length > 1 ? parts[0] + decimalSep + parts[1] : parts[0];
      if (symbol && symbol !== code && symbol.length <= 4) {
        return symbol + (symbol === '$' ? '' : ' ') + joined;
      }
      return joined + ' ' + code;
    };
  }

  onReady(function(){
    var canvas = document.getElementById('settingsEarningsChart');
    if (!canvas || typeof Chart === 'undefined') { return; }

    var labels = parseJsonAttr(canvas, 'data-labels') || [];
    var weekly = parseJsonAttr(canvas, 'data-weekly') || [];
    var monthly = parseJsonAttr(canvas, 'data-monthly') || [];
    var weeklyLabel = canvas.getAttribute('data-weekly-label') || 'Weekly earnings';
    var monthlyLabel = canvas.getAttribute('data-monthly-label') || 'Rolling 30-day earnings';

    var datasetLength = Math.min(labels.length, weekly.length, monthly.length);
    if (!datasetLength) {
      toggleFallback(canvas, false);
      return;
    }

    labels = labels.slice(0, datasetLength);
    weekly = weekly.slice(0, datasetLength);
    monthly = monthly.slice(0, datasetLength);

    var ctx = canvas.getContext('2d');

    var formatCurrency = buildCurrencyFormatter();

    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: weeklyLabel,
            data: weekly,
            backgroundColor: 'rgba(31,75,216,0.25)',
            borderColor: '#1f4bd8',
            borderWidth: 1,
            borderRadius: 8,
            borderSkipped: false,
            maxBarThickness: 28
          },
          {
            label: monthlyLabel,
            data: monthly,
            backgroundColor: 'rgba(36,184,199,0.25)',
            borderColor: '#24b8c7',
            borderWidth: 1,
            borderRadius: 8,
            borderSkipped: false,
            maxBarThickness: 28
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { display: true, position: 'bottom' },
          tooltip: {
            callbacks: {
              label: function(context) {
                var label = context.dataset.label || '';
                var value = context.parsed.y;
                if (typeof value === 'number') {
                  var formatted = formatCurrency(value);
                  return label ? (label + ': ' + formatted) : formatted;
                }
                return label ? (label + ': ' + value) : value;
              }
            }
          }
        },
        scales: {
          x: {
            grid: { display: false }
          },
          y: {
            beginAtZero: true,
            grid: { color: 'rgba(0,0,0,0.06)' },
            ticks: {
              callback: function(value) {
                return typeof value === 'number' ? formatCurrency(value) : value;
              }
            }
          }
        }
      }
    });

    toggleFallback(canvas, true);
  });
})();
