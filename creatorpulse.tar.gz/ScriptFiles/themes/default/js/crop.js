(function (global) {
  if (global.__DIZZY_CROP_INITED__) {
    return;
  }
  global.__DIZZY_CROP_INITED__ = true;

  'use strict';
  var buildUrl = (window.DZ && window.DZ.buildUrl) || function(path){
    try { var base=(typeof window.site_url==='string'&&window.site_url)?window.site_url:(window.location.origin+window.location.pathname.replace(/[^\/]*$/,'')); if(base.slice(-1)!=='/') base+='/'; return new URL(String(path||'').replace(/^\//,''), base).toString(); } catch(_) { return String(path||''); }
  };
  /**
   * Dizzy – Crop & Upload Module (Popup)
   * ------------------------------------------------------------
   * Purpose: Client-side cropping, filters, and upload pipeline
   * Author : mstfoztrk (Envato-ready formatting)
   * Notes  :
   *  - Wrapped in a singleton guard to avoid duplicate execution when popup reloads the script
   *  - Uses delegated events (jQuery) per Envato reviewer expectations
   *  - All functions documented with JSDoc for readability & IDE intellisense
   */

  // ============================================================
  // #region Constants & Module State
  // ============================================================
  let currentIndex = 0;
  let isOpen = false;
  const appliedFilters = {};

  // Cache last known crop-frame size (needed when frame is hidden at upload time)
  let __lastFrameW = 0;
  let __lastFrameH = 0;
  // #endregion

  // ============================================================
  // #region Utilities (Filters, Canvas, Toast, Loader)
  // ============================================================
  /**
   * Map internal filter keys to valid CSS filter strings for canvas and preview.
   * @param {string} name
   * @returns {string}
   */
  function getCssFilterForName(name) {
    switch (name) {
      case 'moon':
        return 'grayscale(100%) contrast(1.1)';
      case 'gingham':
        return 'grayscale(100%) brightness(1.1)';
      case 'reyes':
        return 'brightness(1.1) contrast(0.85)';
      case 'sepia':
        return 'grayscale(100%) sepia(1)';
      case 'invert':
        return 'invert(1)';
      case 'brighten':
        return 'brightness(1.2)';
      case 'contrast':
        return 'contrast(1.5)';
      default:
        return 'none';
    }
  }

  /**
   * Convert a canvas to PNG Blob with a safe fallback for older browsers.
   * @param {HTMLCanvasElement} canvas
   * @param {(blob: Blob|null)=>void} cb
   */
  function canvasToBlobPNG(canvas, cb) {
    if (canvas && typeof canvas.toBlob === 'function') {
      canvas.toBlob(function (blob) {
        cb(blob);
      }, 'image/png');
    } else {
      // Fallback polyfill using toDataURL
      try {
        var dataURL = canvas.toDataURL('image/png');
        var parts = dataURL.split(',');
        var byteString = atob(parts[1]);
        var ab = new ArrayBuffer(byteString.length);
        var ia = new Uint8Array(ab);
        for (var i = 0; i < byteString.length; i++) ia[i] = byteString.charCodeAt(i);
        cb(new Blob([ab], { type: 'image/png' }));
      } catch (e) {
        cb(null);
      }
    }
  }

  /**
   * Show a temporary toast-like popup message.
   * @param {string} message
   * @param {number} [duration=5000]
   */
  function showTempPopup(message, duration) {
    duration = typeof duration === 'number' ? duration : 5000;
    var toast = document.createElement('div');
    toast.className = 'dizzy-temp-toast';
    toast.textContent = message;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'polite');
    toast.style.position = 'fixed';
    toast.style.left = '50%';
    toast.style.bottom = '24px';
    toast.style.transform = 'translateX(-50%)';
    toast.style.maxWidth = '90%';
    toast.style.zIndex = '99999';
    toast.style.background = 'rgba(0,0,0,0.85)';
    toast.style.color = '#fff';
    toast.style.padding = '10px 14px';
    toast.style.borderRadius = '8px';
    toast.style.fontSize = '14px';
    toast.style.lineHeight = '1.4';
    toast.style.boxShadow = '0 4px 16px rgba(0,0,0,0.25)';
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 200ms ease';
    document.body.appendChild(toast);
    requestAnimationFrame(function () { toast.style.opacity = '1'; });
    setTimeout(function () {
      toast.style.opacity = '0';
      setTimeout(function () {
        if (toast && toast.parentNode) toast.parentNode.removeChild(toast);
      }, 250);
    }, duration);
  }

  /**
   * Ensure a single loading overlay exists inside the popup wrapper.
   * @param {string} [message]
   * @returns {JQuery}
   */
  function ensureLoading(message) {
    var $wrapper = $('.popUp-container .popup-wrapper').first();
    var $fallbackPopup = $('.popUp-container').first();
    var $loader = $('.loading-container').first();
    if (!$loader.length) {
      var html = '' +
        '<div class="loading-container absolute">' +
        '<div class="loader">' +
        '<div></div><div></div><div></div><div></div><div></div><div></div>' +
        '<div></div><div></div><div></div><div></div><div></div><div></div>' +
        '</div>' +
        '<p class="loading-text"></p>' +
        '</div>';
      var $node = $(html);
      $node.find('.loading-text').text(message || 'Please wait...');
      var $target = $wrapper.length ? $wrapper : ($fallbackPopup.length ? $fallbackPopup : $(document.body));
      if ($target.css('position') === 'static') { $target.css('position', 'relative'); }
      $target.append($node);
      $loader = $node;
    } else if (message) {
      $loader.find('.loading-text').text(message);
    }
    $loader.show();
    return $loader;
  }
  function removeLoading() { $('.loading-container').remove(); }
  // #endregion

  function ensureVisibilityNotice() {
    if (window.DZ && typeof window.DZ.openVisibilityNotice === 'function') {
      return window.DZ.openVisibilityNotice;
    }

    function escapeHtml(value) {
      return String(value == null ? '' : value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    }

    function closeVisibilityNotice() {
      var existing = document.querySelector('.popUp-container[data-modal="visibility-guard"]');
      if (existing && existing.parentNode) {
        existing.parentNode.removeChild(existing);
      }
    }

    function openVisibilityNotice(options) {
      var opts = options || {};
      closeVisibilityNotice();

      var modal = document.createElement('div');
      modal.className = 'popUp-container';
      modal.setAttribute('data-modal', 'visibility-guard');

      var i18n = (window.DZ && typeof window.DZ.i18n === 'function') ? window.DZ.i18n : function(){ return ''; };
      var defaultOk = i18n('ui_ok') || 'OK';
      var cancelLabel = opts.cancelLabel || i18n('menu_cancel') || 'Cancel';
      var confirmLabel = opts.confirmLabel || defaultOk;
      var title = opts.title ? escapeHtml(opts.title) : '';
      var message = escapeHtml(opts.message || '');

      var html = '<div class="pm-sheet-container"><div class="pm-sheet" role="dialog" aria-modal="true">';
      if (title) {
        html += '<div class="pm-header flex align_items_justify_content full-width">' + title + '</div><div class="aud-sep"></div>';
      }
      html += '<div class="pm-message">' + message + '</div><div class="aud-sep"></div>';
      html += '<button type="button" class="pm-item pm-confirm">' + escapeHtml(confirmLabel) + '</button>';
      html += '</div>';
      html += '<button type="button" class="pm-cancel">' + escapeHtml(cancelLabel) + '</button>';
      html += '</div>';
      modal.innerHTML = html;

      modal.addEventListener('click', function (event) {
        var target = event.target;
        if (target.classList.contains('pm-confirm')) {
          closeVisibilityNotice();
          if (typeof opts.onConfirm === 'function') {
            if (opts.onConfirm() === false) {
              return;
            }
          } else if (opts.redirectUrl) {
            window.location.href = opts.redirectUrl;
            return;
          }
          if (opts.redirectUrl) {
            window.location.href = opts.redirectUrl;
          }
          return;
        }
        if (target.classList.contains('pm-cancel') || target === modal) {
          closeVisibilityNotice();
        }
      });

      document.body.appendChild(modal);
      return modal;
    }

    window.DZ = window.DZ || {};
    window.DZ.openVisibilityNotice = openVisibilityNotice;
    window.DZ.closeVisibilityNotice = closeVisibilityNotice;
    return openVisibilityNotice;
  }

  const openVisibilityNotice = ensureVisibilityNotice();

  function parseGuardBool(value) {
    if (typeof value === 'boolean') {
      return value;
    }
    if (typeof value === 'number') {
      return value === 1;
    }
    if (typeof value === 'string') {
      var normalized = value.trim().toLowerCase();
      return normalized === '1' || normalized === 'true' || normalized === 'yes';
    }
    return false;
  }

  function getVisibilityContext($source) {
    if (!$source || !$source.length) {
      return null;
    }
    var $root = $source.closest('.popUp-container');
    if (!$root.length) {
      return null;
    }
    var data = $root.data() || {};
    return {
      isCreator: typeof data.isCreator !== 'undefined' ? parseGuardBool(data.isCreator) : true,
      paymentsActive: typeof data.paymentsActive !== 'undefined' ? parseGuardBool(data.paymentsActive) : true,
      hasCreatorFlag: typeof data.isCreator !== 'undefined',
      hasPaymentsFlag: typeof data.paymentsActive !== 'undefined',
      creatorUrl: data.creatorUrl || '',
      creatorMessage: data.creatorMessage || '',
      creatorAction: data.creatorAction || '',
      paymentsMessage: data.paymentsMessage || '',
      paymentsAction: data.paymentsAction || '',
      cancelLabel: data.guardCancel || ''
    };
  }

  function handleVisibilityAccess($item, type) {
    if (type !== 'subscribers' && type !== 'locked') {
      return true;
    }
    var context = getVisibilityContext($item);
    if (!context) {
      return true;
    }
    var i18n = (window.DZ && typeof window.DZ.i18n === 'function') ? window.DZ.i18n : function(){ return ''; };
    var cancelLabel = context.cancelLabel || i18n('menu_cancel') || 'Cancel';
    if (context.hasCreatorFlag && !context.isCreator) {
      openVisibilityNotice({
        message: context.creatorMessage || (i18n('post_visibility_creator_required') || 'Only approved creators can share subscriber or paywalled posts. Become a creator to unlock these options.'),
        confirmLabel: context.creatorAction || (i18n('post_visibility_open_creator') || i18n('creator_identity_title') || 'Become a creator'),
        cancelLabel: cancelLabel,
        onConfirm: function () {
          if (context.creatorUrl) {
            window.location.href = context.creatorUrl;
          }
        }
      });
      return false;
    }
    if (context.hasPaymentsFlag && !context.paymentsActive) {
      openVisibilityNotice({
        message: context.paymentsMessage || (i18n('post_visibility_payments_disabled') || 'Payment methods are currently being improved. Please try again later.'),
        confirmLabel: context.paymentsAction || (i18n('ui_ok') || 'OK'),
        cancelLabel: cancelLabel
      });
      return false;
    }
    return true;
  }

  // ============================================================
  // #region Step Management (select -> crop -> finish)
  // ============================================================
  // View step controller: 'select' (pick files) -> 'crop' (edit) -> 'finish' (post)
  let currentStep = 'select';

  /**
   * Control visible panels (selection/crop/finish) and header buttons.
   * @param {'select'|'crop'|'finish'} step
   */
  function setStep(step) {
    currentStep = step;

    const $createBox = $('.create_media_box, .crop_media_box');
    const $cropContainer = $('.crop-container');
    const $finishBox = $('.crop-finish-and-post');
    const $goNext = $('#goNext');
    const $goBack = $('#goBack');
    const $uploadBtn = $('#uploadBtn');

    if (step === 'select') {
      $createBox.removeClass('none').addClass('d-flex');
      $cropContainer.addClass('none').removeClass('d-flex');
      if ($finishBox) $finishBox.addClass('none').removeClass('d-flex');
      $goNext.addClass('none');
      $goBack.addClass('none');
      $uploadBtn.addClass('none');
    } else if (step === 'crop') {
      $createBox.addClass('none').removeClass('d-flex');
      $cropContainer.removeClass('none').addClass('d-flex');
      __lastFrameW = $('.crop-frame').outerWidth() || __lastFrameW;
      __lastFrameH = $('.crop-frame').outerHeight() || __lastFrameH;
      if ($finishBox) $finishBox.addClass('none').removeClass('d-flex');
      $goNext.removeClass('none');
      $goBack.addClass('none');
      $uploadBtn.addClass('none');
    } else if (step === 'finish') {
      $createBox.addClass('none').removeClass('d-flex');
      $cropContainer.addClass('none').removeClass('d-flex');
      if ($finishBox) $finishBox.removeClass('none').addClass('d-flex');
      __lastFrameW = $('.crop-frame').outerWidth() || __lastFrameW;
      __lastFrameH = $('.crop-frame').outerHeight() || __lastFrameH;
      $goNext.addClass('none');
      $goBack.removeClass('none');
      $uploadBtn.removeClass('none');
    }
  }
  // #endregion

  // ============================================================
  // #region Navigation UI (prev/next)
  // ============================================================
  let totalImages = $('.crop-image').length;
  function updateNavButtons() {
    totalImages = $('.crop-image').length;
    const $prev = $('#prev');
    const $next = $('#next');
    if (totalImages <= 1) { $prev.hide(); $next.hide(); return; }
    if (currentIndex <= 0) { $prev.hide(); $next.show(); }
    else if (currentIndex >= totalImages - 1) { $prev.show(); $next.hide(); }
    else { $prev.show(); $next.show(); }
  }
  // #endregion

  // ============================================================
  // #region Image Sizing & State Init
  // ============================================================
  /** Initialize dataset & CSS to best-fit each image in the crop frame. */
  function initImageDataAttributes() {
    $('.crop-image img').each(function () {
      const $img = $(this);
      // Skip images that were already initialized to preserve user adjustments
      if ($img.attr('data-initialized') === '1') { return; }
      const frameWidth = $('.crop-frame').width();
      const frameHeight = $('.crop-frame').height();
      const imgEl = $img.get(0);
      if (!imgEl) return;
      if (!(imgEl.complete && imgEl.naturalWidth > 0 && imgEl.naturalHeight > 0)) return;

      const imgWidth = imgEl.naturalWidth;
      const imgHeight = imgEl.naturalHeight;
      const scaleX = frameWidth / imgWidth;
      const scaleY = frameHeight / imgHeight;
      const scale = Math.max(scaleX, scaleY);
      const newWidth = imgWidth * scale;
      const newHeight = imgHeight * scale;
      const offsetX = Math.round((frameWidth - newWidth) / 2);
      const offsetY = Math.round((frameHeight - newHeight) / 2);

      $img.css({ width: newWidth + 'px', height: newHeight + 'px', left: offsetX + 'px', top: offsetY + 'px', transform: 'scale(1)'

      });

      $img.attr('data-base-scale', scale);
      $img.attr('data-zoom', 1);
      $img.attr('data-left', offsetX);
      $img.attr('data-top', offsetY);

      // initial & previous state
      $img.attr('data-init-left', offsetX);
      $img.attr('data-init-top', offsetY);
      $img.attr('data-init-zoom', 1);
      $img.attr('data-init-base-scale', scale);
      $img.attr('data-prev-left', offsetX);
      $img.attr('data-prev-top', offsetY);
      $img.attr('data-prev-zoom', 1);
      $img.attr('data-prev-base-scale', scale);
      $img.attr('data-initialized', '1');
    });
  }

  /** Show image by index and sync its saved transform/zoom/position. */
  function showImage(index) {
    if ($('.crop-image').length === 0) return;
    $('.crop-image').hide().eq(index).show();
    const $currentImg = $('.crop-image').eq(index).find('img');
    if ($currentImg.length === 0) return;

    const imgEl = $currentImg.get(0);
    if (!imgEl || !(imgEl.naturalWidth > 0 && imgEl.naturalHeight > 0)) return;

    const naturalWidth = imgEl.naturalWidth;
    const naturalHeight = imgEl.naturalHeight;

    let baseScale = parseFloat($currentImg.attr('data-base-scale'));
    let zoom = parseFloat($currentImg.attr('data-zoom'));
    let left = parseFloat($currentImg.attr('data-left'));
    let top = parseFloat($currentImg.attr('data-top'));
    const hasState = !isNaN(baseScale) && !isNaN(zoom) && !isNaN(left) && !isNaN(top);

    if (!hasState) {
      fitImageToFrame($currentImg);
      baseScale = parseFloat($currentImg.attr('data-base-scale')) || 1;
      zoom = 1; left = parseFloat($currentImg.css('left')) || 0; top = parseFloat($currentImg.css('top')) || 0;
      $currentImg.attr('data-zoom', zoom);
      $currentImg.attr('data-left', left);
      $currentImg.attr('data-top', top);
    }

    const newWidth = naturalWidth * baseScale * zoom;
    const newHeight = naturalHeight * baseScale * zoom;

    $currentImg.css({ width: newWidth + 'px', height: newHeight + 'px', left: left + 'px', top: top + 'px', transform: 'scale(1)' });
    $('#zoom').val(zoom);
    enforceBoundaries($currentImg);
  }

  /** Compute best-fit cover sizing and center the image in the frame. */
  function fitImageToFrame($img) {
    if (!$img || $img.length === 0) return;
    const frameWidth = $('.crop-frame').width();
    const frameHeight = $('.crop-frame').height();
    const imgEl = $img.get(0);
    if (!imgEl || !(imgEl.naturalWidth > 0 && imgEl.naturalHeight > 0)) return;

    const imgWidth = imgEl.naturalWidth;
    const imgHeight = imgEl.naturalHeight;
    const scaleX = frameWidth / imgWidth;
    const scaleY = frameHeight / imgHeight;
    const scale = Math.max(scaleX, scaleY);
    const newWidth = imgWidth * scale;
    const newHeight = imgHeight * scale;
    const offsetX = Math.round((frameWidth - newWidth) / 2);
    const offsetY = Math.round((frameHeight - newHeight) / 2);

    $img.attr('data-natural-width', imgWidth);
    $img.attr('data-natural-height', imgHeight);
    $img.css({ width: newWidth + 'px', height: newHeight + 'px', left: offsetX + 'px', top: offsetY + 'px' });
    $img.attr('data-base-scale', scale);
  }

  /** Keep the image within the crop frame bounds; update state attrs. */
  function enforceBoundaries($img) {
    if (!$img || $img.length === 0) return;
    const frame = document.querySelector('.crop-frame');
    if (!frame) return;
    const frameRect = frame.getBoundingClientRect();
    const el = $img.get(0); if (!el) return;
    const imgRect = el.getBoundingClientRect();

    let left = parseFloat($img.css('left')) || 0;
    let top = parseFloat($img.css('top')) || 0;

    const overflowX = imgRect.width - frameRect.width;
    const overflowY = imgRect.height - frameRect.height;

    if (overflowX < 0) { left = (frameRect.width - imgRect.width) / 2; }
    else {
      if (imgRect.left > frameRect.left) { left -= imgRect.left - frameRect.left; }
      if (imgRect.right < frameRect.right) { left += frameRect.right - imgRect.right; }
    }

    if (overflowY < 0) { top = (frameRect.height - imgRect.height) / 2; }
    else {
      if (imgRect.top > frameRect.top) { top -= imgRect.top - frameRect.top; }
      if (imgRect.bottom < frameRect.bottom) { top += frameRect.bottom - imgRect.bottom; }
    }

    $img.css({ left: Math.round(left) + 'px', top: Math.round(top) + 'px' });
    $img.attr('data-left', Math.round(left));
    $img.attr('data-top', Math.round(top));
  }
  // #endregion

  // ============================================================
  // #region Swiper Integration (local fallback & helpers)
  // (Removed: All Swiper helper functions now handled centrally)
  // #endregion

  // ============================================================
  // #region Upload Pipeline (render → formdata → ajax → mount)
  // ============================================================
  /**
   * Attempt to parse a JSON payload that might include BOMs or stray markup.
   * @param {string|Object} payload
   * @returns {Object|null}
   */
  function parseJsonPayload(payload) {
    if (!payload) { return null; }
    if (typeof payload === 'object') { return payload; }
    if (typeof payload !== 'string') { return null; }

    var trimmed = String(payload).replace(/\uFEFF/g, '').trim();
    if (!trimmed) { return null; }

    var firstBrace = trimmed.indexOf('{');
    var firstBracket = trimmed.indexOf('[');
    var startIdx = -1;
    if (firstBrace !== -1 && firstBracket !== -1) {
      startIdx = Math.min(firstBrace, firstBracket);
    } else {
      startIdx = firstBrace !== -1 ? firstBrace : firstBracket;
    }
    if (startIdx > 0) {
      trimmed = trimmed.slice(startIdx);
    }

    var lastBrace = trimmed.lastIndexOf('}');
    var lastBracket = trimmed.lastIndexOf(']');
    var endIdx = Math.max(lastBrace, lastBracket);
    if (endIdx >= 0 && endIdx + 1 < trimmed.length) {
      trimmed = trimmed.slice(0, endIdx + 1);
    }

    try {
      return JSON.parse(trimmed);
    } catch (err) {
      var jsonMatch = trimmed.match(/\{[\s\S]*?"status"\s*:\s*"(?:success|error)"[\s\S]*?\}/i);
      if (jsonMatch) {
        try {
          return JSON.parse(jsonMatch[0]);
        } catch (innerErr) {
          return null;
        }
      }
      return null;
    }
  }

  /**
   * Normalize any payload (object or string) to a sane response structure.
   * Falls back to checking for rendered post markup if JSON is not available.
   * @param {Object|string} payload
   * @returns {{status:string, html?:string, message?:string}|null}
   */
  function normalizeUploadResponse(payload) {
    if (!payload) { return null; }
    if (typeof payload === 'object' && payload !== null) { return payload; }
    if (typeof payload !== 'string') { return null; }

    var trimmed = String(payload).replace(/\uFEFF/g, '').trim();
    if (!trimmed) { return null; }

    var parsed = parseJsonPayload(trimmed);
    if (parsed) { return parsed; }

    if (/status"\s*:\s*"success"/i.test(trimmed)) {
      parsed = parseJsonPayload(trimmed.replace(/^[\s\S]*?({[\s\S]*})[\s\S]*$/, '$1'));
      if (parsed) { return parsed; }
    }

    if (trimmed.indexOf('class="post_') !== -1 || trimmed.indexOf("class='post_") !== -1 || trimmed.indexOf('data-post-id=') !== -1) {
      try {
        var wrapper = document.createElement('div');
        var decoded = trimmed
          .replace(/\\n/g, '\n')
          .replace(/\\t/g, '\t')
          .replace(/\\r/g, '\r')
          .replace(/\\\//g, '/')
          .replace(/\\"/g, '"')
          .replace(/\\'/g, '\'');
        wrapper.innerHTML = decoded;
        var posts = wrapper.querySelectorAll('.post_');
        if (posts.length) {
          var collected = '';
          posts.forEach(function (node) {
            if (node && node.outerHTML) {
              collected += node.outerHTML;
            }
          });
          if (collected) {
            return { status: 'success', html: collected, message: '' };
          }
        }
      } catch (_) { /* ignore DOM parsing errors */ }
      return { status: 'success', html: trimmed, message: '' };
    }

    if (/Upload successful/i.test(trimmed)) {
      return { status: 'success', html: '', message: 'Upload successful.' };
    }

    return null;
  }

  function decodeBinaryString(binary) {
    if (typeof binary !== 'string') {
      return '';
    }
    if (typeof TextDecoder !== 'undefined') {
      var buffer = new Uint8Array(binary.length);
      for (var i = 0; i < binary.length; i++) {
        buffer[i] = binary.charCodeAt(i);
      }
      return new TextDecoder('utf-8').decode(buffer);
    }
    try {
      return decodeURIComponent(binary.split('').map(function (char) {
        var code = char.charCodeAt(0).toString(16);
        return '%' + (code.length < 2 ? '0' + code : code);
      }).join(''));
    } catch (_) {
      return binary;
    }
  }

  function decodeHtmlPayload(value, encoding) {
    if (typeof value !== 'string' || value === '') {
      return '';
    }
    if ((encoding || '').toLowerCase() !== 'base64') {
      return value;
    }
    var sanitized = value.replace(/\s+/g, '');
    var binary = null;
    try {
      if (typeof window !== 'undefined' && typeof window.atob === 'function') {
        binary = window.atob(sanitized);
      } else if (typeof atob === 'function') {
        binary = atob(sanitized);
      }
    } catch (_) {
      binary = null;
    }
    if (binary !== null) {
      return decodeBinaryString(binary);
    }
    if (typeof Buffer !== 'undefined') {
      try {
        return Buffer.from(sanitized, 'base64').toString('utf8');
      } catch (_) {}
    }
    return '';
  }

  /**
   * Handle AJAX success for cropped image upload.
   * @param {Object|string} res - Response from server (may be JSON or stringified JSON)
   */
  function handleUploadSuccess(res) {
    var rawResponse = res;
    res = normalizeUploadResponse(res);
    if (!res) {
      removeLoading();
      showTempPopup((window.DZ && DZ.i18n ? DZ.i18n('ui_unexpected_server_response_retry') : '') || 'Unexpected server response. Please try again.', 5000);
      return;
    }

    var status = typeof res.status === 'string' ? res.status.toLowerCase() : res.status;
    if (!res || status !== 'success') {
      removeLoading();
      showTempPopup(res && res.message ? res.message : ((window.DZ && DZ.i18n ? DZ.i18n('ui_request_failed_retry') : '') || 'Upload failed. Please try again.'), 5000);
      return;
    }

    removeLoading();

    var chunkHtml = '';
    var htmlEncoding = (typeof res.html_encoding === 'string') ? res.html_encoding : 'none';
    if (typeof res.html === 'string' && res.html.trim()) {
      var decoded = decodeHtmlPayload(res.html.trim(), htmlEncoding || 'none');
      if ((htmlEncoding || '').toLowerCase() === 'base64') {
        if (!decoded) {
          showTempPopup((window.DZ && DZ.i18n ? DZ.i18n('ui_unexpected_server_response_retry') : '') || 'Unexpected server response. Please try again.', 5000);
          return;
        }
        chunkHtml = decoded;
      } else {
        chunkHtml = decoded || res.html;
      }
    } else if (Array.isArray(res.html)) { chunkHtml = res.html.join(''); }

    if (!chunkHtml && rawResponse && typeof rawResponse === 'string') {
      var httpMatch = rawResponse.match(/https?:\/\/[^\s"'<>]+/i);
      if (httpMatch) {
        chunkHtml = '<div class="post_"><div class="post-media-single"><img src="' + httpMatch[0] + '" alt=""></div></div>';
      }
    }

    function sanitizeMediaUrls($root) {
      if (!$root || !$root.length) { return; }
      var ATTRS = ['src', 'href', 'poster', 'data-src', 'data-href', 'data-video', 'data-bg', 'data-source'];
      $root.find('[src], [href], [poster], [data-src], [data-href], [data-video], [data-bg], [data-source]').addBack('[src],[href],[poster],[data-src],[data-href],[data-video],[data-bg],[data-source]').each(function () {
        for (var i = 0; i < ATTRS.length; i++) {
          var attr = ATTRS[i];
          if (!this.hasAttribute(attr)) { continue; }
          var current = this.getAttribute(attr);
          if (!current) { continue; }
          var trimmed = current.trim();
          if (!trimmed) { continue; }
          var cleaned = trimmed.replace(/^['"]+/, '').replace(/['"]+$/, '');
          cleaned = cleaned.replace(/&quot;/gi, '"').replace(/&#34;/gi, '"').replace(/&#39;/gi, "'");
          cleaned = cleaned.replace(/^(https?:)\/{3,}/i, '$1//');
          var hostMatch = cleaned.match(/^(https?:\/\/[^\/?#]+)(\/.*)?$/i);
          if (hostMatch) {
            var base = hostMatch[1];
            var tail = hostMatch[2] || '';
            tail = tail.replace(/\/{2,}/g, '/');
            cleaned = base + tail;
          } else {
            if (cleaned.indexOf('//') === 0) {
              var rest = cleaned.slice(2).replace(/\/{2,}/g, '/');
              cleaned = '//' + rest;
            } else {
              cleaned = cleaned.replace(/\/{2,}/g, '/');
            }
          }
          if (cleaned !== current) {
            this.setAttribute(attr, cleaned);
          }
        }
      });
    }

    function forceInitSwipers(rootEl) {
      if (typeof Swiper !== 'function') {
        console.warn('[SwiperDebug] Swiper library not available.');
        return;
      }
      var selector = '.post-body .post-media-swiper';
      var $root = $(rootEl);
      var $nodes = $root.is(selector) ? $root : $root.find(selector);
      if (!$nodes.length) {
        console.warn('[SwiperDebug] No swiper containers found within new post.');
        return;
      }
      $nodes.each(function () {
        var container = this;
        try {
          if (container.swiper && typeof container.swiper.destroy === 'function') {
            container.swiper.destroy(true, true);
          }
        } catch (destroyErr) {
          console.warn('[SwiperDebug] Swiper destroy failed', destroyErr);
        }
        $(container)
          .removeData('swiperInstance')
          .removeData('swiperInited');
        try {
          container.classList.remove('swiper-initialized', 'swiper-horizontal', 'swiper-pointer-events');
        } catch (_) {}

        var slidesCount = $(container).find('.swiper-slide').length;
        var enableControls = slidesCount > 1;
        var paginationEl = $(container).find('.swiper-pagination').get(0);
        var nextEl = $(container).find('.swiper-button-next').get(0);
        var prevEl = $(container).find('.swiper-button-prev').get(0);
        var isRTL = (document.documentElement && String(document.documentElement.dir || '').toLowerCase() === 'rtl');
        if (isRTL) {
          container.setAttribute('dir', 'rtl');
        }
        try {
          var swiper = new Swiper(container, {
            slidesPerView: 1,
            spaceBetween: 8,
            loop: false,
            rtl: isRTL,
            rtlTranslate: isRTL,
            allowTouchMove: enableControls,
            watchSlidesProgress: true,
            speed: 400,
            observer: true,
            observeParents: true,
            resizeObserver: true,
            pagination: (enableControls && paginationEl)
              ? { el: paginationEl, clickable: true, dynamicBullets: true }
              : false,
            navigation: (enableControls && nextEl && prevEl)
              ? { nextEl: nextEl, prevEl: prevEl }
              : false,
            on: {
              init: function (sw) { sw.update(); },
              imagesReady: function (sw) { sw.update(); }
            }
          });
          $(container).data('swiperInstance', swiper);
          $(container).data('swiperInited', 1);
          if (!enableControls) {
            if (paginationEl) { $(paginationEl).hide(); }
            if (nextEl) { $(nextEl).hide(); }
            if (prevEl) { $(prevEl).hide(); }
          } else {
            if (paginationEl) { $(paginationEl).show(); }
            if (nextEl) { $(nextEl).show(); }
            if (prevEl) { $(prevEl).show(); }
          }
        } catch (_) {}
      });
    }

    function fallbackInitSwipers(root) {
      if (typeof Swiper !== 'function') { return; }
      var IS_RTL = (document.documentElement && String(document.documentElement.dir || '').toLowerCase() === 'rtl');
      var selector = ".post_ .post-body .post-media-swiper";
      var $root = root ? $(root) : $(document);
      var $nodes = $root.is(selector) ? $root : $root.find(selector);
      $nodes.each(function () {
        var $el = $(this);
        if ($el.data('swiperInited') === 1 || this.classList.contains('swiper-initialized')) { return; }
        var slidesCount = $el.find('.swiper-slide').length;
        var enableControls = slidesCount > 1;
        var paginationEl = $el.find('.swiper-pagination').get(0);
        var nextEl = $el.find('.swiper-button-next').get(0);
        var prevEl = $el.find('.swiper-button-prev').get(0);
        if (IS_RTL) { this.setAttribute('dir', 'rtl'); }
        try {
          var swiper = new Swiper(this, {
            slidesPerView: 1,
            spaceBetween: 8,
            loop: false,
            rtl: IS_RTL,
            rtlTranslate: IS_RTL,
            allowTouchMove: enableControls,
            watchSlidesProgress: true,
            speed: 400,
            observer: true,
            observeParents: true,
            resizeObserver: true,
            pagination: (enableControls && paginationEl)
              ? { el: paginationEl, clickable: true, dynamicBullets: true }
              : false,
            navigation: (enableControls && nextEl && prevEl)
              ? { nextEl: nextEl, prevEl: prevEl }
              : false,
            on: {
              init: function (sw) { sw.update(); },
              imagesReady: function (sw) { sw.update(); }
            }
          });
          $el.data('swiperInstance', swiper);
          $el.data('swiperInited', 1);
          if (!enableControls) {
            if (paginationEl) { $(paginationEl).hide(); }
            if (nextEl) { $(nextEl).hide(); }
            if (prevEl) { $(prevEl).hide(); }
          } else {
            if (paginationEl) { $(paginationEl).show(); }
            if (nextEl) { $(nextEl).show(); }
            if (prevEl) { $(prevEl).show(); }
          }
        } catch (err) {
          console.warn('Fallback Swiper init failed', err);
        }
      });
    }

    function reInitPostElements(rootEl) {
      if (!rootEl) { return; }
      var ranDZ = false;
      if (typeof window !== 'undefined' && window.DZ && typeof window.DZ.initPostSwipers === 'function') {
        try {
          window.DZ.initPostSwipers(rootEl);
          ranDZ = true;
        } catch (err) {
          console.warn('DZ.initPostSwipers failed', err);
        }
      }
      // Always schedule the generic posts:loaded event so the global initializer runs too.
      try {
        setTimeout(function () {
          $(document).trigger('posts:loaded', { root: rootEl });
        }, ranDZ ? 60 : 0);
      } catch (_) {
        // ignore
      }
      if (!ranDZ) {
        fallbackInitSwipers(rootEl);
      }
      forceInitSwipers(rootEl);
      if (typeof window !== 'undefined' && window.DZ && typeof window.DZ.initPostVideos === 'function') {
        try {
          window.DZ.initPostVideos(rootEl);
        } catch (e) {
          console.warn('DZ.initPostVideos failed', e);
        }
      }
    }

    if (chunkHtml) {
      chunkHtml = chunkHtml
        .replace(/\\n/g, '\n')
        .replace(/\\t/g, '\t')
        .replace(/\\r/g, '\r')
        .replace(/\\\//g, '/')
        .replace(/\\"/g, '"')
        .replace(/\\'/g, '\'');
      chunkHtml = chunkHtml.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    }

    var $chunk = chunkHtml ? $(chunkHtml) : $();
    if ($chunk.length) {
      sanitizeMediaUrls($chunk);
      var rebuilt = '';
      $chunk.each(function () {
        if (this.nodeType === 1) {
          if (typeof this.outerHTML === 'string') {
            rebuilt += this.outerHTML;
          } else {
            rebuilt += $('<div>').append($(this).clone()).html();
          }
        }
      });
      if (rebuilt) {
        chunkHtml = rebuilt;
        $chunk = $(chunkHtml);
      }
    }

    var $target = $('#posts');

    var insertedPost = null;
    if ($chunk.length) {
      if (window.DZ && typeof DZ.mountPosts === 'function') {
        DZ.mountPosts({
          html: $chunk,
          target: '#posts',
          prepend: true
        });
      } else if ($target.length) {
        $target.prepend($chunk);
      }
      if (res && res.post_id) {
        insertedPost = document.getElementById('post-' + String(res.post_id));
      }
      if (!insertedPost) {
        insertedPost = $chunk.find('.post_').get(0) || $chunk.get(0);
      }
      if (!insertedPost && $target.length) {
        insertedPost = $target.find('.post_').first().get(0) || $target.get(0);
      }
      if (insertedPost) {
        reInitPostElements(insertedPost);
      }
    }

    var $activePopup = $('#uploadBtn').closest('.popUp-container');
    if ($activePopup.length) {
      $activePopup.remove();
    } else {
      $('.popUp-container').remove();
    }

    $(document).trigger('post:created', {
      html: $chunk.length ? $chunk : null,
      response: res,
      root: insertedPost || ($target.length ? $target.get(0) : null)
    });

    var successMsg = res.message || ((window.DZ && DZ.i18n ? DZ.i18n('reel_upload_success') : '') || '');
    if (successMsg) {
      if (window.DZ && typeof window.DZ.toast === 'function') {
        window.DZ.toast(String(successMsg), { type: 'success', duration: 2800 });
      } else {
        showTempPopup(String(successMsg), 3000);
      }
    }
  }

  /** Render each image to canvas, attach metadata, and upload via AJAX. */
  function uploadCroppedImages() {
    const csrfToken = $("input[name='csrf_token']").val();
    const createdTime = Math.floor(Date.now() / 1000);
    const postType = 'image';

    const postTitle = $.trim($("input[name='post_title']").val() || '');
    const postText = $.trim($("textarea[name='post_text']").val() || '');
    const whoCanSee = $.trim($("input[name='post_type']").val() || 'everyone');

    const $likeInput = $(".advanced_settings_box input[name='hide_likes_view']").first();
    const $commentInput = $(".advanced_settings_box input[name='turn_on_off_comment']").first();

    const likeStatus = $likeInput.length && String($likeInput.val()).toLowerCase() === 'on' ? 'on' : 'off';
    const commentStatus = $commentInput.length && String($commentInput.val()).toLowerCase() === 'on' ? 'on' : 'off';

    const priceRaw = $.trim($("input[name='set-price']").val() || '');

    const formData = new FormData();
    formData.append('p', 'uploadImage');
    formData.append('csrf_token', csrfToken);
    formData.append('post_type', postType);
    formData.append('created_time', createdTime);

    formData.append('post_title', postTitle);
    formData.append('post_text', postText);
    formData.append('who_can_see', whoCanSee);
    formData.append('price', priceRaw);
    formData.append('like_status', likeStatus);
    formData.append('comment_status', commentStatus);

    const images = $('.crop-image img');

    let loaded = 0;
    let frameWidth = $('.crop-frame').outerWidth() || 0;
    let frameHeight = $('.crop-frame').outerHeight() || 0;
    if (!frameWidth || !frameHeight) { frameWidth = __lastFrameW || 600; frameHeight = __lastFrameH || 600; }
    if (!frameWidth || !frameHeight) { showTempPopup((window.DZ && DZ.i18n ? DZ.i18n('ui_upload_failed_crop_zero') : '') || 'Upload failed: crop area size is 0. Please try again.', 5000); return; }

    images.each(function (index, imgEl) {
      const $img = $(imgEl);
      const naturalWidth = imgEl.naturalWidth;
      const naturalHeight = imgEl.naturalHeight;

      let baseScale = parseFloat($img.attr('data-base-scale'));
      let zoom = parseFloat($img.attr('data-zoom'));
      if (!Number.isFinite(baseScale)) { const sx = frameWidth / naturalWidth; const sy = frameHeight / naturalHeight; baseScale = Math.max(sx, sy); }
      if (!Number.isFinite(zoom)) { zoom = 1; }

      const displayWidth = naturalWidth * baseScale * zoom;
      const displayHeight = naturalHeight * baseScale * zoom;

      let offsetLeft = parseFloat($img.attr('data-left'));
      let offsetTop = parseFloat($img.attr('data-top'));
      if (!Number.isFinite(offsetLeft)) offsetLeft = parseFloat($img.css('left')) || 0;
      if (!Number.isFinite(offsetTop)) offsetTop = parseFloat($img.css('top')) || 0;

      const scaleX = naturalWidth / displayWidth;
      const scaleY = naturalHeight / displayHeight;

      const cropX = -offsetLeft * scaleX;
      const cropY = -offsetTop * scaleY;
      const cropW = frameWidth * scaleX;
      const cropH = frameHeight * scaleY;

      const outW = Math.max(1, Math.round(cropW));
      const outH = Math.max(1, Math.round(cropH));

      const canvas = document.createElement('canvas');
      canvas.width = outW;
      canvas.height = outH;
      const ctx = canvas.getContext('2d');
      // Prefer highest quality resampling on supporting browsers
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';

      const filterName = appliedFilters[index] && appliedFilters[index].filter ? appliedFilters[index].filter : 'none';
      ctx.filter = getCssFilterForName(filterName);

      // Draw the exact crop region at its native resolution (no forced downscale)
      ctx.drawImage(imgEl, cropX, cropY, cropW, cropH, 0, 0, outW, outH);

      formData.append(`filters[]`, appliedFilters[index] && appliedFilters[index].filter ? appliedFilters[index].filter : 'none');

      canvasToBlobPNG(canvas, function (blob) {
        if (!blob) { showTempPopup((window.DZ && DZ.i18n ? DZ.i18n('ui_unable_prepare_image') : '') || 'Unable to prepare image data for upload. Please try again.', 5000); loaded++; return; }

        formData.append('images[]', blob, `image_${index}.png`);
        const filter = appliedFilters[index]?.filter || 'none';
        formData.append(`filter_${index}`, filter);

        loaded++;
        if (loaded === images.length) {
          ensureLoading((window.DZ && DZ.i18n ? DZ.i18n('ui_uploading_wait') : '') || 'Uploading, please wait...');
          $.ajax({
            url: buildUrl('request/requests.php'),
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'text',
            success: handleUploadSuccess,
            error: function (xhr) {
              var fallback = (window.DZ && DZ.i18n ? DZ.i18n('ui_error_during_upload_retry') : '') || 'An error occurred during upload. Please try again.';
              var parsed = null;
              if (xhr) {
                parsed = normalizeUploadResponse(xhr.responseJSON || xhr.responseText);
              }
              if (parsed) {
                if (parsed.status === 'success') {
                  handleUploadSuccess(parsed);
                  return;
                }
                if (parsed.message) {
                  fallback = parsed.message;
                }
              }
              removeLoading();
              showTempPopup(fallback, 5000);
            },
          });
        }
      });
    });
  }
  // #endregion

  // ============================================================
  // #region Event Wiring (delegated handlers)
  // ============================================================
  $(document).ready(function () {
    // Initialize current step from DOM
    (function initStepFromDOM() {
      const hasImages = $('.crop-image img').length > 0;
      const $finishBox = $('.crop-finish-and-post').first();
      const finishVisible = $finishBox.length ? !$finishBox.hasClass('none') : false;
      if (finishVisible) { setStep('finish'); }
      else if (hasImages) { setStep('crop'); }
      else { setStep('select'); }
    })();

    // Header navigation buttons
    $(document).on('click', '#goNext', function () { setStep('finish'); });
    $(document).on('click', '#goBack', function () {
      setStep('crop');
      if ($('.crop-image').length) { showImage(currentIndex); updateNavButtons(); }
    });

    // Initialize image datasets if present
    if ($('.crop-image img').length) { initImageDataAttributes(); }

    // Seed filter state for existing images
    $('.crop-image img').each(function (index) { appliedFilters[index] = { filter: 'none' }; });

    // Filter buttons (assign & mark active)
    $(document).on('click', '.filter-btn', function () {
      const $img = $('.crop-image').eq(currentIndex).find('img');
      const filter = $(this).data('filter');
      let cssFilter = getCssFilterForName(filter);
      $img.css('filter', cssFilter);
      appliedFilters[currentIndex].filter = filter;
      $('.filter-btn').removeClass('active');
      $(this).addClass('active');
    });

    if ($('.crop-image').length) { showImage(currentIndex); }
    updateNavButtons();

    // Filter panel toggle & outside close
    $(document).on('click', '.open-filters', function (e) {
      e.stopPropagation();
      const $menu = $(this).parent().find('.filter-buttons');
      if (isOpen) { $menu.addClass('hidden'); } else { $menu.removeClass('hidden'); }
      isOpen = !isOpen;
    });
    $(document).on('click', function (e) { if (!$(e.target).closest('.filter-wrapper').length) { $('.filter-buttons').addClass('hidden'); isOpen = false; } });

    // Image navigation (next/prev)
    $(document).on('click', '#next', function () { if (currentIndex < totalImages - 1) { currentIndex++; showImage(currentIndex); updateNavButtons(); } });
    $(document).on('click', '#prev', function () { if (currentIndex > 0) { currentIndex--; showImage(currentIndex); updateNavButtons(); } });

    // Original view (fit) & Restore previous view
    $(document).on('click', '#originalView', function () {
      const $img = $('.crop-image').eq(currentIndex).find('img');
      const currentZoom = parseFloat($img.attr('data-zoom')) || 1;
      const currentLeft = parseFloat($img.attr('data-left')) || 0;
      const currentTop = parseFloat($img.attr('data-top')) || 0;
      const currentBaseScale = parseFloat($img.attr('data-base-scale')) || 1;
      $img.attr('data-prev-zoom', currentZoom);
      $img.attr('data-prev-left', currentLeft);
      $img.attr('data-prev-top', currentTop);
      $img.attr('data-prev-base-scale', currentBaseScale);

      const naturalWidth = $img.get(0).naturalWidth;
      const naturalHeight = $img.get(0).naturalHeight;
      const frameWidth = $('.crop-frame').width();
      const frameHeight = $('.crop-frame').height();
      const scaleX = frameWidth / naturalWidth; const scaleY = frameHeight / naturalHeight; const fitScale = Math.min(scaleX, scaleY);
      const displayWidth = naturalWidth * fitScale; const displayHeight = naturalHeight * fitScale;
      const offsetX = Math.round((frameWidth - displayWidth) / 2); const offsetY = Math.round((frameHeight - displayHeight) / 2);

      $img.css({ width: displayWidth + 'px', height: displayHeight + 'px', left: offsetX + 'px', top: offsetY + 'px', transform: 'scale(1)' });
      $img.attr('data-zoom', 1); $img.attr('data-base-scale', fitScale); $img.attr('data-left', offsetX); $img.attr('data-top', offsetY);
      $('#zoom').val(1);
    });

    $(document).on('click', '#restorePreviousView', function () {
      const $img = $('.crop-image').eq(currentIndex).find('img'); if (!$img || $img.length === 0) return;
      let targetZoom = parseFloat($img.attr('data-prev-zoom'));
      let targetLeft = parseFloat($img.attr('data-prev-left'));
      let targetTop = parseFloat($img.attr('data-prev-top'));
      let targetBaseScale = parseFloat($img.attr('data-prev-base-scale'));
      if (isNaN(targetZoom) || isNaN(targetLeft) || isNaN(targetTop) || isNaN(targetBaseScale)) {
        targetZoom = parseFloat($img.attr('data-init-zoom')) || 1;
        targetLeft = parseFloat($img.attr('data-init-left')) || 0;
        targetTop = parseFloat($img.attr('data-init-top')) || 0;
        targetBaseScale = parseFloat($img.attr('data-init-base-scale')) || 1;
      }
      const el = $img.get(0); if (!el || !(el.naturalWidth > 0 && el.naturalHeight > 0)) return;
      const naturalWidth = el.naturalWidth; const naturalHeight = el.naturalHeight;
      const newWidth = naturalWidth * targetBaseScale * targetZoom; const newHeight = naturalHeight * targetBaseScale * targetZoom;
      $img.css({ width: newWidth + 'px', height: newHeight + 'px', left: targetLeft + 'px', top: targetTop + 'px', transform: 'scale(1)' });
      $img.attr('data-zoom', targetZoom); $img.attr('data-base-scale', targetBaseScale); $img.attr('data-left', targetLeft); $img.attr('data-top', targetTop);
      $('#zoom').val(targetZoom); enforceBoundaries($img);
    });

    // Zoom slider
    $(document).on('input', '#zoom', function () {
      const zoom = parseFloat($(this).val());
      const $img = $('.crop-image').eq(currentIndex).find('img'); if (!$img || $img.length === 0) return;
      const baseScale = parseFloat($img.attr('data-base-scale')) || 1;
      const naturalWidth = $img.get(0).naturalWidth; const naturalHeight = $img.get(0).naturalHeight;
      const oldWidth = $img.width(); const oldHeight = $img.height();
      const oldLeft = parseFloat($img.css('left')) || 0; const oldTop = parseFloat($img.css('top')) || 0;
      const newWidth = naturalWidth * baseScale * zoom; const newHeight = naturalHeight * baseScale * zoom;
      const deltaX = (newWidth - oldWidth) / 2; const deltaY = (newHeight - oldHeight) / 2;
      const newLeft = oldLeft - deltaX; const newTop = oldTop - deltaY;
      $img.css({ width: newWidth + 'px', height: newHeight + 'px', left: newLeft + 'px', top: newTop + 'px' });
      $img.attr('data-zoom', zoom); $img.attr('data-left', newLeft); $img.attr('data-top', newTop);
      enforceBoundaries($img);
    });

    // Setup drag interactions for each image
    $('.crop-image img').each(function () { initImageInteractions($(this)); });

    // File input (#imageFileInput) – initial selection
    $(document).on('change', '#imageFileInput', function (event) {
      'use strict';
      const files = event.target.files;
      const $cropWrapper = $('.crop-images-wrapper');
      if (!files.length) return;
      var allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

      var validFiles = []; var allValid = true;
      Array.from(files).forEach(function (file) {
        var typeOk = file.type && allowedTypes.indexOf(file.type) !== -1;
        if (!typeOk) {
          var name = (file.name || '').toLowerCase();
          if (name.endsWith('.jpg') || name.endsWith('.jpeg') || name.endsWith('.png') || name.endsWith('.webp') || name.endsWith('.gif')) {
            typeOk = true; // extension fallback when mime is missing
          }
        }
        if (!typeOk) { allValid = false; } else { validFiles.push(file); }
      });

      if (!allValid || validFiles.length === 0) { showTempPopup(((window.DZ && DZ.i18n ? DZ.i18n('ui_only_images_allowed') : '') || 'Only JPEG, PNG, WEBP or GIF files are allowed.'), 5000); setStep('select'); $(this).val(''); return; }

      $('.crop-images-wrapper').empty();
      var index = 0;
      validFiles.forEach(function (file) {
        var objectUrl = (window.URL || window.webkitURL).createObjectURL(file);
        var $imgDiv = $('<div class="crop-image" data-index="' + index + '"><img draggable="false" /></div>');
        var $img = $imgDiv.find('img');
        $img.attr('src', objectUrl);
        $img.one('load', function () { (window.URL || window.webkitURL).revokeObjectURL(objectUrl); });
        $cropWrapper.append($imgDiv);
        appliedFilters[index] = { filter: 'none' };
        initImageInteractions($img);
        index++;
      });

      totalImages = $('.crop-image').length; currentIndex = 0; setStep('crop');
      setTimeout(function () { initImageDataAttributes(); showImage(currentIndex); updateNavButtons(); }, 100);
      $(this).val('');
    });

    // File input (#fileInputMore) – append more images
    $(document).on('change', '#fileInputMore', function (event) {
      'use strict';
      const files = event.target.files; const $cropWrapper = $('.crop-images-wrapper');
      if (!files.length) return;
      var allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

      var validFiles = []; var allValid = true;
      Array.from(files).forEach(function (file) {
        var typeOk = file.type && allowedTypes.indexOf(file.type) !== -1;
        if (!typeOk) {
          var name = (file.name || '').toLowerCase();
          if (name.endsWith('.jpg') || name.endsWith('.jpeg') || name.endsWith('.png') || name.endsWith('.webp') || name.endsWith('.gif')) { typeOk = true; }
        }
        if (!typeOk) { allValid = false; } else { validFiles.push(file); }
      });

      if (!allValid || validFiles.length === 0) { showTempPopup(((window.DZ && DZ.i18n ? DZ.i18n('ui_only_images_allowed') : '') || 'Only JPEG, PNG, WEBP or GIF files are allowed.'), 5000); $(this).val(''); return; }

      var startIndex = $('.crop-image').length; setStep('crop');
      var index = startIndex;
      validFiles.forEach(function (file) {
        var objectUrl = (window.URL || window.webkitURL).createObjectURL(file);
        var $imgDiv = $('<div class="crop-image" data-index="' + index + '"><img draggable="false" /></div>');
        var $img = $imgDiv.find('img'); $img.attr('src', objectUrl);
        $img.one('load', function () { (window.URL || window.webkitURL).revokeObjectURL(objectUrl); });
        $cropWrapper.append($imgDiv);
        appliedFilters[index] = { filter: 'none' };
        initImageInteractions($img);
        index++;
      });

      totalImages = $('.crop-image').length;
      if (totalImages > 0 && startIndex < totalImages) {
        currentIndex = startIndex;
        setTimeout(function () { initImageDataAttributes(); showImage(currentIndex); updateNavButtons(); }, 50);
      } else { updateNavButtons(); }
      $(this).val('');
    });

    // Upload button
    $(document).on('click', '#uploadBtn', function () { uploadCroppedImages(); });

    // Visibility & price flow (locked/subscribers)
    (function ensurePostTypeHiddenInput() {
      var $box = $('.advanced_settings_box'); if (!$box.length) return;
      if (!$box.find("input[name='post_type']").length) {
        var activeType = $('.post-visiblity.active').data('type') || 'everyone';
        $('<input>', { type: 'hidden', name: 'post_type', value: String(activeType) }).appendTo($box);
      }
    })();

    $(document).on('click', '.post-visiblity', function (event) {
      var $item = $(this); var type = String($item.data('type') || 'everyone');
      if (!handleVisibilityAccess($item, type)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        return false;
      }
      $('.post-visiblity').removeClass('active'); $item.addClass('active');
      $("input[name='post_type']").val(String(type));
      if (type === 'locked') { $('.set-price-popup').removeClass('none'); }
      else {
        $('.set-price-popup').addClass('none');
        $("input[name='set-price']").val('');
        var $priceSpan = $(".post-visiblity[data-type='locked'] .post-price"); if ($priceSpan.length) { $priceSpan.text('($)'); }
        $('.set-price-popup .warn').removeClass('form-warning');
      }
    });

    $(document).on('click', '.set-price-done', function () {
      var raw = $("input[name='set-price']").val(); var trimmed = $.trim(String(raw || ''));
      var min = parseInt($("input[name='min-price']").val(), 10); var max = parseInt($("input[name='max-price']").val(), 10);
      if (!Number.isFinite(min)) { min = 1; } if (!Number.isFinite(max)) { max = 500; }
      var amount = parseInt(trimmed, 10);
      var $warn = $('.set-price-popup .warn');
      if (!Number.isFinite(amount) || amount < min || amount > max) { $warn.addClass('form-warning'); return; }
      else { $warn.removeClass('form-warning'); }
      $('.set-price-popup').addClass('none');
      var $priceSpan = $(".post-visiblity[data-type='locked'] .post-price"); if ($priceSpan.length) { $priceSpan.text('($' + amount + ')'); }
      $('.post-visiblity').removeClass('active'); $(".post-visiblity[data-type='locked']").addClass('active'); $("input[name='post_type']").val('locked');
    });

    $(document).on('click', '.set-price-clear', function () {
      $("input[name='set-price']").val('');
      var $priceSpan = $(".post-visiblity[data-type='locked'] .post-price"); if ($priceSpan.length) { $priceSpan.text('($)'); }
      $(".post-visiblity[data-type='locked']").removeClass('active');
      $('.set-price-popup').addClass('none');
      var activeType = $('.post-visiblity.active').data('type');
      if (activeType) { $("input[name='post_type']").val(String(activeType)); }
      else { $("input[name='post_type']").val('everyone'); $(".post-visiblity[data-type='everyone']").addClass('active'); }
      $('.set-price-popup .warn').removeClass('form-warning');
    });

    // Toggle on/off value based on the checkbox state for stability
    $(document).on('change', "input[name='hide_likes_view'], input[name='turn_on_off_comment']", function () {
      $(this).val($(this).is(':checked') ? 'on' : 'off');
    });
  });
  // #endregion

  // ============================================================
  // #region Interactions (drag/move + grid overlay)
  // ============================================================
  /** Bind drag interactions and grid overlay behavior for a given <img>. */
  function initImageInteractions($img) {
    let isDragging = false; let startX, startY, initialLeft, initialTop;
    const container = $img.parent();

    container.on('mousedown touchstart', function (e) {
      e.preventDefault(); isDragging = true; const evt = e.type === 'touchstart' ? e.originalEvent.touches[0] : e;
      startX = evt.pageX; startY = evt.pageY; initialLeft = parseFloat($img.css('left')) || 0; initialTop = parseFloat($img.css('top')) || 0;
    });

    $(document).on('mousemove.cropimg touchmove.cropimg', function (e) {
      if (!isDragging) return; if (isDragging && e.type.indexOf('touch') === 0) { e.preventDefault(); }
      const evt = e.type.indexOf('touch') === 0 ? (e.originalEvent.touches[0] || e.originalEvent.changedTouches[0]) : e;
      const dx = evt.pageX - startX; const dy = evt.pageY - startY;
      const newLeft = initialLeft + dx; const newTop = initialTop + dy;
      $img.css({ left: newLeft + 'px', top: newTop + 'px' });
      $img.attr('data-left', newLeft); $img.attr('data-top', newTop);
      enforceBoundaries($img);
    });

    $(document).on('mouseup.cropimg touchend.cropimg touchcancel.cropimg', function () { isDragging = false; });

    const gridOverlay = $('.grid-overlay'); gridOverlay.css('pointer-events', 'none');
    $('.crop-frame').on('mousedown', function (e) { if ($(e.target).closest('.prev_button, .next_button').length) return; gridOverlay.removeClass('none'); });
    $(document).on('mouseup', () => gridOverlay.addClass('none'));
    $('.crop-frame').on('touchstart', function (e) { if ($(e.target).closest('.prev_button, .next_button').length) return; gridOverlay.removeClass('none'); });
    $(document).on('touchend', () => gridOverlay.addClass('none'));
    $(document).on('mousedown touchstart', '.prev_button, .next_button', function (e) { e.stopPropagation(); });
  }
  // #endregion
})(window);
