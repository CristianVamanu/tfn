'use strict';
(function(){
  function onReady(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  function build(url) {
    try {
      return (typeof window.buildUrl === 'function') ? window.buildUrl(url) : url;
    } catch (_) {
      return url;
    }
  }

  if (typeof window.REQUESTS_ENDPOINT === 'undefined' || !window.REQUESTS_ENDPOINT) {
    window.REQUESTS_ENDPOINT = build('request/requests.php');
  }

  function postJson(url, data) {
    try {
      var params = new URLSearchParams();
      Object.keys(data || {}).forEach(function(key) {
        params.append(key, data[key]);
      });
      return fetch(url, { method: 'POST', headers: { 'Accept': 'application/json' }, body: params })
        .then(function(response) { return response.json(); });
    } catch (error) {
      return Promise.reject(error);
    }
  }

  function parseJsonAttr(el, attr) {
    if (!el) { return null; }
    var raw = el.getAttribute(attr);
    if (!raw) { return null; }
    try {
      return JSON.parse(raw);
    } catch (error) {
      if (window.DZ_DEBUG) {
        console.warn('settingsPayments: failed to parse', attr, error);
      }
      return null;
    }
  }

  function toggleFallback(canvas, success) {
    if (!canvas) { return; }
    var fallback = canvas.nextElementSibling;
    if (!fallback || !fallback.classList || !fallback.classList.contains('chart-fallback')) { return; }
    if (success) {
      fallback.classList.add('is-hidden');
    } else {
      fallback.classList.remove('is-hidden');
    }
  }

  function initSecretsForm() {
    var form = document.getElementById('payment-secrets-form');
    if (!form) { return; }

    form.addEventListener('click', function(event) {
      var button = event.target.closest('.reveal-btn');
      if (!button) { return; }
      event.preventDefault();
      var targetId = button.getAttribute('data-target');
      var input = document.getElementById(targetId);
      if (!input) { return; }
      var csrfEl = form.querySelector('input[name="csrf_token"]');
      var csrf = csrfEl ? csrfEl.value : '';
      var question = (window.DZ && typeof DZ.i18n === 'function')
        ? (DZ.i18n('re_auth_required') || 'Confirm Password')
        : 'Confirm Password';
      var password = window.prompt(question);
      if (password === null) { return; }
      postJson(build('admin/request/payment_settings.php'), { action: 'reauth', csrf_token: csrf, password: password })
        .then(function(response) {
          if (response && response.status === 'success') {
            input.type = 'text';
            input.value = '';
            input.focus();
          } else {
            alert((window.DZ && DZ.i18n) ? (DZ.i18n('invalid_password') || 'Invalid password.') : 'Invalid password.');
          }
        })
        .catch(function() {
          alert((window.DZ && DZ.i18n) ? (DZ.i18n('server_error') || 'Server error') : 'Server error');
        });
    });

    form.addEventListener('submit', function(event) {
      event.preventDefault();
      var data = new FormData(form);
      fetch(form.action, { method: 'POST', body: data })
        .then(function(response) { return response.json(); })
        .then(function(result) {
          if (result && result.status === 'success') {
            alert((window.DZ && DZ.i18n) ? (DZ.i18n('saved_ok') || 'Saved.') : 'Saved.');
            var secretInputs = form.querySelectorAll('input[type="password"][data-mask]');
            secretInputs.forEach(function(el) {
              var mask = el.getAttribute('data-mask') || '';
              el.type = 'password';
              el.value = mask;
            });
          } else {
            alert((window.DZ && DZ.i18n) ? (DZ.i18n('save_failed') || 'Save failed.') : 'Save failed.');
          }
        })
        .catch(function() {
          alert((window.DZ && DZ.i18n) ? (DZ.i18n('server_error') || 'Server error') : 'Server error');
        });
    });
  }

  function startChartWhenReady(canvas, attempt) {
    if (!canvas) { return; }
    if (typeof Chart !== 'undefined') {
      initPaymentsChart(canvas);
      return;
    }
    if ((attempt || 0) > 20) {
      toggleFallback(canvas, false);
      return;
    }
    window.setTimeout(function() {
      startChartWhenReady(canvas, (attempt || 0) + 1);
    }, 50);
  }

  function buildCurrencyFormatter() {
    var cfg = (window.DZ && window.DZ.currencyFormat) || {};
    var code = (cfg.code || 'USD').toString().toUpperCase();
    var symbol = (cfg.symbol || '').toString();
    var decimalSep = cfg.decimalSep === ',' ? ',' : '.';
    var thousandsSep = typeof cfg.thousandsSep === 'string' ? cfg.thousandsSep : ',';
    var basePrecision = typeof cfg.decimalPlaces === 'number' ? cfg.decimalPlaces : 2;

    return function formatCurrency(amount) {
      if (window.DZ && typeof window.DZ.formatCurrency === 'function') {
        return window.DZ.formatCurrency(amount, code, symbol);
      }
      var numeric = Number(amount);
      if (!isFinite(numeric)) { numeric = 0; }
      var precision = Math.min(Math.max(0, basePrecision), 8);
      var fixed = numeric.toFixed(precision);
      var parts = fixed.split('.');
      if (thousandsSep) {
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandsSep);
      }
      var joined = parts.length > 1 ? parts[0] + decimalSep + parts[1] : parts[0];
      if (symbol && symbol !== code && symbol.length <= 4) {
        return symbol + (symbol === '$' ? '' : ' ') + joined;
      }
      return joined + ' ' + code;
    };
  }

  function initPaymentsChart(canvas) {
    var labels = parseJsonAttr(canvas, 'data-labels') || [];
    var weekly = parseJsonAttr(canvas, 'data-weekly') || [];
    var monthly = parseJsonAttr(canvas, 'data-monthly') || [];
    var weeklyLabel = canvas.getAttribute('data-weekly-label') || 'Weekly spend';
    var monthlyLabel = canvas.getAttribute('data-monthly-label') || 'Rolling 30-day spend';

    var datasetLength = Math.min(labels.length, weekly.length, monthly.length);
    if (!datasetLength) {
      toggleFallback(canvas, false);
      return;
    }

    labels = labels.slice(0, datasetLength);
    weekly = weekly.slice(0, datasetLength);
    monthly = monthly.slice(0, datasetLength);

    var context = canvas.getContext('2d');
    if (!context) {
      toggleFallback(canvas, false);
      return;
    }

    var formatCurrency = buildCurrencyFormatter();

    new Chart(context, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: weeklyLabel,
            data: weekly,
            backgroundColor: 'rgba(31,75,216,0.25)',
            borderColor: '#1f4bd8',
            borderWidth: 1,
            borderRadius: 8,
            borderSkipped: false,
            maxBarThickness: 28
          },
          {
            label: monthlyLabel,
            data: monthly,
            backgroundColor: 'rgba(36,184,199,0.25)',
            borderColor: '#24b8c7',
            borderWidth: 1,
            borderRadius: 8,
            borderSkipped: false,
            maxBarThickness: 28
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { display: true, position: 'bottom' },
          tooltip: {
            callbacks: {
              label: function(context) {
                var label = context.dataset.label || '';
                var value = context.parsed.y;
                if (typeof value === 'number') {
                  var formatted = formatCurrency(value);
                  return label ? (label + ': ' + formatted) : formatted;
                }
                return label ? (label + ': ' + value) : value;
              }
            }
          }
        },
        scales: {
          x: {
            grid: { display: false }
          },
          y: {
            beginAtZero: true,
            grid: { color: 'rgba(0,0,0,0.06)' },
            ticks: {
              callback: function(value) {
                return typeof value === 'number'
                  ? formatCurrency(value)
                  : value;
              }
            }
          }
        }
      }
    });

    toggleFallback(canvas, true);
  }

  onReady(function() {
    initSecretsForm();
    startChartWhenReady(document.getElementById('settingsEarningsChart'), 0);
  });
})();
