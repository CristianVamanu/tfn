(function(){
  'use strict';
  if (!window.__feesLogOnce) { window.__feesLogOnce = true; }
  var currencyConfig = (window.DZ && window.DZ.currencyFormat) ? window.DZ.currencyFormat : {};
  var basePrecision = (typeof currencyConfig.decimalPlaces === 'number')
    ? Math.max(0, Math.min(8, currencyConfig.decimalPlaces))
    : 2;

  function isFiniteNumber(value){ return typeof value === 'number' && isFinite(value); }

  function parseAmount(value){
    if (value == null) { return NaN; }
    var normalized = String(value);
    var thousandsSep = currencyConfig.thousandsSep || ',';
    if (thousandsSep) {
      var escaped = thousandsSep.replace(/([.*+?^=!:${}()|[\]\\])/g, '\\$1');
      normalized = normalized.replace(new RegExp(escaped, 'g'), '');
    }
    var dec = currencyConfig.decimalSep === ',' ? ',' : '.';
    if (dec !== '.') {
      var escapedDec = dec.replace(/([.*+?^=!:${}()|[\]\\])/g, '\\$1');
      normalized = normalized.replace(new RegExp(escapedDec, 'g'), '.');
    }
    normalized = normalized.replace(/[^0-9.\-]/g, '');
    var num = parseFloat(normalized);
    return isFiniteNumber(num) ? num : NaN;
  }

  function formatMoney(amount, symbol, code){
    if (window.DZ && typeof window.DZ.formatCurrency === 'function') {
      return window.DZ.formatCurrency(amount, code, symbol);
    }
    var safe = isFiniteNumber(amount) ? amount : 0;
    var decSep = currencyConfig.decimalSep === ',' ? ',' : '.';
    var thousandsSep = typeof currencyConfig.thousandsSep === 'string' ? currencyConfig.thousandsSep : ',';
    var precision = Math.min(Math.max(0, basePrecision), 8);
    var fixed = safe.toFixed(precision);
    var parts = fixed.split('.');
    if (thousandsSep) {
      parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandsSep);
    }
    var formatted = parts.length > 1 ? parts[0] + decSep + parts[1] : parts[0];
    if (symbol && symbol.length <= 3 && symbol !== code) {
      return symbol + (symbol === '$' ? '' : ' ') + formatted;
    }
    return formatted + ' ' + code;
  }

  /**
   * Format the amount input using digits only; inserts thousand separators (.)
   * and decimal separator (,) automatically.
   * @param {HTMLInputElement} input
   * @param {number} desiredFractionDigits
   * @returns {{value:string, digits:string, decimals:number}}
   */
  function sanitizeMonetaryInput(input, desiredFractionDigits){
    if (!input) { return { value: '', digits: '', decimals: 0 }; }
    var raw = input.value || '';
    var digitsOnly = raw.replace(/\D/g, '');
    var decimalSep = currencyConfig.decimalSep === ',' ? ',' : '.';
    var thousandsSep = (typeof currencyConfig.thousandsSep === 'string') ? currencyConfig.thousandsSep : '.';
    if (thousandsSep === decimalSep) { thousandsSep = ''; }

    var decimals = 0;
    if (typeof desiredFractionDigits === 'number' && !isNaN(desiredFractionDigits)) {
      decimals = desiredFractionDigits;
    } else if (input.dataset && typeof input.dataset.feeDecimals !== 'undefined') {
      decimals = parseInt(input.dataset.feeDecimals, 10) || 0;
    }
    if (decimals < 0) { decimals = 0; }
    if (decimals > basePrecision) { decimals = basePrecision; }

    if (!digitsOnly.length) {
      input.value = '';
      if (input.dataset) {
        input.dataset.feeDigits = '';
        if (input.dataset.feeDecimalsForceNext === '1') {
          input.dataset.feeDecimals = String(decimals);
          input.dataset.feeDecimalsOverride = decimals > 0 ? '1' : '0';
        } else {
          input.dataset.feeDecimals = '0';
          input.dataset.feeDecimalsOverride = '0';
          input.dataset.feeDecimalsForceNext = '0';
        }
      }
      return { value: '', digits: '', decimals: decimals };
    }

    if (digitsOnly.length <= decimals) {
      digitsOnly = digitsOnly.padStart(decimals + 1, '0');
    }

    var intDigits = digitsOnly.slice(0, digitsOnly.length - decimals) || '0';
    var fracDigits = decimals > 0 ? digitsOnly.slice(digitsOnly.length - decimals) : '';

    intDigits = intDigits.replace(/^0+(?=\d)/, '');
    if (!intDigits.length) {
      intDigits = '0';
    }

    var regexThousands = thousandsSep ? new RegExp('\\B(?=(\\d{3})+(?!\\d))', 'g') : null;
    var formattedInt = regexThousands ? intDigits.replace(regexThousands, thousandsSep) : intDigits;
    var formattedValue = decimals > 0
      ? formattedInt + decimalSep + fracDigits.padEnd(decimals, '0')
      : formattedInt;

    input.value = formattedValue;
    if (input.dataset) {
      input.dataset.feeDigits = digitsOnly;
      input.dataset.feeDecimals = String(decimals);
      input.dataset.feeDecimalsOverride = decimals > 0 ? '1' : '0';
    }

    return { value: formattedValue, digits: digitsOnly, decimals: decimals };
  }

  function formatAmountForInput(amount, decimals){
    if (!isFiniteNumber(amount)) { amount = 0; }
    var safeDecimals = isFiniteNumber(decimals) ? Math.max(0, Math.min(basePrecision, Math.round(decimals))) : 0;
    var fixed = Number(amount).toFixed(safeDecimals);
    var parts = fixed.split('.');
    var intPart = parts[0];
    var fracPart = parts[1] || '';
    var decimalSep = currencyConfig.decimalSep === ',' ? ',' : '.';
    var thousandsSep = (typeof currencyConfig.thousandsSep === 'string') ? currencyConfig.thousandsSep : '.';
    if (thousandsSep === decimalSep) { thousandsSep = ''; }
    var regexThousands = thousandsSep ? new RegExp('\\B(?=(\\d{3})+(?!\\d))', 'g') : null;
    var formattedInt = regexThousands ? intPart.replace(regexThousands, thousandsSep) : intPart;
    return safeDecimals > 0 ? formattedInt + decimalSep + fracPart : formattedInt;
  }

  function digitCountBefore(str, index){
    if (!str || index <= 0) { return 0; }
    var slice = str.slice(0, Math.max(0, index));
    var matches = slice.match(/\d/g);
    return matches ? matches.length : 0;
  }

  function caretFromDigitCount(str, digitCount){
    if (!str || digitCount <= 0) { return 0; }
    var seen = 0;
    for (var i = 0; i < str.length; i++) {
      if (/\d/.test(str.charAt(i))) {
        seen++;
        if (seen === digitCount) {
          return i + 1;
        }
      }
    }
    return str.length;
  }

  function detectInitialDecimals(raw){
    if (raw == null) { return 0; }
    var str = String(raw).trim();
    if (!str) { return 0; }
    var commaIdx = str.lastIndexOf(',');
    if (commaIdx !== -1) {
      var tailComma = str.slice(commaIdx + 1).replace(/\D/g, '');
      return Math.max(0, Math.min(2, tailComma.length));
    }
    var dotIdx = str.lastIndexOf('.');
    if (dotIdx !== -1) {
      var tailDot = str.slice(dotIdx + 1).replace(/\D/g, '');
      if (tailDot.length > 0 && tailDot.length <= 2) {
        return Math.max(0, tailDot.length);
      }
    }
    return 0;
  }

  /**
   * Block disallowed keyboard, paste, and IME insertions on the plan amount input.
   * @param {HTMLInputElement} input
   * @param {Function} onValueChanged
   */
  function attachInputGuards(input, onValueChanged){
    if (!input) { return; }
    var CONTROL_KEYS = ['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End', 'Tab'];

    input.addEventListener('keydown', function(ev){
      if (ev.key === 'Enter') {
        ev.preventDefault();
        ev.stopPropagation();
        return;
      }
      if (ev.key === '.' || ev.key === ',' || ev.key === 'Decimal') {
        ev.preventDefault();
        var currentDecimals = parseInt(input.dataset.feeDecimals || '0', 10) || 0;
        var nextDecimals = currentDecimals > 0 ? 0 : 2;
        input.dataset.feeDecimals = String(nextDecimals);
        input.dataset.feeDecimalsOverride = nextDecimals > 0 ? '1' : '0';
        input.dataset.feeDecimalsForceNext = nextDecimals > 0 ? '1' : '0';
        if (typeof onValueChanged === 'function') {
          setTimeout(onValueChanged, 0);
        }
        return;
      }
      if (ev.ctrlKey || ev.metaKey || ev.altKey) { return; }
      if (CONTROL_KEYS.indexOf(ev.key) !== -1) { return; }
      if (ev.key && ev.key.length === 1 && !/^[0-9]$/.test(ev.key)) {
        ev.preventDefault();
      }
    });

    if (typeof input.addEventListener === 'function') {
      input.addEventListener('beforeinput', function(ev){
        if (ev.inputType === 'insertText' && ev.data && !/^[0-9]+$/.test(ev.data)) {
          ev.preventDefault();
        }
      });
    }

    input.addEventListener('paste', function(ev){
      var clipboard = ev.clipboardData || window.clipboardData;
      if (!clipboard) { return; }
      ev.preventDefault();
      var text = clipboard.getData('text');
      if (typeof text !== 'string') { return; }
      var digits = text.replace(/\D/g, '');
      if (!digits.length) { return; }
      var decimalsFromPaste = 0;
      if (/[.,]/.test(text)) {
        var normalised = text.replace(/\./g, '');
        var commaIdx = normalised.indexOf(',');
        if (commaIdx === -1) { commaIdx = normalised.indexOf('.'); }
        if (commaIdx !== -1) {
          decimalsFromPaste = normalised.length - commaIdx - 1;
        }
      }
      input.dataset.feeDecimals = String(Math.min(2, Math.max(0, decimalsFromPaste)));
      input.dataset.feeDecimalsOverride = decimalsFromPaste > 0 ? '1' : '0';
      input.dataset.feeDecimalsForceNext = decimalsFromPaste > 0 ? '1' : '0';
      var start = typeof input.selectionStart === 'number' ? input.selectionStart : (input.value || '').length;
      var end = typeof input.selectionEnd === 'number' ? input.selectionEnd : start;
      var current = input.value || '';
      var nextRaw = current.slice(0, start) + digits + current.slice(end);
      input.value = nextRaw;
      if (typeof onValueChanged === 'function') {
        onValueChanged();
      }
    });
  }

  function initialiseCalculator(form){
    if (!form || form.__subscriptionFeesReady) { return false; }

    var input = form.querySelector('[data-fee-input]') || form.querySelector('#plan_amount') || form.querySelector('input[name="plan_amount"]');
    if (!input) { return false; }

    var initialDecimals = detectInitialDecimals(input.value);
    input.dataset.feeDecimals = String(initialDecimals);
    input.dataset.feeDecimalsOverride = initialDecimals > 0 ? '1' : '0';
    input.dataset.feeDecimalsForceNext = '0';

    // Use a broader scope: results sit outside the <form> as siblings inside the same card
    var scope = form.closest('.admin-card') || form.parentElement || document;

    // Prevent full page reloads: disable submit + Enter default in number input
    try {
      // Convert any submit buttons to type="button"
      var submits = form.querySelectorAll('button[type="submit"], input[type="submit"]');
      for (var s = 0; s < submits.length; s++) {
        submits[s].setAttribute('type', 'button');
      }
      // Block form submission from any source (Enter, programmatic, etc.)
      form.addEventListener('submit', function(ev){
        ev.preventDefault();
        ev.stopPropagation();
        return false;
      }, true);
    } catch(_) {}

    var outputs = {
      creator: scope.querySelector('[data-fee-output="creator"]'),
      platform: scope.querySelector('[data-fee-output="platform"]'),
      processing: scope.querySelector('[data-fee-output="processing"]')
    };
    if (!outputs.creator || !outputs.platform || !outputs.processing) { return false; }

    var percNodes = {
      creator: scope.querySelector('[data-fee-percent="creator"]'),
      platform: scope.querySelector('[data-fee-percent="platform"]'),
      processing: scope.querySelector('[data-fee-percent="processing"]')
    };
    var currencySymbol = form.dataset.currencySymbol || '';
    var currencyCode = form.dataset.currencyCode || '';
    var endpoint = form.dataset.feeEndpoint || '';
    if (!endpoint) {
      try {
        if (typeof window.buildUrl === 'function') {
          endpoint = window.buildUrl('request/requests.php');
        } else {
          var base = (form && form.dataset) ? (form.dataset.baseUrl || form.dataset.siteUrl || '') : '';
          if (!base && typeof window.site_url === 'string' && window.site_url) {
            base = window.site_url;
          } else if (!base && typeof site_url !== 'undefined' && site_url) {
            base = site_url;
          } else {
            var loc = (typeof window !== 'undefined') ? window.location : null;
            var origin = (loc && loc.origin) ? loc.origin : '';
            var path = (loc && loc.pathname) ? loc.pathname.replace(/[^\/]*$/, '') : '';
            base = origin ? (origin + path) : '';
          }
          if (base && base.slice(-1) !== '/') { base += '/'; }
          endpoint = base ? (base + 'request/requests.php') : 'request/requests.php';
        }
      } catch (e) {}
    }

    var percentages = {
      creator: parseAmount(form.dataset.creatorPercent),
      platform: parseAmount(form.dataset.platformPercent),
      processing: parseAmount(form.dataset.taxPercent)
    };
    if (!isFiniteNumber(percentages.platform)) { percentages.platform = 0; }
    if (!isFiniteNumber(percentages.processing)) { percentages.processing = 0; }
    if (!isFiniteNumber(percentages.creator)) {
      percentages.creator = Math.max(100 - percentages.platform - percentages.processing, 0);
    }

    Object.keys(percNodes).forEach(function(key){
      if (!percNodes[key]) { return; }
      var value = percentages[key];
      percNodes[key].textContent = isFiniteNumber(value) ? value.toFixed(1) + '%' : '0.0%';
    });

    var minAmount = parseAmount(input.getAttribute('min'));
    var maxAmount = parseAmount(input.getAttribute('max'));

    var activeRequest = null;
    var debounceTimer = null;

    function updateOutputs(shares){
      outputs.creator.textContent = formatMoney(shares.creator, currencySymbol, currencyCode);
      outputs.platform.textContent = formatMoney(shares.platform, currencySymbol, currencyCode);
      outputs.processing.textContent = formatMoney(shares.processing, currencySymbol, currencyCode);
    }

    function normaliseAmount(raw){
      var amount = parseAmount(raw);
      if (!isFiniteNumber(amount) || amount <= 0) { return 0; }
      if (isFiniteNumber(minAmount) && amount < minAmount) { amount = minAmount; }
      if (isFiniteNumber(maxAmount) && amount > maxAmount) { amount = maxAmount; }
      return amount;
    }

    function computeLocalShares(amount){
      if (!isFiniteNumber(amount) || amount <= 0) {
        return { amount: 0, creator: 0, platform: 0, processing: 0 };
      }
      var creatorShare = amount * (percentages.creator / 100);
      var platformShare = amount * (percentages.platform / 100);
      var processingShare = amount * (percentages.processing / 100);
      var total = creatorShare + platformShare + processingShare;
      var remainder = amount - total;
      if (Math.abs(remainder) > 0.01) { creatorShare += remainder; }
      return {
        amount: amount,
        creator: Math.max(creatorShare, 0),
        platform: Math.max(platformShare, 0),
        processing: Math.max(processingShare, 0)
      };
    }

    function applyPercentages(data){
      if (!data) { return; }
      ['creator','platform','processing'].forEach(function(key){
        if (!Object.prototype.hasOwnProperty.call(data, key)) { return; }
        var value = parseAmount(data[key]);
        if (!isFiniteNumber(value)) { return; }
        percentages[key] = value;
        if (percNodes[key]) {
          percNodes[key].textContent = value.toFixed(1) + '%';
        }
      });
    }

    function handleResponse(payload){
      if (!payload || payload.status !== 'success' || !payload.data) { return; }
      var data = payload.data;

      if (data.percentages) {
        applyPercentages(data.percentages);
      }

      if (data.amounts) {
        ['creator','platform','processing'].forEach(function(key){
          if (!Object.prototype.hasOwnProperty.call(data.amounts, key)) { return; }
          outputs[key].textContent = String(data.amounts[key]);
        });
      }
    }

    function sendRequest(amount){
      if (!endpoint) { return; }
      if (activeRequest) { activeRequest.abort(); }
      activeRequest = new AbortController();

      var formData = new FormData();
      formData.append('p', 'subscription_fees_calculate');
      formData.append('amount', amount.toFixed(2));

      fetch(endpoint, {
        method: 'POST',
        body: formData,
        credentials: 'same-origin',
        signal: activeRequest.signal,
        headers: { 'Accept': 'application/json' }
      })
        .then(function(res){ return res.json().catch(function(){ return null; }); })
        .then(function(payload){ handleResponse(payload); })
        .catch(function(err){
          if (err && err.name === 'AbortError') { return; }
        });
    }

    function handleInput(){
      var rawValue = input.value || '';

      var caretPos = (typeof input.selectionStart === 'number') ? input.selectionStart : null;
      var digitsAhead = caretPos !== null ? digitCountBefore(rawValue, caretPos) : null;

      var hasComma = rawValue.indexOf(',') !== -1;
      var hasDot = rawValue.indexOf('.') !== -1;
      var forceDecimals = input.dataset && input.dataset.feeDecimalsOverride === '1';
      var forceNextToggle = input.dataset && input.dataset.feeDecimalsForceNext === '1';
      var desiredDecimals = 0;
      if (!hasComma && !hasDot) {
        if (forceNextToggle || forceDecimals) {
          desiredDecimals = parseInt(input.dataset.feeDecimals, 10) || 0;
        } else {
          desiredDecimals = 0;
          if (input.dataset) {
            input.dataset.feeDecimals = '0';
            input.dataset.feeDecimalsOverride = '0';
          }
        }
      } else {
        var cleanedForDecimals = rawValue.replace(/\./g, '');
        var sepIndex = cleanedForDecimals.indexOf(',');
        if (sepIndex === -1) { sepIndex = cleanedForDecimals.indexOf('.'); }
        if (sepIndex !== -1) {
          desiredDecimals = cleanedForDecimals.slice(sepIndex + 1).replace(/\D/g, '').length;
        } else {
          desiredDecimals = forceDecimals ? (parseInt(input.dataset.feeDecimals, 10) || 0) : 0;
        }
      }
      desiredDecimals = Math.max(0, Math.min(2, desiredDecimals));

      var sanitised = sanitizeMonetaryInput(input, desiredDecimals);
      var formattedValue = sanitised.value;
      if (input.dataset && sanitised.digits.length > 0) {
        input.dataset.feeDecimalsForceNext = '0';
      }

      if (caretPos !== null && digitsAhead !== null && document.activeElement === input && typeof input.setSelectionRange === 'function') {
        var newCaret = caretFromDigitCount(formattedValue, digitsAhead);
        try { input.setSelectionRange(newCaret, newCaret); } catch (_) {}
      }

      var parsedAmount = parseAmount(formattedValue);
      var amount = normaliseAmount(formattedValue);
      if (Math.abs(amount - parsedAmount) > 0.0001) {
        var clampedValue = formatAmountForInput(amount, desiredDecimals);
        input.value = clampedValue;
        sanitised = sanitizeMonetaryInput(input, desiredDecimals);
        formattedValue = sanitised.value;
        digitsAhead = null;
        if (input.dataset) {
          input.dataset.feeDecimalsForceNext = '0';
        }
        if (document.activeElement === input && typeof input.setSelectionRange === 'function') {
          var clampCaret = formattedValue.length;
          try { input.setSelectionRange(clampCaret, clampCaret); } catch (_) {}
        }
      }

      if (!isFiniteNumber(amount) || amount <= 0) {
        if (activeRequest) { activeRequest.abort(); activeRequest = null; }
        if (debounceTimer) { clearTimeout(debounceTimer); debounceTimer = null; }
        updateOutputs({ creator: 0, platform: 0, processing: 0 });
        return;
      }

      updateOutputs(computeLocalShares(amount));

      if (debounceTimer) { clearTimeout(debounceTimer); }
      debounceTimer = setTimeout(function(){
        debounceTimer = null;
        sendRequest(amount);
      }, 120);
    }

    attachInputGuards(input, handleInput);

    input.addEventListener('input', handleInput);
    input.addEventListener('keyup', handleInput);   // fallback for browsers that defer number input
    input.addEventListener('change', handleInput);  // fallback on blur/enter (does not replace input)

    handleInput();


    form.__subscriptionFeesReady = true;
    return true;
  }

  function watchForCalculator(){
    initResourceModals();
    if (initialiseCalculator(document.querySelector('[data-fee-calculator]') || document.querySelector('form.subscription-fees-calculator'))) {
      initResourceModals();
      return;
    }

    var observer = new MutationObserver(function(mutations){
      for (var i = 0; i < mutations.length; i++) {
        var mutation = mutations[i];
        if (!mutation.addedNodes) { continue; }
        for (var j = 0; j < mutation.addedNodes.length; j++) {
          var node = mutation.addedNodes[j];
          if (!(node instanceof HTMLElement)) { continue; }
          initResourceModals();
          if (node.matches && node.matches('[data-fee-calculator]') && initialiseCalculator(node)) {
            observer.disconnect();
            initResourceModals();
            return;
          }
          if (node.matches && node.matches('form.subscription-fees-calculator') && initialiseCalculator(node)) {
            observer.disconnect();
            initResourceModals();
            return;
          }
          if (node.querySelector) {
            var target = node.querySelector('[data-fee-calculator]');
            if (!target) { target = node.querySelector('form.subscription-fees-calculator'); }
            if (target && initialiseCalculator(target)) {
              observer.disconnect();
              initResourceModals();
              return;
            }
          }
        }
      }
    });

    observer.observe(document.body || document.documentElement, { childList: true, subtree: true });
  }

  function initResourceModals(){
    if (initResourceModals.__ready) { return; }

    var hasModal = document.querySelector('[data-fee-resource-modal]');
    var hasTrigger = document.querySelector('[data-fee-resource-trigger]');
    if (!hasModal || !hasTrigger) { return; }

    initResourceModals.__ready = true;

    var activeModal = null;

    function setExpanded(trigger, state){
      if (!trigger) { return; }
      trigger.setAttribute('aria-expanded', state ? 'true' : 'false');
    }

    function openModal(modal, trigger){
      if (!modal) { return; }
      if (activeModal && activeModal !== modal) {
        closeModal(activeModal);
      }
      modal.classList.add('is-open');
      modal.setAttribute('aria-hidden', 'false');
      modal.__trigger = trigger || null;
      if (trigger) {
        setExpanded(trigger, true);
      }
      var focusTarget = modal.querySelector('[data-fee-resource-close]') ||
        modal.querySelector('button, [href], input, textarea, select, [tabindex]:not([tabindex="-1"])');
      if (focusTarget && focusTarget.focus) {
        try { focusTarget.focus(); } catch (_) {
          setTimeout(function(){ try { focusTarget.focus(); } catch (__) {} }, 0);
        }
      }
      activeModal = modal;
      if (document.body && document.body.classList) {
        document.body.classList.add('fee-resource-modal-open');
      }
    }

    function closeModal(modal){
      if (!modal) { return; }
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
      if (modal.__trigger) {
        var triggerRef = modal.__trigger;
        modal.__trigger = null;
        setExpanded(triggerRef, false);
        if (triggerRef.focus) {
          setTimeout(function(){ try { triggerRef.focus(); } catch (__) {} }, 0);
        }
      }
      if (activeModal === modal) {
        activeModal = null;
      }
      if (!document.querySelector('.fee-resource-modal.is-open') && document.body && document.body.classList) {
        document.body.classList.remove('fee-resource-modal-open');
      }
    }

    document.addEventListener('click', function(event){
      var trigger = event.target.closest ? event.target.closest('[data-fee-resource-trigger]') : null;
      if (trigger) {
        event.preventDefault();
        var targetId = trigger.getAttribute('data-target');
        if (!targetId) { return; }
        var modal = document.getElementById(targetId);
        if (modal) {
          openModal(modal, trigger);
        }
        return;
      }

      var closer = event.target.closest ? event.target.closest('[data-fee-resource-close]') : null;
      if (closer) {
        event.preventDefault();
        var modalHost = closer.closest ? closer.closest('[data-fee-resource-modal]') : null;
        closeModal(modalHost || activeModal);
      }
    });

    document.addEventListener('keydown', function(event){
      if (event.key === 'Escape' && activeModal) {
        event.preventDefault();
        closeModal(activeModal);
      }
    });
  }

  function initialiseSubscriptionFees(){
    watchForCalculator();
    initResourceModals();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialiseSubscriptionFees);
  } else {
    initialiseSubscriptionFees();
  }
})();
