(function (global) {
  if (global.__DIZZY_CROP_INITED__) {
    return;
  }
  global.__DIZZY_CROP_INITED__ = true;

  ('use strict');
  (function initAdsHelpTooltips($) {
    if (!$ || window.__ADS_HELP_TOOLTIP_INIT__) {
      return;
    }
    window.__ADS_HELP_TOOLTIP_INIT__ = true;

    var activeTrigger = null;
    var activeTooltip = null;
    var hideTimer = null;
    var lastPointerX = null;
    var doc = document;
    var spacing = 12;

    function clearHideTimer() {
      if (hideTimer) {
        clearTimeout(hideTimer);
        hideTimer = null;
      }
    }

    function scheduleHide(delay) {
      clearHideTimer();
      if (!activeTooltip) {
        return;
      }
      var tooltipRef = activeTooltip;
      hideTimer = setTimeout(function () {
        if (tooltipRef === activeTooltip) {
          removeTooltip();
        }
      }, typeof delay === 'number' ? delay : 0);
    }

    function ensureId(trigger) {
      var id = trigger.getAttribute('data-tooltip-id');
      if (!id) {
        id = 'ads-tooltip-' + Date.now() + '-' + Math.floor(Math.random() * 100000);
        trigger.setAttribute('data-tooltip-id', id);
      }
      return id;
    }

    function removeTooltip() {
      clearHideTimer();
      if (!activeTooltip) {
        return;
      }
      var tooltip = activeTooltip;
      var trigger = activeTrigger;
      activeTooltip = null;
      activeTrigger = null;
      lastPointerX = null;
      if (trigger) {
        trigger.setAttribute('aria-expanded', 'false');
        trigger.removeAttribute('aria-describedby');
      }
      tooltip.classList.remove('is-visible');
      setTimeout(function () {
        if (tooltip && tooltip.parentNode) {
          tooltip.parentNode.removeChild(tooltip);
        }
      }, 160);
    }

    function positionTooltip(trigger, tooltip, originEvent) {
      if (!trigger || !tooltip) {
        return;
      }
      var rect = trigger.getBoundingClientRect();
      var vw = window.innerWidth || doc.documentElement.clientWidth || 0;
      var vh = window.innerHeight || doc.documentElement.clientHeight || 0;
      var referenceX;
      if (originEvent && typeof originEvent.clientX === 'number') {
        referenceX = originEvent.clientX;
      } else if (lastPointerX !== null) {
        referenceX = lastPointerX;
      } else {
        referenceX = rect.left + rect.width / 2;
      }
      var placement = 'bottom';
      var shouldHideForMeasure = !tooltip.classList.contains('is-visible');
      if (shouldHideForMeasure) {
        tooltip.style.visibility = 'hidden';
      }
      tooltip.style.top = '0px';
      tooltip.style.left = '0px';
      var tooltipRect = tooltip.getBoundingClientRect();
      var top = rect.bottom + spacing;
      if (top + tooltipRect.height > vh - spacing && rect.top - tooltipRect.height - spacing >= spacing) {
        top = rect.top - tooltipRect.height - spacing;
        placement = 'top';
      } else if (top + tooltipRect.height > vh - spacing) {
        top = Math.max(spacing, vh - tooltipRect.height - spacing);
      }
      var left = referenceX - tooltipRect.width / 2;
      var minLeft = spacing;
      var maxLeft = Math.max(spacing, vw - tooltipRect.width - spacing);
      if (left < minLeft) {
        left = minLeft;
      }
      if (left > maxLeft) {
        left = maxLeft;
      }
      tooltip.style.top = Math.round(top) + 'px';
      tooltip.style.left = Math.round(left) + 'px';
      tooltip.setAttribute('data-placement', placement);

      var anchorPx = referenceX - left;
      var tooltipWidth = tooltipRect.width || 0;
      var arrowGutter = 10;
      if (tooltipWidth > 0) {
        var clampedAnchor = Math.max(arrowGutter, Math.min(tooltipWidth - arrowGutter, anchorPx));
        tooltip.style.setProperty('--ads-tooltip-anchor', Math.round(clampedAnchor) + 'px');
        var originX = Math.round((clampedAnchor / tooltipWidth) * 10000) / 100;
        tooltip.style.setProperty('--ads-tooltip-origin-x', originX + '%');
      } else {
        tooltip.style.removeProperty('--ads-tooltip-anchor');
        tooltip.style.removeProperty('--ads-tooltip-origin-x');
      }
      tooltip.style.setProperty('--ads-tooltip-origin-y', placement === 'top' ? '100%' : '0%');

      if (shouldHideForMeasure) {
        tooltip.style.visibility = '';
      }
    }

    function showTooltip(trigger, originEvent) {
      if (!trigger) {
        return;
      }
      var text = trigger.getAttribute('data-tooltip');
      if (!text) {
        return;
      }
      if (originEvent && typeof originEvent.clientX === 'number') {
        lastPointerX = originEvent.clientX;
      } else {
        lastPointerX = null;
      }
      if (activeTrigger === trigger && activeTooltip) {
        positionTooltip(trigger, activeTooltip, originEvent);
        return;
      }
      removeTooltip();
      clearHideTimer();
      var tooltip = doc.createElement('div');
      tooltip.className = 'ads-tooltip';
      tooltip.setAttribute('role', 'tooltip');
      tooltip.textContent = text;
      var id = ensureId(trigger);
      tooltip.id = id;
      if (!trigger.hasAttribute('aria-haspopup')) {
        trigger.setAttribute('aria-haspopup', 'true');
      }
      if (!trigger.hasAttribute('aria-expanded')) {
        trigger.setAttribute('aria-expanded', 'false');
      }
      trigger.setAttribute('aria-describedby', id);
      trigger.setAttribute('aria-expanded', 'true');
      doc.body.appendChild(tooltip);
      activeTrigger = trigger;
      activeTooltip = tooltip;
      positionTooltip(trigger, tooltip, originEvent);
      requestAnimationFrame(function () {
        if (activeTooltip === tooltip) {
          tooltip.classList.add('is-visible');
        }
      });
      tooltip.addEventListener('mouseenter', clearHideTimer, { passive: true });
      tooltip.addEventListener('mouseleave', function () {
        scheduleHide(120);
      });
    }

    function handleDocClick(event) {
      if (!activeTooltip) {
        return;
      }
      var target = event.target;
      if (activeTrigger && (activeTrigger === target || activeTrigger.contains(target))) {
        return;
      }
      if (activeTooltip && activeTooltip.contains(target)) {
        return;
      }
      removeTooltip();
    }

    function handleKeydown(event) {
      var key = event.key || event.keyCode;
      if (key === 'Escape' || key === 'Esc' || key === 27) {
        if (activeTooltip) {
          removeTooltip();
        }
      }
    }

    function handleReposition() {
      if (activeTooltip && activeTrigger) {
        positionTooltip(activeTrigger, activeTooltip);
      }
    }

    $(doc)
      .on('mouseenter.adsTooltip focusin.adsTooltip', '.ads-help-button', function (event) {
        showTooltip(this, event);
      })
      .on('mouseleave.adsTooltip', '.ads-help-button', function () {
        scheduleHide(140);
      })
      .on('focusout.adsTooltip', '.ads-help-button', function () {
        scheduleHide(0);
      })
      .on('click.adsTooltip', '.ads-help-button', function (event) {
        if (activeTrigger === this && activeTooltip) {
          removeTooltip();
          return;
        }
        showTooltip(this, event);
      });

    doc.addEventListener('keydown', handleKeydown, true);
    doc.addEventListener('click', handleDocClick, true);
    doc.addEventListener('touchstart', handleDocClick, true);
    window.addEventListener('scroll', handleReposition, true);
    window.addEventListener('resize', handleReposition, true);
  })(window.jQuery || window.$);

  var buildUrl = (window.DZ && window.DZ.buildUrl) || function(path){
    try { var base=(typeof window.site_url==='string'&&window.site_url)?window.site_url:(window.location.origin+window.location.pathname.replace(/[^\/]*$/,'')); if(base.slice(-1)!=='/') base+='/'; return new URL(String(path||'').replace(/^\//,''), base).toString(); } catch(_) { return String(path||''); }
  };
  var I18N = (window.DZ && typeof DZ.i18n === 'function') ? DZ.i18n : function(){ return ''; };
  /**
   * Dizzy – Crop & Upload Module (Popup)
   * ------------------------------------------------------------
   * Purpose: Client-side cropping, filters, and upload pipeline
   * Author : mstfoztrk (Envato-ready formatting)
   * Notes  :
   *  - Wrapped in a singleton guard to avoid duplicate execution when popup reloads the script
   *  - Uses delegated events (jQuery) per Envato reviewer expectations
   *  - All functions documented with JSDoc for readability & IDE intellisense
   */

  // ============================================================
  // #region Constants & Module State
  // ============================================================
  let currentIndex = 0;
  let isOpen = false;
  const appliedFilters = {};

  // Cache last known crop-frame size (needed when frame is hidden at upload time)
  let __lastFrameW = 0;
  let __lastFrameH = 0;
  // #endregion

  // ============================================================
  // #region Utilities (Filters, Canvas, Toast, Loader)
  // ============================================================
  /**
   * Map internal filter keys to valid CSS filter strings for canvas and preview.
   * @param {string} name
   * @returns {string}
   */
  function getCssFilterForName(name) {
    switch (name) {
      case 'moon':
        return 'grayscale(100%) contrast(1.1)';
      case 'gingham':
        return 'grayscale(100%) brightness(1.1)';
      case 'reyes':
        return 'brightness(1.1) contrast(0.85)';
      case 'sepia':
        return 'grayscale(100%) sepia(1)';
      case 'invert':
        return 'invert(1)';
      case 'brighten':
        return 'brightness(1.2)';
      case 'contrast':
        return 'contrast(1.5)';
      default:
        return 'none';
    }
  }

  /**
   * Convert a canvas to PNG Blob with a safe fallback for older browsers.
   * @param {HTMLCanvasElement} canvas
   * @param {(blob: Blob|null)=>void} cb
   */
  function canvasToBlobPNG(canvas, cb) {
    if (canvas && typeof canvas.toBlob === 'function') {
      canvas.toBlob(function (blob) {
        cb(blob);
      }, 'image/png');
    } else {
      // Fallback polyfill using toDataURL
      try {
        var dataURL = canvas.toDataURL('image/png');
        var parts = dataURL.split(',');
        var byteString = atob(parts[1]);
        var ab = new ArrayBuffer(byteString.length);
        var ia = new Uint8Array(ab);
        for (var i = 0; i < byteString.length; i++)
          ia[i] = byteString.charCodeAt(i);
        cb(new Blob([ab], { type: 'image/png' }));
      } catch (e) {
        cb(null);
      }
    }
  }

  /**
   * Show a temporary toast-like popup message.
   * @param {string} message
   * @param {number} [duration=5000]
   */
  function showTempPopup(message, duration) {
    duration = typeof duration === 'number' ? duration : 5000;
    var toast = document.createElement('div');
    toast.className = 'dizzy-temp-toast';
    toast.textContent = message;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'polite');
    toast.style.position = 'fixed';
    toast.style.left = '50%';
    toast.style.bottom = '24px';
    toast.style.transform = 'translateX(-50%)';
    toast.style.maxWidth = '90%';
    toast.style.zIndex = '99999';
    toast.style.background = 'rgba(0,0,0,0.85)';
    toast.style.color = '#fff';
    toast.style.padding = '10px 14px';
    toast.style.borderRadius = '8px';
    toast.style.fontSize = '14px';
    toast.style.lineHeight = '1.4';
    toast.style.boxShadow = '0 4px 16px rgba(0,0,0,0.25)';
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 200ms ease';
    document.body.appendChild(toast);
    requestAnimationFrame(function () {
      toast.style.opacity = '1';
    });
    setTimeout(function () {
      toast.style.opacity = '0';
      setTimeout(function () {
        if (toast && toast.parentNode) toast.parentNode.removeChild(toast);
      }, 250);
    }, duration);
  }

  /**
   * Ensure a single loading overlay exists inside the popup wrapper.
   * @param {string} [message]
   * @returns {JQuery}
   */
  function ensureLoading(message) {
    var $wrapper = $('.popUp-container .popup-wrapper').first();
    var $fallbackPopup = $('.popUp-container').first();
    var $loader = $('.loading-container').first();
    if (!$loader.length) {
      var html =
        '' +
        '<div class="loading-container absolute">' +
        '<div class="loader">' +
        '<div></div><div></div><div></div><div></div><div></div><div></div>' +
        '<div></div><div></div><div></div><div></div><div></div><div></div>' +
        '</div>' +
        '<p class="loading-text"></p>' +
        '</div>';
      var $node = $(html);
      $node.find('.loading-text').text(message || 'Please wait...');
      var $target = $wrapper.length
        ? $wrapper
        : $fallbackPopup.length
          ? $fallbackPopup
          : $(document.body);
      if ($target.css('position') === 'static') {
        $target.css('position', 'relative');
      }
      $target.append($node);
      $loader = $node;
    } else if (message) {
      $loader.find('.loading-text').text(message);
    }
    $loader.show();
    return $loader;
  }
  function removeLoading() {
    $('.loading-container').remove();
  }
  // #endregion

  function ensureVisibilityNotice() {
    if (window.DZ && typeof window.DZ.openVisibilityNotice === 'function') {
      return window.DZ.openVisibilityNotice;
    }

    function escapeHtml(value) {
      return String(value == null ? '' : value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    }

    function closeVisibilityNotice() {
      var existing = document.querySelector('.popUp-container[data-modal="visibility-guard"]');
      if (existing && existing.parentNode) {
        existing.parentNode.removeChild(existing);
      }
    }

    function openVisibilityNotice(options) {
      var opts = options || {};
      closeVisibilityNotice();

      var modal = document.createElement('div');
      modal.className = 'popUp-container';
      modal.setAttribute('data-modal', 'visibility-guard');

      var i18nFn = (window.DZ && typeof window.DZ.i18n === 'function') ? window.DZ.i18n : function(){ return ''; };
      var defaultOk = i18nFn('ui_ok') || 'OK';
      var cancelLabel = opts.cancelLabel || i18nFn('menu_cancel') || 'Cancel';
      var confirmLabel = opts.confirmLabel || defaultOk;
      var title = opts.title ? escapeHtml(opts.title) : '';
      var message = escapeHtml(opts.message || '');

      var html = '<div class="pm-sheet-container"><div class="pm-sheet" role="dialog" aria-modal="true">';
      if (title) {
        html += '<div class="pm-header flex align_items_justify_content full-width">' + title + '</div><div class="aud-sep"></div>';
      }
      html += '<div class="pm-message">' + message + '</div><div class="aud-sep"></div>';
      html += '<button type="button" class="pm-item pm-confirm">' + escapeHtml(confirmLabel) + '</button>';
      html += '</div>';
      html += '<button type="button" class="pm-cancel">' + escapeHtml(cancelLabel) + '</button>';
      html += '</div>';
      modal.innerHTML = html;

      modal.addEventListener('click', function (event) {
        var target = event.target;
        if (target.classList.contains('pm-confirm')) {
          closeVisibilityNotice();
          if (typeof opts.onConfirm === 'function') {
            if (opts.onConfirm() === false) {
              return;
            }
          } else if (opts.redirectUrl) {
            window.location.href = opts.redirectUrl;
            return;
          }
          if (opts.redirectUrl) {
            window.location.href = opts.redirectUrl;
          }
          return;
        }
        if (target.classList.contains('pm-cancel') || target === modal) {
          closeVisibilityNotice();
        }
      });

      document.body.appendChild(modal);
      return modal;
    }

    window.DZ = window.DZ || {};
    window.DZ.openVisibilityNotice = openVisibilityNotice;
    window.DZ.closeVisibilityNotice = closeVisibilityNotice;
    return openVisibilityNotice;
  }

  const openVisibilityNotice = ensureVisibilityNotice();

  function parseGuardBool(value) {
    if (typeof value === 'boolean') {
      return value;
    }
    if (typeof value === 'number') {
      return value === 1;
    }
    if (typeof value === 'string') {
      var normalized = value.trim().toLowerCase();
      return normalized === '1' || normalized === 'true' || normalized === 'yes';
    }
    return false;
  }

  function getVisibilityContext($source) {
    if (!$source || !$source.length) {
      return null;
    }
    var $root = $source.closest('.popUp-container');
    if (!$root.length) {
      return null;
    }
    var data = $root.data() || {};
    return {
      isCreator: typeof data.isCreator !== 'undefined' ? parseGuardBool(data.isCreator) : true,
      paymentsActive: typeof data.paymentsActive !== 'undefined' ? parseGuardBool(data.paymentsActive) : true,
      hasCreatorFlag: typeof data.isCreator !== 'undefined',
      hasPaymentsFlag: typeof data.paymentsActive !== 'undefined',
      creatorUrl: data.creatorUrl || '',
      creatorMessage: data.creatorMessage || '',
      creatorAction: data.creatorAction || '',
      paymentsMessage: data.paymentsMessage || '',
      paymentsAction: data.paymentsAction || '',
      cancelLabel: data.guardCancel || ''
    };
  }

  function resolvePaymentContext() {
    var $root = $('.popUp-container').first();
    return getVisibilityContext($root.length ? $root : null);
  }

  // ============================================================
  // #region Step Management (select -> crop -> finish)
  // ============================================================
  // View step controller: 'select' (pick files) -> 'crop' (edit) -> 'finish' (post)
  let currentStep = 'select';

  /**
   * Control visible panels (selection/crop/finish) and header buttons.
   * @param {'select'|'crop'|'finish'} step
   */
  function setStep(step) {
    currentStep = step;

    const $createBox = $('.create_media_box, .crop_media_box');
    const $cropContainer = $('.crop-container');
    const $finishBox = $('.crop-finish-and-post');
    const $goNext = $('#goNext');
    const $goBack = $('#goBack');
    const $uploadBtn = $('#uploadBtn');

    if (step === 'select') {
      $createBox.removeClass('none').addClass('d-flex');
      $cropContainer.addClass('none').removeClass('d-flex');
      if ($finishBox) $finishBox.addClass('none').removeClass('d-flex');
      $goNext.addClass('none');
      $goBack.addClass('none');
      $uploadBtn.addClass('none');
    } else if (step === 'crop') {
      $createBox.addClass('none').removeClass('d-flex');
      $cropContainer.removeClass('none').addClass('d-flex');
      __lastFrameW = $('.crop-frame').outerWidth() || __lastFrameW;
      __lastFrameH = $('.crop-frame').outerHeight() || __lastFrameH;
      if ($finishBox) $finishBox.addClass('none').removeClass('d-flex');
      $goNext.removeClass('none');
      $goBack.addClass('none');
      $uploadBtn.addClass('none');
    } else if (step === 'finish') {
      $createBox.addClass('none').removeClass('d-flex');
      $cropContainer.addClass('none').removeClass('d-flex');
      if ($finishBox) $finishBox.removeClass('none').addClass('d-flex');
      __lastFrameW = $('.crop-frame').outerWidth() || __lastFrameW;
      __lastFrameH = $('.crop-frame').outerHeight() || __lastFrameH;
      $goNext.addClass('none');
      $goBack.removeClass('none');
      $uploadBtn.removeClass('none');
    }
  }
  // #endregion

  // ============================================================
  // #region Navigation UI (prev/next)
  // ============================================================
  let totalImages = $('.crop-image').length;
  function updateNavButtons() {
    totalImages = $('.crop-image').length;
    const $prev = $('#prev');
    const $next = $('#next');
    if (totalImages <= 1) {
      $prev.hide();
      $next.hide();
      return;
    }
    if (currentIndex <= 0) {
      $prev.hide();
      $next.show();
    } else if (currentIndex >= totalImages - 1) {
      $prev.show();
      $next.hide();
    } else {
      $prev.show();
      $next.show();
    }
  }
  // #endregion

  // ============================================================
  // #region Image Sizing & State Init
  // ============================================================
  /** Initialize dataset & CSS to best-fit each image in the crop frame. */
  function initImageDataAttributes() {
    $('.crop-image img').each(function () {
      const $img = $(this);
      // Skip images that were already initialized to preserve user adjustments
      if ($img.attr('data-initialized') === '1') {
        return;
      }
      const frameWidth = $('.crop-frame').width();
      const frameHeight = $('.crop-frame').height();
      const imgEl = $img.get(0);
      if (!imgEl) return;
      if (
        !(imgEl.complete && imgEl.naturalWidth > 0 && imgEl.naturalHeight > 0)
      )
        return;

      const imgWidth = imgEl.naturalWidth;
      const imgHeight = imgEl.naturalHeight;
      const scaleX = frameWidth / imgWidth;
      const scaleY = frameHeight / imgHeight;
      const scale = Math.max(scaleX, scaleY);
      const newWidth = imgWidth * scale;
      const newHeight = imgHeight * scale;
      const offsetX = Math.round((frameWidth - newWidth) / 2);
      const offsetY = Math.round((frameHeight - newHeight) / 2);

      $img.css({
        width: newWidth + 'px',
        height: newHeight + 'px',
        left: offsetX + 'px',
        top: offsetY + 'px',
        transform: 'scale(1)',
      });

      $img.attr('data-base-scale', scale);
      $img.attr('data-zoom', 1);
      $img.attr('data-left', offsetX);
      $img.attr('data-top', offsetY);

      // initial & previous state
      $img.attr('data-init-left', offsetX);
      $img.attr('data-init-top', offsetY);
      $img.attr('data-init-zoom', 1);
      $img.attr('data-init-base-scale', scale);
      $img.attr('data-prev-left', offsetX);
      $img.attr('data-prev-top', offsetY);
      $img.attr('data-prev-zoom', 1);
      $img.attr('data-prev-base-scale', scale);
      $img.attr('data-initialized', '1');
    });
  }

  /** Show image by index and sync its saved transform/zoom/position. */
  function showImage(index) {
    if ($('.crop-image').length === 0) return;
    $('.crop-image').hide().eq(index).show();
    const $currentImg = $('.crop-image').eq(index).find('img');
    if ($currentImg.length === 0) return;

    const imgEl = $currentImg.get(0);
    if (!imgEl || !(imgEl.naturalWidth > 0 && imgEl.naturalHeight > 0)) return;

    const naturalWidth = imgEl.naturalWidth;
    const naturalHeight = imgEl.naturalHeight;

    let baseScale = parseFloat($currentImg.attr('data-base-scale'));
    let zoom = parseFloat($currentImg.attr('data-zoom'));
    let left = parseFloat($currentImg.attr('data-left'));
    let top = parseFloat($currentImg.attr('data-top'));
    const hasState =
      !isNaN(baseScale) && !isNaN(zoom) && !isNaN(left) && !isNaN(top);

    if (!hasState) {
      fitImageToFrame($currentImg);
      baseScale = parseFloat($currentImg.attr('data-base-scale')) || 1;
      zoom = 1;
      left = parseFloat($currentImg.css('left')) || 0;
      top = parseFloat($currentImg.css('top')) || 0;
      $currentImg.attr('data-zoom', zoom);
      $currentImg.attr('data-left', left);
      $currentImg.attr('data-top', top);
    }

    const newWidth = naturalWidth * baseScale * zoom;
    const newHeight = naturalHeight * baseScale * zoom;

    $currentImg.css({
      width: newWidth + 'px',
      height: newHeight + 'px',
      left: left + 'px',
      top: top + 'px',
      transform: 'scale(1)',
    });
    $('#zoom').val(zoom);
    enforceBoundaries($currentImg);
  }

  /** Compute best-fit cover sizing and center the image in the frame. */
  function fitImageToFrame($img) {
    if (!$img || $img.length === 0) return;
    const frameWidth = $('.crop-frame').width();
    const frameHeight = $('.crop-frame').height();
    const imgEl = $img.get(0);
    if (!imgEl || !(imgEl.naturalWidth > 0 && imgEl.naturalHeight > 0)) return;

    const imgWidth = imgEl.naturalWidth;
    const imgHeight = imgEl.naturalHeight;
    const scaleX = frameWidth / imgWidth;
    const scaleY = frameHeight / imgHeight;
    const scale = Math.max(scaleX, scaleY);
    const newWidth = imgWidth * scale;
    const newHeight = imgHeight * scale;
    const offsetX = Math.round((frameWidth - newWidth) / 2);
    const offsetY = Math.round((frameHeight - newHeight) / 2);

    $img.attr('data-natural-width', imgWidth);
    $img.attr('data-natural-height', imgHeight);
    $img.css({
      width: newWidth + 'px',
      height: newHeight + 'px',
      left: offsetX + 'px',
      top: offsetY + 'px',
    });
    $img.attr('data-base-scale', scale);
  }

  /** Keep the image within the crop frame bounds; update state attrs. */
  function enforceBoundaries($img) {
    if (!$img || $img.length === 0) return;
    const frame = document.querySelector('.crop-frame');
    if (!frame) return;
    const frameRect = frame.getBoundingClientRect();
    const el = $img.get(0);
    if (!el) return;
    const imgRect = el.getBoundingClientRect();

    let left = parseFloat($img.css('left')) || 0;
    let top = parseFloat($img.css('top')) || 0;

    const overflowX = imgRect.width - frameRect.width;
    const overflowY = imgRect.height - frameRect.height;

    if (overflowX < 0) {
      left = (frameRect.width - imgRect.width) / 2;
    } else {
      if (imgRect.left > frameRect.left) {
        left -= imgRect.left - frameRect.left;
      }
      if (imgRect.right < frameRect.right) {
        left += frameRect.right - imgRect.right;
      }
    }

    if (overflowY < 0) {
      top = (frameRect.height - imgRect.height) / 2;
    } else {
      if (imgRect.top > frameRect.top) {
        top -= imgRect.top - frameRect.top;
      }
      if (imgRect.bottom < frameRect.bottom) {
        top += frameRect.bottom - imgRect.bottom;
      }
    }

    $img.css({ left: Math.round(left) + 'px', top: Math.round(top) + 'px' });
    $img.attr('data-left', Math.round(left));
    $img.attr('data-top', Math.round(top));
  }
  // #endregion

  // ============================================================
  // #region Swiper Integration (local fallback & helpers)
  // (Removed: All Swiper helper functions now handled centrally)
  // #endregion

  // ============================================================
  // #region Upload Pipeline (render → formdata → ajax → finalize ad)
  // ============================================================
  /**
   * Handle AJAX success for cropped image upload.
   * @param {Object|string} res - Response from server (may be JSON or stringified JSON)
   */
  function handleUploadSuccess(res) {
    if (typeof res === 'string') {
      try {
        res = JSON.parse(res);
      } catch (e) {
        removeLoading();
        showTempPopup(I18N('ui_unexpected_server_response_retry') || 'Unexpected server response. Please try again.', 5000);
        return;
      }
    }
    if (
      !(res && res.status === 'success' && (res.ad_media || res.media_paths))
    ) {
      removeLoading();
      showTempPopup(res && res.message ? res.message : (I18N('ui_request_failed_retry') || 'Upload failed. Please try again.'), 5000);
      return;
    }

    // Proceed to finalize advertisement with returned media
    var adMedia =
      res.ad_media ||
      (Array.isArray(res.media_paths) ? res.media_paths.join(',') : '');
    finalizeAdvertisementImage(adMedia);
  }

  function normalizeAdLink(link) {
    if (!link) { return ''; }
    var trimmed = String(link).trim();
    if (trimmed === '') { return ''; }
    if (!/^https?:\/\//i.test(trimmed)) {
      trimmed = 'https://' + trimmed;
    }
    try {
      var parsed = new URL(trimmed);
      if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
        return '';
      }
      return parsed.toString();
    } catch (err) {
      return '';
    }
  }

  // Collect ad fields from finish step and finalize
  function finalizeAdvertisementImage(adMedia) {
    const csrfToken = $("input[name='csrf_token']").val() || '';
    const $box = $('.crop-finish-and-post');
    const title = $.trim($box.find("input[name='ad_title']").val() || '');
    const description = $.trim(
      $box.find("textarea[name='ad_description']").val() || '',
    );
    const linkRaw = $.trim($box.find("input[name='ad_link']").val() || '');
    const target = $.trim(
      $box.find("input[name='target_impressions']").val() || '0',
    );
    const ppi = $.trim(
      $box.find("input[name='price_per_impression']").val() || '0',
    );
    const days = $.trim($box.find("input[name='duration_days']").val() || '1');
    var budget = $.trim($box.find("input[name='total_budget']").val() || '0');
    const status = $box.find("select[name='ad_status']").val() || 'draft';

    if (!title) {
      removeLoading();
      showTempPopup(I18N('ads_enter_title') || 'Please enter a title.', 4000);
      return;
    }
    if (!description) {
      removeLoading();
      showTempPopup(I18N('ads_enter_description') || 'Please enter a description.', 4000);
      return;
    }
    var adLink = normalizeAdLink(linkRaw);
    if (!adLink) {
      removeLoading();
      showTempPopup(I18N('ads_enter_destination_url') || 'Please enter a valid destination URL.', 4500);
      return;
    }
    if (!adMedia) {
      removeLoading();
      showTempPopup(I18N('ui_no_content_to_insert') || 'No content to insert.', 4000);
      return;
    }
    var impNum = parseFloat(target);
    var ppiNum = parseFloat(ppi);
    var dayNum = parseInt(days, 10);
    if (!(impNum > 0)) {
      removeLoading();
      showTempPopup(I18N('ads_target_impressions_gt_zero') || 'Target impressions must be greater than 0.', 4500);
      return;
    }
    if (!(ppiNum > 0)) {
      removeLoading();
      showTempPopup(I18N('ads_ppi_gt_zero') || 'Price per impression must be greater than 0.', 4500);
      return;
    }
    if (!(dayNum >= 1)) {
      removeLoading();
      showTempPopup(I18N('ads_duration_days_min') || 'Duration (days) must be at least 1.', 4500);
      return;
    }
    // Minimum budget check (from global or fallback to 10)
    var MIN_AD_BUDGET =
      (window.MIN_AD_BUDGET && Number(window.MIN_AD_BUDGET)) || 10;
    var budNum = parseFloat(budget);
    if (!(budNum > 0)) {
      budNum = Math.round(impNum * ppiNum * 100) / 100;
    }
    if (budNum < MIN_AD_BUDGET) {
      removeLoading();
      var amt = '$' + (MIN_AD_BUDGET.toFixed ? MIN_AD_BUDGET.toFixed(2) : MIN_AD_BUDGET);
      showTempPopup(I18N('ui_min_total_budget', { amount: amt }) || ('Minimum total budget is ' + amt + '.'), 4500);
      return;
    }
    budget = String(budNum);

    // Auto-calc budget if left zero but inputs present
    var tInt = parseInt(target, 10);
    var pFloat = parseFloat(ppi);
    var bFloat = parseFloat(budget);
    if (
      (!Number.isFinite(bFloat) || bFloat <= 0) &&
      Number.isFinite(tInt) &&
      tInt > 0 &&
      Number.isFinite(pFloat) &&
      pFloat >= 0
    ) {
      bFloat = Math.round(tInt * pFloat * 100) / 100;
      budget = String(bFloat);
    }

    var fd = new FormData();
    fd.append('p', 'ads_finalize_image');
    fd.append('csrf_token', csrfToken);
    fd.append('ad_title', title);
    fd.append('ad_description', description);
    fd.append('ad_link', adLink);
    fd.append('target_impressions', target);
    fd.append('price_per_impression', ppi);
    fd.append('duration_days', days);
    fd.append('total_budget', budget);
    fd.append('ad_status', status);
    fd.append('ad_media', adMedia);

    ensureLoading((I18N('ui_saving_advertisement') || 'Saving advertisement...'));
    $.ajax({
        url: buildUrl('request/requests.php'),
      type: 'POST',
      data: fd,
      processData: false,
      contentType: false,
      success: function (res2) {
        removeLoading();
        var j = null;
        if (typeof res2 === 'string') {
          try {
            j = JSON.parse(res2);
          } catch (_) {}
        } else if (res2 && typeof res2 === 'object') {
          j = res2;
        }
        if (!j || j.status !== 'success') {
          showTempPopup(
            j && j.message ? j.message : 'Failed to save advertisement.',
            5000,
          );
          return;
        }
        var adId = j.ad_id || 0;
        if (adId) {
          $("input[name='ad_id']").val(String(adId));
          var payContext = resolvePaymentContext();
          var paymentsActive = true;
          if (payContext && payContext.hasPaymentsFlag) {
            paymentsActive = parseGuardBool(payContext.paymentsActive);
          }
          if (!paymentsActive) {
            openVisibilityNotice({
              message:
                (payContext && payContext.paymentsMessage) ||
                (I18N('post_visibility_payments_disabled') ||
                  'Payment methods are currently being improved. Please try again later.'),
              confirmLabel:
                (payContext && payContext.paymentsAction) ||
                (I18N('ui_ok') || 'OK'),
              cancelLabel:
                (payContext && payContext.cancelLabel) ||
                (I18N('menu_cancel') || 'Cancel')
            });
            return;
          }
          $('.payment_box').removeClass('none');
          // Hide uploadBtn to avoid duplicate finalize
          $('#uploadBtn').addClass('none');
          showTempPopup(
            j.message || 'Draft created. Choose payment method.',
            3500,
          );
        } else {
          showTempPopup('Missing advertisement id.', 5000);
        }
      },
      error: function () {
        removeLoading();
        showTempPopup(
          'An error occurred while saving the advertisement.',
          5000,
        );
      },
    });
  }

  /** Render each image to canvas, attach metadata, and upload via AJAX. */
  function uploadCroppedImages() {
    const csrfToken = $("input[name='csrf_token']").val();
    const formData = new FormData();
    formData.append('p', 'ads_upload_images');
    formData.append('csrf_token', csrfToken);

    const images = $('.crop-image img');

    let loaded = 0;
    let frameWidth = $('.crop-frame').outerWidth() || 0;
    let frameHeight = $('.crop-frame').outerHeight() || 0;
    if (!frameWidth || !frameHeight) {
      frameWidth = __lastFrameW || 600;
      frameHeight = __lastFrameH || 600;
    }
    if (!frameWidth || !frameHeight) {
      showTempPopup(
        (I18N('ui_upload_failed_crop_zero') || 'Upload failed: crop area size is 0. Please try again.'),
        5000,
      );
      return;
    }

    images.each(function (index, imgEl) {
      const $img = $(imgEl);
      const naturalWidth = imgEl.naturalWidth;
      const naturalHeight = imgEl.naturalHeight;

      let baseScale = parseFloat($img.attr('data-base-scale'));
      let zoom = parseFloat($img.attr('data-zoom'));
      if (!Number.isFinite(baseScale)) {
        const sx = frameWidth / naturalWidth;
        const sy = frameHeight / naturalHeight;
        baseScale = Math.max(sx, sy);
      }
      if (!Number.isFinite(zoom)) {
        zoom = 1;
      }

      const displayWidth = naturalWidth * baseScale * zoom;
      const displayHeight = naturalHeight * baseScale * zoom;

      let offsetLeft = parseFloat($img.attr('data-left'));
      let offsetTop = parseFloat($img.attr('data-top'));
      if (!Number.isFinite(offsetLeft))
        offsetLeft = parseFloat($img.css('left')) || 0;
      if (!Number.isFinite(offsetTop))
        offsetTop = parseFloat($img.css('top')) || 0;

      const scaleX = naturalWidth / displayWidth;
      const scaleY = naturalHeight / displayHeight;

      const cropX = -offsetLeft * scaleX;
      const cropY = -offsetTop * scaleY;
      const cropW = frameWidth * scaleX;
      const cropH = frameHeight * scaleY;

      const outW = Math.max(1, Math.round(cropW));
      const outH = Math.max(1, Math.round(cropH));

      const canvas = document.createElement('canvas');
      canvas.width = outW;
      canvas.height = outH;
      const ctx = canvas.getContext('2d');
      // Prefer highest quality resampling on supporting browsers
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';

      const filterName =
        appliedFilters[index] && appliedFilters[index].filter
          ? appliedFilters[index].filter
          : 'none';
      ctx.filter = getCssFilterForName(filterName);

      // Draw the exact crop region at its native resolution (no forced downscale)
      ctx.drawImage(imgEl, cropX, cropY, cropW, cropH, 0, 0, outW, outH);

      formData.append(
        `filters[]`,
        appliedFilters[index] && appliedFilters[index].filter
          ? appliedFilters[index].filter
          : 'none',
      );

      canvasToBlobPNG(canvas, function (blob) {
        if (!blob) {
          showTempPopup(
            (I18N('ui_unable_prepare_image') || 'Unable to prepare image data for upload. Please try again.'),
            5000,
          );
          loaded++;
          return;
        }

        formData.append('images[]', blob, `image_${index}.png`);
        const filter = appliedFilters[index]?.filter || 'none';
        formData.append(`filter_${index}`, filter);

        loaded++;
        if (loaded === images.length) {
          ensureLoading((I18N('ui_uploading_images') || 'Uploading images...'));
          $.ajax({
            url: buildUrl('request/requests.php'),
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: handleUploadSuccess,
            error: function () {
              removeLoading();
              showTempPopup(
                (I18N('ui_error_during_upload_retry') || 'An error occurred during upload. Please try again.'),
                5000,
              );
            },
          });
        }
      });
    });
  }
  // #endregion

  // ============================================================
  // #region Event Wiring (delegated handlers)
  // ============================================================
  $(document).ready(function () {
    // ===== Auto-calc Total Budget (image ads) =====
    function resolveCurrency($box) {
      var cfg = {
        code: ($box && $box.data('currencyCode')) || (window.DZ && DZ.currencyFormat && DZ.currencyFormat.code) || 'USD',
        symbol: ($box && $box.data('currencySymbol')) || (window.DZ && DZ.currencyFormat && DZ.currencyFormat.symbol) || '',
        precision: parseInt($box && $box.data('amountPrecision'), 10)
      };
      if (!isFinite(cfg.precision) || cfg.precision < 0) {
        var base = window.DZ && DZ.currencyFormat && typeof DZ.currencyFormat.decimalPlaces === 'number'
          ? DZ.currencyFormat.decimalPlaces
          : 2;
        cfg.precision = isFinite(base) && base >= 0 ? base : 2;
      }
      return cfg;
    }
    function formatDisplay(amount, cfg) {
      if (window.DZ && typeof window.DZ.formatCurrency === 'function') {
        return window.DZ.formatCurrency(amount, cfg.code, cfg.symbol);
      }
      var v = Number(amount);
      if (!Number.isFinite(v)) v = 0;
      return v.toFixed(cfg.precision) + ' ' + (cfg.symbol || cfg.code);
    }
    function formatInput(amount, cfg) {
      var v = Number(amount);
      if (!Number.isFinite(v)) v = 0;
      return v.toFixed(cfg.precision);
    }
    function recalcAdBudget() {
      var $box = $('.crop-finish-and-post');
      if (!$box.length) return;
      var curCfg = resolveCurrency($box);
      var imp = parseFloat(
        $box.find("input[name='target_impressions']").val() || '0',
      );
      var ppi = parseFloat(
        $box.find("input[name='price_per_impression']").val() || '0',
      );
      var auto = 0;
      if (
        Number.isFinite(imp) &&
        Number.isFinite(ppi) &&
        imp >= 0 &&
        ppi >= 0
      ) {
        auto = Math.round(imp * ppi * 100) / 100;
      }
      // Update hint
      var $hint = $box.find('.calc-hint .calc-value');
      if ($hint.length) {
        $hint.text(formatDisplay(auto, curCfg));
      }

      var $budget = $box.find("input[name='total_budget']");
      if (!$budget.length) return;
      // If user has not manually edited budget, keep it in sync
      var manual =
        $budget.data('manual') === 1 || $budget.data('manual') === '1';
      var prevAuto = $budget.data('prevAuto');
      if (
        !manual ||
        (typeof prevAuto !== 'undefined' &&
          String($budget.val()) === String(prevAuto))
      ) {
        var raw = formatInput(auto, curCfg);
        $budget.val(raw);
        $budget.data('prevAuto', raw);
      }
    }
    // Mark manual when user types in total_budget
    $(document).on('input', "input[name='total_budget']", function () {
      var $b = $(this);
      $b.data('manual', 1);
    });
    // Tie changes
    $(document).on(
      'input change',
      "input[name='target_impressions'], input[name='price_per_impression']",
      recalcAdBudget,
    );
    // Initial calc
    setTimeout(recalcAdBudget, 50);
    // Initialize current step from DOM
    (function initStepFromDOM() {
      const hasImages = $('.crop-image img').length > 0;
      const $finishBox = $('.crop-finish-and-post').first();
      const finishVisible = $finishBox.length
        ? !$finishBox.hasClass('none')
        : false;
      if (finishVisible) {
        setStep('finish');
      } else if (hasImages) {
        setStep('crop');
      } else {
        setStep('select');
      }
    })();

    // Header navigation buttons
    $(document).on('click', '#goNext', function () {
      setStep('finish');
    });
    $(document).on('click', '#goBack', function () {
      setStep('crop');
      if ($('.crop-image').length) {
        showImage(currentIndex);
        updateNavButtons();
      }
    });

    // Initialize image datasets if present
    if ($('.crop-image img').length) {
      initImageDataAttributes();
    }

    // Seed filter state for existing images
    $('.crop-image img').each(function (index) {
      appliedFilters[index] = { filter: 'none' };
    });

    // Filter buttons (assign & mark active)
    $(document).on('click', '.filter-btn', function () {
      const $img = $('.crop-image').eq(currentIndex).find('img');
      const filter = $(this).data('filter');
      let cssFilter = getCssFilterForName(filter);
      $img.css('filter', cssFilter);
      appliedFilters[currentIndex].filter = filter;
      $('.filter-btn').removeClass('active');
      $(this).addClass('active');
    });

    if ($('.crop-image').length) {
      showImage(currentIndex);
    }
    updateNavButtons();

    // Filter panel toggle & outside close
    $(document).on('click', '.open-filters', function (e) {
      e.stopPropagation();
      const $menu = $(this).parent().find('.filter-buttons');
      if (isOpen) {
        $menu.addClass('hidden');
      } else {
        $menu.removeClass('hidden');
      }
      isOpen = !isOpen;
    });
    $(document).on('click', function (e) {
      if (!$(e.target).closest('.filter-wrapper').length) {
        $('.filter-buttons').addClass('hidden');
        isOpen = false;
      }
    });

    // Image navigation (next/prev)
    $(document).on('click', '#next', function () {
      if (currentIndex < totalImages - 1) {
        currentIndex++;
        showImage(currentIndex);
        updateNavButtons();
      }
    });
    $(document).on('click', '#prev', function () {
      if (currentIndex > 0) {
        currentIndex--;
        showImage(currentIndex);
        updateNavButtons();
      }
    });

    // Original view (fit) & Restore previous view
    $(document).on('click', '#originalView', function () {
      const $img = $('.crop-image').eq(currentIndex).find('img');
      const currentZoom = parseFloat($img.attr('data-zoom')) || 1;
      const currentLeft = parseFloat($img.attr('data-left')) || 0;
      const currentTop = parseFloat($img.attr('data-top')) || 0;
      const currentBaseScale = parseFloat($img.attr('data-base-scale')) || 1;
      $img.attr('data-prev-zoom', currentZoom);
      $img.attr('data-prev-left', currentLeft);
      $img.attr('data-prev-top', currentTop);
      $img.attr('data-prev-base-scale', currentBaseScale);

      const naturalWidth = $img.get(0).naturalWidth;
      const naturalHeight = $img.get(0).naturalHeight;
      const frameWidth = $('.crop-frame').width();
      const frameHeight = $('.crop-frame').height();
      const scaleX = frameWidth / naturalWidth;
      const scaleY = frameHeight / naturalHeight;
      const fitScale = Math.min(scaleX, scaleY);
      const displayWidth = naturalWidth * fitScale;
      const displayHeight = naturalHeight * fitScale;
      const offsetX = Math.round((frameWidth - displayWidth) / 2);
      const offsetY = Math.round((frameHeight - displayHeight) / 2);

      $img.css({
        width: displayWidth + 'px',
        height: displayHeight + 'px',
        left: offsetX + 'px',
        top: offsetY + 'px',
        transform: 'scale(1)',
      });
      $img.attr('data-zoom', 1);
      $img.attr('data-base-scale', fitScale);
      $img.attr('data-left', offsetX);
      $img.attr('data-top', offsetY);
      $('#zoom').val(1);
    });

    $(document).on('click', '#restorePreviousView', function () {
      const $img = $('.crop-image').eq(currentIndex).find('img');
      if (!$img || $img.length === 0) return;
      let targetZoom = parseFloat($img.attr('data-prev-zoom'));
      let targetLeft = parseFloat($img.attr('data-prev-left'));
      let targetTop = parseFloat($img.attr('data-prev-top'));
      let targetBaseScale = parseFloat($img.attr('data-prev-base-scale'));
      if (
        isNaN(targetZoom) ||
        isNaN(targetLeft) ||
        isNaN(targetTop) ||
        isNaN(targetBaseScale)
      ) {
        targetZoom = parseFloat($img.attr('data-init-zoom')) || 1;
        targetLeft = parseFloat($img.attr('data-init-left')) || 0;
        targetTop = parseFloat($img.attr('data-init-top')) || 0;
        targetBaseScale = parseFloat($img.attr('data-init-base-scale')) || 1;
      }
      const el = $img.get(0);
      if (!el || !(el.naturalWidth > 0 && el.naturalHeight > 0)) return;
      const naturalWidth = el.naturalWidth;
      const naturalHeight = el.naturalHeight;
      const newWidth = naturalWidth * targetBaseScale * targetZoom;
      const newHeight = naturalHeight * targetBaseScale * targetZoom;
      $img.css({
        width: newWidth + 'px',
        height: newHeight + 'px',
        left: targetLeft + 'px',
        top: targetTop + 'px',
        transform: 'scale(1)',
      });
      $img.attr('data-zoom', targetZoom);
      $img.attr('data-base-scale', targetBaseScale);
      $img.attr('data-left', targetLeft);
      $img.attr('data-top', targetTop);
      $('#zoom').val(targetZoom);
      enforceBoundaries($img);
    });

    // Zoom slider
    $(document).on('input', '#zoom', function () {
      const zoom = parseFloat($(this).val());
      const $img = $('.crop-image').eq(currentIndex).find('img');
      if (!$img || $img.length === 0) return;
      const baseScale = parseFloat($img.attr('data-base-scale')) || 1;
      const naturalWidth = $img.get(0).naturalWidth;
      const naturalHeight = $img.get(0).naturalHeight;
      const oldWidth = $img.width();
      const oldHeight = $img.height();
      const oldLeft = parseFloat($img.css('left')) || 0;
      const oldTop = parseFloat($img.css('top')) || 0;
      const newWidth = naturalWidth * baseScale * zoom;
      const newHeight = naturalHeight * baseScale * zoom;
      const deltaX = (newWidth - oldWidth) / 2;
      const deltaY = (newHeight - oldHeight) / 2;
      const newLeft = oldLeft - deltaX;
      const newTop = oldTop - deltaY;
      $img.css({
        width: newWidth + 'px',
        height: newHeight + 'px',
        left: newLeft + 'px',
        top: newTop + 'px',
      });
      $img.attr('data-zoom', zoom);
      $img.attr('data-left', newLeft);
      $img.attr('data-top', newTop);
      enforceBoundaries($img);
    });

    // Setup drag interactions for each image
    $('.crop-image img').each(function () {
      initImageInteractions($(this));
    });

    // File input (#imageFileInput) – initial selection
    $(document).on('change', '#imageFileInput', function (event) {
      'use strict';
      const files = event.target.files;
      const $cropWrapper = $('.crop-images-wrapper');
      if (!files.length) return;
      var allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

      var validFiles = [];
      var allValid = true;
      Array.from(files).forEach(function (file) {
        var typeOk = file.type && allowedTypes.indexOf(file.type) !== -1;
        if (!typeOk) {
          var name = (file.name || '').toLowerCase();
          if (
            name.endsWith('.jpg') ||
            name.endsWith('.jpeg') ||
            name.endsWith('.png') ||
            name.endsWith('.webp') ||
            name.endsWith('.gif')
          ) {
            typeOk = true; // extension fallback when mime is missing
          }
        }
        if (!typeOk) {
          allValid = false;
        } else {
          validFiles.push(file);
        }
      });

      if (!allValid || validFiles.length === 0) {
        showTempPopup('Only JPEG, PNG, WEBP or GIF files are allowed.', 5000);
        setStep('select');
        $(this).val('');
        return;
      }

      $('.crop-images-wrapper').empty();
      var index = 0;
      validFiles.forEach(function (file) {
        var objectUrl = (window.URL || window.webkitURL).createObjectURL(file);
        var $imgDiv = $(
          '<div class="crop-image" data-index="' +
            index +
            '"><img draggable="false" /></div>',
        );
        var $img = $imgDiv.find('img');
        $img.attr('src', objectUrl);
        $img.one('load', function () {
          (window.URL || window.webkitURL).revokeObjectURL(objectUrl);
        });
        $cropWrapper.append($imgDiv);
        appliedFilters[index] = { filter: 'none' };
        initImageInteractions($img);
        index++;
      });

      totalImages = $('.crop-image').length;
      currentIndex = 0;
      setStep('crop');
      setTimeout(function () {
        initImageDataAttributes();
        showImage(currentIndex);
        updateNavButtons();
      }, 100);
      $(this).val('');
    });

    // File input (#fileInputMore) – append more images
    $(document).on('change', '#fileInputMore', function (event) {
      'use strict';
      const files = event.target.files;
      const $cropWrapper = $('.crop-images-wrapper');
      if (!files.length) return;
      var allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

      var validFiles = [];
      var allValid = true;
      Array.from(files).forEach(function (file) {
        var typeOk = file.type && allowedTypes.indexOf(file.type) !== -1;
        if (!typeOk) {
          var name = (file.name || '').toLowerCase();
          if (
            name.endsWith('.jpg') ||
            name.endsWith('.jpeg') ||
            name.endsWith('.png') ||
            name.endsWith('.webp') ||
            name.endsWith('.gif')
          ) {
            typeOk = true;
          }
        }
        if (!typeOk) {
          allValid = false;
        } else {
          validFiles.push(file);
        }
      });

      if (!allValid || validFiles.length === 0) {
        showTempPopup('Only JPEG, PNG, WEBP or GIF files are allowed.', 5000);
        $(this).val('');
        return;
      }

      var startIndex = $('.crop-image').length;
      setStep('crop');
      var index = startIndex;
      validFiles.forEach(function (file) {
        var objectUrl = (window.URL || window.webkitURL).createObjectURL(file);
        var $imgDiv = $(
          '<div class="crop-image" data-index="' +
            index +
            '"><img draggable="false" /></div>',
        );
        var $img = $imgDiv.find('img');
        $img.attr('src', objectUrl);
        $img.one('load', function () {
          (window.URL || window.webkitURL).revokeObjectURL(objectUrl);
        });
        $cropWrapper.append($imgDiv);
        appliedFilters[index] = { filter: 'none' };
        initImageInteractions($img);
        index++;
      });

      totalImages = $('.crop-image').length;
      if (totalImages > 0 && startIndex < totalImages) {
        currentIndex = startIndex;
        setTimeout(function () {
          initImageDataAttributes();
          showImage(currentIndex);
          updateNavButtons();
        }, 50);
      } else {
        updateNavButtons();
      }
      $(this).val('');
    });

    // Upload button (Finalize Ad)
    $(document).on('click', '#uploadBtn', function () {
      uploadCroppedImages();
    });

  // Start Payment
  $(document).on('click', '#startPayment', function () {
      var payContext = resolvePaymentContext();
      if (payContext && payContext.hasPaymentsFlag && !parseGuardBool(payContext.paymentsActive)) {
        openVisibilityNotice({
          message:
            (payContext && payContext.paymentsMessage) ||
            (I18N('post_visibility_payments_disabled') ||
              'Payment methods are currently being improved. Please try again later.'),
          confirmLabel:
            (payContext && payContext.paymentsAction) ||
            (I18N('ui_ok') || 'OK'),
          cancelLabel:
            (payContext && payContext.cancelLabel) ||
            (I18N('menu_cancel') || 'Cancel')
        });
        return;
      }
      var adId = parseInt($("input[name='ad_id']").val() || '0', 10);
      if (!adId) {
        showTempPopup('No draft advertisement to pay for.', 5000);
        return;
      }
      var provider = $("input[name='pay_provider']:checked").val() || 'stripe';
      var mode = $("input[name='pay_mode']:checked").val() || 'one_time';
      var fd = new FormData();
      fd.append('p', 'ads_create_payment');
      fd.append('csrf_token', $("input[name='csrf_token']").val() || '');
      fd.append('provider', provider);
      fd.append('mode', mode);
      fd.append('ad_id', String(adId));
      ensureLoading((I18N('ui_creating_checkout') || 'Creating checkout...'));
      $.ajax({
        url: buildUrl('request/requests.php'),
        type: 'POST',
        data: fd,
        processData: false,
        contentType: false,
        success: function (res) {
          removeLoading();
          var j = null;
          if (typeof res === 'string') {
            try {
              j = JSON.parse(res);
            } catch (_) {}
          } else if (res && typeof res === 'object') {
            j = res;
          }
          if (!j || j.status !== 'success') {
            showTempPopup(
              j && j.message ? j.message : 'Failed to start payment.',
              5000,
            );
            return;
          }
          if (j.provider === 'wallet') {
            showTempPopup(j.message || 'Payment completed from wallet.', 4000);
            setTimeout(function(){ window.location.reload(); }, 1200);
            return;
          }
          if (j.checkout_url) {
            window.location.href = j.checkout_url;
            return;
          }
          showTempPopup('Payment could not be initiated.', 5000);
        },
        error: function () {
          removeLoading();
          showTempPopup('Payment init failed.', 5000);
        },
      });
    });
  });

  // Enforce provider availability by mode
  function toggleProvidersByMode() {
    var mode = $("input[name='pay_mode']:checked").val() || 'one_time';
    var $np = $("input[name='pay_provider'][value='nowpayments']");
    var $cb = $("input[name='pay_provider'][value='coinbase']");
    var disallow = (mode === 'subscription');
    [$np, $cb].forEach(function($el){
      if (!$el.length) return;
      if (disallow) {
        $el.prop('disabled', true);
        // If currently selected, fallback to Stripe
        if ($el.is(':checked')) {
          $("input[name='pay_provider'][value='stripe']").prop('checked', true);
        }
      } else {
        $el.prop('disabled', false);
      }
    });
  }
  $(document).on('change', "input[name='pay_mode']", toggleProvidersByMode);
  // Run once on init (in case payment box is visible by default)
  toggleProvidersByMode();
  // #endregion

  // ============================================================
  // #region Interactions (drag/move + grid overlay)
  // ============================================================
  /** Bind drag interactions and grid overlay behavior for a given <img>. */
  function initImageInteractions($img) {
    let isDragging = false;
    let startX, startY, initialLeft, initialTop;
    const container = $img.parent();

    container.on('mousedown touchstart', function (e) {
      e.preventDefault();
      isDragging = true;
      const evt = e.type === 'touchstart' ? e.originalEvent.touches[0] : e;
      startX = evt.pageX;
      startY = evt.pageY;
      initialLeft = parseFloat($img.css('left')) || 0;
      initialTop = parseFloat($img.css('top')) || 0;
    });

    $(document).on('mousemove.cropimg touchmove.cropimg', function (e) {
      if (!isDragging) return;
      if (isDragging && e.type.indexOf('touch') === 0) {
        e.preventDefault();
      }
      const evt =
        e.type.indexOf('touch') === 0
          ? e.originalEvent.touches[0] || e.originalEvent.changedTouches[0]
          : e;
      const dx = evt.pageX - startX;
      const dy = evt.pageY - startY;
      const newLeft = initialLeft + dx;
      const newTop = initialTop + dy;
      $img.css({ left: newLeft + 'px', top: newTop + 'px' });
      $img.attr('data-left', newLeft);
      $img.attr('data-top', newTop);
      enforceBoundaries($img);
    });

    $(document).on(
      'mouseup.cropimg touchend.cropimg touchcancel.cropimg',
      function () {
        isDragging = false;
      },
    );

    const gridOverlay = $('.grid-overlay');
    gridOverlay.css('pointer-events', 'none');
    $('.crop-frame').on('mousedown', function (e) {
      if ($(e.target).closest('.prev_button, .next_button').length) return;
      gridOverlay.removeClass('none');
    });
    $(document).on('mouseup', () => gridOverlay.addClass('none'));
    $('.crop-frame').on('touchstart', function (e) {
      if ($(e.target).closest('.prev_button, .next_button').length) return;
      gridOverlay.removeClass('none');
    });
    $(document).on('touchend', () => gridOverlay.addClass('none'));
    $(document).on(
      'mousedown touchstart',
      '.prev_button, .next_button',
      function (e) {
        e.stopPropagation();
      },
    );
  }
  // #endregion
})(window);
