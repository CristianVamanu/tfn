'use strict';
(function () {
  var root = document.querySelector('.audio-room-create-shell');
  if (!root || root.dataset.bound === '1') { return; }
  root.dataset.bound = '1';

  function $(selector) { return root.querySelector(selector); }
  function csrf() {
    var token = root.querySelector('input[name="csrf_token"]');
    return token ? token.value : '';
  }
  function url(path) {
    if (typeof window.buildUrl === 'function') { return window.buildUrl(path); }
    return path;
  }
  function i18n(key, fallback, params) {
    try {
      if (window.DZ && typeof window.DZ.i18n === 'function') {
        var value = window.DZ.i18n(key, params || {});
        if (value) { return value; }
      }
    } catch (_) {}
    var text = fallback || key || '';
    if (params) {
      Object.keys(params).forEach(function (name) {
        text = text.replace(new RegExp('\\{\\{?' + name + '\\}?\\}', 'g'), params[name]);
      });
    }
    return text;
  }
  function serverMessage(code, fallback) {
    var map = {
      audio_room_custom_price_disabled: 'audio_room_error_custom_price_disabled',
      audio_room_daily_limit_reached: 'audio_room_error_daily_limit_reached',
      audio_room_paid_not_allowed: 'audio_room_error_paid_not_allowed',
      audio_room_price_out_of_range: 'audio_room_error_price_out_of_range',
      audio_rooms_disabled: 'audio_room_error_disabled',
      invalid_audio_room_price: 'audio_room_error_invalid_price'
    };
    return map[code] ? i18n(map[code], fallback || code) : (fallback || code || i18n('audio_room_error_generic', 'Something went wrong.'));
  }
  function status(message, type) {
    var box = $('.audio-room-create__status');
    if (!box) {
      box = document.createElement('div');
      box.className = 'audio-room-create__status';
      var form = $('.audio-room-create');
      if (form) { form.appendChild(box); }
    }
    box.textContent = message || '';
    box.dataset.type = type || 'info';
  }
  function activePrice(value) {
    root.querySelectorAll('.audio-room-price').forEach(function (button) {
      button.classList.toggle('active', String(button.dataset.price || '') === String(value || ''));
    });
    var hidden = $('#audioRoomEntryPrice');
    if (hidden) { hidden.value = value || ''; }
  }
  function refresh() {
    var title = ($('#audioRoomTitle') || {}).value || '';
    var button = $('#createAudioRoomBtn');
    var disabled = root.getAttribute('data-audio-disabled') === '1' || title.trim().length < 3;
    if (button) {
      button.disabled = disabled;
      button.classList.toggle('disabled', disabled);
    }
  }

  var titleInput = $('#audioRoomTitle');
  if (titleInput) {
    titleInput.addEventListener('input', refresh);
    refresh();
  }

  root.querySelectorAll('.audio-room-segmented__item').forEach(function (button) {
    button.addEventListener('click', function () {
      root.querySelectorAll('.audio-room-segmented__item').forEach(function (item) { item.classList.remove('active'); });
      button.classList.add('active');
      var hidden = $('#audioRoomAudience');
      if (hidden) { hidden.value = button.dataset.audience || 'everyone'; }
    });
  });

  var paid = $('#audioRoomPaid');
  if (paid) {
    paid.addEventListener('change', function () {
      var panel = $('#audioRoomPricePanel');
      if (panel) { panel.classList.toggle('none', !paid.checked); }
      if (!paid.checked) { activePrice(''); }
    });
  }

  root.querySelectorAll('.audio-room-price').forEach(function (button) {
    button.addEventListener('click', function () {
      activePrice(button.dataset.price || '');
      var custom = $('#audioRoomCustomPrice');
      if (custom) { custom.value = ''; }
    });
  });

  var customPrice = $('#audioRoomCustomPrice');
  if (customPrice) {
    customPrice.addEventListener('input', function () {
      activePrice(customPrice.value || '');
    });
  }

  var createButton = $('#createAudioRoomBtn');
  if (createButton) {
    createButton.addEventListener('click', function () {
      if (createButton.disabled) { return; }
      var fd = new FormData();
      fd.append('p', 'create_audio_room');
      fd.append('csrf_token', csrf());
      fd.append('title', (($('#audioRoomTitle') || {}).value || '').trim());
      fd.append('description', (($('#audioRoomDescription') || {}).value || '').trim());
      fd.append('audience', (($('#audioRoomAudience') || {}).value || 'everyone'));
      fd.append('is_paid', paid && paid.checked ? '1' : '0');
      if (paid && paid.checked) {
        fd.append('entry_price', (($('#audioRoomEntryPrice') || {}).value || '').trim());
      }
      createButton.disabled = true;
      createButton.classList.add('disabled');
      status(i18n('audio_room_creating_room', 'Creating room...'), 'info');
      fetch(url('request/requests.php'), {
        method: 'POST',
        body: fd,
        credentials: 'same-origin'
      })
        .then(function (response) { return response.json(); })
        .then(function (res) {
          if (res && res.status === 'success' && res.url) {
            window.location.href = res.url;
            return;
          }
          status((res && res.message) ? serverMessage(res.message, res.message) : i18n('audio_room_create_failed', 'Could not create audio room.'), 'error');
          createButton.disabled = false;
          createButton.classList.remove('disabled');
        })
        .catch(function () {
          status(i18n('audio_room_request_failed', 'Request failed.'), 'error');
          createButton.disabled = false;
          createButton.classList.remove('disabled');
        });
    });
  }
})();
