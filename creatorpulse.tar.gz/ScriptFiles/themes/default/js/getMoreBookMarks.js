/* getMoreImages.js
 * Minimal, dev-friendly infinite scroll for the images feed.
 * - Uses IntersectionObserver to trigger loading when sentinel enters viewport.
 * - Prevents duplicate requests with an isLoading flag.
 */

(function () {
  "use strict";

  // ---- DOM refs ----
  var feedEl     = document.getElementById("images-feed");
  var sentinelEl = document.getElementById("images-infinite-sentinel");
  var loadingEl  = document.getElementById("images-loading");

  if (!feedEl || !sentinelEl) { return; }

  // ---- Config/state ----
  var limit     = parseInt(feedEl.getAttribute("data-limit"), 10) || 10;
  var offset    = parseInt(feedEl.getAttribute("data-offset"), 10) || 0;
  var isLoading = false;
  var hasMore   = true;

  // Helper: read CSRF token from the hidden input placed globally
  function getCsrf() {
    var el = document.querySelector('input[name="csrf_token"]');
    return el ? el.value : "";
  }

  // Helper: read site_url from global (fallback to '/')
  function getSiteUrl() {
    try {
      // eslint-disable-next-line no-undef
      return (typeof site_url !== "undefined" && site_url) ? site_url : "/";
    } catch (e) {
      return "/";
    }
  }

  // UI helpers
  function showLoading() { if (loadingEl) { loadingEl.classList.remove("none"); } }
  function hideLoading() { if (loadingEl) { loadingEl.classList.add("none"); } }

  // Core loader
  async function loadMore() {
    if (isLoading || !hasMore) { return; }
    isLoading = true;
    showLoading();

    try {
      var form = new FormData();
      form.append("p", "getMoreBookmarks");
      form.append("limit", String(limit));
      form.append("offset", String(offset));
      form.append("csrf_token", getCsrf());

      var endpoint = (typeof window.buildUrl === 'function')
        ? window.buildUrl('request/requests.php')
        : ((typeof window.site_url !== 'undefined' && window.site_url) ? (window.site_url + 'request/requests.php') : 'request/requests.php');
      var resp = await fetch(endpoint, {
        method: "POST",
        credentials: "same-origin",
        body: form
      });

      if (!resp.ok) { throw new Error("Network error: " + resp.status); }

      var data = await resp.json();
      if (data && data.status === "ok") {
        // Append HTML tiles
        if (data.html) {
          // Use a temporary container to avoid reflow cost on string concatenation
          var wrapper = document.createElement("div");
          wrapper.innerHTML = data.html;
          while (wrapper.firstChild) {
            feedEl.insertBefore(wrapper.firstChild, sentinelEl);
          }
        }

        // Update pagination state
        offset  = parseInt(data.next_offset, 10) || (offset + limit);
        hasMore = !!data.has_more;

        // Persist offset to DOM (useful for debugging / future hooks)
        feedEl.setAttribute("data-offset", String(offset));

        // If no more content, stop observing
        if (!hasMore && observer) {
          observer.unobserve(sentinelEl);
        }
      } else {
        // Soft fail: keep hasMore true to allow retry on next intersection
        console.warn("getMoreBookmarks responded with non-ok status", data);
      }
    } catch (err) {
      console.error("getMoreBookmarks failed:", err);
      // Allow user to retry by keeping hasMore as is, but clear loading state
    } finally {
      hideLoading();
      isLoading = false;
    }
  }

  // IntersectionObserver to trigger loadMore when sentinel is visible
  var observer = new IntersectionObserver(function (entries) {
    for (var i = 0; i < entries.length; i++) {
      if (entries[i].isIntersecting) {
        loadMore();
      }
    }
  }, {
    root: null,
    rootMargin: "600px 0px 600px 0px", // prefetch a bit earlier
    threshold: 0
  });

  observer.observe(sentinelEl);
})();
