(function (window, $) {
  'use strict';
  var buildUrl = (window.DZ && window.DZ.buildUrl) || function(path){
    try { var base=(typeof window.site_url==='string'&&window.site_url)?window.site_url:(window.location.origin+window.location.pathname.replace(/[^\/]*$/,'')); if(base.slice(-1)!=='/') base+='/'; return new URL(String(path||'').replace(/^\//,''), base).toString(); } catch(_) { return String(path||''); }
  };

  /**
   * ExploreGrid
   * ------------
   * Infinite scroll loader for the Explore page.
   *
   * Key points:
   * - Uses IntersectionObserver (IO) to detect when the sentinel is near viewport.
   * - Includes a Safari-friendly fallback using scroll/resize when IO gets flaky
   *   (observed especially with very small CSS gaps in grid layouts).
   * - CSRF token is read from a hidden input and refreshed from server responses.
   * - Newly fetched HTML chunks are inserted right before the sentinel.
   *
   * Assumptions:
   * - `#explore-root` exists and exposes data-* attributes for cursor/limits/etc.
   * - `#explore-sentinel` exists at the end of the grid/list.
   * - Global `site_url` and jQuery ($) are available.
   */
  var Explore = {
    // State flags
    busy: false,          // prevent parallel loads
    hasMore: false,       // server indicates whether more content is available

    // Cursor for pagination (time + id is safer than offset for dynamic feeds)
    cursor: { time: 0, id: 0 },

    // Runtime handles
    io: null,             // IntersectionObserver instance
    $root: null,          // $('#explore-root')
    $sentinel: null,      // $('#explore-sentinel')

    // Layout preferences
    startLayout: 'right', // or 'left' (server alternates columns)

    // Security
    csrf: '',

    // Config (tuned for Safari reliability without hurting others)
    IO_ROOT_MARGIN: '1200px 0px 1200px 0px', // preload generously
    IO_THRESHOLD: [0, 0.01],                 // trigger on tiniest intersections
    FALLBACK_DISTANCE: 1600,                 // px from bottom to trigger load
    FALLBACK_THROTTLE_MS: 200,

    /**
     * Initialize module. Call on DOM ready.
     */
    init: function () {
      if (window.console && console.log) {
        console.log('[Explore] init start');
      }
      this.$root = $('#explore-root');
      if (!this.$root.length) { return; }

      this.$sentinel = $('#explore-sentinel');
      if (this.$sentinel.length) {
        // Tag sentinel for optional CSS (e.g., min-height). No inline styles here.
        this.$sentinel.addClass('io-sentinel');
      }

      // Read initial state from DOM (server-controlled)
      this.cursor.time = parseInt(this.$root.attr('data-cursor-time') || '0', 10);
      this.cursor.id   = parseInt(this.$root.attr('data-cursor-id')   || '0', 10);
      this.hasMore     = (this.$root.attr('data-has-more') === '1');
      this.limit       = parseInt(this.$root.attr('data-limit') || '25', 10);
      this.startLayout = (this.$root.attr('data-start-layout') === 'left') ? 'left' : 'right';

      // Bind CSRF token from hidden input
      var $csrf = $('input[name="csrf_token"]');
      this.csrf = $csrf.length ? ($csrf.val() || '') : '';

      // Set up IntersectionObserver (primary mechanism)
      this._setupObserver();

      // Attach the fallback (non-invasive, passive listeners)
      this._attachFallback();

      // Kick IO after initial layout/paint — helps Safari recalc intersections
      var self = this;
      setTimeout(function () {
        self._nudgeObserver();
        // Run one fallback tick as a gentle kickstart
        self._fallbackTick();
      }, 50);
    },

    /**
     * Configure IntersectionObserver with Safari-friendly parameters.
     */
    _setupObserver: function () {
      var self = this;
      if (!('IntersectionObserver' in window)) {
        this.io = null;
        return;
      }
      this.io = new IntersectionObserver(function (entries) {
        var e = entries && entries[0];
        if (!e) { return; }
        if (window.console && console.log) {
          console.log('[Explore] IO fired', { ratio: e.intersectionRatio, isIntersecting: e.isIntersecting });
        }

        // Some Safari builds report intersectionRatio > 0 while isIntersecting stays false
        if (e.isIntersecting || e.intersectionRatio > 0) {
          self.loadMore();
        }
      }, {
        root: null,
        rootMargin: this.IO_ROOT_MARGIN,
        threshold: this.IO_THRESHOLD
      });

      if (this.$sentinel.length) {
        this.io.observe(this.$sentinel.get(0));
      }
    },

    /**
     * Gently re-arm the observer to force a fresh geometry read (Safari quirk).
     */
    _nudgeObserver: function () {
      if (!this.io || !this.$sentinel || !this.$sentinel.length) { return; }
      try { this.io.unobserve(this.$sentinel.get(0)); } catch (err) { /* noop */ }
      try { this.io.observe(this.$sentinel.get(0)); }  catch (err) { /* noop */ }
    },

    /**
     * Attach passive scroll/resize listeners for a near-bottom fallback.
     * This keeps the UX unblocked if IO silently fails in edge cases.
     */
    _attachFallback: function () {
      var self = this;
      this._fallbackBusy = false;

      this._fallbackHandler = function () {
        // Throttle to reduce layout thrash and work during rapid scrolls
        if (self._fallbackBusy) { return; }
        self._fallbackBusy = true;
        setTimeout(function () { self._fallbackBusy = false; }, self.FALLBACK_THROTTLE_MS);
        self._fallbackTick();
      };

      window.addEventListener('scroll', this._fallbackHandler, { passive: true });
      window.addEventListener('resize', this._fallbackHandler, { passive: true });
    },

    /**
     * One pass of the near-bottom detector.
     */
    _fallbackTick: function () {
      var doc = document.documentElement;
      var scrollTop = (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
      var viewport = window.innerHeight || doc.clientHeight;
      var full = Math.max(doc.scrollHeight, doc.offsetHeight, doc.clientHeight);
      var distanceToBottom = full - (scrollTop + viewport);

      if (window.console && console.log) {
        console.log('[Explore] fallback tick', { distanceToBottom: distanceToBottom });
      }

      if (distanceToBottom < this.FALLBACK_DISTANCE) {
        this.loadMore();
      }
    },

    /**
     * Detach the fallback listeners when no more content is available.
     */
    _detachFallback: function () {
      if (this._fallbackHandler) {
        window.removeEventListener('scroll', this._fallbackHandler, { passive: true });
        window.removeEventListener('resize', this._fallbackHandler, { passive: true });
      }
    },

    /**
     * Request and append more content.
     * - Debounced by `busy` to avoid race conditions.
     * - Updates cursor, hasMore, CSRF token.
     * - Re-arms the observer after DOM mutations to stabilize Safari.
     */
    loadMore: function () {
      if (this.busy) {
        if (window.console && console.log) { console.log('[Explore] loadMore skipped (busy)'); }
        return;
      }
      if (!this.hasMore) {
        if (window.console && console.log) { console.log('[Explore] loadMore skipped (hasMore=false)'); }
        return;
      }
      this.busy = true;

      var self = this;

      var form = new FormData();
      form.append('p', 'explore_more');
      form.append('cursor_time', String(this.cursor.time));
      form.append('cursor_id',   String(this.cursor.id));
      form.append('limit',       String(this.limit));
      form.append('start_layout', this.startLayout);
      form.append('csrf_token',  this.csrf || '');

      fetch(buildUrl('request/requests.php'), {
        method: 'POST',
        credentials: 'same-origin',
        body: form
      }).then(function (resp) {
        if (!resp.ok) { throw new Error('HTTP ' + resp.status); }
        return resp.json();
      }).then(function (res) {
        if (window.console && console.log) {
          console.log('[Explore] loadMore response', res);
        }
        if (!res || res.status !== 'ok') { return; }

        if (res.csrf_token) {
          self.csrf = res.csrf_token;
          var $csrf = $('input[name="csrf_token"]');
          if ($csrf.length) { $csrf.val(self.csrf); }
        }

        if (res.next_start_layout) {
          self.startLayout = (res.next_start_layout === 'left') ? 'left' : 'right';
        }

        var htmlChunk = '';
        if (Array.isArray(res.blocks_html) && res.blocks_html.length) {
          htmlChunk = res.blocks_html.join('');
        } else if (res.html) {
          htmlChunk = (res.html || '').trim();
        }

        if (htmlChunk !== '') {
          var sentinelNode = (self.$sentinel && self.$sentinel.length) ? self.$sentinel.get(0) : null;
          var wrapper = document.createElement('div');
          wrapper.innerHTML = htmlChunk;
          if (sentinelNode && sentinelNode.parentNode) {
            while (wrapper.firstChild) {
              sentinelNode.parentNode.insertBefore(wrapper.firstChild, sentinelNode);
            }
          } else {
            var gridFallback = self.$root.find('.explore-grid').get(0) || self.$root.get(0);
            while (wrapper.firstChild) {
              gridFallback.appendChild(wrapper.firstChild);
            }
          }
          if (window.console && console.log) {
            var count = self.$root.find('.explore-grid > section.explore-block').length;
            console.log('[Explore] appended chunk via DOM nodes, total sections:', count);
          }
          self._nudgeObserver();
        } else if (window.console && console.error) {
          console.error('[Explore] received empty chunk');
        }

        self.hasMore = !!res.has_more;
        if (res.next_cursor) {
          self.cursor.time = parseInt(res.next_cursor.time || '0', 10);
          self.cursor.id   = parseInt(res.next_cursor.id   || '0', 10);
        }

        if (!self.hasMore) {
          if (self.io && self.$sentinel && self.$sentinel.length) {
            try { self.io.unobserve(self.$sentinel.get(0)); } catch (err) { /* noop */ }
          }
          self._detachFallback();
        }
      }).catch(function (err) {
        console.error('[Explore] loadMore failed', err);
      }).finally(function () {
        self.busy = false;
      });
    }
  };

  // Auto-init on DOM ready
  $(function () {
    Explore.init();
  });

  // Optional: expose for debugging/telemetry hooks
  window.ExploreGrid = Explore;

})(window, jQuery);
