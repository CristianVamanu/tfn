(function(){
  'use strict';

  function ready(fn){
    if(document.readyState !== 'loading'){ fn(); }
    else { document.addEventListener('DOMContentLoaded', fn); }
  }

  function $(sel, root){ return (root || document).querySelector(sel); }
  function $all(sel, root){ return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function resolveFormAction(form){
    if (!form) { return ''; }
    try {
      // `form.action` returns an absolute URL resolved by the browser.
      var direct = form.action && String(form.action).trim();
      if (direct) { return direct; }
    } catch (_) {}
    try {
      var attr = form.getAttribute('action');
      if (attr && attr.trim() !== '') {
        return attr.trim();
      }
    } catch (_) {}
    return '';
  }

  function fetchJson(url, options){
    return fetch(url, options || {}).then(function(res){
      if (!res.ok) {
        var err = new Error('HTTP_' + res.status);
        err.status = res.status;
        throw err;
      }
      return res.json().catch(function(){
        var err = new Error('INVALID_JSON');
        err.status = res.status;
        throw err;
      });
    });
  }

  function toFormData(params){
    var fd = new FormData();
    Object.keys(params || {}).forEach(function(key){
      fd.append(key, params[key]);
    });
    return fd;
  }

  function setAlert(el, type, msg){
    if (!el) { return; }
    el.textContent = msg || '';
    el.classList.remove('is-error', 'is-success');
    if (!msg) { return; }
    el.classList.add(type === 'success' ? 'is-success' : 'is-error');
  }

  function setFieldFeedback(root, key, msg){
    if (!root) { return; }
    var target = root.querySelector('[data-feedback="' + key + '"]');
    if (target) { target.textContent = msg || ''; }
  }

  function evaluateStrength(pwd){
    var score = 0;
    if (pwd.length >= 8) { score += 1; }
    if (pwd.length >= 12) { score += 1; }
    if (/[a-z]/.test(pwd) && /[A-Z]/.test(pwd)) { score += 1; }
    if (/\d/.test(pwd) || /[^A-Za-z0-9]/.test(pwd)) { score += 1; }
    if (/[^A-Za-z0-9]/.test(pwd)) { score += 1; }
    if (score > 4) { score = 4; }
    var percent = [10, 30, 55, 80, 100][score];
    return { score: score, percent: percent };
  }

  function copyToClipboard(text){
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text);
    }
    return new Promise(function(resolve, reject){
      var textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.setAttribute('readonly', '');
      textarea.style.position = 'absolute';
      textarea.style.left = '-9999px';
      document.body.appendChild(textarea);
      textarea.select();
      try {
        var ok = document.execCommand('copy');
        document.body.removeChild(textarea);
        if (ok) { resolve(); }
        else { reject(new Error('COPY_FAILED')); }
      } catch (err) {
        document.body.removeChild(textarea);
        reject(err);
      }
    });
  }

  ready(function(){
    var root = document.querySelector('.security-dashboard') || document.querySelector('.security-settings');
    if (!root) { return; }

    var config = {};
    try { config = JSON.parse(root.getAttribute('data-security-config') || '{}'); }
    catch (_) { config = {}; }

    var endpoint = config.endpoint || '';
    var csrf = config.csrf || '';
    var strings = config.strings || {};
    var strengthLabels = config.strengthLabels || [];
    var statusOn = config.statusOn || strings.twoFactorEnabled || '';
    var statusOff = config.statusOff || strings.twoFactorDisabled || '';

    var backupList = root.querySelector('[data-backup-list]');
    var backupCodesList = root.querySelector('[data-backup-codes]');
    var backupCopyBtn = root.querySelector('[data-backup-copy]');
    var backupDownloadBtn = root.querySelector('[data-backup-download]');
    var backupLastGenerated = root.querySelector('[data-backup-last-generated]');
    var backupAlert = root.querySelector('[data-backup-alert]');

    function renderBackupCodes(codes){
      if (!backupCodesList) { return; }
      backupCodesList.innerHTML = '';
      if (Array.isArray(codes) && codes.length) {
        codes.forEach(function(code){
          var li = document.createElement('li');
          li.textContent = code;
          backupCodesList.appendChild(li);
        });
        if (backupList) { backupList.hidden = false; }
        backupCodesList.dataset.codes = codes.join('\n');
        if (backupCopyBtn) { backupCopyBtn.disabled = false; }
        if (backupDownloadBtn) { backupDownloadBtn.disabled = false; }
        if (backupLastGenerated) { backupLastGenerated.textContent = new Date().toLocaleString(); }
      } else {
        if (backupList) { backupList.hidden = true; }
        backupCodesList.dataset.codes = '';
        if (backupCopyBtn) { backupCopyBtn.disabled = true; }
        if (backupDownloadBtn) { backupDownloadBtn.disabled = true; }
      }
    }

    if (!endpoint) {
      var fallbackForm = root.querySelector('form[action]') || root.querySelector('form');
      var resolved = resolveFormAction(fallbackForm);
      if (resolved) {
        endpoint = resolved;
      }
    }

    initPasswordForm();
    initTwoFactor();
    initSessions();
    initBackup();

    function initPasswordForm(){
      var form = $('#security-password-form', root);
      if (!form) { return; }
      var submitBtn = form.querySelector('button[type="submit"]');
      var alertEl = form.querySelector('[data-password-alert]');
      var strengthBar = form.querySelector('[data-password-strength-bar]');
      var strengthText = form.querySelector('[data-password-strength-text]');
      var fields = {
        current: form.querySelector('input[name="current_password"]'),
        fresh: form.querySelector('input[name="new_password"]'),
        confirm: form.querySelector('input[name="confirm_password"]')
      };
      var ajaxSupported = typeof window.fetch === 'function' && typeof window.FormData === 'function';
      var passwordEndpoint = endpoint || resolveFormAction(form);

      function updateStrength(){
        if (!fields.fresh) { return; }
        var value = fields.fresh.value || '';
        var stat = evaluateStrength(value);
        if (strengthBar) {
          strengthBar.style.width = stat.percent + '%';
        }
        if (strengthText) {
          var label = strengthLabels[stat.score] || '';
          strengthText.textContent = label;
        }
      }

      function isStrong(value){
        if (typeof value !== 'string') { return false; }
        if (value.length < 8) { return false; }
        if (!/[a-z]/.test(value) || !/[A-Z]/.test(value)) { return false; }
        if (!(/\d/.test(value) || /[^A-Za-z0-9]/.test(value))) { return false; }
        return true;
      }

      function validate(){
        var ok = true;
        setFieldFeedback(form, 'current_password', '');
        setFieldFeedback(form, 'new_password', '');
        setFieldFeedback(form, 'confirm_password', '');

        if (!fields.current.value) {
          setFieldFeedback(form, 'current_password', strings.errorRequired || strings.passwordError || '');
          ok = false;
        }
        if (!isStrong(fields.fresh.value || '')) {
          setFieldFeedback(form, 'new_password', strings.errorWeak || strings.passwordError || '');
          ok = false;
        }
        if ((fields.fresh.value || '') !== (fields.confirm.value || '')) {
          setFieldFeedback(form, 'confirm_password', strings.errorMismatch || strings.passwordError || '');
          ok = false;
        }
        if (submitBtn) { submitBtn.disabled = !ok; }
        return ok;
      }

      if (fields.fresh) { fields.fresh.addEventListener('input', function(){ updateStrength(); validate(); }); }
      if (fields.confirm) { fields.confirm.addEventListener('input', validate); }
      if (fields.current) { fields.current.addEventListener('input', validate); }
      updateStrength();
      validate();

      form.addEventListener('submit', function(ev){
        if (!ajaxSupported || !passwordEndpoint) {
          return;
        }
        ev.preventDefault();
        if (!validate()) { return; }
        setAlert(alertEl, 'success', '');
        if (submitBtn) { submitBtn.disabled = true; submitBtn.dataset.originalText = submitBtn.textContent; submitBtn.textContent = strings.saving || 'Saving...'; }
        fetchJson(passwordEndpoint, {
          method: 'POST',
          credentials: 'same-origin',
          body: new FormData(form)
        }).then(function(res){
          if (res && res.status === 'success') {
            if (alertEl) { setAlert(alertEl, 'success', res.message || strings.passwordSaved || ''); }
            Object.keys(fields).forEach(function(key){ if (fields[key]) { fields[key].value = ''; } });
            updateStrength();
            if (submitBtn) { submitBtn.disabled = true; }
          } else {
            var msg = (res && (res.message || res.error)) || strings.passwordError || '';
            if (alertEl) { setAlert(alertEl, 'error', msg); }
          }
        }).catch(function(){
          if (alertEl) { setAlert(alertEl, 'error', strings.passwordError || ''); }
        }).finally(function(){
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = submitBtn.dataset.originalText || submitBtn.textContent;
          }
        });
      });
    }

    function initTwoFactor(){
      var toggle = $('#security-twofactor-toggle', root);
      var setup = root.querySelector('[data-twofactor-setup]');
      var manage = root.querySelector('[data-twofactor-manage]');
      var statusEl = root.querySelector('[data-twofactor-status]');
      var pill = root.querySelector('.status-pill');
      var qrHolder = root.querySelector('[data-twofactor-qr]');
      var secretEl = root.querySelector('[data-twofactor-secret]');
      var otpauthEl = root.querySelector('[data-twofactor-otpauth]');
      var copySecretBtn = root.querySelector('[data-copy-secret]');
      var copyOtpauthBtn = root.querySelector('[data-copy-otpauth]');
      var codeInput = root.querySelector('[data-twofactor-code]');
      var confirmBtn = root.querySelector('[data-twofactor-confirm]');
      var cancelBtn = root.querySelector('[data-twofactor-cancel]');
      var disableContainer = root.querySelector('[data-twofactor-disable-form]');
      var disableStart = root.querySelector('[data-twofactor-disable]');
      var disableActions = root.querySelector('[data-twofactor-disable-actions]');
      var disableConfirm = root.querySelector('[data-twofactor-disable-confirm]');
      var disableCancel = root.querySelector('[data-twofactor-disable-cancel]');
      var disableCode = root.querySelector('[data-twofactor-disable-code]');
      var disablePassword = root.querySelector('[data-twofactor-disable-password]');
      var disableFeedback = root.querySelector('[data-feedback="twofactor-disable"]');
      var currentSecret = null;
      var currentOtpauth = null;
      var isRequesting = false;

      function updateStatus(enabled){
        if (statusEl) { statusEl.textContent = enabled ? statusOn : statusOff; }
        if (pill) {
          pill.classList.toggle('status-pill--on', !!enabled);
          pill.classList.toggle('status-pill--off', !enabled);
        }
        config.twoFactorEnabled = !!enabled;
      }
      updateStatus(!!config.twoFactorEnabled);

      function renderQrFallback(){
        if (!qrHolder) { return; }
        qrHolder.innerHTML = '';
        if (currentOtpauth) {
          var fallback = document.createElement('code');
          fallback.textContent = currentOtpauth;
          qrHolder.appendChild(fallback);
        }
      }

      function showSetup(payload){
        var secret = payload && payload.secret ? String(payload.secret) : '';
        var otpauth = payload && payload.otpauth ? String(payload.otpauth) : '';
        var qrToken = payload && payload.qr_token ? String(payload.qr_token) : '';

        currentSecret = secret;
        currentOtpauth = otpauth;

        if (secretEl) {
          secretEl.textContent = secret || '';
          if (secretEl.dataset) { secretEl.dataset.secret = secret || ''; }
        }

        if (otpauthEl) {
          otpauthEl.textContent = currentOtpauth || '';
          if (otpauthEl.dataset) { otpauthEl.dataset.otpauth = currentOtpauth || ''; }
        }

        if (setup) {
          setup.hidden = false;
        }
        if (manage) { manage.hidden = true; }
        if (confirmBtn) { confirmBtn.disabled = true; }
        if (codeInput) { codeInput.value = ''; codeInput.focus(); }
        if (qrHolder) {
          var dpr = Math.min(Math.max(window.devicePixelRatio || 1, 1), 3);
          var base = (endpoint || '').split('?')[0] || '/request/requests.php';
          qrHolder.innerHTML = '';
          if (qrHolder.classList) { qrHolder.classList.add('security-qr-wrap'); }
          if (!qrToken) {
            renderQrFallback();
            return;
          }
          var src = base + '?p=twofactor_qr&token=' + encodeURIComponent(qrToken)
            + '&dpr=' + dpr + '&_=' + Date.now();
          var img = document.createElement('img');
          img.alt = strings.twoFactorQrAlt || 'Authenticator QR code';
          img.decoding = 'async';
          img.loading = 'eager';
          img.style.imageRendering = 'pixelated';
          img.src = src;
          img.addEventListener('error', function(){ renderQrFallback(); });
          img.addEventListener('click', function(){
            try {
              if (window.matchMedia && window.matchMedia('(pointer: coarse)').matches) {
                window.open(src, '_blank');
              }
            } catch (_) {}
          });
          qrHolder.appendChild(img);
        }
      }

      function hideSetup(){
        if (setup) { setup.hidden = true; }
        if (codeInput) { codeInput.value = ''; }
        currentSecret = null;
        currentOtpauth = null;
        if (otpauthEl) {
          otpauthEl.textContent = '';
          if (otpauthEl.dataset) { otpauthEl.dataset.otpauth = ''; }
        }
      }

      function openDisableForm(){
        if (disableActions) { disableActions.hidden = true; }
        if (disableContainer) {
          disableContainer.hidden = false;
        }
        if (disableCode) { disableCode.value = ''; disableCode.focus(); }
        if (disablePassword) { disablePassword.value = ''; }
        if (disableFeedback) { disableFeedback.textContent = ''; }
      }

      function closeDisableForm(){
        if (disableActions) { disableActions.hidden = false; }
        if (disableContainer) { disableContainer.hidden = true; }
        if (disableFeedback) { disableFeedback.textContent = ''; }
        if (disableCode) { disableCode.value = ''; }
        if (disablePassword) { disablePassword.value = ''; }
      }

      function handlePrepare(){
        if (isRequesting) { return; }
        isRequesting = true;
        fetchJson(endpoint, {
          method: 'POST',
          credentials: 'same-origin',
          body: toFormData({
            p: 'settings_security_prepare_2fa',
            csrf_token: csrf
          })
        }).then(function(res){
          if (res && res.status === 'success' && res.data) {
            config.twoFactorPending = true;
            showSetup(res.data);
          } else {
            if (toggle) { toggle.checked = false; }
            hideSetup();
          }
        }).catch(function(){
          if (toggle) { toggle.checked = false; }
          hideSetup();
        }).finally(function(){ isRequesting = false; });
      }

      function handleConfirm(){
        if (!currentSecret || !codeInput) { return; }
        var code = (codeInput.value || '').trim();
        if (!/^\d{6}$/.test(code)) {
          setFieldFeedback(setup, 'twofactor', strings.twoFactorMismatch || strings.genericError || '');
          return;
        }
        if (confirmBtn) { confirmBtn.disabled = true; }
        fetchJson(endpoint, {
          method: 'POST',
          credentials: 'same-origin',
          body: toFormData({
            p: 'settings_security_enable_2fa',
            csrf_token: csrf,
            secret: currentSecret,
            code: code
          })
        }).then(function(res){
          if (res && res.status === 'success') {
            hideSetup();
            if (manage) { manage.hidden = false; }
            if (toggle) { toggle.checked = true; }
            updateStatus(true);
            config.twoFactorPending = false;
            if (Array.isArray(res.data && res.data.codes)) {
              renderBackupCodes(res.data.codes);
            }
          } else {
            var msg = (res && (res.message || res.error)) || strings.genericError || '';
            setFieldFeedback(setup, 'twofactor', msg);
          }
        }).catch(function(){
          setFieldFeedback(setup, 'twofactor', strings.genericError || '');
        }).finally(function(){ if (confirmBtn) { confirmBtn.disabled = false; } });
      }

      function handleDisable(){
        if (!disableCode || !disablePassword || !disableFeedback) { return; }
        var payload = {
          p: 'settings_security_disable_2fa',
          csrf_token: csrf,
          code: (disableCode.value || '').trim(),
          password: disablePassword.value || ''
        };
        if (!payload.code && !payload.password) {
          disableFeedback.textContent = strings.disableRequires || strings.genericError || '';
          return;
        }
        if (disableConfirm) { disableConfirm.disabled = true; }
        fetchJson(endpoint, {
          method: 'POST',
          credentials: 'same-origin',
          body: toFormData(payload)
        }).then(function(res){
          if (res && res.status === 'success') {
            closeDisableForm();
            if (toggle) { toggle.checked = false; }
            updateStatus(false);
            hideSetup();
            if (manage) { manage.hidden = true; }
            renderBackupCodes([]);
          } else {
            var msg = (res && (res.message || res.error)) || strings.genericError || '';
            disableFeedback.textContent = msg;
          }
        }).catch(function(){
          disableFeedback.textContent = strings.genericError || '';
        }).finally(function(){ if (disableConfirm) { disableConfirm.disabled = false; } });
      }

      var shouldShowSetup = false;
      if (setup) {
        setup.hidden = !shouldShowSetup;
      }
      if (manage) {
        manage.hidden = !config.twoFactorEnabled;
      }

      if (toggle) {
        toggle.addEventListener('change', function(){
          if (toggle.checked) {
            if (config.twoFactorEnabled) {
              // Already enabled; keep toggle on and show manage card.
              toggle.checked = true;
              if (manage) { manage.hidden = false; }
              if (setup) { setup.hidden = true; }
            } else {
              shouldShowSetup = true;
              if (setup) { setup.hidden = false; }
              if (manage) { manage.hidden = true; }
              handlePrepare();
            }
          } else {
            if (config.twoFactorEnabled) {
              toggle.checked = true; // keep on until user confirms disable
              openDisableForm();
            } else {
              shouldShowSetup = false;
              hideSetup();
              if (manage) { manage.hidden = true; }
            }
          }
        });
      }

      if (codeInput) {
        codeInput.addEventListener('input', function(){
          if (!confirmBtn) { return; }
          var ready = /^\d{6}$/.test(codeInput.value || '');
          confirmBtn.disabled = !ready;
          if (ready) { setFieldFeedback(setup, 'twofactor', ''); }
        });
      }

      if (confirmBtn) { confirmBtn.addEventListener('click', handleConfirm); }
      if (cancelBtn) {
        cancelBtn.addEventListener('click', function(){
          hideSetup();
          if (toggle && !config.twoFactorEnabled) { toggle.checked = false; }
        });
      }

      if (disableStart) {
        disableStart.addEventListener('click', function(){ openDisableForm(); });
      }
      if (disableCancel) {
        disableCancel.addEventListener('click', function(){ closeDisableForm(); });
      }
      if (disableConfirm) {
        disableConfirm.addEventListener('click', handleDisable);
      }

      if (copySecretBtn) {
        copySecretBtn.addEventListener('click', function(){
          var secretValue = '';
          if (secretEl) {
            secretValue = secretEl.dataset && secretEl.dataset.secret ? secretEl.dataset.secret : (secretEl.textContent || '');
          }
          if (!secretValue) { return; }
          copyToClipboard(secretValue).then(function(){
            copySecretBtn.textContent = strings.copied || strings.copy || 'Copy';
            setTimeout(function(){ copySecretBtn.textContent = strings.copySecret || strings.copy || 'Copy'; }, 1500);
          });
        });
      }

      if (copyOtpauthBtn) {
        copyOtpauthBtn.addEventListener('click', function(){
          var otpauthValue = '';
          if (otpauthEl) {
            otpauthValue = otpauthEl.dataset && otpauthEl.dataset.otpauth ? otpauthEl.dataset.otpauth : (otpauthEl.textContent || '');
          }
          if (!otpauthValue) { return; }
          copyToClipboard(otpauthValue).then(function(){
            copyOtpauthBtn.textContent = strings.copied || strings.copy || 'Copy';
            setTimeout(function(){ copyOtpauthBtn.textContent = strings.copyOtpauth || strings.copy || 'Copy'; }, 1500);
          });
        });
      }

      manage && manage.hidden && config.twoFactorEnabled && (manage.hidden = false);
    }

    function initSessions(){
      var table = root.querySelector('.security-sessions');
      if (!table) { return; }
      var revokeButtons = $all('[data-session-revoke]', root);
      revokeButtons.forEach(function(btn){
        btn.addEventListener('click', function(){
          var row = btn.closest('[data-session-row]');
          var key = btn.getAttribute('data-session-key');
          if (!key || !row) { return; }
          btn.disabled = true;
          fetchJson(endpoint, {
            method: 'POST',
            credentials: 'same-origin',
            body: toFormData({
              p: 'settings_security_revoke_session',
              csrf_token: csrf,
              session_key: key
            })
          }).then(function(res){
            if (res && res.status === 'success') {
              row.remove();
              evaluateEmptySessions();
            } else {
              btn.disabled = false;
            }
          }).catch(function(){ btn.disabled = false; });
        });
      });

      var revokeOthers = root.querySelector('[data-session-revoke-others]');
      if (revokeOthers) {
        revokeOthers.addEventListener('click', function(){
          if (!window.confirm(strings.sessionsConfirm || strings.sessionsRevoked || 'Sign out other sessions?')) {
            return;
          }
          revokeOthers.disabled = true;
          fetchJson(endpoint, {
            method: 'POST',
            credentials: 'same-origin',
            body: toFormData({
              p: 'settings_security_revoke_others',
              csrf_token: csrf
            })
          }).then(function(res){
            if (res && res.status === 'success') {
              $all('[data-session-row]', table).forEach(function(row){
                if (row.querySelector('.security-badge')) { return; }
                row.remove();
              });
              evaluateEmptySessions();
            }
          }).catch(function(){
            revokeOthers.disabled = false;
          }).finally(function(){ revokeOthers.disabled = false; });
        });
      }

      function evaluateEmptySessions(){
        var rows = $all('[data-session-row]', table);
        if (!rows.length) {
          table.remove();
          var empty = root.querySelector('[data-sessions-empty]');
          if (empty) { empty.hidden = false; }
        }
      }
    }

    function initBackup(){
      var generateBtn = root.querySelector('[data-backup-generate]');

      if (generateBtn) {
        generateBtn.addEventListener('click', function(){
          generateBtn.disabled = true;
          fetchJson(endpoint, {
            method: 'POST',
            credentials: 'same-origin',
            body: toFormData({
              p: 'settings_security_generate_codes',
              csrf_token: csrf
            })
          }).then(function(res){
            if (res && res.status === 'success') {
              renderBackupCodes(res.data && res.data.codes ? res.data.codes : []);
            } else {
              setAlert(backupAlert, 'error', (res && res.message) || strings.genericError || '');
            }
          }).catch(function(){
            setAlert(backupAlert, 'error', strings.genericError || '');
          }).finally(function(){ generateBtn.disabled = false; });
        });
      }

      if (backupCopyBtn) {
        backupCopyBtn.addEventListener('click', function(){
          if (!backupCodesList || !backupCodesList.dataset.codes) { return; }
          copyToClipboard(backupCodesList.dataset.codes).then(function(){
            backupCopyBtn.textContent = strings.copied || backupCopyBtn.textContent;
            setTimeout(function(){ backupCopyBtn.textContent = strings.copyCodes || strings.copy || 'Copy'; }, 1500);
          });
        });
      }

      if (backupDownloadBtn) {
        backupDownloadBtn.addEventListener('click', function(){
          if (!backupCodesList || !backupCodesList.dataset.codes) { return; }
          var blob = new Blob([backupCodesList.dataset.codes], { type: 'text/plain' });
          var link = document.createElement('a');
          link.href = URL.createObjectURL(blob);
          link.download = (strings.downloadFileName || 'backup-codes.txt');
          document.body.appendChild(link);
          link.click();
          setTimeout(function(){ URL.revokeObjectURL(link.href); document.body.removeChild(link); }, 100);
        });
      }

      var existing = (backupCodesList && backupCodesList.dataset.codes)
        ? backupCodesList.dataset.codes.split('\n')
        : [];
      renderBackupCodes(existing);
    }
  });
})();
