(function(){
  'use strict';

  function onReady(fn){
    if (document.readyState !== 'loading') { fn(); }
    else { document.addEventListener('DOMContentLoaded', fn); }
  }

  function parseJsonAttr(el, attr){
    if (!el) { return null; }
    var raw = el.getAttribute(attr);
    if (!raw) { return null; }
    try { return JSON.parse(raw); }
    catch (err) {
      if (window.DZ_DEBUG) { console.warn('settingsDashboard: failed to parse', attr, err); }
      return null;
    }
  }

  function formatTemplateLabel(template, index, fallbackBase){
    var n = index;
    var base = fallbackBase || 'Item';
    if (!template || typeof template !== 'string') {
      return base + ' ' + n;
    }
    if (template.indexOf('{n}') !== -1) {
      return template.replace('{n}', n);
    }
    if (template.indexOf('%d') !== -1) {
      return template.replace('%d', n);
    }
    if (template.indexOf('%s') !== -1) {
      return template.replace('%s', n);
    }
    return template + ' ' + n;
  }

  function toggleFallback(canvas, success){
    if (!canvas) { return; }
    var fb = canvas.nextElementSibling;
    if (!fb || !fb.classList || !fb.classList.contains('chart-fallback')) { return; }
    if (success) { fb.classList.add('is-hidden'); }
    else { fb.classList.remove('is-hidden'); }
  }

  function initGrowthChart(){
    var cv = document.getElementById('settingsGrowthChart');
    if (!cv || typeof Chart === 'undefined') { return; }

    var labels = parseJsonAttr(cv, 'data-labels') || [];
    var followers = parseJsonAttr(cv, 'data-followers') || [];
    var subscribers = parseJsonAttr(cv, 'data-subscribers') || [];
    var periodTemplate = cv.getAttribute('data-period-template') || '';

    if (!labels.length) {
      var maxLen = Math.max(followers.length || 0, subscribers.length || 0);
      if (maxLen > 0) {
        var generated = [];
        for (var i = 0; i < maxLen; i++) {
          generated.push(formatTemplateLabel(periodTemplate, i + 1, 'Period'));
        }
        labels = generated;
      }
    }

    var maxLen = Math.max(labels.length || 0, followers.length || 0, subscribers.length || 0);
    if (maxLen <= 0) {
      maxLen = 6;
      labels = [];
    }

    if (labels.length < maxLen) {
      var autoLabels = [];
      for (var li = 0; li < maxLen; li++) {
        autoLabels.push(formatTemplateLabel(periodTemplate, li + 1, 'Period'));
      }
      labels = autoLabels;
    } else if (labels.length > maxLen) {
      labels = labels.slice(0, maxLen);
    }

    var normalizeSeries = function(series){
      var arr = Array.isArray(series) ? series.slice(0, maxLen) : [];
      while (arr.length < maxLen) { arr.push(0); }
      return arr.map(function(value){ return Number.isFinite(Number(value)) ? Number(value) : 0; });
    };

    followers = normalizeSeries(followers);
    subscribers = normalizeSeries(subscribers);

    var ctx = cv.getContext('2d');

    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: cv.getAttribute('data-followers-label') || 'Followers',
            data: followers,
            backgroundColor: 'rgba(31,75,216,0.25)',
            borderColor: '#1f4bd8',
            borderWidth: 1,
            borderRadius: 8,
            borderSkipped: false,
            maxBarThickness: 28
          },
          {
            label: cv.getAttribute('data-subscribers-label') || 'Subscribers',
            data: subscribers,
            backgroundColor: 'rgba(36,184,199,0.25)',
            borderColor: '#24b8c7',
            borderWidth: 1,
            borderRadius: 8,
            borderSkipped: false,
            maxBarThickness: 28
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        layout: { padding: { top: 8, bottom: 8, left: 4, right: 4 } },
        plugins: {
          legend: { display: true, position: 'bottom' },
          tooltip: {
            enabled: true,
            callbacks: {
              label: function(context){
                var label = context.dataset.label || '';
                var value = context.parsed.y;
                return label + ': ' + (typeof value === 'number' ? value.toLocaleString() : value);
              }
            }
          }
        },
        scales: {
          x: { grid: { display: false } },
          y: { grid: { color: 'rgba(0,0,0,0.06)' }, beginAtZero: true }
        }
      }
    });

    toggleFallback(cv, true);
  }

  function initRevenueMixChart(){
    var cv = document.getElementById('settingsRevenueMixChart');
    if (!cv || typeof Chart === 'undefined') { return; }

    var breakdown = parseJsonAttr(cv, 'data-breakdown') || {};

    var labels = Array.isArray(breakdown.labels) ? breakdown.labels.slice() : [];
    var rawValues = Array.isArray(breakdown.values) ? breakdown.values.slice() : [];
    var segmentTemplate = cv.getAttribute('data-segment-template') || '';
    if (!labels.length && rawValues.length) {
      labels = rawValues.map(function(_, idx){
        return formatTemplateLabel(segmentTemplate, idx + 1, 'Segment');
      });
    }
    if (!rawValues.length) {
      rawValues = [0, 0, 0, 0];
    }

    var cleanedValues = rawValues.map(function(val){
      var num = Number(val);
      return Number.isFinite(num) ? num : 0;
    });
    var actualTotal = cleanedValues.reduce(function(sum, val){ return sum + val; }, 0);
    var displayValues = cleanedValues.slice();
    var fallbackMode = false;

    if (actualTotal <= 0) {
      fallbackMode = true;
      if (!displayValues.length) {
        displayValues = [1, 1, 1, 1];
        cleanedValues = [0, 0, 0, 0];
        if (!labels.length) {
          var generatedSegments = [];
          for (var s = 0; s < displayValues.length; s++) {
            generatedSegments.push(formatTemplateLabel(segmentTemplate, s + 1, 'Segment'));
          }
          labels = generatedSegments;
        }
      } else {
        displayValues = displayValues.map(function(){ return 1; });
      }
    }

    var ctx = cv.getContext('2d');

    var donutCenter = {
      id: 'settingsDonutCenter',
      beforeDraw: function(chart){
        var w = chart.width;
        var h = chart.height;
        var context = chart.ctx;
        context.save();
        context.textAlign = 'center';
        context.textBaseline = 'middle';
        context.fillStyle = '#6b7280';
        context.font = '600 16px system-ui, -apple-system, Segoe UI, Roboto, sans-serif';
        context.fillText(cv.getAttribute('data-total-label') || 'Total', w / 2, h / 2 - 10);
        context.fillStyle = '#111827';
        context.font = '700 18px system-ui, -apple-system, Segoe UI, Roboto, sans-serif';
        context.fillText(actualTotal.toLocaleString(), w / 2, h / 2 + 12);
        context.restore();
      }
    };

    new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: labels,
        datasets: [{
          data: displayValues,
          backgroundColor: ['#1f4bd8', '#ff6b60', '#14b8a6', '#16a34a', '#f59e0b', '#7c3aed'],
          borderWidth: 0,
          borderRadius: 6,
          originalData: cleanedValues,
          originalTotal: actualTotal,
          isFallback: fallbackMode
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        layout: { padding: { top: 8, bottom: 8 } },
        plugins: {
          legend: { display: true, position: 'bottom' },
          tooltip: {
            callbacks: {
              label: function(context){
                var dataset = context.chart.data.datasets[context.datasetIndex] || {};
                var original = Array.isArray(dataset.originalData) ? dataset.originalData : [];
                var actualValue = original.length ? Number(original[context.dataIndex]) || 0 : Number(context.parsed) || 0;
                var totalValue = typeof dataset.originalTotal === 'number' ? dataset.originalTotal : actualTotal;
                var label = context.label || '';
                var pct = totalValue > 0 ? ((actualValue / totalValue) * 100) : 0;
                var pctText = totalValue > 0 ? ' (' + pct.toFixed(1) + '%)' : '';
                return label + ': ' + actualValue.toLocaleString() + pctText;
              }
            }
          }
        },
        cutout: '60%'
      },
      plugins: [donutCenter]
    });

    toggleFallback(cv, true);
  }

  onReady(function(){
    if (!document.body || document.body.getAttribute('data-layout') !== 'settings') {
      return;
    }
    if (typeof Chart === 'undefined') {
      if (window.DZ_DEBUG) { console.warn('settingsDashboard: Chart.js missing'); }
      return;
    }
    initGrowthChart();
    initRevenueMixChart();
  });
})();
