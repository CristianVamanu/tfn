(function () {
  "use strict";

  var endpoint = (typeof window.buildUrl === 'function')
    ? window.buildUrl('request/requests.php')
    : (function () {
      if (typeof window.site_url !== 'undefined' && window.site_url) {
        return window.site_url + 'request/requests.php';
      }
      var origin = (typeof window.location !== 'undefined' && window.location.origin) ? window.location.origin : '';
      return origin ? origin + '/request/requests.php' : 'request/requests.php';
    })();

  function getCsrf(el) {
    var field = el.querySelector('[data-suggested-csrf]');
    if (field && field.value) {
      return field.value;
    }
    var global = document.querySelector('input[name="csrf_token"]');
    return (global && global.value) ? global.value : '';
  }

  function setCsrf(el, token) {
    if (!token) { return; }
    var field = el.querySelector('[data-suggested-csrf]');
    if (field) { field.value = token; }
  }

  function reloadList(widget, trigger) {
    if (!widget || widget.dataset.loading === '1') { return; }
    widget.dataset.loading = '1';
    widget.classList.add('is-loading');
    if (trigger) {
      trigger.disabled = true;
      trigger.setAttribute('aria-busy', 'true');
    }

    var csrf = getCsrf(widget);
    var body = new URLSearchParams();
    body.set('p', 'suggested_users');
    body.set('csrf_token', csrf);

    fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString(),
      credentials: 'same-origin'
    })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (!res || res.status !== 'ok') { return; }
        var list = widget.querySelector('[data-suggested-list]');
        if (list) {
          list.innerHTML = res.html || '';
        }
        if (res.csrf) {
          setCsrf(widget, res.csrf);
        }
      })
      .catch(function () { /* silent */ })
      .finally(function () {
        widget.dataset.loading = '0';
        widget.classList.remove('is-loading');
        if (trigger) {
          trigger.disabled = false;
          trigger.setAttribute('aria-busy', 'false');
        }
      });
  }

  document.addEventListener('click', function (ev) {
    var btn = ev.target.closest('[data-action="suggested-users-reload"]');
    if (!btn) { return; }
    var widget = btn.closest('.suggested-users');
    if (!widget || widget.dataset.allowReload === '0') { return; }
    reloadList(widget, btn);
  });
})();
