(function () {
  'use strict';

  if (window.chatCallController && typeof window.chatCallController.destroy === 'function') {
    try { window.chatCallController.destroy(); } catch (_) {}
  }

  var destroyed = false;
  var pollTimer = null;
  var activeCall = null;
  var currentPeerId = 0;
  var agoraClient = null;
  var localTracks = { audio: null, video: null };
  var mediaJoinedCallId = 0;
  var mediaConnecting = false;
  var audioMuted = false;
  var videoMuted = false;
  var callMinimized = false;
  var miniDragState = null;
  var miniResizeState = null;
  var miniPosition = null;
  var miniSize = null;
  var MINI_POSITION_KEY = 'creatorpulse.chatCall.minimizedPosition';
  var MINI_SIZE_KEY = 'creatorpulse.chatCall.minimizedSize';

  var buildUrl = (window.DZ && window.DZ.buildUrl) || function (path) {
    try {
      var base = (typeof window.site_url === 'string' && window.site_url) ? window.site_url : (window.location.origin + '/crpulse/');
      if (base.slice(-1) !== '/') base += '/';
      return new URL(String(path || '').replace(/^\//, ''), base).toString();
    } catch (_) {
      return String(path || '');
    }
  };
  var REQUEST_URL = buildUrl('request/chat.php');

  function assetUrl(path) {
    return buildUrl(String(path || '').replace(/^\//, ''));
  }

  function csrfToken() {
    var input = document.querySelector('input[name="csrf_token"]');
    return input ? (input.value || '') : '';
  }

  function selectedPeerId() {
    var controls = document.querySelector('.chat_call_controls[data-chat-peer-id]');
    return controls ? parseInt(controls.getAttribute('data-chat-peer-id') || '0', 10) : 0;
  }

  function post(payload) {
    var body = new URLSearchParams();
    Object.keys(payload || {}).forEach(function (key) {
      body.set(key, String(payload[key]));
    });
    body.set('csrf_token', csrfToken());
    return fetch(REQUEST_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body,
      credentials: 'same-origin'
    }).then(function (res) { return res.json(); });
  }

  function clearModal() {
    var node = document.querySelector('.chat_call_modal');
    if (node) node.remove();
  }

  function storageGet(key) {
    try {
      return window.localStorage ? window.localStorage.getItem(key) : null;
    } catch (_) {
      return null;
    }
  }

  function storageSet(key, value) {
    try {
      if (window.localStorage) window.localStorage.setItem(key, value);
    } catch (_) {}
  }

  function readMiniPosition() {
    if (miniPosition) return miniPosition;
    var raw = storageGet(MINI_POSITION_KEY);
    if (!raw) return null;
    try {
      var parsed = JSON.parse(raw);
      if (Number.isFinite(parsed.x) && Number.isFinite(parsed.y)) {
        miniPosition = { x: parsed.x, y: parsed.y };
        return miniPosition;
      }
    } catch (_) {}
    return null;
  }

  function saveMiniPosition(position) {
    if (!position) return;
    miniPosition = { x: Math.round(position.x), y: Math.round(position.y) };
    storageSet(MINI_POSITION_KEY, JSON.stringify(miniPosition));
  }

  function defaultMiniSize() {
    return { width: 320, stageHeight: 168 };
  }

  function clampMiniSize(width, stageHeight) {
    var maxWidth = Math.max(280, Math.min(560, window.innerWidth - (miniMargin() * 2)));
    var maxStageHeight = Math.max(150, Math.min(360, window.innerHeight - 210));
    return {
      width: Math.round(Math.min(Math.max(280, width || 320), maxWidth)),
      stageHeight: Math.round(Math.min(Math.max(150, stageHeight || 168), maxStageHeight))
    };
  }

  function readMiniSize() {
    if (miniSize) return miniSize;
    var raw = storageGet(MINI_SIZE_KEY);
    if (!raw) return defaultMiniSize();
    try {
      var parsed = JSON.parse(raw);
      if (Number.isFinite(parsed.width) && Number.isFinite(parsed.stageHeight)) {
        miniSize = clampMiniSize(parsed.width, parsed.stageHeight);
        return miniSize;
      }
    } catch (_) {}
    return defaultMiniSize();
  }

  function saveMiniSize(size) {
    if (!size) return;
    miniSize = clampMiniSize(size.width, size.stageHeight);
    storageSet(MINI_SIZE_KEY, JSON.stringify(miniSize));
  }

  function miniMargin() {
    return window.innerWidth <= 720 ? 12 : 8;
  }

  function clampMiniPosition(x, y, panel) {
    var margin = miniMargin();
    var width = panel ? panel.offsetWidth : 320;
    var height = panel ? panel.offsetHeight : 80;
    var maxX = Math.max(margin, window.innerWidth - width - margin);
    var maxY = Math.max(margin, window.innerHeight - height - margin);
    return {
      x: Math.min(Math.max(margin, x), maxX),
      y: Math.min(Math.max(margin, y), maxY)
    };
  }

  function clearMiniPositionStyle(node) {
    if (!node) return;
    node.classList.remove('is-positioned', 'is-dragging', 'is-resizing');
    node.style.left = '';
    node.style.top = '';
    node.style.right = '';
    node.style.bottom = '';
  }

  function applyMiniSize(node, size) {
    if (!node || !node.classList.contains('is-minimized')) return;
    var panel = node.querySelector('[data-chat-call-panel]');
    if (!panel) return;
    var next = clampMiniSize((size || {}).width, (size || {}).stageHeight);
    panel.style.setProperty('--mini-call-width', next.width + 'px');
    panel.style.setProperty('--mini-call-stage-height', next.stageHeight + 'px');
    miniSize = next;
  }

  function applyMiniPosition(node, position) {
    if (!node || !node.classList.contains('is-minimized') || !position) return;
    var panel = node.querySelector('[data-chat-call-panel]');
    var next = clampMiniPosition(position.x, position.y, panel);
    node.classList.add('is-positioned');
    node.style.left = next.x + 'px';
    node.style.top = next.y + 'px';
    node.style.right = 'auto';
    node.style.bottom = 'auto';
    miniPosition = next;
  }

  function applyStoredMiniPosition(node) {
    var saved = readMiniPosition();
    if (saved) applyMiniPosition(node, saved);
  }

  function applyStoredMiniSize(node) {
    applyMiniSize(node, readMiniSize());
  }

  function setStatus(message) {
    var status = document.querySelector('[data-chat-call-status]');
    if (status) status.textContent = message || '';
    var miniStatus = document.querySelector('[data-chat-call-mini-status]');
    if (miniStatus && message) miniStatus.textContent = message;
  }

  function callTypeLabel(call) {
    return call && call.call_type === 'video' ? 'Video call' : 'Audio call';
  }

  function callIconPath(call) {
    return call && call.call_type === 'video'
      ? 'themes/default/icons/video-call.svg'
      : 'themes/default/icons/voice-call.svg';
  }

  function callOffIconPath(call) {
    return call && call.call_type === 'video'
      ? 'themes/default/icons/video-call-off.svg'
      : 'themes/default/icons/voice-call-off.svg';
  }

  function partnerName(call) {
    if (call && call.partner_name) {
      return String(call.partner_name);
    }
    if (call && call.direction === 'incoming' && call.caller_name) {
      return String(call.caller_name);
    }
    if (call && call.direction === 'outgoing' && call.receiver_name) {
      return String(call.receiver_name);
    }
    var name = document.querySelector('.chat_current_user .username');
    return name ? (name.textContent || '').trim() : 'User';
  }

  function partnerUsername(call) {
    if (call && call.partner_username) return String(call.partner_username);
    if (call && call.direction === 'incoming' && call.caller_username) return String(call.caller_username);
    if (call && call.direction === 'outgoing' && call.receiver_username) return String(call.receiver_username);
    return '';
  }

  function partnerAvatar(call) {
    if (call && call.partner_avatar_url) return String(call.partner_avatar_url);
    if (call && call.direction === 'incoming' && call.caller_avatar_url) return String(call.caller_avatar_url);
    if (call && call.direction === 'outgoing' && call.receiver_avatar_url) return String(call.receiver_avatar_url);
    if (call && call.partner_avatar) return assetUrl(call.partner_avatar);
    return assetUrl('uploads/user_avatars/default.jpeg');
  }

  function partnerCover(call) {
    if (call && call.partner_cover_url) return String(call.partner_cover_url);
    if (call && call.direction === 'incoming' && call.caller_cover_url) return String(call.caller_cover_url);
    if (call && call.direction === 'outgoing' && call.receiver_cover_url) return String(call.receiver_cover_url);
    return '';
  }

  function partnerVerified(call) {
    if (call && typeof call.partner_verified !== 'undefined') return !!call.partner_verified;
    if (call && call.direction === 'incoming' && typeof call.caller_verified !== 'undefined') return !!call.caller_verified;
    if (call && call.direction === 'outgoing' && typeof call.receiver_verified !== 'undefined') return !!call.receiver_verified;
    return false;
  }

  function statusText(mode, call, message) {
    if (message) return message;
    if (mode === 'incoming') return 'Incoming call. Choose how you want to respond.';
    if (mode === 'outgoing') return 'Ringing...';
    if (mode === 'active') return 'Connected';
    return '';
  }

  function iconHtml(name, path) {
    if (path) {
      return '<img src="' + escapeHtml(assetUrl(path)) + '" alt="" aria-hidden="true">';
    }
    var icons = {
      minimize: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 16h8M5 19h14V5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      open: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3H3v5M3 3l7 7M16 21h5v-5M21 21l-7-7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      mic: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 14a4 4 0 0 0 4-4V6a4 4 0 1 0-8 0v4a4 4 0 0 0 4 4Z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M19 10a7 7 0 0 1-14 0M12 17v4M8 21h8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
      camera: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8.5A2.5 2.5 0 0 1 6.5 6h7A2.5 2.5 0 0 1 16 8.5v7a2.5 2.5 0 0 1-2.5 2.5h-7A2.5 2.5 0 0 1 4 15.5v-7Z" fill="none" stroke="currentColor" stroke-width="2"/><path d="m16 10 4-2.5v9L16 14" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>'
    };
    return icons[name] || '';
  }

  function callIdentityHtml(mode, call, message) {
    var cover = partnerCover(call);
    var avatar = partnerAvatar(call);
    var name = partnerName(call);
    var username = partnerUsername(call);
    var verified = partnerVerified(call);
    return [
      '<div class="chat_call_identity">',
      cover ? '<div class="chat_call_identity__cover" style="background-image:url(\'' + escapeHtml(cover) + '\')"></div>' : '<div class="chat_call_identity__cover is-empty"></div>',
      '  <div class="chat_call_identity__inner">',
      '    <div class="chat_call_identity__avatar_wrap">',
      '      <span class="chat_call_identity__pulse" aria-hidden="true"></span>',
      '      <img class="chat_call_identity__avatar" src="' + escapeHtml(avatar) + '" alt="' + escapeHtml(name) + '">',
      '    </div>',
      '    <div class="chat_call_identity__meta">',
      '      <span class="chat_call_identity__type">' + escapeHtml(callTypeLabel(call)) + '</span>',
      '      <strong>' + escapeHtml(name) + (verified ? '<span class="chat_call_identity__verified" aria-label="Verified">✓</span>' : '') + '</strong>',
      username ? '      <small>@' + escapeHtml(username) + '</small>' : '',
      '      <p>' + escapeHtml(statusText(mode, call, message)) + '</p>',
      '    </div>',
      '  </div>',
      '</div>'
    ].join('');
  }

  function renderModal(mode, call, message) {
    clearModal();
    if (mode !== 'active') {
      callMinimized = false;
    }
    var isActive = mode === 'active';
    var isVideo = call && call.call_type === 'video';
    var wrap = document.createElement('div');
    wrap.className = [
      'chat_call_modal',
      'chat_call_modal--' + mode,
      isVideo ? 'is-video-call' : 'is-audio-call',
      callMinimized ? 'is-minimized' : ''
    ].filter(Boolean).join(' ');
    wrap.setAttribute('role', 'dialog');
    wrap.setAttribute('aria-modal', isActive ? 'false' : 'true');
    wrap.innerHTML = [
      '<div class="chat_call_modal__panel" data-chat-call-panel>',
      callIdentityHtml(mode, call, message),
      (mode === 'active' ? mediaStageHtml(call) : ''),
      '  <div class="chat_call_modal__actions">' + actionHtml(mode, call) + '</div>',
      '</div>'
    ].join('');
    document.body.appendChild(wrap);
  }

  function mediaStageHtml(call) {
    var isVideo = call && call.call_type === 'video';
    var avatar = partnerAvatar(call);
    var cover = partnerCover(call);
    var name = partnerName(call);
    return [
      '<div class="chat_call_mini_header" data-chat-call-mini-drag title="Drag call window">',
      '  <span class="chat_call_mini_header__person"><img src="' + escapeHtml(avatar) + '" alt=""><strong>' + escapeHtml(name) + '</strong></span>',
      '  <span data-chat-call-mini-status>Connecting...</span>',
      '</div>',
      '<div class="chat_call_stage" data-chat-call-stage data-call-type="' + (isVideo ? 'video' : 'audio') + '">',
      '  <div class="chat_call_remote" data-chat-call-remote>',
      isVideo
        ? '    <span>Waiting for remote video...</span>'
        : [
            '<div class="chat_call_audio_surface">',
            cover ? '<div class="chat_call_audio_surface__cover" style="background-image:url(\'' + escapeHtml(cover) + '\')"></div>' : '<div class="chat_call_audio_surface__cover is-empty"></div>',
            '  <div class="chat_call_audio_surface__content">',
            '    <span class="chat_call_audio_surface__rings" aria-hidden="true"></span>',
            '    <img src="' + escapeHtml(avatar) + '" alt="' + escapeHtml(name) + '">',
            '    <strong>' + escapeHtml(name) + '</strong>',
            '    <small>Audio connected</small>',
            '  </div>',
            '</div>'
          ].join(''),
      '  </div>',
      '  <div class="chat_call_local" data-chat-call-local' + (isVideo ? '' : ' hidden') + '></div>',
      '  <div class="chat_call_status" data-chat-call-status>Connecting media...</div>',
      '</div>',
      '<span class="chat_call_resize_handle" data-chat-call-mini-resize title="Resize call window" aria-hidden="true"></span>'
    ].join('');
  }

  function actionHtml(mode, call) {
    var id = call && call.call_id ? String(call.call_id) : '';
    if (mode === 'incoming') {
      return [
        '<button type="button" class="chat_call_action chat_call_action--accept" data-chat-call-action="accept" data-call-id="' + id + '" aria-label="Accept" title="Accept">' + iconHtml('call', 'themes/default/icons/voice-call.svg') + '<span>Accept</span></button>',
        '<button type="button" class="chat_call_action chat_call_action--reject" data-chat-call-action="reject" data-call-id="' + id + '" aria-label="Decline" title="Decline">' + iconHtml('call_off', callOffIconPath(call)) + '<span>Decline</span></button>'
      ].join('');
    }
    if (mode === 'active') {
      var camera = call && call.call_type === 'video'
        ? '<button type="button" class="chat_call_action chat_call_action--secondary" data-chat-call-action="camera" data-call-id="' + id + '" aria-label="Camera" title="Camera">' + iconHtml('camera') + '<span>Camera</span></button>'
        : '';
      return [
        '<button type="button" class="chat_call_action chat_call_action--secondary chat_call_action--minimize" data-chat-call-action="minimize" data-call-id="' + id + '" aria-label="Minimize" title="Minimize">' + iconHtml('minimize') + '<span>Minimize</span></button>',
        '<button type="button" class="chat_call_action chat_call_action--secondary chat_call_action--restore" data-chat-call-action="restore" data-call-id="' + id + '" aria-label="Open" title="Open">' + iconHtml('open') + '<span>Open</span></button>',
        '<button type="button" class="chat_call_action chat_call_action--secondary" data-chat-call-action="mute" data-call-id="' + id + '" aria-label="Mute" title="Mute">' + iconHtml('mic') + '<span>Mute</span></button>',
        camera,
        '<button type="button" class="chat_call_action chat_call_action--end" data-chat-call-action="end" data-call-id="' + id + '" aria-label="End call" title="End call">' + iconHtml('call_off', callOffIconPath(call)) + '<span>End call</span></button>'
      ].join('');
    }
    if (mode === 'outgoing') {
      return '<button type="button" class="chat_call_action chat_call_action--reject" data-chat-call-action="cancel" data-call-id="' + id + '" aria-label="Cancel" title="Cancel">' + iconHtml('call_off', callOffIconPath(call)) + '<span>Cancel</span></button>';
    }
    return '<button type="button" class="chat_call_action chat_call_action--reject" data-chat-call-action="close" aria-label="Close" title="Close">' + iconHtml('call_off', callOffIconPath(call)) + '<span>Close</span></button>';
  }

  function escapeHtml(value) {
    return String(value || '').replace(/[&<>"']/g, function (char) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
    });
  }

  function startPolling() {
    if (pollTimer) return;
    pollTimer = setInterval(pollCalls, 3000);
  }

  function stopPollingIfIdle() {
    startPolling();
  }

  function tokenForJoin(payload) {
    if (!payload) return null;
    if (payload.debug && payload.allow_tokenless) return null;
    return payload.token || null;
  }

  function resetMediaState() {
    mediaJoinedCallId = 0;
    mediaConnecting = false;
    audioMuted = false;
    videoMuted = false;
    callMinimized = false;
  }

  function setCallMinimized(minimized) {
    callMinimized = !!minimized;
    var node = document.querySelector('.chat_call_modal');
    if (node) {
      node.classList.toggle('is-minimized', callMinimized);
      node.setAttribute('aria-modal', callMinimized ? 'false' : (node.classList.contains('chat_call_modal--active') ? 'false' : 'true'));
      if (callMinimized) {
        applyStoredMiniSize(node);
        applyStoredMiniPosition(node);
      } else {
        clearMiniPositionStyle(node);
      }
    }
  }

  function startMiniDrag(event) {
    var handle = event.target.closest('[data-chat-call-mini-drag]');
    if (!handle) return;
    var node = handle.closest('.chat_call_modal.is-minimized');
    if (!node) return;
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    var panel = node.querySelector('[data-chat-call-panel]');
    if (!panel) return;
    var rect = node.getBoundingClientRect();
    miniDragState = {
      pointerId: event.pointerId,
      handle: handle,
      node: node,
      panel: panel,
      startClientX: event.clientX,
      startClientY: event.clientY,
      startX: rect.left,
      startY: rect.top
    };
    node.classList.add('is-dragging');
    try { handle.setPointerCapture(event.pointerId); } catch (_) {}
    event.preventDefault();
  }

  function moveMiniDrag(event) {
    if (!miniDragState || event.pointerId !== miniDragState.pointerId) return;
    var next = clampMiniPosition(
      miniDragState.startX + event.clientX - miniDragState.startClientX,
      miniDragState.startY + event.clientY - miniDragState.startClientY,
      miniDragState.panel
    );
    applyMiniPosition(miniDragState.node, next);
    event.preventDefault();
  }

  function endMiniDrag(event) {
    if (!miniDragState || event.pointerId !== miniDragState.pointerId) return;
    var node = miniDragState.node;
    var rect = node.getBoundingClientRect();
    var next = clampMiniPosition(rect.left, rect.top, miniDragState.panel);
    applyMiniPosition(node, next);
    saveMiniPosition(next);
    node.classList.remove('is-dragging');
    try { miniDragState.handle.releasePointerCapture(event.pointerId); } catch (_) {}
    miniDragState = null;
  }

  function startMiniResize(event) {
    var handle = event.target.closest('[data-chat-call-mini-resize]');
    if (!handle) return;
    var node = handle.closest('.chat_call_modal.is-minimized');
    if (!node) return;
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    var panel = node.querySelector('[data-chat-call-panel]');
    var stage = node.querySelector('[data-chat-call-stage]');
    if (!panel) return;
    var panelRect = panel.getBoundingClientRect();
    var stageRect = stage ? stage.getBoundingClientRect() : null;
    miniResizeState = {
      pointerId: event.pointerId,
      handle: handle,
      node: node,
      panel: panel,
      startClientX: event.clientX,
      startClientY: event.clientY,
      startWidth: panelRect.width,
      startStageHeight: stageRect ? stageRect.height : readMiniSize().stageHeight
    };
    node.classList.add('is-resizing');
    try { handle.setPointerCapture(event.pointerId); } catch (_) {}
    event.preventDefault();
  }

  function moveMiniResize(event) {
    if (!miniResizeState || event.pointerId !== miniResizeState.pointerId) return;
    var next = clampMiniSize(
      miniResizeState.startWidth + event.clientX - miniResizeState.startClientX,
      miniResizeState.startStageHeight + event.clientY - miniResizeState.startClientY
    );
    applyMiniSize(miniResizeState.node, next);
    var rect = miniResizeState.node.getBoundingClientRect();
    applyMiniPosition(miniResizeState.node, { x: rect.left, y: rect.top });
    event.preventDefault();
  }

  function endMiniResize(event) {
    if (!miniResizeState || event.pointerId !== miniResizeState.pointerId) return;
    saveMiniSize(miniSize || readMiniSize());
    if (miniPosition) saveMiniPosition(miniPosition);
    miniResizeState.node.classList.remove('is-resizing');
    try { miniResizeState.handle.releasePointerCapture(event.pointerId); } catch (_) {}
    miniResizeState = null;
  }

  function clampMiniOnResize() {
    var node = document.querySelector('.chat_call_modal.is-minimized.is-positioned');
    if (!node) return;
    applyMiniSize(node, readMiniSize());
    var rect = node.getBoundingClientRect();
    applyMiniPosition(node, { x: rect.left, y: rect.top });
    if (miniPosition) saveMiniPosition(miniPosition);
  }

  async function leaveMedia() {
    try {
      if (localTracks.audio) {
        try { localTracks.audio.stop(); } catch (_) {}
        try { localTracks.audio.close(); } catch (_) {}
      }
      if (localTracks.video) {
        try { localTracks.video.stop(); } catch (_) {}
        try { localTracks.video.close(); } catch (_) {}
      }
      localTracks.audio = null;
      localTracks.video = null;
      if (agoraClient) {
        try { await agoraClient.leave(); } catch (_) {}
      }
    } finally {
      agoraClient = null;
      resetMediaState();
    }
  }

  function wireAgoraEvents(client) {
    client.on('user-published', async function (user, mediaType) {
      try {
        await client.subscribe(user, mediaType);
        if (mediaType === 'video' && user.videoTrack) {
          var remote = document.querySelector('[data-chat-call-remote]');
          if (remote) {
            remote.innerHTML = '';
            user.videoTrack.play(remote);
          }
        }
        if (mediaType === 'audio' && user.audioTrack) {
          user.audioTrack.play();
        }
        setStatus('Connected');
      } catch (e) {
        setStatus('Remote media could not be subscribed.');
      }
    });
    client.on('user-unpublished', function (user, mediaType) {
      if (mediaType === 'video') {
        var remote = document.querySelector('[data-chat-call-remote]');
        if (remote) {
          remote.innerHTML = '<span>Remote camera is off</span>';
        }
      }
    });
    client.on('user-left', function () {
      var remote = document.querySelector('[data-chat-call-remote]');
      if (remote) {
        remote.innerHTML = '<span>Remote user left</span>';
      }
      setStatus('Remote user left');
    });
  }

  async function connectMedia(call) {
    if (!call || !call.call_id || mediaConnecting || mediaJoinedCallId === Number(call.call_id)) return;
    if (!window.AgoraRTC || typeof window.AgoraRTC.createClient !== 'function') {
      setStatus('Agora SDK is not loaded.');
      return;
    }
    mediaConnecting = true;
    setStatus('Preparing secure media session...');
    try {
      var res = await post({ p: 'joinChatCall', call_id: call.call_id });
      if (!res || res.status !== 'success' || !res.agora) {
        throw new Error((res && res.message) || 'join_failed');
      }
      var payload = res.agora;
      agoraClient = window.AgoraRTC.createClient({ mode: 'rtc', codec: 'vp8' });
      wireAgoraEvents(agoraClient);
      setStatus('Joining Agora channel...');
      await agoraClient.join(payload.appId, payload.channel, tokenForJoin(payload), payload.uid || null);

      setStatus('Opening microphone...');
      localTracks.audio = await window.AgoraRTC.createMicrophoneAudioTrack();
      var publishTracks = [localTracks.audio];
      if (call.call_type === 'video') {
        setStatus('Opening camera...');
        localTracks.video = await window.AgoraRTC.createCameraVideoTrack();
        publishTracks.push(localTracks.video);
        var local = document.querySelector('[data-chat-call-local]');
        if (local) {
          local.hidden = false;
          local.innerHTML = '';
          localTracks.video.play(local);
        }
      }
      setStatus('Publishing media...');
      await agoraClient.publish(publishTracks);
      mediaJoinedCallId = Number(call.call_id);
      mediaConnecting = false;
      setStatus('Connected');
    } catch (e) {
      mediaConnecting = false;
      setStatus('Media connection failed: ' + (e && e.message ? e.message : 'unknown error'));
      try { await leaveMedia(); } catch (_) {}
    }
  }

  async function toggleAudio() {
    if (!localTracks.audio) return;
    audioMuted = !audioMuted;
    await localTracks.audio.setEnabled(!audioMuted);
    var btn = document.querySelector('[data-chat-call-action="mute"]');
    if (btn) {
      var label = btn.querySelector('span');
      if (label) label.textContent = audioMuted ? 'Unmute' : 'Mute';
      btn.setAttribute('aria-label', audioMuted ? 'Unmute' : 'Mute');
      btn.setAttribute('title', audioMuted ? 'Unmute' : 'Mute');
      btn.classList.toggle('is-active', audioMuted);
    }
  }

  async function toggleVideo() {
    if (!localTracks.video) return;
    videoMuted = !videoMuted;
    await localTracks.video.setEnabled(!videoMuted);
    var btn = document.querySelector('[data-chat-call-action="camera"]');
    if (btn) {
      var label = btn.querySelector('span');
      if (label) label.textContent = videoMuted ? 'Camera on' : 'Camera';
      btn.setAttribute('aria-label', videoMuted ? 'Camera on' : 'Camera');
      btn.setAttribute('title', videoMuted ? 'Camera on' : 'Camera');
      btn.classList.toggle('is-active', videoMuted);
    }
    var local = document.querySelector('[data-chat-call-local]');
    if (local) {
      local.classList.toggle('is-muted', videoMuted);
    }
  }

  function pollCalls() {
    if (destroyed) return;
    var selectedPeer = selectedPeerId();
    if (selectedPeer) currentPeerId = selectedPeer;
    post({ p: 'pollChatCalls', with: 0 }).then(function (res) {
      if (!res || res.status !== 'success') return;
      var calls = Array.isArray(res.items) ? res.items : [];
      var ringingIncoming = calls.find(function (item) { return item.direction === 'incoming' && item.status === 'ringing'; });
      var accepted = calls.find(function (item) { return item.status === 'accepted'; });

      if (ringingIncoming && (!activeCall || Number(activeCall.call_id) !== Number(ringingIncoming.call_id))) {
        activeCall = ringingIncoming;
        currentPeerId = Number(ringingIncoming.partner_id || ringingIncoming.caller_id || 0);
        renderModal('incoming', ringingIncoming, 'Incoming call. Choose how you want to respond.');
        startPolling();
        return;
      }

      if (accepted && activeCall && Number(activeCall.call_id) === Number(accepted.call_id) && activeCall.status !== 'accepted') {
        activeCall = accepted;
        renderModal('active', accepted, 'Call accepted. Connecting media...');
        connectMedia(accepted);
        return;
      }

      if (!calls.length && activeCall) {
        leaveMedia();
        activeCall = null;
        clearModal();
        stopPollingIfIdle();
      }
    }).catch(function () {});
  }

  function startCall(type) {
    var peerId = selectedPeerId();
    if (!peerId) return;
    currentPeerId = peerId;
    renderModal('loading', { call_type: type }, 'Starting call...');
    post({ p: 'startChatCall', to: peerId, call_type: type }).then(function (res) {
      if (!res || res.status !== 'success') {
        renderModal('closed', { call_type: type }, (res && res.message) ? res.message : 'Could not start the call.');
        return;
      }
      activeCall = res.call;
      renderModal('outgoing', res.call, 'Ringing...');
      startPolling();
      pollCalls();
    }).catch(function () {
      renderModal('closed', { call_type: type }, 'Could not start the call.');
    });
  }

  function controlCall(action, callId) {
    if (action === 'close') {
      clearModal();
      return;
    }
    if (!callId) return;
    var endpoint = {
      accept: 'acceptChatCall',
      reject: 'rejectChatCall',
      cancel: 'cancelChatCall',
      end: 'endChatCall'
    }[action];
    if (!endpoint) return;

    post({ p: endpoint, call_id: callId }).then(function (res) {
      if (!res || res.status !== 'success') {
        renderModal('closed', activeCall || {}, (res && res.message) ? res.message : 'Call action failed.');
        return;
      }
      activeCall = res.call || null;
      if (action === 'accept') {
        renderModal('active', activeCall, 'Call accepted. Connecting media...');
        startPolling();
        connectMedia(activeCall);
      } else if (action === 'end' || action === 'reject' || action === 'cancel') {
        leaveMedia();
        activeCall = null;
        renderModal('closed', res.call || {}, action === 'reject' ? 'Call declined.' : 'Call ended.');
        setTimeout(function () {
          if (!activeCall) clearModal();
          stopPollingIfIdle();
        }, 1400);
      }
    }).catch(function () {
      renderModal('closed', activeCall || {}, 'Call action failed.');
    });
  }

  function clickHandler(event) {
    var start = event.target.closest('[data-chat-call-start]');
    if (start) {
      event.preventDefault();
      if (start.disabled) return;
      startCall(start.getAttribute('data-chat-call-start') || 'audio');
      return;
    }

    var action = event.target.closest('[data-chat-call-action]');
    if (action) {
      event.preventDefault();
      var name = action.getAttribute('data-chat-call-action');
      if (name === 'mute') {
        toggleAudio();
        return;
      }
      if (name === 'camera') {
        toggleVideo();
        return;
      }
      if (name === 'minimize') {
        setCallMinimized(true);
        return;
      }
      if (name === 'restore') {
        setCallMinimized(false);
        return;
      }
      controlCall(name, action.getAttribute('data-call-id'));
    }
  }

  document.addEventListener('click', clickHandler);
  document.addEventListener('pointerdown', startMiniDrag);
  document.addEventListener('pointerdown', startMiniResize);
  document.addEventListener('pointermove', moveMiniDrag);
  document.addEventListener('pointermove', moveMiniResize);
  document.addEventListener('pointerup', endMiniDrag);
  document.addEventListener('pointerup', endMiniResize);
  document.addEventListener('pointercancel', endMiniDrag);
  document.addEventListener('pointercancel', endMiniResize);
  window.addEventListener('resize', clampMiniOnResize);
  startPolling();

  window.chatCallController = {
    poll: pollCalls,
    destroy: function () {
      destroyed = true;
      document.removeEventListener('click', clickHandler);
      document.removeEventListener('pointerdown', startMiniDrag);
      document.removeEventListener('pointerdown', startMiniResize);
      document.removeEventListener('pointermove', moveMiniDrag);
      document.removeEventListener('pointermove', moveMiniResize);
      document.removeEventListener('pointerup', endMiniDrag);
      document.removeEventListener('pointerup', endMiniResize);
      document.removeEventListener('pointercancel', endMiniDrag);
      document.removeEventListener('pointercancel', endMiniResize);
      window.removeEventListener('resize', clampMiniOnResize);
      if (pollTimer) clearInterval(pollTimer);
      pollTimer = null;
      leaveMedia();
      clearModal();
    }
  };
})();
