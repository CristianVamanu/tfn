'use strict';
(function () {
  var stage = document.querySelector('.audio-room-stage');
  if (!stage || stage.dataset.bound === '1') { return; }
  stage.dataset.bound = '1';

  var roomId = parseInt(stage.dataset.roomId || '0', 10);
  var client = null;
  var localTrack = null;
  var joined = false;
  var currentRole = stage.dataset.role || 'listener';
  var micMuted = true;
  var moderatorMuted = false;
  var pingTimer = null;
  var stateTimer = null;
  var chatTimer = null;
  var manageTimer = null;
  var countdownTimer = null;
  var redirectTimer = null;
  var endedHandled = false;
  var chatMuteRemaining = 0;
  var autoEndAt = parseInt(stage.dataset.autoEndAt || '0', 10) || 0;
  var serverTime = parseInt(stage.dataset.serverTime || '0', 10) || 0;
  var clientStart = Math.floor(Date.now() / 1000);
  var speakingUsers = {};
  var openManageMenuUserId = '';
  var activeManageActionButton = null;
  var lastChatFetchAt = 0;

  function qs(selector, host) { return (host || document).querySelector(selector); }
  function qsa(selector, host) { return Array.prototype.slice.call((host || document).querySelectorAll(selector)); }
  function url(path) {
    if (typeof window.buildUrl === 'function') { return window.buildUrl(path); }
    return path;
  }
  function i18n(key, fallback, params) {
    try {
      if (window.DZ && typeof window.DZ.i18n === 'function') {
        var value = window.DZ.i18n(key, params || {});
        if (value) { return value; }
      }
    } catch (_) {}
    var text = fallback || key || '';
    if (params) {
      Object.keys(params).forEach(function (name) {
        text = text.replace(new RegExp('\\{\\{?' + name + '\\}?\\}', 'g'), params[name]);
      });
    }
    return text;
  }
  var chatPanel = qs('[data-audio-room-chat]');
  var chatToggle = qs('[data-audio-room-chat-toggle]');
  var chatBackdrop = qs('[data-audio-room-chat-backdrop]');
  var chatClose = qs('[data-audio-room-chat-close]');
  var chatDot = qs('[data-audio-room-chat-dot]');
  function speakerIconHtml() {
    var template = qs('[data-audio-room-speaker-icon]');
    return template ? template.innerHTML : '';
  }
  function isChatOpen() {
    return !!(chatPanel && !chatPanel.classList.contains('none'));
  }
  function setChatUnread(active) {
    if (chatDot) { chatDot.classList.toggle('none', !active); }
  }
  function openRoomChat() {
    if (!chatPanel) { return; }
    chatPanel.classList.remove('none');
    chatPanel.setAttribute('aria-hidden', 'false');
    if (chatBackdrop) { chatBackdrop.classList.remove('none'); }
    if (chatToggle) {
      chatToggle.classList.add('is-selected');
      chatToggle.setAttribute('aria-expanded', 'true');
    }
    setChatUnread(false);
    var messages = qs('[data-audio-room-messages]', chatPanel);
    if (messages) {
      window.setTimeout(function () { messages.scrollTop = messages.scrollHeight; }, 30);
    }
    var input = qs('[data-audio-room-chat-input]', chatPanel);
    if (input && !input.disabled && !input.readOnly) {
      window.setTimeout(function () { input.focus(); }, 60);
    }
  }
  function closeRoomChat() {
    if (!chatPanel) { return; }
    chatPanel.classList.add('none');
    chatPanel.setAttribute('aria-hidden', 'true');
    if (chatBackdrop) { chatBackdrop.classList.add('none'); }
    if (chatToggle) {
      chatToggle.classList.remove('is-selected');
      chatToggle.setAttribute('aria-expanded', 'false');
    }
  }
  function ensureManageActionSheet() {
    var sheet = qs('[data-audio-room-action-sheet]');
    if (sheet) { return sheet; }
    sheet = document.createElement('div');
    sheet.className = 'audio-room-action-sheet none';
    sheet.setAttribute('data-audio-room-action-sheet', '1');
    sheet.innerHTML = '<div class="audio-room-action-sheet__content" role="dialog" aria-modal="true">' +
      '<div class="audio-room-action-sheet__panel" data-audio-room-action-list></div>' +
      '<button type="button" class="audio-room-action-sheet__cancel" data-audio-room-action-cancel>' + i18n('cancel', 'Cancel') + '</button>' +
      '</div>';
    document.body.appendChild(sheet);
    sheet.addEventListener('click', function (event) {
      if (event.target === sheet || event.target.closest('[data-audio-room-action-cancel]')) {
        closeManageActionSheet();
        return;
      }
      var actionButton = event.target.closest('button[data-action]');
      if (actionButton) {
        runManageAction(actionButton);
      }
    });
    return sheet;
  }
  function closeManageActionSheet() {
    var sheet = qs('[data-audio-room-action-sheet]');
    if (sheet) { sheet.classList.add('none'); }
    activeManageActionButton = null;
    closeManageMenus();
  }
  function openManageActionSheet(menu) {
    var dropdown = qs('.audio-room-manage-item__dropdown', menu);
    if (!dropdown) { return; }
    var sheet = ensureManageActionSheet();
    var list = qs('[data-audio-room-action-list]', sheet);
    if (!list) { return; }
    list.innerHTML = '';
    qsa('button[data-action]', dropdown).forEach(function (sourceButton) {
      var button = document.createElement('button');
      button.type = 'button';
      button.textContent = sourceButton.textContent || '';
      button.dataset.action = sourceButton.dataset.action || '';
      button.dataset.userId = sourceButton.dataset.userId || '';
      if (sourceButton.dataset.minutes) { button.dataset.minutes = sourceButton.dataset.minutes; }
      if (sourceButton.classList.contains('is-danger')) { button.classList.add('is-danger'); }
      list.appendChild(button);
    });
    sheet.classList.remove('none');
  }
  function serverMessage(code, fallback, params) {
    var map = {
      audio_room_capacity_reached: 'audio_room_error_capacity_reached',
      audio_room_chat_disabled: 'audio_room_error_chat_disabled',
      audio_room_custom_price_disabled: 'audio_room_error_custom_price_disabled',
      audio_room_daily_limit_reached: 'audio_room_error_daily_limit_reached',
      audio_room_paid_not_allowed: 'audio_room_error_paid_not_allowed',
      audio_rooms_disabled: 'audio_room_error_disabled',
      banned: 'audio_room_error_banned',
      chat_muted: 'audio_room_error_chat_muted',
      invalid_audio_room_price: 'audio_room_error_invalid_price',
      invalid_room_id: 'audio_room_error_invalid_room',
      muted_by_moderator: 'audio_room_error_muted_by_moderator',
      room_ended: 'audio_room_error_room_ended',
      room_not_found: 'audio_room_error_room_not_found',
      removed: 'audio_room_error_removed'
    };
    var key = map[code] || '';
    return key ? i18n(key, fallback || code, params) : (fallback || code || i18n('audio_room_error_generic', 'Something went wrong.'));
  }
  function csrf() {
    var token = qs('input[name="csrf_token"]', stage);
    if (!token) { token = qs('input[name="csrf_token"]'); }
    return token ? token.value : '';
  }
  function setLine(message, type) {
    var line = qs('[data-audio-room-status-line]', stage);
    if (line) {
      line.textContent = message || '';
      line.dataset.type = type || 'info';
    }
  }
  function currentServerTime() {
    return serverTime > 0 ? serverTime + (Math.floor(Date.now() / 1000) - clientStart) : Math.floor(Date.now() / 1000);
  }
  function formatDuration(seconds) {
    seconds = Math.max(0, parseInt(seconds || 0, 10));
    var h = Math.floor(seconds / 3600);
    var m = Math.floor((seconds % 3600) / 60);
    var s = seconds % 60;
    if (h > 0) {
      return h + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
    }
    return m + ':' + String(s).padStart(2, '0');
  }
  function updateChatMuteState(seconds) {
    chatMuteRemaining = Math.max(0, parseInt(seconds || 0, 10));
    var input = qs('[data-audio-room-chat-input]');
    var send = qs('.audio-room-chat__send');
    var muted = chatMuteRemaining > 0;
    if (input) {
      input.disabled = muted;
      input.placeholder = muted ? i18n('audio_room_chat_muted_for', 'Chat muted for {time}', { time: formatDuration(chatMuteRemaining) }) : (input.dataset.placeholder || input.getAttribute('placeholder') || i18n('audio_room_chat_placeholder', 'Write a message'));
      if (!input.dataset.placeholder) { input.dataset.placeholder = input.getAttribute('placeholder') || i18n('audio_room_chat_placeholder', 'Write a message'); }
    }
    if (send) { send.disabled = muted; }
    updateSpeakerRequestButton();
  }
  function updateMicButton() {
    var micButton = qs('[data-audio-room-mic]', stage);
    var micLabel = qs('[data-audio-room-mic-label]', stage);
    var canUseMic = joined && canPublish(currentRole) && !moderatorMuted;
    if (micButton) {
      micButton.disabled = !canUseMic;
      micButton.classList.toggle('is-active', canUseMic && !micMuted);
      micButton.classList.toggle('is-muted', joined && canPublish(currentRole) && (micMuted || moderatorMuted));
    }
    if (micLabel) {
      micLabel.textContent = !joined
        ? i18n('audio_room_join_to_use_mic', 'Join to use mic')
        : (moderatorMuted
          ? i18n('audio_room_muted_by_moderator', 'Muted by moderator')
          : (micMuted ? i18n('audio_room_unmute_mic', 'Unmute mic') : i18n('audio_room_mute_mic', 'Mute mic')));
    }
  }
  function updateSpeakerRequestButton() {
    var request = qs('[data-audio-room-speaker-request]', stage);
    if (!request) { return; }
    var canRequest = joined && currentRole === 'listener' && stage.dataset.canJoin === '1' && chatMuteRemaining <= 0;
    request.disabled = !canRequest;
  }
  function setRole(role, speakerStatus) {
    currentRole = role || 'listener';
    stage.dataset.role = currentRole;
    moderatorMuted = currentRole === 'speaker' && speakerStatus === 'muted';
    var target = qs('[data-audio-room-role]', stage);
    if (target) {
      target.textContent = i18n('audio_room_role_' + currentRole, currentRole.replace(/^./, function (c) { return c.toUpperCase(); }));
    }
    updateSpeakerRequestButton();
    if (moderatorMuted && !micMuted) { setMicMuted(true, false); }
    updateMicButton();
  }
  function request(method, params) {
    var fd = new FormData();
    Object.keys(params || {}).forEach(function (key) { fd.append(key, params[key]); });
    return fetch(url('request/requests.php'), {
      method: method || 'POST',
      body: fd,
      credentials: 'same-origin'
    }).then(function (response) { return response.json(); });
  }
  function getJson(path) {
    return fetch(url(path), { credentials: 'same-origin' }).then(function (response) { return response.json(); });
  }
  function canPublish(role) {
    return ['host', 'moderator', 'speaker'].indexOf(role || '') !== -1;
  }
  function markUserSpeaking(userId, speaking) {
    userId = String(userId || '');
    if (!userId) { return; }
    if (speaking) {
      speakingUsers[userId] = Date.now();
    }
    qsa('[data-user-id="' + userId.replace(/"/g, '\\"') + '"]').forEach(function (item) {
      var active = speaking || (speakingUsers[userId] && Date.now() - speakingUsers[userId] < 1800);
      item.classList.toggle('is-speaking', !!active);
    });
  }
  function pruneSpeakingUsers() {
    var now = Date.now();
    Object.keys(speakingUsers).forEach(function (userId) {
      if (now - speakingUsers[userId] > 1800) {
        delete speakingUsers[userId];
        markUserSpeaking(userId, false);
      }
    });
  }
  function friendlyAgoraError(err) {
    var raw = (err && (err.message || err.toString && err.toString())) ? String(err.message || err.toString()) : '';
    if (/invalid vendor key|can not find appid|CAN_NOT_GET_GATEWAY_SERVER/i.test(raw)) {
      return i18n('audio_room_agora_invalid_app', 'Agora App ID could not be verified. Please check the Agora App ID and certificate in admin settings.');
    }
    if (/network|timeout|gateway/i.test(raw)) {
      return i18n('audio_room_agora_network_error', 'Could not reach Agora. Please check the network connection and Agora domain access.');
    }
    if (/permission|notallowed|denied/i.test(raw)) {
      return i18n('audio_room_agora_mic_denied', 'Microphone permission was denied. Please allow microphone access and try again.');
    }
    return raw || i18n('audio_room_agora_connect_error', 'Could not connect to Agora.');
  }
  async function applyLocalMicMuted(muted) {
    micMuted = !!muted;
    try {
      if (localTrack) {
        if (typeof localTrack.setEnabled === 'function') {
          await localTrack.setEnabled(!micMuted);
        } else if (typeof localTrack.setMuted === 'function') {
          await localTrack.setMuted(micMuted);
        }
      }
    } catch (_) {}
    updateMicButton();
  }
  async function setMicMuted(muted, notifyServer) {
    await applyLocalMicMuted(muted);
    if (notifyServer) {
      request('POST', {
        p: 'audio_room_mic_update',
        room_id: String(roomId),
        muted: micMuted ? '1' : '0',
        csrf_token: csrf()
      }).then(function (res) {
        if (res && res.status !== 'success') {
          if (res.message === 'muted_by_moderator') {
            moderatorMuted = true;
            applyLocalMicMuted(true);
          }
          setLine(res && res.message ? serverMessage(res.message, res.message) : i18n('audio_room_mic_update_failed', 'Mic state could not be updated.'), 'error');
        }
      }).catch(function () {});
    }
  }
  function tokenForJoin(payload) {
    if (!payload) { return null; }
    if (payload.debug && payload.allow_tokenless) { return null; }
    return payload.token || null;
  }
  async function connectAgora(payload) {
    if (!payload || !payload.appId || !payload.channel) {
      setLine(i18n('audio_room_agora_join_missing', 'Agora join data is missing.'), 'error');
      return false;
    }
    if (!window.AgoraRTC) {
      setLine(i18n('audio_room_agora_sdk_missing', 'Agora SDK is not loaded. Room presence is active, but audio cannot start.'), 'error');
      return false;
    }
    if (payload.debug && !payload.allow_tokenless) {
      setLine(i18n('audio_room_agora_certificate_missing', 'Agora certificate is missing. Add a certificate or enable tokenless debug for local testing.'), 'error');
      return false;
    }

    client = window.AgoraRTC.createClient({ mode: 'live', codec: 'vp8' });
    client.on('connection-state-change', function (curState, prevState) {
      if (curState === 'DISCONNECTED' || curState === 'FAILED') {
        setLine(i18n('audio_room_agora_reconnecting', 'Audio connection is reconnecting...'), 'error');
      } else if (prevState && curState === 'CONNECTED') {
        setLine(canPublish(currentRole) && !micMuted ? i18n('audio_room_microphone_live', 'Microphone is live.') : i18n('audio_room_listening', 'Listening in the room.'), 'success');
      }
    });
    client.on('user-published', async function (user, mediaType) {
      try {
        await client.subscribe(user, mediaType);
        if (mediaType === 'audio' && user.audioTrack) {
          user.audioTrack.play();
        }
      } catch (_) {}
    });
    client.on('user-unpublished', function () {});
    client.on('volume-indicator', function (volumes) {
      (volumes || []).forEach(function (volume) {
        markUserSpeaking(volume.uid, Number(volume.level || 0) > 8);
      });
    });

    var role = payload.role || stage.dataset.role || 'listener';
    currentRole = role;
    try {
      if (typeof client.setClientRole === 'function') {
        await client.setClientRole(canPublish(role) ? 'host' : 'audience');
      }
      await client.join(payload.appId, payload.channel, tokenForJoin(payload), payload.uid || null);
      if (typeof client.enableAudioVolumeIndicator === 'function') {
        try { client.enableAudioVolumeIndicator(); } catch (_) {}
      }
      if (canPublish(role) && !moderatorMuted && typeof window.AgoraRTC.createMicrophoneAudioTrack === 'function') {
        localTrack = await window.AgoraRTC.createMicrophoneAudioTrack();
        await client.publish([localTrack]);
        await setMicMuted(false, true);
      }
      updateMicButton();
      setLine(canPublish(role) ? i18n('audio_room_microphone_live', 'Microphone is live.') : i18n('audio_room_listening', 'Listening in the room.'), 'success');
      return true;
    } catch (err) {
      try { await disconnectAgora(); } catch (_) {}
      setLine(friendlyAgoraError(err), 'error');
      return false;
    }
  }
  async function disconnectAgora() {
    try {
      if (localTrack) {
        try { localTrack.stop(); } catch (_) {}
        try { localTrack.close(); } catch (_) {}
      }
      localTrack = null;
      micMuted = true;
      if (client) {
        try { await client.leave(); } catch (_) {}
      }
      client = null;
      updateMicButton();
    } catch (_) {}
  }
  async function unpublishLocalAudioTrack() {
    if (!localTrack) { return; }
    try {
      if (client && typeof client.unpublish === 'function') {
        await client.unpublish([localTrack]);
      }
    } catch (_) {}
    try { localTrack.stop(); } catch (_) {}
    try { localTrack.close(); } catch (_) {}
    localTrack = null;
    micMuted = true;
  }
  async function syncAgoraRole(role, speakerStatus) {
    role = role || 'listener';
    if (!client || !joined) { return; }
    moderatorMuted = role === 'speaker' && speakerStatus === 'muted';
    try {
      if (typeof client.setClientRole === 'function') {
        await client.setClientRole(canPublish(role) && !moderatorMuted ? 'host' : 'audience');
      }
      if (canPublish(role) && !moderatorMuted) {
        if (!localTrack && window.AgoraRTC && typeof window.AgoraRTC.createMicrophoneAudioTrack === 'function') {
          localTrack = await window.AgoraRTC.createMicrophoneAudioTrack();
          await client.publish([localTrack]);
          await setMicMuted(false, true);
        }
      } else {
        await unpublishLocalAudioTrack();
        if (role === 'listener') {
          setLine(i18n('audio_room_listener_mode', 'You are listening in the room.'), 'info');
        }
      }
    } catch (err) {
      setLine(friendlyAgoraError(err), 'error');
    }
    updateMicButton();
  }
  function markJoined(isJoined) {
    joined = !!isJoined;
    var joinBtn = qs('[data-audio-room-join]', stage);
    var leaveBtn = qs('[data-audio-room-leave]', stage);
    if (joinBtn) { joinBtn.classList.toggle('none', joined); joinBtn.disabled = joined; }
    if (leaveBtn) { leaveBtn.classList.toggle('none', !joined); leaveBtn.disabled = !joined; }
    updateSpeakerRequestButton();
    updateMicButton();
  }
  function redirectToRooms(delaySeconds) {
    var target = stage.dataset.audioRoomsUrl || url('audio-rooms');
    var remaining = Math.max(1, parseInt(delaySeconds || 5, 10));
    var count = qs('[data-audio-room-ended-countdown]');
    if (count) { count.textContent = String(remaining); }
    if (redirectTimer) { window.clearInterval(redirectTimer); }
    redirectTimer = window.setInterval(function () {
      remaining -= 1;
      if (count) { count.textContent = String(Math.max(0, remaining)); }
      if (remaining <= 0) {
        window.clearInterval(redirectTimer);
        window.location.href = target;
      }
    }, 1000);
  }
  function showRoomExitModal(title, message, delaySeconds) {
    var modal = qs('[data-audio-room-ended-modal]');
    if (!modal) { return; }
    var titleEl = qs('[data-audio-room-ended-title]', modal);
    var messageEl = qs('[data-audio-room-ended-message]', modal);
    if (titleEl) { titleEl.textContent = title || i18n('audio_room_ended_title', 'Room ended'); }
    if (messageEl) { messageEl.textContent = message || i18n('audio_room_ended_message', 'This audio room has ended.'); }
    modal.classList.remove('none');
    redirectToRooms(delaySeconds || 5);
  }
  async function handleForcedExit(kind) {
    if (endedHandled) { return; }
    endedHandled = true;
    stopTimers();
    await disconnectAgora();
    markJoined(false);
    stage.dataset.roomStatus = 'ended';
    var title = i18n('audio_room_ended_title', 'Room ended');
    var message = i18n('audio_room_ended_message', 'This audio room has ended.');
    if (kind === 'banned') {
      title = i18n('audio_room_removed_title', 'Removed from room');
      message = i18n('audio_room_banned_message', 'You have been banned from this audio room.');
    } else if (kind === 'removed') {
      title = i18n('audio_room_removed_title', 'Removed from room');
      message = i18n('audio_room_removed_message', 'You have been removed from this audio room.');
    }
    setLine(message, kind === 'ended' ? 'info' : 'error');
    showRoomExitModal(title, message, 5);
  }
  function renderCountdown() {
    var box = qs('[data-audio-room-countdown]');
    var value = qs('[data-audio-room-countdown-value]', box || stage);
    if (!box || !value || !autoEndAt) { return; }
    var remaining = autoEndAt - currentServerTime();
    value.textContent = formatDuration(remaining);
    box.classList.toggle('is-warning', remaining <= 300 && remaining > 60);
    box.classList.toggle('is-danger', remaining <= 60);
    if (remaining <= 0) {
      value.textContent = '0:00';
    }
  }
  function startCountdown() {
    if (countdownTimer) { window.clearInterval(countdownTimer); }
    renderCountdown();
    if (autoEndAt > 0) {
      countdownTimer = window.setInterval(renderCountdown, 1000);
    }
  }
  function startTimers() {
    stopTimers();
    pingTimer = window.setInterval(function () {
      request('POST', { p: 'audio_room_ping', room_id: String(roomId) })
        .then(function (res) {
          if (res && res.status === 'error' && (res.message === 'removed' || res.message === 'banned' || res.message === 'room_ended')) {
            handleForcedExit(res.message === 'room_ended' ? 'ended' : res.message);
            return;
          }
          if (res && res.status === 'success' && res.role) {
            var previousRole = currentRole;
            updateChatMuteState(res.chat_mute_remaining || 0);
            setRole(res.role, res.speaker_status || '');
            if (joined && canPublish(res.role) !== canPublish(previousRole)) {
              syncAgoraRole(res.role, res.speaker_status || '');
            }
          }
        })
        .catch(function () {});
    }, 10000);
    stateTimer = window.setInterval(refreshRoomState, 2000);
    if (stage.dataset.chatEnabled === '1' && !chatTimer) {
      chatTimer = window.setInterval(fetchMessages, 4000);
    }
    startCountdown();
    refreshRoomState();
  }
  function stopTimers() {
    [pingTimer, stateTimer, chatTimer, manageTimer, countdownTimer].forEach(function (timer) {
      if (timer) { window.clearInterval(timer); }
    });
    pingTimer = null;
    stateTimer = null;
    chatTimer = null;
    manageTimer = null;
    countdownTimer = null;
  }
  function refreshAgoraRole() {
    setLine(i18n('audio_room_role_updated_rejoining', 'Role updated. Refreshing audio...'), 'info');
    request('POST', { p: 'audio_room_join', room_id: String(roomId), csrf_token: csrf() })
      .then(async function (res) {
        if (!res || res.status !== 'success' || !res.data) {
          setLine((res && res.message) ? serverMessage(res.message, res.message) : i18n('audio_room_role_refresh_failed', 'Could not refresh audio role.'), 'error');
          return;
        }
        setRole(res.data.role || 'listener', '');
        if (client) {
          await syncAgoraRole(res.data.role || 'listener', res.data.speaker_status || '');
        } else {
          await connectAgora(res.data);
        }
      })
      .catch(function () { setLine(i18n('audio_room_role_refresh_request_failed', 'Role refresh failed.'), 'error'); });
  }
  function applyRoomState(res) {
    if (!res || res.status !== 'success') { return; }
    var speakers = qs('[data-audio-room-speakers]', stage);
    var listeners = qs('[data-audio-room-listeners]', stage);
    if (speakers) { speakers.textContent = String(res.speakers || 0); }
    if (listeners) { listeners.textContent = String(res.listeners || 0); }
    if (res.server_time) {
      serverTime = parseInt(res.server_time, 10) || serverTime;
      clientStart = Math.floor(Date.now() / 1000);
    }
    if (res.auto_end_at) {
      autoEndAt = parseInt(res.auto_end_at, 10) || autoEndAt;
      stage.dataset.autoEndAt = String(autoEndAt || 0);
      if (!countdownTimer) { startCountdown(); }
    }
    updateChatMuteState(res.chat_mute_remaining || 0);
    var participantStatus = res.participant && res.participant.status ? String(res.participant.status) : '';
    if (participantStatus === 'removed' || participantStatus === 'banned') {
      handleForcedExit(participantStatus);
      return;
    }
    if (res.room_status === 'ended') {
      handleForcedExit('ended');
      return;
    }
    if (res.role) {
      var previousRole = currentRole;
      setRole(res.role, res.speaker_status || '');
      if (joined && canPublish(res.role) !== canPublish(previousRole)) {
        syncAgoraRole(res.role, res.speaker_status || '');
      } else if (joined && res.speaker_status === 'muted' && !micMuted) {
        syncAgoraRole(res.role, res.speaker_status || '');
      }
    }
    if (qs('[data-audio-room-manage]') && res.can_manage) {
      renderManagePanel(res);
    }
    if (stage.dataset.chatEnabled === '1') {
      var nowMs = Date.now();
      if (nowMs - lastChatFetchAt > 3000) {
        lastChatFetchAt = nowMs;
        fetchMessages();
      }
    }
    pruneSpeakingUsers();
  }
  function refreshRoomState() {
    if (!roomId) { return; }
    getJson('request/requests.php?p=audio_room_state&room_id=' + encodeURIComponent(String(roomId)))
      .then(applyRoomState)
      .catch(function () {});
  }
  function refreshStats() {
    if (!roomId) { return; }
    getJson('request/requests.php?p=audio_room_stats&room_id=' + encodeURIComponent(String(roomId)))
      .then(function (res) {
        if (!res || res.status !== 'success') { return; }
        var speakers = qs('[data-audio-room-speakers]', stage);
        var listeners = qs('[data-audio-room-listeners]', stage);
        if (speakers) { speakers.textContent = String(res.speakers || 0); }
        if (listeners) { listeners.textContent = String(res.listeners || 0); }
        if (res.server_time) {
          serverTime = parseInt(res.server_time, 10) || serverTime;
          clientStart = Math.floor(Date.now() / 1000);
        }
        if (res.auto_end_at) {
          autoEndAt = parseInt(res.auto_end_at, 10) || autoEndAt;
          stage.dataset.autoEndAt = String(autoEndAt || 0);
        }
        updateChatMuteState(res.chat_mute_remaining || 0);
        var participantStatus = res.participant && res.participant.status ? String(res.participant.status) : '';
        if (participantStatus === 'removed' || participantStatus === 'banned') {
          handleForcedExit(participantStatus);
          return;
        }
        if (res.room_status === 'ended') {
          handleForcedExit('ended');
        }
      })
      .catch(function () {});
  }
  function messageHtml(message) {
    var item = document.createElement('div');
    item.className = 'audio-room-chat-message';
    item.dataset.messageId = String(message.id || '0');
    item.dataset.messageType = message.message_type || 'chat';
    var strong = document.createElement('strong');
    strong.textContent = message.user_fullname || message.username || i18n('chat_user_fallback', 'User');
    var span = document.createElement('span');
    if ((message.message_type || '') === 'tip') {
      var meta = {};
      try {
        meta = message.meta_json ? JSON.parse(message.meta_json) : {};
      } catch (_) {
        meta = {};
      }
      var amount = Number(meta.amount || 0);
      var currency = String(meta.currency || stage.getAttribute('data-currency') || '').toUpperCase();
      var amountText = amount > 0 ? String(amount) : '';
      if (amount > 0 && window.DZ && typeof window.DZ.formatCurrency === 'function') {
        amountText = window.DZ.formatCurrency(amount, currency);
      } else if (amount > 0 && currency) {
        amountText = currency + ' ' + amountText;
      }
      span.textContent = amountText ? i18n('audio_room_tip_chat_with_amount', 'sent a {amount} tip', { amount: amountText }) : i18n('audio_room_tip_chat_fallback', 'sent a tip');
      item.classList.add('audio-room-chat-message--tip');
    } else {
      span.textContent = message.message || '';
    }
    item.appendChild(strong);
    item.appendChild(span);
    return item;
  }
  function manageName(row) {
    return row.display_name || row.user_fullname || row.username || i18n('audio_room_user_number', 'User #{id}', { id: row.user_id || '' });
  }
  function manageAvatar(row) {
    return row.avatar_url || '';
  }
  function manageItem(row, options) {
    options = options || {};
    var item = document.createElement('div');
    item.className = 'audio-room-manage-item';
    item.dataset.userId = String(row.user_id || '');
    var avatar = document.createElement('img');
    avatar.src = manageAvatar(row);
    avatar.alt = manageName(row);
    var copy = document.createElement('div');
    copy.className = 'audio-room-manage-item__copy';
    var strong = document.createElement('strong');
    strong.textContent = manageName(row);
    var small = document.createElement('small');
    small.textContent = options.meta || row.role || ('@' + (row.username || i18n('audio_room_username_fallback', 'user')));
    copy.appendChild(strong);
    copy.appendChild(small);
    item.appendChild(avatar);
    item.appendChild(copy);
    var speakingIndicator = document.createElement('span');
    speakingIndicator.className = 'audio-room-manage-item__speaker-indicator';
    speakingIndicator.setAttribute('aria-label', i18n('audio_room_speaking_now', 'Speaking'));
    speakingIndicator.innerHTML = speakerIconHtml();
    item.appendChild(speakingIndicator);
    if (options.actions) {
      var actions = document.createElement('div');
      actions.className = 'audio-room-manage-item__actions';
      options.actions.forEach(function (action) {
        var button = document.createElement('button');
        button.type = 'button';
        button.textContent = action.label;
        button.dataset.action = action.action;
        button.dataset.userId = String(row.user_id || '');
        if (action.minutes) { button.dataset.minutes = String(action.minutes); }
        if (action.danger) { button.classList.add('is-danger'); }
        actions.appendChild(button);
      });
      item.appendChild(actions);
    }
    if (options.menuActions && options.menuActions.length) {
      var menuWrap = document.createElement('div');
      menuWrap.className = 'audio-room-manage-item__menu';
      var toggle = document.createElement('button');
      toggle.type = 'button';
      toggle.className = 'audio-room-manage-item__menu-toggle';
      toggle.setAttribute('aria-haspopup', 'true');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.textContent = '...';
      var dropdown = document.createElement('div');
      dropdown.className = 'audio-room-manage-item__dropdown';
      var arrow = document.createElement('span');
      arrow.className = 'audio-room-manage-item__dropdown-arrow';
      dropdown.appendChild(arrow);
      options.menuActions.forEach(function (action) {
        var menuButton = document.createElement('button');
        menuButton.type = 'button';
        menuButton.textContent = action.label;
        menuButton.dataset.action = action.action;
        menuButton.dataset.userId = String(row.user_id || '');
        if (action.minutes) { menuButton.dataset.minutes = String(action.minutes); }
        if (action.danger) { menuButton.classList.add('is-danger'); }
        dropdown.appendChild(menuButton);
      });
      menuWrap.appendChild(toggle);
      menuWrap.appendChild(dropdown);
      if (openManageMenuUserId && openManageMenuUserId === String(row.user_id || '')) {
        menuWrap.classList.add('is-open');
        toggle.setAttribute('aria-expanded', 'true');
      }
      item.appendChild(menuWrap);
    }
    if (row.user_id && speakingUsers[String(row.user_id)] && Date.now() - speakingUsers[String(row.user_id)] < 1800) {
      item.classList.add('is-speaking');
    }
    return item;
  }
  function closeManageMenus() {
    openManageMenuUserId = '';
    qsa('.audio-room-manage-item__menu.is-open').forEach(function (openMenu) {
      openMenu.classList.remove('is-open', 'is-above');
      var openToggle = qs('.audio-room-manage-item__menu-toggle', openMenu);
      var openDropdown = qs('.audio-room-manage-item__dropdown', openMenu);
      if (openToggle) { openToggle.setAttribute('aria-expanded', 'false'); }
      if (openDropdown) {
        openDropdown.style.left = '';
        openDropdown.style.top = '';
        openDropdown.style.right = '';
        openDropdown.style.display = '';
        openDropdown.style.visibility = '';
      }
    });
  }
  function positionManageMenu(menu) {
    var toggle = qs('.audio-room-manage-item__menu-toggle', menu);
    var dropdown = qs('.audio-room-manage-item__dropdown', menu);
    if (!toggle || !dropdown || !menu.classList.contains('is-open')) { return; }
    dropdown.style.left = '0px';
    dropdown.style.top = '0px';
    dropdown.style.right = 'auto';
    dropdown.style.visibility = 'hidden';
    dropdown.style.display = 'flex';
    var toggleRect = toggle.getBoundingClientRect();
    var dropdownRect = dropdown.getBoundingClientRect();
    var gap = 10;
    var margin = 12;
    var left = toggleRect.right - dropdownRect.width;
    left = Math.max(margin, Math.min(left, window.innerWidth - dropdownRect.width - margin));
    var top = toggleRect.bottom + gap;
    var above = false;
    if (top + dropdownRect.height > window.innerHeight - margin) {
      top = toggleRect.top - dropdownRect.height - gap;
      above = true;
    }
    top = Math.max(margin, Math.min(top, window.innerHeight - dropdownRect.height - margin));
    dropdown.style.left = left + 'px';
    dropdown.style.top = top + 'px';
    dropdown.style.visibility = '';
    menu.classList.toggle('is-above', above);
    var arrow = qs('.audio-room-manage-item__dropdown-arrow', dropdown);
    if (arrow) {
      var arrowLeft = (toggleRect.left + toggleRect.width / 2) - left - 6;
      arrow.style.left = Math.max(14, Math.min(arrowLeft, dropdownRect.width - 26)) + 'px';
    }
  }
  function positionOpenManageMenu() {
    qsa('.audio-room-manage-item__menu.is-open').forEach(positionManageMenu);
  }
  function renderManagePanel(data) {
    var requestBox = qs('[data-audio-room-speaker-requests]');
    var participantBox = qs('[data-audio-room-participants]');
    var counts = qs('[data-audio-room-manage-counts]');
    var requests = (data && Array.isArray(data.speaker_requests)) ? data.speaker_requests : [];
    var participants = (data && Array.isArray(data.participants)) ? data.participants : [];
    if (counts) {
      counts.textContent = i18n('audio_room_manage_counts', '{requests} requests / {participants} online', {
        requests: requests.length,
        participants: participants.length
      });
    }
    if (requestBox) {
      requestBox.innerHTML = '';
      if (!requests.length) {
        var emptyReq = document.createElement('div');
        emptyReq.className = 'audio-room-manage__empty';
        emptyReq.textContent = i18n('audio_room_no_pending_requests', 'No pending requests.');
        requestBox.appendChild(emptyReq);
      } else {
        requests.forEach(function (row) {
          requestBox.appendChild(manageItem(row, {
            meta: '@' + (row.username || i18n('audio_room_username_fallback', 'user')),
            actions: [
              { label: i18n('audio_room_accept', 'Accept'), action: 'approve-speaker' },
              { label: i18n('audio_room_reject', 'Reject'), action: 'reject-speaker' }
            ]
          }));
        });
      }
    }
    if (participantBox) {
      participantBox.innerHTML = '';
      if (!participants.length) {
        var emptyPart = document.createElement('div');
        emptyPart.className = 'audio-room-manage__empty';
        emptyPart.textContent = i18n('audio_room_no_active_participants', 'No active participants.');
        participantBox.appendChild(emptyPart);
      } else {
        participants.forEach(function (row) {
          var role = row.role || 'listener';
          var userId = String(row.user_id || '');
          var ownerId = String(stage.dataset.ownerId || '');
          var viewerId = String(stage.dataset.viewerId || '');
          var chatMute = parseInt(row.chat_mute_remaining || '0', 10) || 0;
          var actions = [];
          if (role === 'listener' && userId !== ownerId) {
            actions.push({ label: i18n('audio_room_make_moderator', 'Moderator'), action: 'make-moderator' });
          }
          if (role === 'speaker') {
            actions.push({ label: i18n('audio_room_remove_mic', 'Remove mic'), action: 'mute-speaker' });
          }
          if (userId && userId !== ownerId && userId !== viewerId) {
            if (chatMute > 0) {
              actions.push({ label: i18n('audio_room_unmute_chat', 'Unmute chat'), action: 'chat-unmute' });
            } else {
              [1, 2, 3, 4, 5].forEach(function (minute) {
                actions.push({ label: i18n('audio_room_minute_mute', '{minutes}m mute', { minutes: minute }), action: 'chat-mute', minutes: minute });
              });
            }
            actions.push({ label: i18n('audio_room_kick', 'Kick'), action: 'kick-user', danger: true });
            actions.push({ label: i18n('audio_room_ban', 'Ban'), action: 'ban-user', danger: true });
          }
          participantBox.appendChild(manageItem(row, {
            meta: i18n('audio_room_role_' + role, role) + (chatMute > 0 ? i18n('audio_room_meta_chat_muted', ' / chat muted {time}', { time: formatDuration(chatMute) }) : (row.mic_muted === '0' || row.mic_muted === 0 ? i18n('audio_room_meta_mic_on', ' / mic on') : i18n('audio_room_meta_muted', ' / muted'))),
            menuActions: actions
          }));
        });
      }
    }
    positionOpenManageMenu();
  }
  function fetchManagePanel() {
    var panel = qs('[data-audio-room-manage]');
    if (!panel || !roomId) { return; }
    request('POST', { p: 'audio_room_manage_panel', room_id: String(roomId), csrf_token: csrf() })
      .then(function (res) {
        if (res && res.status === 'success') { renderManagePanel(res); }
      })
      .catch(function () {});
  }
  function startManagePanel() {
    if (!qs('[data-audio-room-manage]')) { return; }
    refreshRoomState();
    if (manageTimer) { window.clearInterval(manageTimer); }
    manageTimer = window.setInterval(refreshRoomState, 3000);
  }
  function startPassiveRoomLoops() {
    if (stage.dataset.chatEnabled === '1') {
      fetchMessages();
      if (!chatTimer) { chatTimer = window.setInterval(fetchMessages, 4000); }
    }
    startManagePanel();
  }
  function handleManageMenuToggle(toggle, event) {
    var menu = toggle.closest('.audio-room-manage-item__menu');
    if (!menu) { return false; }
    var item = toggle.closest('.audio-room-manage-item');
    var userId = item ? String(item.dataset.userId || '') : '';
    var willOpen = !menu.classList.contains('is-open');
    closeManageMenus();
    menu.classList.toggle('is-open', willOpen);
    toggle.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
    openManageMenuUserId = willOpen ? userId : '';
    if (willOpen) { openManageActionSheet(menu); }
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    return true;
  }
  function runManageAction(button) {
    var action = button.dataset.action || '';
    var targetId = button.dataset.userId || '';
    if (!targetId) { return; }
    closeManageMenus();
    var sheet = qs('[data-audio-room-action-sheet]');
    if (sheet) { sheet.classList.add('none'); }
    activeManageActionButton = button;
    button.disabled = true;
    var payload = { room_id: String(roomId), user_id: targetId, csrf_token: csrf() };
    if (action === 'approve-speaker' || action === 'reject-speaker') {
      payload.p = 'audio_room_speaker_review';
      payload.decision = action === 'approve-speaker' ? 'approved' : 'rejected';
    } else if (action === 'make-moderator') {
      payload.p = 'audio_room_moderator_assign';
    } else if (action === 'mute-speaker' || action === 'unmute-speaker') {
      payload.p = 'audio_room_speaker_mute';
      payload.muted = action === 'mute-speaker' ? '1' : '0';
    } else if (action === 'chat-mute' || action === 'chat-unmute' || action === 'kick-user' || action === 'ban-user') {
      payload.p = 'audio_room_participant_action';
      payload.action = action === 'chat-mute' ? 'chat_mute' : (action === 'chat-unmute' ? 'chat_unmute' : (action === 'kick-user' ? 'kick' : 'ban'));
      if (button.dataset.minutes) { payload.minutes = button.dataset.minutes; }
    } else {
      button.disabled = false;
      activeManageActionButton = null;
      return;
    }
    request('POST', payload)
      .then(function (res) {
        if (res && res.status === 'success') {
          fetchManagePanel();
          refreshRoomState();
          activeManageActionButton = null;
        } else {
          setLine((res && res.message) ? serverMessage(res.message, res.message) : i18n('audio_room_management_action_failed', 'Management action failed.'), 'error');
          button.disabled = false;
          activeManageActionButton = null;
        }
      })
      .catch(function () {
        setLine(i18n('audio_room_management_action_request_failed', 'Management action request failed.'), 'error');
        button.disabled = false;
        activeManageActionButton = null;
      });
  }
  function fetchMessages() {
    var box = qs('[data-audio-room-messages]');
    if (!box || !roomId) { return; }
    var lastId = parseInt(box.dataset.lastId || '0', 10);
    getJson('request/requests.php?p=audio_room_chat_fetch&room_id=' + encodeURIComponent(String(roomId)) + '&since_id=' + encodeURIComponent(String(lastId)))
      .then(function (res) {
        if (!res || res.status !== 'success' || !Array.isArray(res.messages) || !res.messages.length) { return; }
        qsa('.audio-room-chat__empty', box).forEach(function (empty) { empty.remove(); });
        res.messages.forEach(function (message) {
          box.appendChild(messageHtml(message));
        });
        box.dataset.lastId = String(res.last_id || lastId);
        box.scrollTop = box.scrollHeight;
        if (!isChatOpen()) { setChatUnread(true); }
      })
      .catch(function () {});
  }

  var joinBtn = qs('[data-audio-room-join]', stage);
  function joinRoom() {
    if (joined) { return; }
    if (joinBtn) { joinBtn.disabled = true; }
    setLine(i18n('audio_room_joining', 'Joining room...'), 'info');
    request('POST', { p: 'audio_room_join', room_id: String(roomId), csrf_token: csrf() })
      .then(async function (res) {
        if (!res || res.status !== 'success' || !res.data) {
          setLine((res && res.message) ? serverMessage(res.message, res.message) : i18n('audio_room_join_failed', 'Could not join room.'), 'error');
          if (joinBtn) { joinBtn.disabled = false; }
          return;
        }
        if (res.data.auto_end_at) {
          autoEndAt = parseInt(res.data.auto_end_at, 10) || autoEndAt;
          serverTime = parseInt(res.data.server_time || '0', 10) || serverTime;
          clientStart = Math.floor(Date.now() / 1000);
          startCountdown();
        }
        setRole(res.data.role || 'listener', res.data.speaker_status || '');
        markJoined(true);
        startTimers();
        refreshRoomState();
        var connected = await connectAgora(res.data);
        if (!connected) {
          stopTimers();
          startPassiveRoomLoops();
          request('POST', { p: 'audio_room_leave', room_id: String(roomId), csrf_token: csrf() }).catch(function () {});
          markJoined(false);
          if (joinBtn) { joinBtn.disabled = false; }
        } else {
          refreshRoomState();
        }
      })
      .catch(function () {
        setLine(i18n('audio_room_join_request_failed', 'Join request failed.'), 'error');
        if (joinBtn) { joinBtn.disabled = false; }
      });
  }
  if (joinBtn) {
    joinBtn.addEventListener('click', joinRoom);
  }

  var leaveBtn = qs('[data-audio-room-leave]', stage);
  if (leaveBtn) {
    leaveBtn.addEventListener('click', async function () {
      stopTimers();
      await disconnectAgora();
      request('POST', { p: 'audio_room_leave', room_id: String(roomId), csrf_token: csrf() }).catch(function () {});
      markJoined(false);
      setLine(i18n('audio_room_left_room', 'You left the room.'), 'info');
      if (joinBtn) { joinBtn.disabled = false; }
    });
  }

  var speakerRequest = qs('[data-audio-room-speaker-request]', stage);
  if (speakerRequest) {
    speakerRequest.addEventListener('click', function () {
      if (speakerRequest.disabled) { return; }
      speakerRequest.disabled = true;
      request('POST', { p: 'audio_room_speaker_request', room_id: String(roomId), csrf_token: csrf() })
        .then(function (res) {
          if (res && res.status === 'error' && res.message === 'chat_muted') {
            updateChatMuteState(res.remaining || chatMuteRemaining);
            setLine(i18n('audio_room_request_mic_after_mute', 'You can request the mic after the mute timer ends.'), 'error');
            return;
          }
          setLine(res && res.status === 'success' ? i18n('audio_room_speaker_request_sent', 'Speaker request sent.') : i18n('audio_room_speaker_request_failed', 'Could not send speaker request.'), res && res.status === 'success' ? 'success' : 'error');
          refreshRoomState();
        })
        .catch(function () { setLine(i18n('audio_room_speaker_request_error', 'Speaker request failed.'), 'error'); });
    });
  }

  var micButton = qs('[data-audio-room-mic]', stage);
  if (micButton) {
    micButton.addEventListener('click', function () {
      if (micButton.disabled || !canPublish(currentRole) || moderatorMuted) { return; }
      if (!localTrack && joined) {
        refreshAgoraRole();
        return;
      }
      setMicMuted(!micMuted, true);
    });
  }

  var endBtn = qs('[data-audio-room-end]', stage);
  if (endBtn) {
    endBtn.addEventListener('click', function () {
      endBtn.disabled = true;
      request('POST', { p: 'end_audio_room', room_id: String(roomId), csrf_token: csrf() })
        .then(function (res) {
          if (res && res.status === 'success') {
            handleForcedExit('ended');
          } else {
            endBtn.disabled = false;
            setLine((res && res.message) ? serverMessage(res.message, res.message) : i18n('audio_room_end_failed', 'Could not end room.'), 'error');
          }
        })
        .catch(function () {
          endBtn.disabled = false;
          setLine(i18n('audio_room_end_request_failed', 'End request failed.'), 'error');
        });
    });
  }

  var chatForm = qs('[data-audio-room-chat-form]');
  if (chatForm) {
    chatForm.addEventListener('submit', function (event) {
      event.preventDefault();
      var input = qs('[data-audio-room-chat-input]', chatForm);
      var message = input ? input.value.trim() : '';
      if (!message) { return; }
      if (chatMuteRemaining > 0) {
        setLine(i18n('audio_room_chat_muted_for_sentence', 'Chat is muted for {time}.', { time: formatDuration(chatMuteRemaining) }), 'error');
        return;
      }
      request('POST', { p: 'audio_room_chat_send', room_id: String(roomId), csrf_token: csrf(), message: message })
        .then(function (res) {
          if (res && res.status === 'success') {
            if (input) { input.value = ''; }
            fetchMessages();
          } else {
            if (res && res.message === 'chat_muted') {
              updateChatMuteState(res.remaining || chatMuteRemaining);
              setLine(i18n('audio_room_chat_muted_for_sentence', 'Chat is muted for {time}.', { time: formatDuration(chatMuteRemaining) }), 'error');
              return;
            }
            setLine((res && res.message) ? serverMessage(res.message, res.message) : i18n('audio_room_message_send_failed', 'Message could not be sent.'), 'error');
          }
        })
        .catch(function () { setLine(i18n('audio_room_message_request_failed', 'Message request failed.'), 'error'); });
    });
  }

  var ticketForm = qs('[data-audio-room-ticket-form]');
  if (ticketForm) {
    ticketForm.addEventListener('submit', function (event) {
      event.preventDefault();
      var provider = (qs('[data-audio-room-ticket-provider]', ticketForm) || {}).value || 'wallet';
      var submit = qs('button[type="submit"]', ticketForm);
      if (submit) { submit.disabled = true; }
      setLine(i18n('audio_room_ticket_payment_starting', 'Starting ticket payment...'), 'info');
      request('POST', {
        p: 'audio_room_ticket_create_payment',
        room_id: String(roomId),
        provider: provider,
        csrf_token: csrf()
      })
        .then(function (res) {
          if (res && res.status === 'success') {
            if (res.checkout_url) {
              window.location.href = res.checkout_url;
              return;
            }
            window.location.href = res.redirect_url || window.location.href;
            return;
          }
          setLine((res && res.message) ? serverMessage(res.message, res.message) : i18n('audio_room_ticket_payment_failed', 'Ticket payment could not be started.'), 'error');
          if (submit) { submit.disabled = false; }
        })
        .catch(function () {
          setLine(i18n('audio_room_ticket_payment_request_failed', 'Ticket payment request failed.'), 'error');
          if (submit) { submit.disabled = false; }
        });
    });
  }

  var tipButton = qs('[data-audio-room-tip]', stage);
  var tipSheet = qs('[data-audio-room-tip-sheet]');
  if (tipButton && tipSheet) {
    var setTipSheetOpen = function (open) {
      tipSheet.classList.toggle('none', !open);
      tipButton.classList.toggle('is-selected', open);
      tipButton.setAttribute('aria-expanded', open ? 'true' : 'false');
    };
    tipButton.setAttribute('aria-expanded', 'false');
    tipButton.addEventListener('click', function () {
      if (tipButton.disabled) { return; }
      setTipSheetOpen(tipSheet.classList.contains('none'));
    });
  }

  var tipForm = qs('[data-audio-room-tip-form]');
  if (tipForm) {
    tipForm.addEventListener('submit', function (event) {
      event.preventDefault();
      var amountInput = qs('[data-audio-room-tip-amount]', tipForm);
      var providerInput = qs('[data-audio-room-tip-provider]', tipForm);
      var amount = amountInput ? parseFloat(amountInput.value || '0') : 0;
      var provider = providerInput ? providerInput.value : 'wallet';
      var submit = qs('button[type="submit"]', tipForm);
      if (!amount || amount < 1 || amount > 500) {
        setLine(i18n('audio_room_tip_invalid_amount', 'Please enter a valid tip amount.'), 'error');
        return;
      }
      if (submit) { submit.disabled = true; }
      setLine(i18n('audio_room_tip_sending', 'Sending tip...'), 'info');
      request('POST', {
        p: 'audio_room_tip_create_payment',
        room_id: String(roomId),
        provider: provider,
        amount: String(amount),
        csrf_token: csrf()
      })
        .then(function (res) {
          if (res && res.status === 'success') {
            if (res.checkout_url) {
              window.location.href = res.checkout_url;
              return;
            }
            setLine(i18n('audio_room_tip_sent_thanks', 'Tip sent. Thank you.'), 'success');
            if (tipSheet) { tipSheet.classList.add('none'); }
            if (tipButton) {
              tipButton.classList.remove('is-selected');
              tipButton.setAttribute('aria-expanded', 'false');
            }
            fetchMessages();
            if (submit) { submit.disabled = false; }
            return;
          }
          setLine((res && res.message) ? serverMessage(res.message, res.message) : i18n('audio_room_tip_failed', 'Tip could not be sent.'), 'error');
          if (submit) { submit.disabled = false; }
        })
        .catch(function () {
          setLine(i18n('audio_room_tip_request_failed', 'Tip request failed.'), 'error');
          if (submit) { submit.disabled = false; }
        });
    });
  }

  var managePanel = qs('[data-audio-room-manage]');
  if (managePanel) {
    managePanel.addEventListener('click', function (event) {
      var toggle = event.target.closest('.audio-room-manage-item__menu-toggle');
      if (toggle) {
        handleManageMenuToggle(toggle, event);
        return;
      }
      var button = event.target.closest('button[data-action]');
      if (!button) { return; }
      runManageAction(button);
    });
  }
  document.addEventListener('click', function (event) {
    if (!managePanel || event.target.closest('.audio-room-manage-item__menu') || event.target.closest('[data-audio-room-action-sheet]')) { return; }
    closeManageMenus();
  });
  document.addEventListener('click', function (event) {
    var toggle = event.target.closest('.audio-room-manage-item__menu-toggle');
    if (!toggle) { return; }
    handleManageMenuToggle(toggle, event);
  }, true);
  if (chatToggle) {
    chatToggle.addEventListener('click', function () {
      if (isChatOpen()) { closeRoomChat(); } else { openRoomChat(); }
    });
  }
  if (chatClose) { chatClose.addEventListener('click', closeRoomChat); }
  if (chatBackdrop) { chatBackdrop.addEventListener('click', closeRoomChat); }
  window.addEventListener('resize', closeManageActionSheet);

  refreshStats();
  startCountdown();
  updateChatMuteState(0);
  startPassiveRoomLoops();
  updateMicButton();
  if (stage.dataset.autoJoin === '1') {
    window.setTimeout(joinRoom, 150);
  }
  window.addEventListener('beforeunload', function () {
    if (joined) {
      try {
        var fd = new FormData();
        fd.append('p', 'audio_room_leave');
        fd.append('room_id', String(roomId));
        fd.append('csrf_token', csrf());
        navigator.sendBeacon(url('request/requests.php'), fd);
      } catch (_) {}
    }
  });
})();
