'use strict';
(function(){
  if (window.DZ && typeof window.DZ.i18n === 'function') return;
  function metaI18n(key, params){
    try {
      var el = document.querySelector('meta[name="i18n.' + key + '"]');
      var s = el ? (el.getAttribute('content') || '') : '';
      if (s && params && typeof params === 'object') {
        for (var k in params) {
          if (Object.prototype.hasOwnProperty.call(params, k)) {
            s = s.replace(new RegExp('\\{' + k + '\\}', 'g'), String(params[k]));
          }
        }
      }
      return s;
    } catch(_) { return ''; }
  }
  window.DZ = window.DZ || {};
  window.DZ.i18n = metaI18n;
  // Global alias for legacy callers: I18N('key', {param:'x'})
  if (typeof window.I18N !== 'function') {
    window.I18N = function(key, params){
      try { return window.DZ && typeof window.DZ.i18n === 'function' ? window.DZ.i18n(key, params) : ''; }
      catch(_) { return ''; }
    };
  }
})();
