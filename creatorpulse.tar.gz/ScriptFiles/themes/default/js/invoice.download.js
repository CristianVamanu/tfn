(function () {
  'use strict';

  /**
   * Waits until an image finishes loading (or errors) before continuing.
   *
   * @param {HTMLImageElement} img The image element to monitor.
   * @returns {Promise<void>}
   */
  function waitForImageSettled(img) {
    if (!img || img.complete) {
      return Promise.resolve();
    }

    return new Promise(function (resolve) {
      var onDone = function () {
        img.removeEventListener('load', onDone);
        img.removeEventListener('error', onDone);
        resolve();
      };

      img.addEventListener('load', onDone);
      img.addEventListener('error', onDone);
    });
  }

  /**
   * Temporarily hides an image so unsupported formats do not break pdf export.
   *
   * @param {HTMLImageElement} img The image element to hide.
   * @returns {Function} Cleanup function restoring visibility.
   */
  function hideImageForExport(img) {
    var previousVisibility = img.style.visibility;
    img.style.visibility = 'hidden';
    return function restoreVisibility() {
      img.style.visibility = previousVisibility;
    };
  }

  function getBrandLogoContainer(img) {
    if (!img) {
      return null;
    }
    if (typeof img.closest === 'function') {
      return img.closest('.brand-logo');
    }
    var node = img.parentElement;
    while (node) {
      if (node.classList && node.classList.contains('brand-logo')) {
        return node;
      }
      node = node.parentElement;
    }
    return null;
  }

  function isBrandLogoImage(img) {
    return !!(img && img.dataset && img.dataset.invoiceBrandLogo === '1');
  }

  function fallbackBrandLogo(img) {
    var container = getBrandLogoContainer(img);
    if (!container) {
      return hideImageForExport(img);
    }

    var alreadyVisible = container.classList.contains('brand-logo--fallback-visible');
    container.classList.add('brand-logo--fallback-visible');

    var previousDisplay = img.style.display;
    img.style.display = 'none';

    return function restoreBrandLogo() {
      img.style.display = previousDisplay;
      if (!alreadyVisible) {
        container.classList.remove('brand-logo--fallback-visible');
      }
    };
  }

  function convertBrandLogoImage(img, source, originalSrcset) {
    if (!isBrandLogoImage(img)) {
      return null;
    }

    if (img.dataset.invoiceConvertedForPdf === '1') {
      return null;
    }

    if (!source || source.indexOf('data:') === 0) {
      return null;
    }

    if (typeof window.fetch !== 'function' || typeof window.FileReader !== 'function') {
      return null;
    }

    return window.fetch(source, { credentials: 'include' })
      .then(function (response) {
        if (!response.ok) {
          throw new Error('Network response not ok: ' + response.status);
        }
        return response.blob();
      })
      .then(function (blob) {
        return new Promise(function (resolve, reject) {
          var reader = new FileReader();
          reader.onload = function () {
            try {
              var dataUrl = reader.result;
              var originalSrc = source;
              img.dataset.invoiceOriginalSrc = originalSrc;
              img.dataset.invoiceConvertedForPdf = '1';
              if (originalSrcset !== '') {
                img.dataset.invoiceOriginalSrcset = originalSrcset;
                img.removeAttribute('srcset');
              }
              img.src = dataUrl;

              resolve(function restoreImage() {
                if (img.dataset && img.dataset.invoiceOriginalSrc === originalSrc) {
                  img.src = originalSrc;
                  delete img.dataset.invoiceOriginalSrc;
                  delete img.dataset.invoiceConvertedForPdf;
                  if (img.dataset.invoiceOriginalSrcset) {
                    img.setAttribute('srcset', img.dataset.invoiceOriginalSrcset);
                    delete img.dataset.invoiceOriginalSrcset;
                  }
                }
              });
            } catch (conversionError) {
              reject(conversionError);
            }
          };
          reader.onerror = function () {
            reject(reader.error || new Error('Failed to read brand logo blob'));
          };
          reader.readAsDataURL(blob);
        });
      })
      .catch(function (error) {
        console.warn('Invoice PDF: brand logo conversion failed, using fallback', source, error);
        return fallbackBrandLogo(img);
      });
  }

  /**
   * Converts unsupported image formats (e.g. WebP) to PNG data URLs for export.
   *
   * @param {HTMLImageElement} img The image element to prepare.
   * @returns {Function|null} Cleanup function or null when no conversion happens.
   */
  function convertImageForExport(img) {
    if (!img) {
      return null;
    }

    var source = img.currentSrc || img.src || '';
    if (source === '') {
      return null;
    }

    if (!img.getAttribute('crossorigin')) {
      img.setAttribute('crossorigin', 'anonymous');
    }
    if (!img.getAttribute('referrerpolicy')) {
      img.setAttribute('referrerpolicy', 'same-origin');
    }

    if (img.dataset.invoiceConvertedForPdf === '1') {
      return null;
    }

    var originalSrcset = img.getAttribute('srcset') || '';
    var brandLogoTask = convertBrandLogoImage(img, source, originalSrcset);
    if (brandLogoTask) {
      return brandLogoTask;
    }

    var width = img.naturalWidth || img.width;
    var height = img.naturalHeight || img.height;
    if (!width || !height) {
      return hideImageForExport(img);
    }

    var canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;

    var context = canvas.getContext('2d');
    if (!context) {
      return hideImageForExport(img);
    }

    try {
      context.drawImage(img, 0, 0, width, height);
      var dataUrl = canvas.toDataURL('image/png');
      var originalSrc = source;
      img.dataset.invoiceOriginalSrc = originalSrc;
      img.dataset.invoiceConvertedForPdf = '1';
      if (originalSrcset !== '') {
        img.dataset.invoiceOriginalSrcset = originalSrcset;
        img.removeAttribute('srcset');
      }
      img.src = dataUrl;

      return function restoreImage() {
        if (img.dataset && img.dataset.invoiceOriginalSrc === originalSrc) {
          img.src = originalSrc;
          delete img.dataset.invoiceOriginalSrc;
          delete img.dataset.invoiceConvertedForPdf;
          if (img.dataset.invoiceOriginalSrcset) {
            img.setAttribute('srcset', img.dataset.invoiceOriginalSrcset);
            delete img.dataset.invoiceOriginalSrcset;
          }
        }
      };
    } catch (error) {
      console.warn('Invoice PDF: failed to convert image, hiding instead', source, error);
      return hideImageForExport(img);
    }
  }

  /**
   * Ensures invoice images are compatible with the PDF pipeline by waiting for load and
   * converting unsupported formats.
   *
   * @param {HTMLElement} container The invoice document container.
   * @returns {Promise<Function>} Resolves with a cleanup function.
   */
  function prepareImagesForExport(container) {
    if (!container) {
      return Promise.resolve(function () {});
    }

    var images = container.querySelectorAll('img');
    if (!images.length) {
      return Promise.resolve(function () {});
    }

    var tasks = [];
    for (var index = 0; index < images.length; index += 1) {
      (function (img) {
        tasks.push(
          waitForImageSettled(img).then(function () {
            return convertImageForExport(img);
          })
        );
      })(images[index]);
    }

    return Promise.all(tasks).then(function (results) {
      var cleanups = [];
      for (var i = 0; i < results.length; i += 1) {
        if (typeof results[i] === 'function') {
          cleanups.push(results[i]);
        }
      }

      return function cleanupImages() {
        for (var j = 0; j < cleanups.length; j += 1) {
          cleanups[j]();
        }
      };
    });
  }

  /**
   * Attaches the PDF download handler using html2canvas + jsPDF.
   *
   * @param {HTMLElement} invoiceElement The invoice container element.
   * @param {HTMLButtonElement} trigger The button that initiates the PDF export.
   * @returns {void}
   */
  function bindPdfDownload(invoiceElement, trigger) {
    if (!invoiceElement || !trigger) {
      return;
    }

    var pdfOptions = {
      margin: 10,
      filename: 'invoice.pdf',
      image: { type: 'jpeg', quality: 0.92 },
      html2canvas: {
        scale: 2,
        useCORS: true,
        scrollX: 0,
        scrollY: 0,
        windowWidth: document.documentElement.scrollWidth,
        windowHeight: document.documentElement.scrollHeight,
        imageTimeout: 0,
        backgroundColor: '#ffffff'
      },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
      pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
    };

    /**
     * Resolves the jsPDF constructor from known globals.
     *
     * @returns {Function|null}
     */
    function resolveJsPDF() {
      if (window.jspdf && typeof window.jspdf.jsPDF === 'function') {
        return window.jspdf.jsPDF;
      }
      if (typeof window.jsPDF === 'function') {
        return window.jsPDF;
      }
      if (window.jsPDF && typeof window.jsPDF.jsPDF === 'function') {
        return window.jsPDF.jsPDF;
      }
      return null;
    }

    trigger.addEventListener('click', function handlePdfClick(event) {
      event.preventDefault();
      trigger.disabled = true;
      trigger.classList.add('is-loading');

      var releaseButton = function () {
        trigger.disabled = false;
        trigger.classList.remove('is-loading');
      };

      prepareImagesForExport(invoiceElement)
        .then(function (cleanup) {
          if (typeof window.html2canvas === 'undefined') {
            throw new Error('html2canvas is not available on window.');
          }

          return window.html2canvas(invoiceElement, pdfOptions.html2canvas)
            .then(function (canvas) {
              var JsPDFCtor = resolveJsPDF();
              if (!JsPDFCtor) {
                throw new Error('jsPDF constructor not found on window.');
              }

              var pdf = new JsPDFCtor(pdfOptions.jsPDF);
              var pageWidth = pdf.internal.pageSize.getWidth();
              var pageHeight = pdf.internal.pageSize.getHeight();
              var marginValue = Array.isArray(pdfOptions.margin)
                ? Number(pdfOptions.margin[0]) || 0
                : Number(pdfOptions.margin) || 0;
              var printableWidth = pageWidth - marginValue * 2;
              var printableHeight = pageHeight - marginValue * 2;

              var canvasWidth = canvas.width;
              var canvasHeight = canvas.height;
              var renderedHeight = (canvasHeight * printableWidth) / canvasWidth;

              var jpegQuality = pdfOptions.image && typeof pdfOptions.image.quality === 'number'
                ? pdfOptions.image.quality
                : 0.92;
              var imageDataJpg = canvas.toDataURL('image/jpeg', jpegQuality);
              var imageDataPng = canvas.toDataURL('image/png');

              var addImageSafe = function (pdfDoc, data, format, x, y, w, h) {
                try {
                  pdfDoc.addImage(data, format, x, y, w, h);
                  return { data: data, format: format };
                } catch (err) {
                  var message = String(err).toLowerCase();
                  if (message.indexOf('unsupported image type') !== -1 && format === 'JPEG') {
                    pdfDoc.addImage(imageDataPng, 'PNG', x, y, w, h);
                    return { data: imageDataPng, format: 'PNG' };
                  }
                  throw err;
                }
              };

              var positionY = marginValue;
              var firstPage = addImageSafe(pdf, imageDataJpg, 'JPEG', marginValue, positionY, printableWidth, renderedHeight);
              var imageData = firstPage.data;
              var imageFormat = firstPage.format;

              var heightLeft = renderedHeight - printableHeight;
              while (heightLeft > 0) {
                pdf.addPage();
                positionY = marginValue - (renderedHeight - heightLeft);
                pdf.addImage(imageData, imageFormat, marginValue, positionY, printableWidth, renderedHeight);
                heightLeft -= printableHeight;
              }

              pdf.save(pdfOptions.filename);
            })
            .then(function () {
              if (typeof cleanup === 'function') {
                cleanup();
              }
            })
            .catch(function (error) {
              if (typeof cleanup === 'function') {
                cleanup();
              }
              throw error;
            });
        })
        .then(function () {
          releaseButton();
        })
        .catch(function (error) {
          console.error('Invoice PDF export failed:', error);
          releaseButton();
        });
    });
  }

  /**
   * Attaches the PNG download handler using the html2canvas library.
   *
   * @param {HTMLElement} invoiceElement The invoice container element.
   * @param {HTMLButtonElement} trigger The button that initiates the PNG export.
   * @returns {void}
   */
  function bindPngDownload(invoiceElement, trigger) {
    if (!invoiceElement || !trigger || typeof window.html2canvas === 'undefined') {
      return;
    }

    trigger.addEventListener('click', function handlePngClick(event) {
      event.preventDefault();
      trigger.disabled = true;
      trigger.classList.add('is-loading');

      window.html2canvas(invoiceElement, {
        scale: 2,
        useCORS: true,
        scrollX: 0,
        scrollY: 0,
        windowWidth: document.documentElement.scrollWidth,
        windowHeight: document.documentElement.scrollHeight
      })
        .then(function onCanvasReady(canvas) {
          var link = document.createElement('a');
          link.href = canvas.toDataURL('image/png');
          link.download = 'invoice.png';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        })
        .finally(function () {
          trigger.disabled = false;
          trigger.classList.remove('is-loading');
        });
    });
  }

  /**
   * Sets up invoice export actions for the current page.
   *
   * @returns {void}
   */
  function initInvoiceDownloads() {
    var invoiceElement = document.querySelector('[data-invoice-document]');
    if (!invoiceElement) {
      return;
    }

    bindPdfDownload(invoiceElement, document.querySelector('.js-invoice-download-pdf'));
    bindPngDownload(invoiceElement, document.querySelector('.js-invoice-download-png'));
  }

  document.addEventListener('DOMContentLoaded', initInvoiceDownloads);
})();
