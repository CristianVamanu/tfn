(function(){
  'use strict';

  function buildUrl(path){
    try {
      if (typeof window.buildUrl === 'function') {
        return window.buildUrl(path);
      }
    } catch(_){}
    try {
      var base='';
      if (typeof window.site_url === 'string' && window.site_url) {
        base = window.site_url;
      } else if (window.DZ && typeof window.DZ.__computeBase === 'function') {
        base = window.DZ.__computeBase('');
      } else {
        var origin = window.location.origin || ((window.location.protocol || 'http:') + '//' + (window.location.host || ''));
        var root = (window.location.pathname || '/').replace(/[^\/]*$/, '');
        base = origin + (root || '/');
      }
      return new URL(String(path||''), base).toString();
    } catch(_) { return String(path||''); }
  }

  function setAlert(el, type, msg){
    if(!el) return;
    el.classList.add('tips-alert','pp-alert','is-shown');
    el.classList.remove('is-error','is-success','is-info');
    if (type === 'success') el.classList.add('is-success');
    else if (type === 'info') el.classList.add('is-info');
    else el.classList.add('is-error');
    el.textContent = msg || '';
  }

  function clearAlert(el){ if(!el) return; el.classList.remove('is-shown','is-error','is-success','is-info'); el.textContent=''; }

  function onReady(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

  onReady(function(){
    var form = document.getElementById('settings-profile-form');
    var hasForm = !!form;
    var submitting = false;
    var alertBox = hasForm ? form.querySelector('.pp-alert') : null;
    var submitBtn = hasForm ? form.querySelector('.pp-save') : null;

    if (hasForm) form.addEventListener('submit', function(e){
      e.preventDefault();
      if(submitting) return;
      submitting = true;
      clearAlert(alertBox);
      if(submitBtn){ submitBtn.disabled=true; submitBtn.dataset._oldText = submitBtn.textContent; submitBtn.textContent = tr('saving', 'Saving...'); }

      var fd = new FormData(form);
      // Ensure action is set correctly
      if(!fd.has('p')) fd.set('p','update_profile');

      // Inject cropped blobs if present
      try {
        if (window.__PROFILE_CROP) {
          if (window.__PROFILE_CROP.avatarBlob) {
            try { fd.delete('avatar'); } catch(_){}
            fd.append('avatar', window.__PROFILE_CROP.avatarBlob, 'avatar.png');
          }
          if (window.__PROFILE_CROP.coverBlob) {
            try { fd.delete('cover'); } catch(_){}
            fd.append('cover', window.__PROFILE_CROP.coverBlob, 'cover.png');
          }
        }
      } catch(_){}

      fetch(buildUrl('request/requests.php'), {
        method: 'POST',
        body: fd,
        credentials: 'same-origin'
      }).then(function(r){ return r.json().catch(function(){ return {status:'error', message:'INVALID_RESPONSE'}; }); })
        .then(function(res){
          if(res && res.status==='success'){
            var successMsg = (res && res.message) ? res.message : tr('profile_saved', 'Profile updated.');
            setAlert(alertBox, 'success', successMsg);
            try {
              if(res.data){
                if(res.data.avatar_url){
                  var img = form.querySelector('img');
                  if(img){ img.src = res.data.avatar_url + (res.data.avatar_url.indexOf('?')>-1?'&':'?') + 't=' + Date.now(); }
                  var hdr = document.querySelector('.user_dropdown .avatar');
                  if(hdr){ hdr.src = res.data.avatar_url + (res.data.avatar_url.indexOf('?')>-1?'&':'?') + 't=' + Date.now(); }
                }
                if(res.data.cover_url){
                  var cover = form.querySelector('div[style*="border-radius:8px"] img');
                  if(cover){ cover.src = res.data.cover_url + (res.data.cover_url.indexOf('?')>-1?'&':'?') + 't=' + Date.now(); }
                }
                if(res.data.user_fullname){
                  var h = form.querySelector('div[style*="font-weight:600;"]');
                  if(h){ h.textContent = res.data.user_fullname; }
                  var hdrName = document.querySelector('.user_dropdown .username');
                  if(hdrName){ hdrName.textContent = res.data.user_fullname; }
                }
              }
            } catch(_){}
          } else {
            var msg = (res && (res.message || res.error)) || tr('save_failed', 'Save failed.');
            setAlert(alertBox, 'error', msg);
          }
        })
        .catch(function(){ setAlert(alertBox, 'error', tr('network_error', 'Network error.')); })
        .finally(function(){ submitting=false; if(submitBtn){ submitBtn.disabled=false; submitBtn.textContent = submitBtn.dataset._oldText || 'Save'; } });
    });

    // ---------------------------------------------
    // Profile: Avatar/Cover cropper (zoom + move)
    // ---------------------------------------------
    var AVATAR_SIZE = 300; // 300x300 px
    var COVER_W = 1280, COVER_H = 720; // 16:9 like YouTube cover
    window.__PROFILE_CROP = window.__PROFILE_CROP || { avatarBlob:null, coverBlob:null };

    function $(sel, root){ return (root||document).querySelector(sel); }
    function tr(key, fallback){
      try {
        var fn = (window.DZ && typeof DZ.i18n === 'function') ? DZ.i18n : null;
        var v = fn ? String(fn(key) || '') : '';
        v = (v || '').trim();
        return v !== '' ? v : String(fallback || '');
      } catch(_) { return String(fallback || ''); }
    }
    function toBlob(canvas, cb){
      if (canvas.toBlob) { canvas.toBlob(function(b){ cb(b||null); }, 'image/png'); return; }
      try {
        var dataURL = canvas.toDataURL('image/png');
        var parts = dataURL.split(',');
        var bin = atob(parts[1]); var len = bin.length; var ab = new ArrayBuffer(len); var u8 = new Uint8Array(ab);
        for (var i=0;i<len;i++) u8[i] = bin.charCodeAt(i);
        cb(new Blob([ab], {type:'image/png'}));
      } catch(_) { cb(null); }
    }

    function openCropper(file, type){
      if (!file) return;
      var fr = new FileReader();
      fr.onload = function(){
        var src = fr.result;
        var overlay = document.createElement('div');
        overlay.className = 'popUp-container pcrop-overlay flex align_items_justify_content';
        overlay.innerHTML = ''+
          '<div class="close_pop flex align_items pcrop-close" aria-label="Close">×</div>'+
          '<div class="popup-wrapper flex flexBoxColumn align_items">'+
            '<div class="click_box_header flex align_items_justify_content">'+
              '<button type="button" class="goBack pcrop-cancel">'+ tr('cancel','Cancel') +'</button>'+ 
              '<div class="full-width flex align_items_justify_content pcrop-title">'+ (type==='avatar'? tr('edit_avatar','Edit Avatar') : tr('edit_cover','Edit Cover')) +'</div>'+ 
              '<button type="button" class="goNext pcrop-save">'+ tr('save','Save') +'</button>'+ 
            '</div>'+
            '<div class="arrow"></div>'+
            '<div class="crop-container d-flex">'+
              '<div class="crop-frame pcrop-frame '+ (type==='cover'?'pcrop-frame--wide':'pcrop-frame--square') +'">'+
                '<div class="grid-overlay"></div>'+
                (type==='cover' ? '<div class="pcrop-safe" aria-hidden="true"></div><div class="pcrop-viewport"><div class="crop-image"><img alt="crop" draggable="false" /></div></div>' : '<div class="crop-image"><img alt="crop" draggable="false" /></div>')+
                '<div class="crop-controls">'+
                  '<input type="range" class="pcrop-zoom" min="1" max="3" step="0.01" value="1" />'+
                '</div>'+
              '</div>'+
            '</div>'+
            '<div class="pe-actions pcrop-actions">'+
              '<button type="button" class="pe-cancel pcrop-cancel">'+ tr('cancel','Cancel') +'</button>'+ 
              '<button type="button" class="pe-save pcrop-save">'+ tr('save','Save') +'</button>'+ 
            '</div>'+
          '</div>';

        document.body.appendChild(overlay);
        var frame = overlay.querySelector('.pcrop-frame');
        var pane  = (type === 'cover') ? overlay.querySelector('.pcrop-viewport') : frame;
        var img = overlay.querySelector('.crop-image img');
        var zoom = overlay.querySelector('.pcrop-zoom');
        img.src = src;

        var state = { baseScale:1, zoom:1, left:0, top:0, naturalW:0, naturalH:0 };

        // Helper: size viewport to 16:9 (COVER_W x COVER_H) and safe-area overlay to YouTube safe ratio
        function sizeSafeBox(){
          if (type !== 'cover') return;
          var safe = overlay.querySelector('.pcrop-safe');
          var fw = frame.clientWidth, fh = frame.clientHeight;
          // Viewport: 16:9
          var vr = COVER_H / COVER_W; // 720/1280
          var vw = Math.round(fw);
          var vh = Math.round(vw * vr);
          var vl = 0;
          var vt = Math.round((fh - vh) / 2);
          if (vh > fh) { vh = fh; vw = Math.round(vh / vr); vl = Math.round((fw - vw) / 2); vt = 0; }
          if (pane && pane !== frame) {
            pane.style.width = vw + 'px';
            pane.style.height = vh + 'px';
            pane.style.left = vl + 'px';
            pane.style.top = vt + 'px';
          }
          // Safe area overlay: YouTube safe area ratio (h/w)
          var sr = 423 / 1546; // ~0.2735
          var sw = vw, sh = Math.round(sw * sr);
          var sl = vl, st = vt + Math.round((vh - sh) / 2);
          if (sh > vh) { sh = vh; sw = Math.round(sh / sr); sl = vl + Math.round((vw - sw) / 2); st = vt; }
          if (safe) {
            safe.style.width = sw + 'px';
            safe.style.height = sh + 'px';
            safe.style.left = sl + 'px';
            safe.style.top = st + 'px';
          }
        }

        sizeSafeBox();

        img.addEventListener('load', function(){
          // Fit to target area: avatar -> frame, cover -> viewport
          var fw = (pane && pane !== frame) ? pane.clientWidth : frame.clientWidth;
          var fh = (pane && pane !== frame) ? pane.clientHeight: frame.clientHeight;
          var iw = img.naturalWidth, ih = img.naturalHeight;
          state.naturalW = iw; state.naturalH = ih;
          var scale = Math.max(fw/iw, fh/ih);
          state.baseScale = scale; state.zoom = 1;
          var dw = iw * scale, dh = ih * scale;
          var left = Math.round((fw - dw)/2), top = Math.round((fh - dh)/2);
          state.left = left; state.top = top;
          img.style.width = dw+'px'; img.style.height = dh+'px'; img.style.left = left+'px'; img.style.top = top+'px';
        }, { once:true });

        // Dragging
        (function(){
          var dragging = false, sx=0, sy=0, sl=0, st=0;
          function onMove(ev){ if(!dragging) return; ev.preventDefault(); var p = ev.touches? ev.touches[0]: ev; var dx=p.pageX-sx, dy=p.pageY-sy; state.left = sl+dx; state.top = st+dy; applyPos(); enforceBounds(); }
          function onUp(){ dragging=false; document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onUp); document.removeEventListener('touchmove', onMove, {passive:false}); document.removeEventListener('touchend', onUp); }
          img.addEventListener('mousedown', function(ev){ ev.preventDefault(); dragging=true; sx=ev.pageX; sy=ev.pageY; sl=state.left; st=state.top; document.addEventListener('mousemove', onMove); document.addEventListener('mouseup', onUp); });
          img.addEventListener('touchstart', function(ev){ dragging=true; var p=ev.touches[0]; sx=p.pageX; sy=p.pageY; sl=state.left; st=state.top; document.addEventListener('touchmove', onMove, {passive:false}); document.addEventListener('touchend', onUp); }, {passive:true});
        })();

        // Zoom
        zoom.addEventListener('input', function(){
          var prevW = parseFloat(img.style.width)||0, prevH = parseFloat(img.style.height)||0;
          state.zoom = parseFloat(zoom.value)||1;
          var dw = state.naturalW * state.baseScale * state.zoom;
          var dh = state.naturalH * state.baseScale * state.zoom;
          // keep center stable
          state.left = Math.round(state.left - (dw - prevW)/2);
          state.top  = Math.round(state.top  - (dh - prevH)/2);
          img.style.width = dw+'px'; img.style.height = dh+'px';
          applyPos();
          enforceBounds();
        });

        function applyPos(){ img.style.left = state.left+'px'; img.style.top = state.top+'px'; }

        function enforceBounds(){
          var fw = (pane && pane !== frame) ? pane.clientWidth : frame.clientWidth;
          var fh = (pane && pane !== frame) ? pane.clientHeight: frame.clientHeight;
          var dw = parseFloat(img.style.width)||0, dh = parseFloat(img.style.height)||0;
          // Ensure image covers the container completely
          if (dw < fw) { dw = fw; img.style.width = dw+'px'; state.baseScale = dw / state.naturalW / state.zoom; }
          if (dh < fh) { dh = fh; img.style.height = dh+'px'; state.baseScale = dh / state.naturalH / state.zoom; }
          // Clamp inside container edges
          if (state.left > 0) state.left = 0;
          if (state.top  > 0) state.top  = 0;
          if (state.left + dw < fw) state.left = Math.round(fw - dw);
          if (state.top  + dh < fh) state.top  = Math.round(fh - dh);

          applyPos();
        }

        function doCrop(){
          var paneEl = (typeof pane !== 'undefined' && pane) ? pane : frame;
          var fw = paneEl.clientWidth, fh = paneEl.clientHeight;
          var s = state.baseScale * state.zoom;
          var srcX = Math.max(0, -state.left) / s;
          var srcY = Math.max(0, -state.top) / s;
          var srcW = fw / s;
          var srcH = fh / s;
          // clamp
          if (srcX + srcW > state.naturalW) srcX = state.naturalW - srcW;
          if (srcY + srcH > state.naturalH) srcY = state.naturalH - srcH;
          if (srcX < 0) srcX = 0; if (srcY < 0) srcY = 0;

          var outW = (type==='avatar') ? AVATAR_SIZE : COVER_W;
          var outH = (type==='avatar') ? AVATAR_SIZE : COVER_H;
          var canvas = document.createElement('canvas');
          canvas.width = outW; canvas.height = outH;
          var ctx = canvas.getContext('2d');
          ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
          var image = img; // use same element
          ctx.drawImage(image, srcX, srcY, srcW, srcH, 0, 0, outW, outH);
          return canvas;
        }

        function close(){ if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay); }
        // Disable click-outside to avoid accidental close; only explicit buttons will close
        // overlay.addEventListener('click', function(e){ if (e.target === overlay) close(); });
        overlay.querySelector('.pcrop-close').addEventListener('click', close);
        Array.prototype.forEach.call(overlay.querySelectorAll('.pcrop-cancel'), function(btn){ btn.addEventListener('click', close); });
        Array.prototype.forEach.call(overlay.querySelectorAll('.pcrop-save'), function(btn){ btn.addEventListener('click', function(){
          var canvas = doCrop();
          toBlob(canvas, function(blob){
            if (!blob) { setAlert(alertBox,'error', (window.DZ&&DZ.i18n? DZ.i18n('ui_upload_failed_crop_zero'):'Upload failed.')); return; }
            if (type==='avatar') {
              window.__PROFILE_CROP.avatarBlob = blob;
              // Update preview
              try {
                var url = URL.createObjectURL(blob);
                var imgPrev = document.getElementById('avatarPreviewImg');
                if (imgPrev) { imgPrev.src = url; }
              } catch(_){}
            } else {
              window.__PROFILE_CROP.coverBlob = blob;
              try {
                var url2 = URL.createObjectURL(blob);
                var coverPrev = document.getElementById('coverPreviewImg');
                if (coverPrev) {
                  coverPrev.src = url2;
                  if (coverPrev.closest) {
                    var coverBox = coverPrev.closest('.pm-cover');
                    if (coverBox) { coverBox.classList.remove('pm-cover--empty'); }
                  }
                }
              } catch(_){}
            }
            close();
          });
        }); });

        // Keep safe area and viewport sized on resize
        if (type === 'cover') {
          try {
            window.addEventListener('resize', sizeSafeBox, { passive:true });
          } catch(_){}
        }
      };
      fr.readAsDataURL(file);
    }

    // Hook both legacy hero selectors and new media-row selectors
    var avatarInput = document.querySelector('.pm-avatar input[name="avatar"], .hero-avatar input[name=\"avatar\"], input[name="avatar"]');
    var coverInput  = document.querySelector('.pm-cover  input[name="cover"],  .hero-cover  input[name=\"cover\"],  input[name="cover"]');
    var coverBtn    = document.querySelector('.pm-edit.pm-cover, .hero-edit-cover');
    var avatarBtn   = document.querySelector('.pm-edit.pm-avatar, .hero-edit-avatar');
    if (coverBtn && coverInput) { coverBtn.addEventListener('click', function(ev){ ev.preventDefault(); coverInput.click(); }); }
    if (avatarBtn && avatarInput) { avatarBtn.addEventListener('click', function(ev){ ev.preventDefault(); avatarInput.click(); }); }
    if (avatarInput) {
      avatarInput.addEventListener('change', function(){ var f = (this.files||[])[0]; if (f) openCropper(f, 'avatar'); this.value=''; });
    }
    if (coverInput) {
      coverInput.addEventListener('change', function(){ var f = (this.files||[])[0]; if (f) openCropper(f, 'cover'); this.value=''; });
    }

    // Toggle hero safe-area guides in preview
    try {
      var toggle = document.getElementById('toggleHeroGuides');
      var hero   = document.querySelector('.profile-hero');
      if (toggle && hero) {
        toggle.addEventListener('change', function(){ hero.classList.toggle('is-show-guides', !!toggle.checked); });
      }
    } catch(_){}
  });
})();
