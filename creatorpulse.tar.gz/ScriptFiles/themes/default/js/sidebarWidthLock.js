(function () {
  'use strict';

  var DESKTOP_BREAKPOINT = 769;
  var controllers = [
    {
      rootSelector: '.sidebar.sidebar--left',
      innerSelector: '.sidebar__inner',
      lockClass: 'ls-locked',
      prefix: 'cp-ls'
    },
    {
      rootSelector: '.content-right',
      innerSelector: '.content-right-container',
      lockClass: 'rs-locked',
      prefix: 'cp-rs'
    }
  ];

  function setImportantStyle(element, property, value) {
    if (element) {
      element.style.setProperty(property, value, 'important');
    }
  }

  function clearRootMetrics(state) {
    if (!state.root) { return; }
    state.root.style.removeProperty('width');
    state.root.style.removeProperty('min-width');
    state.root.style.removeProperty('flex-basis');
    state.root.style.removeProperty('flex');
    state.root.style.removeProperty('box-sizing');
    state.root.style.removeProperty('--' + state.config.prefix + '-root-width');
  }

  function createController(config) {
    var state = {
      config: config,
      root: null,
      inner: null,
      left: 0,
      width: 0,
      rootWidth: 0,
      raf: 0,
      refreshRaf: 0
    };

    function findElements() {
      state.root = document.querySelector(config.rootSelector);
      state.inner = state.root ? state.root.querySelector(config.innerSelector) : null;
    }

    function capture() {
      if (!state.root || !state.inner || window.innerWidth < DESKTOP_BREAKPOINT) { return; }
      var rootRect = state.root.getBoundingClientRect();
      var innerRect = state.inner.getBoundingClientRect();
      if (rootRect.width <= 0 || innerRect.width <= 0) { return; }
      state.left = innerRect.left;
      state.width = innerRect.width;
      state.rootWidth = rootRect.width;
    }

    function lockRootMetrics() {
      if (!state.root || state.rootWidth <= 0) { return; }
      setImportantStyle(state.root, 'box-sizing', 'border-box');
      setImportantStyle(state.root, 'width', state.rootWidth + 'px');
      setImportantStyle(state.root, 'min-width', state.rootWidth + 'px');
      setImportantStyle(state.root, 'flex-basis', state.rootWidth + 'px');
      setImportantStyle(state.root, 'flex', '0 0 ' + state.rootWidth + 'px');
      state.root.style.setProperty('--' + config.prefix + '-root-width', state.rootWidth + 'px');
    }

    function apply() {
      if (!state.root || !state.inner || window.innerWidth < DESKTOP_BREAKPOINT || state.width <= 0 || state.rootWidth <= 0) { return; }
      if (!state.inner.classList.contains(config.lockClass)) {
        clearRootMetrics(state);
        return;
      }
      lockRootMetrics();
      state.inner.style.setProperty('--' + config.prefix + '-lock-left', state.left + 'px');
      state.inner.style.setProperty('--' + config.prefix + '-lock-width', state.width + 'px');
      setImportantStyle(state.inner, 'box-sizing', 'border-box');
      setImportantStyle(state.inner, 'width', state.width + 'px');
      setImportantStyle(state.inner, 'min-width', state.width + 'px');
      setImportantStyle(state.inner, 'max-width', state.width + 'px');
    }

    function scheduleApply() {
      if (state.raf) { return; }
      if (state.inner && !state.inner.classList.contains(config.lockClass)) {
        capture();
      }
      state.raf = window.requestAnimationFrame(function () {
        state.raf = 0;
        apply();
      });
    }

    function refresh() {
      if (state.refreshRaf) { window.cancelAnimationFrame(state.refreshRaf); }
      state.refreshRaf = window.requestAnimationFrame(function () {
        state.refreshRaf = 0;
        clearRootMetrics(state);
        findElements();
        capture();
        apply();
      });
    }

    window.addEventListener('scroll', scheduleApply, { passive: true });
    window.addEventListener('resize', refresh);
    window.addEventListener('load', refresh);
    document.addEventListener('DOMContentLoaded', refresh);
    refresh();
    window.setTimeout(refresh, 700);
  }

  controllers.forEach(createController);
})();
