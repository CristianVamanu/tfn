(function(){
  'use strict';

  function buildUrl(path){
    try { if (typeof window.buildUrl === 'function') { return window.buildUrl(path); } } catch(_){}
    try {
      var base = '';
      if (typeof window.site_url === 'string' && window.site_url) {
        base = window.site_url;
      } else {
        var origin = window.location.origin || ((window.location.protocol || 'http:') + '//' + (window.location.host || ''));
        base = origin + (window.location.pathname ? window.location.pathname.replace(/[^\/]*$/, '') : '/');
      }
      return new URL(String(path || ''), base).toString();
    } catch (_){ return String(path || ''); }
  }

  function setAlert(el, type, msg){
    if (!el) return;
    el.textContent = msg || '';
    el.classList.remove('is-error', 'is-success');
    if (type === 'success') { el.classList.add('is-success'); }
    else if (type === 'error') { el.classList.add('is-error'); }
  }

  function clearAlert(el){ if (el) { el.textContent = ''; el.classList.remove('is-error', 'is-success'); } }

  function onReady(fn){ if (document.readyState !== 'loading') { fn(); } else { document.addEventListener('DOMContentLoaded', fn); } }

 function disableWhile(btn, fn){
    if (!btn) { return fn(); }
    var prev = btn.textContent;
    btn.disabled = true;
    btn.textContent = (window.DZ && DZ.i18n) ? DZ.i18n('saving') : 'Saving...';
    var done = Promise.resolve(fn());
    var reset = function(){ btn.disabled = false; btn.textContent = prev; };
    if (typeof done.finally === 'function') {
      return done.finally(reset);
    }
    return done.then(function(res){ reset(); return res; }, function(err){ reset(); throw err; });
  }

  onReady(function(){
    var identityForm = document.getElementById('creator-identity-form');
    var plansForm = document.getElementById('creator-plans-form');
    var payoutForm = document.getElementById('creator-payout-form');

    if (identityForm) {
      identityForm.addEventListener('submit', function(ev){
        ev.preventDefault();
        var alertBox = identityForm.querySelector('.creator-form__alert');
        clearAlert(alertBox);
        var submitBtn = identityForm.querySelector('button[type="submit"]');

        disableWhile(submitBtn, function(){
          var fd = new FormData(identityForm);
          var requiredFields = ['id_front','id_back'];
          for (var i = 0; i < requiredFields.length; i++) {
            var input = identityForm.querySelector('input[name="' + requiredFields[i] + '"]');
            if (!input || !input.files || !input.files.length) {
              setAlert(alertBox, 'error', (window.DZ && DZ.i18n) ? DZ.i18n('creator_identity_missing_' + requiredFields[i]) : 'Please attach all required files.');
              return Promise.resolve();
            }
          }
          return fetch(buildUrl('request/requests.php'), {
            method: 'POST',
            body: fd,
            credentials: 'same-origin'
          }).then(function(r){
            return r.json().catch(function(){ return {status:'error', message:'INVALID_RESPONSE'}; });
          }).then(function(res){
            if (res && res.status === 'success') {
              setAlert(alertBox, 'success', res.message || 'Submitted for review.');
            } else {
              var msg = (res && (res.message || res.error)) || 'Submission failed.';
              setAlert(alertBox, 'error', msg);
            }
          }).catch(function(){
            setAlert(alertBox, 'error', 'Network error.');
          });
        });
      });
    }

    if (plansForm) {
      plansForm.addEventListener('submit', function(ev){
        ev.preventDefault();
        var alertBox = plansForm.querySelector('.creator-form__alert');
        clearAlert(alertBox);
        var submitBtn = plansForm.querySelector('button[type="submit"]');

        disableWhile(submitBtn, function(){
          var fd = new FormData(plansForm);
          return fetch(buildUrl('request/requests.php'), {
            method: 'POST',
            body: fd,
            credentials: 'same-origin'
          }).then(function(r){
            return r.json().catch(function(){ return {status:'error', message:'INVALID_RESPONSE'}; });
          }).then(function(res){
            if (res && res.status === 'success') {
              setAlert(alertBox, 'success', res.message || 'Plans saved.');
            } else {
              var msg = (res && (res.message || res.error)) || 'Save failed.';
              setAlert(alertBox, 'error', msg);
            }
          }).catch(function(){ setAlert(alertBox, 'error', 'Network error.'); });
        });
      });
    }

    if (payoutForm) {
      var methodSelect = payoutForm.querySelector('#creator-payout-method');
      var groups = Array.prototype.slice.call(payoutForm.querySelectorAll('.payout-method-fields'));
      var toggleGroups = function(val){
        groups.forEach(function(group){
          var match = group.getAttribute('data-method') === val;
          group.hidden = !match;
          if (match) {
            group.removeAttribute('hidden');
          } else {
            group.setAttribute('hidden', 'hidden');
          }
        });
        payoutForm.setAttribute('data-selected-method', val || 'none');
      };
      if (methodSelect) {
        toggleGroups(methodSelect.value || methodSelect.getAttribute('data-current-method'));
        methodSelect.addEventListener('change', function(){ toggleGroups(methodSelect.value); });
      }

      payoutForm.addEventListener('submit', function(ev){
        ev.preventDefault();
        var alertBox = payoutForm.querySelector('.creator-form__alert');
        clearAlert(alertBox);
        var submitBtn = payoutForm.querySelector('button[type="submit"]');

        disableWhile(submitBtn, function(){
          var fd = new FormData(payoutForm);
          return fetch(buildUrl('request/requests.php'), {
            method: 'POST',
            body: fd,
            credentials: 'same-origin'
          }).then(function(r){
            return r.json().catch(function(){ return {status:'error', message:'INVALID_RESPONSE'}; });
          }).then(function(res){
            if (res && res.status === 'success') {
              setAlert(alertBox, 'success', res.message || 'Payout preferences saved.');
            } else {
              var msg = (res && (res.message || res.error)) || 'Save failed.';
              setAlert(alertBox, 'error', msg);
            }
          }).catch(function(){ setAlert(alertBox, 'error', 'Network error.'); });
        });
      });
    }
  });
})();
