(function(){
  "use strict";
  if (window.__walletTopupHandlerBound) { return; }
  window.__walletTopupHandlerBound = true;

  function buildUrl(path) {
    try {
      if (window.DZ && typeof window.DZ.buildUrl === 'function') {
        return window.DZ.buildUrl(path);
      }
    } catch (_) {}
    try {
      var base = (typeof window.site_url === 'string' && window.site_url)
        ? window.site_url
        : (window.location.origin + window.location.pathname.replace(/[^\/]*$/, ''));
      if (base.slice(-1) !== '/') { base += '/'; }
      return new URL(String(path || '').replace(/^\/+/, ''), base).toString();
    } catch (_) {
      return String(path || '');
    }
  }

  var REQUEST_ENDPOINT = buildUrl('request/requests.php');
  var I18N = (window.DZ && typeof window.DZ.i18n === 'function') ? window.DZ.i18n : function(){ return ''; };
  var CRYPTO_PROVIDERS = ['nowpayments', 'coinbase'];
  var currencyConfig = (window.DZ && (window.DZ.walletTopupFormat || window.DZ.currencyFormat))
    ? (window.DZ.walletTopupFormat || window.DZ.currencyFormat)
    : {};
  var formCurrencyConfig = null;
  var formDatasetConfig = null;

  function getFormCurrencyConfig() {
    if (formCurrencyConfig) { return formCurrencyConfig; }
    var form = document.querySelector('.wallet-topup-form');
    if (!form) { return null; }
    var raw = form.getAttribute('data-currency-config') || '';
    if (!raw) { return null; }
    try {
      formCurrencyConfig = JSON.parse(raw);
    } catch (_) {
      formCurrencyConfig = null;
    }
    return formCurrencyConfig;
  }

  function getFormDatasetConfig() {
    if (formDatasetConfig) { return formDatasetConfig; }
    var form = document.querySelector('.wallet-topup-form');
    if (!form) { return null; }
    formDatasetConfig = {
      position: form.getAttribute('data-currency-position') || null,
      decimalSep: form.getAttribute('data-decimal-sep') || null,
      thousandsSep: form.getAttribute('data-thousands-sep') || null,
    };
    return formDatasetConfig;
  }

  function getCurrencyConfig() {
    var cfg = null;
    var fromForm = getFormCurrencyConfig();
    if (fromForm) {
      cfg = fromForm;
    } else if (window.DZ && window.DZ.walletTopupFormat) {
      cfg = window.DZ.walletTopupFormat;
    } else if (window.DZ && window.DZ.currencyFormat) {
      cfg = window.DZ.currencyFormat;
    } else {
      cfg = currencyConfig;
    }
    var ds = getFormDatasetConfig();
    if (ds) {
      if (ds.position) { cfg.position = ds.position; }
      if (ds.decimalSep) { cfg.decimalSep = ds.decimalSep; }
      if (ds.thousandsSep) { cfg.thousandsSep = ds.thousandsSep; }
    }
    // Ensure normalized keys exist
    if (cfg && typeof cfg === 'object') {
      if (!cfg.position && cfg.position !== '') {
        cfg.position = 'left';
      }
      if (typeof cfg.decimalPlaces !== 'number') {
        cfg.decimalPlaces = 2;
      }
      if (typeof cfg.decimalSep !== 'string' || !cfg.decimalSep) {
        cfg.decimalSep = '.';
      }
      if (typeof cfg.thousandsSep !== 'string') {
        cfg.thousandsSep = ',';
      }
    }
    currencyConfig = cfg || {};
    return currencyConfig;
  }

  function providerPrecision(providerValue) {
    var value = (providerValue || '').toLowerCase();
    return CRYPTO_PROVIDERS.indexOf(value) !== -1 ? 8 : 2;
  }

  function currencyPrecision(currency) {
    var cfg = getCurrencyConfig();
    var base = (typeof cfg.decimalPlaces === 'number')
      ? Math.max(0, Math.min(8, cfg.decimalPlaces))
      : 2;
    var code = (currency || '').toUpperCase();
    if (!code) { return base; }
    var cryptoCurrencies = ['BTC', 'ETH', 'BCH', 'LTC', 'DOGE', 'XMR', 'SOL', 'ADA', 'MATIC', 'XRP', 'USDT', 'USDC', 'DAI', 'BNB', 'TRX'];
    return cryptoCurrencies.indexOf(code) !== -1 ? Math.max(base, 8) : base;
  }

  function getProviderMinimums(form) {
    if (!form) { return {}; }
    if (!form.__providerMins) {
      var raw = form.getAttribute('data-provider-mins') || form.dataset.providerMins || '';
      try {
        form.__providerMins = raw ? JSON.parse(raw) : {};
      } catch (_) {
        form.__providerMins = {};
      }
    }
    return form.__providerMins;
  }

  function getProviderQuickMap(form) {
    if (!form) { return {}; }
    if (!form.__providerQuick) {
      var raw = form.getAttribute('data-provider-quick') || form.dataset.providerQuick || '';
      try {
        form.__providerQuick = raw ? JSON.parse(raw) : {};
      } catch (_) {
        form.__providerQuick = {};
      }
    }
    return form.__providerQuick;
  }

  function renderQuickChips(form, providerValue, precision, currency, symbol) {
    var quickSection = form ? form.querySelector('.wallet-topup-quick') : null;
    var container = quickSection ? quickSection.querySelector('.wallet-topup-quick-chips') : null;
    var map = getProviderQuickMap(form);
    var key = (providerValue || '').toLowerCase();
    var values = (map && map[key]) ? map[key] : [];
    if (!container) { return { values: [], firstChip: null }; }
    container.innerHTML = '';
    if (!values || !values.length) { return { values: [], firstChip: null }; }
    var factor = Math.pow(10, precision);
    var firstChip = null;
    values.forEach(function(amount, idx){
      var normalized = typeof amount === 'number' ? amount : parseFloat(amount);
      if (!isFinite(normalized) || normalized <= 0) { return; }
      var fixed = (Math.round(normalized * factor) / factor).toFixed(precision);
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'wallet-topup-chip' + (idx === 0 ? ' is-active' : '');
      btn.dataset.amount = fixed;
      btn.setAttribute('aria-pressed', idx === 0 ? 'true' : 'false');
      btn.textContent = formatMoney(parseFloat(fixed), currency, symbol);
      container.appendChild(btn);
      if (!firstChip && idx === 0) {
        firstChip = btn;
      }
    });
    return { values: values, firstChip: firstChip };
  }

  function ensureDzToast() {
    window.DZ = window.DZ || {};
    if (typeof window.DZ.toast === 'function') { return; }
    window.DZ.toast = function(msg, opts) {
      try {
        var id = 'dz-toast-container';
        var root = document.getElementById(id);
        if (!root) {
          root = document.createElement('div');
          root.id = id;
          root.className = 'dz-toast-container';
          document.body.appendChild(root);
        }
        var toast = document.createElement('div');
        toast.className = 'dz-toast is-info';
        toast.textContent = String(msg || '');
        root.appendChild(toast);
        requestAnimationFrame(function(){ toast.classList.add('is-shown'); });
        setTimeout(function(){
          toast.classList.remove('is-shown');
          setTimeout(function(){ toast.remove(); }, 220);
        }, (opts && opts.duration) || 2600);
      } catch (_) {}
    };
  }

  function showMessage(form, msg, kind) {
    var alertBox = form ? form.querySelector('.wallet-topup-alert') : null;
    var tone = (kind === 'error' || kind === 'success') ? kind : 'info';
    if (alertBox) {
      alertBox.className = 'wallet-topup-alert is-shown ' + (tone === 'error' ? 'is-error' : (tone === 'success' ? 'is-success' : 'is-info'));
      alertBox.textContent = String(msg || '');
      clearTimeout(alertBox.__hideTimer);
      alertBox.__hideTimer = setTimeout(function(){ alertBox.classList.remove('is-shown'); }, 3600);
      return;
    }
    ensureDzToast();
    window.DZ.toast(String(msg || ''), { type: tone === 'error' ? 'error' : (tone === 'success' ? 'success' : 'info'), duration: 2800 });
  }

  function getCsrf() {
    var el = document.querySelector('input[name="csrf_token"]');
    return el ? (el.value || '') : '';
  }

  function parseAmount(inputValue) {
    if (!inputValue) { return NaN; }
    var str = String(inputValue);
    var cfg = getCurrencyConfig();
    var thousands = cfg.thousandsSep || '';
    if (thousands) {
      var escaped = thousands.replace(/([.*+?^=!:${}()|[\]\\])/g, '\\$1');
      str = str.replace(new RegExp(escaped, 'g'), '');
    }
    var dec = cfg.decimalSep === ',' ? ',' : '.';
    if (dec !== '.') {
      var escapedDec = dec.replace(/([.*+?^=!:${}()|[\]\\])/g, '\\$1');
      str = str.replace(new RegExp(escapedDec, 'g'), '.');
    }
    str = str.replace(/[^0-9.\-]/g, '');
    return parseFloat(str);
  }

  function formatMoney(amount, currency, symbol) {
    var cfg = getCurrencyConfig();
    var code = (currency || cfg.code || 'USD').toString().toUpperCase();
    var sym = (symbol || cfg.symbol || '').toString();
    if (sym && sym.toUpperCase() === code) { sym = ''; }
    if ((!sym || sym === code) && cfg.symbols && cfg.symbols[code]) {
      sym = cfg.symbols[code];
    }

    var precision = currencyPrecision(code);
    var decimalSep = cfg.decimalSep === ',' ? ',' : '.';
    var thousandsSep = (typeof cfg.thousandsSep === 'string') ? cfg.thousandsSep : ',';
    if (thousandsSep === decimalSep) { thousandsSep = ''; }

    var numeric = (typeof amount === 'number' && isFinite(amount)) ? amount : 0;
    var negative = numeric < 0;
    var fixed = Math.abs(numeric).toFixed(precision);
    var parts = fixed.split('.');
    if (thousandsSep) {
      parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandsSep);
    }
    var formatted = parts.length > 1 ? (parts[0] + decimalSep + parts[1]) : parts[0];
    if (negative) { formatted = '-' + formatted; }

    var position = (cfg.position || 'left').toLowerCase();
    var symValid = sym && sym !== code && sym.length <= 4;
    if (!symValid) { return formatted + ' ' + code; }
    switch (position) {
      case 'left':
        return sym + formatted;
      case 'left_space':
        return sym + ' ' + formatted;
      case 'right':
        return formatted + sym;
      case 'right_space':
        return formatted + ' ' + sym;
      default:
        return sym + formatted;
    }
  }

  function resolveAbsoluteUrl(url) {
    if (!url) { return ''; }
    if (/^https?:\/\//i.test(url)) { return url; }
    return buildUrl(String(url).replace(/^\/+/, ''));
  }

  function verifyRedirectUrl(url) {
    var absolute = resolveAbsoluteUrl(url);
    if (!absolute) { return Promise.resolve(false); }
    return fetch(absolute, {
      method: 'HEAD',
      credentials: 'same-origin',
      cache: 'no-store'
    }).then(function(resp){
      return !!(resp && resp.ok);
    }).catch(function(){
      return false;
    });
  }

  function amountTolerance(form) {
    var precision = parseInt(form && form.dataset && form.dataset.amountPrecision, 10);
    if (!isFinite(precision) || precision < 0) { precision = 2; }
    if (precision === 0) { return 0.01; }
    return Math.pow(10, -precision) * 0.5;
  }

  var balanceRefreshTimer = null;
  function scheduleBalanceRefresh(delay) {
    var ms = (typeof delay === 'number' && delay >= 0) ? delay : 180;
    if (balanceRefreshTimer) { return; }
    balanceRefreshTimer = setTimeout(function(){
      balanceRefreshTimer = null;
      fetchWalletBalance();
    }, ms);
  }

  function setInputValue(input, value) {
    if (!input) { return; }
    var form = input.closest('.wallet-topup-form');
    var precision = 2;
    if (form && form.dataset.amountPrecision) {
      var parsed = parseInt(form.dataset.amountPrecision, 10);
      if (isFinite(parsed) && parsed >= 0 && parsed <= 8) {
        precision = parsed;
      }
    }
    var factor = Math.pow(10, precision);
    var normalized = (Math.round(value * factor) / factor).toFixed(precision);
    input.value = normalized;
    input.dispatchEvent(new Event('input', { bubbles: true }));
  }

  function markActiveChip(chip, form) {
    if (!form) { return; }
    var chips = form.querySelectorAll('.wallet-topup-chip');
    chips.forEach(function(btn){
      btn.classList.remove('is-active');
      btn.setAttribute('aria-pressed', 'false');
    });
    if (chip) {
      chip.classList.add('is-active');
      chip.setAttribute('aria-pressed', 'true');
    }
  }

  function initForm(form) {
    if (!form || form.__walletTopupInitialized) { return; }
    form.__walletTopupInitialized = true;

    refreshProvidersCurrency(form);

    var input = form.querySelector('.wallet-topup-input');
    var firstChip = form.querySelector('.wallet-topup-chip');
    var quickEnabled = form.dataset.quickEnabled !== '0';

    if (quickEnabled && input && firstChip) {
      var amount = parseFloat(firstChip.dataset.amount || '0');
      if (amount > 0) {
        setInputValue(input, amount);
        markActiveChip(firstChip, form);
      }
    }
    if (input && !input.value) {
      var min = parseFloat(form.dataset.minAmount || input.dataset.min || '0');
      if (min > 0 && quickEnabled) {
        setInputValue(input, min);
      } else {
        input.value = '';
      }
    }
  }

  function toggleQuickSection(form, allowQuick) {
    if (!form) { return; }
    var quickSection = form.querySelector('.wallet-topup-quick');
    if (!quickSection) { return; }
    var chips = quickSection.querySelectorAll('.wallet-topup-chip');
    if (allowQuick) {
      quickSection.removeAttribute('hidden');
      quickSection.classList.remove('is-disabled');
      quickSection.removeAttribute('aria-hidden');
    } else {
      quickSection.setAttribute('hidden', 'hidden');
      quickSection.classList.add('is-disabled');
      quickSection.setAttribute('aria-hidden', 'true');
    }
    chips.forEach(function(chip){
      chip.disabled = !allowQuick;
      chip.setAttribute('tabindex', allowQuick ? '0' : '-1');
      if (!allowQuick) {
        chip.classList.remove('is-active');
        chip.setAttribute('aria-pressed', 'false');
      }
    });
  }

  function refreshProvidersCurrency(form) {
    if (!form) { return; }
    var input = form.querySelector('.wallet-topup-input');
    var provider = form.querySelector('input[name="wallet_topup_provider"]:checked');
    if (!provider) { return; }

    var previousQuickState = form.dataset.quickEnabled || '';
    var providerValue = (provider.value || '').toLowerCase();
    var cur = provider.getAttribute('data-currency') || form.dataset.currencyCode || 'USD';
    var sym = provider.getAttribute('data-symbol');
    form.dataset.currencyCode = cur;
    if (typeof sym === 'string') {
      form.dataset.currencySymbol = sym;
    }
    var precision = providerPrecision(providerValue);
    if (!isFinite(precision) || precision < 0) { precision = 2; }
    form.dataset.amountPrecision = String(precision);

    var renderResult = renderQuickChips(form, providerValue, precision, cur, sym || form.dataset.currencySymbol || '');
    var quickValues = (renderResult.values || []).map(function(val){
      var numeric = parseFloat(val);
      return isFinite(numeric) ? numeric : 0;
    });
    var quickDisabled = !quickValues.length;
    form.dataset.quickEnabled = quickDisabled ? '0' : '1';
    toggleQuickSection(form, !quickDisabled);

    var providerMins = getProviderMinimums(form);
    var minForProvider = providerMins[providerValue];
    if (typeof minForProvider === 'undefined') {
      var fallbackMin = parseFloat(form.getAttribute('data-min-amount') || form.dataset.minAmount || (input ? input.getAttribute('data-min') : '0') || '0');
      minForProvider = isFinite(fallbackMin) ? fallbackMin : 0;
    }
    form.dataset.minAmount = String(minForProvider);

    if (input) {
      if (!input.getAttribute('data-placeholder-template')) {
        input.setAttribute('data-placeholder-template', input.getAttribute('placeholder') || '');
      }
      var placeholderTemplate = input.getAttribute('data-placeholder-template');
      var decimalsExample = (precision > 0) ? ('0.' + Array(precision + 1).join('0')) : '0';
      if (precision === 2) { decimalsExample = '0.00'; }
      if (placeholderTemplate) {
        var placeholder = placeholderTemplate.replace(/\b0(?:\.[0]+)?/, decimalsExample);
        if (placeholder.indexOf('{currency}') !== -1) {
          placeholder = placeholder.replace('{currency}', cur);
        }
        input.setAttribute('placeholder', placeholder);
      }
      input.setAttribute('inputmode', 'decimal');
      input.setAttribute('pattern', '^\\d*(?:[\\.,]\\d{0,' + precision + '})?$');
      input.setAttribute('data-min', String(minForProvider));
      input.setAttribute('min', String(minForProvider));
      if (quickDisabled) {
        input.removeAttribute('readonly');
      }
      if (quickDisabled && input.value) {
        // Reset auto-selected quick values when switching to crypto providers
        var currentVal = parseFloat(input.value);
        if (!isFinite(currentVal) || currentVal >= 10) {
          input.value = '';
          input.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }
    }

    if (!quickDisabled && input && (previousQuickState === '0' || input.value === '')) {
      var firstChip = renderResult.firstChip || form.querySelector('.wallet-topup-chip');
      if (firstChip) {
        var chipAmount = parseFloat(firstChip.getAttribute('data-amount') || '0');
        if (chipAmount > 0) {
          setInputValue(input, chipAmount);
          markActiveChip(firstChip, form);
        }
      }
    }

    var balanceNodes = form.querySelectorAll('[data-wallet-balance-text]');
    if (balanceNodes.length) {
      balanceNodes.forEach(function(node){
        node.setAttribute('data-wallet-balance-currency', cur);
        if (typeof sym === 'string') {
          node.setAttribute('data-wallet-balance-symbol', sym);
        }
      });
      updateDisplayedBalance(undefined, cur, sym || form.dataset.currencySymbol || '');
    }

    if (quickDisabled && input && input.value) {
      var currentVal = parseFloat(input.value);
      var shouldClear = false;
      var tolerance = amountTolerance(form);
      if (!isFinite(currentVal) || currentVal <= 0) {
        shouldClear = true;
      } else {
        for (var i = 0; i < quickValues.length; i += 1) {
          if (Math.abs(quickValues[i] - currentVal) < tolerance) {
            shouldClear = true;
            break;
          }
        }
        if (!shouldClear && currentVal >= 10) {
          shouldClear = true;
        }
      }
      if (shouldClear) {
        input.value = '';
        input.dispatchEvent(new Event('input', { bubbles: true }));
      }
    }
  }

  function submitForm(ev) {
    if (!ev.target || !ev.target.matches('.wallet-topup-form')) { return; }
    ev.preventDefault();
    var form = ev.target;
    if (form.dataset.submitting === '1') { return; }

    var amountInput = form.querySelector('.wallet-topup-input');
    var providerInput = form.querySelector('input[name="wallet_topup_provider"]:checked');
    if (!amountInput || !providerInput) {
      showMessage(form, I18N('wallet_topup_provider_unavailable') || 'No payment providers are available right now.', 'error');
      return;
    }

    var amount = parseAmount(amountInput.value);
    if (!isFinite(amount) || amount <= 0) {
      showMessage(form, I18N('wallet_topup_invalid_amount') || 'Please choose an amount within the allowed range.', 'error');
      return;
    }

    var min = parseFloat(form.dataset.minAmount || amountInput.dataset.min || '0') || 0;
    var max = parseFloat(form.dataset.maxAmount || amountInput.dataset.max || '0') || 0;
    if (min > 0 && amount < min) {
      showMessage(form, I18N('wallet_topup_invalid_amount') || 'Please choose an amount within the allowed range.', 'error');
      return;
    }
    if (max > 0 && amount > max) {
      showMessage(form, I18N('wallet_topup_invalid_amount') || 'Please choose an amount within the allowed range.', 'error');
      return;
    }

    var provider = providerInput.value || '';
    if (!provider) {
      showMessage(form, I18N('wallet_topup_provider_unavailable') || 'No payment providers are available right now.', 'error');
      return;
    }

    var precision = parseInt(form.dataset.amountPrecision || '2', 10);
    if (!isFinite(precision) || precision < 0 || precision > 8) { precision = 2; }
    var amountFactor = Math.pow(10, precision);
    var normalizedAmount = (Math.round(amount * amountFactor) / amountFactor).toFixed(precision);

    var fd = new FormData();
    fd.append('p', 'wallet_topup_create_payment');
    fd.append('provider', provider);
    fd.append('amount', normalizedAmount);

    var billingFields = form.querySelectorAll('[data-billing-field]');
    billingFields.forEach(function(field){
      var key = field.getAttribute('data-billing-field');
      if (!key) { return; }
      fd.append('billing_' + key, field.value || '');
    });

    fd.append('csrf_token', getCsrf());

    form.dataset.submitting = '1';
    var submitBtn = form.querySelector('.wallet-topup-submit');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.classList.add('is-loading');
    }

    fetch(REQUEST_ENDPOINT, {
      method: 'POST',
      body: fd,
      credentials: 'same-origin'
    }).then(function(resp){
      return resp.json().catch(function(){ return null; });
    }).then(function(data){
      if (!data || data.status !== 'success') {
        var msg = (data && (data.message_text || data.message)) || I18N('wallet_topup_checkout_failed') || 'Unable to start top-up checkout. Please try again later.';
        showMessage(form, msg, 'error');
        return;
      }
      if (data.checkout_url) {
        try {
          var pending = {
            type: 'wallet_topup',
            provider: data.provider || provider,
            reference: data.reference || '',
            amount: amount,
            currency: data.currency || form.dataset.currencyCode || providerInput.getAttribute('data-currency') || 'USD',
            symbol: form.dataset.currencySymbol || '',
            created_at: Date.now(),
            redirect_url: data.redirect_url || ''
          };
          window.sessionStorage.setItem('wallet_topup_pending', JSON.stringify(pending));
        } catch (_) {}
        window.location.href = data.checkout_url;
        return;
      }
      showMessage(form, I18N('wallet_topup_checkout_failed') || 'Unable to start top-up checkout. Please try again later.', 'error');
    }).catch(function(err){
      console.error('wallet_topup_create_payment failed', err);
      showMessage(form, I18N('wallet_topup_checkout_failed') || 'Unable to start top-up checkout. Please try again later.', 'error');
    }).finally(function(){
      if (!form.isConnected) { return; }
      delete form.dataset.submitting;
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.classList.remove('is-loading');
      }
    });
  }

  function updateDisplayedBalance(amount, currency, symbol) {
    var nodes = document.querySelectorAll('[data-wallet-balance-text], [data-wallet-balance-field]');
    nodes.forEach(function(node){
      var numeric = parseFloat(node.getAttribute('data-wallet-balance') || '0');
      if (isFinite(amount)) {
        numeric = amount;
      }
      if (!isFinite(numeric)) {
        numeric = 0;
      }
      var displayCurrency = node.getAttribute('data-wallet-balance-currency') || currency || 'USD';
      var precision = currencyPrecision(displayCurrency);
      var factor = Math.pow(10, precision);
      var normalized = Math.round(numeric * factor) / factor;
      node.setAttribute('data-wallet-balance', normalized.toFixed(precision));

      if (currency) {
        node.setAttribute('data-wallet-balance-currency', currency);
      }
      if (typeof symbol === 'string' && symbol !== '') {
        node.setAttribute('data-wallet-balance-symbol', symbol);
      } else if (!symbol) {
        symbol = node.getAttribute('data-wallet-balance-symbol') || '';
      }

      var displaySymbol = node.getAttribute('data-wallet-balance-symbol') || symbol || currencyConfig.symbol || '';
      var template = node.getAttribute('data-wallet-balance-template') || '';
      var formatMode = (node.getAttribute('data-wallet-balance-format') || '').toLowerCase();
      var formatted;

      if (formatMode === 'numeric') {
        formatted = normalized.toFixed(precision);
      } else if (formatMode === 'integer') {
        formatted = String(Math.round(normalized));
      } else {
        formatted = formatMoney(normalized, displayCurrency, displaySymbol);
      }

      if (node.hasAttribute('data-wallet-balance-field')) {
        var fieldName = node.getAttribute('data-wallet-balance-field') || 'value';
        try {
          if (fieldName === 'value') {
            if (node.value !== formatted) {
              node.value = formatted;
              try { node.dispatchEvent(new Event('input', { bubbles: true })); } catch (__) {}
              try { node.dispatchEvent(new Event('change', { bubbles: true })); } catch (__) {}
            }
          } else {
            node.setAttribute(fieldName, formatted);
          }
        } catch (__) {
          node.setAttribute('data-wallet-balance-fallback', formatted);
        }
        return;
      }

      if (template && template.indexOf('{balance}') !== -1) {
        node.textContent = template.replace('{balance}', formatted);
      } else {
        node.textContent = formatted;
      }
    });
  }

  function fetchWalletBalance() {
    var fd = new FormData();
    fd.append('p', 'wallet_balance_get');
    fd.append('csrf_token', getCsrf());
    return fetch(REQUEST_ENDPOINT, {
      method: 'POST',
      body: fd,
      credentials: 'same-origin'
    }).then(function(resp){
      return resp.json().catch(function(){ return null; });
    }).then(function(data){
      if (data && data.status === 'success' && typeof data.balance !== 'undefined') {
        var balance = parseFloat(data.balance);
        var currency = data.currency || 'USD';
        var symbol = data.symbol || '';
        if (!isFinite(balance)) { return null; }
        updateDisplayedBalance(balance, currency, symbol);
        return balance;
      }
      return null;
    }).catch(function(){ return null; });
  }

  function clearPendingTopup() {
    try { window.sessionStorage.removeItem('wallet_topup_pending'); } catch (_) {}
  }

  function handlePendingSuccess(pending, options) {
    var opts = options || {};
    clearPendingTopup();
    var successMsg = I18N('wallet_topup_success') || 'Wallet top-up completed successfully.';
    if (!opts.skipToast) {
      ensureDzToast();
      window.DZ.toast(successMsg, { type: 'success', duration: 3000 });
    }
    if (opts.skipBalance) { return; }
    fetchWalletBalance().then(function(updated){
      if (updated === null && typeof pending.amount === 'number') {
        var nodes = document.querySelectorAll('[data-wallet-balance-text]');
        if (nodes.length) {
          var current = parseFloat(nodes[0].getAttribute('data-wallet-balance') || '0') || 0;
          var newBalance = current + (pending.amount || 0);
          updateDisplayedBalance(newBalance, pending.currency || 'USD', pending.symbol || '');
        }
      }
    });
  }

  function pollPendingTopup() {
    var raw = null;
    try { raw = window.sessionStorage.getItem('wallet_topup_pending'); } catch (_) {}
    if (!raw) { return; }
    var pending;
    try { pending = JSON.parse(raw); } catch (_) { pending = null; }
    if (!pending || !pending.provider || !pending.reference) { return; }

    var attemptCount = 0;
    var maxAttempts = 10;
    var processingNotified = false;
    var finished = false;

    function toast(kind, message, duration) {
      if (!message) { return; }
      ensureDzToast();
      window.DZ.toast(String(message), {
        type: kind || 'info',
        duration: duration || (kind === 'error' ? 4200 : 2800)
      });
    }

    function finish(kind, message) {
      if (finished) { return; }
      finished = true;
      clearPendingTopup();
      toast(kind, message);
      scheduleBalanceRefresh(200);
    }

    function handleTimeout() {
      var msg = I18N('wallet_topup_still_processing') || I18N('wallet_topup_processing') || (I18N('pay_processing_message') || 'We are processing your payment. It may take a moment to finalize.');
      finish('info', msg);
    }

    function handleFailure() {
      var msg = I18N('wallet_topup_failed') || 'We could not confirm your wallet top-up. Please contact support if you were charged.';
      finish('error', msg);
    }

    function tick() {
      if (finished) { return; }
      attemptCount += 1;
      var fd = new FormData();
      fd.append('p', 'payment_status');
      fd.append('provider', pending.provider);
      fd.append('reference', pending.reference);
      fd.append('type', 'wallet_topup');
      var csrfToken = getCsrf();
      if (csrfToken) {
        fd.append('csrf_token', csrfToken);
      }
      fetch(REQUEST_ENDPOINT, {
        method: 'POST',
        body: fd,
        credentials: 'same-origin'
      }).then(function(resp){
        return resp.json().catch(function(){ return null; });
      }).then(function(data){
        if (finished) { return; }
        if (!data || data.status !== 'success') {
          if (attemptCount < maxAttempts - 2) {
            setTimeout(tick, 4000);
          } else {
            handleTimeout();
          }
          return;
        }

        var status = String(data.payment_status || '').toLowerCase();
        if (status === 'succeeded') {
          finished = true;
          var redirectTarget = data.redirect_url || pending.redirect_url || '';
          if (redirectTarget) {
            var absoluteRedirect = resolveAbsoluteUrl(redirectTarget);
            verifyRedirectUrl(absoluteRedirect).then(function(ok){
              if (ok) {
                handlePendingSuccess(pending, { skipToast: true, skipBalance: true });
                window.location.href = absoluteRedirect;
              } else {
                handlePendingSuccess(pending);
              }
            }).catch(function(){
              handlePendingSuccess(pending);
            });
          } else {
            handlePendingSuccess(pending);
          }
          return;
        }

        if (status === 'failed' || status === 'canceled' || status === 'cancelled' || status === 'expired') {
          handleFailure();
          return;
        }

        if (!processingNotified) {
          processingNotified = true;
          var processingMsg = I18N('wallet_topup_processing') || (I18N('pay_processing_message') || 'We are processing your payment. It may take a moment to finalize.');
          toast('info', processingMsg, 2400);
        }

        if (attemptCount < maxAttempts) {
          setTimeout(tick, 5000);
        } else {
          handleTimeout();
        }
      }).catch(function(){
        if (finished) { return; }
        if (attemptCount < maxAttempts) {
          setTimeout(tick, 6000);
        } else {
          handleTimeout();
        }
      });
    }

    setTimeout(tick, 1000);
  }

  function setupEventListeners() {
    document.addEventListener('click', function(ev){
      var chip = ev.target && ev.target.closest('.wallet-topup-chip');
      if (!chip) { return; }
      var form = chip.closest('.wallet-topup-form');
      if (!form) { return; }
      var amount = parseFloat(chip.dataset.amount || '0');
      if (isFinite(amount) && amount > 0) {
        var input = form.querySelector('.wallet-topup-input');
        setInputValue(input, amount);
      }
      markActiveChip(chip, form);
    });

    document.addEventListener('input', function(ev){
      if (!ev.target || !ev.target.matches('.wallet-topup-input')) { return; }
      var form = ev.target.closest('.wallet-topup-form');
      if (!form) { return; }
      var value = parseAmount(ev.target.value);
      var chips = form.querySelectorAll('.wallet-topup-chip');
      var matched = false;
      var tolerance = amountTolerance(form);
      chips.forEach(function(chip){
        var chipAmount = parseFloat(chip.dataset.amount || '0');
        if (isFinite(value) && Math.abs(chipAmount - value) < tolerance) {
          chip.classList.add('is-active');
          chip.setAttribute('aria-pressed', 'true');
          matched = true;
        } else {
          chip.classList.remove('is-active');
          chip.setAttribute('aria-pressed', 'false');
        }
      });
      if (!matched) {
        markActiveChip(null, form);
      }
    });

    document.addEventListener('change', function(ev){
      if (!ev.target || ev.target.name !== 'wallet_topup_provider') { return; }
      var form = ev.target.closest('.wallet-topup-form');
      refreshProvidersCurrency(form);
    });

    document.addEventListener('submit', submitForm, true);
  }

  function observeDom() {
    var observer = new MutationObserver(function(mutations){
      var shouldRefresh = false;
      mutations.forEach(function(mutation){
        mutation.addedNodes && mutation.addedNodes.forEach(function(node){
          if (!(node instanceof HTMLElement)) { return; }
          if (node.matches('.wallet-topup-form')) {
            initForm(node);
            shouldRefresh = true;
          }
          var innerForms = node.querySelectorAll ? node.querySelectorAll('.wallet-topup-form') : [];
          innerForms.forEach(function(inner){
            initForm(inner);
            shouldRefresh = true;
          });
        });
      });
      if (shouldRefresh) {
        scheduleBalanceRefresh(220);
      }
    });
    observer.observe(document.documentElement || document.body, { childList: true, subtree: true });
    var existing = document.querySelectorAll('.wallet-topup-form');
    existing.forEach(initForm);
    if (existing.length) {
      scheduleBalanceRefresh(120);
    }
  }

  setupEventListeners();
  observeDom();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', pollPendingTopup);
  } else {
    pollPendingTopup();
  }

})();
