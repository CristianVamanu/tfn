(function () {
  if (typeof document === 'undefined') {
    return;
  }

  var selector = '.activity-item[data-post-url]';

  function isActivationKey(event) {
    return event.key === 'Enter' || event.key === ' ' || event.key === 'Spacebar';
  }

  function resolveUrl(element) {
    if (!element) {
      return null;
    }
    var url = element.getAttribute('data-post-url');
    if (!url) {
      return null;
    }
    url = url.trim();
    return url === '' ? null : url;
  }

  document.addEventListener('click', function (event) {
    var item = event.target.closest(selector);
    if (!item) {
      return;
    }
    if (event.target.closest('a, button')) {
      return;
    }
    var url = resolveUrl(item);
    if (!url) {
      return;
    }
    window.location.href = url;
  });

  document.addEventListener('keydown', function (event) {
    if (!isActivationKey(event)) {
      return;
    }
    var item = event.target.closest(selector);
    if (!item || event.target !== item) {
      return;
    }
    var url = resolveUrl(item);
    if (!url) {
      return;
    }
    event.preventDefault();
    window.location.href = url;
  });
})();
