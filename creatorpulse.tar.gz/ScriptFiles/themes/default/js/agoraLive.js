/* Agora Live: RTC + RTM
   - Server endpoint: request/requests.php p=agora_join
   - Uses RTC for live playback/broadcast
   - Uses RTM for chat and live viewer count
   - Expects window.AgoraRTC and window.AgoraRTM (added via local vendor scripts)
*/
'use strict';
(function(){
  if (window.__agoraLiveBound) return; window.__agoraLiveBound = true;

  function qs(sel, root){ return (root||document).querySelector(sel); }
  function getCsrf(){ try { return document.querySelector('input[name="csrf_token"]').value || ''; } catch(e){ return ''; } }

  var bodyEl = document.body || null;
  var globalLiveEnabled = true;
  var globalLiveChatEnabled = true;
  try {
    if (bodyEl) {
      globalLiveEnabled = bodyEl.getAttribute('data-live-stream-enabled') !== '0';
      globalLiveChatEnabled = bodyEl.getAttribute('data-live-chat-enabled') !== '0';
    }
  } catch(_){ }
  if (!globalLiveEnabled) {
    return;
  }
  var I18N = (window.DZ && typeof DZ.i18n === 'function') ? DZ.i18n : function(){ return ''; };

  function showToast(message, type){
    try {
      if (window.DZ && typeof DZ.toast === 'function') {
        DZ.toast(String(message || ''), { type: type || 'info', duration: 2600 });
      }
    } catch(_){ }
  }

  // Shared refs for graceful teardown
  window.__agoraRtcRef = window.__agoraRtcRef || null; // { client, role, localTracks: [mic, cam] | null }
  window.__agoraRtmRef = window.__agoraRtmRef || null; // { rtm, channel }
  let __agoraLeaving = false;

  var buildUrl = (window.DZ && window.DZ.buildUrl) || function(path){
    try { var base=(typeof window.site_url==='string'&&window.site_url)?window.site_url:(window.location.origin+window.location.pathname.replace(/[^\/]*$/,'')); if(base.slice(-1)!=='/') base+='/'; return new URL(String(path||'').replace(/^\//,''), base).toString(); } catch(_) { return String(path||''); }
  };

  // Shared redirect helper so both RTC and RTM paths can use it
  function __resolveOwnerRedirectUrl(){
    try {
      var box = document.querySelector('.contents_box[data-owner-url]');
      var ownerUrl = box ? (box.getAttribute('data-owner-url') || '') : '';
      if (ownerUrl) return ownerUrl;
    } catch(e){}
    try { if (typeof site_url === 'string' && site_url) return site_url; } catch(_){}
    return '/';
  }
  let __agoraEndedRedirected = false;
  function showLiveEndedPopup(redirectUrl){
    try { var old = document.getElementById('liveEndedOverlay'); if (old) old.parentNode.removeChild(old); } catch(_){ }
    var ov = document.createElement('div'); ov.id='liveEndedOverlay'; ov.className='live-ended-overlay';
    var box = document.createElement('div'); box.className='live-ended-modal';
    var title = document.createElement('div'); title.className='live-ended-title'; title.textContent = 'Live has ended';
    var desc = document.createElement('div'); desc.className='live-ended-desc'; desc.textContent = 'You will be redirected shortly…';
    var actions = document.createElement('div'); actions.className='live-ended-actions';
    var btn = document.createElement('button'); btn.type='button'; btn.className='btn-go'; btn.textContent='Go now';
    actions.appendChild(btn); box.appendChild(title); box.appendChild(desc); box.appendChild(actions); ov.appendChild(box);
    document.body.appendChild(ov);
    var to = (typeof redirectUrl === 'string' && redirectUrl) ? redirectUrl : __resolveOwnerRedirectUrl();
    var timer = setTimeout(function(){ try { window.location.href = to; } catch(_){ } }, 2500);
    btn.addEventListener('click', function(){ try { clearTimeout(timer); } catch(_){ } try { window.location.href = to; } catch(_){ } });
  }
  window.__agoraEndAndRedirect = async function(url){
    if (__agoraEndedRedirected) return; __agoraEndedRedirected = true;
    // Leave RTC/RTM gracefully
    try { if (window.agoraLeave) { await window.agoraLeave(); } } catch(_){ }
    // Show popup for viewers (not owner). Owners go immediately.
    try {
      var root = document.querySelector('.contents_box[data-is-owner]');
      var isOwner = root ? (root.getAttribute('data-is-owner') === '1') : false;
      if (!isOwner) { showLiveEndedPopup(url); return; }
    } catch(_){ }
    var to = (typeof url === 'string' && url) ? url : __resolveOwnerRedirectUrl();
    try { window.location.href = to; } catch(_){ }
  };

  // Public helper to leave RTC + RTM cleanly
  window.agoraLeave = async function(){
    if (__agoraLeaving) return; __agoraLeaving = true;
    try {
      const rtmRef = window.__agoraRtmRef;
      if (rtmRef && rtmRef.channel) { try { await rtmRef.channel.leave(); } catch(_){} }
      if (rtmRef && rtmRef.rtm)     { try { await rtmRef.rtm.logout(); } catch(_){} }
    } catch(_){}
    window.__agoraRtmRef = null;
    try {
      const rtcRef = window.__agoraRtcRef;
      if (rtcRef) {
        const tracks = rtcRef.localTracks || [];
        for (let i=0;i<tracks.length;i++){
          try { tracks[i].stop && tracks[i].stop(); } catch(_){}
          try { tracks[i].close && tracks[i].close(); } catch(_){}
        }
        if (rtcRef.client) { try { await rtcRef.client.leave(); } catch(_){} }
      }
    } catch(_){}
    window.__agoraRtcRef = null;
  };

  function init(){
    var root = qs('.live-content');
    if (!root) return;
    var liveId = parseInt((qs('[data-live-id]')?.getAttribute('data-live-id') || '0'), 10) || 0;
    if (!liveId) return;

    // If RTC is disabled (no local SDK or runtime unavailable), show a subtle hint and stop early.
    if (window.DZ_RTC_DISABLED === true) {
      try {
        var player = qs('.live-player');
        if (player) {
          var note = document.createElement('div');
          note.className = 'live-muted';
          var txt = '';
          try {
            if (window.DZ && DZ.i18n) {
              txt = DZ.i18n('rtc_unavailable_offline') || DZ.i18n('rtx_unavailable_offline') || '';
            }
          } catch(_){ }
          note.textContent = txt || 'Live video is unavailable offline.'; // i18n-ready fallback
          player.appendChild(note);
        }
      } catch(_){}
      return;
    }

    // Start tip polling immediately so broadcaster sees toasts even if RTC/RTM setup delays
    try { startTipPolling(liveId); } catch(_){ }

    // Ask server for join info
    var fd = new FormData();
    fd.append('p','agora_join');
    fd.append('live_id', String(liveId));
    fd.append('csrf_token', getCsrf());

    fetch(buildUrl('request/requests.php'), { method:'POST', body: fd, credentials:'same-origin' })
      .then(r => r.json())
      .then(j => {
        if (!j || j.status !== 'success' || !j.data){
          var code = (j && typeof j.message === 'string') ? j.message : '';
          if (code === 'live_capacity_reached') {
            showToast(I18N('live_capacity_reached') || 'This live room is at capacity.', 'info');
          } else if (code === 'live_stream_disabled') {
            showToast(I18N('live_stream_disabled_public') || 'Live streaming is currently disabled.', 'info');
          } else if (code) {
            showToast(I18N(code) || String(code), 'error');
          } else {
            showToast(I18N('live_join_failed') || 'Unable to join the live stream.', 'error');
          }
          console.warn('[Agora] join payload error:', j);
          return;
        }
        try {
          const d = j.data || {};
          console.info('[Agora] Join payload', {
            appId: d.appId,
            channel: d.channel,
            uid: d.uid,
            role: d.role,
            region: d.region || 'GLOBAL',
            debug: !!d.debug,
            tokenPreview: d.token ? (String(d.token).slice(0, 12) + '…') : null,
            meta: d.meta || null,
          });
        } catch(e){}
        mountAgora(j.data);
      }).catch((e)=>{
        console.error('[Agora] join request failed', e);
        showToast(I18N('live_join_failed') || 'Unable to join the live stream.', 'error');
      });

    // Start lightweight heartbeat so server-side viewer count can work even without RTM
    try { startViewerHeartbeat(liveId); } catch(_){ }
  }

  async function mountAgora(info){
    var player = qs('.live-player');
    if (!player) return;
    var host = qs('#liveVideoHost', player);
    if (!host) {
      host = document.createElement('div');
      host.id = 'liveVideoHost';
      host.style.position = 'absolute'; host.style.inset = '0';
      player.appendChild(host);
    }

    if (!window.AgoraRTC) {
      // Provide a friendly message without breaking UI
      var m = document.createElement('div');
      m.className = 'live-muted';
      m.textContent = 'Agora SDK not loaded. Please include AgoraRTC script.';
      player.appendChild(m);
      return;
    }

    // Debug: intercept Agora network requests to verify appid actually sent
    try {
      if (!window.__agoraNetIntercept) {
        window.__agoraNetIntercept = true;
        // Fetch
        var _fetch = window.fetch;
        window.fetch = function(url, opts){
          try {
            var u = (typeof url === 'string') ? url : (url && url.url ? url.url : String(url));
            if (u && u.indexOf('agora.io') !== -1) {
              if (window.DZ_DEBUG) { console.info('[Agora][net][fetch]', u); }
            }
          } catch(e){}
          return _fetch.apply(this, arguments);
        };
        // XHR
        var _open = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function(method, url){
          try {
            var u = String(url || '');
            if (u && u.indexOf('agora.io') !== -1) {
              if (window.DZ_DEBUG) { console.info('[Agora][net][xhr]', method, u); }
            }
          } catch(e){}
          return _open.apply(this, arguments);
        };
      }
    } catch(e){}

    function showMsg(text){
      try {
        var m = document.createElement('div');
        m.className = 'live-muted';
        m.textContent = String(text || '');
        player.appendChild(m);
      } catch(e){}
    }

    try {
      const client = AgoraRTC.createClient({ mode: 'live', codec: 'vp8' });
      client.on('connection-state-change', (cur, prev, reason) => {
        if (window.DZ_DEBUG) { console.debug('[Agora] connection state', { prev, cur, reason }); }
      });
      if (info.role === 'host') { client.setClientRole('host'); } else { client.setClientRole('audience'); }

      // Sanity: token header appId vs payload appId
      var appIdToUse = String(info.appId || '');
      try {
        var tok = String(info.token || '');
        if (tok.startsWith('007') && tok.length > 35) {
          var tokenAppId = tok.substring(3, 35);
          if (appIdToUse && tokenAppId && appIdToUse !== tokenAppId) {
            console.error('[Agora] appId mismatch between token and payload', { tokenAppId, appId: appIdToUse });
          }
          // Prefer the App ID embedded in token to avoid inconsistency
          if (tokenAppId) { appIdToUse = tokenAppId; }
        }
      } catch(e){}

      let joined = false;
      let usedFallback = false;
      const joinUid = (/^\d+$/.test(String(info.uid))) ? Number(info.uid) : String(info.uid);
      try {
        console.info('[Agora] Using appId to join', {
          appId: appIdToUse,
          channel: info.channel,
          uid: joinUid,
          tokenPrefix: (String(info.token||'').slice(0, 12) || null)
        });
      } catch(e){}
      try {
        await client.join(appIdToUse, info.channel, info.token, joinUid);
        joined = true;
      } catch (joinErr) {
        console.error('[Agora] join failed', joinErr);
        // Security-first: only fallback to tokenless join if server allowed explicitly
        // or debug mode is on. Useful when project certificate is disabled but token was provided.
        var msg = (joinErr && joinErr.message) ? String(joinErr.message) : '';
        // Be lenient: treat 1/'1'/true as enabled
        var allowFallback = !!(info && (info.allow_tokenless || info.debug));
        if (allowFallback) {
          try {
            console.warn('[Agora] retrying join without token (debug mode)…');
            await client.join(appIdToUse, info.channel, null, joinUid);
            usedFallback = true;
            joined = true;
          } catch (joinErr2) {
            console.error('[Agora] fallback join failed', joinErr2);
            showMsg('Join failed: ' + (joinErr2 && joinErr2.message ? joinErr2.message : 'unknown error'));
            return;
          }
        } else {
          showMsg('Join failed: ' + (joinErr && joinErr.message ? joinErr.message : 'unknown error'));
          return;
        }
        if (!joined) {
          showMsg('Join failed: ' + (joinErr && joinErr.message ? joinErr.message : 'unknown error'));
          return;
        }
      }
      if (usedFallback) { console.info('[Agora] joined successfully without token'); }

      // Expose RTC ref for teardown
      window.__agoraRtcRef = { client: client, role: info.role, localTracks: null };

      if (info.role === 'host') {
        const localTrack = await AgoraRTC.createMicrophoneAndCameraTracks();
        const container = document.createElement('div');
        container.id = 'agora-local';
        container.style.width = '100%';
        container.style.height = '100%';
        host.innerHTML = '';
        host.appendChild(container);
        localTrack[1].play('agora-local');
        await client.publish(localTrack);
        hideStartingOverlay();
        // Save local tracks for later stop/close
        try { window.__agoraRtcRef.localTracks = localTrack; } catch(_){}
      } else {
        let hostUid = null;
        client.on('user-published', async (user, mediaType) => {
          await client.subscribe(user, mediaType);
          if (mediaType === 'video') {
            const container = document.createElement('div');
            container.id = 'agora-remote-' + user.uid;
            container.style.width = '100%';
            container.style.height = '100%';
            host.innerHTML = '';
            host.appendChild(container);
            // Ensure remote video is NOT mirrored for viewers
            try { user.videoTrack.play(container.id, { mirror: false }); }
            catch(_){ user.videoTrack.play(container.id); }
            hideStartingOverlay();
            if (hostUid === null) { hostUid = user.uid; }
          }
          if (mediaType === 'audio') { user.audioTrack.play(); }
        });
        // If host stops publishing or leaves, redirect viewers
        client.on('user-unpublished', (user, mediaType) => {
          try {
            if (hostUid !== null && String(user.uid) === String(hostUid)) {
              // Avoid false positives on quick republish by delaying briefly
              setTimeout(() => { window.__agoraEndAndRedirect && window.__agoraEndAndRedirect(); }, 800);
            }
          } catch(_){}
        });
        client.on('user-left', (user) => {
          try {
            if (hostUid !== null && String(user.uid) === String(hostUid)) {
              setTimeout(() => { window.__agoraEndAndRedirect && window.__agoraEndAndRedirect(); }, 200);
            }
          } catch(_){}
        });
      }

      // RTM (chat + viewers). Even if RTM aktif, tip polling is already running
      try { await startRTM(info); } catch (e){ console.warn('RTM init failed', e); }

      // Likes/viewers polling (fallback)
      try { if (!window.__rtmActive) { startLikePolling(); } } catch(_){ startLikePolling(); }
    } catch (e){
      console.error('[Agora] init error', e);
      var m = document.createElement('div');
      m.className = 'live-muted';
      m.textContent = 'Failed to initialize live playback.';
      player.appendChild(m);
    }
  }

  // ===== RTM (Chat + Viewer Count) =====
  async function startRTM(info){
    if (!globalLiveChatEnabled) {
      window.__rtmActive = false;
      return;
    }
    if (window.DZ_RTM_DISABLED === true || !window.AgoraRTM) {
      try {
        // Subtle hint that live RTM chat is offline
        var root = document.querySelector('.live-chat');
        if (root) {
          var note = document.createElement('div');
          note.className = 'live-muted';
          var t = (window.DZ && DZ.i18n) ? (DZ.i18n('rtm_unavailable_offline') || '') : '';
          note.textContent = t || 'Live chat is unavailable offline.';
          root.insertBefore(note, root.firstChild);
        }
      } catch(_){ }
      return;
    }
    window.__rtmActive = true;
    // Derive appId for RTM from RTM token if available (007...), else use payload appId
    let rtmAppId = String(info.appId || '');
    try {
      const t = String(info.rtm_token || '');
      if (t.startsWith('007') && t.length > 35) {
        const embedded = t.substring(3, 35);
        if (embedded) { rtmAppId = embedded; }
      }
    } catch(_){}
    const rtm = AgoraRTM.createInstance(rtmAppId, { enableLogUpload: false });
    try {
      await rtm.login({ uid: String(info.uid), token: info.rtm_token });
    } catch (e) {
      // If RTM login fails, disable RTM features and rely on polling
      window.__rtmActive = false;
      console.warn('RTM login failed, falling back to polling', e);
      return;
    }
    const channel = rtm.createChannel(info.channel);
    try {
      await channel.join();
    } catch (e) {
      window.__rtmActive = false;
      console.warn('RTM join failed, falling back to polling', e);
      return;
    }
    // Mark RTM active after successful join
    window.__rtmActive = true;
    // Save RTM ref for teardown
    try { window.__agoraRtmRef = { rtm, channel, myUid: String(info.uid) }; } catch(_){}

    // Viewer count
    const vcEl = document.getElementById('viewerCount');
    async function refreshCount(){
      try {
        const members = await channel.getMembers();
        // Exclude broadcaster from viewer count. RTM includes self in members list.
        var viewers = Math.max(0, (members ? members.length : 0) - 1);
        if (vcEl) vcEl.textContent = String(viewers);
        try { var vc2 = document.getElementById('viewerCountBottom'); if (vc2) vc2.textContent = String(viewers); } catch(_){ }
      } catch(e){}
    }
    channel.on('MemberJoined', refreshCount);
    channel.on('MemberLeft', refreshCount);
    await refreshCount();

    // Chat inbound
    const chatBody = document.getElementById('liveChatBody');
    function appendMessage(from, text){
      if (!chatBody) return;
      const div = document.createElement('div');
      div.className = 'live-chat-msg';
      const f = document.createElement('span'); f.className = 'from'; f.textContent = from;
      const m = document.createElement('span'); m.className = 'msg'; m.textContent = ' ' + text;
      div.appendChild(f); div.appendChild(m);
      chatBody.appendChild(div);
      chatBody.scrollTop = chatBody.scrollHeight;
    }

    channel.on('ChannelMessage', ({ text }, memberId) => {
      var msg = String(text || '');
      // System: live ended
      if (msg === 'LIVE_ENDED') {
        var sysLbl = (window.DZ && DZ.i18n) ? (DZ.i18n('live_chat_system') || 'System') : 'System';
        var endedLbl = (window.DZ && DZ.i18n) ? (DZ.i18n('live_ended') || 'Live ended') : 'Live ended';
        appendMessage(sysLbl, endedLbl);
        if (window.__agoraEndAndRedirect) window.__agoraEndAndRedirect();
        return;
      }
      try {
        var parsed = JSON.parse(msg);
        if (parsed && parsed.type === 'live_ended') {
          var sysLbl2 = (window.DZ && DZ.i18n) ? (DZ.i18n('live_chat_system') || 'System') : 'System';
          var endedLbl2 = (window.DZ && DZ.i18n) ? (DZ.i18n('live_ended') || 'Live ended') : 'Live ended';
          appendMessage(sysLbl2, endedLbl2);
          if (window.__agoraEndAndRedirect) window.__agoraEndAndRedirect(String(parsed.redirect || ''));
          return;
        }
        if (parsed && parsed.type === 'live_like') {
          // Ignore my own message if SDK loops back (usually it doesn't)
          try { if (String(memberId) === String(window.__agoraRtmRef?.myUid)) return; } catch(_){ }
          // Update counters
          try {
            var likeCount = (typeof parsed.likes === 'number') ? parsed.likes : null;
            if (likeCount !== null) {
              var c1 = document.getElementById('liveLikeCount');
              var c2 = document.getElementById('liveLikeTotal');
              if (c1) c1.textContent = String(likeCount);
              if (c2) c2.textContent = String(likeCount);
            }
          } catch(_){ }
          // Floating hearts on like
          if (parsed.liked) {
            try {
              var host = document.getElementById('liveHeartStream');
              if (host) {
                // Minimal local heart spawn (mirrors CSS in style.css)
                var n = 4; for (var i=0;i<n;i++) (function(idx){ setTimeout(function(){
                  var span = document.createElement('span'); span.className='f-heart';
                  var size = 16 + Math.round(Math.random()*10);
                  var tx = -10 - Math.round(Math.random()*40);
                  var dur = 1200 + Math.round(Math.random()*700);
                  span.style.setProperty('--tx', tx+'px'); span.style.setProperty('--dur', dur+'ms'); span.style.setProperty('--scale', (0.9+Math.random()*0.4).toFixed(2));
                  span.innerHTML = '<svg viewBox="0 0 48 48" width="'+size+'" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="rtm_like_grad" gradientTransform="rotate(35)"><stop offset="0%" stop-color="#FF7A00"/><stop offset="40%" stop-color="#FF0169"/><stop offset="100%" stop-color="#D300C5"/></linearGradient></defs><path fill="url(#rtm_like_grad)" d="M34.6 3.1c-4.5 0-7.9 1.8-10.6 5.6-2.7-3.7-6.1-5.5-10.6-5.5C6 3.1 0 9.6 0 17.6c0 7.3 5.4 12 10.6 16.5.6.5 1.3 1.1 1.9 1.7l2.3 2c4.4 3.9 6.6 5.9 7.6 6.5.5.3 1.1.5 1.6.5s1.1-.2 1.6-.5c1-.6 2.8-2.2 7.8-6.8l2-1.8c.7-.6 1.3-1.2 2-1.7C42.7 29.6 48 25 48 17.6c0-8-6-14.5-13.4-14.5z"/></svg>';
                  host.appendChild(span);
                  span.addEventListener('animationend', function(){ if (span.parentNode) span.parentNode.removeChild(span); });
                }, idx*120); })(i);
              }
            } catch(_){ }
          }
          return;
        }
        if (parsed && parsed.type === 'live_tip') {
          try {
            var root = document.querySelector('.contents_box[data-tip-threshold]');
            var thr = 50; try { thr = parseFloat(root.getAttribute('data-tip-threshold')) || 50; } catch(_){ }
            var tipper = String(parsed.buyer || 'Someone');
            var amt = parseFloat(parsed.amount || 0) || 0;
            var cur = String(parsed.currency || '$');
            if (shouldDisplayTip(tipper, amt, cur, Math.floor(Date.now()/1000))) {
              showLiveTipToast(tipper, amt, cur);
              if (amt >= thr) { spawnConfetti(); }
            }
          } catch(_){ }
          return;
        }
      } catch(_){ /* not JSON */ }
      appendMessage(String(memberId), msg);
    });

    // Chat outbound
    const form = document.getElementById('liveChatForm');
    const input = document.getElementById('liveChatInput');
    if (form && input) {
      form.addEventListener('submit', async function(ev){
        ev.preventDefault();
        const t = (input.value || '').trim();
        if (!t) return;
        try {
          await channel.sendMessage({ text: t });
          appendMessage('You', t);
          input.value = '';
        } catch(e){ console.warn('send failed', e); }
      });
    }

    // Clean up on unload
    window.addEventListener('beforeunload', function(){ try { window.agoraLeave && window.agoraLeave(); } catch(e){} });
  }

  // ===== Fallback: poll like count periodically when RTM is unavailable =====
  function startLikePolling(){
    try { if (window.__liveLikePoll) return; } catch(_){ }
    var box = document.querySelector('.contents_box[data-live-id]');
    var liveId = 0; try { liveId = parseInt((box && box.getAttribute('data-live-id')) || '0', 10) || 0; } catch(_){ }
    if (!liveId) return;
    var endpoint = buildUrl('request/requests.php?p=live_stats&live_id=' + encodeURIComponent(String(liveId)));
    var last = null;
    function tick(){
      fetch(endpoint, { credentials:'same-origin' })
        .then(function(r){ return r.json(); })
        .then(function(j){
          if (!j || j.status !== 'success') return;
          var likes = (typeof j.likes === 'number') ? j.likes : 0;
          var viewers = (typeof j.viewers === 'number') ? j.viewers : null;
          var c1 = document.getElementById('liveLikeCount');
          var c2 = document.getElementById('liveLikeTotal');
          var prev = last;
          last = likes;
          if (c1) c1.textContent = String(likes);
          if (c2) c2.textContent = String(likes);
          if (viewers !== null) {
            try { var vTop = document.getElementById('viewerCount'); if (vTop) vTop.textContent = String(viewers); } catch(_){ }
            try { var vBot = document.getElementById('viewerCountBottom'); if (vBot) vBot.textContent = String(viewers); } catch(_){ }
          }
          if (prev !== null && likes > prev) {
            var host = document.getElementById('liveHeartStream');
            if (host) {
              var delta = Math.min(6, Math.max(1, likes - prev));
              for (var i=0;i<delta;i++) (function(idx){ setTimeout(function(){
                var span = document.createElement('span'); span.className='f-heart';
                var size = 16 + Math.round(Math.random()*10);
                var tx = -10 - Math.round(Math.random()*40);
                var dur = 1200 + Math.round(Math.random()*700);
                span.style.setProperty('--tx', tx+'px'); span.style.setProperty('--dur', dur+'ms'); span.style.setProperty('--scale', (0.9+Math.random()*0.4).toFixed(2));
                span.innerHTML = '<svg viewBox="0 0 48 48" width="'+size+'" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="poll_like_grad" gradientTransform="rotate(35)"><stop offset="0%" stop-color="#FF7A00"/><stop offset="40%" stop-color="#FF0169"/><stop offset="100%" stop-color="#D300C5"/></linearGradient></defs><path fill="url(#poll_like_grad)" d="M34.6 3.1c-4.5 0-7.9 1.8-10.6 5.6-2.7-3.7-6.1-5.5-10.6-5.5C6 3.1 0 9.6 0 17.6c0 7.3 5.4 12 10.6 16.5.6.5 1.3 1.1 1.9 1.7l2.3 2c4.4 3.9 6.6 5.9 7.6 6.5.5.3 1.1.5 1.6.5s1.1-.2 1.6-.5c1-.6 2.8-2.2 7.8-6.8l2-1.8c.7-.6 1.3-1.2 2-1.7C42.7 29.6 48 25 48 17.6c0-8-6-14.5-13.4-14.5z"/></svg>';
                host.appendChild(span);
                span.addEventListener('animationend', function(){ if (span.parentNode) span.parentNode.removeChild(span); });
              }, idx*120); })(i);
            }
          }
        }).catch(function(){ /* ignore */ });
    }
    tick();
    window.__liveLikePoll = setInterval(tick, 3000);
    window.addEventListener('beforeunload', function(){ try { clearInterval(window.__liveLikePoll); } catch(_){ } });
  }

  // ===== Tip toast + confetti =====
  // Map currency to symbol (fallback to code)
  function tipSymbol(cur){
    var c = (cur||'').toString().toUpperCase();
    if (c === '$' || c === 'USD') return '$';
    if (c === 'EUR' || c === '€') return '€';
    if (c === 'GBP' || c === '£') return '£';
    if (c === 'TRY' || c === 'TL' || c === '₺') return '₺';
    if (c === 'JPY' || c === '¥') return '¥';
    return c || '$';
  }
  function formatAmount(a){
    var n = parseFloat(a||0);
    if (!isFinite(n)) n = 0;
    return Math.abs(n - Math.round(n)) < 1e-9 ? String(Math.round(n)) : String((Math.round(n*100)/100).toFixed(2));
  }
  function showLiveTipToast(name, amount, currency){
    try {
      var host = document.getElementById('liveTipStream'); if (!host) return;
      var toast = document.createElement('div'); toast.className='tip-toast';
      var nameEl = document.createElement('span'); nameEl.className='tip-name'; nameEl.textContent = String(name);
      var txtEl = document.createElement('span'); txtEl.className='tip-text'; txtEl.textContent = ' sent ';
      var amtEl = document.createElement('span'); amtEl.className='tip-amount';
      var sym = tipSymbol(currency);
      amtEl.textContent = formatAmount(amount) + sym; // 10$
      var txt2 = document.createElement('span'); txt2.textContent = ' tip';
      toast.appendChild(nameEl); toast.appendChild(txtEl); toast.appendChild(amtEl); toast.appendChild(txt2);
      host.appendChild(toast);
      setTimeout(function(){ toast.style.opacity='0'; toast.style.transform='translateY(-6px)'; }, 2800);
      setTimeout(function(){ if (toast && toast.parentNode) toast.parentNode.removeChild(toast); }, 3600);
    } catch(_){ }
  }
  function spawnConfetti(){
    try {
      var player = document.querySelector('.live-player'); if (!player) return;
      var colors = ['#f87171','#60a5fa','#34d399','#fbbf24','#a78bfa','#f472b6'];
      for (var i=0;i<26;i++){
        (function(idx){
          var p = document.createElement('div'); p.className='confetti-piece';
          p.style.left = (5 + Math.random()*90) + '%';
          p.style.top = '-6px';
          p.style.background = colors[Math.floor(Math.random()*colors.length)];
          p.style.animation = 'confettiFall ' + (800 + Math.round(Math.random()*900)) + 'ms ease-out forwards';
          p.style.transform = 'rotate(' + (Math.random()*360) + 'deg)';
          player.appendChild(p);
          setTimeout(function(){ if (p && p.parentNode) p.parentNode.removeChild(p); }, 1600);
        })(i);
      }
    } catch(_){ }
  }
  // expose for other modules (e.g., tipsHandler) when RTM is off
  try { window.showLiveTipToast = showLiveTipToast; window.spawnConfetti = spawnConfetti; } catch(_){ }

  // ===== Viewer heartbeat to backend (works for both host and audience) =====
  function startViewerHeartbeat(liveId){
    try { if (window.__livePingTimer) return; } catch(_){ }
    var endpoint = buildUrl('request/requests.php?p=live_ping&live_id=' + encodeURIComponent(String(liveId)));
    function ping(){ fetch(endpoint, { credentials:'same-origin' }).catch(function(){}); }
    ping();
    window.__livePingTimer = setInterval(ping, 7000); // 7s faster drop
    window.addEventListener('beforeunload', function(){ try { clearInterval(window.__livePingTimer); } catch(_){ } });
  }

  // ===== Tip polling fallback (when RTM is unavailable) =====
  function startTipPolling(liveId){
    try { if (window.__liveTipPoll) return; } catch(_){ }
    var since = 0; // start from live started_at (server clamps); dedup prevents repeats
    try { if (typeof window.__liveTipPollSince === 'number') since = window.__liveTipPollSince; } catch(_){ }
    var endpointBase = (typeof site_url !== 'undefined' && site_url ? site_url : '/');
    function tick(){
      var url = buildUrl('request/requests.php?p=live_tips&live_id=' + encodeURIComponent(String(liveId)) + '&since=' + encodeURIComponent(String(since)));
      fetch(url, { credentials:'same-origin' })
        .then(function(r){ return r.json(); })
        .then(function(j){
          if (!j || j.status !== 'success') return;
          var tips = Array.isArray(j.tips) ? j.tips : [];
          if (tips.length){
            var root = document.querySelector('.contents_box[data-tip-threshold]');
            var thr = 50; try { thr = parseFloat(root.getAttribute('data-tip-threshold')) || 50; } catch(_){ }
            tips.forEach(function(t){
              var buyer = t.buyer || 'Someone'; var amt = parseFloat(t.amount||0) || 0; var cur = t.currency || 'USD';
              if (shouldDisplayTip(buyer, amt, cur)) {
                if (typeof window.showLiveTipToast === 'function') { window.showLiveTipToast(buyer, amt, cur); }
                try { if (amt >= thr && typeof window.spawnConfetti === 'function') { window.spawnConfetti(); } } catch(_){ }
              }
            });
          }
          if (typeof j.since === 'number') { since = Math.max(since, j.since, (window.__liveTipPollSince||0)); }
          window.__liveTipPollSince = since;
        }).catch(function(){ /* ignore */ });
    }
    tick();
    window.__liveTipPoll = setInterval(tick, 3000);
    window.addEventListener('beforeunload', function(){ try { clearInterval(window.__liveTipPoll); } catch(_){ } });
  // ===== Dedup helpers for tips (avoid double toast from RTM + polling) =====
  function normCur(c){
    try { var s = String(c||'').trim(); if (s === '' || s === '$') return 'USD'; return s.toUpperCase(); } catch(_){ return 'USD'; }
  }
  function tipKeyNoTime(buyer, amount, currency){
    return [String(buyer||'').toLowerCase(), normCur(currency), String(Math.round((parseFloat(amount)||0)*100))].join('|');
  }

  function maybeShowLiveTip(buyer, amount, currency){
    try {
      var root = document.querySelector('.contents_box[data-tip-threshold]');
      var thr = 50; try { thr = parseFloat(root.getAttribute('data-tip-threshold')) || 50; } catch(_){ }
      var nowTs = Math.floor(Date.now()/1000);
      if (shouldDisplayTip(buyer, amount, currency, nowTs)) {
        showLiveTipToast(buyer || 'Someone', parseFloat(amount||0)||0, currency || 'USD');
        if ((parseFloat(amount||0)||0) >= thr) { spawnConfetti(); }
      }
    } catch(_){ }
  }
  try { window.maybeLiveTip = maybeShowLiveTip; } catch(_){ }
  function shouldDisplayTip(buyer, amount, currency){
    try {
      var now = Math.floor(Date.now()/1000);
      window.__tipSeenMap = window.__tipSeenMap || new Map();
      var k = tipKeyNoTime(buyer, amount, currency);
      var last = window.__tipSeenMap.get(k);
      var THRESH = 20; // seconds; suppress repeats within 20s
      if (typeof last === 'number' && (now - last) < THRESH) return false;
      window.__tipSeenMap.set(k, now);
      try { window.__liveTipPollSince = Math.max(window.__liveTipPollSince||0, now); } catch(_){ }
      return true;
    } catch(_){ return true; }
  }
  }

    function hideStartingOverlay(){
      try {
        var t = document.querySelector('.live-player .text-center');
        if (t) t.style.display = 'none';
      } catch(_){ }
    }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
