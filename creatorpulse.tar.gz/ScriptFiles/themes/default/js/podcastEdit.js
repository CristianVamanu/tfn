(function ($, window, document) {
    "use strict";

    var ENDPOINT = (typeof window.buildUrl === 'function')
        ? window.buildUrl('request/requests.php')
        : ((typeof window.site_url !== 'undefined' && window.site_url) ? (window.site_url + 'request/requests.php') : 'request/requests.php');
    var I18N = (window.DZ && typeof DZ.i18n === 'function') ? DZ.i18n : function(){ return ''; };

    var state = {
        audioUrl: '',
        duration: null,
        fileName: '',
        coverFile: null,
        coverBlob: null,
        coverName: '',
        categoryId: ''
    };

    function getRoot(node) {
        var $el = node ? $(node) : $();
        if ($el.length) {
            var $closest = $el.closest('.popUp-container');
            if ($closest.length) {
                return $closest;
            }
        }
        var $fallback = $('.popUp-container').last();
        return $fallback.length ? $fallback : $();
    }

    function toast(msg, type) {
        if (!msg) { return; }
        if (window.DZ && typeof DZ.toast === 'function') {
            DZ.toast(String(msg), { type: type || 'info', duration: 2600 });
            return;
        }
        alert(String(msg));
    }

    function decodeHtmlPayload(html, encoding) {
        var trimmed = (html || '').toString().trim();
        if (!trimmed) { return ''; }
        if (encoding && encoding.toLowerCase() === 'base64') {
            try {
                return atob(trimmed);
            } catch (_) {
                return '';
            }
        }
        return trimmed;
    }

    function setStep(root, step) {
        var $root = getRoot(root);
        if (!$root.length) { return; }
        var $createBox = $root.find('.create_media_box');
        var $finishBox = $root.find('.finish_podcast_container');
        var $goBack = $root.find('#podcastGoBack');
        var $uploadBtn = $root.find('#podcastUploadBtn');
        var $header = $root.find('.click_box_header');

        if (step === 'finish') {
            $createBox.addClass('none');
            $finishBox.removeClass('none');
            $goBack.removeClass('none');
            $uploadBtn.removeClass('none');
            if ($header.length) {
                $header.addClass('is-finish');
            }
        } else {
            $createBox.removeClass('none');
            $finishBox.addClass('none');
            $goBack.addClass('none');
            $uploadBtn.addClass('none');
            if ($header.length) {
                $header.removeClass('is-finish');
            }
        }
    }

    function resetState(root) {
        var $root = getRoot(root);
        if (!$root.length) { return; }
        state.audioUrl = '';
        state.duration = null;
        state.fileName = '';
        state.coverFile = null;

        $root.find('#podcastFileInput').val('');
        $root.find('#podcastCoverInput').val('');
        $root.find('.podcast-file-name').text('');
        $root.find('.podcast-duration').text('');
        $root.find('.podcast-cover-name').text('');
        $root.find('#podcastAudioPreview source').attr('src', '');
        var audioEl = $root.find('#podcastAudioPreview').get(0);
        if (audioEl && typeof audioEl.load === 'function') {
            audioEl.load();
        }
        $root.find("textarea[name='post_text']").val('');
        $root.find("input[name='set-price']").val('');
        $root.find(".post-visiblity").removeClass('active');
        $root.find(".post-visiblity[data-type='everyone']").addClass('active');
        $root.find("input[name='post_type']").val('everyone');
        $root.find(".podcast-price-row").addClass('none');
        $root.find('.podcast-price-error').addClass('none');
        $root.find('#podcast_hide_likes_view, #podcast_turn_on_off_comment').prop('checked', false).val('off');
        $root.find('#podcastCategorySelect').val('');
        state.categoryId = '';

        setStep($root, 'select');
    }

    function updateVisibilitySelection($option) {
        var $root = getRoot($option);
        var type = ($option.data('type') || 'everyone').toString();
        var $container = $option.closest('.popUp-container');
        var isCreator = $container.data('is-creator') === 1 || $container.data('is-creator') === '1';
        var paymentsActive = $container.data('payments-active') === 1 || $container.data('payments-active') === '1';
        var creatorMessage = $container.data('creator-message') || '';
        var creatorAction = $container.data('creator-action') || '';
        var creatorUrl = $container.data('creator-url') || '';
        var paymentsMessage = $container.data('payments-message') || '';

        if ((type === 'locked' || type === 'subscribers') && !isCreator) {
            toast(creatorMessage || 'Only approved creators can use this visibility.', 'error');
            if (creatorUrl) {
                window.location.href = creatorUrl;
            }
            return;
        }
        if (type === 'locked' && !paymentsActive) {
            toast(paymentsMessage || 'Payments are currently disabled.', 'error');
            return;
        }

        $root.find('.post-visiblity').removeClass('active');
        $option.addClass('active');
        $root.find("input[name='post_type']").val(type);
        if (type === 'locked') {
            $root.find('.podcast-price-row').removeClass('none');
        } else {
            $root.find('.podcast-price-row').addClass('none');
            $root.find('.podcast-price-error').addClass('none');
        }
    }

    function validatePrice($root) {
        var type = $root.find("input[name='post_type']").val() || 'everyone';
        if (type !== 'locked') { return true; }
        var min = parseInt($root.find("input[name='min-price']").val() || '1', 10);
        var max = parseInt($root.find("input[name='max-price']").val() || '0', 10);
        var priceRaw = $.trim($root.find("input[name='set-price']").val() || '');
        var $error = $root.find('.podcast-price-error');
        if (priceRaw === '') {
            $error.removeClass('none').addClass('form-warning');
            return false;
        }
        var price = parseInt(priceRaw, 10);
        if (!Number.isFinite(price) || price < min || price > max) {
            $error.removeClass('none').addClass('form-warning');
            return false;
        }
        $error.addClass('none').removeClass('form-warning');
        return true;
    }

    function handleUploadSuccess(payload, $root) {
        $root = getRoot($root);
        if (!$root || !$root.length || !payload || payload.status !== 'success' || !payload.audio_url) {
            toast((payload && payload.message) || (I18N('ui_unexpected_response') || 'Unexpected response.'), 'error');
            return;
        }
        state.audioUrl = payload.audio_url;
        state.duration = payload.duration_seconds || null;

        var durationLabel = '';
        if (state.duration && Number.isFinite(Number(state.duration))) {
            var minutes = Math.floor(state.duration / 60);
            var seconds = state.duration % 60;
            durationLabel = minutes + ':' + String(seconds).padStart(2, '0');
        }

        $root.find('.podcast-file-name').text(state.fileName);
        $root.find('.podcast-duration').text(durationLabel);
        var $audio = $root.find('#podcastAudioPreview');
        $audio.find('source').attr('src', state.audioUrl);
        var audioEl = $audio.get(0);
        if (audioEl && typeof audioEl.load === 'function') {
            audioEl.load();
        }

        // Reset progress UI
        $root.find('.podcast-progress-fill').css('width', '0%');
        $root.find('.podcast-progress-thumb').css('left', '0%');
        $root.find('.podcast-time').text(durationLabel ? ('0:00 / ' + durationLabel) : '0:00');

        setStep($root, 'finish');
        $root.addClass('podcast-ready');
    }

    $(document).on('change', '#podcastFileInput', function (e) {
        var files = e.target.files || (this.files ? this.files : null);
        if (!files || !files.length) { return; }
        var file = files[0];
        var $root = getRoot(this);
        if (!$root.length) { return; }
        state.fileName = file.name || '';

        var formData = new FormData();
        formData.append('p', 'upload_temp_podcast');
        formData.append('audio', file);
        var csrfToken = $('input[name="csrf_token"]').val() || '';
        if (csrfToken) {
            formData.append('csrf_token', csrfToken);
        }

        var uploadLabel = I18N('ui_uploading_wait') || 'Uploading, please wait...';
        $root.find('.upload-text').text(uploadLabel);
        $root.addClass('podcast-uploading');
        var $progress = $root.find('.ve-upload-progress-stack');
        if ($progress.length) {
            $progress.removeClass('none');
            $progress.find('.ve-upload-progress-fill').css('width', '0%');
            $progress.find('.ve-upload-progress-percent').text('0%');
        }

        $.ajax({
            url: ENDPOINT,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            xhr: function () {
                var xhr = $.ajaxSettings.xhr();
                if (xhr.upload) {
                    xhr.upload.addEventListener('progress', function (e) {
                        if (!e.lengthComputable) { return; }
                        var pct = Math.round((e.loaded / e.total) * 100);
                        if ($progress.length) {
                            $progress.find('.ve-upload-progress-fill').css('width', pct + '%');
                            $progress.find('.ve-upload-progress-percent').text(pct + '%');
                        }
                    }, false);
                }
                return xhr;
            },
            success: function (res) {
                handleUploadSuccess(res, $root);
            },
            error: function (xhr) {
                var msg = (xhr && xhr.responseJSON && xhr.responseJSON.message) ? xhr.responseJSON.message : (I18N('ui_upload_failed') || 'Upload failed.');
                toast(msg, 'error');
            },
            complete: function () {
                var label = I18N('upload_podcast');
                if (!label || typeof label !== 'string') {
                    label = 'Upload podcast';
                }
                $root.find('.upload-text').text(label);
                $root.removeClass('podcast-uploading');
                if ($progress.length) {
                    $progress.addClass('none');
                }
                initPreviewPlayer($root);
            }
        });
    });

    $(document).on('change', '#podcastCoverInput', function (e) {
        var files = e.target.files || (this.files ? this.files : null);
        if (!files || !files.length) { return; }
        state.coverFile = files[0];
        state.coverName = state.coverFile.name || 'cover.png';
        state.coverBlob = null;
        var $root = getRoot(this);
        if (!$root.length) { return; }
        openCoverCropper(state.coverFile, $root);
    });

    $(document).on('click', '.finish_podcast_container .post-visiblity', function () {
        updateVisibilitySelection($(this));
    });

    function initPreviewPlayer($root) {
        var $card = $root.find('.podcast-player-card').first();
        if (!$card.length || $card.data('preview-ready') === true) { return; }
        var audio = $card.find('#podcastAudioPreview').get(0);
        if (!audio) { return; }

        var $play = $card.find('.podcast-btn.play');
        var $rew  = $card.find('.podcast-btn.rewind');
        var $fwd  = $card.find('.podcast-btn.forward');
        var $track = $card.find('.podcast-progress-fill');
        var $thumb = $card.find('.podcast-progress-thumb');
        var $time  = $card.find('.podcast-time');
        var $bar   = $card.find('.podcast-progress-track');

        function formatTime(seconds) {
            var sec = Math.max(0, Math.floor(seconds || 0));
            var m = Math.floor(sec / 60);
            var s = sec % 60;
            return m + ':' + String(s).padStart(2, '0');
        }

        function updateProgress() {
            var dur = audio.duration || 0;
            var cur = audio.currentTime || 0;
            var pct = dur > 0 ? Math.min(100, Math.max(0, (cur / dur) * 100)) : 0;
            $track.css('width', pct + '%');
            $thumb.css('left', pct + '%');
            if ($time.length) {
                var durLabel = dur ? formatTime(dur) : '--:--';
                $time.text(formatTime(cur) + ' / ' + durLabel);
            }
        }

        audio.addEventListener('timeupdate', updateProgress);
        audio.addEventListener('loadedmetadata', updateProgress);
        audio.addEventListener('play', function(){
            document.querySelectorAll('.podcast-audio-element').forEach(function(el){
                if (el !== audio && !el.paused) {
                    el.pause();
                }
            });
            $card.addClass('is-playing');
        });
        audio.addEventListener('pause', function(){ $card.removeClass('is-playing'); });

        if ($play.length) {
            $play.on('click', function(){
                if (audio.paused) { audio.play(); } else { audio.pause(); }
            });
        }
        function nudge(offset) {
            var dur = audio.duration || 0;
            var tgt = (audio.currentTime || 0) + offset;
            if (dur > 0) { tgt = Math.max(0, Math.min(dur, tgt)); }
            audio.currentTime = tgt;
        }
        if ($rew.length) { $rew.on('click', function(){ nudge(-10); }); }
        if ($fwd.length) { $fwd.on('click', function(){ nudge(10); }); }

        if ($bar.length) {
            $bar.on('click', function (ev) {
                var rect = this.getBoundingClientRect();
                var ratio = (ev.clientX - rect.left) / rect.width;
                ratio = Math.max(0, Math.min(1, ratio));
                if (audio.duration) {
                    audio.currentTime = audio.duration * ratio;
                }
            });
        }

        updateProgress();
        $card.data('preview-ready', true);
    }

    function openCoverCropper(file, $root) {
        var reader = new FileReader();
        reader.onload = function () {
            var src = reader.result;
            var overlay = document.createElement('div');
            overlay.className = 'popUp-container pcover-overlay';
            overlay.innerHTML = '' +
                '<div class="pcover-wrapper">' +
                  '<div class="pcover-header flex align_items_justify_content">' +
                    '<button type="button" class="pcover-cancel">'+ (I18N('menu_cancel') || 'Cancel') +'</button>' +
                    '<div class="pcover-title">'+ (I18N('podcast_cover_upload') || 'Upload podcast cover') +'</div>' +
                    '<button type="button" class="pcover-save">'+ (I18N('save') || 'Save') +'</button>' +
                  '</div>' +
                  '<div class="pcover-frame">' +
                    '<img src="'+ src +'" alt="cover crop" draggable="false" />' +
                  '</div>' +
                  '<div class="pcover-controls">' +
                    '<input type="range" min="1" max="3" step="0.01" value="1" class="pcover-zoom" />' +
                  '</div>' +
                '</div>';

            var $overlay = $(overlay);
            var $img = $overlay.find('img');
            var $zoom = $overlay.find('.pcover-zoom');
            var $save = $overlay.find('.pcover-save');
            var $cancel = $overlay.find('.pcover-cancel');

            var frameSize = 200;
            var cropState = {
                baseScale: 1,
                zoom: 1,
                left: 0,
                top: 0,
                naturalW: 0,
                naturalH: 0
            };
            var isDragging = false;
            var startX = 0, startY = 0;
            var startLeft = 0, startTop = 0;

            function syncZoomLimits() {
                var maxScale = Math.max(3, cropState.baseScale * 3, cropState.zoom);
                $zoom.attr('min', '1');
                $zoom.attr('max', maxScale.toFixed(2));
                if (cropState.zoom < 1) {
                    cropState.zoom = 1;
                }
                if (cropState.zoom > maxScale) {
                    cropState.zoom = maxScale;
                }
                $zoom.val(cropState.zoom.toFixed(2));
            }

            function applyPos() {
                $img.css({
                    left: cropState.left + 'px',
                    top: cropState.top + 'px',
                    width: (cropState.naturalW * cropState.baseScale * cropState.zoom) + 'px',
                    height: (cropState.naturalH * cropState.baseScale * cropState.zoom) + 'px'
                });
            }

            function enforceBounds() {
                var fw = frameSize;
                var fh = frameSize;
                var minZoom = Math.max(1, Math.max(
                    fw / (cropState.naturalW * cropState.baseScale),
                    fh / (cropState.naturalH * cropState.baseScale)
                ));
                if (cropState.zoom < minZoom) {
                    cropState.zoom = minZoom;
                    syncZoomLimits();
                }
                var dw = cropState.naturalW * cropState.baseScale * cropState.zoom;
                var dh = cropState.naturalH * cropState.baseScale * cropState.zoom;

                if (cropState.left > 0) { cropState.left = 0; }
                if (cropState.top > 0) { cropState.top = 0; }
                if (cropState.left + dw < fw) { cropState.left = fw - dw; }
                if (cropState.top + dh < fh) { cropState.top = fh - dh; }
                applyPos();
            }

            function handleImageLoad() {
                cropState.naturalW = $img[0].naturalWidth || frameSize;
                cropState.naturalH = $img[0].naturalHeight || frameSize;
                cropState.baseScale = Math.max(frameSize / cropState.naturalW, frameSize / cropState.naturalH);
                cropState.zoom = 1;
                var initW = cropState.naturalW * cropState.baseScale * cropState.zoom;
                var initH = cropState.naturalH * cropState.baseScale * cropState.zoom;
                cropState.left = (frameSize - initW) / 2;
                cropState.top = (frameSize - initH) / 2;
                syncZoomLimits();
                applyPos();
                enforceBounds();
            }

            $img.on('load', handleImageLoad);
            if ($img[0].complete && $img[0].naturalWidth) {
                handleImageLoad();
            }

            $zoom.on('input change', function () {
                var prevW = cropState.naturalW * cropState.baseScale * cropState.zoom;
                var prevH = cropState.naturalH * cropState.baseScale * cropState.zoom;
                var val = parseFloat(this.value) || 1;
                cropState.zoom = Math.max(val, 1);
                syncZoomLimits();
                var newW = cropState.naturalW * cropState.baseScale * cropState.zoom;
                var newH = cropState.naturalH * cropState.baseScale * cropState.zoom;
                cropState.left = cropState.left - (newW - prevW) / 2;
                cropState.top = cropState.top - (newH - prevH) / 2;
                applyPos();
                enforceBounds();
            });

            $img.on('pointerdown', function (ev) {
                ev.preventDefault();
                isDragging = true;
                startX = ev.clientX;
                startY = ev.clientY;
                startLeft = cropState.left;
                startTop = cropState.top;
                $img[0].setPointerCapture(ev.pointerId);
            });
            $img.on('pointermove', function (ev) {
                if (!isDragging) { return; }
                ev.preventDefault();
                var dx = ev.clientX - startX;
                var dy = ev.clientY - startY;
                cropState.left = startLeft + dx;
                cropState.top = startTop + dy;
                applyPos();
                enforceBounds();
            });
            $img.on('pointerup pointercancel', function (ev) {
                ev.preventDefault();
                isDragging = false;
                try { $img[0].releasePointerCapture(ev.pointerId); } catch (_) {}
            });

            $cancel.on('click', function () {
                $overlay.remove();
            });

            $save.on('click', function () {
                var canvas = document.createElement('canvas');
                canvas.width = frameSize;
                canvas.height = frameSize;
                var ctx = canvas.getContext('2d');
                if (ctx) {
                    var scaleVal = cropState.baseScale * cropState.zoom;
                    var srcX = Math.max(0, -cropState.left) / scaleVal;
                    var srcY = Math.max(0, -cropState.top) / scaleVal;
                    var srcW = frameSize / scaleVal;
                    var srcH = frameSize / scaleVal;
                    if (srcX + srcW > cropState.naturalW) { srcX = cropState.naturalW - srcW; }
                    if (srcY + srcH > cropState.naturalH) { srcY = cropState.naturalH - srcH; }
                    if (srcX < 0) { srcX = 0; }
                    if (srcY < 0) { srcY = 0; }
                    ctx.imageSmoothingEnabled = true;
                    ctx.imageSmoothingQuality = 'high';
                    ctx.drawImage($img[0], srcX, srcY, srcW, srcH, 0, 0, frameSize, frameSize);
                }
                canvas.toBlob(function (blob) {
                    if (blob) {
                        state.coverBlob = blob;
                        $root.find('.podcast-cover-name').text(state.coverName || 'cover.png');
                        $root.find('.podcast-cover-preview img').attr('src', URL.createObjectURL(blob));
                    }
                    $overlay.remove();
                }, 'image/png');
            });

            document.body.appendChild(overlay);
        };
        reader.readAsDataURL(file);
    }

    $(document).on('change', "#podcast_hide_likes_view, #podcast_turn_on_off_comment", function () {
        $(this).val($(this).is(':checked') ? 'on' : 'off');
    });

    $(document).on('click', '#podcastGoBack', function () {
        resetState(this);
    });

    $(document).on('click', '#podcastUploadBtn', function () {
        var $root = getRoot(this);
        if (!$root.length) { return; }
        if (!state.audioUrl) {
            toast(I18N('podcast_missing_audio') || 'Please upload an audio file first.', 'error');
            return;
        }
        if (!validatePrice($root)) {
            return;
        }

        var priceRaw = $.trim($root.find("input[name='set-price']").val() || '');
        var postTitle = $root.find("input[name='post_title']").val() || '';
        var postText = $root.find("textarea[name='post_text']").val() || '';
        var visibility = $root.find(".post-visiblity.active").data('type') || $root.find("input[name='post_type']").val() || 'everyone';
        var hideLikes = $root.find('#podcast_hide_likes_view').is(':checked') ? 'on' : 'off';
        var turnOffComments = $root.find('#podcast_turn_on_off_comment').is(':checked') ? 'on' : 'off';
        var categoryId = $.trim($root.find('#podcastCategorySelect').val() || '');
        var csrfToken = $('input[name="csrf_token"]').val() || '';

        var formData = new FormData();
        formData.append('p', 'finalize_podcast');
        formData.append('csrf_token', csrfToken);
        formData.append('audio_url', state.audioUrl);
        if (state.duration !== null) {
            formData.append('duration', state.duration);
        }
        formData.append('post_title', postTitle);
        formData.append('post_text', postText);
        formData.append('visibility', visibility);
        formData.append('set_price', priceRaw);
        formData.append('min_price', $root.find("input[name='min-price']").val() || '');
        formData.append('max_price', $root.find("input[name='max-price']").val() || '');
        formData.append('hide_likes_view', hideLikes);
        formData.append('turn_on_off_comment', turnOffComments);
        if (categoryId) {
            formData.append('podcast_category_id', categoryId);
        }
        if (state.coverFile) {
            if (state.coverBlob) {
                formData.append('cover', state.coverBlob, state.coverName || 'cover.png');
            } else {
                formData.append('cover', state.coverFile);
            }
        }

        $(this).prop('disabled', true).addClass('is-busy');

        $.ajax({
            url: ENDPOINT,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function (res) {
                if (!res || res.status !== 'success') {
                    toast((res && res.message) || (I18N('ui_unexpected_response') || 'Unexpected response.'), 'error');
                    return;
                }

                var markup = '';
                if (res.html) {
                    markup = decodeHtmlPayload(res.html, res.html_encoding || 'none');
                    if (!markup) {
                        markup = res.html;
                    }
                }

                if (markup) {
                    var $posts = $('#posts');
                    if ($posts.length) {
                        var $node = $(markup);
                        var didInsert = false;
                        if (res.post_id && Number.isFinite(Number(res.post_id))) {
                            var sel = '#post-' + String(res.post_id);
                            if ($(sel).length) {
                                $(sel).replaceWith($node);
                                didInsert = true;
                            }
                        }
                        if (!didInsert) {
                            var $first = $posts.find('.post_').first();
                            if ($first.length) {
                                $first.before($node);
                            } else {
                                $posts.prepend($node);
                            }
                        }

                        if (typeof DZ !== 'undefined' && typeof DZ.initPost === 'function') {
                            DZ.initPost($node[0]);
                        }
                        $(document).trigger('post:created', { root: $node });
                    }
                }

                $('.popUp-container').remove();
            },
            error: function (xhr) {
                var msg = (xhr && xhr.responseJSON && xhr.responseJSON.message) ? xhr.responseJSON.message : (I18N('ui_upload_failed') || 'Upload failed.');
                toast(msg, 'error');
            },
            complete: function () {
                $('#podcastUploadBtn').prop('disabled', false).removeClass('is-busy');
            }
        });
    });

    resetState();
})(jQuery, window, document);
