(function (root, factory) {
  if (typeof root.jQuery === 'undefined') {
    var bootstrapped = false;
    var attemptInit = function () {
      if (bootstrapped) {
        return;
      }
      if (typeof root.jQuery === 'undefined') {
        return;
      }
      bootstrapped = true;
      root.removeEventListener('DOMContentLoaded', attemptInit);
      root.removeEventListener('load', attemptInit);
      factory(root.jQuery);
    };
    root.addEventListener('DOMContentLoaded', attemptInit);
    root.addEventListener('load', attemptInit);
    if (root.document && (root.document.readyState === 'complete' || root.document.readyState === 'interactive')) {
      setTimeout(attemptInit, 0);
    }
    return;
  }
  factory(root.jQuery);
})(window, function ($) {
  'use strict';

  var buildUrl = (window.DZ && typeof window.DZ.buildUrl === 'function')
    ? window.DZ.buildUrl
    : function (path) {
        var base = (typeof window.site_url === 'string' && window.site_url)
          ? window.site_url
          : (window.location.origin + window.location.pathname.replace(/[^\/]*$/, ''));
        if (base.slice(-1) !== '/') {
          base += '/';
        }
        return base + String(path || '').replace(/^\/+/, '');
      };

  $(document).on('submit', '.register-form', function (event) {
    event.preventDefault();

    var $form = $(this);
    var $button = $form.find('.register-submit');
    var $warning = $form.find('#registerWarning');
    var $success = $form.find('#registerSuccess');
    var hideMessage = function ($element) {
      if (!$element || !$element.length) {
        return;
      }
      $element.removeAttr('style').text('').addClass('none');
    };
    var showMessage = function ($element, message) {
      if (!$element || !$element.length) {
        return;
      }
      $element.removeAttr('style').removeClass('none').text(message);
    };

    var username = $form.find('input[name="username"]').val().trim();
    var email = $form.find('input[name="email"]').val().trim();
    var password = $form.find('input[name="password"]').val();
    var confirmPassword = $form.find('input[name="confirm_password"]').val();
    var csrfToken = $form.find('input[name="csrf_token"]').val();
    var autoUsernameEnabled = String($form.data('auto-username')) !== '0';
    var phoneEnabled = String($form.data('phone-enabled')) !== '0';
    var dialCode = '';
    var phoneNumber = '';
    var userPhone = '';

    if (!autoUsernameEnabled && !username) {
      var usernameRequired = $form.data('error-username') || 'Username is required.';
      showMessage($warning, usernameRequired);
      return;
    }

    if (autoUsernameEnabled && !username && email) {
      var base = String(email.split('@')[0] || '');
      var sanitized = base.replace(/[^A-Za-z0-9_]/g, '_').replace(/^_+|_+$/g, '');
      if (sanitized.length >= 3) {
        username = sanitized.slice(0, 32);
        $form.find('input[name="username"]').val(username);
      }
    }
    if (phoneEnabled) {
      dialCode = $form.find('select[name="phone_country"]').val() || '';
      phoneNumber = $form.find('input[name="phone_number"]').val() || '';
    }
    if (phoneEnabled && phoneNumber.trim().length) {
      var cleanedDial = String(dialCode).replace(/[^0-9+]/g, '');
      var hasPlus = phoneNumber.trim().charAt(0) === '+';
      var cleanedPhone = String(phoneNumber).replace(/[^0-9]/g, '');
      if (!cleanedDial && hasPlus) {
        cleanedPhone = '+' + cleanedPhone;
      }
      userPhone = (cleanedDial || '') + cleanedPhone;
    }

    var errorRequired = $form.data('error-required') || 'Please fill all fields.';
    var errorMismatch = $form.data('error-mismatch') || 'Passwords do not match.';

    var originalText = $button.data('default-text');
    if (!originalText) {
      originalText = $button.text();
      $button.data('default-text', originalText);
    }
    var loadingText = $button.data('loading-text') || 'Processing...';

    hideMessage($warning);
    hideMessage($success);

    if (!email || !password || !confirmPassword) {
      showMessage($warning, errorRequired);
      return;
    }

    if (password !== confirmPassword) {
      showMessage($warning, errorMismatch);
      return;
    }

    $.ajax({
      type: 'POST',
      url: buildUrl('request/requests.php'),
      dataType: 'json',
      data: {
        p: 'register_account',
        username: username,
        email: email,
        password: password,
        confirm_password: confirmPassword,
        csrf_token: csrfToken,
        user_phone: userPhone
      },
      beforeSend: function () {
        $button.prop('disabled', true).text(loadingText);
      },
      success: function (response) {
        if (response && response.status === 'success') {
          var message = response.message || 'Account created successfully.';
          showMessage($success, message);
          hideMessage($warning);

          if (response.redirect) {
            setTimeout(function () {
              window.location.href = response.redirect;
            }, 800);
          } else {
            setTimeout(function () {
              window.location.href = buildUrl('');
            }, 800);
          }
        } else {
          var errorMessage = (response && response.message) ? response.message : 'Unable to create account.';
          showMessage($warning, errorMessage);
        }
      },
      error: function () {
        showMessage($warning, 'Unexpected error occurred.');
      },
      complete: function () {
        $button.prop('disabled', false).text(originalText);
      }
    });
  });
});
