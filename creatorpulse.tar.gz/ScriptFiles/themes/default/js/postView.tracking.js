(function () {
  "use strict";

  // Enable to see detailed console output while integrating
  const DEBUG = false;
  const log = (...args) => { if (DEBUG) { console.debug("[postView.tracking]", ...args); } };

  // Popup alerts for field testing (turn off in prod)
  const DEBUG_ALERT = false;
  function dbgAlert(...args) {
    if (!DEBUG_ALERT) return;
    try { alert(args.map(x => (typeof x === 'object' ? JSON.stringify(x) : String(x))).join(' ')); }
    catch (_) { /* ignore */ }
  }

  // ---------------------------
  // Config
  // ---------------------------
  const MIN_RATIO = 0.5;    // kept for legacy ratio mode; center-band uses entry.isIntersecting
  const MIN_MS    = 1200;   // required dwell time within the center band
  // Choose a compact target inside the post to observe (media instead of whole tall post)
  const targetToRoot = new WeakMap(); // observed target -> root .reel-item
  function getObserveTarget(rootEl) {
    // Prefer explicit hint
    let t = rootEl.querySelector('[data-observe="1"]');
    if (t) return t;
    // Common media selectors
    t = rootEl.querySelector('video.post-media, img.post-media, video, img');
    return t || rootEl; // fallback to root
  }

  // Fine-tuning for alignment-sensitive feeds
  const CENTER_BAND = 0.20;   // 20% tall central band
  const ANCHOR_PCT  = 0.40;   // use a point at 40% of media height as the anchor

  // Try to account for fixed top bars so the "visual center" is correct
  const HEADER_SEL = '.topbar, .top-navbar, header.navbar, .site-header';
  function getHeaderOffsetPx() {
    const cands = qsa(HEADER_SEL);
    let maxH = 0;
    cands.forEach(el => {
      const st = getComputedStyle(el);
      const isFixed = (st.position === 'fixed' || st.position === 'sticky');
      const top0 = (parseInt(st.top || '0', 10) === 0);
      if (isFixed && top0) {
        maxH = Math.max(maxH, el.offsetHeight || 0);
      }
    });
    return maxH;
  }

  function isAnchorInCenterBand(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    const vh   = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
    const header = getHeaderOffsetPx();
    const usableTop = header;
    const usableVh  = Math.max(0, vh - header);

    // Visual center ignoring the fixed header
    const centerY = usableTop + usableVh / 2;
    const bandHalf = (vh * CENTER_BAND) / 2;

    const anchorY = rect.top + rect.height * ANCHOR_PCT;
    return Math.abs(anchorY - centerY) <= bandHalf;
  }

  const USE_SESSIONSTORAGE = true; // Persist within the tab only (avoids stale 'alreadySent' across reloads)

  // ---------------------------
  // Network rate limiting (client-side backpressure)
  // ---------------------------
  const FLUSH_MS       = 1000;  // flush every 1s
  const MAX_PER_FLUSH  = 4;     // send at most 4 view posts per flush tick
  const MAX_QUEUE_SIZE = 200;   // safety cap to avoid unbounded memory

  const sendQueue = [];         // FIFO of payloads awaiting network send
  let   flushTimer = null;
  let   pageHidden = document.visibilityState === 'hidden';

  document.addEventListener('visibilitychange', () => {
    pageHidden = document.visibilityState === 'hidden';
  }, { passive: true });

  function scheduleFlush() {
    if (flushTimer) return;
    flushTimer = setInterval(() => {
      if (pageHidden) return; // pause when tab is hidden
      if (sendQueue.length === 0) return;

      const batch = sendQueue.splice(0, MAX_PER_FLUSH);
      batch.forEach(sendPayloadNow);
    }, FLUSH_MS);
  }

  // Resolve endpoint once (prefer global buildUrl, fallback to site_url, finally relative)
  function resolveRequestsEndpoint() {
    const relative = 'request/requests.php';
    let candidate = relative;

    if (typeof window.buildUrl === 'function') {
      candidate = window.buildUrl(relative);
    } else if (typeof window.site_url !== 'undefined' && window.site_url) {
      candidate = String(window.site_url) + relative;
    }

    try {
      const baseOrigin = window.location.origin || ((window.location.protocol || 'http:') + '//' + (window.location.host || ''));
      const resolved = new URL(candidate, window.location.href);
      if (resolved.origin !== baseOrigin && baseOrigin) {
        resolved.protocol = window.location.protocol;
        resolved.host = window.location.host;
      }
      return resolved.toString();
    } catch (_) {
      return relative;
    }
  }

  const REQUESTS_ENDPOINT = resolveRequestsEndpoint();

  // ---------------------------
  // Helpers
  // ---------------------------
  function qs(selector, root) {
    return (root || document).querySelector(selector);
  }
  function qsa(selector, root) {
    return Array.from((root || document).querySelectorAll(selector));
  }

  function getCsrf() {
    const el = qs('input[name="csrf_token"]');
    const token = el ? el.value : "";
    if (!token) { log("CSRF token not found in DOM (continuing)."); }
    return token;
  }

  function postForm(url, dataObj) {
    const body = new URLSearchParams();
    for (const [k, v] of Object.entries(dataObj)) body.append(k, String(v));
    log("POST", url, Object.fromEntries(Object.entries(dataObj).map(([k,v]) => [k, String(v)])));
    return fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: body.toString(),
      credentials: "same-origin",
    });
  }

  function sendPayloadNow({ postId, source, dwellMs, ratio }) {
    const csrf = getCsrf();
    const payload = {
      p: "add_view",
      post_id: postId,
      source: source || "feed",
      dwell_ms: Math.max(0, dwellMs | 0),
      visible_ratio: Math.max(0, Math.min(1, Number(ratio) || 0)),
    };
    if (csrf) payload.csrf_token = csrf;

    postForm(REQUESTS_ENDPOINT, payload)
      .then(async (res) => {
        try {
          const data = await res.clone().json();
          if (data && data.success === true) {
            markSent(postId);
            log("Marked sent (client)", postId);
          } else {
            log("Server success is FALSE for post", postId, data);
          }
        } catch (e) {
          log("Non-JSON or parse error for post", postId, e);
          // Do not mark as sent on parse error
        }
      })
      .catch((err) => {
        log("Network error for post", postId, err);
        // Do not mark as sent on network error
      });
  }

  // Track sent posts (client-side throttle)
  const sentSet = new Set();
  const LS_KEY  = "reels_views_sent_v2";

  if (USE_SESSIONSTORAGE) {
    try {
      const prev = JSON.parse(sessionStorage.getItem(LS_KEY) || "[]");
      if (Array.isArray(prev)) prev.forEach(id => sentSet.add(String(id)));
    } catch { /* noop */ }
  }

  function markSent(postId) {
    sentSet.add(String(postId));
    if (USE_SESSIONSTORAGE) {
      try {
        sessionStorage.setItem(LS_KEY, JSON.stringify(Array.from(sentSet)));
      } catch { /* noop */ }
    }
  }

  function alreadySent(postId) {
    return sentSet.has(String(postId));
  }

  function sendViewOnce({ postId, source, dwellMs, ratio }) {
    log("sendViewOnce called with", { postId, source, dwellMs, ratio, alreadySent: alreadySent(postId) });
    if (!postId) { return; }
    if (alreadySent(postId)) { return; }

    // Enqueue with safety cap
    if (sendQueue.length >= MAX_QUEUE_SIZE) {
      // Drop oldest to keep memory bounded (best-effort)
      sendQueue.splice(0, sendQueue.length - MAX_QUEUE_SIZE + 1);
    }
    sendQueue.push({ postId, source, dwellMs, ratio });
    scheduleFlush();
  }

  // ---------------------------
  // FEED: IntersectionObserver
  // ---------------------------

  function getScrollRoot(el) {
    let node = el.parentElement;
    while (node && node !== document.body) {
      const style = window.getComputedStyle(node);
      const oy = style.overflowY;
      const ox = style.overflowX;
      const isScrollable = (oy === 'auto' || oy === 'scroll' || ox === 'auto' || ox === 'scroll');
      if (isScrollable && node.scrollHeight > node.clientHeight) {
        return node;
      }
      node = node.parentElement;
    }
    return null; // fallback to viewport
  }

  // Manage one IntersectionObserver per scroll root
  const observersByRoot = new Map();      // root(Node|null) -> IO
  const targetToObserver = new WeakMap(); // observed target -> IO (for unobserve)

  function getIOForRoot(rootScroll) {
    const key = rootScroll || null;
    let io = observersByRoot.get(key);
    if (!io) {
      io = new IntersectionObserver(onFeedIntersect, {
        root: key,
        threshold: [0, 0.25, 0.5, 0.75, 1],
        rootMargin: '0px'               // we now compute center-band manually with anchor
      });
      observersByRoot.set(key, io);
    }
    return io;
  }

  // Cumulative dwell tracking per element
  const visibleSince = new Map();     // el -> timestamp (performance.now())
  const accumulated  = new Map();     // el -> ms accumulated above MIN_RATIO

  function observeFeedItem(el) {
    if (!el || !el.classList || !el.classList.contains("reel-item")) return;
    if (!el.dataset || !el.dataset.id) return;

    const rootScroll = getScrollRoot(el);
    const target = getObserveTarget(el);
    targetToRoot.set(target, el);

    log("Observe item", el.dataset.id, "target:", target.tagName.toLowerCase(), "root:", rootScroll || "viewport");

    // Get or create an IO for this scroll root and observe the compact target
    const io = getIOForRoot(rootScroll);
    io.observe(target);
    targetToObserver.set(target, io);
  }

  function onFeedIntersect(entries) {
    const now = performance.now();
    entries.forEach(entry => {
      const target = entry.target;
      const rootEl = targetToRoot.get(target) || target.closest('.reel-item');
      if (!rootEl) return;

      const postId = rootEl.dataset.id;
      const source = rootEl.dataset.source || "feed";
      const ratioNow = (typeof entry.intersectionRatio === 'number') ? entry.intersectionRatio : getCurrentVisibilityRatio(target, entry);
      const anchorOK = isAnchorInCenterBand(target);
      const condition = (ratioNow >= MIN_RATIO) || anchorOK;

      log("Intersect(mixed)", { id: postId, ratio: Number(ratioNow).toFixed(2), anchorOK });

      if (!postId) return;

      if (condition) {
        if (!visibleSince.has(target)) {
          visibleSince.set(target, now);
          log("Visible start (mixed)", { id: postId, at: now });
        }
      } else {
        if (visibleSince.has(target)) {
          const start = visibleSince.get(target);
          const prev  = accumulated.get(target) || 0;
          const add   = Math.max(0, now - start);
          accumulated.set(target, prev + add);
          visibleSince.delete(target);
          log("Visible stop (mixed)", { id: postId, added: add, total: prev + add });
        }
      }

      const base  = accumulated.get(target) || 0;
      const extra = visibleSince.has(target) ? Math.max(0, now - visibleSince.get(target)) : 0;
      const total = base + extra;

      if (total >= MIN_MS) {
        sendViewOnce({ postId, source, dwellMs: Math.round(total), ratio: Math.max(0.5, ratioNow || 0) });
        accumulated.delete(target);
        visibleSince.delete(target);
        const io = targetToObserver.get(target);
        if (io) {
          try { io.unobserve(target); } catch {}
          targetToObserver.delete(target);
        }
      }
    });
  }

  function getCurrentVisibilityRatio(el, lastEntry) {
    // Some browsers don’t expose a direct API, so we reuse the last known ratio
    // or compute a coarse ratio using getBoundingClientRect.
    if (lastEntry && typeof lastEntry.intersectionRatio === "number") {
      return lastEntry.intersectionRatio;
    }
    const rect = el.getBoundingClientRect();
    const vw   = Math.max(document.documentElement.clientWidth,  window.innerWidth || 0);
    const vh   = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
    const visibleX = Math.max(0, Math.min(rect.right, vw) - Math.max(rect.left, 0));
    const visibleY = Math.max(0, Math.min(rect.bottom, vh) - Math.max(rect.top, 0));
    const visibleArea = visibleX * visibleY;
    const totalArea   = Math.max(1, rect.width * rect.height);
    return Math.max(0, Math.min(1, visibleArea / totalArea));
  }

  function isInViewport(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    const vh   = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
    const vw   = Math.max(document.documentElement.clientWidth,  window.innerWidth  || 0);
    return rect.top < vh && rect.bottom > 0 && rect.left < vw && rect.right > 0;
  }
  function estimateViewportCoverage(el) {
    const rect = el.getBoundingClientRect();
    const vw   = Math.max(document.documentElement.clientWidth,  window.innerWidth || 0);
    const vh   = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
    const visibleX = Math.max(0, Math.min(rect.right, vw) - Math.max(rect.left, 0));
    const visibleY = Math.max(0, Math.min(rect.bottom, vh) - Math.max(rect.top, 0));
    const visibleArea = visibleX * visibleY;
    const totalArea   = Math.max(1, rect.width * rect.height);
    return Math.max(0, Math.min(1, visibleArea / totalArea));
  }

  // ---------------------------
  // POPUP / SINGLE: video play hook
  // ---------------------------
  function bindPopupVideoPlay(root) {
    log("Binding popup video listeners within scope:", root === document ? "document" : root);
    // In full/single, sources typically marked as data-source="popup"
    const scope = root || document;
    qsa('.reel-item[data-source="popup"] video').forEach(v => {
      if (v.__viewPlayBound) return; // idempotent
      v.__viewPlayBound = true;
      log("Bound 'play' listener for popup video of post", v.closest('.reel-item')?.dataset?.id);

      v.addEventListener("playing", () => {
        const wrap = v.closest('.reel-item[data-id]');
        if (!wrap) return;
        const postId = wrap.dataset.id;
        const source = "popup";
        const start  = performance.now();

        const check = () => {
          if (v.paused || v.ended) return;
          const playedEnough = v.currentTime >= 1; // at least 1s playback
          if (playedEnough) {
            sendViewOnce({ postId, source, dwellMs: 1000, ratio: 1 });
          } else {
            requestAnimationFrame(check);
          }
        };
        requestAnimationFrame(check);
      }, { passive: true });
    });
  }

  // ---------------------------
  // Dynamic content: MutationObserver
  // - When infinite scroll or popup injects new .reel-item, we auto-wire.
  // ---------------------------
  const mo = new MutationObserver(muts => {
    muts.forEach(m => {
      m.addedNodes.forEach(node => {
        if (!(node instanceof HTMLElement)) return;

        // If the node itself is a reel-item
        if (node.classList.contains("reel-item")) {
          observeFeedItem(node);
          log("Observed reel-item", "(self)", (node.dataset && node.dataset.id) || null);
          bindPopupVideoPlay(node);
        }

        // Or it contains reel-items
        qsa(".reel-item", node).forEach(el => {
          observeFeedItem(el);
          log("Observed reel-item", "(descendant)", (el.dataset && el.dataset.id) || null);
          bindPopupVideoPlay(el);
        });

        // Also wire any new popup videos
        qsa('video', node).forEach(v => bindPopupVideoPlay(node));
      });
    });
  });

  // ---------------------------
  // Initial viewport pass: count items already visible on first load
  // ---------------------------
  function initialViewportPass() {
    const items = qsa(".reel-item[data-id]").filter(el => isInViewport(el));
    if (!items.length) {
      log("Initial pass: no visible items");
      return;
    }
    log("Initial pass: candidates =", items.map(el => el.dataset.id));

    items.forEach((el) => {
      const pid = el.dataset.id;
      const src = el.dataset.source || "feed";
      const target = getObserveTarget(el);
      const ratioNow = estimateViewportCoverage(target);

      if ((ratioNow >= MIN_RATIO || isAnchorInCenterBand(target)) && !alreadySent(pid)) {
        log("Initial pass: arm timer for", pid, "ratio:", ratioNow);
        setTimeout(() => {
          // Re-check after dwell to ensure it really stayed visible enough
          const target2 = getObserveTarget(el);
          const ratioLater = estimateViewportCoverage(target2);
          if ((ratioLater >= MIN_RATIO || isAnchorInCenterBand(target2)) && !alreadySent(pid)) {
            log("Initial pass: fire for", pid, "ratio:", ratioLater);
            dbgAlert("INIT FIRE post:", pid, "ratio:", ratioLater.toFixed(2));
            sendViewOnce({ postId: pid, source: src, dwellMs: MIN_MS, ratio: ratioLater });
          } else {
            log("Initial pass: skip after recheck", pid, "ratio:", ratioLater);
            dbgAlert("INIT SKIP post:", pid, "ratio:", ratioLater.toFixed(2));
          }
        }, MIN_MS + 100);
      } else {
        log("Initial pass: below ratio or already sent", pid, "ratio:", ratioNow, "alreadySent:", alreadySent(pid));
      }
    });
  }

  // ---------------------------
  // Boot
  // ---------------------------
  function boot() {
    // Initial bind for existing items
    qsa(".reel-item[data-id]").forEach(el => observeFeedItem(el));
    log("Initial reel items found:", qsa(".reel-item[data-id]").length);
    bindPopupVideoPlay(document);

    // Observe future additions (infinite scroll, popups, etc.)
    mo.observe(document.body, { childList: true, subtree: true });

    // Optional: comment composer smooth scroll after it becomes visible
    bindCommentComposerScroll();

    scheduleFlush();

    // Multi-item initial pass so all on-screen posts at load can be counted
    setTimeout(initialViewportPass, 200);               // soon after DOM/layout
    setTimeout(initialViewportPass, MIN_MS + 300);      // after dwell to catch lazy images/layout shifts
  }

  // ---------------------------
  // Optional UX: Scroll to composer after it opens (matches your earlier need)
  // ---------------------------
  function bindCommentComposerScroll() {
    // When .p_comment clicked, comment area opens with animation; scroll afterwards.
    document.addEventListener("click", (e) => {
      const btn = (e.target instanceof Element) ? e.target.closest(".p_comment[data-id]") : null;
      if (!btn) return;
      const pid = btn.getAttribute("data-id");
      if (!pid) return;

      // Wait for your animation to toggle classes, then scroll into view
      setTimeout(() => {
        const target = qs('.p_comment_' + pid);
        if (target) {
          target.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      }, 220); // adjust to your CSS animation timing
    }, false);
  }

  // Kick off when DOM ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
