(function ($, window, document) {
    "use strict";
    var I18N = (window.DZ && typeof DZ.i18n === 'function') ? DZ.i18n : function(){ return ''; };

    /**
     * Authoring Notes
     * ---------------
     *
     * - Keep DOM selectors centralized under `VE.selectors`.
     * - Keep all HTML-generating helpers (`...HTML()` functions) side-effect free; they should only return strings.
     * - Keep UI state mutations inside small helpers (show/hide/html) for clarity and testability.
     * - Never rely on inline styles; CSS classes handle visibility (`.none`) and loaders.
     */

    /**
     * =====================
     * Module Configuration
     * =====================
     * Centralized selectors and endpoints to avoid scattering literals throughout the file.
     */

    // Namespace to avoid globals & collisions
    var VE = {
        selectors: {
            fileInput:    "#fileInput",
            createBox:    ".create_media_box",
            setContainer: ".set_video_container",
            finishContainer: ".finish_video_container",
            goBack:       "#goBack",
            goNext:       "#goNext",
            uploadBtn:    "#uploadBtn",
            popupWrapper: ".popup-wrapper",
            teaserInput:  "#videoTeaserInput",
            teaserField:  ".video-teaser-field",
            teaserName:   ".video-teaser-filename"
        },
        endpoint: (typeof window.buildUrl === 'function')
            ? window.buildUrl('request/requests.php')
            : ((typeof window.site_url !== 'undefined' && window.site_url) ? (window.site_url + 'request/requests.php') : 'request/requests.php'),
        actionUpload: "upload_temp_video" // action key for PHP (processed by requests.php)
    };

    var DEFAULT_UPLOAD_PROCESSING_NOTICE = 'Upload complete. Video is being checked and processed, this may take a moment. Please wait.';
    var SUPPORTS_XHR_UPLOAD_PROGRESS = detectUploadProgressSupport();

    /**
     * Locate the video popup container for a given node.
     * Ensures delegated handlers ignore other popups sharing the same IDs.
     * @param {Element|JQuery} node
     * @returns {JQuery}
     */
    function getVideoPopupRoot(node) {
        var $el = node ? $(node) : $();
        if (!$el.length) { return $(); }
        var $popup = $el.closest('.popUp-container');
        if (!$popup.length) { return $(); }
        if ($popup.find('.finish_video_container').length && $popup.find(VE.selectors.fileInput).length) {
            return $popup;
        }
        return $();
    }

    /**
     * Check if an event target belongs to the video popup.
     * @param {Element|JQuery} node
     * @returns {boolean}
     */
    function isTargetInsideVideoPopup(node) {
        return getVideoPopupRoot(node).length > 0;
    }

    // Helpers
    /** Utility: show an element (visibility driven by CSS classes). */
    function show(el) { $(el).removeClass("none"); }
    /** Utility: hide an element (visibility driven by CSS classes). */
    function hide(el) { $(el).addClass("none"); }
    /** Utility: set inner HTML of a target container. */
    function html(el, content) { $(el).html(content); }
    function toggleTeaserField($root, visibility) {
        if (!$root || !$root.length) { return; }
        var $field = $root.find(VE.selectors.teaserField);
        if (!$field.length) { return; }
        var showField = (visibility === 'locked' || visibility === 'subscribers');
        if (showField) {
            $field.removeClass('none');
        } else {
            $field.addClass('none');
            var $input = $field.find('input[type="file"]');
            if ($input.length) { $input.val(''); }
            $field.find(VE.selectors.teaserName).text('');
        }
    }
    /**
     * Remove native video UI for editor area and enforce inline playback.
     * This keeps the UX consistent across browsers and allows custom controls.
     */
    function stripNativeControls(){
        var $v = $(VE.selectors.setContainer).find('video');
        if(!$v.length) return;
        $v.each(function(){
            var el = this;
            // Remove native controls UI
            el.controls = false;
            el.removeAttribute('controls');
            // Force inline playback (iOS/Safari)
            el.setAttribute('playsinline', '');
            el.setAttribute('webkit-playsinline', '');
            // Reduce native UI affordances
            el.setAttribute('disablepictureinpicture', '');
            el.setAttribute('controlsList', 'nodownload noplaybackrate nofullscreen noremoteplayback');
            // Marker class for CSS targeting
            $(el).addClass('no-native-controls');
        });
    }

    function detectUploadProgressSupport() {
        try {
            if (!window.XMLHttpRequest) { return false; }
            var xhr = new window.XMLHttpRequest();
            return !!(xhr && xhr.upload && typeof xhr.upload.addEventListener === 'function');
        } catch (_) {
            return false;
        }
    }
    // Loader helpers (no inline styles; styles come from style.css)
    /** Returns HTML for the editor-stage loader (string only; no side effects). */
    function veLoaderHTML(){
        return '' +
        '<div class="loading-container absolute">' +
        '<div class="loader">' +
        '<div></div><div></div><div></div><div></div><div></div><div></div>' +
        '<div></div><div></div><div></div><div></div><div></div><div></div>' +
        '</div>' +
        '<p class="loading-text"></p>' +
        '</div>';
    }
    /** Mount the editor-stage loader into the setContainer, if not already present. */
    function showLoader() {
        var $host = $(VE.selectors.setContainer);
        if (!$host.find('.loading-container').length) {
            $host.append(veLoaderHTML());
        }
    }
    /** Remove the editor-stage loader from the setContainer. */
    function hideLoader() {
        $(VE.selectors.setContainer).find('.loading-container').remove();
    }

    // Popup-level loader (shown during finalize on uploadBtn)
    /** Returns HTML for the popup-level loader shown during final submit. */
    function vePopupLoaderHTML(){
        return '' +
        '<div class="loading-container popup-loader absolute">' +
          '<div class="loader">' +
            '<div></div><div></div><div></div><div></div><div></div><div></div>' +
            '<div></div><div></div><div></div><div></div><div></div><div></div>' +
          '</div>' +
          '<p class="loading-text"></p>' +
        '</div>';
    }
    /** Mount the popup-level loader into `.popup-wrapper`, once. */
    function showPopupLoader(){
        var $host = $(VE.selectors.popupWrapper).first();
        if ($host.length && !$host.find('.popup-loader').length) {
            $host.append(vePopupLoaderHTML());
        }
    }
    /** Remove the popup-level loader from `.popup-wrapper`. */
    function hidePopupLoader(){
        $(VE.selectors.popupWrapper).find('.popup-loader').remove();
    }

    function getUploadLoaderOverlay() {
        return $(VE.selectors.setContainer).find('.loading-container').first();
    }

    function instantiateUploadProgressBlock() {
        var tpl = document.getElementById('ve-upload-progress-template');
        var node = null;
        if (tpl) {
            if (tpl.content && tpl.content.firstElementChild) {
                node = tpl.content.firstElementChild.cloneNode(true);
            } else if (tpl.firstElementChild) {
                node = tpl.firstElementChild.cloneNode(true);
            } else if (tpl.innerHTML) {
                var wrap = document.createElement('div');
                wrap.innerHTML = tpl.innerHTML;
                node = wrap.firstElementChild;
            }
        }
        if (!node) {
            var fallback = document.createElement('div');
            fallback.className = 've-upload-progress-stack none';
            fallback.setAttribute('aria-live', 'polite');
            fallback.innerHTML = '' +
                '<div class="ve-upload-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">' +
                    '<span class="ve-upload-progress-fill" style="width:0%;"></span>' +
                '</div>' +
                '<div class="ve-upload-progress-percent">0%</div>' +
                '<p class="ve-upload-processing-notice none">' + DEFAULT_UPLOAD_PROCESSING_NOTICE + '</p>';
            node = fallback;
        }
        return node;
    }

    function ensureUploadProgressUI() {
        var $loader = getUploadLoaderOverlay();
        if (!$loader.length) { return null; }
        var cached = $loader.data('veUploadProgress');
        if (cached) { return cached; }
        var node = instantiateUploadProgressBlock();
        if (!node) { return null; }
        var $root = $(node);
        $loader.append($root);

        var $bar = $root.find('.ve-upload-progress-bar').first();
        if (!$bar.length) {
            $bar = $('<div class="ve-upload-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"></div>');
            $root.prepend($bar);
        } else {
            if (!$bar.attr('role')) { $bar.attr('role', 'progressbar'); }
            $bar.attr('aria-valuemin', '0');
            $bar.attr('aria-valuemax', '100');
            if (!$bar.attr('aria-valuenow')) { $bar.attr('aria-valuenow', '0'); }
        }

        var $fill = $bar.find('.ve-upload-progress-fill').first();
        if (!$fill.length) {
            $fill = $('<span class="ve-upload-progress-fill"></span>');
            $bar.append($fill);
        }
        $fill.css('width', '0%');

        var $percent = $root.find('.ve-upload-progress-percent').first();
        if (!$percent.length) {
            $percent = $('<div class="ve-upload-progress-percent">0%</div>');
            $root.append($percent);
        }

        var $notice = $root.find('.ve-upload-processing-notice').first();
        if (!$notice.length) {
            $notice = $('<p class="ve-upload-processing-notice none"></p>');
            $notice.text(DEFAULT_UPLOAD_PROCESSING_NOTICE);
            $root.append($notice);
        }
        var defaultText = $notice.attr('data-default') || $notice.text() || DEFAULT_UPLOAD_PROCESSING_NOTICE;
        $notice.attr('data-default', defaultText);

        var ui = {
            root: $root,
            bar: $bar,
            fill: $fill,
            percent: $percent,
            notice: $notice
        };
        $loader.data('veUploadProgress', ui);
        return ui;
    }

    function hideUploadProcessingNotice(ui) {
        if (!ui) { ui = ensureUploadProgressUI(); }
        if (!ui || !ui.notice || !ui.notice.length) { return; }
        ui.notice.addClass('none');
    }

    function showUploadProcessingNotice(ui) {
        if (!ui) { ui = ensureUploadProgressUI(); }
        if (!ui || !ui.notice || !ui.notice.length) { return; }
        var msg = I18N('upload_processing_notice');
        if (typeof msg !== 'string' || !msg.trim()) {
            msg = ui.notice.attr('data-default') || DEFAULT_UPLOAD_PROCESSING_NOTICE;
        }
        ui.notice.text(msg);
        ui.notice.removeClass('none');
    }

    function prepareUploadProgressUI() {
        var ui = ensureUploadProgressUI();
        if (!ui) { return; }
        if (ui.fill && ui.fill.length) { ui.fill.css('width', '0%'); }
        if (ui.bar && ui.bar.length) { ui.bar.attr('aria-valuenow', '0'); }
        if (ui.percent && ui.percent.length) { ui.percent.text('0%'); }
        hideUploadProcessingNotice(ui);
        ui.root.removeClass('none');
    }

    function updateUploadProgressValue(percent) {
        var ui = ensureUploadProgressUI();
        if (!ui) { return; }
        var numericPercent = Number(percent);
        if (!Number.isFinite(numericPercent)) { numericPercent = 0; }
        var normalized = Math.max(0, Math.min(100, numericPercent));
        ui.root.removeClass('none');
        if (ui.fill && ui.fill.length) { ui.fill.css('width', normalized + '%'); }
        if (ui.bar && ui.bar.length) { ui.bar.attr('aria-valuenow', Math.round(normalized)); }
        if (ui.percent && ui.percent.length) { ui.percent.text(Math.round(normalized) + '%'); }
        if (normalized >= 100) {
            showUploadProcessingNotice(ui);
        } else {
            hideUploadProcessingNotice(ui);
        }
    }

    function ensureVisibilityNotice() {
        if (window.DZ && typeof window.DZ.openVisibilityNotice === 'function') {
            return window.DZ.openVisibilityNotice;
        }

        function escapeHtml(value) {
            return String(value == null ? '' : value)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        function closeVisibilityNotice() {
            var existing = document.querySelector('.popUp-container[data-modal="visibility-guard"]');
            if (existing && existing.parentNode) {
                existing.parentNode.removeChild(existing);
            }
        }

        function openVisibilityNotice(options) {
            var opts = options || {};
            closeVisibilityNotice();

            var modal = document.createElement('div');
            modal.className = 'popUp-container';
            modal.setAttribute('data-modal', 'visibility-guard');

            var i18nFn = (window.DZ && typeof window.DZ.i18n === 'function') ? window.DZ.i18n : function(){ return ''; };
            var defaultOk = i18nFn('ui_ok') || 'OK';
            var cancelLabel = opts.cancelLabel || i18nFn('menu_cancel') || 'Cancel';
            var confirmLabel = opts.confirmLabel || defaultOk;
            var title = opts.title ? escapeHtml(opts.title) : '';
            var message = escapeHtml(opts.message || '');

            var html = '<div class="pm-sheet-container"><div class="pm-sheet" role="dialog" aria-modal="true">';
            if (title) {
                html += '<div class="pm-header flex align_items_justify_content full-width">' + title + '</div><div class="aud-sep"></div>';
            }
            html += '<div class="pm-message">' + message + '</div><div class="aud-sep"></div>';
            html += '<button type="button" class="pm-item pm-confirm">' + escapeHtml(confirmLabel) + '</button>';
            html += '</div>';
            html += '<button type="button" class="pm-cancel">' + escapeHtml(cancelLabel) + '</button>';
            html += '</div>';
            modal.innerHTML = html;

            modal.addEventListener('click', function (event) {
                var target = event.target;
                if (target.classList.contains('pm-confirm')) {
                    closeVisibilityNotice();
                    if (typeof opts.onConfirm === 'function') {
                        if (opts.onConfirm() === false) {
                            return;
                        }
                    } else if (opts.redirectUrl) {
                        window.location.href = opts.redirectUrl;
                        return;
                    }
                    if (opts.redirectUrl) {
                        window.location.href = opts.redirectUrl;
                    }
                    return;
                }
                if (target.classList.contains('pm-cancel') || target === modal) {
                    closeVisibilityNotice();
                }
            });

            document.body.appendChild(modal);
            return modal;
        }

        window.DZ = window.DZ || {};
        window.DZ.openVisibilityNotice = openVisibilityNotice;
        window.DZ.closeVisibilityNotice = closeVisibilityNotice;
        return openVisibilityNotice;
    }

    const openVisibilityNotice = ensureVisibilityNotice();

    function parseGuardBool(value) {
        if (typeof value === 'boolean') {
            return value;
        }
        if (typeof value === 'number') {
            return value === 1;
        }
        if (typeof value === 'string') {
            var normalized = value.trim().toLowerCase();
            return normalized === '1' || normalized === 'true' || normalized === 'yes';
        }
        return false;
    }

    function getVisibilityContext($source) {
        if (!$source || !$source.length) {
            return null;
        }
        var $root = $source.closest('.popUp-container');
        if (!$root.length) {
            return null;
        }
        var data = $root.data() || {};
        return {
            isCreator: typeof data.isCreator !== 'undefined' ? parseGuardBool(data.isCreator) : true,
            paymentsActive: typeof data.paymentsActive !== 'undefined' ? parseGuardBool(data.paymentsActive) : true,
            hasCreatorFlag: typeof data.isCreator !== 'undefined',
            hasPaymentsFlag: typeof data.paymentsActive !== 'undefined',
            creatorUrl: data.creatorUrl || '',
            creatorMessage: data.creatorMessage || '',
            creatorAction: data.creatorAction || '',
            paymentsMessage: data.paymentsMessage || '',
            paymentsAction: data.paymentsAction || '',
            cancelLabel: data.guardCancel || ''
        };
    }

    function handleVisibilityAccess($item, type) {
        if (type !== 'subscribers' && type !== 'locked') {
            return true;
        }
        var context = getVisibilityContext($item);
        if (!context) {
            return true;
        }
        var cancelLabel = context.cancelLabel || I18N('menu_cancel') || 'Cancel';
        if (context.hasCreatorFlag && !context.isCreator) {
            openVisibilityNotice({
                message: context.creatorMessage || (I18N('post_visibility_creator_required') || 'Only approved creators can share subscriber or paywalled posts. Become a creator to unlock these options.'),
                confirmLabel: context.creatorAction || (I18N('post_visibility_open_creator') || I18N('creator_identity_title') || 'Become a creator'),
                cancelLabel: cancelLabel,
                onConfirm: function () {
                    if (context.creatorUrl) {
                        window.location.href = context.creatorUrl;
                    }
                }
            });
            return false;
        }
        if (context.hasPaymentsFlag && !context.paymentsActive) {
            openVisibilityNotice({
                message: context.paymentsMessage || (I18N('post_visibility_payments_disabled') || 'Payment methods are currently being improved. Please try again later.'),
                confirmLabel: context.paymentsAction || (I18N('ui_ok') || 'OK'),
                cancelLabel: cancelLabel
            });
            return false;
        }
        return true;
    }

    // Toast helpers (server messages). Styles must live in style.css
    /** Build a toast container. `kind` can be `error`, `success`, or `info`. */
    function veToastHTML(text, kind){
        // kind: 'error' | 'success' | 'info'
        var k = kind || 'info';
        return '' +
        '<div class="ve-toast ve-toast-' + k + '" role="status" aria-live="polite">' +
            '<div class="ve-toast-body">' + $('<div/>').text(text).html() + '</div>' +
        '</div>';
    }
    /** Append a toast to the popup wrapper (or `<body>`) and auto-remove after 5s. */
    function showToast(text, kind){
        var $host = $(VE.selectors.popupWrapper).first();
        if(!$host.length){ $host = $(document.body); }
        var $t = $(veToastHTML(text, kind));
        $host.append($t);
        // auto remove after 5s
        setTimeout(function(){ $t.addClass('hide'); setTimeout(function(){ $t.remove(); }, 400); }, 5000);
    }

    // Icon helpers for play/pause button (no inline styles)
    /** SVG icon: play. */
    function vePlaySVG(){
        return '<svg viewBox="-1 0 12 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <title>play [#ffffff]</title> <desc>Created with Sketch.</desc> <defs> </defs> <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="Dribbble-Light-Preview" transform="translate(-65.000000, -3803.000000)" fill="#ffffff"> <g id="icons" transform="translate(56.000000, 160.000000)"> <path d="M18.074,3650.7335 L12.308,3654.6315 C10.903,3655.5815 9,3654.5835 9,3652.8985 L9,3645.1015 C9,3643.4155 10.903,3642.4185 12.308,3643.3685 L18.074,3647.2665 C19.306,3648.0995 19.306,3649.9005 18.074,3650.7335" id="play-[#ffffff]"> </path> </g> </g> </g> </g></svg>';
    }
    /** SVG icon: pause. */
    function vePauseSVG(){
        return '<svg viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" fill="none"><g fill="#ffffff"><rect x="2" y="1" width="3" height="10" rx="0.8"></rect><rect x="7" y="1" width="3" height="10" rx="0.8"></rect></g></svg>';
    }
    /** Set the play button state and swap the icon accordingly. */
    function setPlayButtonState($btn, state){ // state: 'play' | 'pause'
        if(state === 'pause'){
            $btn.attr('data-state','pause').html(vePauseSVG());
        }else{
            $btn.attr('data-state','play').html(vePlaySVG());
        }
    }

    // =========================
    // Editor (Timeline + Cover)
    // =========================
    // Internal state
    var veState = {
        duration: 0,
        startSec: 0,
        endSec: 0,
        coverDataURL: null,
        objectUrl: null
    };
    // Minimum selectable range length in seconds (kept consistent across inputs & dragging)
    var MIN_RANGE_SECONDS = 0.25;

    /**
     * Build the timeline editor panel (seek bar, handles, playhead, and inputs).
     * Returned string is inserted into `.set_video_container`.
     */
function buildEditorPanelHTML() {
    return `<div class="ve-controls"><div class="ve-timeline"><div class="ve-track"><canvas class="ve-canvas"></canvas><div class="ve-shade ve-shade-left"></div><div class="ve-shade ve-shade-right"></div><div class="ve-range-outline"></div><div class="ve-handle ve-handle-start" title="Start"></div><div class="ve-handle ve-handle-end" title="End"></div><div class="ve-playhead"></div></div><div class="ve-tick-dots"></div><div class="ve-ticks"><span class="ve-tick-start">0s</span><span class="ve-tick-mid">5s</span><span class="ve-tick-end">10s</span></div></div><div class="ve-fields full-width flex align_items"><label class="ve-label"><input type="range" class="ve-start-range" step="0.001" min="0" value="0"><input type="number" class="ve-start-number" step="0.001" min="0" value="0"></label><label class="ve-label"><input type="range" class="ve-end-range" step="0.001" min="0" value="0"><input type="number" class="ve-end-number" step="0.001" min="0" value="0"></label><button type="button" class="ve-play-range" data-state="play"><svg viewBox="-1 0 12 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <title>play [#ffffff]</title> <desc>Created with Sketch.</desc> <defs> </defs> <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="Dribbble-Light-Preview" transform="translate(-65.000000, -3803.000000)" fill="#ffffff"> <g id="icons" transform="translate(56.000000, 160.000000)"> <path d="M18.074,3650.7335 L12.308,3654.6315 C10.903,3655.5815 9,3654.5835 9,3652.8985 L9,3645.1015 C9,3643.4155 10.903,3642.4185 12.308,3643.3685 L18.074,3647.2665 C19.306,3648.0995 19.306,3649.9005 18.074,3650.7335" id="play-[#ffffff]"> </path> </g> </g> </g> </g></svg></button></div></div>`;
}

    /** Utility: resolve the primary `<video>` element inside the editor container. */
    function getVideoEl() {
        // Prefer #editVideo if present, else the first video in setContainer
        var $v = $(VE.selectors.setContainer).find("#editVideo");
        if (!$v.length) $v = $(VE.selectors.setContainer).find("video").first();
        return $v.length ? $v[0] : null;
    }

    /** Ensure the editor panel exists; append if not present. */
    function ensureEditorPanel() {
        var $host = $(VE.selectors.setContainer);
        if (!$host.find(".ve-controls").length) {
            $host.append(buildEditorPanelHTML());
        }
    }

    /**
     * Sync handle positions, shaded regions, and input fields from `veState` times.
     * This is the single source of truth for reflecting selection changes in the UI.
     */
    function fitHandlesFromTimes($root) {
        var startPct = (veState.startSec / veState.duration) * 100;
        var endPct = (veState.endSec / veState.duration) * 100;
        var $track = $root.find(".ve-track");
        var hw = 10; // reserved for CSS handle width
        $root.find(".ve-handle-start").css({ left: 'calc(' + startPct + '% - ' + (hw/2) + 'px)' });
        $root.find(".ve-handle-end").css({ left: 'calc(' + endPct + '% - ' + (hw/2) + 'px)' });
        $root.find(".ve-shade-left").css({ left: 0, width: startPct + '%' });
        $root.find(".ve-shade-right").css({ left: endPct + '%', right: 0 });
        $root.find(".ve-range-outline").css({ left: startPct + '%', right: (100 - endPct) + '%' });
        $root.find(".ve-start").val(veState.startSec.toFixed(2));
        $root.find(".ve-end").val(veState.endSec.toFixed(2));
        $root.find(".ve-tick-mid").text((veState.duration/2).toFixed(0) + 's');
        $root.find(".ve-tick-end").text((veState.duration).toFixed(0) + 's');
        $root.find('.ve-start-range').val(veState.startSec.toFixed(3));
        $root.find('.ve-end-range').val(veState.endSec.toFixed(3));
        $root.find('.ve-start-number').val(veState.startSec.toFixed(3));
        $root.find('.ve-end-number').val(veState.endSec.toFixed(3));
    }

    /** Set min/max/step attributes for range & number inputs based on video duration. */
    function setFieldBounds($root){
        var dur = veState.duration || 0;
        var $sr = $root.find('.ve-start-range');
        var $er = $root.find('.ve-end-range');
        var $sn = $root.find('.ve-start-number');
        var $en = $root.find('.ve-end-number');
        $sr.attr({ min: 0, max: dur, step: 0.001 });
        $er.attr({ min: 0.001, max: dur, step: 0.001 });
        $sn.attr({ min: 0, max: dur, step: 0.001 });
        $en.attr({ min: 0.001, max: dur, step: 0.001 });
    }

    /** Update the floating playhead position given a current time (in seconds). */
    function updatePlayhead($root, current){
        if (!veState.duration || !isFinite(veState.duration)) return;
        var pct = clamp((current / veState.duration) * 100, 0, 100);
        $root.find('.ve-playhead').css({ left: pct + '%' });
    }

    /** Compute a visually pleasant tick step for the timeline given total duration. */
    function niceStepFor(duration){
        // choose ~8-10 dots: steps 0.5,1,2,5,10
        var target = 9;
        var rough = duration / target;
        if (rough <= 0.5) return 0.5;
        if (rough <= 1) return 1;
        if (rough <= 2) return 2;
        if (rough <= 5) return 5;
        return Math.ceil(rough / 5) * 5; // 10,15,20...
    }

    /** Render timeline tick dots at regular intervals for easier visual navigation. */
    function renderTickDots($root){
        var dur = veState.duration || 0;
        var $dots = $root.find('.ve-tick-dots').empty();
        if (!dur || !isFinite(dur)) return;
        var step = niceStepFor(dur);
        for (var t = step; t < dur; t += step){
            var pct = (t / dur) * 100;
            var $d = $('<span class="ve-dot" />').css({ left: pct + '%' }).attr('data-t', t.toFixed(0)+'s');
            $dots.append($d);
        }
    }

    /** rAF-based playhead updater machinery (for smooth UI without layout thrash). */
    // Playhead visibility + rAF-driven smooth updater
    var playheadRAF = null;
    var playheadHideTimer = null;

    /** Soft-hide the playhead; used during handle drags to reduce visual noise. */
    function hidePlayhead($root){
        $root.find('.ve-playhead').addClass('is-hidden');
    }
    /** Reveal the playhead; typically after short inactivity post-drag. */
    function showPlayhead($root){
        $root.find('.ve-playhead').removeClass('is-hidden');
    }

    /**
     * Safely parse a JSON response that might include BOMs or stray characters
     * before the JSON payload. Returns `null` when parsing fails.
     */
    function safeParseJson(raw){
        if (raw === null || typeof raw === 'undefined') {
            return null;
        }
        if (typeof raw === 'object') {
            return raw;
        }
        if (typeof raw !== 'string') {
            return null;
        }

        var text = raw.replace(/^\uFEFF/, '').trim();
        if (!text) {
            return null;
        }

        var attemptParse = function(str) {
            try {
                return JSON.parse(str);
            } catch (err) {
                return null;
            }
        };

        var parsed = attemptParse(text);
        if (parsed !== null) {
            return parsed;
        }

        var start = -1;
        var end = -1;
        var firstBrace = text.indexOf('{');
        var firstBracket = text.indexOf('[');
        if (firstBrace !== -1 && (firstBracket === -1 || firstBrace < firstBracket)) {
            start = firstBrace;
            end = text.lastIndexOf('}');
        } else if (firstBracket !== -1) {
            start = firstBracket;
            end = text.lastIndexOf(']');
        }
        if (start !== -1 && end !== -1 && end > start) {
            parsed = attemptParse(text.slice(start, end + 1));
            if (parsed !== null) {
                return parsed;
            }
        }

        if (text.charAt(0) === '"' && text.charAt(text.length - 1) === '"') {
            var unquoted = text.slice(1, -1).replace(/\\"/g, '"');
            parsed = attemptParse(unquoted);
            if (parsed !== null) {
                return parsed;
            }
        }

        return looseJsonExtract(text);
    }

    function decodeJsonFragment(fragment) {
        if (typeof fragment !== 'string') {
            return fragment;
        }
        return fragment
            .replace(/\\u([0-9a-fA-F]{4})/g, function (_, code) {
                return String.fromCharCode(parseInt(code, 16));
            })
            .replace(/\\(["\\/bfnrt])/g, function (_, esc) {
                switch (esc) {
                    case '"': return '"';
                    case '\\': return '\\';
                    case '/': return '/';
                    case 'b': return '\b';
                    case 'f': return '\f';
                    case 'n': return '\n';
                    case 'r': return '\r';
                    case 't': return '\t';
                    default: return esc;
                }
            });
    }

    function looseJsonExtract(text) {
        if (typeof text !== 'string' || text.indexOf('"status"') === -1) {
            return null;
        }
        var result = {};
        var statusMatch = text.match(/"status"\s*:\s*"([\s\S]*?)"/);
        if (statusMatch) {
            result.status = decodeJsonFragment(statusMatch[1]);
        }
        var messageMatch = text.match(/"message"\s*:\s*"([\s\S]*?)"(?:\s*,\s*"(?:final_video_url|html|poster|post_id)"|\s*})/);
        if (messageMatch) {
            result.message = decodeJsonFragment(messageMatch[1]);
        }
        var videoMatch = text.match(/"final_video_url"\s*:\s*"([\s\S]*?)"(?:\s*,\s*"(?:poster|html|post_id)")?/);
        if (videoMatch) {
            result.final_video_url = decodeJsonFragment(videoMatch[1]);
        }
        var posterMatch = text.match(/"poster"\s*:\s*"([\s\S]*?)"(?:\s*,\s*"(?:html|post_id)")?/);
        if (posterMatch) {
            result.poster = decodeJsonFragment(posterMatch[1]);
        }
        var htmlMatch = text.match(/"html"\s*:\s*"([\s\S]*?)","post_id"/);
        if (htmlMatch) {
            result.html = decodeJsonFragment(htmlMatch[1]);
        }
        var postIdMatch = text.match(/"post_id"\s*:\s*([0-9]+)/);
        if (postIdMatch) {
            var pid = parseInt(postIdMatch[1], 10);
            if (!Number.isNaN(pid)) {
                result.post_id = pid;
            }
        }
        return Object.keys(result).length ? result : null;
    }

    function decodeBinaryString(binary) {
        if (typeof binary !== 'string') {
            return '';
        }
        if (typeof TextDecoder !== 'undefined') {
            var buffer = new Uint8Array(binary.length);
            for (var i = 0; i < binary.length; i++) {
                buffer[i] = binary.charCodeAt(i);
            }
            return new TextDecoder('utf-8').decode(buffer);
        }
        try {
            return decodeURIComponent(binary.split('').map(function (char) {
                var code = char.charCodeAt(0).toString(16);
                return '%' + (code.length < 2 ? '0' + code : code);
            }).join(''));
        } catch (_) {
            return binary;
        }
    }

    function decodeHtmlPayload(value, encoding){
        if (typeof value !== 'string' || value === '') {
            return '';
        }
        if ((encoding || '').toLowerCase() !== 'base64') {
            return value;
        }
        var sanitized = value.replace(/\s+/g, '');
        var binary = null;
        try {
            if (typeof window !== 'undefined' && typeof window.atob === 'function') {
                binary = window.atob(sanitized);
            } else if (typeof atob === 'function') {
                binary = atob(sanitized);
            }
        } catch (_) {
            binary = null;
        }
        if (binary !== null) {
            return decodeBinaryString(binary);
        }
        if (typeof Buffer !== 'undefined') {
            try {
                return Buffer.from(sanitized, 'base64').toString('utf8');
            } catch (_) {}
        }
        return '';
    }

    /** Start a requestAnimationFrame loop to keep the playhead in sync while playing. */
    function startPlayheadLoop(v, $root){
        stopPlayheadLoop();
        function step(){
            updatePlayhead($root, v.currentTime || 0);
            playheadRAF = window.requestAnimationFrame(step);
        }
        playheadRAF = window.requestAnimationFrame(step);
    }
    /** Stop the active requestAnimationFrame loop for the playhead. */
    function stopPlayheadLoop(){
        if (playheadRAF){
            window.cancelAnimationFrame(playheadRAF);
            playheadRAF = null;
        }
    }

    /** Math utility: clamp a number between two bounds. */
    function clamp(v, a, b){ return Math.min(Math.max(v, a), b); }

    /** Convert a clientX coordinate to a percentage across the timeline track. */
    function pctFromClientX($track, clientX){
        var rect = $track[0].getBoundingClientRect();
        var x = clamp(clientX - rect.left, 0, rect.width);
        return (x / rect.width) * 100;
    }

    /** Hidden off-DOM video used solely for frame-accurate seeking & canvas capture. */
    // A single hidden seeker video for frame capture
    var seeker = document.createElement("video");
    seeker.muted = true;
    seeker.playsInline = true;
    /** Promise-based seek helper to await the `seeked` event at time `t` (seconds). */
    function seekAsync(v, t){
        return new Promise(function(resolve){
            var done = function(){ v.removeEventListener('seeked', done); resolve(); };
            v.addEventListener('seeked', done, { once:true });
            var safeT = clamp(t, 0, Math.max(0, veState.duration - 0.05));
            v.currentTime = safeT;
        });
    }

    /**
     * Draw a strip of representative frames on the timeline canvas.
     * Note: Uses the hidden `seeker` video to avoid stalling the main player.
     */
    async function drawTimelineFrames($root, frameCount) {
        var $canvas = $root.find(".ve-canvas");
        var canvas = $canvas[0];
        var ctx = canvas.getContext("2d", { willReadFrequently: true });
        // Size canvas to track
        var trackRect = $root.find(".ve-track")[0].getBoundingClientRect();
        canvas.width = Math.max(800, Math.round(trackRect.width));
        canvas.height = Math.round(trackRect.height);

        ctx.fillStyle = "#111";
        ctx.fillRect(0,0,canvas.width,canvas.height);

        var cellW = Math.floor(canvas.width / frameCount);
        var cellH = canvas.height;
        var step = veState.duration / frameCount;

        for (var i=0;i<frameCount;i++){
            var time = i*step + step/2;
            await seekAsync(seeker, time);
            var vw = seeker.videoWidth, vh = seeker.videoHeight;
            if(!vw || !vh) continue;
            var scale = Math.min(cellW/vw, cellH/vh);
            var w = vw*scale, h = vh*scale;
            var ox = i*cellW + (cellW - w)/2;
            var oy = (cellH - h)/2;
            ctx.drawImage(seeker, ox, oy, w, h);
        }
    }

    /** Generate evenly spaced cover thumbnails (kept for potential future use). */
    async function generateCoverThumbs($root, count){
        var $c = $root.find(".ve-thumbs").empty();
        var step = veState.duration / (count+1);
        for (var i=1;i<=count;i++){
            var time = i*step;
            var url = await captureFrame(time, 240);
            var $img = $('<img/>', { src:url, alt:'Cover '+i, class:'ve-thumb' });
            if(i===1){ $img.addClass('active'); veState.coverDataURL = url; }
            $c.append($img);
        }
    }

    /** Capture a JPEG dataURL from the current video at `time` (seconds) and `width` px. */
    function captureFrame(time, width){
        return new Promise(async function(resolve){
            await seekAsync(seeker, time);
            var vw = seeker.videoWidth, vh = seeker.videoHeight;
            var scale = width / vw;
            var cw = Math.round(vw*scale), ch = Math.round(vh*scale);
            var c = document.createElement("canvas");
            c.width = cw; c.height = ch;
            var cctx = c.getContext("2d");
            cctx.drawImage(seeker, 0, 0, cw, ch);
            resolve(c.toDataURL("image/jpeg", 0.9));
        });
    }

    /**
     * Initialize the editor for the currently injected video:
     * - Creates panel if needed
     * - Binds metadata, play/pause, end-of-range checks
     * - Pre-renders timeline frames
     */
    // Initialize editor for current video in setContainer
    function initEditorForCurrentVideo(){
        var v = getVideoEl();
        if(!v) { return; }

        // Ensure panel
        ensureEditorPanel();
        var $root = $(VE.selectors.setContainer);
        stripNativeControls();
        setFieldBounds($root);

        // Keep play button state in sync with native controls and end-of-range
        var $btn = $root.find('.ve-play-range');
        setPlayButtonState($btn, 'play');
        v.addEventListener('pause', function(){ setPlayButtonState($btn, 'play'); });
        v.addEventListener('ended', function(){ setPlayButtonState($btn, 'play'); });

        // Bind seeker to same source
        if (v.currentSrc) {
            seeker.src = v.currentSrc;
        } else {
            var source = $(v).find("source").attr("src") || v.src || "";
            if (source) seeker.src = source;
        }

        v.onloadedmetadata = function(){
            veState.duration = v.duration || 0;
            if(!veState.duration || !isFinite(veState.duration)) return;
            veState.startSec = 0;
            veState.endSec = veState.duration;
            setFieldBounds($root);
            fitHandlesFromTimes($root);
            renderTickDots($root);
            updatePlayhead($root, 0);
            showPlayhead($root);
            drawTimelineFrames($root, 24).then(function(){
                // done
            });
            // generateCoverThumbs($root, 5); // Removed covers section
        };

        // If already loaded (Safari sometimes)
        if (v.readyState >= 1) {
            veState.duration = v.duration || 0;
            veState.startSec = 0;
            veState.endSec = veState.duration || 0;
            setFieldBounds($(VE.selectors.setContainer));
            fitHandlesFromTimes($(VE.selectors.setContainer));
            renderTickDots($(VE.selectors.setContainer));
            updatePlayhead($(VE.selectors.setContainer), v.currentTime || 0);
            showPlayhead($(VE.selectors.setContainer));
            drawTimelineFrames($(VE.selectors.setContainer), 24);
            // generateCoverThumbs($(VE.selectors.setContainer), 5); // Removed covers section
        }

        // Range stop check (keep timeupdate only for end-boundary enforcement)
        v.addEventListener("timeupdate", function(){
            if (veState.endSec && v.currentTime > veState.endSec) {
                v.pause();
                stopPlayheadLoop();
                var $btn = $(VE.selectors.setContainer).find('.ve-play-range');
                setPlayButtonState($btn, 'play');
            }
        });

        // Start/stop the rAF loop on play/pause/ended
        v.addEventListener('play', function(){
            startPlayheadLoop(v, $(VE.selectors.setContainer));
        });
        v.addEventListener('pause', function(){
            stopPlayheadLoop();
        });
        v.addEventListener('ended', function(){
            stopPlayheadLoop();
        });
    }

    // Expose to namespace
    VE.initEditorForCurrentVideo = initEditorForCurrentVideo;

    // Delegated events for editor UI
    // --- Range Handles: drag logic (pause during drag, keep within bounds, rAF throttled) ---
    var dragging = null; // 'start' | 'end'
    var draggingWasPlaying = false;
    var rafPending = false;
    $(document).on("pointerdown", ".ve-handle-start, .ve-handle-end", function(e){
        var $track = $(VE.selectors.setContainer).find(".ve-track");
        dragging = $(this).hasClass("ve-handle-start") ? "start" : "end";
        // If video was playing, pause during drag to avoid iOS audio policies and desync
        var v = getVideoEl();
        var $btn = $(VE.selectors.setContainer).find('.ve-play-range');
        draggingWasPlaying = false;
        if (v) {
            draggingWasPlaying = !v.paused && !v.ended;
            if (draggingWasPlaying) {
                v.pause();
                setPlayButtonState($btn, 'play');
            }
        }
        hidePlayhead($(VE.selectors.setContainer));
        if (typeof this.setPointerCapture === 'function') {
            try { this.setPointerCapture(e.pointerId); } catch(_) {}
        }
        // Prevent touch scrolling while dragging
        e.preventDefault();
        e.stopPropagation();
    });

    $(document).on("pointermove", function(e){
        if (!dragging) return;
        if (rafPending) return;
        rafPending = true;
        window.requestAnimationFrame(function(){
            var $root = $(VE.selectors.setContainer);
            var $track = $root.find(".ve-track");
            var pct = clamp(pctFromClientX($track, e.clientX), 0, 100);
            var sPct = (veState.startSec / veState.duration) * 100;
            var ePct = (veState.endSec / veState.duration) * 100;

            var minGapPct = (MIN_RANGE_SECONDS / veState.duration) * 100;

            if (dragging === "start") {
                sPct = Math.min(pct, ePct - minGapPct);
            } else {
                ePct = Math.max(pct, sPct + minGapPct);
            }
            veState.startSec = (sPct/100) * veState.duration;
            veState.endSec = (ePct/100) * veState.duration;
            fitHandlesFromTimes($root);
            var vcur = getVideoEl();
            if (vcur) updatePlayhead($root, vcur.currentTime || 0);
            rafPending = false;
        });
    });

    $(document).on("pointerup pointercancel", function(){
        if (!dragging) return;
        dragging = null;
        var v = getVideoEl();
        var $btn = $(VE.selectors.setContainer).find('.ve-play-range');
        if (v) {
            // Seek to start of selected range; do not auto-play to comply with mobile audio policies.
            v.currentTime = veState.startSec;
            // Require explicit user tap on the play button to start with sound reliably on iOS/Android.
            showPlayhead($(VE.selectors.setContainer));
            setPlayButtonState($btn, 'play');
        }
    });

    // --- Inputs: keep start in sync across range/number fields and enforce min gap ---
    // Start inputs (range or number)
    $(document).on('input', '.ve-start-range, .ve-start-number', function(){
        var $root = $(VE.selectors.setContainer);
        hidePlayhead($root);
        if (playheadHideTimer) { clearTimeout(playheadHideTimer); }
        var val = parseFloat($(this).val() || '0');
        var e = parseFloat($root.find('.ve-end-number').val() || $root.find('.ve-end-range').val() || veState.endSec);
        var s = clamp(Math.min(val, e - 0.25), 0, Math.max(0, veState.duration - 0.25));
        veState.startSec = s;
        // sync peers
        $root.find('.ve-start-range').val(s.toFixed(3));
        $root.find('.ve-start-number').val(s.toFixed(3));
        fitHandlesFromTimes($root);
        var vcur2 = getVideoEl();
        if (vcur2) updatePlayhead($root, vcur2.currentTime || 0);
        var v = getVideoEl();
        if (v && v.currentTime > veState.endSec) {
            v.pause();
            setPlayButtonState($(VE.selectors.setContainer).find('.ve-play-range'), 'play');
        }
        playheadHideTimer = setTimeout(function(){ showPlayhead($root); }, 300);
    });

    // --- Inputs: keep end in sync across range/number fields and enforce min gap ---
    // End inputs (range or number)
    $(document).on('input', '.ve-end-range, .ve-end-number', function(){
        var $root = $(VE.selectors.setContainer);
        hidePlayhead($root);
        if (playheadHideTimer) { clearTimeout(playheadHideTimer); }
        var val = parseFloat($(this).val() || String(veState.duration));
        var s = parseFloat($root.find('.ve-start-number').val() || $root.find('.ve-start-range').val() || veState.startSec);
        var e = clamp(Math.max(val, s + 0.25), 0.25, veState.duration);
        veState.endSec = e;
        // sync peers
        $root.find('.ve-end-range').val(e.toFixed(3));
        $root.find('.ve-end-number').val(e.toFixed(3));
        fitHandlesFromTimes($root);
        var vcur2 = getVideoEl();
        if (vcur2) updatePlayhead($root, vcur2.currentTime || 0);
        var v2 = getVideoEl();
        if (v2 && v2.currentTime > veState.endSec) {
            v2.pause();
            setPlayButtonState($(VE.selectors.setContainer).find('.ve-play-range'), 'play');
        }
        playheadHideTimer = setTimeout(function(){ showPlayhead($root); }, 300);
    });

    // --- Play selected range: explicit user gesture only (mobile-safe) ---
    $(document).on("click", ".ve-play-range", function(){
        var v = getVideoEl();
        if (!v) return;
        v.muted = false; // ensure audio is enabled for explicit user gesture
        var $btn = $(this);
        var state = $btn.attr('data-state') || 'play';

        // If currently in 'play' state, start playback from startSec and switch to pause icon
        if (state === 'play') {
            v.currentTime = veState.startSec;
            updatePlayhead($(VE.selectors.setContainer), veState.startSec);
            startPlayheadLoop(v, $(VE.selectors.setContainer));
            var p = v.play();
            if (p && typeof p.then === 'function') {
                p.then(function(){
                    setPlayButtonState($btn, 'pause');
                }).catch(function(){
                    // autoplay blocked or similar — keep as play icon
                    setPlayButtonState($btn, 'play');
                });
            } else {
                setPlayButtonState($btn, 'pause');
            }
        } else {
            // Pause requested
            stopPlayheadLoop();
            v.pause();
            setPlayButtonState($btn, 'play');
        }
    });

    // Removed delegated cover event handlers (.ve-regen and .ve-thumbs img)

    /** Reset to pre-upload state; used on errors or when user navigates back. */
    // Reset view back to initial (in case PHP error returns)
    function resetToInitial() {
        show(VE.selectors.createBox);
        hide(VE.selectors.setContainer);
        hide(VE.selectors.goBack);
        hide(VE.selectors.goNext);
        hide(VE.selectors.uploadBtn);
        hideLoader();
        var $in = $(VE.selectors.fileInput);
        if ($in.length) { $in.val(""); }
        html(VE.selectors.setContainer, "");
        veState.duration = 0; veState.startSec = 0; veState.endSec = 0;
    }

    /** Switch UI to the editing step (after a successful temporary upload). */
    // Prepare UI for editing state (after successful upload)
    function toEditingState() {
        hide(VE.selectors.createBox);
        show(VE.selectors.setContainer);
        show(VE.selectors.goBack);
        show(VE.selectors.goNext);
        // Share/Upload button stays hidden at this step; will be enabled in the finalize view.
        hide(VE.selectors.uploadBtn);
    }

    /** Switch UI to the finalize/publish step. */
    // Switch to finish step (publish view)
    function toFinishState() {
        // containers
        $(VE.selectors.setContainer).addClass('none');
        $(VE.selectors.finishContainer).removeClass('none');

        // header buttons
        show(VE.selectors.goBack);
        hide(VE.selectors.goNext);
        show(VE.selectors.uploadBtn);

        var $root = $(VE.selectors.finishContainer).closest('.popUp-container');
        var activeType = $root.find('.post-visiblity.active').data('type') || $root.find("input[name='post_type']").val() || 'everyone';
        toggleTeaserField($root, String(activeType));
    }

    /** Return from finalize view back to the editor view. */
    // Switch back to edit step
    function backToEditState() {
        // containers
        $(VE.selectors.finishContainer).addClass('none');
        $(VE.selectors.setContainer).removeClass('none');

        // header buttons
        show(VE.selectors.goBack);
        show(VE.selectors.goNext);
        hide(VE.selectors.uploadBtn);
    }

    /**
     * Gather the final payload to be sent on submit.
     * Includes: source URLs, trim times, text, visibility, pricing, and switches.
     */
    // Gather data for final submit (what will be sent on upload)
    function gatherFinishPayload(){
        // Video info
        var v = getVideoEl();
        var videoUrl = "";
        var posterUrl = "";
        if (v) {
            videoUrl = v.currentSrc || $(v).find('source').attr('src') || v.src || "";
            posterUrl = v.poster || "";
        }

        // Text
        var postTitle = $(VE.selectors.finishContainer).find('input[name="post_title"]').val() || "";
        var postText = $(VE.selectors.finishContainer).find('textarea[name="post_text"]').val() || "";

        // Visibility (active .post-visiblity[data-type])
        var $activeVis = $(VE.selectors.finishContainer).find('.post-visiblity.active[data-type]');
        var visibility = $activeVis.attr('data-type') || $(VE.selectors.finishContainer).find('input[name="post_type"]').val() || "everyone";

        // Price (for locked)
        var setPrice = $(VE.selectors.finishContainer).find('input[name="set-price"]').val() || "";
        var minPrice = $(VE.selectors.finishContainer).find('input[name="min-price"]').val() || "";
        var maxPrice = $(VE.selectors.finishContainer).find('input[name="max-price"]').val() || "";

        // Switches
        var hideLikesViews = $(VE.selectors.finishContainer).find('#hide_likes_view:checked').length ? 'on' : 'off';
        var turnOffComment = $(VE.selectors.finishContainer).find('#turn_on_off_comment:checked').length ? 'on' : 'off';

        // CSRF
        var csrfToken = $('input[name="csrf_token"]').val() || "";

        // Trim info
        var startSec = Number((veState.startSec || 0).toFixed(3));
        var endSec   = Number((veState.endSec   || 0).toFixed(3));
        var duration = Number((veState.duration || 0).toFixed(3));

        return {
            p: 'finalize_reel',      // action key for requests.php (example)
            csrf_token: csrfToken,    // security
            video_url: videoUrl,      // MP4 on server
            poster_url: posterUrl,    // poster if created
            trim_start: startSec,     // for real trimming via ffmpeg
            trim_end: endSec,
            duration: duration,

            post_title: postTitle,
            post_text: postText,      // form fields
            visibility: visibility,
            set_price: setPrice,
            min_price: minPrice,
            max_price: maxPrice,
            hide_likes_view: hideLikesViews,
            turn_on_off_comment: turnOffComment
        };
    }

    /** Build a minimal editor-stage video wrapper when backend returns only a URL. */
    // Build fallback video HTML if server returns only URL
    function buildVideoHTML(url, poster) {
        var p = poster ? ' poster="'+ poster +'"' : "";
        return '' +
        '<div class="video-edit-stage">' +
            '<video id="editVideo" class="edit-video no-native-controls" playsinline'+ p +'>' +
                '<source src="'+ url +'" type="video/mp4">' +
            '</video>' +
        '</div>';
    }

    /** Build a minimal feed card as a fallback when server does not return ready-made HTML. */
    // Build a minimal feed card if backend didn't return ready-made HTML
    function buildFeedCardHTML(videoUrl, poster){
        var p = poster ? ' poster="'+ poster +'"' : "";
        return '' +
        '<div class="post-card">' +
          '<div class="post-media">' +
            '<video class="post-video" playsinline controls'+ p +'>' +
              '<source src="'+ videoUrl +'" type="video/mp4">' +
            '</video>' +
          '</div>' +
        '</div>';
    }

    // =====================
    // Upload → Temp Preview
    // =====================
    // Handles file input, posts to PHP, and injects returned HTML/JSON.
    // Handle file selection -> AJAX upload to server
    $(document).on("change", VE.selectors.fileInput, function (e) {
        var files = e.target.files || (this.files ? this.files : null);
        if (!files || !files.length) { return; }

        // Only the first file is used at this step (multi-file support can be added later).
        var file = files[0];

        var formData = new FormData();
        formData.append("p", VE.actionUpload);
        formData.append("video", file);
        // Append CSRF token if present
        var csrfToken = $('input[name="csrf_token"]').val();
        if (csrfToken) {
            formData.append("csrf_token", csrfToken);
        }

        html(VE.selectors.setContainer, "");
        showLoader();
        toEditingState();

        if (SUPPORTS_XHR_UPLOAD_PROGRESS) {
            prepareUploadProgressUI();
        }

        var ajaxOptions = {
            url: VE.endpoint,
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            dataType: "text",

            success: function (res) {
                var parsed = safeParseJson(res);
                if (parsed === null) {
                    var rawText = (typeof res === 'string') ? res.replace(/^\uFEFF/, '').trim() : '';
                    if (rawText && rawText.charAt(0) === '<') {
                        hideLoader();
                        html(VE.selectors.setContainer, rawText);
                        stripNativeControls();
                        VE.initEditorForCurrentVideo();
                        show(VE.selectors.setContainer);
                        return;
                    }
                    hideLoader();
                    showToast(I18N('ui_unexpected_response') || 'Unexpected response.', 'error');
                    resetToInitial();
                    return;
                }
                var payload = (typeof parsed === 'string') ? safeParseJson(parsed) : parsed;
                if (typeof payload === 'string' || payload === null) {
                    hideLoader();
                    showToast(I18N('ui_unexpected_response') || 'Unexpected response.', 'error');
                    resetToInitial();
                    return;
                }

                // 3) JSON object handling
                if (payload && payload.status === "success") {
                    if (payload.html) {
                        var payloadMarkup = decodeHtmlPayload(payload.html, payload.html_encoding || 'none');
                        if ((payload.html_encoding || '').toLowerCase() === 'base64' && !payloadMarkup) {
                            hideLoader();
                            showToast(I18N('ui_unexpected_response') || 'Unexpected response.', 'error');
                            resetToInitial();
                            return;
                        }
                        if (!payloadMarkup) {
                            payloadMarkup = payload.html;
                        }
                        hideLoader();
                        html(VE.selectors.setContainer, payloadMarkup);
                        stripNativeControls();
                        VE.initEditorForCurrentVideo();
                    } else if (payload.video_url) {
                        hideLoader();
                        html(VE.selectors.setContainer, buildVideoHTML(payload.video_url, payload.poster || ""));
                        stripNativeControls();
                        VE.initEditorForCurrentVideo();
                    } else {
                        hideLoader();
                        if (payload && payload.message) { showToast(payload.message, 'error'); }
                        resetToInitial();
                        return;
                    }
                    show(VE.selectors.setContainer);
                    return;
                }

                // JSON error or unknown structure: revert UI (server is responsible for messages)
                hideLoader();
                if (payload && payload.message) { showToast(payload.message, (payload.status && payload.status !== 'success') ? 'error' : 'info'); }
                resetToInitial();
            },

            error: function (xhr) {
                hideLoader();
                var msg = I18N('ui_request_failed_retry') || 'Request failed. Please try again.';
                try {
                    if (xhr && xhr.responseText && xhr.responseText.trim().charAt(0) === '{') {
                        var j = JSON.parse(xhr.responseText);
                        if (j && j.message) msg = j.message;
                    }
                } catch(_) {}
                showToast(msg, 'error');
                resetToInitial();
            }
        };

        if (SUPPORTS_XHR_UPLOAD_PROGRESS) {
            ajaxOptions.xhr = function () {
                var xhr = $.ajaxSettings.xhr();
                if (xhr && xhr.upload && typeof xhr.upload.addEventListener === 'function') {
                    xhr.upload.addEventListener('progress', function (event) {
                        if (!event || !event.lengthComputable) { return; }
                        if (!event.total) { return; }
                        var percent = (event.loaded / event.total) * 100;
                        updateUploadProgressValue(percent);
                    }, false);
                }
                return xhr;
            };
        }

        $.ajax(ajaxOptions);
    });

    $(document).on("change", VE.selectors.teaserInput, function () {
        var $root = getVideoPopupRoot(this);
        if (!$root.length) { return; }
        var name = '';
        if (this.files && this.files[0] && this.files[0].name) {
            name = String(this.files[0].name);
        }
        $root.find(VE.selectors.teaserName).text(name);
    });

    // Navigation: Go Back — either to editor from finish step or to pre-upload state.
    $(document).on("click", VE.selectors.goBack, function () {
        var $root = getVideoPopupRoot(this);
        if (!$root.length) { return; }
        // If user is at finish step, go back to edit; else reset to initial
        if (!$root.find(VE.selectors.finishContainer).hasClass('none')) {
            backToEditState();
            return;
        }
        // Otherwise, full reset to initial (before upload)
        var $in = $root.find(VE.selectors.fileInput);
        if ($in.length) { $in.val(""); }
        resetToInitial();
    });


    // Navigation: Go Next — proceed to finalize/publish UI.
    $(document).on("click", VE.selectors.goNext, function () {
        if (!isTargetInsideVideoPopup(this)) { return; }
        toFinishState();
    });

    // =====================
    // Visibility & Price (finish step) — parity with crop.js
    // =====================
    // Ensure hidden post_type input exists inside .advanced_settings_box
    (function ensurePostTypeHiddenInputForVideo(){
        var $box = $('.advanced_settings_box');
        if ($box.length && !$box.find("input[name='post_type']").length) {
            var activeType = $('.post-visiblity.active').data('type') || 'everyone';
            $('<input>', { type: 'hidden', name: 'post_type', value: String(activeType) }).appendTo($box);
        }
    })();

    // Click on visibility pill
    $(document).on('click', '.post-visiblity', function (event) {
        var $item = $(this);
        var $root = getVideoPopupRoot(this);
        if (!$root.length) { return; }
        var type = String($item.data('type') || 'everyone');
        if (!handleVisibilityAccess($item, type)) {
            event.preventDefault();
            event.stopImmediatePropagation();
            return false;
        }
        $root.find('.post-visiblity').removeClass('active');
        $item.addClass('active');
        $root.find("input[name='post_type']").val(type);

        if (type === 'locked') {
            $root.find('.set-price-popup').removeClass('none');
        } else {
            // Hide and reset price UI when leaving locked
            $root.find('.set-price-popup').addClass('none');
            $root.find("input[name='set-price']").val('');
            var $priceSpan = $root.find(".post-visiblity[data-type='locked'] .post-price");
            if ($priceSpan.length) { $priceSpan.text('($)'); }
            $root.find('.set-price-popup .warn').removeClass('form-warning');
        }
        toggleTeaserField($root, type);
    });

    // Save price (validate between min/max), keep 'locked' active
    $(document).on('click', '.set-price-done', function () {
        var $root = getVideoPopupRoot(this);
        if (!$root.length) { return; }
        var $priceInput = $root.find("input[name='set-price']");
        var raw = $priceInput.val();
        var trimmed = $.trim(String(raw || ''));
        var min = parseInt($root.find("input[name='min-price']").val(), 10);
        var max = parseInt($root.find("input[name='max-price']").val(), 10);
        if (!Number.isFinite(min)) { min = 1; }
        if (!Number.isFinite(max)) { max = 500; }
        var amount = parseInt(trimmed, 10);
        var $warn = $root.find('.set-price-popup .warn');

        if (!Number.isFinite(amount) || amount < min || amount > max) {
            $warn.addClass('form-warning');
            return;
        } else {
            $warn.removeClass('form-warning');
        }

        $root.find('.set-price-popup').addClass('none');
        var $priceSpan = $root.find(".post-visiblity[data-type='locked'] .post-price");
        if ($priceSpan.length) { $priceSpan.text('($' + amount + ')'); }

        $root.find('.post-visiblity').removeClass('active');
        $root.find(".post-visiblity[data-type='locked']").addClass('active');
        $root.find("input[name='post_type']").val('locked');
        toggleTeaserField($root, 'locked');
    });

    // Clear price & revert selection
    $(document).on('click', '.set-price-clear', function () {
        var $root = getVideoPopupRoot(this);
        if (!$root.length) { return; }
        $root.find("input[name='set-price']").val('');
        var $priceSpan = $root.find(".post-visiblity[data-type='locked'] .post-price");
        if ($priceSpan.length) { $priceSpan.text('($)'); }
        $root.find(".post-visiblity[data-type='locked']").removeClass('active');
        $root.find('.set-price-popup').addClass('none');

        var activeType = $root.find('.post-visiblity.active').data('type');
        if (activeType) {
            $root.find("input[name='post_type']").val(String(activeType));
        } else {
            $root.find("input[name='post_type']").val('everyone');
            $root.find(".post-visiblity[data-type='everyone']").addClass('active');
        }
        $root.find('.set-price-popup .warn').removeClass('form-warning');
        toggleTeaserField($root, String($root.find("input[name='post_type']").val() || 'everyone'));
    });

    // Stabilize checkbox values to 'on'/'off' like crop.js does (for backend consistency)
    $(document).on('change', "input[name='hide_likes_view'], input[name='turn_on_off_comment']", function () {
        if (!isTargetInsideVideoPopup(this)) { return; }
        $(this).val($(this).is(':checked') ? 'on' : 'off');
    });

    // =====================
    // Finalize → Submit
    // =====================
    // Submits the finalized reel, injects new post into #posts, and closes popup on success.
    // Final submit: upload the finalized reel, append to #posts, show loader, close popup on success
    $(document).on('click', VE.selectors.uploadBtn, function(){
        if (!isTargetInsideVideoPopup(this)) { return; }
        var $btn = $(this);
        // prevent double submit
        if ($btn.prop('disabled')) { return; }
        $btn.prop('disabled', true).addClass('is-busy');
        showPopupLoader();

        var payload = gatherFinishPayload();
        // Build FormData
        var fd = new FormData();
        Object.keys(payload).forEach(function(k){ fd.append(k, payload[k]); });
        var teaserInput = $(VE.selectors.finishContainer).find(VE.selectors.teaserInput).get(0);
        if (teaserInput && teaserInput.files && teaserInput.files[0]) {
            fd.append('video_teaser', teaserInput.files[0]);
        }

        $.ajax({
            url: VE.endpoint,
            type: 'POST',
            data: fd,
            processData: false,
            contentType: false,
            dataType: 'text',
            success: function(res){
    // Accept JSON (object or string)
    var raw = res, j = null;
    j = safeParseJson(raw);
    if (!j && typeof raw === 'string') {
        var maybeHtml = raw.replace(/^\uFEFF/, '').trim();
        if (maybeHtml.charAt(0) === '<') {
            j = { status: 'success', html: maybeHtml };
        }
    }

    if (typeof j === 'string') {
        j = safeParseJson(j);
    }

    if (!j || typeof j !== 'object' || j.status !== 'success') {
        hidePopupLoader();
        var msgErr = (j && j.message) ? j.message : (I18N('ui_unexpected_response') || 'Unexpected response.');
        showToast(msgErr, 'error');
        return;
    }

    if (j.message) { showToast(j.message, 'success'); }

    // Build final markup (prefer server-rendered HTML)
    var markup = '';
    if (j.html && typeof j.html === 'string' && j.html.trim().length) {
        markup = decodeHtmlPayload(j.html, j.html_encoding || 'none');
        if ((j.html_encoding || '').toLowerCase() === 'base64' && !markup) {
            hidePopupLoader();
            showToast(I18N('ui_unexpected_response') || 'Unexpected response.', 'error');
            return;
        }
        if (!markup) {
            markup = j.html;
        }
    } else if (j.final_video_url) {
        markup = buildFeedCardHTML(j.final_video_url, j.poster || '');
    }

    if (!markup) {
        hidePopupLoader();
        showToast(I18N('ui_no_content_to_insert') || 'No content to insert.', 'error');
        return;
    }

    var $posts = $('#posts');
    if ($posts.length) {
        var $node = $(markup);

        // Dedup/replace guard by post_id, else prepend once
        var didInsert = false;
        if (j.post_id && Number.isFinite(Number(j.post_id))) {
            var sel = '#post-' + String(j.post_id);
            if ($(sel).length) {
                $(sel).replaceWith($node);
                didInsert = true;
            }
        }
        if (!didInsert) {
            var $first = $posts.find('.post_').first();
            if ($first.length) {
                $first.before($node);
            } else {
                $posts.prepend($node);
            }
        }

        // Initialize media/controls only once on the new node
        if (typeof DZ !== 'undefined') {
            if (typeof DZ.initPostVideos === 'function') {
                DZ.initPostVideos($node[0]);
            }
            if (typeof DZ.initPostSwipers === 'function') {
                DZ.initPostSwipers($node[0]); // start swipers if present
            }
            if (typeof DZ.initPost === 'function') {
                DZ.initPost($node[0]); // run general initializer if available
            }
        }
    }

    // Close popup on success
    $('.popUp-container').remove();
},
            error: function(xhr){
                hidePopupLoader();
                var msg = 'Request failed. Please try again.';
                try {
                    if (xhr && xhr.responseText && xhr.responseText.trim().charAt(0) === '{') {
                        var jj = JSON.parse(xhr.responseText);
                        if (jj && jj.message) msg = jj.message;
                    }
                } catch(_) {}
                showToast(msg, 'error');
            },
            complete: function(){
                $btn.prop('disabled', false).removeClass('is-busy');
                hidePopupLoader();
            }
        });
    });

    resetToInitial();

})(jQuery, window, document);
