'use strict';
(function (window, $) {
  if (!window || !$) { return; }

  var pageRoot = document.querySelector('.podcasts-page');
  if (!pageRoot) { return; }

  var buildUrl = (window.DZ && window.DZ.buildUrl) || function (path) {
    try {
      var base = (typeof window.site_url === 'string' && window.site_url) ? window.site_url : (window.location.origin + window.location.pathname.replace(/[^\/]*$/, ''));
      if (base.slice(-1) !== '/') { base += '/'; }
      return new URL(String(path || '').replace(/^\//, ''), base).toString();
    } catch (_) {
      return String(path || '');
    }
  };

  var $list = $('.podcasts-list');
  var $sentinel = $('#podcasts-sentinel');
  if (!$list.length || !$sentinel.length) { return; }

  var hasMoreAttr = $sentinel.data('has-more');
  var hasMore = (hasMoreAttr === true || hasMoreAttr === 1 || hasMoreAttr === '1');
  var limit = parseInt($sentinel.data('limit'), 10);
  if (isNaN(limit) || limit <= 0) { limit = 12; }

  var cursorTime = parseInt($sentinel.data('cursor-time') || '0', 10) || 0;
  var cursorId = parseInt($sentinel.data('cursor-id') || '0', 10) || 0;
  var category = ($sentinel.data('category') || '').toString();
  var loadingLabel = ($sentinel.data('loading-label') || '').toString();
  var doneLabel = ($sentinel.data('done-label') || '').toString();

  var busy = false;
  var observer = null;

  function setLabel(text) {
    if (!$sentinel.length) { return; }
    var safe = (text || '').toString();
    if (safe !== '') {
      $sentinel.text(safe);
    }
  }

  function setLoading(state) {
    if (!$sentinel.length) { return; }
    if (state) {
      $sentinel.addClass('is-loading');
      setLabel(loadingLabel);
    } else {
      $sentinel.removeClass('is-loading');
    }
  }

  function markComplete() {
    hasMore = false;
    $sentinel.attr('data-has-more', '0').addClass('is-complete');
    setLabel(doneLabel);
    if (observer && typeof observer.disconnect === 'function') {
      observer.disconnect();
    }
  }

  function updateCursor(nextCursor) {
    if (!nextCursor || typeof nextCursor !== 'object') { return; }
    var nTime = parseInt(nextCursor.time || '0', 10);
    var nId = parseInt(nextCursor.id || '0', 10);
    if (!isNaN(nTime) && nTime >= 0) { cursorTime = nTime; }
    if (!isNaN(nId) && nId >= 0) { cursorId = nId; }
    $sentinel.attr('data-cursor-time', cursorTime);
    $sentinel.attr('data-cursor-id', cursorId);
  }

  function requestMore() {
    if (busy || !hasMore) { return; }
    busy = true;
    setLoading(true);

    var csr = $('input[name="csrf_token"]').val() || '';
    $.ajax({
      url: buildUrl('request/requests.php'),
      type: 'POST',
      dataType: 'json',
      data: {
        p: 'podcasts_more',
        csrf_token: csr,
        cursor_time: cursorTime,
        cursor_id: cursorId,
        category: category,
        limit: limit
      }
    }).done(function (res) {
      if (!res || res.status !== 'ok') {
        markComplete();
        return;
      }
      if (res.html) {
        $list.append(res.html);
      }
      updateCursor(res.next_cursor || {});
      hasMore = !!res.has_more;
      if (!hasMore) {
        markComplete();
      }
    }).fail(function () {
      markComplete();
    }).always(function () {
      busy = false;
      setLoading(false);
    });
  }

  if ('IntersectionObserver' in window) {
    observer = new IntersectionObserver(function (entries) {
      var entry = entries && entries[0];
      if (!entry) { return; }
      if (entry.isIntersecting || entry.intersectionRatio > 0) {
        requestMore();
      }
    }, { root: null, rootMargin: '1200px 0px 1200px 0px', threshold: [0, 0.01] });
    observer.observe($sentinel.get(0));
  }

  var ticking = false;
  function fallbackTick() {
    if (!hasMore || busy) { return; }
    var doc = document.documentElement;
    var st = (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
    var vh = window.innerHeight || doc.clientHeight;
    var full = Math.max(doc.scrollHeight, doc.offsetHeight, doc.clientHeight);
    if (full - (st + vh) < 1400) { requestMore(); }
  }
  function onScroll() {
    if (ticking) { return; }
    ticking = true;
    window.requestAnimationFrame(function () {
      ticking = false;
      fallbackTick();
    });
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onScroll, { passive: true });
})(window, window.jQuery);
