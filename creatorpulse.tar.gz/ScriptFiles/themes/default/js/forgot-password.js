/* eslint-env jquery */
(function ($) {
  'use strict';

  var buildUrl = (window.DZ && typeof window.DZ.buildUrl === 'function')
    ? window.DZ.buildUrl
    : function (path) {
        var base = (typeof window.site_url === 'string' && window.site_url)
          ? window.site_url
          : (window.location.origin + window.location.pathname.replace(/[^\/]*$/, ''));
        if (base.slice(-1) !== '/') {
          base += '/';
        }
        return base + String(path || '').replace(/^\/+/, '');
      };

  $(document).on('submit', '.forgot-password-form', function (event) {
    event.preventDefault();

    var $form = $(this);
    var $button = $form.find('.login-submit');
    var $warning = $form.find('#forgotWarning');
    var $success = $form.find('#forgotSuccess');
    var email = $.trim($form.find('input[name="email"]').val());
    var csrfToken = $form.find('input[name="csrf_token"]').val();
    var errorRequired = $form.data('error-required') || 'Please fill all fields.';
    var errorInvalid = $form.data('error-invalid') || 'Please provide a valid email.';
    var errorLimit = $form.data('error-limit') || 'Too many requests. Please try again later.';
    var errorUnexpected = $form.data('error-unexpected') || 'Unexpected error occurred.';
    var successMessage = $form.data('success') || $form.data('success-message') || 'Please check your inbox for further instructions.';
    var loadingText = $form.data('loading-text') || 'Processing...';
    var originalText = $button.data('default-text');
    if (!originalText) {
      originalText = $button.text();
      $button.data('default-text', originalText);
    }

    var resetMessages = function () {
      [$warning, $success].forEach(function ($el) {
        if ($el && $el.length) {
          $el.addClass('none').text('');
        }
      });
    };
    var showMessage = function ($el, message) {
      if ($el && $el.length) {
        $el.removeClass('none').text(message);
      }
    };

    resetMessages();

    if (!email) {
      showMessage($warning, errorRequired);
      return;
    }

    var requestData = {
      p: 'forgot_password_request',
      email: email,
      csrf_token: csrfToken
    };

    $.ajax({
      type: 'POST',
      url: buildUrl('request/requests.php'),
      dataType: 'json',
      data: requestData,
      beforeSend: function () {
        $button.prop('disabled', true).text(loadingText);
      },
      success: function (response) {
        if (response && response.status === 'success') {
          var message = response.message || successMessage;
          showMessage($success, message);
          setTimeout(function () {
            var redirect = response.redirect ? String(response.redirect) : 'forgot_password_sent';
            window.location.href = buildUrl(redirect);
          }, 800);
        } else {
          var message = (response && response.message) ? response.message : errorUnexpected;
          if (message === 'invalid_email') {
            message = errorInvalid;
          }
          if (message === 'rate_limit') {
            message = errorLimit;
          }
          showMessage($warning, message);
        }
      },
      error: function () {
        showMessage($warning, errorUnexpected);
      },
      complete: function () {
        $button.prop('disabled', false).text(originalText);
      }
    });
  });
})(jQuery);
