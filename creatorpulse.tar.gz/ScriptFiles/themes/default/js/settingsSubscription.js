(function(){
  'use strict';

  var STATUS_CLASSES = ['status-badge--success', 'status-badge--pending', 'status-badge--danger', 'status-badge--neutral'];

  function formatAccessDate(timestamp){
    var ts = Number(timestamp);
    if (!isFinite(ts) || ts <= 0) { return ''; }
    try {
      var date = new Date(ts * 1000);
      if (isNaN(date.getTime())) { return ''; }
      var day = String(date.getDate()).padStart(2, '0');
      var month = String(date.getMonth() + 1).padStart(2, '0');
      var year = date.getFullYear();
      return day + '.' + month + '.' + year;
    } catch (_) {
      return '';
    }
  }

  function ready(fn){
    if (document.readyState !== 'loading') { fn(); }
    else { document.addEventListener('DOMContentLoaded', fn); }
  }

  function ensureToastStack(){
    var stack = document.querySelector('.settings-toast-stack');
    if (stack) { return stack; }
    stack = document.createElement('div');
    stack.className = 'settings-toast-stack';
    stack.setAttribute('role', 'status');
    stack.setAttribute('aria-live', 'polite');
    document.body.appendChild(stack);
    return stack;
  }

  function createToast(message, type){
    var stack = ensureToastStack();
    var toast = document.createElement('div');
    toast.className = 'settings-toast';
    var tone = (type || 'info').toLowerCase();
    if (tone === 'success') { toast.classList.add('is-success'); }
    else if (tone === 'error') { toast.classList.add('is-error'); }
    else { toast.classList.add('is-info'); }
    toast.textContent = String(message || '');
    stack.appendChild(toast);
    requestAnimationFrame(function(){ toast.classList.add('is-visible'); });
    setTimeout(function(){
      toast.classList.remove('is-visible');
      setTimeout(function(){ if (toast && toast.parentNode) { toast.parentNode.removeChild(toast); } }, 260);
    }, 3200);
  }

  function showToast(message, type){
    try {
      if (window.DZ && typeof window.DZ.toast === 'function') {
        window.DZ.toast(String(message || ''), { type: type || 'info', duration: 2600 });
        return;
      }
    } catch (_) {}
    createToast(message, type);
  }

  function closePopup(root){
    var popup = root.closest('.post-menu-popup');
    if (!popup) { return; }
    popup.classList.add('none');
    popup.setAttribute('aria-hidden', 'true');
    var popupId = popup.getAttribute('id');
    if (popupId) {
      var trigger = document.querySelector('.post-settings-btn[data-id="' + popupId.replace('postMenuPopup-', '') + '"]');
      if (trigger) { trigger.setAttribute('aria-expanded', 'false'); }
    } else {
      var triggerAlt = popup.closest('td');
      if (triggerAlt) {
        var btn = triggerAlt.querySelector('.post-settings-btn[aria-expanded="true"]');
        if (btn) { btn.setAttribute('aria-expanded', 'false'); }
      }
    }
  }

  function ensureFormSubmission(){
    document.addEventListener('click', function(ev){
      if (!ev || !ev.target || typeof ev.target.closest !== 'function') { return; }
      var btn = ev.target.closest('.subscription-action-form button.pm-item');
      if (!btn) { return; }
      var form = btn.closest('form');
      if (!form) { return; }
      ev.preventDefault();
      ev.stopPropagation();
      if (form.dataset.processing === '1') { return; }
      if (typeof form.requestSubmit === 'function') {
        form.requestSubmit(btn);
      } else {
        var submitEvent = new Event('submit', { bubbles: true, cancelable: true });
        if (!form.dispatchEvent(submitEvent)) { return; }
        if (!submitEvent.defaultPrevented) {
          form.submit();
        }
      }
    }, true);
  }

  function updateSubscriptionRow(form, options){
    if (!form || !options) { return; }
    var row = form.closest('tr');
    if (!row) { return; }

    if (options.statusText || options.statusClass) {
      var statusEl = row.querySelector('.status-badge');
      if (statusEl) {
        if (options.statusText) { statusEl.textContent = String(options.statusText); }
        if (options.statusClass) {
          STATUS_CLASSES.forEach(function(cls){ statusEl.classList.remove(cls); });
          statusEl.classList.add(options.statusClass);
        }
      }
    }

    if (options.note) {
      var actionsCell = row.querySelector('.subscription-actions');
      if (!actionsCell) { actionsCell = row.querySelector('td:last-child'); }
      if (actionsCell) {
        var noteEl = actionsCell.querySelector('.subscription-action-note');
        if (!noteEl) {
          noteEl = document.createElement('div');
          noteEl.className = 'subscription-action-note';
          actionsCell.appendChild(noteEl);
        }
        noteEl.textContent = String(options.note || '');
        noteEl.classList.remove('is-success', 'is-error', 'is-info');
        if (options.noteType) { noteEl.classList.add('is-' + options.noteType); }
      }
    }

    if (options.disablePopup) {
      var toggler = row.querySelector('.post-settings-btn');
      if (toggler) {
        toggler.setAttribute('aria-disabled', 'true');
        toggler.classList.add('is-disabled');
        toggler.setAttribute('tabindex', '-1');
      }
      row.querySelectorAll('.subscription-action-form button').forEach(function(btn){
        btn.disabled = true;
        btn.classList.add('is-disabled');
      });
    }

    if (options.rowClass) {
      row.classList.add(options.rowClass);
    }

    if (typeof options.accessUntil !== 'undefined' || typeof options.accessUntilLabel === 'string') {
      var renewalEl = row.querySelector('.subscription-date--renewal');
      if (renewalEl) {
        var displayLabel = (typeof options.accessUntilLabel === 'string' && options.accessUntilLabel !== '')
          ? options.accessUntilLabel
          : formatAccessDate(options.accessUntil);
        if (displayLabel) {
          var template = 'Access until %s';
          try {
            if (window.DZ && typeof window.DZ.i18n === 'function') {
              var pattern = window.DZ.i18n('settings_subscription_access_until_short');
              if (pattern && typeof pattern === 'string') { template = pattern; }
            }
          } catch (_) {}
          var text = template.indexOf('%s') !== -1 ? template.replace('%s', displayLabel) : template;
          renewalEl.textContent = text;
          renewalEl.classList.add('subscription-date--pending-cancel');
        }
      }
      row.classList.add('subscription-row--pending-cancel');
    }
  }

  ready(function(){
    ensureFormSubmission();
    document.addEventListener('submit', function(ev){
      var form = ev.target;
      if (!form || !form.classList || !form.classList.contains('subscription-action-form')) { return; }
      ev.preventDefault();
      if (form.dataset.processing === '1') { return; }
      form.dataset.processing = '1';

      var submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) { submitBtn.disabled = true; submitBtn.classList.add('is-disabled'); }

      var parentPopup = form.closest('.post-menu-popup');

      var action = form.getAttribute('data-subscription-action') || '';
      var endpoint = form.getAttribute('action') || '';
      if (!endpoint) { endpoint = window.location.href; }
      var formData = new FormData(form);

      fetch(endpoint, {
        method: 'POST',
        credentials: 'same-origin',
        body: formData
      }).then(function(res){
        var contentType = res.headers.get('content-type') || '';
        if (contentType.indexOf('application/json') !== -1) {
          return res.json();
        }
        return res.text().then(function(text){
          try { return JSON.parse(text); }
          catch (_) { return { status: res.ok ? 'success' : 'error', raw: text }; }
        });
      }).then(function(payload){
        var data = payload || {};
        var status = (typeof data.status === 'string') ? data.status.toLowerCase() : '';
        if (status === 'success') {
          closePopup(form);
          var defaultSuccess = action === 'cancel'
            ? ((window.DZ && window.DZ.i18n) ? window.DZ.i18n('settings_subscription_cancel_success') : 'Subscription cancelled successfully.')
            : ((window.DZ && window.DZ.i18n) ? window.DZ.i18n('settings_subscription_update_payment') : 'Payment updated.');
          var successMessage = data.message || defaultSuccess;
          showToast(successMessage, 'success');

          if (action === 'cancel') {
            var cancelledLabel = form.getAttribute('data-success-status-label') || 'Cancelled';
            var accessUntilTs = typeof data.access_until === 'number' ? data.access_until : null;
            var accessUntilLabel = typeof data.access_until_label === 'string' ? data.access_until_label : '';
            updateSubscriptionRow(form, {
              statusText: cancelledLabel,
              statusClass: 'status-badge--pending',
              note: successMessage,
              noteType: 'success',
              disablePopup: true,
              rowClass: 'subscription-row--pending-cancel',
              accessUntil: accessUntilTs,
              accessUntilLabel: accessUntilLabel
            });
          } else {
            updateSubscriptionRow(form, {
              note: successMessage,
              noteType: data.redirect_url || data.checkout_url ? 'info' : 'success'
            });
          }

          var redirectUrl = data.redirect_url || data.checkout_url;
          if (redirectUrl) {
            setTimeout(function(){ window.location.href = redirectUrl; }, 1100);
          }
        } else {
          var message = data.message || data.error || ((window.DZ && window.DZ.i18n) ? window.DZ.i18n('ui_unknown_error') : 'Something went wrong.');
          showToast(message, 'error');
          updateSubscriptionRow(form, {
            note: message,
            noteType: 'error'
          });
        }
      }).catch(function(){
        showToast('Network error. Please try again.', 'error');
        updateSubscriptionRow(form, {
          note: 'Network error. Please try again.',
          noteType: 'error'
        });
      }).finally(function(){
        delete form.dataset.processing;
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.classList.remove('is-disabled');
        }
        if (parentPopup) {
          if (parentPopup.classList.contains('none')) {
            parentPopup.setAttribute('aria-hidden', 'true');
          } else {
            parentPopup.removeAttribute('aria-hidden');
          }
        }
      });
    });
  });
})();
