(function() {
  'use strict';

  // ---- lifecycle controls ----
  // If a previous chat instance exists, tear it down first
  if (window.chatController && typeof window.chatController.destroy === 'function') {
    try { window.chatController.destroy(); } catch (e) {}
  }
  var destroyed = false;       // flipped to true on teardown
  var pollTimer = null;        // stores setInterval id
  var keyHandler = null;       // keydown handler reference
  var abortController = ('AbortController' in window) ? new AbortController() : null;

  var list = document.getElementById('chatScroll');
  if (!list) return;

  var buildUrl = (window.DZ && window.DZ.buildUrl) || function(path){
    try { var base=(typeof window.site_url==='string'&&window.site_url)?window.site_url:(window.location.origin+window.location.pathname.replace(/[^\\/]*$/,'')); if(base.slice(-1)!=='/') base+='/'; return new URL(String(path||'').replace(/^\//,''), base).toString(); } catch(_) { return String(path||''); }
  };

  var REQUEST_URL = buildUrl('request/chat.php');

  // --- Icon resolver (theme-aware) ---
  var ICONS = (function(){
    // Prefer inline SVG markup from data-* (rendered via PHP renderVerifiedBadge)
    function html(name){
      // Prefer hidden templates rendered by PHP helper
      try {
        var wrap = document.getElementById('chat-icon-templates');
        if (wrap) {
          var node = wrap.querySelector('[data-icon="' + name + '"]');
          if (node) { return node.innerHTML || ''; }
        }
      } catch (__) {}
      return '';
    }
    // URL fallback if no inline markup available
    function url(name){
      var base = null;
      try {
        var meta = document.querySelector('meta[name="icon-theme-base"]');
        if (meta) {
          base = meta.getAttribute('content') || '';
        }
        if (base) {
          base = base.replace(/\/+$/, '') + '/';
        }
      } catch (__) {}
      if (!base) {
        try {
          var any = document.querySelector('img[src*="/themes/"][src*="/icons/"]');
          if (any && any.src) {
            var s = any.src; var idx = s.toLowerCase().lastIndexOf('/icons/');
            if (idx > 0) { base = s.slice(0, idx + 7); }
          }
        } catch (__) {}
      }
      if (!base) { base = (window.site_url || '/') + 'themes/default/icons/'; }
      return base + name + '.svg';
    }
    return { html: html, url: url };
  })();

  // ---- Auto-scroll helpers ----
  function isNearBottom(threshold){
    var t = (typeof threshold === 'number' ? threshold : 120);
    try {
      var distance = (list.scrollHeight - list.scrollTop - list.clientHeight);
      return distance <= t;
    } catch (e) { return true; }
  }
  function scrollToBottom(smooth) {
    try {
      if (smooth) {
        list.scrollTo({ top: list.scrollHeight, behavior: 'smooth' });
      } else {
        list.scrollTop = list.scrollHeight;
      }
    } catch (e) {
      list.scrollTop = list.scrollHeight;
    }
  }

  // More reliable bottoming: nudge after layout/media load
  var bottomNudgeTimer = null;
  function nudgeBottomSoon(force) {
    try { if (bottomNudgeTimer) clearTimeout(bottomNudgeTimer); } catch (e) {}
    bottomNudgeTimer = setTimeout(function(){
      if (destroyed) return;
      if (isLoadingOlder && !force) { return; }
      if (force || isNearBottom()) {
        scrollToBottom(false);
        requestAnimationFrame(function(){ if (!destroyed) scrollToBottom(false); });
        setTimeout(function(){ if (!destroyed) scrollToBottom(false); }, 160);
      }
    }, 10);
  }

  function scrollToBottomReliable(force) {
    if (isLoadingOlder) { return; }
    if (force || isNearBottom()) {
      scrollToBottom(true);
      nudgeBottomSoon(true);
    }
  }

  // Initial autoscroll after layout and once media resolved
  requestAnimationFrame(function(){ scrollToBottomReliable(true); });
  // Server already marks on get_live_chat; no client mark here (reduces requests)

  // ---- Day label helper ----
  function __i18n(key, params){
    try { if (window.DZ && typeof DZ.i18n === 'function') { return DZ.i18n(key, params); } } catch(_){}
    try {
      var el = document.querySelector('meta[name="i18n.' + key + '"]');
      var s = el ? (el.getAttribute('content') || '') : '';
      if (s && params && typeof params === 'object') {
        Object.keys(params).forEach(function(k){
          s = s.replace(new RegExp('\\{' + k + '\\}', 'g'), String(params[k]));
        });
      }
      return s;
    } catch(e){ return ''; }
  }

  function t(key, fallback, params){
    var value = __i18n(key, params);
    return value || fallback || key;
  }

  function formatChatTipMoney(value){
    var amount = parseFloat(value);
    if (!isFinite(amount)) { amount = 0; }
    var formatted = amount.toFixed(2);
    var symbol = chatCurrencySymbol || chatCurrencyCode;
    return (String(symbol).length <= 4 ? symbol + formatted : formatted + ' ' + (chatCurrencyCode || symbol));
  }

  function chatTipErrorMessage(code, data){
    var payload = data || {};
    var messageCode = String(code || 'error');
    if (messageCode === 'insufficient_wallet') {
      return t('chat_tip_error_insufficient_wallet', 'Your wallet balance is not enough. Available: {balance}. Required: {required}.', {
        balance: formatChatTipMoney(payload.balance),
        required: formatChatTipMoney(payload.required)
      });
    }
    if (messageCode === 'recipient_not_creator') {
      return t('chat_tip_error_recipient_not_creator', 'Tips can only be sent to approved creators.');
    }
    if (messageCode === 'invalid_parameters') {
      return t('chat_tip_error_invalid_amount', 'Enter a valid tip amount and try again.');
    }
    if (messageCode === 'network') {
      return t('chat_tip_error_network', 'The tip could not be sent. Check your connection and try again.');
    }
    return t('chat_tip_error_generic', 'The tip could not be sent. Please try again.');
  }
  function formatDayLabelFromYMD(ymd) {
    // ymd: "YYYY-MM-DD"
    var parts = (ymd || '').split('-');
    if (parts.length !== 3) return ymd || '';
    var y = parseInt(parts[0], 10), m = parseInt(parts[1], 10)-1, d = parseInt(parts[2], 10);

    var now = new Date();
    var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var msg  = new Date(y, m, d);
    var diffMs = today - msg; // ms
    var diffDays = Math.round(diffMs / 86400000);

    if (diffDays === 0) return __i18n('chat_day_today') || 'Today';
    if (diffDays === 1) return __i18n('chat_day_yesterday') || 'Yesterday';
    if (diffDays > 1 && diffDays <= 6) return __i18n('chat_day_days_ago', { days: diffDays }) || (diffDays + ' days ago');

    // dd.mm.yyyy fallback
    var dd = ('0' + d).slice(-2);
    var mm = ('0' + (m+1)).slice(-2);
    return dd + '.' + mm + '.' + y;
  }

  // ---- Ensure day headers on dynamic insert ----
  function ensureDayHeaderFor(node) {
    if (!node || !node.classList || !node.classList.contains('chat_message_row')) return;
    var ymd = node.getAttribute('data-ymd');
    if (!ymd) return;

    // Find the closest previous sibling that is a chat_meta
    var prev = node.previousElementSibling;
    var hasHeaderBefore = false;
    while (prev) {
      if (prev.classList.contains('chat_meta')) {
        hasHeaderBefore = prev.getAttribute('data-ymd') === ymd;
        break;
      }
      // stop seeking if we cross into previous date group
      if (prev.classList.contains('chat_message_row')) {
        var prevY = prev.getAttribute('data-ymd');
        if (prevY && prevY !== ymd) break;
      }
      prev = prev.previousElementSibling;
    }

    if (hasHeaderBefore) { return; }

    // If a header for this ymd exists elsewhere (likely below when prepending), move it above this node
    var existing = list.querySelector('.chat_meta[data-ymd="' + ymd.replace(/"/g, '') + '"]');
    if (existing) {
      if (existing !== node.previousElementSibling) {
        try { node.parentNode.insertBefore(existing, node); } catch (e) {}
      }
      // Remove any duplicates beyond the first
      var dups = list.querySelectorAll('.chat_meta[data-ymd="' + ymd.replace(/"/g, '') + '"]');
      for (var i = 1; i < dups.length; i++) {
        try { if (dups[i] !== existing && dups[i].parentNode) { dups[i].parentNode.removeChild(dups[i]); } } catch (e) {}
      }
      return;
    }

    // Otherwise, create a new header before this node
    var header = document.createElement('div');
    header.className = 'chat_meta';
    header.setAttribute('data-ymd', ymd);
    header.textContent = formatDayLabelFromYMD(ymd);
    node.parentNode.insertBefore(header, node);
  }

  // Observe new messages appended to list
  var mo = new MutationObserver(function(mutations) {
    var needScroll = false;
    mutations.forEach(function(m) {
      if (m.type === 'childList' && m.addedNodes && m.addedNodes.length) {
        m.addedNodes.forEach(function(n) {
          if (n.nodeType === 1) {
            ensureDayHeaderFor(n);
            if (n.classList.contains('chat_message_row')) {
              var hasMedia = n.getAttribute('data-has-media') === '1';
              if (!hasMedia) { needScroll = true; }
            }
          }
        });
      }
    });
    if (!isLoadingOlder && needScroll && isNearBottom()) { scrollToBottomReliable(); }
  });

  mo.observe(list, { childList: true, subtree: true });

  // Trigger older fetch on reaching near top
  var topThreshold = 120;
  list.addEventListener('scroll', function(){
    if (destroyed) return;
    if (list.scrollTop <= topThreshold) {
      fetchOlder();
    }
  });

  // ---- Live chat (AJAX) ----
  // Expect #chatScroll to carry dataset: data-chat-user and optional data-other-avatar
  var chatPartnerId = (function(){
    var v = list.getAttribute('data-chat-user');
    return v ? parseInt(v, 10) : 0;
  })();
  try { window.DZ = window.DZ || {}; DZ.activeChatUserId = chatPartnerId || 0; } catch (__) {}
  var otherAvatar = list.getAttribute('data-other-avatar') || '';
  var canSendTip = list.getAttribute('data-can-tip') === '1';
  var canSendPaidMedia = list.getAttribute('data-can-paid-media') === '1';
  var chatCurrencyCode = list.getAttribute('data-currency-code') || 'USD';
  var chatCurrencySymbol = list.getAttribute('data-currency-symbol') || chatCurrencyCode;
  var olderLimit = parseInt(list.getAttribute('data-limit') || '20', 10);
  if (!isFinite(olderLimit) || olderLimit <= 0) olderLimit = 20;

  var input   = document.querySelector('.chat_textarea');
  var sendBtn = document.querySelector('.send_btn');
  var inputAreaWrapper = document.querySelector('.chat_input_area_wrapper');
  var compactActions = document.querySelector('[data-chat-compact-actions]');
  var actionsToggle = document.querySelector('[data-chat-actions-toggle]');
  var replyTarget = null;
  var replyBar = null;
  var tipPanel = null;
  var paidPanel = null;

  // Chat emoji picker
  // The chat view can be opened or replaced through AJAX, so this behavior
  // belongs to the chat controller rather than only to the feed script.
  function insertChatEmojiAtCursor(textarea, emoji){
    if (!textarea) { return; }
    var value = textarea.value || '';
    var start = (typeof textarea.selectionStart === 'number') ? textarea.selectionStart : value.length;
    var end = (typeof textarea.selectionEnd === 'number') ? textarea.selectionEnd : value.length;
    var scrollTop = textarea.scrollTop;
    textarea.value = value.slice(0, start) + emoji + value.slice(end);
    var caret = start + emoji.length;
    if (textarea.setSelectionRange) { textarea.setSelectionRange(caret, caret); }
    textarea.scrollTop = scrollTop;
    textarea.focus();
    try { textarea.dispatchEvent(new Event('input', { bubbles: true })); } catch (_) {}
  }

  function setupChatEmojiPicker(){
    if (window.__cpChatEmojiPickerBound) { return; }
    window.__cpChatEmojiPickerBound = true;

    document.addEventListener('click', function(event){
      var button = event.target && event.target.closest ? event.target.closest('.chat_input_area .get_emojis') : null;
      if (!button) { return; }
      event.preventDefault();

      var id = button.getAttribute('data-id') || '01';
      var wrapper = document.querySelector('.chat_input_area .make-emoji-wrapper.get_emojis_' + id);
      if (!wrapper) { return; }

      var currentList = wrapper.querySelector('.make-comment-emoji-list');
      if (currentList) {
        currentList.remove();
        button.setAttribute('aria-expanded', 'false');
        return;
      }

      document.querySelectorAll('.chat_input_area .make-emoji-wrapper .make-comment-emoji-list').forEach(function(listEl){
        if (listEl !== currentList) { listEl.remove(); }
      });

      if (button.getAttribute('data-emoji-loading') === '1') { return; }
      button.setAttribute('data-emoji-loading', '1');
      button.classList.add('is-loading');

      var form = new FormData();
      form.append('p', 'getEmojiList');
      form.append('csrf_token', getCsrf());
      fetch(buildUrl('request/requests.php'), {
        method: 'POST',
        credentials: 'same-origin',
        body: form
      }).then(function(response){
        if (!response.ok) { throw new Error('Emoji list request failed'); }
        return response.json();
      }).then(function(response){
        if (response && response.status === 'success' && response.html && !wrapper.querySelector('.make-comment-emoji-list')) {
          wrapper.insertAdjacentHTML('beforeend', response.html);
          button.setAttribute('aria-expanded', 'true');
        }
      }).catch(function(){
        button.setAttribute('aria-expanded', 'false');
      }).finally(function(){
        button.removeAttribute('data-emoji-loading');
        button.classList.remove('is-loading');
      });
    });

    document.addEventListener('click', function(event){
      if (event.target && event.target.closest && (event.target.closest('.chat_input_area .get_emojis') || event.target.closest('.chat_input_area .make-comment-emoji-list'))) {
        return;
      }
      document.querySelectorAll('.chat_input_area .make-emoji-wrapper .make-comment-emoji-list').forEach(function(listEl){
        listEl.remove();
      });
      document.querySelectorAll('.chat_input_area .get_emojis[aria-expanded="true"]').forEach(function(button){
        button.setAttribute('aria-expanded', 'false');
      });
    });

    document.addEventListener('click', function(event){
      var emojiButton = event.target && event.target.closest ? event.target.closest('.chat_input_area .make-comment-emoji-list .emoji') : null;
      if (!emojiButton) { return; }
      event.preventDefault();
      var textarea = document.querySelector('.chat_input_area textarea[name="post-text"]');
      if (!textarea || textarea.disabled) { return; }
      insertChatEmojiAtCursor(textarea, emojiButton.textContent || '');
      var listEl = emojiButton.closest('.make-comment-emoji-list');
      if (listEl) { listEl.remove(); }
      var toggle = document.querySelector('.chat_input_area .get_emojis[aria-expanded="true"]');
      if (toggle) { toggle.setAttribute('aria-expanded', 'false'); }
    });
  }

  setupChatEmojiPicker();

  function setComposerActionsOpen(forceOpen){
    if (!inputAreaWrapper || !compactActions || !actionsToggle) { return; }
    var shouldOpen = typeof forceOpen === 'boolean'
      ? forceOpen
      : !inputAreaWrapper.classList.contains('is-actions-open');
    inputAreaWrapper.classList.toggle('is-actions-open', shouldOpen);
    actionsToggle.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
  }

  function syncComposerActions(){
    if (!inputAreaWrapper || !input) { return; }
    var isTyping = (input.value || '').trim().length > 0;
    inputAreaWrapper.classList.toggle('is-typing', isTyping);
    setComposerActionsOpen(false);
  }

  var composerToggleHandler = function(event){
    event.preventDefault();
    event.stopPropagation();
    setComposerActionsOpen();
  };
  var composerActionsHandler = function(event){
    if (event.target.closest('.chat_input_icon')) { setComposerActionsOpen(false); }
  };
  var composerOutsideClickHandler = function(event){
    if (!inputAreaWrapper || !inputAreaWrapper.classList.contains('is-actions-open')) { return; }
    if (!compactActions || !actionsToggle) { return; }
    if (!compactActions.contains(event.target) && !actionsToggle.contains(event.target)) {
      setComposerActionsOpen(false);
    }
  };

  if (actionsToggle) { actionsToggle.addEventListener('click', composerToggleHandler); }
  if (compactActions) { compactActions.addEventListener('click', composerActionsHandler); }
  document.addEventListener('click', composerOutsideClickHandler);

  var isSending = false;
  var isLoadingOlder = false;
  var noMoreOlder = false;
  var olderLoaderEl = null;
  var lastTs = (function(){
    var last = list.querySelector('.chat_message_row:last-of-type');
    return last ? parseInt(last.getAttribute('data-ts') || '0', 10) : 0;
  })();

  function rowPreviewText(row){
    if (!row) { return ''; }
    var bubble = row.querySelector('.chat_bubble') || row;
    if (bubble.querySelector('.chat_paid_media')) {
      return t('chat_preview_sent_paid_media', 'Sent paid media');
    }
    var clone = bubble.cloneNode(true);
    clone.querySelectorAll('.chat_status, .tick_icon, .chat_message_actions, .chat_reactions, .chat_reaction_rail, .chat_action_menu, .chat_reply_quote, svg, img, video, source').forEach(function(node){
      if (node.parentNode) { node.parentNode.removeChild(node); }
    });
    var text = (clone.textContent || '').replace(/\s+/g, ' ').trim();
    if (text) { return text.length > 120 ? text.slice(0, 117) + '...' : text; }
    if (bubble.querySelector('img')) { return t('chat_preview_image', 'Image'); }
    if (bubble.querySelector('video')) { return t('chat_preview_video', 'Video'); }
    if (bubble.querySelector('.chat-share-card')) { return t('chat_preview_shared_post_short', 'Shared post'); }
    return t('chat_reply_message_fallback', 'Message');
  }

  function ensureReplyBar(){
    if (replyBar && replyBar.parentNode) { return replyBar; }
    var inputArea = document.querySelector('.chat_input_area');
    if (!inputArea) { return null; }
    replyBar = veCreate('div', 'chat_reply_composer');
    replyBar.hidden = true;
    replyBar.innerHTML = '<div><span>' + escapeHtml(t('chat_replying_to_message', 'Replying to message')) + '</span><strong></strong></div><button type="button" data-chat-action="cancel-reply" aria-label="' + escapeHtml(t('chat_cancel_reply', 'Cancel reply')) + '">&times;</button>';
    inputArea.insertBefore(replyBar, inputArea.firstChild);
    return replyBar;
  }

  function setReplyTarget(row){
    if (!row) { return; }
    var mid = parseInt(row.getAttribute('data-mid') || '0', 10) || 0;
    if (!mid) { return; }
    replyTarget = { id: mid, text: rowPreviewText(row) };
    var bar = ensureReplyBar();
    if (bar) {
      var strong = bar.querySelector('strong');
      if (strong) { strong.textContent = replyTarget.text || t('chat_reply_message_fallback', 'Message'); }
      bar.hidden = false;
    }
    if (input) { input.focus(); }
  }

  function clearReplyTarget(){
    replyTarget = null;
    if (replyBar) { replyBar.hidden = true; }
  }

  function ensureTipPanel(){
    if (!canSendTip) { return null; }
    if (tipPanel && tipPanel.parentNode) { return tipPanel; }
    var inputArea = document.querySelector('.chat_input_area');
    if (!inputArea) { return null; }
    tipPanel = veCreate('div', 'chat_tip_panel');
    tipPanel.hidden = true;
    tipPanel.innerHTML = ''
      + '<div class="chat_tip_panel__copy"><span>' + escapeHtml(t('chat_send_tip', 'Send tip')) + '</span><strong>' + escapeHtml(t('chat_tip_support_creator', 'Support this creator')) + '</strong></div>'
      + '<label><span>' + escapeHtml(chatCurrencySymbol) + '</span><input type="number" min="1" max="500" step="1" value="5" data-chat-tip-amount></label>'
      + '<button type="button" data-chat-tip-send>' + escapeHtml(t('chat_send_tip', 'Send tip')) + '</button>'
      + '<button type="button" data-chat-tip-close aria-label="' + escapeHtml(t('close', 'Close')) + '">&times;</button>'
      + '<div class="chat_tip_panel__error" data-chat-tip-error role="alert" aria-live="polite" hidden></div>';
    var reply = ensureReplyBar();
    inputArea.insertBefore(tipPanel, reply && reply.parentNode === inputArea ? reply.nextSibling : inputArea.firstChild);
    var tipAmountInput = tipPanel.querySelector('[data-chat-tip-amount]');
    if (tipAmountInput) {
      tipAmountInput.addEventListener('input', function(){ setChatTipError(tipPanel, ''); });
    }
    return tipPanel;
  }

  function setChatTipError(panel, message, options){
    if (!panel) { return; }
    var errorNode = panel.querySelector('[data-chat-tip-error]');
    var text = String(message || '').trim();
    if (!text) {
      panel.removeAttribute('data-error');
      if (errorNode) {
        errorNode.hidden = true;
        errorNode.textContent = '';
      }
      return;
    }
    panel.setAttribute('data-error', text);
    if (errorNode) {
      errorNode.textContent = '';
      var messageNode = veCreate('span', 'chat_tip_panel__error_text');
      messageNode.textContent = text;
      errorNode.appendChild(messageNode);
      if (options && options.topup) {
        var topupButton = veCreate('button', 'chat_tip_panel__topup walletTopup');
        topupButton.type = 'button';
        topupButton.textContent = t('wallet_topup_button_label', 'Add funds');
        errorNode.appendChild(topupButton);
      }
      errorNode.hidden = false;
    }
  }

  function toggleTipPanel(forceOpen){
    var panel = ensureTipPanel();
    if (!panel) { return; }
    var open = typeof forceOpen === 'boolean' ? forceOpen : panel.hidden;
    panel.hidden = !open;
    if (open) {
      setChatTipError(panel, '');
      var inputAmount = panel.querySelector('[data-chat-tip-amount]');
      if (inputAmount) { inputAmount.focus(); inputAmount.select(); }
    }
  }

  function sendChatTip(){
    var panel = ensureTipPanel();
    if (!panel || !chatPartnerId) { return; }
    var inputAmount = panel.querySelector('[data-chat-tip-amount]');
    var amount = inputAmount ? parseFloat(inputAmount.value || '0') : 0;
    setChatTipError(panel, '');
    if (!isFinite(amount) || amount <= 0) {
      setChatTipError(panel, chatTipErrorMessage('invalid_parameters'));
      return;
    }
    var btn = panel.querySelector('[data-chat-tip-send]');
    if (btn) { btn.disabled = true; }
    var form = new FormData();
    form.append('p', 'sendChatTip');
    form.append('to', String(chatPartnerId));
    form.append('amount', String(amount));
    form.append('csrf_token', getCsrf());
    postForm(form).then(function(res){
      if (res && res.status === 'success' && res.data) {
        buildMessageRow(res.data);
        lastTs = Math.max(lastTs, res.data.message_time || 0);
        setChatTipError(panel, '');
        toggleTipPanel(false);
        scrollToBottomReliable(true);
      } else if (panel) {
        var responseCode = (res && res.message) ? res.message : 'error';
        setChatTipError(panel, chatTipErrorMessage(responseCode, res || {}), {
          topup: String(responseCode) === 'insufficient_wallet'
        });
      }
    }).catch(function(){
      if (panel) { setChatTipError(panel, chatTipErrorMessage('network')); }
    }).finally(function(){
      if (btn) { btn.disabled = false; }
    });
  }

  function ensurePaidPanel(){
    if (!canSendPaidMedia) { return null; }
    if (paidPanel && paidPanel.parentNode) { return paidPanel; }
    var inputArea = document.querySelector('.chat_input_area');
    if (!inputArea) { return null; }
    paidPanel = veCreate('div', 'chat_paid_panel');
    paidPanel.hidden = true;
    paidPanel.innerHTML = ''
      + '<div class="chat_paid_panel__copy"><span>' + escapeHtml(t('chat_paid_media_label', 'Paid media')) + '</span><strong>' + escapeHtml(t('chat_paid_media_set_price', 'Set a price before uploading')) + '</strong></div>'
      + '<label><span>' + escapeHtml(chatCurrencySymbol) + '</span><input type="number" min="1" max="500" step="1" value="5" data-chat-paid-price></label>'
      + '<button type="button" data-chat-paid-image>' + escapeHtml(t('chat_preview_image', 'Image')) + '</button>'
      + '<button type="button" data-chat-paid-video>' + escapeHtml(t('chat_preview_video', 'Video')) + '</button>'
      + '<button type="button" data-chat-paid-close aria-label="' + escapeHtml(t('close', 'Close')) + '">&times;</button>';
    var reply = ensureReplyBar();
    inputArea.insertBefore(paidPanel, reply && reply.parentNode === inputArea ? reply.nextSibling : inputArea.firstChild);
    return paidPanel;
  }

  function togglePaidPanel(forceOpen){
    var panel = ensurePaidPanel();
    if (!panel) { return; }
    var open = typeof forceOpen === 'boolean' ? forceOpen : panel.hidden;
    panel.hidden = !open;
    if (open) {
      var price = panel.querySelector('[data-chat-paid-price]');
      if (price) { price.focus(); price.select(); }
    }
  }

  function paidMediaPrice(){
    var panel = ensurePaidPanel();
    var inputPrice = panel ? panel.querySelector('[data-chat-paid-price]') : null;
    var price = inputPrice ? parseFloat(inputPrice.value || '0') : 0;
    return isFinite(price) ? price : 0;
  }

  function sendPaidMediaFile(kind, file){
    if (!file || !chatPartnerId) { return; }
    var price = paidMediaPrice();
    if (price <= 0) { return; }
    var form = new FormData();
    form.append('p', kind === 'video' ? 'sendPaidMediaVideo' : 'sendPaidMediaImage');
    form.append('with', String(chatPartnerId));
    form.append('price', String(price));
    form.append(kind === 'video' ? 'video' : 'image', file);
    form.append('csrf_token', getCsrf());
    postForm(form).then(function(res){
      if (res && res.status === 'success' && res.data) {
        buildMessageRow(res.data);
        lastTs = Math.max(lastTs, res.data.message_time || 0);
        togglePaidPanel(false);
        scrollToBottomReliable(true);
      } else if (paidPanel) {
        paidPanel.setAttribute('data-error', (res && res.message) ? res.message : 'error');
      }
    }).catch(function(){
      if (paidPanel) { paidPanel.setAttribute('data-error', 'network'); }
    });
  }

  function renderPaidMediaIntoBubble(row, mediaUrl, mediaType){
    if (!row || !mediaUrl) { return; }
    var card = row.querySelector('[data-paid-media-card]');
    var bubble = row.querySelector('.chat_bubble');
    if (!card || !bubble) { return; }
    var wrap = veCreate('div', 'chat_paid_media chat_paid_media--unlocked');
    if (mediaType === 'video') {
      var video = document.createElement('video');
      video.controls = true;
      var source = document.createElement('source');
      source.src = mediaUrl;
      source.type = 'video/mp4';
      video.appendChild(source);
      wrap.appendChild(video);
      addMediaNudge(video);
    } else {
      var img = document.createElement('img');
      img.src = mediaUrl;
      img.alt = t('chat_paid_media_label', 'Paid media');
      wrap.appendChild(img);
      addMediaNudge(img);
    }
    var badge = document.createElement('span');
    badge.textContent = t('chat_paid_media_unlocked', 'Unlocked');
    wrap.appendChild(badge);
    card.replaceWith(wrap);
  }

  function getCsrf(){
    var el = document.querySelector('input[name="csrf_token"]');
    return el ? el.value : '';
  }

  function veCreate(nodeName, className){
    var el = document.createElement(nodeName);
    if (className) el.className = className;
    return el;
  }

  function escapeHtml(value){
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function reactionLabel(reaction){
    var map = {
      heart: '\u2764\ufe0f',
      like: '\ud83d\udc4d',
      fire: '\ud83d\udd25',
      laugh: '\ud83d\ude02',
      wow: '\ud83d\ude2e',
      sad: '\ud83d\ude22'
    };
    return map[reaction] || map.heart;
  }

  function actionToast(message, tone){
    var toast = document.querySelector('.chat_action_toast');
    if (!toast) {
      toast = veCreate('div', 'chat_action_toast');
      toast.setAttribute('role', 'status');
      document.body.appendChild(toast);
    }
    toast.className = 'chat_action_toast' + (tone ? ' chat_action_toast--' + tone : '');
    toast.textContent = message || '';
    toast.hidden = false;
    clearTimeout(actionToast._timer);
    actionToast._timer = setTimeout(function(){
      if (toast) { toast.hidden = true; }
    }, 2200);
  }

  function closeChatActionModal(){
    var modal = document.querySelector('.chat_action_modal');
    if (modal && modal.parentNode) {
      modal.parentNode.removeChild(modal);
    }
  }

  function openChatActionModal(title, bodyHtml, actionsHtml){
    closeChatActionModal();
    var modal = veCreate('div', 'chat_action_modal');
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.innerHTML = ''
      + '<div class="chat_action_modal__panel">'
      + '  <div class="chat_action_modal__header">'
      + '    <strong>' + escapeHtml(title || '') + '</strong>'
      + '    <button type="button" class="chat_action_modal__close" data-chat-modal-close aria-label="' + escapeHtml(t('close', 'Close')) + '">&times;</button>'
      + '  </div>'
      + '  <div class="chat_action_modal__body">' + (bodyHtml || '') + '</div>'
      + '  <div class="chat_action_modal__footer">' + (actionsHtml || '') + '</div>'
      + '</div>';
    document.body.appendChild(modal);
    return modal;
  }

  function reactionItems(){
    return [
      ['heart', reactionLabel('heart'), t('chat_reaction_heart', 'Heart')],
      ['like', reactionLabel('like'), t('chat_reaction_like', 'Like')],
      ['fire', reactionLabel('fire'), t('chat_reaction_fire', 'Fire')],
      ['laugh', reactionLabel('laugh'), t('chat_reaction_laugh', 'Laugh')],
      ['wow', reactionLabel('wow'), t('chat_reaction_wow', 'Wow')],
      ['sad', reactionLabel('sad'), t('chat_reaction_sad', 'Sad')]
    ];
  }

  function openDeleteConfirm(row, mid, scope){
    var isEveryone = scope === 'everyone';
    var body = '<p>' + escapeHtml(isEveryone ? t('chat_delete_everyone_confirm_text', 'This message will be deleted for everyone in the conversation.') : t('chat_delete_self_confirm_text', 'This message will only be removed from your view.')) + '</p>';
    var actions = '<button type="button" class="chat_action_secondary" data-chat-modal-close>' + escapeHtml(t('menu_cancel', 'Cancel')) + '</button>'
      + '<button type="button" class="chat_action_danger" data-chat-delete-confirm>' + escapeHtml(t('delete', 'Delete')) + '</button>';
    var modal = openChatActionModal(isEveryone ? t('chat_delete_everyone_confirm_title', 'Delete for everyone?') : t('chat_delete_self_confirm_title', 'Delete for you?'), body, actions);
    var confirm = modal.querySelector('[data-chat-delete-confirm]');
    if (!confirm) { return; }
    confirm.addEventListener('click', function(event){
      event.preventDefault();
      confirm.disabled = true;
      postMessageAction('deleteMessage', mid, { scope: scope }).then(function(res){
        if (res && res.status === 'success') {
          markRowDeleted(row, scope === 'self');
          closeChatActionModal();
          actionToast(t('chat_toast_message_deleted', 'Message deleted.'), 'success');
        } else {
          confirm.disabled = false;
          actionToast(t('chat_toast_message_delete_failed', 'Message could not be deleted.'), 'error');
        }
      }).catch(function(){
        confirm.disabled = false;
        actionToast(t('chat_toast_message_delete_failed', 'Message could not be deleted.'), 'error');
      });
    });
  }

  function openReportModal(mid){
    var reasons = [
      ['harassment', t('chat_report_reason_harassment', 'Harassment')],
      ['spam', t('chat_report_reason_spam', 'Spam')],
      ['scam', t('chat_report_reason_scam', 'Scam or fraud')],
      ['adult', t('chat_report_reason_adult', 'Adult content')],
      ['other', t('chat_report_reason_other', 'Other')]
    ];
    var body = '<label class="chat_report_field"><span>' + escapeHtml(t('chat_report_reason_label', 'Reason')) + '</span><select name="chat_report_reason">'
      + reasons.map(function(item){ return '<option value="' + item[0] + '">' + escapeHtml(item[1]) + '</option>'; }).join('')
      + '</select></label>'
      + '<label class="chat_report_field"><span>' + escapeHtml(t('chat_report_note_label', 'Note')) + '</span><textarea name="chat_report_note" rows="4" maxlength="1000" placeholder="' + escapeHtml(t('chat_report_note_placeholder', 'Add context for the moderation team.')) + '"></textarea></label>';
    var actions = '<button type="button" class="chat_action_secondary" data-chat-modal-close>' + escapeHtml(t('menu_cancel', 'Cancel')) + '</button>'
      + '<button type="button" class="chat_action_primary" data-chat-report-submit>' + escapeHtml(t('chat_report_submit', 'Submit report')) + '</button>';
    var modal = openChatActionModal(t('chat_report_message_title', 'Report message'), body, actions);
    var submit = modal.querySelector('[data-chat-report-submit]');
    if (!submit) { return; }
    submit.addEventListener('click', function(event){
      event.preventDefault();
      var reason = modal.querySelector('[name="chat_report_reason"]');
      var note = modal.querySelector('[name="chat_report_note"]');
      submit.disabled = true;
      postMessageAction('reportMessage', mid, {
        reason: reason ? reason.value : 'other',
        note: note ? note.value : ''
      }).then(function(res){
        if (res && res.status === 'success') {
          closeChatActionModal();
          actionToast(t('chat_toast_report_submitted', 'Report submitted.'), 'success');
        } else {
          submit.disabled = false;
          actionToast(t('chat_toast_report_failed', 'Report could not be submitted.'), 'error');
        }
      }).catch(function(){
        submit.disabled = false;
        actionToast(t('chat_toast_report_failed', 'Report could not be submitted.'), 'error');
      });
    });
  }

  function renderReplyQuote(msg){
    var reply = msg && msg.reply ? msg.reply : null;
    if (!reply) { return null; }
    var btn = veCreate('button', 'chat_reply_quote');
    btn.type = 'button';
    btn.setAttribute('data-chat-action', 'reply-jump');
    btn.setAttribute('data-reply-mid', String(reply.message_id || 0));
    var label = veCreate('span');
    label.textContent = reply.is_outgoing ? t('chat_reply_you', 'You') : t('chat_reply_label', 'Reply');
    var text = veCreate('strong');
    text.textContent = reply.message || t('chat_reply_message_fallback', 'Message');
    btn.appendChild(label);
    btn.appendChild(text);
    return btn;
  }

  function appendMessageReactions(bubble, msg){
    var reactions = msg && Array.isArray(msg.reactions) ? msg.reactions : [];
    if (!reactions.length) { return; }
    var wrap = veCreate('div', 'chat_reactions');
    reactions.forEach(function(item){
      var count = parseInt(item.count || 0, 10) || 0;
      if (count <= 0) { return; }
      var pill = document.createElement('span');
      pill.textContent = reactionLabel(item.reaction || 'heart') + (count > 1 ? ' ' + count : '');
      wrap.appendChild(pill);
    });
    if (wrap.childNodes.length) { bubble.appendChild(wrap); }
  }

  function appendMessageActions(bubble, row, msg){
    var mid = parseInt((msg && msg.message_id) || row.getAttribute('data-mid') || '0', 10) || 0;
    if (!mid || (msg && msg.is_deleted)) { return; }
    var isOutgoing = row.classList.contains('outgoing');
    var canDeleteEveryone = !!(msg && msg.can_delete_everyone);
    var myReaction = (msg && msg.my_reaction) ? String(msg.my_reaction) : (row.getAttribute('data-my-reaction') || '');
    var wrap = veCreate('div', 'chat_message_actions');
    wrap.setAttribute('data-chat-actions', '');
    var reactionToggle = veCreate('button', 'chat_reaction_toggle');
    reactionToggle.type = 'button';
    reactionToggle.setAttribute('data-chat-action', 'toggle-reactions');
    reactionToggle.setAttribute('data-mid', String(mid));
    reactionToggle.setAttribute('aria-label', t('chat_react_to_message', 'React to message'));
    reactionToggle.innerHTML = ICONS.html('smiley_chat') || '<img src="' + ICONS.url('smiley_chat') + '" alt="">';
    var toggle = veCreate('button', 'chat_action_toggle');
    toggle.type = 'button';
    toggle.setAttribute('data-chat-action', 'toggle-menu');
    toggle.setAttribute('aria-label', t('chat_message_actions', 'Message actions'));
    toggle.innerHTML = '&#8942;';
    var rail = veCreate('div', 'chat_reaction_rail');
    rail.hidden = true;
    reactionItems().forEach(function(item){
      var btn = veCreate('button', 'chat_reaction_choice' + (myReaction === item[0] ? ' is-active' : ''));
      btn.type = 'button';
      btn.setAttribute('data-chat-action', 'react-choice');
      btn.setAttribute('data-chat-reaction-choice', item[0]);
      btn.setAttribute('data-mid', String(mid));
      btn.setAttribute('aria-label', item[2]);
      btn.setAttribute('aria-pressed', myReaction === item[0] ? 'true' : 'false');
      var span = document.createElement('span');
      span.textContent = item[1];
      btn.appendChild(span);
      rail.appendChild(btn);
    });
    var menu = veCreate('div', 'chat_action_menu');
    menu.hidden = true;
    [
      ['reply', t('chat_action_reply', 'Reply')],
      ['copy', t('chat_action_copy', 'Copy')],
      ['delete-self', t('chat_action_delete_self', 'Delete for me')]
    ].forEach(function(item){
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.setAttribute('data-chat-action', item[0]);
      btn.setAttribute('data-mid', String(mid));
      btn.textContent = item[1];
      menu.appendChild(btn);
    });
    if (isOutgoing && canDeleteEveryone) {
      var delAll = document.createElement('button');
      delAll.type = 'button';
      delAll.setAttribute('data-chat-action', 'delete-everyone');
      delAll.setAttribute('data-mid', String(mid));
      delAll.textContent = t('chat_action_delete_everyone', 'Delete for everyone');
      menu.appendChild(delAll);
    }
    var report = document.createElement('button');
    report.type = 'button';
    report.setAttribute('data-chat-action', 'report');
    report.setAttribute('data-mid', String(mid));
    report.textContent = t('chat_action_report', 'Report');
    menu.appendChild(report);
    wrap.appendChild(reactionToggle);
    wrap.appendChild(toggle);
    wrap.appendChild(rail);
    wrap.appendChild(menu);
    bubble.appendChild(wrap);
  }

  function decorateMessageBubble(row, bubble, msg){
    var reply = renderReplyQuote(msg || {});
    if (reply) {
      bubble.insertBefore(reply, bubble.firstChild);
    }
    appendMessageReactions(bubble, msg || {});
    appendMessageActions(bubble, row, msg || {});
  }

  function buildPaidMediaNode(msg){
    var paid = msg && msg.paid_media ? msg.paid_media : null;
    if (!paid) { return null; }
    var wrap = veCreate('div', 'chat_paid_media');
    var unlocked = !!paid.is_unlocked && !!paid.file_url;
    var mediaType = paid.media_type || 'image';
    if (unlocked) {
      wrap.className += ' chat_paid_media--unlocked';
      if (mediaType === 'video') {
        var video = document.createElement('video');
        video.controls = true;
        var source = document.createElement('source');
        source.src = paid.file_url;
        source.type = 'video/mp4';
        video.appendChild(source);
        wrap.appendChild(video);
        addMediaNudge(video);
      } else {
        var img = document.createElement('img');
        img.src = paid.file_url;
        img.alt = t('chat_paid_media_label', 'Paid media');
        wrap.appendChild(img);
        addMediaNudge(img);
      }
      var badge = document.createElement('span');
      badge.textContent = paid.is_owner ? t('chat_paid_media_label', 'Paid media') : t('chat_paid_media_unlocked', 'Unlocked');
      wrap.appendChild(badge);
      return wrap;
    }
    wrap.className += ' chat_paid_media--locked';
    wrap.setAttribute('data-paid-media-card', '');
    wrap.setAttribute('data-mid', String(paid.message_id || msg.message_id || 0));
    var icon = veCreate('div', 'chat_paid_media__icon');
    icon.innerHTML = ICONS.html('locked');
    var title = document.createElement('strong');
    title.textContent = t('chat_paid_media_locked_title', 'Locked media');
    var copy = document.createElement('p');
    copy.textContent = t('chat_paid_media_locked_desc', 'Unlock this {type} to view it.', { type: mediaType });
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.setAttribute('data-chat-action', 'unlock-paid-media');
    btn.setAttribute('data-mid', String(paid.message_id || msg.message_id || 0));
    var symbol = chatCurrencySymbol || paid.currency || chatCurrencyCode;
    var price = parseFloat(paid.price || '0') || 0;
    btn.textContent = t('chat_paid_media_unlock_button', 'Unlock {price}', {
      price: (String(symbol).length <= 4 ? symbol + price.toFixed(2) : price.toFixed(2) + ' ' + (paid.currency || chatCurrencyCode))
    });
    wrap.appendChild(icon);
    wrap.appendChild(title);
    wrap.appendChild(copy);
    wrap.appendChild(btn);
    return wrap;
  }

  function buildTipMessageNode(msg){
    if (!msg || String(msg.message_type || '').toLowerCase() !== 'tip') { return null; }
    var tip = msg.tip || {};
    var text = String(msg.message || '').trim();
    var amountDisplay = String(tip.amount_display || '').trim();
    if (!amountDisplay && text) {
      var parts = text.split(':');
      amountDisplay = parts.length > 1 ? parts.slice(1).join(':').trim() : text;
    }
    if (!amountDisplay && tip.amount) {
      var symbol = chatCurrencySymbol || tip.currency || chatCurrencyCode;
      var amount = parseFloat(tip.amount || '0') || 0;
      amountDisplay = (String(symbol).length <= 4 ? symbol + amount.toFixed(2) : amount.toFixed(2) + ' ' + (tip.currency || chatCurrencyCode));
    }

    var wrap = veCreate('div', 'chat_tip_message');
    var icon = veCreate('span', 'chat_tip_message__icon');
    icon.textContent = chatCurrencySymbol || '$';
    var copy = veCreate('div', 'chat_tip_message__copy');
    var label = veCreate('span', 'chat_tip_message__label');
    label.textContent = t('chat_tip_message_label', 'Tip sent');
    var amountNode = veCreate('strong', 'chat_tip_message__amount');
    amountNode.textContent = amountDisplay || text || t('chat_send_tip', 'Send tip');
    copy.appendChild(label);
    copy.appendChild(amountNode);
    wrap.appendChild(icon);
    wrap.appendChild(copy);
    return wrap;
  }

  function firstMessageNode(){
    var n = list.firstElementChild;
    while (n && !n.classList.contains('chat_message_row') && !n.classList.contains('chat_meta')) {
      n = n.nextElementSibling;
    }
    return n;
  }

  function getOldestTs(){
    var nodes = list.querySelectorAll('.chat_message_row');
    var minTs = 0;
    nodes.forEach(function(n){
      var ts = parseInt(n.getAttribute('data-ts') || '0', 10) || 0;
      if (ts > 0 && (minTs === 0 || ts < minTs)) { minTs = ts; }
    });
    return minTs;
  }

  function buildMessageRow(msg){
    // De-duplication by message_id
    var mid = parseInt(msg.message_id || 0, 10) || 0;
    if (mid > 0) {
      var exists = list.querySelector('[data-mid="' + mid + '"]');
      if (exists) { return exists; }
    }
    // msg: {message_id, message, message_time, direction, ymd, avatar, file, file_kind}
    var row = veCreate('div', 'chat_message_row ' + (msg.direction === 'outgoing' ? 'outgoing' : 'incoming'));
    row.setAttribute('data-ymd', msg.ymd || '');
    if (mid > 0) { row.setAttribute('data-mid', String(mid)); }
    row.setAttribute('data-my-reaction', msg.my_reaction ? String(msg.my_reaction) : '');
    row.setAttribute('data-ts', String(msg.message_time || 0));

    var hasMedia = false;
    if (msg.direction === 'outgoing') {
      var spacer = veCreate('div', 'chat_spacer');
      var bubble = veCreate('div', 'chat_bubble outgoing');
      var tipNode = buildTipMessageNode(msg);
      var paidNode = buildPaidMediaNode(msg);
      if (tipNode) {
        bubble.className += ' chat_bubble--tip';
        bubble.appendChild(tipNode);
      } else if (paidNode) {
        bubble.appendChild(paidNode);
        hasMedia = true;
      } else if (msg.share_html) {
        bubble.innerHTML = msg.share_html;
        hasMedia = true;
      } else if (msg.file && /^post:\\d+$/i.test(String(msg.file||''))) {
        var pidTemp = String(msg.file||'').replace(/^post:/i,'');
        bubble.innerHTML = '<a class="chat-share-card" target="_blank" rel="noopener noreferrer" href="' + buildUrl('posts/' + pidTemp) + '"><div class="chat-share-skeleton"></div></a>';
        try { fetchSharePreview(String(msg.file||'').replace(/^post:/i,''), bubble); } catch(_){}
        hasMedia = true;
      } else if (msg.file && msg.file_kind === 'image') {
        var imgOut = veCreate('img'); imgOut.alt = '';
        imgOut.src = (site_url + (msg.file || '')).replace(/\/$/, '').replace(/([^:])\/\//g, '$1/');
        bubble.appendChild(imgOut);
        addMediaNudge(imgOut);
        hasMedia = true;
      } else if (msg.file && msg.file_kind === 'video') {
        var vOut = veCreate('video'); vOut.controls = true;
        var so = veCreate('source'); so.src = site_url + (msg.file || ''); so.type = 'video/mp4';
        vOut.appendChild(so); bubble.appendChild(vOut);
        addMediaNudge(vOut);
        hasMedia = true;
      } else {
        bubble.innerHTML = escapeHtml(msg.message || '').replace(/\n/g, '<br>');
      }
      // Status ticks for outgoing
      var st = veCreate('div', 'chat_status');
      try {
        var d = parseInt(msg.delivered_at || 0, 10) || 0;
        var r = parseInt(msg.read_at || 0, 10) || 0;
        var icon = 'tick';
        var tickState = 'single';
        if (r > 0) { icon = 'tick_double_blue'; tickState = 'blue'; }
        else if (d > 0) { icon = 'tick_double'; tickState = 'double'; }
        var svg = ICONS.html(icon);
        if (svg) { var span = document.createElement('span'); span.className='tick_icon'; span.innerHTML = svg; st.appendChild(span); }
        else { var im = document.createElement('img'); im.src = ICONS.url(icon); im.alt = icon; im.className='tick_icon'; st.appendChild(im); }
        row.setAttribute('data-tick', tickState);
      } catch (__) {
        var svg2 = ICONS.html('tick'); if (svg2) { var s2 = document.createElement('span'); s2.className='tick_icon'; s2.innerHTML=svg2; st.appendChild(s2); }
        else { var im2 = document.createElement('img'); im2.src = ICONS.url('tick'); im2.alt = 'tick'; im2.className='tick_icon'; st.appendChild(im2); }
        row.setAttribute('data-tick', 'single');
      }
      bubble.appendChild(st);
      decorateMessageBubble(row, bubble, msg);
      row.appendChild(spacer);
      row.appendChild(bubble);
    } else {
      var avatarWrap = veCreate('div', 'chat_avatar');
      var img = veCreate('img'); img.alt = ''; img.src = otherAvatar || '';
      avatarWrap.appendChild(img);
      var bubble2 = veCreate('div', 'chat_bubble incoming');
      var tipNodeIn = buildTipMessageNode(msg);
      var paidNodeIn = buildPaidMediaNode(msg);
      if (tipNodeIn) {
        bubble2.className += ' chat_bubble--tip';
        bubble2.appendChild(tipNodeIn);
      } else if (paidNodeIn) {
        bubble2.appendChild(paidNodeIn);
        hasMedia = true;
      } else if (msg.share_html) {
        bubble2.innerHTML = msg.share_html;
        hasMedia = true;
      } else if (msg.file && /^post:\\d+$/i.test(String(msg.file||''))) {
        var pidTemp2 = String(msg.file||'').replace(/^post:/i,'');
        bubble2.innerHTML = '<a class="chat-share-card" target="_blank" rel="noopener noreferrer" href="' + buildUrl('posts/' + pidTemp2) + '"><div class="chat-share-skeleton"></div></a>';
        try { fetchSharePreview(String(msg.file||'').replace(/^post:/i,''), bubble2); } catch(_){}
        hasMedia = true;
      } else if (msg.file && msg.file_kind === 'image') {
        var imgIn = veCreate('img'); imgIn.alt = '';
        imgIn.src = (site_url + (msg.file || '')).replace(/\/$/, '').replace(/([^:])\/\//g, '$1/');
        bubble2.appendChild(imgIn);
        addMediaNudge(imgIn);
        hasMedia = true;
      } else if (msg.file && msg.file_kind === 'video') {
        var vIn = veCreate('video'); vIn.controls = true;
        var si = veCreate('source'); si.src = site_url + (msg.file || ''); si.type = 'video/mp4';
        vIn.appendChild(si); bubble2.appendChild(vIn);
        addMediaNudge(vIn);
        hasMedia = true;
      } else {
        bubble2.innerHTML = escapeHtml(msg.message || '').replace(/\n/g, '<br>');
      }
      decorateMessageBubble(row, bubble2, msg);
      row.appendChild(avatarWrap);
      row.appendChild(bubble2);
    }

    list.appendChild(row);
    // remove empty state if present
    var empty = list.querySelector('.chat_empty_placeholder');
    if (empty && empty.parentNode) { try { empty.parentNode.removeChild(empty); } catch (e) {} }
    if (hasMedia) { row.setAttribute('data-has-media','1'); }
    ensureDayHeaderFor(row);
    if (!hasMedia) { scrollToBottomReliable(msg && msg.direction === 'outgoing'); }
    return row;
  }

  function prependMessageRow(msg){
    var mid = parseInt(msg.message_id || 0, 10) || 0;
    if (mid > 0) {
      var exists = list.querySelector('[data-mid="' + mid + '"]');
      if (exists) { return exists; }
    }
    var row = veCreate('div', 'chat_message_row ' + (msg.direction === 'outgoing' ? 'outgoing' : 'incoming'));
    row.setAttribute('data-ymd', msg.ymd || '');
    if (mid > 0) { row.setAttribute('data-mid', String(mid)); }
    row.setAttribute('data-my-reaction', msg.my_reaction ? String(msg.my_reaction) : '');
    row.setAttribute('data-ts', String(msg.message_time || 0));
    row.setAttribute('data-older', '1');
    var hasMedia = false;

    if (msg.direction === 'outgoing') {
      var spacer = veCreate('div', 'chat_spacer');
      var bubble = veCreate('div', 'chat_bubble outgoing');
      var tipNodeOld = buildTipMessageNode(msg);
      var paidNodeOld = buildPaidMediaNode(msg);
      if (tipNodeOld) {
        bubble.className += ' chat_bubble--tip';
        bubble.appendChild(tipNodeOld);
      } else if (paidNodeOld) {
        bubble.appendChild(paidNodeOld);
        hasMedia = true;
      } else if (msg.share_html) {
        bubble.innerHTML = msg.share_html;
        hasMedia = true;
      } else if (msg.file && /^post:\\d+$/i.test(String(msg.file||''))) {
        var pidTemp3 = String(msg.file||'').replace(/^post:/i,'');
        bubble.innerHTML = '<a class="chat-share-card" target="_blank" rel="noopener noreferrer" href="' + buildUrl('posts/' + pidTemp3) + '"><div class="chat-share-skeleton"></div></a>';
        try { fetchSharePreview(String(msg.file||'').replace(/^post:/i,''), bubble); } catch(_){}
        hasMedia = true;
      } else if (msg.file && msg.file_kind === 'image') {
        var imgOut = veCreate('img'); imgOut.alt = '';
        imgOut.src = (site_url + (msg.file || '')).replace(/\/$/, '').replace(/([^:])\/\//g, '$1/');
        bubble.appendChild(imgOut); addMediaNudge(imgOut);
        hasMedia = true;
      } else if (msg.file && msg.file_kind === 'video') {
        var vOut = veCreate('video'); vOut.controls = true;
        var so = veCreate('source'); so.src = site_url + (msg.file || ''); so.type = 'video/mp4';
        vOut.appendChild(so); bubble.appendChild(vOut); addMediaNudge(vOut);
        hasMedia = true;
      } else {
        bubble.innerHTML = escapeHtml(msg.message || '').replace(/\n/g, '<br>');
      }
      var st = veCreate('div', 'chat_status');
      try {
        var d = parseInt(msg.delivered_at || 0, 10) || 0;
        var r = parseInt(msg.read_at || 0, 10) || 0;
        var icon = 'tick';
        if (r > 0) { icon = 'tick_double_blue'; }
        else if (d > 0) { icon = 'tick_double'; }
        var svg = ICONS.html(icon);
        if (svg) { var span = document.createElement('span'); span.className='tick_icon'; span.innerHTML = svg; st.appendChild(span); }
        else { var im = document.createElement('img'); im.src = ICONS.url(icon); im.alt = icon; im.className='tick_icon'; st.appendChild(im); }
      } catch (__) {
        var svg2 = ICONS.html('tick'); if (svg2) { var s2 = document.createElement('span'); s2.className='tick_icon'; s2.innerHTML=svg2; st.appendChild(s2); }
        else { var im2 = document.createElement('img'); im2.src = ICONS.url('tick'); im2.alt = 'tick'; im2.className='tick_icon'; st.appendChild(im2); }
      }
      bubble.appendChild(st);
      decorateMessageBubble(row, bubble, msg);
      row.appendChild(spacer);
      row.appendChild(bubble);
    } else {
      var avatarWrap = veCreate('div', 'chat_avatar');
      var img = veCreate('img'); img.alt = ''; img.src = otherAvatar || '';
      avatarWrap.appendChild(img);
      var bubble2 = veCreate('div', 'chat_bubble incoming');
      var tipNodeOldIn = buildTipMessageNode(msg);
      var paidNodeOldIn = buildPaidMediaNode(msg);
      if (tipNodeOldIn) {
        bubble2.className += ' chat_bubble--tip';
        bubble2.appendChild(tipNodeOldIn);
      } else if (paidNodeOldIn) {
        bubble2.appendChild(paidNodeOldIn);
        hasMedia = true;
      } else if (msg.share_html) {
        bubble2.innerHTML = msg.share_html;
        hasMedia = true;
      } else if (msg.file && /^post:\\d+$/i.test(String(msg.file||''))) {
        var pidTemp4 = String(msg.file||'').replace(/^post:/i,'');
        bubble2.innerHTML = '<a class="chat-share-card" target="_blank" rel="noopener noreferrer" href="' + buildUrl('posts/' + pidTemp4) + '"><div class="chat-share-skeleton"></div></a>';
        try { fetchSharePreview(String(msg.file||'').replace(/^post:/i,''), bubble2); } catch(_){}
        hasMedia = true;
      } else if (msg.file && msg.file_kind === 'image') {
        var imgIn = veCreate('img'); imgIn.alt = '';
        imgIn.src = (site_url + (msg.file || '')).replace(/\/$/, '').replace(/([^:])\/\//g, '$1/');
        bubble2.appendChild(imgIn); addMediaNudge(imgIn);
        hasMedia = true;
      } else if (msg.file && msg.file_kind === 'video') {
        var vIn = veCreate('video'); vIn.controls = true;
        var si = veCreate('source'); si.src = site_url + (msg.file || ''); si.type = 'video/mp4';
        vIn.appendChild(si); bubble2.appendChild(vIn); addMediaNudge(vIn);
        hasMedia = true;
      } else {
        bubble2.innerHTML = escapeHtml(msg.message || '').replace(/\n/g, '<br>');
      }
      decorateMessageBubble(row, bubble2, msg);
      row.appendChild(avatarWrap);
      row.appendChild(bubble2);
    }

    var anchor = firstMessageNode();
    if (anchor) {
      list.insertBefore(row, anchor);
    } else {
      list.appendChild(row);
    }
    if (hasMedia) { row.setAttribute('data-has-media','1'); }
    ensureDayHeaderFor(row);
    return row;
  }

  function lockedShareLabel(){
    return __i18n('chat_locked_post_placeholder') || 'Locked / Premium / Subscribers only';
  }

  function buildLockedSharePlaceholder(postId){
    var labelText = lockedShareLabel();
    var card = document.createElement('a');
    card.className = 'chat-share-card chat-share-card--locked';
    card.href = buildUrl('posts/' + String(postId || ''));
    card.target = '_blank';
    card.rel = 'noopener noreferrer';

    var thumb = document.createElement('div');
    thumb.className = 'csp-thumb csp-thumb-locked';

    var placeholder = document.createElement('div');
    placeholder.className = 'csp-placeholder csp-placeholder-locked';

    var icon = document.createElement('span');
    icon.className = 'csp-lock';
    icon.innerHTML = ICONS.html('locked');

    var label = document.createElement('span');
    label.className = 'csp-label';
    label.textContent = labelText;

    placeholder.appendChild(icon);
    placeholder.appendChild(label);
    thumb.appendChild(placeholder);

    var meta = document.createElement('div');
    meta.className = 'csp-meta';
    var user = document.createElement('div');
    user.className = 'csp-user';
    user.textContent = labelText;
    var type = document.createElement('div');
    type.className = 'csp-type';
    type.textContent = labelText;
    meta.appendChild(user);
    meta.appendChild(type);

    card.appendChild(thumb);
    card.appendChild(meta);
    return card;
  }

  // Fetch preview HTML for shared post and inject into bubble
  function fetchSharePreview(postId, bubbleEl){
    try{
      var fd = new FormData();
      fd.append('p','postSharePreview');
      fd.append('post_id', String(postId||0));
      var csrf = document.querySelector("input[name='csrf_token']"); if (csrf) fd.append('csrf_token', csrf.value);
      fetch(buildUrl('request/chat.php'), { method:'POST', credentials:'same-origin', body: fd })
        .then(function(r){ return r.json(); })
        .then(function(j){
          if (!bubbleEl) return;
          if (j && j.status==='success' && j.html) {
            bubbleEl.innerHTML = j.html;
            addMediaNudge(bubbleEl.querySelector('img,video'));
          } else {
            bubbleEl.innerHTML = '';
            bubbleEl.appendChild(buildLockedSharePlaceholder(postId));
          }
        });
    } catch (_){}
  }

  function fetchOlder(){
    if (destroyed || isLoadingOlder || noMoreOlder) return;
    var before = getOldestTs();
    if (!before) return;

    isLoadingOlder = true;
    var prevHeight = list.scrollHeight;
    var prevTop = list.scrollTop;

    // show loader and compensate scroll position so view doesn't jump
    showOlderLoader();
    if (olderLoaderEl && olderLoaderEl.offsetHeight) {
      list.scrollTop = prevTop + olderLoaderEl.offsetHeight;
      prevTop = list.scrollTop;
    }

    var form = new FormData();
    form.append('p', 'fetchOlderMessages');
    form.append('with', String(chatPartnerId));
    form.append('before', String(before));
    form.append('limit', String(olderLimit));
    form.append('csrf_token', getCsrf());

    postForm(form).then(function(res){
      if (res && res.status === 'success' && Array.isArray(res.items)) {
        if (res.items.length === 0) {
          noMoreOlder = true;
          hideOlderLoader();
          return;
        }
        res.items.forEach(function(m){ prependMessageRow(m); });
        // remove loader then restore viewport position based on height diff
        hideOlderLoader();
        var newHeight = list.scrollHeight;
        list.scrollTop = prevTop + (newHeight - prevHeight);
      }
    }).catch(function(){ /* no-op */ })
      .finally(function(){ isLoadingOlder = false; });
  }

  function showOlderLoader(){
    if (olderLoaderEl && olderLoaderEl.parentNode === list) return;
    var wrap = document.createElement('div');
    wrap.className = 'chat_loading_older';
    var svgNS = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(svgNS, 'svg');
    svg.setAttribute('width', '24');
    svg.setAttribute('height', '24');
    svg.setAttribute('viewBox', '0 0 50 50');
    var circle = document.createElementNS(svgNS, 'circle');
    circle.setAttribute('cx', '25');
    circle.setAttribute('cy', '25');
    circle.setAttribute('r', '20');
    circle.setAttribute('fill', 'none');
    circle.setAttribute('stroke', 'currentColor');
    circle.setAttribute('stroke-width', '4');
    circle.setAttribute('stroke-linecap', 'round');
    var anim = document.createElementNS(svgNS, 'animateTransform');
    anim.setAttribute('attributeName', 'transform');
    anim.setAttribute('type', 'rotate');
    anim.setAttribute('from', '0 25 25');
    anim.setAttribute('to', '360 25 25');
    anim.setAttribute('dur', '0.8s');
    anim.setAttribute('repeatCount', 'indefinite');
    circle.appendChild(anim);
    svg.appendChild(circle);
    wrap.appendChild(svg);
    list.insertBefore(wrap, list.firstChild);
    olderLoaderEl = wrap;
  }

  function hideOlderLoader(){
    if (olderLoaderEl && olderLoaderEl.parentNode) {
      try { olderLoaderEl.parentNode.removeChild(olderLoaderEl); } catch (e) {}
    }
    olderLoaderEl = null;
  }

  // Attach load/canplay listeners to media to nudge bottom after natural size resolves
  function addMediaNudge(el){
    if (!el) return;
    var nudger = function(){
      if (isLoadingOlder) { return; }
      var force = false;
      var row = el.closest ? el.closest('.chat_message_row') : null;
      if (row && row.getAttribute && row.getAttribute('data-older') === '1') { return; }
      if (row && row.classList && row.classList.contains('outgoing')) { force = true; }
      scrollToBottomReliable(force);
    };
    if (el.tagName === 'IMG') {
      if (el.complete) { nudger(); return; }
      el.addEventListener('load', nudger, { once: true });
      el.addEventListener('error', nudger, { once: true });
      return;
    }
    if (el.tagName === 'VIDEO') {
      el.addEventListener('loadedmetadata', nudger, { once: true });
      return;
    }
  }

  // ---- Image upload integration ----
  var imgInput = document.getElementById('chat_image_input');
  var vidInput = document.getElementById('chat_video_input');

  function openImagePicker(){ if (imgInput) { imgInput.value = ''; imgInput.click(); } }

  function sendImageFile(f){
    if (!f || !chatPartnerId) return;
    var form = new FormData();
    form.append('p', 'sendImageMessage');
    form.append('with', String(chatPartnerId));
    form.append('image', f);
    form.append('csrf_token', getCsrf());
    postForm(form).then(function(res){
      if (res && res.status === 'success' && res.data) {
        buildMessageRow(res.data);
        lastTs = Math.max(lastTs, res.data.message_time || 0);
        try { window.DZ = window.DZ || {}; DZ.lastSentMessageAt = Date.now(); DZ.lastSentMessageTs = parseInt(res.data.message_time || '0', 10) || 0; } catch (__) {}
        scrollToBottomReliable(true);
      }
    }).catch(function(){ /* no-op */ });
  }

  // ---- Video upload integration ----
  function openVideoPicker(){ if (vidInput) { vidInput.value = ''; vidInput.click(); } }
  function sendVideoFile(f){
    if (!f || !chatPartnerId) return;
    var form = new FormData();
    form.append('p', 'sendVideoMessage');
    form.append('with', String(chatPartnerId));
    form.append('video', f);
    form.append('csrf_token', getCsrf());
    postForm(form).then(function(res){
      if (res && res.status === 'success' && res.data) {
        buildMessageRow(res.data);
        lastTs = Math.max(lastTs, res.data.message_time || 0);
        try { window.DZ = window.DZ || {}; DZ.lastSentMessageAt = Date.now(); DZ.lastSentMessageTs = parseInt(res.data.message_time || '0', 10) || 0; } catch (__) {}
        scrollToBottomReliable(true);
      }
    }).catch(function(){ /* no-op */ });
  }

  // ---- Typing helpers ----
  var typingActive = false;
  var typingPingTimer = null;
  var lastTypingPing = 0;
  var typingRow = null;

  function nowSec(){ return Math.floor(Date.now() / 1000); }
  function todayYmd(){
    var d = new Date();
    var mm = ('0' + (d.getMonth()+1)).slice(-2);
    var dd = ('0' + d.getDate()).slice(-2);
    return d.getFullYear() + '-' + mm + '-' + dd;
  }

  function buildTypingSVG(){
    var svgNS = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(svgNS, 'svg');
    svg.setAttribute('width', '28');
    svg.setAttribute('height', '10');
    svg.setAttribute('viewBox', '0 0 32 10');
    function dot(cx, begin){
      var c = document.createElementNS(svgNS, 'circle');
      c.setAttribute('cx', String(cx));
      c.setAttribute('cy', '5');
      c.setAttribute('r', '3');
      c.setAttribute('fill', 'currentColor');
      var anim = document.createElementNS(svgNS, 'animate');
      anim.setAttribute('attributeName', 'opacity');
      anim.setAttribute('values', '0;1;0');
      anim.setAttribute('dur', '1.2s');
      anim.setAttribute('repeatCount', 'indefinite');
      anim.setAttribute('begin', begin);
      c.appendChild(anim);
      return c;
    }
    svg.appendChild(dot(6, '0s'));
    svg.appendChild(dot(16, '0.2s'));
    svg.appendChild(dot(26, '0.4s'));
    return svg;
  }

  function ensureTypingRow(){
    if (typingRow && typingRow.parentNode === list) { nudgeBottomSoon(); return typingRow; }
    var row = veCreate('div', 'chat_message_row incoming typing');
    row.setAttribute('data-ymd', todayYmd());
    row.setAttribute('data-typing', '1');
    var avatarWrap = veCreate('div', 'chat_avatar');
    var img = veCreate('img'); img.alt = ''; img.src = otherAvatar || '';
    avatarWrap.appendChild(img);
    var bubble = veCreate('div', 'chat_bubble incoming typing');
    var svg = buildTypingSVG();
    bubble.appendChild(svg);
    row.appendChild(avatarWrap);
    row.appendChild(bubble);
    list.appendChild(row);
    ensureDayHeaderFor(row);
    typingRow = row;
    nudgeBottomSoon();
    return row;
  }

  function removeTypingRow(){
    if (typingRow && typingRow.parentNode) {
      try { typingRow.parentNode.removeChild(typingRow); } catch (e) {}
    }
    typingRow = null;
    nudgeBottomSoon();
  }

  function sendTyping(isOn){
    if (!chatPartnerId) return Promise.resolve();
    var form = new FormData();
    form.append('p', 'typingPing');
    form.append('with', String(chatPartnerId));
    form.append('typing', isOn ? '1' : '0');
    form.append('csrf_token', getCsrf());
    return postForm(form).catch(function(){ /* no-op */ });
  }

  function startTyping(){
    if (destroyed || !chatPartnerId) return;
    if (!typingActive) {
      typingActive = true;
      lastTypingPing = 0; // force immediate ping
    }
    var now = nowSec();
    if (now - lastTypingPing >= 3) {
      lastTypingPing = now;
      sendTyping(true);
    }
    if (typingPingTimer) clearTimeout(typingPingTimer);
    typingPingTimer = setTimeout(function(){
      if (!destroyed && typingActive) {
        startTyping();
      }
    }, 3000);
  }

  function stopTyping(){
    typingActive = false;
    if (typingPingTimer) { try { clearTimeout(typingPingTimer); } catch (e) {} typingPingTimer = null; }
    sendTyping(false);
  }

  function checkTyping(){
    if (destroyed || !chatPartnerId) return;
    var form = new FormData();
    form.append('p', 'typingStatus');
    form.append('with', String(chatPartnerId));
    form.append('csrf_token', getCsrf());
    postForm(form).then(function(res){
      if (!res || res.status !== 'success') return;
      if (res.typing) {
        ensureTypingRow();
      } else {
        removeTypingRow();
      }
    }).catch(function(){ /* no-op */ });
  }

  function postForm(form) {
    if (destroyed) { return Promise.resolve({}); }
    var opts = {
      method: 'POST',
      credentials: 'same-origin',
      body: form
    };
    if (abortController && abortController.signal) {
      opts.signal = abortController.signal;
    }
    return fetch(REQUEST_URL, opts).then(function(r){
      if (destroyed) { return {}; }
      if (r.status === 403) { throw new Error('CSRF'); }
      return r.json();
    });
  }

  function chatShellFromNode(node){
    if (!node || !node.closest) { return document; }
    return node.closest('.i_message_wrp, .i_message_container, .i_message_wrapper, .chat_list, .chat_box, .messages-page__thread') || document;
  }

  function isMessagesPageNode(node){
    return !!(node && node.closest && node.closest('.messages-page__thread'));
  }

  function resetFloatingMenu(menu){
    if (!menu) { return; }
    menu.classList.remove('is-floating');
    menu.style.left = '';
    menu.style.top = '';
    menu.style.right = '';
    menu.style.bottom = '';
    menu.style.maxHeight = '';
    menu.style.overflowY = '';
    menu.__chatAnchor = null;
    if (menu.__chatOriginalParent) {
      try {
        menu.__chatOriginalParent.insertBefore(menu, menu.__chatOriginalNext || null);
      } catch (_) {
        try { menu.__chatOriginalParent.appendChild(menu); } catch (__) {}
      }
      menu.__chatOriginalParent = null;
      menu.__chatOriginalNext = null;
    }
  }

  function resetFloatingReactionRail(rail){
    if (!rail) { return; }
    rail.classList.remove('is-floating');
    rail.style.left = '';
    rail.style.top = '';
    rail.style.right = '';
    rail.style.bottom = '';
    rail.style.maxWidth = '';
    rail.style.overflowX = '';
    rail.__chatAnchor = null;
    rail.__chatRow = null;
    if (rail.__chatOriginalParent) {
      try {
        rail.__chatOriginalParent.insertBefore(rail, rail.__chatOriginalNext || null);
      } catch (_) {
        try { rail.__chatOriginalParent.appendChild(rail); } catch (__) {}
      }
      rail.__chatOriginalParent = null;
      rail.__chatOriginalNext = null;
    }
  }

  function positionFloatingMenu(menu, anchor, preferLeft){
    if (!menu || !anchor) { return; }
    menu.classList.add('is-floating');
    menu.style.left = '0px';
    menu.style.top = '0px';
    menu.style.right = 'auto';
    menu.style.bottom = 'auto';
    menu.style.maxHeight = '';
    menu.style.overflowY = '';
    var anchorRect = anchor.getBoundingClientRect();
    var menuRect = menu.getBoundingClientRect();
    var width = menuRect.width || 180;
    var height = menuRect.height || 160;
    var gap = 8;
    var viewportW = window.innerWidth || document.documentElement.clientWidth || 0;
    var viewportH = window.innerHeight || document.documentElement.clientHeight || 0;
    var x = preferLeft ? (anchorRect.left - width - gap) : (anchorRect.right + gap);
    if (x < gap) { x = anchorRect.right + gap; }
    if (x + width > viewportW - gap) { x = Math.max(gap, viewportW - width - gap); }
    var y = anchorRect.top;
    if (y + height > viewportH - gap) { y = Math.max(gap, viewportH - height - gap); }
    if (height > viewportH - (gap * 2)) {
      y = gap;
      menu.style.maxHeight = Math.max(140, viewportH - (gap * 2)) + 'px';
      menu.style.overflowY = 'auto';
    }
    menu.style.left = Math.round(x) + 'px';
    menu.style.top = Math.round(y) + 'px';
  }

  function positionFloatingReactionRail(rail, anchor){
    if (!rail || !anchor) { return; }
    rail.classList.add('is-floating');
    rail.style.left = '0px';
    rail.style.top = '0px';
    rail.style.right = 'auto';
    rail.style.bottom = 'auto';
    rail.style.maxWidth = '';
    rail.style.overflowX = '';

    var anchorRect = anchor.getBoundingClientRect();
    var railRect = rail.getBoundingClientRect();
    var viewportW = window.innerWidth || document.documentElement.clientWidth || 0;
    var viewportH = window.innerHeight || document.documentElement.clientHeight || 0;
    var edge = 8;
    var gap = 8;
    var width = railRect.width || 280;
    var height = railRect.height || 52;

    if (width > viewportW - (edge * 2)) {
      width = Math.max(180, viewportW - (edge * 2));
      rail.style.maxWidth = width + 'px';
      rail.style.overflowX = 'auto';
    }

    var x = anchorRect.left + (anchorRect.width / 2) - (width / 2);
    if (x < edge) { x = edge; }
    if (x + width > viewportW - edge) { x = Math.max(edge, viewportW - width - edge); }

    var yBelow = anchorRect.bottom + gap;
    var yAbove = anchorRect.top - height - gap;
    var y = yBelow;
    if (yBelow + height > viewportH - edge && yAbove >= edge) {
      y = yAbove;
    }
    if (y + height > viewportH - edge) { y = Math.max(edge, viewportH - height - edge); }
    if (y < edge) { y = edge; }

    rail.style.left = Math.round(x) + 'px';
    rail.style.top = Math.round(y) + 'px';
  }

  function positionHeaderConversationMenu(menu, anchor){
    if (!menu || !anchor) { return; }
    menu.classList.add('is-floating');
    menu.style.left = '0px';
    menu.style.top = '0px';
    menu.style.right = 'auto';
    menu.style.bottom = 'auto';
    menu.style.maxHeight = '';
    menu.style.overflowY = '';
    var anchorRect = anchor.getBoundingClientRect();
    var menuRect = menu.getBoundingClientRect();
    var width = menuRect.width || 232;
    var height = menuRect.height || 312;
    var gap = 10;
    var edge = 8;
    var viewportW = window.innerWidth || document.documentElement.clientWidth || 0;
    var viewportH = window.innerHeight || document.documentElement.clientHeight || 0;
    var x = anchorRect.right - width;
    var y = anchorRect.bottom + gap;
    if (x < edge) { x = edge; }
    if (x + width > viewportW - edge) { x = Math.max(edge, viewportW - width - edge); }
    if (y + height > viewportH - edge) { y = Math.max(edge, anchorRect.top - height - gap); }
    if (height > viewportH - (edge * 2)) {
      y = edge;
      menu.style.maxHeight = Math.max(160, viewportH - (edge * 2)) + 'px';
      menu.style.overflowY = 'auto';
    }
    menu.style.left = Math.round(x) + 'px';
    menu.style.top = Math.round(y) + 'px';
  }

  function portalActionMenu(menu, anchor, row){
    if (!menu || !document.body) { return; }
    if (!menu.__chatOriginalParent) {
      menu.__chatOriginalParent = menu.parentNode;
      menu.__chatOriginalNext = menu.nextSibling;
    }
    menu.__chatAnchor = anchor || null;
    menu.__chatRow = row || null;
    if (menu.parentNode !== document.body) {
      document.body.appendChild(menu);
    }
  }

  function portalReactionRail(rail, anchor, row){
    if (!rail || !document.body) { return; }
    if (!rail.__chatOriginalParent) {
      rail.__chatOriginalParent = rail.parentNode;
      rail.__chatOriginalNext = rail.nextSibling;
    }
    rail.__chatAnchor = anchor || null;
    rail.__chatRow = row || null;
    if (rail.parentNode !== document.body) {
      document.body.appendChild(rail);
    }
  }

  function closeHeaderConversationMenus(except){
    document.querySelectorAll('[data-chat-conversation-menu]').forEach(function(menu){
      if (menu !== except) {
        menu.hidden = true;
        resetFloatingMenu(menu);
        var btn = menu.parentNode ? menu.parentNode.querySelector('[data-chat-menu-toggle]') : null;
        if (btn) {
          btn.setAttribute('aria-expanded', 'false');
          btn.classList.remove('is-active');
        }
      }
    });
  }

  function setHeaderSearch(root, open){
    var panel = root.querySelector ? root.querySelector('[data-chat-thread-search]') : null;
    var toggle = root.querySelector ? root.querySelector('[data-chat-thread-search-toggle]') : null;
    if (!panel) { return; }
    panel.hidden = !open;
    if (toggle) {
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      toggle.classList.toggle('is-active', !!open);
    }
    if (open) {
      var input = panel.querySelector('[data-chat-thread-search-input]');
      if (input) {
        setTimeout(function(){ input.focus(); input.select(); }, 0);
      }
    } else {
      clearHeaderSearch(root);
    }
  }

  function headerSearchRows(root){
    return Array.prototype.slice.call((root.querySelectorAll ? root.querySelectorAll('.chat_message_row') : []));
  }

  function headerSearchText(row){
    return (row ? row.textContent : '').toLowerCase();
  }

  function updateHeaderSearch(root, step){
    var panel = root.querySelector ? root.querySelector('[data-chat-thread-search]') : null;
    if (!panel) { return; }
    var input = panel.querySelector('[data-chat-thread-search-input]');
    var counter = panel.querySelector('[data-chat-thread-search-count]');
    var query = input ? String(input.value || '').trim().toLowerCase() : '';
    var rows = headerSearchRows(root);
    var matches = [];
    rows.forEach(function(row){
      var isMatch = !!query && headerSearchText(row).indexOf(query) !== -1;
      row.classList.toggle('chat_search_match', isMatch);
      row.classList.remove('is-current');
      if (isMatch) { matches.push(row); }
    });
    var index = parseInt(panel.getAttribute('data-current-index') || '-1', 10);
    if (!matches.length) {
      panel.setAttribute('data-current-index', '-1');
      if (counter) { counter.textContent = query ? '0/0' : '0/0'; }
      return;
    }
    if (typeof step === 'number') {
      index = index < 0 ? 0 : (index + step + matches.length) % matches.length;
    } else if (index < 0 || index >= matches.length) {
      index = 0;
    }
    panel.setAttribute('data-current-index', String(index));
    matches[index].classList.add('is-current');
    if (counter) { counter.textContent = (index + 1) + '/' + matches.length; }
    try { matches[index].scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (_) {}
  }

  function clearHeaderSearch(root){
    if (!root || !root.querySelectorAll) { return; }
    root.querySelectorAll('.chat_search_match, .chat_message_row.is-current').forEach(function(row){
      row.classList.remove('chat_search_match', 'is-current');
    });
    var panel = root.querySelector('[data-chat-thread-search]');
    if (panel) { panel.setAttribute('data-current-index', '-1'); }
    var counter = root.querySelector('[data-chat-thread-search-count]');
    if (counter) { counter.textContent = '0/0'; }
  }

  function closeActionMenus(except){
    var menus = Array.prototype.slice.call(list.querySelectorAll('.chat_action_menu'));
    document.querySelectorAll('.chat_action_menu.is-floating').forEach(function(menu){
      if (menus.indexOf(menu) === -1) { menus.push(menu); }
    });
    menus.forEach(function(menu){
      if (menu !== except) {
        menu.hidden = true;
        resetFloatingMenu(menu);
      }
    });
  }

  function closeReactionRails(except){
    var rails = Array.prototype.slice.call(list.querySelectorAll('.chat_reaction_rail'));
    document.querySelectorAll('.chat_reaction_rail.is-floating').forEach(function(rail){
      if (rails.indexOf(rail) === -1) { rails.push(rail); }
    });
    rails.forEach(function(rail){
      if (rail !== except) {
        rail.hidden = true;
        resetFloatingReactionRail(rail);
      }
    });
  }

  function postMessageAction(action, mid, extra){
    var form = new FormData();
    form.append('p', action);
    form.append('message_id', String(mid || 0));
    form.append('csrf_token', getCsrf());
    Object.keys(extra || {}).forEach(function(key){
      form.append(key, String(extra[key]));
    });
    return postForm(form);
  }

  function refreshRowReaction(row, reaction){
    if (!row) { return; }
    var bubble = row.querySelector('.chat_bubble');
    if (!bubble) { return; }
    var normalized = (!reaction || reaction === 'none') ? '' : reaction;
    row.setAttribute('data-my-reaction', normalized);
    row.querySelectorAll('.chat_reaction_choice').forEach(function(btn){
      var isActive = normalized && btn.getAttribute('data-chat-reaction-choice') === normalized;
      btn.classList.toggle('is-active', !!isActive);
      btn.setAttribute('aria-pressed', isActive ? 'true' : 'false');
    });
    var wrap = bubble.querySelector('.chat_reactions');
    if (!normalized) {
      if (wrap && wrap.parentNode) {
        wrap.parentNode.removeChild(wrap);
      }
      return;
    }
    if (!wrap) {
      wrap = veCreate('div', 'chat_reactions');
      var actions = bubble.querySelector('.chat_message_actions');
      bubble.insertBefore(wrap, actions || null);
    }
    wrap.innerHTML = '<span>' + reactionLabel(normalized || 'heart') + '</span>';
  }

  function handleReactionChoice(actionEl, row, mid){
    if (!actionEl || !row || !mid) { return; }
    var reaction = actionEl.getAttribute('data-chat-reaction-choice') || 'heart';
    actionEl.disabled = true;
    postMessageAction('reactMessage', mid, { reaction: reaction }).then(function(res){
      if (res && res.status === 'success') {
        var savedReaction = typeof res.reaction === 'string' ? res.reaction : reaction;
        refreshRowReaction(row, savedReaction);
        closeReactionRails();
        actionToast(savedReaction ? t('chat_toast_reaction_added', 'Reaction added.') : t('chat_toast_reaction_removed', 'Reaction removed.'), 'success');
      } else {
        actionToast(t('chat_toast_reaction_failed', 'Reaction could not be saved.'), 'error');
      }
      actionEl.disabled = false;
    }).catch(function(){
      actionEl.disabled = false;
      actionToast(t('chat_toast_reaction_failed', 'Reaction could not be saved.'), 'error');
    });
  }

  function markRowDeleted(row, removeForMe){
    if (!row) { return; }
    if (removeForMe) {
      if (row.parentNode) { row.parentNode.removeChild(row); }
      return;
    }
    var bubble = row.querySelector('.chat_bubble');
    if (!bubble) { return; }
    bubble.innerHTML = '<span class="chat_deleted_message">' + escapeHtml(t('chat_deleted_message', 'This message was deleted')) + '</span>';
    row.setAttribute('data-deleted', '1');
  }

  list.addEventListener('click', function(event){
    var actionEl = event.target.closest('[data-chat-action]');
    if (!actionEl) { return; }
    var action = actionEl.getAttribute('data-chat-action') || '';
    var row = actionEl.closest('.chat_message_row');
    var mid = parseInt(actionEl.getAttribute('data-mid') || (row ? row.getAttribute('data-mid') : '0') || '0', 10) || 0;

    if (action === 'toggle-menu') {
      event.preventDefault();
      var menu = actionEl.parentNode ? actionEl.parentNode.querySelector('.chat_action_menu') : null;
      if (!menu) {
        var activeFloatingMenu = document.querySelector('.chat_action_menu.is-floating');
        if (activeFloatingMenu && activeFloatingMenu.__chatAnchor === actionEl) {
          menu = activeFloatingMenu;
        }
      }
      if (menu) {
        var willOpen = menu.hidden;
        closeActionMenus(menu);
        closeReactionRails();
        menu.hidden = !willOpen;
        if (willOpen) {
          var preferLeft = !!(row && row.classList.contains('outgoing'));
          portalActionMenu(menu, actionEl, row);
          positionFloatingMenu(menu, actionEl, preferLeft);
        } else {
          resetFloatingMenu(menu);
        }
      }
      return;
    }

    if (action === 'toggle-reactions') {
      event.preventDefault();
      var rail = actionEl.parentNode ? actionEl.parentNode.querySelector('.chat_reaction_rail') : null;
      if (!rail) {
        var activeFloatingRail = document.querySelector('.chat_reaction_rail.is-floating');
        if (activeFloatingRail && activeFloatingRail.__chatAnchor === actionEl) {
          rail = activeFloatingRail;
        }
      }
      if (rail) {
        var willOpenRail = rail.hidden;
        closeActionMenus();
        closeReactionRails(rail);
        rail.hidden = !willOpenRail;
        if (willOpenRail) {
          portalReactionRail(rail, actionEl, row);
          positionFloatingReactionRail(rail, actionEl);
        } else {
          resetFloatingReactionRail(rail);
        }
      }
      return;
    }

    if (action === 'reply') {
      event.preventDefault();
      closeActionMenus();
      closeReactionRails();
      setReplyTarget(row);
      return;
    }

    if (action === 'reply-jump') {
      event.preventDefault();
      var targetMid = parseInt(actionEl.getAttribute('data-reply-mid') || '0', 10) || 0;
      var target = targetMid ? list.querySelector('[data-mid="' + targetMid + '"]') : null;
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'center' });
        target.classList.add('is-highlighted');
        setTimeout(function(){ target.classList.remove('is-highlighted'); }, 1400);
      }
      return;
    }

    if (action === 'copy') {
      event.preventDefault();
      closeActionMenus();
      closeReactionRails();
      var text = rowPreviewText(row);
      if (navigator.clipboard && text) {
        navigator.clipboard.writeText(text).then(function(){
          actionToast(t('chat_toast_message_copied', 'Message copied.'), 'success');
        }).catch(function(){
          actionToast(t('chat_toast_message_copy_failed', 'Message could not be copied.'), 'error');
        });
      }
      return;
    }

    if (action === 'react-choice' && mid) {
      event.preventDefault();
      handleReactionChoice(actionEl, row, mid);
      return;
    }

    if (action === 'unlock-paid-media' && mid) {
      event.preventDefault();
      closeActionMenus();
      closeReactionRails();
      actionEl.disabled = true;
      postMessageAction('unlockPaidMedia', mid, {}).then(function(res){
        if (res && res.status === 'success' && res.media_url) {
          renderPaidMediaIntoBubble(row, res.media_url, res.media_type || 'image');
        } else {
          actionEl.disabled = false;
          var card = row ? row.querySelector('[data-paid-media-card]') : null;
          if (card) { card.setAttribute('data-error', (res && res.message) ? res.message : 'error'); }
        }
      }).catch(function(){
        actionEl.disabled = false;
      });
      return;
    }

    if ((action === 'delete-self' || action === 'delete-everyone') && mid) {
      event.preventDefault();
      closeActionMenus();
      closeReactionRails();
      var scope = action === 'delete-everyone' ? 'everyone' : 'self';
      openDeleteConfirm(row, mid, scope);
      return;
    }

    if (action === 'report' && mid) {
      event.preventDefault();
      closeActionMenus();
      closeReactionRails();
      openReportModal(mid);
    }
  });

  document.addEventListener('click', function(event){
    var portalledReactionAction = event.target.closest('.chat_reaction_rail.is-floating [data-chat-action="react-choice"]');
    if (portalledReactionAction) {
      event.preventDefault();
      var portalledRail = portalledReactionAction.closest('.chat_reaction_rail.is-floating');
      var portalledReactionRow = portalledRail ? portalledRail.__chatRow : null;
      var portalledReactionMid = parseInt(portalledReactionAction.getAttribute('data-mid') || (portalledReactionRow ? portalledReactionRow.getAttribute('data-mid') : '0') || '0', 10) || 0;
      handleReactionChoice(portalledReactionAction, portalledReactionRow, portalledReactionMid);
      return;
    }

    var portalledMessageAction = event.target.closest('.chat_action_menu.is-floating [data-chat-action]');
    if (portalledMessageAction) {
      event.preventDefault();
      var portalledMenu = portalledMessageAction.closest('.chat_action_menu.is-floating');
      var portalledRow = portalledMenu ? portalledMenu.__chatRow : null;
      var portalledMid = parseInt(portalledMessageAction.getAttribute('data-mid') || (portalledRow ? portalledRow.getAttribute('data-mid') : '0') || '0', 10) || 0;
      var portalledAction = portalledMessageAction.getAttribute('data-chat-action') || '';
      closeActionMenus();
      closeReactionRails();
      if (portalledAction === 'reply') {
        setReplyTarget(portalledRow);
        return;
      }
      if (portalledAction === 'copy') {
        var copiedText = rowPreviewText(portalledRow);
        if (navigator.clipboard && copiedText) {
          navigator.clipboard.writeText(copiedText).then(function(){
            actionToast(t('chat_toast_message_copied', 'Message copied.'), 'success');
          }).catch(function(){
            actionToast(t('chat_toast_message_copy_failed', 'Message could not be copied.'), 'error');
          });
        }
        return;
      }
      if ((portalledAction === 'delete-self' || portalledAction === 'delete-everyone') && portalledMid) {
        openDeleteConfirm(portalledRow, portalledMid, portalledAction === 'delete-everyone' ? 'everyone' : 'self');
        return;
      }
      if (portalledAction === 'report' && portalledMid) {
        openReportModal(portalledMid);
        return;
      }
    }

    var headerSearchToggle = event.target.closest('[data-chat-thread-search-toggle]');
    if (headerSearchToggle && !isMessagesPageNode(headerSearchToggle)) {
      event.preventDefault();
      var searchRoot = chatShellFromNode(headerSearchToggle);
      closeHeaderConversationMenus();
      var searchPanel = searchRoot.querySelector('[data-chat-thread-search]');
      setHeaderSearch(searchRoot, !(searchPanel && !searchPanel.hidden));
      return;
    }

    var headerSearchClose = event.target.closest('[data-chat-thread-search-close]');
    if (headerSearchClose && !isMessagesPageNode(headerSearchClose)) {
      event.preventDefault();
      setHeaderSearch(chatShellFromNode(headerSearchClose), false);
      return;
    }

    var headerSearchNext = event.target.closest('[data-chat-thread-search-next]');
    var headerSearchPrev = event.target.closest('[data-chat-thread-search-prev]');
    if ((headerSearchNext || headerSearchPrev) && !isMessagesPageNode(headerSearchNext || headerSearchPrev)) {
      event.preventDefault();
      updateHeaderSearch(chatShellFromNode(headerSearchNext || headerSearchPrev), headerSearchNext ? 1 : -1);
      return;
    }

    var headerMenuToggle = event.target.closest('[data-chat-menu-toggle]');
    if (headerMenuToggle && !isMessagesPageNode(headerMenuToggle)) {
      event.preventDefault();
      var menu = headerMenuToggle.parentNode ? headerMenuToggle.parentNode.querySelector('[data-chat-conversation-menu]') : null;
      var willOpen = !!(menu && menu.hidden);
      closeHeaderConversationMenus(menu);
      if (menu) {
        menu.hidden = !willOpen;
        headerMenuToggle.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
        headerMenuToggle.classList.toggle('is-active', willOpen);
        if (willOpen) {
          setHeaderSearch(chatShellFromNode(headerMenuToggle), false);
          positionHeaderConversationMenu(menu, headerMenuToggle);
        } else {
          resetFloatingMenu(menu);
        }
      }
      return;
    }

    var headerMenuAction = event.target.closest('[data-chat-menu-action]');
    if (headerMenuAction && !isMessagesPageNode(headerMenuAction)) {
      event.preventDefault();
      closeHeaderConversationMenus();
      actionToast(t('chat_open_messages_manage_hint', 'Open Messages page to manage this conversation.'), 'success');
      return;
    }

    if (event.target.closest('[data-chat-modal-close]') || event.target.classList.contains('chat_action_modal')) {
      event.preventDefault();
      closeChatActionModal();
      return;
    }
    if (!event.target.closest('.chat_message_actions')) {
      closeActionMenus();
      closeReactionRails();
    }
    if (!event.target.closest('[data-chat-header-actions]') && !event.target.closest('[data-chat-thread-search]')) {
      closeHeaderConversationMenus();
    }
    var cancel = event.target.closest('[data-chat-action="cancel-reply"]');
    if (cancel) {
      event.preventDefault();
      clearReplyTarget();
    }
  });

  list.addEventListener('scroll', function(){
    closeActionMenus();
    closeReactionRails();
  });

  window.addEventListener('resize', function(){
    closeActionMenus();
    closeReactionRails();
  });

  document.addEventListener('input', function(event){
    var inputEl = event.target.closest ? event.target.closest('[data-chat-thread-search-input]') : null;
    if (inputEl && !isMessagesPageNode(inputEl)) {
      updateHeaderSearch(chatShellFromNode(inputEl), 0);
    }
  });

  // (legacy guard helpers removed; marking read is now idempotent and unconditional when chat is open)

  function sendMessage(){
    if (destroyed) return;
    if (isSending) return;
    if (!chatPartnerId) return;
    var text = (input && input.value ? input.value.trim() : '');
    if (!text) return;

    var form = new FormData();
    form.append('p', 'sendNewMessage');
    form.append('to', String(chatPartnerId));
    form.append('message', text);
    if (replyTarget && replyTarget.id) {
      form.append('reply_to', String(replyTarget.id));
    }
    form.append('csrf_token', getCsrf());

    isSending = true;
    postForm(form).then(function(res){
      if (res && res.status === 'success' && res.data) {
        buildMessageRow(res.data);
        lastTs = Math.max(lastTs, res.data.message_time || 0);
        try { window.DZ = window.DZ || {}; DZ.lastSentMessageAt = Date.now(); DZ.lastSentMessageTs = parseInt(res.data.message_time || '0', 10) || 0; } catch (__) {}
        if (input) { input.value = ''; input.dispatchEvent(new Event('input')); }
        clearReplyTarget();
        stopTyping();
        scrollToBottom(true);
        if (input) { input.focus(); }
      }
    }).catch(function(err){
      // Optionally show toast: err.message === 'CSRF' ? 'Session expired' : 'Network error'
    }).finally(function(){ isSending = false; });
  }

  function fetchNew(){
    if (destroyed) return;
    if (!chatPartnerId) return;
    var wasNearBottom = false;
    try { wasNearBottom = isNearBottom(); } catch(_){ }
    var form = new FormData();
    form.append('p', 'fetchNewMessages');
    form.append('with', String(chatPartnerId));
    form.append('since', String(lastTs || 0));
    form.append('csrf_token', getCsrf());

    postForm(form).then(function(res){
      if (res && res.status === 'success' && Array.isArray(res.items)) {
        var anyMedia = false;
        var gotNew = res.items.length > 0;
        res.items.forEach(function(m){
          buildMessageRow(m);
          lastTs = Math.max(lastTs, m.message_time || 0);
          if (m && m.file && (m.file_kind === 'image' || m.file_kind === 'video')) { anyMedia = true; }
        });
        if (res.items.length && (wasNearBottom || isNearBottom())) scrollToBottomReliable(true);
        // If we just received messages, immediately refresh statuses and mark read (no scroll condition)
        if (gotNew) {
          try { fetchStatuses({ force:true }); } catch(_){ }
          try { markReadConversation(); } catch(_){ }
        }
      }
    }).catch(function(){ /* no-op */ });
  }

  function markReadConversation(){
    if (!chatPartnerId) return;
    var fd = new FormData();
    fd.append('p','markReadConversation');
    fd.append('with', String(chatPartnerId));
    fd.append('csrf_token', getCsrf());
    postForm(fd).then(function(){ try { fetchStatuses({ force:true }); } catch(_){ } }).catch(function(){});
  }

  // On focus/visibility regain, mark read (no scroll condition)
  try {
    window.addEventListener('focus', function(){ try { markReadConversation(); } catch(_){} });
    document.addEventListener('visibilitychange', function(){ try { if (document.visibilityState === 'visible') markReadConversation(); } catch(_){} });
  } catch(_){ }

  // On scroll, opportunistically mark read (idempotent)
  try {
    list.addEventListener('scroll', function(){ try { markReadConversation(); } catch(_){} });
  } catch(_){ }

  // --- Status poller: update ticks for recent outgoing messages ---
  function updateBubbleTick(mid, deliveredAt, readAt){
    try {
      var row = list.querySelector('[data-mid="' + mid + '"]');
      if (!row) return;
      var bubble = row.querySelector('.chat_bubble.outgoing');
      if (!bubble) return;
      var st = bubble.querySelector('.chat_status');
      if (!st) { st = document.createElement('div'); st.className = 'chat_status'; bubble.appendChild(st); }
      st.innerHTML = '';
      var icon = 'tick';
      var tickState = 'single';
      if (parseInt(readAt||0,10) > 0) { icon = 'tick_double_blue'; tickState = 'blue'; }
      else if (parseInt(deliveredAt||0,10) > 0) { icon = 'tick_double'; tickState = 'double'; }
      var svg = ICONS.html(icon);
      if (svg) { var span = document.createElement('span'); span.className='tick_icon'; span.innerHTML = svg; st.appendChild(span); }
      else { var im = document.createElement('img'); im.src = ICONS.url(icon); im.alt = icon; im.className='tick_icon'; st.appendChild(im); }
      row.setAttribute('data-tick', tickState);
    } catch (_) {}
  }

  var statusPollSkip = 0;
  function fetchStatuses(opts){
    opts = opts || {};
    if (destroyed) return;
    if (!chatPartnerId) return;
    // Poll every other tick to reduce load unless forced
    if (!opts.force) {
      statusPollSkip = (statusPollSkip + 1) % 2;
      if (statusPollSkip) return;
    }
    var mids = [];
    var expanded = !!opts.expanded; // when true, ask server for a bigger recent window
    try {
      if (!expanded) {
        // Query messages that are not yet "read" (blue): include single, double and those missing an explicit state (server-rendered)
        var nodes = list.querySelectorAll('.chat_message_row.outgoing[data-mid]:not([data-tick]), .chat_message_row.outgoing[data-mid][data-tick="single"], .chat_message_row.outgoing[data-mid][data-tick="double"]');
        nodes.forEach(function(n){ var id = parseInt(n.getAttribute('data-mid')||'0',10)||0; if (id) mids.push(id); });
      }
    } catch(_){}
    // Hard limit to keep payload small (last 50) when using targeted ids
    if (!expanded && mids.length > 50) { mids = mids.slice(-50); }
    var form = new FormData();
    form.append('p','fetchMessageStatuses');
    form.append('with', String(chatPartnerId));
    if (mids.length) { form.append('ids', JSON.stringify(mids)); }
    else {
      // Ask server for a broader recent window (e.g., older messages still single-tick)
      var lim = (typeof opts.limit === 'number' && opts.limit > 0) ? Math.min(opts.limit, 500) : 200;
      form.append('limit', String(lim));
    }
    form.append('csrf_token', getCsrf());
    postForm(form).then(function(res){
      if (!res || res.status !== 'success' || !Array.isArray(res.items)) return;
      res.items.forEach(function(it){
        var mid = parseInt(it.message_id||0,10)||0; if (!mid) return;
        updateBubbleTick(mid, it.delivered_at, it.read_at);
      });
      // Backfill: if server reports a highest read id, mark all older outgoing bubbles as read (blue)
      try {
        var maxRid = parseInt(res.max_read_id||0,10)||0;
        if (maxRid > 0) {
          var nodes = list.querySelectorAll('.chat_message_row.outgoing[data-mid]');
          nodes.forEach(function(n){
            var id = parseInt(n.getAttribute('data-mid')||'0',10)||0;
            if (id > 0 && id <= maxRid) {
              updateBubbleTick(id, 1, 1);
            }
          });
        }
      } catch(_){}
    }).catch(function(){ /* no-op */ });
  }

  // Allow external nudges (e.g., after get_live_chat response) to refresh ticks immediately
  try {
    document.addEventListener('chat:refresh-status', function(){
      try { statusPollActive = true; fetchStatuses({ force:true, expanded:true, limit: 300 }); } catch(_){}
    });
  } catch(_){}

  if (sendBtn) {
    sendBtn.addEventListener('click', function(){ sendMessage(); });
  }
  if (input) {
    // Enter to send (newline with Shift+Enter)
    keyHandler = function(ev){
      if (destroyed) return;
      if (ev.key === 'Enter' && !ev.shiftKey) {
        ev.preventDefault();
        sendMessage();
      }
    };
    input.addEventListener('keydown', keyHandler);
    input.addEventListener('input', function(){
      if (destroyed) return;
      var val = input.value || '';
      syncComposerActions();
      if (val.trim().length > 0) { startTyping(); }
      else { stopTyping(); }
    });
    input.addEventListener('blur', function(){ stopTyping(); });
    syncComposerActions();
  }
  // attach image picker to the existing attach button
  var attachBtn = document.querySelector('.attach_btn');
  if (attachBtn) {
    attachBtn.addEventListener('click', function(){ openImagePicker(); });
  }
  if (imgInput) {
    imgInput.addEventListener('change', function(){
      if (destroyed) return;
      var f = imgInput.files && imgInput.files[0] ? imgInput.files[0] : null;
      if (!f) return;
      sendImageFile(f);
      // reset input for subsequent selects
      try { imgInput.value = ''; } catch (e) {}
    });
  }
  var videoBtn = document.querySelector('.video_btn');
  if (videoBtn) {
    videoBtn.addEventListener('click', function(){ openVideoPicker(); });
  }
  var tipBtn = document.querySelector('[data-chat-tip-open]');
  if (tipBtn) {
    tipBtn.addEventListener('click', function(){
      toggleTipPanel();
    });
  }
  var paidBtn = document.querySelector('[data-chat-paid-open]');
  if (paidBtn) {
    paidBtn.addEventListener('click', function(){
      togglePaidPanel();
    });
  }
  var paidImgInput = document.getElementById('chat_paid_image_input');
  var paidVidInput = document.getElementById('chat_paid_video_input');
  document.addEventListener('click', function(event){
    var tipSend = event.target.closest('[data-chat-tip-send]');
    if (tipSend) {
      event.preventDefault();
      sendChatTip();
      return;
    }
    var tipClose = event.target.closest('[data-chat-tip-close]');
    if (tipClose) {
      event.preventDefault();
      toggleTipPanel(false);
      return;
    }
    var paidImage = event.target.closest('[data-chat-paid-image]');
    if (paidImage) {
      event.preventDefault();
      if (paidImgInput) { paidImgInput.value = ''; paidImgInput.click(); }
      return;
    }
    var paidVideo = event.target.closest('[data-chat-paid-video]');
    if (paidVideo) {
      event.preventDefault();
      if (paidVidInput) { paidVidInput.value = ''; paidVidInput.click(); }
      return;
    }
    var paidClose = event.target.closest('[data-chat-paid-close]');
    if (paidClose) {
      event.preventDefault();
      togglePaidPanel(false);
    }
  });
  if (paidImgInput) {
    paidImgInput.addEventListener('change', function(){
      if (destroyed) return;
      var f = paidImgInput.files && paidImgInput.files[0] ? paidImgInput.files[0] : null;
      if (!f) return;
      sendPaidMediaFile('image', f);
      try { paidImgInput.value = ''; } catch (e) {}
    });
  }
  if (paidVidInput) {
    paidVidInput.addEventListener('change', function(){
      if (destroyed) return;
      var f = paidVidInput.files && paidVidInput.files[0] ? paidVidInput.files[0] : null;
      if (!f) return;
      sendPaidMediaFile('video', f);
      try { paidVidInput.value = ''; } catch (e) {}
    });
  }
  if (vidInput) {
    vidInput.addEventListener('change', function(){
      if (destroyed) return;
      var f = vidInput.files && vidInput.files[0] ? vidInput.files[0] : null;
      if (!f) return;
      sendVideoFile(f);
      try { vidInput.value = ''; } catch (e) {}
    });
  }

  // Start polling (override with window.CHAT_POLL_INTERVAL if needed)
  var pollMs = (typeof window.CHAT_POLL_INTERVAL === 'number' && window.CHAT_POLL_INTERVAL > 300)
      ? window.CHAT_POLL_INTERVAL
      : 4000;
  pollTimer = setInterval(function(){
    fetchNew();
    checkTyping();
    fetchStatuses();
  }, pollMs);

  // On initial chat open, attach nudges to any existing media and re-bottom after they load
  Array.prototype.forEach.call(list.querySelectorAll('img,video'), function(m){ addMediaNudge(m); });
  setTimeout(function(){
    if (destroyed) return;
    scrollToBottomReliable(true);
    // Notify chat opened; a central handler will mark read unconditionally
    try { document.dispatchEvent(new CustomEvent('chat:opened')); } catch(_){ }
  }, 200);
  // After initial render, perform an expanded status refresh once
  setTimeout(function(){ try { if (!destroyed) fetchStatuses({ force:true, expanded:true, limit:300 }); } catch(_){} }, 350);

  // Unified opener: debounce and call markRead + status refresh once per open
  (function(){
    var debounceTimer = null;
    function onChatOpened(){
      try { if (debounceTimer) clearTimeout(debounceTimer); } catch(_){}
      debounceTimer = setTimeout(function(){
        if (destroyed) return;
        try { markReadConversation(); } catch(_){ }
        try { fetchStatuses({ force:true, expanded:true, limit:300 }); } catch(_){ }
      }, 300);
    }
    try { document.addEventListener('chat:opened', onChatOpened); } catch(_){}
  })();

  // ---- global controller to allow clean teardown ----
  window.chatController = {
    destroy: function(){
      if (destroyed) return;
      destroyed = true;
      try { window.DZ = window.DZ || {}; DZ.activeChatUserId = 0; } catch (__) {}
      // stop polling
      try { if (pollTimer) { clearInterval(pollTimer); } } catch (e) {}
      // disconnect observer
      try { if (typeof mo !== 'undefined' && mo && typeof mo.disconnect === 'function') { mo.disconnect(); } } catch (e) {}
      // remove listeners
      try { if (sendBtn) { sendBtn.removeEventListener('click', sendMessage); } } catch (e) {}
      try { if (input && keyHandler) { input.removeEventListener('keydown', keyHandler); } } catch (e) {}
      try { if (actionsToggle) { actionsToggle.removeEventListener('click', composerToggleHandler); } } catch (e) {}
      try { if (compactActions) { compactActions.removeEventListener('click', composerActionsHandler); } } catch (e) {}
      try { document.removeEventListener('click', composerOutsideClickHandler); } catch (e) {}
      // abort any in-flight request
      try { if (abortController && typeof abortController.abort === 'function') { abortController.abort(); } } catch (e) {}
      // clear typing state
      try { stopTyping(); } catch (e) {}
      try { removeTypingRow(); } catch (e) {}
    }
  };
  $(document).on("click",".back-to , .getChatList", function(){
    $(".chat_list_box").empty();
    $(".current_message_box").addClass("none");
    if (window.chatController && typeof window.chatController.destroy === 'function') {
      window.chatController.destroy();
    }
  });
})();
