<?php
$languageAttr = 'en';
if (!empty($locale) && is_string($locale)) {
    $lc = strtolower($locale);
    if ($lc === 'eng') {
        $languageAttr = 'en';
    } elseif (strlen($lc) >= 2) {
        $languageAttr = substr($lc, 0, 2);
    }
}

$isRTLLocale = isset($isRTLLocale) ? (bool) $isRTLLocale : false;
$currentLocale = isset($currentLocale)
    ? (string) $currentLocale
    : strtolower((string) ($currentLang ?? ($locale ?? 'eng')));
if ($currentLocale === '') {
    $currentLocale = 'eng';
}

$currentTheme = $themeSlug ?? ($currentTheme ?? 'default');
$pageTitle = customLang('maintenance_page_title');
$headline  = customLang('maintenance_heading');
$tagline   = customLang('maintenance_subheading');
$defaultMessage = customLang('maintenance_default_message');
$etaLabel  = customLang('maintenance_eta_label');
$countdownLabel = customLang('maintenance_countdown_label');
$retryLabel = customLang('maintenance_retry_cta');
$contactLabel = customLang('maintenance_contact_cta');
$statusLabel  = customLang('maintenance_follow_updates');

// Ensure helper available (WordPress-style date_i18n fallback)
if (!function_exists('date_i18n')) {
    function date_i18n(string $format, int $timestamp): string
    {
        return gmdate($format, $timestamp);
    }
}

$etaStatus = isset($etaStatus) ? (string)$etaStatus : 'unset';
$hasEta = isset($etaTimestamp) && $etaTimestamp !== null;
$etaFuture = $hasEta && $etaStatus === 'future';
$etaElapsed = $hasEta && $etaStatus === 'elapsed';
$etaIso = $hasEta ? gmdate('c', (int)$etaTimestamp) : '';
$etaHuman = $hasEta ? date_i18n('M j, Y · H:i \U\T\C', (int)$etaTimestamp) : '';
$etaDisplayValue = $hasEta ? $etaHuman : customLang('maintenance_eta_tbd');

$logoDark  = isset($siteDarkLogo) && $siteDarkLogo ? $siteDarkLogo : ($siteData['logo_dark'] ?? '');
$logoWhite = isset($siteWhiteLogo) && $siteWhiteLogo ? $siteWhiteLogo : ($siteData['logo_white'] ?? '');
$logoMobileDark  = isset($siteMobileDarkLogo) && $siteMobileDarkLogo ? $siteMobileDarkLogo : ($siteData['logo_mobile_dark'] ?? '');
$logoMobileWhite = isset($siteMobileWhiteLogo) && $siteMobileWhiteLogo ? $siteMobileWhiteLogo : ($siteData['logo_mobile_white'] ?? '');

// Provide placeholders when metadata arrays not already in scope.
if (!isset($siteDescription)) {
    $siteDescription = $siteData['site_description'] ?? '';
}
if (!isset($siteTitle)) {
    $siteTitle = $siteData['site_title'] ?? ($siteData['site_name'] ?? '');
}

$siteNameLocal = isset($siteName) && $siteName ? $siteName : ($siteData['site_name'] ?? '');
$contactUrlSafe = $contactUrl ?? (rtrim($baseUrl ?? '/', '/') . '/contact');
$statusLinks = isset($statusLinks) && is_array($statusLinks) ? $statusLinks : [];

$buildAssetUrl = static function (?string $path) use ($baseUrl): string {
    $path = trim((string)$path);
    if ($path === '') {
        return '';
    }
    if (preg_match('~^https?://~i', $path)) {
        return $path;
    }
    return rtrim((string)$baseUrl, '/') . '/' . ltrim($path, '/');
};

$badgeLetter = static function (string $label): string {
    $label = trim($label);
    if ($label === '') {
        return '#';
    }
    if (function_exists('mb_substr') && function_exists('mb_strtoupper')) {
        return mb_strtoupper(mb_substr($label, 0, 1, 'UTF-8'), 'UTF-8');
    }
    return strtoupper(substr($label, 0, 1));
};

// Normalise variables expected by shared head partials
$base_url     = isset($base_url) && $base_url ? $base_url : ($baseUrl ?? '/');
$base_url     = rtrim($base_url, '/') . '/';
$currentTheme = isset($currentTheme) && $currentTheme ? $currentTheme : ($themeSlug ?? 'default');
$version      = isset($version) && $version ? $version : ($siteData['script_version'] ?? '1.0');
?>
<!doctype html>
<html lang="<?php echo iN_HelpSecure($currentLocale); ?>" dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-theme="auto">
  <head>
    <title><?php echo iN_HelpSecure($pageTitle); ?></title>
    <?php include __DIR__ . '/head/meta.php'; ?>
    <?php include __DIR__ . '/head/css.php'; ?>
    <?php include __DIR__ . '/head/js.php'; ?>
  </head>
  <body class="maintenance-body<?php echo $isRTLLocale ? ' rtl-locale' : ''; ?>" dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-logged-in="<?php echo (isset($loggedIn) && $loggedIn === '1') ? '1' : '0'; ?>">
    <?php $maintenanceCsrfToken = htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>
    <input type="hidden" name="csrf_token" value="<?php echo $maintenanceCsrfToken; ?>" />
    <main class="maintenance-screen" role="main" tabindex="-1" data-maintenance-auto-focus>
      <header class="maintenance-header">
        <a class="maintenance-brand" href="<?php echo iN_HelpSecure($baseUrl); ?>" aria-label="<?php echo iN_HelpSecure($siteNameLocal ?: 'Home'); ?>">
          <?php
            $alt = iN_HelpSecure($siteNameLocal ?: 'Logo');
            if (!empty($logoDark)) {
              echo '<img class="maintenance-logo maintenance-logo--dark" src="' . iN_HelpSecure($buildAssetUrl($logoDark)) . '" alt="' . $alt . '">';
            }
            if (!empty($logoWhite)) {
              echo '<img class="maintenance-logo maintenance-logo--light" src="' . iN_HelpSecure($buildAssetUrl($logoWhite)) . '" alt="' . $alt . '">';
            }
            if (!empty($logoMobileDark)) {
              echo '<img class="maintenance-logo maintenance-logo--mobile-dark" src="' . iN_HelpSecure($buildAssetUrl($logoMobileDark)) . '" alt="' . $alt . '">';
            }
            if (!empty($logoMobileWhite)) {
              echo '<img class="maintenance-logo maintenance-logo--mobile-light" src="' . iN_HelpSecure($buildAssetUrl($logoMobileWhite)) . '" alt="' . $alt . '">';
            }
          ?>
        </a>
        <div class="maintenance-language-switcher">
          <?php
            $languageSwitcherContext = [
                'button_classes' => 'auth_language_switcher flex align_items',
                'label_class' => 'auth_language_switcher__label',
            ];
            include __DIR__ . '/partials/language_switcher.php';
            unset($languageSwitcherContext);
          ?>
        </div>
        <div class="maintenance-header__meta">
          <span class="maintenance-pill" role="status" aria-live="polite"><?php echo iN_HelpSecure(customLang('maintenance_status_active')); ?></span>
          <?php if ($siteNameLocal): ?>
          <p class="maintenance-site-name"><?php echo iN_HelpSecure($siteNameLocal); ?></p>
          <?php endif; ?>
        </div>
      </header>

      <section class="maintenance-content">
        <h1 class="maintenance-title"><?php echo iN_HelpSecure($headline); ?></h1>
        <p class="maintenance-lead"><?php echo iN_HelpSecure($tagline); ?></p>

        <div class="maintenance-message">
          <p>
            <?php
              $messageToShow = $message !== '' ? $message : $defaultMessage;
              echo nl2br(iN_HelpSecure($messageToShow));
            ?>
          </p>
        </div>

        <div class="maintenance-status-card" aria-live="polite" data-maintenance-status>
          <div class="maintenance-status-card__row">
            <span class="maintenance-status-card__label"><?php echo iN_HelpSecure($etaLabel); ?></span>
            <span class="maintenance-status-card__value" data-maintenance-eta-text>
              <?php echo iN_HelpSecure($etaDisplayValue); ?>
            </span>
            <?php if ($hasEta && $etaElapsed): ?>
            <p class="maintenance-status-note"><?php echo iN_HelpSecure(customLang('maintenance_eta_elapsed')); ?></p>
            <?php endif; ?>
          </div>

          <?php
            $countdownClasses = 'maintenance-status-card__countdown';
            if (!$etaFuture) {
                $countdownClasses .= ' maintenance-status-card__countdown--hidden';
            }
            $countdownAttrs = '';
            if ($etaFuture) {
                $countdownAttrs .= ' data-maintenance-target="' . iN_HelpSecure((string)$etaTimestamp) . '"';
            }
            if ($hasEta) {
                $countdownAttrs .= ' data-maintenance-elapsed="' . iN_HelpSecure(customLang('maintenance_eta_elapsed')) . '"';
                $countdownAttrs .= ' data-maintenance-status="' . iN_HelpSecure($etaStatus) . '"';
            }
          ?>
          <div class="<?php echo $countdownClasses; ?>" data-maintenance-countdown<?php echo $countdownAttrs; ?> aria-live="polite">
            <span class="maintenance-status-card__countdown-label"><?php echo iN_HelpSecure($countdownLabel); ?></span>
            <div class="maintenance-countdown" data-maintenance-countdown-display>
              <span class="maintenance-countdown__segment" data-maintenance-countdown-days>
                <strong>0</strong><span><?php echo iN_HelpSecure(customLang('maintenance_countdown_days')); ?></span>
              </span>
              <span class="maintenance-countdown__segment" data-maintenance-countdown-hours>
                <strong>0</strong><span><?php echo iN_HelpSecure(customLang('maintenance_countdown_hours')); ?></span>
              </span>
              <span class="maintenance-countdown__segment" data-maintenance-countdown-minutes>
                <strong>0</strong><span><?php echo iN_HelpSecure(customLang('maintenance_countdown_minutes')); ?></span>
              </span>
              <span class="maintenance-countdown__segment" data-maintenance-countdown-seconds>
                <strong>0</strong><span><?php echo iN_HelpSecure(customLang('maintenance_countdown_seconds')); ?></span>
              </span>
            </div>
          </div>
        </div>

        <div class="maintenance-actions">
          <button type="button" class="btn maintenance-btn" data-maintenance-retry>
            <?php echo iN_HelpSecure($retryLabel); ?>
          </button>
          <?php if ($contactUrlSafe): ?>
          <a class="btn maintenance-btn maintenance-btn--secondary" href="<?php echo iN_HelpSecure($contactUrlSafe); ?>">
            <?php echo iN_HelpSecure($contactLabel); ?>
          </a>
          <?php endif; ?>
        </div>

        <?php if (!empty($statusLinks)): ?>
        <div class="maintenance-social">
          <p class="maintenance-social__title"><?php echo iN_HelpSecure($statusLabel); ?></p>
          <div class="maintenance-social__links" role="list">
            <?php foreach ($statusLinks as $link): ?>
              <a role="listitem" class="maintenance-social__link" href="<?php echo iN_HelpSecure($link['url']); ?>" target="_blank" rel="noopener noreferrer">
                <span class="maintenance-social__badge maintenance-social__badge--<?php echo iN_HelpSecure($link['icon']); ?>" aria-hidden="true"><?php echo iN_HelpSecure($badgeLetter($link['label'])); ?></span>
                <span><?php echo iN_HelpSecure($link['label']); ?></span>
              </a>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>
      </section>

      <footer class="maintenance-footer">
        <p><?php echo iN_HelpSecure(customLang('maintenance_footer_note')); ?></p>
        <p class="maintenance-retry-hint"><?php echo iN_HelpSecure(customLang('maintenance_retry_hint')); ?></p>
      </footer>
    </main>
    <?php
      $themeAssetBase = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme);
      $scriptVersion = iN_HelpSecure($version);
    ?>
    <script defer src="<?php echo $themeAssetBase; ?>/js/utils.js?v=<?php echo $scriptVersion; ?>"></script>
  </body>
</html>
