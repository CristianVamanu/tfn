<?php
$isRTLLocale = isset($isRTLLocale) ? (bool) $isRTLLocale : false;
$currentLocale = strtolower((string)($currentLang ?? 'eng'));
$pageCsrfToken = htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="<?php echo htmlspecialchars($currentLocale, ENT_QUOTES, 'UTF-8'); ?>" dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-theme="auto">
  <head>
    <title><?php echo customLang('forgot_title'); ?> – <?php echo iN_HelpSecure($siteName ?? ''); ?></title>
    <?php include "head/meta.php";?>
    <?php include "head/css.php";?>
    <?php include "head/js.php";?>
  </head>
  <body class="<?php echo $isRTLLocale ? 'rtl-locale' : ''; ?>" dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-logged-in="<?php echo (isset($loggedIn) && $loggedIn === '1') ? '1' : '0'; ?>">
    <input type="hidden" name="csrf_token" value="<?php echo $pageCsrfToken; ?>" />
    <section class="hero login-page wrapper">
      <div class="login-container">
        <a
          class="site-logo"
          href="<?php echo iN_HelpSecure($base_url ?? 'index', false); ?>"
          data-aos="fade-down"
          data-aos-easing="linear"
          data-aos-duration="650"
        >
          <?php echo iN_HelpSecure($siteName ?? ''); ?>
        </a>
        <div class="auth_language_switcher_wrapper">
          <?php
            $languageSwitcherContext = [
                'button_classes' => 'auth_language_switcher flex align_items',
                'label_class' => 'auth_language_switcher__label',
            ];
            include __DIR__ . '/partials/language_switcher.php';
            unset($languageSwitcherContext);
          ?>
        </div>

        <form
          class="login-form relative forgot-password-form"
          action="request/requests.php"
          method="POST"
          data-aos="zoom-in-up"
          data-aos-easing="linear"
          data-aos-duration="650"
          data-error-required="<?php echo iN_HelpSecure(customLang('please_fill_all_fields')); ?>"
          data-error-invalid="<?php echo iN_HelpSecure(customLang('forgot_error_invalid_email', 'Please provide a valid email address.')); ?>"
          data-error-limit="<?php echo iN_HelpSecure(customLang('forgot_error_rate_limit', 'Too many reset requests. Please try again later.')); ?>"
          data-error-unexpected="<?php echo iN_HelpSecure(customLang('unexpected_error_occurred', 'Unexpected error occurred.')); ?>"
          data-success-message="<?php echo iN_HelpSecure(customLang('forgot_success_message', 'If an account exists for that email, we\'ll send a reset link shortly.')); ?>"
          data-success="<?php echo iN_HelpSecure(customLang('forgot_success_message', 'If an account exists for that email, we\'ll send a reset link shortly.')); ?>"
          data-loading-text="<?php echo iN_HelpSecure(customLang('processing', 'Processing...')); ?>"
        >
          <input
            type="hidden"
            name="csrf_token"
            value="<?php echo $pageCsrfToken; ?>"
          />
          <input type="hidden" name="p" value="forgot_password_request" />

          <div class="login-form-not">
            <h2 class="marker-animation" data-ma_color="#FFD700">
              <?php echo customLang('forgot_title'); ?>
            </h2>
            <p>
              <?php echo customLang('forgot_description'); ?>
            </p>
          </div>

          <div class="form-container">
            <div class="form-input-wrapper">
              <label for="email"><?php echo customLang('forgot_email_label'); ?></label>
              <input
                type="email"
                id="email"
                name="email"
                class="form-input"
                placeholder="<?php echo customLang('forgot_email_placeholder'); ?>"
                required
              />
            </div>

            <div class="form-input-wrapper divid">
              <button type="submit" class="login-submit btn-hover"><?php echo customLang('forgot_send_link'); ?></button>
            </div>
          </div>

          <div
            id="forgotSuccess"
            class="login-alert login-alert--success none"
          ></div>

          <div
            id="forgotWarning"
            class="login-wraning none"
          ></div>

          <div class="form-not">
            <a href="login"><?php echo customLang('forgot_back_to_login'); ?></a>
          </div>

          <div class="form-divider">
            <span class="form-divider-text"><?php echo customLang('forgot_need_help'); ?></span>
          </div>

          <div class="form-not-register">
            <small><?php echo customLang('forgot_contact_support_html'); ?></small>
          </div>
        </form>
      </div>
    </section>
    <!---->
    <section class="footer footer-out" id="get-started">
      <!---->
      <div class="footer-small-print">
        <div class="copyright">
          <p class="white-text">© <?php echo iN_HelpSecure($siteName);?></p>
        </div>
        <?php include __DIR__ . '/partials/footer_links.php'; ?>
      </div>
      <!---->
    </section>
    <!---->
    <?php include "head/footer_js.php";?>
    <?php $forgotJsVersion = (int) @filemtime(__DIR__ . '/js/forgot-password.js'); ?>
    <script src="<?php echo $themePath; ?>/js/forgot-password.js?v=<?php echo iN_HelpSecure($forgotJsVersion); ?>" defer></script>
  </body>
</html>
