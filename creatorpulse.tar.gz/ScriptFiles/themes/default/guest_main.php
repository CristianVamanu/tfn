<?php
declare(strict_types=1);

$guestMode = true;
$layoutFileName = 'guest_contents.php';

require __DIR__ . '/main.php';
