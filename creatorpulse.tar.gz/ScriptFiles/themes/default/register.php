<?php
$providersConfig = $socialLoginConfig ?? social_login_get_config($siteData ?? []);
$enabledSocialProviders = [];
foreach (['google', 'facebook', 'twitter'] as $providerKey) {
    if (social_login_is_enabled($providerKey, $providersConfig)) {
        $enabledSocialProviders[] = $providerKey;
    }
}
$registerFlashError = social_login_consume_flash('error');
$registerFlashSuccess = social_login_consume_flash('success');
$isRTLLocale = isset($isRTLLocale) ? (bool) $isRTLLocale : false;
$currentLocale = strtolower((string)($currentLang ?? 'eng'));
$pageCsrfToken = htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8');
$countryDialCodes = [];
$countryDialCodesPath = dirname(__DIR__, 2) . '/includes/helpers/country_dial_codes.php';
if (is_file($countryDialCodesPath)) {
    include $countryDialCodesPath;
}
if (!isset($countryDialCodes) || !is_array($countryDialCodes)) {
    $countryDialCodes = [];
}
$registerAutoUsernameSetting = strtolower((string)($siteData['register_auto_username'] ?? 'open'));
$registerAutoUsernameEnabled = $registerAutoUsernameSetting !== 'close';
$registerPhoneEnabledSetting = strtolower((string)($siteData['register_phone_enabled'] ?? 'open'));
$registerPhoneEnabled = $registerPhoneEnabledSetting !== 'close';
$registerDialCodesRaw = '';
if (isset($lang) && is_array($lang) && isset($lang['register_phone_dial_codes_list'])) {
    $registerDialCodesRaw = trim((string)$lang['register_phone_dial_codes_list']);
}
if ($registerDialCodesRaw === '') {
    $registerDialCodesRaw = trim((string)($siteData['register_phone_dial_codes'] ?? ''));
}
if ($registerDialCodesRaw !== '') {
    $customDialCodes = [];
    $normalizeDial = static function (string $value): string {
        $digits = preg_replace('/\D/', '', $value);
        if (!is_string($digits)) {
            return '';
        }
        $digits = trim($digits);
        if ($digits === '' || strlen($digits) > 5) {
            return '';
        }
        return '+' . $digits;
    };
    $lines = preg_split('/\r\n|\r|\n/', $registerDialCodesRaw);
    foreach ($lines as $line) {
        $line = trim((string)$line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }
        $parts = preg_split('/[|,]/', $line, 2);
        if (!is_array($parts) || count($parts) < 2) {
            continue;
        }
        $left = trim((string)$parts[0]);
        $right = trim((string)$parts[1]);
        if ($left === '' || $right === '') {
            continue;
        }
        $leftDial = $normalizeDial($left);
        $rightDial = $normalizeDial($right);
        if ($leftDial !== '') {
            $customDialCodes[] = ['name' => $right, 'dial' => $leftDial];
            continue;
        }
        if ($rightDial !== '') {
            $customDialCodes[] = ['name' => $left, 'dial' => $rightDial];
        }
    }
    if ($customDialCodes !== []) {
        $countryDialCodes = $customDialCodes;
    }
}
$themePreference = null;
if (isset($_COOKIE['theme_preference'])) {
    $themePreference = strtolower((string) $_COOKIE['theme_preference']);
} elseif (isset($_COOKIE['landing_theme_mode'])) {
    $themePreference = strtolower((string) $_COOKIE['landing_theme_mode']);
}
if ($themePreference !== 'dark' && $themePreference !== 'light') {
    $themePreference = 'auto';
}
$initialThemeClass = $themePreference === 'dark'
    ? 'theme-dark'
    : ($themePreference === 'light' ? 'theme-light' : '');
$initialToggleMode = $themePreference === 'dark' ? 'dark' : 'light';
$initialToggleIcon = $initialToggleMode === 'dark' ? '☀️' : '🌙';
$initialToggleAria = $initialToggleMode === 'dark'
    ? customLang('theme_toggle_light', 'Switch to light mode')
    : customLang('theme_toggle_dark', 'Switch to dark mode');
?>
<!doctype html>
<html
  lang="<?php echo htmlspecialchars($currentLocale, ENT_QUOTES, 'UTF-8'); ?>"
  dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
  data-theme="<?php echo htmlspecialchars($themePreference, ENT_QUOTES, 'UTF-8'); ?>"
  class="<?php echo $initialThemeClass; ?>"
>
  <head>
    <title><?php echo iN_HelpSecure($siteTitle); ?></title>
    <?php include "head/meta.php";?>
    <?php include "head/css.php";?>
    <?php include "head/js.php";?>
  </head>
  <body
    class="<?php echo trim(($isRTLLocale ? 'rtl-locale ' : '') . $initialThemeClass); ?>"
    dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
    data-dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
    data-logged-in="<?php echo (isset($loggedIn) && $loggedIn === '1') ? '1' : '0'; ?>"
    data-theme="<?php echo htmlspecialchars($themePreference, ENT_QUOTES, 'UTF-8'); ?>"
  >
    <!---->
    <input type="hidden" name="csrf_token" value="<?php echo $pageCsrfToken; ?>" />

    <section class="hero login-page wrapper">
      <div class="login-container">
        <?php $hasMobileLogo = (!empty($siteMobileDarkLogo) || !empty($siteMobileWhiteLogo)); ?>
        <a
          class="site-logo<?php echo $hasMobileLogo ? ' has-mobile-logo' : ''; ?>"
          href="<?php echo iN_HelpSecure($base_url, false); ?>"
          data-aos="fade-down"
          data-aos-easing="linear"
          data-aos-duration="650"
        >
          <?php
            $alt = iN_HelpSecure($siteName ?? 'Logo');
            // Desktop variants
            if (!empty($siteDarkLogo)) {
              echo '<img class="logo-image logo--for-light logo--desktop" src="' . iN_HelpSecure($base_url . $siteDarkLogo) . '" alt="' . $alt . '" />';
            }
            if (!empty($siteWhiteLogo)) {
              echo '<img class="logo-image logo--for-dark logo--desktop" src="' . iN_HelpSecure($base_url . $siteWhiteLogo) . '" alt="' . $alt . '" />';
            }
            if (!empty($siteMobileDarkLogo)) {
              echo '<img class="logo-image logo--for-light logo--mobile" src="' . iN_HelpSecure($base_url . $siteMobileDarkLogo) . '" alt="' . $alt . '" />';
            }
            if (!empty($siteMobileWhiteLogo)) {
              echo '<img class="logo-image logo--for-dark logo--mobile" src="' . iN_HelpSecure($base_url . $siteMobileWhiteLogo) . '" alt="' . $alt . '" />';
            }
          ?>
        </a>
        <div class="auth_language_switcher_wrapper">
          <?php
            $languageSwitcherContext = [
                'button_classes' => 'auth_language_switcher flex align_items',
                'label_class' => 'auth_language_switcher__label',
            ];
            include __DIR__ . '/partials/language_switcher.php';
            unset($languageSwitcherContext);
          ?>
        </div>

        <form
          class="login-form register-form relative"
          method="POST"
          data-aos="zoom-in-up"
          data-aos-easing="linear"
          data-aos-duration="650"
          autocomplete="off"
          data-auto-username="<?php echo $registerAutoUsernameEnabled ? '1' : '0'; ?>"
          data-phone-enabled="<?php echo $registerPhoneEnabled ? '1' : '0'; ?>"
          data-error-required="<?php echo iN_HelpSecure(customLang('please_fill_all_fields')); ?>"
          data-error-username="<?php echo iN_HelpSecure(customLang('register_username_required') ?: customLang('please_fill_all_fields')); ?>"
          data-error-mismatch="<?php echo iN_HelpSecure(customLang('settings_security_error_password_mismatch')); ?>"
        >
          <input
            type="hidden"
            name="csrf_token"
            value="<?php echo $pageCsrfToken; ?>"
          />

          <div class="login-form-not">
            <h2 class="marker-animation" data-ma_color="#4F86F7">
              <?php echo customLang('register_title');?>
            </h2>
            <p>
              <?php echo customLang('register_description');?>
            </p>
          </div>

          <?php $initialRegisterSuccess = !empty($registerFlashSuccess) ? iN_HelpSecure($registerFlashSuccess) : ''; ?>

          <div class="register-form-container">
            <div class="form-register-box">
              <div class="form-input-wrapper">
                <label for="username"><?php echo customLang('register_username_label');?></label>
                <input
                  type="text"
                  id="username"
                  name="username"
                  class="form-input"
                  placeholder="<?php echo customLang('register_username_placeholder');?>"
                  <?php echo $registerAutoUsernameEnabled ? '' : 'required'; ?>
                />
                <?php if ($registerAutoUsernameEnabled): ?>
                  <span class="form-hint"><?php echo customLang('register_username_auto_hint'); ?></span>
                <?php endif; ?>
              </div>

              <div class="form-input-wrapper">
                <label for="email"><?php echo customLang('register_email_label');?></label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  class="form-input"
                  placeholder="<?php echo customLang('register_email_placeholder');?>"
                  required
                />
              </div>
            </div>
            <div class="form-register-box">
              <div class="form-input-wrapper">
                <label for="password"><?php echo customLang('register_password_label');?></label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  class="form-input"
                  placeholder="<?php echo customLang('register_password_placeholder');?>"
                  required
                />
              </div>

              <div class="form-input-wrapper">
                <label for="confirm_password"><?php echo customLang('register_confirm_password_label');?></label>
                <input
                  type="password"
                  id="confirm_password"
                  name="confirm_password"
                  class="form-input"
                  placeholder="<?php echo customLang('register_confirm_password_placeholder');?>"
                  required
                />
              </div>
            </div>
            <?php if ($registerPhoneEnabled): ?>
              <div class="form-register-box">
                <div class="form-input-wrapper">
                  <label for="phone_country"><?php echo customLang('register_phone_country_label'); ?></label>
                  <select id="phone_country" name="phone_country" class="form-input">
                    <option value=""><?php echo customLang('register_phone_country_placeholder'); ?></option>
                    <?php if (!empty($countryDialCodes) && is_array($countryDialCodes)): ?>
                      <?php foreach ($countryDialCodes as $dialRow): ?>
                        <?php
                          $dialCode = isset($dialRow['dial']) ? (string) $dialRow['dial'] : '';
                          $dialName = isset($dialRow['name']) ? (string) $dialRow['name'] : '';
                          if ($dialCode === '' || $dialName === '') { continue; }
                          $label = $dialName . ' (' . $dialCode . ')';
                        ?>
                        <option value="<?php echo iN_HelpSecure($dialCode); ?>"><?php echo iN_HelpSecure($label); ?></option>
                      <?php endforeach; ?>
                    <?php endif; ?>
                  </select>
                </div>
                <div class="form-input-wrapper">
                  <label for="phone_number"><?php echo customLang('register_phone_label'); ?></label>
                  <input
                    type="tel"
                    id="phone_number"
                    name="phone_number"
                    class="form-input"
                    placeholder="<?php echo customLang('register_phone_placeholder'); ?>"
                  />
                  <span class="form-hint"><?php echo customLang('register_phone_hint'); ?></span>
                </div>
              </div>
            <?php endif; ?>
            <div
              id="registerSuccess"
              class="login-alert login-alert--success<?php echo $initialRegisterSuccess === '' ? ' none' : ''; ?>"
            ><?php echo $initialRegisterSuccess; ?></div>
            <div
              id="registerWarning"
              class="login-wraning<?php echo empty($registerFlashError) ? ' none' : ''; ?>"
            ><?php echo !empty($registerFlashError) ? iN_HelpSecure($registerFlashError) : ''; ?></div>
            <div class="form-input-wrapper">
              <button
                type="submit"
                class="register-submit btn-hover"
                data-loading-text="<?php echo iN_HelpSecure(customLang('processing')); ?>"
              >
                <?php echo customLang('register_button');?>
              </button>
            </div>
          </div>

          <div class="form-not">
            <a href="login"
              ><?php echo customLang('register_already_have_account');?> <strong><?php echo customLang('register_signin_link');?></strong></a
            >
          </div>

          <?php if (!empty($enabledSocialProviders)): ?>
          <div class="form-divider">
            <span class="form-divider-text"><?php echo customLang('register_or_with'); ?></span>
          </div>

          <div class="social-login-wrapper">
            <?php if (in_array('google', $enabledSocialProviders, true)): ?>
            <a href="<?php echo iN_HelpSecure($base_url . 'auth/google'); ?>" class="social-btn google-btn btn-hover">
              <img src="<?php echo iN_HelpSecure($base_url . 'assets/icons/google.svg'); ?>" alt="Google" /> <?php echo customLang('register_google'); ?>
            </a>
            <?php endif; ?>
            <?php if (in_array('facebook', $enabledSocialProviders, true)): ?>
            <a href="<?php echo iN_HelpSecure($base_url . 'auth/facebook'); ?>" class="social-btn facebook-btn btn-hover">
              <img src="<?php echo iN_HelpSecure($base_url . 'assets/icons/facebook.svg'); ?>" alt="Facebook" /> <?php echo customLang('register_facebook'); ?>
            </a>
            <?php endif; ?>
            <?php if (in_array('twitter', $enabledSocialProviders, true)): ?>
            <a href="<?php echo iN_HelpSecure($base_url . 'auth/twitter'); ?>" class="social-btn twitter-btn btn-hover">
              <img src="<?php echo iN_HelpSecure($base_url . 'assets/icons/twitter.svg'); ?>" alt="Twitter" /> <?php echo customLang('register_twitter'); ?>
            </a>
            <?php endif; ?>
          </div>
          <?php endif; ?>

          <div class="form-not-register">
            <small>
              <?php echo customLang('register_terms_notice');?>
              <a href="<?php echo iN_HelpSecure(($base_url ?? '') . 'terms-of-use.php'); ?>"><?php echo customLang('register_terms_link');?></a>.
            </small>
          </div>
        </form>
      </div>
    </section>

    <!---->
    <!---->
    <section class="footer footer-out" id="get-started">
      <!---->
      <div class="footer-small-print">
        <div class="copyright">
          <p class="white-text"><?php echo customLang('footer_copyright'); ?></p>
        </div>
        <?php include __DIR__ . '/partials/footer_links.php'; ?>
      </div>
      <!---->
    </section>
    <!---->
    <button
      type="button"
      class="theme-toggle"
      data-theme-toggle=""
      data-storage-key="landing_theme_mode"
      data-label-light="<?php echo customLang('theme_toggle_light', 'Switch to light mode'); ?>"
      data-label-dark="<?php echo customLang('theme_toggle_dark', 'Switch to dark mode'); ?>"
      data-icon-light="☀️"
      data-icon-dark="🌙"
      aria-label="<?php echo iN_HelpSecure($initialToggleAria); ?>"
      data-mode="<?php echo $initialToggleMode; ?>"
    ><?php echo $initialToggleIcon; ?></button>
    <?php $welcomeJsVersion = (int) @filemtime(__DIR__ . '/js/welcome.js'); ?>
    <script defer src="<?php echo iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme); ?>/js/welcome.js?v=<?php echo $welcomeJsVersion; ?>"></script>
    <?php include "head/footer_js.php";?>
    <script src="<?php echo $themePath; ?>/js/register.js?v=<?php echo iN_HelpSecure($version);?>"></script>
  </body>
</html>
