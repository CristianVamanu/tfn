<?php
declare(strict_types=1);

if (!isset($base_url) || !isset($siteName)) {
    $inc = dirname(__DIR__, 2) . '/includes/inc.php';
    if (is_file($inc)) {
        include $inc;
    }
}

$requestedSlug = isset($_GET['page_slug']) ? (string) $_GET['page_slug'] : '';
$requestedSlug = trim($requestedSlug);
if ($requestedSlug === '' && isset($_SERVER['REQUEST_URI'])) {
    $requestedSlug = trim(basename(parse_url((string) $_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? ''), '/');
}

$preferredLang = isset($currentLang) ? strtolower((string) $currentLang) : 'eng';
if ($preferredLang === '') {
    $preferredLang = 'eng';
}
$isRTLLocale = isset($isRTLLocale) ? (bool) $isRTLLocale : false;
$currentLocale = $preferredLang;
$fallbackLangs = [];
if ($preferredLang !== 'eng') {
    $fallbackLangs[] = 'eng';
}
if ($preferredLang !== 'tr') {
    $fallbackLangs[] = 'tr';
}

$pageRow = null;
if ($requestedSlug !== '' && isset($RL) && method_exists($RL, 'RL_GetPageBySlug')) {
    $pageRow = $RL->RL_GetPageBySlug($requestedSlug, $preferredLang, $fallbackLangs);
}

if (!$pageRow) {
    http_response_code(404);
    $themePath = __DIR__;
    $notFound = $themePath . '/404.php';
    if (is_file($notFound)) {
        include $notFound;
    }
    return;
}

$pageTitle = (string) ($pageRow['title'] ?? '');
if ($pageTitle === '') {
    $pageTitle = ucfirst(str_replace('-', ' ', $requestedSlug));
}
$pageContent = (string) ($pageRow['content_html'] ?? '');
$siteTitle = isset($siteName) ? (string) $siteName : 'ReelsProject';
$fullTitle = $pageTitle !== '' ? ($pageTitle . ' – ' . $siteTitle) : $siteTitle;
$baseUrl = isset($base_url) ? rtrim((string) $base_url, '/') : '';
$pageCsrfToken = htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="<?php echo htmlspecialchars($currentLocale, ENT_QUOTES, 'UTF-8'); ?>" dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-theme="auto">
  <head>
    <meta charset="UTF-8" />
    <title><?php echo iN_HelpSecure($fullTitle); ?></title>
    <?php include __DIR__ . '/head/meta.php'; ?>
    <?php include __DIR__ . '/head/css.php'; ?>
    <?php include __DIR__ . '/head/js.php'; ?>
  </head>
  <body class="<?php echo $isRTLLocale ? 'rtl-locale' : ''; ?>" dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-logged-in="<?php echo (isset($loggedIn) && $loggedIn === '1') ? '1' : '0'; ?>">
    <input type="hidden" name="csrf_token" value="<?php echo $pageCsrfToken; ?>" />
    <header class="main-header" data-aos="fade-down">
      <div class="main-header-inner">
        <div class="container-nav">
          <?php
            $primaryNavLabel = customLang('nav_primary_label');
            if (!$primaryNavLabel) {
                $primaryNavLabel = 'Primary navigation';
            }
            $menuToggleLabel = customLang('nav_menu');
            if (!$menuToggleLabel) {
                $menuToggleLabel = 'Menu';
            }
            $menuToggleAria = customLang('nav_toggle_menu');
            if (!$menuToggleAria) {
                $menuToggleAria = customLang('nav_toggle_navigation') ?: 'Toggle navigation';
            }
          ?>
          <a class="site-logo" href="<?php echo $baseUrl !== '' ? iN_HelpSecure($baseUrl . '/') : '#'; ?>" aria-label="<?php echo iN_HelpSecure($siteTitle); ?>">
            <?php echo iN_HelpSecure($siteTitle); ?>
          </a>
          <button
            type="button"
            class="nav-toggle"
            data-nav-toggle
            aria-expanded="false"
            aria-controls="primary-navigation"
            aria-label="<?php echo iN_HelpSecure($menuToggleAria); ?>"
          >
            <span class="nav-toggle__box" aria-hidden="true">
              <span class="nav-toggle__line nav-toggle__line--top"></span>
              <span class="nav-toggle__line nav-toggle__line--middle"></span>
              <span class="nav-toggle__line nav-toggle__line--bottom"></span>
            </span>
            <span class="nav-toggle__label"><?php echo iN_HelpSecure($menuToggleLabel); ?></span>
          </button>
          <div class="nav-cluster" data-nav-panel>
            <nav id="primary-navigation" class="primary-navigation" aria-label="<?php echo iN_HelpSecure($primaryNavLabel); ?>">
              <a href="<?php echo $baseUrl !== '' ? iN_HelpSecure($baseUrl . '/') : '#'; ?>" class="btn-call"><?php echo customLang('nav_home') ?: 'Home'; ?></a>
            </nav>
            <div class="welcome_language_switcher_wrapper">
            <?php
              $languageSwitcherContext = [
                  'button_classes' => 'welcome_language_switcher flex align_items',
                  'label_class' => 'welcome_language_switcher__label',
              ];
              include __DIR__ . '/partials/language_switcher.php';
              unset($languageSwitcherContext);
            ?>
            </div>
          </div>
        </div>
      </div>
    </header>

    <section class="hero wrapper privacy-section">
      <div class="container">
        <h1 class="policy-title"><?php echo iN_HelpSecure($pageTitle); ?></h1>
        <div class="policy-content">
          <?php echo $pageContent !== '' ? $pageContent : '<p>' . iN_HelpSecure(customLang('ui_empty_content') ?: 'Content coming soon.') . '</p>'; ?>
        </div>
      </div>
    </section>

    <section class="footer footer-out" id="get-started">
      <div class="footer-small-print">
        <div class="copyright">
          <p class="white-text">© <?php echo date('Y'); ?> <?php echo iN_HelpSecure($siteTitle); ?></p>
        </div>
        <?php include __DIR__ . '/partials/footer_links.php'; ?>
      </div>
    </section>

    <?php include __DIR__ . '/head/footer_js.php'; ?>
  </body>
</html>
