<div class="site_header">
    <div class="mobile-template-host" data-mobile-template>
        <template id="close-icon-template">
            <?php echo render_icon('close', true); ?>
        </template>
    </div>
    <div class="site_header_container flex align_items_justify_content space_between">
        <?php
            $hasMobileLogo = (!empty($siteMobileDarkLogo) || !empty($siteMobileWhiteLogo));
            $isLoggedIn = isset($loggedIn) && $loggedIn === '1';
            $authBase = rtrim((string)($base_url ?? ''), '/');
            $loginHref = $authBase !== '' ? $authBase . '/login' : 'login';
            $registerHref = $authBase !== '' ? $authBase . '/register' : 'register';
            $walletTopupEnabledGlobal = isset($walletTopupEnabled)
                ? (bool) $walletTopupEnabled
                : (bool) ($GLOBALS['walletTopupEnabled'] ?? false);
            $walletTopupHasProviders = isset($walletTopupHasProviders)
                ? (bool) $walletTopupHasProviders
                : (bool) ($GLOBALS['walletTopupHasProviders'] ?? false);
            $isAdminUserGlobal = isset($isAdminUser)
                ? (bool) $isAdminUser
                : (bool) ($GLOBALS['isAdminUser'] ?? false);
            $walletTopupShortcutEnabled = ($walletTopupEnabledGlobal && $walletTopupHasProviders) || $isAdminUserGlobal;
        ?>
        <div class="header_left flex align_items">
            <button type="button" class="btn-icon mobile-nav-btn-left" aria-label="Open left menu">
              <?php echo render_icon('header_menu_left', true); ?>
            </button>
        <a class="flex flex_start<?php echo $hasMobileLogo ? ' has-mobile-logo' : ''; ?>" href="<?php echo iN_HelpSecure($base_url);?>" aria-label="<?php echo iN_HelpSecure($siteName ?? 'Home'); ?>">
            <?php
              $alt = iN_HelpSecure($siteName ?? 'Logo');
              // Desktop variants
              if (!empty($siteDarkLogo)) {
                echo '<img class="logo-image logo--for-light logo--desktop" src="' . iN_HelpSecure($base_url . $siteDarkLogo) . '" alt="' . $alt . '" />';
              }
              if (!empty($siteWhiteLogo)) {
                echo '<img class="logo-image logo--for-dark logo--desktop" src="' . iN_HelpSecure($base_url . $siteWhiteLogo) . '" alt="' . $alt . '" />';
              }
              if (!empty($siteMobileDarkLogo)) {
                echo '<img class="logo-image logo--for-light logo--mobile" src="' . iN_HelpSecure($base_url . $siteMobileDarkLogo) . '" alt="' . $alt . '" />';
              }
              if (!empty($siteMobileWhiteLogo)) {
                echo '<img class="logo-image logo--for-dark logo--mobile" src="' . iN_HelpSecure($base_url . $siteMobileWhiteLogo) . '" alt="' . $alt . '" />';
              }
            ?>
        </a>
        </div>
        <div class="header_search_wrapper flex align_items_justify_content">
            <div class="search_bar_container flex align_items" data-creator-only="0">
                <input type="text" name="user_search" class="search_input get_box" data-type="search" placeholder="<?php echo customLang('header_search_placeholder');?>">
                <div class="search-filter-dropdown">
                    <button type="button" class="search-filter-toggle" aria-haspopup="listbox" aria-expanded="false">
                        <span class="search-filter-label"><?php echo customLang('search_filter_all'); ?></span>
                        <span class="search-filter-caret" aria-hidden="true"></span>
                    </button>
                    <div class="search-filter-menu" role="listbox">
                        <button type="button" class="search-filter-option active" data-creator-only="0" role="option" aria-selected="true">
                            <?php echo customLang('search_filter_all'); ?>
                        </button>
                        <button type="button" class="search-filter-option" data-creator-only="1" role="option" aria-selected="false">
                            <?php echo customLang('search_filter_creators_only'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <!---->
        <div class="header_right flex align_items_justify_content">
            <div class="header_icon_group flex align_items">
                <?php if ($isLoggedIn): ?>
                    <!-- Create Icon -->
                    <div class="icon_button get_box" data-type="create_new">
                        <?php echo render_icon('create_post', true); ?>
                    </div>

                    <!-- Message Icon -->
                    <div class="icon_button has_badge get_box" data-type="new_messages">
                        <?php echo render_icon('send', true); ?>
                        <span class="badge_count"></span>
                    </div>

                    <!-- Mobile Search Toggle -->
                    <div class="icon_button mobile-search-toggle" role="button" aria-label="Search">
                        <?php echo render_icon('search_icon', true); ?>
                    </div>

                    <!-- Notification Icon -->
                    <div class="icon_button has_badge get_box" data-type="new_notifications">
                        <?php echo render_icon('notification', true); ?>
                        <span class="badge_count"></span>
                    </div>

                    <?php if ($walletTopupShortcutEnabled): ?>
                    <!-- Wallet top up shortcut -->
                    <div class="icon_button walletTopup" role="button" aria-label="<?php echo iN_HelpSecure(customLang('wallet_topup_button_label', 'Add funds')); ?>">
                        <?php echo render_icon('add_funds_icon', true); ?>
                    </div>
                    <?php endif; ?>

                    <!-- Profile Dropdown -->
                    <div class="user_dropdown flex align_items get_box" data-type="menu">
                        <?php
                          $__hdrName = ($dataUserFullName ?: ($dataUsername ?? 'user'));
                          $__hdrAlt  = sprintf(customLang('alt_avatar_of_user'), $__hdrName);
                        ?>
                        <img class="avatar" src="<?php echo iN_HelpSecure($defaultUserAvatar);?>" alt="<?php echo iN_HelpSecure($__hdrAlt); ?>">
                        <span class="username"><?php echo iN_HelpSecure($dataUserFullName);?></span>
                        <svg class="dropdown_arrow" viewBox="0 0 20 20"><path d="M6 8l4 4 4-4" fill="none" stroke="currentColor" stroke-width="2"/></svg>
                    </div>
                    <button type="button" class="btn-icon mobile-nav-btn-right" aria-label="Open right panel">
                      <?php echo render_icon('header_menu_right', true); ?>
                    </button>
                <?php else: ?>
                    <!-- Mobile Search Toggle -->
                    <div class="icon_button mobile-search-toggle" role="button" aria-label="Search">
                        <?php echo render_icon('search_icon', true); ?>
                    </div>
                    <div class="header_language_switcher_wrapper">
                        <?php
                            $languageSwitcherContext = [
                                'button_classes' => 'header_language_switcher flex align_items',
                                'label_class' => 'header_language_switcher__label',
                            ];
                            include __DIR__ . '/../partials/language_switcher.php';
                            unset($languageSwitcherContext);
                        ?>
                    </div>
                    <a class="header-auth-link header-auth-link--signin" href="<?php echo iN_HelpSecure($loginHref); ?>">
                        <?php echo customLang('sign_in'); ?>
                    </a>
                    <a class="header-auth-link header-auth-link--signup" href="<?php echo iN_HelpSecure($registerHref); ?>">
                        <?php echo customLang('sign_up'); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <!---->
    </div>
</div>
