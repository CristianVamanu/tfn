<?php
if (!isset($loggedIn) || $loggedIn !== '1') {
    $loginUrl = isset($base_url) ? rtrim((string) $base_url, '/') . '/login' : 'login';
    ?>
    <div class="click_box_wrapper settings-menu-dropdown">
        <div class="settings-menu-dropdown__profile-section">
            <a class="settings-menu-dropdown__profile-link" href="<?php echo iN_HelpSecure($loginUrl); ?>">
                <img class="settings-menu-dropdown__avatar" src="<?php echo iN_HelpSecure($defaultUserAvatar ?? ''); ?>" alt="<?php echo iN_HelpSecure(customLang('sign_in')); ?>">
                <div class="settings-menu-dropdown__identity">
                    <span class="settings-menu-dropdown__name"><?php echo customLang('sign_in'); ?></span>
                    <span class="settings-menu-dropdown__hint"><?php echo customLang('profile_view_link', 'Sign in to continue'); ?></span>
                </div>
            </a>
        </div>
    </div>
    <?php
    return;
}

$baseRoot = isset($base_url) ? rtrim((string) $base_url, '/') : '';
$profileUser = isset($dataUsername) ? (string) $dataUsername : '';
$profileHref = $baseRoot !== '' && $profileUser !== ''
    ? $baseRoot . '/profile/' . rawurlencode($profileUser)
    : ($baseRoot !== '' ? $baseRoot . '/settings' : '#');

$displayName = trim((string) ($dataUserFullName ?? $profileUser ?? ''));
if ($displayName === '') {
    $displayName = customLang('menu_profile');
}

$handle = $profileUser !== '' ? '@' . ltrim($profileUser, '@') : '';
$profileHint = customLang('profile_view_link', 'View profile');
$subtitleParts = [];
if ($handle !== '') { $subtitleParts[] = $handle; }
if ($profileHint !== '') { $subtitleParts[] = $profileHint; }
$profileSubtitle = implode(' - ', $subtitleParts);

$currencyCode = isset($globalCurCode) ? strtoupper((string) $globalCurCode) : (isset($currency) ? strtoupper((string) $currency) : 'USD');
$currencySymbol = '';
if (isset($currencies) && is_array($currencies) && isset($currencies[$currencyCode])) {
    $currencySymbol = (string) $currencies[$currencyCode];
} elseif (isset($currencys) && is_array($currencys) && isset($currencys[$currencyCode])) {
    $currencySymbol = (string) $currencys[$currencyCode];
}
if ($currencySymbol === '') {
    $currencySymbol = $currencyCode;
}

$normalizeAmount = static function ($value): float {
    if (is_numeric($value)) {
        return (float) $value;
    }
    if (is_string($value)) {
        $value = trim($value);
        if ($value === '') {
            return 0.0;
        }
        $normalized = preg_replace('/[^0-9,.-]/', '', $value);
        if ($normalized === '' || $normalized === '-' || $normalized === '.' || $normalized === ',') {
            return 0.0;
        }
        $commaPos = strrpos($normalized, ',');
        $dotPos = strrpos($normalized, '.');
        if ($commaPos !== false && $dotPos !== false) {
            if ($commaPos > $dotPos) {
                $normalized = str_replace('.', '', $normalized);
                $normalized = str_replace(',', '.', $normalized);
            } else {
                $normalized = str_replace(',', '', $normalized);
            }
        } elseif ($commaPos !== false) {
            $normalized = str_replace(',', '.', $normalized);
        }
        return is_numeric($normalized) ? (float) $normalized : 0.0;
    }
    return 0.0;
};

$formatMoney = static function ($value) use ($currencySymbol, $currencyCode): string {
    return dz_format_currency(
        (float) $value,
        $currencyCode,
        $currencySymbol,
        $GLOBALS['currency_format_settings'] ?? null
    );
};

$earningsAmount = isset($userEarned) ? $userEarned : 0.0;
$walletAmount = isset($userWallet) ? $userWallet : 0.0;
$earningsDisplay = $formatMoney($earningsAmount);
$walletDisplay = $formatMoney($walletAmount);

$settingsBase = $baseRoot !== '' ? $baseRoot . '/settings' : 'settings';
$currentTab = null;
if (isset($_GET['tab'])) {
    $maybeTab = strtolower(trim((string) $_GET['tab']));
    $allowedTabs = [
        'my_profile',
        'dashboard',
        'security',
        'password',
        'preferences',
        'blocked',
        'subscription',
        'subscription_fees',
        'super_thanks',
        'payments',
        'bank',
        'payout_methods',
        'creator_identity',
        'creator_plans',
        'creator_payout',
    ];
    if (in_array($maybeTab, $allowedTabs, true)) {
        $currentTab = $maybeTab;
    }
}

$toSettings = function (string $tab) use ($settingsBase) {
    return iN_HelpSecure($settingsBase . '?tab=' . rawurlencode($tab));
};

$menuSections = [
    [
        [
            'tab' => 'my_profile',
            'class' => 'my_profile',
            'icon' => 'profile',
            'label' => customLang('menu_profile'),
        ],
        [
            'tab' => 'dashboard',
            'class' => 'dashboard_user',
            'icon' => 'dashboard_user',
            'label' => customLang('menu_dashboard'),
        ],
    ],
    [
        [
            'tab' => 'security',
            'class' => 'security',
            'icon' => 'security',
            'label' => customLang('menu_security'),
        ],
        [
            'tab' => 'password',
            'class' => 'password',
            'icon' => 'password',
            'label' => customLang('menu_password'),
        ],
        [
            'tab' => 'preferences',
            'class' => 'preferences',
            'icon' => 'preferences',
            'label' => customLang('menu_preferences'),
        ],
        [
            'tab' => 'blocked',
            'class' => 'blocked',
            'icon' => 'block',
            'label' => customLang('menu_blocked_users'),
        ],
    ],
    [
        [
            'tab' => 'subscription',
            'class' => 'subscription',
            'icon' => 'creator_icon',
            'label' => customLang('nav_subscriptions'),
        ],
        [
            'tab' => 'subscription_fees',
            'class' => 'subscription_fees',
            'icon' => 'subscription_fees',
            'label' => customLang('subscription_fees'),
        ],
        [
            'tab' => 'creator_identity',
            'class' => 'creator_identity',
            'icon' => 'security',
            'label' => customLang('menu_creator_identity', 'Creator verification'),
        ],
        [
            'tab' => 'creator_plans',
            'class' => 'creator_plans',
            'icon' => 'creator_icon',
            'label' => customLang('menu_creator_plans', 'Creator plans'),
        ],
        [
            'tab' => 'super_thanks',
            'class' => 'super_thanks',
            'icon' => 'super_thanks',
            'label' => customLang('earnings'),
        ],
    ],
    [
        [
            'tab' => 'payments',
            'class' => 'payments',
            'icon' => 'payments',
            'label' => customLang('menu_payments'),
        ],
        [
            'tab' => 'bank',
            'class' => 'bank',
            'icon' => 'bank',
            'label' => customLang('menu_withdrawal'),
        ],
        [
            'tab' => 'payout_methods',
            'class' => 'payout_methods',
            'icon' => 'payout_methods',
            'label' => customLang('menu_payout_method'),
        ],
        [
            'tab' => 'creator_payout',
            'class' => 'creator_payout',
            'icon' => 'bank',
            'label' => customLang('menu_creator_payout', 'Creator payout'),
        ],
    ],
];

$activityBase = isset($base_url) ? rtrim((string) $base_url, '/') : '';
$activityLink = $activityBase !== '' ? $activityBase . '/activity' : 'activity';
$activityHref = iN_HelpSecure($activityLink, false, 0, false);
$languageSwitcherContext = [
    'button_classes' => 'settings_sidebar__menu_box full-width flex align_items transition',
    'label_class' => 'sidebar__menu_lang_label',
];

$logoutUrl = $baseRoot !== '' ? $baseRoot . '/logout.php' : 'logout.php';
$logoutHref = iN_HelpSecure($logoutUrl, false, 0, false);

$canAccessAdmin = false;
if (isset($userMode)) {
    $mode = strtolower(trim((string) $userMode));
    $canAccessAdmin = in_array($mode, ['admin', 'moderator'], true);
}
$adminUrl = $baseRoot !== '' ? $baseRoot . '/admin' : 'admin';
$creatorStatusRaw = isset($creatorStatus) ? strtolower((string) $creatorStatus) : 'none';
$creatorApproved = $creatorStatusRaw === 'approved';
$creatorRestrictedTabs = [
    'dashboard',
    'subscription',
    'subscription_fees',
    'payments',
    'creator_plans',
    'super_thanks',
    'bank',
    'payout_methods',
    'creator_payout',
];
$filteredMenuSections = [];
foreach ($menuSections as $entries) {
    $visibleEntries = [];
    foreach ($entries as $entry) {
        $tabKey = isset($entry['tab']) ? (string) $entry['tab'] : '';
        if (!$creatorApproved && in_array($tabKey, $creatorRestrictedTabs, true)) {
            continue;
        }
        $visibleEntries[] = $entry;
    }
    if (!empty($visibleEntries)) {
        $filteredMenuSections[] = $visibleEntries;
    }
}
if (!$creatorApproved && $currentTab !== null && in_array($currentTab, $creatorRestrictedTabs, true)) {
    $currentTab = null;
}
?>
<div class="click_box_wrapper settings-menu-dropdown">
    <div class="click_box_new_search_results settings-menu-dropdown__body">
        <div class="settings-menu-dropdown__profile-section">
            <a href="<?php echo iN_HelpSecure($profileHref); ?>" class="settings-menu-dropdown__profile-link">
                <img class="settings-menu-dropdown__avatar" src="<?php echo iN_HelpSecure($defaultUserAvatar ?? ''); ?>" alt="<?php echo iN_HelpSecure($displayName); ?>">
                <div class="settings-menu-dropdown__identity">
                    <span class="settings-menu-dropdown__name"><?php echo iN_HelpSecure($displayName); ?></span>
                    <span class="settings-menu-dropdown__hint"><?php echo iN_HelpSecure($profileSubtitle); ?></span>
                </div>
            </a>
            <div class="settings-menu-dropdown__cards">
                <?php if ($canAccessAdmin): ?>
                    <a href="<?php echo iN_HelpSecure($adminUrl); ?>" class="settings-menu-dropdown__card settings-menu-dropdown__card--action">
                        <span class="settings-menu-dropdown__card-icon"><?php echo render_icon('dashboard_user', true); ?></span>
                        <span class="settings-menu-dropdown__card-body">
                            <span class="settings-menu-dropdown__card-label"><?php echo iN_HelpSecure(customLang('menu_admin_panel', 'Admin panel')); ?></span>
                            <span class="settings-menu-dropdown__card-value"><?php echo iN_HelpSecure(customLang('menu_admin_panel_hint', 'Manage site')); ?></span>
                        </span>
                    </a>
                <?php endif; ?>
                <?php if ($creatorApproved): ?>
                    <div class="settings-menu-dropdown__card settings-menu-dropdown__card--metric" role="presentation">
                        <span class="settings-menu-dropdown__card-icon"><?php echo render_icon('super_thanks', true); ?></span>
                        <span class="settings-menu-dropdown__card-body">
                            <span class="settings-menu-dropdown__card-label"><?php echo iN_HelpSecure(customLang('earnings', 'Earnings')); ?></span>
                            <span class="settings-menu-dropdown__card-value"><?php echo iN_HelpSecure($earningsDisplay); ?></span>
                        </span>
                    </div>
                <?php endif; ?>
                <div class="settings-menu-dropdown__card settings-menu-dropdown__card--metric" role="presentation">
                    <span class="settings-menu-dropdown__card-icon"><?php echo render_icon('bank', true); ?></span>
                    <span class="settings-menu-dropdown__card-body">
                        <span class="settings-menu-dropdown__card-label"><?php echo iN_HelpSecure(customLang('wallet_topup_balance_label', 'Wallet balance')); ?></span>
                        <span class="settings-menu-dropdown__card-value"><?php echo iN_HelpSecure($walletDisplay); ?></span>
                    </span>
                </div>
            </div>
        </div>
        <div class="settings-menu-dropdown__divider"></div>
        <div class="settings-menu-dropdown__links">
            <?php foreach ($filteredMenuSections as $sectionIndex => $entries): ?>
                <?php if ($sectionIndex > 0): ?>
                    <div class="settings-menu-dropdown__divider"></div>
                <?php endif; ?>
                <?php foreach ($entries as $entry):
                    $href = $toSettings($entry['tab']);
                    $isCurrent = ($currentTab !== null && $currentTab === $entry['tab']);
                    $ariaCurrent = $isCurrent ? ' aria-current="page"' : '';
                    ?>
                    <a href="<?php echo $href; ?>"
                       class="settings_sidebar__menu_box full-width flex align_items transition <?php echo iN_HelpSecure($entry['class']); ?>"
                       <?php echo $ariaCurrent; ?>>
                        <span class="home_page flex align_items"><?php echo render_icon($entry['icon'], true); ?></span>
                        <?php echo iN_HelpSecure((string) $entry['label']); ?>
                    </a>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
        <div class="settings-menu-dropdown__divider"></div>
        <div class="settings-menu-dropdown__links settings-menu-dropdown__links--shortcuts">
            <a href="<?php echo $activityHref; ?>" class="settings_sidebar__menu_box full-width flex align_items transition activity">
                <span class="activity flex align_items"><?php echo render_icon('activity', true); ?></span>
                <?php echo customLang('menu_your_activity'); ?>
            </a>
            <button type="button" class="settings_sidebar__menu_box full-width flex align_items transition switch_apperange">
                <span class="switch_apperange flex align_items"><?php echo render_icon('switch_apperange', true); ?></span>
                <?php echo customLang('menu_switch_appearance'); ?>
            </button>
            <?php
                include __DIR__ . '/../partials/language_switcher.php';
                unset($languageSwitcherContext);
            ?>
            <a href="<?php echo $logoutHref; ?>" class="settings_sidebar__menu_box full-width flex align_items transition logout">
                <span class="logout flex align_items"><?php echo render_icon('logout', true); ?></span>
                <?php echo customLang('menu_logout'); ?>
            </a>
        </div>
    </div>
</div>
