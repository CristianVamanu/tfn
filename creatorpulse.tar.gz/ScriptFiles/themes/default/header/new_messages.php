<div class="click_box_wrapper">
    <?php
    if (!function_exists('cp_header_currency_symbol')) {
        function cp_header_currency_symbol(string $code): string
        {
            $code = strtoupper(trim($code));
            $map = [];
            if (isset($GLOBALS['currencies']) && is_array($GLOBALS['currencies'])) {
                $map = $GLOBALS['currencies'];
            } elseif (isset($GLOBALS['currencys']) && is_array($GLOBALS['currencys'])) {
                $map = $GLOBALS['currencys'];
            }

            return isset($map[$code]) ? (string) $map[$code] : $code;
        }
    }

    if (!function_exists('cp_header_format_tip_preview')) {
        function cp_header_format_tip_preview(string $message): string
        {
            $message = trim($message);
            if ($message === '' || !preg_match('/^(.*?\btip\s*:\s*)([0-9]+(?:[.,][0-9]+)?)\s+([A-Z]{3})\b(.*)$/iu', $message, $matches)) {
                return $message;
            }

            $prefix = (string) $matches[1];
            $amount = (float) str_replace(',', '.', (string) $matches[2]);
            $currencyCode = strtoupper((string) $matches[3]);
            $suffix = (string) $matches[4];
            $symbol = cp_header_currency_symbol($currencyCode);
            $settings = $GLOBALS['currency_format_settings'] ?? null;

            if (function_exists('dz_format_currency')) {
                $formatted = dz_format_currency($amount, $currencyCode, $symbol, $settings);
            } else {
                $formatted = $symbol . number_format($amount, 2, '.', '');
            }

            return $prefix . $formatted . $suffix;
        }
    }
    ?>
    <div class="click_box_header messages_dropdown_header">
        <span><?php echo customLang('new_messages'); ?></span>
        <a class="messages_dropdown_view_all" href="<?php echo iN_HelpSecure(rtrim((string)$base_url, '/') . '/messages'); ?>">
            <?php echo iN_HelpSecure(customLang('see_all', 'See all')); ?>
        </a>
    </div>
    <div class="arrow"></div>
    <div class="click_box_new_search_results _padding">
        <?php
        if ($loggedIn === '1') {
            $rows = $RL->RL_GetNewMessages($userID, 20, 0);
            if ($rows) {
                echo '<div class="click_box_recent_searches recent">';

                foreach ($rows as $conv) {
                    ?>
                    <?php
                    $profileUrl = $base_url . $conv['username'];
                    $avatarRel  = !empty($conv['avatar']) ? $conv['avatar'] : 'uploads/user_avatars/default.jpeg';
                    $avatarUrl  = storage_url($avatarRel);
                    $fullName   = !empty($conv['fullname']) ? $conv['fullname'] : $conv['username'];
                    $lastMsg    = cp_header_format_tip_preview((string) $conv['last_message']);
                    $partnerID = $conv['partner_id'] ?? null;

                    if (function_exists('mb_strimwidth')) {
                        $lastMsg = mb_strimwidth($lastMsg, 0, 90, '…', 'UTF-8');
                    } else {
                        $lastMsg = substr($lastMsg, 0, 90) . (strlen($lastMsg) > 90 ? '…' : '');
                    }

                    $lastTime = (int) $conv['last_time'];
                    $timeText = dz_relative_time_label($lastTime);
                    ?>
                    <div class="search-result-item getTheChat" data-id="<?php echo iN_HelpSecure($partnerID);?>">
                        <img
                            class="search-result-avatar"
                            src="<?php echo iN_HelpSecure($avatarUrl); ?>"
                            alt="<?php echo iN_HelpSecure($conv['username']); ?>"
                        >
                        <div class="search-result-info">
                            <div class="search-result-username">
                                <?php echo iN_HelpSecure($fullName); ?>
                                <?php if (!empty($conv['verified_status'])) { ?>
                                    <span class="verified-badge">
                                        <?php echo render_icon('verified', true); ?>
                                    </span>
                                <?php } ?>
                            </div>
                            <div class="search-result-fullname-message">
                                <span class="last-text"><?php echo iN_HelpSecure($lastMsg); ?></span>
                                <span class="last-time"><?php echo iN_HelpSecure($timeText); ?></span>
                            </div>
                        </div>
                    </div>
                    <?php
                }

                echo '</div>';
            } else {
                ?>
                <div class="no-seached-yet flex align_items_justify_content flexBoxColumn recent">
                    <?php echo render_icon('sparkles', false); ?>
                    <?php echo customLang('messages_empty_state_info'); ?>
                </div>
                <?php
            }
        }
        ?>
    </div>
</div>
