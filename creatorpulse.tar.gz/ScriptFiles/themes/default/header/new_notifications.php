<div class="click_box_wrapper">
    <div class="click_box_header">
        <?php echo customLang('header_notifications'); ?>
    </div>
    <div class="arrow"></div>
    <div class="click_box_new_search_results _padding"><!-- reuse existing styles -->
        <?php
        if ($loggedIn === '1') {
            // Fetch notifications instead of messages
            $rows = $RL->RL_GetMyNotifications($userID, 20, 0);
            $selfUsernameCache = '';
            if (method_exists($RL, 'RL_GetUserDetails')) {
                try {
                    $selfData = (array) $RL->RL_GetUserDetails((int) $userID);
                    $selfUsernameCache = (string) ($selfData['username'] ?? '');
                } catch (Throwable $__) {
                    $selfUsernameCache = '';
                }
            }
            if ($rows) {
                // --- Grouping helpers ---
                $now = time();

                $isWithinHours = static function (int $ts, int $hours) use ($now): bool {
                    return ($now - $ts) <= ($hours * 3600);
                };

                $isWithinDays = static function (int $ts, int $days) use ($now): bool {
                    return ($now - $ts) <= ($days * 24 * 3600);
                };

                // Buckets based on relative windows (not calendar boundaries)
                $groups = [
                    'new'   => [],  // <= 6 hours
                    'today' => [],  // >6h and <=24h
                    'week'  => [],  // >24h and <=7d
                    'older' => [],  // >7d
                ];

                foreach ($rows as $notif) {
                    $ts = (int) $notif['last_time'];

                    if ($isWithinHours($ts, 6)) {
                        $groups['new'][] = $notif;
                    } elseif ($isWithinHours($ts, 24)) {
                        $groups['today'][] = $notif;
                    } elseif ($isWithinDays($ts, 7)) {
                        $groups['week'][] = $notif;
                    } else {
                        $groups['older'][] = $notif;
                    }
                }

                $postOwnerCache = [];
                // Reusable item renderer
                $renderItem = function (array $notif) use ($base_url, $iconPath, &$postOwnerCache, $RL, $selfUsernameCache): string {
                    ob_start();

                    $profileBase = isset($base_url) ? rtrim((string) $base_url, '/') : '';
                    $notifUsername = (string) ($notif['username'] ?? '');
                    $profileUrl = $notifUsername !== '' ? $profileBase . '/profile/' . rawurlencode($notifUsername) : '#';
                    // Resolve target URL to post when available
                    $targetUrl = $profileUrl;
                    $extraData = [];
                    if (isset($notif['extra']) && is_array($notif['extra'])) {
                        $extraData = $notif['extra'];
                    } elseif (!empty($notif['extra']) && is_string($notif['extra'])) {
                        $decoded = json_decode($notif['extra'], true);
                        if (is_array($decoded)) {
                            $extraData = $decoded;
                        }
                    }
                    $postId = 0;
                    $type   = (string)($notif['type'] ?? '');
                    if (!empty($extraData['post_id'])) {
                        $postId = (int) $extraData['post_id'];
                    } elseif (!empty($notif['object_id']) && in_array($type, ['post_like','comment','comment_like','mention','post_purchase','post_approval','tip_payment','tip_payment_receipt'], true)) {
                        $postId = (int) $notif['object_id'];
                    } elseif (!empty($notif['parent_object_id']) && in_array($type, ['comment','comment_like','mention'], true)) {
                        $postId = (int) $notif['parent_object_id'];
                    }
                    $postOwnerUsername = '';
                    if ($postId > 0 && isset($RL) && method_exists($RL, 'RL_GetPostOwnerId')) {
                        if (!array_key_exists($postId, $postOwnerCache)) {
                            $ownerId = (int) $RL->RL_GetPostOwnerId($postId);
                            $ownerUsernameResolved = '';
                            if ($ownerId > 0 && method_exists($RL, 'RL_GetUserDetails')) {
                                try {
                                    $u = (array) $RL->RL_GetUserDetails($ownerId);
                                    $ownerUsernameResolved = (string) ($u['username'] ?? '');
                                } catch (Throwable $__) {
                                    $ownerUsernameResolved = '';
                                }
                            }
                            $postOwnerCache[$postId] = $ownerUsernameResolved;
                        }
                        $postOwnerUsername = (string) $postOwnerCache[$postId];
                    }
                    // Types that stay on profile
                    if ($postId > 0 && !in_array($type, ['follow','subscriber'], true)) {
                        $targetUserSlug = $postOwnerUsername !== '' ? $postOwnerUsername : '';
                        if ($targetUserSlug === '' && in_array($type, ['tip_payment','tip_payment_receipt','post_purchase','post_like','comment','comment_like','mention','post_approval'], true)) {
                            $targetUserSlug = $selfUsernameCache !== '' ? $selfUsernameCache : $notifUsername;
                        }
                        if ($targetUserSlug === '') {
                            $targetUserSlug = $notifUsername;
                        }
                        $targetUrl = $profileBase . '/posts/' . $postId . '/' . rawurlencode($targetUserSlug);
                    } else {
                        $targetUrl = $profileUrl;
                    }
                    $avatarField = $notif['avatar_last'] ?? $notif['avatar'] ?? '';
                    $avatarRel   = $avatarField !== '' ? $avatarField : 'uploads/user_avatars/default.jpeg';
                    $avatarUrl   = storage_url($avatarRel);
                    if ($avatarUrl === '' || stripos($avatarUrl, 'http') !== 0) {
                        $avatarUrl = storage_url('uploads/user_avatars/default.jpeg');
                    }

                    $lastMsg = trim((string) $notif['last_message']);
                    $previewLimit = 140;
                    if (function_exists('mb_strimwidth')) {
                        $lastMsg = mb_strimwidth($lastMsg, 0, $previewLimit, '…', 'UTF-8');
                    } else {
                        $lastMsg = substr($lastMsg, 0, $previewLimit) . (strlen($lastMsg) > $previewLimit ? '…' : '');
                    }

                    $lastTime = (int) $notif['last_time'];
                    $timeText = dz_relative_time_label($lastTime);
                    ?>
                    <a href="<?php echo iN_HelpSecure($targetUrl); ?>" class="search-result-item">
                        <img
                            class="search-result-avatar"
                            src="<?php echo iN_HelpSecure($avatarUrl); ?>"
                            alt="<?php echo iN_HelpSecure($notif['username']); ?>"
                        >
                        <div class="search-result-info">
                            <div class="search-result-username">
                                <?php echo iN_HelpSecure($notif['username']); ?>
                                <?php if (!empty($notif['verified_status'])) { ?>
                                    <span class="verified-badge">
                                        <?php echo render_icon('verified', true); ?>
                                    </span>
                                <?php } ?>
                            </div>
                            <div class="search-result-fullname-message">
                                <span class="last-text"><?php echo iN_HelpSecure($lastMsg); ?></span>
                                <span class="last-time"><?php echo iN_HelpSecure($timeText); ?></span>
                            </div>
                        </div>
                    </a>
                    <?php
                    return (string) ob_get_clean();
                };

                // Section renderer (title + list)
                $renderSection = function (string $title, array $items) use ($renderItem): void {
                    if (!$items) {
                        return;
                    }
                    echo '<div class="notif-section">';
                    echo '<div class="notif-section-title">' . iN_HelpSecure($title) . '</div>';
                    echo '<div class="click_box_recent_searches recent">';
                    foreach ($items as $it) {
                        echo $renderItem($it);
                    }
                    echo '</div>';
                    echo '</div>';
                };

                // Output: New / Today / This week / Older
                $renderSection(customLang('notifications_group_new') ?: 'New', $groups['new']);
                $renderSection(customLang('notifications_group_today') ?: 'Today', $groups['today']);
                $renderSection(customLang('notifications_group_this_week') ?: 'This week', $groups['week']);
                $renderSection(customLang('notifications_group_older') ?: 'Older', $groups['older']);
            } else {
                ?>
                <div class="no-seached-yet flex align_items_justify_content flexBoxColumn recent">
                    <?php echo render_icon('sparkles', false); ?>
                    <?php echo customLang('notifications_empty_state_info'); ?>
                </div>
                <?php
            }
        }
        ?>
    </div>
</div>
