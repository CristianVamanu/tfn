<?php
$liveEnabled = !empty($liveStreamingEnabled);
$imagePostsEnabled = !empty($enableImagePosts);
$videoPostsEnabled = !empty($enableVideoPosts);
$podcastPostsEnabled = isset($enablePodcastPosts) ? (bool) $enablePodcastPosts : true;
$adsEnabled   = !empty($enableAds);
$adsImageEnabled = $adsEnabled && $imagePostsEnabled;
$adsVideoEnabled = $adsEnabled && $videoPostsEnabled;
?>
<div class="click_box_wrapper">
    <div class="click_box_header">
        <?php echo customLang('createpost_create'); ?>
    </div>
    <div class="arrow"></div>
    <div class="click_box_new_search_results">
        <?php if ($imagePostsEnabled): ?>
        <div class="create_new_btn_box flex align_items new_item" data-pop="createImagePost">
            <?php echo render_icon('image', true); ?>
            <?php echo customLang('create_image_post'); ?>
        </div>
        <?php endif; ?>
        <?php if ($videoPostsEnabled): ?>
        <div class="create_new_btn_box flex align_items new_item" data-pop="createVideoPost">
            <?php echo render_icon('video', true); ?>
            <?php echo customLang('create_video_post'); ?>
        </div>
        <?php endif; ?>
        <?php if ($podcastPostsEnabled): ?>
        <div class="create_new_btn_box flex align_items new_item" data-pop="createPodcastPost">
            <?php echo render_icon('podcast', true); ?>
            <?php echo customLang('create_podcast_post', 'Create podcast'); ?>
        </div>
        <?php endif; ?>
        <?php if ($liveEnabled): ?>
        <div class="create_new_btn_box flex align_items new_item" data-pop="live_streaming">
            <?php echo render_icon('live', true); ?>
            <?php echo customLang('create_live'); ?>
        </div>
        <?php endif; ?>
        <?php if ($adsImageEnabled || $adsVideoEnabled): ?>
        <div class="create_new_btn_box flex align_items flexBoxColumn">
            <div class="flex full-width align_items">
                <?php echo render_icon('trending', true); ?>
                <?php echo customLang('create_advertisement'); ?>
            </div>
            <div class="create_ads_btns full-width flex align_items gap">
                <?php if ($adsImageEnabled): ?>
                <div class="create_ads full-width flex align_items new_item" data-pop="createAdsImage">Image Ads</div>
                <?php endif; ?>
                <?php if ($adsVideoEnabled): ?>
                <div class="create_ads full-width flex align_items new_item" data-pop="createAdsVideo">Video Ads</div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
