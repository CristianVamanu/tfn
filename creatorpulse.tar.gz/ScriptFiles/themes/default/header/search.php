<div class="click_box_wrapper">
    <div class="click_box_header">
        <?php echo customLang('search_search_title'); ?>
    </div>
    <div class="arrow"></div>
    <div class="click_box_results flex flexBoxColumn">
        <?php
        if ($loggedIn === '1') {
            $userID = (int) $userData['user_id'];
            $users  = $RL->RL_RecentSearches($userID);

            if ($users) {
                echo '<div class="box_title recent">' . customLang('search_recent') . '</div>';
                echo '<div class="click_box_recent_searches recent">';

                foreach ($users as $user) {
                    ?>
                    <?php
                        $avatarRel = isset($user['avatar']) ? (string)$user['avatar'] : '';
                        if (function_exists('storage_resolve_media_url')) {
                            $avatarUrl = storage_resolve_media_url($avatarRel, $base_url ?? '');
                        } else {
                            $avatarUrl = (string)($base_url ?? '') . ltrim($avatarRel, '/');
                        }
                    ?>
                    <a href="<?php echo iN_HelpSecure($base_url . $user['username']); ?>" class="search-result-item">
                        <img
                            class="search-result-avatar"
                            src="<?php echo iN_HelpSecure($avatarUrl); ?>"
                            alt="<?php echo iN_HelpSecure($user['username']); ?>"
                        >
                        <div class="search-result-info">
                            <div class="search-result-username">
                                <?php echo iN_HelpSecure($user['username']); ?>
                                <?php if (!empty($user['verified_status'])) { ?>
                                    <span class="verified-badge">
                                        <?php echo render_icon('verified', true); ?>
                                    </span>
                                <?php } ?>
                            </div>
                            <div class="search-result-fullname">
                                <?php echo iN_HelpSecure($user['fullname']); ?>
                            </div>
                        </div>
                    </a>
                    <?php
                }

                echo '</div>';
            } else {
                ?>
                <div class="no-seached-yet flex align_items_justify_content flexBoxColumn recent">
                    <?php echo render_icon('sparkles', false); ?>
                    <?php echo customLang('search_empty_state_info'); ?>
                </div>
                <?php
            }
        }
        ?>

        <div class="box_title s_r s_result">
            <?php echo customLang('search_results'); ?>
        </div>
        <div class="click_box_new_search_results s_r s_result"></div>
    </div>
</div>
