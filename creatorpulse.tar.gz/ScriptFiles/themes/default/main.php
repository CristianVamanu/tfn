<?php
declare(strict_types=1);

/**
 * Theme shell (main):
 * - Router = index.php (single entry)
 * - Only selects and includes a layout here.
 * - Bootstrap/DB/session: loaded via inc.php -> connect.php chain by index.php.
 */

$guestMode  = isset($guestMode) ? (bool) $guestMode : false;
$baseDir    = __DIR__;
$layoutsDir = $baseDir . '/layouts';

// Comes from index.php; fallback to feed
$layoutFileName = isset($layoutFileName) ? (string) $layoutFileName : 'contents.php';

// Security: load only allowed layouts
$allowedLayouts = [
    'contents.php',
    'singlePost.php',
    'explore.php',
    'images.php',
    'profile.php',
    'reels.php',
    'lives.php',
    'audio_rooms.php',
    'audio_room.php',
    'ebooks.php',
    'ebook_detail.php',
    'ebook_library.php',
    'messages.php',
    'podcasts.php',
    'our_creators.php',
    'bookmarks.php',
    'settings.php',
    'activity.php',
    'advertisements.php',
    'invoice.php',
    'premium.php',
    'live.php',
    'contact.php'
];
if (empty($enableVideoPosts)) {
    $allowedLayouts = array_values(array_diff($allowedLayouts, ['reels.php']));
}
if (empty($enableImagePosts)) {
    $allowedLayouts = array_values(array_diff($allowedLayouts, ['images.php']));
}
if (empty($enableAds)) {
    $allowedLayouts = array_values(array_diff($allowedLayouts, ['advertisements.php']));
}

if ($guestMode) {
    $allowedLayouts[] = 'guest_contents.php';
}

if (!in_array($layoutFileName, $allowedLayouts, true)) {
    $layoutFileName = 'contents.php';
}

$layoutFile = $layoutsDir . '/' . $layoutFileName;

if (!is_file($layoutFile)) {
    http_response_code(500);
    exit('Layout not found.');
}
$__isLoggedIn = isset($loggedIn) && $loggedIn === '1';
$_maintenanceStatus = strtolower((string)($GLOBALS['__MAINTENANCE_MODE_STATUS'] ?? 'off'));
$_isMaintenanceLive = $_maintenanceStatus === 'on';
$isRTLLocale = isset($isRTLLocale) ? (bool) $isRTLLocale : false;
$__langAttr = strtolower((string)($currentLang ?? 'eng'));
$__dirAttr = $isRTLLocale ? 'rtl' : 'ltr';
$__bodyClasses = [];
if ($_isMaintenanceLive) { $__bodyClasses[] = 'maintenance-mode-live'; }
if ($layoutFileName === 'contact.php') { $__bodyClasses[] = 'layout-contact'; }
if ($isRTLLocale) { $__bodyClasses[] = 'rtl-locale'; }
$__themePreference = null;
if (isset($_COOKIE['theme_preference'])) {
    $__themePreference = strtolower((string) $_COOKIE['theme_preference']);
} elseif (isset($_COOKIE['landing_theme_mode'])) {
    $__themePreference = strtolower((string) $_COOKIE['landing_theme_mode']);
}
if ($__themePreference !== 'dark' && $__themePreference !== 'light') {
    $__themePreference = 'auto';
}
$__initialThemeClass = $__themePreference === 'dark'
    ? 'theme-dark'
    : ($__themePreference === 'light' ? 'theme-light' : '');
if ($__initialThemeClass !== '') {
    $__bodyClasses[] = $__initialThemeClass;
}
$__bodyClassAttr = implode(' ', $__bodyClasses);
$__authBase = rtrim((string)($base_url ?? ''), '/');
$__loginUrl = $__authBase !== '' ? $__authBase . '/login' : 'login';
$__registerUrl = $__authBase !== '' ? $__authBase . '/register' : 'register';
$__loginLabel = customLang('sign_in');
$__registerLabel = customLang('sign_up');
$__authMessage = customLang('login_required');
$__closeLabel = customLang('close');
$__liveStreamingEnabled = isset($liveStreamingEnabled) ? (bool)$liveStreamingEnabled : true;
$__liveChatEnabled = isset($liveChatEnabled) ? (bool)$liveChatEnabled : true;
$__liveTitlePrefixAttr = isset($liveTitlePrefix) ? (string)$liveTitlePrefix : '';
?>
<!doctype html>
<html
  lang="<?php echo htmlspecialchars($__langAttr, ENT_QUOTES, 'UTF-8'); ?>"
  dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
  data-theme="<?php echo htmlspecialchars($__themePreference, ENT_QUOTES, 'UTF-8'); ?>"
  <?php if ($__initialThemeClass !== ''): ?>
  class="<?php echo htmlspecialchars($__initialThemeClass, ENT_QUOTES, 'UTF-8'); ?>"
  <?php endif; ?>
>
  <head>
    <meta charset="UTF-8" />
    <title><?php echo iN_HelpSecure($siteTitle); ?></title>
    <?php include $baseDir . "/head/meta.php"; ?>
    <?php include $baseDir . "/head/gtm.php"; ?>
    <?php include $baseDir . "/head/css.php"; ?>
    <?php include $baseDir . "/head/js.php"; ?>
  </head>
<body
  class="<?php echo iN_HelpSecure($__bodyClassAttr); ?>"
  dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
  data-dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
  data-logged-in="<?php echo $__isLoggedIn ? '1' : '0'; ?>"
  data-maintenance-status="<?php echo iN_HelpSecure($_maintenanceStatus); ?>"
  data-layout="<?php echo iN_HelpSecure(basename($layoutFileName, '.php')); ?>"
  data-live-stream-enabled="<?php echo $__liveStreamingEnabled ? '1' : '0'; ?>"
  data-live-chat-enabled="<?php echo $__liveChatEnabled ? '1' : '0'; ?>"
  data-live-title-prefix="<?php echo iN_HelpSecure($__liveTitlePrefixAttr, false); ?>"
  data-theme="<?php echo htmlspecialchars($__themePreference, ENT_QUOTES, 'UTF-8'); ?>"
>
<?php
  $__gtmRender = isset($gtmTrackingEnabled) ? (bool) $gtmTrackingEnabled : (bool) ($GLOBALS['gtmTrackingEnabled'] ?? false);
  $__gtmId = isset($gtmId) ? (string) $gtmId : (string) ($GLOBALS['gtmId'] ?? '');
  $__gtmId = strtoupper(trim($__gtmId));
?>
<?php if ($__gtmRender && $__gtmId !== '' && preg_match('/^GTM-[A-Z0-9]+$/', $__gtmId)): ?>
  <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo iN_HelpSecure($__gtmId); ?>" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<?php endif; ?>
  <input
      type="hidden"
      name="csrf_token"
      value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>"
  />
  <div class="site_container flex flexBoxColumn">
    <?php
        include_once $baseDir . "/header/header.php";
        include_once $baseDir . "/partials/site_announcement.php";
        echo '<div class="sidebar_container flex relative sidebar_scroll">';
        include_once $baseDir . "/menu/left_menu.php";
        include_once $layoutFile;
        echo '</div>';
        include_once $baseDir . "/head/footer_js.php";
    ?>
  </div>
  <div id="popup-root">

  </div>
<?php if (!$__isLoggedIn): ?>
  <template id="auth-required-popup-template">
    <div class="popUp-container flex align_items auth-required-container" role="presentation">
      <div class="auth-required-popup popup-wrapper" role="dialog" aria-modal="true" aria-live="assertive">
        <button type="button" class="auth-required-close flex align_items close_pop" aria-label="<?php echo iN_HelpSecure($__closeLabel); ?>">
          <?php echo render_icon('close', true); ?>
        </button>
        <div class="auth-required-content flex align_items flexBoxColumn">
          <h2 class="auth-required-title"><?php echo iN_HelpSecure($__authMessage); ?></h2>
          <div class="auth-required-actions flex align_items_justify_content">
            <a class="auth-required-btn auth-required-btn--login" href="<?php echo iN_HelpSecure($__loginUrl); ?>"><?php echo iN_HelpSecure($__loginLabel); ?></a>
            <a class="auth-required-btn auth-required-btn--register" href="<?php echo iN_HelpSecure($__registerUrl); ?>"><?php echo iN_HelpSecure($__registerLabel); ?></a>
          </div>
        </div>
      </div>
    </div>
  </template>
<?php endif; ?>
<?php if (!$guestMode && $__isLoggedIn): ?>
<!---->
<div class="messages_box_wrapper">
  <!---->
  <div class="messages_box_container transition">
    <div class="messages_icon_title_latest_chat flex align_items gap full-width">
      <div class="messages_icon flex align_items getChatList"><?php echo render_icon('messages', true); ?></div>
      <div class="message_title flex align_items getChatList"><?php echo customLang('menu_messages');?></div>
      <div class="latest_chat_avatars flex align_items" id="latest_chat_avatars">
        <?php
          // Use existing conversation list provider (same as chat_list.php)
          if (isset($loggedIn) && $loggedIn === '1' && isset($userID) && (int)$userID > 0 && isset($RL) && method_exists($RL, 'RL_GetNewMessages')) {
            try {
              $list = $RL->RL_GetNewMessages((int)$userID, 3, 0);
              foreach ($list as $conv) {
                $pid = (int)($conv['partner_id'] ?? 0);
                if ($pid <= 0) { continue; }
                $nm  = htmlspecialchars((string)($conv['fullname'] ?? $conv['username'] ?? ''), ENT_QUOTES, 'UTF-8');
                $av  = (string)($conv['avatar'] ?? 'uploads/user_avatars/default.jpeg');
                $avatarUrl = storage_url($av);
                $src = iN_HelpSecure($avatarUrl);
                echo '<div class="avatar_ring getTheChat" data-id="' . $pid . '" title="' . $nm . '"><img src="' . $src . '" alt="' . $nm . '" /></div>';
              }
            } catch (\Throwable $__) {}
          }
        ?>
      </div>
    </div>
  </div>
  <!---->
  <!---->
  <div class="current_message_box flex align_items flexBoxColumn none">
    <div class="chat_list_box flex align_items flexBoxColumn">
    </div>
  </div>
  <!---->
</div>
<!---->
<?php endif; ?>
  <?php
    $gdprMessageFallback = $siteName
        ? ($siteName . ' uses cookies as an essential part of our website.')
        : 'We use cookies as an essential part of our website.';
    $gdprBannerMessage = customLang('gdpr_banner_message', $gdprMessageFallback);
    $gdprConsentActionsLabel = customLang('gdpr_consent_actions_label', 'Cookie consent options');
    $gdprAllowLabel = customLang('gdpr_allow_all', 'Allow all');
    $gdprRejectLabel = customLang('gdpr_reject_all', 'Reject all');
    $gdprManageLabel = customLang('gdpr_manage_settings', 'Manage settings');
    $gdprSettingsTitle = customLang('gdpr_settings_title', 'Cookie settings');
    $gdprSettingsIntro = customLang(
        'gdpr_settings_intro',
        'Choose which cookies you want to allow. Essential cookies are always enabled.'
    );
    $gdprNecessaryLabel = customLang('gdpr_settings_necessary', 'Essential cookies');
    $gdprNecessaryHint = customLang('gdpr_settings_necessary_hint', 'Always on');
    $gdprAnalyticsLabel = customLang('gdpr_settings_analytics', 'Analytics cookies');
    $gdprMarketingLabel = customLang('gdpr_settings_marketing', 'Marketing cookies');
    $gdprSaveLabel = customLang('gdpr_save_preferences', 'Save preferences');
  ?>
  <div class="gdpr-banner" data-gdpr-banner hidden role="region" aria-live="polite" aria-atomic="true">
    <div class="gdpr-banner__inner">
      <div class="gdpr-banner__icon" aria-hidden="true">
        <?php echo render_icon('security', true); ?>
      </div>
      <div class="gdpr-banner__content">
        <p class="gdpr-banner__message"><?php echo iN_HelpSecure($gdprBannerMessage); ?></p>
        <div class="gdpr-banner__actions" role="group" aria-label="<?php echo iN_HelpSecure($gdprConsentActionsLabel); ?>">
          <button type="button" class="gdpr-banner__btn gdpr-banner__btn--primary" data-gdpr-accept>
            <?php echo iN_HelpSecure($gdprAllowLabel); ?>
          </button>
          <button type="button" class="gdpr-banner__btn gdpr-banner__btn--ghost" data-gdpr-manage aria-haspopup="dialog">
            <?php echo iN_HelpSecure($gdprManageLabel); ?>
          </button>
        </div>
      </div>
    </div>
  </div>
  <div class="gdpr-settings" data-gdpr-settings hidden>
    <div class="gdpr-settings__backdrop" data-gdpr-settings-close></div>
    <div class="gdpr-settings__panel" role="dialog" aria-modal="true" aria-labelledby="gdpr-settings-title" aria-describedby="gdpr-settings-intro">
      <div class="gdpr-settings__header">
        <h2 class="gdpr-settings__title" id="gdpr-settings-title">
          <?php echo iN_HelpSecure($gdprSettingsTitle); ?>
        </h2>
        <button type="button" class="gdpr-settings__close" data-gdpr-settings-close>
          <?php echo iN_HelpSecure(customLang('close', 'Close')); ?>
        </button>
      </div>
      <p class="gdpr-settings__intro" id="gdpr-settings-intro">
        <?php echo iN_HelpSecure($gdprSettingsIntro); ?>
      </p>
      <div class="gdpr-settings__options" role="group" aria-label="<?php echo iN_HelpSecure($gdprSettingsTitle); ?>">
        <label class="gdpr-settings__option">
          <span class="gdpr-settings__option-text">
            <span class="gdpr-settings__option-title"><?php echo iN_HelpSecure($gdprNecessaryLabel); ?></span>
            <span class="gdpr-settings__option-hint"><?php echo iN_HelpSecure($gdprNecessaryHint); ?></span>
          </span>
          <input type="checkbox" class="gdpr-settings__toggle" data-gdpr-toggle="necessary" checked disabled aria-disabled="true">
        </label>
        <label class="gdpr-settings__option">
          <span class="gdpr-settings__option-text">
            <span class="gdpr-settings__option-title"><?php echo iN_HelpSecure($gdprAnalyticsLabel); ?></span>
          </span>
          <input type="checkbox" class="gdpr-settings__toggle" data-gdpr-toggle="analytics">
        </label>
        <label class="gdpr-settings__option">
          <span class="gdpr-settings__option-text">
            <span class="gdpr-settings__option-title"><?php echo iN_HelpSecure($gdprMarketingLabel); ?></span>
          </span>
          <input type="checkbox" class="gdpr-settings__toggle" data-gdpr-toggle="marketing">
        </label>
      </div>
      <div class="gdpr-settings__actions" role="group" aria-label="<?php echo iN_HelpSecure($gdprConsentActionsLabel); ?>">
        <button type="button" class="gdpr-banner__btn gdpr-banner__btn--ghost" data-gdpr-reject>
          <?php echo iN_HelpSecure($gdprRejectLabel); ?>
        </button>
        <button type="button" class="gdpr-banner__btn gdpr-banner__btn--primary" data-gdpr-save>
          <?php echo iN_HelpSecure($gdprSaveLabel); ?>
        </button>
      </div>
    </div>
  </div>
</body>
</html>
