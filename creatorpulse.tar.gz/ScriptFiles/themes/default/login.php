<?php
$providersConfig = $socialLoginConfig ?? social_login_get_config($siteData ?? []);
$enabledSocialProviders = [];
foreach (['google', 'facebook', 'twitter'] as $providerKey) {
    if (social_login_is_enabled($providerKey, $providersConfig)) {
        $enabledSocialProviders[] = $providerKey;
    }
}
$loginFlashError = social_login_consume_flash('error');
$loginFlashSuccess = social_login_consume_flash('success');
$isRTLLocale = isset($isRTLLocale) ? (bool) $isRTLLocale : false;
$currentLocale = strtolower((string)($currentLang ?? 'eng'));
$pageCsrfToken = htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8');
$themePreference = null;
if (isset($_COOKIE['theme_preference'])) {
    $themePreference = strtolower((string) $_COOKIE['theme_preference']);
} elseif (isset($_COOKIE['landing_theme_mode'])) {
    $themePreference = strtolower((string) $_COOKIE['landing_theme_mode']);
}
if ($themePreference !== 'dark' && $themePreference !== 'light') {
    $themePreference = 'auto';
}
$initialThemeClass = $themePreference === 'dark'
    ? 'theme-dark'
    : ($themePreference === 'light' ? 'theme-light' : '');
$initialToggleMode = $themePreference === 'dark' ? 'dark' : 'light';
$initialToggleIcon = $initialToggleMode === 'dark' ? '☀️' : '🌙';
$initialToggleAria = $initialToggleMode === 'dark'
    ? customLang('theme_toggle_light', 'Switch to light mode')
    : customLang('theme_toggle_dark', 'Switch to dark mode');
?>
<!doctype html>
<html
  lang="<?php echo htmlspecialchars($currentLocale, ENT_QUOTES, 'UTF-8'); ?>"
  dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
  data-theme="<?php echo htmlspecialchars($themePreference, ENT_QUOTES, 'UTF-8'); ?>"
  class="<?php echo $initialThemeClass; ?>"
>
  <head>
    <title><?php echo iN_HelpSecure($siteTitle); ?></title>
    <?php include "head/meta.php";?>
    <?php include "head/css.php";?>
    <?php include "head/js.php";?>
  </head>
  <body
    class="<?php echo trim(($isRTLLocale ? 'rtl-locale ' : '') . $initialThemeClass); ?>"
    dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
    data-dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
    data-logged-in="<?php echo (isset($loggedIn) && $loggedIn === '1') ? '1' : '0'; ?>"
    data-theme="<?php echo htmlspecialchars($themePreference, ENT_QUOTES, 'UTF-8'); ?>"
  >
    <!---->
    <input type="hidden" name="csrf_token" value="<?php echo $pageCsrfToken; ?>" />

    <section class="hero login-page wrapper">
      <div class="login-container">
        <?php $hasMobileLogo = (!empty($siteMobileDarkLogo) || !empty($siteMobileWhiteLogo)); ?>
        <a class="site-logo<?php echo $hasMobileLogo ? ' has-mobile-logo' : ''; ?>" href="<?php echo iN_HelpSecure($base_url, false); ?>" aria-label="<?php echo iN_HelpSecure($siteName ?? 'Home'); ?>">
          <?php
            $alt = iN_HelpSecure($siteName ?? 'Logo');
            // Desktop variants
            if (!empty($siteDarkLogo)) {
              echo '<img class="logo-image logo--for-light logo--desktop" src="' . iN_HelpSecure($base_url . $siteDarkLogo) . '" alt="' . $alt . '" />';
            }
            if (!empty($siteWhiteLogo)) {
              echo '<img class="logo-image logo--for-dark logo--desktop" src="' . iN_HelpSecure($base_url . $siteWhiteLogo) . '" alt="' . $alt . '" />';
            }
            if (!empty($siteMobileDarkLogo)) {
              echo '<img class="logo-image logo--for-light logo--mobile" src="' . iN_HelpSecure($base_url . $siteMobileDarkLogo) . '" alt="' . $alt . '" />';
            }
            if (!empty($siteMobileWhiteLogo)) {
              echo '<img class="logo-image logo--for-dark logo--mobile" src="' . iN_HelpSecure($base_url . $siteMobileWhiteLogo) . '" alt="' . $alt . '" />';
            }
          ?>
        </a>
        <div class="auth_language_switcher_wrapper">
          <?php
            $languageSwitcherContext = [
                'button_classes' => 'auth_language_switcher flex align_items',
                'label_class' => 'auth_language_switcher__label',
            ];
            include __DIR__ . '/partials/language_switcher.php';
            unset($languageSwitcherContext);
          ?>
        </div>

        <form
          class="login-form relative"
          method="POST"
          data-aos="zoom-in-up"
          data-aos-easing="linear"
          data-aos-duration="650"
          autocomplete="off"
          data-error-required="<?php echo iN_HelpSecure(customLang('please_fill_all_fields')); ?>"
          data-error-unexpected="<?php echo iN_HelpSecure(customLang('unexpected_error_occurred', 'Unexpected error occurred.')); ?>"
          data-error-login-failed="<?php echo iN_HelpSecure(customLang('login_failed', 'Unable to sign in.')); ?>"
          data-loading-message="<?php echo iN_HelpSecure(customLang('login_loading_text', 'Logging in please wait...')); ?>"
          data-success-message="<?php echo iN_HelpSecure(customLang('login_success_redirect', 'Login successful, redirecting to your feed...')); ?>"
        >
          <div class="loading-container absolute none">
            <div class="loader">
              <div></div>
              <div></div>
              <div></div>
              <div></div>
              <div></div>
              <div></div>
              <div></div>
              <div></div>
              <div></div>
              <div></div>
              <div></div>
              <div></div>
            </div>
            <p class="loading-text">
              <?php echo iN_HelpSecure(customLang('login_loading_text', 'Logging in please wait...')); ?>
            </p>
          </div>
          <input
            type="hidden"
            name="csrf_token"
            value="<?php echo $pageCsrfToken; ?>"
          />

          <div class="login-form-not">
            <h2 class="marker-animation" data-ma_color="#43E97B">
              <?php echo customLang('login_title');?>
            </h2>
            <p>
              <?php echo customLang('login_description');?>
            </p>
          </div>

          <?php $initialLoginSuccess = !empty($loginFlashSuccess) ? iN_HelpSecure($loginFlashSuccess) : ''; ?>

          <div class="form-container">
            <div class="form-input-wrapper">
              <label for="username"><?php echo customLang('login_username_label');?></label>
              <input
                type="text"
                id="username"
                name="my_username"
                class="form-input"
                autocomplete="new-username"
                placeholder="<?php echo customLang('login_username_placeholder');?>"
                required
              />
            </div>

            <div class="form-input-wrapper">
              <label for="password"><?php echo customLang('login_password_label');?></label>
              <input
                type="password"
                id="password"
                name="lg_password"
                class="form-input"
                autocomplete="new-password"
                placeholder="<?php echo customLang('login_password_placeholder');?>"
                required
              />
            </div>

            <div class="form-input-wrapper">
              <button
                type="submit"
                class="login-submit btn-hover"
                data-loading-text="<?php echo iN_HelpSecure(customLang('processing', 'Processing...')); ?>"
              >
                <?php echo customLang('login_button');?>
              </button>
            </div>
          </div>
          <div
            id="loginSuccess"
            class="login-alert login-alert--success<?php echo $initialLoginSuccess === '' ? ' none' : ''; ?>"
          ><?php echo $initialLoginSuccess; ?></div>
          <div
            id="loginWarning"
            class="login-wraning<?php echo empty($loginFlashError) ? ' none' : ''; ?>"
          ><?php echo !empty($loginFlashError) ? iN_HelpSecure($loginFlashError) : ''; ?></div>
          <div class="login-action-links">
            <div class="form-not">
              <a href="forgot_password"><?php echo customLang('login_forgot_password_link', 'Forgot password?'); ?></a>
            </div>
            <div class="form-not">
              <a href="<?php echo iN_HelpSecure((isset($base_url) ? rtrim((string)$base_url, '/') . '/support' : 'support'), false); ?>" rel="noopener noreferrer"><?php echo customLang('login_help');?></a>
            </div>
          </div>

          <?php if (!empty($enabledSocialProviders)): ?>
          <div class="form-divider">
            <span class="form-divider-text"><?php echo customLang('login_or_with'); ?></span>
          </div>

          <div class="social-login-wrapper">
            <?php if (in_array('google', $enabledSocialProviders, true)): ?>
            <a href="<?php echo iN_HelpSecure($base_url . 'auth/google'); ?>" class="social-btn google-btn btn-hover">
              <img src="<?php echo iN_HelpSecure($base_url . 'assets/icons/google.svg'); ?>" alt="Google" /> <?php echo customLang('login_google'); ?>
            </a>
            <?php endif; ?>
            <?php if (in_array('facebook', $enabledSocialProviders, true)): ?>
            <a href="<?php echo iN_HelpSecure($base_url . 'auth/facebook'); ?>" class="social-btn facebook-btn btn-hover">
              <img src="<?php echo iN_HelpSecure($base_url . 'assets/icons/facebook.svg'); ?>" alt="Facebook" /> <?php echo customLang('login_facebook'); ?>
            </a>
            <?php endif; ?>
            <?php if (in_array('twitter', $enabledSocialProviders, true)): ?>
            <a href="<?php echo iN_HelpSecure($base_url . 'auth/twitter'); ?>" class="social-btn twitter-btn btn-hover">
              <img src="<?php echo iN_HelpSecure($base_url . 'assets/icons/twitter.svg'); ?>" alt="Twitter" /> <?php echo customLang('login_twitter'); ?>
            </a>
            <?php endif; ?>
          </div>
          <?php endif; ?>

          <div class="form-not-register">
            <span
              ><?php echo customLang('login_no_account');?>
              <a href="register"><strong><?php echo customLang('login_register_now');?></strong></a></span
            >
          </div>

          <div class="form-not-register">
            <small
              ><strong><?php echo customLang('login_terms_notice');?>
              <a href="terms-of-use.php"><?php echo customLang('login_terms_link');?></a>.</small
            >
          </div>
        </form>
      </div>
    </section>

    <!---->
    <!---->
    <section class="footer footer-out" id="get-started">
      <!---->
      <div class="footer-small-print">
        <div class="copyright">
          <p class="white-text"><?php echo customLang('footer_copyright'); ?></p>
        </div>
        <?php include __DIR__ . '/partials/footer_links.php'; ?>
      </div>
      <!---->
    </section>
    <!---->
    <button
      type="button"
      class="theme-toggle"
      data-theme-toggle=""
      data-storage-key="landing_theme_mode"
      data-label-light="<?php echo customLang('theme_toggle_light', 'Switch to light mode'); ?>"
      data-label-dark="<?php echo customLang('theme_toggle_dark', 'Switch to dark mode'); ?>"
      data-icon-light="☀️"
      data-icon-dark="🌙"
      aria-label="<?php echo iN_HelpSecure($initialToggleAria); ?>"
      data-mode="<?php echo $initialToggleMode; ?>"
    ><?php echo $initialToggleIcon; ?></button>
    <?php $welcomeJsVersion = (int) @filemtime(__DIR__ . '/js/welcome.js'); ?>
    <script defer src="<?php echo iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme); ?>/js/welcome.js?v=<?php echo $welcomeJsVersion; ?>"></script>
    <?php include "head/footer_js.php";?>
    <script defer src="<?php echo $themePath; ?>/js/login.js?v=<?php echo iN_HelpSecure($version);?>"></script>
  </body>
</html>
