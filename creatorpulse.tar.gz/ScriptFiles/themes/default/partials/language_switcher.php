<?php
declare(strict_types=1);

$languageSwitcherContext = isset($languageSwitcherContext) && is_array($languageSwitcherContext)
    ? $languageSwitcherContext
    : [];

$currentLanguageCode = isset($languageSwitcherContext['current'])
    ? (string) $languageSwitcherContext['current']
    : (string) ($currentLang ?? 'eng');
$baseUrlForSwitcher = isset($languageSwitcherContext['base_url'])
    ? (string) $languageSwitcherContext['base_url']
    : (string) ($base_url ?? '');

$switcherData = buildLanguageSwitcherData($currentLanguageCode, $baseUrlForSwitcher);
$languageOptionsJson = iN_HelpSecure(
    json_encode(array_values($switcherData['options']), JSON_UNESCAPED_UNICODE),
    false,
    0,
    false
);
$languageLabelsJson = iN_HelpSecure(
    json_encode((array) ($switcherData['labels'] ?? []), JSON_UNESCAPED_UNICODE),
    false,
    0,
    false
);
$languageCurrentAttr = iN_HelpSecure($switcherData['current'], false);
$languageEndpointAttr = iN_HelpSecure((string) ($languageSwitcherContext['endpoint'] ?? $switcherData['endpoint']), false, 0, false);
$languageWaitMessageAttr = iN_HelpSecure(
    (string) ($languageSwitcherContext['wait_message'] ?? $switcherData['wait_message']),
    false
);
$languageTitleAttr = iN_HelpSecure((string) ($languageSwitcherContext['title'] ?? $switcherData['title']), false);
$languageLabelText = iN_HelpSecure((string) ($languageSwitcherContext['label'] ?? $switcherData['label']), false);
$languageStaticText = iN_HelpSecure((string) ($switcherData['current_label'] ?? 'English'), false);

$buttonClasses = ['language_switcher'];
$contextButtonClasses = $languageSwitcherContext['button_classes'] ?? '';
if (is_array($contextButtonClasses)) {
    foreach ($contextButtonClasses as $className) {
        $trimmed = trim((string) $className);
        if ($trimmed !== '') {
            $buttonClasses[] = $trimmed;
        }
    }
} elseif (is_string($contextButtonClasses) && $contextButtonClasses !== '') {
    foreach (preg_split('/\s+/', $contextButtonClasses) as $className) {
        $trimmed = trim($className);
        if ($trimmed !== '') {
            $buttonClasses[] = $trimmed;
        }
    }
}
$buttonClasses = array_values(array_unique($buttonClasses));
$buttonClassAttr = htmlspecialchars(implode(' ', $buttonClasses), ENT_QUOTES | ENT_HTML5, 'UTF-8');

$labelClass = 'language_switcher_label';
if (!empty($languageSwitcherContext['label_class'])) {
    $labelClass = trim((string) $languageSwitcherContext['label_class']);
}
$labelClassAttr = htmlspecialchars($labelClass, ENT_QUOTES | ENT_HTML5, 'UTF-8');

$showLanguageText = true;
if (array_key_exists('show_label_text', $languageSwitcherContext)) {
    $showLanguageText = (bool) $languageSwitcherContext['show_label_text'];
}
?>
<button
    type="button"
    class="<?php echo $buttonClassAttr; ?>"
    data-language-options="<?php echo $languageOptionsJson; ?>"
    data-language-labels="<?php echo $languageLabelsJson; ?>"
    data-language-current="<?php echo $languageCurrentAttr; ?>"
    data-language-endpoint="<?php echo $languageEndpointAttr; ?>"
    data-language-wait-message="<?php echo $languageWaitMessageAttr; ?>"
    data-language-title="<?php echo $languageTitleAttr; ?>"
>
    <span class="language_switcher_icon flex align_items"><?php echo render_icon('world', true); ?></span>
<?php if ($showLanguageText): ?>
    <span class="language_switcher_text"><?php echo $languageStaticText; ?></span>
<?php endif; ?>
<span class="<?php echo $labelClassAttr; ?>" data-language-label><?php echo $languageLabelText; ?></span>
</button>
