<?php
declare(strict_types=1);

if (!isset($siteAnnouncement) || !is_array($siteAnnouncement) || $siteAnnouncement === null) {
    return;
}

$announcementId = isset($siteAnnouncement['id']) ? (int)$siteAnnouncement['id'] : 0;
$announcementMessageRaw = isset($siteAnnouncement['message']) ? (string)$siteAnnouncement['message'] : '';
if (function_exists('sanitizeAnnouncementContent')) {
    $announcementMessage = sanitizeAnnouncementContent($announcementMessageRaw);
    $announcementMessage = html_entity_decode($announcementMessage, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $announcementMessagePlain = trim(strip_tags($announcementMessage));
} else {
    $announcementMessage = nl2br(htmlspecialchars(trim($announcementMessageRaw), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    $announcementMessagePlain = trim(strip_tags($announcementMessage));
}
$announcementClosable = !empty($siteAnnouncement['allow_close']);
$announcementTitle = isset($siteAnnouncement['title']) ? trim((string)$siteAnnouncement['title']) : '';
$announcementCtaLabel = isset($siteAnnouncement['cta_label']) ? trim((string)$siteAnnouncement['cta_label']) : '';
$announcementCtaUrl = isset($siteAnnouncement['cta_url']) ? trim((string)$siteAnnouncement['cta_url']) : '';
$announcementImagePath = isset($siteAnnouncement['image_path']) ? trim((string)$siteAnnouncement['image_path']) : '';

if ($announcementId <= 0 || $announcementMessagePlain === '') {
    return;
}

$announcementLabel = customLang('announcement_label') ?: 'Announcement';
$closeLabel = customLang('announcement_close_button') ?: 'Tamam';
$messageHtml = $announcementMessage;
$titleHtml = $announcementTitle !== '' ? iN_HelpSecure($announcementTitle, false) : '';
$ctaLabelHtml = $announcementCtaLabel !== '' ? iN_HelpSecure($announcementCtaLabel, false) : '';
$ctaUrlHtml = $announcementCtaUrl !== '' ? iN_HelpSecure($announcementCtaUrl, false) : '';
$base = isset($base_url) ? rtrim((string)$base_url, '/') : '';
$announcementImageUrl = '';
if ($announcementImagePath !== '') {
    $announcementImageUrl = $base !== '' ? $base . '/' . ltrim($announcementImagePath, '/') : '/' . ltrim($announcementImagePath, '/');
    $announcementImageUrl = iN_HelpSecure($announcementImageUrl, false);
}
?>
<div
  class="site-announcement"
  data-site-announcement="true"
  data-announcement-id="<?php echo $announcementId; ?>"
  data-allow-close="<?php echo $announcementClosable ? '1' : '0'; ?>"
  role="presentation"
>
  <div class="site-announcement__overlay"></div>
  <div
    class="site-announcement__dialog"
    role="alertdialog"
    aria-modal="true"
    aria-labelledby="site-announcement-heading-<?php echo $announcementId; ?>"
  >
    <?php if ($announcementImageUrl !== ''): ?>
      <div class="site-announcement__media">
        <img src="<?php echo $announcementImageUrl; ?>" alt="<?php echo iN_HelpSecure($announcementLabel, false); ?>">
      </div>
    <?php endif; ?>

    <div class="site-announcement__content">
      <?php if ($titleHtml !== ''): ?>
        <h2 id="site-announcement-heading-<?php echo $announcementId; ?>" class="site-announcement__title"><?php echo $titleHtml; ?></h2>
      <?php else: ?>
        <h2 id="site-announcement-heading-<?php echo $announcementId; ?>" class="site-announcement__title"><?php echo iN_HelpSecure($announcementLabel, false); ?></h2>
      <?php endif; ?>

      <div class="site-announcement__body" aria-live="polite"><?php echo $messageHtml; ?></div>
    </div>

    <?php if ($announcementCtaUrl !== '' || $announcementClosable): ?>
      <footer class="site-announcement__footer">
        <?php if ($announcementCtaUrl !== '' && $ctaLabelHtml !== ''): ?>
          <a
            class="site-announcement__cta"
            href="<?php echo $ctaUrlHtml; ?>"
            target="_blank"
            rel="noopener"
          ><?php echo $ctaLabelHtml; ?></a>
        <?php endif; ?>
        <?php if ($announcementClosable): ?>
          <button
            type="button"
            class="site-announcement__close"
            data-announcement-dismiss
          ><?php echo iN_HelpSecure($closeLabel, false); ?></button>
        <?php endif; ?>
      </footer>
    <?php endif; ?>
  </div>
</div>
