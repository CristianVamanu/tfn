<?php
declare(strict_types=1);

global $RL, $base_url, $currentLang;

$footerTheme = 'welcome_default';
$footerLang = isset($currentLang) ? strtolower((string) $currentLang) : 'eng';
if ($footerLang === '') { $footerLang = 'eng'; }
$footerFallbackLangs = [];
if ($footerLang !== 'eng') { $footerFallbackLangs[] = 'eng'; }
if ($footerLang !== 'tr') { $footerFallbackLangs[] = 'tr'; }

$defaultLinks = [
    [
        'href' => 'login',
        'target' => '_self',
        'rel' => '',
        'label' => (string) customLang('footer_link_login'),
    ],
    [
        'href' => 'terms-of-use',
        'target' => '_self',
        'rel' => '',
        'label' => (string) customLang('footer_link_terms'),
    ],
    [
        'href' => 'privacy-policy',
        'target' => '_self',
        'rel' => '',
        'label' => (string) customLang('footer_link_privacy'),
    ],
];

$basePrefix = isset($base_url) ? rtrim((string) $base_url, '/') : '';
$finalLinks = [];
$seen = [];

$pushLink = static function (string $href, string $label, string $target = '_self', string $rel = '') use (&$finalLinks, &$seen, $basePrefix): void {
    if ($label === '' || $href === '') {
        return;
    }
    $target = strtolower($target);
    if (!in_array($target, ['_self', '_blank', '_parent', '_top'], true)) {
        $target = '_self';
    }
    $rel = trim($rel);
    $isAbsolute = (bool) preg_match('/^https?:\/\//i', $href);
    $resolvedHref = $isAbsolute ? $href : (($basePrefix !== '' ? $basePrefix : '') . '/' . ltrim($href, '/'));
    $key = strtolower($resolvedHref);
    if (isset($seen[$key])) {
        return;
    }
    $seen[$key] = true;
    $finalLinks[] = [
        'href' => $resolvedHref,
        'target' => $target,
        'rel' => $rel,
        'label' => $label,
    ];
};

if (isset($RL) && method_exists($RL, 'RL_GetActivePagesForLang')) {
    $dynamicPages = $RL->RL_GetActivePagesForLang($footerLang, $footerFallbackLangs);
    if (is_array($dynamicPages) && $dynamicPages) {
        foreach ($dynamicPages as $pageRow) {
            $slug = trim((string) ($pageRow['slug'] ?? ''));
            $title = trim((string) ($pageRow['title'] ?? ''));
            if ($slug === '' || $title === '') {
                continue;
            }
            $pushLink(rawurlencode($slug), $title);
        }
    }
}

if (!$finalLinks) {
    foreach ($defaultLinks as $entry) {
        $pushLink((string) ($entry['href'] ?? ''), trim((string) ($entry['label'] ?? '')), (string) ($entry['target'] ?? '_self'), (string) ($entry['rel'] ?? ''));
    }
}

$footerLinksData = $finalLinks;
?>
<div class="footer-links">
  <?php foreach ($footerLinksData as $link):
    $href = iN_HelpSecure($link['href'], false, 0, false);
    $target = strtolower((string) ($link['target'] ?? '_self'));
    if (!in_array($target, ['_self','_blank','_parent','_top'], true)) { $target = '_self'; }
    $relAttr = trim((string) ($link['rel'] ?? ''));
    $labelHtml = iN_HelpSecure($link['label'], false);
  ?>
    <a href="<?php echo $href; ?>" class="footer-link" target="<?php echo $target; ?>"<?php echo $relAttr !== '' ? ' rel="' . iN_HelpSecure($relAttr, false) . '"' : ''; ?>><?php echo $labelHtml; ?></a>
  <?php endforeach; ?>
</div>
