<?php
declare(strict_types=1);

if (!isset($ad) || !is_array($ad)) {
    return;
}

$adId = (int) ($ad['ad_id'] ?? 0);
if ($adId <= 0) {
    return;
}

$title       = trim((string) ($ad['title'] ?? ''));
$description = trim((string) ($ad['description'] ?? ''));
$mediaType   = strtolower((string) ($ad['media_type'] ?? 'image'));
$mediaUrls   = isset($ad['media_urls']) && is_array($ad['media_urls']) ? $ad['media_urls'] : [];
$primaryMedia = (string) ($ad['primary_media_url'] ?? ($mediaUrls[0] ?? ''));
$videoThumb  = (string) ($ad['video_thumb_url'] ?? '');
$profileUrl  = (string) ($ad['profile_url'] ?? '#');
$targetUrl   = (string) ($ad['target_url'] ?? $profileUrl);
$ownerName   = trim((string) ($ad['owner_fullname'] ?? ($ad['user_fullname'] ?? '')));
$username    = trim((string) ($ad['owner_username'] ?? ($ad['username'] ?? '')));
$ctaLabel    = customLang('ads_visit_advertiser', 'Visit advertiser');
$badgeLabel  = customLang('ads_sponsored', 'Sponsored');
$altText     = $ownerName !== '' ? $ownerName : ($username !== '' ? ('@' . $username) : $title);
if ($altText === '') {
    $altText = 'Advertisement';
}

$targetAttr = ' target="_blank" rel="nofollow noopener"';
?>
<div class="post_ ads-sponsored full-width relative flex align_items flexBoxColumn" data-ad-id="<?php echo $adId; ?>" data-ad-placement="instream">
    <div class="ads-frame flex flexBoxColumn">
        <div class="ads-frame__badge"><?php echo iN_HelpSecure($badgeLabel); ?></div>
        <div class="ads-frame__media">
            <?php if ($mediaType === 'video' && $primaryMedia !== ''): ?>
                <video class="ads-frame__video" src="<?php echo iN_HelpSecure($primaryMedia); ?>" poster="<?php echo iN_HelpSecure($videoThumb ?: $primaryMedia); ?>" controls playsinline preload="metadata" data-ad-clickable="1"></video>
            <?php elseif ($primaryMedia !== ''): ?>
                <a class="ads-frame__link" href="<?php echo iN_HelpSecure($targetUrl); ?>"<?php echo $targetAttr; ?> data-ad-clickable="1">
                    <img class="ads-frame__image" src="<?php echo iN_HelpSecure($primaryMedia); ?>" alt="<?php echo iN_HelpSecure($altText); ?>" loading="lazy">
                </a>
            <?php endif; ?>
        </div>
        <div class="ads-frame__body flex flexBoxColumn">
            <?php if ($title !== ''): ?>
                <a class="ads-frame__title" href="<?php echo iN_HelpSecure($targetUrl); ?>"<?php echo $targetAttr; ?> data-ad-clickable="1"><?php echo iN_HelpSecure($title); ?></a>
            <?php endif; ?>
            <?php if ($description !== ''): ?>
                <p class="ads-frame__description"><?php echo nl2br(iN_HelpSecure($description)); ?></p>
            <?php endif; ?>
            <a class="ads-frame__cta" href="<?php echo iN_HelpSecure($targetUrl); ?>"<?php echo $targetAttr; ?> data-ad-clickable="1"><?php echo iN_HelpSecure($ctaLabel); ?></a>
        </div>
    </div>
</div>
