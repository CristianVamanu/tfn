<!---->
<div class="chat_list_header flex full-width align_items">
  <div class="chat_list_text flex align_items"><?php echo customLang('chat_messages_title'); ?></div>
  <div class="back-prev back-to"><?php echo render_icon('close', false); ?></div>
</div>
<div class="arrow"></div>
<!---->
<!---->
<div class="chat_list_container full-width flex align_items flexBoxColumn relative sidebar_scroll">
  <div class="chat_list_wrapper flex align_items full-width flexBoxColumn">
    <!---->
    <?php
        if ($loggedIn === '1') {
            $rows = $RL->RL_GetNewMessages($userID, 20, 0);
            if ($rows) {
                echo '<div class="click_box_recent_searches recent">';

                foreach ($rows as $conv) {
                    ?>
                    <?php
                    $profileUrl = $base_url . $conv['username'];
                    $partnerID = $conv['partner_id'] ?? null;
                    $avatarRel  = !empty($conv['avatar']) ? $conv['avatar'] : 'uploads/user_avatars/default.jpeg';
                    $avatarUrl  = storage_url($avatarRel);
                    $fullName   = !empty($conv['fullname']) ? $conv['fullname'] : $conv['username'];
                    $lastMsg    = trim((string) $conv['last_message']);
                    $lastFile   = isset($conv['last_file']) ? trim((string)$conv['last_file']) : '';

                    if (function_exists('mb_strimwidth')) {
                        $lastMsg = mb_strimwidth($lastMsg, 0, 90, '…', 'UTF-8');
                    } else {
                        $lastMsg = substr($lastMsg, 0, 90) . (strlen($lastMsg) > 90 ? '…' : '');
                    }

                    $lastTime = (int) $conv['last_time'];
                    $timeText = dz_relative_time_label($lastTime);

                    // Build last-preview (text or icon+label for image/video/link)
                    $previewHtml = '';
                    $isUrl = function(string $s): bool { return (bool) preg_match('~https?://\S+~i', $s); };
                    $label = function(string $key) use ($iconPath): string {
                        $map = [
                            'image' => ['images.svg','Image'],
                            'video' => ['video.svg','Video'],
                            'link'  => ['link.svg','Link'],
                        ];
                        $p = $map[$key] ?? null; if (!$p) return '';
                        return '<span class="last-text flex align_items gap"><span class="icon flex align_items gap">' . renderVerifiedBadge($iconPath . $p[0], true) . '</span> ' . htmlspecialchars($p[1], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</span>';
                    };

                    if ($lastFile !== '') {
                        $ext = strtolower(pathinfo($lastFile, PATHINFO_EXTENSION));
                        if (preg_match('/^post:\\d+$/i', $lastFile)) {
                            $previewHtml = $label('link');
                        } elseif (in_array($ext, ['jpg','jpeg','png','gif','webp'], true)) {
                            $previewHtml = $label('image');
                        } elseif (in_array($ext, ['mp4','mov','m4v','webm','avi'], true)) {
                            $previewHtml = $label('video');
                        }
                    }
                    if ($previewHtml === '') {
                        if ($lastMsg !== '' && $isUrl($lastMsg)) { $previewHtml = $label('link'); }
                    }
                    ?>
                    <div class="search-result-item getTheChat" data-id="<?php echo iN_HelpSecure($partnerID);?>">
                        <img
                            class="search-result-avatar"
                            src="<?php echo iN_HelpSecure($avatarUrl); ?>"
                            alt="<?php echo iN_HelpSecure($conv['username']); ?>"
                        >
                        <div class="search-result-info">
                            <div class="search-result-username">
                                <?php echo iN_HelpSecure($fullName); ?>
                                <?php if (!empty($conv['verified_status'])) { ?>
                                    <span class="verified-badge">
                                        <?php echo render_icon('verified', true); ?>
                                    </span>
                                <?php } ?>
                            </div>
                            <div class="search-result-fullname-message">
                                <?php if ($previewHtml !== '') { echo $previewHtml; } else { ?>
                                  <span class="last-text"><?php echo iN_HelpSecure($lastMsg); ?></span>
                                <?php } ?>
                                <span class="last-time"><?php echo iN_HelpSecure($timeText); ?></span>
                            </div>
                        </div>
                      </div>
                    <?php
                }

                echo '</div>';
            } else {
                ?>
                <div class="no-seached-yet flex align_items_justify_content flexBoxColumn recent">
                    <?php echo render_icon('sparkles', false); ?>
                    <?php echo customLang('messages_empty_state_info'); ?>
                </div>
                <?php
            }
        }
        ?>
    <!---->
  </div>
</div>
<!---->
