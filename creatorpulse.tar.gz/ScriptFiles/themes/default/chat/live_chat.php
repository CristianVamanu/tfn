<?php
// Header data
$pair  = $RL->RL_GetConversationUsers($userID, $chatUserID);
$self  = $pair['self'] ?? null;
$other = $pair['other'] ?? null;

$otherAvatarRel = (string) ($other['avatar'] ?? 'uploads/user_avatars/default.jpeg');
$otherAvatarUrl = storage_url($otherAvatarRel);
$chatCanTip = strtolower((string)($other['creator_status'] ?? '')) === 'approved';
$chatCanPaidMedia = strtolower((string)($self['creator_status'] ?? '')) === 'approved';
$chatCurrencyCode = 'USD';
if (!empty($globalCurCode)) {
  $chatCurrencyCode = strtoupper((string)$globalCurCode);
} elseif (!empty($currency)) {
  $chatCurrencyCode = strtoupper((string)$currency);
}
$chatCurrencyMap = [];
if (isset($currencies) && is_array($currencies)) {
  $chatCurrencyMap = $currencies;
} elseif (isset($currencys) && is_array($currencys)) {
  $chatCurrencyMap = $currencys;
}
$chatCurrencySymbol = isset($chatCurrencyMap[$chatCurrencyCode]) ? (string)$chatCurrencyMap[$chatCurrencyCode] : $chatCurrencyCode;
$chatRequestState = ['status' => 'none', 'direction' => '', 'request_id' => 0];
if (isset($RL) && method_exists($RL, 'RL_GetMessageRequestState')) {
  try {
    $chatRequestState = $RL->RL_GetMessageRequestState((int)$userID, (int)$chatUserID);
  } catch (Throwable $__) {
    $chatRequestState = ['status' => 'none', 'direction' => '', 'request_id' => 0];
  }
}
$chatRequestStatus = (string)($chatRequestState['status'] ?? 'none');
$chatRequestDirection = (string)($chatRequestState['direction'] ?? '');
$chatRequestId = (int)($chatRequestState['request_id'] ?? 0);
$chatInputLocked = ($chatRequestStatus === 'pending' && $chatRequestDirection === 'incoming')
  || in_array($chatRequestStatus, ['blocked_in', 'blocked_out'], true);

// Grouped messages
$limitInit = isset($scrollLimitChat) ? (int) $scrollLimitChat : 20;
if ($limitInit <= 0) { $limitInit = 20; }
$preferredTimezone = 'UTC';
if (isset($RL) && method_exists($RL, 'RL_GetPreferredTimezone')) {
  try {
    $preferredTimezone = $RL->RL_GetPreferredTimezone((int)$userID);
  } catch (Throwable $__) {
    $preferredTimezone = 'UTC';
  }
}
$groups = $RL->RL_GetConversationMessagesGroupedLimited($userID, $chatUserID, $limitInit, $preferredTimezone);

if (!function_exists('cp_chat_reaction_label')) {
  function cp_chat_reaction_label(string $reaction): string
  {
    $map = [
      'heart' => '&#10084;&#65039;',
      'like' => '&#128077;',
      'fire' => '&#128293;',
      'laugh' => '&#128514;',
      'wow' => '&#128558;',
      'sad' => '&#128546;',
    ];
    return $map[$reaction] ?? '&#10084;&#65039;';
  }
}

if (!function_exists('cp_render_chat_reply')) {
  function cp_render_chat_reply(array $message): string
  {
    $reply = $message['reply'] ?? null;
    if (!is_array($reply)) {
      return '';
    }
    $label = !empty($reply['is_outgoing'])
      ? customLang('chat_reply_you', 'You')
      : customLang('chat_reply_label', 'Reply');
    $text = trim((string)($reply['message'] ?? ''));
    if ($text === '') {
      $text = customLang('chat_reply_message_fallback', 'Message');
    }
    return '<button type="button" class="chat_reply_quote" data-chat-action="reply-jump" data-reply-mid="' . (int)($reply['message_id'] ?? 0) . '">'
      . '<span>' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</span>'
      . '<strong>' . htmlspecialchars($text, ENT_QUOTES, 'UTF-8') . '</strong>'
      . '</button>';
  }
}

if (!function_exists('cp_render_chat_reactions')) {
  function cp_render_chat_reactions(array $message): string
  {
    $reactions = $message['reactions'] ?? [];
    if (!is_array($reactions) || empty($reactions)) {
      return '';
    }
    $html = '<div class="chat_reactions" aria-label="Message reactions">';
    foreach ($reactions as $reaction) {
      $key = (string)($reaction['reaction'] ?? 'heart');
      $count = (int)($reaction['count'] ?? 0);
      if ($count <= 0) { continue; }
      $html .= '<span>' . cp_chat_reaction_label($key) . ($count > 1 ? ' ' . $count : '') . '</span>';
    }
    return $html . '</div>';
  }
}

if (!function_exists('cp_render_chat_actions')) {
  function cp_render_chat_actions(array $message, bool $isOutgoing): string
  {
    $mid = (int)($message['message_id'] ?? 0);
    if ($mid <= 0 || !empty($message['is_deleted'])) {
      return '';
    }
    $canDeleteEveryone = !empty($message['can_delete_everyone']);
    $myReaction = (string)($message['my_reaction'] ?? '');
    $reactionItems = [
      'heart' => customLang('chat_reaction_heart', 'Heart'),
      'like'  => customLang('chat_reaction_like', 'Like'),
      'fire'  => customLang('chat_reaction_fire', 'Fire'),
      'laugh' => customLang('chat_reaction_laugh', 'Laugh'),
      'wow'   => customLang('chat_reaction_wow', 'Wow'),
      'sad'   => customLang('chat_reaction_sad', 'Sad'),
    ];
    $reactionIcon = render_icon('smiley_chat', true, 'themes/default/icons/smiley_chat.svg');
    $html = '<div class="chat_message_actions" data-chat-actions>'
      . '<button type="button" class="chat_reaction_toggle" data-chat-action="toggle-reactions" data-mid="' . $mid . '" aria-label="' . iN_HelpSecure(customLang('chat_react_to_message', 'React to message'), false) . '">' . $reactionIcon . '</button>'
      . '<button type="button" class="chat_action_toggle" data-chat-action="toggle-menu" aria-label="' . iN_HelpSecure(customLang('chat_message_actions', 'Message actions'), false) . '">&#8942;</button>'
      . '<div class="chat_reaction_rail" hidden>';
    foreach ($reactionItems as $key => $title) {
      $active = ($myReaction === $key) ? ' is-active' : '';
      $pressed = ($myReaction === $key) ? 'true' : 'false';
      $html .= '<button type="button" class="chat_reaction_choice' . $active . '" data-chat-action="react-choice" data-chat-reaction-choice="' . $key . '" data-mid="' . $mid . '" aria-label="' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '" aria-pressed="' . $pressed . '">'
        . '<span>' . cp_chat_reaction_label($key) . '</span>'
        . '</button>';
    }
    $html .= '</div>'
      . '<div class="chat_action_menu" hidden>'
      . '<button type="button" data-chat-action="reply" data-mid="' . $mid . '">' . iN_HelpSecure(customLang('chat_action_reply', 'Reply')) . '</button>'
      . '<button type="button" data-chat-action="copy" data-mid="' . $mid . '">' . iN_HelpSecure(customLang('chat_action_copy', 'Copy')) . '</button>'
      . '<button type="button" data-chat-action="delete-self" data-mid="' . $mid . '">' . iN_HelpSecure(customLang('chat_action_delete_self', 'Delete for me')) . '</button>';
    if ($isOutgoing && $canDeleteEveryone) {
      $html .= '<button type="button" data-chat-action="delete-everyone" data-mid="' . $mid . '">' . iN_HelpSecure(customLang('chat_action_delete_everyone', 'Delete for everyone')) . '</button>';
    }
    $html .= '<button type="button" data-chat-action="report" data-mid="' . $mid . '">' . iN_HelpSecure(customLang('chat_action_report', 'Report')) . '</button>'
      . '</div></div>';
    return $html;
  }
}

if (!function_exists('cp_chat_currency_symbol')) {
  function cp_chat_currency_symbol(string $code): string
  {
    $code = strtoupper(trim($code));
    $map = [];
    if (isset($GLOBALS['currencies']) && is_array($GLOBALS['currencies'])) {
      $map = $GLOBALS['currencies'];
    } elseif (isset($GLOBALS['currencys']) && is_array($GLOBALS['currencys'])) {
      $map = $GLOBALS['currencys'];
    }
    return isset($map[$code]) ? (string)$map[$code] : $code;
  }
}

if (!function_exists('cp_render_tip_chat_message')) {
  function cp_render_tip_chat_message(array $message): string
  {
    $tip = $message['tip'] ?? null;
    $currency = is_array($tip) ? strtoupper((string)($tip['currency'] ?? 'USD')) : 'USD';
    $symbol = cp_chat_currency_symbol($currency);
    $amountDisplay = is_array($tip) ? trim((string)($tip['amount_display'] ?? '')) : '';

    if ($amountDisplay === '' && is_array($tip) && isset($tip['amount'])) {
      $amountDisplay = $symbol . number_format((float)$tip['amount'], 2, '.', '');
    }

    if ($amountDisplay === '') {
      $rawMessage = trim((string)($message['message'] ?? ''));
      if (preg_match('/([0-9]+(?:[.,][0-9]+)?)\s*([A-Z]{3})\b/i', $rawMessage, $matches)) {
        $currency = strtoupper($matches[2]);
        $symbol = cp_chat_currency_symbol($currency);
        $amountDisplay = $symbol . number_format((float)str_replace(',', '.', $matches[1]), 2, '.', '');
      } elseif (strpos($rawMessage, ':') !== false) {
        $amountDisplay = trim((string)substr($rawMessage, (int)strrpos($rawMessage, ':') + 1));
      }
    }

    if ($amountDisplay === '') {
      $amountDisplay = $symbol . '0.00';
    }

    return '<div class="chat_tip_message">'
      . '<span class="chat_tip_message__icon">' . iN_HelpSecure($symbol, false) . '</span>'
      . '<div class="chat_tip_message__copy">'
      . '<span class="chat_tip_message__label">' . iN_HelpSecure(customLang('chat_tip_message_label', 'Tip sent')) . '</span>'
      . '<strong class="chat_tip_message__amount">' . iN_HelpSecure($amountDisplay, false) . '</strong>'
      . '</div>'
      . '</div>';
  }
}

if (!function_exists('cp_render_paid_chat_media')) {
  function cp_render_paid_chat_media(array $message): string
  {
    $paid = $message['paid_media'] ?? null;
    if (!is_array($paid)) {
      return '';
    }
    $mid = (int)($paid['message_id'] ?? ($message['message_id'] ?? 0));
    $type = (string)($paid['media_type'] ?? 'image');
    $price = number_format((float)($paid['price'] ?? 0), 2, '.', '');
    $currency = strtoupper((string)($paid['currency'] ?? 'USD'));
    $symbol = cp_chat_currency_symbol($currency);
    $isUnlocked = !empty($paid['is_unlocked']);
    $isOwner = !empty($paid['is_owner']);
    $url = (string)($paid['file_url'] ?? '');
    $label = $symbol . $price;
    if (mb_strlen($symbol) > 4) {
      $label = $price . ' ' . $currency;
    }

    if ($isUnlocked && $url !== '') {
      $paidLabel = customLang('chat_paid_media_label', 'Paid media');
      $unlockedLabel = customLang('chat_paid_media_unlocked', 'Unlocked');
      if ($type === 'video') {
        return '<div class="chat_paid_media chat_paid_media--unlocked"><video controls><source src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" type="video/mp4"></video><span>' . iN_HelpSecure($isOwner ? $paidLabel : $unlockedLabel) . '</span></div>';
      }
      return '<div class="chat_paid_media chat_paid_media--unlocked"><img src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" alt="' . iN_HelpSecure($paidLabel, false) . '" data-lazy-dimensions="skip" data-skip-image-dimensions="true"><span>' . iN_HelpSecure($isOwner ? $paidLabel : $unlockedLabel) . '</span></div>';
    }

    $lockedIcon = render_icon('locked', true);

    return '<div class="chat_paid_media chat_paid_media--locked" data-paid-media-card data-mid="' . $mid . '">'
      . '<div class="chat_paid_media__icon">' . $lockedIcon . '</div>'
      . '<strong>' . iN_HelpSecure(customLang('chat_paid_media_locked_title', 'Locked media')) . '</strong>'
      . '<p>' . iN_HelpSecure(customLang('chat_paid_media_locked_desc', 'Unlock this {type} to view it.', ['type' => $type])) . '</p>'
      . '<button type="button" data-chat-action="unlock-paid-media" data-mid="' . $mid . '">' . iN_HelpSecure(customLang('chat_paid_media_unlock_button', 'Unlock {price}', ['price' => $label])) . '</button>'
      . '</div>';
  }
}

?>
<!-- Header -->
<div class="chat_list_header flex full-width align_items gap">
  <div class="back-prev-chat getChatList flex align_items">
    <?php echo render_icon('prev', false); ?>
  </div>
  <div class="chat_current_user flex align_items gap">
    <?php $__oName = (string)(($other['user_fullname'] ?? '') ?: ($other['username'] ?? 'user')); $__oAlt = sprintf(customLang('alt_avatar_of_user'), $__oName); ?>
    <img class="avatar"
         src="<?php echo htmlspecialchars($otherAvatarUrl, ENT_QUOTES, 'UTF-8'); ?>"
         alt="<?php echo iN_HelpSecure($__oAlt); ?>">
    <span class="username flex align_items truncated">
      <?php echo htmlspecialchars(($other['user_fullname'] ?? '') ?: ($other['username'] ?? '')); ?>
    </span>
  </div>
  <div class="chat_header_actions" data-chat-header-actions data-chat-peer-id="<?php echo (int)$chatUserID; ?>" data-chat-peer-name="<?php echo iN_HelpSecure($__oName, false); ?>">
    <div class="chat_call_controls flex align_items" data-chat-peer-id="<?php echo (int)$chatUserID; ?>">
      <button type="button" class="chat_call_button" data-chat-call-start="audio" aria-label="<?php echo iN_HelpSecure(customLang('chat_call_audio', 'Start audio call')); ?>"<?php echo $chatInputLocked ? ' disabled' : ''; ?>>
        <?php echo render_icon('voice_call', true, 'themes/default/icons/voice-call.svg'); ?>
      </button>
      <button type="button" class="chat_call_button" data-chat-call-start="video" aria-label="<?php echo iN_HelpSecure(customLang('chat_call_video', 'Start video call')); ?>"<?php echo $chatInputLocked ? ' disabled' : ''; ?>>
        <?php echo render_icon('video_call', true, 'themes/default/icons/video-call.svg'); ?>
      </button>
    </div>
    <button type="button" class="chat_header_icon_button" data-chat-thread-search-toggle aria-expanded="false" aria-label="<?php echo iN_HelpSecure(customLang('chat_search_conversation', 'Search in conversation')); ?>">
      <?php echo render_icon('search_icon', true); ?>
    </button>
    <div class="chat_header_more">
      <button type="button" class="chat_header_icon_button" data-chat-menu-toggle aria-haspopup="menu" aria-expanded="false" aria-label="<?php echo iN_HelpSecure(customLang('chat_conversation_options', 'Conversation options')); ?>">
        <?php echo render_icon('dots', true); ?>
      </button>
      <div class="chat_conversation_menu" data-chat-conversation-menu role="menu" hidden>
        <button type="button" data-chat-menu-action="info" role="menuitem">
          <span aria-hidden="true"><?php echo render_icon('info', true); ?></span><?php echo iN_HelpSecure(customLang('chat_menu_person_info', 'Person Information')); ?>
        </button>
        <button type="button" data-chat-menu-action="clear" role="menuitem">
          <span aria-hidden="true"><?php echo render_icon('clear', true); ?></span><?php echo iN_HelpSecure(customLang('chat_menu_clear', 'Clear Chat')); ?>
        </button>
        <button type="button" data-chat-menu-action="delete" role="menuitem">
          <span aria-hidden="true"><?php echo render_icon('delete', true); ?></span><?php echo iN_HelpSecure(customLang('chat_menu_delete', 'Delete Chat')); ?>
        </button>
        <button type="button" data-chat-menu-action="download" role="menuitem">
          <span aria-hidden="true"><?php echo render_icon('download', true); ?></span><?php echo iN_HelpSecure(customLang('chat_menu_download', 'Download Chat')); ?>
        </button>
        <button type="button" data-chat-menu-action="report" role="menuitem">
          <span aria-hidden="true"><?php echo render_icon('report', true); ?></span><?php echo iN_HelpSecure(customLang('chat_menu_report', 'Report Chat')); ?>
        </button>
        <button type="button" data-chat-menu-action="pin" role="menuitem" data-chat-pin-label="<?php echo iN_HelpSecure(customLang('chat_menu_pin', 'Pin this chat'), false); ?>" data-chat-unpin-label="<?php echo iN_HelpSecure(customLang('chat_menu_unpin', 'Unpin this chat'), false); ?>">
          <span aria-hidden="true"><?php echo render_icon('pin', true); ?></span><em><?php echo iN_HelpSecure(customLang('chat_menu_pin', 'Pin this chat')); ?></em>
        </button>
        <button type="button" data-chat-menu-action="block" role="menuitem" class="is-danger">
          <span aria-hidden="true"><?php echo render_icon('block', true); ?></span><?php echo iN_HelpSecure(customLang('chat_menu_block', 'Block')); ?>
        </button>
      </div>
    </div>
  </div>
</div>
<div class="chat_thread_search" data-chat-thread-search hidden>
  <label>
    <span aria-hidden="true"><?php echo render_icon('search_icon', true); ?></span>
    <input type="search" data-chat-thread-search-input placeholder="<?php echo iN_HelpSecure(customLang('chat_search_conversation_placeholder', 'Search this conversation')); ?>" autocomplete="off">
  </label>
  <span class="chat_thread_search_count" data-chat-thread-search-count>0/0</span>
  <button type="button" data-chat-thread-search-prev aria-label="<?php echo iN_HelpSecure(customLang('previous', 'Previous')); ?>">&#8593;</button>
  <button type="button" data-chat-thread-search-next aria-label="<?php echo iN_HelpSecure(customLang('next', 'Next')); ?>">&#8595;</button>
  <button type="button" data-chat-thread-search-close aria-label="<?php echo iN_HelpSecure(customLang('close', 'Close')); ?>">&times;</button>
</div>
<div class="arrow"></div>

<?php if ($chatRequestStatus === 'pending' && $chatRequestDirection === 'incoming' && $chatRequestId > 0): ?>
  <div class="chat_request_banner" data-message-request-banner data-request-id="<?php echo $chatRequestId; ?>">
    <div>
      <strong><?php echo iN_HelpSecure(customLang('chat_request_incoming_title', 'Message request')); ?></strong>
      <p><?php echo iN_HelpSecure(customLang('chat_request_incoming_text', 'Accept this request to continue the conversation, or decline it if you do not want to chat.')); ?></p>
    </div>
    <div class="chat_request_actions">
      <button type="button" data-message-request-action="accept" data-request-id="<?php echo $chatRequestId; ?>"><?php echo iN_HelpSecure(customLang('chat_request_accept', 'Accept')); ?></button>
      <button type="button" data-message-request-action="decline" data-request-id="<?php echo $chatRequestId; ?>"><?php echo iN_HelpSecure(customLang('chat_request_decline', 'Decline')); ?></button>
      <button type="button" data-message-request-action="block" data-request-id="<?php echo $chatRequestId; ?>"><?php echo iN_HelpSecure(customLang('chat_request_block', 'Block')); ?></button>
    </div>
  </div>
<?php elseif ($chatRequestStatus === 'pending' && $chatRequestDirection === 'outgoing'): ?>
  <div class="chat_request_banner chat_request_banner--quiet" data-message-request-banner>
    <div>
      <strong><?php echo iN_HelpSecure(customLang('chat_request_outgoing_title', 'Request sent')); ?></strong>
      <p><?php echo iN_HelpSecure(customLang('chat_request_outgoing_text', 'They will be able to accept your message request before replying.')); ?></p>
    </div>
  </div>
<?php elseif (in_array($chatRequestStatus, ['blocked_in', 'blocked_out'], true)): ?>
  <div class="chat_request_banner chat_request_banner--blocked" data-message-request-banner>
    <div>
      <strong><?php echo iN_HelpSecure(customLang('chat_request_blocked_title', 'Conversation blocked')); ?></strong>
      <p><?php echo iN_HelpSecure(customLang('chat_request_blocked_text', 'Messaging is disabled for this conversation.')); ?></p>
    </div>
  </div>
<?php endif; ?>

<!-- List -->
  <div class="chat_list_container full-width flex align_items flexBoxColumn relative">
  <div id="chatScroll" class="chat_list_wrapper flex align_items full-width flexBoxColumn conversations sidebar_scroll"
     data-chat-user="<?php echo (int)$chatUserID; ?>"
     data-other-avatar="<?php echo htmlspecialchars($otherAvatarUrl, ENT_QUOTES, 'UTF-8'); ?>"
     data-limit="<?php echo (int) $limitInit; ?>"
     data-can-tip="<?php echo $chatCanTip ? '1' : '0'; ?>"
     data-can-paid-media="<?php echo $chatCanPaidMedia ? '1' : '0'; ?>"
     data-currency-code="<?php echo iN_HelpSecure($chatCurrencyCode, false); ?>"
     data-currency-symbol="<?php echo iN_HelpSecure($chatCurrencySymbol, false); ?>"
     data-message-request-status="<?php echo iN_HelpSecure($chatRequestStatus, false); ?>"
     data-message-request-direction="<?php echo iN_HelpSecure($chatRequestDirection, false); ?>">

    <?php foreach ($groups as $g): ?>
      <div class="chat_meta" data-ymd="<?php echo htmlspecialchars($g['ymd']); ?>"><?php echo htmlspecialchars($g['label']); ?></div>

      <?php
        $lastDirection = null;
        foreach ($g['items'] as $m):
          $isOutgoing = ($m['direction'] === 'outgoing');
          $rowClass   = $isOutgoing ? 'outgoing' : 'incoming';
          $compact    = ($lastDirection !== null && $lastDirection === $m['direction']) ? ' compact' : '';
          $isTipMessage = (($m['message_type'] ?? '') === 'tip');
      ?>
        <?php
          $tickState = '';
          if ($isOutgoing) {
            if (!empty($m['read_at'])) { $tickState = 'blue'; }
            elseif (!empty($m['delivered_at'])) { $tickState = 'double'; }
            else { $tickState = 'single'; }
          }
        ?>
        <div class="chat_message_row <?php echo $rowClass . $compact; ?>" data-ymd="<?php echo htmlspecialchars($g['ymd']); ?>" data-ts="<?php echo (int)($m['message_time'] ?? 0); ?>" data-mid="<?php echo (int)($m['message_id'] ?? 0); ?>" data-my-reaction="<?php echo htmlspecialchars((string)($m['my_reaction'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"<?php if ($isOutgoing) { echo ' data-tick="' . $tickState . '"'; } ?>>
          <?php if ($isOutgoing): ?>
            <div class="chat_spacer"></div>
            <div class="chat_bubble outgoing<?php echo $isTipMessage ? ' chat_bubble--tip' : ''; ?>">
              <?php echo cp_render_chat_reply($m); ?>
              <?php if (($m['message_type'] ?? '') === 'paid_media'): ?>
                <?php echo cp_render_paid_chat_media($m); ?>
              <?php elseif ($isTipMessage): ?>
                <?php echo cp_render_tip_chat_message($m); ?>
              <?php elseif (!empty($m['file']) && is_string($m['file']) && preg_match('/^post:\\d+$/i', $m['file'])): ?>
                <?php
                  $pidShare = (int) preg_replace('/^post:/i', '', (string) $m['file']);
                  $pShare   = $RL->RL_GetPostById($pidShare, $userID, null);
                  if ($pShare) {
                    $ownerU = (string)($pShare['owner_username'] ?? '');
                    $url    = rtrim((string)$base_url, '/') . '/posts/' . $pidShare . '/' . $ownerU;
                    $type   = (string)($pShare['post_type'] ?? '');
                    $files  = array_filter(array_map('trim', explode(',', (string)($pShare['post_file'] ?? ''))));
                    $thumb  = $files ? $files[0] : '';
                    $coverRel = '';
                    if ($type === 'podcast' && isset($RL) && method_exists($RL, 'RL_GetPostCoverPath')) {
                        try { $coverRel = (string) $RL->RL_GetPostCoverPath($pidShare); } catch (Throwable $__) { $coverRel = ''; }
                    }
                    $thumbUrlResolved = ($thumb !== '') ? storage_url($thumb) : '';
                    $coverUrlResolved = ($coverRel !== '') ? storage_url($coverRel) : '';
                ?>
                  <a class="chat-share-card" href="<?php echo iN_HelpSecure($url); ?>" target="_blank" rel="noopener noreferrer">
                    <?php $altTxt = dzShortCaption($pShare, 80); if ($altTxt === '') { $altTxt = sprintf(customLang('alt_post_by_user'), $ownerU ?: 'user'); } ?>
                    <div class="csp-thumb">
                    <?php if ($type === 'image' && $thumbUrlResolved !== ''): ?>
                      <img src="<?php echo iN_HelpSecure($thumbUrlResolved); ?>" alt="<?php echo iN_HelpSecure($altTxt); ?>" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
                    <?php elseif ($type === 'video' && $thumb !== ''): ?>
                      <?php
                        $videoThumbUrl = $thumbUrlResolved;
                        if ($videoThumbUrl !== '' && isset($RL) && method_exists($RL, 'videoThumbNail')) {
                            try { $videoThumbUrl = $RL->videoThumbNail($videoThumbUrl); } catch (Throwable $__) {}
                        }
                      ?>
                      <?php if ($videoThumbUrl !== ''): ?>
                        <img src="<?php echo iN_HelpSecure($videoThumbUrl); ?>" alt="<?php echo iN_HelpSecure($altTxt); ?>" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
                        <span class="csp-play">&#9658;</span>
                      <?php else: ?>
                        <div class="csp-placeholder"><?php echo iN_HelpSecure(customLang('post_type_post', 'Post')); ?></div>
                      <?php endif; ?>
                    <?php elseif ($type === 'podcast'): ?>
                      <?php if ($coverUrlResolved !== ''): ?>
                        <img src="<?php echo iN_HelpSecure($coverUrlResolved); ?>" alt="<?php echo iN_HelpSecure($altTxt); ?>" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
                        <span class="csp-play">&#9658;</span>
                      <?php else: ?>
                        <div class="csp-placeholder"><?php echo iN_HelpSecure(customLang('post_type_post', 'Post')); ?></div>
                      <?php endif; ?>
                    <?php else: ?>
                      <div class="csp-placeholder"><?php echo iN_HelpSecure(customLang('post_type_post', 'Post')); ?></div>
                    <?php endif; ?>
                    </div>
                    <div class="csp-meta">
                      <div class="csp-user">@<?php echo iN_HelpSecure($ownerU); ?></div>
                      <div class="csp-type"><?php echo $type === 'video' ? iN_HelpSecure(customLang('post_type_reel', 'Reel')) : ($type === 'podcast' ? customLang('menu_podcasts') : iN_HelpSecure(customLang('post_type_post', 'Post'))); ?></div>
                    </div>
                  </a>
                <?php } else { ?>
                  <div class="csp-placeholder"><?php echo iN_HelpSecure(customLang('post_type_post', 'Post')); ?></div>
                <?php } ?>
              <?php elseif (!empty($m['file']) && ($m['file_kind'] ?? '') === 'image'): ?>
                <?php $fileUrl = storage_url($m['file']); ?>
                <img src="<?php echo htmlspecialchars($fileUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo iN_HelpSecure(customLang('image_alt_generic')); ?>" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
              <?php elseif (!empty($m['file']) && ($m['file_kind'] ?? '') === 'video'): ?>
                <?php $fileUrl = storage_url($m['file']); ?>
                <video controls>
                  <source src="<?php echo htmlspecialchars($fileUrl, ENT_QUOTES, 'UTF-8'); ?>" type="video/mp4">
                </video>
              <?php else: ?>
                <?php echo nl2br(htmlspecialchars($m['message'])); ?>
              <?php endif; ?>
              <?php
                $icon = 'tick';
                if (!empty($m['read_at'])) { $icon = 'tick_double_blue'; }
                elseif (!empty($m['delivered_at'])) { $icon = 'tick_double'; }
              ?>
              <div class="chat_status"><span class="tick_icon"><?php echo renderVerifiedBadge($iconPath . $icon . '.svg', false); ?></span></div> 
              <?php echo cp_render_chat_reactions($m); ?>
              <?php echo cp_render_chat_actions($m, $isOutgoing); ?>
            </div>
          <?php else: ?>
            <?php if (!$compact): ?>
              <div class="chat_avatar">
                <img src="<?php echo htmlspecialchars($base_url . ($m['avatar'] ?? 'uploads/user_avatars/default.jpeg')); ?>"
                     alt="<?php echo htmlspecialchars($other['username'] ?? 'user'); ?>">
              </div>
            <?php else: ?>
              <div class="chat_avatar"></div>
            <?php endif; ?>
            <div class="chat_bubble incoming<?php echo $isTipMessage ? ' chat_bubble--tip' : ''; ?>">
              <?php echo cp_render_chat_reply($m); ?>
              <?php if (($m['message_type'] ?? '') === 'paid_media'): ?>
                <?php echo cp_render_paid_chat_media($m); ?>
              <?php elseif ($isTipMessage): ?>
                <?php echo cp_render_tip_chat_message($m); ?>
              <?php elseif (!empty($m['file']) && is_string($m['file']) && preg_match('/^post:\\d+$/i', $m['file'])): ?>
                <?php
                  $pidShare = (int) preg_replace('/^post:/i', '', (string) $m['file']);
                  $pShare   = $RL->RL_GetPostById($pidShare, $userID, null);
                  if ($pShare) {
                    $ownerU = (string)($pShare['owner_username'] ?? '');
                    $url    = rtrim((string)$base_url, '/') . '/posts/' . $pidShare . '/' . $ownerU;
                    $type   = (string)($pShare['post_type'] ?? '');
                    $files  = array_filter(array_map('trim', explode(',', (string)($pShare['post_file'] ?? ''))));
                    $thumb  = $files ? $files[0] : '';
                    $coverRel = '';
                    if ($type === 'podcast' && isset($RL) && method_exists($RL, 'RL_GetPostCoverPath')) {
                        try { $coverRel = (string) $RL->RL_GetPostCoverPath($pidShare); } catch (Throwable $__) { $coverRel = ''; }
                    }
                    $thumbUrlResolved = ($thumb !== '') ? storage_url($thumb) : '';
                    $coverUrlResolved = ($coverRel !== '') ? storage_url($coverRel) : '';
                ?>
                  <?php $altTxt = dzShortCaption($pShare, 80); if ($altTxt === '') { $altTxt = sprintf(customLang('alt_post_by_user'), $ownerU ?: 'user'); } ?>
                  <a class="chat-share-card" href="<?php echo iN_HelpSecure($url); ?>" target="_blank" rel="noopener noreferrer">
                    <div class="csp-thumb">
                    <?php if ($type === 'image' && $thumbUrlResolved !== ''): ?>
                      <img src="<?php echo iN_HelpSecure($thumbUrlResolved); ?>" alt="<?php echo iN_HelpSecure($altTxt); ?>" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
                    <?php elseif ($type === 'video' && $thumb !== ''): ?>
                      <?php
                        $videoThumbUrl = $thumbUrlResolved;
                        if ($videoThumbUrl !== '' && isset($RL) && method_exists($RL, 'videoThumbNail')) {
                            try { $videoThumbUrl = $RL->videoThumbNail($videoThumbUrl); } catch (Throwable $__) {}
                        }
                      ?>
                      <?php if ($videoThumbUrl !== ''): ?>
                        <img src="<?php echo iN_HelpSecure($videoThumbUrl); ?>" alt="<?php echo iN_HelpSecure($altTxt); ?>" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
                        <span class="csp-play">&#9658;</span>
                      <?php else: ?>
                        <div class="csp-placeholder"><?php echo iN_HelpSecure(customLang('post_type_post', 'Post')); ?></div>
                      <?php endif; ?>
                    <?php elseif ($type === 'podcast'): ?>
                      <?php if ($coverUrlResolved !== ''): ?>
                        <img src="<?php echo iN_HelpSecure($coverUrlResolved); ?>" alt="<?php echo iN_HelpSecure($altTxt); ?>" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
                        <span class="csp-play">&#9658;</span>
                      <?php else: ?>
                        <div class="csp-placeholder"><?php echo iN_HelpSecure(customLang('post_type_post', 'Post')); ?></div>
                      <?php endif; ?>
                    <?php else: ?>
                      <div class="csp-placeholder"><?php echo iN_HelpSecure(customLang('post_type_post', 'Post')); ?></div>
                    <?php endif; ?>
                    </div>
                    <div class="csp-meta">
                      <div class="csp-user">@<?php echo iN_HelpSecure($ownerU); ?></div>
                      <div class="csp-type"><?php echo $type === 'video' ? iN_HelpSecure(customLang('post_type_reel', 'Reel')) : ($type === 'podcast' ? customLang('menu_podcasts') : iN_HelpSecure(customLang('post_type_post', 'Post'))); ?></div>
                    </div>
                  </a>
                <?php } else { ?>
                  <div class="csp-placeholder"><?php echo iN_HelpSecure(customLang('post_type_post', 'Post')); ?></div>
                <?php } ?>
              <?php elseif (!empty($m['file']) && ($m['file_kind'] ?? '') === 'image'): ?>
                <?php $fileUrl = storage_url($m['file']); ?>
                <img src="<?php echo htmlspecialchars($fileUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo iN_HelpSecure(customLang('image_alt_generic')); ?>" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
              <?php elseif (!empty($m['file']) && ($m['file_kind'] ?? '') === 'video'): ?>
                <?php $fileUrl = storage_url($m['file']); ?>
                <video controls>
                  <source src="<?php echo htmlspecialchars($fileUrl, ENT_QUOTES, 'UTF-8'); ?>" type="video/mp4">
                </video>
              <?php else: ?>
                <?php echo nl2br(htmlspecialchars($m['message'])); ?>
              <?php endif; ?> 
              <?php echo cp_render_chat_reactions($m); ?>
              <?php echo cp_render_chat_actions($m, $isOutgoing); ?>
            </div>
          <?php endif; ?>
        </div>
      <?php
        $lastDirection = $m['direction'];
        endforeach;
      ?>
    <?php endforeach; ?>

    <?php if (empty($groups)): ?>
      <div class="chat_empty_placeholder full-width flex align_items_justify_content flexBoxColumn gap" data-empty="1">
        <div class="chat_avatar_empty_message">
          <img src="<?php echo htmlspecialchars($otherAvatarUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($other['username'] ?? 'user'); ?>">
        </div>
        <div class="chat_empty_name">
          <?php echo htmlspecialchars(($other['user_fullname'] ?? '') ?: ($other['username'] ?? '')); ?>
        </div>
        <div class="chat_meta"><?php echo customLang('chat_empty'); ?></div>
      </div>
    <?php endif; ?>

  </div>

  <!-- Icon templates (inline via PHP helper) for JS to clone; no inline JS used -->
  <div id="chat-icon-templates" class="visually-hidden none" aria-hidden="true">
    <span data-icon="tick"><?php echo render_icon('tick', true); ?></span>
    <span data-icon="tick_double"><?php echo render_icon('tick_double', true); ?></span>
    <span data-icon="tick_double_blue"><?php echo render_icon('tick_double_blue', true); ?></span>
    <span data-icon="smiley_chat"><?php echo render_icon('smiley_chat', true, 'themes/default/icons/smiley_chat.svg'); ?></span>
    <span data-icon="locked"><?php echo render_icon('locked', true); ?></span>
  </div>

  <!-- Input -->
  <div class="chat_input_area full-width flex align_items chat_area flexBoxColumn<?php echo $chatInputLocked ? ' is-locked' : ''; ?>">
    <div class="chat_input_area_wrapper full-width flex align_items chat_area">
      <button type="button" class="chat_input_icon chat_actions_toggle" data-chat-actions-toggle aria-expanded="false" aria-controls="chat-compact-actions" aria-label="<?php echo iN_HelpSecure(customLang('chat_message_actions', 'Message actions')); ?>">
        <span aria-hidden="true">+</span>
      </button>
      <div class="chat_compact_actions" id="chat-compact-actions" data-chat-compact-actions aria-label="<?php echo iN_HelpSecure(customLang('chat_message_actions', 'Message actions')); ?>">
        <button type="button" class="chat_input_icon emoji_btn get_emojis" data-id="01" aria-label="<?php echo iN_HelpSecure(customLang('chat_add_emoji', 'Add emoji')); ?>" aria-expanded="false" aria-controls="chat-emoji-list-01">
          <?php echo render_icon('smiley_chat', true); ?>
        </button>
        <div class="chat_input_icon attach_btn<?php echo $chatInputLocked ? ' is-disabled' : ''; ?>">
          <?php echo render_icon('image', true); ?>
        </div>
        <div class="chat_input_icon video_btn<?php echo $chatInputLocked ? ' is-disabled' : ''; ?>">
          <?php echo render_icon('video', true); ?>
        </div>
        <?php if ($chatCanTip && !$chatInputLocked): ?>
          <button type="button" class="chat_input_icon chat_tip_btn" data-chat-tip-open aria-label="<?php echo iN_HelpSecure(customLang('chat_send_tip', 'Send tip')); ?>">
            <span><?php echo iN_HelpSecure($chatCurrencySymbol, false); ?></span>
          </button>
        <?php endif; ?>
        <?php if ($chatCanPaidMedia && !$chatInputLocked): ?>
          <button type="button" class="chat_input_icon chat_paid_btn" data-chat-paid-open aria-label="<?php echo iN_HelpSecure(customLang('chat_send_paid_media', 'Send paid media')); ?>">
            <?php echo render_icon('locked', true); ?>
          </button>
        <?php endif; ?>
      </div>
      <textarea name="post-text" class="chat_textarea"
                placeholder="<?php echo $chatInputLocked ? iN_HelpSecure(customLang('chat_request_locked_placeholder', 'Accept the request to reply.'), false) : customLang('chat_placeholder'); ?>" data-max-height="260" rows="1"<?php echo $chatInputLocked ? ' disabled' : ''; ?>></textarea>
      <input type="file" id="chat_image_input" class="chat_image_input" accept="image/*" hidden>
      <input type="file" id="chat_video_input" class="chat_video_input" accept="video/*" hidden>
      <input type="file" id="chat_paid_image_input" class="chat_paid_image_input" accept="image/*" hidden>
      <input type="file" id="chat_paid_video_input" class="chat_paid_video_input" accept="video/*" hidden>
      <div class="chat_input_icon send_btn">
        <?php echo render_icon('send', true); ?>
      </div>
    </div>
    <div id="chat-emoji-list-01" class="make-emoji-wrapper full-width get_emojis_01" aria-live="polite"></div>
  </div>
<?php $themePath = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme);?>
<script defer src="<?php echo $themePath; ?>/js/chat.js?v=<?php echo iN_HelpSecure($version);?>&fix=emoji-20260721-v18"></script>
</div>
