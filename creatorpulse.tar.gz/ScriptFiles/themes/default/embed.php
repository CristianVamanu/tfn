<?php
declare(strict_types=1);

// Minimal, embeddable player page for public posts only.
// Expects: $_GET['post_id']

require_once __DIR__ . '/../../includes/inc.php';

// Override global CSP for embeds: set only frame-ancestors from ENV.
if (!headers_sent()) {
    header_remove('Content-Security-Policy');
    header_remove('X-Frame-Options');
    $allowed = getenv('EMBED_FRAME_ANCESTORS') ?: '*';
    header("Content-Security-Policy: frame-ancestors {$allowed}");
}

$postId = isset($_GET['post_id']) && preg_match('/^\d+$/', (string)$_GET['post_id']) ? (int)$_GET['post_id'] : 0;
if ($postId <= 0) {
  http_response_code(400);
  echo 'Invalid embed URL.';
  exit;
}

$viewerId  = isset($userID) ? (int)$userID : 0;
// Username is optional here; we only need the post by ID
$post = $RL->RL_GetPostById($postId, $viewerId, null);

if (!$post) {
  http_response_code(404);
  echo 'Post not found.';
  exit;
}

$visibility = strtolower((string)($post['post_visibility'] ?? 'everyone'));
$isPublic   = ($visibility === 'everyone');

// Build absolute URLs
$abs = function(string $rel) use ($base_url): string {
  if (preg_match('~^https?://~i', $rel)) { return $rel; }
  return rtrim((string)$base_url, '/') . '/' . ltrim($rel, '/');
};

$title = trim((string)($post['post_text'] ?? ''));
if ($title === '') {
  $owner = (string)($post['owner_fullname'] ?? $post['owner_username'] ?? '');
  $title = $owner !== '' ? ($owner . ' – ' . ($siteTitle ?? '')) : ((string)($siteTitle ?? ''));
}

$isImage = (string)($post['post_type'] ?? '') === 'image';
$files   = array_filter(array_map('trim', explode(',', (string)($post['post_file'] ?? ''))));
$video   = (string)($post['post_file'] ?? '');
$poster  = (string)($post['poster'] ?? ($post['poster_url'] ?? ''));
// Extra details for richer embed header
$ownerU  = (string)($post['owner_username'] ?? '');
$ownerF  = (string)($post['owner_fullname'] ?? '');
$ownerN  = $ownerF !== '' ? $ownerF : $ownerU;
$ownerA  = $RL->RL_userAvatar((int)($post['post_owner_id'] ?? 0));
$postUrl = rtrim((string)$base_url, '/') . '/posts/' . $postId . ($ownerU !== '' ? '/' . rawurlencode($ownerU) : '');
$lc = strtolower((string)($currentLang ?? 'eng'));
$rtLocale = ($lc === 'tr') ? 'tr' : 'en';
$isRTLLocale = isset($isRTLLocale) ? (bool) $isRTLLocale : false;
$currentLocale = $lc;
try { $timeLabel = \RelativeTime::format((int)($post['post_created_time'] ?? time()), null, $rtLocale); } catch(\Throwable $__) { $timeLabel = ''; }
?><!doctype html>
<html lang="<?php echo htmlspecialchars($currentLocale, ENT_QUOTES, 'UTF-8'); ?>" dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo htmlspecialchars($title, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="stylesheet" href="<?php echo htmlspecialchars(rtrim((string)$base_url,'/').'/themes/default/css/style.css?v='.(string)($version ?? ''), ENT_QUOTES, 'UTF-8'); ?>" />
  </head>
  <body class="embed-page<?php echo $isRTLLocale ? ' rtl-locale' : ''; ?>" dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>">
    <div class="embed-wrap">
      <div class="embed-frame">
        <?php if ($isPublic): ?>
          <div class="embed-card">
            <div class="embed-head">
              <div class="embed-avatar"><img src="<?php echo htmlspecialchars($abs($ownerA), ENT_QUOTES, 'UTF-8'); ?>" alt="avatar"></div>
              <div class="embed-meta">
                <div class="embed-uname"><?php echo htmlspecialchars($ownerN, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php if (!empty($timeLabel)): ?><div class="embed-time"><?php echo htmlspecialchars($timeLabel, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
              </div>
            </div>
            <div class="embed-media">
              <?php if ($isImage && !empty($files)): ?>
                <?php $first = reset($files); ?>
                <img src="<?php echo htmlspecialchars($abs($first), ENT_QUOTES, 'UTF-8'); ?>" alt="Post image" />
              <?php else: ?>
                <?php $src  = $abs($video); $postAttr = $poster !== '' ? ' poster="' . htmlspecialchars($abs($poster), ENT_QUOTES, 'UTF-8') . '"' : ''; ?>
                <video controls playsinline<?php echo $postAttr; ?>>
                  <source src="<?php echo htmlspecialchars($src, ENT_QUOTES, 'UTF-8'); ?>" />
                </video>
              <?php endif; ?>
            </div>
            <?php if (trim((string)($post['post_text'] ?? '')) !== ''): ?>
            <div class="embed-body">
              <div class="embed-caption"><?php echo nl2br(htmlspecialchars((string)$post['post_text'], ENT_QUOTES, 'UTF-8')); ?></div>
            </div>
            <?php endif; ?>
            <div class="embed-footer">
              <a class="embed-viewlink" href="<?php echo htmlspecialchars($postUrl, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener"><?php echo customLang('embed_view_on_site'); ?></a>
            </div>
          </div>
        <?php else: ?>
          <div class="embed-placeholder">
            <?php
              $msg = customLang('embed_not_embeddable');
              if ($visibility === 'followers') { $msg = customLang('post_only_followers'); }
              elseif ($visibility === 'subscribers') { $msg = customLang('post_only_subscribers'); }
              elseif ($visibility === 'locked') { $msg = customLang('post_hidden_generic'); }
              echo htmlspecialchars($msg, ENT_QUOTES, 'UTF-8');
            ?>
            <div class="embed-owner">
              <?php echo htmlspecialchars((string)($post['owner_username'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>
            </div>
            <div class="embed-brand"><a href="<?php echo htmlspecialchars((string)$base_url, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener"><?php echo customLang('embed_view_on_site'); ?></a></div>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </body>
  </html>
