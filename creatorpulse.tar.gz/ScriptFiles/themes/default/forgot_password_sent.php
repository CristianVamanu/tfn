<?php
$isRTLLocale = isset($isRTLLocale) ? (bool) $isRTLLocale : false;
$currentLocale = strtolower((string)($currentLang ?? 'eng'));
?>
<!doctype html>
<html lang="<?php echo htmlspecialchars($currentLocale, ENT_QUOTES, 'UTF-8'); ?>" dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-theme="auto">
  <head>
    <title><?php echo customLang('forgot_sent_title', 'Check your inbox'); ?> – <?php echo iN_HelpSecure($siteName ?? ''); ?></title>
    <?php include "head/meta.php";?>
    <?php include "head/css.php";?>
    <?php include "head/js.php";?>
  </head>
  <body class="<?php echo $isRTLLocale ? 'rtl-locale' : ''; ?>" dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-logged-in="<?php echo (isset($loggedIn) && $loggedIn === '1') ? '1' : '0'; ?>">
    <section class="hero login-page wrapper">
      <div class="login-container">
        <a
          class="site-logo"
          href="<?php echo iN_HelpSecure($base_url ?? 'index', false); ?>"
          data-aos="fade-down"
          data-aos-easing="linear"
          data-aos-duration="650"
        >
          <?php echo iN_HelpSecure($siteName ?? ''); ?>
        </a>
        <div class="auth_language_switcher_wrapper">
          <?php
            $languageSwitcherContext = [
                'button_classes' => 'auth_language_switcher flex align_items',
                'label_class' => 'auth_language_switcher__label',
            ];
            include __DIR__ . '/partials/language_switcher.php';
            unset($languageSwitcherContext);
          ?>
        </div>

        <div
          class="login-form relative"
          data-aos="zoom-in-up"
          data-aos-easing="linear"
          data-aos-duration="650"
        >
          <div class="login-form-not">
            <h2 class="marker-animation" data-ma_color="#00BFA5">
              <?php echo customLang('forgot_sent_title', 'Check your inbox'); ?>
            </h2>
            <p>
              <?php echo customLang('forgot_sent_description', 'If we find a matching account, we\'ve emailed password reset instructions. Remember to check your spam folder.'); ?>
            </p>
          </div>

          <div class="form-not-group">
            <div class="form-not">
              <a href="login"><?php echo customLang('forgot_back_to_login'); ?></a>
            </div>
            <div class="form-not">
              <a href="forgot_password"><?php echo customLang('forgot_try_again_link', 'Submit another request'); ?></a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!---->
    <section class="footer footer-out" id="get-started">
      <!---->
      <div class="footer-small-print">
        <div class="copyright">
          <p class="white-text">© <?php echo iN_HelpSecure($siteName);?></p>
        </div>
        <?php include __DIR__ . '/partials/footer_links.php'; ?>
      </div>
      <!---->
    </section>
    <!---->
    <?php include "head/footer_js.php";?>
  </body>
</html>
