<?php
    $isLoggedIn = isset($loggedIn) && $loggedIn === '1';
    $isGuestFeed = isset($guestMode) && $guestMode === true;
    $baseHome = isset($base_url) ? (string) $base_url : '';
    $homeLink = $baseHome !== '' ? $baseHome : '/';
    if ($isGuestFeed) {
        $homeLink = rtrim($homeLink, '/') . '/guest';
    }

    $maintenanceStatus = strtolower((string)($GLOBALS['__MAINTENANCE_MODE_STATUS'] ?? 'off'));
    $currentLayout = isset($layoutFileName) ? basename((string)$layoutFileName) : '';
    $hideMessagesShortcut = ($maintenanceStatus === 'on' && $currentLayout === 'contact.php');
    $walletTopupEnabledGlobal = isset($walletTopupEnabled)
        ? (bool) $walletTopupEnabled
        : (bool) ($GLOBALS['walletTopupEnabled'] ?? false);
    $walletTopupHasProviders = isset($walletTopupHasProviders)
        ? (bool) $walletTopupHasProviders
        : (bool) ($GLOBALS['walletTopupHasProviders'] ?? false);
    $walletTopupAdminOverride = isset($isAdminUser)
        ? (bool) $isAdminUser
        : (bool) ($GLOBALS['isAdminUser'] ?? false);
    $walletTopupMenuEnabled = ($walletTopupEnabledGlobal && $walletTopupHasProviders) || $walletTopupAdminOverride;
    $liveEnabled = isset($liveStreamingEnabled)
        ? (bool) $liveStreamingEnabled
        : (bool) ($GLOBALS['liveStreamingEnabled'] ?? false);
    $audioRoomsEnabledNav = isset($audioRoomsEnabled)
        ? (bool) $audioRoomsEnabled
        : (bool) ($GLOBALS['audioRoomsEnabled'] ?? false);
    $ebooksEnabledNav = isset($ebooksEnabled)
        ? (bool) $ebooksEnabled
        : (bool) ($GLOBALS['ebooksEnabled'] ?? true);

?>

<div class="sidebar sidebar--left sticky_top">
    <div class="sidebar__inner flex align_items flexBoxColumn sidebar_scroll">
        <!---->
        <div class="sidebar__menu_wrapper full-width flex align_items flexBoxColumn">
            <!-- 🔹 Home -->
            <a href="<?php echo iN_HelpSecure($homeLink);?>" class="sidebar__menu_box full-width flex align_items home_page">
                <span class="home_page flex align_items"><?php echo render_icon('home_page', true);?></span>
                <?php echo customLang($isGuestFeed ? 'guest_home' : 'menu_home'); ?>
            </a>

            <?php if ($isLoggedIn && !$isGuestFeed): ?>
            <a href="<?php echo $base_url;?>explore" class="sidebar__menu_box full-width flex align_items explore">
                <span class="explore flex align_items"><?php echo render_icon('explore', true);?></span>
                <?php echo customLang('menu_explore'); ?>
            </a>

            <div class="arrow flex full-width"></div>

            <!-- 🔹 Content types -->
            <?php if (!empty($enableVideoPosts)): ?>
            <a href="<?php echo $base_url;?>reels" class="sidebar__menu_box full-width flex align_items reels">
                <span class="reels flex align_items"><?php echo render_icon('video', true);?></span>
                <?php echo customLang('menu_reels'); ?>
            </a>
            <?php endif; ?>
            <?php if (!empty($enableImagePosts)): ?>
            <a href="<?php echo $base_url;?>images" class="sidebar__menu_box full-width flex align_items images">
                <span class="images flex align_items"><?php echo render_icon('images', true);?></span>
                <?php echo customLang('menu_images'); ?>
            </a>
            <?php endif; ?>
            <?php if (!empty($enablePodcastPosts)): ?>
            <?php
                $podcastsUrl = isset($base_url) ? iN_HelpSecure(rtrim((string)$base_url, '/') . '/podcasts') : '/podcasts';
                $podcastsAria = ($currentLayout === 'podcasts.php') ? ' aria-current="page"' : '';
            ?>
            <a href="<?php echo $podcastsUrl; ?>" class="sidebar__menu_box full-width flex align_items podcasts"<?php echo $podcastsAria; ?>>
                <span class="podcasts flex align_items"><?php echo render_icon('podcast', true, 'themes/default/icons/podcast-c1bea17a82.svg');?></span>
                <?php echo customLang('menu_podcasts', 'Podcasts'); ?>
            </a>
            <?php endif; ?>
            <?php if ($liveEnabled): ?>
            <?php
                $livesUrl = isset($base_url) ? iN_HelpSecure(rtrim((string)$base_url, '/') . '/lives') : '/lives';
                $livesAria = ($currentLayout === 'lives.php') ? ' aria-current="page"' : '';
            ?>
            <a href="<?php echo $livesUrl; ?>" class="sidebar__menu_box full-width flex align_items lives"<?php echo $livesAria; ?>">
                <span class="lives flex align_items"><?php echo render_icon('live', true);?></span>
                <?php echo customLang('menu_lives'); ?>
            </a>
            <?php endif; ?>
            <?php if ($audioRoomsEnabledNav): ?>
            <?php
                $audioRoomsUrl = isset($base_url) ? iN_HelpSecure(rtrim((string)$base_url, '/') . '/audio-rooms') : '/audio-rooms';
                $audioRoomsAria = ($currentLayout === 'audio_rooms.php' || $currentLayout === 'audio_room.php') ? ' aria-current="page"' : '';
            ?>
            <a href="<?php echo $audioRoomsUrl; ?>" class="sidebar__menu_box full-width flex align_items audio_rooms"<?php echo $audioRoomsAria; ?>">
                <span class="audio_rooms flex align_items"><?php echo render_icon('podcast', true, 'themes/default/icons/podcast-c1bea17a82.svg');?></span>
                <?php echo customLang('menu_audio_rooms', 'Audio Rooms'); ?>
            </a>
            <?php endif; ?>

            <div class="arrow flex full-width"></div>

            <!-- 🔹 Social and community -->
            <a href="<?php echo $base_url;?>our_creators" class="sidebar__menu_box full-width flex align_items creators">
                <span class="creators flex align_items"><?php echo render_icon('creator_icon', true);?></span>
                <?php echo customLang('menu_our_creators'); ?>
            </a>
            <?php if (!$hideMessagesShortcut): ?>
            <?php
                $messagesUrl = isset($base_url) ? iN_HelpSecure(rtrim((string)$base_url, '/') . '/messages') : '/messages';
                $messagesAria = ($currentLayout === 'messages.php') ? ' aria-current="page"' : '';
            ?>
            <a href="<?php echo $messagesUrl; ?>" class="sidebar__menu_box full-width flex align_items messages"<?php echo $messagesAria; ?>>
                <span class="messages flex align_items"><?php echo render_icon('messages', true);?></span>
                <?php echo customLang('menu_messages'); ?>
            </a>
            <?php endif; ?>
            <a href="<?php echo iN_HelpSecure($base_url.'bookmarks');?>" class="sidebar__menu_box full-width flex align_items bookmarks">
                <span class="bookmarks flex align_items"><?php echo render_icon('saved', true);?></span>
                <?php echo customLang('menu_bookmarks'); ?>
            </a>

            <div class="arrow flex full-width"></div>

            <!-- 🔹 User management -->
            <?php
                $creatorStatusRaw = isset($creatorStatus) ? strtolower((string) $creatorStatus) : 'none';
                $creatorApprovedNav = $creatorStatusRaw === 'approved';
                $settingsDashboardUrl = iN_HelpSecure(rtrim((string) $base_url, '/') . '/settings?tab=dashboard');
            ?>
            <?php if ($creatorApprovedNav): ?>
            <a href="<?php echo $settingsDashboardUrl; ?>" class="sidebar__menu_box full-width flex align_items dashboard_user"<?php echo ($currentLayout === 'settings.php' && (isset($_GET['tab']) && $_GET['tab'] === 'dashboard')) ? ' aria-current="page"' : ''; ?>>
                <span class="dashboard_user flex align_items"><?php echo render_icon('dashboard_user', true);?></span>
                <?php echo customLang('menu_dashboard'); ?>
            </a>
            <div class="arrow flex full-width"></div>
            <?php else: ?>
            <div class="arrow flex full-width"></div>
            <?php endif; ?>

            <!-- 🔹 Extra services -->
            <a href="<?php echo iN_HelpSecure($base_url);?>premium" class="sidebar__menu_box full-width flex align_items premium">
                <span class="premium flex align_items"><?php echo render_icon('unlocked', true);?></span>
                <?php echo customLang('menu_premium'); ?>
            </a>
            <?php if ($ebooksEnabledNav): ?>
            <a href="<?php echo iN_HelpSecure(rtrim((string) $base_url, '/') . '/ebooks');?>" class="sidebar__menu_box full-width flex align_items ebooks"<?php echo ($currentLayout === 'ebooks.php') ? ' aria-current="page"' : ''; ?>>
                <span class="ebooks flex align_items"><?php echo render_icon('ebook', true);?></span>
                <?php echo customLang('menu_ebooks', 'eBooks'); ?>
            </a>
            <a href="<?php echo iN_HelpSecure(rtrim((string) $base_url, '/') . '/my-library');?>" class="sidebar__menu_box full-width flex align_items ebook_library"<?php echo ($currentLayout === 'ebook_library.php') ? ' aria-current="page"' : ''; ?>>
                <span class="ebook_library flex align_items"><?php echo render_icon('ebook', true);?></span>
                <?php echo customLang('menu_ebook_library', 'My Library'); ?>
            </a>
            <?php endif; ?>
            <?php if (!empty($enableAds)): ?>
            <a href="<?php echo iN_HelpSecure($base_url);?>advertisements" class="sidebar__menu_box full-width flex align_items addvertisements">
                <span class="messages flex align_items"><?php echo render_icon('trending', true);?></span>
                <?php echo customLang('menu_advertisements'); ?>
            </a>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <!---->
        <?php if ($isLoggedIn && !$isGuestFeed): ?>
        <div class="sidebar__footer full-width flex align_items flexBoxColumn">
            <!---->
            <div class="sidebar__menu_box full-width flex align_items list_menu more_menu">
                <span class="list_menu flex align_items"><?php echo render_icon('list_menu', true);?></span>
                <?php echo customLang('menu_more'); ?>
            </div>
            <!---->
            <!---->
            <div class="sidebar_hide_more_menu_box flex align_items flexBoxColumn full-width none">
                <a href="<?php echo iN_HelpSecure($base_url.'settings');?> " class="sidebar__menu_box full-width flex align_items settings">
                    <span class="settings flex align_items"><?php echo render_icon('settings', true);?></span>
                    <?php echo customLang('menu_settings'); ?>
                </a>
                <?php
                    $activityBase = isset($base_url) ? rtrim((string) $base_url, '/') : '';
                    $activityLink = $activityBase !== '' ? $activityBase . '/activity' : 'activity';
                ?>
                <a href="<?php echo iN_HelpSecure($activityLink); ?>" class="sidebar__menu_box full-width flex align_items activity"<?php echo ($currentLayout === 'activity.php') ? ' aria-current="page"' : ''; ?>>
                    <span class="activity flex align_items"><?php echo render_icon('activity', true);?></span>
                    <?php echo customLang('menu_your_activity'); ?>
                </a>
                <button type="button" class="sidebar__menu_box full-width flex align_items switch_apperange">
                    <span class="switch_apperange flex align_items"><?php echo render_icon('switch_apperange', true);?></span>
                    <?php echo customLang('menu_switch_appearance'); ?>
                </button>
                <?php
                    $languageSwitcherContext = [
                        'button_classes' => 'sidebar__menu_box full-width flex align_items',
                        'label_class' => 'sidebar__menu_lang_label',
                    ];
                    include __DIR__ . '/../partials/language_switcher.php';
                    unset($languageSwitcherContext);
                ?>
                <?php if ($ebooksEnabledNav): ?>
                <a href="<?php echo iN_HelpSecure(rtrim((string) $base_url, '/') . '/ebooks');?>" class="sidebar__menu_box full-width flex align_items ebooks sidebar_mobile_more_only"<?php echo ($currentLayout === 'ebooks.php') ? ' aria-current="page"' : ''; ?>>
                    <span class="ebooks flex align_items"><?php echo render_icon('ebook', true);?></span>
                    <?php echo customLang('menu_ebooks', 'eBooks'); ?>
                </a>
                <a href="<?php echo iN_HelpSecure(rtrim((string) $base_url, '/') . '/my-library');?>" class="sidebar__menu_box full-width flex align_items ebook_library sidebar_mobile_more_only"<?php echo ($currentLayout === 'ebook_library.php') ? ' aria-current="page"' : ''; ?>>
                    <span class="ebook_library flex align_items"><?php echo render_icon('ebook', true);?></span>
                    <?php echo customLang('menu_ebook_library', 'My Library'); ?>
                </a>
                <?php endif; ?>
                <?php if (!empty($enableAds)): ?>
                <a href="<?php echo iN_HelpSecure($base_url);?>advertisements" class="sidebar__menu_box full-width flex align_items addvertisements sidebar_mobile_more_only">
                    <span class="messages flex align_items"><?php echo render_icon('trending', true);?></span>
                    <?php echo customLang('menu_advertisements'); ?>
                </a>
                <?php endif; ?>
                <div class="arrow flex full-width"></div>
                <a href="<?php echo iN_HelpSecure(($base_url ?? '/') . 'logout.php', false); ?>" class="sidebar__menu_box full-width flex align_items logout">
                    <span class="logout flex align_items"><?php echo render_icon('logout', true);?></span>
                    <?php echo customLang('menu_logout'); ?>
                </a>
            </div>
            <!---->
            <!---->
            <a href="<?php echo iN_HelpSecure($base_url.'profile/'.$dataUsername);?>" class="sidebar__menu_box full-width flex align_items profile">
                <span class="profile flex align_items">
                    <?php $___alt = sprintf(customLang('alt_avatar_of_user'), ($dataUserFullName ?: $dataUsername)); ?>
                    <img class="avatar" src="<?php echo iN_HelpSecure($defaultUserAvatar);?>" alt="<?php echo iN_HelpSecure($___alt); ?>">
                </span>
                <?php echo customLang('menu_profile'); ?>
            </a>
            <?php if ($walletTopupMenuEnabled): ?>
            <button type="button" class="sidebar__menu_box full-width flex align_items walletTopup">
                <span class="walletTopup flex align_items"><?php echo render_icon('bank', true);?></span>
                <?php echo customLang('wallet_topup_button_label', 'Top up'); ?>
            </button>
            <?php endif; ?>
            <!---->
        </div>
        <?php endif; ?>
        <!---->
    </div>
</div>
