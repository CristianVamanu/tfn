<?php
$isRTLLocale = isset($isRTLLocale) ? (bool) $isRTLLocale : false;
$currentLocale = strtolower((string)($currentLang ?? 'eng'));
$pageCsrfToken = htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8');

$requestedUid = isset($_GET['uid']) ? (int) $_GET['uid'] : 0;
$requestedToken = isset($_GET['token']) ? trim((string) $_GET['token']) : '';

$resetRecord = null;
if ($requestedUid > 0 && $requestedToken !== '' && isset($RL) && is_object($RL) && method_exists($RL, 'RL_FindValidPasswordReset')) {
    $resetRecord = $RL->RL_FindValidPasswordReset($requestedUid, $requestedToken);
}
$resetValid = is_array($resetRecord);
?>
<!doctype html>
<html lang="<?php echo htmlspecialchars($currentLocale, ENT_QUOTES, 'UTF-8'); ?>" dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-theme="auto">
  <head>
    <title><?php echo customLang('reset_password_title', 'Reset password'); ?> – <?php echo iN_HelpSecure($siteName ?? ''); ?></title>
    <?php include "head/meta.php";?>
    <?php include "head/css.php";?>
    <?php include "head/js.php";?>
  </head>
  <body class="<?php echo $isRTLLocale ? 'rtl-locale' : ''; ?>" dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>" data-logged-in="<?php echo (isset($loggedIn) && $loggedIn === '1') ? '1' : '0'; ?>">
    <section class="hero login-page wrapper">
      <div class="login-container">
        <a
          class="site-logo"
          href="<?php echo iN_HelpSecure($base_url ?? 'index', false); ?>"
          data-aos="fade-down"
          data-aos-easing="linear"
          data-aos-duration="650"
        >
          <?php echo iN_HelpSecure($siteName ?? ''); ?>
        </a>
        <div class="auth_language_switcher_wrapper">
          <?php
            $languageSwitcherContext = [
                'button_classes' => 'auth_language_switcher flex align_items',
                'label_class' => 'auth_language_switcher__label',
            ];
            include __DIR__ . '/partials/language_switcher.php';
            unset($languageSwitcherContext);
          ?>
        </div>

        <?php if ($resetValid): ?>
        <form
          class="login-form relative reset-password-form"
          action="request/requests.php"
          method="POST"
          data-aos="zoom-in-up"
          data-aos-easing="linear"
          data-aos-duration="650"
          data-error-required="<?php echo iN_HelpSecure(customLang('please_fill_all_fields')); ?>"
          data-error-mismatch="<?php echo iN_HelpSecure(customLang('reset_password_error_mismatch', 'Passwords do not match.')); ?>"
          data-error-strength="<?php echo iN_HelpSecure(customLang('reset_password_error_strength', 'Please choose a stronger password.')); ?>"
          data-error-token="<?php echo iN_HelpSecure(customLang('reset_password_error_token', 'The reset link is invalid or has expired.')); ?>"
          data-error-unexpected="<?php echo iN_HelpSecure(customLang('unexpected_error_occurred', 'Unexpected error occurred.')); ?>"
          data-success-message="<?php echo iN_HelpSecure(customLang('reset_password_success', 'Your password has been updated. You can now sign in.')); ?>"
          data-success="<?php echo iN_HelpSecure(customLang('reset_password_success', 'Your password has been updated. You can now sign in.')); ?>"
          data-loading-text="<?php echo iN_HelpSecure(customLang('processing', 'Processing...')); ?>"
        >
          <input type="hidden" name="csrf_token" value="<?php echo $pageCsrfToken; ?>" />
          <input type="hidden" name="p" value="reset_password_submit" />
          <input type="hidden" name="uid" value="<?php echo (int) $requestedUid; ?>" />
          <input type="hidden" name="token" value="<?php echo htmlspecialchars($requestedToken, ENT_QUOTES, 'UTF-8'); ?>" />

          <div class="login-form-not">
            <h2 class="marker-animation" data-ma_color="#FF6F61">
              <?php echo customLang('reset_password_title', 'Reset password'); ?>
            </h2>
            <p>
              <?php echo customLang('reset_password_description', 'Choose a new password for your account. It must be at least 8 characters and include upper, lower, and numbers or symbols.'); ?>
            </p>
          </div>

          <div class="form-container">
            <div class="form-input-wrapper">
              <label for="new_password"><?php echo customLang('reset_password_new_label', 'New password'); ?></label>
              <input
                type="password"
                id="new_password"
                name="new_password"
                class="form-input"
                autocomplete="new-password"
                required
              />
            </div>

            <div class="form-input-wrapper">
              <label for="confirm_password"><?php echo customLang('reset_password_confirm_label', 'Confirm new password'); ?></label>
              <input
                type="password"
                id="confirm_password"
                name="confirm_password"
                class="form-input"
                autocomplete="new-password"
                required
              />
            </div>

            <div class="form-input-wrapper divid">
              <button type="submit" class="login-submit btn-hover"><?php echo customLang('reset_password_submit', 'Update password'); ?></button>
            </div>
          </div>

          <div
            id="resetSuccess"
            class="login-alert login-alert--success none"
          ></div>

          <div
            id="resetWarning"
            class="login-wraning none"
          ></div>

          <div class="form-not">
            <a href="login"><?php echo customLang('forgot_back_to_login'); ?></a>
          </div>
        </form>
        <?php else: ?>
        <div
          class="login-form relative"
          data-aos="zoom-in-up"
          data-aos-easing="linear"
          data-aos-duration="650"
        >
          <div class="login-form-not">
            <h2 class="marker-animation" data-ma_color="#F44336">
              <?php echo customLang('reset_password_title', 'Reset password'); ?>
            </h2>
            <p>
              <?php echo customLang('reset_password_error_token', 'The reset link is invalid or has expired.'); ?>
            </p>
          </div>

          <div class="form-not">
            <a href="forgot_password"><?php echo customLang('forgot_try_again_link', 'Submit another request'); ?></a>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </section>
    <!---->
    <section class="footer footer-out" id="get-started">
      <!---->
      <div class="footer-small-print">
        <div class="copyright">
          <p class="white-text">© <?php echo iN_HelpSecure($siteName);?></p>
        </div>
        <?php include __DIR__ . '/partials/footer_links.php'; ?>
      </div>
      <!---->
    </section>
    <!---->
    <?php include "head/footer_js.php";?>
    <?php $resetJsVersion = (int) @filemtime(__DIR__ . '/js/reset-password.js'); ?>
    <script src="<?php echo $themePath; ?>/js/reset-password.js?v=<?php echo iN_HelpSecure($resetJsVersion); ?>" defer></script>
  </body>
</html>
