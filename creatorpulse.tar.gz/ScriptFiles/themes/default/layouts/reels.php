<?php
if (empty($enableVideoPosts)) {
    echo '<div class="settings-placeholder">' . iN_HelpSecure(customLang('content_disabled_videos')) . '</div>';
    return;
}
?>
<div class="main-content">
  <div class="page-hero flex align_items space_between">
    <div class="page-hero__title flex align_items gap">
      <span class="page-hero__icon flex align_items_justify_content"><?php echo render_icon('video', true); ?></span>
      <div class="page-hero__text flex flexBoxColumn">
        <h1 class="page-hero__heading"><?php echo iN_HelpSecure(customLang('page_reels_heading', 'Reels')); ?></h1>
        <p class="page-hero__subheading"><?php echo iN_HelpSecure(customLang('page_reels_subheading', 'Short videos from everyone.')); ?></p>
      </div>
    </div>
  </div>
  <div class="reels_container flex align_items flexBoxColumn relative gap">
    <?php
      $videos = $RL->RL_FeedAllVideos($userID, 20, 0);
      if (!$videos) {
        $cta = '';
        if (isset($loggedIn) && $loggedIn === '1') {
          $cta = sprintf(
            '<div class="empty-state__body flex align_items flexBoxColumn gap">
                <p class="empty-state__subtitle">%s</p>
                <button type="button" class="empty-state__cta new_item" data-pop="createNew">%s</button>
            </div>',
            customLang('empty_state_create_prompt'),
            customLang('empty_state_create_button')
          );
        }

        echo sprintf(
          '<div class="empty-state flex align_items flexBoxColumn gap">'
          . '<div class="empty-state__icon flex align_items">%s</div>'
          . '<div class="empty-state__title flex align_items">%s</div>%s'
          . '</div>',
          render_icon('not_founded', true),
          customLang('empty_state_reels'),
          $cta
        );
      }
      foreach ($videos as $post) {
        $postId = $post['post_id'] ?? null;
        $postFile = $post['post_file'] ?? null;
        $postViews = $post['post_views'] ?? null;
        $postFilePath = $base_url.$postFile;
        $totalPostLike = $RL->RL_CountLikes($postId);
        $totalComment = $RL->RL_TotalComment($postId);
    ?>
      <div class="reels_post_wrapper_reels relative getFullPost" data-post-id="<?php echo iN_HelpSecure($postId);?>">
        <img class="post-media" src="<?php echo $RL->videoThumbNail($postFilePath);?>" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
        <!---->
        <div class="tile-overlay flex align_items" aria-hidden="true">    <span class="metric metric-like flex align_items"><span class="metric-icon flex align_items"><?php echo render_icon('post_liked', true);?></span><span class="metric-value flex align_items"><?php echo iN_HelpSecure($totalPostLike);?></span></span>    <span class="metric metric-comment flex align_items"><span class="metric-icon flex align_items"><?php echo render_icon('post_commented', true);?></span><span class="metric-value flex align_items"><?php echo iN_HelpSecure($totalComment);?></span></span>  </div>
        <!---->
        <!---->
        <div class="tile-total-view flex align_items">
          <div class="view-svg flex align_items"><?php echo renderVerifiedBadge(($iconPath ?? '') . 'view.svg', true);?></div>
          <div class="view-total flex align_items"><?php echo iN_HelpSecure($postViews);?></div>
        </div>
        <!---->
      </div>
    <?php } ?>
  </div>
</div>

<?php $themePathExplore = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme);?>

<script defer src="<?php echo $themePathExplore; ?>/js/getPost.js"></script>
