<?php
declare(strict_types=1);

$includeAgoraAudioRoom = true;
$viewerId = isset($userID) ? (int) $userID : 0;
$roomId = isset($_GET['audio_room_id']) ? (int) $_GET['audio_room_id'] : 0;
$audioRoomsEnabledPage = isset($audioRoomsEnabled)
    ? (bool) $audioRoomsEnabled
    : (bool) ($GLOBALS['audioRoomsEnabled'] ?? false);
$audioRoomChatEnabledPage = isset($audioRoomChatEnabled)
    ? (bool) $audioRoomChatEnabled
    : (bool) ($GLOBALS['audioRoomChatEnabled'] ?? true);

$room = null;
$canView = false;
$canJoin = false;
$joinReason = 'room_not_found';
if ($audioRoomsEnabledPage && $roomId > 0 && isset($RL) && method_exists($RL, 'RL_GetAudioRoomById')) {
    try {
        $room = $RL->RL_GetAudioRoomById($roomId);
        $canView = $room && method_exists($RL, 'RL_UserCanViewAudioRoom') && $RL->RL_UserCanViewAudioRoom($viewerId, $room);
        if ($canView && method_exists($RL, 'RL_UserCanJoinAudioRoom')) {
            $joinAccess = $RL->RL_UserCanJoinAudioRoom($viewerId, $roomId);
            $canJoin = !empty($joinAccess['ok']);
            $joinReason = (string)($joinAccess['reason'] ?? ($canJoin ? 'ok' : 'not_allowed'));
        }
    } catch (Throwable $__) {
        $room = null;
    }
}

$baseUrl = isset($base_url) ? rtrim((string)$base_url, '/') : '';
$csrfToken = function_exists('generateCsrfToken') ? generateCsrfToken() : '';
$currencyCode = strtoupper((string)($paymentsCurrency ?? $currency ?? 'USD'));
$audioRoomFormatPrice = static function ($amount, string $code) {
    if (function_exists('dz_format_currency')) {
        return dz_format_currency((float)$amount, $code);
    }
    return strtoupper($code) . ' ' . rtrim(rtrim(number_format((float)$amount, 2, '.', ''), '0'), '.');
};
?>
<div class="main-content flex align_items">
    <div class="content-area flex">
        <div class="content-left">
            <div class="content-left-container flex align_items flexBoxColumn audio-room-page">
                <?php if (!$audioRoomsEnabledPage): ?>
                    <div class="empty-state flex align_items flexBoxColumn gap">
                        <div class="empty-state__icon flex align_items"><?php echo render_icon('not_founded', true); ?></div>
                        <div class="empty-state__title flex align_items"><?php echo iN_HelpSecure(customLang('audio_room_disabled_hint', 'Audio rooms are currently disabled.'), false); ?></div>
                    </div>
                <?php elseif (!$room || !$canView): ?>
                    <div class="empty-state flex align_items flexBoxColumn gap">
                        <div class="empty-state__icon flex align_items"><?php echo render_icon('not_founded', true); ?></div>
                        <div class="empty-state__title flex align_items"><?php echo iN_HelpSecure(customLang('audio_room_not_found', 'Audio room not found.'), false); ?></div>
                    </div>
                <?php else:
                    $ownerId = (int)($room['owner_id'] ?? 0);
                    $status = strtolower((string)($room['status'] ?? 'created'));
                    $title = trim((string)($room['title'] ?? ''));
                    $description = trim((string)($room['description'] ?? ''));
                    $ownerUsername = (string)($room['username'] ?? '');
                    $ownerFullname = (string)($room['user_fullname'] ?? '');
                    $displayName = $ownerFullname !== '' ? $ownerFullname : $ownerUsername;
                    $avatarPath = (string)($room['user_avatar'] ?? '');
                    if ($avatarPath === '') {
                        $avatarPath = 'uploads/avatars/default_avatar.png';
                    }
                    $avatarUrl = function_exists('storage_resolve_media_url')
                        ? storage_resolve_media_url($avatarPath, (string)($base_url ?? ''))
                        : $baseUrl . '/' . ltrim($avatarPath, '/');
                    $profileUrl = $baseUrl . ($ownerUsername !== '' ? '/profile/' . rawurlencode($ownerUsername) : '/');
                    $isOwner = $viewerId > 0 && $viewerId === $ownerId;
                    $isModerator = $viewerId > 0 && isset($RL) && method_exists($RL, 'RL_IsAudioRoomModerator') && $RL->RL_IsAudioRoomModerator($roomId, $viewerId);
                    $isSpeaker = $viewerId > 0 && isset($RL) && method_exists($RL, 'RL_IsAudioRoomSpeaker') && $RL->RL_IsAudioRoomSpeaker($roomId, $viewerId);
                    $canManageRoom = $isOwner || $isModerator;
                    $initialRole = $isOwner ? 'host' : ($isModerator ? 'moderator' : ($isSpeaker ? 'speaker' : 'listener'));
                    $isPaid = (int)($room['is_paid'] ?? 0) === 1;
                    $price = $room['entry_price'] ?? null;
                    $roomCurrency = strtoupper((string)($room['currency'] ?? $currencyCode));
                    $autoEndAt = isset($room['auto_end_at']) ? (int)$room['auto_end_at'] : 0;
                    $serverNow = time();
                    $listenerCount = isset($RL) && method_exists($RL, 'RL_CountAudioRoomParticipants') ? $RL->RL_CountAudioRoomParticipants($roomId, time() - 30, ['listener']) : 0;
                    $speakerCount = isset($RL) && method_exists($RL, 'RL_CountAudioRoomParticipants') ? $RL->RL_CountAudioRoomParticipants($roomId, time() - 30, ['host','moderator','speaker']) : 0;
                    $initialMessages = [];
                    if ($audioRoomChatEnabledPage && isset($RL) && method_exists($RL, 'RL_GetAudioRoomMessagesSince')) {
                        try {
                            $initialMessages = $RL->RL_GetAudioRoomMessagesSince($roomId, 0, 30);
                        } catch (Throwable $__) {
                            $initialMessages = [];
                        }
                    }
                ?>
                <section
                    class="audio-room-stage full-width"
                    data-room-id="<?php echo $roomId; ?>"
                    data-room-status="<?php echo htmlspecialchars($status, ENT_QUOTES, 'UTF-8'); ?>"
                    data-can-join="<?php echo $canJoin ? '1' : '0'; ?>"
                    data-join-reason="<?php echo htmlspecialchars($joinReason, ENT_QUOTES, 'UTF-8'); ?>"
                    data-role="<?php echo htmlspecialchars($initialRole, ENT_QUOTES, 'UTF-8'); ?>"
                    data-chat-enabled="<?php echo $audioRoomChatEnabledPage ? '1' : '0'; ?>"
                    data-owner-id="<?php echo (int)$ownerId; ?>"
                    data-viewer-id="<?php echo (int)$viewerId; ?>"
                    data-auto-join="<?php echo ($canJoin && $isOwner && $status !== 'ended') ? '1' : '0'; ?>"
                    data-currency="<?php echo htmlspecialchars($roomCurrency, ENT_QUOTES, 'UTF-8'); ?>"
                    data-auto-end-at="<?php echo (int)$autoEndAt; ?>"
                    data-server-time="<?php echo (int)$serverNow; ?>"
                    data-audio-rooms-url="<?php echo htmlspecialchars($baseUrl . '/audio-rooms', ENT_QUOTES, 'UTF-8'); ?>"
                >
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
                    <div class="audio-room-stage__header">
                        <div class="audio-room-stage__identity">
                            <div class="audio-room-stage__pulse" aria-hidden="true"><?php echo render_icon('podcast', true); ?></div>
                            <div class="audio-room-stage__copy">
                                <div class="audio-room-stage__badges">
                                    <span class="audio-room-badge audio-room-badge--<?php echo htmlspecialchars($status, ENT_QUOTES, 'UTF-8'); ?>">
                                        <?php echo iN_HelpSecure($status === 'live' ? customLang('audio_room_live_badge', 'LIVE') : customLang('audio_room_open_badge', 'OPEN'), false); ?>
                                    </span>
                                    <?php if ($isPaid): ?>
                                        <span class="audio-room-badge audio-room-badge--paid">
                                            <?php echo htmlspecialchars($audioRoomFormatPrice((float)$price, $roomCurrency), ENT_QUOTES, 'UTF-8'); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <h1><?php echo htmlspecialchars($title !== '' ? $title : customLang('audio_room_untitled', 'Audio room'), ENT_QUOTES, 'UTF-8'); ?></h1>
                                <?php if ($description !== ''): ?>
                                    <p><?php echo htmlspecialchars($description, ENT_QUOTES, 'UTF-8'); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="audio-room-stage__actions">
                            <?php if ($canManageRoom && $status !== 'ended'): ?>
                                <button type="button" class="audio-room-action audio-room-action--danger" data-audio-room-end>
                                    <?php echo iN_HelpSecure(customLang('audio_room_end_button', 'End room'), false); ?>
                                </button>
                            <?php endif; ?>
                            <?php if ($viewerId <= 0): ?>
                                <a class="audio-room-action" href="<?php echo iN_HelpSecure($baseUrl . '/login', false); ?>">
                                    <?php echo iN_HelpSecure(customLang('login'), false); ?>
                                </a>
                            <?php elseif ($isPaid && !$canJoin && $joinReason === 'ticket_required'): ?>
                                <button type="button" class="audio-room-action" disabled>
                                    <?php echo iN_HelpSecure(customLang('audio_room_ticket_required', 'Ticket required'), false); ?>
                                </button>
                            <?php elseif ($status === 'ended'): ?>
                                <button type="button" class="audio-room-action" disabled>
                                    <?php echo iN_HelpSecure(customLang('audio_room_ended', 'Ended'), false); ?>
                                </button>
                            <?php else: ?>
                                <button type="button" class="audio-room-action" data-audio-room-join>
                                    <?php echo iN_HelpSecure(customLang('audio_room_join_button', 'Join room'), false); ?>
                                </button>
                                <button type="button" class="audio-room-action audio-room-action--ghost none" data-audio-room-leave>
                                    <?php echo iN_HelpSecure(customLang('audio_room_leave_button', 'Leave'), false); ?>
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if ($autoEndAt > 0 && $status !== 'ended'): ?>
                    <div class="audio-room-countdown" data-audio-room-countdown>
                        <span><?php echo iN_HelpSecure(customLang('audio_room_time_remaining', 'Time remaining'), false); ?></span>
                        <strong data-audio-room-countdown-value>--:--</strong>
                    </div>
                    <?php endif; ?>

                    <div class="audio-room-stage__host">
                        <a class="audio-room-stage__avatar" href="<?php echo iN_HelpSecure($profileUrl, false); ?>">
                            <img src="<?php echo htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($displayName ?: $ownerUsername ?: 'creator', ENT_QUOTES, 'UTF-8'); ?>">
                        </a>
                        <div>
                            <span><?php echo iN_HelpSecure(customLang('audio_room_host_label', 'Host'), false); ?></span>
                            <a href="<?php echo iN_HelpSecure($profileUrl, false); ?>"><?php echo htmlspecialchars($displayName ?: ('@' . $ownerUsername), ENT_QUOTES, 'UTF-8'); ?></a>
                        </div>
                    </div>

                    <div class="audio-room-stage__meters">
                        <div class="audio-room-meter">
                            <strong data-audio-room-speakers><?php echo (int)$speakerCount; ?></strong>
                            <span><?php echo iN_HelpSecure(customLang('audio_room_speakers_short', 'speakers'), false); ?></span>
                        </div>
                        <div class="audio-room-meter">
                            <strong data-audio-room-listeners><?php echo (int)$listenerCount; ?></strong>
                            <span><?php echo iN_HelpSecure(customLang('audio_room_listeners_short', 'listeners'), false); ?></span>
                        </div>
                        <div class="audio-room-meter">
                            <strong data-audio-room-role><?php echo htmlspecialchars(ucfirst($initialRole), ENT_QUOTES, 'UTF-8'); ?></strong>
                            <span><?php echo iN_HelpSecure(customLang('audio_room_role_label', 'role'), false); ?></span>
                        </div>
                    </div>

                    <div class="audio-room-stage__controls">
                        <button type="button" class="audio-room-control" data-audio-room-mic disabled>
                            <?php echo render_icon('podcast', true); ?>
                            <span data-audio-room-mic-label><?php echo iN_HelpSecure(customLang('audio_room_join_to_use_mic', 'Join to use mic'), false); ?></span>
                        </button>
                        <button type="button" class="audio-room-control" data-audio-room-speaker-request disabled>
                            <?php echo render_icon('make_user', true); ?>
                            <span><?php echo iN_HelpSecure(customLang('audio_room_request_speak', 'Request to speak'), false); ?></span>
                        </button>
                        <button type="button" class="audio-room-control" data-audio-room-tip <?php echo $viewerId > 0 && $viewerId !== $ownerId && $canJoin ? '' : 'disabled'; ?>>
                            <?php echo render_icon('super_thanks', true); ?>
                            <span><?php echo iN_HelpSecure(customLang('audio_room_tip_button', 'Tip'), false); ?></span>
                        </button>
                        <?php if ($audioRoomChatEnabledPage): ?>
                        <button type="button" class="audio-room-control audio-room-control--chat" data-audio-room-chat-toggle aria-expanded="false">
                            <?php echo render_icon('messages', true); ?>
                            <span><?php echo iN_HelpSecure(customLang('audio_room_chat_button', 'Room chat'), false); ?></span>
                            <i class="audio-room-control__dot none" data-audio-room-chat-dot aria-hidden="true"></i>
                        </button>
                        <?php endif; ?>
                    </div>

                    <div class="audio-room-status-line" data-audio-room-status-line>
                        <?php echo iN_HelpSecure($canJoin ? customLang('audio_room_ready_hint', 'Ready to join.') : customLang('audio_room_locked_hint', 'Join is currently restricted.'), false); ?>
                    </div>

                    <div class="audio-room-ended-modal none" data-audio-room-ended-modal>
                        <div class="audio-room-ended-modal__panel">
                            <strong data-audio-room-ended-title><?php echo iN_HelpSecure(customLang('audio_room_ended_title', 'Room ended'), false); ?></strong>
                            <span data-audio-room-ended-message><?php echo iN_HelpSecure(customLang('audio_room_ended_message', 'This audio room has ended.'), false); ?></span>
                            <em><b data-audio-room-ended-countdown>5</b> <?php echo iN_HelpSecure(customLang('audio_room_redirect_seconds', 'seconds'), false); ?></em>
                        </div>
                    </div>
                </section>

                <?php if ($viewerId > 0 && $viewerId !== $ownerId && $canJoin): ?>
                <section class="audio-room-tip-sheet full-width none" data-audio-room-tip-sheet>
                    <div class="audio-room-ticket__copy">
                        <strong><?php echo iN_HelpSecure(customLang('audio_room_tip_sheet_title', 'Send a tip'), false); ?></strong>
                        <span><?php echo iN_HelpSecure(customLang('audio_room_tip_sheet_hint', 'Support the host during the room.'), false); ?></span>
                    </div>
                    <form class="audio-room-ticket__form" data-audio-room-tip-form>
                        <input type="number" min="1" max="500" step="1" value="5" class="text-field" data-audio-room-tip-amount>
                        <select class="text-field" data-audio-room-tip-provider>
                            <option value="wallet"><?php echo iN_HelpSecure(customLang('wallet', 'Wallet'), false); ?></option>
                            <option value="stripe">Stripe</option>
                            <option value="paypal">PayPal</option>
                            <option value="nowpayments">NOWPayments</option>
                            <option value="coinbase">Coinbase</option>
                            <option value="flutterwave">Flutterwave</option>
                            <option value="paystack">Paystack</option>
                            <option value="iyzico">Iyzico</option>
                            <option value="payu">PayU</option>
                        </select>
                        <button type="submit" class="audio-room-action">
                            <?php echo iN_HelpSecure(customLang('audio_room_tip_send', 'Send tip'), false); ?>
                        </button>
                    </form>
                </section>
                <?php endif; ?>

                <?php if ($viewerId > 0 && $isPaid && !$canJoin && $joinReason === 'ticket_required' && $status !== 'ended'): ?>
                <section class="audio-room-ticket full-width" data-audio-room-ticket>
                    <div class="audio-room-ticket__copy">
                        <strong><?php echo iN_HelpSecure(customLang('audio_room_ticket_title', 'Unlock this audio room'), false); ?></strong>
                        <span>
                            <?php echo htmlspecialchars($audioRoomFormatPrice((float)$price, $roomCurrency), ENT_QUOTES, 'UTF-8'); ?>
                        </span>
                    </div>
                    <form class="audio-room-ticket__form" data-audio-room-ticket-form>
                        <select class="text-field" data-audio-room-ticket-provider>
                            <option value="wallet"><?php echo iN_HelpSecure(customLang('wallet', 'Wallet'), false); ?></option>
                            <option value="stripe">Stripe</option>
                            <option value="paypal">PayPal</option>
                            <option value="nowpayments">NOWPayments</option>
                            <option value="coinbase">Coinbase</option>
                            <option value="flutterwave">Flutterwave</option>
                            <option value="paystack">Paystack</option>
                            <option value="iyzico">Iyzico</option>
                            <option value="payu">PayU</option>
                        </select>
                        <button type="submit" class="audio-room-action">
                            <?php echo iN_HelpSecure(customLang('audio_room_unlock_button', 'Unlock room'), false); ?>
                        </button>
                    </form>
                </section>
                <?php endif; ?>

                <?php if ($canManageRoom && $status !== 'ended'): ?>
                <section class="audio-room-manage full-width" data-audio-room-manage>
                    <div class="audio-room-manage__header">
                        <strong><?php echo iN_HelpSecure(customLang('audio_room_manage_title', 'Room management'), false); ?></strong>
                        <span data-audio-room-manage-counts><?php echo iN_HelpSecure(customLang('audio_room_manage_loading', 'Loading...'), false); ?></span>
                    </div>
                    <div class="audio-room-manage__grid">
                        <div class="audio-room-manage__panel">
                            <h2><?php echo iN_HelpSecure(customLang('audio_room_speaker_requests_title', 'Speaker requests'), false); ?></h2>
                            <div class="audio-room-manage__list" data-audio-room-speaker-requests>
                                <div class="audio-room-manage__empty"><?php echo iN_HelpSecure(customLang('audio_room_manage_loading', 'Loading...'), false); ?></div>
                            </div>
                        </div>
                        <div class="audio-room-manage__panel">
                            <h2><?php echo iN_HelpSecure(customLang('audio_room_participants_title', 'Participants'), false); ?></h2>
                            <div class="audio-room-manage__list" data-audio-room-participants>
                                <div class="audio-room-manage__empty"><?php echo iN_HelpSecure(customLang('audio_room_manage_loading', 'Loading...'), false); ?></div>
                            </div>
                        </div>
                    </div>
                </section>
                <?php endif; ?>

                <template data-audio-room-speaker-icon><?php echo render_icon('speaker', true); ?></template>
                <div class="audio-room-chat-backdrop none" data-audio-room-chat-backdrop></div>
                <aside class="audio-room-chat audio-room-chat--drawer none" data-audio-room-chat aria-hidden="true">
                    <div class="audio-room-chat__header">
                        <strong><?php echo iN_HelpSecure(customLang('audio_room_chat_title', 'Room chat'), false); ?></strong>
                        <button type="button" class="audio-room-chat__close" data-audio-room-chat-close aria-label="<?php echo iN_HelpSecure(customLang('audio_room_close_chat', 'Close chat'), false); ?>">
                            <?php echo render_icon('close', true); ?>
                        </button>
                    </div>
                    <div class="audio-room-chat__messages" data-audio-room-messages data-last-id="<?php echo $initialMessages ? (int)max(array_map(static fn($m) => (int)($m['id'] ?? 0), $initialMessages)) : 0; ?>">
                        <?php if (!$audioRoomChatEnabledPage): ?>
                            <div class="audio-room-chat__empty"><?php echo iN_HelpSecure(customLang('audio_room_chat_disabled', 'Chat is disabled for audio rooms.'), false); ?></div>
                        <?php elseif (!$initialMessages): ?>
                            <div class="audio-room-chat__empty"><?php echo iN_HelpSecure(customLang('audio_room_chat_empty', 'No messages yet.'), false); ?></div>
                        <?php else: ?>
                            <?php foreach ($initialMessages as $message):
                                $messageId = (int)($message['id'] ?? 0);
                                $messageType = (string)($message['message_type'] ?? 'chat');
                                $messageText = (string)($message['message'] ?? '');
                                $messageUser = (string)($message['user_fullname'] ?? $message['username'] ?? '');
                                if ($messageType === 'tip') {
                                    $tipMeta = [];
                                    $tipMetaRaw = (string)($message['meta_json'] ?? '');
                                    if ($tipMetaRaw !== '') {
                                        $tipDecoded = json_decode($tipMetaRaw, true);
                                        if (is_array($tipDecoded)) {
                                            $tipMeta = $tipDecoded;
                                        }
                                    }
                                    $tipAmount = isset($tipMeta['amount']) ? (float)$tipMeta['amount'] : 0.0;
                                    $tipCurrency = strtoupper((string)($tipMeta['currency'] ?? $roomCurrency));
                                    $messageText = $tipAmount > 0
                                        ? 'sent a ' . $audioRoomFormatPrice($tipAmount, $tipCurrency) . ' tip'
                                        : customLang('audio_room_tip_chat_fallback', 'sent a tip');
                                }
                            ?>
                            <div class="audio-room-chat-message<?php echo $messageType === 'tip' ? ' audio-room-chat-message--tip' : ''; ?>" data-message-id="<?php echo $messageId; ?>" data-message-type="<?php echo htmlspecialchars($messageType, ENT_QUOTES, 'UTF-8'); ?>">
                                <strong><?php echo htmlspecialchars($messageUser !== '' ? $messageUser : customLang('user', 'User'), ENT_QUOTES, 'UTF-8'); ?></strong>
                                <span><?php echo htmlspecialchars($messageText, ENT_QUOTES, 'UTF-8'); ?></span>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <?php if ($audioRoomChatEnabledPage && $viewerId > 0): ?>
                    <form class="audio-room-chat__form" data-audio-room-chat-form>
                        <input type="text" class="text-field full-width" maxlength="500" data-audio-room-chat-input placeholder="<?php echo iN_HelpSecure(customLang('audio_room_chat_placeholder', 'Write a message'), false); ?>">
                        <button type="submit" class="audio-room-chat__send"><?php echo render_icon('send', true); ?></button>
                    </form>
                    <?php endif; ?>
                </aside>
                <?php endif; ?>
            </div>
        </div>
        <div class="content-right flex align_items">
            <div class="content-right-container">
                <?php
                    include_once __DIR__ . '/widgets/suggestedUsers.php';
                    include_once __DIR__ . '/widgets/adsSidebar.php';
                    $hideMostPopularIfEmpty = true;
                    include_once __DIR__ . '/widgets/mosPopularPost.php';
                    unset($hideMostPopularIfEmpty);
                ?>
            </div>
        </div>
    </div>
</div>
