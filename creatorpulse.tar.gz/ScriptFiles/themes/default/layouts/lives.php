<?php
declare(strict_types=1);

$viewerId = isset($userID) ? (int) $userID : 0;
$lives = [];

if (isset($RL)) {
    if (method_exists($RL, 'RL_GetLiveList')) {
        try {
            $lives = $RL->RL_GetLiveList($viewerId, 12, 0, ['live', 'created']);
        } catch (Throwable $__) {
            $lives = [];
        }
    } elseif (method_exists($RL, 'RL_GetLiveById')) {
        // Fallback: fetch the latest live IDs from database if list helper is missing.
        try {
            $pdo = $RL->getDb();
            $stmt = $pdo->query('SELECT live_id FROM i_live_streams WHERE status IN (\'live\', \'created\') ORDER BY live_id DESC LIMIT 12');
            $ids = $stmt ? $stmt->fetchAll(\PDO::FETCH_COLUMN) : [];
            foreach ($ids as $id) {
                $row = $RL->RL_GetLiveById((int) $id);
                if ($row) { $lives[] = $row; }
            }
        } catch (Throwable $__) {
            $lives = [];
        }
    }
}

$baseUrl = isset($base_url) ? (string) $base_url : '';
$emptyStateMessage = customLang('lives_empty_state', 'No live streams right now');
$badgeLabel = customLang('lives_badge_live', 'LIVE');
$ctaLabel = customLang('lives_go_to_live', 'Go to live');

?>
<div class="main-content flex align_items">
    <div class="content-area flex">
        <div class="content-left">
            <div class="content-left-container flex align_items flexBoxColumn lives-page">
                <div class="page-hero flex align_items space_between full-width">
                    <div class="page-hero__title flex align_items gap">
                        <span class="page-hero__icon flex align_items_justify_content"><?php echo render_icon('live', true); ?></span>
                        <div class="page-hero__text flex flexBoxColumn">
                            <h1 class="page-hero__heading"><?php echo iN_HelpSecure(customLang('page_lives_heading', 'Lives')); ?></h1>
                            <p class="page-hero__subheading"><?php echo iN_HelpSecure(customLang('page_lives_subheading', 'Live streams happening now.')); ?></p>
                        </div>
                    </div>
                </div>
                <?php if (!$lives): ?>
                    <div class="empty-state flex align_items flexBoxColumn gap">
                        <div class="empty-state__icon flex align_items"><?php echo render_icon('not_founded', true); ?></div>
                        <div class="empty-state__title flex align_items"><?php echo iN_HelpSecure($emptyStateMessage, false); ?></div>
                    </div>
                <?php else: ?>
                    <div class="lives-grid">
                        <?php foreach ($lives as $live):
                            $liveId = (int) ($live['live_id'] ?? 0);
                            if ($liveId <= 0) { continue; }

                            $title = trim((string) ($live['title'] ?? ''));
                            $ownerId = (int) ($live['owner_id'] ?? ($live['user_id'] ?? 0));
                            $ownerUsername = (string) ($live['owner_username'] ?? ($live['username'] ?? ''));
                            $ownerFullname = (string) ($live['owner_fullname'] ?? ($live['user_fullname'] ?? ''));
                            $displayName = $ownerFullname !== '' ? $ownerFullname : $ownerUsername;

                            $coverPath = (string) ($live['cover'] ?? ($live['cover_path'] ?? ''));
                            $coverUrl = '';
                            if ($coverPath !== '') {
                                if (function_exists('storage_resolve_media_url')) {
                                    $coverUrl = storage_resolve_media_url($coverPath, $baseUrl);
                                } else {
                                    $coverUrl = rtrim($baseUrl, '/') . '/' . ltrim($coverPath, '/');
                                }
                            }

                            $avatarPath = (string) ($live['owner_avatar'] ?? ($live['user_avatar'] ?? ''));
                            if ($avatarPath === '' && isset($RL) && method_exists($RL, 'RL_userAvatar') && $ownerId > 0) {
                                try {
                                    $avatarPath = (string) $RL->RL_userAvatar($ownerId);
                                } catch (Throwable $__) {
                                    $avatarPath = '';
                                }
                            }
                            if ($avatarPath === '') {
                                $avatarPath = 'uploads/avatars/default_avatar.png';
                            }

                            if (function_exists('storage_resolve_media_url')) {
                                $avatarUrl = storage_resolve_media_url($avatarPath, $baseUrl);
                            } else {
                                $avatarUrl = rtrim($baseUrl, '/') . '/' . ltrim($avatarPath, '/');
                            }

                            $profileUrl = rtrim($baseUrl, '/') . ($ownerUsername !== '' ? '/profile/' . $ownerUsername : '/');
                            $liveUrl = rtrim($baseUrl, '/') . '/live/' . $liveId;

                            $altCover = $title !== '' ? $title : sprintf(customLang('alt_tile_by_user', 'Content by %s'), $displayName ?: $ownerUsername);
                            $altAvatar = sprintf(customLang('alt_avatar_of_user'), $displayName ?: $ownerUsername ?: 'creator');
                        ?>
                        <article class="live-card" data-live-id="<?php echo $liveId; ?>">
                            <div class="live-card__cover<?php echo $coverUrl === '' ? ' live-card__cover--fallback' : ''; ?>">
                                <?php if ($coverUrl !== ''): ?>
                                    <img src="<?php echo htmlspecialchars($coverUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo iN_HelpSecure($altCover); ?>">
                                <?php else: ?>
                                    <span class="live-card__cover-icon" aria-hidden="true"><?php echo render_icon('live', true); ?></span>
                                <?php endif; ?>
                                <span class="badge-live" aria-label="<?php echo iN_HelpSecure($badgeLabel); ?>">
                                    <span class="badge-live__icon" aria-hidden="true"><?php echo render_icon('live', true); ?></span>
                                    <span class="badge-live__label"><?php echo iN_HelpSecure($badgeLabel, false); ?></span>
                                </span>
                            </div>
                            <div class="live-card__body">
                                <a class="live-card__avatar" href="<?php echo iN_HelpSecure($profileUrl, false); ?>">
                                    <img src="<?php echo htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo iN_HelpSecure($altAvatar); ?>">
                                </a>
                                <div class="live-card__meta">
                                    <h2 class="live-card__title"><?php echo htmlspecialchars($title !== '' ? $title : customLang('live_badge_live', 'Live'), ENT_QUOTES, 'UTF-8'); ?></h2>
                                    <?php if ($ownerUsername !== ''): ?>
                                        <a class="live-card__owner" href="<?php echo iN_HelpSecure($profileUrl, false); ?>">
                                            <?php echo '@' . htmlspecialchars($ownerUsername, ENT_QUOTES, 'UTF-8'); ?>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="live-card__footer">
                                <a class="live-card__cta" href="<?php echo iN_HelpSecure($liveUrl, false); ?>">
                                    <?php echo iN_HelpSecure($ctaLabel, false); ?>
                                </a>
                            </div>
                        </article>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <!---->
        <div class="content-right flex align_items">
            <div class="content-right-container">
                <?php
                    include_once __DIR__ . '/widgets/suggestedUsers.php';
                    include_once __DIR__ . '/widgets/adsSidebar.php';
                    $hideMostPopularIfEmpty = true;
                    include_once __DIR__ . '/widgets/mosPopularPost.php';
                    unset($hideMostPopularIfEmpty);
                ?>
            </div>
        </div>
        <!---->
    </div>
</div>

<?php $themePathLives = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme); ?>
<script defer src="<?php echo $themePathLives; ?>/js/adsFeedSlots.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePathLives; ?>/js/media.viewer.js?v=<?php echo iN_HelpSecure($version);?>"></script>
