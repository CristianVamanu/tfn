<?php
// Expects: $post (array), $iconPath, $base_url
// Locals prepared by caller: $postId, $type, $displaySrc, $hasMulti, $postViews, $totalPostLike, $totalComment
?>
<div class="reels_post_wrapper relative getFullPost" data-post-id="<?php echo iN_HelpSecure($postId);?>">
  <?php
    $__cap = dzShortCaption($post ?? [], 80);
    $__u   = isset($post['owner_username']) ? (string)$post['owner_username'] : '';
    $__alt = $__cap !== '' ? $__cap : ($__u !== '' ? sprintf(customLang('alt_post_by_user'), $__u) : customLang('image_alt_generic'));
  ?>
  <img class="post-media" src="<?php echo iN_HelpSecure($displaySrc);?>" alt="<?php echo iN_HelpSecure($__alt); ?>" loading="lazy" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
  <div class="tile-overlay flex align_items" aria-hidden="true">
    <span class="metric metric-like flex align_items">
      <span class="metric-icon flex align_items"><?php echo render_icon('post_liked', true);?></span>
      <span class="metric-value flex align_items"><?php echo iN_HelpSecure($totalPostLike);?></span>
    </span>
    <span class="metric metric-comment flex align_items">
      <span class="metric-icon flex align_items"><?php echo render_icon('post_commented', true);?></span>
      <span class="metric-value flex align_items"><?php echo iN_HelpSecure($totalComment);?></span>
    </span>
  </div>
  <div class="tile-total-view flex align_items">
    <div class="view-svg flex align_items"><?php echo renderVerifiedBadge(($iconPath ?? '') . 'view.svg', true);?></div>
    <div class="view-total flex align_items"><?php echo iN_HelpSecure((int)$postViews);?></div>
  </div>
  <?php if ($type === 'image' && $hasMulti): ?>
    <div class="multi-image-indicator flex align_items" aria-label="<?php echo iN_HelpSecure(customLang('media_multi_image_indicator')); ?>">
      <?php echo renderVerifiedBadge(($iconPath ?? '') . 'plus_image.svg', true); ?>
    </div>
  <?php endif; ?>
</div>
