<div class="main-content">
  <div class="content-area flex">
    <!---->
    <div class="content-left">
      <div class="content-left-container flex align_items flexBoxColumn">
        <div
          class="reels_container flex align_items flexBoxColumn relative gap"
          id="images-feed"
          data-limit="<?php echo iN_HelpSecure($pageScrollLimit);?>"
          data-offset="<?php echo iN_HelpSecure($pageScrollLimit);?>">
          <?php
            $items = $RL->RL_FeedBookmarksMixed($userID, $pageScrollLimit, 0);
            if (!$items) {
              $cta = '';
              if (isset($loggedIn) && $loggedIn === '1') {
                $cta = sprintf(<<<HTML
<div class="empty-state__body flex align_items flexBoxColumn gap">
    <p class="empty-state__subtitle">%s</p>
    <button type="button" class="empty-state__cta new_item" data-pop="createNew">%s</button>
</div>
HTML,
                  customLang('empty_state_create_prompt'),
                  customLang('empty_state_create_button')
                );
              }

              echo sprintf(
                '<div class="empty-state flex align_items flexBoxColumn gap">'
                . '<div class="empty-state__icon flex align_items">%s</div>'
                . '<div class="empty-state__title flex align_items">%s</div>%s'
                . '</div>',
                render_icon('not_founded', true),
                customLang('empty_state_bookmarks'),
                $cta
              );
            }

            foreach ($items as $post) {
              $postId       = (int) ($post['post_id'] ?? 0);
              $type         = (string) ($post['post_type'] ?? 'image');
              $displaySrc   = '';
              if ($type === 'video') {
                  $videoPath = function_exists('storage_resolve_media_url')
                      ? storage_resolve_media_url((string)($post['post_file'] ?? ''), $base_url ?? '')
                      : ((string)($base_url ?? '') . ltrim((string)($post['post_file'] ?? ''), '/'));
                  $displaySrc = $RL->videoThumbNail($videoPath);
              } else {
                  $firstImage = $post['first_image'] ?? ($post['post_file'] ?? '');
                  $displaySrc = function_exists('storage_resolve_media_url')
                      ? storage_resolve_media_url((string)$firstImage, $base_url ?? '')
                      : ((string)($base_url ?? '') . ltrim((string)$firstImage, '/'));
              }
              $hasMulti     = !empty($post['has_multiple_images']);
              $postViews    = (int) ($post['post_views'] ?? 0);
              $totalPostLike= $RL->RL_CountLikes($postId);
              $totalComment = $RL->RL_TotalComment($postId);
          ?>
            <div class="reels_post_wrapper relative getFullPost" data-post-id="<?php echo iN_HelpSecure($postId);?>">
              <?php
                $__cap = dzShortCaption($post ?? [], 80);
                $__u   = isset($post['owner_username']) ? (string)$post['owner_username'] : '';
                $__alt = $__cap !== '' ? $__cap : ($__u !== '' ? sprintf(customLang('alt_post_by_user'), $__u) : customLang('image_alt_generic'));
              ?>
              <img class="post-media" src="<?php echo iN_HelpSecure($displaySrc);?>" alt="<?php echo iN_HelpSecure($__alt); ?>" loading="lazy" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
              <div class="tile-overlay flex align_items" aria-hidden="true">
                <span class="metric metric-like flex align_items">
                  <span class="metric-icon flex align_items"><?php echo render_icon('post_liked', true);?></span>
                  <span class="metric-value flex align_items"><?php echo iN_HelpSecure($totalPostLike);?></span>
                </span>
                <span class="metric metric-comment flex align_items">
                  <span class="metric-icon flex align_items"><?php echo render_icon('post_commented', true);?></span>
                  <span class="metric-value flex align_items"><?php echo iN_HelpSecure($totalComment);?></span>
                </span>
              </div>

              <div class="tile-total-view flex align_items">
                <div class="view-svg flex align_items"><?php echo renderVerifiedBadge(($iconPath ?? '') . 'view.svg', true);?></div>
                <div class="view-total flex align_items"><?php echo iN_HelpSecure((int)$postViews);?></div>
              </div>

              <?php if ($type === 'image' && $hasMulti): ?>
                <div class="multi-image-indicator flex align_items" aria-label="<?php echo iN_HelpSecure(customLang('media_multi_image_indicator')); ?>">
                  <?php echo renderVerifiedBadge(($iconPath ?? '') . 'plus_image.svg', true); ?>
                </div>
              <?php endif; ?>
            </div>
          <?php } ?>

          <div id="images-infinite-sentinel" aria-hidden="true"></div>
        </div>
      </div>
    </div>
    <!---->
    <div class="content-right flex align_items">
      <div class="content-right-container">
        <?php
          include_once __DIR__ . '/widgets/suggestedUsers.php';
          include_once __DIR__ . '/widgets/adsSidebar.php';
          $hideMostPopularIfEmpty = true;
          include_once __DIR__ . '/widgets/mosPopularPost.php';
          unset($hideMostPopularIfEmpty);
        ?>
      </div>
    </div>
    <!---->
  </div>
</div>

<?php $themePathExplore = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme);?>

<div id="images-loading" class="none" aria-live="polite"><?php echo customLang('ui_loading'); ?></div>

<script defer src="<?php echo $themePathExplore; ?>/js/getMoreBookMarks.js"></script>
<script defer src="<?php echo $themePathExplore; ?>/js/getPost.js"></script>
<script defer src="<?php echo $themePathExplore; ?>/js/adsFeedSlots.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePathExplore; ?>/js/media.viewer.js?v=<?php echo iN_HelpSecure($version);?>"></script>
