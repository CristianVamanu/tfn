<?php
// Feed (multi-stream) — legacy post.php
$viewMode = 'feed'; // this is the default
$limit = 20; $offset = 0;
include __DIR__ . '/post_view.php';
