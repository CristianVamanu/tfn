<?php
$ownerProfileUrl = ($base_url ?? '') . 'profile/' . $post['owner_username'];
$ownerId = isset($post['post_owner_id']) ? (int) $post['post_owner_id'] : 0;
$ownerAvatarRel = '';
if ($ownerId > 0 && isset($RL) && method_exists($RL, 'RL_userAvatar')) {
    $ownerAvatarRel = $RL->RL_userAvatar($ownerId);
}
if ($ownerAvatarRel === '') {
    $ownerAvatarRel = $post['owner_avatar'] ?: ($defaultUserAvatar ?? 'uploads/user_avatars/default.jpeg');
}
if (function_exists('storage_url')) {
    $ownerAvatar = storage_url((string) $ownerAvatarRel);
    if ($ownerAvatar === '') {
        $ownerAvatar = storage_url('uploads/user_avatars/default.jpeg');
    }
} elseif (function_exists('storage_resolve_media_url')) {
    $ownerAvatar = storage_resolve_media_url((string) $ownerAvatarRel, $base_url ?? '');
    if ($ownerAvatar === '') {
        $ownerAvatar = storage_resolve_media_url('uploads/user_avatars/default.jpeg', $base_url ?? '');
    }
} else {
    $ownerAvatar = (string)($base_url ?? '') . ltrim((string)$ownerAvatarRel, '/');
    if ($ownerAvatar === '' && !empty($defaultUserAvatar)) {
        $ownerAvatar = (string)($base_url ?? '') . ltrim((string)$defaultUserAvatar, '/');
    }
}
$timeLabel       = dz_relative_time_label((int) ($post['post_created_time'] ?? time()));

// Prepare media files
$postFiles = array_filter(array_map('trim', explode(',', (string) $post['post_file'])));
$lockedPreviewPath = isset($post['locked_preview_path']) ? (string) $post['locked_preview_path'] : '';
$lockedPreviewType = strtolower((string) ($post['locked_preview_type'] ?? ''));
$lockedPreviewUrl = '';
if ($lockedPreviewPath !== '') {
    if (function_exists('storage_resolve_media_url')) {
        $lockedPreviewUrl = storage_resolve_media_url($lockedPreviewPath, $base_url ?? '');
    } elseif (function_exists('storage_url')) {
        $lockedPreviewUrl = storage_url($lockedPreviewPath);
    } else {
        $lockedPreviewUrl = (string)($base_url ?? '') . ltrim($lockedPreviewPath, '/');
    }
}
$hasLockedPreview = $lockedPreviewUrl !== '' && in_array($lockedPreviewType, ['static', 'animated'], true);
$teaserPath = '';
$teaserUrl = '';
if (isset($RL) && method_exists($RL, 'RL_GetPostTeaserPath')) {
    $teaserPath = (string) $RL->RL_GetPostTeaserPath((int) ($post['post_id'] ?? 0));
    if ($teaserPath !== '') {
        if (function_exists('storage_resolve_media_url')) {
            $teaserUrl = storage_resolve_media_url($teaserPath, $base_url ?? '');
        } elseif (function_exists('storage_url')) {
            $teaserUrl = storage_url($teaserPath);
        } else {
            $teaserUrl = (string)($base_url ?? '') . ltrim($teaserPath, '/');
        }
    }
}
$hasTeaser = $teaserUrl !== '';
$teaserExtension = '';
if ($hasTeaser) {
    $teaserUrlPath = parse_url($teaserUrl, PHP_URL_PATH);
    $teaserExtension = strtolower(pathinfo((string) ($teaserUrlPath ?: $teaserUrl), PATHINFO_EXTENSION));
}
$teaserIsAudio = in_array($teaserExtension, ['mp3', 'm4a', 'aac', 'wav', 'ogg', 'oga'], true);

global $userData;
$viewerIdForActions = 0;
if (isset($userData['user_id'])) {
    $viewerIdForActions = (int) $userData['user_id'];
} elseif (isset($post['viewer_id'])) {
    $viewerIdForActions = (int) $post['viewer_id'];
}

$preferences = isset($userPreferences) && is_array($userPreferences) ? $userPreferences : [];
$prefAutoplay = array_key_exists('feed_autoplay', $preferences) ? (bool) $preferences['feed_autoplay'] : true;
$prefMuted    = array_key_exists('feed_muted', $preferences) ? (bool) $preferences['feed_muted'] : true;

$buildVideoAttributes = static function (string $src, bool $autoplay, bool $muted, ?string $poster = null): string {
    $attrs = [
        'class="post-media"',
        'preload="metadata"',
        'src="' . iN_HelpSecure($src) . '"',
        'loop',
        'playsinline',
        'data-pref-autoplay="' . ($autoplay ? 'on' : 'off') . '"'
    ];
    if ($poster) {
        $attrs[] = 'poster="' . iN_HelpSecure($poster) . '"';
    }
    if ($muted)    { $attrs[] = 'muted'; }
    return implode(' ', $attrs);
};

// -------------------------
// Visibility resolution
// -------------------------
$canView = true;
$visibilityMessage = '';

if (empty($post['is_owner'])) {
    switch ($post['post_visibility']) {
        case 'everyone':
            $canView = true;
            break;

        case 'followers':
            $relV2O  = $post['viewer_to_owner_status'] ?? null;
            $canView = in_array($relV2O, ['flwr', 'subscriber'], true);
            if (!$canView) {
                $visibilityMessage = customLang('post_only_followers');
            }
            break;

        case 'subscribers':
            $relV2O  = $post['viewer_to_owner_status'] ?? null;
            $canView = ($relV2O === 'subscriber');
            if (!$canView) {
                $visibilityMessage = customLang('post_only_subscribers');
            }
            break;

        case 'locked':
            $viewerId  = isset($post['viewer_id']) ? (int) $post['viewer_id'] : 0;
            $purchased = $RL->hasPurchasedPost($viewerId, (int) $post['post_id']);
            if (!$purchased) {
                $canView = false;
                $visibilityMessage = '<div class="unlock-box flex full-width align_items_justify_content flexBoxColumn"><div class="unlock-icon flex align_items_justify_content locked">'.render_icon('locked', true).'</div><div class="unlock-icon flex align_items_justify_content unlock">'.render_icon('unlocked', true).'</div>'.customLang('pay_to_unlock').'</div>';
            }
            break;

        default:
            $canView = false;
            $visibilityMessage = customLang('post_hidden_generic');
            break;
    }
}
// Build URLs and flags
$approvalStatus = strtolower((string)($post['approval_status'] ?? 'approved'));
$approvalNotes = isset($post['approval_notes']) ? trim((string)$post['approval_notes']) : '';
$approvalBlocked = in_array($approvalStatus, ['pending', 'rejected'], true);
$viewerIsAdmin = isset($isAdminUser)
    ? (bool)$isAdminUser
    : (bool)($post['viewer_is_admin'] ?? ($GLOBALS['isAdminUser'] ?? false));
$approvalLabel = $approvalStatus === 'rejected'
    ? (customLang('post_status_rejected') ?: 'Rejected')
    : (customLang('post_status_pending') ?: 'Pending approval');
$approvalMessage = $approvalStatus === 'rejected'
    ? (customLang('post_status_rejected_message') ?: 'This post was rejected and is hidden from others.')
    : (customLang('post_status_pending_message') ?: 'This post is waiting for admin approval.');
$postUrl  = ($base_url ?? '') . 'posts/' . (int)$post['post_id'] . '/' . ($post['owner_username'] ?? '');
$isOwner  = !empty($post['is_owner']);
$podcastCategoryName = '';
$podcastCategorySlug = '';
$podcastCategoryUrl  = '';
if (!empty($post['post_type']) && $post['post_type'] === 'podcast') {
    $podcastCategoryName = isset($post['podcast_category_name']) ? trim((string)$post['podcast_category_name']) : '';
    $podcastCategorySlug = isset($post['podcast_category_slug']) ? trim((string)$post['podcast_category_slug']) : '';
    if ($podcastCategoryName !== '') {
        $podcastCategoryUrl = ($base_url ?? '') . 'profile/' . ($post['owner_username'] ?? '') . '/podcasts';
        if ($podcastCategorySlug !== '') {
            $podcastCategoryUrl .= '?category=' . rawurlencode($podcastCategorySlug);
        }
    }
}
?>
<div class="post_ full-width relative flex align_items flexBoxColumn"
     id="post-<?php echo (int) $post['post_id']; ?>"
     data-id="<?php echo (int)$post['post_id']; ?>"
     data-owner-id="<?php echo (int)$post['post_owner_id']; ?>"
     data-approval="<?php echo iN_HelpSecure($approvalStatus); ?>"
     data-visibility="<?php echo iN_HelpSecure((string)($post['post_visibility'] ?? 'everyone')); ?>"
     data-price="<?php echo (int) ($post['post_price'] ?? 0); ?>"
     data-min-price="<?php echo (int)($premiumPostPriceMinimum ?? 1); ?>"
     data-max-price="<?php echo (int)($premiumPostPriceMaximum ?? 500); ?>"
     data-text="<?php echo iN_HelpSecure((string)($post['post_text'] ?? '')); ?>"
     data-comments="<?php echo (($post['comment_status'] ?? 'on') === 'on') ? 'on' : 'off'; ?>">
    <!--Post HEADER-->
    <div class="post_header full-width relative flex align_items column-gap">
        <div class="post_owner_avatar relative flex align_items">
            <div class="user-avatar relative flex align_items">
                <?php $___ownerAlt = sprintf(customLang('alt_avatar_of_user'), (string)($post['owner_fullname'] ?: $post['owner_username'])); ?>
                <?php
                    $altTemplate = customLang('alt_avatar_of_user', 'Avatar of %s');
                    if (!is_string($altTemplate) || strpos($altTemplate, '%') === false) {
                        $altTemplate = 'Avatar of %s';
                    }
                    $___ownerAlt = sprintf($altTemplate, (string)($post['owner_fullname'] ?: $post['owner_username']));
                ?>
                <img class="avatar-img relative" src="<?php echo iN_HelpSecure($ownerAvatar); ?>" alt="<?php echo iN_HelpSecure($___ownerAlt); ?>">
            </div>
        </div>
        <div class="post-owner-data full-width relative flex align_items flexBoxColumn">
            <div class="post-owner-name full-width flex align_items post-owner-name-img">
                <a href="<?php echo iN_HelpSecure($ownerProfileUrl); ?>"><?php echo iN_HelpSecure($post['owner_fullname'] ?: $post['owner_username']); ?></a>
                <?php if ((int) $post['owner_verified'] === 1) { echo render_icon('verified', true); } ?>
            </div>
            <div class="post-share-data full-width flex align_items">
                <div class="post-share-time flex align_items"><?php echo iN_HelpSecure($timeLabel); ?></div>
                <?php if ($approvalBlocked): ?>
                    <div class="post-approval-chip post-approval-chip--<?php echo iN_HelpSecure($approvalStatus); ?>">
                        <?php echo iN_HelpSecure($approvalLabel); ?>
                    </div>
                <?php endif; ?>
                <?php if ($post['post_type'] === 'podcast' && $podcastCategoryName !== ''): ?>
                    <a class="post-category-chip" href="<?php echo iN_HelpSecure($podcastCategoryUrl); ?>">
                        <?php echo iN_HelpSecure($podcastCategoryName); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="post-settings-btn-box flex align_items relative">
            <div class="post-settings-btn flex align_items_justify_content relative"
                 role="button" tabindex="0" aria-haspopup="dialog" aria-expanded="false"
                 data-id="<?php echo (int)$post['post_id']; ?>"
                 data-url="<?php echo iN_HelpSecure($postUrl); ?>"
                 data-username="<?php echo iN_HelpSecure((string)$post['owner_username']); ?>">
                 <?php echo render_icon('dots', true); ?>
            </div>
        </div>
    </div>
    <!--/Post HEADER-->

    <!--POST BODY-->
    <div class="post-body full-width flex align_items flexBoxColumn">
        <?php if ($canView) : ?>
            <?php if ($post['post_type'] === 'image') : ?>
                <?php if (count($postFiles) > 1) : ?>
                    <div class="post-media-swiper swiper">
                        <div class="swiper-wrapper">
                            <?php foreach ($postFiles as $idx => $f) : ?>
                                <div class="swiper-slide">
                                    <img src="<?php echo iN_HelpSecure(storage_url($f)); ?>" alt="<?php echo iN_HelpSecure(sprintf(customLang('image_alt_sequence'), (int) ($idx + 1))); ?>" loading="lazy" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="swiper-pagination"></div>
                        <div class="swiper-button-prev" aria-label="<?php echo iN_HelpSecure(customLang('carousel_prev_label')); ?>"></div>
                        <div class="swiper-button-next" aria-label="<?php echo iN_HelpSecure(customLang('carousel_next_label')); ?>"></div>
                    </div>
                <?php else : ?>
                    <?php $single = $postFiles ? reset($postFiles) : ''; ?>
                    <?php if ($single) : ?>
                        <div class="post-media-single">
                            <img src="<?php echo iN_HelpSecure(storage_url($single)); ?>" alt="<?php echo iN_HelpSecure(customLang('image_alt_generic')); ?>" loading="lazy" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php elseif ($post['post_type'] === 'podcast') : ?>
                <?php
                    $audioKey    = (string) $post['post_file'];
                    $audioSrc    = storage_url($audioKey);
                    $coverPath   = isset($post['cover_path']) ? (string) $post['cover_path'] : '';
                    if ($coverPath === '' && isset($RL) && method_exists($RL, 'RL_GetPostCoverPath')) {
                        $coverPath = $RL->RL_GetPostCoverPath((int) ($post['post_id'] ?? 0));
                    }
                    $coverUrl    = $coverPath !== '' ? storage_url($coverPath) : '';
                    $durationSec = isset($post['audio_duration_seconds']) ? (int) $post['audio_duration_seconds'] : null;
                    $initialTime = $durationSec ? '0:00 / ' . gmdate('i:s', $durationSec) : '0:00';
                ?>
                <div class="post-media-audio full-width flex align_items flexBoxColumn">
                    <div class="podcast-player-card">
                        <?php if ($coverUrl !== '') : ?>
                            <div class="podcast-card-backdrop" aria-hidden="true">
                                <img src="<?php echo iN_HelpSecure($coverUrl); ?>" alt="">
                            </div>
                        <?php endif; ?>
                        <?php if ($coverUrl !== '') : ?>
                            <div class="podcast-cover-preview">
                                <img src="<?php echo iN_HelpSecure($coverUrl); ?>" alt="<?php echo iN_HelpSecure(customLang('podcast_cover_alt', 'Podcast cover')); ?>" loading="lazy">
                            </div>
                        <?php endif; ?>
                        <div class="podcast-visual">
                            <div class="podcast-bars left">
                                <span></span><span></span><span></span><span></span><span></span>
                            </div>
                            <div class="podcast-bars right">
                                <span></span><span></span><span></span><span></span><span></span>
                            </div>
                        </div>
                        <div class="podcast-progress" role="group" aria-label="<?php echo iN_HelpSecure(customLang('upload_podcast', 'Podcast')); ?>">
                            <div class="podcast-progress-track">
                                <div class="podcast-progress-fill"></div>
                                <div class="podcast-progress-thumb" aria-hidden="true"></div>
                            </div>
                            <div class="podcast-time"><?php echo iN_HelpSecure($initialTime); ?></div>
                        </div>
                        <div class="podcast-controls">
                            <button type="button" class="podcast-btn rewind" aria-label="<?php echo iN_HelpSecure(customLang('ui_rewind_10', 'Rewind 10 seconds')); ?>">&#9198;</button>
                            <button type="button" class="podcast-btn play" aria-label="<?php echo iN_HelpSecure(customLang('ui_play_pause', 'Play / Pause')); ?>">
                                <span class="icon-play">&#9658;</span>
                                <span class="icon-pause">❚❚</span>
                            </button>
                            <button type="button" class="podcast-btn forward" aria-label="<?php echo iN_HelpSecure(customLang('ui_forward_10', 'Forward 10 seconds')); ?>">&#9197;</button>
                        </div>
                        <audio class="podcast-audio-element" preload="metadata" src="<?php echo iN_HelpSecure($audioSrc); ?>"></audio>
                    </div>
                </div>
            <?php else : ?>
                <!-- Video -->
                <div class="post-media-video full-width flex align_items">
                    <div class="video-wrapper video-wrapper--reel" data-video-mode="reel">
                        <?php
                            $videoKey    = (string) $post['post_file'];
                            $videoSrc    = storage_url($videoKey);
                            $videoPoster = '';
                            if (isset($RL) && method_exists($RL, 'videoThumbNail')) {
                                try {
                                    $videoPoster = $RL->videoThumbNail($videoSrc);
                                } catch (Throwable $__) {
                                    $videoPoster = '';
                                }
                            }
                        ?>
                        <video <?php echo $buildVideoAttributes($videoSrc, $prefAutoplay, $prefMuted, $videoPoster ?: null); ?>></video>
                        <div class="video-speed-control" data-video-id="<?php echo (int) $post['post_id']; ?>">
                            <button
                                type="button"
                                class="video-speed-toggle"
                                data-video-id="<?php echo (int) $post['post_id']; ?>"
                                aria-label="<?php echo iN_HelpSecure(customLang('video_speed_label', 'Playback speed')); ?>"
                                aria-expanded="false"
                                aria-controls="video-speed-menu-<?php echo (int) $post['post_id']; ?>"
                            >
                                <span class="video-speed-toggle-text"><?php echo iN_HelpSecure(customLang('video_speed_option_1x', '1x')); ?></span>
                                <span class="video-speed-toggle-icon" aria-hidden="true">
                                    <?php echo render_icon('down_arrow', true); ?>
                                </span>
                            </button>
                            <div
                                class="video-speed-menu"
                                id="video-speed-menu-<?php echo (int) $post['post_id']; ?>"
                                data-video-id="<?php echo (int) $post['post_id']; ?>"
                                role="menu"
                                aria-label="<?php echo iN_HelpSecure(customLang('video_speed_label', 'Playback speed')); ?>"
                                aria-hidden="true"
                            >
                                <div class="video-speed-menu-title"><?php echo iN_HelpSecure(customLang('video_speed_label', 'Playback speed')); ?></div>
                                <button
                                    type="button"
                                    class="video-speed-option is-active"
                                    data-speed="1"
                                    data-speed-label="<?php echo iN_HelpSecure(customLang('video_speed_option_1x', '1x')); ?>"
                                    role="menuitemradio"
                                    aria-checked="true"
                                >
                                    <span class="video-speed-option-label"><?php echo iN_HelpSecure(customLang('video_speed_normal', 'Normal')); ?></span>
                                    <span class="video-speed-option-suffix"><?php echo iN_HelpSecure(customLang('video_speed_option_1x', '1x')); ?></span>
                                </button>
                                <button
                                    type="button"
                                    class="video-speed-option"
                                    data-speed="1.5"
                                    data-speed-label="<?php echo iN_HelpSecure(customLang('video_speed_option_1_5x', '1.5x')); ?>"
                                    role="menuitemradio"
                                    aria-checked="false"
                                >
                                    <span class="video-speed-option-label"><?php echo iN_HelpSecure(customLang('video_speed_option_1_5x', '1.5x')); ?></span>
                                </button>
                                <button
                                    type="button"
                                    class="video-speed-option"
                                    data-speed="2"
                                    data-speed-label="<?php echo iN_HelpSecure(customLang('video_speed_option_2x', '2x')); ?>"
                                    role="menuitemradio"
                                    aria-checked="false"
                                >
                                    <span class="video-speed-option-label"><?php echo iN_HelpSecure(customLang('video_speed_option_2x', '2x')); ?></span>
                                </button>
                                <button
                                    type="button"
                                    class="video-speed-option"
                                    data-speed="2.5"
                                    data-speed-label="<?php echo iN_HelpSecure(customLang('video_speed_option_2_5x', '2.5x')); ?>"
                                    role="menuitemradio"
                                    aria-checked="false"
                                >
                                    <span class="video-speed-option-label"><?php echo iN_HelpSecure(customLang('video_speed_option_2_5x', '2.5x')); ?></span>
                                </button>
                            </div>
                        </div>
                        <div class="video-seek" data-video-id="<?php echo (int) $post['post_id']; ?>">
                            <label class="sr-only" for="video-seek-<?php echo (int) $post['post_id']; ?>">
                                <?php echo iN_HelpSecure(customLang('video_seek_label', 'Seek')); ?>
                            </label>
                            <input
                                type="range"
                                class="video-seek-range"
                                id="video-seek-<?php echo (int) $post['post_id']; ?>"
                                min="0"
                                max="100"
                                step="0.01"
                                value="0"
                            >
                            <div class="video-seek-time" aria-live="polite">
                                <span class="video-seek-current">0:00</span>
                                <span class="video-seek-separator">/</span>
                                <span class="video-seek-duration">0:00</span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!empty($post['post_text'])) : ?>
                <div class="post-text"><?php echo nl2br(iN_HelpSecure($post['post_text'])); ?></div>
            <?php endif; ?>
        <?php else : ?>
            <?php
                $lockedPreviewMessageHtml = html_entity_decode($visibilityMessage);
                $canUseTeaser = $hasTeaser && in_array((string) ($post['post_visibility'] ?? ''), ['locked', 'subscribers'], true);
            ?>
            <div class="locked-preview-container full-width flex align_items flexBoxColumn gap">
                <?php if ($canUseTeaser) : ?>
                    <div class="locked-preview-media locked-preview-media--teaser" data-premium-teaser="1">
                        <?php if ($teaserIsAudio) : ?>
                            <div class="locked-preview locked-preview--audio-teaser flex align_items flexBoxColumn">
                                <div class="locked-preview-audio-icon"><?php echo render_icon('podcast', true); ?></div>
                                <audio
                                    class="locked-preview-audio"
                                    src="<?php echo iN_HelpSecure($teaserUrl); ?>"
                                    controls
                                    preload="metadata"
                                    data-premium-teaser-media="1"
                                ></audio>
                            </div>
                        <?php else : ?>
                            <video
                                class="locked-preview locked-preview--teaser"
                                src="<?php echo iN_HelpSecure($teaserUrl); ?>"
                                controls
                                playsinline
                                preload="metadata"
                                data-premium-teaser-media="1"
                            ></video>
                        <?php endif; ?>
                        <div class="locked-preview-overlay locked-preview-overlay--deferred">
                            <div class="visibility-warning flex align_items full-width visibility-warning--overlay">
                                <?php echo $lockedPreviewMessageHtml; ?>
                            </div>
                        </div>
                    </div>
                <?php elseif ($hasLockedPreview) : ?>
                    <div class="locked-preview-media">
                        <?php if ($lockedPreviewType === 'animated') : ?>
                            <video
                                class="locked-preview locked-preview--video"
                                src="<?php echo iN_HelpSecure($lockedPreviewUrl); ?>"
                                autoplay
                                muted
                                playsinline
                                preload="metadata"
                                data-max-locked-loops="2"
                            ></video>
                        <?php else : ?>
                            <img class="locked-preview locked-preview--image" src="<?php echo iN_HelpSecure($lockedPreviewUrl); ?>" alt="<?php echo iN_HelpSecure(customLang('locked_preview_alt') ?: 'Pixelated preview for locked content.'); ?>" loading="lazy">
                        <?php endif; ?>
                        <div class="locked-preview-overlay">
                            <div class="visibility-warning flex align_items full-width visibility-warning--overlay">
                                <?php echo $lockedPreviewMessageHtml; ?>
                            </div>
                        </div>
                    </div>
                <?php else : ?>
                    <div class="visibility-warning flex align_items full-width locked_bg">
                        <?php echo $lockedPreviewMessageHtml; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    <!--/POST BODY-->

    <?php if ($approvalBlocked && !$viewerIsAdmin): ?>
        <div class="post-approval-alert post-approval-alert--<?php echo iN_HelpSecure($approvalStatus); ?> full-width">
            <div class="post-approval-alert__title"><?php echo iN_HelpSecure($approvalLabel); ?></div>
            <div class="post-approval-alert__message"><?php echo iN_HelpSecure($approvalMessage); ?></div>
            <?php if ($approvalNotes !== ''): ?>
                <div class="post-approval-alert__note"><?php echo iN_HelpSecure($approvalNotes); ?></div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!--FOOTER-->
    <?php if (!$approvalBlocked || $viewerIsAdmin): ?>
        <div class="post-footer full-width flex align_items flexBoxColumn">
            <!--FOOTER BUTTONS-->
            <div class="post-footer-buttons relative full-width flex align_items">
                <div class="post-button-box flex align_items cursor-point">
                    <div class="post-button-heart flex align_items p_like <?php echo ($viewerIdForActions > 0 && $RL->RL_HasLiked($viewerIdForActions, (int)$post['post_id'], 'post')) ? 'is-liked' : ''; ?>"
                        post-id="<?php echo (int) iN_HelpSecure($post['post_id']);?>">

                        <span class="icon-unliked">
                            <?php echo render_icon('like', true); ?>
                        </span>
                        <span class="icon-liked">
                            <?php echo render_icon('liked', true); ?>
                        </span>
                    </div>

                    <div class="total-like flex align_items">
                        <span class="metric-value"><?php echo $RL->RL_CountLikes(iN_HelpSecure($post['post_id']), 'post'); ?></span>
                        <span class="metric-label"> <?php echo customLang('likes'); ?></span>
                    </div>
                </div>
                <div class="post-button-box flex align_items">
                    <div class="post-button-comment flex align_items p_comment cursor-point" data-id="<?php echo (int) $post['post_id']; ?>"><?php echo render_icon('comment', true); ?></div>
                    <div class="total-comment flex align_items cursor-pointer commentCount">
                        <span class="metric-value">0</span>
                        <span class="metric-label"> <?php echo customLang('comments'); ?></span>
                    </div>
                </div>
                <div class="post-button-box flex align_items cursor-point">
                    <?php $shareCount = method_exists($RL,'RL_CountPostShares') ? (int)$RL->RL_CountPostShares((int)$post['post_id']) : 0; ?>
                    <div class="post-button-send flex align_items p_send"><?php echo render_icon('send', true); ?></div>
                    <div class="total-send flex align_items" data-role="share-count"><?php echo (int)$shareCount; ?></div>
                </div>
                <div class="post-button-box post-button-box-super-thanks flex align_items cursor-point">
                    <div class="post-button-super-thanks flex align_items p_super_thanks"><?php echo render_icon('super_thanks', true); ?></div>
                    <div class="total-send flex align_items"><?php echo customLang('thanks'); ?></div>
                </div>
                <div class="post-button-box button-save flex align_items cursor-point">
                    <div class="post-button-super-thanks flex align_items p_super_thanks"><?php echo render_icon('save', true); ?></div>
                </div>
            </div>
            <!--/FOOTER BUTTONS-->

            <div class="post-comments-container full-width flex align_items gap flexBoxColumn" id="comments-<?php echo (int) $post['post_id']; ?>">
                <div class="post-comments relative full-width flex align_items gap flexBoxColumn"></div>
            </div>
        </div>
        <!--/FOOTER-->

        <?php if ($post['comment_status'] === 'on') : ?>
            <?php $postID = (int) $post['post_id']; include __DIR__ . '/commentComposer.php'; ?>
        <?php endif; ?>
        <div class="like-fx-layer"></div>
    <?php else: ?>
        <div class="post-footer post-footer--disabled full-width flex align_items flexBoxColumn"></div>
    <?php endif; ?>

    <?php include __DIR__ . '/partials/post_settings.php'; ?>
</div>
