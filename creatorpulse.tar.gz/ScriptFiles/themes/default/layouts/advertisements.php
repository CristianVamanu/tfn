<?php
declare(strict_types=1);

if (!isset($loggedIn) || $loggedIn !== '1') {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}

$userId = isset($userID) ? (int) $userID : 0;
if ($userId <= 0) {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}
if (empty($enableAds)) {
    echo '<div class="settings-placeholder">' . iN_HelpSecure(customLang('content_disabled_ads')) . '</div>';
    return;
}

$summaryCardConfig = [
    ['key' => 'active', 'icon' => 'trending', 'icon_class' => 'kpi-icon--followers', 'label_key' => 'ads_dashboard_total_active'],
    ['key' => 'paused', 'icon' => 'time', 'icon_class' => 'kpi-icon--supporters', 'label_key' => 'ads_dashboard_total_paused'],
    ['key' => 'budget', 'icon' => 'payments', 'icon_class' => 'kpi-icon--revenue', 'label_key' => 'ads_dashboard_total_budget'],
    ['key' => 'spent', 'icon' => 'subscription_fees', 'icon_class' => 'kpi-icon--earnings', 'label_key' => 'ads_dashboard_total_spent'],
    ['key' => 'remaining', 'icon' => 'sparkles', 'icon_class' => 'kpi-icon--supporters', 'label_key' => 'ads_dashboard_total_remaining'],
];

$loadingLabel = (string) customLang('ads_dashboard_loading');
$emptyLabel   = (string) customLang('ads_dashboard_empty');
?>

<div class="main-content flex align_items flexBoxColumn">
<section class="card_admin ads-dashboard settings-dashboard" role="region" aria-labelledby="adsDashboardHeading">
  <h1 class="h1" id="adsDashboardHeading"><?php echo iN_HelpSecure(customLang('ads_dashboard_title')); ?></h1>
  <p class="settings-dashboard-intro ads-dashboard-subtitle"><?php echo iN_HelpSecure(customLang('ads_dashboard_subtitle')); ?></p>

  <div class="notice small" data-ads-dashboard-hint>
    <?php echo iN_HelpSecure(customLang('ads_dashboard_hint', 'Monitor active campaigns, adjust copy, and keep budgets on track.')); ?>
  </div>

  <div class="kpi-row ads-dashboard-summary" data-ads-summary>
    <?php foreach ($summaryCardConfig as $card): ?>
      <?php $label = (string) customLang($card['label_key']); ?>
      <article class="admin-card card kpi-card ads-summary-card is-loading" data-summary-card="<?php echo htmlspecialchars($card['key'], ENT_QUOTES, 'UTF-8'); ?>">
        <div class="kpi-left">
          <div class="kpi-title">
            <span class="kpi-icon <?php echo htmlspecialchars($card['icon_class'], ENT_QUOTES, 'UTF-8'); ?>">
              <?php echo render_icon($card['icon'], true); ?>
            </span>
            <?php echo iN_HelpSecure($label); ?>
          </div>
          <div class="kpi-amount" data-summary-value><?php echo iN_HelpSecure($loadingLabel); ?></div>
          <div class="kpi-period" data-summary-meta>—</div>
        </div>
      </article>
    <?php endforeach; ?>
  </div>

  <div class="charts-row ads-dashboard-charts" data-ads-charts>
    <div class="admin-card card chart-card ads-chart-card">
      <div class="chart-header flex align_items_justify_content flexBoxColumn">
        <div class="chart-title"><?php echo iN_HelpSecure(customLang('ads_dashboard_chart_heading', 'Campaign performance')); ?></div>
        <div class="charge_type flex align_items column-gap ads-dashboard-range" role="tablist" aria-label="<?php echo iN_HelpSecure(customLang('ads_dashboard_chart_heading', 'Campaign performance')); ?>" data-ads-range>
          <button type="button" class="ads-range-btn is-active" data-range="daily" aria-selected="true"><?php echo iN_HelpSecure(customLang('ads_dashboard_timeframe_daily')); ?></button>
          <button type="button" class="ads-range-btn" data-range="weekly" aria-selected="false"><?php echo iN_HelpSecure(customLang('ads_dashboard_timeframe_weekly')); ?></button>
          <button type="button" class="ads-range-btn" data-range="monthly" aria-selected="false"><?php echo iN_HelpSecure(customLang('ads_dashboard_timeframe_monthly')); ?></button>
          <button type="button" class="ads-range-btn" data-range="yearly" aria-selected="false"><?php echo iN_HelpSecure(customLang('ads_dashboard_timeframe_yearly')); ?></button>
        </div>
      </div>
      <div class="chart-legend">
        <span><span class="legend-dot legend-blue"></span><?php echo iN_HelpSecure(customLang('ads_dashboard_chart_views')); ?></span>
        <span><span class="legend-dot legend-purple"></span><?php echo iN_HelpSecure('Clicks'); ?></span>
        <span><span class="legend-dot legend-cyan"></span><?php echo iN_HelpSecure(customLang('ads_dashboard_chart_spend')); ?></span>
      </div>
      <div class="chart-box">
        <canvas id="adsPerformanceChart" class="chart-canvas" aria-label="<?php echo iN_HelpSecure(customLang('ads_dashboard_chart_heading', 'Campaign performance')); ?>" role="img"></canvas>
        <div class="chart-fallback empty-state" data-ads-chart-loading>
          <div class="empty-state__icon"><?php echo render_icon('not_founded', true); ?></div>
          <p class="empty-state__title"><?php echo iN_HelpSecure($loadingLabel); ?></p>
          <p><?php echo iN_HelpSecure(customLang('ads_dashboard_fetch_hint', 'Data loads automatically once your advertisements are saved.')); ?></p>
        </div>
        <div class="chart-fallback empty-state none" data-ads-chart-error>
          <div class="empty-state__icon"><?php echo render_icon('time_alert', true); ?></div>
          <p class="empty-state__title"><?php echo iN_HelpSecure(customLang('ads_dashboard_error')); ?></p>
          <p><?php echo iN_HelpSecure(customLang('ads_dashboard_fetch_failed')); ?></p>
          <button type="button" class="upload-btn" data-ads-chart-retry><?php echo iN_HelpSecure(customLang('ui_request_failed_retry')); ?></button>
        </div>
      </div>
    </div>
  </div>

  <div class="admin-card card table-card-plus ads-dashboard-table" data-ads-table>
    <div class="table-card__header">
      <h2 class="table-card__title"><?php echo iN_HelpSecure(customLang('ads_dashboard_table_heading')); ?></h2>
      <p class="table-card__hint" data-ads-table-summary><?php echo iN_HelpSecure(customLang('ads_dashboard_loading')); ?></p>
    </div>
    <div class="table-card__scroll ads-grid-wrapper" data-ads-grid-wrapper>
      <div class="ads-grid ads-grid--header">
        <div><?php echo iN_HelpSecure(customLang('ads_dashboard_table_campaign', 'Campaign')); ?></div>
        <div><?php echo iN_HelpSecure(customLang('ads_dashboard_table_budget_overview', 'Budget overview')); ?></div>
        <div><?php echo iN_HelpSecure(customLang('ads_dashboard_table_performance', 'Performance')); ?></div>
        <div class="ads-header-actions"><?php echo iN_HelpSecure(customLang('ads_dashboard_table_actions')); ?></div>
      </div>
      <div class="ads-grid-body" data-ads-table-body>
        <div class="ads-grid ads-grid-row ads-placeholder-row">
          <div class="ads-cell-full"><?php echo iN_HelpSecure($loadingLabel); ?></div>
        </div>
      </div>
    </div>
    <div class="empty-state flex align_items flexBoxColumn gap none" data-ads-empty>
      <div class="empty-state__icon"><?php echo render_icon('not_founded', true); ?></div>
      <p class="empty-state__title"><?php echo iN_HelpSecure($emptyLabel); ?></p>
      <p><?php echo iN_HelpSecure(customLang('ads_dashboard_empty_hint', 'Create an advertisement to populate this view.')); ?></p>
      <div class="ads-empty-actions flex align_items column-gap">
        <?php if (!empty($enableImagePosts)): ?>
        <button type="button" class="upload-btn" data-ads-empty-cta="image"><?php echo iN_HelpSecure(customLang('ads_dashboard_create_image_cta', 'Create image ad')); ?></button>
        <?php endif; ?>
        <?php if (!empty($enableVideoPosts)): ?>
        <button type="button" class="pr-cancel" data-ads-empty-cta="video"><?php echo iN_HelpSecure(customLang('ads_dashboard_create_video_cta', 'Create video ad')); ?></button>
        <?php endif; ?>
      </div>
    </div>
    <div class="empty-state none" data-ads-error>
      <div class="empty-state__icon"><?php echo render_icon('time_alert', true); ?></div>
      <p class="empty-state__title"><?php echo iN_HelpSecure(customLang('ads_dashboard_error')); ?></p>
      <p><?php echo iN_HelpSecure(customLang('ads_dashboard_fetch_failed')); ?></p>
      <button type="button" class="upload-btn" data-ads-retry><?php echo iN_HelpSecure(customLang('ui_request_failed_retry')); ?></button>
    </div>
  </div>
</section>
</div>

<div class="popUp-container flex align_items_justify_content none" id="adsEditCopyModal" role="dialog" aria-modal="true" aria-labelledby="adsEditCopyTitle" data-ads-edit-modal>
  <div class="close_pop flex align_items" data-ads-edit-close><?php echo render_icon('close', false); ?></div>
  <div class="popup-wrapper flex flexBoxColumn align_items">
    <div class="click_box_header flex align_items_justify_content">
      <div class="full-width flex align_items_justify_content" id="adsEditCopyTitle">
        <?php echo iN_HelpSecure(customLang('ads_dashboard_edit_copy')); ?>
      </div>
    </div>
    <div class="arrow"></div>
    <form class="ads-edit-form flex flexBoxColumn align_items full-width" data-ads-edit-form>
      <label class="full-width flex flexBoxColumn align_items_justify_content ads-edit-field">
        <span class="ads-edit-label full-width"><?php echo iN_HelpSecure(customLang('ads_dashboard_edit_title')); ?></span>
        <input type="text" name="ads_edit_title" maxlength="255" class="ads-edit-input text-field" data-ads-edit-title placeholder="<?php echo iN_HelpSecure(customLang('ads_dashboard_edit_title')); ?>" required />
      </label>
      <label class="full-width flex flexBoxColumn align_items_justify_content ads-edit-field">
        <span class="ads-edit-label full-width"><?php echo iN_HelpSecure(customLang('ads_dashboard_edit_description')); ?></span>
        <textarea name="ads_edit_description" maxlength="1000" class="ads-edit-textarea pe-text" data-ads-edit-description placeholder="<?php echo iN_HelpSecure(customLang('ads_dashboard_edit_description')); ?>" required></textarea>
      </label>
      <label class="full-width flex flexBoxColumn align_items_justify_content ads-edit-field">
        <span class="ads-edit-label full-width"><?php echo iN_HelpSecure(customLang('ads_link_label', 'Destination URL')); ?></span>
        <input type="text" name="ads_edit_link" maxlength="255" class="ads-edit-input text-field" data-ads-edit-link placeholder="<?php echo iN_HelpSecure(customLang('ads_link_placeholder', 'https://your-site.com')); ?>" required />
      </label>
      <div class="ads-edit-actions flex align_items column-gap full-width">
        <button type="button" class="ads-btn ads-btn-grey" data-ads-edit-cancel><?php echo iN_HelpSecure(customLang('ads_dashboard_edit_cancel')); ?></button>
        <button type="submit" class="ads-btn ads-btn-primary" data-ads-edit-save><?php echo iN_HelpSecure(customLang('ads_dashboard_edit_save')); ?></button>
      </div>
    </form>
  </div>
</div>
