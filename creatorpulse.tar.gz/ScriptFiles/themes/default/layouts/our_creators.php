<div class="main-content flex align_items">
    <div class="content-area flex">
        <!---->
        <div class="content-left">
            <div class="creators-page-container full-width flex align_items flexBoxColumn">
                <div class="creators-container full-width relative flex align_items" id="creators-container" data-limit="3" data-offset="3">
                    <?php
                        $creators = $RL->RL_GetCreatorsWithPublicPreviews(limit: 3, offset: 0);

                        // Helper: safe defaults for assets
                        $defaultAvatarPath = 'uploads/avatars/default_avatar.png';
                        $baseUrl = rtrim($base_url ?? '', '/').'/';

                        if (!$creators) {
                            $cta = '';
                            if (isset($loggedIn) && $loggedIn === '1') {
                                $cta = sprintf(
                                    '<div class="empty-state__body flex align_items flexBoxColumn gap">
                                        <p class="empty-state__subtitle">%s</p>
                                        <button type="button" class="empty-state__cta new_item" data-pop="createNew">%s</button>
                                    </div>',
                                    customLang('empty_state_create_prompt'),
                                    customLang('empty_state_create_button')
                                );
                            }

                            echo sprintf(
                                '<div class="empty-state flex align_items flexBoxColumn gap">'
                                . '<div class="empty-state__icon flex align_items">%s</div>'
                                . '<div class="empty-state__title flex align_items">%s</div>%s'
                                . '</div>',
                                render_icon('not_founded', true),
                                customLang('empty_state_creators'),
                                $cta
                            );
                        } else {
                            include 'creators.php';
                        }
                    ?>
                </div>
                <div id="creators-sentinel" aria-hidden="true"></div>
                <div id="creators-loading" class="none"><?php echo customLang('ui_loading'); ?></div>
            </div>
        </div>
        <!---->
        <div class="content-right flex align_items">
            <div class="content-right-container">
                <?php
                    include_once __DIR__ . '/widgets/suggestedUsers.php';
                    include_once __DIR__ . '/widgets/adsSidebar.php';
                    $hideMostPopularIfEmpty = true;
                    include_once __DIR__ . '/widgets/mosPopularPost.php';
                    unset($hideMostPopularIfEmpty);
                ?>
            </div>
        </div>
        <!---->
    </div>
</div>
<?php $themePathExplore = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme);?>
<script defer src="<?php echo $themePathExplore; ?>/js/getMoreCreators.js"></script>
<script defer src="<?php echo $themePathExplore; ?>/js/getPost.js"></script>
<script defer src="<?php echo $themePathExplore; ?>/js/followUnfollow.js"></script>
<script defer src="<?php echo $themePathExplore; ?>/js/adsFeedSlots.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePathExplore; ?>/js/media.viewer.js?v=<?php echo iN_HelpSecure($version);?>"></script>
