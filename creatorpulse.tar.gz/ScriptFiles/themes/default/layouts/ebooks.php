<?php
declare(strict_types=1);

$viewerId = isset($userID) ? (int)$userID : 0;
$isCreatorApproved = isset($creatorStatus) && strtolower((string)$creatorStatus) === 'approved';
$ebooksEnabledPage = isset($ebooksEnabled)
    ? (bool)$ebooksEnabled
    : (bool)($GLOBALS['ebooksEnabled'] ?? true);
$ebookCreatorUploadsEnabledPage = isset($ebookCreatorUploadsEnabled)
    ? (bool)$ebookCreatorUploadsEnabled
    : (bool)($GLOBALS['ebookCreatorUploadsEnabled'] ?? true);
$canPublishEbooks = $isCreatorApproved && $ebookCreatorUploadsEnabledPage;
$ebookPage = max(1, (int)($_GET['ebook_page'] ?? 1));
$ebookPerPage = 24;
$ebookPriceFilter = (string)($_GET['ebook_price'] ?? 'all');
$ebookSortFilter = (string)($_GET['ebook_sort'] ?? 'newest');
$ebookFilters = [
    'q' => trim((string)($_GET['ebook_q'] ?? '')),
    'category' => max(0, (int)($_GET['ebook_category'] ?? 0)),
    'price' => in_array($ebookPriceFilter, ['all', 'free', 'paid'], true) ? $ebookPriceFilter : 'all',
    'sort' => in_array($ebookSortFilter, ['newest', 'popular', 'rating', 'price_low', 'price_high'], true) ? $ebookSortFilter : 'newest',
];
$ebooks = [];
$ebookCategories = [];
$ebookTotal = 0;
if ($ebooksEnabledPage && isset($RL) && method_exists($RL, 'RL_GetEbooks')) {
    $ebooks = $RL->RL_GetEbooks($viewerId, $ebookPerPage, ($ebookPage - 1) * $ebookPerPage, $ebookFilters);
    $ebookTotal = method_exists($RL, 'RL_CountEbooks') ? $RL->RL_CountEbooks($ebookFilters) : count($ebooks);
    $ebookCategories = method_exists($RL, 'RL_GetEbookCategories') ? $RL->RL_GetEbookCategories(true) : [];
}
$ebookPageCount = max(1, (int)ceil($ebookTotal / $ebookPerPage));
$ebookBaseUrl = rtrim((string)($base_url ?? ''), '/') . '/';
$ebookCsrf = function_exists('generateCsrfToken') ? generateCsrfToken() : '';
$formatMoney = static function (float $amount, ?string $code = null): string {
    return function_exists('dz_format_currency') ? dz_format_currency($amount, $code) : number_format($amount, 2);
};
$currencyFormatSettings = isset($currencyFormatSettings)
    ? $currencyFormatSettings
    : ($GLOBALS['currency_format_settings'] ?? (function_exists('dz_currency_normalize_settings') ? dz_currency_normalize_settings([]) : []));
$curSymbolMap = (isset($currencies) && is_array($currencies))
    ? $currencies
    : ((isset($currencys) && is_array($currencys)) ? $currencys : []);
$globalCurCodeRaw = $globalCurCode ?? ($currency ?? 'USD');
if (!is_string($globalCurCodeRaw)) {
    $globalCurCodeRaw = (string)$globalCurCodeRaw;
}
$globalCurCode = strtoupper($globalCurCodeRaw !== '' ? $globalCurCodeRaw : 'USD');
$ebookCurrencySymbol = (string)($curSymbolMap[$globalCurCode] ?? '');
if ($ebookCurrencySymbol === '') {
    $ebookCurrencySymbol = $globalCurCode === 'USD' ? '$' : $globalCurCode;
}
$ebookPriceCurrencyLabel = trim($ebookCurrencySymbol . ' ' . $globalCurCode);
$walletBalanceRaw = isset($userWallet) ? (float)$userWallet : (float)($userData['wallet'] ?? 0);
$walletCurrencySymbol = (string)($curSymbolMap[$globalCurCode] ?? '');
$walletBalanceDisplay = function_exists('dz_format_currency')
    ? dz_format_currency($walletBalanceRaw, $globalCurCode, $walletCurrencySymbol, $currencyFormatSettings)
    : number_format($walletBalanceRaw, 2) . ' ' . $globalCurCode;
$walletProviderTemplate = customLang('pay_provider_wallet', 'Wallet ({balance})');
$walletProviderLabel = strtr($walletProviderTemplate, ['{balance}' => $walletBalanceDisplay]);
$providerCurrency = static function (string $provider) use ($globalCurCode): string {
    $map = [
        'stripe' => 'stripeCurCode',
        'paypal' => 'paypalCurCode',
        'payu' => 'payuCurCode',
        'paystack' => 'paystackCurCode',
        'iyzico' => 'iyzicoCurCode',
        'flutterwave' => 'flutterwaveCurCode',
        'nowpayments' => 'nowpayCurCode',
        'coinbase' => 'coinbaseCurCode',
    ];
    $var = $map[$provider] ?? '';
    $value = $var !== '' ? ($GLOBALS[$var] ?? null) : null;
    return strtoupper((string)($value ?: $globalCurCode));
};
$providerLabels = [
    'stripe' => customLang('pay_provider_stripe', 'Credit card'),
    'paypal' => customLang('pay_provider_paypal', 'PayPal'),
    'payu' => customLang('pay_provider_payu', 'PayU'),
    'paystack' => customLang('pay_provider_paystack', 'Paystack'),
    'iyzico' => customLang('pay_provider_iyzico', 'iyzico'),
    'flutterwave' => customLang('pay_provider_flutterwave', 'Flutterwave'),
    'nowpayments' => customLang('pay_provider_nowpayments', 'Crypto'),
    'coinbase' => customLang('pay_provider_coinbase', 'Coinbase'),
];
$availablePaymentProviders = [];
foreach ([
    'stripe' => !empty($enableStripe),
    'paypal' => !empty($enablePaypal),
    'payu' => !empty($enablePayu),
    'paystack' => !empty($enablePaystack),
    'iyzico' => !empty($enableIyziCo),
    'flutterwave' => !empty($enableFlutterwave),
    'nowpayments' => !empty($enableNowpayments),
    'coinbase' => !empty($enableCoinbase),
] as $providerKey => $enabled) {
    if ($enabled) {
        $availablePaymentProviders[$providerKey] = [
            'label' => $providerLabels[$providerKey] ?? ucfirst($providerKey),
            'currency' => $providerCurrency($providerKey),
        ];
    }
}
$availablePaymentProviders['wallet'] = [
    'label' => $walletProviderLabel,
    'currency' => $globalCurCode,
];
$ebookLanguageOptions = (isset($RL) && method_exists($RL, 'RL_GetEbookLanguages'))
    ? $RL->RL_GetEbookLanguages(true, (string)($currentLang ?? 'eng'))
    : [];
$ebookDefaultLanguage = (isset($RL) && method_exists($RL, 'RL_DefaultEbookLanguageTag'))
    ? $RL->RL_DefaultEbookLanguageTag()
    : 'en';
if (!$ebookLanguageOptions) {
    $ebookLanguageOptions = [[
        'language_tag' => 'en',
        'display_name' => 'English',
        'native_name' => 'English',
        'is_default' => 1,
    ]];
}
?>
<div class="main-content flex align_items">
  <div class="content-area flex">
    <div class="content-left">
      <div
        class="ebooks-page full-width"
        data-request-url="<?php echo iN_HelpSecure($ebookBaseUrl . 'request/requests.php'); ?>"
        data-topup-label="<?php echo iN_HelpSecure(customLang('wallet_topup_button_label', 'Add funds')); ?>"
        data-published-label="<?php echo iN_HelpSecure(customLang('ebook_published', 'eBook published.')); ?>"
        data-upload-failed-label="<?php echo iN_HelpSecure(customLang('upload_failed', 'Upload failed.')); ?>"
        data-purchase-failed-label="<?php echo iN_HelpSecure(customLang('ebook_purchase_failed', 'Purchase failed.')); ?>"
        data-payment-start-label="<?php echo iN_HelpSecure(customLang('payment_starting', 'Starting payment...')); ?>"
        data-pay-label="<?php echo iN_HelpSecure(customLang('ebook_pay_button', 'Pay now')); ?>"
        data-redirecting-label="<?php echo iN_HelpSecure(customLang('redirecting_to_payment', 'Redirecting to payment...')); ?>"
        data-wallet-insufficient-label="<?php echo iN_HelpSecure(customLang('wallet_balance_not_enough_add_funds', 'Your wallet balance is not enough. Add funds to continue.')); ?>"
      >
        <section class="ebooks-hero full-width">
          <div class="ebooks-hero__icon flex align_items"><?php echo render_icon('ebook', true); ?></div>
          <div class="ebooks-hero__copy">
            <h1><?php echo customLang('ebooks_title', 'eBooks'); ?></h1>
            <p><?php echo customLang('ebooks_subtitle', 'Download creator-made guides, books and digital resources.'); ?></p>
          </div>
          <?php if ($ebooksEnabledPage && $canPublishEbooks): ?>
            <button type="button" class="ebooks-add-trigger" data-ebook-modal-open>
              <span><?php echo render_icon('ebook', true); ?></span>
              <?php echo customLang('ebooks_add_title', 'Add eBook'); ?>
            </button>
          <?php endif; ?>
        </section>

        <?php if (!$ebooksEnabledPage): ?>
          <section class="ebooks-create ebooks-create--locked full-width">
            <div class="ebooks-section-head">
              <h2><?php echo customLang('ebooks_disabled_title', 'eBooks are disabled.'); ?></h2>
              <p><?php echo customLang('ebooks_disabled_note', 'The eBook store is currently disabled by the site administrator.'); ?></p>
            </div>
          </section>
        <?php elseif ($canPublishEbooks): ?>
          <div class="ebooks-create-modal" data-ebook-modal aria-hidden="true">
            <div class="ebooks-create-modal__backdrop" data-ebook-modal-close></div>
            <section class="ebooks-create ebooks-create-modal__panel full-width" role="dialog" aria-modal="true" aria-labelledby="ebooksCreateHeading">
              <button type="button" class="ebooks-create-modal__close" data-ebook-modal-close aria-label="<?php echo iN_HelpSecure(customLang('close', 'Close')); ?>">
                <?php echo render_icon('close', true); ?>
              </button>
              <div class="ebooks-section-head">
                <span class="ebooks-create__badge"><?php echo render_icon('ebook', true); ?></span>
                <h2 id="ebooksCreateHeading"><?php echo customLang('ebooks_add_title', 'Add eBook'); ?></h2>
                <p><?php echo customLang('ebooks_creator_note', 'Sell downloadable PDFs, EPUBs and MOBI files from your creator profile.'); ?></p>
              </div>
              <form class="ebooks-create-form" id="ebooks-create-form" enctype="multipart/form-data">
                <input type="hidden" name="p" value="ebook_create">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($ebookCsrf, ENT_QUOTES, 'UTF-8'); ?>">
                <label class="ebooks-field">
                  <span><?php echo customLang('ebook_title_label', 'Title'); ?></span>
                  <input type="text" name="title" maxlength="190" placeholder="<?php echo iN_HelpSecure(customLang('ebook_title_placeholder', 'Example: Creator monetization guide')); ?>" required>
                </label>
                <label class="ebooks-field">
                  <span><?php echo customLang('ebook_short_description_label', 'Short description'); ?></span>
                  <input type="text" name="short_description" maxlength="500" placeholder="<?php echo iN_HelpSecure(customLang('ebook_short_description_placeholder', 'A short promise buyers will see in the store.')); ?>">
                </label>
                <label class="ebooks-field">
                  <span><?php echo customLang('ebook_description_label', 'Description'); ?></span>
                  <textarea name="description" rows="3" maxlength="1000" placeholder="<?php echo iN_HelpSecure(customLang('ebook_description_placeholder', 'Describe what readers get, who it helps, and what is inside.')); ?>"></textarea>
                </label>
                <div class="ebooks-form-grid">
                  <label class="ebooks-field">
                    <span><?php echo customLang('ebook_language_label', 'Language'); ?></span>
                    <select name="language_code" required>
                      <option value=""><?php echo iN_HelpSecure(customLang('ebook_language_select_placeholder', 'Choose a language')); ?></option>
                      <?php foreach ($ebookLanguageOptions as $ebookLanguageOption): ?>
                        <?php $ebookLanguageTag = (string)($ebookLanguageOption['language_tag'] ?? ''); ?>
                        <option value="<?php echo iN_HelpSecure($ebookLanguageTag); ?>" <?php echo $ebookLanguageTag === $ebookDefaultLanguage ? 'selected' : ''; ?>>
                          <?php echo iN_HelpSecure((string)($ebookLanguageOption['display_name'] ?? $ebookLanguageOption['native_name'] ?? $ebookLanguageTag)); ?>
                        </option>
                      <?php endforeach; ?>
                    </select>
                    <small><?php echo iN_HelpSecure(customLang('ebook_language_help', 'Choose the language readers will find inside this eBook.')); ?></small>
                  </label>
                  <label class="ebooks-field"><span><?php echo customLang('ebook_pages_label', 'Pages'); ?></span><input type="number" name="page_count" min="0" step="1" placeholder="<?php echo iN_HelpSecure(customLang('ebook_pages_placeholder', '120')); ?>"></label>
                  <label class="ebooks-field"><span><?php echo customLang('ebook_version_label', 'Version'); ?></span><input type="text" name="version_label" maxlength="40" value="1.0" placeholder="<?php echo iN_HelpSecure(customLang('ebook_version_placeholder', '1.0')); ?>"></label>
                  <label class="ebooks-field"><span>ISBN</span><input type="text" name="isbn" maxlength="32" placeholder="<?php echo iN_HelpSecure(customLang('ebook_isbn_placeholder', 'Optional ISBN')); ?>"></label>
                  <label class="ebooks-field ebooks-field--date"><span><?php echo customLang('ebook_publication_date_label', 'Publication date'); ?></span><span class="ebooks-date-control"><input type="date" name="publication_date" placeholder="<?php echo iN_HelpSecure(customLang('ebook_publication_date_placeholder', 'Select a publication date')); ?>"><span class="ebooks-date-control__icon" aria-hidden="true"><?php echo render_icon('time_table', true); ?></span></span></label>
                  <label class="ebooks-field ebooks-field--price">
                    <span class="ebooks-field__label-row">
                      <span><?php echo customLang('ebook_price_label', 'Price'); ?></span>
                      <em><?php echo iN_HelpSecure($ebookPriceCurrencyLabel); ?></em>
                    </span>
                    <span class="ebooks-price-control">
                      <span class="ebooks-price-control__symbol" aria-hidden="true"><?php echo iN_HelpSecure($ebookCurrencySymbol); ?></span>
                      <input type="number" name="price" min="0" step="0.01" value="0" placeholder="<?php echo iN_HelpSecure(customLang('ebook_price_placeholder', '0.00')); ?>">
                    </span>
                    <small><?php echo strtr(customLang('ebook_price_help', 'Use 0 for a free eBook. Paid eBooks use {currency}.'), ['{currency}' => iN_HelpSecure($ebookPriceCurrencyLabel)]); ?></small>
                  </label>
                  <div class="ebooks-field ebooks-file-field" data-ebook-file-field data-empty-label="<?php echo iN_HelpSecure(customLang('ebook_no_file_selected', 'No file selected')); ?>">
                    <label for="ebook-cover-file"><?php echo customLang('ebook_cover_label', 'Cover image'); ?></label>
                    <input id="ebook-cover-file" class="ebooks-native-file" type="file" name="cover_file" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp">
                    <button type="button" class="ebooks-file-control" data-ebook-file-trigger>
                      <span class="ebooks-file-control__icon" data-ebook-cover-preview><?php echo render_icon('image', true); ?></span>
                      <span class="ebooks-file-control__copy">
                        <strong><?php echo customLang('ebook_cover_upload_title', 'Upload cover image'); ?></strong>
                        <small><?php echo customLang('ebook_cover_upload_hint', 'JPG, PNG or WebP'); ?></small>
                        <em data-ebook-file-name><?php echo customLang('ebook_no_file_selected', 'No file selected'); ?></em>
                      </span>
                    </button>
                    <button type="button" class="ebooks-file-clear" data-ebook-file-clear hidden><?php echo render_icon('close', true); ?><span><?php echo customLang('ebook_file_remove', 'Remove'); ?></span></button>
                  </div>
                  <div class="ebooks-field ebooks-file-field" data-ebook-file-field data-empty-label="<?php echo iN_HelpSecure(customLang('ebook_no_file_selected', 'No file selected')); ?>">
                    <label for="ebook-main-file"><?php echo customLang('ebook_file_label', 'eBook file'); ?></label>
                    <input id="ebook-main-file" class="ebooks-native-file" type="file" name="ebook_file" accept=".pdf,.epub,.mobi,application/pdf,application/epub+zip" required>
                    <button type="button" class="ebooks-file-control" data-ebook-file-trigger>
                      <span class="ebooks-file-control__icon"><?php echo render_icon('ebook', true); ?></span>
                      <span class="ebooks-file-control__copy">
                        <strong><?php echo customLang('ebook_file_upload_title', 'Upload eBook file'); ?></strong>
                        <small><?php echo customLang('ebook_file_upload_hint', 'PDF, EPUB or MOBI'); ?></small>
                        <em data-ebook-file-name><?php echo customLang('ebook_no_file_selected', 'No file selected'); ?></em>
                      </span>
                    </button>
                    <button type="button" class="ebooks-file-clear" data-ebook-file-clear hidden><?php echo render_icon('close', true); ?><span><?php echo customLang('ebook_file_remove', 'Remove'); ?></span></button>
                  </div>
                  <div class="ebooks-field ebooks-file-field" data-ebook-file-field data-empty-label="<?php echo iN_HelpSecure(customLang('ebook_no_file_selected', 'No file selected')); ?>">
                    <label for="ebook-sample-file"><?php echo customLang('ebook_sample_file_label', 'Sample PDF'); ?></label>
                    <input id="ebook-sample-file" class="ebooks-native-file" type="file" name="sample_file" accept=".pdf,application/pdf">
                    <button type="button" class="ebooks-file-control" data-ebook-file-trigger>
                      <span class="ebooks-file-control__icon"><?php echo render_icon('ebook', true); ?></span>
                      <span class="ebooks-file-control__copy">
                        <strong><?php echo customLang('ebook_sample_upload_title', 'Upload sample PDF'); ?></strong>
                        <small><?php echo customLang('ebook_sample_file_help', 'Optional preview shown before purchase.'); ?></small>
                        <em data-ebook-file-name><?php echo customLang('ebook_no_file_selected', 'No file selected'); ?></em>
                      </span>
                    </button>
                    <button type="button" class="ebooks-file-clear" data-ebook-file-clear hidden><?php echo render_icon('close', true); ?><span><?php echo customLang('ebook_file_remove', 'Remove'); ?></span></button>
                  </div>
                </div>
                <div class="ebooks-form-actions">
                  <div class="ebooks-form-message" id="ebooks-form-message" aria-live="polite"></div>
                  <div class="ebooks-publish-actions">
                    <button type="submit" data-publish-action="draft"><?php echo customLang('ebook_save_draft_button', 'Save draft'); ?></button>
                    <button type="submit" data-publish-action="submit"><?php echo customLang('ebook_submit_review_button', 'Submit for review'); ?></button>
                  </div>
                </div>
              </form>
            </section>
          </div>
        <?php endif; ?>

        <?php if ($ebooksEnabledPage): ?>
        <?php if ($viewerId > 0): ?>
        <div class="ebooks-purchase-modal" data-ebook-purchase-modal aria-hidden="true">
          <div class="ebooks-purchase-modal__backdrop" data-ebook-purchase-close></div>
          <section class="ebooks-purchase-modal__panel" role="dialog" aria-modal="true" aria-labelledby="ebooksPurchaseHeading">
            <button type="button" class="ebooks-purchase-modal__close" data-ebook-purchase-close aria-label="<?php echo iN_HelpSecure(customLang('close', 'Close')); ?>">
              <?php echo render_icon('close', true); ?>
            </button>
            <div class="ebooks-purchase-modal__head">
              <span class="ebooks-purchase-modal__icon"><?php echo render_icon('ebook', true); ?></span>
              <div>
                <h2 id="ebooksPurchaseHeading"><?php echo customLang('ebook_purchase_title', 'Buy eBook'); ?></h2>
                <p><?php echo customLang('ebook_purchase_subtitle', 'Choose a payment method to complete your purchase.'); ?></p>
              </div>
            </div>
            <div class="ebooks-purchase-summary">
              <div class="ebooks-purchase-summary__cover" data-ebook-purchase-cover><?php echo render_icon('ebook', true); ?></div>
              <div class="ebooks-purchase-summary__copy">
                <strong data-ebook-purchase-title></strong>
                <span data-ebook-purchase-creator></span>
              </div>
              <div class="ebooks-purchase-summary__price" data-ebook-purchase-price></div>
            </div>
            <form class="ebooks-payment-form" data-ebook-payment-form>
              <input type="hidden" name="p" value="ebook_create_payment">
              <input type="hidden" name="ebook_id" value="">
              <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($ebookCsrf, ENT_QUOTES, 'UTF-8'); ?>">
              <div class="ebooks-payment-methods" role="radiogroup" aria-label="<?php echo iN_HelpSecure(customLang('pay_payment_methods_title', 'Payment methods')); ?>">
                <?php $firstPaymentProvider = true; ?>
                <?php foreach ($availablePaymentProviders as $providerKey => $providerData): ?>
                  <label class="ebooks-payment-method">
                    <input type="radio" name="provider" value="<?php echo iN_HelpSecure($providerKey); ?>" <?php echo $firstPaymentProvider ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure((string)$providerData['currency']); ?>">
                    <span class="ebooks-payment-method__mark"></span>
                    <span class="ebooks-payment-method__label"><?php echo iN_HelpSecure((string)$providerData['label'], false); ?></span>
                    <?php if ($providerKey !== 'wallet'): ?>
                      <span class="ebooks-payment-method__meta"><?php echo iN_HelpSecure((string)$providerData['currency']); ?></span>
                    <?php endif; ?>
                  </label>
                  <?php $firstPaymentProvider = false; ?>
                <?php endforeach; ?>
              </div>
              <label class="ebook-coupon-field"><span><?php echo customLang('ebook_coupon_label','Coupon code'); ?></span><input type="text" name="coupon_code" maxlength="64" autocomplete="off"><button type="button" data-ebook-coupon-apply><?php echo customLang('ebook_coupon_apply','Apply'); ?></button></label><div data-ebook-coupon-message aria-live="polite"></div>
              <div class="ebooks-payment-message" data-ebook-payment-message aria-live="polite"></div>
              <button type="submit" class="ebooks-payment-submit"><?php echo customLang('ebook_pay_button', 'Pay now'); ?></button>
            </form>
          </section>
        </div>
        <?php endif; ?>
        <section class="ebooks-library full-width">
          <div class="ebooks-section-head">
            <div>
              <h2><?php echo customLang('ebooks_store_title', 'Store'); ?></h2>
              <p><?php echo customLang('ebooks_store_subtitle', 'Browse downloadable creator resources.'); ?></p>
            </div>
            <span class="ebooks-results-count"><?php echo iN_HelpSecure(strtr(customLang('ebooks_results_count', '{count} eBooks'), ['{count}' => (string)$ebookTotal])); ?></span>
          </div>
          <form class="ebooks-catalog-toolbar" method="get" action="<?php echo iN_HelpSecure($ebookBaseUrl . 'ebooks'); ?>">
            <label class="ebooks-catalog-search">
              <span class="ebooks-catalog-search__icon"><?php echo render_icon('search_icon', true); ?></span>
              <input type="search" name="ebook_q" value="<?php echo iN_HelpSecure((string)$ebookFilters['q']); ?>" placeholder="<?php echo iN_HelpSecure(customLang('ebooks_search_placeholder', 'Search title, creator or description')); ?>">
            </label>
            <label class="ebooks-catalog-select">
              <span><?php echo customLang('ebooks_category_label', 'Category'); ?></span>
              <select name="ebook_category">
                <option value="0"><?php echo customLang('ebooks_all_categories', 'All categories'); ?></option>
                <?php foreach ($ebookCategories as $category): ?>
                  <option value="<?php echo (int)$category['category_id']; ?>" <?php echo (int)$ebookFilters['category'] === (int)$category['category_id'] ? 'selected' : ''; ?>>
                    <?php echo iN_HelpSecure((string)$category['name']); ?> (<?php echo (int)$category['ebook_count']; ?>)
                  </option>
                <?php endforeach; ?>
              </select>
            </label>
            <label class="ebooks-catalog-select">
              <span><?php echo customLang('ebooks_price_filter_label', 'Price'); ?></span>
              <select name="ebook_price">
                <option value="all" <?php echo $ebookFilters['price'] === 'all' ? 'selected' : ''; ?>><?php echo customLang('ebooks_price_all', 'All prices'); ?></option>
                <option value="free" <?php echo $ebookFilters['price'] === 'free' ? 'selected' : ''; ?>><?php echo customLang('ebook_free_label', 'Free'); ?></option>
                <option value="paid" <?php echo $ebookFilters['price'] === 'paid' ? 'selected' : ''; ?>><?php echo customLang('ebooks_price_paid', 'Paid'); ?></option>
              </select>
            </label>
            <label class="ebooks-catalog-select">
              <span><?php echo customLang('ebooks_sort_label', 'Sort'); ?></span>
              <select name="ebook_sort">
                <option value="newest" <?php echo $ebookFilters['sort'] === 'newest' ? 'selected' : ''; ?>><?php echo customLang('ebooks_sort_newest', 'Newest'); ?></option>
                <option value="popular" <?php echo $ebookFilters['sort'] === 'popular' ? 'selected' : ''; ?>><?php echo customLang('ebooks_sort_popular', 'Best selling'); ?></option>
                <option value="rating" <?php echo $ebookFilters['sort'] === 'rating' ? 'selected' : ''; ?>><?php echo customLang('ebooks_sort_rating', 'Top rated'); ?></option>
                <option value="price_low" <?php echo $ebookFilters['sort'] === 'price_low' ? 'selected' : ''; ?>><?php echo customLang('ebooks_sort_price_low', 'Price: low to high'); ?></option>
                <option value="price_high" <?php echo $ebookFilters['sort'] === 'price_high' ? 'selected' : ''; ?>><?php echo customLang('ebooks_sort_price_high', 'Price: high to low'); ?></option>
              </select>
            </label>
            <button type="submit" class="ebooks-filter-submit"><?php echo render_icon('search_icon', true); ?><span><?php echo customLang('ebooks_apply_filters', 'Apply'); ?></span></button>
            <?php if ($ebookFilters['q'] !== '' || $ebookFilters['category'] > 0 || $ebookFilters['price'] !== 'all' || $ebookFilters['sort'] !== 'newest'): ?>
              <a class="ebooks-filter-reset" href="<?php echo iN_HelpSecure($ebookBaseUrl . 'ebooks'); ?>"><?php echo customLang('ebooks_clear_filters', 'Clear'); ?></a>
            <?php endif; ?>
          </form>
          <?php if (empty($ebooks)): ?>
            <div class="ebooks-empty flex align_items flexBoxColumn">
              <div class="ebooks-empty__icon flex align_items"><?php echo render_icon('not_founded', true); ?></div>
              <strong><?php echo customLang('ebooks_empty_title', 'No eBooks yet.'); ?></strong>
            </div>
          <?php else: ?>
            <div class="ebooks-grid">
              <?php foreach ($ebooks as $ebook): ?>
                <?php
                  $ebookId = (int)($ebook['ebook_id'] ?? 0);
                  $ownerId = (int)($ebook['owner_id'] ?? 0);
                  $price = (float)($ebook['price'] ?? 0);
                  $isOwner = $viewerId > 0 && $ownerId === $viewerId;
                  $isPurchased = (int)($ebook['viewer_purchased'] ?? 0) === 1;
                  $canDownload = $viewerId > 0 && ($isOwner || $isPurchased || $price <= 0);
                  $cover = trim((string)($ebook['cover_path'] ?? ''));
                  $coverUrl = $cover !== '' && function_exists('storage_resolve_media_url')
                    ? storage_resolve_media_url($cover, $ebookBaseUrl)
                    : '';
                  $creatorName = trim((string)($ebook['user_fullname'] ?? '')) ?: (string)($ebook['username'] ?? '');
                  $creatorAvatar = trim((string)($ebook['user_avatar'] ?? ''));
                  if ($creatorAvatar === '') { $creatorAvatar = 'uploads/avatars/default_avatar.png'; }
                  $creatorAvatarUrl = function_exists('storage_resolve_media_url') ? storage_resolve_media_url($creatorAvatar, $ebookBaseUrl) : $ebookBaseUrl . ltrim($creatorAvatar, '/');
                  $detailUrl = $ebookBaseUrl . 'ebook/' . rawurlencode((string)($ebook['slug'] ?? ''));
                ?>
                <article
                  class="ebook-card"
                  data-ebook-id="<?php echo $ebookId; ?>"
                  data-ebook-title="<?php echo iN_HelpSecure((string)($ebook['title'] ?? '')); ?>"
                  data-ebook-price="<?php echo iN_HelpSecure(number_format($price, 2, '.', '')); ?>"
                  data-ebook-price-display="<?php echo iN_HelpSecure($price > 0 ? $formatMoney($price, (string)($ebook['currency'] ?? null)) : customLang('ebook_free_label', 'Free')); ?>"
                  data-ebook-cover="<?php echo iN_HelpSecure($coverUrl); ?>"
                  data-ebook-creator="<?php echo iN_HelpSecure($creatorName); ?>"
                >
                  <div class="ebook-card__cover">
                    <?php if ($coverUrl !== ''): ?>
                      <img src="<?php echo iN_HelpSecure($coverUrl); ?>" alt="<?php echo iN_HelpSecure((string)($ebook['title'] ?? 'eBook')); ?>">
                    <?php else: ?>
                      <div class="ebook-card__placeholder flex align_items"><?php echo render_icon('ebook', true); ?></div>
                    <?php endif; ?>
                    <span class="ebook-card__price"><?php echo $price > 0 ? iN_HelpSecure($formatMoney($price, (string)($ebook['currency'] ?? null))) : customLang('ebook_free_label', 'Free'); ?></span>
                  </div>
                  <div class="ebook-card__body">
                    <h3><a href="<?php echo iN_HelpSecure($detailUrl); ?>"><?php echo iN_HelpSecure((string)($ebook['title'] ?? '')); ?></a></h3>
                    <?php if (trim((string)($ebook['description'] ?? '')) !== ''): ?>
                      <p><?php echo iN_HelpSecure((string)$ebook['description']); ?></p>
                    <?php endif; ?>
                    <div class="ebook-card__creator">
                      <img src="<?php echo iN_HelpSecure($creatorAvatarUrl); ?>" alt="<?php echo iN_HelpSecure($creatorName); ?>">
                      <span><?php echo iN_HelpSecure($creatorName); ?></span>
                    </div>
                  </div>
                  <div class="ebook-card__actions">
                    <?php if ($canDownload): ?>
                      <a href="#" class="ebook-download-btn" data-secure-ebook-download data-ebook-id="<?php echo $ebookId; ?>"><?php echo customLang('ebook_download_button', 'Download'); ?></a>
                    <?php elseif ($viewerId <= 0): ?>
                      <a href="<?php echo iN_HelpSecure($ebookBaseUrl . 'login'); ?>" class="ebook-download-btn"><?php echo customLang('ebook_login_to_buy', 'Log in to buy'); ?></a>
                    <?php else: ?>
                      <button type="button" class="ebook-purchase-btn" data-ebook-id="<?php echo $ebookId; ?>"><?php echo customLang('ebook_buy_button', 'Buy'); ?></button>
                    <?php endif; ?>
                  </div>
                </article>
              <?php endforeach; ?>
            </div>
            <?php if ($ebookPageCount > 1): ?>
              <nav class="ebooks-pagination" aria-label="<?php echo iN_HelpSecure(customLang('ebooks_pagination_label', 'eBook pages')); ?>">
                <?php for ($pageNumber = 1; $pageNumber <= $ebookPageCount; $pageNumber++): ?>
                  <?php $pageQuery = array_filter([
                    'ebook_q' => $ebookFilters['q'],
                    'ebook_category' => $ebookFilters['category'] ?: null,
                    'ebook_price' => $ebookFilters['price'] !== 'all' ? $ebookFilters['price'] : null,
                    'ebook_sort' => $ebookFilters['sort'] !== 'newest' ? $ebookFilters['sort'] : null,
                    'ebook_page' => $pageNumber,
                  ], static fn($value) => $value !== null && $value !== ''); ?>
                  <a href="<?php echo iN_HelpSecure($ebookBaseUrl . 'ebooks?' . http_build_query($pageQuery)); ?>" class="<?php echo $pageNumber === $ebookPage ? 'is-active' : ''; ?>" <?php echo $pageNumber === $ebookPage ? 'aria-current="page"' : ''; ?>><?php echo $pageNumber; ?></a>
                <?php endfor; ?>
              </nav>
            <?php endif; ?>
          <?php endif; ?>
        </section>
        <?php endif; ?>
      </div>
    </div>
    <div class="content-right flex align_items">
      <div class="content-right-container">
        <?php
          include_once __DIR__ . '/widgets/suggestedUsers.php';
          include_once __DIR__ . '/widgets/adsSidebar.php';
          $hideMostPopularIfEmpty = true;
          include_once __DIR__ . '/widgets/mosPopularPost.php';
          unset($hideMostPopularIfEmpty);
        ?>
      </div>
    </div>
  </div>
</div>

<?php $ebooksThemePath = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme); ?>
<script defer src="<?php echo $ebooksThemePath; ?>/js/ebooks.js?v=<?php echo iN_HelpSecure($version); ?>"></script>
