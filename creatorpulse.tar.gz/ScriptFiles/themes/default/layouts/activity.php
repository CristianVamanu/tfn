<?php
declare(strict_types=1);

if (!isset($loggedIn) || $loggedIn !== '1' || !isset($userID) || (int) $userID <= 0) {
    echo '<div class="warning_box full-width flex align_items_justify_content pad-24">' . customLang('login_required') . '</div>';
    return;
}

$userId = (int) $userID;
$pdo = null;
if (isset($RL) && is_object($RL) && method_exists($RL, 'getDb')) {
    $pdo = $RL->getDb();
} elseif (isset($db) && $db instanceof PDO) {
    $pdo = $db;
}

$currencyCode   = isset($currency) ? strtoupper((string) $currency) : 'USD';
$currencyMap    = isset($currencys) && is_array($currencys) ? $currencys : [];
$currencySymbol = isset($currencyMap[$currencyCode]) ? (string) $currencyMap[$currencyCode] : '$';

$formatAmount = static function (?float $amount, ?string $code) use ($currencyMap, $currencySymbol, $currencyCode): string {
    if (!is_numeric($amount)) {
        return '';
    }
    $value = (float) $amount;
    $displayCurrency = $code !== null && $code !== '' ? strtoupper($code) : $currencyCode;
    $displaySymbol = isset($currencyMap[$displayCurrency]) ? (string) $currencyMap[$displayCurrency] : $currencySymbol;
    return dz_format_currency(
        $value,
        $displayCurrency,
        $displaySymbol,
        $GLOBALS['currency_format_settings'] ?? null
    );
};

$normalizeName = static function (?string $fullName, ?string $username): string {
    $name = trim((string) $fullName);
    if ($name === '') {
        $name = trim((string) $username);
    }
    if ($name === '') {
        $name = customLang('activity_unknown_user', 'Someone');
    }
    return $name;
};

$buildProfileLink = static function (?string $username): string {
    $candidate = trim((string) $username);
    if ($candidate === '') {
        return '';
    }
    $candidate = ltrim($candidate, '@');
    if ($candidate === '') {
        return '';
    }
    $encoded = rawurlencode($candidate);
    return 'profile/' . $encoded;
};

$buildPostLink = static function (?int $postId, ?string $ownerUsername): string {
    $id = (int) ($postId ?? 0);
    if ($id <= 0) {
        return '';
    }
    $owner = trim((string) $ownerUsername);
    $owner = $owner !== '' ? ltrim($owner, '@') : '';
    $url = 'posts/' . $id;
    if ($owner !== '') {
        $url .= '/' . rawurlencode($owner);
    }
    return $url;
};

$resolveAvatarUrl = static function (?string $avatar): string {
    $path = trim((string) $avatar);
    if ($path === '') {
        $path = 'uploads/user_avatars/default.jpeg';
    }
    return storage_url($path);
};

$locale = 'en';
if (isset($currentLang) && is_string($currentLang) && $currentLang !== '') {
    $localeSlug = strtolower((string) $currentLang);
    $locale = substr($localeSlug, 0, 2);
}

$formatRelativeTime = static function (int $timestamp, string $locale): string {
    if ($timestamp <= 0) {
        return '';
    }
    try {
        return RelativeTime::format($timestamp, null, $locale);
    } catch (Throwable $__) {
        return '';
    }
};

$formatStatus = static function (?string $status): string {
    $raw = strtolower(trim((string) $status));
    if ($raw === '') {
        return '';
    }
    $slug = preg_replace('~[^a-z0-9]+~', '_', $raw);
    $key = 'activity_status_' . $slug;
    $label = customLang($key);
    if ($label === $key || $label === '') {
        $label = ucwords(str_replace(['_', '-'], ' ', $raw));
    }
    return $label;
};

$formatPlanLabel = static function (?string $plan): string {
    $raw = strtolower(trim((string) $plan));
    if ($raw === '') {
        return '';
    }
    $slug = preg_replace('~[^a-z0-9]+~', '_', $raw);
    $key = 'activity_plan_' . $slug;
    $label = customLang($key);
    if ($label === $key || $label === '') {
        $label = ucwords(str_replace(['_', '-'], ' ', $raw));
    }
    return $label;
};

$formatEventLabel = static function (?string $event) {
    $raw = strtolower(trim((string) $event));
    if ($raw === '') {
        return customLang('activity_subscription_event_unknown', 'Subscription update');
    }
    $slug = preg_replace('~[^a-z0-9]+~', '_', $raw);
    $key = 'activity_subscription_event_' . $slug;
    $label = customLang($key);
    if ($label === $key || $label === '') {
        $label = ucwords(str_replace(['_', '-'], ' ', $raw));
    }
    return $label;
};

$activitySections = [
    'subscriptions' => [
        'label' => customLang('activity_section_subscriptions', 'Subscriptions'),
        'empty' => customLang('activity_section_empty_subscriptions', 'No subscription activity recorded yet.'),
        'items' => [],
    ],
    'tips' => [
        'label' => customLang('activity_section_tips', 'Tips Sent'),
        'empty' => customLang('activity_section_empty_tips', 'No tips sent yet.'),
        'items' => [],
    ],
    'purchases' => [
        'label' => customLang('activity_section_purchases', 'Post Purchases'),
        'empty' => customLang('activity_section_empty_purchases', 'No post purchases yet.'),
        'items' => [],
    ],
    'likes' => [
        'label' => customLang('activity_section_likes', 'Likes'),
        'empty' => customLang('activity_section_empty_likes', 'No likes yet.'),
        'items' => [],
    ],
    'comments' => [
        'label' => customLang('activity_section_comments', 'Comments'),
        'empty' => customLang('activity_section_empty_comments', 'No comments yet.'),
        'items' => [],
    ],
];

if ($pdo instanceof PDO) {
    try {
        // Subscriptions
        $subscriptionSql = "
            SELECT
                p.id,
                p.recipient_id,
                p.plan_interval,
                p.amount,
                p.currency,
                p.status,
                p.event,
                p.created_at,
                p.updated_at,
                u.username,
                u.user_fullname,
                u.user_avatar,
                u.verified_status
            FROM i_subscription_payments AS p
            LEFT JOIN i_users AS u ON u.user_id = p.recipient_id
            WHERE p.buyer_id = :uid
            ORDER BY p.created_at DESC, p.id DESC
            LIMIT 40
        ";
        $subscriptionStmt = $pdo->prepare($subscriptionSql);
        $subscriptionStmt->bindValue(':uid', $userId, PDO::PARAM_INT);
        $subscriptionStmt->execute();
        $subscriptionRows = $subscriptionStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        foreach ($subscriptionRows as $row) {
            $name = $normalizeName($row['user_fullname'] ?? null, $row['username'] ?? null);
            $profileUrl = $buildProfileLink($row['username'] ?? null);
            $avatarUrl = $resolveAvatarUrl($row['user_avatar'] ?? null);
            $verified = !empty($row['verified_status']);
            $planLabel = $formatPlanLabel($row['plan_interval'] ?? null);
            $statusLabel = $formatStatus($row['status'] ?? null);
            $eventLabel = $formatEventLabel($row['event'] ?? null);
            $amountValue = isset($row['amount']) ? (float) $row['amount'] : null;
            $amountText = $formatAmount($amountValue, $row['currency'] ?? null);
            $timeLabel = $formatRelativeTime((int) ($row['created_at'] ?? 0), $locale);
            $postUrl = '';

            $metaItems = [];
            if ($planLabel !== '') {
                $metaItems[] = strtr(customLang('activity_meta_plan', 'Plan: {plan}'), ['{plan}' => $planLabel]);
            }
            if ($statusLabel !== '') {
                $metaItems[] = strtr(customLang('activity_meta_status', 'Status: {status}'), ['{status}' => $statusLabel]);
            }
            $activitySections['subscriptions']['items'][] = [
                'name' => $name,
                'username' => (string) ($row['username'] ?? ''),
                'profile' => $profileUrl,
                'avatar' => $avatarUrl,
                'verified' => $verified,
                'type_label' => customLang('activity_label_subscription', 'Subscription'),
                'summary' => $eventLabel,
                'meta' => $metaItems,
                'amount' => $amountText,
                'time' => $timeLabel,
                'url' => $postUrl,
            ];
        }

        // Tips
        $tipSql = "
            SELECT
                tp.id,
                tp.recipient_id,
                tp.post_id,
                tp.amount,
                tp.net_amount,
                tp.currency,
                tp.status,
                tp.event,
                tp.created_at,
                u.username,
                u.user_fullname,
                u.user_avatar,
                u.verified_status
            FROM i_tip_payments tp
            LEFT JOIN i_users u ON u.user_id = tp.recipient_id
            WHERE tp.buyer_id = :uid
            ORDER BY tp.created_at DESC, tp.id DESC
            LIMIT 40
        ";
        $tipStmt = $pdo->prepare($tipSql);
        $tipStmt->bindValue(':uid', $userId, PDO::PARAM_INT);
        $tipStmt->execute();
        $tipRows = $tipStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        foreach ($tipRows as $row) {
            $name = $normalizeName($row['user_fullname'] ?? null, $row['username'] ?? null);
            $profileUrl = $buildProfileLink($row['username'] ?? null);
            $avatarUrl = $resolveAvatarUrl($row['user_avatar'] ?? null);
            $verified = !empty($row['verified_status']);
            $statusLabel = $formatStatus($row['status'] ?? null);
            $amountValue = isset($row['net_amount']) && is_numeric($row['net_amount']) ? (float) $row['net_amount'] : (isset($row['amount']) ? (float) $row['amount'] : null);
            $amountText = $formatAmount($amountValue, $row['currency'] ?? null);
            $timeLabel = $formatRelativeTime((int) ($row['created_at'] ?? 0), $locale);
            $postId = isset($row['post_id']) ? (int) $row['post_id'] : 0;
            $postUrl = $buildPostLink($postId, $row['username'] ?? null);

            $metaItems = [];
            if (!empty($row['post_id'])) {
                $metaItems[] = strtr(customLang('activity_post_reference', 'Post #{id}'), ['{id}' => (int) $row['post_id']]);
            }
            if ($statusLabel !== '') {
                $metaItems[] = strtr(customLang('activity_meta_status', 'Status: {status}'), ['{status}' => $statusLabel]);
            }

            $activitySections['tips']['items'][] = [
                'name' => $name,
                'username' => (string) ($row['username'] ?? ''),
                'profile' => $profileUrl,
                'avatar' => $avatarUrl,
                'verified' => $verified,
                'type_label' => customLang('activity_label_tip', 'Tip'),
                'summary' => customLang('activity_tip_summary', 'Tip sent'),
                'meta' => $metaItems,
                'amount' => $amountText,
                'time' => $timeLabel,
                'url' => $postUrl,
            ];
        }

        // Purchases
        $purchaseSql = "
            SELECT
                pp.id,
                pp.post_id,
                pp.recipient_id,
                pp.amount,
                pp.net_amount,
                pp.currency,
                pp.status,
                pp.event,
                pp.created_at,
                u.username,
                u.user_fullname,
                u.user_avatar,
                u.verified_status,
                up.post_type
            FROM i_post_purchases pp
            LEFT JOIN i_users u ON u.user_id = pp.recipient_id
            LEFT JOIN i_user_posts up ON up.post_id = pp.post_id
            WHERE pp.buyer_id = :uid
            ORDER BY pp.created_at DESC, pp.id DESC
            LIMIT 40
        ";
        $purchaseStmt = $pdo->prepare($purchaseSql);
        $purchaseStmt->bindValue(':uid', $userId, PDO::PARAM_INT);
        $purchaseStmt->execute();
        $purchaseRows = $purchaseStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        foreach ($purchaseRows as $row) {
            $name = $normalizeName($row['user_fullname'] ?? null, $row['username'] ?? null);
            $profileUrl = $buildProfileLink($row['username'] ?? null);
            $avatarUrl = $resolveAvatarUrl($row['user_avatar'] ?? null);
            $verified = !empty($row['verified_status']);
            $statusLabel = $formatStatus($row['status'] ?? null);
            $amountValue = isset($row['net_amount']) && is_numeric($row['net_amount']) ? (float) $row['net_amount'] : (isset($row['amount']) ? (float) $row['amount'] : null);
            $amountText = $formatAmount($amountValue, $row['currency'] ?? null);
            $timeLabel = $formatRelativeTime((int) ($row['created_at'] ?? 0), $locale);
            $postId = isset($row['post_id']) ? (int) $row['post_id'] : 0;
            $postUrl = $buildPostLink($postId, $row['username'] ?? null);

            $metaItems = [];
            if (!empty($row['post_id'])) {
                $metaItems[] = strtr(customLang('activity_post_reference', 'Post #{id}'), ['{id}' => (int) $row['post_id']]);
            }
            if (!empty($row['post_type'])) {
                $typeSlug = strtolower((string) $row['post_type']);
                $typeKey = 'activity_post_type_' . preg_replace('~[^a-z0-9]+~', '_', $typeSlug);
                $typeLabel = customLang($typeKey);
                if ($typeLabel === $typeKey || $typeLabel === '') {
                    $typeLabel = ucwords(str_replace(['_', '-'], ' ', $typeSlug));
                }
                if ($typeLabel !== '') {
                    $metaItems[] = strtr(customLang('activity_meta_post_type', 'Post type: {type}'), ['{type}' => $typeLabel]);
                }
            }
            if ($statusLabel !== '') {
                $metaItems[] = strtr(customLang('activity_meta_status', 'Status: {status}'), ['{status}' => $statusLabel]);
            }

            $activitySections['purchases']['items'][] = [
                'name' => $name,
                'username' => (string) ($row['username'] ?? ''),
                'profile' => $profileUrl,
                'avatar' => $avatarUrl,
                'verified' => $verified,
                'type_label' => customLang('activity_label_purchase', 'Purchase'),
                'summary' => customLang('activity_purchase_summary', 'Post unlocked'),
                'meta' => $metaItems,
                'amount' => $amountText,
                'time' => $timeLabel,
                'url' => $postUrl,
            ];
        }

        // Likes
        $likeSql = "
            SELECT
                l.like_id,
                l.liked_item_id,
                l.liked_time,
                up.post_type,
                up.post_text,
                up.post_created_time,
                owner.username,
                owner.user_fullname,
                owner.user_avatar,
                owner.verified_status
            FROM i_post_liked l
            LEFT JOIN i_user_posts up ON up.post_id = l.liked_item_id
            LEFT JOIN i_users owner ON owner.user_id = up.post_owner_id
            WHERE l.uid_fk = :uid_like AND l.liked_item_type = 'post'
            ORDER BY l.liked_time DESC, l.like_id DESC
            LIMIT 40
        ";
        $likeStmt = $pdo->prepare($likeSql);
        $likeStmt->bindValue(':uid_like', $userId, PDO::PARAM_INT);
        $likeStmt->execute();
        $likeRows = $likeStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        foreach ($likeRows as $row) {
            $name = $normalizeName($row['user_fullname'] ?? null, $row['username'] ?? null);
            $profileUrl = $buildProfileLink($row['username'] ?? null);
            $avatarUrl = $resolveAvatarUrl($row['user_avatar'] ?? null);
            $verified = !empty($row['verified_status']);
            $postId = isset($row['liked_item_id']) ? (int) $row['liked_item_id'] : 0;
            $timeReference = (int) ($row['liked_time'] ?? 0);
            if ($timeReference <= 0) {
                $timeReference = (int) ($row['post_created_time'] ?? 0);
            }
            $timeLabel = $formatRelativeTime($timeReference, $locale);
            $postId = isset($row['liked_item_id']) ? (int) $row['liked_item_id'] : 0;
            $postUrl = $buildPostLink($postId, $row['username'] ?? null);

            $metaItems = [];
            if ($postId > 0) {
                $metaItems[] = strtr(customLang('activity_post_reference', 'Post #{id}'), ['{id}' => $postId]);
            }
            if (!empty($row['post_type'])) {
                $typeSlug = strtolower((string) $row['post_type']);
                $typeKey = 'activity_post_type_' . preg_replace('~[^a-z0-9]+~', '_', $typeSlug);
                $typeLabel = customLang($typeKey);
                if ($typeLabel === $typeKey || $typeLabel === '') {
                    $typeLabel = ucwords(str_replace(['_', '-'], ' ', $typeSlug));
                }
                if ($typeLabel !== '') {
                    $metaItems[] = strtr(customLang('activity_meta_post_type', 'Post type: {type}'), ['{type}' => $typeLabel]);
                }
            }
            $postText = trim((string) ($row['post_text'] ?? ''));
            if ($postText !== '') {
                $excerptSource = strip_tags($postText);
                if (function_exists('mb_strimwidth')) {
                    $excerpt = trim(mb_strimwidth($excerptSource, 0, 90, '…', 'UTF-8'));
                } else {
                    $excerpt = trim(substr($excerptSource, 0, 90));
                    if (strlen($excerptSource) > 90) {
                        $excerpt .= '…';
                    }
                }
                if ($excerpt !== '') {
                    $metaItems[] = strtr(customLang('activity_meta_excerpt', '“{excerpt}”'), ['{excerpt}' => $excerpt]);
                }
            }

            $activitySections['likes']['items'][] = [
                'name' => $name,
                'username' => (string) ($row['username'] ?? ''),
                'profile' => $profileUrl,
                'avatar' => $avatarUrl,
                'verified' => $verified,
                'type_label' => customLang('activity_label_like', 'Like'),
                'summary' => customLang('activity_like_summary', 'Post liked'),
                'meta' => $metaItems,
                'amount' => '',
                'time' => $timeLabel,
                'url' => $postUrl,
            ];
        }

        // Comments
        $commentSql = "
            SELECT
                c.c_id,
                c.item_id,
                c.comment,
                c.created_time,
                up.post_type,
                owner.username,
                owner.user_fullname,
                owner.user_avatar,
                owner.verified_status
            FROM i_comments c
            LEFT JOIN i_user_posts up ON up.post_id = c.item_id
            LEFT JOIN i_users owner ON owner.user_id = up.post_owner_id
            WHERE c.uid_fk = :uid_comment
            ORDER BY c.created_time DESC, c.c_id DESC
            LIMIT 40
        ";
        $commentStmt = $pdo->prepare($commentSql);
        $commentStmt->bindValue(':uid_comment', $userId, PDO::PARAM_INT);
        $commentStmt->execute();
        $commentRows = $commentStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        foreach ($commentRows as $row) {
            $name = $normalizeName($row['user_fullname'] ?? null, $row['username'] ?? null);
            $profileUrl = $buildProfileLink($row['username'] ?? null);
            $avatarUrl = $resolveAvatarUrl($row['user_avatar'] ?? null);
            $verified = !empty($row['verified_status']);
            $postId = isset($row['item_id']) ? (int) $row['item_id'] : 0;
            $timeLabel = $formatRelativeTime((int) ($row['created_time'] ?? 0), $locale);
            $postUrl = $buildPostLink($postId, $row['username'] ?? null);

            $metaItems = [];
            if ($postId > 0) {
                $metaItems[] = strtr(customLang('activity_post_reference', 'Post #{id}'), ['{id}' => $postId]);
            }
            if (!empty($row['post_type'])) {
                $typeSlug = strtolower((string) $row['post_type']);
                $typeKey = 'activity_post_type_' . preg_replace('~[^a-z0-9]+~', '_', $typeSlug);
                $typeLabel = customLang($typeKey);
                if ($typeLabel === $typeKey || $typeLabel === '') {
                    $typeLabel = ucwords(str_replace(['_', '-'], ' ', $typeSlug));
                }
                if ($typeLabel !== '') {
                    $metaItems[] = strtr(customLang('activity_meta_post_type', 'Post type: {type}'), ['{type}' => $typeLabel]);
                }
            }
            $commentText = trim((string) ($row['comment'] ?? ''));
            if ($commentText !== '') {
                $plain = strip_tags($commentText);
                if (function_exists('mb_strimwidth')) {
                    $excerpt = trim(mb_strimwidth($plain, 0, 140, '…', 'UTF-8'));
                } else {
                    $excerpt = trim(substr($plain, 0, 140));
                    if (strlen($plain) > 140) {
                        $excerpt .= '…';
                    }
                }
                if ($excerpt !== '') {
                    $metaItems[] = strtr(customLang('activity_meta_excerpt', '“{excerpt}”'), ['{excerpt}' => $excerpt]);
                }
            }

            $activitySections['comments']['items'][] = [
                'name' => $name,
                'username' => (string) ($row['username'] ?? ''),
                'profile' => $profileUrl,
                'avatar' => $avatarUrl,
                'verified' => $verified,
                'type_label' => customLang('activity_label_comment', 'Comment'),
                'summary' => customLang('activity_comment_summary', 'Commented on a post'),
                'meta' => $metaItems,
                'amount' => '',
                'time' => $timeLabel,
                'url' => $postUrl,
            ];
        }
    } catch (Throwable $activityError) {
        // Leave sections empty but provide a fallback message below.
    }
}

$hasItems = false;
foreach ($activitySections as $section) {
    if (!empty($section['items'])) {
        $hasItems = true;
        break;
    }
}
?>

<div class="main-content flex align_items">
  <div class="content-area flex">
    <div class="content-left">
      <div class="activity-page">
        <header class="activity-page__header">
          <h1 class="activity-page__heading"><?php echo customLang('menu_your_activity'); ?></h1>
        </header>

        <div class="activity-page__body">
          <article class="admin-card card list-card activity-page__card" role="region" aria-labelledby="activityListHeading">
            <div class="list-header" id="activityListHeading">
              <span class="icon"><?php echo render_icon('activity', true); ?></span>
              <span><strong><?php echo customLang('menu_your_activity'); ?></strong></span>
            </div>

            <?php if ($pdo instanceof PDO && $hasItems): ?>
              <div class="activity-page__sections">
                <?php foreach ($activitySections as $sectionKey => $section): ?>
                  <section class="activity-page__section" aria-label="<?php echo iN_HelpSecure($section['label']); ?>">
                    <h2 class="activity-page__section-title"><?php echo iN_HelpSecure($section['label']); ?></h2>
                    <?php if (empty($section['items'])): ?>
                      <p class="activity-page__section-empty"><?php echo iN_HelpSecure($section['empty']); ?></p>
                    <?php else: ?>
                      <ul class="activity-list">
                        <?php foreach ($section['items'] as $item): ?>
                          <?php
                            $itemUrl = isset($item['url']) ? trim((string) $item['url']) : '';
                            $hasItemLink = $itemUrl !== '';
                            $itemClasses = 'activity-item';
                            if ($hasItemLink) {
                                $itemClasses .= ' activity-item--has-link';
                            }
                          ?>
                          <li class="<?php echo htmlspecialchars($itemClasses, ENT_QUOTES, 'UTF-8'); ?>"<?php if ($hasItemLink) { echo ' data-post-url="' . iN_HelpSecure($itemUrl) . '" role="link" tabindex="0"'; } ?>>
                            <div class="avatar-stack">
                              <?php if ($item['profile'] !== ''): ?>
                                <a class="avatar-link" href="<?php echo iN_HelpSecure($item['profile']); ?>">
                                  <img src="<?php echo iN_HelpSecure($item['avatar']); ?>" alt="<?php echo iN_HelpSecure(sprintf(customLang('alt_avatar_of_user', 'Avatar of %s'), $item['name'])); ?>" loading="lazy">
                                </a>
                              <?php else: ?>
                                <img src="<?php echo iN_HelpSecure($item['avatar']); ?>" alt="<?php echo iN_HelpSecure(sprintf(customLang('alt_avatar_of_user', 'Avatar of %s'), $item['name'])); ?>" loading="lazy">
                              <?php endif; ?>
                            </div>
                            <div class="activity-body">
                              <div class="title">
                                <?php if ($item['profile'] !== ''): ?>
                                  <a class="activity-name" href="<?php echo iN_HelpSecure($item['profile']); ?>"><?php echo iN_HelpSecure($item['name']); ?></a>
                                <?php else: ?>
                                  <strong><?php echo iN_HelpSecure($item['name']); ?></strong>
                                <?php endif; ?>
                                <?php if (!empty($item['verified'])): ?>
                                  <span class="verified-badge"><?php echo render_icon('verified', true); ?></span>
                                <?php endif; ?>
                                <span class="activity-chip"><?php echo iN_HelpSecure($item['type_label']); ?></span>
                                <?php if (!empty($item['summary'])): ?>
                                  <span><?php echo iN_HelpSecure($item['summary']); ?></span>
                                <?php endif; ?>
                              </div>
                              <div class="meta">
                                <?php if (!empty($item['meta'])): ?>
                                  <?php foreach ($item['meta'] as $metaText): ?>
                                    <?php if ($metaText === '') { continue; } ?>
                                    <span class="activity-meta__item"><?php echo iN_HelpSecure($metaText); ?></span>
                                  <?php endforeach; ?>
                                <?php endif; ?>
                                <?php if (!empty($item['amount'])): ?>
                                  <span class="activity-meta__item activity-meta__amount"><?php echo iN_HelpSecure($item['amount']); ?></span>
                                <?php endif; ?>
                                <?php if (!empty($item['time'])): ?>
                                  <span class="activity-meta__item activity-meta__time"><?php echo iN_HelpSecure($item['time']); ?></span>
                                <?php endif; ?>
                              </div>
                            </div>
                          </li>
                        <?php endforeach; ?>
                      </ul>
                    <?php endif; ?>
                  </section>
                <?php endforeach; ?>
              </div>
            <?php elseif ($pdo instanceof PDO): ?>
              <div class="activity-page__empty">
                <span class="activity-page__empty-icon"><?php echo render_icon('sparkles', true); ?></span>
                <p><?php echo customLang('activity_empty_state', 'You have no recorded activity yet.'); ?></p>
              </div>
            <?php else: ?>
              <div class="activity-page__empty">
                <span class="activity-page__empty-icon"><?php echo render_icon('warning', true); ?></span>
                <p><?php echo customLang('activity_data_unavailable', 'Activity data is temporarily unavailable.'); ?></p>
              </div>
            <?php endif; ?>
          </article>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
    $activityThemeBase = rtrim((string) ($base_url ?? ''), '/');
    $activityThemeBase = $activityThemeBase !== ''
        ? $activityThemeBase . '/themes/' . $currentTheme
        : 'themes/' . $currentTheme;
    $activityThemeBase = iN_HelpSecure($activityThemeBase);
?>
<script defer src="<?php echo $activityThemeBase; ?>/js/activityPage.js?v=<?php echo iN_HelpSecure($version); ?>"></script>
