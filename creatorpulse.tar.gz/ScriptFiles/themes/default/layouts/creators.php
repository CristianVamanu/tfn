<?php
$viewerId = 0;
if (isset($userID)) {
    $viewerId = (int) $userID;
} elseif (isset($userData['user_id'])) {
    $viewerId = (int) $userData['user_id'];
} elseif (isset($_SESSION['iuid'])) {
    $viewerId = (int) $_SESSION['iuid'];
}

foreach ($creators as $c):
        $dataUserFullName = (string) ($c['user_fullname'] ?? '');
        $dataUserUserID   = (int)    ($c['user_id'] ?? 0);
        $dataUsername     = (string) ($c['username'] ?? '');
        $dataUserBio      = (string) ($c['about_me'] ?? '');
        $isVerified       = (int)    ($c['verified_status'] ?? 0) === 1;
        if ($dataUserFullName === '') {
            $dataUserFullName = $dataUsername;
        }
        // Avatar helper (falls back internally if your helper does)
        if (method_exists($RL, 'RL_userAvatar')) {
            $avatarRel = $RL->RL_userAvatar($dataUserUserID);
        } else {
            $avatarRel = (string) ($c['user_avatar'] ?? 'uploads/avatars/default_avatar.png');
        }
        $defaultUserAvatar = storage_url($avatarRel);

        $postsCount     = (int) ($c['posts_count'] ?? 0);
        $followersCount = (int) ($c['followers_count'] ?? 0);
        $followingCount = (int) ($c['following_count'] ?? 0);

        // Short number formatting with graceful fallback
        $fmt = function (int $n): string {
            if (function_exists('number_format_short')) {
                return number_format_short($n);
            }
            // fallback: standard number_format
            return number_format($n, 0, '.', ',');
        };
        $postsCountFmt     = $fmt($postsCount);
        $followersCountFmt = $fmt($followersCount);
        $followingCountFmt = $fmt($followingCount);

        $latest = (array) ($c['latest_posts'] ?? []);
?>
<!---->
<div class="creator-wrapper full-width flex align_items flexBoxColumn relative transition">
    <div class="creator-avatar-container full-width flex align_items">
        <a href="<?php echo iN_HelpSecure($baseUrl . 'profile/' . $dataUsername); ?>" class="creator-avatar relative flex align_items">
            <?php $__alt = sprintf(customLang('alt_avatar_of_user'), $dataUserFullName ?: $dataUsername); ?>
            <img class="flex align_items" src="<?php echo htmlspecialchars($defaultUserAvatar, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo iN_HelpSecure($__alt); ?>">
        </a>
    </div>

    <div class="creator-info-wrapper flex align_items flexBoxColumn transition">
        <a href="<?php echo iN_HelpSecure($baseUrl . 'profile/' . $dataUsername); ?>" class="creator-name-username full-width flex align_items_justify_content">
            <?php echo htmlspecialchars($dataUserFullName, ENT_QUOTES, 'UTF-8'); ?>
            <?php if ($isVerified): ?>
                <span class="flex align_items verified-badge">
                    <?php echo render_icon('verified', true); ?>
                </span>
            <?php endif; ?>
        </a>

        <a href="<?php echo iN_HelpSecure($baseUrl . 'profile/' . $dataUsername); ?>" class="creator-username full-width flex align_items_justify_content">
            <?php echo '@' . htmlspecialchars($dataUsername, ENT_QUOTES, 'UTF-8'); ?>
        </a>

        <div class="creator-post-following-followers full-width flex align_items_justify_content">
            <div class="creator-pff-wrapper full-width flex align_items_justify_content flexBoxColumn">
                <div class="full-width flex align_items_justify_content"><?php echo $postsCountFmt; ?></div>
                <div class="full-width flex align_items_justify_content ppf-count"><?php echo customLang('social_posts'); ?></div>
            </div>
            <div class="creator-pff-wrapper full-width flex align_items_justify_content flexBoxColumn">
                <div class="full-width flex align_items_justify_content"><?php echo $followersCountFmt; ?></div>
                <div class="full-width flex align_items_justify_content ppf-count"><?php echo customLang('social_followers'); ?></div>
            </div>
            <div class="creator-pff-wrapper full-width flex align_items_justify_content flexBoxColumn">
                <div class="full-width flex align_items_justify_content"><?php echo $followingCountFmt; ?></div>
                <div class="full-width flex align_items_justify_content ppf-count"><?php echo customLang('social_following'); ?></div>
            </div>
        </div>

        <div class="creator-las-three-post full-width flex align_items relative">
            <?php
            $rendered = 0;
            foreach ($latest as $lp):
                $type   = (string) ($lp['post_type'] ?? '');
                $srcRel = (string) ($lp['media_thumb'] ?? '');
                if ($srcRel === '') { continue; }

                if ($type === 'video' && isset($RL) && method_exists($RL, 'videoThumbNail')) {
                    $thumbUrl = storage_url($srcRel);
                    if ($thumbUrl !== '') {
                        try { $thumbUrl = $RL->videoThumbNail($thumbUrl); } catch (Throwable $__) {}
                    }
                } else {
                    $thumbUrl = storage_url($srcRel);
                }
                $rendered++;
                ?>
                <div class="creator-latest-post flex align_items">
                    <a href="<?php echo iN_HelpSecure($baseUrl . 'posts/' . (int)($lp['post_id'] ?? 0) . '/' . $dataUsername); ?>">
                        <?php $__tileAlt = sprintf(customLang('alt_tile_by_user'), $dataUsername); ?>
                        <img src="<?php echo htmlspecialchars($thumbUrl, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy" alt="<?php echo iN_HelpSecure($__tileAlt); ?>">
                    </a>
                </div>
            <?php endforeach; ?>
            <?php if($rendered == '0'): ?>
                <div class="no-post-shared-yet flex align_items_justify_content gap flexBoxColumn">
                    <div class="no-post-icon flex align_items"><?php echo render_icon('media', false); ?></div>
                    <div class="no-post-title flex align_items"><?php echo customLang('no_posts_yet'); ?></div>
                </div>
            <?php endif;?>
            <?php for ($i = $rendered; $i < 3; $i++): ?>
                <div class="creator-latest-post creator-latest-post--placeholder flex align_items" aria-hidden="true" role="presentation">
                    <div class="creator-latest-post__empty"></div>
                </div>
            <?php endfor; ?>
        </div>

        <div class="creator-follow-btn-wrapper flex align_items full-width">
            <?php
                $alreadyFollowing = false;
                if ($viewerId > 0 && method_exists($RL, 'RL_IsFollowing')) {
                    $alreadyFollowing = $RL->RL_IsFollowing($viewerId, (int) $dataUserUserID);
                }
                ?>
                <?php if ($viewerId > 0 && !$alreadyFollowing): ?>
                <div class="follow_user full-width align_items_justify_content flex transition_background_color follow_this_user"
                    data-id="<?php echo (int)$dataUserUserID; ?>">
                <span class="follow_me flex align_items">
                    <?php echo render_icon('follow', true); ?>
                </span> <?php echo customLang('live_follow'); ?>
             </div>
            <?php endif; ?>
            <div class="message_user message_user--chat full-width align_items_justify_content flex transition_background_color getTheChat" data-id="<?php echo iN_HelpSecure($dataUserUserID);?>" aria-label="<?php echo customLang('profile_message_user'); ?>">
                <span class="message_me flex align_items">
                    <?php echo render_icon('messages', true); ?>
                </span>
                <span class="message_label"><?php echo customLang('profile_message_user'); ?></span>
            </div>
        </div>
    </div>
</div>
<!---->
<?php endforeach; ?>
