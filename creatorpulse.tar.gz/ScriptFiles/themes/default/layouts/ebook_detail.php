<?php
declare(strict_types=1);

$viewerId = isset($userID) ? (int)$userID : 0;
$slug = strtolower(trim((string)($_GET['ebook_slug'] ?? '')));
$ebook = isset($RL) && method_exists($RL, 'RL_GetEbookBySlug') ? $RL->RL_GetEbookBySlug($slug, $viewerId) : null;
$ebookBaseUrl = rtrim((string)($base_url ?? ''), '/') . '/';
$formatMoney = static function (float $amount, ?string $code = null): string {
    return function_exists('dz_format_currency') ? dz_format_currency($amount, $code) : number_format($amount, 2);
};

if (!$ebook || ((string)($ebook['status'] ?? '') !== 'active' && (int)($ebook['owner_id'] ?? 0) !== $viewerId)) {
    http_response_code(404);
    ?>
    <div class="main-content flex align_items"><div class="content-area flex"><div class="content-left">
      <section class="ebook-detail-empty">
        <span><?php echo render_icon('ebook', true); ?></span>
        <h1><?php echo customLang('ebook_not_found', 'eBook not found.'); ?></h1>
        <a href="<?php echo iN_HelpSecure($ebookBaseUrl . 'ebooks'); ?>"><?php echo customLang('ebooks_back_to_store', 'Back to eBook store'); ?></a>
      </section>
    </div></div></div>
    <?php
    return;
}

$ebookId = (int)$ebook['ebook_id'];
$ownerId = (int)$ebook['owner_id'];
$price = (float)$ebook['price'];
$isOwner = $viewerId > 0 && $viewerId === $ownerId;
$isPurchased = (int)($ebook['viewer_purchased'] ?? 0) === 1;
$canDownload = $viewerId > 0 && ($isOwner || $isPurchased || $price <= 0);
$coverPath = trim((string)($ebook['cover_path'] ?? ''));
$coverUrl = $coverPath !== '' && function_exists('storage_resolve_media_url') ? storage_resolve_media_url($coverPath, $ebookBaseUrl) : '';
$avatarPath = trim((string)($ebook['user_avatar'] ?? '')) ?: 'uploads/avatars/default_avatar.png';
$avatarUrl = function_exists('storage_resolve_media_url') ? storage_resolve_media_url($avatarPath, $ebookBaseUrl) : $ebookBaseUrl . ltrim($avatarPath, '/');
$creatorName = trim((string)($ebook['user_fullname'] ?? '')) ?: (string)($ebook['username'] ?? '');
$creatorProfile = $ebookBaseUrl . 'profile/' . rawurlencode((string)($ebook['username'] ?? ''));
$categories = method_exists($RL, 'RL_GetEbookCategoryLabels') ? $RL->RL_GetEbookCategoryLabels($ebookId) : [];
$related = method_exists($RL, 'RL_GetRelatedEbooks') ? $RL->RL_GetRelatedEbooks($ebookId, $viewerId, 4) : [];
$ebookReviews = method_exists($RL, 'RL_GetEbookReviews') ? $RL->RL_GetEbookReviews($ebookId, $viewerId) : [];
$viewerReview = null;
foreach ($ebookReviews as $reviewRow) { if ((int)($reviewRow['user_id'] ?? 0) === $viewerId) { $viewerReview = $reviewRow; break; } }
$canReview = $viewerId > 0 && !$isOwner && $canDownload;
$isWishlisted = $viewerId > 0 && method_exists($RL, 'RL_IsEbookWishlisted') ? $RL->RL_IsEbookWishlisted($ebookId, $viewerId) : false;
if (method_exists($RL, 'RL_IncrementEbookView')) { $RL->RL_IncrementEbookView($ebookId); }
$priceDisplay = $price > 0 ? $formatMoney($price, (string)($ebook['currency'] ?? null)) : customLang('ebook_free_label', 'Free');
$ebookCsrf = function_exists('generateCsrfToken') ? generateCsrfToken() : '';

$globalCurCode = strtoupper((string)($globalCurCode ?? $currency ?? 'USD'));
$providerLabels = [
    'stripe' => customLang('pay_provider_stripe', 'Credit card'), 'paypal' => customLang('pay_provider_paypal', 'PayPal'),
    'payu' => customLang('pay_provider_payu', 'PayU'), 'paystack' => customLang('pay_provider_paystack', 'Paystack'),
    'iyzico' => customLang('pay_provider_iyzico', 'iyzico'), 'flutterwave' => customLang('pay_provider_flutterwave', 'Flutterwave'),
    'nowpayments' => customLang('pay_provider_nowpayments', 'Crypto'), 'coinbase' => customLang('pay_provider_coinbase', 'Coinbase'),
];
$providerStatus = [
    'stripe' => !empty($enableStripe), 'paypal' => !empty($enablePaypal), 'payu' => !empty($enablePayu),
    'paystack' => !empty($enablePaystack), 'iyzico' => !empty($enableIyziCo), 'flutterwave' => !empty($enableFlutterwave),
    'nowpayments' => !empty($enableNowpayments), 'coinbase' => !empty($enableCoinbase),
];
$availablePaymentProviders = [];
foreach ($providerStatus as $provider => $enabled) {
    if ($enabled) { $availablePaymentProviders[$provider] = ['label' => $providerLabels[$provider], 'currency' => $globalCurCode]; }
}
$walletBalance = (float)($userWallet ?? ($userData['wallet'] ?? 0));
$availablePaymentProviders['wallet'] = [
    'label' => strtr(customLang('pay_provider_wallet', 'Wallet ({balance})'), ['{balance}' => $formatMoney($walletBalance, $globalCurCode)]),
    'currency' => $globalCurCode,
];
?>
<div class="main-content flex align_items">
  <div class="content-area flex">
    <div class="content-left">
      <div class="ebooks-page ebook-detail-page"
        data-request-url="<?php echo iN_HelpSecure($ebookBaseUrl . 'request/requests.php'); ?>"
        data-topup-label="<?php echo iN_HelpSecure(customLang('wallet_topup_button_label', 'Add funds')); ?>"
        data-purchase-failed-label="<?php echo iN_HelpSecure(customLang('ebook_purchase_failed', 'Purchase failed.')); ?>"
        data-payment-start-label="<?php echo iN_HelpSecure(customLang('payment_starting', 'Starting payment...')); ?>"
        data-wallet-insufficient-label="<?php echo iN_HelpSecure(customLang('wallet_balance_not_enough_add_funds', 'Your wallet balance is not enough. Add funds to continue.')); ?>">
        <a class="ebook-detail-back" href="<?php echo iN_HelpSecure($ebookBaseUrl . 'ebooks'); ?>"><?php echo render_icon('back', true); ?><span><?php echo customLang('ebooks_back_to_store', 'Back to eBook store'); ?></span></a>

        <article class="ebook-card ebook-detail-card"
          data-ebook-id="<?php echo $ebookId; ?>"
          data-ebook-title="<?php echo iN_HelpSecure((string)$ebook['title']); ?>"
          data-ebook-price="<?php echo iN_HelpSecure(number_format($price, 2, '.', '')); ?>"
          data-ebook-price-display="<?php echo iN_HelpSecure($priceDisplay); ?>"
          data-ebook-cover="<?php echo iN_HelpSecure($coverUrl); ?>"
          data-ebook-creator="<?php echo iN_HelpSecure($creatorName); ?>">
          <div class="ebook-detail-cover">
            <?php if ($coverUrl !== ''): ?><img src="<?php echo iN_HelpSecure($coverUrl); ?>" alt="<?php echo iN_HelpSecure((string)$ebook['title']); ?>">
            <?php else: ?><span><?php echo render_icon('ebook', true); ?></span><?php endif; ?>
          </div>
          <div class="ebook-detail-copy">
            <div class="ebook-detail-tags">
              <?php foreach ($categories as $category): ?><a href="<?php echo iN_HelpSecure($ebookBaseUrl . 'ebooks?ebook_category=' . (int)$category['category_id']); ?>"><?php echo iN_HelpSecure((string)$category['name']); ?></a><?php endforeach; ?>
              <?php if ((int)($ebook['featured'] ?? 0) === 1): ?><span><?php echo customLang('ebook_featured_label', 'Featured'); ?></span><?php endif; ?>
            </div>
            <h1><?php echo iN_HelpSecure((string)$ebook['title']); ?></h1>
            <?php if (trim((string)($ebook['short_description'] ?? '')) !== ''): ?><p class="ebook-detail-lead"><?php echo iN_HelpSecure((string)$ebook['short_description']); ?></p><?php endif; ?>
            <a class="ebook-detail-creator" href="<?php echo iN_HelpSecure($creatorProfile); ?>">
              <img src="<?php echo iN_HelpSecure($avatarUrl); ?>" alt="<?php echo iN_HelpSecure($creatorName); ?>">
              <span><small><?php echo customLang('ebook_author_label', 'Author'); ?></small><strong><?php echo iN_HelpSecure($creatorName); ?></strong></span>
            </a>
            <div class="ebook-detail-rating" aria-label="<?php echo iN_HelpSecure(customLang('ebook_rating_label', 'Rating')); ?>">
              <strong><?php echo number_format((float)($ebook['rating_average'] ?? 0), 1); ?></strong>
              <span><?php echo str_repeat('★', max(0, min(5, (int)round((float)($ebook['rating_average'] ?? 0))))); ?><?php echo str_repeat('☆', 5 - max(0, min(5, (int)round((float)($ebook['rating_average'] ?? 0))))); ?></span>
              <small><?php echo (int)($ebook['rating_count'] ?? 0); ?> <?php echo customLang('ebook_reviews_label', 'reviews'); ?></small>
            </div>
            <div class="ebook-detail-price"><?php echo iN_HelpSecure($priceDisplay); ?></div>
            <div class="ebook-detail-actions">
              <?php if ($canDownload): ?>
                <a class="ebook-download-btn" href="#" data-secure-ebook-download data-ebook-id="<?php echo $ebookId; ?>"><?php echo render_icon('download', true); ?><span><?php echo customLang('ebook_download_button', 'Download'); ?></span></a>
              <?php elseif ($viewerId <= 0): ?>
                <a class="ebook-download-btn" href="<?php echo iN_HelpSecure($ebookBaseUrl . 'login'); ?>"><?php echo customLang('ebook_login_to_buy', 'Log in to buy'); ?></a>
              <?php else: ?>
                <button type="button" class="ebook-purchase-btn" data-ebook-id="<?php echo $ebookId; ?>"><?php echo customLang('ebook_buy_button', 'Buy'); ?></button>
              <?php endif; ?>
              <?php if (trim((string)($ebook['sample_path'] ?? '')) !== ''): ?><a class="ebook-sample-btn" href="#ebookSample"><?php echo customLang('ebook_preview_button', 'Read sample'); ?></a><?php endif; ?>
              <?php if ($viewerId > 0): ?><button type="button" class="ebook-wishlist-btn <?php echo $isWishlisted?'is-active':''; ?>" data-ebook-wishlist data-ebook-id="<?php echo $ebookId; ?>" aria-pressed="<?php echo $isWishlisted?'true':'false'; ?>"><?php echo render_icon('saved', true); ?><span><?php echo $isWishlisted?customLang('ebook_in_wishlist','In wishlist'):customLang('ebook_add_wishlist','Add to wishlist'); ?></span></button><?php endif; ?>
            </div>
          </div>
        </article>

        <?php if (trim((string)($ebook['sample_path'] ?? '')) !== ''): ?><section class="ebook-detail-section ebook-sample" id="ebookSample"><h2><?php echo customLang('ebook_sample_title','Free sample'); ?></h2><p><?php echo customLang('ebook_sample_text','Preview selected pages before you buy.'); ?></p><a target="_blank" rel="noopener" href="<?php echo iN_HelpSecure($ebookBaseUrl.'request/requests.php?p=ebook_sample&id='.$ebookId); ?>"><?php echo render_icon('ebook',true); ?><span><?php echo customLang('ebook_open_sample','Open sample PDF'); ?></span></a></section><?php endif; ?>

        <section class="ebook-detail-section">
          <h2><?php echo customLang('ebook_about_title', 'About this eBook'); ?></h2>
          <div class="ebook-detail-description"><?php echo nl2br(iN_HelpSecure((string)($ebook['description'] ?? ''))); ?></div>
          <dl class="ebook-detail-facts">
            <?php
              $ebookDetailLanguageCode = (string)($ebook['language_code'] ?? 'en');
              $ebookDetailLanguageLabel = (isset($RL) && method_exists($RL, 'RL_GetEbookLanguageLabel'))
                  ? $RL->RL_GetEbookLanguageLabel($ebookDetailLanguageCode, (string)($currentLang ?? 'eng'))
                  : strtoupper($ebookDetailLanguageCode);
            ?>
            <div><dt><?php echo customLang('ebook_language_label', 'Language'); ?></dt><dd><?php echo iN_HelpSecure($ebookDetailLanguageLabel); ?></dd></div>
            <div><dt><?php echo customLang('ebook_pages_label', 'Pages'); ?></dt><dd><?php echo (int)($ebook['page_count'] ?? 0) ?: '—'; ?></dd></div>
            <div><dt><?php echo customLang('ebook_version_label', 'Version'); ?></dt><dd><?php echo iN_HelpSecure((string)($ebook['version_label'] ?? '1.0')); ?></dd></div>
            <div><dt><?php echo customLang('ebook_format_label', 'Format'); ?></dt><dd><?php echo iN_HelpSecure(strtoupper((string)pathinfo((string)($ebook['file_name'] ?? ''), PATHINFO_EXTENSION))); ?></dd></div>
          </dl>
        </section>

        <section class="ebook-detail-section ebook-reviews" id="ebookReviews">
          <div class="ebook-reviews__head"><div><h2><?php echo customLang('ebook_reviews_title', 'Reader reviews'); ?></h2><p><?php echo strtr(customLang('ebook_reviews_summary', '{rating} from {count} reviews'), ['{rating}'=>number_format((float)($ebook['rating_average'] ?? 0),1),'{count}'=>(string)(int)($ebook['rating_count'] ?? 0)]); ?></p></div><span><?php echo number_format((float)($ebook['rating_average'] ?? 0),1); ?> ★</span></div>
          <?php if ($canReview): ?>
            <form class="ebook-review-form" data-ebook-review-form>
              <input type="hidden" name="p" value="ebook_review_save"><input type="hidden" name="ebook_id" value="<?php echo $ebookId; ?>"><input type="hidden" name="csrf_token" value="<?php echo iN_HelpSecure($ebookCsrf); ?>">
              <fieldset><legend><?php echo customLang('ebook_your_rating', 'Your rating'); ?></legend><div class="ebook-review-stars" role="radiogroup" aria-label="<?php echo iN_HelpSecure(customLang('ebook_your_rating', 'Your rating')); ?>">
                <input type="hidden" name="rating" value="<?php echo (int)($viewerReview['rating'] ?? 0); ?>" required>
                <?php for ($star=1;$star<=5;$star++): ?><button type="button" class="ebook-review-star <?php echo $star <= (int)($viewerReview['rating'] ?? 0)?'is-active':''; ?>" data-review-rating="<?php echo $star; ?>" role="radio" aria-checked="<?php echo $star === (int)($viewerReview['rating'] ?? 0)?'true':'false'; ?>" aria-label="<?php echo $star; ?>">★</button><?php endfor; ?>
              </div></fieldset>
              <textarea name="review_text" rows="3" maxlength="1500" placeholder="<?php echo iN_HelpSecure(customLang('ebook_review_placeholder', 'Share what you liked about this eBook.')); ?>"><?php echo iN_HelpSecure((string)($viewerReview['review_text'] ?? '')); ?></textarea>
              <div><span data-ebook-review-message aria-live="polite"></span><button type="submit"><?php echo customLang('ebook_review_submit', 'Save review'); ?></button></div>
            </form>
          <?php endif; ?>
          <div class="ebook-review-list">
            <?php if (!$ebookReviews): ?><p class="ebook-review-empty"><?php echo customLang('ebook_reviews_empty', 'No reviews yet.'); ?></p><?php endif; ?>
            <?php foreach ($ebookReviews as $review): $reviewName=trim((string)($review['user_fullname']??'')) ?: (string)($review['username']??''); $reviewAvatar=trim((string)($review['user_avatar']??'')) ?: 'uploads/avatars/default_avatar.png'; $reviewAvatarUrl=function_exists('storage_resolve_media_url')?storage_resolve_media_url($reviewAvatar,$ebookBaseUrl):$ebookBaseUrl.ltrim($reviewAvatar,'/'); ?>
              <article class="ebook-review-item"><img src="<?php echo iN_HelpSecure($reviewAvatarUrl); ?>" alt="<?php echo iN_HelpSecure($reviewName); ?>"><div><header><strong><?php echo iN_HelpSecure($reviewName); ?></strong><span><?php echo str_repeat('★',(int)$review['rating']); ?><?php echo str_repeat('☆',5-(int)$review['rating']); ?></span></header><?php if ((int)($review['verified_purchase']??0)===1): ?><small><?php echo customLang('ebook_verified_reader', 'Verified reader'); ?></small><?php endif; ?><p><?php echo nl2br(iN_HelpSecure((string)($review['review_text']??''))); ?></p></div></article>
            <?php endforeach; ?>
          </div>
        </section>

        <?php if (!empty($related)): ?>
          <section class="ebook-detail-section"><h2><?php echo customLang('ebook_related_title', 'You may also like'); ?></h2><div class="ebook-related-grid">
            <?php foreach ($related as $item): ?>
              <?php $relatedCover = trim((string)($item['cover_path'] ?? '')); $relatedCoverUrl = $relatedCover !== '' && function_exists('storage_resolve_media_url') ? storage_resolve_media_url($relatedCover, $ebookBaseUrl) : ''; ?>
              <a class="ebook-related-card" href="<?php echo iN_HelpSecure($ebookBaseUrl . 'ebook/' . (string)$item['slug']); ?>">
                <span><?php if ($relatedCoverUrl !== ''): ?><img src="<?php echo iN_HelpSecure($relatedCoverUrl); ?>" alt=""><?php else: ?><?php echo render_icon('ebook', true); ?><?php endif; ?></span>
                <strong><?php echo iN_HelpSecure((string)$item['title']); ?></strong>
                <small><?php echo iN_HelpSecure((float)$item['price'] > 0 ? $formatMoney((float)$item['price'], (string)$item['currency']) : customLang('ebook_free_label', 'Free')); ?></small>
              </a>
            <?php endforeach; ?>
          </div></section>
        <?php endif; ?>

        <?php if ($viewerId > 0 && !$canDownload): ?>
        <div class="ebooks-purchase-modal" data-ebook-purchase-modal aria-hidden="true">
          <div class="ebooks-purchase-modal__backdrop" data-ebook-purchase-close></div>
          <section class="ebooks-purchase-modal__panel" role="dialog" aria-modal="true" aria-labelledby="ebooksPurchaseHeading">
            <button type="button" class="ebooks-purchase-modal__close" data-ebook-purchase-close aria-label="<?php echo iN_HelpSecure(customLang('close', 'Close')); ?>"><?php echo render_icon('close', true); ?></button>
            <div class="ebooks-purchase-modal__head"><span class="ebooks-purchase-modal__icon"><?php echo render_icon('ebook', true); ?></span><div><h2 id="ebooksPurchaseHeading"><?php echo customLang('ebook_purchase_title', 'Buy eBook'); ?></h2><p><?php echo customLang('ebook_purchase_subtitle', 'Choose a payment method to complete your purchase.'); ?></p></div></div>
            <div class="ebooks-purchase-summary"><div class="ebooks-purchase-summary__cover" data-ebook-purchase-cover><?php echo render_icon('ebook', true); ?></div><div class="ebooks-purchase-summary__copy"><strong data-ebook-purchase-title></strong><span data-ebook-purchase-creator></span></div><div class="ebooks-purchase-summary__price" data-ebook-purchase-price></div></div>
            <form class="ebooks-payment-form" data-ebook-payment-form><input type="hidden" name="p" value="ebook_create_payment"><input type="hidden" name="ebook_id" value=""><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($ebookCsrf, ENT_QUOTES, 'UTF-8'); ?>">
              <div class="ebooks-payment-methods" role="radiogroup"><?php $first = true; foreach ($availablePaymentProviders as $key => $provider): ?><label class="ebooks-payment-method"><input type="radio" name="provider" value="<?php echo iN_HelpSecure($key); ?>" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure((string)$provider['currency']); ?>"><span class="ebooks-payment-method__mark"></span><span class="ebooks-payment-method__label"><?php echo iN_HelpSecure((string)$provider['label'], false); ?></span></label><?php $first = false; endforeach; ?></div>
              <label class="ebook-coupon-field"><span><?php echo customLang('ebook_coupon_label','Coupon code'); ?></span><input type="text" name="coupon_code" maxlength="64" autocomplete="off"><button type="button" data-ebook-coupon-apply><?php echo customLang('ebook_coupon_apply','Apply'); ?></button></label><div data-ebook-coupon-message aria-live="polite"></div>
              <div class="ebooks-payment-message" data-ebook-payment-message aria-live="polite"></div><button type="submit" class="ebooks-payment-submit"><?php echo customLang('ebook_pay_button', 'Pay now'); ?></button>
            </form>
          </section>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <div class="content-right flex align_items"><div class="content-right-container"><?php include __DIR__ . '/widgets/suggestedUsers.php'; include __DIR__ . '/widgets/adsSidebar.php'; ?></div></div>
  </div>
</div>
<script defer src="<?php echo iN_HelpSecure($ebookBaseUrl . 'themes/' . $currentTheme . '/js/ebooks.js?v=' . $version); ?>"></script>
