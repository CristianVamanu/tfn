<div class="main-content">
    <div class="explore-area explore-page-area">
        <!---->
        <div class="explore-left">
            <div class="explore-left-container flex align_items flexBoxColumn">
                <div class="posts-container gap full-width relative flex align_items flexBoxColumn" id="explore">
                    <?php

                        $initialTiles = 10; // Set how many tiles (cards) to show on the first page
                        $page        = $RL->getPageByCursor(0, 0, $initialTiles);
                        $html        = $RL->renderToString($page['blocks'], $page['startLayout'], false);
                        $cursor      = $page['nextCursor'];
                        $hasMore     = !empty($page['hasMore']);
                        ?>
                        <div class="full-width flex gap-root align_items flexBoxColumn" id="explore-root"
                            data-cursor-time="<?php echo (int)$cursor['time']; ?>"
                            data-cursor-id="<?php echo (int)$cursor['id']; ?>"
                            data-has-more="<?php echo $hasMore ? '1' : '0'; ?>"
                            data-limit="<?php echo (int)$initialTiles; ?>"
                            data-start-layout="<?php echo htmlspecialchars($page['startLayout'] ?? 'right'); ?>">
                        <div class="explore-grid">
                        <?php
                            $cleanHtml = trim((string) $html);
                            echo $html;
                            if ($cleanHtml === '' || trim((string) strip_tags($cleanHtml)) === '') {
                                $cta = '';
                                if (isset($loggedIn) && $loggedIn === '1') {
                                    $cta = sprintf(
                                        '<div class="empty-state__body flex align_items flexBoxColumn gap">
                                            <p class="empty-state__subtitle">%s</p>
                                            <button type="button" class="empty-state__cta new_item" data-pop="createNew">%s</button>
                                        </div>',
                                        customLang('empty_state_create_prompt'),
                                        customLang('empty_state_create_button')
                                    );
                                }

                                echo sprintf(
                                    '<div class="empty-state flex align_items flexBoxColumn gap">'
                                    . '<div class="empty-state__icon flex align_items">%s</div>'
                                    . '<div class="empty-state__title flex align_items">%s</div>%s'
                                    . '</div>',
                                    render_icon('not_founded', true),
                                    customLang('empty_state_explore'),
                                    $cta
                                );
                            }
                        ?>
                        <div id="explore-sentinel" aria-hidden="true"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!---->
        <div class="content-right flex align_items">
            <div class="content-right-container">
                <?php
                    include_once __DIR__ . '/widgets/suggestedUsers.php';
                    include_once __DIR__ . '/widgets/adsSidebar.php';
                    $hideMostPopularIfEmpty = true;
                    include_once __DIR__ . '/widgets/mosPopularPost.php';
                    unset($hideMostPopularIfEmpty);
                ?>
            </div>
        </div>
        <!---->
    </div>
</div>
<?php $themePathExplore = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme);?>

<script defer src="<?php echo $themePathExplore; ?>/js/explore.js"></script>
<script defer src="<?php echo $themePathExplore; ?>/js/getPost.js"></script>
<script defer src="<?php echo $themePathExplore; ?>/js/adsFeedSlots.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePathExplore; ?>/js/media.viewer.js?v=<?php echo iN_HelpSecure($version);?>"></script>
