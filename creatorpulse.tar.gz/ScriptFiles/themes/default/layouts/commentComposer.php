<?php
$commentComposerPostId = isset($postID) ? (int) $postID : (isset($post['post_id']) ? (int) $post['post_id'] : 0);
if ($commentComposerPostId <= 0) {
    return;
}

$commentComposerAvatar = $defaultUserAvatar ?? '';
if ($commentComposerAvatar === '') {
    $commentComposerAvatar = storage_url('uploads/user_avatars/default.jpeg');
}

$commentComposerAlt = customLang('alt_avatar_of_user', 'Avatar of %s');
$commentComposerName = (string) ($userData['username'] ?? customLang('you', 'You'));
$commentComposerAlt = sprintf($commentComposerAlt, $commentComposerName);

$commentComposerShouldOpen = false;
if (isset($RL) && is_object($RL) && method_exists($RL, 'RL_TotalComment')) {
    $commentComposerShouldOpen = ((int) $RL->RL_TotalComment($commentComposerPostId)) > 0;
}

$commentComposerClasses = 'make-comment full-width p_comment_' . $commentComposerPostId;
if (!$commentComposerShouldOpen) {
    $commentComposerClasses .= ' none';
}
?>
<div
  class="<?php echo iN_HelpSecure($commentComposerClasses); ?>"
  aria-hidden="<?php echo $commentComposerShouldOpen ? 'false' : 'true'; ?>"
  data-target="composer"
  data-post-id="<?php echo $commentComposerPostId; ?>"
>
    <div class="make-comment-area full-width p_comment__<?php echo $commentComposerPostId; ?>">
        <div class="comment-reply-context none" data-role="comment-reply-context">
            <div class="comment-reply-context__text">
                <span><?php echo iN_HelpSecure(customLang('comment_replying_to', 'Replying to')); ?></span>
                <strong data-role="comment-reply-name"></strong>
            </div>
            <button
              type="button"
              class="comment-reply-cancel"
              aria-label="<?php echo iN_HelpSecure(customLang('comment_cancel_reply', 'Cancel reply')); ?>"
              data-role="comment-reply-cancel"
            >
                &times;
            </button>
        </div>
        <div class="make-comment-row">
            <div class="make-comment-avatar" aria-hidden="true">
                <img src="<?php echo iN_HelpSecure($commentComposerAvatar); ?>" alt="<?php echo iN_HelpSecure($commentComposerAlt); ?>">
            </div>
            <div class="make-comment-input-shell">
                <textarea
                  name="post-text"
                  class="write-comment"
                  rows="1"
                  data-min-height="34"
                  data-max-height="140"
                  placeholder="<?php echo iN_HelpSecure(customLang('comment_placeholder', 'Write a comment...')); ?>"
                  data-post-id="<?php echo $commentComposerPostId; ?>"
                ></textarea>
                <div class="make-emoji-wrapper full-width get_emojis_<?php echo $commentComposerPostId; ?>"></div>
            </div>
            <button
              type="button"
              class="make-comment-emojis get_emojis"
              data-id="<?php echo $commentComposerPostId; ?>"
              aria-label="<?php echo iN_HelpSecure(customLang('comment_add_emoji', 'Add emoji')); ?>"
            >
                <?php echo render_icon('smiley', true); ?>
            </button>
            <button
              type="button"
              class="make-send-comment cursor-point sendComment"
              data-post-id="<?php echo $commentComposerPostId; ?>"
              aria-label="<?php echo iN_HelpSecure(customLang('comment_send', 'Send')); ?>"
            >
                <?php echo render_icon('send_comment', true); ?>
            </button>
        </div>
    </div>
</div>
