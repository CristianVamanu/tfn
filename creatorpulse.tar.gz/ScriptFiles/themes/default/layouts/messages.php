<?php
declare(strict_types=1);

$includeAgoraChatCall = true;
$viewerId = isset($userID) ? (int)$userID : 0;
$baseUrl = isset($base_url) ? rtrim((string)$base_url, '/') : '';
$conversations = [];

if ($viewerId > 0 && isset($RL) && method_exists($RL, 'RL_GetNewMessages')) {
    try {
        $conversations = $RL->RL_GetNewMessages($viewerId, 30, 0);
    } catch (Throwable $__) {
        $conversations = [];
    }
}

$requestConversations = [];
$inboxConversations = [];
foreach ($conversations as $conversation) {
    $isIncomingRequest = (($conversation['request_status'] ?? '') === 'pending' && ($conversation['request_direction'] ?? '') === 'incoming');
    if ($isIncomingRequest) {
        $requestConversations[] = $conversation;
    } else {
        $inboxConversations[] = $conversation;
    }
}
$conversationGroups = [];
if ($requestConversations) {
    $conversationGroups[] = [
        'title' => customLang('messages_requests_title', 'Message requests'),
        'items' => $requestConversations,
        'class' => 'requests',
    ];
}
if ($inboxConversations) {
    $conversationGroups[] = [
        'title' => customLang('messages_inbox_title', 'Inbox'),
        'items' => $inboxConversations,
        'class' => 'inbox',
    ];
}

$messagesCurrencySymbol = static function (string $code): string {
    $code = strtoupper(trim($code));
    $map = [];
    if (isset($GLOBALS['currencies']) && is_array($GLOBALS['currencies'])) {
        $map = $GLOBALS['currencies'];
    } elseif (isset($GLOBALS['currencys']) && is_array($GLOBALS['currencys'])) {
        $map = $GLOBALS['currencys'];
    }
    return isset($map[$code]) ? (string)$map[$code] : $code;
};

$formatPreview = static function (array $conversation) use ($messagesCurrencySymbol): string {
    $message = trim((string)($conversation['last_message'] ?? ''));
    $file = trim((string)($conversation['last_file'] ?? ''));
    $messageType = strtolower(trim((string)($conversation['last_message_type'] ?? 'text')));
    $metadata = [];
    $metadataRaw = trim((string)($conversation['last_metadata'] ?? ''));
    if ($metadataRaw !== '') {
        $decodedMetadata = json_decode($metadataRaw, true);
        if (is_array($decodedMetadata)) {
            $metadata = $decodedMetadata;
        }
    }

    if ($messageType === 'tip') {
        $amount = isset($metadata['amount']) && is_numeric($metadata['amount']) ? (float)$metadata['amount'] : null;
        $currency = strtoupper((string)($metadata['currency'] ?? ''));
        if ($currency === '' && preg_match('/([0-9]+(?:[.,][0-9]+)?)\s*([A-Z]{3})\b/i', $message, $matches)) {
            $amount = (float)str_replace(',', '.', $matches[1]);
            $currency = strtoupper($matches[2]);
        }
        if ($currency === '') {
            $currency = isset($GLOBALS['globalCurCode']) ? strtoupper((string)$GLOBALS['globalCurCode']) : 'USD';
        }
        $symbol = $messagesCurrencySymbol($currency);
        $amountDisplay = $amount !== null ? $symbol . number_format($amount, 2, '.', '') : trim((string)preg_replace('/^Sent a tip:\s*/i', '', $message));
        if ($amountDisplay === '') {
            $amountDisplay = $symbol . '0.00';
        }
        return customLang('chat_preview_sent_tip', 'Sent a tip: {amount}', ['amount' => $amountDisplay]);
    }

    if ($messageType === 'paid_media') {
        return customLang('chat_preview_sent_paid_media', 'Sent paid media');
    }

    if ($file !== '') {
        if (preg_match('/^post:\d+$/i', $file)) {
            return customLang('chat_preview_shared_post', 'Shared a post');
        }

        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)) {
            return customLang('chat_preview_sent_image', 'Sent an image');
        }
        if (in_array($extension, ['mp4', 'mov', 'm4v', 'webm', 'avi'], true)) {
            return customLang('chat_preview_sent_video', 'Sent a video');
        }
        return customLang('chat_preview_sent_attachment', 'Sent an attachment');
    }

    if ($message === '') {
        return customLang('chat_message_empty_preview', 'New conversation');
    }

    if (function_exists('mb_strimwidth')) {
        return mb_strimwidth($message, 0, 92, '...', 'UTF-8');
    }

    return strlen($message) > 92 ? substr($message, 0, 89) . '...' : $message;
};

$messagesTitle = customLang('chat_messages_title', customLang('menu_messages', 'Messages'));
$emptyTitle = customLang('messages_empty_state_title', 'No messages yet');
$emptyText = customLang('messages_empty_state_info', 'Start a conversation from a creator profile.');
$selectTitle = customLang('messages_select_conversation_title', 'Select a conversation');
$selectText = customLang('messages_select_conversation_info', 'Your full conversation will open here.');
?>
<div class="main-content flex align_items messages-page-main">
    <div class="content-area flex messages-page-content">
        <section class="messages-page messages-page--details-hidden" aria-labelledby="messagesPageTitle">
            <aside class="messages-page__sidebar" data-messages-sidebar aria-label="<?php echo iN_HelpSecure($messagesTitle); ?>">
                <div class="messages-page__header">
                    <div class="messages-page__title-row">
                        <span class="messages-page__title-icon flex align_items_justify_content" aria-hidden="true">
                            <?php echo render_icon('messages', true); ?>
                        </span>
                        <div>
                            <h1 id="messagesPageTitle"><?php echo iN_HelpSecure($messagesTitle); ?></h1>
                            <span><?php echo (int)count($conversations); ?> <?php echo iN_HelpSecure(customLang('messages_conversation_count_label', 'conversations')); ?></span>
                        </div>
                    </div>
                    <label class="messages-page__search">
                        <span aria-hidden="true"><?php echo render_icon('search_icon', true); ?></span>
                        <input type="search" name="message_search" placeholder="<?php echo iN_HelpSecure(customLang('search_messages_placeholder', 'Search messages')); ?>" autocomplete="off">
                    </label>
                </div>

                <div class="messages-page__conversation-list">
                    <?php if ($conversations): ?>
                        <?php foreach ($conversationGroups as $group): ?>
                            <div class="messages-page__group-title messages-page__group-title--<?php echo iN_HelpSecure((string)$group['class']); ?>">
                                <span><?php echo iN_HelpSecure((string)$group['title']); ?></span>
                                <strong><?php echo (int)count($group['items']); ?></strong>
                            </div>
                        <?php foreach ($group['items'] as $conversation):
                            $partnerId = (int)($conversation['partner_id'] ?? 0);
                            if ($partnerId <= 0) { continue; }
                            $requestStatus = (string)($conversation['request_status'] ?? 'none');
                            $requestDirection = (string)($conversation['request_direction'] ?? '');
                            $isIncomingRequest = ($requestStatus === 'pending' && $requestDirection === 'incoming');
                            $isOutgoingRequest = ($requestStatus === 'pending' && $requestDirection === 'outgoing');
                            $isPinned = (int)($conversation['pinned_at'] ?? 0) > 0;

                            $username = (string)($conversation['username'] ?? '');
                            $fullName = trim((string)($conversation['fullname'] ?? ''));
                            $displayName = $fullName !== '' ? $fullName : ($username !== '' ? $username : customLang('unknown_user', 'User'));
                            $avatarRel = (string)($conversation['avatar'] ?? 'uploads/user_avatars/default.jpeg');
                            $avatarUrl = function_exists('storage_url') ? storage_url($avatarRel) : $baseUrl . '/' . ltrim($avatarRel, '/');
                            $profileUrl = $baseUrl . '/profile/' . rawurlencode($username);
                            $lastTime = (int)($conversation['last_time'] ?? 0);
                            $timeText = $lastTime > 0 && function_exists('dz_relative_time_label') ? dz_relative_time_label($lastTime) : '';
                            $preview = $formatPreview($conversation);
                        ?>
                            <article
                                class="messages-page__conversation<?php echo $isIncomingRequest ? ' is-request' : ''; ?><?php echo $isPinned ? ' is-pinned' : ''; ?>"
                                data-user-id="<?php echo $partnerId; ?>"
                                data-pinned-at="<?php echo (int)($conversation['pinned_at'] ?? 0); ?>"
                                data-search-text="<?php echo iN_HelpSecure(strtolower($displayName . ' ' . $username . ' ' . $preview)); ?>"
                            >
                                <a class="messages-page__avatar" href="<?php echo iN_HelpSecure($profileUrl, false); ?>">
                                    <img src="<?php echo iN_HelpSecure($avatarUrl, false); ?>" alt="<?php echo iN_HelpSecure($displayName); ?>">
                                </a>
                                <button
                                    type="button"
                                    class="messages-page__conversation-button"
                                    data-message-conversation
                                    data-id="<?php echo $partnerId; ?>"
                                    data-name="<?php echo iN_HelpSecure($displayName); ?>"
                                    data-username="<?php echo iN_HelpSecure($username); ?>"
                                    data-avatar="<?php echo iN_HelpSecure($avatarUrl, false); ?>"
                                >
                                    <span class="messages-page__conversation-top">
                                        <strong>
                                            <?php echo iN_HelpSecure($displayName); ?>
                                            <?php if (!empty($conversation['verified_status'])): ?>
                                                <span class="messages-page__verified" aria-label="<?php echo iN_HelpSecure(customLang('verified', 'Verified')); ?>">
                                                    <?php echo render_icon('verified', true); ?>
                                                </span>
                                            <?php endif; ?>
                                        </strong>
                                        <?php if ($timeText !== ''): ?>
                                            <time><?php echo iN_HelpSecure($timeText); ?></time>
                                        <?php endif; ?>
                                    </span>
                                    <span class="messages-page__preview"><?php echo iN_HelpSecure($preview); ?></span>
                                    <?php if ($isIncomingRequest || $isOutgoingRequest): ?>
                                        <span class="messages-page__request-chip">
                                            <?php echo iN_HelpSecure($isIncomingRequest ? customLang('messages_request_chip', 'Request') : customLang('messages_request_sent_chip', 'Request sent')); ?>
                                        </span>
                                    <?php endif; ?>
                                    <?php if ($isPinned): ?>
                                        <span class="messages-page__pin-chip">
                                            <?php echo iN_HelpSecure(customLang('messages_pinned_chip', 'Pinned')); ?>
                                        </span>
                                    <?php endif; ?>
                                </button>
                            </article>
                        <?php endforeach; ?>
                        <?php endforeach; ?>
                        <div class="messages-page__no-results" data-messages-no-results hidden>
                            <span aria-hidden="true"><?php echo render_icon('search_icon', true); ?></span>
                            <strong><?php echo iN_HelpSecure(customLang('messages_search_no_results', 'No matching conversations')); ?></strong>
                        </div>
                    <?php else: ?>
                        <div class="messages-page__empty">
                            <span class="messages-page__empty-icon" aria-hidden="true"><?php echo render_icon('messages', true); ?></span>
                            <strong><?php echo iN_HelpSecure($emptyTitle); ?></strong>
                            <p><?php echo iN_HelpSecure($emptyText); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </aside>
            <button
                type="button"
                class="messages-page__drawer-backdrop"
                data-messages-drawer-close
                aria-label="<?php echo iN_HelpSecure(customLang('close', 'Close')); ?>"
                hidden
            ></button>

            <main class="messages-page__thread" data-messages-thread aria-label="<?php echo iN_HelpSecure(customLang('chat_conversation_label', 'Conversation')); ?>">
                <div class="messages-page__thread-empty" data-messages-thread-empty>
                    <span class="messages-page__thread-icon" aria-hidden="true"><?php echo render_icon('messages', true); ?></span>
                    <strong><?php echo iN_HelpSecure($selectTitle); ?></strong>
                    <p><?php echo iN_HelpSecure($selectText); ?></p>
                </div>
            </main>

            <aside class="messages-page__details" aria-label="<?php echo iN_HelpSecure(customLang('conversation_details_title', 'Conversation details')); ?>" data-messages-details-shell hidden>
                <div class="messages-page__details-panel" data-messages-details>
                    <span class="messages-page__details-icon" aria-hidden="true"><?php echo render_icon('security', true); ?></span>
                    <strong><?php echo iN_HelpSecure(customLang('conversation_details_title', 'Conversation details')); ?></strong>
                    <p><?php echo iN_HelpSecure(customLang('conversation_details_empty', 'Shared media and profile actions will appear here.')); ?></p>
                </div>
            </aside>
        </section>
        <div id="messages-page-icon-templates" class="visually-hidden none" aria-hidden="true">
            <span data-icon="locked"><?php echo render_icon('locked', true); ?></span>
        </div>
    </div>
</div>

<?php $themePathMessages = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme); ?>
<script defer src="<?php echo $themePathMessages; ?>/js/messagesPage.js?v=<?php echo iN_HelpSecure($version); ?>"></script>
