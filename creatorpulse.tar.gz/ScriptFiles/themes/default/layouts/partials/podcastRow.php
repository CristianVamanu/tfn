<?php
declare(strict_types=1);

if (!isset($podcast, $base_url)) {
    return;
}

$podcastId = (int) ($podcast['id'] ?? 0);
if ($podcastId <= 0) {
    return;
}

$title = trim((string) ($podcast['title'] ?? ''));
$title = $title !== '' ? $title : customLang('profile_podcast_untitled', 'Untitled podcast');
$username = (string) ($podcast['username'] ?? '');
$fullname = (string) ($podcast['fullname'] ?? '');
$displayName = $fullname !== '' ? $fullname : $username;
$avatarUrl = (string) ($podcast['avatar'] ?? '');
$coverUrl = (string) ($podcast['cover_url'] ?? '');
$durationSec = isset($podcast['duration']) ? (int) $podcast['duration'] : 0;
$durationLabel = $durationSec > 0 ? sprintf('%d:%02d', (int) floor($durationSec / 60), $durationSec % 60) : '--:--';
$categoryName = (string) ($podcast['category_name'] ?? '');
$audioUrl = (string) ($podcast['audio_url'] ?? '');
$postUrl = rtrim((string) $base_url, '/') . '/posts/' . $podcastId;
$profileUrl = rtrim((string) $base_url, '/') . '/profile/' . rawurlencode($username);
$isVerified = !empty($podcast['verified']);
$liked = !empty($podcast['liked']);
$bookmarked = !empty($podcast['bookmarked']);
?>
<article class="podcast-row flex align_items" data-id="<?php echo $podcastId; ?>" data-audio-url="<?php echo iN_HelpSecure($audioUrl, false); ?>" data-duration-sec="<?php echo (int) $durationSec; ?>" data-post-url="<?php echo iN_HelpSecure($postUrl); ?>">
    <div class="podcast-row__thumb">
        <?php if ($coverUrl !== ''): ?>
            <img src="<?php echo iN_HelpSecure($coverUrl, false); ?>" alt="<?php echo iN_HelpSecure(customLang('podcast_cover_alt', 'Podcast cover')); ?>">
        <?php else: ?>
            <span class="podcast-row__thumb-placeholder"><?php echo render_icon('music_note', true) ?: '♪'; ?></span>
        <?php endif; ?>
        <button type="button" class="podcast-row__play" aria-label="<?php echo iN_HelpSecure($playLabel); ?>">
            <span class="icon-play"><?php echo render_icon('play', true) ?: '▶'; ?></span>
            <span class="icon-pause"><?php echo render_icon('pause', true) ?: '⏸'; ?></span>
        </button>
    </div>
    <div class="podcast-row__body flex flexBoxColumn gap">
        <div class="podcast-row__header flex">
            <div class="podcast-row__title-wrapper flex flexBoxColumn">
                <a class="podcast-row__title" href="<?php echo iN_HelpSecure($postUrl); ?>"><?php echo htmlspecialchars($title, ENT_QUOTES, 'UTF-8'); ?></a>
                <a class="podcast-row__creator flex align_items gap" href="<?php echo iN_HelpSecure($profileUrl); ?>">
                    <div class="podcast-row__avatar">
                        <?php
                            $altAvatar = customLang('alt_avatar_of_user', 'Avatar of %s');
                            $altAvatar = sprintf($altAvatar, $displayName !== '' ? $displayName : $username);
                        ?>
                        <img src="<?php echo iN_HelpSecure($avatarUrl, false); ?>" alt="<?php echo iN_HelpSecure($altAvatar, false); ?>">
                    </div>
                    <div class="podcast-row__creator-text">
                        <span class="podcast-row__creator-name">
                            <?php echo htmlspecialchars($displayName, ENT_QUOTES, 'UTF-8'); ?>
                            <?php if ($isVerified): ?>
                                <span class="podcast-row__verified"><?php echo render_icon('verified', true) ?: '✓'; ?></span>
                            <?php endif; ?>
                        </span>
                        <?php if ($username !== ''): ?>
                            <span class="podcast-row__creator-handle">@<?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?></span>
                        <?php endif; ?>
                    </div>
                </a>
                <?php if ($categoryName !== ''): ?>
                    <div class="podcast-row__tag"><?php echo htmlspecialchars($categoryName, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
            </div>
            <div class="podcast-row__actions flex align_items">
                <button type="button" class="podcast-row__icon-btn podcast-save<?php echo $bookmarked ? ' is-active' : ''; ?>" data-action="podcast-save" data-post-id="<?php echo $podcastId; ?>" aria-label="<?php echo iN_HelpSecure($saveLabel); ?>">
                    <span class="icon-save"><?php echo render_icon('save', true) ?: '💾'; ?></span>
                    <span class="icon-saved"><?php echo render_icon('saved', true) ?: '✔'; ?></span>
                </button>
                <button type="button" class="podcast-row__icon-btn podcast-like<?php echo $liked ? ' is-active' : ''; ?>" data-action="podcast-like" data-post-id="<?php echo $podcastId; ?>" aria-label="<?php echo iN_HelpSecure($likeLabel); ?>">
                    <span class="icon-like"><?php echo render_icon('like', true) ?: '❤'; ?></span>
                    <span class="icon-liked"><?php echo render_icon('liked', true) ?: '♥'; ?></span>
                </button>
                <div class="podcast-row__duration" aria-label="<?php echo iN_HelpSecure($durationLabel); ?>"><?php echo htmlspecialchars($durationLabel, ENT_QUOTES, 'UTF-8'); ?></div>
            </div>
        </div>
    </div>
</article>
