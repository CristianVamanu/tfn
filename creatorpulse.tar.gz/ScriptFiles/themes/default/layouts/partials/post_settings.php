<?php
// Shared post settings menu + popups
// Expects in scope: $post, $isOwner (bool), $postUrl, $ownerProfileUrl, $iconPath, $viewerId, $premiumPostPriceMinimum, $premiumPostPriceMaximum, $RL, $userID

$postId   = (int)($post['post_id'] ?? 0);
$ownerId  = (int)($post['post_owner_id'] ?? 0);
$commentsOn = (($post['comment_status'] ?? 'on') === 'on');
$isFollowing = (isset($RL) && method_exists($RL,'RL_IsFollowing')) ? $RL->RL_IsFollowing((int)($viewerId ?? 0), $ownerId) : false;
?>

<!-- Post settings popup (per-post, hidden by default) -->
<div id="postMenuPopup-<?php echo $postId; ?>" class="post-menu-popup none" data-post-id="<?php echo $postId; ?>" role="dialog" aria-modal="true" aria-hidden="true">
  <div class="pm-sheet-container">
    <div class="pm-sheet">
      <?php if (!$isOwner): ?>
      <button type="button" class="pm-item is-danger" data-action="report"><?php echo customLang('menu_report'); ?></button>
      <div class="pm-sep"></div>
      <button type="button" class="pm-item <?php echo $isFollowing ? 'is-danger' : ''; ?>" data-action="unfollow"><?php echo $isFollowing ? customLang('menu_unfollow') : customLang('menu_follow'); ?></button>
      <div class="pm-sep"></div>
      <?php endif; ?>
      <button type="button" class="pm-item" data-action="save"><?php echo customLang('menu_add_to_favorites'); ?></button>
      <div class="pm-sep"></div>
      <button type="button" class="pm-item" data-action="open" data-url="<?php echo iN_HelpSecure($postUrl); ?>"><?php echo customLang('menu_go_to_post'); ?></button>
      <div class="pm-sep"></div>
      <button type="button" class="pm-item" data-action="share" data-url="<?php echo iN_HelpSecure($postUrl); ?>"><?php echo customLang('menu_share_to'); ?></button>
      <div class="pm-sep"></div>
      <button type="button" class="pm-item" data-action="copy-link" data-url="<?php echo iN_HelpSecure($postUrl); ?>"><?php echo customLang('menu_copy_link'); ?></button>
      <div class="pm-sep"></div>
      <?php $vis = strtolower((string)($post['post_visibility'] ?? 'everyone')); $canEmbed = ($vis === 'everyone'); ?>
      <button type="button" class="pm-item<?php echo $canEmbed ? '' : ' is-disabled'; ?>" data-action="embed" <?php echo $canEmbed ? '' : 'aria-disabled="true"'; ?>><?php echo customLang('menu_embed'); ?></button>
      <div class="pm-sep"></div>
      <a class="pm-item as-link" href="<?php echo iN_HelpSecure($ownerProfileUrl); ?>"><?php echo customLang('menu_about_this_account'); ?></a>
      <?php if ($isOwner): ?>
      <div class="pm-sep"></div>
      <button type="button" class="pm-item" data-action="who-can-see"><?php echo customLang('menu_who_can_see_this'); ?></button>
      <div class="pm-sep"></div>
      <button type="button" class="pm-item" data-action="edit"><?php echo customLang('menu_edit_post'); ?></button>
      <div class="pm-sep"></div>
      <button type="button" class="pm-item" data-action="toggle-comments"><?php echo $commentsOn ? customLang('menu_disable_comments') : customLang('menu_enable_comments'); ?></button>
      <div class="pm-sep"></div>
      <button type="button" class="pm-item is-danger" data-action="delete"><?php echo customLang('menu_delete_post'); ?></button>
      <?php endif; ?>
    </div>
    <button type="button" class="pm-cancel"><?php echo customLang('menu_cancel'); ?></button>
  </div>
</div>

<!-- Report reasons popup -->
<div id="postReportPopup-<?php echo $postId; ?>" class="post-report-popup none" data-post-id="<?php echo $postId; ?>" role="dialog" aria-modal="true" aria-hidden="true">
  <div class="pr-sheet-container">
    <div class="pr-sheet">
      <div class="pr-header">
        <div class="pr-title"><?php echo customLang('report_title'); ?></div>
        <div class="pr-sub"><?php echo customLang('report_subtitle'); ?></div>
      </div>
      <div class="pr-list" data-loaded="0"></div>
    </div>
    <button type="button" class="pr-cancel"><?php echo customLang('menu_cancel'); ?></button>
  </div>
</div>

<!-- Embed popup -->
<div id="postEmbedPopup-<?php echo $postId; ?>" class="post-embed-popup none" data-post-id="<?php echo $postId; ?>" role="dialog" aria-modal="true" aria-hidden="true">
  <div class="pe-sheet-container">
    <div class="pe-sheet">
      <div class="pe-header">
        <div class="pe-title"><?php echo customLang('embed_title'); ?></div>
        <div class="pe-sub"><?php echo customLang('embed_subtitle'); ?></div>
      </div>
      <div class="pe-body">
        <textarea class="peb-code" rows="4" readonly></textarea>
        <div class="pp-actions"><button type="button" class="peb-copy"><?php echo customLang('embed_copy_code'); ?></button></div>
      </div>
    </div>
    <button type="button" class="pe-cancel"><?php echo customLang('menu_cancel'); ?></button>
  </div>
  </div>

<?php if ($isOwner): ?>
<!-- Visibility popup -->
<div id="postVisibilityPopup-<?php echo $postId; ?>" class="post-visibility-popup none" data-post-id="<?php echo $postId; ?>" role="dialog" aria-modal="true" aria-hidden="true">
  <div class="pv-sheet-container">
    <div class="pv-sheet">
      <div class="pv-header">
        <div class="pv-title"><?php echo customLang('vis_title'); ?></div>
        <div class="pv-sub"><?php echo customLang('vis_subtitle'); ?></div>
      </div>
      <div class="pv-list" data-loaded="0"></div>
    </div>
    <button type="button" class="pv-cancel"><?php echo customLang('menu_cancel'); ?></button>
  </div>
</div>

<!-- Price popup -->
<div id="postPricePopup-<?php echo $postId; ?>" class="post-price-popup none" data-post-id="<?php echo $postId; ?>" role="dialog" aria-modal="true" aria-hidden="true">
  <div class="pp-sheet-container">
    <div class="pp-sheet">
      <div class="pp-header">
        <div class="pp-title"><?php echo customLang('price_title'); ?></div>
        <div class="pp-sub"><?php echo customLang('price_subtitle'); ?></div>
      </div>
      <div class="pp-body">
        <input type="number" class="pp-input" min="<?php echo (int)($premiumPostPriceMinimum ?? 1); ?>" max="<?php echo (int)($premiumPostPriceMaximum ?? 500); ?>" step="1" value="<?php echo (int) ($post['post_price'] ?? 0); ?>" />
        <div class="pp-hint"><?php echo customLang('price_hint'); ?> <?php echo (int)($premiumPostPriceMinimum ?? 1); ?> – <?php echo (int)($premiumPostPriceMaximum ?? 500); ?></div>
        <div class="pp-actions"><button type="button" class="pp-save"><?php echo customLang('menu_save'); ?></button></div>
      </div>
    </div>
    <button type="button" class="pp-cancel"><?php echo customLang('menu_cancel'); ?></button>
  </div>
</div>

<!-- Edit popup -->
<div id="postEditPopup-<?php echo $postId; ?>" class="post-edit-popup none" data-post-id="<?php echo $postId; ?>" role="dialog" aria-modal="true" aria-hidden="true">
  <div class="pe-sheet-container">
    <div class="pe-sheet">
      <div class="pe-header">
        <div class="pe-title"><?php echo customLang('edit_title'); ?></div>
        <div class="pe-sub"><?php echo customLang('edit_subtitle'); ?></div>
      </div>
      <div class="pe-body">
        <textarea class="pe-text" rows="5" maxlength="2000" placeholder="<?php echo customLang('edit_placeholder'); ?>"></textarea>
        <div class="pe-actions"><button type="button" class="pe-save"><?php echo customLang('menu_save'); ?></button></div>
      </div>
    </div>
    <button type="button" class="pe-cancel"><?php echo customLang('menu_cancel'); ?></button>
  </div>
</div>

<!-- Delete confirm popup -->
<div id="postDeletePopup-<?php echo $postId; ?>" class="post-delete-popup none" data-post-id="<?php echo $postId; ?>" role="dialog" aria-modal="true" aria-hidden="true">
  <div class="pd-sheet-container">
    <div class="pd-sheet">
      <div class="pd-header">
        <div class="pd-title"><?php echo customLang('delete_title'); ?></div>
        <div class="pd-sub"><?php echo customLang('delete_subtitle'); ?></div>
      </div>
      <div class="pd-actions">
        <button type="button" class="pd-confirm is-danger"><?php echo customLang('menu_delete_post'); ?></button>
        <button type="button" class="pd-cancel"><?php echo customLang('menu_cancel'); ?></button>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>
