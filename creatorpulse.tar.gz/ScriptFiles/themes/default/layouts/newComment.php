<!--User Comment-->
<?php
    $commentIdLocal          = isset($commentID) ? (int) $commentID : 0;
    $postIdLocal             = isset($postID) ? (int) $postID : 0;
    $commentOwnerIdLocal     = isset($commentOwnerId) ? (int) $commentOwnerId : 0;
    $commentPlainText        = isset($commentText) ? (string) $commentText : '';
    $commentTimeLocal        = isset($commentTime) ? (int) $commentTime : 0;
    $commentUpdatedTimeLocal = isset($commentUpdatedTime) ? (int) $commentUpdatedTime : 0;

    if ($commentOwnerIdLocal <= 0 && $commentIdLocal > 0 && isset($RL) && is_object($RL) && method_exists($RL, 'RL_GetCommentOwnerIdSimple')) {
        $commentOwnerIdLocal = (int) $RL->RL_GetCommentOwnerIdSimple($commentIdLocal);
    }

    $viewerIdResolved = isset($viewerId) ? (int) $viewerId : 0;
    if ($viewerIdResolved === 0 && isset($userID)) {
        $viewerIdResolved = (int) $userID;
    }
    if ($viewerIdResolved === 0 && isset($userData['user_id'])) {
        $viewerIdResolved = (int) $userData['user_id'];
    }

    $viewerIsAdmin = isset($isAdminUser)
        ? (bool) $isAdminUser
        : (bool) ($GLOBALS['isAdminUser'] ?? false);

    $postData = $RL->RL_GetPostData($postIdLocal);
    $postType = $postData['post_type'] ?? null;
    $postOwnerId = (int) ($postData['post_owner_id'] ?? 0);
    $viewerIsPostOwner = ($viewerIdResolved > 0 && $postOwnerId > 0 && $viewerIdResolved === $postOwnerId);

    $viewerCanEdit   = ($viewerIdResolved > 0 && $viewerIdResolved === $commentOwnerIdLocal);
    $viewerCanDelete = $viewerCanEdit || $viewerIsPostOwner || $viewerIsAdmin;
    $viewerCanReport = ($viewerIdResolved > 0 && $viewerIdResolved !== $commentOwnerIdLocal);

    $viewerHasReportedLocal = isset($viewerHasReported) ? (bool) $viewerHasReported : false;
    if ($viewerCanReport && !$viewerHasReportedLocal && isset($RL) && is_object($RL) && method_exists($RL, 'RL_HasUserReportedComment')) {
        $viewerHasReportedLocal = (bool) $RL->RL_HasUserReportedComment($commentIdLocal, $viewerIdResolved);
    }

    $commentIsEdited = ($commentUpdatedTimeLocal > 0 && $commentUpdatedTimeLocal > $commentTimeLocal);

    $commentDomId    = 'comment-' . $commentIdLocal;
    $commentTextAttr = htmlspecialchars($commentPlainText, ENT_QUOTES, 'UTF-8');

    $avatarPath = $ownerAvatar ?? 'uploads/user_avatars/default.jpeg';
    $avatarSrc  = storage_url($avatarPath);

    $commentProfileBase = isset($base_url) ? rtrim((string) $base_url, '/') : '';
    $commentHandle      = (string) ($commentUserName ?? '');
    $commentProfileHref = $commentHandle !== ''
        ? ($commentProfileBase !== '' ? $commentProfileBase . '/profile/' . rawurlencode($commentHandle) : 'profile/' . rawurlencode($commentHandle))
        : '#';

    $reportClass = $viewerHasReportedLocal ? ' is-reported' : '';
    $reportState = $viewerHasReportedLocal ? '1' : '0';
?>
<div
    id="<?php echo iN_HelpSecure($commentDomId); ?>"
    class="post-comment flex full-width"
    data-post-id="<?php echo $postIdLocal; ?>"
    data-comment-id="<?php echo $commentIdLocal; ?>"
    data-comment-owner-id="<?php echo $commentOwnerIdLocal; ?>"
    data-comment-updated="<?php echo $commentIsEdited ? '1' : '0'; ?>"
    data-comment-updated-time="<?php echo $commentUpdatedTimeLocal; ?>"
    data-comment-text="<?php echo $commentTextAttr; ?>"
    data-comment-reported="<?php echo $reportState; ?>"
    data-can-edit="<?php echo $viewerCanEdit ? '1' : '0'; ?>"
    data-can-delete="<?php echo $viewerCanDelete ? '1' : '0'; ?>"
>
    <!-- Avatar -->
    <div class="post-comment-owner-avatar flex align_items relative">
        <div class="post-comment-owner-avatar-container relative">
            <img src="<?php echo iN_HelpSecure($avatarSrc); ?>" alt="<?php echo iN_HelpSecure($commentUserName ?? ''); ?>">
        </div>
    </div>

    <!-- Body -->
    <div class="comment-container full-width">
        <div class="comment-bubble">
            <a href="<?php echo iN_HelpSecure($commentProfileHref, false); ?>" class="comment-owner">
                <?php echo iN_HelpSecure($commentUserName ?? ''); ?>
            </a>
            <span class="comment-text">
                <?php echo nl2br(iN_HelpSecure($commentPlainText)); ?>
            </span>
        </div>

        <div class="comment-data full-width flex align_items">
            <div class="comment-meta flex align_items">
                <div class="comment-data-box flex align_items comment-time">
                    <?php
                        if ($commentTimeLocal > 0) {
                            $commentIso = date('c', $commentTimeLocal);
                            $commentLabel = dz_relative_time_label($commentTimeLocal);
                            echo '<time datetime="' . iN_HelpSecure($commentIso) . '" data-ts="' . $commentTimeLocal . '">' . iN_HelpSecure($commentLabel) . '</time>';
                        }
                    ?>
                </div>
                <?php if ($commentIsEdited): ?>
                    <span class="comment-edited"><?php echo customLang('comment_edited', 'Edited'); ?></span>
                <?php endif; ?>
            </div>

            <div class="comment-actions flex align_items">
                <button
                    type="button"
                    class="comment-data-box flex align_items comment-like cursor-point like_comment"
                    data-comment="<?php echo $commentIdLocal; ?>"
                    data-id="<?php echo $postIdLocal; ?>"
                    data-type="<?php echo iN_HelpSecure((string) $postType); ?>"
                >
                    <?php echo customLang('comment_like'); ?>
                    <span class="comment-like-count" data-comment-id="<?php echo $commentIdLocal; ?>">
                        <?php echo $RL->RL_CountCommentLikes($postIdLocal, $commentIdLocal, $postType) ?: ''; ?>
                    </span>
                </button>

                <button
                    type="button"
                    class="comment-data-box flex align_items comment-reply cursor-point"
                    data-reply="<?php echo iN_HelpSecure((string) $commentUserName); ?>"
                    data-id="<?php echo $postIdLocal; ?>"
                >
                    <?php echo customLang('comment_reply'); ?>
                </button>

                <?php if ($viewerCanReport): ?>
                    <button
                        type="button"
                        class="comment-data-box flex align_items comment-report cursor-point<?php echo $reportClass; ?>"
                        data-comment-id="<?php echo $commentIdLocal; ?>"
                        data-post-id="<?php echo $postIdLocal; ?>"
                        data-comment-owner-id="<?php echo $commentOwnerIdLocal; ?>"
                        data-reported="<?php echo $reportState; ?>"
                    >
                        <?php echo $viewerHasReportedLocal ? customLang('ui_unreport', customLang('menu_report')) : customLang('menu_report'); ?>
                    </button>
                <?php endif; ?>

                <?php if ($viewerCanEdit): ?>
                    <button
                        type="button"
                        class="comment-data-box flex align_items comment-edit cursor-point"
                        data-comment-id="<?php echo $commentIdLocal; ?>"
                        data-post-id="<?php echo $postIdLocal; ?>"
                    >
                        <?php echo customLang('comment_edit', 'Edit'); ?>
                    </button>
                <?php endif; ?>

                <?php if ($viewerCanDelete): ?>
                    <button
                        type="button"
                        class="comment-data-box flex align_items comment-delete cursor-point"
                        data-comment-id="<?php echo $commentIdLocal; ?>"
                        data-post-id="<?php echo $postIdLocal; ?>"
                    >
                        <?php echo customLang('comment_delete', 'Delete'); ?>
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php
        $likedComment = ($viewerIdResolved > 0 && method_exists($RL, 'RL_HasLikedComment'))
            ? $RL->RL_HasLikedComment($viewerIdResolved, $postIdLocal, $commentIdLocal, (string) ($postType ?? ''))
            : false;
    ?>
    <div
        class="c-like cursor-point c_comment_<?php echo $commentIdLocal; ?> <?php echo $likedComment ? 'is-liked' : ''; ?> like_comment"
        data-comment="<?php echo $commentIdLocal; ?>"
        data-id="<?php echo $postIdLocal; ?>"
        data-type="<?php echo iN_HelpSecure((string) $postType); ?>"
    >
        <span class="icon-unliked">
            <?php echo render_icon('like', true); ?>
        </span>
        <span class="icon-liked">
            <?php echo render_icon('liked', true); ?>
        </span>
    </div>

    <?php
        if ($viewerCanReport) {
            $commentReportPopupPath = __DIR__ . '/../popUps/commentReport.php';
            if (is_file($commentReportPopupPath)) {
                include $commentReportPopupPath;
            }
        }
        if ($viewerCanEdit) {
            $commentEditPopupPath = __DIR__ . '/../popUps/commentEdit.php';
            if (is_file($commentEditPopupPath)) {
                include $commentEditPopupPath;
            }
        }
        if ($viewerCanDelete) {
            $commentDeletePopupPath = __DIR__ . '/../popUps/commentDelete.php';
            if (is_file($commentDeletePopupPath)) {
                include $commentDeletePopupPath;
            }
        }
    ?>
</div>
<!--/User Comment-->
