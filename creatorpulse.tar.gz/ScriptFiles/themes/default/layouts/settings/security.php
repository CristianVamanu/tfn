<?php
if (!isset($loggedIn) || $loggedIn !== '1') {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}

$csrfToken = generateCsrfToken();
$requestsEndpoint = iN_HelpSecure($base_url . 'request/requests.php');
$currentSessionKey = isset($cookieName, $_COOKIE[$cookieName]) ? (string) $_COOKIE[$cookieName] : null;

if (!isset($userSecuritySettings) || !is_array($userSecuritySettings)) {
    if (isset($RL) && method_exists($RL, 'RL_GetUserSecurityProfile') && isset($userID)) {
        try {
            $userSecuritySettings = $RL->RL_GetUserSecurityProfile((int) $userID, $currentSessionKey);
        } catch (Throwable $__) {
            $userSecuritySettings = [];
        }
    } else {
        $userSecuritySettings = [];
    }
}

$securityData = is_array($userSecuritySettings) ? $userSecuritySettings : [];
$sessions = isset($securityData['sessions']) && is_array($securityData['sessions']) ? $securityData['sessions'] : [];
$events = isset($securityData['events']) && is_array($securityData['events']) ? $securityData['events'] : [];
$twoFactorEnabled = !empty($securityData['two_factor_enabled']);
$twoFactorPending = !empty($securityData['two_factor_pending']);
$twoFactorTimestamp = isset($securityData['two_factor_enabled_at']) ? (int) $securityData['two_factor_enabled_at'] : 0;
$backupAvailable = !empty($securityData['backup_codes_available']);
$backupGeneratedAt = isset($securityData['backup_codes_generated_at']) ? (int) $securityData['backup_codes_generated_at'] : 0;

$twoFactorStatusLabel = $twoFactorEnabled
    ? customLang('settings_security_status_on', 'Two-factor authentication is enabled')
    : customLang('settings_security_status_off', 'Two-factor authentication is disabled');
$twoFactorStatusClass = $twoFactorEnabled ? 'status-pill--on' : 'status-pill--off';
$twoFactorDateLabel = $twoFactorTimestamp > 0
    ? date('M j, Y H:i', $twoFactorTimestamp)
    : customLang('settings_security_never_updated', 'Never updated');
$backupDateLabel = $backupGeneratedAt > 0
    ? date('M j, Y H:i', $backupGeneratedAt)
    : customLang('settings_security_never_generated', 'Not generated yet');

$securityConfig = [
    'endpoint' => $requestsEndpoint,
    'csrf' => $csrfToken,
    'twoFactorEnabled' => $twoFactorEnabled,
    'twoFactorPending' => $twoFactorPending,
    'statusOn' => customLang('settings_security_status_on', 'Two-factor authentication is enabled'),
    'statusOff' => customLang('settings_security_status_off', 'Two-factor authentication is disabled'),
    'strings' => [
        'passwordSaved' => customLang('settings_security_password_updated', 'Password updated successfully.'),
        'passwordError' => customLang('settings_security_generic_error', 'Something went wrong. Please try again.'),
        'saving' => customLang('saving', 'Saving...'),
        'errorRequired' => customLang('settings_security_error_required', 'Please complete all required fields.'),
        'errorMismatch' => customLang('settings_security_error_password_mismatch', 'New password fields do not match.'),
        'errorWeak' => customLang('settings_security_error_password_weak', 'Choose a stronger password with upper & lower case letters, numbers, and symbols.'),
        'twoFactorEnabled' => customLang('settings_security_2fa_enabled', 'Two-factor authentication is now enabled.'),
        'twoFactorDisabled' => customLang('settings_security_2fa_disabled', 'Two-factor authentication has been disabled.'),
        'twoFactorSetupTitle' => customLang('settings_security_2fa_setup_title', 'Set up your authenticator'),
        'twoFactorStepScan' => customLang('settings_security_2fa_step_scan', 'Scan this QR code using Google Authenticator, Authy, or a compatible app.'),
        'twoFactorStepCode' => customLang('settings_security_2fa_step_code', 'Enter the 6-digit code from your authenticator to finish setup.'),
        'twoFactorVerify' => customLang('settings_security_2fa_verify_button', 'Verify & enable'),
        'twoFactorCancel' => customLang('settings_security_cancel', 'Cancel'),
        'twoFactorQrAlt' => customLang('settings_security_2fa_qr_alt', 'Authenticator QR code'),
        'twoFactorDisableConfirm' => customLang('settings_security_disable_confirm', 'Disable two-factor authentication?'),
        'disableRequires' => customLang('settings_security_disable_requires_code', 'Provide a code or your password to disable two-factor authentication.'),
        'copied' => customLang('settings_security_code_copied', 'Code copied'),
        'copy' => customLang('settings_security_copy', 'Copy'),
        'copySecret' => customLang('settings_security_copy', 'Copy'),
        'copyOtpauth' => customLang('settings_security_copy_otpauth', 'Copy URL'),
        'downloadFileName' => 'backup-codes.txt',
        'sessionsRevoked' => customLang('settings_security_sessions_revoked', 'Other sessions have been signed out.'),
        'sessionRevoked' => customLang('settings_security_session_revoked', 'Session ended.'),
        'sessionsConfirm' => customLang('settings_security_sessions_revoke_prompt', 'Sign out other sessions?'),
        'codesRegenerated' => customLang('settings_security_codes_regenerated', 'New recovery codes generated.'),
        'genericError' => customLang('settings_security_generic_error', 'Something went wrong. Please try again.'),
        'copyCodes' => customLang('settings_security_backup_copy', 'Copy'),
    ],
    'strengthLabels' => [
        customLang('settings_security_strength_very_weak', 'Very weak'),
        customLang('settings_security_strength_weak', 'Weak'),
        customLang('settings_security_strength_ok', 'Okay'),
        customLang('settings_security_strength_good', 'Good'),
        customLang('settings_security_strength_strong', 'Strong'),
    ],
];

$configJson = htmlspecialchars(json_encode($securityConfig, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8');

$formatRelative = static function (int $timestamp): string {
    if ($timestamp <= 0) {
        return customLang('settings_security_unknown_time', '—');
    }
    return date('M j, Y H:i', $timestamp);
};
?>

<section class="card_admin settings-dashboard security-dashboard" role="region" aria-labelledby="securitySettingsHeading" data-security-config="<?php echo $configJson; ?>">
  <h1 class="h1" id="securitySettingsHeading"><?php echo customLang('menu_security'); ?></h1>
  <p class="settings-dashboard-intro"><?php echo customLang('settings_security_intro', 'Protect your account with two-factor authentication, monitor logged-in devices, and review recent security activity.'); ?></p>

  <div class="security-overview">
    <div class="status-pill <?php echo $twoFactorStatusClass; ?>" role="status">
      <span class="status-pill__icon" aria-hidden="true"><?php echo render_icon('security', true); ?></span>
      <div class="status-pill__info">
        <span class="status-pill__label"><?php echo iN_HelpSecure($twoFactorStatusLabel, false); ?></span>
        <span class="status-pill__meta"><?php echo customLang('settings_security_last_updated', 'Last updated'); ?>: <?php echo iN_HelpSecure($twoFactorDateLabel, false); ?></span>
      </div>
    </div>
  </div>

  <div class="security-grid">

    <article class="security-card" id="security-two-factor-card">
      <header class="security-card__header">
        <h3 class="security-card__title"><?php echo customLang('settings_security_2fa_heading', 'Two-factor authentication'); ?></h3>
        <p class="security-card__description"><?php echo customLang('settings_security_2fa_description', 'Add an extra verification step at login using a one-time code from your authenticator app.'); ?></p>
      </header>
      <div class="security-toggle" role="group" aria-labelledby="security-two-factor-title">
        <div class="security-toggle__label">
          <span id="security-two-factor-title"><?php echo customLang('settings_security_2fa_toggle_label', 'Require 6-digit codes on login'); ?></span>
          <span class="security-toggle__status" data-twofactor-status><?php echo iN_HelpSecure($twoFactorStatusLabel, false); ?></span>
        </div>
        <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('settings_security_toggle_aria', 'Toggle two-factor authentication'), false); ?>">
          <input type="checkbox" id="security-twofactor-toggle" <?php echo $twoFactorEnabled ? 'checked' : ''; ?>>
          <span class="el-switch-style" aria-hidden="true"></span>
        </label>
      </div>
      <div class="security-2fa-setup" data-twofactor-setup hidden>
        <div class="security-2fa-qr security-qr-wrap" aria-hidden="true" data-twofactor-qr></div>
        <div class="security-2fa-details">
          <p class="security-2fa-instructions" data-twofactor-scan-text></p>
          <div class="security-field">
            <span class="security-field__label"><?php echo customLang('settings_security_2fa_manual_label', 'Or enter this key manually'); ?></span>
            <div class="security-code-row">
              <code data-twofactor-secret></code>
              <button type="button" class="btn-secondary" data-copy-secret><?php echo customLang('settings_security_copy', 'Copy'); ?></button>
            </div>
          </div>
          <div class="security-field">
            <span class="security-field__label"><?php echo customLang('settings_security_2fa_otpauth_label', 'Full authenticator URL'); ?></span>
            <div class="security-code-row">
              <code data-twofactor-otpauth></code>
              <button type="button" class="btn-secondary" data-copy-otpauth><?php echo customLang('settings_security_copy', 'Copy'); ?></button>
            </div>
          </div>
          <label class="security-field" for="security-twofactor-code">
            <span class="security-field__label"><?php echo customLang('settings_security_2fa_code_label', 'Verification code'); ?></span>
            <input type="text" id="security-twofactor-code" inputmode="numeric" pattern="[0-9]*" maxlength="6" placeholder="123456" autocomplete="one-time-code" data-twofactor-code>
            <span class="security-field__feedback" data-feedback="twofactor" aria-live="polite"></span>
          </label>
          <div class="security-form__actions">
            <button type="button" class="btn-primary" data-twofactor-confirm disabled><?php echo customLang('settings_security_2fa_verify_button', 'Verify & enable'); ?></button>
            <button type="button" class="btn-secondary" data-twofactor-cancel><?php echo customLang('settings_security_cancel', 'Cancel'); ?></button>
          </div>
        </div>
      </div>
      <div class="security-2fa-manage" data-twofactor-manage<?php echo $twoFactorEnabled ? '' : ' hidden'; ?>>
        <p class="security-field__hint"><?php echo customLang('settings_security_2fa_manage_hint', 'Disable two-factor authentication only if you have lost access to your authenticator app and have recovery codes ready.'); ?></p>
        <div class="security-form__actions" data-twofactor-disable-actions>
          <button type="button" class="btn-danger" data-twofactor-disable><?php echo customLang('settings_security_2fa_disable_button', 'Disable two-factor'); ?></button>
        </div>
        <div class="security-2fa-disable" data-twofactor-disable-form hidden>
          <label class="security-field" for="security-twofactor-disable-code">
            <span class="security-field__label"><?php echo customLang('settings_security_2fa_code_label', 'Verification code'); ?></span>
            <input type="text" id="security-twofactor-disable-code" inputmode="numeric" pattern="[0-9]*" maxlength="6" placeholder="123456" data-twofactor-disable-code>
          </label>
          <label class="security-field" for="security-twofactor-disable-password">
            <span class="security-field__label"><?php echo customLang('settings_password_current', 'Current password'); ?></span>
            <input type="password" id="security-twofactor-disable-password" autocomplete="current-password" placeholder="••••••••" data-twofactor-disable-password>
            <span class="security-field__hint"><?php echo customLang('settings_security_disable_requires_code', 'Provide a code or your password to disable two-factor authentication.'); ?></span>
          </label>
          <div class="security-form__actions">
            <button type="button" class="btn-danger" data-twofactor-disable-confirm><?php echo customLang('settings_security_2fa_disable_button', 'Disable two-factor'); ?></button>
            <button type="button" class="btn-secondary" data-twofactor-disable-cancel><?php echo customLang('settings_security_cancel', 'Cancel'); ?></button>
          </div>
          <span class="security-field__feedback" data-feedback="twofactor-disable" aria-live="polite"></span>
        </div>
      </div>
    </article>

    <article class="security-card security-card--sessions">
      <header class="security-card__header">
        <h3 class="security-card__title"><?php echo customLang('settings_security_sessions_heading', 'Active sessions'); ?></h3>
        <p class="security-card__description"><?php echo customLang('settings_security_sessions_description', 'Devices that are currently signed in to your account. Revoke sessions you do not recognise.'); ?></p>
      </header>
      <?php if (empty($sessions)): ?>
        <div class="security-empty">
          <span class="security-empty__icon" aria-hidden="true"><?php echo render_icon('devices', true); ?></span>
          <p><?php echo customLang('settings_security_no_sessions', 'No other active sessions detected.'); ?></p>
        </div>
      <?php else: ?>
        <div class="security-sessions" role="table">
          <div class="security-sessions__row security-sessions__row--head" role="row">
            <span role="columnheader"><?php echo customLang('settings_security_sessions_device', 'Device'); ?></span>
            <span role="columnheader"><?php echo customLang('settings_security_sessions_location', 'Location'); ?></span>
            <span role="columnheader"><?php echo customLang('settings_security_sessions_last_active', 'Last active'); ?></span>
            <span role="columnheader" class="security-sessions__actions"></span>
          </div>
          <?php foreach ($sessions as $session): ?>
            <?php
              $sessionKey = isset($session['session_key']) ? (string) $session['session_key'] : '';
              $deviceLabel = isset($session['device']) && $session['device'] !== '' ? (string) $session['device'] : customLang('settings_security_unknown_device', 'Unknown device');
              $browser = isset($session['browser']) ? (string) $session['browser'] : '';
              $platform = isset($session['platform']) ? (string) $session['platform'] : '';
              $ip = isset($session['ip']) ? (string) $session['ip'] : customLang('settings_security_unknown_ip', '—');
              $location = isset($session['location']) && $session['location'] !== '' ? (string) $session['location'] : customLang('settings_security_unknown_location', '—');
              $lastActive = isset($session['last_active']) ? $formatRelative((int) $session['last_active']) : customLang('settings_security_unknown_time', '—');
              $isCurrent = !empty($session['current']);
            ?>
            <div class="security-sessions__row" role="row" data-session-row>
              <div class="security-sessions__device" role="cell">
                <strong><?php echo iN_HelpSecure($deviceLabel, false); ?></strong>
                <?php if ($browser !== '' || $platform !== ''): ?>
                  <div class="security-sessions__meta"><?php echo iN_HelpSecure(trim($browser . ' ' . $platform), false); ?></div>
                <?php endif; ?>
                <div class="security-sessions__meta">IP: <?php echo iN_HelpSecure($ip, false); ?></div>
              </div>
              <span class="security-sessions__cell" role="cell"><?php echo iN_HelpSecure($location, false); ?></span>
              <span class="security-sessions__cell" role="cell"><?php echo iN_HelpSecure($lastActive, false); ?></span>
              <div class="security-sessions__actions" role="cell">
                <?php if ($isCurrent): ?>
                  <span class="security-badge"><?php echo customLang('settings_security_current_session', 'Current session'); ?></span>
                <?php elseif ($sessionKey !== ''): ?>
                  <button type="button" class="btn-link" data-session-revoke data-session-key="<?php echo htmlspecialchars($sessionKey, ENT_QUOTES, 'UTF-8'); ?>"><?php echo customLang('settings_security_revoke', 'Revoke'); ?></button>
                <?php else: ?>
                  <span class="security-sessions__meta"><?php echo customLang('settings_security_action_unavailable', 'Action unavailable'); ?></span>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
        <div class="security-form__actions security-form__actions--end">
          <button type="button" class="btn-secondary" data-session-revoke-others><?php echo customLang('settings_security_sessions_revoke_all', 'End all other sessions'); ?></button>
        </div>
        <div class="security-empty" data-sessions-empty hidden>
          <span class="security-empty__icon" aria-hidden="true"><?php echo render_icon('devices', true); ?></span>
          <p><?php echo customLang('settings_security_no_sessions', 'No other active sessions detected.'); ?></p>
        </div>
      <?php endif; ?>
    </article>

    <article class="security-card security-card--backup">
      <header class="security-card__header">
        <h3 class="security-card__title"><?php echo customLang('settings_security_backup_heading', 'Backup & recovery'); ?></h3>
        <p class="security-card__description"><?php echo customLang('settings_security_backup_description', 'Store recovery codes in a safe place. Each code can be used once if you lose access to your authenticator app.'); ?></p>
      </header>
      <div class="security-backup">
        <div class="security-backup__meta">
          <span><?php echo customLang('settings_security_backup_last_generated', 'Last generated'); ?>:</span>
          <strong data-backup-last-generated><?php echo iN_HelpSecure($backupDateLabel, false); ?></strong>
        </div>
        <div class="security-backup__actions">
          <button type="button" class="btn-primary" data-backup-generate><?php echo customLang('settings_security_backup_generate', 'Generate new codes'); ?></button>
          <button type="button" class="btn-secondary" data-backup-download disabled><?php echo customLang('settings_security_backup_download', 'Download'); ?></button>
        </div>
        <div class="security-backup__list" data-backup-list hidden>
          <div class="security-backup__controls">
            <button type="button" class="btn-secondary" data-backup-copy><?php echo customLang('settings_security_backup_copy', 'Copy'); ?></button>
            <span class="security-field__hint"><?php echo customLang('settings_security_backup_hint', 'These codes will disappear after you refresh or leave this page. Store them somewhere safe.'); ?></span>
          </div>
          <ul data-backup-codes></ul>
        </div>
      </div>
    </article>
  </div>

  <div class="security-events">
    <h3 class="security-events__title"><?php echo customLang('settings_security_events_heading', 'Recent security events'); ?></h3>
    <p class="security-events__description"><?php echo customLang('settings_security_events_description', 'Successful sign-ins, password changes, and other security actions appear here.'); ?></p>
    <?php if (empty($events)): ?>
      <div class="security-empty">
        <span class="security-empty__icon" aria-hidden="true"><?php echo render_icon('history', true); ?></span>
        <p><?php echo customLang('settings_security_no_events', 'No recent security events recorded.'); ?></p>
      </div>
    <?php else: ?>
      <ul class="security-event-list">
        <?php foreach ($events as $event): ?>
          <?php
            $type = isset($event['type']) ? (string) $event['type'] : 'log';
            $time = isset($event['time']) ? (int) $event['time'] : 0;
            $meta = isset($event['meta']) && is_array($event['meta']) ? $event['meta'] : [];

            $labels = [
              'password_changed' => customLang('settings_security_event_password', 'Password updated'),
              'two_factor_enabled' => customLang('settings_security_event_2fa_on', 'Two-factor enabled'),
              'two_factor_disabled' => customLang('settings_security_event_2fa_off', 'Two-factor disabled'),
              'session_revoked' => customLang('settings_security_event_session_revoked', 'Session revoked'),
              'sessions_revoked' => customLang('settings_security_event_sessions_revoked', 'Multiple sessions revoked'),
              'recovery_codes_regenerated' => customLang('settings_security_event_codes_regenerated', 'Recovery codes regenerated'),
            ];
            $label = isset($labels[$type]) ? $labels[$type] : customLang('settings_security_event_generic', 'Security update');
            $metaText = '';
            if (!empty($meta['session_key'])) {
                $metaText = customLang('settings_security_event_meta_session', 'Session') . ': ' . iN_HelpSecure((string) $meta['session_key'], false);
            } elseif (!empty($meta['count'])) {
                $metaText = sprintf(customLang('settings_security_event_meta_count', 'Affected: %s'), (int) $meta['count']);
            }
          ?>
          <li class="security-event">
            <div class="security-event__main">
              <strong><?php echo iN_HelpSecure($label, false); ?></strong>
              <time datetime="<?php echo date('c', $time); ?>"><?php echo iN_HelpSecure($formatRelative($time), false); ?></time>
            </div>
            <?php if ($metaText !== ''): ?>
              <div class="security-event__meta"><?php echo iN_HelpSecure($metaText, false); ?></div>
            <?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </div>
</section>
