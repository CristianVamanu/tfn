<?php
if (!isset($loggedIn) || $loggedIn !== '1') {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}

if (!isset($creatorDashboard) && isset($RL) && method_exists($RL, 'RL_GetCreatorDashboard') && isset($userID)) {
    try {
        $creatorDashboard = $RL->RL_GetCreatorDashboard((int) $userID);
    } catch (\Throwable $__) {
        $creatorDashboard = [];
    }
}

$currencyCode   = isset($currency) ? strtoupper((string) $currency) : 'USD';
$currencyMap    = isset($currencys) && is_array($currencys) ? $currencys : [];
$currencySymbol = isset($currencyMap[$currencyCode]) ? (string) $currencyMap[$currencyCode] : '$';

$formatMoney = static function ($amount, ?string $code = null) use ($currencySymbol, $currencyCode, $currencyMap): string {
    $value = is_numeric($amount) ? (float) $amount : 0.0;
    $resolvedCode = $code !== null && $code !== '' ? strtoupper($code) : $currencyCode;
    $resolvedSymbol = isset($currencyMap[$resolvedCode]) ? (string) $currencyMap[$resolvedCode] : $currencySymbol;
    return dz_format_currency(
        $value,
        $resolvedCode,
        $resolvedSymbol,
        $GLOBALS['currency_format_settings'] ?? null
    );
};

$formatCount = static function ($value): string {
    if (is_numeric($value)) {
        $number = (float) $value;
        if (function_exists('number_format_short')) {
            return number_format_short($number, 1);
        }
        return number_format($number);
    }
    return (string) $value;
};

$formatDelta = static function ($delta, ?string $overrideLabel = null): array {
    $result = [
        'text'      => customLang('settings_dashboard_no_change', 'No change vs previous period'),
        'direction' => 'neutral',
        'arrow'     => '',
    ];

    if ($overrideLabel !== null && $overrideLabel !== '') {
        $result['text'] = (string) $overrideLabel;
        return $result;
    }

    if ($delta === null || $delta === '') {
        return $result;
    }

    if (is_numeric($delta)) {
        $value = (float) $delta;
        $threshold = 0.05;
        if (abs($value) < $threshold) {
            return $result;
        }
        $result['direction'] = $value > 0 ? 'positive' : 'negative';
        $result['arrow'] = $value > 0 ? '▲' : '▼';
        $result['text'] = sprintf(
            '%s %s%% %s',
            $result['arrow'],
            number_format(abs($value), 1),
            customLang('settings_dashboard_vs_prev', 'vs previous period')
        );
        return $result;
    }

    $result['text'] = (string) $delta;
    return $result;
};

$periodPlaceholder = customLang('settings_dashboard_period_placeholder', 'Period %d');
$segmentPlaceholder = customLang('settings_dashboard_segment_placeholder', 'Segment %d');

$extractSeries = static function (array $data, float $fallbackValue = 0.0, int $targetPoints = 6) use ($periodPlaceholder): array {
    $candidates = [
        $data['series'] ?? null,
        $data['points'] ?? null,
        $data['trend'] ?? null,
        $data['values'] ?? null,
        $data['data'] ?? null,
    ];

    $labelsSource = null;
    if (!empty($data['labels']) && is_array($data['labels'])) {
        $labelsSource = $data['labels'];
    } elseif (!empty($data['dates']) && is_array($data['dates'])) {
        $labelsSource = $data['dates'];
    } elseif (!empty($data['periods']) && is_array($data['periods'])) {
        $labelsSource = $data['periods'];
    }

    foreach ($candidates as $candidate) {
        if (!is_array($candidate) || empty($candidate)) {
            continue;
        }
        $values = [];
        $labels = [];
        foreach ($candidate as $index => $entry) {
            $value = null;
            $label = null;

            if (is_numeric($entry)) {
                $value = (float) $entry;
            } elseif (is_array($entry)) {
                if (isset($entry['v']) && is_numeric($entry['v'])) {
                    $value = (float) $entry['v'];
                } elseif (isset($entry['value']) && is_numeric($entry['value'])) {
                    $value = (float) $entry['value'];
                } elseif (isset($entry['amount']) && is_numeric($entry['amount'])) {
                    $value = (float) $entry['amount'];
                } elseif (isset($entry[0]) && is_numeric($entry[0])) {
                    $value = (float) $entry[0];
                }

                if (isset($entry['label'])) {
                    $label = (string) $entry['label'];
                } elseif (isset($entry['date'])) {
                    $label = (string) $entry['date'];
                } elseif (isset($entry['day'])) {
                    $label = (string) $entry['day'];
                } elseif (isset($entry['t']) && is_numeric($entry['t'])) {
                    $timestamp = (int) $entry['t'];
                    if ($timestamp > 0) {
                        $label = date('M j', $timestamp);
                    }
                }
            }

            if ($value === null) {
                continue;
            }
            $values[] = $value;
            if ($label === null && is_array($labelsSource) && isset($labelsSource[$index])) {
                $label = (string) $labelsSource[$index];
            }
            if ($label === null || $label === '') {
                $label = sprintf($periodPlaceholder, $index + 1);
            }
            $labels[] = $label;
        }

        if (!empty($values)) {
            $labels = array_slice($labels, 0, count($values));
            return ['values' => $values, 'labels' => $labels];
        }
    }

    if ($fallbackValue === 0.0 && isset($data['value']) && is_numeric($data['value'])) {
        $fallbackValue = (float) $data['value'];
    }

    $fallbackValue = max($fallbackValue, 0.0);
    $values = array_fill(0, $targetPoints, $fallbackValue);
    $labels = [];
    for ($i = 0; $i < $targetPoints; $i++) {
        $labels[] = sprintf($periodPlaceholder, $i + 1);
    }
    return ['values' => $values, 'labels' => $labels];
};

$renderInlineLine = static function (array $values, array $labels, string $color): string {
    if (empty($values)) {
        $values = [0.0];
    }
    $max = max($values);
    if ($max <= 0) {
        $max = 1.0;
    }
    $width = 220;
    $height = 80;
    $padding = 8;
    $usableW = $width - ($padding * 2);
    $usableH = $height - ($padding * 2);
    $count = count($values);
    $step = $count > 1 ? $usableW / ($count - 1) : 0;

    $points = [];
    $hotspots = '';
    foreach ($values as $index => $value) {
        $ratio = $max > 0 ? max(min($value / $max, 1), 0) : 0;
        $x = $padding + ($index * $step);
        $y = $padding + ($usableH - ($ratio * $usableH));
        $points[] = $x . ',' . $y;
        $title = isset($labels[$index]) ? $labels[$index] : ('P' . ($index + 1));
        $hotspots .= '<circle cx="' . $x . '" cy="' . $y . '" r="5" fill="rgba(0,0,0,0)"><title>'
            . htmlspecialchars($title . ' · ' . number_format((float) $value, 2, '.', ''), ENT_QUOTES, 'UTF-8')
            . '</title></circle>';
    }

    $polyline = implode(' ', $points);

    return '<svg width="' . $width . '" height="' . $height . '" viewBox="0 0 ' . $width . ' ' . $height . '" role="presentation" aria-hidden="true">'
        . '<defs><linearGradient id="sdInlineGradient" x1="0" y1="0" x2="0" y2="1">'
        . '<stop offset="0%" stop-color="' . $color . '" stop-opacity="0.25" />'
        . '<stop offset="100%" stop-color="' . $color . '" stop-opacity="0" />'
        . '</linearGradient></defs>'
        . '<polygon fill="url(#sdInlineGradient)" points="' . $padding . ',' . ($height - $padding)
        . ' ' . $polyline . ' ' . ($width - $padding) . ',' . ($height - $padding) . '" />'
        . '<polyline fill="none" stroke="' . $color . '" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" points="' . $polyline . '" />'
        . $hotspots
        . '</svg>';
};

$renderInlineBars = static function (array $values, array $labels, string $color): string {
    if (empty($values)) {
        $values = [0.0];
    }
    $width = 160;
    $height = 72;
    $max = max($values);
    if ($max <= 0) {
        $max = 1.0;
    }
    $count = count($values);
    $gap = 6;
    $barWidth = max(8, (int) floor(($width - ($gap * ($count + 1))) / max(1, $count)));
    $bars = '';
    $x = $gap;
    foreach ($values as $index => $value) {
        $ratio = $max > 0 ? max(min($value / $max, 1), 0) : 0;
        $barHeight = max(4, (int) round(($height - 16) * $ratio));
        $y = ($height - 4) - $barHeight;
        $label = isset($labels[$index]) ? $labels[$index] : ('P' . ($index + 1));
        $bars .= '<rect x="' . $x . '" y="' . $y . '" width="' . $barWidth . '" height="' . $barHeight . '" rx="4" fill="' . $color . '">'
            . '<title>' . htmlspecialchars($label . ' · ' . number_format((float) $value, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '</title>'
            . '</rect>';
        $x += $barWidth + $gap;
    }

    return '<svg width="' . $width . '" height="' . $height . '" viewBox="0 0 ' . $width . ' ' . $height . '" role="presentation" aria-hidden="true">'
        . '<rect x="0" y="0" width="' . $width . '" height="' . $height . '" rx="12" fill="var(--sd-admin-bg-offwhite)" />'
        . $bars
        . '</svg>';
};

$renderInlineChart = static function (array $values, array $labels, string $type, string $color) use ($renderInlineLine, $renderInlineBars): string {
    if ($type === 'bar') {
        return $renderInlineBars($values, $labels, $color);
    }
    return $renderInlineLine($values, $labels, $color);
};

$normalizeKpis = static function (array $defaults, array $source) use ($formatCount, $formatMoney, $formatDelta, $extractSeries) {
    $items = [];
    foreach ($defaults as $item) {
        $key = $item['key'];
        $data = isset($source[$key]) && is_array($source[$key]) ? $source[$key] : [];
        $value = $data['value'] ?? $item['value'] ?? 0;
        $type = $data['type'] ?? $item['type'] ?? 'count';
        $deltaRaw = $data['delta'] ?? ($data['change'] ?? null);
        $deltaLabel = isset($data['delta_label']) ? (string) $data['delta_label'] : null;
        $seriesInfo = $extractSeries($data, (float) $value, 6);

        $item['value'] = $value;
        $item['value_type'] = $type;
        $item['value_formatted'] = $type === 'money' ? $formatMoney($value) : $formatCount($value);
        $item['delta_details'] = $formatDelta($deltaRaw, $deltaLabel);
        $item['series_values'] = $seriesInfo['values'];
        $item['series_labels'] = $seriesInfo['labels'];
        $items[] = $item;
    }
    return $items;
};

$dashboardData = (isset($creatorDashboard) && is_array($creatorDashboard)) ? $creatorDashboard : [];
$dailySource   = isset($dashboardData['daily']) && is_array($dashboardData['daily']) ? $dashboardData['daily'] : [];
$weeklySource  = isset($dashboardData['weekly']) && is_array($dashboardData['weekly']) ? $dashboardData['weekly'] : [];

$dailyKpis = $normalizeKpis([
    [
        'key'         => 'followers',
        'label'       => customLang('settings_dashboard_daily_followers', 'Followers (24h)'),
        'type'        => 'count',
        'value'       => 0,
        'chart'       => 'line',
        'icon'        => 'follower',
        'icon_class'  => 'kpi-icon--followers',
        'period_label'=> customLang('settings_dashboard_period_daily', 'Last 24 hours'),
        'accent'      => '#1f4bd8',
    ],
    [
        'key'         => 'subscribers',
        'label'       => customLang('settings_dashboard_daily_subscribers', 'Subscribers (24h)'),
        'type'        => 'count',
        'value'       => 0,
        'chart'       => 'line',
        'icon'        => 'subscription_fees',
        'icon_class'  => 'kpi-icon--subscribers',
        'period_label'=> customLang('settings_dashboard_period_daily', 'Last 24 hours'),
        'accent'      => '#24b8c7',
    ],
    [
        'key'         => 'earnings',
        'label'       => customLang('settings_dashboard_daily_earnings', 'Earnings (24h)'),
        'type'        => 'money',
        'value'       => 0,
        'chart'       => 'bar',
        'icon'        => 'payments',
        'icon_class'  => 'kpi-icon--earnings',
        'period_label'=> customLang('settings_dashboard_period_daily', 'Last 24 hours'),
        'accent'      => '#ff6b60',
    ],
], $dailySource);

$weeklyKpis = $normalizeKpis([
    [
        'key'         => 'followers',
        'label'       => customLang('settings_dashboard_weekly_followers', 'Followers (7 days)'),
        'type'        => 'count',
        'value'       => 0,
        'chart'       => 'line',
        'icon'        => 'creator_icon',
        'icon_class'  => 'kpi-icon--followers',
        'period_label'=> customLang('settings_dashboard_period_weekly', 'Last 7 days'),
        'accent'      => '#1f4bd8',
    ],
    [
        'key'         => 'subscribers',
        'label'       => customLang('settings_dashboard_weekly_subscribers', 'Subscribers (7 days)'),
        'type'        => 'count',
        'value'       => 0,
        'chart'       => 'bar',
        'icon'        => 'subscription_fees',
        'icon_class'  => 'kpi-icon--subscribers',
        'period_label'=> customLang('settings_dashboard_period_weekly', 'Last 7 days'),
        'accent'      => '#24b8c7',
    ],
    [
        'key'         => 'earnings',
        'label'       => customLang('settings_dashboard_weekly_earnings', 'Earnings (7 days)'),
        'type'        => 'money',
        'value'       => 0,
        'chart'       => 'line',
        'icon'        => 'payments',
        'icon_class'  => 'kpi-icon--earnings',
        'period_label'=> customLang('settings_dashboard_period_weekly', 'Last 7 days'),
        'accent'      => '#ff6b60',
    ],
], $weeklySource);

$weeklyFollowersSeries = isset($weeklyKpis[0]) ? $weeklyKpis[0]['series_values'] : [];
$weeklyFollowersLabels = isset($weeklyKpis[0]) ? $weeklyKpis[0]['series_labels'] : [];
$weeklySubscribersSeries = isset($weeklyKpis[1]) ? $weeklyKpis[1]['series_values'] : [];
$weeklySubscribersLabels = isset($weeklyKpis[1]) ? $weeklyKpis[1]['series_labels'] : [];
$weeklyEarningsSeries  = isset($weeklyKpis[2]) ? $weeklyKpis[2]['series_values'] : [];
$weeklyEarningsLabels  = isset($weeklyKpis[2]) ? $weeklyKpis[2]['series_labels'] : [];

$growthLabels = !empty($weeklyFollowersLabels) ? $weeklyFollowersLabels : $weeklySubscribersLabels;
if (empty($growthLabels) && !empty($weeklyEarningsLabels)) {
    $growthLabels = $weeklyEarningsLabels;
}
$growthCount = min(
    !empty($growthLabels) ? count($growthLabels) : PHP_INT_MAX,
    !empty($weeklyFollowersSeries) ? count($weeklyFollowersSeries) : PHP_INT_MAX,
    !empty($weeklySubscribersSeries) ? count($weeklySubscribersSeries) : PHP_INT_MAX
);
if (!is_int($growthCount) || $growthCount === PHP_INT_MAX) {
    $growthCount = 0;
}
if ($growthCount > 0) {
    $growthLabels = array_slice($growthLabels, -$growthCount);
    $weeklyFollowersSeries = array_slice($weeklyFollowersSeries, -$growthCount);
    $weeklySubscribersSeries = array_slice($weeklySubscribersSeries, -$growthCount);
} else {
    $growthLabels = [];
    $weeklyFollowersSeries = [];
    $weeklySubscribersSeries = [];
}

$insightCards = [];
if (!empty($weeklyFollowersSeries)) {
    $deltaInfo = $weeklyKpis[0]['delta_details'];
    $latestValue = end($weeklyFollowersSeries);
    $insightCards[] = [
        'title'      => customLang('settings_dashboard_chart_supporters', 'Supporter growth'),
        'hint'       => customLang('settings_dashboard_chart_supporters_hint', 'Follower and subscriber momentum across the last seven days.'),
        'summary'    => sprintf(
            customLang('settings_dashboard_chart_supporters_summary', '%s followers this week; %s'),
            $formatCount($latestValue),
            $deltaInfo['text']
        ),
        'trend'      => $deltaInfo,
        'chart'      => 'line',
        'series'     => $weeklyFollowersSeries,
        'labels'     => $weeklyFollowersLabels,
        'accent'     => '#1f4bd8',
        'icon'       => 'follower',
        'icon_class' => 'kpi-icon--supporters',
    ];
    reset($weeklyFollowersSeries);
}

if (!empty($weeklyEarningsSeries)) {
    $deltaInfo = $weeklyKpis[2]['delta_details'];
    $latestValue = end($weeklyEarningsSeries);
    $insightCards[] = [
        'title'      => customLang('settings_dashboard_chart_revenue', 'Revenue trend'),
        'hint'       => customLang('settings_dashboard_chart_revenue_hint', 'Total subscription, tip, post sale and eBook earnings collected per day.'),
        'summary'    => sprintf(
            customLang('settings_dashboard_chart_revenue_summary', '%s earned over the tracked period; %s'),
            $formatMoney($latestValue),
            $deltaInfo['text']
        ),
        'trend'      => $deltaInfo,
        'chart'      => 'bar',
        'series'     => $weeklyEarningsSeries,
        'labels'     => $weeklyEarningsLabels,
        'accent'     => '#ff6b60',
        'icon'       => 'payments',
        'icon_class' => 'kpi-icon--revenue',
    ];
    reset($weeklyEarningsSeries);
}

if (!empty($weeklySubscribersSeries)) {
    $deltaInfo = $weeklyKpis[1]['delta_details'];
    $latestValue = end($weeklySubscribersSeries);
    $insightCards[] = [
        'title'      => customLang('settings_dashboard_chart_subscribers', 'Subscriber conversions'),
        'hint'       => customLang('settings_dashboard_chart_subscribers_hint', 'New paid supporters joining your plans each day.'),
        'summary'    => sprintf(
            customLang('settings_dashboard_chart_subscribers_summary', '%s subscribers added; %s'),
            $formatCount($latestValue),
            $deltaInfo['text']
        ),
        'trend'      => $deltaInfo,
        'chart'      => 'line',
        'series'     => $weeklySubscribersSeries,
        'labels'     => $weeklySubscribersLabels,
        'accent'     => '#24b8c7',
        'icon'       => 'subscription_fees',
        'icon_class' => 'kpi-icon--supporters',
    ];
    reset($weeklySubscribersSeries);
}

$recentSubscribers = [];
if (!empty($dashboardData['recent_subscribers']) && is_array($dashboardData['recent_subscribers'])) {
    foreach ($dashboardData['recent_subscribers'] as $row) {
        if (!is_array($row)) {
            continue;
        }
        $username    = (string) ($row['username'] ?? '');
        $displayName = (string) ($row['display_name'] ?? ($row['user'] ?? ($row['full_name'] ?? ($username !== '' ? $username : '—'))));
        if ($displayName === '') {
            $displayName = $username !== '' ? $username : '—';
        }
        $avatar = (string) ($row['avatar'] ?? '');
        if ($avatar === '') {
            $avatar = 'uploads/user_avatars/default.jpeg';
        }
        $recentSubscribers[] = [
            'user'         => $displayName,
            'display_name' => $displayName,
            'full_name'    => (string) ($row['full_name'] ?? ''),
            'username'     => $username,
            'avatar'       => $avatar,
            'user_id'      => isset($row['user_id']) ? (int) $row['user_id'] : null,
            'plan'         => (string) ($row['plan'] ?? ($row['tier'] ?? '—')),
            'amount'       => $row['amount'] ?? ($row['price'] ?? null),
            'date'         => $row['joined_at'] ?? ($row['date'] ?? null),
        ];
    }
}

$recentTips = [];
if (!empty($dashboardData['recent_tips']) && is_array($dashboardData['recent_tips'])) {
    foreach ($dashboardData['recent_tips'] as $row) {
        if (!is_array($row)) {
            continue;
        }
        $username    = (string) ($row['username'] ?? '');
        $displayName = (string) ($row['display_name'] ?? ($row['user'] ?? ($row['full_name'] ?? ($username !== '' ? $username : '—'))));
        if ($displayName === '') {
            $displayName = $username !== '' ? $username : '—';
        }
        $avatar = (string) ($row['avatar'] ?? '');
        if ($avatar === '') {
            $avatar = 'uploads/user_avatars/default.jpeg';
        }
        $recentTips[] = [
            'user'         => $displayName,
            'display_name' => $displayName,
            'full_name'    => (string) ($row['full_name'] ?? ''),
            'username'     => $username,
            'avatar'       => $avatar,
            'user_id'      => isset($row['user_id']) ? (int) $row['user_id'] : null,
            'amount'       => $row['amount'] ?? ($row['value'] ?? null),
            'note'         => (string) ($row['note'] ?? ($row['message'] ?? '')),
            'date'         => $row['date'] ?? ($row['tipped_at'] ?? null),
            'status'       => isset($row['status']) ? (string) $row['status'] : '',
        ];
    }
}

$recentAudioRoomEarnings = [];
if (!empty($dashboardData['recent_audio_room_earnings']) && is_array($dashboardData['recent_audio_room_earnings'])) {
    foreach ($dashboardData['recent_audio_room_earnings'] as $row) {
        if (!is_array($row)) {
            continue;
        }
        $username = (string)($row['username'] ?? '');
        $displayName = (string)($row['display_name'] ?? ($row['user'] ?? ($username !== '' ? $username : '—')));
        $recentAudioRoomEarnings[] = [
            'type'         => (string)($row['type'] ?? ''),
            'room_id'      => isset($row['room_id']) ? (int)$row['room_id'] : 0,
            'room_title'   => (string)($row['room_title'] ?? ''),
            'display_name' => $displayName !== '' ? $displayName : '—',
            'username'     => $username,
            'avatar'       => (string)($row['avatar'] ?? 'uploads/user_avatars/default.jpeg'),
            'amount'       => $row['amount'] ?? null,
            'currency'     => (string)($row['currency'] ?? ''),
            'date'         => $row['date'] ?? null,
        ];
    }
}

$postSales = [];
if (!empty($dashboardData['recent_sales']) && is_array($dashboardData['recent_sales'])) {
    foreach ($dashboardData['recent_sales'] as $row) {
        if (!is_array($row)) {
            continue;
        }
        $username    = (string) ($row['username'] ?? ($row['buyer_username'] ?? ''));
        $displayName = (string) ($row['display_name'] ?? ($row['buyer'] ?? ($row['buyer_display'] ?? ($row['full_name'] ?? ($username !== '' ? $username : '—')))));
        if ($displayName === '') {
            $displayName = $username !== '' ? $username : '—';
        }
        $avatar = (string) ($row['avatar'] ?? ($row['buyer_avatar'] ?? ''));
        if ($avatar === '') {
            $avatar = 'uploads/user_avatars/default.jpeg';
        }
        $postSales[] = [
            'type'         => (string) ($row['type'] ?? 'post'),
            'post'         => (string) ($row['post'] ?? ($row['title'] ?? customLang('settings_dashboard_sale_post', 'Post'))),
            'buyer'        => $displayName,
            'display_name' => $displayName,
            'full_name'    => (string) ($row['full_name'] ?? ''),
            'username'     => $username,
            'avatar'       => $avatar,
            'buyer_id'     => isset($row['buyer_id']) ? (int) $row['buyer_id'] : null,
            'amount'       => $row['amount'] ?? ($row['price'] ?? null),
            'currency'     => (string) ($row['currency'] ?? ''),
            'date'         => $row['date'] ?? ($row['purchased_at'] ?? null),
        ];
    }
}

$formatDate = static function ($value): string {
    if (is_numeric($value)) {
        $timestamp = (int) $value;
        if ($timestamp > 0) {
            return date('d.m.Y H:i', $timestamp);
        }
    } elseif ($value instanceof DateTimeInterface) {
        return $value->format('d.m.Y H:i');
    } elseif (is_string($value) && $value !== '') {
        return $value;
    }
    return '—';
};

$sumColumn = static function (array $rows, string $key): float {
    $total = 0.0;
    foreach ($rows as $row) {
        if (!isset($row[$key])) {
            continue;
        }
        $amount = $row[$key];
        if (is_numeric($amount)) {
            $total += (float) $amount;
        }
    }
    return $total;
};

$baseProfileRoot = '';
if (!empty($base_url)) {
    $baseProfileRoot = rtrim((string) $base_url, '/');
} elseif (!empty($baseUrl)) {
    $baseProfileRoot = rtrim((string) $baseUrl, '/');
}

$buildProfileLink = static function (?string $username) use ($baseProfileRoot): string {
    $candidate = trim((string) $username);
    if ($candidate === '') {
        return '';
    }
    $candidate = ltrim($candidate, '@');
    if ($candidate === '') {
        return '';
    }
    if ($baseProfileRoot === '') {
        return 'profile/' . $candidate;
    }
    return $baseProfileRoot . '/profile/' . $candidate;
};

$resolveAvatarUrl = static function (?string $path): string {
    $candidate = trim((string) $path);
    if ($candidate === '') {
        $candidate = 'uploads/user_avatars/default.jpeg';
    }
    return storage_url($candidate);
};

$revenueTotals = isset($dashboardData['revenue_breakdown']) && is_array($dashboardData['revenue_breakdown'])
    ? $dashboardData['revenue_breakdown']
    : null;

$revenueBreakdown = [
    'labels' => [
        customLang('settings_dashboard_breakdown_subs', 'Subscription revenue'),
        customLang('settings_dashboard_breakdown_tips', 'Tips'),
        customLang('settings_dashboard_breakdown_sales', 'Post sales'),
        customLang('settings_dashboard_breakdown_ebook_sales', 'eBook sales'),
        customLang('settings_dashboard_breakdown_audio_room_tips', 'Audio Room tips'),
        customLang('settings_dashboard_breakdown_audio_room_tickets', 'Audio Room tickets'),
    ],
    'values' => [
        isset($revenueTotals['subscriptions']) ? round((float)$revenueTotals['subscriptions'], 2) : round($sumColumn($recentSubscribers, 'amount'), 2),
        isset($revenueTotals['tips']) ? round((float)$revenueTotals['tips'], 2) : round($sumColumn($recentTips, 'amount'), 2),
        isset($revenueTotals['sales']) ? round((float)$revenueTotals['sales'], 2) : round($sumColumn($postSales, 'amount'), 2),
        isset($revenueTotals['ebook_sales']) ? round((float)$revenueTotals['ebook_sales'], 2) : 0.0,
        isset($revenueTotals['audio_room_tips']) ? round((float)$revenueTotals['audio_room_tips'], 2) : 0.0,
        isset($revenueTotals['audio_room_tickets']) ? round((float)$revenueTotals['audio_room_tickets'], 2) : 0.0,
    ],
];

$growthLabelsJson = htmlspecialchars(json_encode(array_values($growthLabels)), ENT_QUOTES, 'UTF-8');
$growthFollowersJson = htmlspecialchars(json_encode(array_map('floatval', $weeklyFollowersSeries)), ENT_QUOTES, 'UTF-8');
$growthSubscribersJson = htmlspecialchars(json_encode(array_map('floatval', $weeklySubscribersSeries)), ENT_QUOTES, 'UTF-8');
$revenueBreakdownJson = htmlspecialchars(json_encode($revenueBreakdown), ENT_QUOTES, 'UTF-8');
?>

<section class="card_admin settings-dashboard rounded-2xl" role="region" aria-labelledby="settingsDashHeading">
  <h1 class="h1" id="settingsDashHeading"><?php echo customLang('settings_dashboard_title', 'Creator dashboard'); ?></h1>
  <p class="settings-dashboard-intro"><?php echo customLang('settings_dashboard_intro', 'Track your growth, revenue, and take action without leaving the settings area.'); ?></p>

  <div class="kpi-row">
    <?php foreach ($dailyKpis as $metric): ?>
      <?php $delta = $metric['delta_details']; ?>
      <article class="admin-card card kpi-card" aria-label="<?php echo htmlspecialchars($metric['label'], ENT_QUOTES, 'UTF-8'); ?>">
        <div class="kpi-left">
          <div class="kpi-title">
            <span class="kpi-icon <?php echo $metric['icon_class']; ?>"><?php echo render_icon($metric['icon'], true); ?></span>
            <?php echo htmlspecialchars($metric['label'], ENT_QUOTES, 'UTF-8'); ?>
          </div>
          <div class="kpi-amount"><?php echo htmlspecialchars($metric['value_formatted'], ENT_QUOTES, 'UTF-8'); ?></div>
          <div class="kpi-period"><?php echo htmlspecialchars($metric['period_label'], ENT_QUOTES, 'UTF-8'); ?></div>
          <div class="kpi-delta <?php echo $delta['direction']; ?>">
            <?php if ($delta['arrow'] !== ''): ?><span class="arrow"><?php echo $delta['arrow']; ?></span><?php endif; ?>
            <span><?php echo htmlspecialchars($delta['text'], ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
        </div>
        <div class="kpi-chart <?php echo $metric['chart'] === 'bar' ? '' : 'kpi-chart--line'; ?>">
          <?php echo $renderInlineChart($metric['series_values'], $metric['series_labels'], $metric['chart'], $metric['accent']); ?>
          <span class="sr-only"><?php echo htmlspecialchars($metric['period_label'], ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
      </article>
    <?php endforeach; ?>
  </div>

  <div class="kpi-row">
    <?php foreach ($weeklyKpis as $metric): ?>
      <?php $delta = $metric['delta_details']; ?>
      <article class="admin-card card kpi-card" aria-label="<?php echo htmlspecialchars($metric['label'], ENT_QUOTES, 'UTF-8'); ?>">
        <div class="kpi-left">
          <div class="kpi-title">
            <span class="kpi-icon <?php echo $metric['icon_class']; ?>"><?php echo render_icon($metric['icon'], true); ?></span>
            <?php echo htmlspecialchars($metric['label'], ENT_QUOTES, 'UTF-8'); ?>
          </div>
          <div class="kpi-amount"><?php echo htmlspecialchars($metric['value_formatted'], ENT_QUOTES, 'UTF-8'); ?></div>
          <div class="kpi-period"><?php echo htmlspecialchars($metric['period_label'], ENT_QUOTES, 'UTF-8'); ?></div>
          <div class="kpi-delta <?php echo $delta['direction']; ?>">
            <?php if ($delta['arrow'] !== ''): ?><span class="arrow"><?php echo $delta['arrow']; ?></span><?php endif; ?>
            <span><?php echo htmlspecialchars($delta['text'], ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
        </div>
        <div class="kpi-chart <?php echo $metric['chart'] === 'bar' ? '' : 'kpi-chart--line'; ?>">
          <?php echo $renderInlineChart($metric['series_values'], $metric['series_labels'], $metric['chart'], $metric['accent']); ?>
          <span class="sr-only"><?php echo htmlspecialchars($metric['period_label'], ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
      </article>
    <?php endforeach; ?>
  </div>

  <div class="charts-row">
    <div class="admin-card card chart-card">
      <div class="chart-title"><?php echo customLang('settings_dashboard_growth_chart_title', 'Supporter growth breakdown'); ?></div>
      <div class="chart-legend">
        <span><span class="legend-dot legend-blue"></span><?php echo customLang('settings_dashboard_followers_label', 'Followers'); ?></span>
        <span><span class="legend-dot legend-cyan"></span><?php echo customLang('settings_dashboard_subscribers_label', 'Subscribers'); ?></span>
      </div>
      <div class="chart-box chart-box--growth">
        <canvas
          id="settingsGrowthChart"
          class="chart-canvas"
          data-labels='<?php echo $growthLabelsJson; ?>'
          data-followers='<?php echo $growthFollowersJson; ?>'
          data-subscribers='<?php echo $growthSubscribersJson; ?>'
          data-followers-label="<?php echo htmlspecialchars(customLang('settings_dashboard_followers_label', 'Followers'), ENT_QUOTES, 'UTF-8'); ?>"
          data-subscribers-label="<?php echo htmlspecialchars(customLang('settings_dashboard_subscribers_label', 'Subscribers'), ENT_QUOTES, 'UTF-8'); ?>"
          data-period-template="<?php echo htmlspecialchars($periodPlaceholder, ENT_QUOTES, 'UTF-8'); ?>"
        ></canvas>
        <p class="chart-fallback"><?php echo customLang('settings_dashboard_chart_fallback', 'Not enough data to render this chart yet.'); ?></p>
      </div>
    </div>

    <div class="admin-card card donut-card">
      <div class="chart-title"><?php echo customLang('settings_dashboard_revenue_mix', 'Revenue mix'); ?></div>
      <div class="chart-legend">
        <span><span class="legend-dot legend-blue"></span><?php echo customLang('settings_dashboard_breakdown_subs_short', 'Subscriptions'); ?></span>
        <span><span class="legend-dot legend-red"></span><?php echo customLang('settings_dashboard_breakdown_tips_short', 'Tips'); ?></span>
        <span><span class="legend-dot legend-cyan"></span><?php echo customLang('settings_dashboard_breakdown_sales_short', 'Posts'); ?></span>
        <span><span class="legend-dot legend-green"></span><?php echo customLang('settings_dashboard_breakdown_ebooks_short', 'eBooks'); ?></span>
        <span><span class="legend-dot legend-orange"></span><?php echo customLang('settings_dashboard_breakdown_audio_room_tips_short', 'Room tips'); ?></span>
        <span><span class="legend-dot legend-purple"></span><?php echo customLang('settings_dashboard_breakdown_audio_room_tickets_short', 'Room tickets'); ?></span>
      </div>
      <div class="chart-box chart-box--donut">
        <canvas
          id="settingsRevenueMixChart"
          class="chart-canvas"
          data-breakdown='<?php echo $revenueBreakdownJson; ?>'
          data-total-label="<?php echo htmlspecialchars(customLang('settings_dashboard_revenue_total', 'Total'), ENT_QUOTES, 'UTF-8'); ?>"
          data-segment-template="<?php echo htmlspecialchars($segmentPlaceholder, ENT_QUOTES, 'UTF-8'); ?>"
        ></canvas>
        <p class="chart-fallback"><?php echo customLang('settings_dashboard_chart_fallback', 'Not enough data to render this chart yet.'); ?></p>
      </div>
    </div>
  </div>

  <?php if (!empty($insightCards)): ?>
    <div class="insight-row">
      <?php foreach ($insightCards as $index => $card): ?>
        <div class="admin-card card insight-card">
          <div class="insight-header">
            <span class="kpi-icon <?php echo $card['icon_class']; ?>"><?php echo render_icon($card['icon'], true); ?></span>
            <div class="insight-title-wrap">
              <div class="insight-title"><?php echo htmlspecialchars($card['title'], ENT_QUOTES, 'UTF-8'); ?></div>
              <button type="button" class="insight-info" aria-label="<?php echo htmlspecialchars($card['hint'], ENT_QUOTES, 'UTF-8'); ?>" aria-describedby="insight-tip-<?php echo $index; ?>">
                <?php echo render_icon('question_icon', true); ?>
              </button>
              <div class="insight-tooltip" id="insight-tip-<?php echo $index; ?>" role="tooltip"><?php echo htmlspecialchars($card['hint'], ENT_QUOTES, 'UTF-8'); ?></div>
            </div>
          </div>
          <div class="insight-summary"><?php echo htmlspecialchars($card['summary'], ENT_QUOTES, 'UTF-8'); ?></div>
          <div class="insight-trend <?php echo $card['trend']['direction']; ?>">
            <?php if ($card['trend']['arrow'] !== ''): ?><span class="arrow"><?php echo $card['trend']['arrow']; ?></span><?php endif; ?>
            <span><?php echo htmlspecialchars($card['trend']['text'], ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
          <div class="kpi-chart <?php echo $card['chart'] === 'bar' ? '' : 'kpi-chart--line'; ?>">
            <?php echo $renderInlineChart($card['series'], $card['labels'], $card['chart'], $card['accent']); ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <div class="kpi-row">
    <div class="admin-card card list-card">
      <div class="list-header">
        <span class="icon"><?php echo render_icon('subscription_fees', true); ?></span>
        <span><strong><?php echo customLang('settings_dashboard_recent_subscribers', 'Recent subscribers'); ?></strong></span>
      </div>
      <ul class="activity-list">
        <?php if (empty($recentSubscribers)): ?>
          <li class="activity-item activity-item--empty"><?php echo customLang('settings_dashboard_empty_subscribers', 'No new subscribers recorded this week.'); ?></li>
        <?php else: ?>
          <?php foreach ($recentSubscribers as $row): ?>
            <?php
              $amountDisplay = (isset($row['amount']) && is_numeric($row['amount'])) ? $formatMoney($row['amount']) : '—';
              $dateDisplay = $formatDate($row['date']);
              $profileUrl = $buildProfileLink($row['username'] ?? '');
              $avatarUrl = $resolveAvatarUrl($row['avatar'] ?? '');
              $name = (string) ($row['display_name'] ?? $row['user'] ?? '—');
              $alt = sprintf(customLang('alt_avatar_of_user', 'Avatar of %s'), $name);
            ?>
            <li class="activity-item">
              <div class="avatar-stack">
                <?php if ($profileUrl !== ''): ?>
                  <a class="avatar-link" href="<?php echo htmlspecialchars($profileUrl, ENT_QUOTES, 'UTF-8'); ?>">
                    <img src="<?php echo htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($alt, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy">
                  </a>
                <?php else: ?>
                  <img src="<?php echo htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($alt, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy">
                <?php endif; ?>
              </div>
              <div class="activity-body">
                <div class="title">
                  <?php if ($profileUrl !== ''): ?>
                    <a class="activity-name" href="<?php echo htmlspecialchars($profileUrl, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?></a>
                  <?php else: ?>
                    <strong><?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?></strong>
                  <?php endif; ?>
                  <span><?php echo htmlspecialchars($row['plan'], ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
                <div class="meta">
                  <strong><?php echo htmlspecialchars($amountDisplay, ENT_QUOTES, 'UTF-8'); ?></strong>
                  <span>· <?php echo htmlspecialchars($dateDisplay, ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
              </div>
            </li>
          <?php endforeach; ?>
        <?php endif; ?>
      </ul>
    </div>

    <div class="admin-card card list-card">
      <div class="list-header">
        <span class="icon"><?php echo render_icon('speaker', true); ?></span>
        <span><strong><?php echo customLang('settings_dashboard_recent_audio_room_earnings', 'Recent Audio Room earnings'); ?></strong></span>
      </div>
      <ul class="activity-list">
        <?php if (empty($recentAudioRoomEarnings)): ?>
          <li class="activity-item activity-item--empty"><?php echo customLang('settings_dashboard_empty_audio_room_earnings', 'No Audio Room earnings recorded yet.'); ?></li>
        <?php else: ?>
          <?php foreach ($recentAudioRoomEarnings as $row): ?>
            <?php
              $amountDisplay = (isset($row['amount']) && is_numeric($row['amount'])) ? $formatMoney($row['amount'], $row['currency'] ?? null) : '—';
              $dateDisplay = $formatDate($row['date']);
              $profileUrl = $buildProfileLink($row['username'] ?? '');
              $avatarUrl = $resolveAvatarUrl($row['avatar'] ?? '');
              $name = (string)($row['display_name'] ?? '—');
              $alt = sprintf(customLang('alt_avatar_of_user', 'Avatar of %s'), $name);
              $isTicket = ($row['type'] ?? '') === 'ticket';
              $typeLabel = $isTicket
                ? customLang('settings_dashboard_audio_room_ticket', 'Room ticket')
                : customLang('settings_dashboard_audio_room_tip', 'Room tip');
              $roomTitle = trim((string)($row['room_title'] ?? ''));
              if ($roomTitle === '') {
                  $roomTitle = customLang('audio_room_label', 'Audio Room');
              }
            ?>
            <li class="activity-item">
              <div class="avatar-stack">
                <?php if ($profileUrl !== ''): ?>
                  <a class="avatar-link" href="<?php echo htmlspecialchars($profileUrl, ENT_QUOTES, 'UTF-8'); ?>">
                    <img src="<?php echo htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($alt, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy">
                  </a>
                <?php else: ?>
                  <img src="<?php echo htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($alt, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy">
                <?php endif; ?>
              </div>
              <div class="activity-body">
                <div class="title">
                  <strong><?php echo htmlspecialchars($roomTitle, ENT_QUOTES, 'UTF-8'); ?></strong>
                  <span class="status-badge status-badge--neutral"><?php echo htmlspecialchars($typeLabel, ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
                <div class="meta">
                  <strong><?php echo htmlspecialchars($amountDisplay, ENT_QUOTES, 'UTF-8'); ?></strong>
                  <span>· <?php echo htmlspecialchars($dateDisplay, ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
              </div>
            </li>
          <?php endforeach; ?>
        <?php endif; ?>
      </ul>
    </div>

    <div class="admin-card card list-card">
      <div class="list-header">
        <span class="icon"><?php echo render_icon('super_thanks', true); ?></span>
        <span><strong><?php echo customLang('settings_dashboard_recent_tips', 'Recent tips'); ?></strong></span>
      </div>
      <ul class="activity-list">
        <?php if (empty($recentTips)): ?>
          <li class="activity-item activity-item--empty"><?php echo customLang('settings_dashboard_empty_tips', 'No tips received this period.'); ?></li>
        <?php else: ?>
          <?php foreach ($recentTips as $row): ?>
            <?php
              $amountDisplay = (isset($row['amount']) && is_numeric($row['amount'])) ? $formatMoney($row['amount']) : '—';
              $dateDisplay = $formatDate($row['date']);
              $noteDisplay = $row['note'] !== '' ? $row['note'] : '';
              $profileUrl = $buildProfileLink($row['username'] ?? '');
              $avatarUrl = $resolveAvatarUrl($row['avatar'] ?? '');
              $name = (string) ($row['display_name'] ?? $row['user'] ?? '—');
              $alt = sprintf(customLang('alt_avatar_of_user', 'Avatar of %s'), $name);
            ?>
            <li class="activity-item">
              <div class="avatar-stack">
                <?php if ($profileUrl !== ''): ?>
                  <a class="avatar-link" href="<?php echo htmlspecialchars($profileUrl, ENT_QUOTES, 'UTF-8'); ?>">
                    <img src="<?php echo htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($alt, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy">
                  </a>
                <?php else: ?>
                  <img src="<?php echo htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($alt, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy">
                <?php endif; ?>
              </div>
              <div class="activity-body">
                <div class="title">
                  <?php if ($profileUrl !== ''): ?>
                    <a class="activity-name" href="<?php echo htmlspecialchars($profileUrl, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?></a>
                  <?php else: ?>
                    <strong><?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?></strong>
                  <?php endif; ?>
                  <?php if (!empty($row['status'])): ?><span><?php echo htmlspecialchars($row['status'], ENT_QUOTES, 'UTF-8'); ?></span><?php endif; ?>
                </div>
                <div class="meta">
                  <strong><?php echo htmlspecialchars($amountDisplay, ENT_QUOTES, 'UTF-8'); ?></strong>
                  <span>· <?php echo htmlspecialchars($dateDisplay, ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
                <?php if ($noteDisplay !== ''): ?>
                  <div class="meta"><?php echo htmlspecialchars($noteDisplay, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
              </div>
            </li>
          <?php endforeach; ?>
        <?php endif; ?>
      </ul>
    </div>

    <div class="admin-card card list-card">
      <div class="list-header">
        <span class="icon"><?php echo render_icon('payments', true); ?></span>
        <span><strong><?php echo customLang('settings_dashboard_sales', 'Sales'); ?></strong></span>
      </div>
      <ul class="activity-list">
        <?php if (empty($postSales)): ?>
          <li class="activity-item activity-item--empty"><?php echo customLang('settings_dashboard_empty_sales', 'No post sales recorded yet.'); ?></li>
        <?php else: ?>
          <?php foreach ($postSales as $row): ?>
            <?php
              $amountDisplay = (isset($row['amount']) && is_numeric($row['amount'])) ? $formatMoney($row['amount'], $row['currency'] ?? null) : '—';
              $dateDisplay = $formatDate($row['date']);
              $profileUrl = $buildProfileLink($row['username'] ?? '');
              $avatarUrl = $resolveAvatarUrl($row['avatar'] ?? '');
              $name = (string) ($row['display_name'] ?? $row['buyer'] ?? '—');
              $alt = sprintf(customLang('alt_avatar_of_user', 'Avatar of %s'), $name);
              $saleType = (string) ($row['type'] ?? 'post');
              $saleTypeLabel = $saleType === 'ebook' ? customLang('ebook_singular_label', 'eBook') : customLang('post', 'Post');
            ?>
            <li class="activity-item">
              <div class="avatar-stack">
                <?php if ($profileUrl !== ''): ?>
                  <a class="avatar-link" href="<?php echo htmlspecialchars($profileUrl, ENT_QUOTES, 'UTF-8'); ?>">
                    <img src="<?php echo htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($alt, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy">
                  </a>
                <?php else: ?>
                  <img src="<?php echo htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($alt, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy">
                <?php endif; ?>
              </div>
              <div class="activity-body">
                <div class="title">
                  <strong><?php echo htmlspecialchars($row['post'], ENT_QUOTES, 'UTF-8'); ?></strong>
                  <span class="status-badge status-badge--neutral"><?php echo htmlspecialchars($saleTypeLabel, ENT_QUOTES, 'UTF-8'); ?></span>
                  <?php if ($profileUrl !== ''): ?>
                    <a class="activity-name" href="<?php echo htmlspecialchars($profileUrl, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?></a>
                  <?php else: ?>
                    <span><?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?></span>
                  <?php endif; ?>
                </div>
                <div class="meta">
                  <strong><?php echo htmlspecialchars($amountDisplay, ENT_QUOTES, 'UTF-8'); ?></strong>
                  <span>· <?php echo htmlspecialchars($dateDisplay, ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
              </div>
            </li>
          <?php endforeach; ?>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</section>
