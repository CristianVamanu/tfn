<?php
if (!isset($loggedIn) || $loggedIn !== '1') {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}

$csrfToken = generateCsrfToken();
$requestsEndpoint = iN_HelpSecure($base_url . 'request/requests.php');
$defaultMethod = isset($defaultPayoutMethod) ? (string) $defaultPayoutMethod : 'none';

$methodData = isset($availablePayoutMethods) && is_array($availablePayoutMethods)
    ? $availablePayoutMethods
    : [];

if (!$methodData) {
    $fallbackDefinitions = [
        'bank' => [
            'label'       => customLang('settings_payout_bank_title', 'Bank transfer'),
            'description' => customLang('settings_payout_bank_desc', 'Receive funds directly to your bank account using the banking details you provided.'),
        ],
        'stripe' => [
            'label'       => customLang('settings_payout_stripe_title', 'Stripe Connect'),
            'description' => customLang('settings_payout_stripe_desc', 'Connect your Stripe account to receive payouts instantly.'),
        ],
        'payoneer' => [
            'label'       => customLang('settings_payout_payoneer_title', 'Payoneer'),
            'description' => customLang('settings_payout_payoneer_desc', 'Link your Payoneer account for cross-border payouts.'),
        ],
        'paypal' => [
            'label'       => 'PayPal',
            'description' => customLang('settings_payout_paypal_desc', 'Accept payouts to your verified PayPal account in supported currencies.'),
        ],
    ];

    $prioritySeed = 1;
    foreach ($fallbackDefinitions as $methodKey => $meta) {
        $methodData[$methodKey] = [
            'label'       => $meta['label'],
            'description' => $meta['description'],
            'connected'   => false,
            'priority'    => $prioritySeed++,
            'status'      => 'none',
            'updated_at'  => null,
            'default'     => false,
            'details'     => [],
        ];
    }
}

$normalizeStatus = static function ($value): string {
    if (!is_string($value) || $value === '') {
        return 'pending';
    }
    $normalized = strtolower(trim($value));
    $allowed = ['pending', 'processing', 'review', 'approved', 'verified', 'rejected', 'failed', 'none'];
    if ($normalized === 'verified') {
        $normalized = 'approved';
    }
    return in_array($normalized, $allowed, true) ? $normalized : 'pending';
};

$statusBadgeMap = [
    'approved'  => 'status-badge--success',
    'pending'   => 'status-badge--pending',
    'processing'=> 'status-badge--pending',
    'review'    => 'status-badge--pending',
    'rejected'  => 'status-badge--danger',
    'failed'    => 'status-badge--danger',
    'none'      => 'status-badge--neutral',
];

$statusLabel = static function (string $status) use ($normalizeStatus): string {
    $normalized = $normalizeStatus($status);
    $fallback = ucfirst(str_replace('_', ' ', $normalized));
    return customLang('settings_payout_status_' . $normalized, $fallback);
};

$lastReviewedLabel = customLang('settings_payout_last_reviewed', 'Last reviewed');
$adminNoteHeading = customLang('settings_payout_admin_note_label', 'Admin note');
$updateRequestedText = customLang('settings_payout_update_requested', 'An admin asked you to update this payout method.');

$formatDate = static function ($value): string {
    if (is_numeric($value)) {
        $timestamp = (int) $value;
        if ($timestamp > 0) {
            return date('d.m.Y H:i', $timestamp);
        }
    }
    return customLang('settings_payout_never_updated', 'Not updated yet');
};

$orderedMethods = $methodData;
uasort($orderedMethods, static function ($a, $b): int {
    $pa = isset($a['priority']) ? (int) $a['priority'] : 999;
    $pb = isset($b['priority']) ? (int) $b['priority'] : 999;
    if ($pa === $pb) { return 0; }
    return ($pa < $pb) ? -1 : 1;
});

$connectedCount = 0;
$totalMethods = count($orderedMethods);
$defaultMethodLabel = customLang('settings_payout_default_none', 'Not selected');
$defaultStatus = 'none';
$defaultStatusUpdatedAt = customLang('settings_payout_never_updated', 'Not updated yet');
foreach ($methodData as $methodKey => $meta) {
    if (!empty($meta['connected'])) {
        $connectedCount++;
    }
    if ($defaultMethod === $methodKey && isset($meta['label'])) {
        $defaultMethodLabel = (string) $meta['label'];
        $defaultStatus = isset($meta['status']) ? $normalizeStatus($meta['status']) : 'pending';
        $defaultStatusUpdatedAt = $formatDate($meta['status_updated_at'] ?? ($meta['updated_at'] ?? null));
    }
}

$methodsSummary = sprintf(
    customLang('settings_payout_methods_summary', 'Connected methods: %s/%s'),
    number_format($connectedCount),
    number_format(max(1, $totalMethods))
);
$defaultStatusBadge = $statusBadgeMap[$defaultStatus] ?? 'status-badge--neutral';

$payoutContextForJs = [
    'default_method' => $defaultMethod,
    'methods'        => [],
    'connected'      => [],
];
foreach ($methodData as $ctxKey => $ctxMeta) {
    if (!is_array($ctxMeta)) {
        continue;
    }
    $detailsPayload = isset($ctxMeta['details']) && is_array($ctxMeta['details']) ? $ctxMeta['details'] : [];
    $detailsPayload['status'] = $ctxMeta['status'] ?? ($detailsPayload['status'] ?? 'pending');
    $detailsPayload['priority'] = isset($ctxMeta['priority']) ? (int) $ctxMeta['priority'] : ($detailsPayload['priority'] ?? 1);
    if (isset($ctxMeta['updated_at'])) {
        $detailsPayload['updated_at'] = $ctxMeta['updated_at'];
    }
    if (isset($ctxMeta['status_updated_at'])) {
        $detailsPayload['status_updated_at'] = $ctxMeta['status_updated_at'];
    }
    if (isset($ctxMeta['admin_note'])) {
        $detailsPayload['admin_note'] = $ctxMeta['admin_note'];
    }
    if (isset($ctxMeta['requires_update'])) {
        $detailsPayload['requires_update'] = $ctxMeta['requires_update'];
    }
    $payoutContextForJs['methods'][$ctxKey] = $detailsPayload;
    $payoutContextForJs['connected'][$ctxKey] = !empty($ctxMeta['connected']);
}
$payoutContextJson = htmlspecialchars(json_encode($payoutContextForJs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8');
?>

<section class="card_admin settings-dashboard settings-dashboard--payouts rounded-2xl" role="region" aria-labelledby="settingsPayoutMethodsHeading">
  <h1 class="h1" id="settingsPayoutMethodsHeading"><?= iN_HelpSecure(customLang('menu_payout_method', 'Payout methods'), false); ?></h1>
  <p class="settings-dashboard-intro"><?= iN_HelpSecure(customLang('settings_payout_methods_intro', 'Connect payout destinations, choose a default method, and manage fallback options.'), false); ?></p>

  <article class="admin-card card payout-summary-card" role="status" data-payout-summary="methods">
    <div class="payout-summary-card__header">
      <span class="payout-summary-card__icon"><?php echo render_icon('payout_methods', true); ?></span>
      <div class="payout-summary-card__meta">
        <span class="payout-summary-card__eyebrow"><?= iN_HelpSecure(customLang('settings_payout_overview', 'Overview'), false); ?></span>
        <span class="payout-summary-card__title" data-payout-summary-connected="true" data-payout-summary-template="<?= iN_HelpSecure(customLang('settings_payout_methods_summary_template', 'Connected methods: {connected}/{total}'), false); ?>"><?= iN_HelpSecure($methodsSummary, false); ?></span>
      </div>
    </div>
    <div class="payout-summary-card__details">
      <div class="payout-summary-card__row">
        <span class="payout-summary-card__label"><?= iN_HelpSecure(customLang('settings_payout_default_label', 'Default method'), false); ?>:</span>
        <span class="payout-summary-card__value" data-payout-default-name="true"><?= iN_HelpSecure($defaultMethodLabel, false); ?></span>
        <span class="status-badge <?= iN_HelpSecure($defaultStatusBadge, false); ?> payout-summary-card__status" data-payout-default-status="true"><?= iN_HelpSecure($statusLabel($defaultStatus), false); ?></span>
      </div>
      <div class="payout-summary-card__row">
        <span class="payout-summary-card__label"><?= iN_HelpSecure($lastReviewedLabel, false); ?>:</span>
        <span class="payout-summary-card__value" data-payout-default-reviewed="true"><?= iN_HelpSecure($defaultStatusUpdatedAt, false); ?></span>
      </div>
      <p class="payout-summary-card__hint"><?= iN_HelpSecure(customLang('settings_payout_summary_hint', 'Update your bank details or creator preferences to change the default payout destination.'), false); ?></p>
    </div>
  </article>

  <form id="payout-methods-form" class="creator-form payout-methods-form" method="post" action="<?= $requestsEndpoint; ?>" data-context="<?= $payoutContextJson; ?>">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
    <input type="hidden" name="p" value="settings_update_payout_methods">

    <div class="payout-methods-hint">
      <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2Zm0 3a1.25 1.25 0 1 1-1.25 1.25A1.25 1.25 0 0 1 12 5Zm1.4 12.5H10.6a.75.75 0 0 1 0-1.5h.85v-4H10.6a.75.75 0 0 1 0-1.5h2.8a.75.75 0 0 1 0 1.5h-.85v4h.85a.75.75 0 0 1 0 1.5Z" /></svg>
      <p><?= iN_HelpSecure(customLang(
        'settings_payout_priority_hint',
        'Set the order in which backup payout methods should be tried. The default method always runs first; lower numbers are attempted earlier.'
      ), false); ?></p>
    </div>

    <?php
      $maxPriority = max(1, count($orderedMethods));
    ?>
    <div class="payout-methods-grid">
    <?php foreach ($orderedMethods as $methodKey => $method): ?>
      <?php
        $label = isset($method['label']) ? (string) $method['label'] : ucfirst((string) $methodKey);
        $desc = isset($method['description']) ? (string) $method['description'] : '';
        $connected = !empty($method['connected']);
        $priority = isset($method['priority']) ? (int) $method['priority'] : 1;
        $status = $normalizeStatus($method['status'] ?? 'pending');
        $updatedAt = $formatDate($method['updated_at'] ?? null);
        $statusUpdatedAt = $formatDate($method['status_updated_at'] ?? ($method['updated_at'] ?? null));
        $statusClass = $statusBadgeMap[$status] ?? 'status-badge--neutral';
        $connectionLabel = $connected
            ? customLang('settings_payout_connected', 'Connected')
            : customLang('settings_payout_not_connected', 'Not connected');
        $connectionClass = $connected ? 'is-connected' : 'is-disconnected';
        $isDefault = !empty($method['default']);
        $adminNote = isset($method['admin_note']) ? trim((string) $method['admin_note']) : '';
        $requiresUpdate = !empty($method['requires_update']);
        $switchId = 'default-method-' . preg_replace('/[^a-z0-9_\-]/i', '_', $methodKey);
      ?>
      <article class="admin-card card payout-method-card" data-method="<?= iN_HelpSecure($methodKey, false); ?>" data-status="<?= iN_HelpSecure($status, false); ?>" data-connected="<?= $connected ? '1' : '0'; ?>">
        <header class="payout-method-card__header">
          <div class="payout-method-card__titles">
            <h2 class="payout-method-card__title"><?= iN_HelpSecure($label, false); ?></h2>
            <?php if ($desc !== ''): ?>
              <p class="payout-method-card__description"><?= iN_HelpSecure($desc, false); ?></p>
            <?php endif; ?>
          </div>
          <div class="payout-method-card__status">
            <span class="payout-method-card__chip" data-payout-default-chip="true" aria-label="<?= iN_HelpSecure(customLang('settings_payout_default_method_chip', 'Default payout method'), false); ?>" <?php echo $isDefault ? '' : 'hidden'; ?>><?= iN_HelpSecure(customLang('settings_payout_default_chip', 'Default'), false); ?></span>
            <span class="status-badge <?= iN_HelpSecure($statusClass, false); ?> payout-method-card__status-badge" data-payout-status="true"><?= iN_HelpSecure($statusLabel($status), false); ?></span>
            <span class="payout-method-card__connection <?= iN_HelpSecure($connectionClass, false); ?>" data-payout-connection="true"><?= iN_HelpSecure($connectionLabel, false); ?></span>
          </div>
        </header>

        <div class="payout-method-card__meta">
          <span class="payout-method-card__meta-item" data-payout-updated="true">
            <strong><?= iN_HelpSecure($lastReviewedLabel, false); ?>:</strong>
            <span data-status-updated-stamp><?= iN_HelpSecure($statusUpdatedAt, false); ?></span>
          </span>
          <label class="creator-input payout-method-card__priority">
            <span><?= iN_HelpSecure(customLang('settings_payout_priority_input', 'Priority order'), false); ?></span>
            <select name="priority[<?= iN_HelpSecure($methodKey, false); ?>]" data-payout-priority="true">
              <?php
                $options = range(1, $maxPriority);
                if (!in_array($priority, $options, true)) {
                    $options[] = $priority;
                }
                foreach ($options as $optionValue):
                    $optionValue = (int) $optionValue;
              ?>
                <option value="<?= $optionValue; ?>"<?php echo $optionValue === (int) $priority ? ' selected' : ''; ?>><?= $optionValue; ?></option>
              <?php endforeach; ?>
            </select>
          </label>
        </div>

        <div class="payout-method-card__note" data-admin-note-container<?= $adminNote === '' ? ' hidden' : ''; ?>>
          <strong><?= iN_HelpSecure($adminNoteHeading, false); ?>:</strong>
          <span data-admin-note><?= iN_HelpSecure($adminNote, false); ?></span>
        </div>

        <div class="payout-method-card__banner" data-update-request<?= $requiresUpdate ? '' : ' hidden'; ?>>
          <?= iN_HelpSecure($updateRequestedText, false); ?>
        </div>

        <div class="payout-method-card__actions">
          <div class="payout-method-card__default">
            <label class="el-switch el-switch-sm el-switch-yellow payout-method-card__switch">
              <input type="radio" id="<?= iN_HelpSecure($switchId, false); ?>" name="default_method" value="<?= iN_HelpSecure($methodKey, false); ?>" data-payout-default-radio="true" <?php echo $isDefault ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
            <label class="payout-method-card__switch-label" for="<?= iN_HelpSecure($switchId, false); ?>"><?= iN_HelpSecure(customLang('settings_payout_default_label', 'Set as default'), false); ?></label>
          </div>
          <div class="payout-method-card__buttons">
            <button type="submit" name="action" value="<?= 'connect:' . iN_HelpSecure($methodKey, false); ?>" class="btn-secondary">
              <?= iN_HelpSecure($connected ? customLang('settings_payout_configure', 'Configure') : customLang('settings_payout_connect', 'Connect'), false); ?>
            </button>
            <?php if ($connected): ?>
              <button type="submit" name="action" value="<?= 'disconnect:' . iN_HelpSecure($methodKey, false); ?>" class="btn-secondary btn-dark" data-confirm="<?= iN_HelpSecure(customLang('settings_payout_disconnect_confirm', 'Are you sure you want to disconnect this payout method?'), false); ?>">
                <?= iN_HelpSecure(customLang('settings_payout_disconnect', 'Disconnect'), false); ?>
              </button>
            <?php endif; ?>
          </div>
          <p class="payout-method-card__inline-message" data-payout-inline-message="true" hidden></p>
        </div>
      </article>
    <?php endforeach; ?>
    </div>

    <div class="creator-form__actions payout-methods-form__actions">
      <button type="submit" name="action" value="save" class="btn-primary"><?= iN_HelpSecure(customLang('save_changes'), false); ?></button>
      <div class="creator-form__alert" role="alert" aria-live="polite"></div>
    </div>
  </form>
</section>
