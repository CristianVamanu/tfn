<?php
if (!isset($loggedIn) || $loggedIn !== '1') {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}

$platformPercent = isset($subscriptionfee) ? (float)$subscriptionfee : 5.0;
$taxPercent = isset($paymentTaxPercent) ? (float)$paymentTaxPercent : 0.0;
if ($platformPercent < 0) { $platformPercent = 0.0; }
if ($taxPercent < 0) { $taxPercent = 0.0; }
if ($platformPercent > 50) { $platformPercent = 50.0; }
if ($taxPercent > 25) { $taxPercent = 25.0; }
$creatorPercent = 100.0 - ($platformPercent + $taxPercent);
if ($creatorPercent < 0) { $creatorPercent = 0.0; }

$currencyCode = isset($currency) ? strtoupper((string)$currency) : 'USD';
$currencyMap  = isset($currencys) && is_array($currencys) ? $currencys : [];
$currencySymbol = isset($currencyMap[$currencyCode]) ? (string)$currencyMap[$currencyCode] : '$';

$calcAmount = isset($_GET['plan_amount']) && is_numeric($_GET['plan_amount']) ? (float)$_GET['plan_amount'] : 9.99;
if ($calcAmount < 1) { $calcAmount = 1.0; }
if ($calcAmount > 1000) { $calcAmount = 1000.0; }

$platformShare = $calcAmount * ($platformPercent / 100);
$taxShare      = $calcAmount * ($taxPercent / 100);
$creatorShare  = max($calcAmount - $platformShare - $taxShare, 0);

$formatMoney = static function($amount) use ($currencySymbol, $currencyCode): string {
    return dz_format_currency(
        (float)$amount,
        $currencyCode,
        $currencySymbol,
        $GLOBALS['currency_format_settings'] ?? null
    );
};

$sectionHeadingId     = 'subscriptionFeesHeading';
$revenueHeadingId     = 'subscriptionFeesRevenueHeading';
$calculatorHeadingId  = 'subscriptionFeesCalculatorHeading';
$resourcesHeadingId   = 'subscriptionFeesResourcesHeading';

$creatorPercentDisplay  = number_format($creatorPercent, 1) . '%';
$platformPercentDisplay = number_format($platformPercent, 1) . '%';
$taxPercentDisplay      = number_format($taxPercent, 1) . '%';

$summaryCards = [
    [
        'id'         => 'subscriptionFeesCreatorSummary',
        'icon'       => 'creator_icon',
        'icon_class' => 'kpi-icon--earnings',
        'title'      => customLang('settings_subscription_fees_creator_share', 'Creator take-home'),
        'value'      => $creatorPercentDisplay,
        'hint'       => sprintf(
            customLang('settings_subscription_fees_creator_summary_hint', 'You currently retain %s from each subscription before personal taxes.'),
            $creatorPercentDisplay
        ),
    ],
    [
        'id'         => 'subscriptionFeesPlatformSummary',
        'icon'       => 'subscription_fees',
        'icon_class' => 'kpi-icon--subscribers',
        'title'      => customLang('settings_subscription_fees_platform_share', 'Platform & maintenance'),
        'value'      => $platformPercentDisplay,
        'hint'       => sprintf(
            customLang('settings_subscription_fees_platform_summary_hint', 'Allocated to infrastructure, moderation, and support (%s).'),
            $platformPercentDisplay
        ),
    ],
    [
        'id'         => 'subscriptionFeesProcessingSummary',
        'icon'       => 'payments',
        'icon_class' => 'kpi-icon--revenue',
        'title'      => customLang('settings_subscription_fees_processing_share', 'Payment processing & tax'),
        'value'      => $taxPercentDisplay,
        'hint'       => $taxPercent > 0
            ? sprintf(
                customLang('settings_subscription_fees_processing_summary_hint', 'Payment partners reserve %s to cover gateway fees and compliance.'),
                $taxPercentDisplay
            )
            : customLang('settings_subscription_fees_processing_summary_hint_none', 'No payment processing or tax deductions are currently configured.'),
    ],
];

$segments = [
    [
        'key'     => 'creator',
        'label'   => customLang('settings_subscription_fees_creator_share', 'Creator take-home'),
        'percent' => $creatorPercent,
        'hint'    => customLang('settings_subscription_fees_creator_share_hint', 'Sent to you before personal income taxes are applied.'),
    ],
    [
        'key'     => 'platform',
        'label'   => customLang('settings_subscription_fees_platform_share', 'Platform & maintenance'),
        'percent' => $platformPercent,
        'hint'    => customLang('settings_subscription_fees_platform_share_hint', 'Supports product development, hosting, and member support.'),
    ],
    [
        'key'     => 'processing',
        'label'   => customLang('settings_subscription_fees_processing_share', 'Payment processing & tax'),
        'percent' => $taxPercent,
        'hint'    => $taxPercent > 0
            ? customLang('settings_subscription_fees_processing_share_hint', 'Reserved by payment processors and tax authorities to stay compliant.')
            : customLang('settings_subscription_fees_processing_share_hint_none', 'Currently no payment processing or tax deductions are taken.'),
    ],
];

$progressClipId    = 'subscriptionFeesClip';
try {
    $progressClipId .= bin2hex(random_bytes(4));
} catch (Throwable $ignored) {
    $progressClipId .= uniqid('', false);
}
$progressViewWidth  = 100.0;
$progressViewHeight = 12.0;
$progressRadius      = $progressViewHeight / 2;

$calculatorResults = [
    [
        'id'         => 'subscriptionFeesResultCreator',
        'key'        => 'creator',
        'icon'       => 'creator_icon',
        'icon_class' => 'kpi-icon--earnings',
        'label'      => customLang('settings_subscription_fees_creator_take', 'Creator keeps'),
        'amount'     => $formatMoney($creatorShare),
        'percent'    => $creatorPercent,
        'hint'       => customLang('settings_subscription_fees_creator_result_hint', 'Estimated payout to you per subscriber at this price.'),
    ],
    [
        'id'         => 'subscriptionFeesResultPlatform',
        'key'        => 'platform',
        'icon'       => 'subscription_fees',
        'icon_class' => 'kpi-icon--subscribers',
        'label'      => customLang('settings_subscription_fees_platform_keeps', 'Platform keeps'),
        'amount'     => $formatMoney($platformShare),
        'percent'    => $platformPercent,
        'hint'       => customLang('settings_subscription_fees_platform_result_hint', 'Helps sustain operations, moderation, and creator programs.'),
    ],
];

$calculatorResults[] = [
    'id'         => 'subscriptionFeesResultProcessing',
    'key'        => 'processing',
    'icon'       => 'payments',
    'icon_class' => 'kpi-icon--revenue',
    'label'      => customLang('settings_subscription_fees_processing', 'Processing & tax'),
    'amount'     => $formatMoney($taxShare),
    'percent'    => $taxPercent,
    'hint'       => $taxPercent > 0
        ? customLang('settings_subscription_fees_processing_result_hint', 'Set aside for gateways, VAT, and sales tax obligations.')
        : customLang('settings_subscription_fees_processing_result_hint_none', 'No processing or tax deductions are currently configured for this price.'),
];

$minimumPayout = isset($minimumWithdrawalAmount) ? (float)$minimumWithdrawalAmount : 0.0;
$minimumPayoutDisplay = $minimumPayout > 0
    ? sprintf(
        customLang('settings_subscription_fees_minimum_withdrawal', 'Minimum withdrawal threshold: %s'),
        $formatMoney($minimumPayout)
    )
    : customLang('settings_subscription_fees_minimum_withdrawal_none', 'No minimum withdrawal threshold is currently enforced.');

$infoLinks = [
    [
        'id'           => 'payouts',
        'icon'         => 'bank',
        'label'        => customLang('settings_subscription_fees_docs', 'View payout documentation'),
        'description'  => customLang('settings_subscription_fees_docs_hint', 'Step-by-step guidance on subscription payouts and timelines.'),
        'modal_title'  => customLang('settings_subscription_fees_payouts_title', 'Payout schedule and eligibility'),
        'modal_intro'  => customLang('settings_subscription_fees_payouts_intro', 'We process creator payouts once cleared earnings cross the minimum threshold and your payout profile is verified.'),
        'modal_points' => [
            customLang('settings_subscription_fees_payouts_point_1', 'Subscription, tip, and pay-per-view payments move into your withdrawable balance as soon as the payment gateway confirms them. Track the totals from the Bank overview.'),
            customLang('settings_subscription_fees_payouts_point_2', 'Update your payout preference under Settings > Payout methods; verified bank or PayPal details are required before transfers can start.'),
            $minimumPayoutDisplay,
            customLang('settings_subscription_fees_payouts_point_4', 'Withdrawal requests are reviewed by the team; check the Bank history for status updates and reference IDs.'),
        ],
    'modal_footer' => customLang('settings_subscription_fees_payouts_footer', 'After you meet the minimum and your payout method is approved, submit a withdrawal request from the Bank tab to start the payout.'),
    ],
    [
        'id'           => 'taxes',
        'icon'         => 'question_icon',
        'label'        => customLang('settings_subscription_fees_tax', 'Understand VAT & sales tax'),
        'description'  => customLang('settings_subscription_fees_tax_hint', 'Learn how regional tax rules affect your take-home earnings.'),
        'modal_title'  => customLang('settings_subscription_fees_taxes_title', 'How we handle platform taxes'),
        'modal_intro'  => customLang('settings_subscription_fees_taxes_intro', 'ReelsProject applies the tax percentage you configure in the admin settings to eligible checkout totals.'),
        'modal_points' => [
            customLang('settings_subscription_fees_taxes_point_1', 'Checkout uses your site-wide tax percentage (Admin > Site settings) when calculating supporter totals.'),
            customLang('settings_subscription_fees_taxes_point_2', 'The "Processing & tax" share shown here combines payment gateway fees with the configured tax amount.'),
            customLang('settings_subscription_fees_taxes_point_3', 'You still report the net income you receive. Export detailed statements from Settings > Payments for bookkeeping.'),
            customLang('settings_subscription_fees_taxes_point_4', 'Keep your identity and tax information up to date under Settings > Creator verification to avoid payout holds.'),
        ],
        'modal_footer' => customLang('settings_subscription_fees_taxes_footer', 'Local regulations change often; we update rates automatically, but you should consult a tax advisor for personal filings.'),
    ],
];
?>

<section class="settings-section preferences-settings card_admin settings-dashboard rounded-2xl" role="region" aria-labelledby="<?php echo $sectionHeadingId; ?>">
  <h1 class="h1" id="<?php echo $sectionHeadingId; ?>"><?php echo customLang('settings_subscription_fees_title', 'Subscription fees'); ?></h1>
  <p class="settings-dashboard-intro"><?php echo customLang('settings_subscription_fees_intro', 'See how each subscription payment is split between the platform, payment processors, and your earnings.'); ?></p>

  <div class="kpi-row">
    <?php foreach ($summaryCards as $card): ?>
      <article class="admin-card card kpi-card" role="group" aria-labelledby="<?php echo $card['id']; ?>">
        <div class="kpi-title" id="<?php echo $card['id']; ?>">
          <span class="kpi-icon <?php echo $card['icon_class']; ?>"><?php echo render_icon($card['icon'], true); ?></span>
          <?php echo iN_HelpSecure($card['title'], false); ?>
        </div>
        <div class="kpi-amount"><?php echo iN_HelpSecure($card['value'], false); ?></div>
        <div class="notice small"><?php echo iN_HelpSecure($card['hint'], false); ?></div>
      </article>
    <?php endforeach; ?>
  </div>

  <div class="kpi-row">
    <article class="admin-card card" role="group" aria-labelledby="<?php echo $revenueHeadingId; ?>">
      <div class="kpi-title" id="<?php echo $revenueHeadingId; ?>">
        <span class="kpi-icon kpi-icon--subscribers"><?php echo render_icon('subscription_fees', true); ?></span>
        <?php echo customLang('settings_subscription_fees_breakdown', 'Revenue split'); ?>
      </div>
      <div class="notice small"><?php echo customLang('settings_subscription_fees_breakdown_hint', 'Percentages are calculated from your current platform settings.'); ?></div>

      <ul class="subscription-fees-segment-list" role="list">
        <?php foreach ($segments as $segment): ?>
          <li class="subscription-fees-segment" role="listitem">
            <div class="subscription-fees-segment__header">
              <span class="subscription-fees-segment__indicator subscription-fees-segment__indicator--<?php echo $segment['key']; ?>" aria-hidden="true"></span>
              <div class="subscription-fees-segment__meta">
                <span class="subscription-fees-segment__title"><?php echo iN_HelpSecure($segment['label'], false); ?></span>
                <span class="subscription-fees-segment__percent"><?php echo number_format($segment['percent'], 1); ?>%</span>
              </div>
            </div>
            <div class="notice small"><?php echo iN_HelpSecure($segment['hint'], false); ?></div>
          </li>
        <?php endforeach; ?>
      </ul>

      <div class="revenue-progress" role="img" aria-label="<?php echo customLang('settings_subscription_fees_breakdown_chart_label', 'Visual breakdown of how each subscription payment is allocated.'); ?>">
        <svg
          class="revenue-progress__chart"
          viewBox="0 0 <?php echo number_format($progressViewWidth, 0, '.', ''); ?> <?php echo number_format($progressViewHeight, 0, '.', ''); ?>"
          role="presentation"
          focusable="false"
          aria-hidden="true"
        >
          <defs>
            <clipPath id="<?php echo htmlspecialchars($progressClipId, ENT_QUOTES, 'UTF-8'); ?>">
              <rect
                x="0"
                y="0"
                width="<?php echo number_format($progressViewWidth, 0, '.', ''); ?>"
                height="<?php echo number_format($progressViewHeight, 0, '.', ''); ?>"
                rx="<?php echo number_format($progressRadius, 2, '.', ''); ?>"
                ry="<?php echo number_format($progressRadius, 2, '.', ''); ?>"
              ></rect>
            </clipPath>
          </defs>
          <rect
            class="revenue-progress__background"
            x="0"
            y="0"
            width="<?php echo number_format($progressViewWidth, 0, '.', ''); ?>"
            height="<?php echo number_format($progressViewHeight, 0, '.', ''); ?>"
            rx="<?php echo number_format($progressRadius, 2, '.', ''); ?>"
            ry="<?php echo number_format($progressRadius, 2, '.', ''); ?>"
          ></rect>
          <g clip-path="url(#<?php echo htmlspecialchars($progressClipId, ENT_QUOTES, 'UTF-8'); ?>)">
            <?php $progressOffset = 0.0; ?>
            <?php foreach ($segments as $segment): ?>
              <?php
                $remaining = $progressViewWidth - $progressOffset;
                $width = max(min($segment['percent'], $remaining), 0.0);
                if ($width <= 0) {
                    continue;
                }
                $x = $progressOffset;
                $progressOffset += $width;
              ?>
              <rect
                class="revenue-progress__segment revenue-progress__segment--<?php echo $segment['key']; ?>"
                x="<?php echo number_format($x, 4, '.', ''); ?>"
                y="0"
                width="<?php echo number_format($width, 4, '.', ''); ?>"
                height="<?php echo number_format($progressViewHeight, 4, '.', ''); ?>"
              ></rect>
            <?php endforeach; ?>
          </g>
        </svg>
      </div>
      <div class="notice small"><?php echo customLang('settings_subscription_fees_breakdown_footer', 'Adjust payout settings to rebalance these allocations.'); ?></div>
    </article>
  </div>

  <div class="kpi-row">
    <article class="admin-card card" role="group" aria-labelledby="<?php echo $calculatorHeadingId; ?>">
      <div class="kpi-title" id="<?php echo $calculatorHeadingId; ?>">
        <span class="kpi-icon kpi-icon--followers"><?php echo render_icon('payments', true); ?></span>
        <?php echo customLang('settings_subscription_fees_calculator', 'Earnings calculator'); ?>
      </div>
      <div class="notice small"><?php echo customLang('settings_subscription_fees_calculator_hint', 'Estimate how much you keep from each subscriber at different price points.'); ?></div>

      <form
        class="creator-form subscription-fees-calculator"
        method="get"
        action="<?php echo iN_HelpSecure($base_url . 'settings'); ?>"
        data-fee-calculator
        data-default-amount="<?php echo htmlspecialchars(number_format($calcAmount, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>"
        data-creator-percent="<?php echo htmlspecialchars(number_format($creatorPercent, 4, '.', ''), ENT_QUOTES, 'UTF-8'); ?>"
        data-platform-percent="<?php echo htmlspecialchars(number_format($platformPercent, 4, '.', ''), ENT_QUOTES, 'UTF-8'); ?>"
        data-tax-percent="<?php echo htmlspecialchars(number_format($taxPercent, 4, '.', ''), ENT_QUOTES, 'UTF-8'); ?>"
        data-currency-symbol="<?php echo htmlspecialchars($currencySymbol, ENT_QUOTES, 'UTF-8'); ?>"
        data-currency-code="<?php echo htmlspecialchars($currencyCode, ENT_QUOTES, 'UTF-8'); ?>"
        data-fee-endpoint="<?php echo iN_HelpSecure($base_url . 'request/requests.php'); ?>"
      >
        <input type="hidden" name="tab" value="subscription_fees">
        <label class="creator-input" for="plan_amount">
          <span><?php echo customLang('settings_subscription_fees_plan_price', 'Plan price'); ?></span>
          <input
            type="text"
            inputmode="decimal"
            step="0.50"
            min="1"
            max="1000"
            id="plan_amount"
            name="plan_amount"
            value="<?php echo htmlspecialchars(number_format($calcAmount, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>"
            data-fee-input
          >
          <span class="creator-form__hint"><?php echo customLang('settings_subscription_fees_plan_hint', 'Enter a price between 1 and 1000 in your payout currency.'); ?></span>
        </label>
        <div class="creator-form__actions">
          <button type="submit" class="btn-primary">
            <?php echo customLang('settings_subscription_fees_recalculate', 'Recalculate'); ?>
          </button>
        </div>
      </form>

      <div class="subscription-fees-calculator__results kpi-row" role="list">
        <?php foreach ($calculatorResults as $result): ?>
          <article class="admin-card card kpi-card subscription-fees-result" role="group" aria-labelledby="<?php echo $result['id']; ?>">
            <div class="kpi-title" id="<?php echo $result['id']; ?>">
              <span class="kpi-icon <?php echo $result['icon_class']; ?>"><?php echo render_icon($result['icon'], true); ?></span>
              <?php echo iN_HelpSecure($result['label'], false); ?>
            </div>
            <div class="kpi-amount" data-fee-output="<?php echo $result['key']; ?>">
              <?php echo iN_HelpSecure($result['amount'], false); ?>
            </div>
            <div class="kpi-period" data-fee-percent="<?php echo $result['key']; ?>"><?php echo number_format($result['percent'], 1); ?>%</div>
            <div class="notice small"><?php echo iN_HelpSecure($result['hint'], false); ?></div>
          </article>
        <?php endforeach; ?>
      </div>
    </article>
  </div>

  <div class="kpi-row">
    <article class="admin-card card" role="group" aria-labelledby="<?php echo $resourcesHeadingId; ?>">
      <div class="kpi-title" id="<?php echo $resourcesHeadingId; ?>">
        <span class="kpi-icon kpi-icon--supporters"><?php echo render_icon('question_icon', true); ?></span>
        <?php echo customLang('settings_subscription_fees_resources', 'Resources'); ?>
      </div>
      <div class="notice small"><?php echo customLang('settings_subscription_fees_resources_intro', 'Guides to help you price plans and understand how fees work.'); ?></div>
      <div class="notice small"><?php echo customLang('settings_subscription_fees_resources_hint', 'Select a resource to open an in-product guide without leaving this page.'); ?></div>

      <ul class="subscription-fees-resources" role="list">
        <?php foreach ($infoLinks as $item): ?>
          <li class="subscription-fees-resources__item" role="listitem">
            <a
              class="btn-link subscription-fees-resource__trigger"
              href="#fee-resource-<?php echo htmlspecialchars($item['id'], ENT_QUOTES, 'UTF-8'); ?>"
              data-fee-resource-trigger
              data-target="fee-resource-<?php echo htmlspecialchars($item['id'], ENT_QUOTES, 'UTF-8'); ?>"
              aria-haspopup="dialog"
              aria-expanded="false"
              aria-controls="fee-resource-<?php echo htmlspecialchars($item['id'], ENT_QUOTES, 'UTF-8'); ?>"
            >
              <?php echo iN_HelpSecure($item['label'], false); ?>
            </a>
            <?php if (!empty($item['description'])): ?>
              <div class="notice small"><?php echo iN_HelpSecure($item['description'], false); ?></div>
            <?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>

      <?php foreach ($infoLinks as $item): ?>
        <?php
          $dialogId = 'fee-resource-' . $item['id'];
          $titleId = $dialogId . '-title';
        ?>
        <section
          class="fee-resource-modal"
          id="<?php echo htmlspecialchars($dialogId, ENT_QUOTES, 'UTF-8'); ?>"
          role="dialog"
          aria-labelledby="<?php echo htmlspecialchars($titleId, ENT_QUOTES, 'UTF-8'); ?>"
          data-fee-resource-modal
        >
          <a
            class="fee-resource-modal__overlay"
            href="#<?php echo htmlspecialchars($resourcesHeadingId, ENT_QUOTES, 'UTF-8'); ?>"
            data-fee-resource-close
          ></a>
          <div class="fee-resource-modal__dialog" role="document">
            <div class="fee-resource-modal__header">
              <header>
                <span class="fee-resource-modal__icon"><?php echo render_icon($item['icon'], true); ?></span>
                <h2 class="fee-resource-modal__title" id="<?php echo htmlspecialchars($titleId, ENT_QUOTES, 'UTF-8'); ?>">
                  <?php echo iN_HelpSecure($item['modal_title'], false); ?>
                </h2>
                <a
                  class="fee-resource-modal__close btn-icon"
                  aria-label="<?php echo customLang('close'); ?>"
                  href="#<?php echo htmlspecialchars($resourcesHeadingId, ENT_QUOTES, 'UTF-8'); ?>"
                  data-fee-resource-close
                >
                  <?php echo render_icon('close', true); ?>
                </a>
              </header>
            </div>
            <div class="fee-resource-modal__body">
              <p class="fee-resource-modal__intro">
                <?php echo iN_HelpSecure($item['modal_intro'], false); ?>
              </p>
              <?php if (!empty($item['modal_points']) && is_array($item['modal_points'])): ?>
                <ul class="fee-resource-modal__list">
                  <?php foreach ($item['modal_points'] as $point): ?>
                    <li><?php echo iN_HelpSecure($point, false); ?></li>
                  <?php endforeach; ?>
                </ul>
              <?php endif; ?>
              <?php if (!empty($item['modal_footer'])): ?>
                <p class="fee-resource-modal__footer">
                  <?php echo iN_HelpSecure($item['modal_footer'], false); ?>
                </p>
              <?php endif; ?>
            </div>
          </div>
        </section>
      <?php endforeach; ?>
    </article>
  </div>
</section>
