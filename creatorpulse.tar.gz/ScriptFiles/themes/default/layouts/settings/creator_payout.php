<?php
if (!isset($loggedIn) || $loggedIn !== '1' || !isset($userData)) {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}

$csrfToken = generateCsrfToken();
$methodsMap = isset($creatorPayout['details']) && is_array($creatorPayout['details']) ? $creatorPayout['details'] : [];
$availableMethodsData = isset($availablePayoutMethods) && is_array($availablePayoutMethods) ? $availablePayoutMethods : [];

$methodOptions = [
    'none'     => customLang('creator_payout_none', 'Not set'),
    'bank'     => customLang('creator_payout_bank', 'Bank transfer'),
    'paypal'   => 'PayPal',
    'stripe'   => customLang('creator_payout_stripe', 'Stripe Connect'),
    'payoneer' => customLang('creator_payout_payoneer', 'Payoneer'),
    'other'    => customLang('creator_payout_other', 'Other (manual)')
];

$normalizeStatus = static function ($value) {
    if (!is_string($value) || $value === '') {
        return 'pending';
    }
    $normalized = strtolower(trim($value));
    if ($normalized === 'verified') {
        $normalized = 'approved';
    }
    $allowed = ['pending', 'processing', 'review', 'approved', 'rejected', 'failed', 'none'];
    return in_array($normalized, $allowed, true) ? $normalized : 'pending';
};

$statusBadgeMap = [
    'approved'  => 'status-badge--success',
    'pending'   => 'status-badge--pending',
    'processing'=> 'status-badge--pending',
    'review'    => 'status-badge--pending',
    'rejected'  => 'status-badge--danger',
    'failed'    => 'status-badge--danger',
    'none'      => 'status-badge--neutral',
];

$statusLabel = static function (string $status) use ($normalizeStatus) {
    $normalized = $normalizeStatus($status);
    $fallback = ucfirst(str_replace('_', ' ', $normalized));
    return customLang('settings_payout_status_' . $normalized, $fallback);
};

$formatDate = static function ($value): string {
    if (is_numeric($value)) {
        $timestamp = (int) $value;
        if ($timestamp > 0) {
            return date('d.m.Y H:i', $timestamp);
        }
    }
    return customLang('settings_payout_never_updated', 'Not updated yet');
};

$selectedMethod = isset($creatorPayout['method']) ? (string) $creatorPayout['method'] : 'none';
if (!array_key_exists($selectedMethod, $methodOptions)) {
    $selectedMethod = 'none';
}
$selectedDetails = isset($methodsMap[$selectedMethod]) && is_array($methodsMap[$selectedMethod]) ? $methodsMap[$selectedMethod] : [];
$selectedStatus = $selectedMethod === 'none' ? 'none' : $normalizeStatus($selectedDetails['status'] ?? 'pending');
$selectedBadgeClass = $statusBadgeMap[$selectedStatus] ?? 'status-badge--neutral';
$selectedUpdatedAt = $selectedDetails ? $formatDate($selectedDetails['status_updated_at'] ?? ($selectedDetails['updated_at'] ?? null)) : customLang('settings_payout_never_updated', 'Not updated yet');
$selectedMethodLabel = $methodOptions[$selectedMethod] ?? customLang('creator_payout_none', 'Not set');
$selectedConnected = isset($availableMethodsData[$selectedMethod]['connected'])
    ? (bool) $availableMethodsData[$selectedMethod]['connected']
    : (!empty($selectedDetails));
$connectionLabel = $selectedConnected
    ? customLang('settings_payout_connected', 'Connected')
    : customLang('settings_payout_not_connected', 'Not connected');
$connectionClass = $selectedConnected ? 'is-connected' : 'is-disconnected';
$selectedAdminNote = $selectedDetails ? trim((string) ($selectedDetails['admin_note'] ?? '')) : '';
$selectedRequiresUpdate = $selectedDetails ? !empty($selectedDetails['requires_update']) : false;
$selectedPendingReview = $selectedMethod !== 'none' && isset($selectedDetails['status']) && in_array($selectedStatus, ['pending', 'processing', 'review'], true);
$pendingReviewTemplate = customLang(
    'creator_payout_pending_review',
    'Your {method} payout method was submitted for approval. Please wait until it is reviewed.'
);
$pendingReviewMessage = str_replace('{method}', $selectedMethodLabel, $pendingReviewTemplate);
$creatorAdminNoteTitle = customLang('creator_payout_admin_note_title', 'Admin note');
$creatorUpdateRequested = customLang('creator_payout_update_requested', 'An admin asked you to update this payout method.');
$creatorLastReviewedLabel = customLang('settings_payout_last_reviewed', 'Last reviewed');

$getField = static function (array $methods, string $methodKey, $fieldKeys, string $fallback = ''): string {
    if (!isset($methods[$methodKey]) || !is_array($methods[$methodKey])) {
        return $fallback;
    }
    $fieldKeys = (array) $fieldKeys;
    foreach ($fieldKeys as $key) {
        if (!array_key_exists($key, $methods[$methodKey])) {
            continue;
        }
        $value = $methods[$methodKey][$key];
        if ($value === null) {
            continue;
        }
        $stringValue = is_scalar($value) ? (string) $value : '';
        if ($stringValue !== '') {
            return $stringValue;
        }
    }
    return $fallback;
};

$bankAccountName = $getField($methodsMap, 'bank', 'account_name');
$bankName = $getField($methodsMap, 'bank', 'bank_name');
$bankIban = $getField($methodsMap, 'bank', 'iban');
$bankAccountNumber = $getField($methodsMap, 'bank', 'account_number');
$bankSwift = $getField($methodsMap, 'bank', 'swift');
$bankNotes = $getField($methodsMap, 'bank', ['notes', 'bank_notes']);

$paypalEmail = $getField($methodsMap, 'paypal', ['email', 'paypal_email']);
$stripeAccountId = $getField($methodsMap, 'stripe', 'account_id');
$stripeEmail = $getField($methodsMap, 'stripe', 'email');
$payoneerEmail = $getField($methodsMap, 'payoneer', ['email', 'payoneer_email']);
$otherNotes = $getField($methodsMap, 'other', ['notes', 'payout_notes']);
$formMethodsJson = htmlspecialchars(json_encode($methodsMap, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8');
?>

<section class="card_admin settings-dashboard settings-dashboard--payouts rounded-2xl" role="region" aria-labelledby="creatorPayoutHeading">
  <h1 class="h1" id="creatorPayoutHeading"><?= iN_HelpSecure(customLang('creator_payout_title', 'Payout preferences'), false); ?></h1>
  <p class="settings-dashboard-intro"><?= iN_HelpSecure(customLang('creator_payout_intro', 'Choose how you would like to receive withdrawals from your earnings. Provide accurate information—administrators will send payouts to this destination.'), false); ?></p>

  <article class="admin-card card payout-summary-card payout-summary-card--preferences" role="status" data-payout-summary="creator">
    <div class="payout-summary-card__header">
      <span class="payout-summary-card__icon"><?php echo render_icon('bank', true); ?></span>
      <div class="payout-summary-card__meta">
        <span class="payout-summary-card__eyebrow"><?= iN_HelpSecure(customLang('settings_payout_overview', 'Overview'), false); ?></span>
        <span class="payout-summary-card__title" data-payout-method-label="true"><?= iN_HelpSecure($selectedMethodLabel, false); ?></span>
      </div>
    </div>
    <div class="payout-summary-card__details">
      <div class="payout-summary-card__row">
        <span class="payout-summary-card__label"><?= iN_HelpSecure(customLang('creator_payout_status_label', 'Status'), false); ?>:</span>
        <span class="status-badge <?= iN_HelpSecure($selectedBadgeClass, false); ?> payout-summary-card__status" data-payout-status="true"><?= iN_HelpSecure($statusLabel($selectedStatus), false); ?></span>
        <span class="payout-summary-card__connection <?= iN_HelpSecure($connectionClass, false); ?>" data-payout-connection="true"><?= iN_HelpSecure($connectionLabel, false); ?></span>
      </div>
      <div class="payout-summary-card__row">
        <span class="payout-summary-card__label"><?= iN_HelpSecure($creatorLastReviewedLabel, false); ?>:</span>
        <span class="payout-summary-card__value" data-status-updated-stamp><?= iN_HelpSecure($selectedUpdatedAt, false); ?></span>
      </div>
      <div class="payout-method-card__note payout-summary-card__note" data-payout-admin-note-container<?= $selectedAdminNote === '' ? ' hidden' : ''; ?>>
        <strong><?= iN_HelpSecure($creatorAdminNoteTitle, false); ?>:</strong>
        <span data-payout-admin-note><?= iN_HelpSecure($selectedAdminNote, false); ?></span>
      </div>
      <div class="payout-method-card__banner payout-summary-card__banner payout-summary-card__banner--pending" data-payout-review-banner<?= $selectedPendingReview ? '' : ' hidden'; ?> data-payout-review-template="<?= iN_HelpSecure($pendingReviewTemplate, false); ?>">
        <?= iN_HelpSecure($pendingReviewMessage, false); ?>
      </div>
      <div class="payout-method-card__banner payout-summary-card__banner" data-payout-update-banner<?= $selectedRequiresUpdate ? '' : ' hidden'; ?>>
        <?= iN_HelpSecure($creatorUpdateRequested, false); ?>
      </div>
      <p class="payout-summary-card__hint"><?= iN_HelpSecure(customLang('creator_payout_summary_hint', 'Save your preferred payout method below. We use the same details across the withdrawals dashboard.'), false); ?></p>
    </div>
  </article>

  <article class="admin-card card payout-preferences-card">
    <form id="creator-payout-form" class="creator-form payout-preferences-form" method="post" action="<?= iN_HelpSecure($base_url . 'request/requests.php'); ?>" novalidate data-selected-method="<?= iN_HelpSecure($selectedMethod, false); ?>" data-methods="<?= $formMethodsJson; ?>">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
      <input type="hidden" name="p" value="creator_payout_update">

      <label class="creator-input payout-preferences-form__selector">
        <span><?= iN_HelpSecure(customLang('creator_payout_method', 'Select payout method'), false); ?></span>
        <select name="payout_method" id="creator-payout-method" data-current-method="<?= htmlspecialchars($selectedMethod, ENT_QUOTES, 'UTF-8'); ?>">
          <?php foreach ($methodOptions as $value => $label): ?>
            <option value="<?= iN_HelpSecure($value, false); ?>"<?php echo $selectedMethod === $value ? ' selected' : ''; ?>><?= iN_HelpSecure($label, false); ?></option>
          <?php endforeach; ?>
        </select>
      </label>

      <div class="payout-preferences-form__groups">
        <div class="payout-method-fields creator-payout-group" data-method="bank"<?php echo $selectedMethod === 'bank' ? '' : ' hidden'; ?>>
          <div class="payout-method-fields__intro">
            <h2><?= iN_HelpSecure(customLang('creator_bank_section_title', 'Bank account details'), false); ?></h2>
            <p><?= iN_HelpSecure(customLang('creator_bank_section_hint', 'These details sync with the Bank tab and must match your verified account.'), false); ?></p>
          </div>
          <div class="payout-form-grid">
            <label class="creator-input">
              <span><?= iN_HelpSecure(customLang('creator_bank_account_name', 'Account holder name'), false); ?></span>
              <input type="text" name="account_name" value="<?= htmlspecialchars($bankAccountName, ENT_QUOTES, 'UTF-8'); ?>" autocomplete="name">
            </label>
            <label class="creator-input">
              <span><?= iN_HelpSecure(customLang('creator_bank_name', 'Bank name'), false); ?></span>
              <input type="text" name="bank_name" value="<?= htmlspecialchars($bankName, ENT_QUOTES, 'UTF-8'); ?>">
            </label>
            <label class="creator-input">
              <span><?= iN_HelpSecure(customLang('creator_bank_iban', 'IBAN (preferred)'), false); ?></span>
              <input type="text" name="iban" value="<?= htmlspecialchars($bankIban, ENT_QUOTES, 'UTF-8'); ?>" placeholder="TR00 0000 0000 0000 0000 0000">
            </label>
            <label class="creator-input">
              <span><?= iN_HelpSecure(customLang('creator_bank_account_number', 'Account number (if no IBAN)'), false); ?></span>
              <input type="text" name="account_number" value="<?= htmlspecialchars($bankAccountNumber, ENT_QUOTES, 'UTF-8'); ?>">
            </label>
            <label class="creator-input">
              <span><?= iN_HelpSecure(customLang('creator_bank_swift', 'SWIFT/BIC (optional)'), false); ?></span>
              <input type="text" name="swift" value="<?= htmlspecialchars($bankSwift, ENT_QUOTES, 'UTF-8'); ?>">
            </label>
            <label class="creator-input creator-input--textarea payout-method-fields__textarea">
              <span><?= iN_HelpSecure(customLang('creator_bank_notes', 'Additional instructions'), false); ?></span>
              <textarea name="bank_notes" rows="3" placeholder="<?= iN_HelpSecure(customLang('creator_bank_notes_hint', 'Include branch, routing, or any instruction for payouts.'), false); ?>"><?= htmlspecialchars($bankNotes, ENT_QUOTES, 'UTF-8'); ?></textarea>
            </label>
          </div>
        </div>

        <div class="payout-method-fields creator-payout-group" data-method="paypal"<?php echo $selectedMethod === 'paypal' ? '' : ' hidden'; ?>>
          <div class="payout-method-fields__intro">
            <h2><?= iN_HelpSecure(customLang('creator_paypal_section_title', 'PayPal details'), false); ?></h2>
            <p><?= iN_HelpSecure(customLang('creator_paypal_section_hint', 'Use the email tied to your PayPal account. We use it across payout screens.'), false); ?></p>
          </div>
          <label class="creator-input">
            <span><?= iN_HelpSecure(customLang('creator_paypal_email', 'PayPal email'), false); ?></span>
            <input type="email" name="paypal_email" value="<?= htmlspecialchars($paypalEmail, ENT_QUOTES, 'UTF-8'); ?>" autocomplete="email">
          </label>
          <p class="creator-form__hint"><?= iN_HelpSecure(customLang('creator_paypal_hint', 'Ensure this PayPal account can receive payments in your selected currency.'), false); ?></p>
        </div>

        <div class="payout-method-fields creator-payout-group" data-method="stripe"<?php echo $selectedMethod === 'stripe' ? '' : ' hidden'; ?>>
          <div class="payout-method-fields__intro">
            <h2><?= iN_HelpSecure(customLang('creator_stripe_section_title', 'Stripe Connect'), false); ?></h2>
            <p><?= iN_HelpSecure(customLang('creator_stripe_section_hint', 'We send payouts to your connected Stripe account via this ID.'), false); ?></p>
          </div>
          <label class="creator-input">
            <span><?= iN_HelpSecure(customLang('creator_stripe_account_id', 'Stripe account ID'), false); ?></span>
            <input type="text" name="stripe_account_id" value="<?= htmlspecialchars($stripeAccountId, ENT_QUOTES, 'UTF-8'); ?>" placeholder="acct_123ABC...">
          </label>
          <label class="creator-input">
            <span><?= iN_HelpSecure(customLang('creator_stripe_email', 'Stripe email (optional)'), false); ?></span>
            <input type="email" name="stripe_email" value="<?= htmlspecialchars($stripeEmail, ENT_QUOTES, 'UTF-8'); ?>" autocomplete="email">
          </label>
          <p class="creator-form__hint"><?= iN_HelpSecure(customLang('creator_stripe_hint', 'Find your account ID in the Stripe dashboard. We use it to send payouts to your connected account.'), false); ?></p>
        </div>

        <div class="payout-method-fields creator-payout-group" data-method="payoneer"<?php echo $selectedMethod === 'payoneer' ? '' : ' hidden'; ?>>
          <div class="payout-method-fields__intro">
            <h2><?= iN_HelpSecure(customLang('creator_payoneer_section_title', 'Payoneer account'), false); ?></h2>
            <p><?= iN_HelpSecure(customLang('creator_payoneer_section_hint', 'Use the email linked to your Payoneer account.'), false); ?></p>
          </div>
          <label class="creator-input">
            <span><?= iN_HelpSecure(customLang('creator_payoneer_email', 'Payoneer email'), false); ?></span>
            <input type="email" name="payoneer_email" value="<?= htmlspecialchars($payoneerEmail, ENT_QUOTES, 'UTF-8'); ?>" autocomplete="email">
          </label>
          <p class="creator-form__hint"><?= iN_HelpSecure(customLang('creator_payoneer_hint', 'Use the email associated with your Payoneer account. Payouts will be initiated there.'), false); ?></p>
        </div>

        <div class="payout-method-fields creator-payout-group" data-method="other"<?php echo $selectedMethod === 'other' ? '' : ' hidden'; ?>>
          <div class="payout-method-fields__intro">
            <h2><?= iN_HelpSecure(customLang('creator_other_section_title', 'Manual payout instructions'), false); ?></h2>
            <p><?= iN_HelpSecure(customLang('creator_other_section_hint', 'Share bank or transfer details so admins can process payouts.'), false); ?></p>
          </div>
          <label class="creator-input creator-input--textarea payout-method-fields__textarea">
            <span><?= iN_HelpSecure(customLang('creator_other_notes', 'Describe your payout instructions'), false); ?></span>
            <textarea name="payout_notes" rows="3" placeholder="<?= iN_HelpSecure(customLang('creator_other_hint', 'Example: Send to Wise account, include my username.'), false); ?>"><?= htmlspecialchars($otherNotes, ENT_QUOTES, 'UTF-8'); ?></textarea>
          </label>
        </div>
      </div>

      <div class="creator-form__actions payout-preferences-form__actions">
        <button type="submit" class="btn-primary"><?= iN_HelpSecure(customLang('save_changes'), false); ?></button>
        <div class="creator-form__alert" role="alert" aria-live="polite"></div>
      </div>
    </form>
  </article>
</section>
