<?php
if (!isset($loggedIn) || $loggedIn !== '1') {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}

$csrfToken = generateCsrfToken();
$requestsEndpoint = iN_HelpSecure($base_url . 'request/requests.php');
$userPrefs = isset($userPreferences) && is_array($userPreferences) ? $userPreferences : [];

$feedAutoplay   = !empty($userPrefs['feed_autoplay']);
$feedMuted      = !empty($userPrefs['feed_muted']);
$pushEnabled    = !empty($userPrefs['notify_push']);
$emailEnabled   = !empty($userPrefs['notify_email']);
$smsEnabled     = !empty($userPrefs['notify_sms']);

$currentLanguage = isset($userPrefs['language']) ? (string)$userPrefs['language'] : ($currentLang ?? 'eng');
$currentTheme    = isset($userPrefs['theme']) ? (string)$userPrefs['theme'] : ($currentTheme ?? 'default');

$rootDir  = dirname(__DIR__, 4);
$langDir  = $rootDir . '/langs';

$langOptions = [];
if (is_dir($langDir)) {
    foreach (scandir($langDir) as $entry) {
        if ($entry === '.' || $entry === '..') { continue; }
        if (preg_match('/^(\w+)\.php$/', $entry, $m)) {
            $langOptions[] = $m[1];
        }
    }
}
sort($langOptions, SORT_NATURAL);
if (!in_array($currentLanguage, $langOptions, true) && $langOptions) {
    $currentLanguage = $langOptions[0];
}

$currentLanguageLabel = strtoupper($currentLanguage);
$currentThemeLabel = ucwords(str_replace('_', ' ', $currentTheme));
?>

<section class="settings-section preferences-settings card_admin settings-dashboard rounded-2xl" role="region" aria-labelledby="settingsPreferencesHeading">
  <h1 class="h1" id="settingsPreferencesHeading"><?php echo customLang('settings_preferences_title', 'Experience preferences'); ?></h1>
  <p class="settings-dashboard-intro"><?php echo customLang('settings_preferences_intro', 'Fine-tune how you consume content, receive notifications, and localize your experience.'); ?></p>

  <form id="settings-preferences-form" class="creator-form" method="post" action="<?php echo $requestsEndpoint; ?>">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
    <input type="hidden" name="p" value="settings_update_preferences">
    <div class="kpi-row">
      <article class="admin-card card" role="group" aria-labelledby="preferencesPlaybackHeading">
        <div class="kpi-title" id="preferencesPlaybackHeading">
          <span class="kpi-icon kpi-icon--followers"><?php echo render_icon('video', true); ?></span>
          <?php echo customLang('settings_preferences_playback', 'Feed playback'); ?>
        </div>
        <div class="notice small"><?php echo customLang('settings_preferences_playback_intro', 'Control autoplay behavior and audio defaults as you scroll through your feed.'); ?></div>
        <div class="creator-grid-pref">
          <div class="creator-input">
            <div class="flex align_items space_between">
              <span><?php echo customLang('settings_preferences_autoplay', 'Autoplay videos in feed'); ?></span>
              <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('settings_preferences_autoplay_toggle', 'Toggle autoplay in feed'), false); ?>">
                <input type="checkbox" name="feed_autoplay" value="1" <?php echo $feedAutoplay ? 'checked' : ''; ?>>
                <span class="el-switch-style"></span>
              </label>
            </div>
            <div class="notice small"><?php echo customLang('settings_preferences_autoplay_hint', 'Videos start playing automatically when they enter view.'); ?></div>
          </div>
          <div class="creator-input">
            <div class="flex align_items space_between">
              <span><?php echo customLang('settings_preferences_autoplay_muted', 'Start autoplayed videos muted'); ?></span>
              <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('settings_preferences_autoplay_muted_toggle', 'Toggle mute for autoplay'), false); ?>">
                <input type="checkbox" name="feed_muted" value="1" <?php echo $feedMuted ? 'checked' : ''; ?>>
                <span class="el-switch-style"></span>
              </label>
            </div>
            <div class="notice small"><?php echo customLang('settings_preferences_autoplay_muted_hint', 'Start silent to avoid unexpected audio; tap to unmute anytime.'); ?></div>
          </div>
        </div>
      </article>
    </div>

    <div class="kpi-row">
      <article class="admin-card card" role="group" aria-labelledby="preferencesNotificationsHeading">
        <div class="kpi-title" id="preferencesNotificationsHeading">
          <span class="kpi-icon kpi-icon--earnings"><?php echo render_icon('notification', true); ?></span>
          <?php echo customLang('settings_preferences_notifications', 'Notification channels'); ?>
        </div>
        <div class="notice small"><?php echo customLang('settings_preferences_notifications_intro', 'Choose how you are alerted about activity and updates.'); ?></div>
        <div class="creator-grid-pref">
          <div class="creator-input">
            <div class="flex align_items space_between">
              <span><?php echo customLang('settings_preferences_push', 'Push notifications'); ?></span>
              <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('settings_preferences_push_toggle', 'Toggle push notifications'), false); ?>">
                <input type="checkbox" name="notify_push" value="1" <?php echo $pushEnabled ? 'checked' : ''; ?>>
                <span class="el-switch-style"></span>
              </label>
            </div>
            <div class="notice small"><?php echo customLang('settings_preferences_push_hint', 'Heads-up alerts on supported devices for time-sensitive activity.'); ?></div>
          </div>
          <div class="creator-input">
            <div class="flex align_items space_between">
              <span><?php echo customLang('settings_preferences_email', 'Email notifications'); ?></span>
              <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('settings_preferences_email_toggle', 'Toggle email notifications'), false); ?>">
                <input type="checkbox" name="notify_email" value="1" <?php echo $emailEnabled ? 'checked' : ''; ?>>
                <span class="el-switch-style"></span>
              </label>
            </div>
            <div class="notice small"><?php echo customLang('settings_preferences_email_hint', 'Summaries and receipts delivered to your account email.'); ?></div>
          </div>
          <div class="creator-input">
            <div class="flex align_items space_between">
              <span><?php echo customLang('settings_preferences_sms', 'SMS notifications'); ?></span>
              <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('settings_preferences_sms_toggle', 'Toggle SMS notifications'), false); ?>">
                <input type="checkbox" name="notify_sms" value="1" <?php echo $smsEnabled ? 'checked' : ''; ?>>
                <span class="el-switch-style"></span>
              </label>
            </div>
            <div class="notice small"><?php echo customLang('settings_preferences_sms_hint', 'Requires a verified mobile number; carrier rates may apply.'); ?></div>
          </div>
        </div>
        <div class="notice small"><?php echo customLang('settings_preferences_notifications_hint', 'Push alerts appear on supported devices. Email alerts go to your account email. SMS alerts require a saved phone number with country code.'); ?></div>
      </article>

      <article class="admin-card card" role="group" aria-labelledby="preferencesLocalizationHeading">
        <div class="kpi-title" id="preferencesLocalizationHeading">
          <span class="kpi-icon kpi-icon--revenue"><?php echo render_icon('creator_icon', true); ?></span>
          <?php echo customLang('settings_preferences_localization', 'Language preferences'); ?>
        </div>
        <div class="notice small"><?php echo customLang('settings_preferences_localization_intro', 'Update the interface language that appears across the product.'); ?></div>
        <div class="creator-grid-pref">
          <label class="creator-input" for="preferences_language">
            <span><?php echo customLang('settings_preferences_language', 'Language'); ?></span>
            <select id="preferences_language" name="language">
              <?php foreach ($langOptions as $code): ?>
                <option value="<?php echo iN_HelpSecure($code, false); ?>" <?php echo $code === $currentLanguage ? 'selected' : ''; ?>><?php echo iN_HelpSecure(strtoupper($code), false); ?></option>
              <?php endforeach; ?>
            </select>
            <div class="notice small"><?php echo customLang('settings_preferences_language_hint', 'Applies language changes to menus, buttons, and messages.'); ?></div>
          </label>
        </div>
        <div class="notice small"><?php echo customLang('settings_preferences_theme_admin_hint', 'Themes are managed by administrators and applied globally.'); ?></div>
      </article>
    </div>

    <div class="creator-form__actions">
      <button type="submit" class="btn-primary"><?php echo customLang('save_changes'); ?></button>
      <div class="creator-form__alert" role="alert" aria-live="polite"></div>
    </div>
  </form>
</section>
