<?php
if (!isset($loggedIn) || $loggedIn !== '1') {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}

$csrfToken = generateCsrfToken();
$requestsEndpoint = iN_HelpSecure($base_url . 'request/requests.php');
$currencyCode = isset($currency) ? strtoupper((string)$currency) : 'USD';
$currencyMap  = isset($currencys) && is_array($currencys) ? $currencys : [];
$currencySymbol = isset($currencyMap[$currencyCode]) ? (string)$currencyMap[$currencyCode] : '$';

$formatMoney = static function($amount) use ($currencySymbol, $currencyCode): string {
    return dz_format_currency(
        (float)$amount,
        $currencyCode,
        $currencySymbol,
        $GLOBALS['currency_format_settings'] ?? null
    );
};

$formatDate = static function($value): string {
    if (is_numeric($value)) {
        $timestamp = (int)$value;
        if ($timestamp > 0) {
            return date('d.m.Y H:i', $timestamp);
        }
    } elseif ($value instanceof DateTimeInterface) {
        return $value->format('d.m.Y H:i');
    } elseif (is_string($value) && trim($value) !== '') {
        return $value;
    }
    return customLang('settings_super_thanks_unknown_time');
};

$tipSummary = isset($tipsSummary) && is_array($tipsSummary) ? $tipsSummary : [
    'total'      => 0,
    'this_month' => 0,
    'this_week'  => 0,
];

$pendingPayouts = isset($tipsPending) && is_array($tipsPending) ? $tipsPending : [];
$tipHistory = isset($tipsHistory) && is_array($tipsHistory) ? $tipsHistory : [];

$filterRange = isset($_GET['tips_range']) ? (string)$_GET['tips_range'] : 'month';
$filterType  = isset($_GET['tips_type']) ? (string)$_GET['tips_type'] : 'all';
$filterOptions = [
    'week'  => customLang('settings_super_thanks_filter_week'),
    'month' => customLang('settings_super_thanks_filter_month'),
    'year'  => customLang('settings_super_thanks_filter_year'),
    'all'   => customLang('settings_super_thanks_filter_all'),
];
$typeOptions = [
    'all'      => customLang('settings_super_thanks_type_all'),
    'super'    => customLang('settings_super_thanks_type_super'),
    'live'     => customLang('settings_super_thanks_type_live'),
    'offline'  => customLang('settings_super_thanks_type_offline'),
];

$earningsSortMap = [
    'date'   => 'created_at',
    'amount' => 'gross_amount',
    'net'    => 'net_amount',
    'status' => 'status',
    'type'   => 'source_type',
];

$earningsSort = isset($_GET['earnings_sort']) ? strtolower(preg_replace('~[^a-z_]~', '', (string) $_GET['earnings_sort'])) : 'date';
if (!array_key_exists($earningsSort, $earningsSortMap)) {
    $earningsSort = 'date';
}

$earningsDir = isset($_GET['earnings_dir']) && strtolower((string) $_GET['earnings_dir']) === 'asc' ? 'asc' : 'desc';
$earningsPerPage = isset($_GET['earnings_per']) ? (int) $_GET['earnings_per'] : 20;
$earningsPerPage = max(5, min(50, $earningsPerPage));
$earningsPage = isset($_GET['page_no']) ? (int) $_GET['page_no'] : 1;
if ($earningsPage < 1) {
    $earningsPage = 1;
}

$earningsRows = [];
$earningsTotal = 0;
$earningsPages = 1;
$earningsChart = [
    'labels'  => [],
    'weekly'  => [],
    'monthly' => [],
];
$earningsSummaryText = '';
$earningsLoadError = null;

$baseProfileRoot = '';
if (!empty($base_url)) {
    $baseProfileRoot = rtrim((string) $base_url, '/');
} elseif (!empty($baseUrl)) {
    $baseProfileRoot = rtrim((string) $baseUrl, '/');
}

$buildProfileLink = static function (?string $username) use ($baseProfileRoot): string {
    $candidate = trim((string) $username);
    if ($candidate === '') {
        return '';
    }
    $candidate = ltrim($candidate, '@');
    if ($candidate === '') {
        return '';
    }
    $path = 'profile/' . rawurlencode($candidate);
    if ($baseProfileRoot === '') {
        return $path;
    }
    return $baseProfileRoot . '/' . $path;
};

$resolveAvatarUrl = static function (?string $path): string {
    $candidate = trim((string) $path);
    if ($candidate === '') {
        $candidate = 'uploads/user_avatars/default.jpeg';
    }
    return storage_url($candidate);
};

$buildPostLink = static function (int $postId, ?string $ownerUsername) use ($baseProfileRoot): string {
    if ($postId <= 0) {
        return '';
    }
    $slug = trim((string) $ownerUsername);
    $path = 'posts/' . $postId;
    if ($slug !== '') {
        $path .= '/' . rawurlencode($slug);
    }
    if ($baseProfileRoot === '') {
        return $path;
    }
    return $baseProfileRoot . '/' . $path;
};

$statusLabels = [
    'succeeded' => customLang('settings_super_thanks_status_succeeded'),
    'paid'      => customLang('settings_super_thanks_status_paid'),
    'completed' => customLang('settings_super_thanks_status_completed'),
    'pending'   => customLang('settings_super_thanks_status_pending'),
    'processing'=> customLang('settings_super_thanks_status_processing'),
    'failed'    => customLang('settings_super_thanks_status_failed'),
    'canceled'  => customLang('settings_super_thanks_status_canceled'),
    'cancelled' => customLang('settings_super_thanks_status_canceled'),
    'refunded'  => customLang('settings_super_thanks_status_refunded'),
];

$statusBadgeMap = [
    'succeeded' => 'status-badge--success',
    'paid'      => 'status-badge--success',
    'completed' => 'status-badge--success',
    'pending'   => 'status-badge--pending',
    'processing'=> 'status-badge--pending',
    'failed'    => 'status-badge--danger',
    'canceled'  => 'status-badge--danger',
    'cancelled' => 'status-badge--danger',
    'refunded'  => 'status-badge--neutral',
];

$typeLabels = [
    'tip'  => customLang('settings_super_thanks_earning_type_tip'),
    'sale' => customLang('settings_super_thanks_earning_type_sale'),
];

$userId = isset($userID) ? (int) $userID : 0;
if ($userId > 0) {
    try {
        $pdo = null;
        if (isset($RL) && is_object($RL) && method_exists($RL, 'getDb')) {
            $pdo = $RL->getDb();
        } elseif (isset($db) && $db instanceof PDO) {
            $pdo = $db;
        }

        if ($pdo instanceof PDO) {
            $earningsUnionSql = "
                SELECT
                    'tip' AS source_type,
                    tp.id AS source_id,
                    COALESCE(tp.created_at, 0) AS created_at,
                    COALESCE(tp.status, '') AS status,
                    COALESCE(tp.amount, 0) AS gross_amount,
                    CASE
                        WHEN tp.net_amount IS NOT NULL THEN tp.net_amount
                        WHEN tp.amount IS NOT NULL THEN tp.amount
                        ELSE 0
                    END AS net_amount,
                    COALESCE(tp.tax_amount, 0) AS tax_amount,
                    COALESCE(tp.fee_amount, 0) AS fee_amount,
                    COALESCE(tp.currency, '') AS currency,
                    COALESCE(tp.provider, '') AS provider,
                    COALESCE(tp.reference, '') AS reference,
                    tp.post_id AS post_id,
                    tp.buyer_id AS buyer_id
                FROM i_tip_payments tp
                WHERE tp.recipient_id = :uid_tip
            UNION ALL
                SELECT
                    'sale' AS source_type,
                    pp.id AS source_id,
                    COALESCE(pp.created_at, 0) AS created_at,
                    COALESCE(pp.status, '') AS status,
                    COALESCE(pp.amount, 0) AS gross_amount,
                    CASE
                        WHEN pp.net_amount IS NOT NULL THEN pp.net_amount
                        WHEN pp.amount IS NOT NULL THEN pp.amount
                        ELSE 0
                    END AS net_amount,
                    COALESCE(pp.tax_amount, 0) AS tax_amount,
                    COALESCE(pp.fee_amount, 0) AS fee_amount,
                    COALESCE(pp.currency, '') AS currency,
                    COALESCE(pp.provider, '') AS provider,
                    COALESCE(pp.reference, '') AS reference,
                    pp.post_id AS post_id,
                    pp.buyer_id AS buyer_id
                FROM i_post_purchases pp
                WHERE pp.recipient_id = :uid_sale
            ";

            $countSql = 'SELECT COUNT(*) FROM (' . $earningsUnionSql . ') AS earnings_base WHERE created_at > 0';
            $countStmt = $pdo->prepare($countSql);
            $countStmt->bindValue(':uid_tip', $userId, PDO::PARAM_INT);
            $countStmt->bindValue(':uid_sale', $userId, PDO::PARAM_INT);
            $countStmt->execute();
            $earningsTotal = (int) $countStmt->fetchColumn();
            $earningsPages = max(1, (int) ceil($earningsTotal / $earningsPerPage));
            if ($earningsPage > $earningsPages) {
                $earningsPage = $earningsPages;
            }
            $offset = ($earningsPage - 1) * $earningsPerPage;

            $orderColumn = $earningsSortMap[$earningsSort] ?? 'created_at';
            $orderExpr = 'base.' . $orderColumn;
            if ($orderColumn === 'status' || $orderColumn === 'source_type') {
                $orderExpr = 'LOWER(' . $orderExpr . ')';
            }
            $orderDir = strtoupper($earningsDir) === 'ASC' ? 'ASC' : 'DESC';

            $dataSql = 'SELECT base.*,
                                u.username AS buyer_username,
                                COALESCE(u.user_fullname, u.username) AS buyer_fullname,
                                u.user_avatar AS buyer_avatar,
                                posts.post_visibility,
                                posts.post_owner_id,
                                owner.username AS post_owner_username
                        FROM (' . $earningsUnionSql . ') AS base
                        LEFT JOIN i_users u ON u.user_id = base.buyer_id
                        LEFT JOIN i_user_posts posts ON posts.post_id = base.post_id
                        LEFT JOIN i_users owner ON owner.user_id = posts.post_owner_id
                        ORDER BY ' . $orderExpr . ' ' . $orderDir . ', base.created_at DESC
                        LIMIT :limit OFFSET :offset';

            $dataStmt = $pdo->prepare($dataSql);
            $dataStmt->bindValue(':uid_tip', $userId, PDO::PARAM_INT);
            $dataStmt->bindValue(':uid_sale', $userId, PDO::PARAM_INT);
            $dataStmt->bindValue(':limit', $earningsPerPage, PDO::PARAM_INT);
            $dataStmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $dataStmt->execute();
            $earningsRows = $dataStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

            $chartWindowDays = 120;
            $todayStart = strtotime(date('Y-m-d 00:00:00'));
            $chartSince = $todayStart - (($chartWindowDays - 1) * 86400);
            $historySql = 'SELECT base.created_at, base.net_amount FROM (' . $earningsUnionSql . ') AS base WHERE base.created_at >= :since_ts';
            $historyStmt = $pdo->prepare($historySql);
            $historyStmt->bindValue(':uid_tip', $userId, PDO::PARAM_INT);
            $historyStmt->bindValue(':uid_sale', $userId, PDO::PARAM_INT);
            $historyStmt->bindValue(':since_ts', $chartSince, PDO::PARAM_INT);
            $historyStmt->execute();
            $historyRows = $historyStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

            $dailySums = [];
            foreach ($historyRows as $row) {
                $ts = isset($row['created_at']) ? (int) $row['created_at'] : 0;
                if ($ts <= 0) {
                    continue;
                }
                $netAmount = isset($row['net_amount']) ? (float) $row['net_amount'] : 0.0;
                $dayKey = date('Y-m-d', $ts);
                if (!isset($dailySums[$dayKey])) {
                    $dailySums[$dayKey] = 0.0;
                }
                $dailySums[$dayKey] += $netAmount;
            }

            $weeksCount = 8;
            $weeklyLabels = [];
            $weeklyValues = [];
            $monthlyValues = [];
            for ($w = $weeksCount - 1; $w >= 0; $w--) {
                $weekEnd = $todayStart - ($w * 7 * 86400) + 86399;
                $weekStart = $weekEnd - (6 * 86400);
                $labelStart = date('M j', $weekStart);
                $labelEnd = date('M j', $weekEnd);
                $weeklyLabels[] = $labelStart . ' – ' . $labelEnd;

                $weeklySum = 0.0;
                for ($d = 0; $d < 7; $d++) {
                    $dayTs = $weekStart + ($d * 86400);
                    $dayKey = date('Y-m-d', $dayTs);
                    $weeklySum += $dailySums[$dayKey] ?? 0.0;
                }

                $monthlySum = 0.0;
                $monthStart = $weekEnd - (29 * 86400);
                for ($dayTs = $monthStart; $dayTs <= $weekEnd; $dayTs += 86400) {
                    $dayKey = date('Y-m-d', $dayTs);
                    $monthlySum += $dailySums[$dayKey] ?? 0.0;
                }

                $weeklyValues[] = round($weeklySum, 2);
                $monthlyValues[] = round($monthlySum, 2);
            }

            $earningsChart = [
                'labels'  => $weeklyLabels,
                'weekly'  => $weeklyValues,
                'monthly' => $monthlyValues,
            ];

            if ($earningsTotal > 0) {
                $rangeStart = ($earningsPage - 1) * $earningsPerPage + 1;
                $rangeEnd = min($earningsTotal, $earningsPage * $earningsPerPage);
                $earningsSummaryText = sprintf(
                    customLang('settings_super_thanks_earnings_summary'),
                    $rangeStart,
                    $rangeEnd,
                    $earningsTotal
                );
            }
        }
    } catch (Throwable $e) {
        $earningsRows = [];
        $earningsTotal = 0;
        $earningsPages = 1;
        $earningsChart = [
            'labels'  => [],
            'weekly'  => [],
            'monthly' => [],
        ];
        $earningsLoadError = customLang('settings_super_thanks_earnings_error');
        if (defined('APP_DEBUG') && APP_DEBUG && $e->getMessage()) {
            $earningsLoadError .= ' ' . $e->getMessage();
        }
    }
}

$earningsTableRows = [];
foreach ($earningsRows as $row) {
    $typeKey = strtolower((string) ($row['source_type'] ?? 'tip'));
    if (!isset($typeLabels[$typeKey])) {
        $typeKey = 'tip';
    }
    $statusKey = strtolower(trim((string) ($row['status'] ?? '')));
    if ($statusKey === '') {
        $statusKey = 'pending';
    }
    $earningsTableRows[] = [
        'id'                => (int) ($row['source_id'] ?? 0),
        'type_key'          => $typeKey,
        'type_label'        => $typeLabels[$typeKey],
        'supporter_display' => ($row['buyer_fullname'] ?? '') !== '' ? (string) $row['buyer_fullname'] : ((string) ($row['buyer_username'] ?? '') !== '' ? (string) $row['buyer_username'] : customLang('settings_super_thanks_unknown_supporter')),
        'supporter_username' => (string) ($row['buyer_username'] ?? ''),
        'supporter_url'     => $buildProfileLink($row['buyer_username'] ?? ''),
        'supporter_avatar'  => $resolveAvatarUrl($row['buyer_avatar'] ?? ''),
        'status_label'      => $statusLabels[$statusKey] ?? ucfirst($statusKey),
        'status_class'      => $statusBadgeMap[$statusKey] ?? 'status-badge--neutral',
        'gross'             => isset($row['gross_amount']) ? (float) $row['gross_amount'] : 0.0,
        'net'               => isset($row['net_amount']) ? (float) $row['net_amount'] : (isset($row['gross_amount']) ? (float) $row['gross_amount'] : 0.0),
        'fee'               => isset($row['fee_amount']) ? (float) $row['fee_amount'] : 0.0,
        'tax'               => isset($row['tax_amount']) ? (float) $row['tax_amount'] : 0.0,
        'provider'          => (string) ($row['provider'] ?? ''),
        'reference'         => (string) ($row['reference'] ?? ''),
        'post_id'           => (int) ($row['post_id'] ?? 0),
        'post_url'          => $buildPostLink((int) ($row['post_id'] ?? 0), $row['post_owner_username'] ?? ''),
        'created_at'        => isset($row['created_at']) ? (int) $row['created_at'] : 0,
    ];
}

$earningsChartLabelsJson = htmlspecialchars(json_encode(array_values($earningsChart['labels']), JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
$earningsChartWeeklyJson = htmlspecialchars(json_encode(array_map('floatval', $earningsChart['weekly']), JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
$earningsChartMonthlyJson = htmlspecialchars(json_encode(array_map('floatval', $earningsChart['monthly']), JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');

$earningsWeeklyLabel = customLang('settings_super_thanks_chart_weekly');
$earningsMonthlyLabel = customLang('settings_super_thanks_chart_monthly');

$buildEarningsUrl = static function (array $overrides = []) use ($base_url): string {
    $params = [];
    foreach ($_GET as $key => $value) {
        if ($key === 'csrf_token' || $key === 'csrftoken') {
            continue;
        }
        if (is_array($value)) {
            continue;
        }
        $params[$key] = $value;
    }
    $params['tab'] = 'super_thanks';
    foreach ($overrides as $key => $value) {
        if ($value === null) {
            unset($params[$key]);
        } else {
            $params[$key] = $value;
        }
    }
    $query = http_build_query($params);
    return iN_HelpSecure(rtrim((string) $base_url, '/') . '/settings' . ($query !== '' ? '?' . $query : ''), false);
};

$earningsPagination = '';
if ($earningsPages > 1) {
    $paginationParams = [];
    foreach ($_GET as $key => $value) {
        if ($key === 'csrf_token' || $key === 'csrftoken') {
            continue;
        }
        if (is_array($value)) {
            continue;
        }
        $paginationParams[$key] = $value;
    }
    $paginationParams['tab'] = 'super_thanks';
    $paginationParams['earnings_sort'] = $earningsSort;
    $paginationParams['earnings_dir'] = $earningsDir;
    $paginationParams['earnings_per'] = (string) $earningsPerPage;
    $paginationBase = rtrim((string) $base_url, '/') . '/settings';
    $earningsPagination = dz_render_pagination($paginationBase, $paginationParams, $earningsPage, $earningsPages, ['radius' => 1]);
}

$sortIndicator = static function (string $column) use ($earningsSort, $earningsDir, $buildEarningsUrl): array {
    $isActive = ($earningsSort === $column);
    $direction = $isActive ? $earningsDir : ($column === 'date' ? 'desc' : 'asc');
    $nextDir = $isActive ? ($earningsDir === 'desc' ? 'asc' : 'desc') : $direction;
    $url = $buildEarningsUrl([
        'earnings_sort' => $column,
        'earnings_dir'  => $nextDir,
        'page_no'       => 1,
    ]);
    return [
        'url'      => $url,
        'isActive' => $isActive,
        'dir'      => $isActive ? $earningsDir : null,
    ];
};
?>

<section class="card_admin settings-dashboard settings-dashboard--super_thanks rounded-2xl" role="region" aria-labelledby="settingsSuperThanksHeading">
  <h1 class="h1" id="settingsSuperThanksHeading"><?= iN_HelpSecure(customLang('settings_super_thanks_title'), false); ?></h1>
  <p class="settings-dashboard-intro"><?= iN_HelpSecure(customLang('settings_super_thanks_intro'), false); ?></p>

  <div class="kpi-row">
    <?php
      $kpis = [
        [
          'label'  => customLang('settings_super_thanks_total'),
          'amount' => $tipSummary['total'] ?? 0,
          'icon'   => 'super_thanks',
          'icon_class' => 'super-thanks-kpi-icon--accent',
          'hint'       => customLang('settings_super_thanks_growth_hint'),
        ],
        [
          'label'  => customLang('settings_super_thanks_month'),
          'amount' => $tipSummary['this_month'] ?? 0,
          'icon'   => 'subscription_fees',
          'icon_class' => 'super-thanks-kpi-icon--primary',
          'hint'       => customLang('settings_super_thanks_growth_hint'),
        ],
        [
          'label'  => customLang('settings_super_thanks_week'),
          'amount' => $tipSummary['this_week'] ?? 0,
          'icon'   => 'payments',
          'icon_class' => 'super-thanks-kpi-icon--warning',
          'hint'       => customLang('settings_super_thanks_growth_hint'),
        ],
      ];
    ?>
    <?php foreach ($kpis as $card): ?>
      <article class="admin-card card kpi-card super-thanks-kpi-card">
        <div class="kpi-left">
          <div class="kpi-title">
            <span class="kpi-icon super-thanks-kpi-icon <?php echo $card['icon_class']; ?>">
              <?php echo render_icon($card['icon'], true); ?>
            </span>
            <?php echo iN_HelpSecure($card['label'], false); ?>
          </div>
          <div class="kpi-amount super-thanks-kpi-amount"><?php echo iN_HelpSecure($formatMoney($card['amount']), false); ?></div>
          <div class="kpi-period super-thanks-kpi-period"><?php echo iN_HelpSecure($card['hint'], false); ?></div>
        </div>
      </article>
    <?php endforeach; ?>
  </div>

  <div class="super-thanks-charts">
    <div class="admin-card card chart-card super-thanks-chart-card">
      <div class="chart-title"><?= iN_HelpSecure(customLang('settings_super_thanks_earnings_chart_title'), false); ?></div>
      <div class="chart-legend">
        <span><span class="legend-dot legend-blue"></span><?php echo iN_HelpSecure($earningsWeeklyLabel, false); ?></span>
        <span><span class="legend-dot legend-cyan"></span><?php echo iN_HelpSecure($earningsMonthlyLabel, false); ?></span>
      </div>
      <div class="chart-box chart-box--growth">
        <canvas
          id="settingsEarningsChart"
          class="chart-canvas"
          data-labels='<?php echo $earningsChartLabelsJson; ?>'
          data-weekly='<?php echo $earningsChartWeeklyJson; ?>'
          data-monthly='<?php echo $earningsChartMonthlyJson; ?>'
          data-weekly-label="<?php echo htmlspecialchars($earningsWeeklyLabel, ENT_QUOTES, 'UTF-8'); ?>"
          data-monthly-label="<?php echo htmlspecialchars($earningsMonthlyLabel, ENT_QUOTES, 'UTF-8'); ?>"
        ></canvas>
        <p class="chart-fallback"><?= iN_HelpSecure(customLang('settings_super_thanks_chart_fallback'), false); ?></p>
      </div>
    </div>

    <div class="admin-card card table-card super-thanks-earnings-card">
      <div class="table-card__header">
        <h3 class="table-card__title"><?= iN_HelpSecure(customLang('settings_super_thanks_earnings_table_title'), false); ?></h3>
      </div>
      <?php if ($earningsLoadError !== null): ?>
        <div class="notice error super-thanks-notice"><?php echo iN_HelpSecure($earningsLoadError, false); ?></div>
      <?php endif; ?>
      <?php if ($earningsSummaryText !== ''): ?>
        <p class="table-card__summary"><?php echo iN_HelpSecure($earningsSummaryText, false); ?></p>
      <?php endif; ?>
      <div class="table-card__scroll">
        <table class="settings-table earnings-table">
          <thead>
            <tr>
              <?php $typeSort = $sortIndicator('type'); ?>
              <th>
                <a href="<?php echo $typeSort['url']; ?>" class="table-sort<?php echo $typeSort['isActive'] ? ' is-active' : ''; ?>">
                  <?= iN_HelpSecure(customLang('settings_super_thanks_table_type'), false); ?>
                  <?php if ($typeSort['isActive']): ?><span class="sort-indicator"><?php echo $typeSort['dir'] === 'asc' ? '▲' : '▼'; ?></span><?php endif; ?>
                </a>
              </th>
              <th><?= iN_HelpSecure(customLang('settings_super_thanks_table_supporter'), false); ?></th>
              <th><?= iN_HelpSecure(customLang('settings_super_thanks_table_post'), false); ?></th>
              <?php $statusSort = $sortIndicator('status'); ?>
              <th>
                <a href="<?php echo $statusSort['url']; ?>" class="table-sort<?php echo $statusSort['isActive'] ? ' is-active' : ''; ?>">
                  <?= iN_HelpSecure(customLang('settings_super_thanks_table_status'), false); ?>
                  <?php if ($statusSort['isActive']): ?><span class="sort-indicator"><?php echo $statusSort['dir'] === 'asc' ? '▲' : '▼'; ?></span><?php endif; ?>
                </a>
              </th>
              <?php $amountSort = $sortIndicator('amount'); ?>
              <th>
                <a href="<?php echo $amountSort['url']; ?>" class="table-sort<?php echo $amountSort['isActive'] ? ' is-active' : ''; ?>">
                  <?= iN_HelpSecure(customLang('settings_super_thanks_table_gross'), false); ?>
                  <?php if ($amountSort['isActive']): ?><span class="sort-indicator"><?php echo $amountSort['dir'] === 'asc' ? '▲' : '▼'; ?></span><?php endif; ?>
                </a>
              </th>
              <th><?= iN_HelpSecure(customLang('settings_super_thanks_table_tax'), false); ?></th>
              <th><?= iN_HelpSecure(customLang('settings_super_thanks_table_fee'), false); ?></th>
              <?php $netSort = $sortIndicator('net'); ?>
              <th>
                <a href="<?php echo $netSort['url']; ?>" class="table-sort<?php echo $netSort['isActive'] ? ' is-active' : ''; ?>">
                  <?= iN_HelpSecure(customLang('settings_super_thanks_table_net'), false); ?>
                  <?php if ($netSort['isActive']): ?><span class="sort-indicator"><?php echo $netSort['dir'] === 'asc' ? '▲' : '▼'; ?></span><?php endif; ?>
                </a>
              </th>
              <?php $dateSort = $sortIndicator('date'); ?>
              <th>
                <a href="<?php echo $dateSort['url']; ?>" class="table-sort<?php echo $dateSort['isActive'] ? ' is-active' : ''; ?>">
                  <?= iN_HelpSecure(customLang('settings_super_thanks_table_date'), false); ?>
                  <?php if ($dateSort['isActive']): ?><span class="sort-indicator"><?php echo $dateSort['dir'] === 'asc' ? '▲' : '▼'; ?></span><?php endif; ?>
                </a>
              </th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($earningsTableRows)): ?>
              <tr>
                <td colspan="9" class="earnings-empty">
                  <?= iN_HelpSecure(customLang('settings_super_thanks_table_empty'), false); ?>
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($earningsTableRows as $row): ?>
                <?php
                  $supporterAlt = sprintf(customLang('alt_avatar_of_user'), $row['supporter_display']);
                  $postCellLabel = $row['post_id'] > 0 ? ('#' . $row['post_id']) : customLang('settings_super_thanks_table_no_post');
                ?>
                <tr>
                  <td class="earnings-type"><?php echo iN_HelpSecure($row['type_label'], false); ?></td>
                  <td class="earnings-supporter">
                    <?php if ($row['supporter_url'] !== ''): ?>
                      <a href="<?php echo iN_HelpSecure($row['supporter_url'], false); ?>" class="earnings-supporter__link">
                        <span class="earnings-supporter__avatar"><img src="<?php echo iN_HelpSecure($row['supporter_avatar'], false); ?>" alt="<?php echo iN_HelpSecure($supporterAlt, false); ?>"></span>
                        <span class="earnings-supporter__names">
                          <span class="earnings-supporter__display"><?php echo iN_HelpSecure($row['supporter_display'], false); ?></span>
                          <?php if ($row['supporter_username'] !== '' && strtolower($row['supporter_username']) !== strtolower($row['supporter_display'])): ?>
                            <span class="earnings-supporter__username">@<?php echo iN_HelpSecure($row['supporter_username'], false); ?></span>
                          <?php endif; ?>
                        </span>
                      </a>
                    <?php else: ?>
                      <span class="earnings-supporter__display"><?php echo iN_HelpSecure($row['supporter_display'], false); ?></span>
                    <?php endif; ?>
                  </td>
                  <td class="earnings-post">
                    <?php if ($row['post_url'] !== ''): ?>
                      <a href="<?php echo iN_HelpSecure($row['post_url'], false); ?>" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure($postCellLabel, false); ?></a>
                    <?php else: ?>
                      <?= iN_HelpSecure(customLang('settings_super_thanks_table_no_post'), false); ?>
                    <?php endif; ?>
                  </td>
                  <td class="earnings-status"><span class="status-badge <?php echo iN_HelpSecure($row['status_class'], false); ?>"><?php echo iN_HelpSecure($row['status_label'], false); ?></span></td>
                  <td><?php echo iN_HelpSecure($formatMoney($row['gross']), false); ?></td>
                  <td><?php echo iN_HelpSecure($formatMoney($row['tax']), false); ?></td>
                  <td><?php echo iN_HelpSecure($formatMoney($row['fee']), false); ?></td>
                  <td><?php echo iN_HelpSecure($formatMoney($row['net']), false); ?></td>
                  <td><?php echo iN_HelpSecure($formatDate($row['created_at']), false); ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      <?php if ($earningsPagination !== ''): ?>
        <div class="earnings-pagination"><?php echo $earningsPagination; ?></div>
      <?php endif; ?>
    </div>
  </div>

</section>
