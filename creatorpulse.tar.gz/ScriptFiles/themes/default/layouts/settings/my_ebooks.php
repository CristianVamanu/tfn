<?php
declare(strict_types=1);

$settingsEbookViewerId = isset($userID) ? (int) $userID : 0;
$settingsEbooksEnabled = isset($ebooksEnabled)
    ? (bool) $ebooksEnabled
    : (bool) ($GLOBALS['ebooksEnabled'] ?? true);
$settingsEbookUploadsEnabled = isset($ebookCreatorUploadsEnabled)
    ? (bool) $ebookCreatorUploadsEnabled
    : (bool) ($GLOBALS['ebookCreatorUploadsEnabled'] ?? true);
$settingsOwnerEbooks = [];
if ($settingsEbooksEnabled && $settingsEbookViewerId > 0 && isset($RL) && method_exists($RL, 'RL_GetOwnerEbooks')) {
    $settingsOwnerEbooks = $RL->RL_GetOwnerEbooks($settingsEbookViewerId);
}

$settingsEbookBaseUrl = rtrim((string) ($base_url ?? ''), '/') . '/';
$settingsEbookCsrf = function_exists('generateCsrfToken') ? generateCsrfToken() : '';
$settingsEbookLanguages = (isset($RL) && method_exists($RL, 'RL_GetEbookLanguages'))
    ? $RL->RL_GetEbookLanguages(true, (string)($currentLang ?? 'eng'))
    : [];
if (!$settingsEbookLanguages) {
    $settingsEbookLanguages = [[
        'language_tag' => 'en',
        'display_name' => 'English',
        'native_name' => 'English',
    ]];
}
$settingsEbookFormatMoney = static function (float $amount, ?string $code = null): string {
    return function_exists('dz_format_currency') ? dz_format_currency($amount, $code) : number_format($amount, 2);
};
$settingsEbookStatusLabels = [
    'draft' => customLang('ebook_status_draft', 'Draft'),
    'pending' => customLang('ebook_status_pending', 'Pending review'),
    'active' => customLang('ebook_status_active', 'Published'),
    'rejected' => customLang('ebook_status_rejected', 'Rejected'),
    'archived' => customLang('ebook_status_archived', 'Archived'),
];
$settingsEbookStatusClasses = [
    'draft' => 'status-badge--neutral',
    'pending' => 'status-badge--pending',
    'active' => 'status-badge--success',
    'rejected' => 'status-badge--danger',
    'archived' => 'status-badge--neutral',
];
$settingsOwnerEbookStats = [
    'total' => count($settingsOwnerEbooks),
    'active' => 0,
    'pending' => 0,
    'sales' => 0,
    'net_revenue' => 0.0,
    'revenue_currency' => '',
];
foreach ($settingsOwnerEbooks as $settingsOwnerEbookStatRow) {
    $settingsOwnerEbookStatStatus = strtolower((string) ($settingsOwnerEbookStatRow['status'] ?? 'draft'));
    if ($settingsOwnerEbookStatStatus === 'active') {
        $settingsOwnerEbookStats['active']++;
    }
    if ($settingsOwnerEbookStatStatus === 'pending') {
        $settingsOwnerEbookStats['pending']++;
    }
    $settingsOwnerEbookStats['sales'] += (int) ($settingsOwnerEbookStatRow['sales_count'] ?? $settingsOwnerEbookStatRow['purchase_count'] ?? 0);
    $settingsOwnerEbookStats['net_revenue'] += (float) ($settingsOwnerEbookStatRow['net_revenue'] ?? 0);
    if ($settingsOwnerEbookStats['revenue_currency'] === '' && !empty($settingsOwnerEbookStatRow['revenue_currency'])) {
        $settingsOwnerEbookStats['revenue_currency'] = (string) $settingsOwnerEbookStatRow['revenue_currency'];
    }
}
$settingsOwnerEbookKpis = [
    ['label' => customLang('settings_my_ebooks_total', 'Total eBooks'), 'amount' => $settingsOwnerEbookStats['total'], 'icon' => 'ebook', 'class' => 'payments-kpi-icon--primary', 'hint' => customLang('settings_my_ebooks_total_hint', 'All products in your catalog')],
    ['label' => customLang('settings_my_ebooks_published', 'Published'), 'amount' => $settingsOwnerEbookStats['active'], 'icon' => 'complete', 'class' => 'payments-kpi-icon--accent', 'hint' => customLang('settings_my_ebooks_published_hint', 'Products visible in the store')],
    ['label' => customLang('settings_my_ebooks_pending', 'Pending review'), 'amount' => $settingsOwnerEbookStats['pending'], 'icon' => 'time', 'class' => 'payments-kpi-icon--warning', 'hint' => customLang('settings_my_ebooks_pending_hint', 'Products awaiting moderation')],
    ['label' => customLang('settings_my_ebooks_sales_total', 'Total sales'), 'amount' => $settingsOwnerEbookStats['sales'], 'icon' => 'payments', 'class' => 'payments-kpi-icon--accent', 'hint' => customLang('settings_my_ebooks_sales_hint', 'Completed eBook purchases')],
    ['label' => customLang('settings_my_ebooks_net_revenue', 'Net revenue'), 'amount' => $settingsOwnerEbookStats['net_revenue'], 'format' => 'money', 'currency' => $settingsOwnerEbookStats['revenue_currency'], 'icon' => 'wallet', 'class' => 'payments-kpi-icon--success', 'hint' => customLang('settings_my_ebooks_net_revenue_hint', 'Creator earnings after platform fees')],
];
?>
<section
  class="card_admin settings-dashboard settings-dashboard--my-ebooks rounded-2xl settings-my-ebooks ebooks-page"
  role="region"
  aria-labelledby="settingsMyEbooksHeading"
  data-request-url="<?php echo iN_HelpSecure($settingsEbookBaseUrl . 'request/requests.php'); ?>"
  data-delete-confirm-label="<?php echo iN_HelpSecure(customLang('ebook_delete_confirm', 'Delete this eBook?')); ?>"
  data-archive-confirm-label="<?php echo iN_HelpSecure(customLang('ebook_archive_confirm', 'Archive this eBook?')); ?>"
  data-update-failed-label="<?php echo iN_HelpSecure(customLang('ebook_management_failed', 'The eBook could not be updated.')); ?>"
  data-results-single-label="<?php echo iN_HelpSecure(customLang('settings_my_ebooks_results_single', '1 eBook shown')); ?>"
  data-results-label="<?php echo iN_HelpSecure(customLang('settings_my_ebooks_results', '{count} eBooks shown')); ?>"
>
  <header class="settings-my-ebooks__hero">
    <div>
      <h1 class="h1" id="settingsMyEbooksHeading"><?php echo customLang('ebooks_my_title', 'My eBooks'); ?></h1>
      <p class="settings-dashboard-intro"><?php echo customLang('ebooks_my_subtitle', 'Manage drafts, published books and review feedback.'); ?></p>
    </div>
    <?php if ($settingsEbooksEnabled && $settingsEbookUploadsEnabled): ?>
      <a class="btn-primary settings-my-ebooks__add" href="<?php echo iN_HelpSecure($settingsEbookBaseUrl . 'ebooks#add-ebook'); ?>">
        <?php echo render_icon('ebook', true); ?>
        <span><?php echo customLang('ebooks_add_title', 'Add eBook'); ?></span>
      </a>
    <?php endif; ?>
  </header>

  <?php if (!$settingsEbooksEnabled): ?>
    <div class="settings-placeholder settings-my-ebooks__notice">
      <div class="title"><?php echo customLang('ebooks_disabled_title', 'eBooks are disabled.'); ?></div>
      <div class="desc"><?php echo customLang('ebooks_disabled_note', 'The eBook store is currently disabled by the site administrator.'); ?></div>
    </div>
  <?php else: ?>
    <div class="kpi-row settings-my-ebooks__kpis">
      <?php foreach ($settingsOwnerEbookKpis as $settingsOwnerEbookKpi): ?>
        <article class="admin-card card kpi-card payments-kpi-card settings-my-ebooks__kpi-card">
          <div class="kpi-left">
            <div class="kpi-title">
              <span class="kpi-icon payments-kpi-icon <?php echo iN_HelpSecure($settingsOwnerEbookKpi['class']); ?>">
                <?php echo render_icon($settingsOwnerEbookKpi['icon'], true); ?>
              </span>
              <?php echo iN_HelpSecure($settingsOwnerEbookKpi['label']); ?>
            </div>
            <div class="kpi-amount payments-kpi-amount"><?php echo isset($settingsOwnerEbookKpi['format']) && $settingsOwnerEbookKpi['format'] === 'money' ? iN_HelpSecure($settingsEbookFormatMoney((float) $settingsOwnerEbookKpi['amount'], (string) ($settingsOwnerEbookKpi['currency'] ?? ''))) : number_format((int) $settingsOwnerEbookKpi['amount']); ?></div>
            <div class="kpi-period payments-kpi-period"><?php echo iN_HelpSecure($settingsOwnerEbookKpi['hint']); ?></div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>

    <div class="payments-tables settings-my-ebooks__tables">
    <div class="admin-card card table-card payments-table-card settings-my-ebooks__table-card">
      <div class="table-card__header">
        <h2 class="table-card__title"><?php echo customLang('settings_my_ebooks_table_title', 'Your catalog'); ?></h2>
        <p class="table-card__hint"><?php echo customLang('settings_my_ebooks_table_hint', 'Review product status, sales and publishing controls from one place.'); ?></p>
        <?php
        $settingsOwnerEbookCount = count($settingsOwnerEbooks);
        $settingsOwnerEbookCountLabel = $settingsOwnerEbookCount === 1
          ? customLang('settings_my_ebooks_count_single', '1 eBook')
          : strtr(customLang('settings_my_ebooks_count', '{count} eBooks'), ['{count}' => (string) $settingsOwnerEbookCount]);
        ?>
        <p class="table-card__summary"><?php echo iN_HelpSecure($settingsOwnerEbookCountLabel); ?></p>
      </div>
      <?php if (!empty($settingsOwnerEbooks)): ?>
        <div class="settings-my-ebooks__toolbar" data-owner-catalog-tools>
          <label class="settings-my-ebooks__search">
            <span class="settings-my-ebooks__control-label"><?php echo customLang('settings_my_ebooks_search_label', 'Search your eBooks'); ?></span>
            <span class="settings-my-ebooks__field-wrap">
              <span class="settings-my-ebooks__control-icon" aria-hidden="true"><?php echo render_icon('search_icon', true); ?></span>
              <input type="search" data-owner-catalog-search placeholder="<?php echo iN_HelpSecure(customLang('settings_my_ebooks_search_placeholder', 'Search by title')); ?>" autocomplete="off">
            </span>
          </label>
          <label class="settings-my-ebooks__filter">
            <span class="settings-my-ebooks__control-label"><?php echo customLang('settings_my_ebooks_filter_status', 'Status'); ?></span>
            <select data-owner-catalog-status>
              <option value="all"><?php echo customLang('settings_my_ebooks_filter_all', 'All statuses'); ?></option>
              <?php foreach ($settingsEbookStatusLabels as $settingsEbookStatusValue => $settingsEbookStatusLabel): ?>
                <option value="<?php echo iN_HelpSecure($settingsEbookStatusValue); ?>"><?php echo iN_HelpSecure($settingsEbookStatusLabel); ?></option>
              <?php endforeach; ?>
              <option value="hidden"><?php echo customLang('ebook_hidden_label', 'Hidden'); ?></option>
            </select>
          </label>
          <button type="button" class="settings-my-ebooks__clear" data-owner-catalog-clear disabled hidden>
            <?php echo render_icon('close', true); ?>
            <span><?php echo customLang('settings_my_ebooks_clear_filters', 'Clear filters'); ?></span>
          </button>
        </div>
        <p class="settings-my-ebooks__results" data-owner-catalog-results aria-live="polite"></p>
      <?php endif; ?>
      <div class="table-card__scroll">
        <table class="earnings-table payments-table settings-my-ebooks__table">
          <thead>
            <tr>
              <th scope="col"><?php echo customLang('ebook_title_label', 'Title'); ?></th>
              <th scope="col"><?php echo customLang('settings_payments_transactions_col_status', 'Status'); ?></th>
              <th scope="col"><?php echo customLang('ebook_price_label', 'Price'); ?></th>
              <th scope="col"><?php echo customLang('ebook_sales_label', 'Sales'); ?></th>
              <th scope="col"><?php echo customLang('settings_my_ebooks_earnings', 'Earnings'); ?></th>
              <th scope="col"><?php echo customLang('ebook_downloads_label', 'Downloads'); ?></th>
              <th scope="col" class="settings-my-ebooks__actions-heading"><?php echo customLang('settings_subscription_column_actions', 'Actions'); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($settingsOwnerEbooks)): ?>
              <tr>
                <td colspan="7" class="earnings-empty settings-my-ebooks__empty">
                  <span><?php echo render_icon('ebook', true); ?></span>
                  <strong><?php echo customLang('ebooks_my_empty', 'You have not created an eBook yet.'); ?></strong>
                  <?php if ($settingsEbookUploadsEnabled): ?><a href="<?php echo iN_HelpSecure($settingsEbookBaseUrl . 'ebooks#add-ebook'); ?>"><?php echo customLang('ebooks_add_title', 'Add eBook'); ?></a><?php endif; ?>
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($settingsOwnerEbooks as $settingsOwnerBook): ?>
                <?php
                  $ownerEbookId = (int) ($settingsOwnerBook['ebook_id'] ?? 0);
                  $ownerStatus = strtolower((string) ($settingsOwnerBook['status'] ?? 'draft'));
                  $ownerHidden = (int) ($settingsOwnerBook['owner_hidden'] ?? 0) === 1;
                  $ownerStatusLabel = $settingsEbookStatusLabels[$ownerStatus] ?? ucwords(str_replace('_', ' ', $ownerStatus));
                  $ownerStatusClass = $settingsEbookStatusClasses[$ownerStatus] ?? 'status-badge--neutral';
                  $ownerPayload = htmlspecialchars(json_encode([
                      'ebook_id' => $ownerEbookId,
                      'title' => (string) ($settingsOwnerBook['title'] ?? ''),
                      'short_description' => (string) ($settingsOwnerBook['short_description'] ?? ''),
                      'description' => (string) ($settingsOwnerBook['description'] ?? ''),
                      'isbn' => (string) ($settingsOwnerBook['isbn'] ?? ''),
                      'language_code' => (string) ($settingsOwnerBook['language_code'] ?? 'en'),
                      'page_count' => (int) ($settingsOwnerBook['page_count'] ?? 0),
                      'publication_date' => (string) ($settingsOwnerBook['publication_date'] ?? ''),
                      'version_label' => (string) ($settingsOwnerBook['version_label'] ?? '1.0'),
                      'price' => (float) ($settingsOwnerBook['price'] ?? 0),
                  ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8');
                  $ownerMenuId = 'owner-ebook-' . $ownerEbookId;
                  $ownerTitle = (string) ($settingsOwnerBook['title'] ?? '');
                  $ownerSearchValue = function_exists('mb_strtolower') ? mb_strtolower($ownerTitle, 'UTF-8') : strtolower($ownerTitle);
                  $ownerCoverPath = trim((string) ($settingsOwnerBook['cover_path'] ?? ''));
                  $ownerCoverUrl = $ownerCoverPath !== '' ? storage_url($ownerCoverPath) : '';
                  $ownerSlug = trim((string) ($settingsOwnerBook['slug'] ?? ''));
                  $ownerDetailUrl = ($ownerStatus === 'active' && !$ownerHidden && $ownerSlug !== '') ? $settingsEbookBaseUrl . 'ebook/' . rawurlencode($ownerSlug) : '';
                ?>
                <tr data-owner-ebook-id="<?php echo $ownerEbookId; ?>" data-owner-status="<?php echo iN_HelpSecure($ownerStatus); ?>" data-owner-hidden="<?php echo $ownerHidden ? '1' : '0'; ?>" data-owner-search="<?php echo iN_HelpSecure($ownerSearchValue); ?>">
                  <td class="settings-my-ebooks__title-cell" data-label="<?php echo iN_HelpSecure(customLang('ebook_title_label', 'Title')); ?>">
                    <?php if ($ownerDetailUrl !== ''): ?><a class="settings-my-ebooks__book-icon" href="<?php echo iN_HelpSecure($ownerDetailUrl); ?>" aria-label="<?php echo iN_HelpSecure($ownerTitle); ?>"><?php else: ?><span class="settings-my-ebooks__book-icon" aria-hidden="true"><?php endif; ?>
                      <?php if ($ownerCoverUrl !== ''): ?><img class="settings-my-ebooks__cover" src="<?php echo iN_HelpSecure($ownerCoverUrl); ?>" alt="" loading="lazy"><?php else: ?><?php echo render_icon('ebook', true); ?><?php endif; ?>
                    <?php if ($ownerDetailUrl !== ''): ?></a><?php else: ?></span><?php endif; ?>
                    <span class="settings-my-ebooks__book-copy">
                      <?php if ($ownerDetailUrl !== ''): ?><a class="settings-my-ebooks__book-title" href="<?php echo iN_HelpSecure($ownerDetailUrl); ?>"><?php echo iN_HelpSecure($ownerTitle); ?></a><?php else: ?><strong><?php echo iN_HelpSecure($ownerTitle); ?></strong><?php endif; ?>
                      <?php if ($ownerStatus === 'rejected' && trim((string) ($settingsOwnerBook['moderation_note'] ?? '')) !== ''): ?>
                        <small><b><?php echo customLang('ebook_rejection_reason', 'Review note'); ?>:</b> <?php echo iN_HelpSecure((string) $settingsOwnerBook['moderation_note']); ?></small>
                      <?php endif; ?>
                    </span>
                  </td>
                  <td data-label="<?php echo iN_HelpSecure(customLang('settings_payments_transactions_col_status', 'Status')); ?>">
                    <span class="status-badge <?php echo iN_HelpSecure($ownerStatusClass); ?>"><?php echo iN_HelpSecure($ownerStatusLabel); ?></span>
                    <?php if ($ownerHidden): ?><span class="status-badge status-badge--neutral"><?php echo customLang('ebook_hidden_label', 'Hidden'); ?></span><?php endif; ?>
                  </td>
                  <td class="amount-mono" data-label="<?php echo iN_HelpSecure(customLang('ebook_price_label', 'Price')); ?>"><?php echo iN_HelpSecure($settingsEbookFormatMoney((float) ($settingsOwnerBook['price'] ?? 0), (string) ($settingsOwnerBook['currency'] ?? ''))); ?></td>
                  <td data-label="<?php echo iN_HelpSecure(customLang('ebook_sales_label', 'Sales')); ?>"><?php echo (int) ($settingsOwnerBook['sales_count'] ?? $settingsOwnerBook['purchase_count'] ?? 0); ?></td>
                  <td class="amount-mono" data-label="<?php echo iN_HelpSecure(customLang('settings_my_ebooks_earnings', 'Earnings')); ?>"><?php echo iN_HelpSecure($settingsEbookFormatMoney((float) ($settingsOwnerBook['net_revenue'] ?? 0), (string) ($settingsOwnerBook['revenue_currency'] ?? $settingsOwnerBook['currency'] ?? ''))); ?></td>
                  <td data-label="<?php echo iN_HelpSecure(customLang('ebook_downloads_label', 'Downloads')); ?>"><?php echo (int) ($settingsOwnerBook['download_count'] ?? 0); ?></td>
                  <td class="settings-my-ebooks__actions" data-label="<?php echo iN_HelpSecure(customLang('settings_subscription_column_actions', 'Actions')); ?>">
                    <div class="post-settings-btn-box flex align_items relative">
                      <button
                        type="button"
                        class="post-settings-btn flex align_items_justify_content relative"
                        aria-label="<?php echo iN_HelpSecure(customLang('settings_my_ebooks_actions_label', 'eBook actions')); ?>"
                        aria-haspopup="dialog"
                        aria-expanded="false"
                        data-id="<?php echo iN_HelpSecure($ownerMenuId); ?>"
                      ><?php echo render_icon('dots', true); ?></button>
                    </div>
                    <div id="postMenuPopup-<?php echo iN_HelpSecure($ownerMenuId); ?>" class="post-menu-popup none" aria-hidden="true" role="dialog" aria-label="<?php echo iN_HelpSecure(customLang('settings_my_ebooks_actions_label', 'eBook actions')); ?>">
                      <div class="pm-sheet-container">
                        <div class="pm-sheet">
                          <button type="button" class="pm-item" data-owner-edit data-ebook="<?php echo $ownerPayload; ?>"><?php echo customLang('edit', 'Edit'); ?></button>
                          <?php if (in_array($ownerStatus, ['draft', 'rejected'], true)): ?><button type="button" class="pm-item" data-owner-action="submit"><?php echo customLang('ebook_submit_review_button', 'Submit for review'); ?></button><?php endif; ?>
                          <button type="button" class="pm-item" data-owner-action="<?php echo $ownerHidden ? 'show' : 'hide'; ?>"><?php echo $ownerHidden ? customLang('show', 'Show') : customLang('hide', 'Hide'); ?></button>
                          <?php if ($ownerStatus !== 'archived'): ?><button type="button" class="pm-item" data-owner-action="archive"><?php echo customLang('archive', 'Archive'); ?></button><?php endif; ?>
                          <button type="button" class="pm-item is-danger" data-owner-action="delete"><?php echo customLang('delete', 'Delete'); ?></button>
                        </div>
                        <button type="button" class="pm-cancel"><?php echo customLang('menu_cancel', 'Cancel'); ?></button>
                      </div>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
              <tr data-owner-catalog-empty hidden>
                <td colspan="7" class="earnings-empty settings-my-ebooks__empty settings-my-ebooks__empty--filtered">
                  <span><?php echo render_icon('search_icon', true); ?></span>
                  <strong><?php echo customLang('settings_my_ebooks_no_results', 'No eBooks match these filters.'); ?></strong>
                  <button type="button" data-owner-catalog-clear><?php echo customLang('settings_my_ebooks_clear_filters', 'Clear filters'); ?></button>
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
    </div>
  <?php endif; ?>

  <div class="ebooks-owner-modal" data-owner-edit-modal aria-hidden="true">
    <div class="ebooks-owner-modal__backdrop" data-owner-edit-close></div>
    <form class="ebooks-owner-modal__panel" data-owner-edit-form role="dialog" aria-modal="true" aria-labelledby="ownerEditHeading">
      <input type="hidden" name="p" value="ebook_owner_update">
      <input type="hidden" name="ebook_id">
      <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($settingsEbookCsrf, ENT_QUOTES, 'UTF-8'); ?>">
      <button type="button" class="ebooks-owner-modal__close" data-owner-edit-close aria-label="<?php echo iN_HelpSecure(customLang('close', 'Close')); ?>"><?php echo render_icon('close', true); ?></button>
      <h2 id="ownerEditHeading"><?php echo customLang('ebook_edit_title', 'Edit eBook'); ?></h2>
      <label class="ebooks-field"><span><?php echo customLang('ebook_title_label', 'Title'); ?></span><input name="title" maxlength="190" required></label>
      <label class="ebooks-field"><span><?php echo customLang('ebook_short_description_label', 'Short description'); ?></span><input name="short_description" maxlength="500"></label>
      <label class="ebooks-field"><span><?php echo customLang('ebook_description_label', 'Description'); ?></span><textarea name="description" rows="4"></textarea></label>
      <div class="ebooks-form-grid">
        <label class="ebooks-field"><span>ISBN</span><input name="isbn" maxlength="32"></label>
        <label class="ebooks-field">
          <span><?php echo customLang('ebook_language_label', 'Language'); ?></span>
          <select name="language_code" required>
            <option value=""><?php echo iN_HelpSecure(customLang('ebook_language_select_placeholder', 'Choose a language')); ?></option>
            <?php foreach ($settingsEbookLanguages as $settingsEbookLanguage): ?>
              <?php $settingsEbookLanguageTag = (string)($settingsEbookLanguage['language_tag'] ?? ''); ?>
              <option value="<?php echo iN_HelpSecure($settingsEbookLanguageTag); ?>">
                <?php echo iN_HelpSecure((string)($settingsEbookLanguage['display_name'] ?? $settingsEbookLanguage['native_name'] ?? $settingsEbookLanguageTag)); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </label>
        <label class="ebooks-field"><span><?php echo customLang('ebook_pages_label', 'Pages'); ?></span><input type="number" name="page_count" min="0"></label>
        <label class="ebooks-field"><span><?php echo customLang('ebook_publication_date_label', 'Publication date'); ?></span><input type="date" name="publication_date"></label>
        <label class="ebooks-field"><span><?php echo customLang('ebook_version_label', 'Version'); ?></span><input name="version_label" maxlength="40"></label>
        <label class="ebooks-field"><span><?php echo customLang('ebook_price_label', 'Price'); ?></span><input type="number" name="price" min="0" step="0.01"></label>
      </div>
      <div class="ebooks-owner-modal__message" aria-live="polite"></div>
      <button type="submit" class="ebooks-owner-modal__save"><?php echo customLang('save_changes', 'Save changes'); ?></button>
    </form>
  </div>
</section>

<?php $settingsEbooksThemePath = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme); ?>
<script defer src="<?php echo $settingsEbooksThemePath; ?>/js/ebooks.js?v=<?php echo iN_HelpSecure($version); ?>"></script>
