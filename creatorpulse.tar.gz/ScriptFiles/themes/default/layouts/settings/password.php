<?php
if (!isset($loggedIn) || $loggedIn !== '1') {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}

$csrfToken = generateCsrfToken();
$basePath = parse_url((string) ($base_url ?? ''), PHP_URL_PATH);
$basePath = is_string($basePath) ? rtrim($basePath, '/') : '';
$requestPath = ($basePath === '' ? '' : $basePath) . '/request/requests.php';
if ($requestPath === '' || $requestPath[0] !== '/') {
    $requestPath = '/' . ltrim($requestPath, '/');
}
$requestsEndpoint = iN_HelpSecure($requestPath, false);

$passwordConfig = [
    'endpoint' => $requestsEndpoint,
    'csrf' => $csrfToken,
    'strings' => [
        'passwordSaved'   => customLang('settings_security_password_updated', 'Password updated successfully.'),
        'passwordError'   => customLang('settings_security_generic_error', 'Something went wrong. Please try again.'),
        'errorRequired'   => customLang('settings_security_error_required', 'Please complete all required fields.'),
        'errorWeak'       => customLang('settings_security_error_password_weak', 'Choose a stronger password with upper & lower case letters, numbers, and symbols.'),
        'errorMismatch'   => customLang('settings_security_error_password_mismatch', 'New password fields do not match.'),
        'saving'          => customLang('saving', 'Saving...'),
    ],
    'strengthLabels' => [
        customLang('settings_security_strength_very_weak', 'Very weak'),
        customLang('settings_security_strength_weak', 'Weak'),
        customLang('settings_security_strength_ok', 'Okay'),
        customLang('settings_security_strength_good', 'Good'),
        customLang('settings_security_strength_strong', 'Strong'),
    ],
];

$configJson = htmlspecialchars(json_encode($passwordConfig, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8');
?>

<section class="card_admin settings-dashboard security-dashboard" role="region" aria-labelledby="passwordSettingsHeading" data-security-config="<?php echo $configJson; ?>">
  <h1 class="h1" id="passwordSettingsHeading"><?php echo customLang('menu_password'); ?></h1>
  <p class="settings-dashboard-intro"><?php echo customLang('settings_password_intro', 'Update your password regularly and use a strong combination of letters, numbers, and symbols.'); ?></p>

  <div class="security-grid-pass">
    <article class="security-card" id="security-password-card">
      <header class="security-card__header">
        <h3 class="security-card__title"><?php echo customLang('settings_security_password_heading', 'Password & login'); ?></h3>
        <p class="security-card__description"><?php echo customLang('settings_security_password_description', 'Use a strong, unique password to keep your account safe. You will be signed out from other devices when you change it.'); ?></p>
      </header>

      <form id="security-password-form" class="security-form" method="post" action="<?php echo $requestsEndpoint; ?>" autocomplete="off" novalidate>
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="p" value="settings_update_password">

        <label class="security-field" for="security_current_password">
          <span class="security-field__label"><?php echo customLang('settings_password_current', 'Current password'); ?></span>
          <input type="password" id="security_current_password" name="current_password" autocomplete="current-password" placeholder="••••••••" required>
          <span class="security-field__feedback" data-feedback="current_password" aria-live="polite"></span>
        </label>

        <label class="security-field" for="security_new_password">
          <span class="security-field__label"><?php echo customLang('settings_password_new', 'New password'); ?></span>
          <input type="password" id="security_new_password" name="new_password" autocomplete="new-password" minlength="8" required data-password-strength>
          <div class="security-meter" aria-hidden="true">
            <span class="security-meter__bar" data-password-strength-bar></span>
          </div>
          <span class="security-field__hint" data-password-strength-text><?php echo customLang('settings_password_strength_hint', 'Use at least 8 characters with upper & lower case letters, numbers, and symbols.'); ?></span>
          <span class="security-field__feedback" data-feedback="new_password" aria-live="polite"></span>
        </label>

        <label class="security-field" for="security_confirm_password">
          <span class="security-field__label"><?php echo customLang('settings_password_confirm', 'Confirm new password'); ?></span>
          <input type="password" id="security_confirm_password" name="confirm_password" autocomplete="new-password" required>
          <span class="security-field__feedback" data-feedback="confirm_password" aria-live="polite"></span>
        </label>

        <div class="security-form__actions">
          <button type="submit" class="btn-primary"><?php echo customLang('save_changes'); ?></button>
          <span class="security-form__alert" data-password-alert role="status" aria-live="polite"></span>
        </div>
      </form>
    </article>
  </div>
</section>
