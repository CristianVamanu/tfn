<?php
if (!isset($loggedIn) || $loggedIn !== '1' || !isset($userData)) {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}
$csrf = generateCsrfToken();
$plans = [];
if (isset($RL) && is_object($RL) && method_exists($RL, 'RL_GetUserSubscriptionPlans')) {
    try {
        $plans = $RL->RL_GetUserSubscriptionPlans((int)$userData['user_id']);
    } catch (Throwable $__) { $plans = []; }
}
$currencyCode = isset($currency) ? strtoupper((string)$currency) : 'USD';
$minPrice = isset($premiumPostPriceMinimum) ? (float)$premiumPostPriceMinimum : 1;
$maxPrice = isset($premiumPostPriceMaximum) ? (float)$premiumPostPriceMaximum : 500;
$status = isset($creatorStatus) ? strtolower((string)$creatorStatus) : 'none';
$subStatusNew = isset($userData) ? strtolower((string)($userData['subscription_status'] ?? '')) : '';
$subStatusOld = isset($userData) ? strtolower((string)($userData['subscrition_status'] ?? '')) : '';
$subscriptionEnabled = ($subStatusNew === 'open') || ($subStatusNew === 'active') || ($subStatusOld === 'active');
?>
<section class="settings-section creator-settings">
  <div class="title"><?php echo customLang('creator_plans_title', 'Subscription plans'); ?></div>
  <p class="description"><?php echo customLang('creator_plans_intro', 'Set the prices that subscribers will pay to access your exclusive content. Leave an interval blank to disable it.'); ?></p>

  <div class="creator-status-card creator-status-card--inline">
    <span class="creator-status-card__label"><?php echo customLang('creator_identity_status', 'Status'); ?>:</span>
    <span class="creator-status-card__value creator-status-card__value--<?php echo iN_HelpSecure($status, false); ?>"><?php echo ucwords($status); ?></span>
    <span class="creator-status-card__hint"><?php echo customLang('creator_plans_hint', 'Plans unlock once your application is approved.'); ?></span>
  </div>

  <form id="creator-plans-form" class="creator-form" method="post" action="<?php echo iN_HelpSecure($base_url . 'request/requests.php'); ?>" novalidate>
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8'); ?>" />
    <input type="hidden" name="p" value="creator_plans_save" />

    <div class="creator-input">
      <div class="flex align_items space_between">
        <div>
          <span><?php echo customLang('creator_plans_toggle_label', 'Allow new subscriptions'); ?></span>
          <div class="notice small"><?php echo customLang('creator_plans_toggle_hint', 'When off, no new members can subscribe. Existing subscribers keep access.'); ?></div>
        </div>
        <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('creator_plans_toggle_aria', 'Toggle subscription availability'), false); ?>">
          <input type="hidden" name="subscription_enabled" value="0">
          <input type="checkbox" name="subscription_enabled" value="1" <?php echo $subscriptionEnabled ? 'checked' : ''; ?> data-subscription-toggle>
          <span class="el-switch-style"></span>
        </label>
      </div>
    </div>

    <div class="creator-grid">
      <?php
        $fields = [
          'weekly'   => customLang('creator_plan_weekly', 'Weekly'),
          'monthly'  => customLang('creator_plan_monthly', 'Monthly'),
          'halfyear' => customLang('creator_plan_halfyear', '6 months'),
          'yearly'   => customLang('creator_plan_yearly', 'Yearly'),
        ];
        foreach ($fields as $key => $label):
            $value = isset($plans['price_' . $key]) ? (float)$plans['price_' . $key] : (isset($plans[$key]) ? (float)$plans[$key] : null);
            $valueAttr = $value !== null && $value > 0 ? htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8') : '';
      ?>
        <label class="creator-input">
          <span><?php echo $label; ?> (<?php echo htmlspecialchars($currencyCode, ENT_QUOTES, 'UTF-8'); ?>)</span>
          <input type="number" name="price_<?php echo $key; ?>" step="0.50" min="0" max="<?php echo htmlspecialchars((string)$maxPrice, ENT_QUOTES, 'UTF-8'); ?>" value="<?php echo $valueAttr; ?>" placeholder="<?php echo customLang('creator_plan_placeholder', 'Leave blank to disable'); ?>" data-plan-input>
        </label>
      <?php endforeach; ?>
    </div>

    <?php $limitsText = sprintf(customLang('creator_plan_limits', 'Recommended range: %s - %s %s.'), number_format($minPrice, 2), number_format($maxPrice, 2), $currencyCode); ?>
    <div class="creator-form__hint">
      <?php echo iN_HelpSecure($limitsText, false); ?>
    </div>

    <div class="creator-form__actions">
      <button type="submit" class="btn-primary"><?php echo customLang('save_changes'); ?></button>
      <div class="creator-form__alert" role="alert" aria-live="polite"></div>
    </div>
  </form>
</section>
