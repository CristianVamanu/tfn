<?php
declare(strict_types=1);

$heading = customLang('settings_podcast_ads_title', 'Podcast hero ads');
$description = customLang('settings_podcast_ads_desc', 'Track your approved, pending, and expired hero ads.');
$emptyMessage = customLang('settings_podcast_ads_empty', 'You have not created any podcast hero ads yet.');
$statusLabel = customLang('settings_podcast_ads_status', 'Status');
$packageLabel = customLang('settings_podcast_ads_package', 'Package');
$amountLabel = customLang('settings_podcast_ads_amount', 'Amount');
$datesLabel = customLang('settings_podcast_ads_dates', 'Dates');
$capsLabel = customLang('settings_podcast_ads_caps', 'Delivery caps');
$metricsLabel = customLang('settings_podcast_ads_metrics', 'Performance');
$premiumLabel = customLang('settings_podcast_ads_premium', 'Premium slot');
$targetingLabel = customLang('settings_podcast_ads_targeting', 'Targeting add-on');
$actionsLabel = customLang('settings_podcast_ads_actions', 'Actions');
$detailsLabel = customLang('settings_podcast_ads_details', 'Details');
$podcastLabel = customLang('settings_podcast_ads_podcast', 'Podcast');
$publishedLabel = customLang('settings_podcast_ads_published', 'Published');
$pauseLabel = customLang('settings_podcast_ads_pause', 'Pause');
$resumeLabel = customLang('settings_podcast_ads_resume', 'Resume');
$actionsNote = customLang('settings_podcast_ads_actions_note', 'Contact support to pause or resume an approved campaign.');
$emptyCta = customLang('settings_podcast_ads_empty_cta', 'Launch a hero placement to boost your next episode.');
$overviewSpend = customLang('settings_podcast_ads_overview_spend', 'Total spend');
$overviewApproved = customLang('settings_podcast_ads_overview_approved', 'Approved');
$overviewPending = customLang('settings_podcast_ads_overview_pending', 'Pending');
$overviewExpired = customLang('settings_podcast_ads_overview_expired', 'Expired');
$startLabel = customLang('hero_ads_start', 'Start date');
$endLabel = customLang('hero_ads_end', 'End date');
$impressionsLabel = customLang('hero_ads_impressions', 'Impressions');
$clicksLabel = customLang('hero_ads_clicks', 'Clicks');
$detailPackageLabel = customLang('settings_podcast_ads_detail_package', 'Selected package');
$detailPlanLabel = customLang('settings_podcast_ads_detail_plan', 'Plan details');
$detailStatsLabel = customLang('settings_podcast_ads_detail_stats', 'Performance');
$detailDaysLeftLabel = customLang('settings_podcast_ads_detail_days_left', 'Days left');
$detailDeleteLabel = customLang('settings_podcast_ads_detail_delete', 'Delete ad');
$detailCloseLabel = customLang('settings_podcast_ads_detail_close', 'Close');

$uid = isset($userID) ? (int) $userID : 0;
$ads = [];
if ($uid > 0 && isset($RL) && method_exists($RL, 'RL_ListPodcastAds')) {
    try {
        $ads = $RL->RL_ListPodcastAds(['created_by' => $uid], 100, 0);
    } catch (Throwable $__) {
        $ads = [];
    }
}

$normalizeTs = static function ($value): ?int {
    if ($value === null) {
        return null;
    }
    if (is_int($value) || is_float($value) || (is_numeric($value) && ctype_digit((string) $value))) {
        $v = (int) $value;
        return $v > 0 ? $v : null;
    }
    if (is_string($value) && trim($value) !== '') {
        $ts = @strtotime($value);
        return $ts && $ts > 0 ? $ts : null;
    }
    return null;
};

$fmtDate = static function (?int $ts): string {
    if ($ts === null) {
        return '--';
    }
    return date('Y-m-d', $ts);
};

$now = time();
$approvedCount = 0;
$pendingCount = 0;
$expiredCount = 0;
$totalSpend = 0.0;
$currencyCounts = [];
foreach ($ads as $adMeta) {
    $statusRaw = strtolower((string) ($adMeta['status'] ?? 'pending'));
    $endAt = $normalizeTs($adMeta['end_at'] ?? null);
    $isExpired = $endAt !== null && $endAt < $now && $statusRaw === 'approved';
    if ($isExpired) {
        $expiredCount++;
    } elseif ($statusRaw === 'approved') {
        $approvedCount++;
    } elseif ($statusRaw === 'pending') {
        $pendingCount++;
    }
    $pay = isset($adMeta['payment_amount']) ? (float) $adMeta['payment_amount'] : null;
    $budgetAmount = isset($adMeta['budget_amount']) ? (float) $adMeta['budget_amount'] : null;
    $currencyCandidate = trim((string) ($adMeta['payment_currency'] ?? ($adMeta['currency'] ?? '')));
    if ($currencyCandidate !== '') {
        $currencyCounts[$currencyCandidate] = true;
    }
    if ($pay !== null) {
        $totalSpend += $pay;
    } elseif ($budgetAmount !== null) {
        $totalSpend += $budgetAmount;
    }
}

$primaryCurrency = '';
if (count($currencyCounts) === 1) {
    $currencyKeys = array_keys($currencyCounts);
    $primaryCurrency = strtoupper((string) ($currencyKeys[0] ?? ''));
}
$spendDisplay = number_format($totalSpend, 2, '.', '');
$currencyMap = [];
if (isset($currencies) && is_array($currencies)) {
    $currencyMap = $currencies;
} elseif (isset($currencys) && is_array($currencys)) {
    $currencyMap = $currencys;
}
if (empty($currencyMap)) {
    $currencyMap = [
        'USD' => '$',
        'EUR' => '€',
        'GBP' => '£',
        'TRY' => '₺',
    ];
}
$defaultCurrencyCode = isset($globalCurCode)
    ? strtoupper(trim((string) $globalCurCode))
    : (isset($currency) ? strtoupper(trim((string) $currency)) : 'USD');
$defaultCurrencySymbol = isset($currencyMap[$defaultCurrencyCode]) ? (string) $currencyMap[$defaultCurrencyCode] : '';
if ($defaultCurrencySymbol === '' || !isset($currencyMap[$defaultCurrencyCode])) {
    $defaultCurrencyCode = 'USD';
    $defaultCurrencySymbol = isset($currencyMap[$defaultCurrencyCode]) ? (string) $currencyMap[$defaultCurrencyCode] : '$';
}
if ($defaultCurrencySymbol === '' && $defaultCurrencyCode === 'USD') {
    $defaultCurrencySymbol = '$';
}
$defaultCurrencyLabel = $defaultCurrencySymbol !== '' ? $defaultCurrencySymbol : $defaultCurrencyCode;
$resolveCurrencyLabel = static function (?string $code) use ($currencyMap, $defaultCurrencyCode, $defaultCurrencySymbol): array {
    $code = $code !== null ? trim((string) $code) : '';
    $normalizedCode = $code !== '' ? strtoupper($code) : $defaultCurrencyCode;
    if (!isset($currencyMap[$normalizedCode]) && $normalizedCode !== '') {
        $stripped = preg_replace('/[^A-Z]/', '', $normalizedCode);
        if ($stripped !== '') {
            if (isset($currencyMap[$stripped])) {
                $normalizedCode = $stripped;
            } else {
                $normalizedCode = $stripped;
            }
        } else {
            $normalizedCode = $defaultCurrencyCode;
        }
    }
    $symbol = isset($currencyMap[$normalizedCode]) ? (string) $currencyMap[$normalizedCode] : $defaultCurrencySymbol;
    if ($symbol === '' && $normalizedCode === 'USD') {
        $symbol = '$';
    }
    $label = $symbol !== '' ? $symbol : $normalizedCode;
    return [$label, $normalizedCode, $symbol];
};
$primaryCurrencyLabel = '';
if ($primaryCurrency !== '') {
    [$primaryCurrencyLabel,] = $resolveCurrencyLabel($primaryCurrency);
} else {
    $primaryCurrencyLabel = $defaultCurrencyLabel;
}
$pageCsrfToken = isset($csrfToken) ? (string) $csrfToken : (function_exists('generateCsrfToken') ? generateCsrfToken() : '');
?>

<section class="settings-card flex flexBoxColumn gap podcast-ads-board">
    <div class="settings-card__header podcast-ads-board__header flex">
        <div>
            <h1><?php echo iN_HelpSecure($heading); ?></h1>
            <p class="form-text"><?php echo iN_HelpSecure($description); ?></p>
        </div>
        <div class="podcast-ads-board__stats">
            <div class="podcast-ads-kpi">
                <div class="podcast-ads-kpi__meta">
                    <span class="podcast-ads-kpi__icon spend"><?php echo render_icon('payments', true); ?></span>
                    <span class="podcast-ads-kpi__label"><?php echo iN_HelpSecure($overviewSpend); ?></span>
                </div>
                <div class="podcast-ads-kpi__value">
                    <?php if ($primaryCurrencyLabel !== ''): ?>
                        <span class="podcast-ads-kpi__currency"><?php echo iN_HelpSecure($primaryCurrencyLabel); ?></span>
                    <?php endif; ?>
                    <span class="podcast-ads-kpi__number"><?php echo iN_HelpSecure($spendDisplay); ?></span>
                </div>
            </div>
            <div class="podcast-ads-kpi">
                <div class="podcast-ads-kpi__meta">
                    <span class="podcast-ads-kpi__icon approved"><?php echo render_icon('complete', true); ?></span>
                    <span class="podcast-ads-kpi__label"><?php echo iN_HelpSecure($overviewApproved); ?></span>
                </div>
                <div class="podcast-ads-kpi__value">
                    <span class="podcast-ads-kpi__number"><?php echo (int) $approvedCount; ?></span>
                </div>
            </div>
            <div class="podcast-ads-kpi">
                <div class="podcast-ads-kpi__meta">
                    <span class="podcast-ads-kpi__icon pending"><?php echo render_icon('in_progress', true); ?></span>
                    <span class="podcast-ads-kpi__label"><?php echo iN_HelpSecure($overviewPending); ?></span>
                </div>
                <div class="podcast-ads-kpi__value">
                    <span class="podcast-ads-kpi__number"><?php echo (int) $pendingCount; ?></span>
                </div>
            </div>
            <div class="podcast-ads-kpi">
                <div class="podcast-ads-kpi__meta">
                    <span class="podcast-ads-kpi__icon expired"><?php echo render_icon('time_alert', false); ?></span>
                    <span class="podcast-ads-kpi__label"><?php echo iN_HelpSecure($overviewExpired); ?></span>
                </div>
                <div class="podcast-ads-kpi__value">
                    <span class="podcast-ads-kpi__number"><?php echo (int) $expiredCount; ?></span>
                </div>
            </div>
        </div>
    </div>

    <?php if (empty($ads)): ?>
        <div class="settings-placeholder podcast-ads-empty flex align_items_justify_content flexBoxColumn">
            <div class="podcast-ads-empty__icon" aria-hidden="true"><?php echo render_icon('podcastads', true); ?></div>
            <div class="title"><?php echo iN_HelpSecure($emptyMessage); ?></div>
            <p class="form-text"><?php echo iN_HelpSecure($emptyCta); ?></p>
        </div>
    <?php else: ?>
        <input type="hidden" id="podcastAdsCsrf" value="<?php echo iN_HelpSecure($pageCsrfToken); ?>">
        <div class="table-responsive podcast-ads-table-wrap">
            <table class="podcast-ads-table">
                <thead>
                    <tr>
                        <th class="podcast-ads-col--podcast"><?php echo iN_HelpSecure($podcastLabel); ?></th>
                        <th class="podcast-ads-col--title"><?php echo iN_HelpSecure($heading); ?></th>
                        <th class="podcast-ads-col--package"><?php echo iN_HelpSecure($packageLabel); ?></th>
                        <th class="podcast-ads-col--dates"><?php echo iN_HelpSecure($publishedLabel); ?></th>
                        <th class="podcast-ads-col--amount"><?php echo iN_HelpSecure($amountLabel); ?></th>
                        <th class="podcast-ads-col--actions align-right"><?php echo iN_HelpSecure($actionsLabel); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($ads as $ad):
                    $title = trim((string) ($ad['title'] ?? ''));
                    $subtitle = trim((string) ($ad['subtitle'] ?? ''));
                    $packageName = trim((string) ($ad['package_name'] ?? ''));
                    $paymentAmount = isset($ad['payment_amount']) ? (float) $ad['payment_amount'] : null;
                    $paymentCurrency = trim((string) ($ad['payment_currency'] ?? ''));
                    $budgetAmount = isset($ad['budget_amount']) ? (float) $ad['budget_amount'] : null;
                    $currency = $paymentCurrency !== '' ? $paymentCurrency : (isset($ad['currency']) ? (string) $ad['currency'] : '');
                    $targetingSelected = false;
                    if (!empty($ad['targeting_meta'])) {
                        $decodedTarget = json_decode((string) $ad['targeting_meta'], true);
                        if (is_array($decodedTarget) && !empty($decodedTarget['targeting_selected'])) {
                            $targetingSelected = true;
                        }
                    }
                    $startAt = $normalizeTs($ad['start_at'] ?? null);
                    $endAt = $normalizeTs($ad['end_at'] ?? null);
                    $amountDisplay = null;
                    if ($paymentAmount !== null) {
                        $amountDisplay = number_format($paymentAmount, 2, '.', '');
                    } elseif ($budgetAmount !== null) {
                        $amountDisplay = number_format($budgetAmount, 2, '.', '');
                    }
                    $impressions = isset($ad['impressions']) ? (int) $ad['impressions'] : 0;
                    $clicks = (isset($ad['clicks_primary']) ? (int) $ad['clicks_primary'] : 0) + (isset($ad['clicks_secondary']) ? (int) $ad['clicks_secondary'] : 0);
                    $dailyCap = isset($ad['daily_cap']) ? (int) $ad['daily_cap'] : null;
                    $totalCap = isset($ad['total_cap']) ? (int) $ad['total_cap'] : null;
                    $podcastId = isset($ad['podcast_post_id']) ? (int) $ad['podcast_post_id'] : 0;
                    $podcastName = $podcastId > 0 ? $podcastLabel . ' #' . $podcastId : $podcastLabel;
                    $podcastHref = '';
                    if ($podcastId > 0) {
                        $podcastHref = rtrim((string) ($base_url ?? ''), '/') . '/posts/' . $podcastId;
                    }
                    $publishedAt = $startAt ?? ($ad['created_at'] ?? null);
                    $publishedValue = $fmtDate($publishedAt !== null ? (int) $publishedAt : null);
                    [$currencyLabel,] = $resolveCurrencyLabel($currency);
                    $daysLeft = null;
                    if ($endAt !== null) {
                        $daysLeft = (int) max(0, ceil(($endAt - $now) / 86400));
                    }
                    $coverPath = isset($ad['cover_path']) ? trim((string) $ad['cover_path']) : '';
                    $coverUrl = '';
                    if ($coverPath !== '') {
                        if (function_exists('storage_resolve_media_url')) {
                            $coverUrl = storage_resolve_media_url($coverPath, $uploadsPath ?? '');
                        } else {
                            $baseUploads = isset($uploadsPath) ? (string) $uploadsPath : (isset($base_url) ? rtrim((string) $base_url, '/') . '/' : '');
                            $coverUrl = $baseUploads . ltrim($coverPath, '/');
                        }
                    }
                    $detailsData = [
                        'adId' => isset($ad['id']) ? (int) $ad['id'] : 0,
                        'podcastTitle' => $podcastName,
                        'podcastId' => $podcastId,
                        'postUrl' => isset($podcastHref) ? $podcastHref : '',
                        'cover' => $coverUrl,
                        'title' => $title !== '' ? $title : customLang('hero_ads_manage', 'Podcast Hero Ads'),
                        'subtitle' => $subtitle,
                        'package' => $packageName !== '' ? $packageName : customLang('hero_ads_package', 'Package'),
                        'premium' => !empty($ad['is_premium']),
                        'targeting' => $targetingSelected,
                        'amount' => $amountDisplay,
                        'currency' => $currencyLabel,
                        'dailyCap' => $dailyCap,
                        'totalCap' => $totalCap,
                        'start' => $fmtDate($startAt),
                        'end' => $fmtDate($endAt),
                        'published' => $fmtDate($publishedAt !== null ? (int) $publishedAt : null),
                        'daysLeft' => $daysLeft,
                        'impressions' => $impressions,
                        'clicks' => $clicks,
                    ];
                    $detailsJson = htmlspecialchars(json_encode($detailsData), ENT_QUOTES, 'UTF-8');
                ?>
                    <tr>
                        <td class="podcast-ads-col--podcast">
                            <div class="podcast-ads-table__heading">
                                <span class="podcast-ads-table__icon" aria-hidden="true"><?php echo render_icon('podcast', true); ?></span>
                                <?php
                                    $podcastHref = '';
                                    if ($podcastId > 0) {
                                        $podcastHref = rtrim((string) ($base_url ?? ''), '/') . '/posts/' . $podcastId;
                                        if (isset($userName) && $userName !== '') {
                                            $podcastHref .= '/' . rawurlencode((string) $userName);
                                        }
                                    }
                                ?>
                                <?php if ($podcastHref !== ''): ?>
                                    <a class="podcast-ads-table__title" href="<?php echo iN_HelpSecure($podcastHref); ?>">
                                        <?php echo iN_HelpSecure($podcastName); ?>
                                    </a>
                                <?php else: ?>
                                    <div class="podcast-ads-table__title"><?php echo iN_HelpSecure($podcastName); ?></div>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td class="podcast-ads-col--title">
                            <div class="podcast-ads-table__title"><?php echo htmlspecialchars($title !== '' ? $title : customLang('hero_ads_manage', 'Podcast Hero Ads'), ENT_QUOTES, 'UTF-8'); ?></div>
                            <?php if (false && $subtitle !== ''): ?>
                                <div class="podcast-ads-table__subtitle"><?php echo htmlspecialchars($subtitle, ENT_QUOTES, 'UTF-8'); ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="podcast-ads-col--package">
                            <div class="podcast-ads-table__tags">
                                <span class="chip chip--soft"><?php echo htmlspecialchars($packageName !== '' ? $packageName : customLang('hero_ads_package', 'Package'), ENT_QUOTES, 'UTF-8'); ?></span>
                            </div>
                        </td>
                        <td class="podcast-ads-col--dates">
                            <div class="podcast-ads-date"><?php echo iN_HelpSecure($publishedValue); ?></div>
                        </td>
                        <td class="podcast-ads-col--amount">
                            <?php if ($amountDisplay !== null): ?>
                                <div class="podcast-ads-amount">
                                    <?php if ($currencyLabel !== ''): ?>
                                        <span class="podcast-ads-amount__currency"><?php echo iN_HelpSecure($currencyLabel); ?></span>
                                    <?php endif; ?>
                                    <span class="podcast-ads-amount__value"><?php echo iN_HelpSecure($amountDisplay); ?></span>
                                </div>
                            <?php else: ?>
                                <span class="meta-value muted">--</span>
                            <?php endif; ?>
                        </td>
                        <td class="podcast-ads-col--actions align-right">
                            <div class="podcast-ads-actions">
                                <button type="button" class="btn-secondary podcast-ads-details" data-ad-id="<?php echo (int) ($ad['id'] ?? 0); ?>" data-ad-details="<?php echo $detailsJson; ?>">
                                    <?php echo iN_HelpSecure($detailsLabel); ?>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<div class="popUp-container flex align_items_justify_content none podcast-ads-details-modal" id="podcastAdsDetailsModal" role="dialog" aria-modal="true" aria-labelledby="podcastAdsDetailsTitle" data-actions-note="<?php echo iN_HelpSecure($actionsNote); ?>">
    <div class="popup-wrapper podcast-ads-details__wrapper flex flexBoxColumn">
        <div class="close_pop flex align_items" data-podcast-ad-details-close><?php echo render_icon('close', false); ?></div>
        <div class="podcast-ads-details__body flex flexBoxColumn gap">
            <div class="podcast-ad-picker__item" id="podcastAdsDetailsPodcast">
                <div class="podcast-ad-picker__cover" id="podcastAdsDetailsPodcastCover" aria-hidden="true"></div>
                <div class="podcast-ad-picker__meta">
                    <div class="podcast-ad-picker__title" id="podcastAdsDetailsPodcastTitle">--</div>
                </div>
                <a class="podcast-ads-details__link none" id="podcastAdsDetailsPodcastLink" href="#" target="_blank" rel="noopener sponsored">
                    <span class="podcast-ads-details__link-icon" aria-hidden="true"><?php echo render_icon('link_out', true); ?></span>
                    <?php echo iN_HelpSecure(customLang('view', 'View')); ?>
                </a>
            </div>

            <div class="podcast-ads-details__flags flex align_items gap">
                <span class="chip chip--accent podcast-ads-details__flag none" id="podcastAdsDetailsPremiumBadge"><?php echo iN_HelpSecure($premiumLabel); ?></span>
                <span class="chip chip--ghost podcast-ads-details__flag none" id="podcastAdsDetailsTargetingBadge"><?php echo iN_HelpSecure($targetingLabel); ?></span>
            </div>

            <div class="podcast-ads-details__cover" id="podcastAdsDetailsCover"></div>

            <div class="podcast-ads-details__text">
                <div class="podcast-ads-details__title" id="podcastAdsDetailsTitle">--</div>
                <div class="podcast-ads-details__subtitle" id="podcastAdsDetailsSubtitle">--</div>
            </div>

            <div class="podcast-ads-details__meta-row">
                <div class="podcast-ads-details__amount-pill" id="podcastAdsDetailsAmountPill">--</div>
                <div class="podcast-ads-details__timeline">
                    <div class="timeline-item">
                        <span class="timeline-icon"><?php echo render_icon('time', true); ?></span>
                        <div>
                            <div class="timeline-label"><?php echo iN_HelpSecure($startLabel); ?></div>
                            <div class="timeline-value" id="podcastAdsDetailsStart">--</div>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <span class="timeline-icon"><?php echo render_icon('time_alert', false); ?></span>
                        <div>
                            <div class="timeline-label"><?php echo iN_HelpSecure($endLabel); ?></div>
                            <div class="timeline-value" id="podcastAdsDetailsEnd">--</div>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <span class="timeline-icon"><?php echo render_icon('unban', true); ?></span>
                        <div>
                            <div class="timeline-label"><?php echo iN_HelpSecure($detailDaysLeftLabel); ?></div>
                            <div class="timeline-value" id="podcastAdsDetailsDaysLeft">--</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="podcast-ads-details__block">
                <div class="podcast-ads-details__block-title"><?php echo iN_HelpSecure($detailPlanLabel); ?></div>
                <div class="podcast-ads-details__rows">
                    <div class="podcast-ads-details__row"><span><?php echo iN_HelpSecure($detailPackageLabel); ?></span><span id="podcastAdsDetailsPackage">--</span></div>
                    <div class="podcast-ads-details__row"><span><?php echo iN_HelpSecure($premiumLabel); ?></span><span id="podcastAdsDetailsPremium">--</span></div>
                    <div class="podcast-ads-details__row"><span><?php echo iN_HelpSecure($targetingLabel); ?></span><span id="podcastAdsDetailsTargeting">--</span></div>
                    <div class="podcast-ads-details__row"><span><?php echo iN_HelpSecure(customLang('hero_ads_package_daily', 'Daily')); ?></span><span id="podcastAdsDetailsDailyCap">--</span></div>
                    <div class="podcast-ads-details__row"><span><?php echo iN_HelpSecure(customLang('hero_ads_package_total', 'Total')); ?></span><span id="podcastAdsDetailsTotalCap">--</span></div>
                </div>
            </div>

            <div class="podcast-ads-details__block">
                <div class="podcast-ads-details__block-title"><?php echo iN_HelpSecure($detailStatsLabel); ?></div>
                <div class="podcast-ads-details__stats">
                    <div class="podcast-ads-details__stat">
                        <div class="stat-label"><?php echo iN_HelpSecure($impressionsLabel); ?></div>
                        <div class="stat-value" id="podcastAdsDetailsImpressions">0</div>
                    </div>
                    <div class="podcast-ads-details__stat">
                        <div class="stat-label"><?php echo iN_HelpSecure($clicksLabel); ?></div>
                        <div class="stat-value" id="podcastAdsDetailsClicks">0</div>
                    </div>
                    <div class="podcast-ads-details__stat">
                        <div class="stat-label"><?php echo iN_HelpSecure($amountLabel); ?></div>
                        <div class="stat-value" id="podcastAdsDetailsAmount">--</div>
                    </div>
                </div>
            </div>

            <div class="podcast-ads-details__footer">
                <button type="button" class="btn-secondary podcast-ads-details__delete" data-podcast-ad-delete><?php echo iN_HelpSecure($detailDeleteLabel); ?></button>
                <button type="button" class="pr-cancel" data-podcast-ad-details-close><?php echo iN_HelpSecure($detailCloseLabel); ?></button>
            </div>
        </div>
    </div>
</div>
