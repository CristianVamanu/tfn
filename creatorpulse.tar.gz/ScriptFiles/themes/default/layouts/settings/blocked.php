<?php
if (!isset($loggedIn) || $loggedIn !== '1') {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}

$csrfToken = generateCsrfToken();
$requestsEndpoint = iN_HelpSecure($base_url . 'request/requests.php');
$settingsBase = isset($base_url) ? rtrim((string)$base_url, '/') . '/settings' : 'settings';

$blockedUsers = [];
if (isset($blockedAccounts) && is_array($blockedAccounts)) {
    $blockedUsers = $blockedAccounts;
} elseif (isset($userBlockedList) && is_array($userBlockedList)) {
    $blockedUsers = $userBlockedList;
}

$searchQuery = isset($_GET['blocked_query']) ? trim((string)$_GET['blocked_query']) : '';
$filterRange = isset($_GET['blocked_range']) ? (string)$_GET['blocked_range'] : 'all';

$formatDate = static function($value): string {
    if (is_numeric($value)) {
        $timestamp = (int)$value;
        if ($timestamp > 0) {
            return date('d.m.Y H:i', $timestamp);
        }
    } elseif ($value instanceof DateTimeInterface) {
        return $value->format('d.m.Y H:i');
    } elseif (is_string($value) && trim($value) !== '') {
        return $value;
    }
    return customLang('settings_blocked_unknown_time', '—');
};

$filterOptions = [
    'all'   => customLang('settings_blocked_filter_all', 'All time'),
    'week'  => customLang('settings_blocked_filter_week', 'Last 7 days'),
    'month' => customLang('settings_blocked_filter_month', 'Last 30 days'),
];
$blockedCount = count($blockedUsers);
$blockedSummary = sprintf(
    customLang('settings_blocked_summary', 'Blocked accounts: %s'),
    number_format($blockedCount)
);

$blockedHeadingId = 'settingsBlockedHeading';
$overviewHeadingId = 'blockedOverviewHeading';
$filtersHeadingId = 'blockedFiltersHeading';
$listHeadingId = 'blockedListHeading';
?>

<section class="settings-section preferences-settings card_admin settings-dashboard rounded-2xl" role="region" aria-labelledby="<?php echo $blockedHeadingId; ?>">
  <h1 class="h1" id="<?php echo $blockedHeadingId; ?>"><?php echo customLang('settings_blocked_title', 'Blocked accounts'); ?></h1>
  <p class="settings-dashboard-intro"><?php echo customLang('settings_blocked_intro', 'Review who you blocked. Unblock someone to let them interact with you again.'); ?></p>

  <div class="kpi-row">
    <article class="admin-card card kpi-card" role="group" aria-labelledby="<?php echo $overviewHeadingId; ?>">
      <div class="kpi-title" id="<?php echo $overviewHeadingId; ?>">
        <span class="kpi-icon kpi-icon--revenue"><?php echo render_icon('ban', true); ?></span>
        <?php echo customLang('settings_blocked_overview_title', 'Blocking overview'); ?>
      </div>
      <div class="kpi-amount"><?php echo number_format($blockedCount); ?></div>
      <div class="kpi-period"><?php echo customLang('settings_blocked_overview_count_label', 'Currently blocked'); ?></div>
      <div class="notice small"><?php echo iN_HelpSecure($blockedSummary, false); ?></div>
      <div class="notice small"><?php echo customLang('settings_blocked_summary_hint', 'Totals update instantly after each unblock.'); ?></div>
      <div class="notice small"><?php echo customLang('settings_blocked_overview_hint', 'Keep your space healthy—remove blocks when you feel comfortable.'); ?></div>
    </article>
  </div>

  <div class="kpi-row">
    <article class="admin-card card" role="group" aria-labelledby="<?php echo $filtersHeadingId; ?>">
      <div class="kpi-title" id="<?php echo $filtersHeadingId; ?>">
        <span class="kpi-icon kpi-icon--followers"><?php echo render_icon('ban', true); ?></span>
        <?php echo customLang('settings_blocked_filter_title', 'Search & filter'); ?>
      </div>
      <div class="notice small"><?php echo customLang('settings_blocked_filter_intro', 'Find blocked accounts quickly using search and timeframe filters.'); ?></div>
      <form class="creator-form" method="get" action="<?php echo iN_HelpSecure($settingsBase); ?>">
        <input type="hidden" name="tab" value="blocked">
        <div class="creator-grid-pref">
          <label class="creator-input creator-input--search-blocked" for="blocked_query">
            <span><?php echo customLang('settings_blocked_search_label', 'Search by name or username'); ?></span>
            <input type="search" id="blocked_query" name="blocked_query" value="<?php echo iN_HelpSecure($searchQuery, false); ?>" placeholder="@username" autocomplete="off">
            <div class="notice small"><?php echo customLang('settings_blocked_search_hint', 'Type at least two characters to narrow the list.'); ?></div>
          </label>
          <label class="creator-input" for="blocked_range">
            <span><?php echo customLang('settings_blocked_filter_label', 'Blocked when'); ?></span>
            <select id="blocked_range" name="blocked_range">
              <?php foreach ($filterOptions as $value => $label): ?>
                <option value="<?php echo iN_HelpSecure($value, false); ?>" <?php echo $value === $filterRange ? 'selected' : ''; ?>><?php echo iN_HelpSecure($label, false); ?></option>
              <?php endforeach; ?>
            </select>
            <div class="notice small"><?php echo customLang('settings_blocked_filter_hint', 'Limit results to when you blocked them.'); ?></div>
          </label>
        </div>
        <div class="creator-form__actions">
          <button type="submit" class="btn-primary">
            <?php echo customLang('settings_blocked_apply_filters', 'Apply filters'); ?>
          </button>
        </div>
        <div class="notice small"><?php echo customLang('settings_blocked_filter_submit_hint', 'Submit to apply filters and refresh the list.'); ?></div>
      </form>
    </article>
  </div>

  <div class="kpi-row">
    <article class="admin-card card" role="region" aria-labelledby="<?php echo $listHeadingId; ?>">
      <div class="kpi-title" id="<?php echo $listHeadingId; ?>">
        <span class="kpi-icon kpi-icon--revenue"><?php echo render_icon('ban', true); ?></span>
        <?php echo customLang('settings_blocked_list_title', 'Manage blocked accounts'); ?>
      </div>
      <div class="notice small"><?php echo customLang('settings_blocked_list_intro', 'Review details, notes, and unblock accounts when ready.'); ?></div>

      <?php if (empty($blockedUsers)): ?>
        <div class="blocked-empty-card">
          <div class="blocked-empty-card__title"><?php echo customLang('settings_blocked_empty_title', 'You have not blocked anyone.'); ?></div>
          <div class="blocked-empty-card__desc"><?php echo customLang('settings_blocked_empty_desc', 'When you block someone, they can no longer message you, see your posts, or follow you.'); ?></div>
          <div class="notice small"><?php echo customLang('settings_blocked_empty_hint', 'People you block will appear here with their block date and any notes.'); ?></div>
        </div>
      <?php else: ?>
        <div class="blocked-card-grid">
          <?php $blockedCardIndex = 0; ?>
          <?php foreach ($blockedUsers as $blocked): ?>
            <?php
              $blockedCardIndex++;
              $cardHeadingId = 'blockedUserHeading' . $blockedCardIndex;
              $userId   = isset($blocked['user_id']) ? (int)$blocked['user_id'] : 0;
              $username = isset($blocked['username']) ? (string)$blocked['username'] : customLang('settings_blocked_unknown_user', 'Unknown');
              $display  = isset($blocked['name']) ? (string)$blocked['name'] : ($blocked['full_name'] ?? $username);
              $avatar   = isset($blocked['avatar']) ? (string)$blocked['avatar'] : '';
              if ($avatar !== '' && str_starts_with($avatar, '//')) { $avatar = 'https:' . $avatar; }
              if ($avatar !== '' && !preg_match('/^https?:/i', $avatar)) {
                  $avatar = rtrim((string)$base_url, '/') . '/' . ltrim($avatar, '/');
              }
              if ($avatar === '') {
                  $avatar = isset($defaultUserAvatar) ? (string)$defaultUserAvatar : (rtrim((string)$base_url, '/') . '/themes/' . iN_HelpSecure($currentTheme ?? 'default', false) . '/img/default-avatar.png');
              }
              $blockedAt = isset($blocked['blocked_at']) ? $formatDate($blocked['blocked_at']) : customLang('settings_blocked_unknown_time', '—');
              $reason    = isset($blocked['reason']) ? (string)$blocked['reason'] : customLang('settings_blocked_no_reason', 'Not specified');
            ?>
            <article class="blocked-card" aria-labelledby="<?php echo $cardHeadingId; ?>">
              <div class="blocked-card__header">
                <img class="blocked-card__avatar" src="<?php echo iN_HelpSecure($avatar, false); ?>" alt="<?php echo iN_HelpSecure($username, false); ?>">
                <div class="blocked-card__identity">
                  <div class="blocked-card__name" id="<?php echo $cardHeadingId; ?>"><?php echo iN_HelpSecure($display, false); ?></div>
                  <div class="notice small">@<?php echo iN_HelpSecure($username, false); ?></div>
                </div>
              </div>
              <div class="blocked-card__meta">
                <div class="blocked-card__meta-item">
                  <span class="blocked-card__label"><?php echo customLang('settings_blocked_card_blocked_on', 'Blocked on'); ?></span>
                  <span class="blocked-card__value"><?php echo iN_HelpSecure($blockedAt, false); ?></span>
                  <div class="notice small"><?php echo customLang('settings_blocked_card_blocked_on_hint', 'We store the timestamp of the block for your reference.'); ?></div>
                </div>
                <div class="blocked-card__meta-item">
                  <span class="blocked-card__label"><?php echo customLang('settings_blocked_card_reason', 'Block reason'); ?></span>
                  <p class="blocked-card__value blocked-card__value--wrap"><?php echo iN_HelpSecure($reason, false); ?></p>
                  <div class="notice small"><?php echo customLang('settings_blocked_card_reason_hint', 'Add short notes when blocking to remember your context.'); ?></div>
                </div>
              </div>
              <form method="post" action="<?php echo $requestsEndpoint; ?>" class="blocked-card__actions">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="p" value="settings_unblock_user">
                <input type="hidden" name="user_id" value="<?php echo $userId; ?>">
                <button type="submit" class="btn-primary">
                  <?php echo customLang('settings_blocked_unblock', 'Unblock'); ?>
                </button>
                <div class="notice small"><?php echo customLang('settings_blocked_card_action_hint', 'Unblocking restores messaging, follows, and visibility for this account.'); ?></div>
              </form>
            </article>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </article>
  </div>
</section>
