<?php
if (!isset($loggedIn) || $loggedIn !== '1') {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}

$csrfToken = generateCsrfToken();
$requestsEndpoint = iN_HelpSecure($base_url . 'request/requests.php');
$currencyCode = isset($currency) ? strtoupper((string) $currency) : 'USD';
$currencyMap  = isset($currencys) && is_array($currencys) ? $currencys : [];
$currencySymbol = isset($currencyMap[$currencyCode]) ? (string) $currencyMap[$currencyCode] : '$';

$currencyPrecision = dz_currency_resolve_precision($currencyCode, $GLOBALS['currency_format_settings']['decimal_places'] ?? 2);
$currencyStep = $currencyPrecision > 0
    ? ('0.' . str_repeat('0', $currencyPrecision - 1) . '1')
    : '1';

$formatMoney = static function ($amount) use ($currencySymbol, $currencyCode): string {
    $numeric = is_numeric($amount) ? (float) $amount : 0.0;
    return dz_format_currency(
        $numeric,
        $currencyCode,
        $currencySymbol,
        $GLOBALS['currency_format_settings'] ?? null
    );
};

$formatDate = static function ($value): string {
    if (is_numeric($value)) {
        $timestamp = (int) $value;
        if ($timestamp > 0) {
            return date('d.m.Y H:i', $timestamp);
        }
    } elseif ($value instanceof DateTimeInterface) {
        return $value->format('d.m.Y H:i');
    } elseif (is_string($value) && trim($value) !== '') {
        return $value;
    }
    return customLang('settings_bank_unknown_time', '—');
};

$walletTopupLimits = ['enabled' => false, 'min' => 0.0, 'max' => 0.0];
if (isset($RL) && method_exists($RL, 'RL_GetWalletTopupLimits')) {
    try {
        $walletTopupData = (array) $RL->RL_GetWalletTopupLimits();
        $walletTopupLimits = array_merge($walletTopupLimits, $walletTopupData);
    } catch (Throwable $__) {
        // ignore lookup failures, keep defaults
    }
}
$walletTopupEnabledLimits = !empty($walletTopupLimits['enabled']);
$walletTopupEnabledState = (bool) ($GLOBALS['walletTopupEnabled'] ?? $walletTopupEnabledLimits);
$walletTopupHasProvidersState = (bool) ($GLOBALS['walletTopupHasProviders'] ?? false);
$walletTopupAdminOverride = isset($isAdminUser)
    ? (bool) $isAdminUser
    : (bool) ($GLOBALS['isAdminUser'] ?? false);
$walletTopupEnabled = ($walletTopupEnabledLimits && $walletTopupEnabledState && $walletTopupHasProvidersState) || $walletTopupAdminOverride;

$resolveTimestamp = static function ($value): int {
    if (is_numeric($value)) {
        $timestamp = (int) $value;
        return $timestamp > 0 ? $timestamp : 0;
    }
    if ($value instanceof DateTimeInterface) {
        return $value->getTimestamp();
    }
    if (is_string($value)) {
        $value = trim($value);
        if ($value !== '') {
            $parsed = strtotime($value);
            if ($parsed !== false) {
                return (int) $parsed;
            }
        }
    }
    return 0;
};

$bankInfo = isset($userBankInfo) && is_array($userBankInfo) ? $userBankInfo : [];
$withdrawals = isset($withdrawalRequests) && is_array($withdrawalRequests) ? $withdrawalRequests : [];
$connectedMethods = isset($connectedPayoutMethods) && is_array($connectedPayoutMethods) ? $connectedPayoutMethods : [];
$defaultWithdrawalMethod = isset($defaultPayoutMethod) ? (string) $defaultPayoutMethod : 'bank';
$minimumWithdrawal = isset($minimumWithdrawalAmount) ? (float) $minimumWithdrawalAmount : 0.0;

$statusRaw = isset($bankInfo['status']) ? strtolower((string) $bankInfo['status']) : 'pending';
$statusNormalized = $statusRaw !== '' ? $statusRaw : 'pending';

$verificationBadgeMap = [
    'verified'   => 'status-badge--success',
    'approved'   => 'status-badge--success',
    'pending'    => 'status-badge--pending',
    'processing' => 'status-badge--pending',
    'review'     => 'status-badge--pending',
    'rejected'   => 'status-badge--danger',
    'failed'     => 'status-badge--danger',
    'none'       => 'status-badge--neutral',
];
$verificationBadgeClass = $verificationBadgeMap[$statusNormalized] ?? 'status-badge--neutral';
$verificationLabel = customLang('settings_bank_status_' . $statusNormalized, ucfirst($statusNormalized));

$pendingStatuses = ['pending', 'processing', 'in_review', 'review', 'awaiting', 'queued', 'verifying'];
$completedStatuses = ['paid', 'completed', 'approved', 'processed', 'success', 'succeeded'];
$rejectedStatuses = ['rejected', 'failed', 'canceled', 'cancelled', 'declined'];

$withdrawalStats = [
    'total_amount'            => 0.0,
    'pending_amount'          => 0.0,
    'pending_count'           => 0,
    'completed_amount'        => 0.0,
    'completed_count'         => 0,
    'rejected_count'          => 0,
    'last_completed'          => null,
    'last_request_timestamp'  => 0,
];

$lastCompleted = null;
foreach ($withdrawals as $entry) {
    if (!is_array($entry)) {
        continue;
    }
    if (empty($entry['reference']) && !empty($entry['payout_id'])) {
        $entry['reference'] = 'REQ-' . str_pad((string) $entry['payout_id'], 6, '0', STR_PAD_LEFT);
    }
    $amount = isset($entry['amount']) && is_numeric($entry['amount']) ? (float) $entry['amount'] : 0.0;
    $status = isset($entry['status']) ? strtolower(trim((string) $entry['status'])) : '';
    $requestedAtRaw = $entry['requested_at'] ?? null;
    $processedAtRaw = $entry['processed_at'] ?? null;

    $requestedTs = $resolveTimestamp($requestedAtRaw);
    $processedTs = $resolveTimestamp($processedAtRaw);
    $effectiveTs = $processedTs > 0 ? $processedTs : $requestedTs;

    $withdrawalStats['total_amount'] += $amount;

    if (in_array($status, $pendingStatuses, true)) {
        $withdrawalStats['pending_amount'] += $amount;
        $withdrawalStats['pending_count']++;
    } elseif (in_array($status, $completedStatuses, true)) {
        $withdrawalStats['completed_amount'] += $amount;
        $withdrawalStats['completed_count']++;
        if ($effectiveTs > ($lastCompleted['timestamp'] ?? 0)) {
            $lastCompleted = [
                'amount'       => $amount,
                'status'       => $status,
                'timestamp'    => $effectiveTs,
                'requested_at' => $requestedAtRaw,
                'processed_at' => $processedAtRaw,
            ];
        }
    } elseif (in_array($status, $rejectedStatuses, true)) {
        $withdrawalStats['rejected_count']++;
    }

    if ($requestedTs > $withdrawalStats['last_request_timestamp']) {
        $withdrawalStats['last_request_timestamp'] = $requestedTs;
    }
}
$withdrawalStats['last_completed'] = $lastCompleted;

$collectIfNumeric = static function (array &$target, $value): void {
    if (is_numeric($value)) {
        $target[] = (float) $value;
    }
};

$availableCandidates = [];
if (isset($bankInfo) && is_array($bankInfo)) {
    foreach (['available_balance', 'available', 'current_balance'] as $key) {
        if (isset($bankInfo[$key])) {
            $collectIfNumeric($availableCandidates, $bankInfo[$key]);
        }
    }
}
if (isset($withdrawalSummary) && is_array($withdrawalSummary)) {
    foreach (['available', 'available_balance', 'balance', 'current_balance'] as $key) {
        if (isset($withdrawalSummary[$key])) {
            $collectIfNumeric($availableCandidates, $withdrawalSummary[$key]);
        }
    }
}
if (isset($walletSummary) && is_array($walletSummary)) {
    foreach (['available', 'balance', 'withdrawable'] as $key) {
        if (isset($walletSummary[$key])) {
            $collectIfNumeric($availableCandidates, $walletSummary[$key]);
        }
    }
}
if (isset($userEarned)) {
    $collectIfNumeric($availableCandidates, $userEarned);
}
if (isset($walletBalance)) {
    $collectIfNumeric($availableCandidates, $walletBalance);
}
if (isset($walletAvailableBalance)) {
    $collectIfNumeric($availableCandidates, $walletAvailableBalance);
}
if (isset($withdrawalBalance)) {
    $collectIfNumeric($availableCandidates, $withdrawalBalance);
}
if (isset($userWithdrawalBalance)) {
    $collectIfNumeric($availableCandidates, $userWithdrawalBalance);
}
if (isset($userWallet) && is_array($userWallet)) {
    foreach (['available', 'available_balance', 'balance', 'withdrawable'] as $key) {
        if (isset($userWallet[$key])) {
            $collectIfNumeric($availableCandidates, $userWallet[$key]);
        }
    }
}

$availableAmount = $availableCandidates[0] ?? 0.0;
$availableHintKey = 'settings_bank_kpi_available_hint';
if ($availableAmount <= 0 && $withdrawalStats['completed_amount'] > 0) {
    $availableAmount = $withdrawalStats['completed_amount'];
    $availableHintKey = 'settings_bank_kpi_available_fallback_hint';
}

$pendingHint = $withdrawalStats['pending_count'] > 0
    ? sprintf(customLang('settings_bank_kpi_pending_hint', '%s requests awaiting review'), number_format($withdrawalStats['pending_count']))
    : customLang('settings_bank_kpi_pending_empty', 'No pending payouts right now.');

$lastPayout = $withdrawalStats['last_completed'];
$lastPayoutAmount = isset($lastPayout['amount']) ? (float) $lastPayout['amount'] : 0.0;
$lastPayoutDisplay = $lastPayout !== null
    ? $formatMoney($lastPayoutAmount)
    : customLang('settings_bank_kpi_last_empty', '—');

if ($lastPayout !== null) {
    $lastTimestamp = $lastPayout['processed_at'] ?? $lastPayout['timestamp'] ?? null;
    $lastPayoutHint = sprintf(
        customLang('settings_bank_kpi_last_hint', 'Processed on %s'),
        $formatDate($lastTimestamp)
    );
} elseif ($withdrawalStats['pending_count'] > 0) {
    $lastRequestedTime = $withdrawalStats['last_request_timestamp'] > 0
        ? $formatDate($withdrawalStats['last_request_timestamp'])
        : customLang('settings_bank_unknown_time', '—');
    $lastPayoutHint = sprintf(
        customLang('settings_bank_kpi_last_pending_hint', 'Last request submitted on %s'),
        $lastRequestedTime
    );
    $lastPayoutDisplay = customLang('settings_bank_kpi_last_pending', 'Pending');
} else {
    $lastPayoutHint = customLang('settings_bank_kpi_last_empty_hint', 'Create a withdrawal request once your balance is ready.');
}

$bankKpiCards = [
    [
        'label'      => customLang('settings_bank_kpi_available_balance', 'Available balance'),
        'amount'     => $availableAmount,
        'display'    => null,
        'icon'       => 'payments',
        'icon_class' => 'bank-kpi-icon--balance',
        'hint'       => $availableHintKey === 'settings_bank_kpi_available_hint'
            ? customLang('settings_bank_kpi_available_hint', 'Funds ready to withdraw')
            : sprintf(
                customLang('settings_bank_kpi_available_fallback_hint', 'Includes %s processed payouts to date'),
                number_format($withdrawalStats['completed_count'])
            ),
    ],
    [
        'label'      => customLang('settings_bank_kpi_pending_payouts', 'Pending payouts'),
        'amount'     => $withdrawalStats['pending_amount'],
        'display'    => null,
        'icon'       => 'time_alert',
        'icon_class' => 'bank-kpi-icon--pending',
        'hint'       => $pendingHint,
    ],
    [
        'label'      => customLang('settings_bank_kpi_last_payout', 'Last payout'),
        'amount'     => $lastPayoutAmount,
        'display'    => $lastPayoutDisplay,
        'icon'       => 'bank',
        'icon_class' => 'bank-kpi-icon--last',
        'hint'       => $lastPayoutHint,
    ],
];

$withdrawalStatusLabels = [
    'pending'   => customLang('withdrawal_status_pending', 'Pending'),
    'processing'=> customLang('withdrawal_status_processing', 'Processing'),
    'approved'  => customLang('withdrawal_status_approved', 'Approved'),
    'completed' => customLang('withdrawal_status_completed', 'Completed'),
    'paid'      => customLang('withdrawal_status_paid', 'Paid'),
    'rejected'  => customLang('withdrawal_status_rejected', 'Rejected'),
    'failed'    => customLang('withdrawal_status_failed', 'Failed'),
    'canceled'  => customLang('withdrawal_status_canceled', 'Canceled'),
    'cancelled' => customLang('withdrawal_status_cancelled', 'Canceled'),
    'review'    => customLang('withdrawal_status_review', 'In review'),
];

$withdrawalStatusBadgeMap = [
    'pending'    => 'status-badge--pending',
    'processing' => 'status-badge--pending',
    'approved'   => 'status-badge--success',
    'completed'  => 'status-badge--success',
    'paid'       => 'status-badge--success',
    'rejected'   => 'status-badge--danger',
    'failed'     => 'status-badge--danger',
    'canceled'   => 'status-badge--neutral',
    'cancelled'  => 'status-badge--neutral',
    'review'     => 'status-badge--pending',
];

$tableSummary = '';
if (!empty($withdrawals)) {
    $tableSummary = sprintf(
        customLang('settings_bank_table_summary', '%s requests recorded, %s pending.'),
        number_format(count($withdrawals)),
        number_format($withdrawalStats['pending_count'])
    );
}

$connectedOptions = [];
$methodLabels = [
    'bank'     => customLang('settings_payout_bank_title', 'Bank transfer'),
    'stripe'   => customLang('settings_payout_stripe_title', 'Stripe Connect'),
    'payoneer' => customLang('settings_payout_payoneer_title', 'Payoneer'),
    'paypal'   => 'PayPal',
];
foreach ($methodLabels as $methodKey => $label) {
    if (!empty($connectedMethods[$methodKey])) {
        $connectedOptions[$methodKey] = $label;
    }
}
$canWithdraw = !empty($connectedOptions) && $availableAmount > 0;

$bankAdminNote = isset($bankInfo['admin_note']) ? trim((string) $bankInfo['admin_note']) : '';
$bankRequiresUpdate = !empty($bankInfo['requires_update']);
$bankStatusReviewed = $formatDate($bankInfo['status_updated_at'] ?? ($bankInfo['updated_at'] ?? null));
$bankAdminNoteTitle = customLang('settings_bank_admin_note_title', 'Admin note');
$bankUpdateRequested = customLang('settings_bank_update_requested', 'Please review and update your bank details as requested by the admin.');
$bankLastReviewedLabel = customLang('settings_bank_last_reviewed', 'Last reviewed');
?>

<section class="card_admin settings-dashboard settings-dashboard--bank rounded-2xl" role="region" aria-labelledby="settingsBankHeading">
  <h1 class="h1" id="settingsBankHeading"><?= iN_HelpSecure(customLang('menu_withdrawal', 'Withdrawals'), false); ?></h1>
  <p class="settings-dashboard-intro"><?= iN_HelpSecure(customLang('settings_bank_intro', 'Update your bank details to receive withdrawals securely. Only verified information is used for payouts.'), false); ?></p>

  <div class="kpi-row">
    <?php foreach ($bankKpiCards as $card): ?>
      <article class="admin-card card kpi-card bank-kpi-card">
        <div class="kpi-left">
          <div class="kpi-title">
            <span class="kpi-icon bank-kpi-icon <?php echo iN_HelpSecure($card['icon_class'], false); ?>">
              <?php echo render_icon($card['icon'], true); ?>
            </span>
            <?= iN_HelpSecure($card['label'], false); ?>
          </div>
          <div class="kpi-amount bank-kpi-amount">
            <?php if ($card['display'] !== null): ?>
              <?= iN_HelpSecure($card['display'], false); ?>
            <?php else: ?>
              <?= iN_HelpSecure($formatMoney($card['amount']), false); ?>
            <?php endif; ?>
          </div>
          <?php if (!empty($card['hint'])): ?>
            <div class="kpi-period bank-kpi-hint"><?= iN_HelpSecure($card['hint'], false); ?></div>
          <?php endif; ?>
        </div>
      </article>
    <?php endforeach; ?>
  </div>

  <article class="admin-card card status-card bank-status-card" role="status" data-bank-status="true">
    <div class="bank-status-card__header">
      <span class="bank-status-card__icon"><?php echo render_icon('verified', true); ?></span>
      <div class="bank-status-card__meta">
        <span class="bank-status-card__eyebrow"><?= iN_HelpSecure(customLang('settings_bank_status', 'Verification status'), false); ?></span>
        <span class="status-badge <?php echo iN_HelpSecure($verificationBadgeClass, false); ?>" data-bank-status-label><?= iN_HelpSecure($verificationLabel, false); ?></span>
      </div>
    </div>
    <p class="bank-status-card__updated">
      <span class="bank-status-card__label"><?= iN_HelpSecure($bankLastReviewedLabel, false); ?>:</span>
      <span data-bank-reviewed><?= iN_HelpSecure($bankStatusReviewed, false); ?></span>
    </p>
    <div class="notice notice--warning bank-status-card__banner" data-bank-update<?= $bankRequiresUpdate ? '' : ' hidden'; ?>>
      <?= iN_HelpSecure($bankUpdateRequested, false); ?>
    </div>
    <div class="notice notice--info bank-status-card__admin-note" data-bank-admin-note<?= $bankAdminNote === '' ? ' hidden' : ''; ?>>
      <strong><?= iN_HelpSecure($bankAdminNoteTitle, false); ?>:</strong>
      <span data-bank-admin-note-text><?= iN_HelpSecure($bankAdminNote, false); ?></span>
    </div>
    <p class="bank-status-card__note">
      <strong><?= iN_HelpSecure(customLang('settings_bank_security_tip', 'Security'), false); ?>:</strong>
      <?= iN_HelpSecure(customLang('settings_bank_security_hint', 'All banking data is encrypted. Withdrawals are processed only to approved accounts.'), false); ?>
    </p>
  </article>

  <article class="admin-card card bank-withdraw-card">
    <div class="bank-withdraw-card__header">
      <div class="bank-withdraw-card__title-wrap">
        <h2 class="bank-withdraw-card__title"><?= iN_HelpSecure(customLang('settings_bank_withdraw_title', 'Request a withdrawal'), false); ?></h2>
        <?php if ($walletTopupEnabled): ?>
          <button type="button" class="btn-primary walletTopup bank-withdraw-card__cta"><?= iN_HelpSecure(customLang('wallet_topup_button_label', 'Add funds'), false); ?></button>
        <?php endif; ?>
      </div>
      <p class="bank-withdraw-card__balance">
        <span><?= iN_HelpSecure(customLang('settings_bank_withdraw_available', 'Available balance'), false); ?>:</span>
        <strong data-wallet-balance-text data-wallet-balance="<?= iN_HelpSecure(number_format($availableAmount, $currencyPrecision, '.', ''), false); ?>" data-wallet-balance-currency="<?= iN_HelpSecure($currencyCode, false); ?>" data-wallet-balance-symbol="<?= iN_HelpSecure($currencySymbol, false); ?>"><?= iN_HelpSecure($formatMoney($availableAmount), false); ?></strong>
      </p>
    </div>
    <?php if (!$walletTopupEnabled): ?>
      <div class="notice notice--info bank-topup-disabled"><?= iN_HelpSecure(customLang('wallet_topup_disabled_message', 'Wallet top-ups are currently unavailable.'), false); ?></div>
    <?php endif; ?>
      <p class="bank-withdraw-card__hint"><?= iN_HelpSecure(sprintf(customLang('settings_bank_withdraw_minimum', 'Minimum withdrawal amount: %s'), $formatMoney($minimumWithdrawal)), false); ?></p>
    <form id="bank-withdrawal-form" class="bank-withdrawal-form" method="post" action="<?= $requestsEndpoint; ?>">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
      <input type="hidden" name="p" value="settings_bank_withdraw">

      <div class="bank-withdraw-form-grid">
        <div class="bank-withdraw-form-grid__row">
          <label class="creator-input">
            <span><?= iN_HelpSecure(customLang('settings_bank_withdraw_amount', 'Withdrawal amount'), false); ?></span>
            <input type="number"
                   step="<?= iN_HelpSecure($currencyStep, false); ?>"
                   min="0"
                   name="amount"
                   value="<?= iN_HelpSecure(number_format($availableAmount, $currencyPrecision, '.', ''), false); ?>"
                   <?php echo $canWithdraw ? '' : 'disabled'; ?>
                   required
                   data-wallet-balance-field="value"
                   data-wallet-balance="<?= iN_HelpSecure(number_format($availableAmount, $currencyPrecision, '.', ''), false); ?>"
                   data-wallet-balance-currency="<?= iN_HelpSecure($currencyCode, false); ?>"
                   data-wallet-balance-symbol="<?= iN_HelpSecure($currencySymbol, false); ?>"
                   data-wallet-balance-format="numeric">
          </label>

          <label class="creator-input">
            <span><?= iN_HelpSecure(customLang('settings_bank_withdraw_method', 'Destination'), false); ?></span>
            <select name="method" <?php echo $canWithdraw ? '' : 'disabled'; ?> required>
              <?php if (empty($connectedOptions)): ?>
                <option value="" selected><?= iN_HelpSecure(customLang('settings_bank_withdraw_connect_hint', 'Connect a payout method first.'), false); ?></option>
              <?php else: ?>
                <?php foreach ($connectedOptions as $key => $label): ?>
                  <option value="<?= iN_HelpSecure($key, false); ?>"<?php echo $key === $defaultWithdrawalMethod ? ' selected' : ''; ?>><?= iN_HelpSecure($label, false); ?></option>
                <?php endforeach; ?>
              <?php endif; ?>
            </select>
          </label>
        </div>

        <label class="creator-input creator-input--textarea">
          <span><?= iN_HelpSecure(customLang('settings_bank_withdraw_note', 'Optional note to admins'), false); ?></span>
          <textarea name="note" rows="2" maxlength="250" placeholder="<?= iN_HelpSecure(customLang('settings_bank_withdraw_note_placeholder', 'Add any context for this payout request (optional).'), false); ?>"<?php echo $canWithdraw ? '' : ' disabled'; ?>></textarea>
        </label>
      </div>

      <div class="creator-form__actions bank-form-actions">
        <button type="submit" class="btn-primary" <?php echo $canWithdraw ? '' : 'disabled'; ?>><?= iN_HelpSecure(customLang('settings_bank_withdraw_submit', 'Submit request'), false); ?></button>
        <div class="creator-form__alert" role="alert" aria-live="polite"></div>
      </div>
    </form>
  </article>

  <form id="bank-details-form" class="creator-form bank-form" method="post" action="<?= $requestsEndpoint; ?>" autocomplete="off">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
    <input type="hidden" name="p" value="settings_bank_update">

    <div class="bank-form-grid">
      <fieldset class="creator-form__group bank-form-card admin-card card">
        <legend class="bank-form-card__title"><?= iN_HelpSecure(customLang('settings_bank_account_details', 'Bank account'), false); ?></legend>

        <label class="creator-input creator-input-plus" for="bank_account_name">
          <span><?= iN_HelpSecure(customLang('settings_bank_account_name', 'Account holder name'), false); ?></span>
          <input type="text" id="bank_account_name" name="account_name" value="<?= iN_HelpSecure($bankInfo['account_name'] ?? '', false); ?>" autocomplete="name" required>
        </label>

        <label class="creator-input creator-input-plus" for="bank_name">
          <span><?= iN_HelpSecure(customLang('settings_bank_name', 'Bank name'), false); ?></span>
          <input type="text" id="bank_name" name="bank_name" value="<?= iN_HelpSecure($bankInfo['bank_name'] ?? '', false); ?>" required>
        </label>

        <label class="creator-input creator-input-plus" for="bank_iban">
          <span><?= iN_HelpSecure(customLang('settings_bank_iban', 'IBAN'), false); ?></span>
          <input type="text" id="bank_iban" name="iban" value="<?= iN_HelpSecure($bankInfo['iban'] ?? '', false); ?>" placeholder="TR00 0000 0000 0000 0000 0000" required>
        </label>

        <label class="creator-input creator-input-plus" for="bank_swift">
          <span><?= iN_HelpSecure(customLang('settings_bank_swift', 'SWIFT/BIC'), false); ?></span>
          <input type="text" id="bank_swift" name="swift" value="<?= iN_HelpSecure($bankInfo['swift'] ?? '', false); ?>" placeholder="ABCDTRISXXX" required>
        </label>

        <label class="creator-input creator-input-plus" for="bank_account_number">
          <span><?= iN_HelpSecure(customLang('settings_bank_account_number', 'Account number (optional)'), false); ?></span>
          <input type="text" id="bank_account_number" name="account_number" value="<?= iN_HelpSecure($bankInfo['account_number'] ?? '', false); ?>">
        </label>
      </fieldset>

      <fieldset class="creator-form__group bank-form-card admin-card card">
        <legend class="bank-form-card__title"><?= iN_HelpSecure(customLang('settings_bank_contact_details', 'Contact details'), false); ?></legend>

        <label class="creator-input creator-input-plus" for="bank_country">
          <span><?= iN_HelpSecure(customLang('settings_bank_country', 'Country'), false); ?></span>
          <input type="text" id="bank_country" name="country" value="<?= iN_HelpSecure($bankInfo['country'] ?? '', false); ?>" placeholder="Türkiye" required>
        </label>

        <label class="creator-input creator-input-plus" for="bank_city">
          <span><?= iN_HelpSecure(customLang('settings_bank_city', 'City'), false); ?></span>
          <input type="text" id="bank_city" name="city" value="<?= iN_HelpSecure($bankInfo['city'] ?? '', false); ?>" required>
        </label>

        <label class="creator-input creator-input-plus" for="bank_address">
          <span><?= iN_HelpSecure(customLang('settings_bank_address', 'Billing address'), false); ?></span>
          <input type="text" id="bank_address" name="address" value="<?= iN_HelpSecure($bankInfo['address'] ?? '', false); ?>" required>
        </label>

        <label class="creator-input creator-input-plus" for="bank_postcode">
          <span><?= iN_HelpSecure(customLang('settings_bank_postcode', 'Postal code'), false); ?></span>
          <input type="text" id="bank_postcode" name="postcode" value="<?= iN_HelpSecure($bankInfo['postcode'] ?? '', false); ?>" required>
        </label>
      </fieldset>
    </div>

    <div class="creator-form__actions bank-form-actions">
      <button type="submit" class="btn-primary"><?= customLang('save_changes'); ?></button>
      <div class="creator-form__alert" role="alert" aria-live="polite"></div>
    </div>
  </form>

  <div class="admin-card card table-card bank-table-card">
    <div class="table-card__header">
      <h2 class="table-card__title"><?= iN_HelpSecure(customLang('settings_bank_history_title', 'Withdrawal requests'), false); ?></h2>
      <p class="table-card__hint"><?= iN_HelpSecure(customLang('settings_bank_history_hint', 'Track recent withdrawal submissions and their status.'), false); ?></p>
      <?php if ($tableSummary !== ''): ?>
        <p class="table-card__summary"><?= iN_HelpSecure($tableSummary, false); ?></p>
      <?php endif; ?>
    </div>
    <div class="table-card__scroll">
      <table class="earnings-table payments-table bank-table">
        <thead>
          <tr>
            <th><?= iN_HelpSecure(customLang('settings_bank_column_id', 'Request ID'), false); ?></th>
            <th><?= iN_HelpSecure(customLang('settings_bank_column_amount', 'Amount'), false); ?></th>
            <th><?= iN_HelpSecure(customLang('settings_bank_column_status', 'Status'), false); ?></th>
            <th><?= iN_HelpSecure(customLang('settings_bank_column_requested', 'Requested'), false); ?></th>
            <th><?= iN_HelpSecure(customLang('settings_bank_column_processed', 'Processed'), false); ?></th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($withdrawals)): ?>
            <tr>
              <td colspan="5" class="earnings-empty">
                <?= iN_HelpSecure(customLang('settings_bank_history_empty', 'No withdrawal requests submitted yet.'), false); ?>
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($withdrawals as $withdrawal): ?>
              <?php
                if (!is_array($withdrawal)) { continue; }
                $id = isset($withdrawal['reference']) ? (string) $withdrawal['reference'] : '';
                if ($id === '') {
                    $id = 'REQ-' . str_pad((string) ($withdrawal['payout_id'] ?? ''), 6, '0', STR_PAD_LEFT);
                }
                $amount = isset($withdrawal['amount']) && is_numeric($withdrawal['amount']) ? (float) $withdrawal['amount'] : 0.0;
                $status = isset($withdrawal['status']) ? strtolower(trim((string) $withdrawal['status'])) : '';
                $statusLabel = $withdrawalStatusLabels[$status] ?? (ucwords(str_replace('_', ' ', $status)) ?: customLang('withdrawal_status_pending', 'Pending'));
                $statusClass = $withdrawalStatusBadgeMap[$status] ?? 'status-badge--neutral';
                $requestedLabel = isset($withdrawal['requested_at']) ? $formatDate($withdrawal['requested_at']) : customLang('settings_bank_unknown_time', '—');
                $processedLabel = isset($withdrawal['processed_at']) && $withdrawal['processed_at'] !== null && $withdrawal['processed_at'] !== ''
                    ? $formatDate($withdrawal['processed_at'])
                    : customLang('settings_bank_unknown_time', '—');
              ?>
              <tr>
                <td class="bank-table__cell bank-table__cell--id"><?= iN_HelpSecure($id, false); ?></td>
                <td class="bank-table__cell bank-table__cell--amount"><?= iN_HelpSecure($formatMoney($amount), false); ?></td>
                <td class="bank-table__cell bank-table__cell--status"><span class="status-badge <?php echo iN_HelpSecure($statusClass, false); ?>"><?= iN_HelpSecure($statusLabel, false); ?></span></td>
                <td class="bank-table__cell bank-table__cell--requested"><?= iN_HelpSecure($requestedLabel, false); ?></td>
               <td class="bank-table__cell bank-table__cell--processed"><?= iN_HelpSecure($processedLabel, false); ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>
