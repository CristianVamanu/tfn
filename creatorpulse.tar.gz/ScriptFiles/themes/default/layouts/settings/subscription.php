<?php
if (!isset($loggedIn) || $loggedIn !== '1') {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}

$csrfToken = generateCsrfToken();
$requestsEndpoint = iN_HelpSecure($base_url . 'request/requests.php');
$currencyCode = isset($currency) ? strtoupper((string)$currency) : 'USD';
$currencyMap  = isset($currencys) && is_array($currencys) ? $currencys : [];
$currencySymbol = isset($currencyMap[$currencyCode]) ? (string)$currencyMap[$currencyCode] : '$';

$formatMoney = static function($amount) use ($currencySymbol, $currencyCode): string {
    $num = is_numeric($amount) ? (float)$amount : 0.0;
    return dz_format_currency(
        $num,
        $currencyCode,
        $currencySymbol,
        $GLOBALS['currency_format_settings'] ?? null
    );
};

$formatDate = static function($value): string {
    if (is_numeric($value)) {
        $timestamp = (int)$value;
        if ($timestamp > 0) {
            return date('d.m.Y', $timestamp);
        }
    } elseif ($value instanceof DateTimeInterface) {
        return $value->format('d.m.Y');
    } elseif (is_string($value) && trim($value) !== '') {
        return $value;
    }
    return customLang('settings_subscription_unknown_time', '—');
};

$activeSubscriptions = [];
if (isset($userSubscriptions) && is_array($userSubscriptions)) {
    $activeSubscriptions = $userSubscriptions;
} elseif (isset($activeSubs) && is_array($activeSubs)) {
    $activeSubscriptions = $activeSubs;
}

$subscriptionHistory = [];
if (isset($subscriptionEvents) && is_array($subscriptionEvents)) {
    $subscriptionHistory = $subscriptionEvents;
} elseif (isset($subscriptionHistoryData) && is_array($subscriptionHistoryData)) {
    $subscriptionHistory = $subscriptionHistoryData;
}

if (empty($activeSubscriptions) && isset($RL) && is_object($RL) && method_exists($RL, 'RL_GetUserActiveSubscriptions') && isset($userID)) {
    try {
        $activeSubscriptions = $RL->RL_GetUserActiveSubscriptions((int) $userID);
    } catch (Throwable $__) {
    }
}
if (empty($subscriptionHistory) && isset($RL) && is_object($RL) && method_exists($RL, 'RL_GetUserSubscriptionHistory') && isset($userID)) {
    try {
        $subscriptionHistory = $RL->RL_GetUserSubscriptionHistory((int) $userID, 40);
    } catch (Throwable $__) {
    }
}

$activeCount = count($activeSubscriptions);
$historyCount = count($subscriptionHistory);
$subscriptionSummary = sprintf(
    customLang('settings_subscription_summary', 'Active subscriptions: %s • Recent events: %s'),
    number_format($activeCount),
    number_format($historyCount)
);

$sectionHeadingId   = 'settingsSubscriptionHeading';
$overviewHeadingId  = 'subscriptionOverviewHeading';
$activeHeadingId    = 'subscriptionActiveHeading';
$historyHeadingId   = 'subscriptionHistoryHeading';
$actionsGroupLabel  = customLang('settings_subscription_actions_label', 'Subscription actions');
$cancelledStatusLabel = customLang('settings_subscription_status_cancelled', 'Cancelled');
?>

<section class="settings-section preferences-settings card_admin settings-dashboard rounded-2xl" role="region" aria-labelledby="<?php echo $sectionHeadingId; ?>">
  <h1 class="h1" id="<?php echo $sectionHeadingId; ?>"><?php echo customLang('nav_subscriptions'); ?></h1>
  <p class="settings-dashboard-intro"><?php echo customLang('settings_subscription_intro', 'Manage the creators you support. Update payment methods or cancel renewals at any time.'); ?></p>

  <div class="kpi-row">
    <article class="admin-card card kpi-card" role="group" aria-labelledby="<?php echo $overviewHeadingId; ?>">
      <div class="kpi-title" id="<?php echo $overviewHeadingId; ?>">
        <span class="kpi-icon kpi-icon--subscribers"><?php echo render_icon('subscription_fees', true); ?></span>
        <?php echo customLang('settings_subscription_overview_title', 'Subscription overview'); ?>
      </div>
      <div class="kpi-amount"><?php echo number_format($activeCount); ?></div>
      <div class="kpi-period"><?php echo customLang('settings_subscription_overview_active_label', 'Active subscriptions'); ?></div>
      <div class="notice small"><?php echo iN_HelpSecure($subscriptionSummary, false); ?></div>
      <div class="notice small"><?php echo customLang('settings_subscription_overview_hint', 'Keep supporting your favourite creators while staying on top of billing.'); ?></div>
    </article>
  </div>

  <div class="kpi-row">
    <article class="admin-card card" role="group" aria-labelledby="<?php echo $activeHeadingId; ?>">
      <div class="kpi-title" id="<?php echo $activeHeadingId; ?>">
        <span class="kpi-icon kpi-icon--followers"><?php echo render_icon('super_thanks', true); ?></span>
        <?php echo customLang('settings_subscription_active_title', 'Active subscriptions'); ?>
      </div>
      <div class="notice small"><?php echo customLang('settings_subscription_active_hint', 'Renewals charge automatically on the renewal date unless you cancel before then.'); ?></div>

      <?php if (empty($activeSubscriptions)): ?>
        <div class="subscription-empty-card" role="status">
          <div class="subscription-empty-card__title"><?php echo customLang('settings_subscription_empty', 'You are not subscribed to any creators yet.'); ?></div>
          <div class="notice small"><?php echo customLang('settings_subscription_empty_hint', 'Find creators you love and subscribe to unlock their supporter-only posts.'); ?></div>
        </div>
      <?php else: ?>
        <?php
          $subscriptionIndex = 0;
          $statusBadgeMap = [
            'active'              => 'status-badge--success',
            'succeeded'           => 'status-badge--success',
            'paid'                => 'status-badge--success',
            'pending'             => 'status-badge--pending',
            'processing'          => 'status-badge--pending',
            'incomplete'          => 'status-badge--pending',
            'trialing'            => 'status-badge--pending',
            'paused'              => 'status-badge--pending',
            'canceled'            => 'status-badge--danger',
            'cancelled'           => 'status-badge--danger',
            'expired'             => 'status-badge--danger',
            'suspended'           => 'status-badge--danger',
            'unpaid'              => 'status-badge--danger',
            'incomplete_expired'  => 'status-badge--danger',
          ];
        ?>
        <div class="table-card subscription-table-card">
          <div class="table-card__scroll">
            <table class="earnings-table payments-table subscription-table" role="table">
              <thead>
                <tr>
                  <th scope="col"><?php echo customLang('settings_subscription_column_creator', 'Creator'); ?></th>
                  <th scope="col"><?php echo customLang('settings_subscription_column_started', 'Started on'); ?></th>
                  <th scope="col"><?php echo customLang('settings_subscription_column_renewal', 'Renews on'); ?></th>
                  <th scope="col"><?php echo customLang('settings_subscription_column_plan', 'Plan'); ?></th>
                  <th scope="col"><?php echo customLang('settings_subscription_column_amount', 'Amount'); ?></th>
                  <th scope="col"><?php echo customLang('settings_subscription_column_status', 'Status'); ?></th>
                  <th scope="col"><?php echo customLang('settings_subscription_column_provider', 'Provider'); ?></th>
                  <th scope="col" class="subscription-table__actions-header"><?php echo customLang('settings_subscription_actions_label', 'Subscription actions'); ?></th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($activeSubscriptions as $subscription): ?>
                  <?php
                    $subscriptionIndex++;
                    $creator = isset($subscription['creator']) ? (string)$subscription['creator'] : customLang('settings_subscription_unknown_creator', 'Unknown creator');
                    $creatorUsername = isset($subscription['username']) ? (string)$subscription['username'] : '';
                    $profileUrl = '';
                    if ($creatorUsername !== '') {
                        $profileUrl = rtrim((string)$base_url, '/') . '/profile/' . rawurlencode($creatorUsername);
                    }
                    $avatar = isset($subscription['avatar']) ? (string)$subscription['avatar'] : '';
                    if ($avatar !== '' && str_starts_with($avatar, '//')) { $avatar = 'https:' . $avatar; }
                    if ($avatar !== '' && !preg_match('/^https?:/i', $avatar)) {
                        $avatar = rtrim((string)$base_url, '/') . '/' . ltrim($avatar, '/');
                    }
                    if ($avatar === '') {
                        $avatar = isset($defaultUserAvatar) ? (string)$defaultUserAvatar : (rtrim((string)$base_url, '/') . '/themes/' . ($currentTheme ?? 'default') . '/img/default-avatar.png');
                    }
                    $planName = isset($subscription['plan']) ? (string)$subscription['plan'] : customLang('settings_subscription_plan_unknown', 'Standard');
                    $amount   = $subscription['amount'] ?? ($subscription['price'] ?? 0);
                    $renews   = isset($subscription['renews_at']) ? $formatDate((int)$subscription['renews_at']) : customLang('settings_subscription_unknown_time', '—');
                    $startedRaw = isset($subscription['subscribed_at']) ? (int)$subscription['subscribed_at'] : 0;
                    $startedAt = $startedRaw > 0 ? $formatDate($startedRaw) : customLang('settings_subscription_unknown_time', '—');
                    $statusRaw = isset($subscription['status']) ? strtolower((string)$subscription['status']) : '';
                    $statusLabelRaw = isset($subscription['status_label']) ? (string)$subscription['status_label'] : ($subscription['status'] ?? '');
                    $statusLabel = $statusLabelRaw !== '' ? $statusLabelRaw : ($statusRaw !== '' ? ucwords(str_replace('_', ' ', $statusRaw)) : customLang('settings_subscription_status_active', 'Active'));
                    $accessUntilRaw = isset($subscription['access_until']) ? (int)$subscription['access_until'] : 0;
                    $pendingCancellation = $accessUntilRaw > 0 && in_array($statusRaw, ['canceled', 'cancelled'], true);
                    $accessUntilLabel = $pendingCancellation ? $formatDate($accessUntilRaw) : '';
                    if ($pendingCancellation && $accessUntilLabel !== '') {
                        $renews = sprintf(
                            customLang('settings_subscription_access_until_short', 'Access until %s'),
                            $accessUntilLabel
                        );
                    }
                    $statusBadgeClass = $statusBadgeMap[$statusRaw] ?? 'status-badge--neutral';
                    if ($pendingCancellation) {
                        $statusBadgeClass = 'status-badge--pending';
                        $statusLabel = customLang('settings_subscription_status_cancel_pending', 'Cancels at period end');
                    }
                    $provider = isset($subscription['provider']) ? (string)$subscription['provider'] : '';
                    $providerLabel = $provider !== '' ? ucfirst($provider) : customLang('settings_subscription_provider_unknown', '—');
                    $reference = isset($subscription['reference']) ? (string)$subscription['reference'] : '';
                    $creatorId = isset($subscription['creator_id']) ? (int)$subscription['creator_id'] : 0;
                    $subscriptionId = isset($subscription['id']) ? (int)$subscription['id'] : 0;
                    $cardHeadingId = 'subscriptionRow' . $subscriptionIndex;
                    $rowClasses = 'subscription-row' . ($pendingCancellation ? ' subscription-row--pending-cancel' : '');
                  ?>
                  <tr class="<?php echo $rowClasses; ?>" aria-labelledby="<?php echo $cardHeadingId; ?>">
                    <td class="earnings-supporter subscription-supporter-cell" data-label="<?php echo customLang('settings_subscription_column_creator', 'Creator'); ?>">
                      <?php if ($profileUrl !== ''): ?>
                        <a class="earnings-supporter__link" href="<?php echo iN_HelpSecure($profileUrl, false); ?>">
                          <span class="earnings-supporter__avatar"><img src="<?php echo iN_HelpSecure($avatar, false); ?>" alt="<?php echo iN_HelpSecure($creator, false); ?>"></span>
                          <span class="earnings-supporter__names">
                            <span class="earnings-supporter__display" id="<?php echo $cardHeadingId; ?>"><?php echo iN_HelpSecure($creator, false); ?></span>
                            <?php if ($creatorUsername !== ''): ?>
                              <span class="earnings-supporter__username">@<?php echo iN_HelpSecure($creatorUsername, false); ?></span>
                            <?php endif; ?>
                          </span>
                        </a>
                      <?php else: ?>
                        <span class="earnings-supporter__link earnings-supporter__link--static">
                          <span class="earnings-supporter__avatar"><img src="<?php echo iN_HelpSecure($avatar, false); ?>" alt="<?php echo iN_HelpSecure($creator, false); ?>"></span>
                          <span class="earnings-supporter__names">
                            <span class="earnings-supporter__display" id="<?php echo $cardHeadingId; ?>"><?php echo iN_HelpSecure($creator, false); ?></span>
                            <?php if ($creatorUsername !== ''): ?>
                              <span class="earnings-supporter__username">@<?php echo iN_HelpSecure($creatorUsername, false); ?></span>
                            <?php endif; ?>
                          </span>
                        </span>
                      <?php endif; ?>
                    </td>
                    <td class="subscription-date-cell" data-label="<?php echo customLang('settings_subscription_column_started', 'Started on'); ?>"><?php echo iN_HelpSecure($startedAt, false); ?></td>
                    <td class="subscription-date-cell" data-label="<?php echo customLang('settings_subscription_column_renewal', 'Renews on'); ?>">
                      <span class="subscription-date subscription-date--renewal<?php echo $pendingCancellation ? ' subscription-date--pending-cancel' : ''; ?>"><?php echo iN_HelpSecure($renews, false); ?></span>
                    </td>
                    <td class="subscription-plan-cell" data-label="<?php echo customLang('settings_subscription_column_plan', 'Plan'); ?>"><span class="earnings-type"><?php echo iN_HelpSecure($planName, false); ?></span></td>
                    <td class="subscription-amount-cell" data-label="<?php echo customLang('settings_subscription_column_amount', 'Amount'); ?>"><span class="amount-mono"><?php echo iN_HelpSecure($formatMoney($amount), false); ?></span></td>
                    <td class="subscription-status-cell" data-label="<?php echo customLang('settings_subscription_column_status', 'Status'); ?>">
                      <span class="status-badge <?php echo iN_HelpSecure($statusBadgeClass, false); ?>"><?php echo iN_HelpSecure($statusLabel, false); ?></span>
                    </td>
                    <td class="subscription-provider-cell" data-label="<?php echo customLang('settings_subscription_column_provider', 'Provider'); ?>">
                      <span class="subscription-provider-label"><?php echo iN_HelpSecure($providerLabel, false); ?></span>
                    </td>
                    <td class="subscription-actions" data-label="<?php echo customLang('settings_subscription_actions_label', 'Subscription actions'); ?>">
                      <div class="post-settings-btn-box flex align_items relative">
                        <?php $menuId = 'sub-' . $subscriptionIndex; ?>
                        <div
                          class="post-settings-btn flex align_items_justify_content relative"
                          role="button"
                          tabindex="0"
                          aria-haspopup="dialog"
                          aria-expanded="false"
                          data-id="<?php echo $menuId; ?>"
                        ><?php echo render_icon('dots', true); ?></div>
                      </div>
                      <div id="postMenuPopup-<?php echo $menuId; ?>" class="post-menu-popup none" aria-hidden="true" role="dialog" aria-label="<?php echo iN_HelpSecure(customLang('settings_subscription_actions_label', 'Subscription actions'), false); ?>">
                        <div class="pm-sheet-container">
                          <div class="pm-sheet">
                            <form
                              method="post"
                              action="<?php echo iN_HelpSecure($requestsEndpoint, false); ?>"
                              class="subscription-action-form"
                              data-subscription-action="cancel"
                              data-success-status-label="<?php echo htmlspecialchars($cancelledStatusLabel, ENT_QUOTES, 'UTF-8'); ?>"
                            >
                              <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
                              <input type="hidden" name="p" value="cancelSubscription">
                              <input type="hidden" name="creator_id" value="<?php echo $creatorId; ?>">
                              <input type="hidden" name="subscription_id" value="<?php echo $subscriptionId; ?>">
                              <button type="submit" class="pm-item is-danger"><?php echo customLang('settings_subscription_cancel_subscription', 'Cancel subscription'); ?></button>
                            </form>
                          </div>
                          <button type="button" class="pm-cancel"><?php echo customLang('menu_cancel', 'Cancel'); ?></button>
                        </div>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      <?php endif; ?>


    </article>
  </div>

  <div class="kpi-row">
    <article class="admin-card card" role="group" aria-labelledby="<?php echo $historyHeadingId; ?>">
      <div class="kpi-title" id="<?php echo $historyHeadingId; ?>">
        <span class="kpi-icon kpi-icon--earnings"><?php echo render_icon('history', true); ?></span>
        <?php echo customLang('settings_subscription_history_title', 'Subscription history'); ?>
      </div>
      <div class="notice small"><?php echo customLang('settings_subscription_history_hint', 'Recent subscription changes, renewals, and payment events.'); ?></div>

      <?php if (empty($subscriptionHistory)): ?>
        <div class="subscription-history-empty" role="status">
          <div class="subscription-history-empty__title"><?php echo customLang('settings_subscription_history_empty', 'No subscription activity recorded yet.'); ?></div>
          <div class="notice small"><?php echo customLang('settings_subscription_history_empty_hint', 'Activity such as renewals, upgrades, or refunds will appear here.'); ?></div>
        </div>
      <?php else: ?>
        <ul class="subscription-history-list" role="list">
          <?php $historyIndex = 0; ?>
          <?php foreach ($subscriptionHistory as $event): ?>
            <?php
              $historyIndex++;
              $eventName = isset($event['event']) ? (string)$event['event'] : customLang('settings_subscription_history_unknown_event', 'Update');
              $eventCreator = isset($event['creator']) ? (string)$event['creator'] : ($event['username'] ?? '—');
              $eventAmount = $event['amount'] ?? ($event['price'] ?? null);
              $eventDate = isset($event['date']) ? $formatDate($event['date']) : customLang('settings_subscription_unknown_time', '—');
              $eventHeadingId = 'subscriptionHistoryItem' . $historyIndex;
            ?>
            <li class="subscription-history-item" role="listitem" aria-labelledby="<?php echo $eventHeadingId; ?>">
              <div class="subscription-history-item__header">
                <span class="subscription-history-item__event" id="<?php echo $eventHeadingId; ?>"><?php echo iN_HelpSecure($eventName, false); ?></span>
              </div>
              <div class="subscription-history-item__meta">
                <div class="subscription-history-item__meta-block">
                  <span class="subscription-history-item__label"><?php echo customLang('settings_subscription_history_column_creator', 'Creator'); ?></span>
                  <span class="subscription-history-item__value"><?php echo iN_HelpSecure($eventCreator, false); ?></span>
                </div>
                <div class="subscription-history-item__meta-block">
                  <span class="subscription-history-item__label"><?php echo customLang('settings_subscription_history_column_amount', 'Amount'); ?></span>
                  <span class="subscription-history-item__value"><?php echo $eventAmount !== null ? iN_HelpSecure($formatMoney($eventAmount), false) : '—'; ?></span>
                </div>
                <div class="subscription-history-item__meta-block">
                  <span class="subscription-history-item__label"><?php echo customLang('settings_subscription_history_column_date', 'Date'); ?></span>
                  <span class="subscription-history-item__value"><?php echo iN_HelpSecure($eventDate, false); ?></span>
                </div>
              </div>
              <div class="notice small subscription-history-item__hint"><?php echo customLang('settings_subscription_history_item_hint', 'Use this log as a receipt trail for your records.'); ?></div>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </article>
  </div>
</section>
