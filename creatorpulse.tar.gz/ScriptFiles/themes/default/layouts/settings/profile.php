<?php
// Safe defaults
$u = isset($userData) && is_array($userData) ? $userData : [];
$fullName = htmlspecialchars((string)($u['user_fullname'] ?? $dataUserFullName ?? ''), ENT_QUOTES, 'UTF-8');
$username = htmlspecialchars((string)($u['username'] ?? $dataUsername ?? ''), ENT_QUOTES, 'UTF-8');
$bio      = htmlspecialchars((string)($u['about_me'] ?? ''), ENT_QUOTES, 'UTF-8');
$email    = htmlspecialchars((string)($u['contact_email'] ?? $u['user_email'] ?? ''), ENT_QUOTES, 'UTF-8');
$phone    = htmlspecialchars((string)($u['user_phone'] ?? ''), ENT_QUOTES, 'UTF-8');
$avatarPath = (string)($defaultUserAvatar ?? '');
if (isset($u['user_avatar']) && $u['user_avatar'] !== '') {
  $avatarPath = (string) $u['user_avatar'];
}
$avatarUrl = $avatarPath !== '' ? storage_url($avatarPath) : '';
$avatar   = htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8');

$coverPath = '';
if (isset($RL) && method_exists($RL, 'RL_GetUserCover') && isset($userID)) {
  try { $coverPath = (string) $RL->RL_GetUserCover((int)$userID); } catch (Throwable $__) { $coverPath = ''; }
}
$coverUrl = $coverPath !== '' ? storage_url($coverPath) : '';
$cover    = $coverUrl !== '' ? htmlspecialchars($coverUrl, ENT_QUOTES, 'UTF-8') : '';
$hasCover = $cover !== '';
?>

<section class="settings-profile flex flexBoxColumn">
  <div class="settings-section-title">
    <?php echo customLang('menu_profile'); ?>
  </div>

  <!-- Profile form (frontend only; backend hook TBD) -->
  <form id="settings-profile-form" class="sp-form flex flexBoxColumn" method="post" action="<?php echo iN_HelpSecure($base_url . 'request/requests.php'); ?>" enctype="multipart/form-data" novalidate>
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>" />
    <input type="hidden" name="p" value="update_profile" />

    <label class="sp-field flex flexBoxColumn">
      <span class="sp-label"><?php echo customLang('full_name'); ?></span>
      <input class="pp-input text-field" type="text" name="user_fullname" value="<?php echo $fullName; ?>" placeholder="<?php echo customLang('full_name'); ?>" maxlength="60" />
    </label>

    <label class="sp-field flex flexBoxColumn">
      <span class="sp-label"><?php echo customLang('username'); ?></span>
      <input class="pp-input text-field" type="text" name="username" value="<?php echo $username; ?>" placeholder="<?php echo customLang('username'); ?>" maxlength="32" />
      <span class="pp-hint"><?php echo customLang('username_hint'); ?></span>
    </label>

    <label class="sp-field flex flexBoxColumn">
      <span class="sp-label"><?php echo customLang('bio'); ?></span>
      <textarea class="pe-text" name="about_me" rows="4" placeholder="<?php echo customLang('bio'); ?>" maxlength="300"><?php echo $bio; ?></textarea>
    </label>

    <label class="sp-field flex flexBoxColumn">
      <span class="sp-label"><?php echo customLang('contact_email'); ?></span>
      <input class="pp-input text-field" type="email" name="contact_email" value="<?php echo $email; ?>" placeholder="name@example.com" maxlength="120" />
    </label>

    <label class="sp-field flex flexBoxColumn">
      <span class="sp-label"><?php echo customLang('phone_number', 'Phone number'); ?></span>
      <input class="pp-input text-field" type="tel" name="user_phone" value="<?php echo $phone; ?>" placeholder="+905551112233" maxlength="32" />
      <span class="pp-hint"><?php echo customLang('phone_number_hint', 'Include country code for SMS notifications.'); ?></span>
    </label>

    <!-- Media Row (left avatar, right cover) under contact_email -->
    <div class="profile-media-row">
      <div class="pm-avatar pm-box">
        <img id="avatarPreviewImg" src="<?php echo $avatar; ?>" alt="avatar" />
        <button type="button" class="pm-edit pm-avatar" title="<?php echo customLang('change_avatar') ?? 'Change avatar'; ?>">
          <?php echo renderVerifiedBadge($iconPath . 'image.svg', true); ?>
        </button>
        <input type="file" name="avatar" accept="image/*" class="none" />
      </div>
      <div class="pm-cover pm-box<?php echo $hasCover ? '' : ' pm-cover--empty'; ?>">
        <img id="coverPreviewImg" src="<?php echo $hasCover ? $cover : ''; ?>" alt="cover" />
        <button type="button" class="pm-edit pm-cover" title="<?php echo customLang('change_cover') ?? 'Change cover'; ?>">
          <?php echo renderVerifiedBadge($iconPath . 'image.svg', true); ?>
        </button>
        <input type="file" name="cover" accept="image/*" class="none" />
      </div>
    </div>

    <div class="pp-actions sp-actions">
      <button type="submit" class="pp-save"><?php echo customLang('save_changes'); ?></button>
    </div>
    <div class="pp-alert none" role="alert" aria-live="polite"></div>
    <div class="pp-hint sp-hint"><?php echo customLang('profile_save_note'); ?></div>
  </form>
</section>
