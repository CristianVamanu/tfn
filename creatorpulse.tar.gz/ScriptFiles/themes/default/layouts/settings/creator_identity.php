<?php
if (!isset($loggedIn) || $loggedIn !== '1' || !isset($userData)) {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}
$csrf = generateCsrfToken();
$status = isset($creatorStatus) ? strtolower((string)$creatorStatus) : 'none';
$verification = isset($creatorVerification) && is_array($creatorVerification) ? $creatorVerification : [];
$documents = isset($verification['documents']) && is_array($verification['documents']) ? $verification['documents'] : [];
$submittedAt = isset($verification['created_at']) && (int)$verification['created_at'] > 0 ? date('d.m.Y H:i', (int)$verification['created_at']) : null;
$adminNote = isset($verification['admin_note']) ? (string)$verification['admin_note'] : '';
$userNote = isset($verification['notes']) ? (string)$verification['notes'] : '';
?>
<section class="settings-section creator-settings">
  <div class="title"><?php echo customLang('creator_identity_title', 'Become a creator'); ?></div>
  <p class="description"><?php echo customLang('creator_identity_intro', 'Upload the required identity documents so the admin team can verify your creator account. Clear photos of government-issued IDs are mandatory.'); ?></p>

  <div class="creator-status-card">
    <div class="creator-status-card__row">
      <span class="creator-status-card__label"><?php echo customLang('creator_identity_status', 'Status'); ?>:</span>
      <span class="creator-status-card__value creator-status-card__value--<?php echo iN_HelpSecure($status, false); ?>"><?php echo ucwords($status); ?></span>
    </div>
    <?php if ($submittedAt): ?>
      <div class="creator-status-card__row">
        <span class="creator-status-card__label"><?php echo customLang('creator_identity_submitted_at', 'Submitted at'); ?>:</span>
        <span class="creator-status-card__value"><?php echo iN_HelpSecure($submittedAt, false); ?></span>
      </div>
    <?php endif; ?>
    <?php if ($adminNote !== ''): ?>
      <div class="creator-status-card__row creator-status-card__row--note">
        <span class="creator-status-card__label"><?php echo customLang('creator_identity_admin_note', 'Admin feedback'); ?>:</span>
        <p class="creator-status-card__note"><?php echo nl2br(iN_HelpSecure($adminNote, false)); ?></p>
      </div>
    <?php endif; ?>
  </div>

  <?php if (!empty($documents)): ?>
    <div class="creator-documents">
      <div class="creator-documents__title"><?php echo customLang('creator_identity_uploaded_docs', 'Uploaded documents'); ?></div>
      <ul class="creator-documents__list">
        <?php foreach ($documents as $key => $value): ?>
          <?php if (is_array($value)): ?>
            <?php foreach ($value as $idx => $path): ?>
              <?php $label = ucfirst(str_replace('_', ' ', (string)$key)) . ' #' . ((int)$idx + 1); ?>
              <li><a href="<?php echo iN_HelpSecure(($base_url ?? '/') . ltrim((string)$path, '/'), false); ?>" target="_blank" rel="noopener"><?php echo iN_HelpSecure($label, false); ?></a></li>
            <?php endforeach; ?>
          <?php else: ?>
            <?php $label = ucfirst(str_replace('_', ' ', (string)$key)); ?>
            <li><a href="<?php echo iN_HelpSecure(($base_url ?? '/') . ltrim((string)$value, '/'), false); ?>" target="_blank" rel="noopener"><?php echo iN_HelpSecure($label, false); ?></a></li>
          <?php endif; ?>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <form id="creator-identity-form" class="creator-form" method="post" action="<?php echo iN_HelpSecure($base_url . 'request/requests.php'); ?>" enctype="multipart/form-data" novalidate>
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8'); ?>" />
    <input type="hidden" name="p" value="creator_identity_submit" />

    <fieldset class="creator-form__group">
      <legend><?php echo customLang('creator_identity_required_title', 'Required documents'); ?></legend>
      <label class="creator-input">
        <span><?php echo customLang('creator_identity_id_front', 'Government ID - front'); ?></span>
        <input type="file" name="id_front" accept="image/jpeg,image/png,image/webp" required>
      </label>
      <label class="creator-input">
        <span><?php echo customLang('creator_identity_id_back', 'Government ID - back'); ?></span>
        <input type="file" name="id_back" accept="image/jpeg,image/png,image/webp" required>
      </label>
    </fieldset>

    <fieldset class="creator-form__group">
      <legend><?php echo customLang('creator_identity_optional_title', 'Optional supporting files'); ?></legend>
      <label class="creator-input">
        <span><?php echo customLang('creator_identity_passport', 'Passport (optional)'); ?></span>
        <input type="file" name="passport" accept="image/jpeg,image/png,image/webp">
      </label>
      <label class="creator-input">
        <span><?php echo customLang('creator_identity_driver_license', 'Driver license (optional)'); ?></span>
        <input type="file" name="driver_license" accept="image/jpeg,image/png,image/webp">
      </label>
      <label class="creator-input">
        <span><?php echo customLang('creator_identity_selfie', 'Selfie with document (optional)'); ?></span>
        <input type="file" name="selfie" accept="image/jpeg,image/png,image/webp">
      </label>
      <label class="creator-input">
        <span><?php echo customLang('creator_identity_extra', 'Additional files (optional)'); ?></span>
        <input type="file" name="additional_docs[]" accept="image/jpeg,image/png,image/webp" multiple>
      </label>
    </fieldset>

    <label class="creator-input creator-input--textarea">
      <span><?php echo customLang('creator_identity_notes', 'Notes for the reviewers'); ?></span>
      <textarea name="notes" rows="3" placeholder="<?php echo customLang('creator_identity_notes_hint', 'Explain any special circumstances or additional context.'); ?>"><?php echo htmlspecialchars($userNote, ENT_QUOTES, 'UTF-8'); ?></textarea>
    </label>

    <div class="creator-form__actions">
      <button type="submit" class="btn-primary"><?php echo customLang('submit_for_review', 'Submit for review'); ?></button>
      <div class="creator-form__alert" role="alert" aria-live="polite"></div>
    </div>
  </form>
</section>
