<?php
if (!isset($loggedIn) || $loggedIn !== '1') {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}

$userId = isset($userID) ? (int) $userID : 0;
if ($userId <= 0) {
    echo '<div class="settings-placeholder">' . customLang('login_required') . '</div>';
    return;
}

$currencyCode = isset($currency) ? strtoupper((string) $currency) : 'USD';
$currencyMap  = isset($currencys) && is_array($currencys) ? $currencys : [];
$currencySymbol = isset($currencyMap[$currencyCode]) ? (string) $currencyMap[$currencyCode] : '$';

$formatMoney = static function($amount) use ($currencySymbol, $currencyCode): string {
    $numeric = is_numeric($amount) ? (float) $amount : 0.0;
    return dz_format_currency(
        $numeric,
        $currencyCode,
        $currencySymbol,
        $GLOBALS['currency_format_settings'] ?? null
    );
};

$formatDate = static function($value): string {
    if (is_numeric($value)) {
        $timestamp = (int) $value;
        if ($timestamp > 0) {
            return date('d.m.Y H:i', $timestamp);
        }
    } elseif ($value instanceof DateTimeInterface) {
        return $value->format('d.m.Y H:i');
    } elseif (is_string($value) && trim($value) !== '') {
        return $value;
    }
    return customLang('settings_payments_unknown_time');
};

$formatRenewalDate = static function($value) use ($formatDate): string {
    if (is_numeric($value)) {
        $timestamp = (int) $value;
        if ($timestamp > 0) {
            return date('d.m.Y', $timestamp);
        }
    }
    return $formatDate($value);
};

$baseProfileRoot = '';
if (!empty($base_url)) {
    $baseProfileRoot = rtrim((string) $base_url, '/');
} elseif (!empty($baseUrl)) {
    $baseProfileRoot = rtrim((string) $baseUrl, '/');
}

$buildProfileLink = static function (?string $username) use ($baseProfileRoot): string {
    $candidate = trim((string) $username);
    if ($candidate === '') {
        return '';
    }
    $candidate = ltrim($candidate, '@');
    if ($candidate === '') {
        return '';
    }
    $path = 'profile/' . rawurlencode($candidate);
    if ($baseProfileRoot === '') {
        return $path;
    }
    return $baseProfileRoot . '/' . $path;
};

$resolveAvatarUrl = static function (?string $path): string {
    $candidate = trim((string) $path);
    if ($candidate === '') {
        $candidate = 'uploads/user_avatars/default.jpeg';
    }
    return storage_url($candidate);
};

$buildPostLink = static function (int $postId, ?string $ownerUsername) use ($baseProfileRoot): string {
    if ($postId <= 0) {
        return '';
    }
    $slug = trim((string) $ownerUsername);
    $path = 'posts/' . $postId;
    if ($slug !== '') {
        $path .= '/' . rawurlencode($slug);
    }
    if ($baseProfileRoot === '') {
        return $path;
    }
    return $baseProfileRoot . '/' . $path;
};

$buildEbookLink = static function (?string $slug) use ($baseProfileRoot): string {
    $slug = trim((string) $slug);
    if ($slug === '') {
        return '';
    }
    $path = 'ebook/' . rawurlencode($slug);
    if ($baseProfileRoot === '') {
        return $path;
    }
    return $baseProfileRoot . '/' . $path;
};

$formatPlanLabel = static function (?string $interval, ?int $count): string {
    $interval = strtolower(trim((string) $interval));
    $count = (int) ($count ?? 1);
    if ($count <= 0) {
        $count = 1;
    }
    $map = [
        'day' => customLang('settings_payments_plan_daily'),
        'daily' => customLang('settings_payments_plan_daily'),
        'week' => customLang('settings_payments_plan_weekly'),
        'weekly' => customLang('settings_payments_plan_weekly'),
        'month' => customLang('settings_payments_plan_monthly'),
        'monthly' => customLang('settings_payments_plan_monthly'),
        'year' => customLang('settings_payments_plan_yearly'),
        'yearly' => customLang('settings_payments_plan_yearly'),
    ];
    $label = $map[$interval] ?? ($interval !== '' ? ucfirst($interval) : customLang('settings_payments_plan_fallback'));
    return $count > 1 ? ($count . '× ' . $label) : $label;
};

$statusLabels = [
    'succeeded' => customLang('settings_super_thanks_status_succeeded'),
    'paid'      => customLang('settings_super_thanks_status_paid'),
    'completed' => customLang('settings_super_thanks_status_completed'),
    'pending'   => customLang('settings_super_thanks_status_pending'),
    'processing'=> customLang('settings_super_thanks_status_processing'),
    'failed'    => customLang('settings_super_thanks_status_failed'),
    'canceled'  => customLang('settings_super_thanks_status_canceled'),
    'cancelled' => customLang('settings_super_thanks_status_canceled'),
    'refunded'  => customLang('settings_super_thanks_status_refunded'),
    'active'    => customLang('settings_payments_status_active'),
    'incomplete'=> customLang('settings_payments_status_incomplete'),
];

$statusBadgeMap = [
    'succeeded' => 'status-badge--success',
    'paid'      => 'status-badge--success',
    'completed' => 'status-badge--success',
    'active'    => 'status-badge--success',
    'pending'   => 'status-badge--pending',
    'processing'=> 'status-badge--pending',
    'incomplete'=> 'status-badge--pending',
    'failed'    => 'status-badge--danger',
    'canceled'  => 'status-badge--danger',
    'cancelled' => 'status-badge--danger',
    'refunded'  => 'status-badge--neutral',
];

$typeLabels = [
    'subscription' => customLang('settings_payments_type_subscription'),
    'tip'          => customLang('settings_payments_type_tip'),
    'purchase'     => customLang('settings_payments_type_purchase'),
    'ebook'        => customLang('settings_payments_type_ebook', 'eBook'),
    'audio_room_ticket' => customLang('settings_payments_type_audio_room_ticket', 'Audio Room ticket'),
    'audio_room_tip' => customLang('settings_payments_type_audio_room_tip', 'Audio Room tip'),
];

$stripeProviderLabel = customLang('pay_provider_stripe');
if (!is_string($stripeProviderLabel) || $stripeProviderLabel === '' || $stripeProviderLabel === 'pay_provider_stripe') {
    $stripeProviderLabel = 'Stripe';
}
$paypalProviderLabel = customLang('pay_provider_paypal');
if (!is_string($paypalProviderLabel) || $paypalProviderLabel === '' || $paypalProviderLabel === 'pay_provider_paypal') {
    $paypalProviderLabel = 'PayPal';
}
$nowProviderLabel = customLang('pay_provider_nowpayments');
if (!is_string($nowProviderLabel) || $nowProviderLabel === '' || $nowProviderLabel === 'pay_provider_nowpayments') {
    $nowProviderLabel = 'NOWPayments';
}
$coinbaseProviderLabel = customLang('pay_provider_coinbase');
if (!is_string($coinbaseProviderLabel) || $coinbaseProviderLabel === '' || $coinbaseProviderLabel === 'pay_provider_coinbase') {
    $coinbaseProviderLabel = 'Coinbase Commerce';
}
$flutterwaveProviderLabel = customLang('pay_provider_flutterwave');
if (!is_string($flutterwaveProviderLabel) || $flutterwaveProviderLabel === '' || $flutterwaveProviderLabel === 'pay_provider_flutterwave') {
    $flutterwaveProviderLabel = 'Flutterwave';
}
$iyzicoProviderLabel = customLang('pay_provider_iyzico');
if (!is_string($iyzicoProviderLabel) || $iyzicoProviderLabel === '' || $iyzicoProviderLabel === 'pay_provider_iyzico') {
    $iyzicoProviderLabel = 'IyziCo';
}
$payuProviderLabel = customLang('pay_provider_payu');
if (!is_string($payuProviderLabel) || $payuProviderLabel === '' || $payuProviderLabel === 'pay_provider_payu') {
    $payuProviderLabel = 'PayU';
}
$walletProviderLabel = 'Wallet';
$walletLang = customLang('pay_provider_wallet');
if (is_string($walletLang) && $walletLang !== '' && $walletLang !== 'pay_provider_wallet') {
    $walletProviderTrimmed = trim((string) preg_replace('~\\s*\\(.*$~', '', $walletLang));
    if ($walletProviderTrimmed !== '') {
        $walletProviderLabel = $walletProviderTrimmed;
    }
}
$bankProviderLabel = 'Bank transfer';
$manualProviderLabel = 'Manual';

$providerLabelMap = [
    'stripe'                 => $stripeProviderLabel,
    'stripecheckout'         => $stripeProviderLabel,
    'stripecheckoutsession'  => $stripeProviderLabel,
    'stripepaymentintent'    => $stripeProviderLabel,
    'stripecustomerportal'   => $stripeProviderLabel,
    'paypal'                 => $paypalProviderLabel,
    'paypalsubscription'     => $paypalProviderLabel,
    'paypalcheckout'         => $paypalProviderLabel,
    'paypalrest'             => $paypalProviderLabel,
    'nowpayments'            => $nowProviderLabel,
    'nowpayment'             => $nowProviderLabel,
    'coinbase'               => $coinbaseProviderLabel,
    'coinbasecommerce'       => $coinbaseProviderLabel,
    'coinbasecheckout'       => $coinbaseProviderLabel,
    'flutterwave'            => $flutterwaveProviderLabel,
    'iyzico'                 => $iyzicoProviderLabel,
    'payu'                   => $payuProviderLabel,
    'wallet'                 => $walletProviderLabel,
    'internalwallet'         => $walletProviderLabel,
    'bank'                   => $bankProviderLabel,
    'banktransfer'           => $bankProviderLabel,
    'manual'                 => $manualProviderLabel,
    'offline'                => $manualProviderLabel,
];

$formatProviderLabel = static function (?string $value) use ($providerLabelMap, $stripeProviderLabel): string {
    $raw = trim((string) $value);
    if ($raw === '') {
        return '';
    }
    $normalized = strtolower(preg_replace('~[^a-z0-9]+~', '', $raw));
    if (isset($providerLabelMap[$normalized])) {
        return $providerLabelMap[$normalized];
    }
    if (preg_match('/^(cs|pi|si|seti|sub)_[a-z0-9]+/i', $raw)) {
        return $stripeProviderLabel;
    }
    return $raw;
};

$invoiceRoot = $baseProfileRoot !== '' ? $baseProfileRoot . '/invoice' : 'invoice';
$buildInvoiceLink = static function (string $type, int $id) use ($invoiceRoot): string {
    if ($id <= 0) {
        return '';
    }
    $type = strtolower($type);
    if (!in_array($type, ['subscription', 'tip', 'purchase', 'ebook', 'audio_room_ticket', 'audio_room_tip'], true)) {
        $type = 'tip';
    }
    return $invoiceRoot . '/' . rawurlencode(str_replace('_', '-', $type)) . '/' . $id;
};

$spendSummary = [
    'total'             => 0.0,
    'subscriptions'     => 0.0,
    'subscription_count'=> 0,
    'tips'              => 0.0,
    'tip_count'         => 0,
    'purchases'         => 0.0,
    'purchase_count'    => 0,
    'ebooks'            => 0.0,
    'ebook_count'       => 0,
    'audio_room_tips'   => 0.0,
    'audio_room_tip_count' => 0,
    'audio_room_tickets'=> 0.0,
    'audio_room_ticket_count' => 0,
];

$chartData = [
    'labels'  => [],
    'weekly'  => [],
    'monthly' => [],
];

$subscriptionRows = [];
$subscriptionTotal = 0;
$subscriptionPages = 1;
$subscriptionSummaryText = '';
$subscriptionPagination = '';

$transactionRows = [];
$transactionTotal = 0;
$transactionPages = 1;
$transactionSummaryText = '';
$transactionPagination = '';

$subscriptionSortMap = [
    'date'     => 'created_at',
    'amount'   => 'amount',
    'status'   => 'status',
    'renewal'  => 'current_period_end',
];

$transactionSortMap = [
    'date'   => 'created_at',
    'amount' => 'gross_amount',
    'net'    => 'net_amount',
    'status' => 'status',
    'type'   => 'source_type',
];

$subscriptionSort = isset($_GET['subs_sort']) ? strtolower(preg_replace('~[^a-z_]~', '', (string) $_GET['subs_sort'])) : 'date';
if (!array_key_exists($subscriptionSort, $subscriptionSortMap)) {
    $subscriptionSort = 'date';
}
$subscriptionDir = isset($_GET['subs_dir']) && strtolower((string) $_GET['subs_dir']) === 'asc' ? 'asc' : 'desc';
$subscriptionPerPage = isset($_GET['subs_per']) ? (int) $_GET['subs_per'] : 20;
$subscriptionPerPage = max(5, min(50, $subscriptionPerPage));
$subscriptionPage = isset($_GET['subs_page']) ? (int) $_GET['subs_page'] : 1;
if ($subscriptionPage < 1) {
    $subscriptionPage = 1;
}

$transactionSort = isset($_GET['txn_sort']) ? strtolower(preg_replace('~[^a-z_]~', '', (string) $_GET['txn_sort'])) : 'date';
if (!array_key_exists($transactionSort, $transactionSortMap)) {
    $transactionSort = 'date';
}
$transactionDir = isset($_GET['txn_dir']) && strtolower((string) $_GET['txn_dir']) === 'asc' ? 'asc' : 'desc';
$transactionPerPage = isset($_GET['txn_per']) ? (int) $_GET['txn_per'] : 20;
$transactionPerPage = max(5, min(50, $transactionPerPage));
$transactionPage = isset($_GET['txn_page']) ? (int) $_GET['txn_page'] : 1;
if ($transactionPage < 1) {
    $transactionPage = 1;
}

$pdo = null;
if (isset($RL) && is_object($RL) && method_exists($RL, 'getDb')) {
    $pdo = $RL->getDb();
} elseif (isset($db) && $db instanceof PDO) {
    $pdo = $db;
}

if ($pdo instanceof PDO) {
    try {
        $subscriptionSuccessStatuses = ['succeeded', 'paid', 'completed', 'active'];
        $transactionSuccessStatuses = ['succeeded', 'paid', 'completed'];

        // Summary: subscriptions
        $subStatusPlaceholders = [];
        foreach ($subscriptionSuccessStatuses as $idx => $_) {
            $subStatusPlaceholders[] = ':sub_status_' . $idx;
        }
        $subSummarySql = 'SELECT SUM(COALESCE(amount, 0)) AS total_amount, COUNT(*) AS total_count
                          FROM i_subscription_payments
                          WHERE buyer_id = :uid AND status IN (' . implode(',', $subStatusPlaceholders) . ')';
        $subSummaryStmt = $pdo->prepare($subSummarySql);
        $subSummaryStmt->bindValue(':uid', $userId, PDO::PARAM_INT);
        foreach ($subscriptionSuccessStatuses as $idx => $status) {
            $subSummaryStmt->bindValue(':sub_status_' . $idx, $status, PDO::PARAM_STR);
        }
        $subSummaryStmt->execute();
        $subSummaryRow = $subSummaryStmt->fetch(PDO::FETCH_ASSOC) ?: [];
        $spendSummary['subscriptions'] = isset($subSummaryRow['total_amount']) ? (float) $subSummaryRow['total_amount'] : 0.0;
        $spendSummary['subscription_count'] = isset($subSummaryRow['total_count']) ? (int) $subSummaryRow['total_count'] : 0;

        // Summary: tips
        $txnStatusPlaceholders = [];
        foreach ($transactionSuccessStatuses as $idx => $_) {
            $txnStatusPlaceholders[] = ':txn_status_' . $idx;
        }
        $tipSummarySql = 'SELECT SUM(COALESCE(net_amount, amount, 0)) AS total_amount, COUNT(*) AS total_count
                          FROM i_tip_payments
                          WHERE buyer_id = :uid AND status IN (' . implode(',', $txnStatusPlaceholders) . ')
                            AND NOT EXISTS (
                                SELECT 1 FROM i_audio_room_tip_events arev
                                WHERE arev.provider = i_tip_payments.provider
                                  AND arev.reference = i_tip_payments.reference
                            )';
        $tipSummaryStmt = $pdo->prepare($tipSummarySql);
        $tipSummaryStmt->bindValue(':uid', $userId, PDO::PARAM_INT);
        foreach ($transactionSuccessStatuses as $idx => $status) {
            $tipSummaryStmt->bindValue(':txn_status_' . $idx, $status, PDO::PARAM_STR);
        }
        $tipSummaryStmt->execute();
        $tipSummaryRow = $tipSummaryStmt->fetch(PDO::FETCH_ASSOC) ?: [];
        $spendSummary['tips'] = isset($tipSummaryRow['total_amount']) ? (float) $tipSummaryRow['total_amount'] : 0.0;
        $spendSummary['tip_count'] = isset($tipSummaryRow['total_count']) ? (int) $tipSummaryRow['total_count'] : 0;

        // Summary: purchases
        $purchaseSummarySql = 'SELECT SUM(COALESCE(net_amount, amount, 0)) AS total_amount, COUNT(*) AS total_count
                               FROM i_post_purchases
                               WHERE buyer_id = :uid AND status IN (' . implode(',', $txnStatusPlaceholders) . ')';
        $purchaseSummaryStmt = $pdo->prepare($purchaseSummarySql);
        $purchaseSummaryStmt->bindValue(':uid', $userId, PDO::PARAM_INT);
        foreach ($transactionSuccessStatuses as $idx => $status) {
            $purchaseSummaryStmt->bindValue(':txn_status_' . $idx, $status, PDO::PARAM_STR);
        }
        $purchaseSummaryStmt->execute();
        $purchaseSummaryRow = $purchaseSummaryStmt->fetch(PDO::FETCH_ASSOC) ?: [];
        $spendSummary['purchases'] = isset($purchaseSummaryRow['total_amount']) ? (float) $purchaseSummaryRow['total_amount'] : 0.0;
        $spendSummary['purchase_count'] = isset($purchaseSummaryRow['total_count']) ? (int) $purchaseSummaryRow['total_count'] : 0;

        // Summary: eBooks
        $ebookSummarySql = 'SELECT SUM(COALESCE(net_amount, amount, 0)) AS total_amount, COUNT(*) AS total_count
                            FROM i_ebook_purchases
                            WHERE buyer_id = :uid AND status IN (' . implode(',', $txnStatusPlaceholders) . ')';
        $ebookSummaryStmt = $pdo->prepare($ebookSummarySql);
        $ebookSummaryStmt->bindValue(':uid', $userId, PDO::PARAM_INT);
        foreach ($transactionSuccessStatuses as $idx => $status) {
            $ebookSummaryStmt->bindValue(':txn_status_' . $idx, $status, PDO::PARAM_STR);
        }
        $ebookSummaryStmt->execute();
        $ebookSummaryRow = $ebookSummaryStmt->fetch(PDO::FETCH_ASSOC) ?: [];
        $spendSummary['ebooks'] = isset($ebookSummaryRow['total_amount']) ? (float) $ebookSummaryRow['total_amount'] : 0.0;
        $spendSummary['ebook_count'] = isset($ebookSummaryRow['total_count']) ? (int) $ebookSummaryRow['total_count'] : 0;

        $audioRoomSummaryStmt = $pdo->prepare('SELECT source_type, SUM(amount) AS total_amount, COUNT(*) AS total_count
                                               FROM i_invoices
                                               WHERE buyer_id = :uid AND source_type IN ("audio_room_tip", "audio_room_ticket") AND status IN ("succeeded", "paid", "completed")
                                               GROUP BY source_type');
        $audioRoomSummaryStmt->execute([':uid' => $userId]);
        foreach ($audioRoomSummaryStmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $audioRoomSummaryRow) {
            $sourceType = (string) ($audioRoomSummaryRow['source_type'] ?? '');
            if ($sourceType === 'audio_room_tip') {
                $spendSummary['audio_room_tips'] = (float) ($audioRoomSummaryRow['total_amount'] ?? 0);
                $spendSummary['audio_room_tip_count'] = (int) ($audioRoomSummaryRow['total_count'] ?? 0);
            } elseif ($sourceType === 'audio_room_ticket') {
                $spendSummary['audio_room_tickets'] = (float) ($audioRoomSummaryRow['total_amount'] ?? 0);
                $spendSummary['audio_room_ticket_count'] = (int) ($audioRoomSummaryRow['total_count'] ?? 0);
            }
        }

        $spendSummary['total'] = $spendSummary['subscriptions'] + $spendSummary['tips'] + $spendSummary['purchases'] + $spendSummary['ebooks'] + $spendSummary['audio_room_tips'] + $spendSummary['audio_room_tickets'];

        // Chart data (last 120 days)
        $chartWindowDays = 120;
        $todayStart = strtotime(date('Y-m-d 00:00:00'));
        $chartSince = $todayStart - (($chartWindowDays - 1) * 86400);
        $chartSql = <<<SQL
SELECT source_type, created_at, amount_value, status FROM (
    SELECT 'subscription' AS source_type,
           sp.created_at AS created_at,
           COALESCE(sp.amount, 0) AS amount_value,
           COALESCE(sp.status, '') AS status
    FROM i_subscription_payments sp
    WHERE sp.buyer_id = :chart_uid_sub
  UNION ALL
    SELECT 'tip' AS source_type,
           tp.created_at AS created_at,
           COALESCE(tp.net_amount, tp.amount, 0) AS amount_value,
           COALESCE(tp.status, '') AS status
    FROM i_tip_payments tp
    WHERE tp.buyer_id = :chart_uid_tip
      AND NOT EXISTS (
          SELECT 1 FROM i_audio_room_tip_events arev
          WHERE arev.provider = tp.provider AND arev.reference = tp.reference
      )
  UNION ALL
    SELECT 'purchase' AS source_type,
           pp.created_at AS created_at,
           COALESCE(pp.net_amount, pp.amount, 0) AS amount_value,
           COALESCE(pp.status, '') AS status
    FROM i_post_purchases pp
    WHERE pp.buyer_id = :chart_uid_purchase
  UNION ALL
    SELECT 'ebook' AS source_type,
           ep.created_at AS created_at,
           COALESCE(ep.net_amount, ep.amount, 0) AS amount_value,
           COALESCE(ep.status, '') AS status
    FROM i_ebook_purchases ep
    WHERE ep.buyer_id = :chart_uid_ebook
  UNION ALL
    SELECT inv.source_type,
           inv.created_at,
           COALESCE(inv.amount, 0),
           COALESCE(inv.status, '')
    FROM i_invoices inv
    WHERE inv.buyer_id = :chart_uid_audio_room
      AND inv.source_type IN ('audio_room_tip', 'audio_room_ticket')
) AS base
WHERE base.created_at >= :chart_since
SQL;
        $chartStmt = $pdo->prepare($chartSql);
        $chartStmt->bindValue(':chart_uid_sub', $userId, PDO::PARAM_INT);
        $chartStmt->bindValue(':chart_uid_tip', $userId, PDO::PARAM_INT);
        $chartStmt->bindValue(':chart_uid_purchase', $userId, PDO::PARAM_INT);
        $chartStmt->bindValue(':chart_uid_ebook', $userId, PDO::PARAM_INT);
        $chartStmt->bindValue(':chart_uid_audio_room', $userId, PDO::PARAM_INT);
        $chartStmt->bindValue(':chart_since', $chartSince, PDO::PARAM_INT);
        $chartStmt->execute();
        $chartRows = $chartStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        $successForChart = array_flip(array_merge($subscriptionSuccessStatuses, $transactionSuccessStatuses));
        $dailySums = [];
        foreach ($chartRows as $row) {
            $ts = isset($row['created_at']) ? (int) $row['created_at'] : 0;
            if ($ts <= 0) {
                continue;
            }
            $statusKey = strtolower(trim((string) ($row['status'] ?? '')));
            if ($statusKey !== '' && !isset($successForChart[$statusKey])) {
                continue;
            }
            $dayKey = date('Y-m-d', $ts);
            if (!isset($dailySums[$dayKey])) {
                $dailySums[$dayKey] = 0.0;
            }
            $dailySums[$dayKey] += isset($row['amount_value']) ? (float) $row['amount_value'] : 0.0;
        }

        $weeksCount = 8;
        $weeklyLabels = [];
        $weeklyValues = [];
        $monthlyValues = [];
        for ($w = $weeksCount - 1; $w >= 0; $w--) {
            $weekEnd = $todayStart - ($w * 7 * 86400) + 86399;
            $weekStart = $weekEnd - (6 * 86400);
            $labelStart = date('M j', $weekStart);
            $labelEnd = date('M j', $weekEnd);
            $weeklyLabels[] = $labelStart . ' – ' . $labelEnd;

            $weeklySum = 0.0;
            for ($d = 0; $d < 7; $d++) {
                $dayTs = $weekStart + ($d * 86400);
                $dayKey = date('Y-m-d', $dayTs);
                $weeklySum += $dailySums[$dayKey] ?? 0.0;
            }

            $monthlySum = 0.0;
            $monthStart = $weekEnd - (29 * 86400);
            for ($dayTs = $monthStart; $dayTs <= $weekEnd; $dayTs += 86400) {
                $dayKey = date('Y-m-d', $dayTs);
                $monthlySum += $dailySums[$dayKey] ?? 0.0;
            }

            $weeklyValues[] = round($weeklySum, 2);
            $monthlyValues[] = round($monthlySum, 2);
        }

        $chartData = [
            'labels'  => $weeklyLabels,
            'weekly'  => $weeklyValues,
            'monthly' => $monthlyValues,
        ];

        // Subscription table
        $subscriptionCountSql = 'SELECT COUNT(*) FROM i_subscription_payments WHERE buyer_id = :uid';
        $subscriptionCountStmt = $pdo->prepare($subscriptionCountSql);
        $subscriptionCountStmt->bindValue(':uid', $userId, PDO::PARAM_INT);
        $subscriptionCountStmt->execute();
        $subscriptionTotal = (int) $subscriptionCountStmt->fetchColumn();
        $subscriptionPages = max(1, (int) ceil($subscriptionTotal / $subscriptionPerPage));
        if ($subscriptionPage > $subscriptionPages) {
            $subscriptionPage = $subscriptionPages;
        }
        $subscriptionOffset = ($subscriptionPage - 1) * $subscriptionPerPage;

        $subscriptionOrderColumn = $subscriptionSortMap[$subscriptionSort] ?? 'created_at';
        $subscriptionOrderExpr = 'sp.' . $subscriptionOrderColumn;
        if ($subscriptionOrderColumn === 'status') {
            $subscriptionOrderExpr = 'LOWER(' . $subscriptionOrderExpr . ')';
        }
        $subscriptionOrderDir = strtoupper($subscriptionDir) === 'ASC' ? 'ASC' : 'DESC';

        $subscriptionDataSql = 'SELECT sp.*, 
                                       recip.username AS recipient_username,
                                       COALESCE(recip.user_fullname, recip.username) AS recipient_fullname,
                                       recip.user_avatar AS recipient_avatar
                                FROM i_subscription_payments sp
                                LEFT JOIN i_users recip ON recip.user_id = sp.recipient_id
                                WHERE sp.buyer_id = :uid
                                ORDER BY ' . $subscriptionOrderExpr . ' ' . $subscriptionOrderDir . ', sp.created_at DESC
                                LIMIT :limit OFFSET :offset';
        $subscriptionDataStmt = $pdo->prepare($subscriptionDataSql);
        $subscriptionDataStmt->bindValue(':uid', $userId, PDO::PARAM_INT);
        $subscriptionDataStmt->bindValue(':limit', $subscriptionPerPage, PDO::PARAM_INT);
        $subscriptionDataStmt->bindValue(':offset', $subscriptionOffset, PDO::PARAM_INT);
        $subscriptionDataStmt->execute();
        $subscriptionRawRows = $subscriptionDataStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        foreach ($subscriptionRawRows as $row) {
            $providerRaw = (string) ($row['provider'] ?? '');
            $statusKey = strtolower(trim((string) ($row['status'] ?? '')));
            if ($statusKey === '') {
                $statusKey = 'pending';
            }
            $subscriptionRows[] = [
                'id'                => (int) ($row['id'] ?? 0),
                'creator_display'   => ($row['recipient_fullname'] ?? '') !== '' ? (string) $row['recipient_fullname'] : ((string) ($row['recipient_username'] ?? '') !== '' ? (string) $row['recipient_username'] : customLang('settings_payments_unknown_creator')),
                'creator_username'  => (string) ($row['recipient_username'] ?? ''),
                'creator_url'       => $buildProfileLink($row['recipient_username'] ?? ''),
                'creator_avatar'    => $resolveAvatarUrl($row['recipient_avatar'] ?? ''),
                'plan_label'        => $formatPlanLabel($row['plan_interval'] ?? '', isset($row['interval_count']) ? (int) $row['interval_count'] : 1),
                'amount'            => isset($row['amount']) ? (float) $row['amount'] : 0.0,
                'status_label'      => $statusLabels[$statusKey] ?? ucfirst($statusKey),
                'status_class'      => $statusBadgeMap[$statusKey] ?? 'status-badge--neutral',
                'renewal_at'        => isset($row['current_period_end']) ? (int) $row['current_period_end'] : 0,
                'created_at'        => isset($row['created_at']) ? (int) $row['created_at'] : 0,
                'provider'          => $providerRaw,
                'provider_label'    => $formatProviderLabel($providerRaw),
                'reference'         => (string) ($row['reference'] ?? ''),
                'invoice_url'       => $buildInvoiceLink('subscription', (int) ($row['id'] ?? 0)),
            ];
        }

        if ($subscriptionTotal > 0) {
            $rangeStart = ($subscriptionPage - 1) * $subscriptionPerPage + 1;
            $rangeEnd = min($subscriptionTotal, $subscriptionPage * $subscriptionPerPage);
            $subscriptionSummaryText = sprintf(
                customLang('settings_payments_subscription_summary'),
                $rangeStart,
                $rangeEnd,
                $subscriptionTotal
            );
        }

        if ($subscriptionPages > 1 && function_exists('dz_render_pagination')) {
            $subsPaginationParams = [];
            foreach ($_GET as $key => $value) {
                if ($key === 'csrf_token' || $key === 'csrftoken') {
                    continue;
                }
                if (is_array($value)) {
                    continue;
                }
                $subsPaginationParams[$key] = $value;
            }
            $subsPaginationParams['tab'] = 'payments';
            $subsPaginationParams['subs_sort'] = $subscriptionSort;
            $subsPaginationParams['subs_dir'] = $subscriptionDir;
            $subsPaginationParams['subs_per'] = (string) $subscriptionPerPage;
            $subscriptionPagination = dz_render_pagination(rtrim((string) $base_url, '/') . '/settings', $subsPaginationParams, $subscriptionPage, $subscriptionPages, ['radius' => 1]);
        }

        // Other transactions table (tips + purchases)
        $transactionCountSql = 'SELECT COUNT(*) FROM (
                                    SELECT tp.id FROM i_tip_payments tp
                                    WHERE tp.buyer_id = :uid_tip
                                      AND NOT EXISTS (
                                          SELECT 1 FROM i_audio_room_tip_events arev
                                          WHERE arev.provider = tp.provider AND arev.reference = tp.reference
                                      )
                                    UNION ALL
                                    SELECT pp.id FROM i_post_purchases pp WHERE pp.buyer_id = :uid_purchase
                                    UNION ALL
                                    SELECT ep.purchase_id FROM i_ebook_purchases ep WHERE ep.buyer_id = :uid_ebook
                                    UNION ALL
                                    SELECT inv.invoice_id FROM i_invoices inv
                                    WHERE inv.buyer_id = :uid_audio_room AND inv.source_type IN ("audio_room_tip", "audio_room_ticket")
                                ) AS base';
        $transactionCountStmt = $pdo->prepare($transactionCountSql);
        $transactionCountStmt->bindValue(':uid_tip', $userId, PDO::PARAM_INT);
        $transactionCountStmt->bindValue(':uid_purchase', $userId, PDO::PARAM_INT);
        $transactionCountStmt->bindValue(':uid_ebook', $userId, PDO::PARAM_INT);
        $transactionCountStmt->bindValue(':uid_audio_room', $userId, PDO::PARAM_INT);
        $transactionCountStmt->execute();
        $transactionTotal = (int) $transactionCountStmt->fetchColumn();
        $transactionPages = max(1, (int) ceil($transactionTotal / $transactionPerPage));
        if ($transactionPage > $transactionPages) {
            $transactionPage = $transactionPages;
        }
        $transactionOffset = ($transactionPage - 1) * $transactionPerPage;

        $transactionOrderColumn = $transactionSortMap[$transactionSort] ?? 'created_at';
        $transactionOrderExpr = 'base.' . $transactionOrderColumn;
        if ($transactionOrderColumn === 'status' || $transactionOrderColumn === 'source_type') {
            $transactionOrderExpr = 'LOWER(' . $transactionOrderExpr . ')';
        }
        $transactionOrderDir = strtoupper($transactionDir) === 'ASC' ? 'ASC' : 'DESC';

        $transactionUnionSql = <<<SQL
SELECT
    'tip' AS source_type,
    tp.id AS source_id,
    tp.recipient_id AS recipient_id,
    tp.post_id AS post_id,
    COALESCE(tp.provider, '') AS provider,
    COALESCE(tp.reference, '') AS reference,
    COALESCE(tp.currency, '') AS currency,
    COALESCE(tp.status, '') AS status,
    COALESCE(tp.created_at, 0) AS created_at,
    COALESCE(tp.amount, 0) AS gross_amount,
    COALESCE(tp.tax_amount, 0) AS tax_amount,
    COALESCE(tp.fee_amount, 0) AS fee_amount,
    COALESCE(tp.net_amount, COALESCE(tp.amount, 0)) AS net_amount,
    0 AS ebook_id,
    '' AS ebook_title,
    '' AS ebook_slug
FROM i_tip_payments tp
WHERE tp.buyer_id = :uid_tip
  AND NOT EXISTS (
      SELECT 1 FROM i_audio_room_tip_events arev
      WHERE arev.provider = tp.provider AND arev.reference = tp.reference
  )
UNION ALL
SELECT
    'purchase' AS source_type,
    pp.id AS source_id,
    pp.recipient_id AS recipient_id,
    pp.post_id AS post_id,
    COALESCE(pp.provider, '') AS provider,
    COALESCE(pp.reference, '') AS reference,
    COALESCE(pp.currency, '') AS currency,
    COALESCE(pp.status, '') AS status,
    COALESCE(pp.created_at, 0) AS created_at,
    COALESCE(pp.amount, 0) AS gross_amount,
    COALESCE(pp.tax_amount, 0) AS tax_amount,
    COALESCE(pp.fee_amount, 0) AS fee_amount,
    COALESCE(pp.net_amount, COALESCE(pp.amount, 0)) AS net_amount,
    0 AS ebook_id,
    '' AS ebook_title,
    '' AS ebook_slug
FROM i_post_purchases pp
WHERE pp.buyer_id = :uid_purchase
UNION ALL
SELECT
    'ebook' AS source_type,
    ep.purchase_id AS source_id,
    ep.seller_id AS recipient_id,
    0 AS post_id,
    COALESCE(ep.provider, '') AS provider,
    COALESCE(ep.reference, '') AS reference,
    COALESCE(ep.currency, '') AS currency,
    COALESCE(ep.status, '') AS status,
    COALESCE(ep.created_at, 0) AS created_at,
    COALESCE(ep.amount, 0) AS gross_amount,
    COALESCE(ep.tax_amount, 0) AS tax_amount,
    COALESCE(ep.fee_amount, 0) AS fee_amount,
    COALESCE(ep.net_amount, COALESCE(ep.amount, 0)) AS net_amount,
    ep.ebook_id AS ebook_id,
    e.title AS ebook_title,
    e.slug AS ebook_slug
FROM i_ebook_purchases ep
LEFT JOIN i_ebooks e ON e.ebook_id = ep.ebook_id
WHERE ep.buyer_id = :uid_ebook
UNION ALL
SELECT
    inv.source_type AS source_type,
    inv.source_id AS source_id,
    inv.seller_id AS recipient_id,
    0 AS post_id,
    COALESCE(inv.provider, '') AS provider,
    COALESCE(inv.reference, '') AS reference,
    COALESCE(inv.currency, '') AS currency,
    COALESCE(inv.status, '') AS status,
    COALESCE(inv.created_at, 0) AS created_at,
    COALESCE(inv.amount, 0) AS gross_amount,
    COALESCE(inv.tax_amount, 0) AS tax_amount,
    COALESCE(inv.fee_amount, 0) AS fee_amount,
    COALESCE(inv.net_amount, 0) AS net_amount,
    0 AS ebook_id,
    '' AS ebook_title,
    '' AS ebook_slug
FROM i_invoices inv
WHERE inv.buyer_id = :uid_audio_room
  AND inv.source_type IN ('audio_room_tip', 'audio_room_ticket')
SQL;

        $transactionDataSql = 'SELECT base.*, 
                                      recip.username AS recipient_username,
                                      COALESCE(recip.user_fullname, recip.username) AS recipient_fullname,
                                      recip.user_avatar AS recipient_avatar,
                                      posts.post_visibility,
                                      posts.post_owner_id,
                                      owner.username AS post_owner_username
                               FROM (' . $transactionUnionSql . ') AS base
                               LEFT JOIN i_users recip ON recip.user_id = base.recipient_id
                               LEFT JOIN i_user_posts posts ON posts.post_id = base.post_id
                               LEFT JOIN i_users owner ON owner.user_id = posts.post_owner_id
                               ORDER BY ' . $transactionOrderExpr . ' ' . $transactionOrderDir . ', base.created_at DESC
                               LIMIT :limit OFFSET :offset';
        $transactionDataStmt = $pdo->prepare($transactionDataSql);
        $transactionDataStmt->bindValue(':uid_tip', $userId, PDO::PARAM_INT);
        $transactionDataStmt->bindValue(':uid_purchase', $userId, PDO::PARAM_INT);
        $transactionDataStmt->bindValue(':uid_ebook', $userId, PDO::PARAM_INT);
        $transactionDataStmt->bindValue(':uid_audio_room', $userId, PDO::PARAM_INT);
        $transactionDataStmt->bindValue(':limit', $transactionPerPage, PDO::PARAM_INT);
        $transactionDataStmt->bindValue(':offset', $transactionOffset, PDO::PARAM_INT);
        $transactionDataStmt->execute();
        $transactionRawRows = $transactionDataStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        foreach ($transactionRawRows as $row) {
            $providerRaw = (string) ($row['provider'] ?? '');
            $typeKey = strtolower((string) ($row['source_type'] ?? 'tip'));
            if (!isset($typeLabels[$typeKey])) {
                $typeKey = 'tip';
            }
            $statusKey = strtolower(trim((string) ($row['status'] ?? '')));
            if ($statusKey === '') {
                $statusKey = 'pending';
            }
            $transactionRows[] = [
                'id'               => (int) ($row['source_id'] ?? 0),
                'type_key'         => $typeKey,
                'type_label'       => $typeLabels[$typeKey],
                'creator_display'  => ($row['recipient_fullname'] ?? '') !== '' ? (string) $row['recipient_fullname'] : ((string) ($row['recipient_username'] ?? '') !== '' ? (string) $row['recipient_username'] : customLang('settings_payments_unknown_creator')),
                'creator_username' => (string) ($row['recipient_username'] ?? ''),
                'creator_url'      => $buildProfileLink($row['recipient_username'] ?? ''),
                'creator_avatar'   => $resolveAvatarUrl($row['recipient_avatar'] ?? ''),
                'post_id'          => (int) ($row['post_id'] ?? 0),
                'status_label'     => $statusLabels[$statusKey] ?? ucfirst($statusKey),
                'status_class'     => $statusBadgeMap[$statusKey] ?? 'status-badge--neutral',
                'gross'            => isset($row['gross_amount']) ? (float) $row['gross_amount'] : 0.0,
                'net'              => isset($row['net_amount']) ? (float) $row['net_amount'] : (isset($row['gross_amount']) ? (float) $row['gross_amount'] : 0.0),
                'tax'              => isset($row['tax_amount']) ? (float) $row['tax_amount'] : 0.0,
                'fee'              => isset($row['fee_amount']) ? (float) $row['fee_amount'] : 0.0,
                'provider'         => $providerRaw,
                'provider_label'   => $formatProviderLabel($providerRaw),
                'reference'        => (string) ($row['reference'] ?? ''),
                'created_at'       => isset($row['created_at']) ? (int) $row['created_at'] : 0,
                'post_url'         => $buildPostLink((int) ($row['post_id'] ?? 0), $row['post_owner_username'] ?? $row['recipient_username'] ?? ''),
                'ebook_title'      => (string) ($row['ebook_title'] ?? ''),
                'ebook_url'        => $buildEbookLink($row['ebook_slug'] ?? ''),
                'invoice_url'      => $buildInvoiceLink($typeKey, (int) ($row['source_id'] ?? 0)),
            ];
        }

        if ($transactionTotal > 0) {
            $rangeStart = ($transactionPage - 1) * $transactionPerPage + 1;
            $rangeEnd = min($transactionTotal, $transactionPage * $transactionPerPage);
            $transactionSummaryText = sprintf(
                customLang('settings_payments_transactions_summary'),
                $rangeStart,
                $rangeEnd,
                $transactionTotal
            );
        }

        if ($transactionPages > 1 && function_exists('dz_render_pagination')) {
            $txnPaginationParams = [];
            foreach ($_GET as $key => $value) {
                if ($key === 'csrf_token' || $key === 'csrftoken') {
                    continue;
                }
                if (is_array($value)) {
                    continue;
                }
                $txnPaginationParams[$key] = $value;
            }
            $txnPaginationParams['tab'] = 'payments';
            $txnPaginationParams['txn_sort'] = $transactionSort;
            $txnPaginationParams['txn_dir'] = $transactionDir;
            $txnPaginationParams['txn_per'] = (string) $transactionPerPage;
            $transactionPagination = dz_render_pagination(rtrim((string) $base_url, '/') . '/settings', $txnPaginationParams, $transactionPage, $transactionPages, ['radius' => 1]);
        }
    } catch (Throwable $e) {
        $subscriptionRows = [];
        $subscriptionTotal = 0;
        $subscriptionPages = 1;
        $subscriptionSummaryText = '';
        $subscriptionPagination = '';

        $transactionRows = [];
        $transactionTotal = 0;
        $transactionPages = 1;
        $transactionSummaryText = '';
        $transactionPagination = '';

        $chartData = [
            'labels'  => [],
            'weekly'  => [],
            'monthly' => [],
        ];

        if (defined('APP_DEBUG') && APP_DEBUG) {
            echo '<div class="settings-placeholder">' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</div>';
        }
    }
}

$chartLabelsJson = htmlspecialchars(json_encode(array_values($chartData['labels']), JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
$chartWeeklyJson = htmlspecialchars(json_encode(array_map('floatval', $chartData['weekly']), JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
$chartMonthlyJson = htmlspecialchars(json_encode(array_map('floatval', $chartData['monthly']), JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');

$chartWeeklyLabel = customLang('settings_payments_chart_weekly');
$chartMonthlyLabel = customLang('settings_payments_chart_monthly');

$buildSubscriptionUrl = static function (array $overrides = []) use ($base_url): string {
    $params = [];
    foreach ($_GET as $key => $value) {
        if ($key === 'csrf_token' || $key === 'csrftoken') {
            continue;
        }
        if (is_array($value)) {
            continue;
        }
        $params[$key] = $value;
    }
    $params['tab'] = 'payments';
    foreach ($overrides as $key => $value) {
        if ($value === null) {
            unset($params[$key]);
        } else {
            $params[$key] = $value;
        }
    }
    $query = http_build_query($params);
    return iN_HelpSecure(rtrim((string) $base_url, '/') . '/settings' . ($query !== '' ? '?' . $query : ''), false);
};

$subscriptionSortIndicator = static function (string $column) use ($subscriptionSort, $subscriptionDir, $buildSubscriptionUrl): array {
    $isActive = ($subscriptionSort === $column);
    $direction = $isActive ? $subscriptionDir : ($column === 'date' ? 'desc' : 'asc');
    $nextDir = $isActive ? ($subscriptionDir === 'desc' ? 'asc' : 'desc') : $direction;
    $url = $buildSubscriptionUrl([
        'subs_sort' => $column,
        'subs_dir'  => $nextDir,
        'subs_page' => 1,
    ]);
    return [
        'url'      => $url,
        'isActive' => $isActive,
        'dir'      => $isActive ? $subscriptionDir : null,
    ];
};

$buildTransactionUrl = static function (array $overrides = []) use ($base_url): string {
    $params = [];
    foreach ($_GET as $key => $value) {
        if ($key === 'csrf_token' || $key === 'csrftoken') {
            continue;
        }
        if (is_array($value)) {
            continue;
        }
        $params[$key] = $value;
    }
    $params['tab'] = 'payments';
    foreach ($overrides as $key => $value) {
        if ($value === null) {
            unset($params[$key]);
        } else {
            $params[$key] = $value;
        }
    }
    $query = http_build_query($params);
    return iN_HelpSecure(rtrim((string) $base_url, '/') . '/settings' . ($query !== '' ? '?' . $query : ''), false);
};

$transactionSortIndicator = static function (string $column) use ($transactionSort, $transactionDir, $buildTransactionUrl): array {
    $isActive = ($transactionSort === $column);
    $direction = $isActive ? $transactionDir : ($column === 'date' ? 'desc' : 'asc');
    $nextDir = $isActive ? ($transactionDir === 'desc' ? 'asc' : 'desc') : $direction;
    $url = $buildTransactionUrl([
        'txn_sort' => $column,
        'txn_dir'  => $nextDir,
        'txn_page' => 1,
    ]);
    return [
        'url'      => $url,
        'isActive' => $isActive,
        'dir'      => $isActive ? $transactionDir : null,
    ];
};

$kpiCards = [
    [
        'label'      => customLang('settings_payments_total_spent'),
        'amount'     => $spendSummary['total'] ?? 0.0,
        'icon'       => 'payments',
        'icon_class' => 'payments-kpi-icon--accent',
        'hint'       => customLang('settings_payments_total_hint'),
    ],
    [
        'label'      => customLang('settings_payments_subscription_spent'),
        'amount'     => $spendSummary['subscriptions'] ?? 0.0,
        'icon'       => 'subscription_fees',
        'icon_class' => 'payments-kpi-icon--primary',
        'hint'       => sprintf(customLang('settings_payments_subscription_hint'), number_format($spendSummary['subscription_count'] ?? 0)),
    ],
    [
        'label'      => customLang('settings_payments_other_spent'),
        'amount'     => ($spendSummary['tips'] ?? 0.0) + ($spendSummary['purchases'] ?? 0.0) + ($spendSummary['ebooks'] ?? 0.0),
        'icon'       => 'super_thanks',
        'icon_class' => 'payments-kpi-icon--warning',
        'hint'       => sprintf(customLang('settings_payments_other_hint'), number_format(($spendSummary['tip_count'] ?? 0) + ($spendSummary['purchase_count'] ?? 0) + ($spendSummary['ebook_count'] ?? 0))),
    ],
];
?>
<section class="card_admin settings-dashboard settings-dashboard--payments rounded-2xl" role="region" aria-labelledby="settingsPaymentsHeading">
  <h1 class="h1" id="settingsPaymentsHeading"><?= iN_HelpSecure(customLang('settings_payments_title'), false); ?></h1>
  <p class="settings-dashboard-intro"><?= iN_HelpSecure(customLang('settings_payments_intro'), false); ?></p>

  <div class="kpi-row">
    <?php foreach ($kpiCards as $card): ?>
      <article class="admin-card card kpi-card payments-kpi-card">
        <div class="kpi-left">
          <div class="kpi-title">
            <span class="kpi-icon payments-kpi-icon <?php echo $card['icon_class']; ?>">
              <?php echo render_icon($card['icon'], true); ?>
            </span>
            <?php echo iN_HelpSecure($card['label'], false); ?>
          </div>
          <div class="kpi-amount payments-kpi-amount"><?php echo iN_HelpSecure($formatMoney($card['amount']), false); ?></div>
          <div class="kpi-period payments-kpi-period"><?php echo iN_HelpSecure($card['hint'], false); ?></div>
        </div>
      </article>
    <?php endforeach; ?>
  </div>

  <div class="payments-charts super-thanks-charts">
    <div class="admin-card card chart-card payments-chart-card super-thanks-chart-card">
      <div class="chart-title"><?= iN_HelpSecure(customLang('settings_payments_chart_title'), false); ?></div>
      <div class="chart-legend">
        <span><span class="legend-dot legend-blue"></span><?php echo iN_HelpSecure($chartWeeklyLabel, false); ?></span>
        <span><span class="legend-dot legend-cyan"></span><?php echo iN_HelpSecure($chartMonthlyLabel, false); ?></span>
      </div>
      <div class="chart-box chart-box--growth">
        <canvas
          id="settingsEarningsChart"
          class="chart-canvas"
          data-labels='<?= $chartLabelsJson; ?>'
          data-weekly='<?= $chartWeeklyJson; ?>'
          data-monthly='<?= $chartMonthlyJson; ?>'
          data-weekly-label="<?= htmlspecialchars($chartWeeklyLabel, ENT_QUOTES, 'UTF-8'); ?>"
          data-monthly-label="<?= htmlspecialchars($chartMonthlyLabel, ENT_QUOTES, 'UTF-8'); ?>"
        ></canvas>
        <p class="chart-fallback"><?= iN_HelpSecure(customLang('settings_payments_chart_fallback'), false); ?></p>
      </div>
    </div>
  </div>

  <div class="payments-tables">
    <div class="admin-card card table-card payments-table-card">
      <div class="table-card__header">
        <h2 class="table-card__title"><?= iN_HelpSecure(customLang('settings_payments_subscription_table_title'), false); ?></h2>
        <p class="table-card__hint"><?= iN_HelpSecure(customLang('settings_payments_subscription_table_hint'), false); ?></p>
        <?php if ($subscriptionSummaryText !== ''): ?>
          <p class="table-card__summary"><?= iN_HelpSecure($subscriptionSummaryText, false); ?></p>
        <?php endif; ?>
      </div>
      <div class="table-card__scroll">
        <table class="earnings-table payments-table">
          <thead>
            <tr>
              <th><?= iN_HelpSecure(customLang('settings_payments_subscription_col_creator'), false); ?></th>
              <th><?= iN_HelpSecure(customLang('settings_payments_subscription_col_plan'), false); ?></th>
              <?php $subStatusSort = $subscriptionSortIndicator('status'); ?>
              <th>
                <a href="<?php echo $subStatusSort['url']; ?>" class="table-sort<?php echo $subStatusSort['isActive'] ? ' is-active' : ''; ?>">
                  <?= iN_HelpSecure(customLang('settings_payments_subscription_col_status'), false); ?>
                  <?php if ($subStatusSort['isActive']): ?><span class="sort-indicator"><?php echo $subStatusSort['dir'] === 'asc' ? '▲' : '▼'; ?></span><?php endif; ?>
                </a>
              </th>
              <?php $subAmountSort = $subscriptionSortIndicator('amount'); ?>
              <th>
                <a href="<?php echo $subAmountSort['url']; ?>" class="table-sort<?php echo $subAmountSort['isActive'] ? ' is-active' : ''; ?>">
                  <?= iN_HelpSecure(customLang('settings_payments_subscription_col_amount'), false); ?>
                  <?php if ($subAmountSort['isActive']): ?><span class="sort-indicator"><?php echo $subAmountSort['dir'] === 'asc' ? '▲' : '▼'; ?></span><?php endif; ?>
                </a>
              </th>
              <?php $subRenewalSort = $subscriptionSortIndicator('renewal'); ?>
              <th>
                <a href="<?php echo $subRenewalSort['url']; ?>" class="table-sort<?php echo $subRenewalSort['isActive'] ? ' is-active' : ''; ?>">
                  <?= iN_HelpSecure(customLang('settings_payments_subscription_col_renewal'), false); ?>
                  <?php if ($subRenewalSort['isActive']): ?><span class="sort-indicator"><?php echo $subRenewalSort['dir'] === 'asc' ? '▲' : '▼'; ?></span><?php endif; ?>
                </a>
              </th>
              <th><?= iN_HelpSecure(customLang('settings_payments_subscription_col_reference'), false); ?></th>
              <?php $subDateSort = $subscriptionSortIndicator('date'); ?>
              <th>
                <a href="<?php echo $subDateSort['url']; ?>" class="table-sort<?php echo $subDateSort['isActive'] ? ' is-active' : ''; ?>">
                  <?= iN_HelpSecure(customLang('settings_payments_subscription_col_date'), false); ?>
                  <?php if ($subDateSort['isActive']): ?><span class="sort-indicator"><?php echo $subDateSort['dir'] === 'asc' ? '▲' : '▼'; ?></span><?php endif; ?>
                </a>
              </th>
              <th><?= iN_HelpSecure(customLang('settings_payments_subscription_col_invoice'), false); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($subscriptionRows)): ?>
              <tr>
                <td colspan="8" class="earnings-empty">
                  <?= iN_HelpSecure(customLang('settings_payments_subscription_empty'), false); ?>
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($subscriptionRows as $row): ?>
                <?php $creatorAlt = sprintf(customLang('alt_avatar_of_user'), $row['creator_display']); ?>
                <tr>
                  <td class="earnings-supporter">
                    <?php if ($row['creator_url'] !== ''): ?>
                      <a href="<?php echo iN_HelpSecure($row['creator_url'], false); ?>" class="earnings-supporter__link">
                        <span class="earnings-supporter__avatar"><img src="<?php echo iN_HelpSecure($row['creator_avatar'], false); ?>" alt="<?php echo iN_HelpSecure($creatorAlt, false); ?>"></span>
                        <span class="earnings-supporter__names">
                          <span class="earnings-supporter__display"><?php echo iN_HelpSecure($row['creator_display'], false); ?></span>
                          <?php if ($row['creator_username'] !== '' && strtolower($row['creator_username']) !== strtolower($row['creator_display'])): ?>
                            <span class="earnings-supporter__username">@<?php echo iN_HelpSecure($row['creator_username'], false); ?></span>
                          <?php endif; ?>
                        </span>
                      </a>
                    <?php else: ?>
                      <span class="earnings-supporter__display"><?php echo iN_HelpSecure($row['creator_display'], false); ?></span>
                    <?php endif; ?>
                  </td>
                  <td><?php echo iN_HelpSecure($row['plan_label'], false); ?></td>
                  <td class="earnings-status"><span class="status-badge <?php echo iN_HelpSecure($row['status_class'], false); ?>"><?php echo iN_HelpSecure($row['status_label'], false); ?></span></td>
                  <td><?php echo iN_HelpSecure($formatMoney($row['amount']), false); ?></td>
                  <td><?php echo iN_HelpSecure($row['renewal_at'] > 0 ? $formatRenewalDate($row['renewal_at']) : customLang('settings_payments_subscription_no_renewal'), false); ?></td>
                  <td>
                    <div class="earnings-reference">
                      <?php if (($row['provider_label'] ?? '') !== ''): ?><span><?php echo iN_HelpSecure($row['provider_label'], false); ?> · </span><?php endif; ?>
                      <span><?php echo iN_HelpSecure($row['reference'] ?: customLang('settings_payments_reference_unknown'), false); ?></span>
                    </div>
                  </td>
                  <td><?php echo iN_HelpSecure($formatDate($row['created_at']), false); ?></td>
                  <td>
                    <?php if ($row['invoice_url'] !== ''): ?>
                      <a class="table-invoice-link" href="<?php echo iN_HelpSecure($row['invoice_url'], false); ?>" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('settings_payments_invoice_view'), false); ?></a>
                    <?php else: ?>
                      <span class="text-muted">—</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      <?php if ($subscriptionPagination !== ''): ?>
        <div class="earnings-pagination"><?php echo $subscriptionPagination; ?></div>
      <?php endif; ?>
    </div>

    <div class="admin-card card table-card payments-table-card">
      <div class="table-card__header">
        <h2 class="table-card__title"><?= iN_HelpSecure(customLang('settings_payments_transactions_table_title'), false); ?></h2>
        <p class="table-card__hint"><?= iN_HelpSecure(customLang('settings_payments_transactions_table_hint'), false); ?></p>
        <?php if ($transactionSummaryText !== ''): ?>
          <p class="table-card__summary"><?= iN_HelpSecure($transactionSummaryText, false); ?></p>
        <?php endif; ?>
      </div>
      <div class="table-card__scroll">
        <table class="earnings-table payments-table">
          <thead>
            <tr>
              <?php $txnTypeSort = $transactionSortIndicator('type'); ?>
              <th>
                <a href="<?php echo $txnTypeSort['url']; ?>" class="table-sort<?php echo $txnTypeSort['isActive'] ? ' is-active' : ''; ?>">
                  <?= iN_HelpSecure(customLang('settings_payments_transactions_col_type'), false); ?>
                  <?php if ($txnTypeSort['isActive']): ?><span class="sort-indicator"><?php echo $txnTypeSort['dir'] === 'asc' ? '▲' : '▼'; ?></span><?php endif; ?>
                </a>
              </th>
              <th><?= iN_HelpSecure(customLang('settings_payments_transactions_col_creator'), false); ?></th>
              <th><?= iN_HelpSecure(customLang('settings_payments_transactions_col_post'), false); ?></th>
              <?php $txnStatusSort = $transactionSortIndicator('status'); ?>
              <th>
                <a href="<?php echo $txnStatusSort['url']; ?>" class="table-sort<?php echo $txnStatusSort['isActive'] ? ' is-active' : ''; ?>">
                  <?= iN_HelpSecure(customLang('settings_payments_transactions_col_status'), false); ?>
                  <?php if ($txnStatusSort['isActive']): ?><span class="sort-indicator"><?php echo $txnStatusSort['dir'] === 'asc' ? '▲' : '▼'; ?></span><?php endif; ?>
                </a>
              </th>
              <?php $txnAmountSort = $transactionSortIndicator('amount'); ?>
              <th>
                <a href="<?php echo $txnAmountSort['url']; ?>" class="table-sort<?php echo $txnAmountSort['isActive'] ? ' is-active' : ''; ?>">
                  <?= iN_HelpSecure(customLang('settings_payments_transactions_col_gross'), false); ?>
                  <?php if ($txnAmountSort['isActive']): ?><span class="sort-indicator"><?php echo $txnAmountSort['dir'] === 'asc' ? '▲' : '▼'; ?></span><?php endif; ?>
                </a>
              </th>
              <th><?= iN_HelpSecure(customLang('settings_payments_transactions_col_tax'), false); ?></th>
              <th><?= iN_HelpSecure(customLang('settings_payments_transactions_col_fee'), false); ?></th>
              <?php $txnNetSort = $transactionSortIndicator('net'); ?>
              <th>
                <a href="<?php echo $txnNetSort['url']; ?>" class="table-sort<?php echo $txnNetSort['isActive'] ? ' is-active' : ''; ?>">
                  <?= iN_HelpSecure(customLang('settings_payments_transactions_col_net'), false); ?>
                  <?php if ($txnNetSort['isActive']): ?><span class="sort-indicator"><?php echo $txnNetSort['dir'] === 'asc' ? '▲' : '▼'; ?></span><?php endif; ?>
                </a>
              </th>
              <th><?= iN_HelpSecure(customLang('settings_payments_transactions_col_invoice'), false); ?></th>
              <?php $txnDateSort = $transactionSortIndicator('date'); ?>
              <th>
                <a href="<?php echo $txnDateSort['url']; ?>" class="table-sort<?php echo $txnDateSort['isActive'] ? ' is-active' : ''; ?>">
                  <?= iN_HelpSecure(customLang('settings_payments_transactions_col_date'), false); ?>
                  <?php if ($txnDateSort['isActive']): ?><span class="sort-indicator"><?php echo $txnDateSort['dir'] === 'asc' ? '▲' : '▼'; ?></span><?php endif; ?>
                </a>
              </th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($transactionRows)): ?>
              <tr>
                <td colspan="10" class="earnings-empty">
                  <?= iN_HelpSecure(customLang('settings_payments_transactions_empty'), false); ?>
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($transactionRows as $row): ?>
                <?php $creatorAlt = sprintf(customLang('alt_avatar_of_user'), $row['creator_display']); ?>
                <?php
                  $isEbookRow = ($row['type_key'] ?? '') === 'ebook';
                  $postCellLabel = $row['post_id'] > 0 ? ('#' . $row['post_id']) : customLang('settings_payments_transactions_no_post');
                  if ($isEbookRow) {
                      $postCellLabel = trim((string)($row['ebook_title'] ?? '')) !== ''
                          ? (string)$row['ebook_title']
                          : customLang('settings_payments_type_ebook', 'eBook');
                  }
                ?>
                <tr>
                  <td><?php echo iN_HelpSecure($row['type_label'], false); ?></td>
                  <td class="earnings-supporter">
                    <?php if ($row['creator_url'] !== ''): ?>
                      <a href="<?php echo iN_HelpSecure($row['creator_url'], false); ?>" class="earnings-supporter__link">
                        <span class="earnings-supporter__avatar"><img src="<?php echo iN_HelpSecure($row['creator_avatar'], false); ?>" alt="<?php echo iN_HelpSecure($creatorAlt, false); ?>"></span>
                        <span class="earnings-supporter__names">
                          <span class="earnings-supporter__display"><?php echo iN_HelpSecure($row['creator_display'], false); ?></span>
                          <?php if ($row['creator_username'] !== '' && strtolower($row['creator_username']) !== strtolower($row['creator_display'])): ?>
                            <span class="earnings-supporter__username">@<?php echo iN_HelpSecure($row['creator_username'], false); ?></span>
                          <?php endif; ?>
                        </span>
                      </a>
                    <?php else: ?>
                      <span class="earnings-supporter__display"><?php echo iN_HelpSecure($row['creator_display'], false); ?></span>
                    <?php endif; ?>
                  </td>
                  <td class="earnings-post">
                    <?php if ($isEbookRow && ($row['ebook_url'] ?? '') !== ''): ?>
                      <a href="<?php echo iN_HelpSecure($row['ebook_url'], false); ?>" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure($postCellLabel, false); ?></a>
                    <?php elseif ($row['post_url'] !== '' && $row['post_id'] > 0): ?>
                      <a href="<?php echo iN_HelpSecure($row['post_url'], false); ?>" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure($postCellLabel, false); ?></a>
                    <?php else: ?>
                      <?= iN_HelpSecure(customLang('settings_payments_transactions_no_post'), false); ?>
                    <?php endif; ?>
                  </td>
                  <td class="earnings-status"><span class="status-badge <?php echo iN_HelpSecure($row['status_class'], false); ?>"><?php echo iN_HelpSecure($row['status_label'], false); ?></span></td>
                  <td><?php echo iN_HelpSecure($formatMoney($row['gross']), false); ?></td>
                  <td><?php echo iN_HelpSecure($formatMoney($row['tax']), false); ?></td>
                  <td><?php echo iN_HelpSecure($formatMoney($row['fee']), false); ?></td>
                  <td><?php echo iN_HelpSecure($formatMoney($row['net']), false); ?></td>
                  <td>
                    <?php if ($row['invoice_url'] !== ''): ?>
                      <a class="table-invoice-link" href="<?php echo iN_HelpSecure($row['invoice_url'], false); ?>" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('settings_payments_invoice_view'), false); ?></a>
                    <?php else: ?>
                      <span class="text-muted">—</span>
                    <?php endif; ?>
                  </td>
                  <td><?php echo iN_HelpSecure($formatDate($row['created_at']), false); ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      <?php if ($transactionPagination !== ''): ?>
        <div class="earnings-pagination"><?php echo $transactionPagination; ?></div>
      <?php endif; ?>
    </div>
  </div>
</section>
