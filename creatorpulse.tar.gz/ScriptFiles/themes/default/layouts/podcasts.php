<?php
declare(strict_types=1);

$viewerId = isset($userID) ? (int) $userID : 0;
$baseUrl = isset($base_url) ? (string) $base_url : '';
$podcastsUrl = rtrim($baseUrl, '/') . '/podcasts';
$podcastsEnabled = isset($enablePodcastPosts) ? (bool) $enablePodcastPosts : true;
$adsEnabled = isset($enableAds) ? (bool) $enableAds : true;
$enableAds = $adsEnabled;
$currentLangCode = isset($currentLang) && is_string($currentLang) ? strtolower((string) $currentLang) : 'eng';
$recentLimit = 12;
$recentLimitPlusOne = $recentLimit + 1;
$recentHasMore = false;
$recentCursor = ['time' => 0, 'id' => 0];

$rawCategory = isset($_GET['category']) ? (string) $_GET['category'] : '';
$categorySlug = '';
if ($rawCategory !== '') {
    $categorySlug = strtolower(trim($rawCategory));
    $categorySlug = preg_replace('/[^a-z0-9_-]+/', '', $categorySlug);
}

$categories = [];
$categoriesRaw = [];
$categoryCounts = [];
if (isset($RL) && method_exists($RL, 'RL_GetPodcastCategories')) {
    try {
        $categoriesRaw = $RL->RL_GetPodcastCategories('active', $currentLangCode);
        $categories = $categoriesRaw;
    } catch (Throwable $__) {
        $categoriesRaw = [];
        $categories = [];
    }
}
if (isset($RL) && method_exists($RL, 'getDb')) {
    try {
        $pdo = $RL->getDb();
        $countStmt = $pdo->prepare(
            "SELECT p.podcast_category_id AS cat_id, COUNT(*) AS cnt
             FROM i_user_posts p
             INNER JOIN i_podcast_categories c ON c.id = p.podcast_category_id AND c.status = 'active'
             WHERE p.post_type = 'podcast'
               AND p.post_visibility = 'everyone'
               AND (p.approval_status IS NULL OR p.approval_status = 'approved')
             GROUP BY p.podcast_category_id"
        );
        $countStmt->execute();
        $rows = $countStmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        foreach ($rows as $row) {
            $cid = isset($row['cat_id']) ? (int) $row['cat_id'] : 0;
            $cnt = isset($row['cnt']) ? (int) $row['cnt'] : 0;
            if ($cid > 0 && $cnt > 0) {
                $categoryCounts[$cid] = $cnt;
            }
        }
    } catch (Throwable $__) {
        $categoryCounts = [];
    }
}
if ($categories) {
    $categories = array_values(array_filter($categories, static function (array $cat) use ($categoryCounts): bool {
        $id = isset($cat['id']) ? (int) $cat['id'] : 0;
        return $id > 0 && isset($categoryCounts[$id]) && $categoryCounts[$id] > 0;
    }));
}

$selectedCategory = null;
if ($categorySlug !== '') {
    foreach ($categoriesRaw as $cat) {
        $slug = isset($cat['slug']) ? strtolower((string) $cat['slug']) : '';
        if ($slug === $categorySlug) {
            $selectedCategory = $cat;
            break;
        }
    }
    if ($selectedCategory === null && isset($RL) && method_exists($RL, 'RL_GetPodcastCategoryBySlug')) {
        try {
            $selectedCategory = $RL->RL_GetPodcastCategoryBySlug($categorySlug, $currentLangCode);
        } catch (Throwable $__) {
            $selectedCategory = null;
        }
    }
    if ($selectedCategory !== null) {
        $status = strtolower((string) ($selectedCategory['status'] ?? ''));
        if ($status !== '' && $status !== 'active') {
            $selectedCategory = null;
        }
    }
}

$selectedCategoryId = $selectedCategory !== null ? (int) ($selectedCategory['id'] ?? 0) : null;
$selectedCategoryName = $selectedCategory !== null ? (string) ($selectedCategory['name'] ?? '') : '';

$podcasts = [];
if ($podcastsEnabled && isset($RL) && method_exists($RL, 'getDb')) {
    try {
        if (method_exists($RL, 'RL_EnsurePodcastCategoriesTable')) {
            $RL->RL_EnsurePodcastCategoriesTable();
        }

        $pdo = $RL->getDb();

        $sql = "SELECT
                    p.post_id,
                    p.post_owner_id,
                    p.post_text,
                    p.post_file,
                    p.audio_duration_seconds,
                    p.post_created_time,
                    p.podcast_category_id,
                    COALESCE(pct.name, pc.name)  AS podcast_category_name,
                    pc.slug  AS podcast_category_slug,
                    pc.status AS podcast_category_status,
                    u.username AS owner_username,
                    u.user_fullname AS owner_fullname,
                    u.user_avatar AS owner_avatar,
                    u.verified_status AS owner_verified
                FROM i_user_posts AS p
                INNER JOIN i_users AS u ON u.user_id = p.post_owner_id
                LEFT JOIN i_podcast_categories AS pc ON pc.id = p.podcast_category_id
                LEFT JOIN i_podcast_category_translations AS pct ON pct.category_id = pc.id AND pct.language = :lang
                WHERE p.post_type = 'podcast'
                  AND p.post_visibility = 'everyone'
                  AND (p.approval_status IS NULL OR p.approval_status = 'approved')";

        $params = [':lang' => $currentLangCode];
        if ($selectedCategoryId !== null && $selectedCategoryId > 0) {
            $sql .= ' AND p.podcast_category_id = :catId';
            $params[':catId'] = $selectedCategoryId;
        } elseif ($categorySlug !== '') {
            $sql .= ' AND pc.slug = :catSlug';
            $params[':catSlug'] = $categorySlug;
        }

        $sql .= ' ORDER BY p.post_created_time DESC, p.post_id DESC LIMIT :limit_plus';

        $stmt = $pdo->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value, is_int($value) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        $stmt->bindValue(':limit_plus', $recentLimitPlusOne, \PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];

        foreach ($rows as $row) {
            $postId = (int) ($row['post_id'] ?? 0);
            if ($postId <= 0) {
                continue;
            }

            $ownerId = (int) ($row['post_owner_id'] ?? 0);
            $ownerUsername = (string) ($row['owner_username'] ?? '');
            $ownerFullname = (string) ($row['owner_fullname'] ?? '');
            $displayName = $ownerFullname !== '' ? $ownerFullname : $ownerUsername;

            $avatarRel = (string) ($row['owner_avatar'] ?? '');
            if ($avatarRel === '' && isset($RL) && method_exists($RL, 'RL_userAvatar') && $ownerId > 0) {
                try {
                    $avatarRel = (string) $RL->RL_userAvatar($ownerId);
                } catch (Throwable $__) {
                    $avatarRel = '';
                }
            }
            if ($avatarRel === '') {
                $avatarRel = 'uploads/user_avatars/default.jpeg';
            }
            $avatarUrl = storage_url($avatarRel);

            $coverRel = '';
            if (isset($row['cover_path'])) {
                $coverRel = (string) $row['cover_path'];
            } elseif (isset($RL) && method_exists($RL, 'RL_GetPostCoverPath')) {
                try {
                    $coverRel = (string) $RL->RL_GetPostCoverPath($postId);
                } catch (Throwable $__) {
                    $coverRel = '';
                }
            }
            $coverUrl = $coverRel !== '' ? storage_url($coverRel) : '';

            $audioKey = isset($row['post_file']) ? (string) $row['post_file'] : '';
            $audioUrl = $audioKey !== '' ? storage_url($audioKey) : '';

            $podcasts[] = [
                'id'              => $postId,
                'title'           => trim((string) ($row['post_text'] ?? '')),
                'username'        => $ownerUsername,
                'fullname'        => $displayName,
                'avatar'          => $avatarUrl,
                'verified'        => (int) ($row['owner_verified'] ?? 0) === 1,
                'category_name'   => isset($row['podcast_category_name']) ? (string) $row['podcast_category_name'] : '',
                'category_slug'   => isset($row['podcast_category_slug']) ? (string) $row['podcast_category_slug'] : '',
                'duration'        => isset($row['audio_duration_seconds']) ? (int) $row['audio_duration_seconds'] : null,
                'cover_url'       => $coverUrl,
                'audio_url'       => $audioUrl,
                'liked'           => false,
                'bookmarked'      => false,
                'created_ts'      => isset($row['post_created_time']) ? (int) $row['post_created_time'] : 0,
            ];
        }
    } catch (Throwable $__) {
        $podcasts = [];
    }
}

// Fallback: if nothing returned, fetch recent public podcasts with minimal joins (only when no category filter)
if ($podcastsEnabled && $categorySlug === '' && $selectedCategoryId === null && (!$podcasts || count($podcasts) === 0) && isset($RL) && method_exists($RL, 'getDb')) {
    try {
        $pdo = $RL->getDb();
        $stmt = $pdo->prepare(
            "SELECT p.post_id, p.post_owner_id, p.post_text, p.post_file, p.audio_duration_seconds, p.post_created_time,
                    u.username AS owner_username, u.user_fullname AS owner_fullname, u.user_avatar AS owner_avatar,
                    u.verified_status AS owner_verified
             FROM i_user_posts AS p
             INNER JOIN i_users AS u ON u.user_id = p.post_owner_id
             WHERE p.post_type = 'podcast'
               AND p.post_visibility = 'everyone'
               AND (p.approval_status IS NULL OR p.approval_status = 'approved')
             ORDER BY p.post_created_time DESC, p.post_id DESC
             LIMIT :limit_plus"
        );
        $stmt->bindValue(':limit_plus', $recentLimitPlusOne, \PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        foreach ($rows as $row) {
            $postId = (int) ($row['post_id'] ?? 0);
            if ($postId <= 0) { continue; }
            $ownerId = (int) ($row['post_owner_id'] ?? 0);
            $ownerUsername = (string) ($row['owner_username'] ?? '');
            $ownerFullname = (string) ($row['owner_fullname'] ?? '');
            $displayName = $ownerFullname !== '' ? $ownerFullname : $ownerUsername;
            $avatarRel = (string) ($row['owner_avatar'] ?? '');
            if ($avatarRel === '' && isset($RL) && method_exists($RL, 'RL_userAvatar') && $ownerId > 0) {
                try {
                    $avatarRel = (string) $RL->RL_userAvatar($ownerId);
                } catch (Throwable $__) {
                    $avatarRel = '';
                }
            }
            if ($avatarRel === '') {
                $avatarRel = 'uploads/user_avatars/default.jpeg';
            }
            $avatarUrl = storage_url($avatarRel);

            $coverRel = '';
            if (isset($RL) && method_exists($RL, 'RL_GetPostCoverPath')) {
                try {
                    $coverRel = (string) $RL->RL_GetPostCoverPath($postId);
                } catch (Throwable $__) {
                    $coverRel = '';
                }
            }
            $coverUrl = $coverRel !== '' ? storage_url($coverRel) : '';

            $audioKey = isset($row['post_file']) ? (string) $row['post_file'] : '';
            $audioUrl = $audioKey !== '' ? storage_url($audioKey) : '';

            $podcasts[] = [
                'id'            => $postId,
                'title'         => trim((string) ($row['post_text'] ?? '')),
                'username'      => $ownerUsername,
                'fullname'      => $displayName,
                'avatar'        => $avatarUrl,
                'verified'      => (int) ($row['owner_verified'] ?? 0) === 1,
                'category_name' => '',
                'category_slug' => '',
                'duration'      => isset($row['audio_duration_seconds']) ? (int) $row['audio_duration_seconds'] : null,
                'cover_url'     => $coverUrl,
                'audio_url'     => $audioUrl,
                'liked'         => false,
                'bookmarked'    => false,
                'created_ts'    => isset($row['post_created_time']) ? (int) $row['post_created_time'] : 0,
            ];
        }
    } catch (Throwable $__) {
        // keep existing empty state
    }
}

// Enrich with user-like/bookmark state for current viewer (small list, safe)
if ($viewerId > 0 && $podcasts) {
    foreach ($podcasts as $idx => $podcastRow) {
        $pid = (int) ($podcastRow['id'] ?? 0);
        if ($pid <= 0) { continue; }
        // liked
        if (method_exists($RL, 'RL_HasLiked')) {
            try {
                $podcasts[$idx]['liked'] = (bool) $RL->RL_HasLiked($viewerId, $pid, 'post');
            } catch (Throwable $__) {
                $podcasts[$idx]['liked'] = false;
            }
        }
        // bookmarked
        if (method_exists($RL, 'RL_IsBookmarked')) {
            try {
                $podcasts[$idx]['bookmarked'] = (bool) $RL->RL_IsBookmarked($viewerId, $pid, 'image');
            } catch (Throwable $__) {
                $podcasts[$idx]['bookmarked'] = false;
            }
        }
    }
}

// If a category filter is present but yielded no results, try a minimal query filtered by slug or category id
if ($podcastsEnabled && ($selectedCategoryId !== null || $categorySlug !== '') && (!$podcasts || count($podcasts) === 0) && isset($RL) && method_exists($RL, 'getDb')) {
    try {
        $pdo = $RL->getDb();
        $baseSql = "SELECT p.post_id, p.post_owner_id, p.post_text, p.post_file, p.audio_duration_seconds, p.post_created_time,
                           u.username AS owner_username, u.user_fullname AS owner_fullname, u.user_avatar AS owner_avatar,
                           u.verified_status AS owner_verified
                    FROM i_user_posts AS p
                    INNER JOIN i_users AS u ON u.user_id = p.post_owner_id
                    LEFT JOIN i_podcast_categories AS pc ON pc.id = p.podcast_category_id
                    WHERE p.post_type = 'podcast'
                      AND p.post_visibility = 'everyone'
                      AND (p.approval_status IS NULL OR p.approval_status = 'approved')";
        $params = [];
        if ($selectedCategoryId !== null && $selectedCategoryId > 0) {
            $baseSql .= " AND p.podcast_category_id = :catId";
            $params[':catId'] = $selectedCategoryId;
        } elseif ($categorySlug !== '') {
            $baseSql .= " AND pc.slug = :catSlug";
            $params[':catSlug'] = $categorySlug;
        }
        $baseSql .= " ORDER BY p.post_created_time DESC, p.post_id DESC LIMIT :limit_plus";
        $stmt = $pdo->prepare($baseSql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value, is_int($value) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        $stmt->bindValue(':limit_plus', $recentLimitPlusOne, \PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        $podcasts = [];
        foreach ($rows as $row) {
            $postId = (int) ($row['post_id'] ?? 0);
            if ($postId <= 0) { continue; }
            $ownerId = (int) ($row['post_owner_id'] ?? 0);
            $ownerUsername = (string) ($row['owner_username'] ?? '');
            $ownerFullname = (string) ($row['owner_fullname'] ?? '');
            $displayName = $ownerFullname !== '' ? $ownerFullname : $ownerUsername;
            $avatarRel = (string) ($row['owner_avatar'] ?? '');
            if ($avatarRel === '' && isset($RL) && method_exists($RL, 'RL_userAvatar') && $ownerId > 0) {
                try {
                    $avatarRel = (string) $RL->RL_userAvatar($ownerId);
                } catch (Throwable $__) {
                    $avatarRel = '';
                }
            }
            if ($avatarRel === '') {
                $avatarRel = 'uploads/user_avatars/default.jpeg';
            }
            $avatarUrl = storage_url($avatarRel);
            $coverRel = '';
            if (isset($RL) && method_exists($RL, 'RL_GetPostCoverPath')) {
                try {
                    $coverRel = (string) $RL->RL_GetPostCoverPath($postId);
                } catch (Throwable $__) {
                    $coverRel = '';
                }
            }
            $coverUrl = $coverRel !== '' ? storage_url($coverRel) : '';
            $audioKey = isset($row['post_file']) ? (string) $row['post_file'] : '';
            $audioUrl = $audioKey !== '' ? storage_url($audioKey) : '';
            $podcasts[] = [
                'id'            => $postId,
                'title'         => trim((string) ($row['post_text'] ?? '')),
                'username'      => $ownerUsername,
                'fullname'      => $displayName,
                'avatar'        => $avatarUrl,
                'verified'      => (int) ($row['owner_verified'] ?? 0) === 1,
                'category_name' => '',
                'category_slug' => '',
                'duration'      => isset($row['audio_duration_seconds']) ? (int) $row['audio_duration_seconds'] : null,
                'cover_url'     => $coverUrl,
                'audio_url'     => $audioUrl,
                'liked'         => false,
                'bookmarked'    => false,
                'created_ts'    => isset($row['post_created_time']) ? (int) $row['post_created_time'] : 0,
            ];
        }
    } catch (Throwable $__) {
        // keep empty
    }
}

// Keep only playable/published podcast rows
$podcasts = array_values(array_filter($podcasts, static function (array $row): bool {
    $pid = (int) ($row['id'] ?? 0);
    if ($pid <= 0) {
        return false;
    }
    $audioUrl = trim((string) ($row['audio_url'] ?? ''));
    return $audioUrl !== '';
}));

$podcastTotal = null;
if (isset($RL) && method_exists($RL, 'getDb')) {
    try {
        $pdo = $RL->getDb();
        $countSql = "SELECT COUNT(*) AS cnt
                     FROM i_user_posts p
                     LEFT JOIN i_podcast_categories pc ON pc.id = p.podcast_category_id
                     WHERE p.post_type = 'podcast'
                       AND p.post_visibility = 'everyone'
                       AND (p.approval_status IS NULL OR p.approval_status = 'approved')";
        $countParams = [];
        if ($selectedCategoryId !== null && $selectedCategoryId > 0) {
            $countSql .= ' AND p.podcast_category_id = :catId';
            $countParams[':catId'] = $selectedCategoryId;
        } elseif ($categorySlug !== '') {
            $countSql .= ' AND pc.slug = :catSlug';
            $countParams[':catSlug'] = $categorySlug;
        }
        $stmt = $pdo->prepare($countSql);
        foreach ($countParams as $key => $value) {
            $stmt->bindValue($key, $value, is_int($value) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        $stmt->execute();
        $podcastTotal = (int) $stmt->fetchColumn();
    } catch (Throwable $__) {
        $podcastTotal = null;
    }
}

$heroAds = [];
$heroAdIds = [];
$heroClickToken = function_exists('generateCsrfToken') ? generateCsrfToken() : '';
$heroTrackingBase = rtrim($baseUrl, '/') . '/request/requests.php';
$normalizeAdTimestamp = static function ($value): ?int {
    if ($value === null) {
        return null;
    }
    if (is_int($value) || is_float($value) || (is_numeric($value) && ctype_digit((string) $value))) {
        $intVal = (int) $value;
        return $intVal > 0 ? $intVal : null;
    }
    if (is_string($value)) {
        $value = trim($value);
        if ($value === '') {
            return null;
        }
        $ts = @strtotime($value);
        return $ts && $ts > 0 ? $ts : null;
    }
    return null;
};

$filterHeroAds = static function (array $rows, int $limit = 5) use ($normalizeAdTimestamp): array {
    $nowTs = time();
    $dayStartTs = strtotime('today', $nowTs);
    $filtered = [];

    foreach ($rows as $row) {
        $startAt = $normalizeAdTimestamp($row['start_at'] ?? null);
        $endAt = $normalizeAdTimestamp($row['end_at'] ?? null);
        if ($startAt !== null && $startAt > $nowTs) {
            continue;
        }
        if ($endAt !== null && $endAt < $nowTs) {
            continue;
        }

        $impressions = isset($row['impressions']) ? (int) $row['impressions'] : 0;
        $today = isset($row['impressions_today']) ? (int) $row['impressions_today'] : 0;
        $dayStart = isset($row['impressions_day_start']) ? (int) $row['impressions_day_start'] : 0;
        if ($dayStart < $dayStartTs) {
            $dayStart = $dayStartTs;
            $today = 0;
        }

        $dailyCap = isset($row['daily_cap']) ? (int) $row['daily_cap'] : null;
        if ($dailyCap !== null && $dailyCap <= 0) {
            $dailyCap = null;
        }
        if ($dailyCap !== null && $today >= $dailyCap) {
            continue;
        }

        $totalCap = isset($row['total_cap']) ? (int) $row['total_cap'] : null;
        if ($totalCap !== null && $totalCap <= 0) {
            $totalCap = null;
        }
        if ($totalCap !== null && $impressions >= $totalCap) {
            continue;
        }

        $row['start_at'] = $startAt;
        $row['end_at'] = $endAt;
        $filtered[] = $row;
    }

    if (!$filtered) {
        return [];
    }

    usort($filtered, static function (array $a, array $b): int {
        $premiumA = !empty($a['is_premium']) ? 1 : 0;
        $premiumB = !empty($b['is_premium']) ? 1 : 0;
        if ($premiumA === $premiumB) {
            return ((int) ($b['created_at'] ?? 0)) <=> ((int) ($a['created_at'] ?? 0));
        }
        return $premiumB <=> $premiumA;
    });

    return array_slice($filtered, 0, $limit);
};

$fetchedAds = [];
if (isset($RL) && method_exists($RL, 'RL_GetActivePodcastAds')) {
    try {
        $fetchedAds = $RL->RL_GetActivePodcastAds(10);
    } catch (Throwable $__) {
        $fetchedAds = [];
    }
}

if ((!$fetchedAds || count($fetchedAds) === 0) && isset($RL) && method_exists($RL, 'getDb')) {
    try {
        $pdo = $RL->getDb();
        $stmt = $pdo->prepare(
            "SELECT a.id, a.title, a.subtitle, a.podcast_post_id, a.cta_primary_label, a.cta_primary_url, a.cta_secondary_label, a.cta_secondary_url, a.cover_path, a.start_at, a.end_at, a.status, a.is_premium, a.daily_cap, a.total_cap, a.impressions, a.impressions_today, a.impressions_day_start, a.created_at
             FROM i_podcast_ads a
             LEFT JOIN i_podcast_ad_payments pay ON pay.id = a.payment_id
             WHERE a.status IN ('approved', 'active')
               AND (pay.id IS NULL OR pay.status = 'paid')
             ORDER BY a.is_premium DESC, a.created_at DESC
             LIMIT 20"
        );
        $stmt->execute();
        $fetchedAds = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $__) {
        $fetchedAds = [];
    }
}

$fetchedAds = $filterHeroAds($fetchedAds, 5);

if ($fetchedAds) {
    try {
        $normalizeUrl = static function (string $url) use ($baseUrl) {
            $trimmed = trim($url);
            if ($trimmed === '') {
                return null;
            }
            if (strpos($trimmed, '/') === 0) {
                $trimmed = rtrim((string) $baseUrl, '/') . $trimmed;
            } elseif (!preg_match('#^https?://#i', $trimmed)) {
                $trimmed = 'https://' . ltrim($trimmed, '/');
            }
            if (!filter_var($trimmed, FILTER_VALIDATE_URL)) {
                return null;
            }
            return $trimmed;
        };
        foreach ($fetchedAds as $row) {
            $adId = (int) ($row['id'] ?? 0);
            if ($adId <= 0) {
                continue;
            }
            $podcastPostId = isset($row['podcast_post_id']) ? (int) $row['podcast_post_id'] : 0;

            $coverPath = (string) ($row['cover_path'] ?? '');
            $coverUrl = $coverPath !== '' ? storage_url($coverPath) : '';
            if ($coverUrl === '' && $coverPath !== '') {
                $coverUrl = rtrim($baseUrl, '/') . '/' . ltrim($coverPath, '/');
            }
            // If still empty, fall back to a theme icon so the ad can render
            if ($coverUrl === '') {
                $coverUrl = rtrim($baseUrl, '/') . '/themes/default/icons/podcast-c1bea17a82.svg';
            }

            $primaryLabel = trim((string) ($row['cta_primary_label'] ?? '')) ?: customLang('hero_ads_cta_primary_label', 'Listen now');
            $primaryUrlRaw = trim((string) ($row['cta_primary_url'] ?? ''));
            $primaryUrl = $normalizeUrl($primaryUrlRaw);
            if ($primaryUrl === null) {
                $primaryUrl = rtrim((string) $baseUrl, '/') . '/podcasts';
            }

            $primaryTrack = $heroTrackingBase . '?' . http_build_query([
                'p'          => 'podcast_ad_click',
                'ad_id'      => $adId,
                'which'      => 'primary',
                'csrf_token' => $heroClickToken,
            ]);

            $secondaryLabel = trim((string) ($row['cta_secondary_label'] ?? ''));
            $secondaryUrlRaw = trim((string) ($row['cta_secondary_url'] ?? ''));
            $secondaryUrl = $secondaryUrlRaw !== '' ? $normalizeUrl($secondaryUrlRaw) : null;
            $secondaryTrack = '';
            if ($secondaryLabel !== '' && $secondaryUrl !== null) {
                $secondaryTrack = $heroTrackingBase . '?' . http_build_query([
                    'p'          => 'podcast_ad_click',
                    'ad_id'      => $adId,
                    'which'      => 'secondary',
                    'csrf_token' => $heroClickToken,
                ]);
            }

            $heroAds[] = [
                'id'                   => $adId,
                'title'                => trim((string) ($row['title'] ?? '')),
                'subtitle'             => trim((string) ($row['subtitle'] ?? '')),
                'podcast_post_id'      => $podcastPostId,
                'cover_url'            => $coverUrl,
                'primary_label'        => $primaryLabel,
                'primary_track_url'    => $primaryTrack,
                'secondary_label'      => $secondaryLabel,
                'secondary_track_url'  => $secondaryTrack,
            ];
            $heroAdIds[] = $adId;
        }
    } catch (Throwable $__) {
        $heroAds = [];
        $heroAdIds = [];
    }
}

if ($heroAdIds && isset($RL) && method_exists($RL, 'RL_RecordPodcastAdImpressions')) {
    $nowTs = time();
    if (!isset($_SESSION['podcast_ad_impressions']) || !is_array($_SESSION['podcast_ad_impressions'])) {
        $_SESSION['podcast_ad_impressions'] = [];
    }
    $eligibleAdIds = [];
    foreach ($heroAdIds as $adId) {
        $lastSeen = isset($_SESSION['podcast_ad_impressions'][$adId]) ? (int) $_SESSION['podcast_ad_impressions'][$adId] : 0;
        if (($nowTs - $lastSeen) >= 300) {
            $eligibleAdIds[] = $adId;
            $_SESSION['podcast_ad_impressions'][$adId] = $nowTs;
        }
    }
    if ($eligibleAdIds) {
        try {
            $RL->RL_RecordPodcastAdImpressions($eligibleAdIds);
        } catch (Throwable $__) {
            // ignore impression failures
        }
    }
}

$heroHasAds = !empty($heroAds);
$heroCover = '';
if ($heroHasAds) {
    $heroCover = (string) ($heroAds[0]['cover_url'] ?? '');
} else {
    foreach ($podcasts as $podcastRow) {
        if (!empty($podcastRow['cover_url'])) {
            $heroCover = (string) $podcastRow['cover_url'];
            break;
        }
    }
}
$heroBgAttr = $heroCover !== '' ? ' data-hero-bg="' . iN_HelpSecure($heroCover, false) . '"' : '';

$badgeLabel = $heroHasAds
    ? customLang('hero_ads_sponsored', 'Sponsored')
    : customLang('page_podcasts_featured_badge', 'Out Now');
$headingLabel = customLang('page_podcasts_heading', 'Podcasts');
$subheadingLabel = customLang('page_podcasts_subheading', 'Stories, shows, and audio from creators.');
$primaryCta = customLang('page_podcasts_cta_primary', 'Listen now');
$secondaryCta = customLang('page_podcasts_cta_secondary', 'Learn more');
$ctaListen = customLang('hero_ads_listen_now', 'Listen now');
$ctaSee = customLang('hero_ads_see_podcast', 'See podcast');
$categoryTitle = customLang('page_podcasts_category_title', 'Category');
$categorySeeMore = customLang('page_podcasts_category_see_more', 'See More');
$categoryAllLabel = customLang('page_podcasts_category_all', 'All Podcast');
$recentTitle = customLang('page_podcasts_recent_title', 'Recent');
$recentSeeMore = customLang('page_podcasts_recent_see_more', 'See More');
$emptyStateMessage = customLang('page_podcasts_empty', 'No podcasts yet.');
$emptyAllMessage = customLang('page_podcasts_empty_all', 'Nothing to show yet.');
$playLabel = customLang('page_podcasts_play', 'Play');
$saveLabel = customLang('page_podcasts_save', 'Save');
$likeLabel = customLang('page_podcasts_like', 'Like');
$durationLabel = customLang('page_podcasts_duration_label', 'Duration');
$loadingLabel = customLang('page_podcasts_loading', 'Loading podcasts...');
$noMoreLabel = customLang('page_podcasts_no_more', 'You are all caught up.');
$carouselPrev = customLang('carousel_prev_label', 'Previous slide');
$carouselNext = customLang('carousel_next_label', 'Next slide');
$heroNavDisabled = (!$heroHasAds || count($heroAds) <= 1) ? ' disabled' : '';
$creatorStatusRaw = isset($creatorStatus) ? strtolower((string) $creatorStatus) : 'none';
$creatorApproved = $creatorStatusRaw === 'approved';
$creatorIdentityUrl = rtrim((string) ($base_url ?? ''), '/') . '/settings?tab=creator_identity';
$creatorLockTitle = customLang('podcast_ads_creator_required_title', 'Creator access required');
$creatorLockDesc = customLang('podcast_ads_creator_required_desc', 'You need an approved creator account to promote your podcast. Complete verification to unlock ads.');
$creatorLockCta = customLang('podcast_ads_creator_required_cta', 'Review creator verification');

$formatDuration = static function (?int $seconds): string {
    if ($seconds === null || $seconds < 0) {
        return '--:--';
    }
    $minutes = (int) floor($seconds / 60);
    $remaining = $seconds % 60;
    if ($minutes > 599) {
        $minutes = 599;
    }
    return sprintf('%02d:%02d', $minutes, $remaining);
};

$isLoggedIn = isset($loggedIn) && $loggedIn === '1';
$disabledMessage = !$podcastsEnabled ? customLang('content_disabled_podcasts', 'Podcast sharing is currently disabled.') : '';
$hasHeroAds = (bool) $heroHasAds;
$podcastRowTemplate = __DIR__ . '/partials/podcastRow.php';
$podcastTemplateExists = is_file($podcastRowTemplate);
$podcastVisibleCount = is_array($podcasts) ? count($podcasts) : 0;
if ($podcastTotal === 0) {
    $podcasts = [];
    $recentHasMore = false;
    $podcastVisibleCount = 0;
}
$podcastVisibleCount = $podcastTemplateExists ? $podcastVisibleCount : 0;
$podcasts = $podcastTemplateExists ? $podcasts : [];
$showPodcastsEmpty = !$hasHeroAds && $podcastVisibleCount === 0;
$emptyAllCopy = !$podcastsEnabled ? $disabledMessage : $emptyAllMessage;

if ($podcasts && count($podcasts) > $recentLimit) {
    $recentHasMore = true;
    $podcasts = array_slice($podcasts, 0, $recentLimit);
}

if ($podcasts) {
    $last = $podcasts[count($podcasts) - 1];
    $recentCursor = [
        'time' => isset($last['created_ts']) ? (int) $last['created_ts'] : 0,
        'id'   => isset($last['id']) ? (int) $last['id'] : 0,
    ];
}

?>
<div class="main-content flex align_items">
    <div class="content-area flex">
        <div class="content-left">
            <div class="content-left-container flex align_items flexBoxColumn podcasts-page">
                <?php if ($showPodcastsEmpty): ?>
                    <div class="empty-state flex align_items flexBoxColumn gap">
                        <div class="empty-state__icon flex align_items"><?php echo render_icon('not_founded', true); ?></div>
                        <div class="empty-state__title flex align_items"><?php echo iN_HelpSecure($emptyAllCopy, false); ?></div>
                    </div>
                <?php else: ?>
                    <?php if ($heroHasAds): ?>
                    <div class="podcasts-hero__head">
                        <div class="podcasts-hero__eyebrow">
                            <span class="podcasts-hero__badge"><?php echo iN_HelpSecure($badgeLabel); ?></span>
                            <?php if ($isLoggedIn && $podcastsEnabled): ?>
                                <button type="button" class="podcasts-cta podcasts-cta--ghost new_item" data-pop="podcastHeroAd" data-creator-approved="<?php echo $creatorApproved ? '1' : '0'; ?>">
                                    <?php echo iN_HelpSecure(customLang('hero_ads_promote', 'Promote podcast')); ?>
                                </button>
                            <?php endif; ?>
                        </div>
                        <div class="podcasts-hero__navs">
                            <button type="button" class="podcasts-hero__nav podcasts-hero__nav--prev" aria-label="<?php echo iN_HelpSecure($carouselPrev); ?>"<?php echo $heroNavDisabled; ?>>
                                <?php echo render_icon('prev', true) ?: '<span aria-hidden="true">←</span>'; ?>
                            </button>
                            <button type="button" class="podcasts-hero__nav podcasts-hero__nav--next" aria-label="<?php echo iN_HelpSecure($carouselNext); ?>"<?php echo $heroNavDisabled; ?>>
                                <?php echo render_icon('next', true) ?: '<span aria-hidden="true">→</span>'; ?>
                            </button>
                        </div>
                    </div>
                    <section class="podcasts-hero full-width<?php echo $heroHasAds ? ' podcasts-hero--ads' : ''; ?>" aria-label="<?php echo iN_HelpSecure($headingLabel); ?>" data-ads-count="<?php echo (int) count($heroAds); ?>" data-ad-ids="<?php echo iN_HelpSecure(implode(',', $heroAdIds)); ?>"<?php echo $heroBgAttr; ?>>
                        <div class="podcasts-hero__slides">
                            <?php foreach ($heroAds as $idx => $ad): ?>
                                <article class="podcasts-hero__slide<?php echo $idx === 0 ? ' is-active' : ''; ?>" data-ad-id="<?php echo (int) ($ad['id'] ?? 0); ?>" data-cover="<?php echo htmlspecialchars((string) ($ad['cover_url'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" aria-hidden="<?php echo $idx === 0 ? 'false' : 'true'; ?>">
                                    <div class="podcasts-hero__body">
                                        <div class="podcasts-hero__copy">
                                            <div class="podcasts-hero__eyebrow">
                                                <span class="podcasts-hero__badge"><?php echo iN_HelpSecure(customLang('hero_ads_sponsored', 'Sponsored')); ?></span>
                                            </div>
                                            <h1 class="podcasts-hero__title"><?php echo htmlspecialchars((string) ($ad['title'] !== '' ? $ad['title'] : $headingLabel), ENT_QUOTES, 'UTF-8'); ?></h1>
                                            <?php if (!empty($ad['subtitle'])): ?>
                                                <p class="podcasts-hero__subtitle"><?php echo htmlspecialchars((string) $ad['subtitle'], ENT_QUOTES, 'UTF-8'); ?></p>
                                            <?php endif; ?>
                                            <div class="podcasts-hero__actions">
                                                <a class="podcasts-cta podcasts-cta--primary" href="<?php echo iN_HelpSecure((string) $ad['primary_track_url'], false); ?>" target="_blank" rel="noopener sponsored">
                                                    <?php echo iN_HelpSecure($ctaListen); ?>
                                                </a>
                                                <?php
                                                    $adPostId = isset($ad['podcast_post_id']) ? (int) $ad['podcast_post_id'] : 0;
                                                    $secondaryUrl = (string) ($ad['secondary_track_url'] ?? '');
                                                ?>
                                                <?php if ($secondaryUrl !== ''): ?>
                                                    <a class="podcasts-cta podcasts-cta--secondary" href="<?php echo iN_HelpSecure($secondaryUrl, false); ?>" target="_blank" rel="noopener sponsored">
                                                        <?php echo iN_HelpSecure($ctaSee); ?>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                            <?php endforeach; ?>
                        </div>
                        <div class="podcasts-hero__progress" aria-hidden="true">
                            <?php foreach ($heroAds as $progressIdx => $__): ?>
                                <span class="podcasts-hero__progress-bar" data-index="<?php echo (int) $progressIdx; ?>"></span>
                            <?php endforeach; ?>
                        </div>
                    </section>
                    <?php endif; ?>

                    <div class="popUp-container flex align_items_justify_content none" id="podcastAdCreatorLock">
                        <div class="popup-wrapper create_post flex flexBoxColumn">
                            <div class="click_box_header flex align_items_justify_content">
                                <div class="full-width flex align_items_justify_content">
                                    <?php echo iN_HelpSecure($creatorLockTitle); ?>
                                </div>
                                <button type="button" class="close_pop podcast-ad-creator-lock__close flex align_items" aria-label="<?php echo iN_HelpSecure(customLang('close')); ?>">
                                    <?php echo render_icon('close', true); ?>
                                </button>
                            </div>
                            <div class="flex flexBoxColumn gap podcast-ad-creator-lock__body">
                                <p class="form-text"><?php echo iN_HelpSecure($creatorLockDesc); ?></p>
                                <a class="podcasts-cta podcasts-cta--primary flex align_items gap" href="<?php echo iN_HelpSecure($creatorIdentityUrl); ?>">
                                    <?php echo iN_HelpSecure($creatorLockCta); ?>
                                    <span aria-hidden="true"><?php echo render_icon('link_out', true); ?></span>
                                </a>
                            </div>
                        </div>
                    </div>

                <section class="podcasts-categories full-width" id="podcasts-categories" aria-label="<?php echo iN_HelpSecure($categoryTitle); ?>">
                    <div class="podcasts-section__header">
                        <h2 class="podcasts-section__title"><?php echo iN_HelpSecure($categoryTitle); ?></h2>
                    </div>
                    <div class="podcasts-chip-row" role="list">
                        <a class="podcasts-chip<?php echo $categorySlug === '' ? ' is-active' : ''; ?>" href="<?php echo iN_HelpSecure($podcastsUrl); ?>" role="listitem">
                            <?php echo iN_HelpSecure($categoryAllLabel); ?>
                        </a>
                            <?php foreach ($categories as $cat):
                                $slug = isset($cat['slug']) ? strtolower((string) $cat['slug']) : '';
                                $name = (string) ($cat['name'] ?? '');
                                if ($slug === '') { continue; }
                                $url = $podcastsUrl . '?category=' . urlencode($slug);
                                $active = $categorySlug !== '' && $categorySlug === $slug;
                            ?>
                                <a class="podcasts-chip<?php echo $active ? ' is-active' : ''; ?>" href="<?php echo iN_HelpSecure($url); ?>" role="listitem">
                                    <?php echo htmlspecialchars($name !== '' ? $name : ucfirst($slug), ENT_QUOTES, 'UTF-8'); ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </section>

                <section class="podcasts-recent full-width" id="podcasts-list" aria-label="<?php echo iN_HelpSecure($recentTitle); ?>">
                    <div class="podcasts-section__header">
                        <h2 class="podcasts-section__title"><?php echo iN_HelpSecure($recentTitle); ?></h2>
                    </div>
                    <?php if (!$podcastsEnabled): ?>
                            <div class="empty-state flex align_items flexBoxColumn gap">
                                <div class="empty-state__icon flex align_items"><?php echo render_icon('not_founded', true); ?></div>
                                <div class="empty-state__title flex align_items"><?php echo iN_HelpSecure($disabledMessage, false); ?></div>
                            </div>
                        <?php elseif (!$podcasts): ?>
                            <div class="empty-state flex align_items flexBoxColumn gap">
                                <div class="empty-state__icon flex align_items"><?php echo render_icon('not_founded', true); ?></div>
                                <div class="empty-state__title flex align_items"><?php echo iN_HelpSecure($emptyStateMessage, false); ?></div>
                                <?php if ($isLoggedIn): ?>
                                    <button type="button" class="empty-state__cta podcasts-cta podcasts-cta--primary new_item" data-pop="createNew">
                                        <?php echo iN_HelpSecure($primaryCta); ?>
                                    </button>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                        <?php if ($podcastTemplateExists): ?>
                            <div class="podcasts-list flex flexBoxColumn gap">
                                <?php foreach ($podcasts as $podcast):
                                    include $podcastRowTemplate;
                                endforeach; ?>
                            </div>
                        <?php endif; ?>
                            <?php if ($recentHasMore): ?>
                                <div id="podcasts-sentinel" class="podcasts-sentinel" data-has-more="1" data-limit="<?php echo (int) $recentLimit; ?>" data-cursor-time="<?php echo (int) ($recentCursor['time'] ?? 0); ?>" data-cursor-id="<?php echo (int) ($recentCursor['id'] ?? 0); ?>" data-category="<?php echo iN_HelpSecure($categorySlug); ?>" data-loading-label="<?php echo iN_HelpSecure($loadingLabel); ?>" data-done-label="<?php echo iN_HelpSecure($noMoreLabel); ?>" aria-live="polite"><?php echo iN_HelpSecure($loadingLabel); ?></div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </section>
                <?php endif; ?>
            </div>
        </div>
        <!---->
        <div class="content-right flex align_items">
            <div class="content-right-container">
                <?php
                    include_once __DIR__ . '/widgets/suggestedUsers.php';
                    include_once __DIR__ . '/widgets/adsSidebar.php';
                    $hideMostPopularIfEmpty = true;
                    include_once __DIR__ . '/widgets/mosPopularPost.php';
                    unset($hideMostPopularIfEmpty);
                ?>
            </div>
        </div>
        <!---->
    </div>
</div>
