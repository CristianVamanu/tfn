<?php
declare(strict_types=1);

if (empty($enableSuggestedUsers)) {
    return;
}

$config = $suggestedUsersConfig ?? [
    'enabled'       => true,
    'limit'         => 5,
    'allow_reload'  => true,
    'mode'          => 'creators',
];

$viewerId = 0;
if (isset($userID)) {
    $viewerId = (int) $userID;
} elseif (isset($userData['user_id'])) {
    $viewerId = (int) $userData['user_id'];
} elseif (isset($_SESSION['iuid'])) {
    $viewerId = (int) $_SESSION['iuid'];
}

$limit = isset($config['limit']) ? (int) $config['limit'] : 5;
if ($limit < 1) { $limit = 1; }
if ($limit > 24) { $limit = 24; }
$mode = is_string($config['mode'] ?? '') ? (string) $config['mode'] : 'creators';
$allowReload = !empty($config['allow_reload']) && !empty($enableSuggestedUsersReload);

$baseUrl = rtrim((string)($base_url ?? ''), '/') . '/';
$csrfToken = function_exists('generateCsrfToken') ? generateCsrfToken() : '';

if ($viewerId <= 0) {
    return;
}

$suggestedUsers = [];
if (isset($RL) && method_exists($RL, 'RL_GetSuggestedUsers') && $viewerId > 0) {
    try {
        $suggestedUsers = $RL->RL_GetSuggestedUsers($viewerId, $limit, $mode);
    } catch (Throwable $__) {
        $suggestedUsers = [];
    }
}
$listTpl = __DIR__ . '/suggestedUsersList.php';
?>
<section class="suggested-users" data-allow-reload="<?php echo $allowReload ? '1' : '0'; ?>">
    <div class="suggested-users__header">
        <div class="suggested-users__title"><?php echo iN_HelpSecure(customLang('suggested_users_title', 'Suggested users'), false); ?></div>
        <?php if ($allowReload): ?>
            <button type="button" class="suggested-users__reload" data-action="suggested-users-reload" aria-label="<?php echo iN_HelpSecure(customLang('suggested_users_reload', 'Reload suggestions'), false); ?>">
                <?php echo render_icon('reload', true); ?>
            </button>
        <?php endif; ?>
    </div>
    <div class="suggested-users__body" data-suggested-list>
        <?php if (is_file($listTpl)) { include $listTpl; } ?>
    </div>
    <input type="hidden" name="csrf_token" value="<?php echo iN_HelpSecure($csrfToken); ?>" data-suggested-csrf>
</section>
