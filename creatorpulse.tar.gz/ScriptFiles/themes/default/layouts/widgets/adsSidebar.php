<?php
declare(strict_types=1);

$viewerId = isset($userID) ? (int) $userID : 0;
$adsEnabled = !empty($enableAds);
$videoAdsAllowed = !empty($enableVideoPosts);
$imageAdsAllowed = !empty($enableImagePosts);
$initialAds = [];
if (!$adsEnabled) {
    return;
}
if (isset($RL) && method_exists($RL, 'RL_GetActiveAdvertisementsForFeed')) {
    try {
        $initialAds = $RL->RL_GetActiveAdvertisementsForFeed(2, [], $viewerId > 0 ? $viewerId : null);
    } catch (Throwable $__) {
        $initialAds = [];
    }
}
$initialAds = array_values(array_filter($initialAds, static function ($ad) use ($videoAdsAllowed, $imageAdsAllowed): bool {
    $type = strtolower((string) ($ad['media_type'] ?? ''));
    if ($type === 'video' && !$videoAdsAllowed) {
        return false;
    }
    if ($type === 'image' && !$imageAdsAllowed) {
        return false;
    }
    return true;
}));

$base = isset($base_url) ? rtrim((string) $base_url, '/') . '/' : '/';
$resolveMedia = static function (string $path) use ($base): string {
    $path = trim($path);
    if ($path === '') {
        return '';
    }
    // Normalize known folder typo ("advertisement ifiles" -> "advertisement_ifiles")
    $path = str_replace('advertisement ifiles', 'advertisement_ifiles', $path);
    $resolved = function_exists('storage_resolve_media_url')
        ? storage_resolve_media_url($path, $base)
        : $base . ltrim($path, '/');

    // Guard: skip nonexistent local files to avoid 404 noise
    $localPath = dirname(__DIR__, 3) . '/' . ltrim($path, '/');
    if (str_starts_with($resolved, $base) && !is_file($localPath)) {
        return '';
    }

    return $resolved;
};

$badgeLabel = customLang('ads_sponsored', 'Sponsored');
$ctaLabel   = customLang('ads_visit_advertiser', 'Visit advertiser');
$titleLabel = customLang('ads_sidebar_title', 'Sponsored');

$initialIds = [];
foreach ($initialAds as $adRow) {
    $initialIds[] = (int) ($adRow['ad_id'] ?? 0);
}
$initialIdsAttr = implode(',', array_filter($initialIds));
?>
<div class="sponsor-sidebar" data-initial-ad-ids="<?php echo iN_HelpSecure($initialIdsAttr); ?>">
    <div class="sponsor-sidebar__cards" id="sponsor-sidebar-cards">
        <?php foreach ($initialAds as $adRow):
            $adId = (int) ($adRow['ad_id'] ?? 0);
            if ($adId <= 0) { continue; }
            $mediaItems = isset($adRow['media_items']) && is_array($adRow['media_items']) ? $adRow['media_items'] : [];
            $mediaUrls = [];
            foreach ($mediaItems as $item) {
                $resolved = $resolveMedia((string) $item);
                if ($resolved !== '') {
                    $mediaUrls[] = $resolved;
                }
            }
            if (!$mediaUrls) { continue; }
            $mediaType = strtolower((string) ($adRow['media_type'] ?? 'image'));
            $title = trim((string) ($adRow['title'] ?? ''));
            $description = trim((string) ($adRow['description'] ?? ''));
            $username = (string) ($adRow['username'] ?? '');
            $ownerName = trim((string) ($adRow['user_fullname'] ?? ''));
            $profileUrl = $base . 'profile/' . rawurlencode($username);
            $adLink = (string) ($adRow['ad_link'] ?? '');
            $targetUrl = $adLink !== '' ? $adLink : $profileUrl;
            $altText = $ownerName !== '' ? $ownerName : ($username !== '' ? ('@' . $username) : $title);
            if ($altText === '') { $altText = 'Advertisement'; }

            $videoPoster = '';
            if ($mediaType === 'video') {
                $primaryMedia = $mediaUrls[0];
                if (isset($RL) && method_exists($RL, 'videoThumbNail')) {
                    try {
                        $videoPoster = (string) $RL->videoThumbNail($primaryMedia);
                    } catch (Throwable $__) {
                        $videoPoster = '';
                    }
                }
                if ($videoPoster === '' && $primaryMedia !== '') {
                    $derivedPoster = preg_replace('/\.mp4(\?.*)?$/i', '.png', $primaryMedia);
                    if (is_string($derivedPoster) && $derivedPoster !== '') {
                        $videoPoster = $derivedPoster;
                    }
                }
            }
        ?>
        <article class="sponsor-card sponsor-sponsored" data-ad-id="<?php echo $adId; ?>" data-media-type="<?php echo iN_HelpSecure($mediaType); ?>">
            <div class="sponsor-card-media" data-ad-media>
                <?php if ($mediaType === 'video'): ?>
                    <video
                        class="sponsor-card-video"
                        src="<?php echo iN_HelpSecure($mediaUrls[0]); ?>"
                        <?php if ($videoPoster !== ''): ?>poster="<?php echo iN_HelpSecure($videoPoster); ?>"<?php endif; ?>
                        playsinline
                        controls
                        preload="metadata"
                        data-ad-clickable="1">
                    </video>
                <?php else: ?>
                    <a class="sponsor-card-media-link" href="<?php echo iN_HelpSecure($targetUrl); ?>" target="_blank" rel="nofollow noopener" data-ad-clickable="1">
                        <img class="sponsor-card-image" src="<?php echo iN_HelpSecure($mediaUrls[0]); ?>" alt="<?php echo iN_HelpSecure($altText); ?>" loading="lazy">
                    </a>
                <?php endif; ?>
            </div>
            <div class="sponsor-card-body">
                <span class="sponsor-card-badge"><?php echo iN_HelpSecure($badgeLabel); ?></span>
                <?php if ($title !== ''): ?>
                    <a class="sponsor-card-title" href="<?php echo iN_HelpSecure($targetUrl); ?>" target="_blank" rel="nofollow noopener" data-ad-clickable="1"><?php echo iN_HelpSecure($title); ?></a>
                <?php endif; ?>
                <?php if ($description !== ''): ?>
                    <p class="sponsor-card-description"><?php echo iN_HelpSecure($description); ?></p>
                <?php endif; ?>
                <a class="sponsor-card-cta" href="<?php echo iN_HelpSecure($targetUrl); ?>" target="_blank" rel="nofollow noopener" data-ad-clickable="1"><?php echo iN_HelpSecure($ctaLabel); ?></a>
            </div>
        </article>
        <?php endforeach; ?>
    </div>
    <template id="sponsor-sidebar-card-template">
        <article class="sponsor-card sponsor-sponsored" data-ad-id="" data-media-type="">
            <div class="sponsor-card-media" data-ad-media></div>
            <div class="sponsor-card-body">
                <span class="sponsor-card-badge"><?php echo iN_HelpSecure($badgeLabel); ?></span>
                <a class="sponsor-card-title" href="" target="_blank" rel="nofollow noopener" data-ad-clickable="1" aria-disabled="true" tabindex="-1" data-ad-placeholder="1"></a>
                <p class="sponsor-card-description"></p>
                <a class="sponsor-card-cta" href="" target="_blank" rel="nofollow noopener" data-ad-clickable="1" aria-disabled="true" tabindex="-1" data-ad-placeholder="1"><?php echo iN_HelpSecure($ctaLabel); ?></a>
            </div>
        </article>
    </template>
</div>
