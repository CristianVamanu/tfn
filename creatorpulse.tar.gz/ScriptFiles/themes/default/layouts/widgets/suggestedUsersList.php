<?php
declare(strict_types=1);

if (!isset($suggestedUsers) || !is_array($suggestedUsers)) {
    $suggestedUsers = [];
}

$viewerId = 0;
if (isset($userID)) {
    $viewerId = (int) $userID;
} elseif (isset($userData['user_id'])) {
    $viewerId = (int) $userData['user_id'];
} elseif (isset($_SESSION['iuid'])) {
    $viewerId = (int) $_SESSION['iuid'];
}

$resolveAvatar = static function (string $path) use ($baseUrl): string {
    $path = trim($path);
    if ($path === '') {
        $path = 'uploads/avatars/default_avatar.png';
    }
    if (function_exists('storage_url')) {
        return storage_url($path);
    }
    return $baseUrl . ltrim($path, '/');
};

?>
<div class="suggested-users__list">
    <?php if (!$suggestedUsers): ?>
        <div class="suggested-users__empty">
            <?php echo iN_HelpSecure(customLang('suggested_users_empty', 'No suggestions yet.'), false); ?>
        </div>
    <?php else: ?>
        <?php foreach ($suggestedUsers as $su):
            $uid      = (int) ($su['user_id'] ?? 0);
            $username = (string) ($su['username'] ?? '');
            $fullname = trim((string) ($su['user_fullname'] ?? ''));
            $verified = (int) ($su['verified_status'] ?? 0) === 1;
            if ($fullname === '') {
                $fullname = $username;
            }
            $profileUrl = $baseUrl . 'profile/' . rawurlencode($username);
            $avatarUrl  = $resolveAvatar((string) ($su['user_avatar'] ?? ''));
            $__alt = sprintf(customLang('alt_avatar_of_user') ?: 'Avatar of %s', $fullname ?: $username);
        ?>
        <article class="suggested-card" data-user-id="<?php echo $uid; ?>">
            <a class="suggested-card__avatar" href="<?php echo iN_HelpSecure($profileUrl); ?>">
                <span class="suggested-card__avatar-inner">
                    <img src="<?php echo iN_HelpSecure($avatarUrl); ?>" alt="<?php echo iN_HelpSecure($__alt); ?>" loading="lazy">
                </span>
                <?php if ($verified): ?>
                    <span class="suggested-card__badge"><?php echo render_icon('verified', true); ?></span>
                <?php endif; ?>
            </a>
            <a class="suggested-card__name" href="<?php echo iN_HelpSecure($profileUrl); ?>">
                <?php echo htmlspecialchars($fullname, ENT_QUOTES, 'UTF-8'); ?>
            </a>
        </article>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
