<?php
declare(strict_types=1);

$limit = 1; // show only one tile in guest sidebar
$tz     = 'Europe/Istanbul';
$items  = $RL->RL_GetMostPopularByActivity($limit, $tz);

// Fallback: relax window to last 24 hours
if (!$items) {
    $items = $RL->RL_GetMostPopularByActivity($limit, $tz, [], time() - 86400, time());
}

// Second fallback: re-use guest feed (ensures widget never disappears)
if (!$items && method_exists($RL, 'RL_GetGuestFeedPosts')) {
    $fallbackPosts = $RL->RL_GetGuestFeedPosts($limit, 0);
    $items = array_map(static function (array $row): array {
        $type = (string)($row['post_type'] ?? 'image');
        if ($type === 'image') {
            $files = array_values(array_filter(array_map('trim', explode(',', (string)($row['post_file'] ?? '')))));
            if (!empty($files)) {
                $row['first_image'] = $files[0];
            }
        }
        $row['likes_count_today']    = (int)($row['likes_count_today']    ?? 0);
        $row['comments_count_today'] = (int)($row['comments_count_today'] ?? 0);
        $row['views_count_today']    = (int)($row['views_count_today']    ?? 0);
        return $row;
    }, $fallbackPosts);
}

$hasItems = !empty($items);
$hideWhenEmpty = isset($hideMostPopularIfEmpty) ? (bool) $hideMostPopularIfEmpty : false;
if (!$hasItems && $hideWhenEmpty) {
    return;
}
?>
<div class="most_popular_post_in_a_day flex align_items relative flexBoxColumn">
    <div class="most_popular_post_header flex full-width">Most popular post today</div>
    <div class="arrow"></div>
    <?php if (!$hasItems): ?>
        <div class="most-popular-empty flex align_items">
            <?php echo customLang('no_posts_yet'); ?>
        </div>
    <?php else: ?>
        <?php foreach ($items as $post): ?>
            <?php
                $postId = (int)($post['post_id'] ?? 0);
                $type   = (string)($post['post_type'] ?? 'image');
                if ($type === 'video') {
                    $videoPath = function_exists('storage_resolve_media_url')
                        ? storage_resolve_media_url((string)($post['post_file'] ?? ''), $base_url ?? '')
                        : ((string)($base_url ?? '') . ltrim((string)($post['post_file'] ?? ''), '/'));
                    $src = $RL->videoThumbNail($videoPath);
                } else {
                    $first = $post['first_image'] ?? ($post['post_file'] ?? '');
                    $src = function_exists('storage_resolve_media_url')
                        ? storage_resolve_media_url((string)$first, $base_url ?? '')
                        : ((string)($base_url ?? '') . ltrim((string)$first, '/'));
                }
                $likes    = (int)($post['likes_count_today']    ?? 0);
                $comments = (int)($post['comments_count_today'] ?? 0);
                $views    = (int)($post['views_count_today']    ?? 0);
                $postUrl  = rtrim((string)($base_url ?? ''), '/') . '/posts/' . $postId . '/' . rawurlencode((string)($post['owner_username'] ?? ''));
                $__cap    = dzShortCaption($post ?? [], 80);
                $__u      = (string)($post['owner_username'] ?? '');
                $__alt    = $__cap !== '' ? $__cap : ($__u !== '' ? sprintf(customLang('alt_tile_by_user'), $__u) : customLang('image_alt_generic'));
            ?>
            <a class="reels_post_wrapper relative most-popular-post-link" href="<?php echo iN_HelpSecure($postUrl, false); ?>" data-post-id="<?php echo (int)$postId; ?>" aria-label="<?php echo iN_HelpSecure($__alt); ?>">
                <img class="post-media" src="<?php echo iN_HelpSecure($src); ?>" alt="<?php echo iN_HelpSecure($__alt); ?>" loading="lazy" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
                <div class="tile-overlay flex align_items" aria-hidden="true">
                    <span class="metric metric-like flex align_items">
                        <span class="metric-icon flex align_items"><?php echo render_icon('post_liked', true); ?></span>
                        <span class="metric-value flex align_items"><?php echo iN_HelpSecure((string)$likes); ?></span>
                    </span>
                    <span class="metric metric-comment flex align_items">
                        <span class="metric-icon flex align_items"><?php echo render_icon('post_commented', true); ?></span>
                        <span class="metric-value flex align_items"><?php echo iN_HelpSecure((string)$comments); ?></span>
                    </span>
                </div>
                <div class="tile-total-view flex align_items">
                    <div class="view-svg flex align_items"><?php echo renderVerifiedBadge(($iconPath ?? '') . 'view.svg', true); ?></div>
                    <div class="view-total flex align_items"><?php echo iN_HelpSecure((string)$views); ?></div>
            </div>
            </a>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
