<?php
// Premium purchases list — shows posts the current user unlocked via pay-per-view.
declare(strict_types=1);

if (!isset($loggedIn) || $loggedIn !== '1' || !isset($userID) || (int)$userID <= 0) {
    echo '<div class="warning_box full-width flex align_items_justify_content pad-24">' . customLang('premium_login_to_view') . '</div>';
    return;
}

$viewMode = 'feed';
$limit  = isset($_GET['limit']) ? max(1, (int)$_GET['limit']) : 20;
$offset = isset($_GET['offset']) ? max(0, (int)$_GET['offset']) : 0;
$__externalPosts = [];
$hasMore = false;
if (isset($RL) && method_exists($RL, 'RL_GetPurchasedPremiumFeed')) {
  $tmp = $RL->RL_GetPurchasedPremiumFeed((int)$userID, $limit + 1, $offset);
  if (count($tmp) > $limit) { $hasMore = true; $tmp = array_slice($tmp, 0, $limit); }
  $__externalPosts = $tmp;
}
?>
<div class="main-content flex align_items">
  <div class="content-area flex">
    <!---->
    <div class="content-left">
      <div class="content-left-container flex align_items flexBoxColumn">
        <div class="posts-container gap full-width relative flex align_items flexBoxColumn" id="premium-root" data-offset="<?php echo (int)$limit; ?>" data-limit="<?php echo (int)$limit; ?>" data-has-more="<?php echo $hasMore ? '1' : '0'; ?>">
          <?php
            $__suppressEmptyFeedMessage = true;
            include __DIR__ . '/post_view.php';
            if (empty($__externalPosts)) {
                $cta = '';
                if (isset($loggedIn) && $loggedIn === '1') {
                    $cta = sprintf(
                        '<div class="empty-state__body flex align_items flexBoxColumn gap">
                            <p class="empty-state__subtitle">%s</p>
                            <button type="button" class="empty-state__cta new_item" data-pop="createNew">%s</button>
                        </div>',
                        customLang('empty_state_create_prompt'),
                        customLang('empty_state_create_button')
                    );
                }

                echo sprintf(
                    '<div class="empty-state flex align_items flexBoxColumn gap">'
                    . '<div class="empty-state__icon flex align_items">%s</div>'
                    . '<div class="empty-state__title flex align_items">%s</div>%s'
                    . '</div>',
                    render_icon('not_founded', true),
                    customLang('empty_state_premium'),
                    $cta
                );
            }
          ?>
          <div id="premium-sentinel" class="io-sentinel" aria-hidden="true"></div>
        </div>
      </div>
    </div>
    <!---->
    <div class="content-right flex align_items">
      <div class="content-right-container">
        <?php
          include_once __DIR__ . '/widgets/suggestedUsers.php';
          include_once __DIR__ . '/widgets/adsSidebar.php';
          $hideMostPopularIfEmpty = true;
          include_once __DIR__ . '/widgets/mosPopularPost.php';
          unset($hideMostPopularIfEmpty);
        ?>
      </div>
    </div>
    <!---->
  </div>
</div>

<?php $themeBase = iN_HelpSecure($base_url).'themes/'.iN_HelpSecure($currentTheme); ?>
<script defer src="<?php echo $themeBase; ?>/js/premium.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themeBase; ?>/js/adsFeedSlots.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themeBase; ?>/js/media.viewer.js?v=<?php echo iN_HelpSecure($version);?>"></script>
