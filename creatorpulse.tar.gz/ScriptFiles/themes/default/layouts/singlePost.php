<?php
// Single sayfa — eski singlePost.php
$viewMode = 'single';
include __DIR__ . '/post_view.php';

$themeBase = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme);
?>
<script defer src="<?php echo $themeBase; ?>/js/media.viewer.js?v=<?php echo iN_HelpSecure($version); ?>"></script>
