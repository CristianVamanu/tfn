<?php
  // Guard: settings requires login
  if (!isset($loggedIn) || $loggedIn !== '1') {
    echo '<div class="main-content flex align_items"><div class="content-area flex"><div class="page-settings-ciontainer full-width flex flexBoxColumn relative"><div class="page-settings-title flex">' . customLang('menu_settings') . '</div><div class="page-settings-wrapper full-width flex align_items"><div class="page-settings-right full-width flex flexBoxColumn">' . customLang('login_required') . '</div></div></div></div></div>';
    return;
  }

  // Routing: determine current tab
  $allowedTabs = [
    'my_profile'        => 'profile',
    'dashboard'         => 'dashboard',
    'security'          => 'security',
    'password'          => 'password',
    'preferences'       => 'preferences',
    'podcastads'        => 'podcastads',
    'blocked'           => 'blocked',
    'subscription'      => 'subscription',
    'subscription_fees' => 'subscription_fees',
    'super_thanks'      => 'super_thanks',
    'payments'          => 'payments',
    'bank'              => 'bank',
    'payout_methods'    => 'payout_methods',
    'creator_identity'  => 'creator_identity',
    'creator_plans'     => 'creator_plans',
    'my_ebooks'         => 'my_ebooks',
    'creator_payout'    => 'creator_payout'
  ];

  $creatorStatusRaw = isset($creatorStatus) ? strtolower((string)$creatorStatus) : 'none';
  $creatorApproved = $creatorStatusRaw === 'approved';
  $creatorRestrictedTabs = [
    'podcastads',
    'dashboard',
    'subscription',
    'subscription_fees',
    'payments',
    'creator_plans',
    'my_ebooks',
    'super_thanks',
    'bank',
    'payout_methods',
    'creator_payout'
  ];
  $menuLabels = [
    'my_profile'        => customLang('menu_profile'),
    'dashboard'         => customLang('menu_dashboard'),
    'security'          => customLang('menu_security'),
    'password'          => customLang('menu_password'),
    'preferences'       => customLang('menu_preferences'),
    'podcastads'        => customLang('settings_podcast_ads_title', 'Podcast hero ads'),
    'blocked'           => customLang('menu_blocked_users'),
    'subscription'      => customLang('nav_subscriptions'),
    'subscription_fees' => customLang('subscription_fees'),
    'super_thanks'      => customLang('earnings'),
    'payments'          => customLang('menu_payments'),
    'bank'              => customLang('menu_withdrawal'),
    'payout_methods'    => customLang('menu_payout_method'),
    'creator_identity'  => customLang('menu_creator_identity', 'Creator verification'),
    'creator_plans'     => customLang('menu_creator_plans', 'Creator plans'),
    'my_ebooks'         => customLang('ebooks_my_title', 'My eBooks'),
    'creator_payout'    => customLang('menu_creator_payout', 'Creator payout'),
  ];

  $tab = isset($_GET['tab']) ? strtolower(trim((string)$_GET['tab'])) : 'my_profile';
  if (!array_key_exists($tab, $allowedTabs)) { $tab = 'my_profile'; }
  $creatorSectionDenied = false;
  if (!$creatorApproved && in_array($tab, $creatorRestrictedTabs, true)) {
    $creatorSectionDenied = true;
    $tab = 'creator_identity';
  }
  $activeMenuLabel = $menuLabels[$tab] ?? customLang('menu_settings');

  // Helper: build settings URLs
  $settingsBase = rtrim((string)$base_url, '/') . '/settings';
  $to = function(string $t) use ($settingsBase) {
    return iN_HelpSecure($settingsBase . '?tab=' . rawurlencode($t));
  };

  // Helper: mark active
  $isActive = function(string $t) use ($tab) { return $tab === $t ? ' aria-current="page"' : ''; };

  $emptyTabPrompts = [
    'dashboard' => [
      'title' => customLang('settings_prompt_dashboard_title', 'Creator dashboard coming soon'),
      'items' => [
        customLang('settings_prompt_dashboard_stats', 'Surface daily follower, subscriber, and earnings stats using the existing KPI card layout.'),
        customLang('settings_prompt_dashboard_activity', 'List the newest subscribers, tips, and post purchases with quick links to thank supporters.'),
        customLang('settings_prompt_dashboard_shortcuts', 'Offer shortcuts for uploading new posts, checking verification status, and updating creator plans.'),
      ],
    ],
    'security' => [
      'title' => customLang('settings_prompt_security_title', 'Security controls in progress'),
      'items' => [
        customLang('settings_prompt_security_2fa', 'Add a two-factor authentication toggle with status badges consistent with the settings theme.'),
        customLang('settings_prompt_security_sessions', 'Display active sessions and devices in a table with “Revoke access” buttons.'),
        customLang('settings_prompt_security_logs', 'Highlight recent security events (password changes, new logins) with timestamps.'),
      ],
    ],
    'password' => [
      'title' => customLang('settings_prompt_password_title', 'Password update form pending'),
      'items' => [
        customLang('settings_prompt_password_fields', 'Provide current, new, and confirm password inputs with inline validation.'),
        customLang('settings_prompt_password_strength', 'Show a strength indicator and requirement checklist styled with the existing alert colors.'),
        customLang('settings_prompt_password_cta', 'Include a primary save button and success toast using the standard settings notifications.'),
      ],
    ],
    'preferences' => [
      'title' => customLang('settings_prompt_preferences_title', 'Personalisation settings coming soon'),
      'items' => [
        customLang('settings_prompt_preferences_feed', 'Add toggles for autoplay, muted start, and feed content filters.'),
        customLang('settings_prompt_preferences_notifications', 'Let users choose notification channels (push, email) via grouped switches.'),
        customLang('settings_prompt_preferences_language', 'Offer language and theme selectors mirroring the existing dropdown styling.'),
      ],
    ],
    'blocked' => [
      'title' => customLang('settings_prompt_blocked_title', 'Blocked users list coming soon'),
      'items' => [
        customLang('settings_prompt_blocked_table', 'Render blocked accounts in a responsive table with avatars and “Unblock” actions.'),
        customLang('settings_prompt_blocked_search', 'Provide search and filter controls for long lists.'),
        customLang('settings_prompt_blocked_empty', 'Design an empty state illustration consistent with the theme when no users are blocked.'),
      ],
    ],
    'subscription' => [
      'title' => customLang('settings_prompt_subscription_title', 'Manage subscriptions module planned'),
      'items' => [
        customLang('settings_prompt_subscription_active', 'List creators the user subscribes to with renewal dates and status badges.'),
        customLang('settings_prompt_subscription_actions', 'Add buttons to cancel or update payment methods per subscription.'),
        customLang('settings_prompt_subscription_history', 'Include a compact history of recent subscription payments for reference.'),
      ],
    ],
    'subscription_fees' => [
      'title' => customLang('settings_prompt_subscription_fees_title', 'Subscription fee breakdown coming soon'),
      'items' => [
        customLang('settings_prompt_subscription_fees_explain', 'Explain platform fees versus creator share with a simple chart or stacked bar.'),
        customLang('settings_prompt_subscription_fees_simulator', 'Offer a fee simulator that recalculates take-home pay as users choose price points.'),
        customLang('settings_prompt_subscription_fees_resources', 'Link to payout schedules and fee policy documents in an info panel.'),
      ],
    ],
    'super_thanks' => [
      'title' => customLang('settings_prompt_super_thanks_title', 'Tips & Super Thanks analytics incoming'),
      'items' => [
        customLang('settings_prompt_super_thanks_overview', 'Summarise lifetime, monthly, and weekly tip totals with KPI cards.'),
        customLang('settings_prompt_super_thanks_table', 'Display a filterable table of tip transactions including supporters and amounts.'),
        customLang('settings_prompt_super_thanks_payout', 'Highlight pending payouts and link to the withdrawal tab for next steps.'),
      ],
    ],
    'bank' => [
      'title' => customLang('settings_prompt_bank_title', 'Withdrawal settings placeholder'),
      'items' => [
        customLang('settings_prompt_bank_form', 'Provide a secure form for banking details (IBAN, SWIFT, account name) with masking.'),
        customLang('settings_prompt_bank_status', 'Show verification status of the banking profile and the latest payout attempt.'),
        customLang('settings_prompt_bank_history', 'List recent withdrawal requests with status tags and support links.'),
      ],
    ],
    'payout_methods' => [
      'title' => customLang('settings_prompt_payout_methods_title', 'Payout method selector on the roadmap'),
      'items' => [
        customLang('settings_prompt_payout_methods_options', 'Present available payout providers (PayPal, bank, crypto) with short descriptions.'),
        customLang('settings_prompt_payout_methods_connect', 'Add “Connect” buttons that launch provider-specific onboarding flows in modals.'),
        customLang('settings_prompt_payout_methods_priority', 'Allow users to set a default payout method and reorder fallback options.'),
      ],
    ],
  ];

?>
<div class="main-content flex align_items">
  <div class="content-area flex">
    <div class="page-settings-ciontainer full-width flex flexBoxColumn relative">
      <div class="page-settings-title flex"><?php echo customLang('menu_settings'); ?></div>
      <div class="arrow"></div>
      <div class="page-settings-wrapper full-width flex">
        <div class="page-settings-left full-width flex align_items flexBoxColumn">
          <input type="checkbox" id="settings-menu-toggle" class="settings-menu__toggle" aria-label="<?php echo customLang('settings_menu_toggle_label', 'Toggle settings navigation'); ?>" aria-controls="settings-menu-list">
          <label for="settings-menu-toggle" class="settings-menu__toggle-btn full-width flex align_items space_between">
            <span class="settings-menu__toggle-title"><?php echo customLang('menu_settings'); ?></span>
            <span class="settings-menu__active-label"><?php echo htmlspecialchars($activeMenuLabel, ENT_QUOTES, 'UTF-8'); ?></span>
            <span class="settings-menu__toggle-icon" aria-hidden="true"></span>
          </label>
          <div class="settings-menu__options" id="settings-menu-list">
          <!-- Profile & Dashboard -->
          <a href="<?php echo $to('my_profile'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition my_profile"<?php echo $isActive('my_profile'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('profile', true);?></span>
            <?php echo customLang('menu_profile'); ?>
          </a>
          <a href="<?php echo $to('dashboard'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition dashboard_user"<?php echo $isActive('dashboard'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('dashboard_user', true);?></span>
            <?php echo customLang('menu_dashboard'); ?>
          </a>

          <div class="arrow"></div>

          <!-- Security & Preferences -->
          <a href="<?php echo $to('security'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition security"<?php echo $isActive('security'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('security', true);?></span>
            <?php echo customLang('menu_security'); ?>
          </a>
          <a href="<?php echo $to('password'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition password"<?php echo $isActive('password'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('password', true);?></span>
            <?php echo customLang('menu_password'); ?>
          </a>
          <a href="<?php echo $to('preferences'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition preferences"<?php echo $isActive('preferences'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('preferences', true);?></span>
            <?php echo customLang('menu_preferences'); ?>
          </a>
          <?php if ($creatorApproved): ?>
          <a href="<?php echo $to('podcastads'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition podcastads"<?php echo $isActive('podcastads'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('podcastads', true);?></span>
            <?php echo customLang('settings_podcast_ads_title', 'Podcast hero ads'); ?>
          </a>
          <?php endif; ?>
          <a href="<?php echo $to('blocked'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition blocked"<?php echo $isActive('blocked'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('block', true);?></span>
            <?php echo customLang('menu_blocked_users'); ?>
          </a>

          <div class="arrow"></div>

          <!-- Subscription & Earnings -->
          <?php if ($creatorApproved): ?>
          <a href="<?php echo $to('subscription'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition subscription"<?php echo $isActive('subscription'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('creator_icon', true);?></span>
            <?php echo customLang('nav_subscriptions'); ?>
          </a>
          <a href="<?php echo $to('subscription_fees'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition subscription_fees"<?php echo $isActive('subscription_fees'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('subscription_fees', true);?></span>
            <?php echo customLang('subscription_fees'); ?>
          </a>
          <?php endif; ?>
          <a href="<?php echo $to('creator_identity'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition creator_identity"<?php echo $isActive('creator_identity'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('security', true);?></span>
            <?php echo customLang('menu_creator_identity', 'Creator verification'); ?>
            <?php if (!$creatorApproved): ?>
              <span class="creator-identity-chip"><?php echo customLang('creator_identity_apply_badge', 'Apply'); ?></span>
            <?php endif; ?>
          </a>
          <?php if ($creatorApproved): ?>
          <a href="<?php echo $to('creator_plans'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition creator_plans"<?php echo $isActive('creator_plans'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('creator_icon', true);?></span>
            <?php echo customLang('menu_creator_plans', 'Creator plans'); ?>
          </a>
          <a href="<?php echo $to('my_ebooks'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition my_ebooks"<?php echo $isActive('my_ebooks'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('ebook', true);?></span>
            <?php echo customLang('ebooks_my_title', 'My eBooks'); ?>
          </a>
          <a href="<?php echo $to('super_thanks'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition super_thanks"<?php echo $isActive('super_thanks'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('super_thanks', true);?></span>
            <?php echo customLang('earnings'); ?>
          </a>
          <?php endif; ?>

          <div class="arrow"></div>

          <!-- Payments & Withdrawals -->
          <?php if ($creatorApproved): ?>
          <a href="<?php echo $to('payments'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition payments"<?php echo $isActive('payments'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('payments', true);?></span>
            <?php echo customLang('menu_payments'); ?>
          </a>
          <a href="<?php echo $to('bank'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition bank"<?php echo $isActive('bank'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('bank', true);?></span>
            <?php echo customLang('menu_withdrawal'); ?>
          </a>
          <a href="<?php echo $to('payout_methods'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition payout_methods"<?php echo $isActive('payout_methods'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('payout_methods', true);?></span>
            <?php echo customLang('menu_payout_method'); ?>
          </a>
          <a href="<?php echo $to('creator_payout'); ?>" class="settings_sidebar__menu_box full-width flex align_items transition creator_payout"<?php echo $isActive('creator_payout'); ?>>
            <span class="home_page flex align_items"><?php echo render_icon('bank', true);?></span>
            <?php echo customLang('menu_creator_payout', 'Creator payout'); ?>
          </a>
          <?php endif; ?>
          </div>
        </div>
        <div class="page-settings-right full-width flex flexBoxColumn">
          <?php
            // Resolve partial path for current tab (only include whitelisted files)
            $partialDir = __DIR__ . '/settings';
            $file = $partialDir . '/' . $allowedTabs[$tab] . '.php';
            if (!is_dir($partialDir)) { @mkdir($partialDir, 0755, true); }
            if ($creatorSectionDenied) {
              echo '<div class="settings-placeholder">'
                . '<div class="title">'
                . customLang('creator_access_required', 'Creator access required')
                . '</div>'
                . '<div class="desc">'
                . customLang('creator_access_required_desc', 'Only approved creators can view this section. Submit your creator application to unlock it.')
                . '</div>'
                . '</div>';
            }
            if (is_file($file)) { include $file; }
            else {
              $prompt = $emptyTabPrompts[$tab] ?? null;
              if (is_array($prompt) && !empty($prompt)) {
                echo '<div class="settings-placeholder">';
                $title = isset($prompt['title']) ? $prompt['title'] : ucwords(str_replace('_', ' ', $allowedTabs[$tab]));
                echo '<div class="title">' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</div>';
                if (!empty($prompt['items']) && is_array($prompt['items'])) {
                  echo '<ul class="settings-prompt-list">';
                  foreach ($prompt['items'] as $item) {
                    echo '<li>' . htmlspecialchars($item, ENT_QUOTES, 'UTF-8') . '</li>';
                  }
                  echo '</ul>';
                }
                echo '</div>';
              } else {
                echo '<div class="settings-placeholder">'
                  . '<div class="title">'
                  . htmlspecialchars(ucwords(str_replace('_',' ', $allowedTabs[$tab])), ENT_QUOTES, 'UTF-8')
                  . '</div>'
                  . '<div class="desc">'
                  . customLang('coming_soon')
                  . '</div>'
                  . '</div>';
              }
            }
          ?>
        </div>
      </div>
    </div>
  </div>
</div>
