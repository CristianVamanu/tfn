<?php
if (empty($enableImagePosts)) {
    echo '<div class="settings-placeholder">' . iN_HelpSecure(customLang('content_disabled_images')) . '</div>';
    return;
}
?>
<div class="main-content">
  <div class="page-hero flex align_items space_between">
    <div class="page-hero__title flex align_items gap">
      <span class="page-hero__icon flex align_items_justify_content"><?php echo render_icon('images', true); ?></span>
      <div class="page-hero__text flex flexBoxColumn">
        <h1 class="page-hero__heading"><?php echo iN_HelpSecure(customLang('page_images_heading', 'Images')); ?></h1>
        <p class="page-hero__subheading"><?php echo iN_HelpSecure(customLang('page_images_subheading', 'Latest photos from creators.')); ?></p>
      </div>
    </div>
  </div>
  <div
    class="reels_container flex align_items flexBoxColumn relative gap"
    id="images-feed"
    data-limit="10"
    data-offset="10">
    <?php
      $images = $RL->RL_FeedAllImages($userID, 10, 0);
      if (!$images) {
        $cta = '';
        if (isset($loggedIn) && $loggedIn === '1') {
          $cta = sprintf(
            '<div class="empty-state__body flex align_items flexBoxColumn gap">
                <p class="empty-state__subtitle">%s</p>
                <button type="button" class="empty-state__cta new_item" data-pop="createNew">%s</button>
            </div>',
            customLang('empty_state_create_prompt'),
            customLang('empty_state_create_button')
          );
        }

        echo sprintf(
          '<div class="empty-state flex align_items flexBoxColumn gap">'
          . '<div class="empty-state__icon flex align_items">%s</div>'
          . '<div class="empty-state__title flex align_items">%s</div>%s'
          . '</div>',
          render_icon('not_founded', true),
          customLang('empty_state_images'),
          $cta
        );
      }
      foreach ($images as $post) {
        $postId       = $post['post_id'] ?? null;
        $firstImage   = $post['first_image'] ?? ($post['post_file'] ?? '');
        if (function_exists('storage_resolve_media_url')) {
            $postFilePath = storage_resolve_media_url((string)$firstImage, $base_url ?? '');
        } else {
            $postFilePath = (string)($base_url ?? '') . ltrim((string)$firstImage, '/');
        }
        $hasMulti     = !empty($post['has_multiple_images']);
        $postViews    = $post['post_views'] ?? 0;
        $totalPostLike= $RL->RL_CountLikes((int)$postId);
        $totalComment = $RL->RL_TotalComment((int)$postId);
    ?>
      <div class="reels_post_wrapper relative getFullPost" data-post-id="<?php echo iN_HelpSecure($postId);?>">
        <?php
          // Alt text: caption -> tile by user -> generic
          $__cap = dzShortCaption($post, 80);
          $__u   = isset($post['owner_username']) ? (string)$post['owner_username'] : '';
          $__alt = $__cap !== '' ? $__cap : ($__u !== '' ? sprintf(customLang('alt_tile_by_user'), $__u) : customLang('image_alt_generic'));
        ?>
        <img class="post-media" src="<?php echo iN_HelpSecure($postFilePath);?>" alt="<?php echo iN_HelpSecure($__alt); ?>" loading="lazy" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
        <div class="tile-overlay flex align_items" aria-hidden="true">
          <span class="metric metric-like flex align_items">
            <span class="metric-icon flex align_items"><?php echo render_icon('post_liked', true);?></span>
            <span class="metric-value flex align_items"><?php echo iN_HelpSecure($totalPostLike);?></span>
          </span>
          <span class="metric metric-comment flex align_items">
            <span class="metric-icon flex align_items"><?php echo render_icon('post_commented', true);?></span>
            <span class="metric-value flex align_items"><?php echo iN_HelpSecure($totalComment);?></span>
          </span>
        </div>

        <div class="tile-total-view flex align_items">
          <div class="view-svg flex align_items"><?php echo renderVerifiedBadge(($iconPath ?? '') . 'view.svg', true);?></div>
          <div class="view-total flex align_items"><?php echo iN_HelpSecure((int)$postViews);?></div>
        </div>

        <?php if ($hasMulti): ?>
          <div class="multi-image-indicator flex align_items" aria-label="<?php echo iN_HelpSecure(customLang('media_multi_image_indicator')); ?>">
            <?php echo renderVerifiedBadge(($iconPath ?? '') . 'plus_image.svg', true); ?>
          </div>
        <?php endif; ?>
      </div>
    <?php } ?>

    <div id="images-infinite-sentinel" aria-hidden="true"></div>
  </div>
</div>

<?php $themePathExplore = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme);?>

<div id="images-loading" class="none" aria-live="polite"><?php echo customLang('ui_loading'); ?></div>

<script defer src="<?php echo $themePathExplore; ?>/js/getMoreImages.js"></script>
<script defer src="<?php echo $themePathExplore; ?>/js/getPost.js"></script>
