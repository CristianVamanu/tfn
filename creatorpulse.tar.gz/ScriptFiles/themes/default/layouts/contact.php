<?php
declare(strict_types=1);

$isLoggedIn = isset($loggedIn) && $loggedIn === '1';
$config = [];
try {
    $config = AdminMail::loadSettings($db);
} catch (RuntimeException $e) {
    if ($e->getMessage() !== 'smtp_not_configured') {
        $config = [];
    }
}
$defaults = [
    'allow_guest_messages' => 1,
    'guest_recaptcha_required' => 1,
    'max_message_length' => 1000,
    'subject_label_feedback' => customLang('admin_contact_subject_feedback') ?: 'Feedback',
    'subject_label_complaint' => customLang('admin_contact_subject_complaint') ?: 'Complaint',
    'subject_label_suggestion' => customLang('admin_contact_subject_suggestion') ?: 'Suggestion',
    'subject_label_bug' => customLang('admin_contact_subject_bug') ?: 'Bug Report',
    'recaptcha_enabled' => 0,
    'recaptcha_site_key' => '',
    'recaptcha_secret_key' => '',
];
$config = array_merge($defaults, array_intersect_key($config, $defaults));

$allowGuests = (int) $config['allow_guest_messages'] === 1;
$guestRecaptchaRequired = (int) $config['guest_recaptcha_required'] === 1;
$maxMessageLength = (int) $config['max_message_length'];
if ($maxMessageLength < 100) {
    $maxMessageLength = 100;
}
$subjectOptions = [
    'feedback' => (string) $config['subject_label_feedback'],
    'complaint' => (string) $config['subject_label_complaint'],
    'suggestion' => (string) $config['subject_label_suggestion'],
    'bug' => (string) $config['subject_label_bug'],
];

$recaptchaEnabled = (int) $config['recaptcha_enabled'] === 1;
$recaptchaSiteKey = trim((string) $config['recaptcha_site_key']);
$shouldShowRecaptcha = $recaptchaEnabled && $recaptchaSiteKey !== '' && (!$isLoggedIn || $guestRecaptchaRequired);

$prefillName = '';
$prefillEmail = '';
if ($isLoggedIn && isset($userData) && is_array($userData)) {
    $prefillName = trim((string) ($userData['user_fullname'] ?? $userData['username'] ?? ''));
    $prefillEmail = trim((string) ($userData['user_email'] ?? ''));
}

$formDisabled = (!$isLoggedIn && !$allowGuests);
$isMaintenanceLive = isset($GLOBALS['__MAINTENANCE_MODE_STATUS']) && strtolower((string)$GLOBALS['__MAINTENANCE_MODE_STATUS']) === 'on';
$intro = customLang('contact_intro_guest');
if ($isLoggedIn) {
    $introTemplate = customLang('contact_intro_user');
    if (strpos($introTemplate, '{{name}}') !== false) {
        $nameForIntro = $prefillName ?: (string) ($userData['username'] ?? customLang('contact_field_name') ?: 'creator');
        $intro = str_replace('{{name}}', iN_HelpSecure($nameForIntro), $introTemplate);
    } else {
        $intro = $introTemplate;
    }
}
$themeBase = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme ?? 'default');
$honeypotName = 'company_website';
$subjectKeys = array_keys($subjectOptions);
$initialType = $subjectKeys[0] ?? 'feedback';
?>
<div class="main-content contact-page">
  <div class="card contact-card flex flexBoxColumn gap">
    <header class="card-header flexBoxColumn">
      <h1><?php echo iN_HelpSecure(customLang('contact_title') ?: 'Contact Support'); ?></h1>
      <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure($intro); ?></p>
      <?php if ($isMaintenanceLive): ?>
        <p class="contact-maintenance-note">
          <?php echo iN_HelpSecure(customLang('contact_maintenance_notice') ?: 'We are in maintenance mode, so navigation, search, and notification shortcuts are temporarily disabled.'); ?>
        </p>
      <?php endif; ?>
      <?php if ($formDisabled): ?>
        <p class="form-helper contact-locked"><?php echo iN_HelpSecure(customLang('contact_error_guests_disabled') ?: 'Only registered members can use the contact form.'); ?></p>
      <?php endif; ?>
    </header>

    <form
      id="contactForm"
      class="form-container flex flexBoxColumn"
      method="post"
      action="<?php echo iN_HelpSecure($base_url); ?>request/contact.php"
      autocomplete="off"
      data-recaptcha="<?php echo $shouldShowRecaptcha ? '1' : '0'; ?>"
      data-recaptcha-required="<?php echo (!$isLoggedIn && $guestRecaptchaRequired && $shouldShowRecaptcha) ? '1' : '0'; ?>"
      data-disabled="<?php echo $formDisabled ? '1' : '0'; ?>"
      data-success-message="<?php echo htmlspecialchars(customLang('contact_success') ?: 'Thanks! Your message has been sent.', ENT_QUOTES, 'UTF-8'); ?>"
      data-error-generic="<?php echo htmlspecialchars(customLang('contact_error_generic') ?: 'We couldn’t send your message. Please try again later.', ENT_QUOTES, 'UTF-8'); ?>"
      data-error-recaptcha="<?php echo htmlspecialchars(customLang('contact_error_recaptcha') ?: 'Please complete the reCAPTCHA challenge.', ENT_QUOTES, 'UTF-8'); ?>"
      data-error-rate-limit="<?php echo htmlspecialchars(customLang('contact_error_rate_limit') ?: 'You have reached the hourly limit for contact messages.', ENT_QUOTES, 'UTF-8'); ?>"
      data-error-guests="<?php echo htmlspecialchars(customLang('contact_error_guests_disabled') ?: 'Only registered members can use the contact form at the moment.', ENT_QUOTES, 'UTF-8'); ?>"
      data-error-invalid-email="<?php echo htmlspecialchars(customLang('contact_error_invalid_email') ?: 'Please provide a valid email address.', ENT_QUOTES, 'UTF-8'); ?>"
      data-error-name-required="<?php echo htmlspecialchars(customLang('contact_error_name_required') ?: 'Please enter your name.', ENT_QUOTES, 'UTF-8'); ?>"
      data-error-message-required="<?php echo htmlspecialchars(customLang('contact_error_message_required') ?: 'Please enter a message.', ENT_QUOTES, 'UTF-8'); ?>"
    >
      <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>" />
      <input type="hidden" name="msg_type" id="contactMsgType" value="<?php echo iN_HelpSecure($initialType); ?>" />
      <input type="text" name="<?php echo $honeypotName; ?>" id="contactHp" class="sr-only" tabindex="-1" autocomplete="off" aria-hidden="true" />

      <div class="form-input-wrapper">
        <label class="form-label" for="contactName"><?php echo iN_HelpSecure(customLang('contact_field_name') ?: 'Your name'); ?></label>
        <input
          id="contactName"
          class="form-input"
          type="text"
          name="name"
          maxlength="120"
          value="<?php echo iN_HelpSecure($prefillName); ?>"
          <?php echo $isLoggedIn ? 'readonly' : 'required'; ?>
        />
      </div>

      <div class="form-input-wrapper">
        <label class="form-label" for="contactEmail"><?php echo iN_HelpSecure(customLang('contact_field_email') ?: 'Email address'); ?></label>
        <input
          id="contactEmail"
          class="form-input"
          type="email"
          name="email"
          maxlength="191"
          value="<?php echo iN_HelpSecure($prefillEmail); ?>"
          <?php echo $isLoggedIn ? 'readonly' : 'required'; ?>
        />
      </div>

      <div class="form-input-wrapper">
        <label class="form-label" for="contactSubject"><?php echo iN_HelpSecure(customLang('contact_field_subject') ?: 'Subject'); ?></label>
        <select id="contactSubject" class="form-input contact-select" name="subject" <?php echo $formDisabled ? 'disabled' : 'required'; ?>>
          <?php foreach ($subjectOptions as $type => $label): ?>
            <option value="<?php echo iN_HelpSecure($label); ?>" data-type="<?php echo iN_HelpSecure($type); ?>"><?php echo iN_HelpSecure($label); ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="form-input-wrapper">
        <label class="form-label" for="contactMessage"><?php echo iN_HelpSecure(customLang('contact_field_message') ?: 'Message'); ?></label>
        <textarea
          id="contactMessage"
          class="form-input"
          name="message"
          rows="6"
          maxlength="<?php echo iN_HelpSecure((string) $maxMessageLength); ?>"
          <?php echo $formDisabled ? 'disabled' : 'required'; ?>
        ></textarea>
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(sprintf(customLang('contact_max_length_hint') ?: 'Up to %d characters.', $maxMessageLength)); ?></p>
      </div>

      <?php if ($shouldShowRecaptcha): ?>
        <div class="form-input-wrapper">
          <div class="g-recaptcha" data-sitekey="<?php echo htmlspecialchars($recaptchaSiteKey, ENT_QUOTES, 'UTF-8'); ?>"></div>
        </div>
      <?php endif; ?>

      <div id="contactStatus" class="form-helper contact-status" role="status" aria-live="polite" hidden></div>

      <button type="submit" class="btn-hover contact-submit align-self-start" <?php echo $formDisabled ? 'disabled' : ''; ?>>
        <?php echo iN_HelpSecure(customLang('contact_submit') ?: 'Send Message'); ?>
      </button>
    </form>
  </div>
</div>

<script defer src="<?php echo $themeBase; ?>/js/contact.js?v=<?php echo iN_HelpSecure($version ?? '1'); ?>"></script>
<?php if ($shouldShowRecaptcha): ?>
  <?php dz_csp_register_source('script-src', 'https://www.google.com'); ?>
  <?php dz_csp_register_source('script-src', 'https://www.gstatic.com'); ?>
  <?php dz_csp_register_source('frame-src', 'https://www.google.com'); ?>
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
<?php endif; ?>
