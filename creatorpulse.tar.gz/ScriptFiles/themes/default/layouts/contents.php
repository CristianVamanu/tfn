<div class="main-content flex align_items">
    <div class="content-area flex">
        <!---->
        <div class="content-left">
            <div class="content-left-container flex align_items flexBoxColumn">
                <div class="feed-filter-bar" data-target="#posts" data-active-filter="all" data-loading-label="<?php echo iN_HelpSecure(customLang('ui_loading', 'Loading...')); ?>" role="group" aria-label="<?php echo iN_HelpSecure(customLang('feed_filter_label', 'Feed filter')); ?>">
                    <button type="button" class="feed-filter-button is-active" data-filter="all" aria-pressed="true">
                        <span class="feed-filter-icon" aria-hidden="true"><?php echo render_icon('home_page', true); ?></span>
                        <?php echo iN_HelpSecure(customLang('feed_filter_all', 'All')); ?>
                    </button>
                    <button type="button" class="feed-filter-button" data-filter="video" aria-pressed="false">
                        <span class="feed-filter-icon" aria-hidden="true"><?php echo render_icon('video', true); ?></span>
                        <?php echo iN_HelpSecure(customLang('feed_filter_reels', 'Reels')); ?>
                    </button>
                    <button type="button" class="feed-filter-button" data-filter="image" aria-pressed="false">
                        <span class="feed-filter-icon" aria-hidden="true"><?php echo render_icon('images', true); ?></span>
                        <?php echo iN_HelpSecure(customLang('feed_filter_images', 'Images')); ?>
                    </button>
                    <button type="button" class="feed-filter-button" data-filter="podcast" aria-pressed="false">
                        <span class="feed-filter-icon" aria-hidden="true">
                            <?php echo render_icon('podcast', true, 'themes/default/icons/podcast-c1bea17a82.svg'); ?>
                        </span>
                        <?php echo iN_HelpSecure(customLang('feed_filter_podcasts', 'Podcast')); ?>
                    </button>
                </div>
                <template id="feed-empty-icon-template"><?php echo render_icon('not_founded', true); ?></template>
                <div class="posts-container gap full-width relative flex align_items flexBoxColumn" id="posts"
                     data-loading-label="<?php echo iN_HelpSecure(customLang('ui_loading', 'Loading...')); ?>"
                     data-empty-title-all="<?php echo iN_HelpSecure(customLang('no_posts_yet', 'No posts yet')); ?>"
                     data-empty-subtitle-all="<?php echo iN_HelpSecure(customLang('empty_state_create_prompt', 'Share something new to kick things off.')); ?>"
                     data-empty-title-video="<?php echo iN_HelpSecure(customLang('feed_empty_reels_title', 'No reels yet')); ?>"
                     data-empty-subtitle-video="<?php echo iN_HelpSecure(customLang('feed_empty_reels_subtitle', 'Reels will appear here when creators share videos.')); ?>"
                     data-empty-title-image="<?php echo iN_HelpSecure(customLang('feed_empty_images_title', 'No images yet')); ?>"
                     data-empty-subtitle-image="<?php echo iN_HelpSecure(customLang('feed_empty_images_subtitle', 'Image posts will appear here when creators share photos.')); ?>"
                     data-empty-title-podcast="<?php echo iN_HelpSecure(customLang('feed_empty_podcasts_title', 'No podcasts yet')); ?>"
                     data-empty-subtitle-podcast="<?php echo iN_HelpSecure(customLang('feed_empty_podcasts_subtitle', 'Podcast posts will appear here when creators publish audio.')); ?>"
                     data-empty-cta="<?php echo (isset($loggedIn) && $loggedIn === '1') ? iN_HelpSecure(customLang('empty_state_create_button', 'Create a post')) : ''; ?>">
                    <?php
                        if (isset($creatorStatus) && $creatorStatus && $creatorStatus !== 'none' && isset($loggedIn) && $loggedIn === '1') {
                            $status = strtolower((string) $creatorStatus);
                            $bannerLink = '';
                            $bannerText = '';
                            $settingsBase = isset($base_url) ? rtrim((string) $base_url, '/') . '/settings' : 'settings';
                            if ($status === 'pending') {
                                $bannerText = customLang('creator_banner_pending', 'Your creator application is under review. We will notify you once an admin approves it.');
                            } elseif ($status === 'approved') {
                                $subscriptionEnabled = true;
                                $stateCandidates = [];
                                if (isset($userData) && is_array($userData)) {
                                    $stateCandidates = array_values(array_filter([
                                        strtolower((string) ($userData['subscription_status'] ?? '')),
                                        strtolower((string) ($userData['subscrition_status'] ?? '')),
                                    ], static function ($value) {
                                        return $value !== '';
                                    }));
                                }
                                if ($stateCandidates) {
                                    $subscriptionEnabled = false;
                                    foreach ($stateCandidates as $state) {
                                        if (in_array($state, ['open', 'active'], true)) {
                                            $subscriptionEnabled = true;
                                            break;
                                        }
                                    }
                                }

                                $plansConfigured = false;
                                if ($subscriptionEnabled && isset($userData) && is_array($userData) && isset($userData['user_id']) && isset($RL) && method_exists($RL, 'RL_GetUserSubscriptionPlans')) {
                                    try {
                                        $userPlans = $RL->RL_GetUserSubscriptionPlans((int) $userData['user_id']);
                                    } catch (Throwable $__) {
                                        $userPlans = [];
                                    }
                                    $planKeys = ['price_weekly', 'price_monthly', 'price_halfyear', 'price_yearly', 'weekly', 'monthly', 'halfyear', 'yearly'];
                                    foreach ($planKeys as $planKey) {
                                        if (!array_key_exists($planKey, $userPlans)) {
                                            continue;
                                        }
                                        $rawValue = $userPlans[$planKey];
                                        if (is_numeric($rawValue)) {
                                            $planValue = (float) $rawValue;
                                        } else {
                                            $planValue = filter_var((string) $rawValue, FILTER_VALIDATE_FLOAT);
                                            $planValue = $planValue === false ? 0.0 : (float) $planValue;
                                        }
                                        if ($planValue > 0) {
                                            $plansConfigured = true;
                                            break;
                                        }
                                    }
                                }

                                if ($subscriptionEnabled && !$plansConfigured) {
                                    $goUrl = $settingsBase . '?tab=creator_plans';
                                    $bannerText = customLang('creator_banner_approved', 'You are approved! Configure your subscription plans and payout method to start earning.');
                                    $bannerLink = '<a class="creator-alert__action" href="' . iN_HelpSecure($goUrl, false) . '">' . customLang('creator_banner_manage_plans', 'Set up plans') . '</a>';
                                }
                            } elseif ($status === 'rejected') {
                                $retryUrl = $settingsBase . '?tab=creator_identity';
                                $bannerText = customLang('creator_banner_rejected', 'Your creator request was rejected. Review the feedback and submit your documents again.');
                                $bannerLink = '<a class="creator-alert__action" href="' . iN_HelpSecure($retryUrl, false) . '">' . customLang('creator_banner_resubmit', 'Resubmit documents') . '</a>';
                            }
                            if ($bannerText !== '') {
                                echo '<div class="creator-alert">'
                                    . '<span class="creator-alert__text">' . iN_HelpSecure($bannerText, false) . '</span>'
                                    . $bannerLink
                                    . '</div>';
                            }
                        }
                    ?>
                    <?php include_once "post.php";?>
                    <div id="feed-sentinel" class="io-sentinel" aria-hidden="true"></div>
                </div>
            </div>
        </div>
        <!---->
        <!---->
        <div class="content-right flex align_items">
            <div class="content-right-container">
                <?php
                    include_once __DIR__ . '/widgets/suggestedUsers.php';
                    include_once __DIR__ . '/widgets/adsSidebar.php';
                    include_once __DIR__ . '/widgets/mosPopularPost.php';
                ?>
            </div>
        </div>
        <!---->
    </div>
</div>

<?php $themeBase = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme); ?>
<script defer src="<?php echo $themeBase; ?>/js/adsFeedSlots.js?v=<?php echo iN_HelpSecure($version); ?>"></script>
<script defer src="<?php echo $themeBase; ?>/js/feedMore.js?v=<?php echo iN_HelpSecure($version); ?>"></script>
<script defer src="<?php echo $themeBase; ?>/js/media.viewer.js?v=<?php echo iN_HelpSecure($version); ?>"></script>
