<?php
declare(strict_types=1);

$guestFeedLimit = isset($pageScrollLimit) ? (int) $pageScrollLimit : 20;
if ($guestFeedLimit <= 0) {
    $guestFeedLimit = 20;
}

$__externalPosts = [];
$guestHasMore = false;

if (isset($RL) && method_exists($RL, 'RL_GetGuestFeedPosts')) {
    $rows = $RL->RL_GetGuestFeedPosts($guestFeedLimit + 1, 0);
    $guestHasMore = count($rows) > $guestFeedLimit;
    if ($guestHasMore) {
        $rows = array_slice($rows, 0, $guestFeedLimit);
    }
    $__externalPosts = $rows;
}

$viewMode = 'feed';
$__suppressEmptyFeedMessage = false;
?>
<div class="main-content flex align_items">
    <div class="content-area flex">
        <!---->
        <div class="content-left">
            <div class="content-left-container flex align_items flexBoxColumn">
                <div
                    class="posts-container gap full-width relative flex align_items flexBoxColumn"
                    id="posts"
                    data-feed-endpoint="guest_feed_more"
                    data-feed-limit="<?php echo (int) $guestFeedLimit; ?>"
                >
                    <?php include __DIR__ . '/post.php'; ?>
                    <div
                        id="feed-sentinel"
                        class="io-sentinel"
                        aria-hidden="true"
                        data-has-more="<?php echo $guestHasMore ? '1' : '0'; ?>"
                    ></div>
                </div>
            </div>
        </div>
        <!---->
        <!---->
        <div class="content-right flex align_items">
            <div class="content-right-container">
                <?php
                    include_once __DIR__ . '/widgets/suggestedUsers.php';
                    include_once __DIR__ . '/widgets/mosPopularPost.php';
                ?>
            </div>
        </div>
        <!---->
    </div>
</div>

<?php $themeBase = iN_HelpSecure($base_url).'themes/'.iN_HelpSecure($currentTheme); ?>
<script defer src="<?php echo $themeBase; ?>/js/feedMore.js?v=<?php echo iN_HelpSecure($version);?>"></script>
