<?php
declare(strict_types=1);

$viewerId = isset($userID) ? (int)$userID : 0;
$library = ($viewerId > 0 && isset($RL) && method_exists($RL, 'RL_GetUserEbookLibrary'))
    ? $RL->RL_GetUserEbookLibrary($viewerId)
    : [];
$libraryBase = rtrim((string)($base_url ?? ''), '/') . '/';
$libraryCsrf = function_exists('generateCsrfToken') ? generateCsrfToken() : '';
$formatMoney = static function (float $amount, ?string $code = null): string {
    return function_exists('dz_format_currency') ? dz_format_currency($amount, $code) : number_format($amount, 2);
};
?>
<div class="main-content flex align_items">
  <div class="content-area flex">
    <div class="content-left">
      <div class="ebooks-page ebook-library-page full-width" data-request-url="<?php echo iN_HelpSecure($libraryBase . 'request/requests.php'); ?>" data-download-failed-label="<?php echo iN_HelpSecure(customLang('ebook_download_failed', 'Download could not be started.')); ?>">
        <header class="ebook-library-header">
          <div class="ebook-library-header__icon"><?php echo render_icon('ebook', true); ?></div>
          <div>
            <h1><?php echo customLang('ebook_library_title', 'My Library'); ?></h1>
            <p><?php echo customLang('ebook_library_subtitle', 'Your purchased and free eBooks are ready here.'); ?></p>
          </div>
          <a href="<?php echo iN_HelpSecure($libraryBase . 'ebooks'); ?>" class="ebook-library-browse"><?php echo customLang('ebook_browse_button', 'Browse eBooks'); ?></a>
        </header>

        <input type="hidden" name="csrf_token" value="<?php echo iN_HelpSecure($libraryCsrf); ?>">
        <?php if (!$library): ?>
          <section class="ebook-library-empty">
            <div><?php echo render_icon('ebook', true); ?></div>
            <h2><?php echo customLang('ebook_library_empty_title', 'Your library is empty'); ?></h2>
            <p><?php echo customLang('ebook_library_empty_text', 'Purchased and free eBooks will appear here.'); ?></p>
            <a href="<?php echo iN_HelpSecure($libraryBase . 'ebooks'); ?>"><?php echo customLang('ebook_browse_button', 'Browse eBooks'); ?></a>
          </section>
        <?php else: ?>
          <section class="ebook-library-grid" aria-label="<?php echo iN_HelpSecure(customLang('ebook_library_title', 'My Library')); ?>">
            <?php foreach ($library as $ebook):
              $ebookId = (int)($ebook['ebook_id'] ?? 0);
              $title = (string)($ebook['title'] ?? '');
              $slug = trim((string)($ebook['slug'] ?? ''));
              $coverPath = ltrim((string)($ebook['cover_path'] ?? ''), '/');
              $coverUrl = $coverPath !== '' ? $libraryBase . $coverPath : '';
              $downloadLimit = max(0, (int)($ebook['entitlement_limit'] ?? 0));
              $downloaded = max(0, (int)($ebook['entitlement_downloads'] ?? 0));
              $remaining = $downloadLimit > 0 ? max(0, $downloadLimit - $downloaded) : null;
              $expiresAt = (int)($ebook['expires_at'] ?? 0);
              $creatorName = trim((string)($ebook['user_fullname'] ?? '')) ?: (string)($ebook['username'] ?? '');
              $purchaseId = (int)($ebook['purchase_id'] ?? 0);
              $invoiceUrl = $purchaseId > 0 ? $libraryBase . 'invoice/ebook/' . $purchaseId : '';
            ?>
              <article class="ebook-library-item">
                <a class="ebook-library-item__cover" href="<?php echo iN_HelpSecure($libraryBase . 'ebook/' . rawurlencode($slug)); ?>">
                  <?php if ($coverUrl !== ''): ?><img src="<?php echo iN_HelpSecure($coverUrl); ?>" alt="<?php echo iN_HelpSecure($title); ?>" loading="lazy"><?php else: ?><?php echo render_icon('ebook', true); ?><?php endif; ?>
                </a>
                <div class="ebook-library-item__body">
                  <span class="ebook-library-item__creator"><?php echo iN_HelpSecure($creatorName); ?></span>
                  <h2><a href="<?php echo iN_HelpSecure($libraryBase . 'ebook/' . rawurlencode($slug)); ?>"><?php echo iN_HelpSecure($title); ?></a></h2>
                  <div class="ebook-library-item__meta">
                    <span><?php echo $remaining === null ? customLang('ebook_downloads_unlimited', 'Unlimited downloads') : strtr(customLang('ebook_downloads_remaining', '{count} downloads remaining'), ['{count}' => (string)$remaining]); ?></span>
                    <?php if ($expiresAt > 0): ?><span><?php echo strtr(customLang('ebook_access_expires', 'Access expires {date}'), ['{date}' => date('M j, Y', $expiresAt)]); ?></span><?php endif; ?>
                    <?php if ($invoiceUrl !== ''): ?><a href="<?php echo iN_HelpSecure($invoiceUrl); ?>" target="_blank" rel="noopener noreferrer"><?php echo customLang('settings_payments_invoice_view', 'View invoice'); ?></a><?php endif; ?>
                  </div>
                  <button type="button" class="ebook-download-btn" data-secure-ebook-download data-ebook-id="<?php echo $ebookId; ?>"><?php echo render_icon('download', true); ?><span><?php echo customLang('ebook_download_button', 'Download'); ?></span></button>
                </div>
              </article>
            <?php endforeach; ?>
          </section>
        <?php endif; ?>
      </div>
    </div>
    <div class="content-right flex align_items"><div class="content-right-container"><?php include __DIR__ . '/widgets/suggestedUsers.php'; include __DIR__ . '/widgets/adsSidebar.php'; ?></div></div>
  </div>
</div>
<script defer src="<?php echo iN_HelpSecure($libraryBase . 'themes/' . $currentTheme . '/js/ebooks.js?v=' . $version); ?>"></script>
