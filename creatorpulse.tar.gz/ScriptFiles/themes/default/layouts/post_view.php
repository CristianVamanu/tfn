<?php
declare(strict_types=1);

/**
 * post_view.php
 * Unified renderer for feed, single, and full-post overlay.
 *
 * Usage:
 *   $viewMode = 'feed'|'single'|'full'; // default: 'feed'
 *   include __DIR__ . '/post_view.php';
 *
 * Developer Notes:
 * - This file **does not** contain any inline JavaScript. All AJAX/event logic must be handled by external JS
 *   (e.g., main.js / getPost.js). We only provide consistent HTML hooks (classes + data-* attributes).
 * - Each post root element now includes:
 *     data-id         : numeric post id (required by all AJAX actions)
 *     data-type       : 'image'|'video' (useful for handlers)
 *     data-source     : 'feed'|'popup' (helps view-tracking endpoints to understand context)
 *     data-owner-id   : numeric owner id (guards like "owner shouldn't count as a view")
 * - For view tracking (IntersectionObserver), target `.reel-item[data-id]` blocks. We purposely mark the **post root**.
 */

// ----- Resolve mode -----
$__mode = isset($viewMode) && in_array($viewMode, ['feed','single','full'], true) ? $viewMode : 'feed';

$__sourceTag = ($__mode === 'full') ? 'popup' : 'feed';

// ----- Common preconditions -----
$viewerId    = isset($userID) ? (int) $userID : 0;
$uploadsPath = isset($uploadsPath) ? rtrim((string) $uploadsPath, '/') . '/' : (rtrim($base_url ?? '', '/') . '/');
$__fallbackMediaBase = rtrim($uploadsPath, '/') . '/';

$__resolveMediaUrl = static function (string $path) use ($__fallbackMediaBase): string {
    if (function_exists('storage_resolve_media_url')) {
        return storage_resolve_media_url($path, $__fallbackMediaBase);
    }

    $base = $__fallbackMediaBase !== '' ? $__fallbackMediaBase : '';

    return $base . ltrim(trim($path), '/');
};

$__currencyCode = isset($globalCurCode) ? strtoupper((string) $globalCurCode) : (isset($currency) ? strtoupper((string) $currency) : 'USD');
$__currenciesMap = [];
if (isset($currencies) && is_array($currencies)) {
    $__currenciesMap = $currencies;
} elseif (isset($currencys) && is_array($currencys)) {
    $__currenciesMap = $currencys;
}
$__currencySymbol = '';
if (isset($__currenciesMap[$__currencyCode])) {
    $__currencySymbol = (string) $__currenciesMap[$__currencyCode];
}
$__currencyFormatSettings = $GLOBALS['currency_format_settings'] ?? null;
if (!is_array($__currencyFormatSettings) || !isset($__currencyFormatSettings['position'])) {
    if (isset($GLOBALS['currency_format_client']) && is_array($GLOBALS['currency_format_client'])) {
        $cfc = $GLOBALS['currency_format_client'];
        $__currencyFormatSettings = [
            'position'        => $cfc['position']      ?? 'left',
            'decimal_places'  => $cfc['decimalPlaces'] ?? 2,
            'decimal_sep'     => $cfc['decimalSep']    ?? '.',
            'thousands_sep'   => $cfc['thousandsSep']  ?? ',',
        ];
    } else {
        $__currencyFormatSettings = dz_currency_normalize_settings((array) $__currencyFormatSettings);
    }
}
$__currencyPosition = $__currencyFormatSettings['position'] ?? 'left';
// Provide formatted string and raw number for JS to avoid overriding server format
$__formatCurrency = static function ($amount) use ($__currencyCode, $__currencySymbol, $__currencyFormatSettings): string {
    return dz_format_currency((float) $amount, $__currencyCode, $__currencySymbol, $__currencyFormatSettings);
};
// Plain number and display pair for JS to reuse without reformatting
$__formatCurrencyPair = static function ($amount) use ($__currencyCode, $__currencySymbol, $__currencyFormatSettings): array {
    return [
        'raw' => (float) $amount,
        'display' => dz_format_currency((float) $amount, $__currencyCode, $__currencySymbol, $__currencyFormatSettings),
        'position' => $GLOBALS['currency_format_settings']['position'] ?? ($__currencyFormatSettings['position'] ?? 'left'),
    ];
};

$__preferences = isset($userPreferences) && is_array($userPreferences) ? $userPreferences : [];
$__prefAutoplay = array_key_exists('feed_autoplay', $__preferences) ? (bool) $__preferences['feed_autoplay'] : true;
$__prefMuted    = array_key_exists('feed_muted', $__preferences) ? (bool) $__preferences['feed_muted'] : true;

$__buildVideoAttributes = static function (string $src, bool $autoplay, bool $muted, ?string $poster = null): string {
    $attrs = [
        'class="post-media"',
        'preload="metadata"',
        'src="' . iN_HelpSecure($src) . '"',
        'loop',
        'playsinline',
        'data-pref-autoplay="' . ($autoplay ? 'on' : 'off') . '"'
    ];
    if ($poster) {
        $attrs[] = 'poster="' . iN_HelpSecure($poster) . '"';
    }
    if ($muted)    { $attrs[] = 'muted'; }
    $attrs[] = 'data-observe="1"';
    return implode(' ', $attrs);
};

// ----- Build $posts -----
$posts = [];
// If an external list is provided (e.g., Premium purchases), always use it — never fall back to general feed
if ($__mode === 'feed') {
    if (isset($__externalPosts)) {
        $posts = is_array($__externalPosts) ? $__externalPosts : [];
    } else {
        $limit  = isset($limit) ? (int) $limit : 20;
        $offset = isset($offset) ? (int) $offset : 0;
        $posts  = $RL->RL_FeedRelatedVisible($viewerId, $limit, $offset);
    }
} else {
    // SINGLE / FULL
    $postIdParam   = $_GET['post_id']  ?? ($postIdParam ?? '');
    $usernameParam = $_GET['username'] ?? ($usernameParam ?? '');

    if (!preg_match('/^\d+$/', (string) $postIdParam)) {
        http_response_code(404);
        require_once __DIR__ . '/../404.php';
        exit;
    }
    $postId   = (int) $postIdParam;
    $expected = ($usernameParam !== '' && preg_match('/^[A-Za-z0-9_]+$/', (string) $usernameParam)) ? $usernameParam : null;

    /** @var array<string,mixed>|null $singlePost */
    $singlePost = $RL->RL_GetPostById($postId, $viewerId, $expected);
    if (!$singlePost) {
        http_response_code(404);
        // Force full 404 page instead of rendering inside layout
        $redirect404 = isset($base_url) ? rtrim((string)$base_url, '/') . '/404' : '/404';
        header('Location: ' . $redirect404);
        exit;
    }
    $posts = [$singlePost];
}

// ----- Open layout wrappers -----
if ($__mode === 'single') {
    ?>
<div class="main-content flex align_items">
    <div class="content-area flex">
        <!---->
        <div class="content-left">
            <div class="content-left-container flex align_items flexBoxColumn">
                <div class="posts-container gap full-width relative flex align_items flexBoxColumn" id="posts">
    <?php
} elseif ($__mode === 'full') {
    ?>
<div class="full-post-container flex align_items_justify_content ">
    <div class="full-post-wrapper full-width relative flex align_items_justify_content">
    <?php
}

/** Developer: In feed mode, if there are no posts, render the standard "no posts" message.
 *  AJAX loaders can replace this container dynamically as needed.
 */
// ----- If feed has no posts, render message (existing behavior) -----
if ($__mode === 'feed' && (!$posts || !is_array($posts)) && empty($__suppressEmptyFeedMessage)) {
    $cta = '';
    if (isset($loggedIn) && $loggedIn === '1') {
        $cta = sprintf(
            '<div class="empty-state__body flex align_items flexBoxColumn gap">
                <p class="empty-state__subtitle">%s</p>
                <button type="button" class="empty-state__cta new_item" data-pop="createNew">%s</button>
            </div>',
            customLang('empty_state_create_prompt'),
            customLang('empty_state_create_button')
        );
    }

    echo sprintf(
        '<div class="empty-state no-posts full-width flex align_items flexBoxColumn gap">'
        . '<div class="empty-state__icon flex align_items">%s</div>'
        . '<div class="empty-state__title flex align_items">%s</div>%s'
        . '</div>',
        render_icon('not_founded', true),
        customLang('no_posts_yet'),
        $cta
    );
}

// ----- Shared renderer: iterate once for single/full, many for feed -----
$__feedAdInterval = 5;
$__feedAdCursor = 0;
$__feedAds = [];
$__feedAdPartial = __DIR__ . '/../partials/feedAd.php';
$__canRenderFeedAds = (
    $__mode === 'feed'
    && empty($__externalPosts)
    && empty($__suppressFeedAds)
    && !empty($enableAds)
    && is_file($__feedAdPartial)
    && isset($RL)
    && method_exists($RL, 'RL_GetActiveAdvertisementsForFeed')
);
if ($__canRenderFeedAds && is_array($posts) && count($posts) >= $__feedAdInterval) {
    $adSlotsNeeded = min(3, (int) floor(count($posts) / $__feedAdInterval));
    try {
        $__feedAds = $RL->RL_GetActiveAdvertisementsForFeed($adSlotsNeeded, [], $viewerId > 0 ? $viewerId : null, 'image');
    } catch (Throwable $__) {
        $__feedAds = [];
    }
}
$__feedAdBaseUrl = isset($base_url) ? (string) $base_url : '';
$__renderFeedAd = static function (array $adRow) use ($__feedAdPartial, $__feedAdBaseUrl, $RL): void {
    $base = $__feedAdBaseUrl !== '' ? rtrim($__feedAdBaseUrl, '/') . '/' : '/';
    $resolveMedia = static function (string $path) use ($base): string {
        $path = trim($path);
        if ($path === '') {
            return '';
        }
        if (function_exists('storage_resolve_media_url')) {
            return storage_resolve_media_url($path, $base);
        }
        return $base . ltrim($path, '/');
    };

    $mediaItems = isset($adRow['media_items']) && is_array($adRow['media_items']) ? $adRow['media_items'] : [];
    $mediaUrls = [];
    foreach ($mediaItems as $path) {
        $resolved = $resolveMedia((string) $path);
        if ($resolved !== '') {
            $mediaUrls[] = $resolved;
        }
    }
    if (!$mediaUrls) {
        return;
    }

    $username = (string) ($adRow['username'] ?? '');
    $profileUrl = $base . 'profile/' . rawurlencode($username);
    $adLink = (string) ($adRow['ad_link'] ?? '');
    $ad = $adRow;
    $ad['media_urls'] = $mediaUrls;
    $ad['primary_media_url'] = $mediaUrls[0];
    $ad['profile_url'] = $profileUrl;
    $ad['target_url'] = $adLink !== '' ? $adLink : $profileUrl;
    $ad['ad_link'] = $adLink;
    if (($ad['media_type'] ?? '') === 'video' && method_exists($RL, 'videoThumbNail')) {
        try {
            $ad['video_thumb_url'] = (string) $RL->videoThumbNail($mediaUrls[0]);
        } catch (Throwable $__) {
            $ad['video_thumb_url'] = '';
        }
    }
    include $__feedAdPartial;
};
if ($posts && is_array($posts)) :
    foreach ($posts as $post) :
        $__feedAdCursor++;
        // Ensure required locals are available for the template extracted below
        $ownerProfileUrl = ($base_url ?? '') . 'profile/' .($post['owner_username'] ?? '');
        $postPrice = $post['post_price'] ?? null;
        $ownerAvatar     = $RL->RL_userAvatar($post['post_owner_id']);
        $timeLabel       = dz_relative_time_label((int) ($post['post_created_time'] ?? time()));
        $postFiles       = array_filter(array_map('trim', explode(',', (string) ($post['post_file'] ?? ''))));
        $lockedPreviewPathValue = isset($post['locked_preview_path']) ? (string) $post['locked_preview_path'] : '';
        $lockedPreviewTypeValue = strtolower((string)($post['locked_preview_type'] ?? ''));
        $lockedPreviewUrl = '';
        if ($lockedPreviewPathValue !== '') {
            $lockedPreviewUrl = $__resolveMediaUrl($lockedPreviewPathValue);
        }
        $hasLockedPreview = $lockedPreviewUrl !== '' && in_array($lockedPreviewTypeValue, ['static', 'animated'], true);
        $teaserPath = '';
        $teaserUrl = '';
        if (isset($RL) && method_exists($RL, 'RL_GetPostTeaserPath')) {
            $teaserPath = (string) $RL->RL_GetPostTeaserPath((int) ($post['post_id'] ?? 0));
            if ($teaserPath !== '') {
                $teaserUrl = $__resolveMediaUrl($teaserPath);
            }
        }
        $hasTeaser = $teaserUrl !== '';
        $teaserExtension = '';
        if ($hasTeaser) {
            $teaserUrlPath = parse_url($teaserUrl, PHP_URL_PATH);
            $teaserExtension = strtolower(pathinfo((string) ($teaserUrlPath ?: $teaserUrl), PATHINFO_EXTENSION));
        }
        $teaserIsAudio = in_array($teaserExtension, ['mp3', 'm4a', 'aac', 'wav', 'ogg', 'oga'], true);
        // Build simple media summary for locked purchase prompt
        $mediaSummary = '';
        if (!empty($post['post_type']) && $post['post_type'] === 'image') {
            $imgCount = (int)count($postFiles);
            if ($imgCount > 0) {
                $mediaSummary = $imgCount . ' ' . ($imgCount === 1 ? 'image' : 'images');
            }
        } elseif (!empty($post['post_type']) && $post['post_type'] === 'podcast') {
            $mediaSummary = '1 podcast';
        } else {
            $mediaSummary = '1 video';
        }
        $podcastCategoryName = '';
        $podcastCategorySlug = '';
        $podcastCategoryUrl  = '';
        if (!empty($post['post_type']) && $post['post_type'] === 'podcast') {
            $podcastCategoryName = isset($post['podcast_category_name']) ? trim((string)$post['podcast_category_name']) : '';
            $podcastCategorySlug = isset($post['podcast_category_slug']) ? trim((string)$post['podcast_category_slug']) : '';
            if ($podcastCategoryName !== '') {
                $podcastCategoryUrl = ($base_url ?? '') . 'profile/' . ($post['owner_username'] ?? '') . '/podcasts';
                if ($podcastCategorySlug !== '') {
                    $podcastCategoryUrl .= '?category=' . rawurlencode($podcastCategorySlug);
                }
            }
        }

        // ------- Visibility resolution (kept identical) -------
        $canView = true;
        $visibilityMessage = '';
        $postType = $post['post_type'] ?? null;

        $totalComments = (int) $RL->RL_TotalComment((int) ($post['post_id'] ?? 0));
        $thanksCount   = (int) (method_exists($RL, 'RL_CountPostTips') ? $RL->RL_CountPostTips((int)($post['post_id'] ?? 0)) : 0);

        if (empty($post['is_owner'])) {
            switch ($post['post_visibility']) {
                case 'everyone':
                    $canView = true;
                    break; // visible to all
                case 'followers':
                    $relV2O   = $post['viewer_to_owner_status'] ?? ($post['relation_status'] ?? null);
                    $canView  = in_array($relV2O, ['flwr','subscriber'], true);
                    if (!$canView) { $visibilityMessage = customLang('post_only_followers'); }
                    break; // require follower/subscriber
                case 'subscribers':
                    $relV2O   = $post['viewer_to_owner_status'] ?? ($post['relation_status'] ?? null);
                    $canView  = ($relV2O === 'subscriber');
                    if (!$canView) {
                        $visibilityMessage = '<div class="unlock-box flex align_items_justify_content flexBoxColumn gap">'
    . '<div class="unlock-icon flex align_items">'
    . '<div class="locked">' . render_icon('locked', true) . '</div>'
    . '<div class="unlock">' . render_icon('unlocked', true) . '</div>'
    . '</div>'
    . '<div class="unlock-text flex align_items_justify_content">' . customLang('exclusive_for_subscriber_join_now') . '</div>'
    . '<div class="unlock-price flex align_items transition subscribeMe" data-id="' . $post['post_owner_id'] . '">' . customLang('join_now') . '</div></div>';
                    }
                    break; // require active subscriber
                case 'locked':
                    $purchased = $RL->hasPurchasedPost($viewerId, (int) $post['post_id']);
                    if (!$purchased) {
                        $canView = false; // locked: require purchase
                        $detailsHtml = $mediaSummary !== '' ? ('<div class="unlock-details flex align_items_justify_content">'.customLang('contains_x_premium_content').'</div>') : '';
                        $unlockFmt = $__formatCurrencyPair($postPrice);
                        $visibilityMessage = '<div class="unlock-box flex align_items_justify_content flexBoxColumn gap">'
                            . '<div class="unlock-icon flex align_items">'
                            .      '<div class="locked">' . render_icon('locked', true) . '</div>'
                            .      '<div class="unlock">' . render_icon('unlocked', true) . '</div>'
                            .  '</div>'
                            . '<div class="unlock-text flex align_items_justify_content">' . customLang('post_locked_purchase_to_view'). '</div>'
                            . $detailsHtml
                            . '<div class="unlock-price flex align_items transition unlockPost" data-id="'.$post['post_id'].'" data-price="'.iN_HelpSecure((string)$unlockFmt['raw']).'" data-price-display="'.iN_HelpSecure($unlockFmt['display']).'" data-currency-position="'.iN_HelpSecure($unlockFmt['position']).'">'. customLang('unlock_for') . ' ' . iN_HelpSecure($unlockFmt['display']) .'</div>'
                            . '</div>';
                    }
                    break; // locked: require purchase
            }
        }

        $approvalStatus = strtolower((string)($post['approval_status'] ?? 'approved'));
        $approvalNotes = isset($post['approval_notes']) ? trim((string)$post['approval_notes']) : '';
        $approvalBlocked = in_array($approvalStatus, ['pending', 'rejected'], true);
        $viewerIsAdmin = isset($isAdminUser)
            ? (bool) $isAdminUser
            : (bool) ($post['viewer_is_admin'] ?? ($GLOBALS['isAdminUser'] ?? false));
        if ($approvalBlocked && !$viewerIsAdmin && empty($post['is_owner'])) {
            // Safety: pending/rejected posts should not appear for unrelated viewers.
            continue;
        }
        $approvalLabel = $approvalStatus === 'rejected'
            ? (customLang('post_status_rejected') ?: 'Rejected')
            : (customLang('post_status_pending') ?: 'Pending approval');
        $approvalMessage = $approvalStatus === 'rejected'
            ? (customLang('post_status_rejected_message') ?: 'This post was rejected and is hidden from others.')
            : (customLang('post_status_pending_message') ?: 'This post is waiting for admin approval.');

        // ------- START: shared post markup (verbatim extracted) -------
        ?>
    <div
      class="post_ reel-item full-width relative flex align_items flexBoxColumn"
      id="post-<?php echo (int) $post['post_id']; ?>"
      data-id="<?php echo (int) $post['post_id']; ?>"
      data-type="<?php echo iN_HelpSecure((string) ($post['post_type'] ?? '')); ?>"
      data-source="<?php echo iN_HelpSecure($__sourceTag); ?>"
      data-owner-id="<?php echo (int) ($post['post_owner_id'] ?? 0); ?>"
      data-visibility="<?php echo iN_HelpSecure((string)($post['post_visibility'] ?? 'everyone')); ?>"
      data-price="<?php echo (int) ($post['post_price'] ?? 0); ?>"
      data-min-price="<?php echo (int)($premiumPostPriceMinimum ?? 1); ?>"
      data-max-price="<?php echo (int)($premiumPostPriceMaximum ?? 500); ?>"
      data-text="<?php echo iN_HelpSecure((string)($post['post_text'] ?? '')); ?>"
      data-comments="<?php echo (($post['comment_status'] ?? 'on') === 'on') ? 'on' : 'off'; ?>"
      data-approval="<?php echo iN_HelpSecure($approvalStatus); ?>"
    >
    <!--Post HEADER-->
    <div class="post_header full-width relative flex align_items column-gap">
        <div class="post_owner_avatar relative flex align_items">
            <div class="user-avatar relative flex align_items">
                <?php
                  $___ownerName = ($post['owner_fullname'] ?: $post['owner_username']);
                  $___ownerAlt  = sprintf(customLang('alt_avatar_of_user'), (string)$___ownerName);
                ?>
                <?php
                  $ownerAvatarUrl = $ownerAvatar;
                  if (function_exists('storage_resolve_media_url')) {
                      $ownerAvatarUrl = storage_resolve_media_url((string)$ownerAvatar, $base_url ?? '');
                  } else {
                      $ownerAvatarUrl = (string)($base_url ?? '') . ltrim((string)$ownerAvatar, '/');
                  }
                ?>
                <img class="avatar-img relative" src="<?php echo iN_HelpSecure($ownerAvatarUrl); ?>" alt="<?php echo iN_HelpSecure($___ownerAlt); ?>">
            </div>
        </div>
        <div class="post-owner-data full-width relative flex align_items flexBoxColumn">
            <div class="post-owner-name full-width flex align_items post-owner-name-img">
                <a href="<?php echo iN_HelpSecure($ownerProfileUrl); ?>"><?php echo iN_HelpSecure($post['owner_fullname'] ?: $post['owner_username']); ?></a>
                <?php if ((int) $post['owner_verified'] === 1) { echo render_icon('verified', true); } ?>
            </div>
            <div class="post-share-data full-width flex align_items">
                <div class="post-share-time flex align_items"><?php echo iN_HelpSecure($timeLabel); ?></div>
                <?php if ($approvalBlocked): ?>
                    <div class="post-approval-chip post-approval-chip--<?php echo iN_HelpSecure($approvalStatus); ?>">
                        <?php echo iN_HelpSecure($approvalLabel); ?>
                    </div>
                <?php endif; ?>
                <?php if ($post['post_type'] === 'podcast' && $podcastCategoryName !== ''): ?>
                    <a class="post-category-chip" href="<?php echo iN_HelpSecure($podcastCategoryUrl); ?>">
                        <?php echo iN_HelpSecure($podcastCategoryName); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <?php if ((int) ($viewerId ?? 0) > 0): ?>
          <div class="post-settings-btn-box flex align_items relative">
              <?php
                  $postUrl = iN_HelpSecure(($base_url ?? '') . 'posts/' . (int)$post['post_id'] . '/' . ($post['owner_username'] ?? ''));
                  $isOwner = (int)($post['post_owner_id'] ?? 0) === (int)($viewerId ?? 0);
              ?>
              <div
                class="post-settings-btn flex align_items_justify_content relative"
                role="button"
                tabindex="0"
                aria-haspopup="dialog"
                aria-expanded="false"
                data-id="<?php echo (int)$post['post_id']; ?>"
                data-url="<?php echo $postUrl; ?>"
                data-username="<?php echo iN_HelpSecure((string)($post['owner_username'] ?? '')); ?>"
              ><?php echo render_icon('dots', true); ?></div>
          </div>
        <?php endif; ?>
    </div>
    <!--/Post HEADER-->

    <!--POST BODY-->
    <div class="post-body full-width flex align_items flexBoxColumn">
        <?php if ($canView) : ?>
            <?php if (($post['post_type'] ?? '') === 'image') : ?>
                <?php if (count($postFiles) > 1) : ?>
                    <div class="post-media-swiper swiper">
                        <div class="swiper-wrapper">
                            <?php foreach ($postFiles as $idx => $f) :
                                $mediaSrc = $__resolveMediaUrl($f);
                                if ($mediaSrc === '') { continue; }
                            ?>
                                <div class="swiper-slide">
                                    <img src="<?php echo iN_HelpSecure($mediaSrc); ?>" alt="<?php echo iN_HelpSecure(sprintf(customLang('image_alt_sequence'), (int) ($idx + 1))); ?>" loading="lazy" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="swiper-pagination"></div>
                        <div class="swiper-button-prev" aria-label="<?php echo iN_HelpSecure(customLang('carousel_prev_label')); ?>"></div>
                        <div class="swiper-button-next" aria-label="<?php echo iN_HelpSecure(customLang('carousel_next_label')); ?>"></div>
                    </div>
                <?php else : ?>
                    <?php
                        $single = $postFiles ? reset($postFiles) : '';
                        $singleSrc = $single !== '' ? $__resolveMediaUrl((string)$single) : '';
                        if ($singleSrc !== '') :
                    ?>
                        <div class="post-media-single">
                            <img src="<?php echo iN_HelpSecure($singleSrc); ?>" alt="<?php echo iN_HelpSecure(customLang('image_alt_generic')); ?>" loading="lazy" data-lazy-dimensions="skip" data-skip-image-dimensions="true">
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php elseif (($post['post_type'] ?? '') === 'podcast') : ?>
                <?php
                    $audioKey    = (string) ($post['post_file'] ?? '');
                    $audioSrc    = $__resolveMediaUrl($audioKey);
                    $coverPath   = isset($post['cover_path']) ? (string) $post['cover_path'] : '';
                    if ($coverPath === '' && isset($RL) && method_exists($RL, 'RL_GetPostCoverPath')) {
                        $coverPath = $RL->RL_GetPostCoverPath((int) ($post['post_id'] ?? 0));
                    }
                    $coverUrl    = $coverPath !== '' ? $__resolveMediaUrl($coverPath) : '';
                    $durationSec = isset($post['audio_duration_seconds']) ? (int) $post['audio_duration_seconds'] : null;
                    $initialTime = $durationSec ? '0:00 / ' . gmdate('i:s', $durationSec) : '0:00';
                ?>
                <div class="post-media-audio full-width flex align_items flexBoxColumn">
                    <div class="podcast-player-card">
                        <?php if ($coverUrl !== '') : ?>
                            <div class="podcast-card-backdrop" aria-hidden="true">
                                <img src="<?php echo iN_HelpSecure($coverUrl); ?>" alt="">
                            </div>
                        <?php endif; ?>
                        <?php if ($coverUrl !== '') : ?>
                            <div class="podcast-cover-preview">
                                <img src="<?php echo iN_HelpSecure($coverUrl); ?>" alt="<?php echo iN_HelpSecure(customLang('podcast_cover_alt', 'Podcast cover')); ?>" loading="lazy">
                            </div>
                        <?php endif; ?>
                        <div class="podcast-visual">
                            <div class="podcast-bars left">
                                <span></span><span></span><span></span><span></span><span></span>
                            </div>
                            <div class="podcast-bars right">
                                <span></span><span></span><span></span><span></span><span></span>
                            </div>
                        </div>
                        <div class="podcast-progress" role="group" aria-label="<?php echo iN_HelpSecure(customLang('upload_podcast', 'Podcast')); ?>">
                            <div class="podcast-progress-track">
                                <div class="podcast-progress-fill"></div>
                                <div class="podcast-progress-thumb" aria-hidden="true"></div>
                            </div>
                            <div class="podcast-time"><?php echo iN_HelpSecure($initialTime); ?></div>
                        </div>
                        <div class="podcast-controls">
                            <button type="button" class="podcast-btn rewind" aria-label="<?php echo iN_HelpSecure(customLang('ui_rewind_10', 'Rewind 10 seconds')); ?>">&#9198;</button>
                            <button type="button" class="podcast-btn play" aria-label="<?php echo iN_HelpSecure(customLang('ui_play_pause', 'Play / Pause')); ?>">
                                <span class="icon-play">&#9658;</span>
                                <span class="icon-pause">❚❚</span>
                            </button>
                            <button type="button" class="podcast-btn forward" aria-label="<?php echo iN_HelpSecure(customLang('ui_forward_10', 'Forward 10 seconds')); ?>">&#9197;</button>
                        </div>
                        <audio class="podcast-audio-element" preload="metadata" src="<?php echo iN_HelpSecure($audioSrc); ?>"></audio>
                    </div>
                </div>
            <?php else : ?>
                <!-- Video -->
                <div class="video-wrapper video-wrapper--reel" data-video-mode="reel">
                    <!-- Developer: External JS may listen to 'play' on this video to trigger a single 'view' event for popup/full view. -->
                    <?php
                        $videoSrc = $__resolveMediaUrl((string)($post['post_file'] ?? ''));
                        if ($videoSrc === '' && !empty($postFiles)) {
                            $firstMedia = reset($postFiles);
                            $videoSrc = $__resolveMediaUrl((string)$firstMedia);
                        }

                        $videoPoster = '';
                        if ($videoSrc !== '' && isset($RL) && method_exists($RL, 'videoThumbNail')) {
                            try {
                                $videoPoster = $RL->videoThumbNail($videoSrc);
                            } catch (Throwable $__) {
                                $videoPoster = '';
                            }
                        }
                    ?>
                    <?php if ($videoSrc !== '') : ?>
                    <video <?php echo $__buildVideoAttributes($videoSrc, $__prefAutoplay, $__prefMuted, $videoPoster ?: null); ?>></video>
                    <div class="video-speed-control" data-video-id="<?php echo (int) $post['post_id']; ?>">
                        <button
                            type="button"
                            class="video-speed-toggle"
                            data-video-id="<?php echo (int) $post['post_id']; ?>"
                            aria-label="<?php echo iN_HelpSecure(customLang('video_speed_label', 'Playback speed')); ?>"
                            aria-expanded="false"
                            aria-controls="video-speed-menu-<?php echo (int) $post['post_id']; ?>"
                        >
                            <span class="video-speed-toggle-text"><?php echo iN_HelpSecure(customLang('video_speed_option_1x', '1x')); ?></span>
                            <span class="video-speed-toggle-icon" aria-hidden="true">
                                <?php echo render_icon('down_arrow', true); ?>
                            </span>
                        </button>
                        <div
                            class="video-speed-menu"
                            id="video-speed-menu-<?php echo (int) $post['post_id']; ?>"
                            data-video-id="<?php echo (int) $post['post_id']; ?>"
                            role="menu"
                            aria-label="<?php echo iN_HelpSecure(customLang('video_speed_label', 'Playback speed')); ?>"
                            aria-hidden="true"
                        >
                            <div class="video-speed-menu-title"><?php echo iN_HelpSecure(customLang('video_speed_label', 'Playback speed')); ?></div>
                            <button
                                type="button"
                                class="video-speed-option is-active"
                                data-speed="1"
                                data-speed-label="<?php echo iN_HelpSecure(customLang('video_speed_option_1x', '1x')); ?>"
                                role="menuitemradio"
                                aria-checked="true"
                            >
                                <span class="video-speed-option-label"><?php echo iN_HelpSecure(customLang('video_speed_normal', 'Normal')); ?></span>
                                <span class="video-speed-option-suffix"><?php echo iN_HelpSecure(customLang('video_speed_option_1x', '1x')); ?></span>
                            </button>
                            <button
                                type="button"
                                class="video-speed-option"
                                data-speed="1.5"
                                data-speed-label="<?php echo iN_HelpSecure(customLang('video_speed_option_1_5x', '1.5x')); ?>"
                                role="menuitemradio"
                                aria-checked="false"
                            >
                                <span class="video-speed-option-label"><?php echo iN_HelpSecure(customLang('video_speed_option_1_5x', '1.5x')); ?></span>
                            </button>
                            <button
                                type="button"
                                class="video-speed-option"
                                data-speed="2"
                                data-speed-label="<?php echo iN_HelpSecure(customLang('video_speed_option_2x', '2x')); ?>"
                                role="menuitemradio"
                                aria-checked="false"
                            >
                                <span class="video-speed-option-label"><?php echo iN_HelpSecure(customLang('video_speed_option_2x', '2x')); ?></span>
                            </button>
                            <button
                                type="button"
                                class="video-speed-option"
                                data-speed="2.5"
                                data-speed-label="<?php echo iN_HelpSecure(customLang('video_speed_option_2_5x', '2.5x')); ?>"
                                role="menuitemradio"
                                aria-checked="false"
                            >
                                <span class="video-speed-option-label"><?php echo iN_HelpSecure(customLang('video_speed_option_2_5x', '2.5x')); ?></span>
                            </button>
                        </div>
                    </div>
                    <div class="video-seek" data-video-id="<?php echo (int) $post['post_id']; ?>">
                        <label class="sr-only" for="video-seek-<?php echo (int) $post['post_id']; ?>">
                            <?php echo iN_HelpSecure(customLang('video_seek_label', 'Seek')); ?>
                        </label>
                        <input
                            type="range"
                            class="video-seek-range"
                            id="video-seek-<?php echo (int) $post['post_id']; ?>"
                            min="0"
                            max="100"
                            step="0.01"
                            value="0"
                        >
                        <div class="video-seek-time" aria-live="polite">
                            <span class="video-seek-current">0:00</span>
                            <span class="video-seek-separator">/</span>
                            <span class="video-seek-duration">0:00</span>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($post['post_text'])) : ?>
                <div class="post-text"><?php echo nl2br(iN_HelpSecure($post['post_text'])); ?></div>
            <?php endif; ?>
        <?php else : ?>
            <?php
                $lockedPreviewMessageHtml = html_entity_decode($visibilityMessage);
                $canUseTeaser = $hasTeaser && in_array((string) ($post['post_visibility'] ?? ''), ['locked', 'subscribers'], true);
            ?>
            <div class="locked-preview-container full-width flex align_items flexBoxColumn gap">
                <?php if ($canUseTeaser) : ?>
                    <div class="locked-preview-media locked-preview-media--teaser" data-premium-teaser="1">
                        <?php if ($teaserIsAudio) : ?>
                            <div class="locked-preview locked-preview--audio-teaser flex align_items_justify_content flexBoxColumn">
                                <div class="locked-preview-audio-icon"><?php echo render_icon('podcast', true); ?></div>
                                <audio
                                    class="locked-preview-audio"
                                    src="<?php echo iN_HelpSecure($teaserUrl); ?>"
                                    controls
                                    preload="metadata"
                                    data-premium-teaser-media="1"
                                ></audio>
                            </div>
                        <?php else : ?>
                            <video
                                class="locked-preview locked-preview--teaser"
                                src="<?php echo iN_HelpSecure($teaserUrl); ?>"
                                controls
                                playsinline
                                preload="metadata"
                                data-premium-teaser-media="1"
                            ></video>
                        <?php endif; ?>
                        <div class="locked-preview-overlay locked-preview-overlay--deferred">
                            <div class="visibility-warning flex align_items_justify_content full-width visibility-warning--overlay">
                                <?php echo $lockedPreviewMessageHtml; ?>
                            </div>
                        </div>
                    </div>
                <?php elseif ($hasLockedPreview) : ?>
                    <div class="locked-preview-media">
                        <?php if ($lockedPreviewTypeValue === 'animated') : ?>
                            <video
                                class="locked-preview locked-preview--video"
                                src="<?php echo iN_HelpSecure($lockedPreviewUrl); ?>"
                                autoplay
                                muted
                                playsinline
                                preload="metadata"
                                data-max-locked-loops="2"
                            ></video>
                        <?php else : ?>
                            <img class="locked-preview locked-preview--image" src="<?php echo iN_HelpSecure($lockedPreviewUrl); ?>" alt="<?php echo iN_HelpSecure(customLang('locked_preview_alt') ?: 'Pixelated preview for locked content.'); ?>" loading="lazy">
                        <?php endif; ?>
                        <div class="locked-preview-overlay">
                            <div class="visibility-warning flex align_items_justify_content full-width visibility-warning--overlay">
                                <?php echo $lockedPreviewMessageHtml; ?>
                            </div>
                        </div>
                    </div>
                <?php else : ?>
                    <div class="visibility-warning flex align_items_justify_content full-width locked_bg">
                        <?php echo $lockedPreviewMessageHtml; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    <!--/POST BODY-->

    <?php if ($approvalBlocked && !$viewerIsAdmin): ?>
        <div class="post-approval-alert post-approval-alert--<?php echo iN_HelpSecure($approvalStatus); ?> full-width">
            <div class="post-approval-alert__title"><?php echo iN_HelpSecure($approvalLabel); ?></div>
            <div class="post-approval-alert__message"><?php echo iN_HelpSecure($approvalMessage); ?></div>
            <?php if ($approvalNotes !== ''): ?>
                <div class="post-approval-alert__note"><?php echo iN_HelpSecure($approvalNotes); ?></div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!--FOOTER-->
    <!-- Developer Hooks:
      - .p_like[post-id]       : Like/Unlike post (AJAX in external JS)
      - .p_comment[data-id]    : Toggle/open comment composer for a given post
      - .sendComment[data-post-id] : Submit new comment (AJAX)
      - .book_post[data-id][data-type] : Save/Unsave bookmark toggle (AJAX)
      All endpoints are handled in requests.php; this template only exposes consistent attributes.
    -->
    <?php if (!$approvalBlocked || $viewerIsAdmin): ?>
    <div class="post-footer full-width flex align_items flexBoxColumn">
        <div class="post-footer-buttons relative full-width flex align_items">
            <div class="post-button-box flex align_items cursor-point">
                <div class="post-button-heart flex align_items p_like <?php echo $RL->RL_HasLiked((int)($userData['user_id'] ?? 0), (int)$post['post_id'], 'post') ? 'is-liked' : ''; ?>"
                    post-id="<?php echo (int) $post['post_id']; ?>">
                    <span class="icon-unliked"><?php echo render_icon('like', true); ?></span>
                    <span class="icon-liked"><?php echo render_icon('liked', true); ?></span>
                </div>
                <div class="total-like flex align_items">
                    <span class="metric-value"><?php echo (int) $RL->RL_CountLikes((int)$post['post_id'], 'post'); ?></span>
                    <span class="metric-label flex align_items"> <?php echo customLang('likes'); ?></span>
                </div>
            </div>

            <?php $commentsOn = (($post['comment_status'] ?? 'on') === 'on'); ?>
            <?php if ($commentsOn): ?>
            <div class="post-button-box flex align_items">
                <div class="post-button-comment flex align_items p_comment cursor-point" data-id="<?php echo (int) $post['post_id']; ?>"><?php echo render_icon('comment', true); ?></div>
                <div class="total-comment flex align_items cursor-pointer commentCount">
                    <span class="metric-value"><?php echo iN_HelpSecure((string) $totalComments); ?></span>
                    <span class="metric-label flex align_items"> <?php echo customLang(((int) $totalComments === 1) ? 'comment_singular' : 'comments'); ?></span>
                </div>
            </div>
            <?php endif; ?>

            <div class="post-button-box flex align_items cursor-point">
                <?php $shareCount = method_exists($RL,'RL_CountPostShares') ? (int)$RL->RL_CountPostShares((int)$post['post_id']) : 0; ?>
                <div class="post-button-send flex align_items p_send"><?php echo render_icon('send', true); ?></div>
                <div class="total-send flex align_items" data-role="share-count"><?php echo (int)$shareCount; ?></div>
            </div>

            <?php
                $__sendTipProvidersActive = isset($hasActivePaymentProviders)
                    ? (bool) $hasActivePaymentProviders
                    : (bool) ($GLOBALS['hasActivePaymentProviders'] ?? false);
                $__sendTipAdminOverride = isset($isAdminUser)
                    ? (bool) $isAdminUser
                    : (bool) ($GLOBALS['isAdminUser'] ?? false);
                $__displaySendTipButton = $__sendTipProvidersActive || $__sendTipAdminOverride;
            ?>
            <?php if ($__displaySendTipButton): ?>
            <div class="post-button-box post-button-box-super-thanks flex align_items cursor-point sendTip" data-id="<?php echo (int) $post['post_id'];?>">
                <div class="post-button-super-thanks flex align_items p_super_thanks"><?php echo render_icon('super_thanks', true); ?></div>
                <div class="total-send flex align_items"><?php echo ($thanksCount > 0) ? ((int)$thanksCount . ' ' . customLang('thanks')) : customLang('thanks'); ?></div>
            </div>
            <?php endif; ?>

            <!-- Save -->
            <div class="post-button-box button-save flex align_items cursor-point">
                <?php
                $isSaved = $RL->RL_IsBookmarked($viewerId, (int)$post['post_id'], $postType);
                $btnClass = $isSaved ? 'p_saved' : 'p_save';
                ?>
                <!-- Save -->
                <div class="post-button-super-thanks flex align_items book_post <?php echo $btnClass; ?>"
                    data-id="<?php echo (int)$post['post_id'];?>"
                    data-type="<?php echo iN_HelpSecure($postType);?>">
                <span class="icon-save flex align_items">
                    <?php echo render_icon('save', true); ?>
                </span>
                <span class="icon-saved flex align_items">
                    <?php echo render_icon('saved', true); ?>
                </span>
                </div>
            </div>
        </div>

        <div class="post-comments-container full-width flex align_items gap flexBoxColumn"
            id="comments-<?php echo (int) $post['post_id']; ?>" data-id="<?php echo (int) $post['post_id']; ?>">
            <div class="post-comments relative full-width flex align_items gap flexBoxColumn post-comment-<?php echo (int) $post['post_id']; ?>" data-id="<?php echo (int) $post['post_id']; ?>">
                <?php include __DIR__ . '/../layouts/allPostComment.php'; ?>
            </div>
        </div>
    </div>

    <?php if (($post['comment_status'] ?? 'on') === 'on') : ?>
        <?php $postID = (int) $post['post_id']; include __DIR__ . '/commentComposer.php'; ?>
    <?php endif; ?>
    <div class="like-fx-layer"></div>
    <?php else: ?>
    <div class="post-footer post-footer--disabled full-width flex align_items flexBoxColumn"></div>
    <?php endif; ?>

    <?php if ((int) ($viewerId ?? 0) > 0) { include __DIR__ . '/partials/post_settings.php'; } ?>
</div>
        <?php
        // ------- END shared post markup -------
        if ($__feedAds && $__feedAdInterval > 0 && ($__feedAdCursor % $__feedAdInterval) === 0) {
            $adRow = array_shift($__feedAds);
            if (is_array($adRow)) {
                $__renderFeedAd($adRow);
            }
        }
    endforeach;
endif;

// ----- Close layout wrappers -----
if ($__mode === 'single') {
    ?>
                </div> <!-- /#posts -->
            </div> <!-- /.content-left-container -->
        </div> <!-- /.content-left -->
        <!---->
        <!---->
        <div class="content-right flex align_items">
            <div class="content-right-container">
                <?php
                    include_once __DIR__ . '/widgets/suggestedUsers.php';
                    include_once __DIR__ . '/widgets/adsSidebar.php';
                    $hideMostPopularIfEmpty = true;
                    include_once __DIR__ . '/widgets/mosPopularPost.php';
                    unset($hideMostPopularIfEmpty);
                ?>
            </div>
        </div>
        <!---->
    </div> <!-- /.content-area -->
</div> <!-- /.main-content -->
    <?php
} elseif ($__mode === 'full') {
    ?>
    </div> <!-- /.full-post-wrapper -->
</div> <!-- /.full-post-container -->
    <?php
}

$themeBase = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme);
?>
