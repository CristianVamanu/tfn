<?php
declare(strict_types=1);

$renderInvoiceError = static function (string $message): void {
    $safe = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
    echo '<!doctype html><html lang="en"><head><meta charset="UTF-8" />'
        . '<meta name="viewport" content="width=device-width,initial-scale=1" />'
        . '<title>Invoice</title>'
        . '<style>body{margin:0;background:#0f172a;color:#f8fafc;font-family:\'Poppins\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:32px;}'
        . '.invoice-error{background:#1f2937;border-radius:20px;padding:32px 40px;max-width:420px;box-shadow:0 24px 60px rgba(15,23,42,0.4);font-size:18px;font-weight:600;text-align:center;line-height:1.6;}'
        . '</style></head><body><div class="invoice-error">' . $safe . '</div></body></html>';
};

if (!isset($loggedIn) || $loggedIn !== '1') {
    $renderInvoiceError(customLang('login_required'));
    return;
}

$userId = isset($userID) ? (int) $userID : 0;
if ($userId <= 0) {
    $renderInvoiceError(customLang('login_required'));
    return;
}

$invoiceType = isset($_GET['invoice_type']) ? strtolower((string) $_GET['invoice_type']) : '';
$invoiceId   = isset($_GET['invoice_id']) ? (int) $_GET['invoice_id'] : 0;
if (!in_array($invoiceType, ['tip', 'subscription', 'purchase', 'ebook', 'audio_room_ticket', 'audio_room_tip'], true) || $invoiceId <= 0) {
    $renderInvoiceError(customLang('invoice_error_not_found'));
    return;
}

$pdo = null;
if (isset($RL) && is_object($RL) && method_exists($RL, 'getDb')) {
    $pdo = $RL->getDb();
} elseif (isset($db) && $db instanceof PDO) {
    $pdo = $db;
}

if (!$pdo instanceof PDO) {
    $renderInvoiceError(customLang('invoice_error_not_found'));
    return;
}

$currencyMap = isset($currencys) && is_array($currencys) ? $currencys : [];

$baseProfileRoot = '';
if (!empty($base_url)) {
    $baseProfileRoot = rtrim((string) $base_url, '/');
} elseif (!empty($baseUrl)) {
    $baseProfileRoot = rtrim((string) $baseUrl, '/');
}

$resolveAvatarUrl = static function (?string $path) use ($baseProfileRoot): string {
    $candidate = trim((string) $path);
    if ($candidate === '') {
        $candidate = 'uploads/user_avatars/default.jpeg';
    }
    if (preg_match('~^https?://~i', $candidate)) {
        return $candidate;
    }
    $normalized = '/' . ltrim($candidate, '/');
    if ($baseProfileRoot === '') {
        return $normalized;
    }
    return $baseProfileRoot . $normalized;
};

$buildProfileLink = static function (?string $username) use ($baseProfileRoot): string {
    $slug = trim((string) $username);
    if ($slug === '') {
        return '';
    }
    $slug = ltrim($slug, '@');
    $path = 'profile/' . rawurlencode($slug);
    if ($baseProfileRoot === '') {
        return $path;
    }
    return $baseProfileRoot . '/' . $path;
};

$buildPostLink = static function (int $postId, ?string $ownerUsername) use ($baseProfileRoot): string {
    if ($postId <= 0) {
        return '';
    }
    $slug = trim((string) $ownerUsername);
    $path = 'posts/' . $postId;
    if ($slug !== '') {
        $path .= '/' . rawurlencode($slug);
    }
    if ($baseProfileRoot === '') {
        return $path;
    }
    return $baseProfileRoot . '/' . $path;
};

$currencyFormatSettings = isset($currencyFormatSettings)
    ? $currencyFormatSettings
    : ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
$formatMoney = static function (float $amount, string $currencyCode, array $currencyMap) use ($currencyFormatSettings): string {
    $currencyCode = strtoupper($currencyCode);
    $symbol = isset($currencyMap[$currencyCode]) ? (string) $currencyMap[$currencyCode] : '';
    return dz_format_currency($amount, $currencyCode, $symbol, $currencyFormatSettings);
};

$formatDate = static function ($timestamp): string {
    if (is_numeric($timestamp)) {
        $ts = (int) $timestamp;
        if ($ts > 0) {
            return date('d.m.Y', $ts);
        }
    }
    return '—';
};

try {
    if ($invoiceType === 'audio_room_ticket') {
        $sql = 'SELECT inv.invoice_id AS id,
                       inv.invoice_number AS stored_invoice_number,
                       inv.buyer_id,
                       inv.seller_id AS recipient_id,
                       inv.amount,
                       inv.fee_amount,
                       inv.tax_amount,
                       inv.net_amount,
                       inv.currency,
                       inv.provider,
                       inv.reference,
                       inv.status,
                       inv.created_at,
                       inv.issued_at,
                       t.room_id,
                       r.title AS room_title,
                       ub.username AS buyer_username,
                       COALESCE(ub.user_fullname, ub.username) AS buyer_fullname,
                       ub.user_email AS buyer_email,
                       ub.user_avatar AS buyer_avatar,
                       ur.username AS recipient_username,
                       COALESCE(ur.user_fullname, ur.username) AS recipient_fullname,
                       ur.user_email AS recipient_email,
                       ur.user_avatar AS recipient_avatar
                FROM i_invoices inv
                INNER JOIN i_audio_room_tickets t ON t.id = inv.source_id
                LEFT JOIN i_audio_rooms r ON r.room_id = t.room_id
                LEFT JOIN i_users ub ON ub.user_id = inv.buyer_id
                LEFT JOIN i_users ur ON ur.user_id = inv.seller_id
                WHERE inv.source_type = "audio_room_ticket" AND inv.source_id = :id AND inv.buyer_id = :uid
                LIMIT 1';
    } elseif ($invoiceType === 'audio_room_tip') {
        $sql = 'SELECT inv.invoice_id AS id,
                       inv.invoice_number AS stored_invoice_number,
                       inv.buyer_id,
                       inv.seller_id AS recipient_id,
                       inv.amount,
                       inv.fee_amount,
                       inv.tax_amount,
                       inv.net_amount,
                       inv.currency,
                       inv.provider,
                       inv.reference,
                       inv.status,
                       inv.created_at,
                       inv.issued_at,
                       e.room_id,
                       r.title AS room_title,
                       ub.username AS buyer_username,
                       COALESCE(ub.user_fullname, ub.username) AS buyer_fullname,
                       ub.user_email AS buyer_email,
                       ub.user_avatar AS buyer_avatar,
                       ur.username AS recipient_username,
                       COALESCE(ur.user_fullname, ur.username) AS recipient_fullname,
                       ur.user_email AS recipient_email,
                       ur.user_avatar AS recipient_avatar
                FROM i_invoices inv
                INNER JOIN i_audio_room_tip_events e ON e.id = inv.source_id
                LEFT JOIN i_audio_rooms r ON r.room_id = e.room_id
                LEFT JOIN i_users ub ON ub.user_id = inv.buyer_id
                LEFT JOIN i_users ur ON ur.user_id = inv.seller_id
                WHERE inv.source_type = "audio_room_tip" AND inv.source_id = :id AND inv.buyer_id = :uid
                LIMIT 1';
    } elseif ($invoiceType === 'ebook') {
        $sql = 'SELECT ep.*,
                       inv.invoice_number AS stored_invoice_number,
                       inv.issued_at AS stored_invoice_issued_at,
                       e.title AS ebook_title,
                       e.slug AS ebook_slug,
                       e.cover_path AS ebook_cover,
                       ub.username AS buyer_username,
                       COALESCE(ub.user_fullname, ub.username) AS buyer_fullname,
                       ub.user_email AS buyer_email,
                       ub.user_avatar AS buyer_avatar,
                       ur.username AS recipient_username,
                       COALESCE(ur.user_fullname, ur.username) AS recipient_fullname,
                       ur.user_email AS recipient_email,
                       ur.user_avatar AS recipient_avatar
                FROM i_ebook_purchases ep
                LEFT JOIN i_invoices inv ON inv.source_type = "ebook_purchase" AND inv.source_id = ep.purchase_id
                LEFT JOIN i_ebooks e ON e.ebook_id = ep.ebook_id
                LEFT JOIN i_users ub ON ub.user_id = ep.buyer_id
                LEFT JOIN i_users ur ON ur.user_id = ep.seller_id
                WHERE ep.purchase_id = :id AND ep.buyer_id = :uid
                LIMIT 1';
    } elseif ($invoiceType === 'tip') {
        $sql = 'SELECT tp.*, 
                       ub.username AS buyer_username,
                       COALESCE(ub.user_fullname, ub.username) AS buyer_fullname,
                       ub.user_email AS buyer_email,
                       ub.user_avatar AS buyer_avatar,
                       ur.username AS recipient_username,
                       COALESCE(ur.user_fullname, ur.username) AS recipient_fullname,
                       ur.user_email AS recipient_email,
                       ur.user_avatar AS recipient_avatar,
                       posts.post_owner_id,
                       owner.username AS post_owner_username
                FROM i_tip_payments tp
                LEFT JOIN i_users ub ON ub.user_id = tp.buyer_id
                LEFT JOIN i_users ur ON ur.user_id = tp.recipient_id
                LEFT JOIN i_user_posts posts ON posts.post_id = tp.post_id
                LEFT JOIN i_users owner ON owner.user_id = posts.post_owner_id
                WHERE tp.id = :id AND tp.buyer_id = :uid
                LIMIT 1';
    } elseif ($invoiceType === 'purchase') {
        $sql = 'SELECT pp.*, 
                       ub.username AS buyer_username,
                       COALESCE(ub.user_fullname, ub.username) AS buyer_fullname,
                       ub.user_email AS buyer_email,
                       ub.user_avatar AS buyer_avatar,
                       ur.username AS recipient_username,
                       COALESCE(ur.user_fullname, ur.username) AS recipient_fullname,
                       ur.user_email AS recipient_email,
                       ur.user_avatar AS recipient_avatar,
                       posts.post_owner_id,
                       owner.username AS post_owner_username
                FROM i_post_purchases pp
                LEFT JOIN i_users ub ON ub.user_id = pp.buyer_id
                LEFT JOIN i_users ur ON ur.user_id = pp.recipient_id
                LEFT JOIN i_user_posts posts ON posts.post_id = pp.post_id
                LEFT JOIN i_users owner ON owner.user_id = posts.post_owner_id
                WHERE pp.id = :id AND pp.buyer_id = :uid
                LIMIT 1';
    } else {
        $sql = 'SELECT sp.*, 
                       ub.username AS buyer_username,
                       COALESCE(ub.user_fullname, ub.username) AS buyer_fullname,
                       ub.user_email AS buyer_email,
                       ub.user_avatar AS buyer_avatar,
                       ur.username AS recipient_username,
                       COALESCE(ur.user_fullname, ur.username) AS recipient_fullname,
                       ur.user_email AS recipient_email,
                       ur.user_avatar AS recipient_avatar
                FROM i_subscription_payments sp
                LEFT JOIN i_users ub ON ub.user_id = sp.buyer_id
                LEFT JOIN i_users ur ON ur.user_id = sp.recipient_id
                WHERE sp.id = :id AND sp.buyer_id = :uid
                LIMIT 1';
    }

    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':id', $invoiceId, PDO::PARAM_INT);
    $stmt->bindValue(':uid', $userId, PDO::PARAM_INT);
    $stmt->execute();
    $invoice = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
} catch (Throwable $e) {
    $invoice = null;
}

if (!$invoice) {
    $renderInvoiceError(customLang('invoice_error_not_found'));
    return;
}

$buyerId = isset($invoice['buyer_id']) ? (int) $invoice['buyer_id'] : 0;
if ($buyerId !== $userId) {
    $renderInvoiceError(customLang('invoice_error_forbidden'));
    return;
}

$buyerUsername = trim((string) ($invoice['buyer_username'] ?? ''));
$buyerDisplay  = trim((string) ($invoice['buyer_fullname'] ?? $buyerUsername));
if ($buyerDisplay === '') {
    $buyerDisplay = 'User #' . $buyerId;
}
$buyerAvatar = $resolveAvatarUrl($invoice['buyer_avatar'] ?? '');
$buyerEmail  = (string) ($invoice['buyer_email'] ?? '');
$buyerProfileUrl = $buildProfileLink($buyerUsername);

$creatorUsername = trim((string) ($invoice['recipient_username'] ?? ''));
$creatorDisplay  = trim((string) ($invoice['recipient_fullname'] ?? $creatorUsername));
if ($creatorDisplay === '') {
    $creatorDisplay = customLang('settings_payments_unknown_creator');
}
$creatorAvatar = $resolveAvatarUrl($invoice['recipient_avatar'] ?? '');
$creatorEmail  = (string) ($invoice['recipient_email'] ?? '');
$creatorProfileUrl = $buildProfileLink($creatorUsername);

$currencyCode = isset($invoice['currency']) && $invoice['currency'] !== ''
    ? strtoupper((string) $invoice['currency'])
    : (isset($currency) ? strtoupper((string) $currency) : 'USD');

$gross = isset($invoice['amount']) ? (float) $invoice['amount'] : 0.0;
$tax   = isset($invoice['tax_amount']) ? (float) $invoice['tax_amount'] : 0.0;
$fee   = isset($invoice['fee_amount']) ? (float) $invoice['fee_amount'] : 0.0;
$net   = isset($invoice['net_amount']) ? (float) $invoice['net_amount'] : $gross;
$isAudioRoomInvoice = in_array($invoiceType, ['audio_room_ticket', 'audio_room_tip'], true);
$invoiceTotal = $isAudioRoomInvoice ? $gross : ($gross + $tax + $fee);

$statusRaw = strtolower(trim((string) ($invoice['status'] ?? '')));
$statusLabelMap = [
    'succeeded' => customLang('settings_super_thanks_status_succeeded'),
    'paid'      => customLang('settings_super_thanks_status_paid'),
    'completed' => customLang('settings_super_thanks_status_completed'),
    'active'    => customLang('settings_payments_status_active'),
    'pending'   => customLang('settings_super_thanks_status_pending'),
    'processing'=> customLang('settings_super_thanks_status_processing'),
    'failed'    => customLang('settings_super_thanks_status_failed'),
    'canceled'  => customLang('settings_super_thanks_status_canceled'),
    'cancelled' => customLang('settings_super_thanks_status_canceled'),
    'refunded'  => customLang('settings_super_thanks_status_refunded'),
    'incomplete'=> customLang('settings_payments_status_incomplete'),
];
$statusText = $statusLabelMap[$statusRaw] ?? ucfirst($statusRaw ?: 'Pending');
$statusTone = 'status--pending';
if (in_array($statusRaw, ['succeeded', 'paid', 'completed', 'active'], true)) {
    $statusTone = 'status--paid';
} elseif (in_array($statusRaw, ['failed', 'canceled', 'cancelled'], true)) {
    $statusTone = 'status--failed';
} elseif ($statusRaw === 'refunded') {
    $statusTone = 'status--refunded';
}

$invoicePrefixMap = [
    'subscription' => 'SP-',
    'purchase' => 'PUR-',
    'ebook' => 'EB-',
    'tip' => 'TIP-',
    'audio_room_ticket' => 'AR-TKT-',
    'audio_room_tip' => 'AR-TIP-',
];
$invoiceNumber = trim((string)($invoice['stored_invoice_number'] ?? ''));
if ($invoiceNumber === '') {
    $invoiceNumber = ($invoicePrefixMap[$invoiceType] ?? 'INV-') . $invoiceId;
}
$createdAt     = isset($invoice['created_at']) ? (int) $invoice['created_at'] : 0;
$createdDate   = $formatDate($createdAt);

$postId = isset($invoice['post_id']) ? (int) $invoice['post_id'] : 0;
$postUrl = '';
if ($invoiceType !== 'subscription' && $postId > 0) {
    $postUrl = $buildPostLink($postId, $invoice['post_owner_username'] ?? $creatorUsername);
}

$ebookTitle = trim((string)($invoice['ebook_title'] ?? ''));
$ebookSlug = trim((string)($invoice['ebook_slug'] ?? ''));
$ebookUrl = '';
if ($invoiceType === 'ebook' && $ebookSlug !== '') {
    $ebookUrl = ($baseProfileRoot === '' ? '' : $baseProfileRoot . '/') . 'ebook/' . rawurlencode($ebookSlug);
}

$planLabel = '';
if ($invoiceType === 'subscription') {
    $interval = isset($invoice['plan_interval']) ? (string) $invoice['plan_interval'] : '';
    $count    = isset($invoice['interval_count']) ? (int) $invoice['interval_count'] : 1;
    $interval = strtolower(trim($interval));
    $count    = $count > 0 ? $count : 1;
    $intervalMap = [
        'day' => customLang('settings_payments_plan_daily'),
        'daily' => customLang('settings_payments_plan_daily'),
        'week' => customLang('settings_payments_plan_weekly'),
        'weekly' => customLang('settings_payments_plan_weekly'),
        'month' => customLang('settings_payments_plan_monthly'),
        'monthly' => customLang('settings_payments_plan_monthly'),
        'year' => customLang('settings_payments_plan_yearly'),
        'yearly' => customLang('settings_payments_plan_yearly'),
    ];
    $planTitle = $intervalMap[$interval] ?? customLang('settings_payments_plan_fallback');
    $planLabel = $count > 1 ? ($count . '× ' . $planTitle) : $planTitle;
}

$typeLabelMap = [
    'subscription' => customLang('settings_payments_type_subscription'),
    'tip'          => customLang('settings_payments_type_tip'),
    'purchase'     => customLang('settings_payments_type_purchase'),
    'ebook'        => customLang('settings_payments_type_ebook', 'eBook'),
    'audio_room_ticket' => customLang('settings_payments_type_audio_room_ticket', 'Audio Room ticket'),
    'audio_room_tip' => customLang('settings_payments_type_audio_room_tip', 'Audio Room tip'),
];
$typeLabel = $typeLabelMap[$invoiceType] ?? ucfirst($invoiceType);

$tipHandle = $creatorUsername !== '' ? '@' . $creatorUsername : $creatorDisplay;
$postLabel = $postId > 0 ? ('#' . $postId) : customLang('settings_payments_transactions_no_post');
$roomId = isset($invoice['room_id']) ? (int) $invoice['room_id'] : 0;
$roomTitle = trim((string) ($invoice['room_title'] ?? ''));
$roomLabel = $roomTitle !== '' ? $roomTitle : ('Audio Room #' . $roomId);
if ($invoiceType === 'audio_room_ticket') {
    $lineDescription = sprintf(customLang('invoice_line_audio_room_ticket_description', 'Audio Room ticket: %s'), $roomLabel);
} elseif ($invoiceType === 'audio_room_tip') {
    $lineDescription = sprintf(customLang('invoice_line_audio_room_tip_description', 'Audio Room tip: %s'), $roomLabel);
} elseif ($invoiceType === 'tip') {
    $lineDescription = sprintf(customLang('invoice_line_tip_description'), $tipHandle);
} elseif ($invoiceType === 'purchase') {
    $lineDescription = sprintf(customLang('invoice_line_purchase_description'), $postLabel);
} elseif ($invoiceType === 'ebook') {
    $lineDescription = sprintf(customLang('invoice_line_ebook_description', 'eBook purchase: %s'), $ebookTitle !== '' ? $ebookTitle : ('#' . $invoiceId));
} else {
    $lineDescription = sprintf(customLang('invoice_line_subscription_description'), $tipHandle);
}

$siteName = isset($siteTitle) && $siteTitle !== '' ? (string) $siteTitle : 'ReelsProject';
$brandInitials = strtoupper(substr(preg_replace('~[^A-Za-z]~', '', $siteName), 0, 2));
if ($brandInitials === '') {
    $brandInitials = 'RP';
}

$siteDarkLogo = isset($siteDarkLogo) ? (string) $siteDarkLogo : '';
$siteWhiteLogo = isset($siteWhiteLogo) ? (string) $siteWhiteLogo : '';
$logoCandidate = trim($siteDarkLogo !== '' ? $siteDarkLogo : $siteWhiteLogo);
$brandLogoUrl = '';
if ($logoCandidate !== '') {
    if (preg_match('~^https?://~i', $logoCandidate)) {
        $brandLogoUrl = $logoCandidate;
    } else {
        $normalized = '/' . ltrim($logoCandidate, '/');
        $brandLogoUrl = $baseProfileRoot === '' ? $normalized : $baseProfileRoot . $normalized;
    }
}
$brandLogoClasses = 'brand-logo';
if ($brandLogoUrl !== '') {
    $brandLogoClasses .= ' brand-logo--has-image';
} else {
    $brandLogoClasses .= ' brand-logo--fallback-visible';
}

$amountLabel = $formatMoney($invoiceTotal, $currencyCode, $currencyMap);
$grossLabel  = $formatMoney($gross, $currencyCode, $currencyMap);
$taxLabel    = $formatMoney($tax, $currencyCode, $currencyMap);
$feeLabel    = $formatMoney($fee, $currencyCode, $currencyMap);
$netLabel    = $formatMoney($net, $currencyCode, $currencyMap);

$langAttr = 'en';
$themeAssetRoot = ($baseProfileRoot !== '' ? $baseProfileRoot : '') . '/themes/default';
$assetVersionResolver = static function (string $relativePath): string {
    $fullPath = dirname(__DIR__) . '/' . ltrim($relativePath, '/');
    $timestamp = @filemtime($fullPath);
    if (!$timestamp) {
        return (string) time();
    }
    return (string) $timestamp;
};
$cssVersion = $assetVersionResolver('css/invoice.css');
$printJsVersion = $assetVersionResolver('js/assets/invoice.print.js');
$downloadJsVersion = $assetVersionResolver('js/invoice.download.js');
$jspdfVersion = $assetVersionResolver('js/assets/vendor/jspdf.umd.min.js');
$html2canvasVersion = $assetVersionResolver('js/assets/vendor/html2canvas.min.js');
?>
<!doctype html>
<html lang="<?php echo iN_HelpSecure($langAttr); ?>">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo iN_HelpSecure(customLang('invoice_heading_title', 'Payment invoice') . ' · ' . $invoiceNumber, false); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo iN_HelpSecure($themeAssetRoot . '/css/invoice.css?v=' . $cssVersion, false); ?>" />
  </head>
  <body class="invoice-page">
    <div class="invoice-wrapper">
      <article class="invoice-document" data-invoice-document>
        <header class="invoice-header">
          <div class="brand">
            <div class="<?php echo iN_HelpSecure($brandLogoClasses, false); ?>">
              <?php if ($brandLogoUrl !== ''): ?>
                <img src="<?php echo iN_HelpSecure($brandLogoUrl, false); ?>" alt="" width="100%" height="100%" loading="lazy" data-invoice-brand-logo="1" />
              <?php endif; ?>
              <span class="brand-logo-fallback"><?php echo iN_HelpSecure($brandInitials, false); ?></span>
            </div>
            <div>
              <h1><?php echo iN_HelpSecure($siteName, false); ?></h1>
              <span><?php echo iN_HelpSecure(customLang('invoice_heading_invoice'), false); ?></span>
            </div>
          </div>

          <div class="header-meta">
            <div>
              <span><?php echo iN_HelpSecure(customLang('invoice_label_invoice_number'), false); ?></span>
              <strong><?php echo iN_HelpSecure($invoiceNumber, false); ?></strong>
            </div>

            <div>
              <span><?php echo iN_HelpSecure(customLang('invoice_label_amount'), false); ?></span>
              <strong><?php echo iN_HelpSecure($amountLabel, false); ?></strong>
            </div>

            <span class="status-chip <?php echo iN_HelpSecure($statusTone); ?>"><?php echo iN_HelpSecure($statusText, false); ?></span>
          </div>
        </header>

        <section class="invoice-body">
          <div class="info-grid">
            <div class="info-card">
              <h3><?php echo iN_HelpSecure(customLang('invoice_label_from'), false); ?></h3>
              <div class="party">
                <img src="<?php echo iN_HelpSecure($creatorAvatar, false); ?>" alt="" referrerpolicy="same-origin" crossorigin="anonymous" />
                <div>
                  <?php if ($creatorProfileUrl !== ''): ?>
                    <strong><a href="<?php echo iN_HelpSecure($creatorProfileUrl, false); ?>"><?php echo iN_HelpSecure($creatorDisplay, false); ?></a></strong>
                  <?php else: ?>
                    <strong><?php echo iN_HelpSecure($creatorDisplay, false); ?></strong>
                  <?php endif; ?>
                  <span>@<?php echo iN_HelpSecure($creatorUsername, false); ?> · <?php echo iN_HelpSecure($creatorEmail, false); ?></span>
                </div>
              </div>
            </div>

            <div class="info-card">
              <h3><?php echo iN_HelpSecure(customLang('invoice_label_billed_to'), false); ?></h3>
              <div class="party">
                <img src="<?php echo iN_HelpSecure($buyerAvatar, false); ?>" alt="" referrerpolicy="same-origin" crossorigin="anonymous" />
                <div>
                  <?php if ($buyerProfileUrl !== ''): ?>
                    <strong><a href="<?php echo iN_HelpSecure($buyerProfileUrl, false); ?>"><?php echo iN_HelpSecure($buyerDisplay, false); ?></a></strong>
                  <?php else: ?>
                    <strong><?php echo iN_HelpSecure($buyerDisplay, false); ?></strong>
                  <?php endif; ?>
                  <span>@<?php echo iN_HelpSecure($buyerUsername, false); ?><?php if ($buyerEmail !== ''): ?> · <?php echo iN_HelpSecure($buyerEmail, false); ?><?php endif; ?></span>
                </div>
              </div>
            </div>

            <div class="info-card info-card--full">
              <h3><?php echo iN_HelpSecure(customLang('invoice_section_invoice_details', 'Invoice details'), false); ?></h3>
              <div class="meta-list">
                <span><span><?php echo iN_HelpSecure(customLang('invoice_label_invoice_date'), false); ?></span><strong><?php echo iN_HelpSecure($createdDate, false); ?></strong></span>
                <span><span><?php echo iN_HelpSecure(customLang('invoice_label_customer_id'), false); ?></span><strong>#<?php echo iN_HelpSecure((string) $buyerId); ?></strong></span>
                <span><span><?php echo iN_HelpSecure(customLang('invoice_label_provider'), false); ?></span><strong><?php echo iN_HelpSecure((string) ($invoice['provider'] ?? ''), false); ?></strong></span>
                <span><span><?php echo iN_HelpSecure(customLang('invoice_label_reference'), false); ?></span><strong><?php echo iN_HelpSecure((string) ($invoice['reference'] ?? ''), false); ?></strong></span>
              </div>
            </div>
          </div>

          <div class="info-card info-card--summary">
            <h3><?php echo iN_HelpSecure(customLang('invoice_section_payment_summary', 'Payment summary'), false); ?></h3>
            <p class="invoice-summary-text">
              <?php echo iN_HelpSecure($lineDescription, false); ?>
            </p>
            <p class="invoice-summary-text">
              <strong class="invoice-summary-label"><?php echo iN_HelpSecure(customLang('invoice_label_invoice_amount'), false); ?>:</strong>
              <?php echo iN_HelpSecure($amountLabel, false); ?>
              <span class="invoice-summary-separator">·</span>
              <strong class="invoice-summary-label"><?php echo iN_HelpSecure(customLang('invoice_label_invoice_to'), false); ?>:</strong>
              <?php echo iN_HelpSecure($typeLabel, false); ?>
              <?php if ($invoiceType === 'subscription' && $planLabel !== ''): ?>
                <span class="invoice-summary-separator">·</span>
                <strong class="invoice-summary-label"><?php echo iN_HelpSecure(customLang('invoice_label_plan'), false); ?>:</strong> <?php echo iN_HelpSecure($planLabel, false); ?>
              <?php endif; ?>
              <?php if ($invoiceType !== 'subscription' && $postUrl !== ''): ?>
                <span class="invoice-summary-separator">·</span>
                <strong class="invoice-summary-label"><?php echo iN_HelpSecure(customLang('invoice_label_post'), false); ?>:</strong>
                <a class="invoice-link" href="<?php echo iN_HelpSecure($postUrl, false); ?>"><?php echo iN_HelpSecure($postLabel, false); ?></a>
              <?php endif; ?>
              <?php if ($invoiceType === 'ebook' && $ebookTitle !== ''): ?>
                <span class="invoice-summary-separator">·</span>
                <strong class="invoice-summary-label"><?php echo iN_HelpSecure(customLang('invoice_label_ebook', 'eBook'), false); ?>:</strong>
                <?php if ($ebookUrl !== ''): ?>
                  <a class="invoice-link" href="<?php echo iN_HelpSecure($ebookUrl, false); ?>"><?php echo iN_HelpSecure($ebookTitle, false); ?></a>
                <?php else: ?>
                  <?php echo iN_HelpSecure($ebookTitle, false); ?>
                <?php endif; ?>
              <?php endif; ?>
            </p>
          </div>

          <div>
            <table class="invoice-table">
              <thead>
                <tr>
                  <th><?php echo iN_HelpSecure(customLang('invoice_table_description'), false); ?></th>
                  <th><?php echo iN_HelpSecure(customLang('invoice_table_price'), false); ?></th>
                  <th><?php echo iN_HelpSecure(customLang('invoice_table_discount'), false); ?></th>
                  <th><?php echo iN_HelpSecure(customLang('invoice_table_amount'), false); ?></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><?php echo iN_HelpSecure($lineDescription, false); ?></td>
                  <td><?php echo iN_HelpSecure($grossLabel, false); ?></td>
                  <td>—</td>
                  <td><?php echo iN_HelpSecure($amountLabel, false); ?></td>
                </tr>
              </tbody>
            </table>
          </div>

          <div class="totals-grid">
            <div class="total-card">
              <span><?php echo iN_HelpSecure(customLang('invoice_table_subtotal'), false); ?></span>
              <strong><?php echo iN_HelpSecure($grossLabel, false); ?></strong>
            </div>
            <div class="total-card">
              <span><?php echo iN_HelpSecure(customLang('invoice_table_tax'), false); ?></span>
              <strong><?php echo iN_HelpSecure($taxLabel, false); ?></strong>
            </div>
            <div class="total-card">
              <span><?php echo iN_HelpSecure(customLang('invoice_table_fee'), false); ?></span>
              <strong><?php echo iN_HelpSecure($feeLabel, false); ?></strong>
            </div>
            <div class="total-card">
              <span><?php echo iN_HelpSecure(customLang('invoice_table_total'), false); ?></span>
              <strong><?php echo iN_HelpSecure($amountLabel, false); ?></strong>
            </div>
            <div class="total-card">
              <span><?php echo iN_HelpSecure(customLang('invoice_table_net', 'Net amount'), false); ?></span>
              <strong><?php echo iN_HelpSecure($netLabel, false); ?></strong>
            </div>
          </div>

          <div class="footer-note">
            <p><?php echo iN_HelpSecure(customLang('invoice_footer_thanks'), false); ?></p>
            <p>
              <a class="support-link" href="<?php echo iN_HelpSecure(($baseProfileRoot !== '' ? $baseProfileRoot : '') . '/support', false); ?>">
                <?php echo iN_HelpSecure(($baseProfileRoot !== '' ? $baseProfileRoot : '') . '/support', false); ?>
              </a>
            </p>
            <p><?php echo iN_HelpSecure(customLang('invoice_footer_note'), false); ?></p>
          </div>
        </section>
      </article>

      <div class="invoice-actions no-print">
        <button type="button" class="invoice-action-button js-invoice-print"><?php echo iN_HelpSecure(customLang('invoice_action_print'), false); ?></button>
        <button type="button" class="invoice-action-button js-invoice-download-pdf"><?php echo iN_HelpSecure(customLang('invoice_action_download_pdf', 'Download PDF'), false); ?></button>
        <button type="button" class="invoice-action-button js-invoice-download-png"><?php echo iN_HelpSecure(customLang('invoice_action_download_png', 'Download PNG'), false); ?></button>
      </div>
    </div>

    <script src="<?php echo iN_HelpSecure($themeAssetRoot . '/js/assets/vendor/jspdf.umd.min.js?v=' . $jspdfVersion, false); ?>"></script>
    <script src="<?php echo iN_HelpSecure($themeAssetRoot . '/js/assets/vendor/html2canvas.min.js?v=' . $html2canvasVersion, false); ?>"></script>
    <script src="<?php echo iN_HelpSecure($themeAssetRoot . '/js/assets/invoice.print.js?v=' . $printJsVersion, false); ?>"></script>
    <script src="<?php echo iN_HelpSecure($themeAssetRoot . '/js/invoice.download.js?v=' . $downloadJsVersion, false); ?>"></script>
  </body>
</html>
