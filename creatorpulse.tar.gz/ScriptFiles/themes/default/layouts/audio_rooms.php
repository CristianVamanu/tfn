<?php
declare(strict_types=1);

$viewerId = isset($userID) ? (int) $userID : 0;
$audioRoomsEnabledPage = isset($audioRoomsEnabled)
    ? (bool) $audioRoomsEnabled
    : (bool) ($GLOBALS['audioRoomsEnabled'] ?? false);
$rooms = [];
if ($audioRoomsEnabledPage && isset($RL) && method_exists($RL, 'RL_GetAudioRoomList')) {
    try {
        $rooms = $RL->RL_GetAudioRoomList($viewerId, 18, 0, ['live', 'created']);
    } catch (Throwable $__) {
        $rooms = [];
    }
}

$baseUrl = isset($base_url) ? rtrim((string)$base_url, '/') : '';
$currencyCode = strtoupper((string)($paymentsCurrency ?? $currency ?? 'USD'));
$audioRoomFormatPrice = static function ($amount, string $code) {
    if (function_exists('dz_format_currency')) {
        return dz_format_currency((float)$amount, $code);
    }
    return strtoupper($code) . ' ' . rtrim(rtrim(number_format((float)$amount, 2, '.', ''), '0'), '.');
};
$emptyStateMessage = customLang('audio_rooms_empty_state', 'No audio rooms right now');
?>
<div class="main-content flex align_items">
    <div class="content-area flex">
        <div class="content-left">
            <div class="content-left-container flex align_items flexBoxColumn audio-rooms-page">
                <div class="page-hero flex align_items space_between full-width">
                    <div class="page-hero__title flex align_items gap">
                        <span class="page-hero__icon flex align_items_justify_content"><?php echo render_icon('podcast', true); ?></span>
                        <div class="page-hero__text flex flexBoxColumn">
                            <h1 class="page-hero__heading"><?php echo iN_HelpSecure(customLang('page_audio_rooms_heading', 'Audio Rooms'), false); ?></h1>
                            <p class="page-hero__subheading"><?php echo iN_HelpSecure(customLang('page_audio_rooms_subheading', 'Join live audio conversations from creators and the community.'), false); ?></p>
                        </div>
                    </div>
                    <?php if ($viewerId > 0 && $audioRoomsEnabledPage): ?>
                        <button type="button" class="audio-room-hero-action new_item" data-pop="audio_room_create">
                            <?php echo render_icon('podcast', true); ?>
                            <span><?php echo iN_HelpSecure(customLang('audio_room_create', 'Create audio room'), false); ?></span>
                        </button>
                    <?php endif; ?>
                </div>

                <?php if (!$audioRoomsEnabledPage): ?>
                    <div class="empty-state flex align_items flexBoxColumn gap">
                        <div class="empty-state__icon flex align_items"><?php echo render_icon('not_founded', true); ?></div>
                        <div class="empty-state__title flex align_items"><?php echo iN_HelpSecure(customLang('audio_room_disabled_hint', 'Audio rooms are currently disabled.'), false); ?></div>
                    </div>
                <?php elseif (!$rooms): ?>
                    <div class="empty-state flex align_items flexBoxColumn gap">
                        <div class="empty-state__icon flex align_items"><?php echo render_icon('not_founded', true); ?></div>
                        <div class="empty-state__title flex align_items"><?php echo iN_HelpSecure($emptyStateMessage, false); ?></div>
                    </div>
                <?php else: ?>
                    <div class="audio-room-grid">
                        <?php foreach ($rooms as $room):
                            $roomId = (int)($room['room_id'] ?? 0);
                            if ($roomId <= 0) { continue; }
                            $title = trim((string)($room['title'] ?? ''));
                            $description = trim((string)($room['description'] ?? ''));
                            $status = strtolower((string)($room['status'] ?? 'created'));
                            $ownerId = (int)($room['owner_id'] ?? 0);
                            $ownerUsername = (string)($room['username'] ?? '');
                            $ownerFullname = (string)($room['user_fullname'] ?? '');
                            $displayName = $ownerFullname !== '' ? $ownerFullname : $ownerUsername;
                            $avatarPath = (string)($room['user_avatar'] ?? '');
                            if ($avatarPath === '') {
                                $avatarPath = 'uploads/avatars/default_avatar.png';
                            }
                            $avatarUrl = function_exists('storage_resolve_media_url')
                                ? storage_resolve_media_url($avatarPath, (string)($base_url ?? ''))
                                : $baseUrl . '/' . ltrim($avatarPath, '/');
                            $roomUrl = $baseUrl . '/audio-room/' . $roomId;
                            $profileUrl = $baseUrl . ($ownerUsername !== '' ? '/profile/' . rawurlencode($ownerUsername) : '/');
                            $listenerCount = (int)($room['listener_count'] ?? 0);
                            $speakerCount = (int)($room['speaker_count'] ?? 0);
                            $isPaid = (int)($room['is_paid'] ?? 0) === 1;
                            $price = $room['entry_price'] ?? null;
                            $roomCurrency = strtoupper((string)($room['currency'] ?? $currencyCode));
                        ?>
                        <article class="audio-room-card" data-room-id="<?php echo $roomId; ?>">
                            <a class="audio-room-card__main" href="<?php echo iN_HelpSecure($roomUrl, false); ?>">
                                <div class="audio-room-card__pulse" aria-hidden="true"><?php echo render_icon('podcast', true); ?></div>
                                <div class="audio-room-card__content">
                                    <div class="audio-room-card__badges">
                                        <span class="audio-room-badge audio-room-badge--<?php echo htmlspecialchars($status, ENT_QUOTES, 'UTF-8'); ?>">
                                            <?php echo iN_HelpSecure($status === 'live' ? customLang('audio_room_live_badge', 'LIVE') : customLang('audio_room_open_badge', 'OPEN'), false); ?>
                                        </span>
                                        <?php if ($isPaid): ?>
                                            <span class="audio-room-badge audio-room-badge--paid">
                                                <?php echo htmlspecialchars($audioRoomFormatPrice((float)$price, $roomCurrency), ENT_QUOTES, 'UTF-8'); ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <h2 class="audio-room-card__title"><?php echo htmlspecialchars($title !== '' ? $title : customLang('audio_room_untitled', 'Audio room'), ENT_QUOTES, 'UTF-8'); ?></h2>
                                    <?php if ($description !== ''): ?>
                                        <p class="audio-room-card__description"><?php echo htmlspecialchars($description, ENT_QUOTES, 'UTF-8'); ?></p>
                                    <?php endif; ?>
                                    <div class="audio-room-card__stats">
                                        <span><?php echo (int)$speakerCount; ?> <?php echo iN_HelpSecure(customLang('audio_room_speakers_short', 'speakers'), false); ?></span>
                                        <span><?php echo (int)$listenerCount; ?> <?php echo iN_HelpSecure(customLang('audio_room_listeners_short', 'listeners'), false); ?></span>
                                    </div>
                                </div>
                            </a>
                            <div class="audio-room-card__owner">
                                <a class="audio-room-card__avatar" href="<?php echo iN_HelpSecure($profileUrl, false); ?>">
                                    <img src="<?php echo htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($displayName ?: $ownerUsername ?: 'creator', ENT_QUOTES, 'UTF-8'); ?>">
                                </a>
                                <div class="audio-room-card__owner-copy">
                                    <span><?php echo iN_HelpSecure(customLang('audio_room_host_label', 'Host'), false); ?></span>
                                    <a class="audio-room-card__name" href="<?php echo iN_HelpSecure($profileUrl, false); ?>">
                                        <?php echo htmlspecialchars($displayName ?: ('@' . $ownerUsername), ENT_QUOTES, 'UTF-8'); ?>
                                    </a>
                                </div>
                            </div>
                        </article>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="content-right flex align_items">
            <div class="content-right-container">
                <?php
                    include_once __DIR__ . '/widgets/suggestedUsers.php';
                    include_once __DIR__ . '/widgets/adsSidebar.php';
                    $hideMostPopularIfEmpty = true;
                    include_once __DIR__ . '/widgets/mosPopularPost.php';
                    unset($hideMostPopularIfEmpty);
                ?>
            </div>
        </div>
    </div>
</div>

<?php $themePathAudioRooms = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme); ?>
<script defer src="<?php echo $themePathAudioRooms; ?>/js/adsFeedSlots.js?v=<?php echo iN_HelpSecure($version);?>"></script>
