<?php
$postID = isset($post['post_id']) ? (int) $post['post_id'] : 0;

$iconPath = $iconPath
    ?? rtrim($base_url ?? '', '/')
    . '/themes/'
    . ($currentTheme ?? 'default')
    . '/img/';

// If we don't have a valid post ID, there's nothing to do.
if ($postID <= 0) {
    return;
}

// Guard: comment service must exist and expose the expected method.
$canFetchComments = isset($RL)
    && is_object($RL)
    && method_exists($RL, 'RL_GetAllCommentsForPost')
    && method_exists($RL, 'RL_GetRecentCommentsForPost');

if (!$canFetchComments) {
    // Developer note: if you swap the comment service, update the guard above.
    return;
}

// ---- Fetch data --------------------------------------------------------------

/** @var array<int, array<string, mixed>> $lastComments */
// Feed: show only the latest 3 comments + a "view other N" link
// Single/full views: show all comments
if (isset($__mode) && $__mode === 'feed') {
    $lastComments = $RL->RL_GetRecentCommentsForPost($postID, 3);
} else {
    $lastComments = $RL->RL_GetAllCommentsForPost($postID);
}
if (empty($lastComments)) {
    // Nothing to render.
    return;
}

// ---- Render loop -------------------------------------------------------------

$commentTemplate = __DIR__ . '/newComment.php';
if (!is_file($commentTemplate)) {
    // Developer note: missing template is a deployment/config issue.
    return;
}

foreach ($lastComments as $row) {
    // Map the raw row to the variables expected by the template.
    // The template shares this scope via `include` and MUST escape output.

    /** @var string $ownerAvatar */
    $ownerAvatar = (string) ($row['avatar'] ?? '');

    /** @var string $commentUserName */
    $commentUserName = (string) ($row['username'] ?? '');

    /** @var string $commentText */
    $commentText = (string) ($row['comment'] ?? '');

    /** @var int $commentTime */
    $commentTime = isset($row['created_time']) ? (int) $row['created_time'] : 0;

    $commentID = (int) $row['c_id'];
    $commentOwnerId = (int) ($row['uid_fk'] ?? 0);
    $commentUpdatedTime = isset($row['updated_time']) ? (int) $row['updated_time'] : 0;
    // Optional: skip rows that are clearly incomplete.
    if ($ownerAvatar === '' || $commentUserName === '' || $commentText === '' || $commentTime <= 0) {
        // Developer note: loosen/tighten this validation to match your data guarantees.
        continue;
    }

    // Provide $postID and $iconPath to the template as well (kept immutable).
    // Include the view item. The template should use only the mapped variables above.
    include $commentTemplate;
}

// In feed mode, append a compact "view other N comments" link if there are more
if (isset($__mode) && $__mode === 'feed') {
    $shownCount = is_array($lastComments) ? count($lastComments) : 0;
    // Use precomputed totalComments from post_view if available; else compute
    $total = isset($totalComments) ? (int)$totalComments : (int)$RL->RL_TotalComment($postID);
    $remaining = max(0, $total - $shownCount);
    if ($remaining > 0) {
        $ownerUsername = isset($post['owner_username']) ? (string)$post['owner_username'] : '';
        $ownerUsername = preg_replace('~[^A-Za-z0-9_]+~', '', $ownerUsername);
        $href = rtrim((string)$base_url, '/') . '/posts/' . $postID . '/' . $ownerUsername;
        ?>
        <div class="show-other-comments flex align_items">
            <a class="view-all-comments" href="<?php echo iN_HelpSecure($href); ?>">
                <?php
                echo iN_HelpSecure(customLang(
                    $remaining === 1 ? 'view_other_comment' : 'view_other_comments',
                    $remaining === 1 ? 'View other {count} comment' : 'View other {count} comments',
                    ['count' => (string) $remaining]
                ));
                ?>
            </a>
        </div>
        <?php
    }
}
