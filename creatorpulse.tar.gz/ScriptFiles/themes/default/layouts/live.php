<?php
// Live stream page layout (renders inside main.php shell)
declare(strict_types=1);

// Route-level CSP override for live.
if (!headers_sent()) {
    header_remove('Content-Security-Policy');

    $defaultConnectParts = [
        "'self'",
        'https://*.agora.io',
        'https://*.agoracdn.com',
        'https://*.sd-rtn.com',
        'wss:'
    ];
    $envConnectRaw = getenv('CSP_CONNECT_SRC');
    $connectParts = $defaultConnectParts;
    if ($envConnectRaw !== false) {
        $envTokens = preg_split('/\s+/', trim((string) $envConnectRaw));
        if ($envTokens !== false) {
            foreach ($envTokens as $token) {
                $token = trim($token);
                if ($token !== '') {
                    $connectParts[] = $token;
                }
            }
        }
    }
    $connectParts = array_values(array_unique($connectParts));
    $connect = implode(' ', $connectParts);

    $imgSrcParts   = ["'self'", 'data:', 'blob:'];
    $mediaSrcParts = ["'self'", 'blob:'];

    $storageOrigin = null;
    $storageIsRemote = false;

    if (function_exists('storage_manager')) {
        $storageManager = storage_manager();
        if ($storageManager instanceof StorageManager) {
            $storageIsRemote = $storageManager->isRemote();
            if (function_exists('dz_csp_origin_from_url')) {
                $storageOrigin = dz_csp_origin_from_url($storageManager->getPublicBaseUrl());
            }
        }
    }

    if ($storageIsRemote && $storageOrigin) {
        $siteOrigin = function_exists('dz_csp_origin_from_url') ? dz_csp_origin_from_url($base_url ?? '') : null;
        if (!$siteOrigin || $storageOrigin !== $siteOrigin) {
            $imgSrcParts[] = $storageOrigin;
            $mediaSrcParts[] = $storageOrigin;
        }
    }

    $imgSrc   = implode(' ', array_unique($imgSrcParts));
    $mediaSrc = implode(' ', array_unique($mediaSrcParts));

    header(
        "Content-Security-Policy: connect-src {$connect}; frame-ancestors 'self'; default-src 'self'; script-src 'self'; style-src 'self'; img-src {$imgSrc}; font-src 'self' data:; media-src {$mediaSrc}; object-src 'none'; base-uri 'self'; form-action 'self'; frame-src 'self';",
        true
    );
}

// Flag footer to include Agora SDK + live-specific scripts only on this page
$liveStreamingEnabledGlobal = isset($liveStreamingEnabled) ? (bool)$liveStreamingEnabled : true;
$liveChatEnabledGlobal = isset($liveChatEnabled) ? (bool)$liveChatEnabled : true;
$liveViewerLimitGlobal = isset($liveViewerLimit) ? (int)$liveViewerLimit : 0;
$includeAgoraLive = $liveStreamingEnabledGlobal;

if (!$liveStreamingEnabledGlobal) {
    echo '<div class="warning_box full-width flex align_items_justify_content pad-24">' . iN_HelpSecure(customLang('live_stream_disabled_public') ?: 'Live streaming is currently disabled.', false) . '</div>';
    return;
}

$liveId = isset($_GET['live_id']) ? (int)$_GET['live_id'] : 0;
$live   = null;
if ($liveId > 0 && isset($RL) && method_exists($RL, 'RL_GetLiveById')) {
    $live = $RL->RL_GetLiveById($liveId);
}

if (!$live) {
    echo '<div class="warning_box full-width flex align_items_justify_content pad-24">' . customLang('live_not_found') . '</div>';
    return;
}

$ownerId = (int)($live['user_id'] ?? 0);
$isOwner = isset($userID) && (int)$userID === $ownerId;
$aud     = (string)($live['audience'] ?? 'everyone');

$ownerAvatarRel = (isset($RL) && method_exists($RL, 'RL_userAvatar')) ? $RL->RL_userAvatar($ownerId) : '';
if (function_exists('storage_resolve_media_url')) {
    $ownerAvatarUrl = storage_resolve_media_url((string)$ownerAvatarRel, $base_url ?? '');
} else {
    $ownerAvatarUrl = (string)($base_url ?? '') . ltrim((string)$ownerAvatarRel, '/');
}

// Audience gate (simple, can be expanded)
$canView = true;
if (!$isOwner) {
    if ($aud === 'only_me') { $canView = false; }
    elseif ($aud === 'followers') {
        if (!isset($userID) || (int)$userID <= 0) { $canView = false; }
        elseif (!method_exists($RL, 'RL_IsFollowing') || !$RL->RL_IsFollowing((int)$userID, $ownerId)) { $canView = false; }
    }
    elseif ($aud === 'subscribers') {
        if (!isset($userID) || (int)$userID <= 0) { $canView = false; }
        elseif (!method_exists($RL, 'RL_IsSubscriber') || !$RL->RL_IsSubscriber((int)$userID, $ownerId)) { $canView = false; }
    }
    elseif ($aud === 'following') {
        // Viewers that the owner follows
        if (!isset($userID) || (int)$userID <= 0) { $canView = false; }
        elseif (!method_exists($RL, 'RL_IsFollowing') || !$RL->RL_IsFollowing($ownerId, (int)$userID)) { $canView = false; }
    }
}

if (!$canView) {
    echo '<div class="warning_box full-width flex align_items_justify_content pad-24">' . customLang('live_restricted') . '</div>';
    return;
}

?>
<?php
  $tipThreshold = isset($siteData['tip_confetti_threshold']) ? (float)$siteData['tip_confetti_threshold'] : 50.0;
?>
<div class="contents_box flex align_items flexBoxColumn full-width" data-live-id="<?php echo (int)$liveId; ?>" data-owner-url="<?php
  $ownerUsername = (string)($live['username'] ?? '');
  $profileUrl = rtrim((string)$base_url, '/') . ($ownerUsername !== '' ? ('/profile/' . $ownerUsername) : '/');
  echo htmlspecialchars($profileUrl, ENT_QUOTES, 'UTF-8');
?>" data-is-owner="<?php echo $isOwner ? '1' : '0'; ?>" data-tip-threshold="<?php echo htmlspecialchars((string)$tipThreshold, ENT_QUOTES, 'UTF-8'); ?>" data-live-chat-enabled="<?php echo $liveChatEnabledGlobal ? '1' : '0'; ?>" data-viewer-cap="<?php echo (int)$liveViewerLimitGlobal; ?>">
  <div class="full-width flex align_items live-header">
    <div class="flex align_items gap">
      <?php $__liveName = (string)(($live['user_fullname'] ?? '') ?: ($live['username'] ?? '')); $__liveAlt = sprintf(customLang('alt_avatar_of_user'), $__liveName); ?>
      <img class="live-owner-avatar" src="<?php echo iN_HelpSecure($ownerAvatarUrl);?>" alt="<?php echo iN_HelpSecure($__liveAlt); ?>" />
      <div class="flex flexBoxColumn">
        <div class="post-owner-name">
          <?php echo htmlspecialchars((string)($live['user_fullname'] ?: $live['username']), ENT_QUOTES, 'UTF-8'); ?>
          <?php if (!empty($live['verified_status'])) { echo '<span class="ml-6">' . render_icon('verified', true) . '</span>'; } ?>
        </div>
        <div class="live-subtext"><?php echo customLang('live_label_live'); ?> • <?php echo htmlspecialchars((string)$live['audience'], ENT_QUOTES, 'UTF-8'); ?></div>
      </div>
    </div>
  </div>

  <div class="live-content">
    <div class="live-left">
      <div class="live-player live-player--wide">
        <!-- Dedicated video host; Agora mounts video inside this element -->
        <div id="liveVideoHost" class="live-video-host"></div>

        <div class="live-chips">
          <div class="chip chip-blue">
            <span class="icon"><?php echo render_icon('eye', true); ?></span>
            <span id="viewerCount" class="chip-txt">0</span>
          </div>
          <div class="chip chip-red">
            <span class="icon"><?php echo render_icon('live', true); ?></span>
            <span class="chip-txt"><?php echo customLang('live_badge_live'); ?></span>
          </div>
        </div>
        <div class="text-center">
          <div class="live-player-title">
            <?php echo htmlspecialchars((string)$live['title'], ENT_QUOTES, 'UTF-8'); ?>
          </div>
          <div class="live-muted"><?php echo customLang('live_starting'); ?></div>
        </div>

        <!-- Tip toasts container (must be direct child of player for absolute positioning) -->
        <div id="liveTipStream" class="live-tip-stream" aria-hidden="true"></div>

        <!-- Live like control + floating hearts overlay -->
        <?php
          $likedLive = (isset($RL) && method_exists($RL, 'RL_HasLikedLive')) ?
            (bool)$RL->RL_HasLikedLive((int)($userID ?? 0), (int)$liveId) : false;
          $totalLiveLikes = (isset($RL) && method_exists($RL, 'RL_CountLiveLikes')) ?
            (int)$RL->RL_CountLiveLikes((int)$liveId) : 0;
        ?>
        <div class="live-like-ctrl">
          <button id="liveLikeBtn"
                  class="post-button-heart p_like live-like-btn <?php echo $likedLive ? 'is-liked' : ''; ?>"
                  data-live-id="<?php echo (int)$liveId; ?>"
                  aria-pressed="<?php echo $likedLive ? 'true' : 'false'; ?>"
                  title="<?php echo customLang('live_like'); ?>">
            <span class="icon-unliked"><?php echo render_icon('like', true); ?></span>
            <span class="icon-liked"><?php echo render_icon('liked', true); ?></span>
          </button>
          <div id="liveLikeCount" class="live-like-count" aria-live="polite"><?php echo (int)$totalLiveLikes; ?></div>
          <div id="liveHeartStream" class="live-heart-stream" aria-hidden="true"></div>
        </div>
      </div>
      <div class="live-meta">
        <div class="live-title-bar"><?php echo customLang('live_title_prefix'); ?> <?php echo htmlspecialchars((string)$live['title'], ENT_QUOTES, 'UTF-8'); ?></div>
        <div class="channel-row">
          <div class="channel-left">
            <div class="channel-avatar">
              <?php $__chanAlt = sprintf(customLang('alt_avatar_of_user'), (string)($live['username'] ?? 'user')); ?>
              <img src="<?php echo iN_HelpSecure($ownerAvatarUrl);?>" alt="<?php echo iN_HelpSecure($__chanAlt); ?>" />
            </div>
            <div class="flex flexBoxColumn">
              <div class="channel-name"><?php echo htmlspecialchars((string)($live['username']), ENT_QUOTES, 'UTF-8'); ?></div>
              <div class="channel-sub">
                <?php
                  $followers = (isset($RL) && method_exists($RL,'RL_CountFollowers')) ? (int)$RL->RL_CountFollowers($ownerId) : 0;
                  echo number_format($followers) . ' ' . customLang('social_followers');
                ?>
              </div>
            </div>
          </div>
          <?php
            // Follow / subscription state
            $alreadyFollowing = false;
            $alreadySubscriber = false;
            if (!$isOwner && isset($RL) && isset($userID)) {
              if (method_exists($RL, 'RL_IsFollowing')) { $alreadyFollowing = $RL->RL_IsFollowing((int)$userID, (int)$ownerId); }
              if (method_exists($RL, 'RL_IsSubscriber')) { $alreadySubscriber = $RL->RL_IsSubscriber((int)$userID, (int)$ownerId); }
            }
            // Follow CTA reflects only direct follow state
            $isFollowingUi = (bool)$alreadyFollowing;

            // Subscription availability for owner
            $ownerDetails = isset($RL) && method_exists($RL, 'RL_GetUserDetails') ? $RL->RL_GetUserDetails((int)$ownerId) : [];
            $subNew = strtolower((string)($ownerDetails['subscription_status'] ?? ''));
            $subOld = strtolower((string)($ownerDetails['subscrition_status'] ?? ''));
            $subActive = ($subNew === 'open') || ($subNew === 'active') || ($subOld === 'active');
            $hasPlan = false;
            if ($subActive && isset($RL) && method_exists($RL, 'RL_GetUserSubscriptionPlans')) {
              try {
                $plan = $RL->RL_GetUserSubscriptionPlans((int)$ownerId);
                if ($plan) {
                  $prices = [
                    (float)($plan['price_weekly']   ?? 0),
                    (float)($plan['price_monthly']  ?? 0),
                    (float)($plan['price_halfyear'] ?? 0),
                    (float)($plan['price_yearly']   ?? 0),
                  ];
                  foreach ($prices as $p) { if ($p > 0) { $hasPlan = true; break; } }
                }
              } catch (\Throwable $__) { $hasPlan = false; }
            }
          ?>
          <div class="channel-actions">
            <div id="liveLikeChip" class="stat-chip clickable" data-live-id="<?php echo (int)$liveId; ?>" title="Like">
              <?php echo render_icon('like', true); ?>
              <span id="liveLikeTotal"><?php echo (int)$totalLiveLikes; ?></span>
            </div>
            <?php if (!$isOwner): ?>
            <div class="profile-actions follow_user flex align_items follow_this_user<?php echo $isFollowingUi ? ' is-following' : '';?>" data-id="<?php echo (int)$ownerId; ?>" aria-pressed="<?php echo $isFollowingUi ? 'true' : 'false';?>">
              <span class="follow_me flex align_items"><?php echo render_icon('follow', true); ?></span>
              <span class="follow_label"><?php echo $isFollowingUi ? customLang('live_following') : customLang('live_follow'); ?></span>
            </div>
            <?php if ($subActive && $hasPlan): ?>
              <?php if ($alreadySubscriber): ?>
                <div class="message_user flex align_items unsubscribeMe" data-id="<?php echo (int)$ownerId; ?>" aria-label="<?php echo customLang('live_unsubscribe'); ?>">
                  <span class="message_me flex align_items"><?php echo render_icon('creator_icon', true); ?></span>
                  <span class="message_label"><?php echo customLang('live_unsubscribe'); ?></span>
                </div>
              <?php else: ?>
                <div class="message_user flex align_items subscribeMe" data-id="<?php echo (int)$ownerId; ?>" aria-label="<?php echo customLang('live_subscribe'); ?>">
                  <span class="message_me flex align_items"><?php echo render_icon('creator_icon', true); ?></span>
                  <span class="message_label"><?php echo customLang('live_subscribe'); ?></span>
                </div>
              <?php endif; ?>
            <?php endif; ?>
            <?php endif; ?>
            <?php if ($isOwner) { ?>
              <button id="endLiveBtn" class="upload-btn btn-danger flex align_items" type="button"><?php echo customLang('live_end_button'); ?></button>
            <?php } else { ?>
              <?php
                  $__sendTipProvidersActive = isset($hasActivePaymentProviders)
                      ? (bool) $hasActivePaymentProviders
                      : (bool) ($GLOBALS['hasActivePaymentProviders'] ?? false);
                  $__sendTipAdminOverride = isset($isAdminUser)
                      ? (bool) $isAdminUser
                      : (bool) ($GLOBALS['isAdminUser'] ?? false);
                  $__displayLiveTipButton = $__sendTipProvidersActive || $__sendTipAdminOverride;
              ?>
              <?php if ($__displayLiveTipButton): ?>
              <button class="donate-btn sendTipUser flex align_items column-gap p_super_thanks_live" data-id="<?php echo (int)$ownerId; ?>" type="button" title="<?php echo customLang('live_send_thanks'); ?>">
                <?php echo render_icon('super_thanks', true); ?>
                <span><?php echo customLang('live_thanks'); ?></span>
              </button>
              <?php endif; ?>
            <?php } ?>
          </div>
        </div>
      </div>
    </div>
    <?php if ($liveChatEnabledGlobal): ?>
    <div class="live-right sticky">
      <div class="live-chat">
        <div class="live-chat-header"><?php echo customLang('live_chat_title'); ?></div>
        <div id="liveChatBody" class="live-chat-body">
          <div class="live-chat-msg"><span class="from"><?php echo customLang('live_chat_system'); ?></span><span class="msg"><?php echo customLang('live_chat_welcome'); ?></span></div>
        </div>
        <form id="liveChatForm" class="live-chat-input" autocomplete="off">
          <input id="liveChatInput" type="text" class="text-field" placeholder="<?php echo customLang('live_chat_input_placeholder'); ?>" />
          <button class="upload-btn" type="submit"><?php echo customLang('live_chat_send'); ?></button>
        </form>
      </div>
    </div>
    <?php else: ?>
    <div class="live-right sticky">
      <div class="live-chat live-chat--disabled">
        <div class="live-chat-header"><?php echo customLang('live_chat_title'); ?></div>
        <div class="live-chat-disabled-copy"><?php echo customLang('live_chat_disabled_message'); ?></div>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

  <script defer src="<?php echo iN_HelpSecure($base_url);?>themes/<?php echo iN_HelpSecure($currentTheme);?>/js/liveLike.js?v=<?php echo iN_HelpSecure($version);?>"></script>
  <script defer src="<?php echo iN_HelpSecure($base_url);?>themes/<?php echo iN_HelpSecure($currentTheme);?>/js/followUnfollow.js?v=<?php echo iN_HelpSecure($version);?>"></script>
  <?php if ($liveChatEnabledGlobal): ?>
  <script defer src="<?php echo iN_HelpSecure($base_url);?>themes/<?php echo iN_HelpSecure($currentTheme);?>/js/liveChat.js?v=<?php echo iN_HelpSecure($version);?>"></script>
  <?php endif; ?>
