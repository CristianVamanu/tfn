<?php
// Controller / page scope:
$postID   = isset($post['post_id']) ? (int) $post['post_id'] : 0;
$iconPath = $iconPath ?? (rtrim($base_url ?? '', '/') . '/themes/' . $currentTheme . '/img/');

// 1) Fetch last 3 comments
$lastComments = [];
if (isset($RL) && is_object($RL) && method_exists($RL, 'RL_GetRecentCommentsForPost')) {
    $lastComments = $RL->RL_GetRecentCommentsForPost($postID, 3);
}

// 2) Render with your template (foreach)
if (!empty($lastComments)) {
    $commentTemplate = __DIR__ . '/newComment.php';
    foreach ($lastComments as $row) {
        // Map data to the variables your template expects
        $ownerAvatar     = $row['avatar'];                  // <img src=...>
        $commentUserName = $row['username'];                // <a class="comment-owner">...</a>
        $commentText     = $row['comment'];                 // <span class="comment-text">...</span>
        $commentTime     = (int) $row['created_time'];      // timeAgo() or ISO8601 in template
        $commentID       = (int) $row['c_id'];
        $commentOwnerId  = (int) ($row['uid_fk'] ?? 0);
        $commentUpdatedTime = isset($row['updated_time']) ? (int) $row['updated_time'] : 0;
        // If template needs $postID/$iconPath too:
        $postID = (int) $postID;
        $iconPath = $iconPath;

        // Output the item
        if (is_file($commentTemplate)) {
            include $commentTemplate;
        }
    }
}
