 <?php
 // Resolve target profile by username from route: /profile/{username}
$targetUsername = isset($_GET['username']) ? trim((string)$_GET['username']) : '';
$targetUserId   = 0;
$targetUser     = null;

 if ($targetUsername !== '' && isset($RL) && method_exists($RL, 'RL_UserIdsByUsernames')) {
     $map = $RL->RL_UserIdsByUsernames([$targetUsername]);
     $key = mb_strtolower($targetUsername, 'UTF-8');
     $targetUserId = (int)($map[$key] ?? 0);
 }

 if ($targetUserId > 0 && method_exists($RL, 'RL_GetUserDetails')) {
     $targetUser = $RL->RL_GetUserDetails($targetUserId);
 }

 // If user not found or banned, render 404
 $isTargetMissing = ($targetUserId <= 0) || !$targetUser || isset($targetUser['error']);
 $isTargetBanned  = false;
 if (!$isTargetMissing) {
     $isTargetBanned = (int)($targetUser['is_banned'] ?? 0) === 1;
 }
 if ($isTargetMissing || $isTargetBanned) {
     // Redirect to 404 route to render full error page
     header('Location: ' . rtrim((string)$base_url, '/') . '/404');
     exit;
 }

 // Basic fallbacks
$tuUsername   = $targetUser['username']      ?? $targetUsername;
 $tuFullname   = $targetUser['user_fullname'] ?? $tuUsername;
$tuBio        = $targetUser['about_me']      ?? '';
$tuVerified   = (int)($targetUser['verified_status'] ?? 0);
$isOwner      = (isset($userID) && (int)$userID === (int)$targetUserId);

$subscribeLabel          = customLang('live_subscribe', 'Subscribe');
$unsubscribeLabel        = customLang('live_unsubscribe', 'Unsubscribe');
$unsubscribePrompt       = customLang('subscription_cancel_confirm', 'Are you sure you want to cancel your subscription?');
$unsubscribeConfirmLabel = customLang('subscription_cancel_confirm_action', 'Yes, cancel subscription');
$unsubscribeKeepLabel    = customLang('subscription_cancel_keep_action', 'Keep subscription');
$unsubscribeTitle        = customLang('subscription_cancel_confirm_title', 'Cancel subscription?');

 // Subscription availability for the profile owner
 // Consider both new `subscription_status` (open/close) and legacy `subscrition_status` (active/passive)
 $subStatusNew = strtolower((string)($targetUser['subscription_status'] ?? ''));
 $subStatusOld = strtolower((string)($targetUser['subscrition_status'] ?? ''));
 $tuSubscriptionOpen = ($subStatusNew === 'open') || ($subStatusNew === 'active') || ($subStatusOld === 'active');
 $tuHasPlan = false;
 if ($targetUserId > 0 && isset($RL) && method_exists($RL, 'RL_GetUserSubscriptionPlans')) {
     try {
         $plan = $RL->RL_GetUserSubscriptionPlans((int)$targetUserId);
         if ($plan) {
             $prices = [
                 (float)($plan['price_weekly']   ?? 0),
                 (float)($plan['price_monthly']  ?? 0),
                 (float)($plan['price_halfyear'] ?? 0),
                 (float)($plan['price_yearly']   ?? 0),
             ];
             foreach ($prices as $p) { if ($p > 0) { $tuHasPlan = true; break; } }
         }
     } catch (Throwable $e) { $tuHasPlan = false; }
 }

 // Avatar & Cover
$avatarRel    = isset($RL) && method_exists($RL, 'RL_userAvatar') ? $RL->RL_userAvatar((int)$targetUserId) : 'uploads/user_avatars/default.jpeg';
$avatarUrl    = storage_url($avatarRel);
$coverRel     = isset($RL) && method_exists($RL, 'RL_GetUserCover') ? $RL->RL_GetUserCover((int)$targetUserId) : '';
$coverUrl     = $coverRel !== '' ? storage_url($coverRel) : '';
$profilePodcastsUrl = ($base_url ?? '') . 'profile/' . ($tuUsername ?? '') . '/podcasts';

 // Counters
 $followers = (isset($RL) && method_exists($RL, 'RL_CountFollowers')) ? (int)$RL->RL_CountFollowers((int)$targetUserId) : 0;
 $following = (isset($RL) && method_exists($RL, 'RL_CountFollowing')) ? (int)$RL->RL_CountFollowing((int)$targetUserId) : 0;

// Posts counters via dedicated helper
$postsCount = 0;
$reelsCount = 0;
$imagesCount = 0;
$premiumCount = 0; // locked
$subscriberOnlyCount = 0; // subscribers-only
$podcastCount = 0;
if ($targetUserId > 0 && isset($RL) && method_exists($RL, 'RL_ProfileCounters')) {
    $cnt = (array)$RL->RL_ProfileCounters((int)$targetUserId);
    $postsCount          = (int)($cnt['posts'] ?? 0);
    $reelsCount          = (int)($cnt['reels'] ?? 0);
    $imagesCount         = (int)($cnt['images'] ?? 0);
    $premiumCount        = (int)($cnt['premium'] ?? 0);
    $subscriberOnlyCount = (int)($cnt['subscriber'] ?? 0);
    $podcastCount        = (int)($cnt['podcasts'] ?? 0);
}

 // Determine selected tab/filter from router (index.php sets $_GET['tab'])
 $allowedTabs = ['all','reels','images','podcasts','premium','subscriber','followers','following'];
 if (empty($enableVideoPosts)) {
     $allowedTabs = array_values(array_diff($allowedTabs, ['reels']));
 }
 if (empty($enableImagePosts)) {
     $allowedTabs = array_values(array_diff($allowedTabs, ['images']));
 }
 $selectedFilter = isset($_GET['tab']) && in_array($_GET['tab'], $allowedTabs, true) ? $_GET['tab'] : 'all';
$selectedView = isset($_GET['view']) && $_GET['view'] === 'feed' ? 'feed' : 'grid';
if ($selectedFilter === 'followers' || $selectedFilter === 'following' || $selectedFilter === 'podcasts') {
    $selectedView = 'grid';
}
$profileUrlFor = static function (string $tab = 'all', string $view = 'grid') use ($base_url, $tuUsername): string {
    $base = rtrim((string)$base_url, '/') . '/profile/' . rawurlencode((string)$tuUsername);
    $tabPath = [
        'all'        => '',
        'reels'      => '/reels',
        'images'     => '/images',
        'podcasts'   => '/podcasts',
        'premium'    => '/premiums',
        'subscriber' => '/subscribers',
        'followers'  => '/followers',
        'following'  => '/following',
    ];
    $url = $base . ($tabPath[$tab] ?? '');
    if ($view === 'feed' && !in_array($tab, ['followers', 'following', 'podcasts'], true)) {
        $url .= '?view=feed';
    }
    return $url;
};
$podcastCategorySlug = null;
if (isset($_GET['category'])) {
    $candidateSlug = strtolower(trim((string) $_GET['category']));
    if ($candidateSlug !== '' && preg_match('/^[a-z0-9-]+$/', $candidateSlug)) {
        $podcastCategorySlug = $candidateSlug;
    }
}
$podcastCategoryMeta = null;
if ($podcastCategorySlug && isset($RL) && method_exists($RL, 'RL_GetPodcastCategoryBySlug')) {
    $podcastCategoryMeta = $RL->RL_GetPodcastCategoryBySlug($podcastCategorySlug);
}

 // Follow / subscription state for viewer (if logged in and not owner)
 $alreadyFollowing = false;
 $alreadySubscriber = false;
 if (!$isOwner && isset($RL) && method_exists($RL, 'RL_IsFollowing') && isset($userID)) {
     $alreadyFollowing = $RL->RL_IsFollowing((int)$userID, (int)$targetUserId);
 }
 if (!$isOwner && isset($RL) && method_exists($RL, 'RL_IsSubscriber') && isset($userID)) {
     $alreadySubscriber = $RL->RL_IsSubscriber((int)$userID, (int)$targetUserId);
 }
 // Follow button should reflect actual follow state only
 $isFollowingUi = (bool)$alreadyFollowing;
 ?>

 <?php
    // Initial grid page by selected filter
    $initialTiles = 10;
    $grid = [
        'blocks' => [],
        'nextCursor' => ['time'=>0,'id'=>0],
        'hasMore' => false,
        'startLayout' => 'right'
    ];
    $gridHtml = '';
    $feedHtml = '';
    $feedResult = ['posts' => [], 'nextCursor' => ['time'=>0,'id'=>0], 'hasMore' => false];
    $hasAnyContent = false;
    $podcastList = [];
    $podcastTotalDuration = 0;
    if ($selectedFilter === 'podcasts' && $targetUserId > 0 && isset($RL) && method_exists($RL, 'RL_ProfileGetPodcastsList')) {
        $podcastList = $RL->RL_ProfileGetPodcastsList((int)$targetUserId, 50, $podcastCategorySlug);
        foreach ($podcastList as $pd) {
            if (!empty($pd['duration'])) {
                $podcastTotalDuration += (int)$pd['duration'];
            }
        }
    }

    if ($targetUserId > 0 && $selectedView === 'feed' && isset($RL) && method_exists($RL, 'RL_ProfileGetFeedByCursor') && $selectedFilter !== 'followers' && $selectedFilter !== 'following' && $selectedFilter !== 'podcasts') {
        $feedResult = $RL->RL_ProfileGetFeedByCursor((int)$targetUserId, 0, 0, (int)$initialTiles, $selectedFilter);
        $grid['nextCursor'] = $feedResult['nextCursor'];
        $grid['hasMore'] = $feedResult['hasMore'];
        $hasAnyContent = !empty($feedResult['posts']);
        if ($hasAnyContent) {
            ob_start();
            $__externalPosts = $feedResult['posts'];
            $__suppressEmptyFeedMessage = true;
            $viewMode = 'feed';
            include __DIR__ . '/post_view.php';
            $feedHtml = (string) ob_get_clean();
            unset($__externalPosts, $__suppressEmptyFeedMessage, $viewMode);
        }
    } elseif ($targetUserId > 0 && isset($RL) && method_exists($RL, 'RL_ProfileGetPageByCursor') && $selectedFilter !== 'followers' && $selectedFilter !== 'following' && $selectedFilter !== 'podcasts') {
        $grid = $RL->RL_ProfileGetPageByCursor((int)$targetUserId, 0, 0, (int)$initialTiles, $selectedFilter);
        if ($selectedFilter === 'all') {
            if (method_exists($RL, 'RL_ProfileRenderToString')) {
                $gridHtml = $RL->RL_ProfileRenderToString($grid['blocks'], $grid['startLayout']);
            }
            // Determine if there is any real tile (non-ghost)
            foreach ($grid['blocks'] as $block) {
                for ($i=0; $i<5; $i++) {
                    if (!isset($block[$i]) || !is_array($block[$i])) { continue; }
                    if (($block[$i]['type'] ?? 'ghost') !== 'ghost') { $hasAnyContent = true; break 2; }
                }
            }
        } else {
            // Flatten blocks to tiles and render as images/reels list
            $tiles = [];
            foreach ($grid['blocks'] as $block) {
                for ($i=0; $i<5; $i++) {
                    if (!isset($block[$i]) || !is_array($block[$i])) { continue; }
                    $t = $block[$i];
                    if (($t['type'] ?? 'ghost') === 'ghost') { continue; }
                    $tiles[] = $t;
                }
            }
            $hasAnyContent = count($tiles) > 0;
            if (method_exists($RL, 'RL_ProfileRenderListToString')) {
                $mode = ($selectedFilter === 'reels') ? 'reels' : 'images';
                $gridHtml = $RL->RL_ProfileRenderListToString($tiles, $mode);
            }
        }
    }
 ?>
 <div class="main-content">
    <div class="explore-area">
    <!---->
    <?php if ($coverUrl !== ''): ?>
        <div class="profile-cover">
            <img class="profile-cover-img" src="<?php echo iN_HelpSecure($coverUrl,false); ?>" alt="">
        </div>
    <?php else: ?>
        <div class="profile-cover profile-cover--empty"></div>
    <?php endif; ?>
    <!---->
        <!---->
        <div class="profile-left">
            <div class="profile-left-container flex align_items flexBoxColumn">
               <div class="posts-container gap full-width relative flex align_items flexBoxColumn" id="profile">
                <!---->
                <div class="profile-top-container full-width">
                    <?php if ($targetUserId > 0): ?>
                        <div class="profile-header flex align_items flexBoxColumn">
                            <div class="profile-avatar">
                                <img src="<?php echo iN_HelpSecure($avatarUrl, false); ?>" alt="<?php echo iN_HelpSecure($tuUsername); ?>">
                            </div>
                            <div class="profile-meta full-width flex align_items_justify_content flexBoxColumn">
                                <div class="profile-username-row flex align_items gap flexBoxColumn">
                                    <div class="profile-username">
                                        <?php echo iN_HelpSecure($tuUsername); ?>
                                        <?php if ($tuVerified === 1): ?>
                                            <span class="verified-badge flex align_items"><?php echo render_icon('verified', true); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="profile-fullname"><?php echo iN_HelpSecure($tuFullname); ?></div>
                                    <div class="profile-actions flex align_items gap">
                                        <?php if ($isOwner): ?>
                                            <?php
                                                $editProfileBase = isset($base_url) ? rtrim((string)$base_url, '/') : '';
                                                $editProfileHref = $editProfileBase !== '' ? $editProfileBase . '/settings' : 'settings';
                                            ?>
                                            <a href="<?php echo iN_HelpSecure($editProfileHref, false); ?>" class="message_user flex align_items" aria-label="<?php echo customLang('profile_edit_profile'); ?>">
                                                <span class="message_label"><?php echo customLang('profile_edit_profile'); ?></span>
                                            </a>
                                        <?php else: ?>
                                            <div class="follow_user flex align_items follow_this_user<?php echo $isFollowingUi ? ' is-following' : '';?>" data-id="<?php echo (int)$targetUserId; ?>" aria-pressed="<?php echo $isFollowingUi ? 'true' : 'false';?>">
                                                <span class="follow_me flex align_items"><?php echo render_icon('follow', true); ?></span>
              <span class="follow_label"><?php echo $isFollowingUi ? customLang('live_following') : customLang('live_follow'); ?></span>
            </div>
                                            <?php if ($tuSubscriptionOpen && $tuHasPlan): ?>
                                                <?php if ($alreadySubscriber): ?>
                <div class="message_user flex align_items unsubscribeMe"
                     data-id="<?php echo (int)$targetUserId; ?>"
                     data-label-subscribe="<?php echo iN_HelpSecure($subscribeLabel, false); ?>"
                     data-label-unsubscribe="<?php echo iN_HelpSecure($unsubscribeLabel, false); ?>"
                     data-confirm="<?php echo iN_HelpSecure($unsubscribePrompt, false); ?>"
                     data-confirm-title="<?php echo iN_HelpSecure($unsubscribeTitle, false); ?>"
                     data-confirm-label="<?php echo iN_HelpSecure($unsubscribeConfirmLabel, false); ?>"
                     data-cancel-label="<?php echo iN_HelpSecure($unsubscribeKeepLabel, false); ?>"
                     aria-label="<?php echo iN_HelpSecure($unsubscribeLabel); ?>">
                  <span class="message_me flex align_items"><?php echo render_icon('creator_icon', true); ?></span>
                  <span class="message_label"><?php echo iN_HelpSecure($unsubscribeLabel); ?></span>
                </div>
                                                <?php else: ?>
                                                    <div class="message_user flex align_items subscribeMe"
                                                         data-id="<?php echo (int)$targetUserId; ?>"
                                                         data-label-subscribe="<?php echo iN_HelpSecure($subscribeLabel, false); ?>"
                                                         data-label-unsubscribe="<?php echo iN_HelpSecure($unsubscribeLabel, false); ?>"
                                                         data-confirm="<?php echo iN_HelpSecure($unsubscribePrompt, false); ?>"
                                                         data-confirm-title="<?php echo iN_HelpSecure($unsubscribeTitle, false); ?>"
                                                         data-confirm-label="<?php echo iN_HelpSecure($unsubscribeConfirmLabel, false); ?>"
                                                         data-cancel-label="<?php echo iN_HelpSecure($unsubscribeKeepLabel, false); ?>"
                                                         aria-label="<?php echo iN_HelpSecure($subscribeLabel); ?>">
                                                        <span class="message_me flex align_items"><?php echo render_icon('creator_icon', true); ?></span>
                                                        <span class="message_label"><?php echo iN_HelpSecure($subscribeLabel); ?></span>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <div class="message_user message_user--chat flex align_items getTheChat" data-id="<?php echo (int)$targetUserId; ?>" aria-label="<?php echo customLang('profile_message_user'); ?>">
                                                <span class="message_me flex align_items"><?php echo render_icon('messages', true); ?></span>
                                                <span class="message_label"><?php echo customLang('profile_message_user'); ?></span>
                                            </div>
                                            <?php /* Owner-specific CTA moved below as a banner */ ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="profile-stats flex gap">
                                    <a class="stat-item transition cursor-point<?php echo ($selectedFilter==='all') ? ' is-active' : ''; ?>" href="<?php echo iN_HelpSecure($profileUrlFor('all', $selectedView)); ?>"><span class="stat-num"><?php echo number_format((int)$postsCount); ?></span> <?php echo customLang('social_posts'); ?></a>
                                    <a class="stat-item transition cursor-point<?php echo ($selectedFilter==='followers') ? ' is-active' : ''; ?>" href="<?php echo iN_HelpSecure($base_url.'profile/'.$tuUsername.'/followers'); ?>"><span class="stat-num"><?php echo number_format((int)$followers); ?></span> <?php echo customLang('social_followers'); ?></a>
                                    <a class="stat-item transition cursor-point<?php echo ($selectedFilter==='following') ? ' is-active' : ''; ?>" href="<?php echo iN_HelpSecure($base_url.'profile/'.$tuUsername.'/following'); ?>"><span class="stat-num"><?php echo number_format((int)$following); ?></span> <?php echo customLang('social_following'); ?></a>
                                </div>
                                <?php if ($isOwner && (!$tuSubscriptionOpen || !$tuHasPlan)): ?>
                                    <div class="tips-alert is-info is-open" role="alert">
                                        <div class="flex align_items gap">
                                            <span class="flex align_items"><?php echo render_icon('subscription_fees', true); ?></span>
                                            <span>
                                                <?php echo customLang('subscription_owner_hint'); ?>
                                                <a href="<?php echo iN_HelpSecure($base_url . 'settings?tab=subscription_fees', false); ?>"><?php echo customLang('subscription_activate_cta'); ?></a>
                                            </span>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($tuBio)): ?>
                                    <div class="profile-bio"><?php echo iN_HelpSecure($tuBio); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="no-profile-found"><?php echo customLang('profile_not_found'); ?></div>
                    <?php endif; ?>
                </div>
                <!---->
                <?php if ($targetUserId > 0): ?>
                <div class="profile-tabs-scroll">
                  <button class="tabs-arrow tabs-arrow--left" aria-label="<?php echo iN_HelpSecure(customLang('profile_tabs_scroll_left')); ?>" type="button">
                    <?php echo render_icon('prev', true); ?>
                  </button>
                  <div class="tabs-viewport">
                    <div class="profile-tabs flex align_items">
                    <a class="profile-tab flex align_items gap <?php echo $selectedFilter==='all'?'is-active':''; ?>" href="<?php echo iN_HelpSecure($profileUrlFor('all', $selectedView)); ?>" data-filter="all">
                        <span class="tab-icon flex align_items"><?php echo render_icon('grid_view', true); ?></span>
                        <span class="tab-label"><?php echo customLang('tab_all'); ?></span>
                    </a>
                    <?php if (!empty($enableVideoPosts)): ?>
                    <a class="profile-tab flex align_items gap <?php echo $selectedFilter==='reels'?'is-active':''; ?>" href="<?php echo iN_HelpSecure($profileUrlFor('reels', $selectedView)); ?>" data-filter="reels">
                        <span class="tab-icon flex align_items"><?php echo render_icon('reels', true); ?></span>
                        <span class="tab-label"><?php echo customLang('tab_reels'); ?></span>
                        <span class="tab-count"><?php echo number_format((int)$reelsCount); ?></span>
                    </a>
                    <?php endif; ?>
                    <?php if (!empty($enableImagePosts)): ?>
                    <a class="profile-tab flex align_items gap <?php echo $selectedFilter==='images'?'is-active':''; ?>" href="<?php echo iN_HelpSecure($profileUrlFor('images', $selectedView)); ?>" data-filter="images">
                        <span class="tab-icon flex align_items"><?php echo render_icon('images', true); ?></span>
                        <span class="tab-label"><?php echo customLang('tab_images'); ?></span>
                        <span class="tab-count"><?php echo number_format((int)$imagesCount); ?></span>
                    </a>
                    <?php endif; ?>
                    <a class="profile-tab flex align_items gap <?php echo $selectedFilter==='podcasts'?'is-active':''; ?>" href="<?php echo iN_HelpSecure($base_url.'profile/'.$tuUsername.'/podcasts'); ?>" data-filter="podcasts">
                        <span class="tab-icon flex align_items"><?php echo render_icon('podcast', true); ?></span>
                        <span class="tab-label"><?php echo customLang('profile_tab_podcasts', 'Podcasts'); ?></span>
                        <span class="tab-count"><?php echo number_format((int)$podcastCount); ?></span>
                    </a>
                    <a class="profile-tab flex align_items gap <?php echo $selectedFilter==='premium'?'is-active':''; ?>" href="<?php echo iN_HelpSecure($profileUrlFor('premium', $selectedView)); ?>" data-filter="premium">
                        <span class="tab-icon flex align_items"><?php echo render_icon('locked', true); ?></span>
                        <span class="tab-label"><?php echo customLang('tab_premium'); ?></span>
                        <span class="tab-count"><?php echo number_format((int)$premiumCount); ?></span>
                    </a>
                    <a class="profile-tab flex align_items gap <?php echo $selectedFilter==='subscriber'?'is-active':''; ?>" href="<?php echo iN_HelpSecure($profileUrlFor('subscriber', $selectedView)); ?>" data-filter="subscriber">
                        <span class="tab-icon flex align_items"><?php echo render_icon('creator_icon', true); ?></span>
                        <span class="tab-label"><?php echo customLang('tab_subscriber'); ?></span>
                        <span class="tab-count"><?php echo number_format((int)$subscriberOnlyCount); ?></span>
                    </a>
                    </div>
                  </div>
                  <button class="tabs-arrow tabs-arrow--right" aria-label="<?php echo iN_HelpSecure(customLang('profile_tabs_scroll_right')); ?>" type="button">
                    <?php echo render_icon('next', true); ?>
                  </button>
                </div>
                <?php if (!in_array($selectedFilter, ['followers', 'following', 'podcasts'], true)): ?>
                <div class="profile-view-toggle flex align_items" role="group" aria-label="<?php echo iN_HelpSecure(customLang('profile_view_toggle_label', 'Profile view')); ?>">
                    <a class="profile-view-toggle__item flex align_items<?php echo $selectedView === 'grid' ? ' is-active' : ''; ?>"
                       href="<?php echo iN_HelpSecure($profileUrlFor($selectedFilter, 'grid')); ?>"
                       aria-pressed="<?php echo $selectedView === 'grid' ? 'true' : 'false'; ?>">
                        <span class="profile-view-toggle__icon flex align_items"><?php echo render_icon('grid_view', true); ?></span>
                        <span><?php echo iN_HelpSecure(customLang('profile_view_grid', 'Grid')); ?></span>
                    </a>
                    <a class="profile-view-toggle__item flex align_items<?php echo $selectedView === 'feed' ? ' is-active' : ''; ?>"
                       href="<?php echo iN_HelpSecure($profileUrlFor($selectedFilter, 'feed')); ?>"
                       aria-pressed="<?php echo $selectedView === 'feed' ? 'true' : 'false'; ?>">
                        <span class="profile-view-toggle__icon flex align_items"><?php echo render_icon('home_page', true); ?></span>
                        <span><?php echo iN_HelpSecure(customLang('profile_view_feed', 'Feed')); ?></span>
                    </a>
                </div>
                <?php endif; ?>
                <div class="full-width flex gap-root align_items flexBoxColumn" id="profile-root"
                     data-user-id="<?php echo (int)$targetUserId; ?>"
                     data-filter="<?php echo iN_HelpSecure($selectedFilter); ?>"
                     data-view="<?php echo iN_HelpSecure($selectedView); ?>"
                     data-cursor-time="<?php echo (int)($grid['nextCursor']['time'] ?? 0); ?>"
                     data-cursor-id="<?php echo (int)($grid['nextCursor']['id'] ?? 0); ?>"
                     data-has-more="<?php echo !empty($grid['hasMore']) ? '1' : '0'; ?>"
                     data-limit="<?php echo (int)$initialTiles; ?>"
                     data-start-layout="<?php echo htmlspecialchars($grid['startLayout'] ?? 'right', ENT_QUOTES, 'UTF-8'); ?>">
                    <?php if ($selectedFilter === 'followers' || $selectedFilter === 'following'): ?>
                        <?php
                        // Reuse creators.php card markup for a professional list view
                        $usersList = [];
                        if (isset($RL)) {
                            if ($selectedFilter === 'followers' && method_exists($RL, 'RL_ProfileGetFollowers')) {
                                $usersList = $RL->RL_ProfileGetFollowers((int)$targetUserId, 0, 50);
                            } elseif ($selectedFilter === 'following' && method_exists($RL, 'RL_ProfileGetFollowing')) {
                                $usersList = $RL->RL_ProfileGetFollowing((int)$targetUserId, 0, 50);
                            }
                        }
                        // Prepare creators dataset with counts and latest posts
                        if (method_exists($RL, 'RL_ProfileEnrichCreators')) {
                            $creators = $RL->RL_ProfileEnrichCreators($usersList);
                        } else {
                            $creators = array_map(function($u){ return (array)$u; }, $usersList);
                        }
                        $baseUrl = iN_HelpSecure($base_url);
                        // Empty-state label per page
                        $emptyMsgMap = [
                            'followers'  => 'No followers yet',
                            'following'  => 'Not following anyone yet',
                        ];
                        $emptyMsg = $emptyMsgMap[$selectedFilter] ?? 'No data';

                        if (!empty($creators)) {
                            // Render using the same template used for creators
                            echo '<div class="creators-grid full-width flex align_items">';
                            include __DIR__ . '/creators.php';
                            echo '</div>';
                        } else {
                            echo '<div class="empty-state flex align_items_justify_content gap flexBoxColumn">'
                               . '  <div class="empty-state__icon flex align_items">' . render_icon('not_founded', true) . '</div>'
                               . '  <div class="empty-state__title flex align_items">' . iN_HelpSecure(customLang($selectedFilter === 'followers' ? 'empty_no_followers' : 'empty_not_following_anyone')) . '</div>'
                               . '</div>';
                        }
                        ?>
                    <?php elseif ($selectedFilter === 'podcasts'): ?>
                        <?php if ($podcastCategorySlug): ?>
                            <?php $filterLabel = $podcastCategoryMeta['name'] ?? $podcastCategorySlug; ?>
                            <div class="podcast-filter-chip flex align_items gap">
                                <span class="podcast-category-chip"><?php echo iN_HelpSecure(customLang('podcast_category_label', 'Category')); ?>: <?php echo iN_HelpSecure($filterLabel); ?></span>
                                <a class="podcast-filter-clear" href="<?php echo iN_HelpSecure($profilePodcastsUrl); ?>"><?php echo iN_HelpSecure(customLang('podcast_category_filter_clear', 'Clear')); ?></a>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($podcastList)): ?>
                            <?php
                            $feature = $podcastList[0];
                            $featureTitle = $feature['title'] !== '' ? $feature['title'] : customLang('profile_podcast_untitled', 'Untitled podcast');
                            $featureDuration = isset($feature['duration']) && $feature['duration'] ? gmdate('i:s', (int)$feature['duration']) : '00:00';
                            $featureDate = $feature['created'] ? date('M j, Y', (int)$feature['created']) : '';
                            $totalTracks = count($podcastList);
                            $totalDurationLabel = $podcastTotalDuration > 0
                                ? gmdate($podcastTotalDuration >= 3600 ? 'H:i:s' : 'i:s', $podcastTotalDuration)
                                : customLang('profile_podcast_album_value', '—');
                        ?>
                            <div class="podcast-page">
                                <div class="profile-podcast-hero flex gap">
                                    <div class="profile-podcast-hero__art">
                                        <div class="podcast-hero-cover<?php echo empty($feature['cover_url']) ? ' has-placeholder' : ''; ?>">
                                            <?php if (!empty($feature['cover_url'])): ?>
                                                <img src="<?php echo iN_HelpSecure($feature['cover_url']); ?>" alt="<?php echo iN_HelpSecure($featureTitle); ?>">
                                            <?php else: ?>
                                                <span class="podcast-cover-placeholder flex align_items_justify_content"><?php echo render_icon('music', true); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="profile-podcast-hero__meta flex flexBoxColumn gap">
                                        <div class="pp-hero-eyebrow"><?php echo customLang('profile_podcast_latest', 'Latest podcast'); ?></div>
                                        <h3 class="pp-hero-title"><?php echo iN_HelpSecure($featureTitle); ?></h3>
                                        <div class="pp-hero-sub"><?php echo iN_HelpSecure($featureDate); ?> · <?php echo iN_HelpSecure($featureDuration); ?></div>
                                        <?php if (!empty($feature['category_name'])): ?>
                                            <?php
                                                $heroCategoryUrl = $profilePodcastsUrl;
                                                if (!empty($feature['category_slug'])) {
                                                    $heroCategoryUrl .= '?category=' . rawurlencode((string)$feature['category_slug']);
                                                }
                                            ?>
                                            <a class="podcast-category-chip" href="<?php echo iN_HelpSecure($heroCategoryUrl); ?>">
                                                <?php echo iN_HelpSecure($feature['category_name']); ?>
                                            </a>
                                        <?php endif; ?>
                                        <div class="pp-hero-stats flex gap">
                                            <div class="pp-stat"><span class="pp-stat__label"><?php echo iN_HelpSecure($tuFullname); ?></span></div>
                                            <div class="pp-stat"><span class="pp-stat__label"><?php echo customLang('profile_podcast_tracks', 'Tracks'); ?></span> <span class="pp-stat__value"><?php echo (int)$totalTracks; ?></span></div>
                                            <div class="pp-stat"><span class="pp-stat__label"><?php echo customLang('profile_podcast_duration', 'Duration'); ?></span> <span class="pp-stat__value"><?php echo iN_HelpSecure($totalDurationLabel); ?></span></div>
                                            <?php if (!empty($feature['category_name'])): ?>
                                                <div class="pp-stat"><span class="pp-stat__label"><?php echo customLang('podcast_category_label', 'Category'); ?></span> <span class="pp-stat__value"><?php echo iN_HelpSecure($feature['category_name']); ?></span></div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="pp-hero-actions flex align_items gap">
                                            <button type="button" class="btn btn-primary pp-hero-play" data-target="hero" data-play-label="<?php echo iN_HelpSecure(customLang('profile_podcast_play', 'Play')); ?>" data-pause-label="<?php echo iN_HelpSecure(customLang('profile_podcast_pause', 'Pause')); ?>">
                                                <span class="pp-hero-label"><?php echo customLang('profile_podcast_play', 'Play'); ?></span>
                                            </button>
                                        </div>
                                        <audio class="profile-podcast-hero__audio" preload="metadata" src="<?php echo iN_HelpSecure($feature['audio_url']); ?>"></audio>
                                    </div>
                                </div>
                                <div class="profile-podcast-list">
                                    <div class="pp-list-head flex align_items">
                                        <div class="pp-col pp-col__track"><?php echo customLang('profile_podcast_track', 'Track'); ?></div>
                                        <div class="pp-col pp-col__about"><?php echo customLang('profile_podcast_about', 'About'); ?></div>
                                        <div class="pp-col pp-col__time"><?php echo customLang('profile_podcast_time', 'Time'); ?></div>
                                    </div>
                                    <?php foreach ($podcastList as $idx => $pod): ?>
                                        <?php
                                        $title = $pod['title'] !== '' ? $pod['title'] : customLang('profile_podcast_untitled', 'Untitled podcast');
                                            $about = $pod['title'] !== '' ? $pod['title'] : customLang('profile_podcast_album_value', '—');
                                            $dur   = isset($pod['duration']) && $pod['duration'] ? gmdate('i:s', (int)$pod['duration']) : '00:00';
                                        ?>
                                        <div class="podcast-row flex align_items<?php echo $idx === 0 ? ' is-featured-row' : ''; ?>" data-id="<?php echo (int)$pod['post_id']; ?>">
                                            <button type="button" class="podcast-row-play" aria-label="<?php echo iN_HelpSecure(customLang('ui_play_pause', 'Play / Pause')); ?>"></button>
                                            <div class="podcast-row-track flex align_items gap">
                                                <div class="podcast-row-thumb<?php echo empty($pod['cover_url']) ? ' has-placeholder' : ''; ?>">
                                                    <?php if (!empty($pod['cover_url'])): ?>
                                                        <img src="<?php echo iN_HelpSecure($pod['cover_url']); ?>" alt="">
                                                    <?php else: ?>
                                                        <span class="podcast-cover-placeholder flex align_items_justify_content"><?php echo render_icon('music', true); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="podcast-row-title"><?php echo iN_HelpSecure($title); ?></div>
                                            </div>
                                            <div class="podcast-row-about">
                                                <div class="podcast-row-about__text"><?php echo iN_HelpSecure($about); ?></div>
                                                <?php if (!empty($pod['category_name'])): ?>
                                                    <div class="podcast-row-category"><?php echo iN_HelpSecure($pod['category_name']); ?></div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="podcast-row-time"><?php echo iN_HelpSecure($dur); ?></div>
                                            <audio preload="metadata" src="<?php echo iN_HelpSecure($pod['audio_url']); ?>"></audio>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="empty-state flex align_items_justify_content gap flexBoxColumn">
                                <div class="empty-state__icon flex align_items"><?php echo render_icon('not_founded', true); ?></div>
                                <div class="empty-state__title flex align_items">
                                    <?php
                                        $emptyLabel = $podcastCategorySlug
                                            ? customLang('profile_empty_podcasts_filtered', 'No podcasts found in this category.')
                                            : customLang('profile_empty_podcasts', 'No podcasts yet.');
                                        echo iN_HelpSecure($emptyLabel);
                                    ?>
                                </div>
                                <?php if ($podcastCategorySlug): ?>
                                    <a class="podcast-filter-clear" href="<?php echo iN_HelpSecure($profilePodcastsUrl); ?>"><?php echo iN_HelpSecure(customLang('podcast_category_filter_clear', 'Clear')); ?></a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    <?php elseif ($selectedView === 'feed'): ?>
                        <div class="profile-feed-list full-width flex align_items flexBoxColumn gap" id="profile-feed-list">
                            <?php
                            if (!empty($feedHtml) && $hasAnyContent) {
                                echo $feedHtml;
                            } else {
                                $emptyMsg = customLang('empty_no_posts');
                                echo '<div class="empty-state flex align_items_justify_content gap flexBoxColumn">'
                                   . '  <div class="empty-state__icon flex align_items">' . render_icon('not_founded', true) . '</div>'
                                   . '  <div class="empty-state__title flex align_items">' . iN_HelpSecure($emptyMsg) . '</div>'
                                   . '</div>';
                            }
                            ?>
                            <div id="profile-sentinel" aria-hidden="true"></div>
                        </div>
                    <?php elseif ($selectedFilter === 'all'): ?>
                        <?php
                        if (!empty($gridHtml) && $hasAnyContent) {
                            echo $gridHtml;
                        } else {
                            $emptyMsg = customLang('empty_no_posts');
                            echo '<div class="explore-grid full-width">'
                               . '  <div class="empty-state flex align_items_justify_content gap flexBoxColumn">'
                               . '    <div class="empty-state__icon flex align_items">' . render_icon('not_founded', true) . '</div>'
                               . '    <div class="empty-state__title flex align_items">' . iN_HelpSecure($emptyMsg) . '</div>'
                               . '  </div>'
                               . '</div>';
                        }
                        ?>
                        <div id="profile-sentinel" aria-hidden="true"></div>
                    <?php else: ?>
                        <div class="reels_container" id="profile-list">
                            <?php
                            if (!empty($gridHtml) && $hasAnyContent) {
                                echo $gridHtml;
                            } else {
                                $emptyMsgMap = [
                                    'reels'      => customLang('empty_no_reels'),
                                    'images'     => customLang('empty_no_images'),
                                    'premium'    => customLang('empty_no_premium_posts'),
                                    'subscriber' => customLang('empty_no_subscriber_posts'),
                                ];
                                $emptyMsg = $emptyMsgMap[$selectedFilter] ?? customLang('empty_no_data');
                                echo '<div class="empty-state flex align_items_justify_content gap flexBoxColumn">'
                                   . '  <div class="empty-state__icon flex align_items">' . render_icon('not_founded', true) . '</div>'
                                   . '  <div class="empty-state__title flex align_items">' . iN_HelpSecure($emptyMsg) . '</div>'
                                   . '</div>';
                            }
                            ?>
                            <div id="profile-sentinel" aria-hidden="true"></div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                </div>
            </div>
        </div>
        <!---->
    </div>
 </div>
 <?php $themePathExplore = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme);?>
  <script defer src="<?php echo $themePathExplore; ?>/js/getPost.js"></script>
  <script defer src="<?php echo $themePathExplore; ?>/js/followUnfollow.js"></script>
  <script defer src="<?php echo $themePathExplore; ?>/js/profileGrid.js"></script>
  <?php if ($selectedFilter === 'podcasts'): ?>
  <script defer src="<?php echo $themePathExplore; ?>/js/profilePodcasts.js"></script>
  <?php endif; ?>
