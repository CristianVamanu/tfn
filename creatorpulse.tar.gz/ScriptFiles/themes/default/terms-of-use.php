<?php
declare(strict_types=1);

if (!isset($base_url) || !isset($siteName)) {
    $inc = dirname(__DIR__, 2) . '/includes/inc.php';
    if (is_file($inc)) { include $inc; }
}

$baseUrl = isset($base_url) ? rtrim((string) $base_url, '/') : '';
$siteTitle = isset($siteName) ? (string) $siteName : 'ReelsProject';

$preferredLang = isset($currentLang) ? strtolower((string) $currentLang) : 'eng';
if ($preferredLang === '') { $preferredLang = 'eng'; }
$isRTLLocale = isset($isRTLLocale) ? (bool) $isRTLLocale : false;
$currentLocale = $preferredLang;
$fallbackLangs = [];
if ($preferredLang !== 'eng') { $fallbackLangs[] = 'eng'; }
if ($preferredLang !== 'tr') { $fallbackLangs[] = 'tr'; }
$termsPage = null;
if (isset($RL) && method_exists($RL, 'RL_GetPageBySlug')) {
    $termsPage = $RL->RL_GetPageBySlug('terms-of-use', $preferredLang, $fallbackLangs);
}

$pageCsrfToken = htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8');
$themePreference = null;
if (isset($_COOKIE['theme_preference'])) {
    $themePreference = strtolower((string) $_COOKIE['theme_preference']);
} elseif (isset($_COOKIE['landing_theme_mode'])) {
    $themePreference = strtolower((string) $_COOKIE['landing_theme_mode']);
}
if ($themePreference !== 'dark' && $themePreference !== 'light') {
    $themePreference = 'auto';
}
$initialThemeClass = $themePreference === 'dark'
    ? 'theme-dark'
    : ($themePreference === 'light' ? 'theme-light' : '');
$initialToggleMode = $themePreference === 'dark' ? 'dark' : 'light';
$initialToggleIcon = $initialToggleMode === 'dark' ? '☀️' : '🌙';
$initialToggleAria = $initialToggleMode === 'dark'
    ? customLang('theme_toggle_light', 'Switch to light mode')
    : customLang('theme_toggle_dark', 'Switch to dark mode');
?>
<!doctype html>
<html
  lang="<?php echo htmlspecialchars($currentLocale, ENT_QUOTES, 'UTF-8'); ?>"
  dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
  data-theme="<?php echo htmlspecialchars($themePreference, ENT_QUOTES, 'UTF-8'); ?>"
  class="<?php echo $initialThemeClass; ?>"
>
  <head>
    <meta charset="UTF-8" />
    <?php $termsTitle = $termsPage && ($termsPage['title'] ?? '') !== ''
        ? (string) $termsPage['title']
        : (customLang('terms_title') ?: 'Terms of Use'); ?>
    <title><?php echo iN_HelpSecure($termsTitle . ' – ' . $siteTitle); ?></title>
    <?php include __DIR__ . '/head/meta.php'; ?>
    <?php include __DIR__ . '/head/css.php'; ?>
    <?php include __DIR__ . '/head/js.php'; ?>
  </head>
  <body
    class="<?php echo trim(($isRTLLocale ? 'rtl-locale ' : '') . $initialThemeClass); ?>"
    dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
    data-dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
    data-logged-in="<?php echo (isset($loggedIn) && $loggedIn === '1') ? '1' : '0'; ?>"
    data-theme="<?php echo htmlspecialchars($themePreference, ENT_QUOTES, 'UTF-8'); ?>"
  >
    <input type="hidden" name="csrf_token" value="<?php echo $pageCsrfToken; ?>" />
    <header class="main-header" data-aos="fade-down">
      <div class="main-header-inner">
        <div class="container-nav">
          <?php
            $hasMobileLogo = (!empty($siteMobileDarkLogo) || !empty($siteMobileWhiteLogo));
            $landingHomeRaw = $baseUrl !== '' ? ($baseUrl . '/') : '';
            $loginHrefRaw = $baseUrl !== '' ? ($baseUrl . '/login') : 'login.php';
            $primaryNavLabel = customLang('nav_primary_label');
            if (!$primaryNavLabel) {
                $primaryNavLabel = 'Primary navigation';
            }
            $menuToggleLabel = customLang('nav_menu');
            if (!$menuToggleLabel) {
                $menuToggleLabel = 'Menu';
            }
            $menuToggleAria = customLang('nav_toggle_menu');
            if (!$menuToggleAria) {
                $menuToggleAria = customLang('nav_toggle_navigation') ?: 'Toggle navigation';
            }
          ?>
          <a class="site-logo<?php echo $hasMobileLogo ? ' has-mobile-logo' : ''; ?>"
             href="<?php echo $landingHomeRaw !== '' ? iN_HelpSecure($landingHomeRaw . '#wrapper') : '#'; ?>"
             aria-label="<?php echo iN_HelpSecure($siteTitle); ?>">
            <?php
              $alt = iN_HelpSecure($siteName ?? 'Logo');
              if (!empty($siteDarkLogo)) {
                  echo '<img class="logo-image logo--for-light logo--desktop" src="' . iN_HelpSecure($base_url . $siteDarkLogo) . '" alt="' . $alt . '" />';
              }
              if (!empty($siteWhiteLogo)) {
                  echo '<img class="logo-image logo--for-dark logo--desktop" src="' . iN_HelpSecure($base_url . $siteWhiteLogo) . '" alt="' . $alt . '" />';
              }
              if (!empty($siteMobileDarkLogo)) {
                  echo '<img class="logo-image logo--for-light logo--mobile" src="' . iN_HelpSecure($base_url . $siteMobileDarkLogo) . '" alt="' . $alt . '" />';
              }
              if (!empty($siteMobileWhiteLogo)) {
                  echo '<img class="logo-image logo--for-dark logo--mobile" src="' . iN_HelpSecure($base_url . $siteMobileWhiteLogo) . '" alt="' . $alt . '" />';
              }
              if (empty($siteDarkLogo) && empty($siteWhiteLogo) && empty($siteMobileDarkLogo) && empty($siteMobileWhiteLogo)) {
                  echo iN_HelpSecure($siteTitle);
              }
            ?>
          </a>
          <button
            type="button"
            class="nav-toggle"
            data-nav-toggle
            aria-expanded="false"
            aria-controls="primary-navigation"
            aria-label="<?php echo iN_HelpSecure($menuToggleAria); ?>"
          >
            <span class="nav-toggle__box" aria-hidden="true">
              <span class="nav-toggle__line nav-toggle__line--top"></span>
              <span class="nav-toggle__line nav-toggle__line--middle"></span>
              <span class="nav-toggle__line nav-toggle__line--bottom"></span>
            </span>
            <span class="nav-toggle__label"><?php echo iN_HelpSecure($menuToggleLabel); ?></span>
          </button>
          <div class="nav-cluster" data-nav-panel>
            <nav id="primary-navigation" class="primary-navigation" aria-label="<?php echo iN_HelpSecure($primaryNavLabel); ?>">
            <?php
              $navItems = [
                  'how-it-works' => customLang('nav_how_it_works'),
                  'features'     => customLang('nav_features'),
                  'samples'      => customLang('nav_explore'),
                  'pricing'      => customLang('nav_subscriptions'),
                  'no-hassle'    => customLang('nav_why_dizzyreel'),
                  'faqs'         => customLang('nav_faqs'),
              ];
              foreach ($navItems as $fragment => $label):
                  $labelText = $label ?: ucfirst(str_replace('-', ' ', $fragment));
                  $hrefRaw = $landingHomeRaw !== '' ? ($landingHomeRaw . '#' . $fragment) : '#';
            ?>
              <a class="menu-item" href="<?php echo $hrefRaw !== '#' ? iN_HelpSecure($hrefRaw) : '#'; ?>">
                <?php echo iN_HelpSecure($labelText); ?>
              </a>
              <?php endforeach; ?>
              <a href="<?php echo iN_HelpSecure($loginHrefRaw); ?>" class="btn-call">
                <?php echo customLang('nav_start_earning'); ?>
              </a>
            </nav>
            <div class="welcome_language_switcher_wrapper">
            <?php
              $languageSwitcherContext = [
                  'button_classes' => 'welcome_language_switcher flex align_items',
                  'label_class' => 'welcome_language_switcher__label',
                  'show_label_text' => false,
              ];
              include __DIR__ . '/partials/language_switcher.php';
              unset($languageSwitcherContext);
            ?>
            </div>
          </div>
        </div>
      </div>
    </header>

    <section class="hero wrapper terms-section">
      <div class="container">
        <?php if ($termsPage): ?>
          <h1 class="terms-title"><?php echo iN_HelpSecure($termsTitle); ?></h1>
          <div class="terms-content">
            <?php echo $termsPage['content_html'] ?? ''; ?>
          </div>
        <?php else: ?>
          <h1 class="terms-title"><?php echo customLang('terms_title') ?: 'Terms of Use'; ?></h1>
          <p class="terms-description">
            <?php echo customLang('terms_intro') ?: 'These Terms of Use govern your use of our platform. By accessing or using the service, you agree to these terms. Please read them carefully.'; ?>
          </p>

          <h2 class="terms-heading">1. <?php echo customLang('terms_acceptance_heading') ?: 'Acceptance of Terms'; ?></h2>
          <p>
            <?php echo customLang('terms_acceptance_body') ?: 'By creating an account or using the service, you confirm that you have read, understood, and agree to these Terms of Use. If you do not agree, please do not use the platform.'; ?>
          </p>

          <h2 class="terms-heading">2. <?php echo customLang('terms_use_heading') ?: 'Use of the Service'; ?></h2>
          <ul class="terms-list">
            <li><?php echo customLang('terms_use_age') ?: 'You must be at least 13 years old or of legal age in your jurisdiction.'; ?></li>
            <li><?php echo customLang('terms_use_lawful') ?: 'You agree not to use the service for unlawful or harmful purposes.'; ?></li>
            <li><?php echo customLang('terms_use_security') ?: 'You are responsible for keeping your account credentials secure.'; ?></li>
            <li><?php echo customLang('terms_use_compliance') ?: 'User content must comply with applicable laws and our content guidelines.'; ?></li>
          </ul>

          <h2 class="terms-heading">3. <?php echo customLang('terms_ip_heading') ?: 'Intellectual Property'; ?></h2>
          <p>
            <?php echo customLang('terms_ip_body') ?: 'All content, trademarks, and code on this platform are the property of their respective owners. You may not reproduce, redistribute, or exploit any part of the service without permission.'; ?>
          </p>

          <h2 class="terms-heading">4. <?php echo customLang('terms_payments_heading') ?: 'Payments and Subscriptions'; ?></h2>
          <p>
            <?php echo customLang('terms_payments_body') ?: 'We may offer free and premium options. Payments are processed securely. By purchasing, you agree to the pricing, renewal, and refund policies described on the site.'; ?>
          </p>

          <h2 class="terms-heading">5. <?php echo customLang('terms_termination_heading') ?: 'Termination'; ?></h2>
          <p>
            <?php echo customLang('terms_termination_body') ?: 'We may suspend or terminate accounts that violate these terms or misuse the service. Content may be removed upon termination.'; ?>
          </p>

          <h2 class="terms-heading">6. <?php echo customLang('terms_liability_heading') ?: 'Limitation of Liability'; ?></h2>
          <p>
            <?php echo customLang('terms_liability_body') ?: 'The service is provided “as is,” without warranties of any kind. We are not liable for losses resulting from third-party services, misuse, or force majeure.'; ?>
          </p>

          <h2 class="terms-heading">7. <?php echo customLang('terms_modifications_heading') ?: 'Modifications'; ?></h2>
          <p>
            <?php echo customLang('terms_modifications_body') ?: 'We may update these terms at any time. Continued use indicates acceptance of the changes. Please review this page periodically.'; ?>
          </p>

          <h2 class="terms-heading">8. <?php echo customLang('terms_law_heading') ?: 'Governing Law'; ?></h2>
          <p>
            <?php echo customLang('terms_law_body') ?: 'These terms are governed by applicable laws in your jurisdiction, without regard to conflict of law principles.'; ?>
          </p>

          <h2 class="terms-heading">9. <?php echo customLang('terms_contact_heading') ?: 'Contact'; ?></h2>
          <p>
            <?php echo customLang('terms_contact_body') ?: 'If you have questions about these Terms of Use, please contact us.'; ?>
          </p>
        <?php endif; ?>
      </div>
    </section>

    <section class="footer footer-out" id="get-started">
      <div class="footer-small-print">
        <div class="copyright">
          <p class="white-text">© <?php echo date('Y'); ?> <?php echo iN_HelpSecure($siteTitle); ?></p>
        </div>
        <?php include __DIR__ . '/partials/footer_links.php'; ?>
      </div>
    </section>

    <button
      type="button"
      class="theme-toggle"
      data-theme-toggle=""
      data-storage-key="landing_theme_mode"
      data-label-light="<?php echo customLang('theme_toggle_light', 'Switch to light mode'); ?>"
      data-label-dark="<?php echo customLang('theme_toggle_dark', 'Switch to dark mode'); ?>"
      data-icon-light="☀️"
      data-icon-dark="🌙"
      aria-label="<?php echo iN_HelpSecure($initialToggleAria); ?>"
      data-mode="<?php echo $initialToggleMode; ?>"
    ><?php echo $initialToggleIcon; ?></button>
    <?php $welcomeJsVersion = (int) @filemtime(__DIR__ . '/js/welcome.js'); ?>
    <script defer src="<?php echo iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme); ?>/js/welcome.js?v=<?php echo $welcomeJsVersion; ?>"></script>
    <?php include __DIR__ . '/head/footer_js.php'; ?>
  </body>
</html>
