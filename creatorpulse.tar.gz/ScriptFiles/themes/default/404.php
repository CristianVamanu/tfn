<?php $pageCsrfToken = htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>
<!doctype html>
<html lang="en" data-theme="auto">
  <head>
    <title><?php echo iN_HelpSecure($siteTitle);?></title>
    <?php include "head/meta.php";?>
    <?php include "head/css.php";?>
    <?php include "head/js.php";?>
  </head>
  <body data-logged-in="<?php echo (isset($loggedIn) && $loggedIn === '1') ? '1' : '0'; ?>">
    <input type="hidden" name="csrf_token" value="<?php echo $pageCsrfToken; ?>" />
    <section class="hero login-page wrapper">
      <div class="login-container">
        <a
          class="site-logo"
          href="index.html"
          data-aos="fade-down"
          data-aos-easing="linear"
          data-aos-duration="650"
        >
          <?php echo iN_HelpSecure($siteName);?>
        </a>
        <div class="auth_language_switcher_wrapper">
          <?php
            $languageSwitcherContext = [
                'button_classes' => 'auth_language_switcher flex align_items',
                'label_class' => 'auth_language_switcher__label',
            ];
            include __DIR__ . '/partials/language_switcher.php';
            unset($languageSwitcherContext);
          ?>
        </div>

        <div
          class="page-404-box relative"
          data-aos="zoom-in-up"
          data-aos-easing="linear"
          data-aos-duration="700"
        >
          <div class="login-form-not-404">
            <h2 class="marker-animation" data-ma_color="#FF3C3C">
              404 – Not Found
            </h2>
            <p>
              Oops! The page you’re looking for doesn’t exist. Maybe it was
              moved or deleted. Don’t worry — you can always return to your AI
              sticker workspace.
            </p>
          </div>

          <div class="form-container mt-40">
            <div class="form-input-wrapper">
              <a href="<?php echo iN_HelpSecure($base_url);?>" class="back-to-home btn-hover"
                >Back to Home</a
              >
            </div>
          </div>

          <div class="form-not-register">
            <small>
              If you think this is a bug, please
              <a href="contact.html">contact us</a>.
            </small>
          </div>
        </div>
      </div>
    </section>
    <!---->
    <section class="footer footer-out" id="get-started">
      <!---->
      <div class="footer-small-print">
        <div class="copyright">
          <p class="white-text">© <?php echo iN_HelpSecure($siteName);?></p>
        </div>
        <?php include __DIR__ . '/partials/footer_links.php'; ?>
      </div>
      <!---->
    </section>
    <!---->
    <?php include "head/footer_js.php";?>
  </body>
</html>
