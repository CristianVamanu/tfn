<?php
declare(strict_types=1);

if (!isset($base_url) || !isset($siteName)) {
    $inc = dirname(__DIR__, 2) . '/includes/inc.php';
    if (is_file($inc)) { include $inc; }
}

$baseUrl = isset($base_url) ? rtrim((string) $base_url, '/') : '';
$siteTitle = isset($siteName) ? (string) $siteName : 'CreatorPulse';

$preferredLang = isset($currentLang) ? strtolower((string) $currentLang) : 'eng';
if ($preferredLang === '') { $preferredLang = 'eng'; }
$isRTLLocale = isset($isRTLLocale) ? (bool) $isRTLLocale : false;
$currentLocale = $preferredLang;
$fallbackLangs = [];
if ($preferredLang !== 'eng') { $fallbackLangs[] = 'eng'; }
if ($preferredLang !== 'tr') { $fallbackLangs[] = 'tr'; }
$privacyPage = null;
if (isset($RL) && method_exists($RL, 'RL_GetPageBySlug')) {
    $privacyPage = $RL->RL_GetPageBySlug('privacy-policy', $preferredLang, $fallbackLangs);
}

$pageCsrfToken = htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8');
$themePreference = null;
if (isset($_COOKIE['theme_preference'])) {
    $themePreference = strtolower((string) $_COOKIE['theme_preference']);
} elseif (isset($_COOKIE['landing_theme_mode'])) {
    $themePreference = strtolower((string) $_COOKIE['landing_theme_mode']);
}
if ($themePreference !== 'dark' && $themePreference !== 'light') {
    $themePreference = 'auto';
}
$initialThemeClass = $themePreference === 'dark'
    ? 'theme-dark'
    : ($themePreference === 'light' ? 'theme-light' : '');
$initialToggleMode = $themePreference === 'dark' ? 'dark' : 'light';
$initialToggleIcon = $initialToggleMode === 'dark' ? '☀️' : '🌙';
$initialToggleAria = $initialToggleMode === 'dark'
    ? customLang('theme_toggle_light', 'Switch to light mode')
    : customLang('theme_toggle_dark', 'Switch to dark mode');
?>
<!doctype html>
<html
  lang="<?php echo htmlspecialchars($currentLocale, ENT_QUOTES, 'UTF-8'); ?>"
  dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
  data-theme="<?php echo htmlspecialchars($themePreference, ENT_QUOTES, 'UTF-8'); ?>"
  class="<?php echo $initialThemeClass; ?>"
>
  <head>
    <meta charset="UTF-8" />
    <?php $privacyTitle = $privacyPage && ($privacyPage['title'] ?? '') !== ''
        ? (string) $privacyPage['title']
        : (customLang('privacy_title') ?: 'Privacy Policy'); ?>
    <title><?php echo iN_HelpSecure($privacyTitle . ' – ' . $siteTitle); ?></title>
    <?php include __DIR__ . '/head/meta.php'; ?>
    <?php include __DIR__ . '/head/css.php'; ?>
    <?php include __DIR__ . '/head/js.php'; ?>
  </head>
  <body
    class="<?php echo trim(($isRTLLocale ? 'rtl-locale ' : '') . $initialThemeClass); ?>"
    dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
    data-dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
    data-logged-in="<?php echo (isset($loggedIn) && $loggedIn === '1') ? '1' : '0'; ?>"
    data-theme="<?php echo htmlspecialchars($themePreference, ENT_QUOTES, 'UTF-8'); ?>"
  >
    <input type="hidden" name="csrf_token" value="<?php echo $pageCsrfToken; ?>" />
    <header class="main-header" data-aos="fade-down">
      <div class="main-header-inner">
        <div class="container-nav">
          <?php
            $hasMobileLogo = (!empty($siteMobileDarkLogo) || !empty($siteMobileWhiteLogo));
            $landingHomeRaw = $baseUrl !== '' ? ($baseUrl . '/') : '';
            $loginHrefRaw = $baseUrl !== '' ? ($baseUrl . '/login') : 'login.php';
            $primaryNavLabel = customLang('nav_primary_label');
            if (!$primaryNavLabel) {
                $primaryNavLabel = 'Primary navigation';
            }
            $menuToggleLabel = customLang('nav_menu');
            if (!$menuToggleLabel) {
                $menuToggleLabel = 'Menu';
            }
            $menuToggleAria = customLang('nav_toggle_menu');
            if (!$menuToggleAria) {
                $menuToggleAria = customLang('nav_toggle_navigation') ?: 'Toggle navigation';
            }
          ?>
          <a class="site-logo<?php echo $hasMobileLogo ? ' has-mobile-logo' : ''; ?>"
             href="<?php echo $landingHomeRaw !== '' ? iN_HelpSecure($landingHomeRaw . '#wrapper') : '#'; ?>"
             aria-label="<?php echo iN_HelpSecure($siteTitle); ?>">
            <?php
              $alt = iN_HelpSecure($siteName ?? 'Logo');
              if (!empty($siteDarkLogo)) {
                  echo '<img class="logo-image logo--for-light logo--desktop" src="' . iN_HelpSecure($base_url . $siteDarkLogo) . '" alt="' . $alt . '" />';
              }
              if (!empty($siteWhiteLogo)) {
                  echo '<img class="logo-image logo--for-dark logo--desktop" src="' . iN_HelpSecure($base_url . $siteWhiteLogo) . '" alt="' . $alt . '" />';
              }
              if (!empty($siteMobileDarkLogo)) {
                  echo '<img class="logo-image logo--for-light logo--mobile" src="' . iN_HelpSecure($base_url . $siteMobileDarkLogo) . '" alt="' . $alt . '" />';
              }
              if (!empty($siteMobileWhiteLogo)) {
                  echo '<img class="logo-image logo--for-dark logo--mobile" src="' . iN_HelpSecure($base_url . $siteMobileWhiteLogo) . '" alt="' . $alt . '" />';
              }
              if (empty($siteDarkLogo) && empty($siteWhiteLogo) && empty($siteMobileDarkLogo) && empty($siteMobileWhiteLogo)) {
                  echo iN_HelpSecure($siteTitle);
              }
            ?>
          </a>
          <button
            type="button"
            class="nav-toggle"
            data-nav-toggle
            aria-expanded="false"
            aria-controls="primary-navigation"
            aria-label="<?php echo iN_HelpSecure($menuToggleAria); ?>"
          >
            <span class="nav-toggle__box" aria-hidden="true">
              <span class="nav-toggle__line nav-toggle__line--top"></span>
              <span class="nav-toggle__line nav-toggle__line--middle"></span>
              <span class="nav-toggle__line nav-toggle__line--bottom"></span>
            </span>
            <span class="nav-toggle__label"><?php echo iN_HelpSecure($menuToggleLabel); ?></span>
          </button>
          <div class="nav-cluster" data-nav-panel>
            <nav id="primary-navigation" class="primary-navigation" aria-label="<?php echo iN_HelpSecure($primaryNavLabel); ?>">
            <?php
              $navItems = [
                  'how-it-works' => customLang('nav_how_it_works'),
                  'features'     => customLang('nav_features'),
                  'samples'      => customLang('nav_explore'),
                  'pricing'      => customLang('nav_subscriptions'),
                  'no-hassle'    => customLang('nav_why_dizzyreel'),
                  'faqs'         => customLang('nav_faqs'),
              ];
              foreach ($navItems as $fragment => $label):
                  $labelText = $label ?: ucfirst(str_replace('-', ' ', $fragment));
                  $hrefRaw = $landingHomeRaw !== '' ? ($landingHomeRaw . '#' . $fragment) : '#';
            ?>
              <a class="menu-item" href="<?php echo $hrefRaw !== '#' ? iN_HelpSecure($hrefRaw) : '#'; ?>">
                <?php echo iN_HelpSecure($labelText); ?>
              </a>
            <?php endforeach; ?>
              <a href="<?php echo iN_HelpSecure($loginHrefRaw); ?>" class="btn-call">
                <?php echo customLang('nav_start_earning'); ?>
              </a>
            </nav>
            <div class="welcome_language_switcher_wrapper">
            <?php
              $languageSwitcherContext = [
                  'button_classes' => 'welcome_language_switcher flex align_items',
                  'label_class' => 'welcome_language_switcher__label',
                  'show_label_text' => false,
              ];
              include __DIR__ . '/partials/language_switcher.php';
              unset($languageSwitcherContext);
            ?>
            </div>
          </div>
        </div>
      </div>
    </header>

    <section class="hero wrapper privacy-section">
      <div class="container">
        <?php if ($privacyPage): ?>
          <h1 class="policy-title"><?php echo iN_HelpSecure($privacyTitle); ?></h1>
          <div class="policy-content">
            <?php echo $privacyPage['content_html'] ?? ''; ?>
          </div>
        <?php else: ?>
          <h1 class="policy-title"><?php echo customLang('privacy_title') ?: 'Privacy Policy'; ?></h1>
          <p class="policy-description">
            <?php echo customLang('privacy_intro') ?: 'We are committed to protecting your personal information and your right to privacy. This policy describes how we collect, use, and protect your data.'; ?>
          </p>

          <h2 class="policy-heading">1. <?php echo customLang('privacy_collect_heading') ?: 'Information We Collect'; ?></h2>
          <p>
            <?php echo customLang('privacy_collect_body') ?: 'We may collect personal information that you voluntarily provide when registering, using our services, or contacting support. This can include your name, email address, username, and payment information.'; ?>
          </p>

          <h2 class="policy-heading">2. <?php echo customLang('privacy_use_heading') ?: 'How We Use Your Information'; ?></h2>
          <ul class="policy-list">
            <li><?php echo customLang('privacy_use_service') ?: 'To provide and maintain our services.'; ?></li>
            <li><?php echo customLang('privacy_use_auth') ?: 'To manage user accounts and authentication.'; ?></li>
            <li><?php echo customLang('privacy_use_improve') ?: 'To improve our platform based on user feedback.'; ?></li>
            <li><?php echo customLang('privacy_use_comms') ?: 'To send updates and transactional communications.'; ?></li>
          </ul>

          <h2 class="policy-heading">3. <?php echo customLang('privacy_cookies_heading') ?: 'Cookies and Tracking Technologies'; ?></h2>
          <p>
            <?php echo customLang('privacy_cookies_body') ?: 'We use cookies and similar tracking technologies to enhance your experience. You can control cookie preferences in your browser settings.'; ?>
          </p>

          <h2 class="policy-heading">4. <?php echo customLang('privacy_third_party_heading') ?: 'Data Sharing and Third Parties'; ?></h2>
          <p>
            <?php echo customLang('privacy_third_party_body') ?: 'We do not sell or rent your personal data. We may share data with trusted third parties who help us operate the platform, such as payment processors or analytics providers.'; ?>
          </p>

          <h2 class="policy-heading">5. <?php echo customLang('privacy_security_heading') ?: 'Data Security'; ?></h2>
          <p>
            <?php echo customLang('privacy_security_body') ?: 'We implement appropriate technical and organizational measures to protect your personal data from unauthorized access, disclosure, or destruction.'; ?>
          </p>

          <h2 class="policy-heading">6. <?php echo customLang('privacy_rights_heading') ?: 'Your Rights'; ?></h2>
          <p>
            <?php echo customLang('privacy_rights_body') ?: 'You have the right to access, update, or delete your personal data. You can also object to processing in certain circumstances. To exercise these rights, please contact us.'; ?>
          </p>

          <h2 class="policy-heading">7. <?php echo customLang('privacy_changes_heading') ?: 'Changes to This Policy'; ?></h2>
          <p>
            <?php echo customLang('privacy_changes_body') ?: 'We may update this Privacy Policy from time to time. Any changes will be posted on this page with a revised date.'; ?>
          </p>

          <h2 class="policy-heading">8. <?php echo customLang('privacy_contact_heading') ?: 'Contact Us'; ?></h2>
          <p>
            <?php echo customLang('privacy_contact_body') ?: 'If you have questions or concerns about this Privacy Policy, please reach out to us.'; ?><br /><br />
            <strong><?php echo iN_HelpSecure($siteTitle); ?></strong><br />
            <a href="mailto:support@example.com">support@example.com</a>
          </p>
        <?php endif; ?>
      </div>
    </section>

    <section class="footer footer-out" id="get-started">
      <div class="footer-small-print">
        <div class="copyright">
          <p class="white-text">© <?php echo date('Y'); ?> <?php echo iN_HelpSecure($siteTitle); ?></p>
        </div>
        <?php include __DIR__ . '/partials/footer_links.php'; ?>
      </div>
    </section>

    <button
      type="button"
      class="theme-toggle"
      data-theme-toggle=""
      data-storage-key="landing_theme_mode"
      data-label-light="<?php echo customLang('theme_toggle_light', 'Switch to light mode'); ?>"
      data-label-dark="<?php echo customLang('theme_toggle_dark', 'Switch to dark mode'); ?>"
      data-icon-light="☀️"
      data-icon-dark="🌙"
      aria-label="<?php echo iN_HelpSecure($initialToggleAria); ?>"
      data-mode="<?php echo $initialToggleMode; ?>"
    ><?php echo $initialToggleIcon; ?></button>
    <?php $welcomeJsVersion = (int) @filemtime(__DIR__ . '/js/welcome.js'); ?>
    <script defer src="<?php echo iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme); ?>/js/welcome.js?v=<?php echo $welcomeJsVersion; ?>"></script>
    <?php include __DIR__ . '/head/footer_js.php'; ?>
  </body>
</html>
