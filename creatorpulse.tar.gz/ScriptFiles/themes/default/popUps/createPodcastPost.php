<?php
declare(strict_types=1);

$creatorStatusRaw = isset($creatorStatus) ? strtolower((string) $creatorStatus) : 'none';
$isCreatorUser = in_array($creatorStatusRaw, ['approved', 'open', 'active'], true);
$paymentsActive = !empty($hasActivePaymentProviders);

$baseForLinks = isset($base_url) ? (string) $base_url : '';
$creatorSettingsUrl = $baseForLinks !== ''
    ? rtrim($baseForLinks, '/') . '/settings?tab=creator_identity'
    : 'settings?tab=creator_identity';

$creatorGuardMessage = customLang('post_visibility_creator_required', 'Only approved creators can share subscriber or paywalled posts. Become a creator to unlock these options.');
if (!is_string($creatorGuardMessage) || $creatorGuardMessage === '') {
    $creatorGuardMessage = 'Only approved creators can share subscriber or paywalled posts. Become a creator to unlock these options.';
}
$creatorGuardAction = customLang('post_visibility_open_creator', 'Become a creator');
if (!is_string($creatorGuardAction) || $creatorGuardAction === '') {
    $creatorGuardAction = 'Become a creator';
}
$paymentsGuardMessage = customLang('post_visibility_payments_disabled', 'Payment methods are currently being improved. Please try again later.');
if (!is_string($paymentsGuardMessage) || $paymentsGuardMessage === '') {
    $paymentsGuardMessage = 'Payment methods are currently being improved. Please try again later.';
}
$paymentsGuardAction = customLang('ui_ok', 'OK');
if (!is_string($paymentsGuardAction) || $paymentsGuardAction === '') {
    $paymentsGuardAction = 'OK';
}
$guardCancelLabel = customLang('menu_cancel', 'Cancel');
if (!is_string($guardCancelLabel) || $guardCancelLabel === '') {
    $guardCancelLabel = 'Cancel';
}

$podcastsEnabled = isset($enablePodcastPosts) ? (bool) $enablePodcastPosts : true;
$maxAudioDuration = isset($maximumAudioDuration) ? (int) $maximumAudioDuration : (isset($maximumVideoDuration) ? (int) $maximumVideoDuration : 7200);
if ($maxAudioDuration <= 0) {
    $maxAudioDuration = 7200;
}
$podcastCategories = [];
if (isset($RL) && method_exists($RL, 'RL_GetPodcastCategories')) {
    $podcastCategories = $RL->RL_GetPodcastCategories('active');
}

if (!$podcastsEnabled) {
    echo '<div class="popUp-container flex align_items_justify_content"><div class="popup-wrapper create_post flex align_items_justify_content flexBoxColumn"><div class="notice small">' . iN_HelpSecure(customLang('content_disabled_podcasts', 'Podcast sharing is currently disabled.')) . '</div></div></div>';
    return;
}
?>
<!----->
<div
    class="popUp-container flex align_items_justify_content"
    data-is-creator="<?php echo $isCreatorUser ? '1' : '0'; ?>"
    data-payments-active="<?php echo $paymentsActive ? '1' : '0'; ?>"
    data-creator-url="<?php echo iN_HelpSecure($creatorSettingsUrl); ?>"
    data-creator-message="<?php echo iN_HelpSecure($creatorGuardMessage); ?>"
    data-creator-action="<?php echo iN_HelpSecure($creatorGuardAction); ?>"
    data-payments-message="<?php echo iN_HelpSecure($paymentsGuardMessage); ?>"
    data-payments-action="<?php echo iN_HelpSecure($paymentsGuardAction); ?>"
    data-guard-cancel="<?php echo iN_HelpSecure($guardCancelLabel); ?>"
    data-max-duration="<?php echo (int) $maxAudioDuration; ?>"
>
    <div class="popup-wrapper flex flexBoxColumn align_items">
        <div class="click_box_header flex align_items_justify_content">
            <button id="podcastGoBack" class="goBack flex align_items none">
                <?php echo customLang('nav_back'); ?>
            </button>
            <div class="full-width flex align_items_justify_content"><?php echo customLang('createpost_create'); ?></div>
            <button id="podcastGoNext" class="goNext flex align_items none">
                <?php echo customLang('nav_next'); ?>
            </button>

            <span id="podcastUploadBtn" class="finishPost flex align_items none">
                <?php echo customLang('nav_share'); ?>
            </span>
            <button type="button" class="close_pop flex align_items"><?php echo customLang('close'); ?></button>
        </div>
        <div class="arrow"></div>

        <div class="create_media_box flex flexBoxColumn align_items_justify_content">
            <div class="flex align_items_justify_content icon_upload"><?php echo render_icon('podcast', true); ?></div>
            <div class="upload-text"><?php echo customLang('upload_podcast', 'Upload podcast'); ?></div>
            <label class="upload-btn flex align_items" for="podcastFileInput"><?php echo customLang('select_audio_from_device', 'Select audio from your device'); ?></label>
            <input type="file" id="podcastFileInput" class="none" accept="audio/mpeg,audio/mp4,audio/x-m4a" />
            <div class="ve-upload-progress-stack none" aria-live="polite">
                <div class="ve-upload-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
                    <span class="ve-upload-progress-fill" style="width:0%;"></span>
                </div>
                <div class="ve-upload-progress-percent">0%</div>
            </div>
            <div class="advanced_settings_description full-width flex align_items">
                <?php echo customLang('podcast_cover_optional', 'MP3 or M4A. Optional cover image can be added on the next step.'); ?>
            </div>
        </div>

        <div class="finish_podcast_container flex align_items flexBoxColumn none">
            <div class="podcast-preview full-width flex align_items flexBoxColumn">
                <div class="podcast-player-card">
                    <div class="podcast-visual">
                        <div class="podcast-bars left">
                            <span></span><span></span><span></span><span></span><span></span>
                        </div>
                        <div class="podcast-bars right">
                            <span></span><span></span><span></span><span></span><span></span>
                        </div>
                    </div>
                    <div class="podcast-progress" role="group" aria-label="<?php echo iN_HelpSecure(customLang('upload_podcast', 'Podcast')); ?>">
                        <div class="podcast-progress-track">
                            <div class="podcast-progress-fill"></div>
                            <div class="podcast-progress-thumb" aria-hidden="true"></div>
                        </div>
                        <div class="podcast-time">0:00</div>
                    </div>
                    <div class="podcast-controls">
                        <button type="button" class="podcast-btn rewind" aria-label="<?php echo iN_HelpSecure(customLang('ui_rewind_10', 'Rewind 10 seconds')); ?>">&#9198;</button>
                        <button type="button" class="podcast-btn play" aria-label="<?php echo iN_HelpSecure(customLang('ui_play_pause', 'Play / Pause')); ?>">
                            <span class="icon-play">&#9658;</span>
                            <span class="icon-pause">❚❚</span>
                        </button>
                        <button type="button" class="podcast-btn forward" aria-label="<?php echo iN_HelpSecure(customLang('ui_forward_10', 'Forward 10 seconds')); ?>">&#9197;</button>
                    </div>
                    <div class="podcast-meta full-width flex align_items space_between">
                        <div class="podcast-file-name"></div>
                        <div class="podcast-duration"></div>
                    </div>
                    <audio id="podcastAudioPreview" class="full-width podcast-audio-element" preload="metadata">
                        <source src="" type="audio/mpeg">
                    </audio>
                </div>
            </div>

            <div class="podcast-cover full-width flex align_items flexBoxColumn">
                <label class="upload-btn flex align_items" for="podcastCoverInput"><?php echo customLang('podcast_cover_upload', 'Upload podcast cover'); ?></label>
                <input type="file" id="podcastCoverInput" class="none" accept="image/jpeg,image/png,image/webp" />
                <div class="podcast-cover-name"></div>
            </div>

            <div class="post-title flex align_items">
                <input type="text" name="post_title" class="create_title full-width" maxlength="255" placeholder="<?php echo customLang('post_title_placeholder', 'Add a title (optional)'); ?>">
            </div>
            <div class="post-text flex align_items">
                <textarea name="post_text" class="create_text full-width" placeholder="<?php echo customLang('post_placeholder');?>"></textarea>
            </div>
            <div class="full-width gap flex align_items flexBoxColumn podcast-category-box">
                <div class="full-width flex align_items setting-row">
                    <div class="advanced_settings_title flex align_items">
                        <?php echo customLang('podcast_category_optional', 'Podcast category (optional)'); ?>
                    </div>
                    <div class="advanced_settings_input full-width flex">
                        <?php if (!empty($podcastCategories)) : ?>
                            <select id="podcastCategorySelect" name="podcast_category_id" class="podcast-category-select full-width">
                                <option value=""><?php echo customLang('podcast_category_placeholder', 'Select a category'); ?></option>
                                <?php foreach ($podcastCategories as $cat): ?>
                                    <?php if (strtolower((string)($cat['status'] ?? '')) !== 'active') { continue; } ?>
                                    <option value="<?php echo (int) ($cat['id'] ?? 0); ?>">
                                        <?php echo iN_HelpSecure((string) ($cat['name'] ?? '')); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        <?php else: ?>
                            <div class="podcast-category-empty advanced_settings_description full-width flex align_items">
                                <?php echo customLang('podcast_category_empty_hint', 'Add podcast categories in the admin panel to make this list available.'); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="advanced_settings_box full-width relative flex align_items flexBoxColumn">
                <div class="full-width post-settings-title"><?php echo customLang('post_advanced_settings');?></div>

                <div class="full-width gap flex align_items flexBoxColumn">
                    <div class="full-width flex align_items">
                        <div class="advanced_settings_title flex align_items">
                            <?php echo customLang('post_visibility_title');?>
                        </div>
                    </div>
                    <div class="relative column-gap full-width flex align_items visibility-options">
                        <div class="post-visiblity flex align_items column-gap active" data-type="everyone">
                            <div class="svg_ flex align_items"><?php echo render_icon('world', true); ?></div>
                            <?php echo customLang('visibility_everyone');?>
                        </div>
                        <div class="post-visiblity flex align_items column-gap" data-type="followers">
                            <div class="svg_ flex align_items"><?php echo render_icon('follower', true); ?></div>
                            <?php echo customLang('visibility_followers');?>
                        </div>
                        <div class="post-visiblity flex align_items column-gap" data-type="subscribers">
                            <div class="svg_ flex align_items"><?php echo render_icon('subscriber', true); ?></div>
                            <?php echo customLang('visibility_subscribers');?>
                        </div>
                        <div class="post-visiblity flex align_items column-gap" data-type="locked">
                            <div class="svg_ flex align_items"><?php echo render_icon('locked', true); ?></div>
                            <?php echo customLang('visibility_paid');?> <span class="post-price flex align_items">($)</span>
                        </div>
                    </div>
                </div>

                <div class="full-width gap flex align_items flexBoxColumn podcast-price-row none">
                    <div class="full-width flex align_items setting-row">
                        <div class="advanced_settings_title flex align_items">
                            <?php echo customLang('set_post_price'); ?>
                        </div>
                        <div class="advanced_settings_input full-width flex align_items">
                            <input type="number" name="set-price" class="set-price" placeholder="<?php echo customLang('write_price');?>">
                        </div>
                    </div>
                    <div class="advanced_settings_description full-width flex align_items warn podcast-price-error none"><?php echo customLang('price_range_error');?></div>
                </div>

                <div class="full-width gap flex align_items flexBoxColumn">
                    <div class="full-width flex align_items setting-row">
                        <div class="advanced_settings_title flex align_items">
                            <?php echo customLang('post_hide_likes_views');?>
                        </div>
                        <div class="advanced_sttings_switch flex align_items">
                            <label class="el-switch el-switch-sm">
                                <input type="checkbox" id="podcast_hide_likes_view" name="hide_likes_view" value="on">
                                <span class="el-switch-style"></span>
                            </label>
                        </div>
                    </div>
                    <div class="advanced_settings_description full-width flex align_items"><?php echo customLang('post_hide_likes_views_desc');?></div>
                </div>

                <div class="full-width gap flex align_items flexBoxColumn">
                    <div class="full-width flex align_items setting-row">
                        <div class="advanced_settings_title flex align_items">
                            <?php echo customLang('post_turn_off_commenting');?>
                        </div>
                        <div class="advanced_sttings_switch flex align_items">
                            <label class="el-switch el-switch-sm">
                                <input type="checkbox" id="podcast_turn_on_off_comment" name="turn_on_off_comment" value="on">
                                <span class="el-switch-style"></span>
                            </label>
                        </div>
                    </div>
                    <div class="advanced_settings_description full-width flex align_items"><?php echo customLang('post_turn_off_commenting_desc');?></div>
                </div>

                <input type="hidden" name="post_type" value="everyone">
                <input type="hidden" name="min-price" value="<?php echo iN_HelpSecure($premiumPostPriceMinimum );?>">
                <input type="hidden" name="max-price" value="<?php echo iN_HelpSecure($premiumPostPriceMaximum );?>">
            </div>
        </div>
    </div>
</div>
<script defer src="<?php echo iN_HelpSecure($base_url);?>themes/<?php echo iN_HelpSecure($currentTheme);?>/js/podcastEdit.js?v=<?php echo iN_HelpSecure($version);?>"></script>
