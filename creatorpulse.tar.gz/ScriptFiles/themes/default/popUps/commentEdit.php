<?php
    if (!isset($commentIdLocal) || $commentIdLocal <= 0) {
        return;
    }

    $commentEditDomId   = 'commentEditPopup-' . $commentIdLocal;
    $commentEditText    = $commentPlainText ?? '';
    $commentEditTextEsc = iN_HelpSecure($commentEditText);
    $commentEditPlaceholder = customLang('comment_update_placeholder', 'Update your comment...');
?>
<div
    id="<?php echo iN_HelpSecure($commentEditDomId); ?>"
    class="comment-edit-popup none"
    data-comment-id="<?php echo $commentIdLocal; ?>"
    data-post-id="<?php echo $postIdLocal; ?>"
    role="dialog"
    aria-modal="true"
    aria-hidden="true"
>
    <div class="ce-sheet-container">
        <div class="ce-sheet">
            <div class="ce-header">
                <div class="ce-title"><?php echo customLang('comment_edit_title', 'Edit comment'); ?></div>
                <div class="ce-sub"><?php echo customLang('comment_edit_subtitle', 'Make your changes below.'); ?></div>
            </div>
            <div class="ce-body">
                <textarea
                    class="ce-text"
                    rows="4"
                    maxlength="5000"
                    placeholder="<?php echo iN_HelpSecure($commentEditPlaceholder); ?>"
                ><?php echo $commentEditTextEsc; ?></textarea>
                <div class="ce-actions">
                    <button type="button" class="ce-save"><?php echo customLang('menu_save'); ?></button>
                    <button type="button" class="ce-cancel"><?php echo customLang('menu_cancel'); ?></button>
                </div>
            </div>
        </div>
    </div>
</div>
