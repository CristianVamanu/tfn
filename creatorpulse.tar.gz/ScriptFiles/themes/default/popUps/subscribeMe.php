<?php
// Guard: Ensure expected variables exist
$recipient      = isset($userDetails) && is_array($userDetails) ? $userDetails : [];
$recipientId    = isset($postOwnerID) ? (int)$postOwnerID : (int)($postData['post_owner_id'] ?? 0);
$recipientName  = trim((string)($recipient['user_fullname'] ?? $recipient['username'] ?? ''));
$recipientUser  = (string)($recipient['username'] ?? '');
$recipientAvatarRel = isset($RL) ? (string)$RL->RL_userAvatar($recipientId) : '';
if (function_exists('storage_resolve_media_url')) {
    $recipientAvatar = storage_resolve_media_url($recipientAvatarRel, $base_url ?? '');
} else {
    $recipientAvatar = (string)($base_url ?? '') . ltrim($recipientAvatarRel, '/');
}

$buyer          = isset($userData) && is_array($userData) ? $userData : [];
$buyerName      = trim((string)($buyer['user_fullname'] ?? $buyer['username'] ?? ''));
$buyerUser      = (string)($buyer['username'] ?? '');
$buyerEmail     = (string)($buyer['contact_email'] ?? $buyer['user_email'] ?? '');

global $siteData;
$paymentTaxPercentVal = isset($siteData['payment_tax_percent']) ? (float)$siteData['payment_tax_percent'] : (isset($paymentTaxPercent) ? (float)$paymentTaxPercent : 0.0);
$paymentFeeFixedVal   = isset($siteData['payment_fee_fixed']) ? (float)$siteData['payment_fee_fixed'] : (isset($paymentFeeFixed) ? (float)$paymentFeeFixed : 0.0);
$paymentFeePercentVal = isset($siteData['payment_fee_percent']) ? (float)$siteData['payment_fee_percent'] : (isset($paymentFeePercent) ? (float)$paymentFeePercent : 0.0);
$subscriptionFeePercentVal = isset($siteData['subscription_fee']) ? (float)$siteData['subscription_fee'] : (isset($subscriptionfee) ? (float)$subscriptionfee : 0.0);


// Provider currencies come from inc.php: $globalCurCode, $stripeCurCode, $paypalCurCode

// Determine default by first enabled subscription-capable provider
$baseCurrency = isset($globalCurCode) && $globalCurCode !== '' ? (string) $globalCurCode : 'USD';

$stripeCurrencyUi  = isset($stripeCurCode) && $stripeCurCode !== '' ? (string) $stripeCurCode : $baseCurrency;
$paypalCurrencyUi  = isset($paypalCurCode) && $paypalCurCode !== '' ? (string) $paypalCurCode : $baseCurrency;
$paystackCurrencyUi = isset($paystackCurCode) && $paystackCurCode !== '' ? (string) $paystackCurCode : $baseCurrency;
$iyzicoCurrencyUi = isset($iyzicoCurCode) && $iyzicoCurCode !== '' ? (string) $iyzicoCurCode : $baseCurrency;
$flutterwaveCurrencyUi = isset($flutterwaveCurCode) && $flutterwaveCurCode !== '' ? (string)$flutterwaveCurCode : $baseCurrency;
$walletCurrencyUi  = $baseCurrency;

$defaultProvider = null;
if (!empty($enableStripe))      { $defaultProvider = 'stripe'; }
elseif (!empty($enablePaypal))  { $defaultProvider = 'paypal'; }
elseif (!empty($enablePaystack)) { $defaultProvider = 'paystack'; }
elseif (!empty($enableIyziCo)) { $defaultProvider = 'iyzico'; }
elseif (!empty($enableFlutterwave)) { $defaultProvider = 'flutterwave'; }
else { $defaultProvider = 'wallet'; }

switch ($defaultProvider) {
  case 'stripe': $curCode = $stripeCurrencyUi; break;
  case 'paypal': $curCode = $paypalCurrencyUi; break;
  case 'paystack': $curCode = $paystackCurrencyUi; break;
  case 'iyzico': $curCode = $iyzicoCurrencyUi; break;
  case 'flutterwave': $curCode = $flutterwaveCurrencyUi; break;
  default:       $curCode = $walletCurrencyUi; break;
}

$currencyFormatSettings = isset($currencyFormatSettings)
    ? $currencyFormatSettings
    : ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
$curSymbolMap = (isset($currencies) && is_array($currencies)) ? $currencies : [];
$curSymbol = (string) ($curSymbolMap[$curCode] ?? $curCode);
$curPrecision = dz_currency_resolve_precision($curCode, $currencyFormatSettings['decimal_places'] ?? 2);
$formatMoney = static function (float $amount, ?string $code = null, ?string $symbol = null) use ($curCode, $curSymbol, $currencyFormatSettings): string {
    return dz_format_currency($amount, $code ?? $curCode, $symbol ?? $curSymbol, $currencyFormatSettings);
};

$walletBalanceRaw       = isset($userWallet) ? (float) $userWallet : 0.0;
$walletCurrencyCode     = isset($globalCurCode) && $globalCurCode !== '' ? (string) $globalCurCode : (string) $curCode;
$walletCurrencySymbol   = (string) ($curSymbolMap[$walletCurrencyCode] ?? '');
$walletPrecision        = dz_currency_resolve_precision($walletCurrencyCode, $currencyFormatSettings['decimal_places'] ?? 2);
$walletBalanceValue     = number_format($walletBalanceRaw, $walletPrecision, '.', '');
$walletProviderTemplate = customLang('pay_provider_wallet');
$walletProviderLabel    = strtr(
    $walletProviderTemplate,
    ['{balance}' => $formatMoney($walletBalanceRaw, $walletCurrencyCode, $walletCurrencySymbol)]
);
$plans          = isset($RL) ? $RL->RL_GetUserSubscriptionPlans($recipientId) : [];
$planOptions    = [];
if ($plans) {
  if (!empty($plans['price_weekly']))   { $planOptions['weekly']   = (float)$plans['price_weekly']; }
  if (!empty($plans['price_monthly']))  { $planOptions['monthly']  = (float)$plans['price_monthly']; }
  if (!empty($plans['price_halfyear'])) { $planOptions['halfyear'] = (float)$plans['price_halfyear']; }
  if (!empty($plans['price_yearly']))   { $planOptions['yearly']   = (float)$plans['price_yearly']; }
}
// Subscription availability for the recipient (creator)
$subNew = strtolower((string)($recipient['subscription_status'] ?? ''));
$subOld = strtolower((string)($recipient['subscrition_status'] ?? ''));
$subscriptionOpen = ($subNew === 'open') || ($subOld === 'active');
// Default: if no plans defined, show a friendly note
?>

<div class="popUp-container flex align_items">
    <div class="tips popup-wrapper" id="tipsModal" role="dialog" aria-modal="true" aria-labelledby="tipsTitle">
      <button class="tips-close close_pop" type="button" aria-label="Close">
        <?php echo render_icon('close', true); ?>
      </button>

      <header class="tips-header">
        <h2 class="tips-title" id="tipsTitle"><?php echo customLang('pay_subscribe_title'); ?></h2>
      </header>

      <section class="tips-user">
        <div class="tips-avatar">
          <img src="<?php echo iN_HelpSecure($recipientAvatar); ?>" alt="<?php echo iN_HelpSecure($recipientUser); ?>">
        </div>
        <div class="tips-identity">
          <div class="tips-name"><?php echo iN_HelpSecure($recipientName); ?></div>
          <div class="tips-handle">@<?php echo iN_HelpSecure($recipientUser); ?></div>
        </div>
      </section>

      <?php
        $bf = [
          'first_name' => (string)($billignDataFirstName ?? ''),
          'last_name'  => (string)($billignDataLastName ?? ''),
          'country'    => (string)($billignDataCountry ?? ''),
          'city'       => (string)($billignDataCity ?? ''),
          'state'      => (string)($billignDataState ?? ''),
          'postcode'   => (string)($billignDataPostCode ?? ''),
          'address'    => (string)($billignDataAddress ?? ''),
        ];
        $hasSavedBilling = array_filter($bf, static fn($v) => trim((string) $v) !== '');
        $billingPayload = [
          'billing_first_name' => (string)($bf['first_name'] ?? ''),
          'billing_last_name'  => (string)($bf['last_name'] ?? ''),
          'billing_country'    => (string)($bf['country'] ?? ''),
          'billing_city'       => (string)($bf['city'] ?? ''),
          'billing_state'      => (string)($bf['state'] ?? ''),
          'billing_postcode'   => (string)($bf['postcode'] ?? ''),
          'billing_address'    => (string)($bf['address'] ?? ''),
        ];
        $billingJsonAttr = $hasSavedBilling
          ? htmlspecialchars(json_encode($billingPayload, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8')
          : '';
        $countries = [];
        $countriesFile = __DIR__ . '/../../../includes/helpers/countries.php';
        if (is_file($countriesFile)) {
          require $countriesFile;
        }
        if (!is_array($countries) || empty($countries)) {
          $countries = ['US' => 'United States', 'TR' => 'Turkey', 'GB' => 'United Kingdom'];
        }
        $billingCountryCode = strtoupper((string)($bf['country'] ?? ''));
        $billingCountryLabel = $billingCountryCode !== '' ? ($countries[$billingCountryCode] ?? $bf['country']) : '';

        $renderBillingFields = function(string $extraAttrs = '') use ($bf, $countries, $buyerName, $buyerUser, $buyerEmail) {
          ?>
          <div class="tips-accordion-body" data-billing-fields<?php echo $extraAttrs ? ' ' . $extraAttrs : ''; ?>>
            <div class="buyer-section">
              <div><strong><?php echo customLang('pay_buyer_label'); ?></strong> <?php echo iN_HelpSecure($buyerName); ?> (@<?php echo iN_HelpSecure($buyerUser); ?>)</div>
              <?php if (!empty($buyerEmail)) : ?>
                <div><strong><?php echo customLang('pay_email_label'); ?></strong> <?php echo iN_HelpSecure($buyerEmail); ?></div>
              <?php endif; ?>
            </div>

            <div class="billing-fields grid gap">
              <div class="tips-field">
                <label class="tips-label" for="bill_first_name"><?php echo customLang('pay_first_name_label'); ?></label>
                <input id="bill_first_name" name="billing_first_name" class="tips-input" type="text" value="<?php echo iN_HelpSecure($bf['first_name']); ?>" placeholder="<?php echo customLang('pay_first_name_placeholder'); ?>" autocomplete="given-name" />
              </div>
              <div class="tips-field">
                <label class="tips-label" for="bill_last_name"><?php echo customLang('pay_last_name_label'); ?></label>
                <input id="bill_last_name" name="billing_last_name" class="tips-input" type="text" value="<?php echo iN_HelpSecure($bf['last_name']); ?>" placeholder="<?php echo customLang('pay_last_name_placeholder'); ?>" autocomplete="family-name" />
              </div>

              <div class="tips-field">
                <label class="tips-label" for="bill_country"><?php echo customLang('pay_country_label'); ?></label>
                <select id="bill_country" name="billing_country" class="tips-input">
                  <option value=""><?php echo customLang('pay_country_placeholder'); ?></option>
                  <?php foreach ($countries as $code => $name): ?>
                    <option value="<?php echo iN_HelpSecure($code); ?>" <?php echo (strtoupper($bf['country']) === $code ? 'selected' : ''); ?>><?php echo iN_HelpSecure($name); ?></option>
                  <?php endforeach; ?>
                </select>
              </div>

              <div class="tips-field">
                <label class="tips-label" for="bill_city"><?php echo customLang('pay_city_label'); ?></label>
                <input id="bill_city" name="billing_city" class="tips-input" type="text" value="<?php echo iN_HelpSecure($bf['city']); ?>" placeholder="<?php echo customLang('pay_city_placeholder'); ?>" autocomplete="address-level2" />
              </div>

              <div class="tips-field">
                <label class="tips-label" for="bill_state"><?php echo customLang('pay_state_label'); ?></label>
                <input id="bill_state" name="billing_state" class="tips-input" type="text" value="<?php echo iN_HelpSecure($bf['state']); ?>" placeholder="<?php echo customLang('pay_state_placeholder'); ?>" autocomplete="address-level1" />
              </div>

              <div class="tips-field">
                <label class="tips-label" for="bill_postcode"><?php echo customLang('pay_postcode_label'); ?></label>
                <input id="bill_postcode" name="billing_postcode" class="tips-input" type="text" value="<?php echo iN_HelpSecure($bf['postcode']); ?>" placeholder="<?php echo customLang('pay_postcode_placeholder'); ?>" autocomplete="postal-code" />
              </div>

              <div class="tips-field full-span">
                <label class="tips-label" for="bill_address"><?php echo customLang('pay_address_label'); ?></label>
                <textarea id="bill_address" name="billing_address" class="tips-input" rows="3" placeholder="<?php echo customLang('pay_address_placeholder'); ?>" autocomplete="street-address"><?php echo iN_HelpSecure($bf['address']); ?></textarea>
              </div>
            </div>
          </div>
          <?php
        };
      ?>

      <form class="tips-form" action="#" method="post" novalidate data-form-type="subscription"
            data-fee-percent="<?php echo iN_HelpSecure(number_format($paymentFeePercentVal, 4, '.', '')); ?>"
            data-fee-fixed="<?php echo iN_HelpSecure(number_format($paymentFeeFixedVal, 2, '.', '')); ?>"
            data-tax-percent="<?php echo iN_HelpSecure(number_format($paymentTaxPercentVal, 4, '.', '')); ?>"
            data-currency="<?php echo iN_HelpSecure($curCode); ?>"
            data-currency-symbol="<?php echo iN_HelpSecure($curSymbol); ?>"
            data-amount-precision="<?php echo (int) $curPrecision; ?>"
            data-subscription-fee-percent="<?php echo iN_HelpSecure(number_format($subscriptionFeePercentVal, 4, '.', '')); ?>"<?php echo $billingJsonAttr !== '' ? ' data-billing-json="' . $billingJsonAttr . '"' : ''; ?>>
        <!-- Plan selection -->
        <div class="tips-field">
          <label class="tips-label"><?php echo customLang('pay_choose_plan_label'); ?></label>
          <?php $defaultPrice = $planOptions ? reset($planOptions) : false; ?>
          <?php if (!$planOptions) : ?>
            <div class="tips-input" aria-readonly="true"><?php echo customLang('pay_no_plans_info'); ?></div>
          <?php else : ?>
            <div class="provider_list full-width flex align_items column-gap" id="subsPlans">
              <?php $first = true; foreach ($planOptions as $key => $price): ?>
                <label class="provider-item flex align_items column-gap">
                  <input type="radio" name="plan_interval" value="<?php echo iN_HelpSecure($key); ?>" <?php echo $first ? 'checked' : ''; ?> data-price="<?php echo iN_HelpSecure(number_format($price, $curPrecision, '.', '')); ?>">
                  <span class="provider-name"><?php echo ucfirst($key); ?> – <?php echo iN_HelpSecure($formatMoney($price)); ?></span>
                </label>
              <?php $first = false; endforeach; ?>
            </div>
            <input type="hidden" id="tipAmount" name="amount" value="<?php echo $defaultPrice !== false ? iN_HelpSecure(number_format((float)$defaultPrice, $curPrecision, '.', '')) : '0.00'; ?>" data-min="<?php echo $defaultPrice !== false ? iN_HelpSecure(number_format((float)$defaultPrice, $curPrecision, '.', '')) : '0.00'; ?>" data-max="<?php echo $defaultPrice !== false ? iN_HelpSecure(number_format((float)$defaultPrice, $curPrecision, '.', '')) : '0.00'; ?>">
          <?php endif; ?>
        </div>
<?php
          $defaultPriceVal = ($defaultPrice !== false) ? (float)$defaultPrice : 0.0;
          $defaultPlatformFee = round($defaultPriceVal * ($subscriptionFeePercentVal / 100.0), $curPrecision);
          $defaultTax = round($paymentFeeFixedVal + ($defaultPriceVal * ($paymentTaxPercentVal / 100.0)), $curPrecision);
          $defaultTotal = round($defaultPriceVal + $defaultPlatformFee + $defaultTax, $curPrecision);
        ?>

        <!-- Billing agreement -->
        <?php if (!empty($hasSavedBilling)): ?>
        <?php $billingAccordionId = 'billing-accordion-' . uniqid(); ?>
        <section class="tips-accordion tips-accordion--summary" data-billing-summary>
          <header class="billing-summary-card">
            <div class="billing-summary-card__title"><?php echo customLang('pay_billing_details_title'); ?></div>
            <div class="billing-summary-card__lines">
              <?php if (!empty($bf['first_name']) || !empty($bf['last_name'])): ?>
                <div><?php echo iN_HelpSecure(trim($bf['first_name'] . ' ' . $bf['last_name'])); ?></div>
              <?php endif; ?>
              <?php if (!empty($bf['address'])): ?>
                <div><?php echo iN_HelpSecure($bf['address']); ?></div>
              <?php endif; ?>
              <?php if (!empty($bf['postcode']) || !empty($bf['city'])): ?>
                <div><?php echo iN_HelpSecure(trim($bf['postcode'] . ' ' . $bf['city'])); ?></div>
              <?php endif; ?>
              <?php if (!empty($billingCountryLabel)): ?>
                <div><?php echo iN_HelpSecure($billingCountryLabel); ?></div>
              <?php endif; ?>
            </div>
            <p class="billing-summary-card__hint"><?php echo customLang('pay_billing_saved_hint', 'We will reuse this billing profile unless you choose to edit it.'); ?></p>
          </header>
          <button type="button"
                  class="billing-edit-toggle"
                  data-billing-edit
                  data-billing-target="#<?php echo iN_HelpSecure($billingAccordionId); ?>">
            <?php echo customLang('pay_billing_edit_button', 'Edit billing details'); ?>
          </button>
        </section>
        <div class="tips-accordion tips-accordion--form is-collapsed"
             id="<?php echo iN_HelpSecure($billingAccordionId); ?>">
          <?php $renderBillingFields('hidden="hidden"'); ?>
        </div>
        <?php else: ?>
        <details class="tips-accordion" open>
          <summary>
            <?php echo customLang('pay_billing_details_title'); ?>
            <img class="icon-16" src="<?php echo iN_HelpSecure($iconPath . 'down_arrow.svg'); ?>" alt="" aria-hidden="true">
          </summary>
          <?php $renderBillingFields(); ?>
        </details>
        <?php endif; ?>

        <!-- Payment summary -->
        <div>
          <div class="tips-section-title"><?php echo customLang('pay_summary_title'); ?></div>
          <div class="tips-summary" data-summary-type="subscription">
            <dl>
              <div class="row"><dt><?php echo customLang('pay_summary_subtotal'); ?></dt><dd><span class="tips-subtotal-amount"><?php echo iN_HelpSecure($formatMoney($defaultPriceVal), false); ?></span></dd></div>
              <div class="row"><dt><?php echo customLang('pay_summary_fees'); ?></dt><dd><span class="tips-fee-amount"><?php echo iN_HelpSecure($formatMoney($defaultPlatformFee), false); ?></span></dd></div>
              <div class="row"><dt><?php echo customLang('pay_summary_taxes'); ?></dt><dd><span class="tips-taxes-amount"><?php echo iN_HelpSecure($formatMoney($defaultTax), false); ?></span></dd></div>
              <div class="row"><dt><?php echo customLang('pay_summary_monthly_total'); ?></dt><dd><span class="tips-total-amount"><?php echo iN_HelpSecure($formatMoney($defaultTotal), false); ?></span></dd></div>
            </dl>
          </div>
        </div>

        <!-- Payment methods -->
        <div class="tips-methods">
          <div class="tips-section-title"><?php echo customLang('pay_method_title'); ?></div>

          <div class="provider_list full-width flex align_items column-gap">
            <?php $first = true; ?>
            <?php if (!empty($enableStripe)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="stripe" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($stripeCurrencyUi); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_stripe'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enablePaypal)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="paypal" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($paypalCurrencyUi); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_paypal'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enablePaystack)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="paystack" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($paystackCurrencyUi); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_paystack'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enableIyziCo)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="iyzico" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($iyzicoCurrencyUi); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_iyzico'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enableFlutterwave)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="flutterwave" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($flutterwaveCurrencyUi); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_flutterwave'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <label class="provider-item flex align_items column-gap">
              <input type="radio" name="tip_provider" value="wallet" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($walletCurrencyUi); ?>">
              <span class="provider-name"
                    data-wallet-balance-text
                    data-wallet-balance="<?php echo iN_HelpSecure($walletBalanceValue, false); ?>"
                    data-wallet-balance-currency="<?php echo iN_HelpSecure($walletCurrencyCode, false); ?>"
                    data-wallet-balance-symbol="<?php echo iN_HelpSecure($walletCurrencySymbol, false); ?>"
                    data-wallet-balance-template="<?php echo iN_HelpSecure($walletProviderTemplate, false); ?>">
                <?php echo iN_HelpSecure($walletProviderLabel, false); ?>
              </span>
            </label>
          </div>
          <div class="advanced_settings_description">
            <?php echo customLang('pay_crypto_note'); ?>
          </div>
        </div>

        <p class="tips-note">
          <?php echo customLang('pay_note_redirect_info'); ?>
        </p>

        <?php if ($subscriptionOpen): ?>
          <div class="tips-actions">
            <button type="submit" class="tips-cta"><?php echo customLang('pay_continue'); ?></button>
          </div>
        <?php else: ?>
          <div class="tips-alert is-info is-open" role="alert">
            <?php echo customLang('subscription_inactive_note'); ?>
          </div>
        <?php endif; ?>

        <!-- Hidden context for client-side handlers -->
        <input type="hidden" name="recipient_id" value="<?php echo (int)$recipientId; ?>">
      </form>
    </div>
<?php
$assetVersion = isset($version) && $version !== '' ? (string) $version : (defined('APP_VERSION') ? (string) APP_VERSION : '1');
?>
<script defer src="<?php echo iN_HelpSecure($base_url);?>themes/<?php echo iN_HelpSecure($currentTheme);?>/js/subscribeHandler.js?v=<?php echo iN_HelpSecure($assetVersion);?>"></script>
</div>
