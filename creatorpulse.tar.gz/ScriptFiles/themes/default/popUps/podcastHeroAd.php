<?php
declare(strict_types=1);

$isLoggedIn = isset($loggedIn) && $loggedIn === '1';
$uid = isset($userID) ? (int) $userID : 0;
$podcastsEnabled = isset($enablePodcastPosts) ? (bool) $enablePodcastPosts : true;

if (!$isLoggedIn || $uid <= 0) {
    echo '<div class="popUp-container flex align_items_justify_content"><div class="popup-wrapper create_post flex align_items_justify_content flexBoxColumn"><div class="notice small">' . iN_HelpSecure(customLang('login_required', 'Login required.')) . '</div></div></div>';
    return;
}

if (!$podcastsEnabled) {
    echo '<div class="popUp-container flex align_items_justify_content"><div class="popup-wrapper create_post flex align_items_justify_content flexBoxColumn"><div class="notice small">' . iN_HelpSecure(customLang('content_disabled_podcasts', 'Podcast sharing is currently disabled.')) . '</div></div></div>';
    return;
}

$csrfToken = generateCsrfToken();
$latestAd = null;
if (isset($RL) && method_exists($RL, 'RL_GetLatestPodcastAdByUser')) {
    try {
        $latestAd = $RL->RL_GetLatestPodcastAdByUser($uid);
    } catch (Throwable $__) {
        $latestAd = null;
    }
}

$latestStatus = strtolower((string) ($latestAd['status'] ?? ''));
$latestId = isset($latestAd['id']) ? (int) $latestAd['id'] : 0;
$statusMap = [
    'pending'  => customLang('hero_ads_status_pending', 'Pending'),
    'approved' => customLang('hero_ads_status_approved', 'Approved'),
    'rejected' => customLang('hero_ads_status_rejected', 'Rejected'),
];
$statusLabel = $statusMap[$latestStatus] ?? '';
$statusContext = '';
if ($latestStatus === 'pending') {
    $statusContext = customLang('hero_ads_awaiting_approval', 'Awaiting approval');
} elseif ($latestStatus === 'approved') {
    $statusContext = customLang('hero_ads_approved', 'Approved');
} elseif ($latestStatus === 'rejected') {
    $statusContext = customLang('hero_ads_rejected', 'Rejected');
}

$baseForActions = isset($base_url) ? (string) $base_url : '';
$requestUrl = $baseForActions !== '' ? rtrim($baseForActions, '/') . '/request/requests.php' : 'request/requests.php';
$packageHeading = customLang('hero_ads_package_heading', 'Select a package');
$packageSubheading = customLang('hero_ads_package_hint', 'Pay for a package to unlock the form.');
$premiumLabel = customLang('hero_ads_package_premium', 'Premium slot (top position)');
$targetingLabel = customLang('hero_ads_package_targeting', 'Targeting add-on');
$payButtonLabel = customLang('hero_ads_payment_pay', 'Pay & unlock form');
$walletLabel = customLang('hero_ads_payment_wallet_label', 'Pay with wallet balance');
$walletBalanceLabel = customLang('hero_ads_wallet_balance', 'Wallet balance');
$planSelectLabel = customLang('hero_ads_select_plan_btn', 'Select a plan for your podcast ad');
$topupRequiredLabel = customLang('hero_ads_topup_required', 'You need to add funds to your wallet.');
$balanceCurrentLabel = customLang('hero_ads_balance_current', 'Current balance');
$balanceAfterLabel = customLang('hero_ads_balance_after', 'Balance after payment');
$planSelectedLabel = customLang('hero_ads_plan_selected', 'Selected plan');
$planPriceLabel = customLang('hero_ads_plan_price', 'Price');
$currencyFormatSettings = isset($currencyFormatSettings)
    ? $currencyFormatSettings
    : ($GLOBALS['currencyFormatSettings'] ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([])));
if (!isset($currencyFormatSettings['position'])) {
    $currencyFormatSettings = dz_currency_normalize_settings((array) $currencyFormatSettings);
}
$displayCurrency = isset($currency) ? (string) $currency : (isset($default_currency) ? (string) $default_currency : 'USD');
$currencySymbolMap = (isset($currencies) && is_array($currencies)) ? $currencies : [];
$displaySymbol = (string) ($currencySymbolMap[$displayCurrency] ?? '');
$displayPrecision = dz_currency_resolve_precision($displayCurrency, $currencyFormatSettings['decimal_places'] ?? 2);
$currencyPosition = $currencyFormatSettings['position'] ?? 'left';
$currencyFormatClient = dz_currency_settings_for_js($currencyFormatSettings, $displayCurrency, $displaySymbol);
$formatMoney = static function (float $amount, ?string $code = null, ?string $symbol = null) use ($displayCurrency, $displaySymbol, $currencyFormatSettings): string {
    return dz_format_currency($amount, $code ?? $displayCurrency, $symbol ?? $displaySymbol, $currencyFormatSettings);
};

$userBalance = isset($userWallet) ? (float) $userWallet : 0.0;
$hasBalance = $userBalance > 0;
?>
<div class="popUp-container flex align_items_justify_content podcast-ad-container">
    <div class="popup-wrapper podcast-ad-popup flex flexBoxColumn">
        <div class="click_box_header flex align_items_justify_content">
            <div class="full-width flex align_items_justify_content">
                <?php echo iN_HelpSecure(customLang('hero_ads_manage', 'Podcast Hero Ads')); ?>
            </div>
            <button type="button" class="close_pop flex align_items" aria-label="<?php echo iN_HelpSecure(customLang('close')); ?>">
                <?php echo render_icon('close', true); ?>
            </button>
        </div>
        <div class="podcast-ad-body flex flexBoxColumn gap">
            <div class="podcast-ad-alert none" id="podcastAdAlert" role="alert"></div>
            <form id="podcastAdForm" class="podcast-ad-form flex flexBoxColumn gap" action="<?php echo iN_HelpSecure($requestUrl); ?>" method="post" enctype="multipart/form-data" data-delete-id="<?php echo $latestId; ?>">
                <input type="hidden" name="p" value="podcast_ad_submit">
                <input type="hidden" name="csrf_token" value="<?php echo iN_HelpSecure($csrfToken, false); ?>">
                <input type="hidden" name="podcast_ad_package_id" id="podcastAdPackageId" value="">
                <input type="hidden" name="podcast_ad_payment_id" id="podcastAdPaymentId" value="">
                <input type="hidden" name="podcast_ad_payment_token" id="podcastAdPaymentToken" value="">

                <div class="podcast-ad-balance">
                    <div class="podcast-ad-balance__row">
                        <span class="podcast-ad-balance__label"><?php echo iN_HelpSecure($walletBalanceLabel); ?></span>
                        <span class="podcast-ad-balance__value"
                              id="podcastAdWalletBalance"
                              data-balance="<?php echo iN_HelpSecure(number_format($userBalance, $displayPrecision, '.', ''), false); ?>"
                              data-currency="<?php echo iN_HelpSecure($displayCurrency, false); ?>"
                              data-currency-symbol="<?php echo iN_HelpSecure($displaySymbol, false); ?>"
                              data-amount-precision="<?php echo (int) $displayPrecision; ?>"
                              data-currency-position="<?php echo iN_HelpSecure($currencyFormatSettings['position'] ?? 'left', false); ?>"
                              data-currency-config="<?php echo htmlspecialchars(json_encode($currencyFormatClient, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8'); ?>">
                            <?php echo iN_HelpSecure($formatMoney($userBalance)); ?>
                        </span>
                    </div>
                </div>

                <?php if (!$hasBalance): ?>
                    <div class="podcast-ad-topup" id="podcastAdTopupRow">
                        <p class="form-text"><?php echo iN_HelpSecure($topupRequiredLabel); ?></p>
                        <button type="button" class="sidebar__menu_box full-width flex align_items walletTopup">
                            <?php echo iN_HelpSecure(customLang('wallet_topup_button_label', 'Add funds')); ?>
                        </button>
                    </div>
                <?php else: ?>
                    <button type="button" class="podcast-ad-plan-toggle" id="podcastAdPlanToggle">
                        <span><?php echo iN_HelpSecure($planSelectLabel); ?></span>
                        <span class="podcast-ad-plan-toggle__chevron">▾</span>
                    </button>
                    <div class="podcast-ad-packages flex flexBoxColumn gap none"
                         id="podcastAdPackages"
                         data-request-url="<?php echo iN_HelpSecure($requestUrl); ?>"
                         data-user-balance="<?php echo iN_HelpSecure(number_format($userBalance, $displayPrecision, '.', ''), false); ?>"
                         data-currency-position="<?php echo iN_HelpSecure($currencyPosition, false); ?>"
                         data-currency-config="<?php echo htmlspecialchars(json_encode($currencyFormatClient, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8'); ?>">
                        <div class="podcast-ad-packages__header">
                            <strong><?php echo iN_HelpSecure($packageHeading); ?></strong>
                            <p class="form-text"><?php echo iN_HelpSecure($packageSubheading); ?></p>
                        </div>
                        <div class="podcast-ad-package-list" id="podcastAdPackageList" role="list" aria-live="polite"></div>
                        <div class="podcast-ad-package-options flex gap">
                            <label class="podcast-ad-option">
                                <input type="checkbox" id="podcastAdPremium" name="premium_selected" value="1">
                                <span class="podcast-ad-option__box" aria-hidden="true"></span>
                                <span class="podcast-ad-option__label"><?php echo iN_HelpSecure($premiumLabel); ?></span>
                            </label>
                            <label class="podcast-ad-option">
                                <input type="checkbox" id="podcastAdTargeting" name="targeting_selected" value="1">
                                <span class="podcast-ad-option__box" aria-hidden="true"></span>
                                <span class="podcast-ad-option__label"><?php echo iN_HelpSecure($targetingLabel); ?></span>
                            </label>
                        </div>
                        <div class="podcast-ad-payment-actions flex align_items gap">
                            <button type="button" class="podcast-ad-pay" id="podcastAdPayBtn" data-provider="wallet">
                                <?php echo iN_HelpSecure($payButtonLabel); ?>
                            </button>
                            <span class="form-text"><?php echo iN_HelpSecure($walletLabel); ?></span>
                        </div>
                        <div class="podcast-ad-payment-summary none" id="podcastAdPaymentSummary" aria-live="polite"></div>
                    </div>
                    <div class="podcast-ad-breakdown none" id="podcastAdBreakdown">
                        <div class="podcast-ad-breakdown__row">
                            <span><?php echo iN_HelpSecure($planSelectedLabel); ?></span>
                            <strong id="podcastAdBreakdownPlan">—</strong>
                        </div>
                        <div class="podcast-ad-breakdown__row">
                            <span><?php echo iN_HelpSecure($planPriceLabel); ?></span>
                            <strong id="podcastAdBreakdownPrice">—</strong>
                        </div>
                        <div class="podcast-ad-breakdown__row">
                            <span><?php echo iN_HelpSecure($balanceCurrentLabel); ?></span>
                            <strong id="podcastAdBreakdownBalance">—</strong>
                        </div>
                        <div class="podcast-ad-breakdown__row">
                            <span><?php echo iN_HelpSecure($balanceAfterLabel); ?></span>
                            <strong id="podcastAdBreakdownAfter">—</strong>
                        </div>
                    </div>
                <?php endif; ?>

                <label class="form-label" for="podcastAdTitle"><?php echo iN_HelpSecure(customLang('hero_ads_title', 'Title')); ?></label>
                <input class="form-input" type="text" name="hero_ad_title" id="podcastAdTitle" maxlength="150" required>

                <label class="form-label" for="podcastAdSubtitle"><?php echo iN_HelpSecure(customLang('hero_ads_subtitle', 'Subtitle')); ?></label>
                <textarea class="form-input" name="hero_ad_subtitle" id="podcastAdSubtitle" maxlength="255" rows="2"></textarea>

                <input type="hidden" name="podcast_post_id" id="podcastAdPostId" value="" required>
                <div class="podcast-ad-grid flex gap">
                    <div class="podcast-ad-field flex flexBoxColumn full-width">
                        <label class="form-label"><?php echo iN_HelpSecure(customLang('hero_ads_select_podcast', 'Select podcast')); ?></label>
                        <button type="button" class="podcast-ad-select-btn" id="podcastAdSelectBtn">
                            <?php echo iN_HelpSecure(customLang('hero_ads_select_podcast', 'Select podcast')); ?>
                        </button>
                        <div class="podcast-ad-selected none" id="podcastAdSelected" aria-live="polite"></div>
                        <div class="podcast-ad-picker none" id="podcastAdPicker" role="dialog" aria-modal="true" aria-labelledby="podcastAdPickerTitle">
                            <div class="podcast-ad-picker__header flex align_items space_between">
                                <strong id="podcastAdPickerTitle"><?php echo iN_HelpSecure(customLang('hero_ads_select_podcast', 'Select podcast')); ?></strong>
                                <button type="button" class="podcast-ad-picker__close" id="podcastAdPickerClose" aria-label="<?php echo iN_HelpSecure(customLang('close')); ?>">&times;</button>
                            </div>
                            <div class="podcast-ad-picker__list" id="podcastAdPickerList"></div>
                        </div>
                    </div>
                </div>

                <div class="podcast-ad-upload flex flexBoxColumn">
                    <label class="form-label" for="podcastAdCover"><?php echo iN_HelpSecure(customLang('hero_ads_cover', 'Cover image')); ?></label>
                    <input class="form-input" type="file" name="cover" id="podcastAdCover" accept="image/jpeg,image/png,image/webp" required>
                    <p class="form-text"><?php echo iN_HelpSecure(customLang('hero_ads_cover_hint', 'JPG, PNG, or WebP.')); ?></p>
                </div>

                <div class="podcast-ad-actions flex align_items gap">
                    <button type="submit" class="podcast-ad-submit">
                        <?php echo iN_HelpSecure(customLang('hero_ads_submit', 'Submit for review')); ?>
                    </button>
                    <?php if ($latestId > 0 && $latestStatus !== 'approved'): ?>
                        <button type="button" class="podcast-ad-delete" data-ad-id="<?php echo $latestId; ?>">
                            <?php echo iN_HelpSecure(customLang('hero_ads_action_delete', 'Delete')); ?>
                        </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>
