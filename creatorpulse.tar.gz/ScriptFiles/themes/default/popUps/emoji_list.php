<div class="make-comment-emoji-list full-width">
    <?php
        if($emojiSections){
            foreach ($emojiSections as $sectionName => $emojis) {
                echo "<h3>" . htmlspecialchars($sectionName, ENT_QUOTES, 'UTF-8') . "</h3>";
                foreach ($emojis as $emoji) {
                    echo "<button class='emoji' type='button'>" . $emoji . "</button>";
                }
            }
        }
    ?>
</div>