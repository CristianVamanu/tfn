<?php
    if (!isset($commentIdLocal) || $commentIdLocal <= 0) {
        return;
    }

    $commentReportPopupId = 'commentReportPopup-' . $commentIdLocal;
    $reportTitle = customLang('comment_report_title', customLang('report_title'));
    $reportSubtitle = customLang('comment_report_subtitle', customLang('report_subtitle'));
?>
<div
    id="<?php echo iN_HelpSecure($commentReportPopupId); ?>"
    class="comment-report-popup none"
    data-comment-id="<?php echo $commentIdLocal; ?>"
    data-post-id="<?php echo $postIdLocal; ?>"
    role="dialog"
    aria-modal="true"
    aria-hidden="true"
>
    <div class="cr-sheet-container">
        <div class="cr-sheet">
            <div class="cr-header">
                <div class="cr-title"><?php echo $reportTitle; ?></div>
                <div class="cr-sub"><?php echo $reportSubtitle; ?></div>
            </div>
            <div class="cr-list" data-loaded="0" data-loading="0"></div>
        </div>
        <button type="button" class="cr-cancel"><?php echo customLang('menu_cancel'); ?></button>
    </div>
</div>
