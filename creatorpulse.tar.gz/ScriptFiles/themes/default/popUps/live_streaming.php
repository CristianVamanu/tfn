<?php $isLiveDisabled = empty($liveStreamingEnabled); ?>
<!----->
<div class="popUp-container flex align_items_justify_content" data-live-disabled="<?php echo $isLiveDisabled ? '1' : '0'; ?>">

  <div class="popup-wrapper flex flexBoxColumn align_items live-popup">
    <div class="click_box_header flex align_items_justify_content">
      <button class="goBack flex align_items none"></button>
      <div class="full-width flex align_items_justify_content"><?php echo customLang('live_modal_title'); ?></div>
      <button
        id="goLiveBtn"
        class="goNext flex align_items disabled<?php echo $isLiveDisabled ? ' is-disabled' : ''; ?>"
        <?php echo $isLiveDisabled ? 'disabled aria-disabled="true"' : 'disabled'; ?>
      ><?php echo $isLiveDisabled ? customLang('live_stream_disabled_button') : customLang('live_go_live_button'); ?></button>
      <button type="button" class="close_pop flex align_items"><?php echo customLang('close'); ?></button>
    </div>

    <div class="arrow"></div>

    <div class="create_media_box flex flexBoxColumn align_items_justify_content live-create">
      <div class="flex align_items_justify_content icon_upload live-icon">
        <?php echo render_icon('live', true); ?>
      </div>
      <div class="upload-text live-title"><?php echo customLang('live_add_details_title'); ?></div>
      <div class="advanced_settings_description full-width flex align_items live-desc">
        <?php
          if ($isLiveDisabled) {
              echo customLang('live_stream_disabled_hint');
          } else {
              echo customLang('live_add_details_desc');
          }
        ?>
      </div>

      <div class="full-width live-input-holder">
        <input id="liveTitle" type="text" class="text-field full-width" placeholder="<?php echo customLang('live_title_placeholder'); ?>" value="<?php echo iN_HelpSecure($liveTitlePrefix ?? '', false); ?>" />
      </div>

      <div class="full-width live-input-holder">
        <div class="advanced_settings_title live-audience-title"><?php echo customLang('live_audience_label'); ?></div>
        <div class="relative live-select">
          <div id="audienceToggle" class="create_ads flex align_items_justify_content live-select-toggle">
            <span id="audienceLabel"><?php echo customLang('live_audience_everyone'); ?></span>
            <span class="chev flex align_items_justify_content">&#9662;</span>
          </div>
          <input type="hidden" id="liveAudience" value="everyone" />
        </div>
      </div>
    </div>
  </div>

  <!-- Audience mini popup (sheet style) -->
  <div id="audiencePopup" class="set-price-popup flex align_items_justify_content none">
    <div class="aud-sheet-container">
      <div class="aud-sheet">
        <button type="button" class="aud-item" data-value="everyone"><?php echo customLang('live_audience_everyone'); ?></button>
        <div class="aud-sep"></div>
        <button type="button" class="aud-item" data-value="subscribers"><?php echo customLang('live_audience_subscribers'); ?></button>
        <div class="aud-sep"></div>
        <button type="button" class="aud-item" data-value="followers"><?php echo customLang('live_audience_followers'); ?></button>
        <div class="aud-sep"></div>
        <button type="button" class="aud-item" data-value="following"><?php echo customLang('live_audience_following'); ?></button>
        <div class="aud-sep"></div>
        <button type="button" class="aud-item" data-value="only_me"><?php echo customLang('live_audience_only_me'); ?></button>
      </div>
      <button type="button" class="aud-cancel" id="audienceCancel"><?php echo customLang('live_audience_cancel'); ?></button>
    </div>
  </div>

  <script defer src="<?php echo iN_HelpSecure($base_url);?>themes/<?php echo iN_HelpSecure($currentTheme);?>/js/liveHandler.js?v=<?php echo iN_HelpSecure($version);?>"></script>
</div>
