<?php
// Share Post popup
// Expected: POST includes post_id
// Uses: RL_GetRecentChatPartners to suggest recipients

if (!isset($postID)) { $postID = (int)($_POST['post_id'] ?? 0); }
$meId = isset($userID) ? (int)$userID : 0;
if ($meId <= 0 && isset($_SESSION['user_id'])) {
    $meId = (int) $_SESSION['user_id'];
}
$postID = (int)$postID;

// Build share URL to copy/share
$shareUrl = rtrim((string)$base_url, '/') . '/posts/' . $postID;
$shareText = customLang('share_external_default_text', 'Check out this post on CreatorPulse');

// Suggested people: recent chat partners; fallback to followers/following if empty
$suggested = [];
try { if (isset($RL) && method_exists($RL, 'RL_GetRecentChatPartners')) { $suggested = $RL->RL_GetRecentChatPartners($meId, 18); } } catch (\Throwable $__) {}
if (!is_array($suggested)) { $suggested = []; }

if (!$suggested && isset($RL) && is_object($RL)) {
    try {
        if (method_exists($RL, 'RL_ProfileGetFollowers')) {
            $fallback = $RL->RL_ProfileGetFollowers($meId, 0, 18);
            if (is_array($fallback)) { $suggested = $fallback; }
        }
        if (!$suggested && method_exists($RL, 'RL_ProfileGetFollowing')) {
            $fallback = $RL->RL_ProfileGetFollowing($meId, 0, 18);
            if (is_array($fallback)) { $suggested = $fallback; }
        }
    } catch (Throwable $__) {
        $suggested = [];
    }
}
?>

<div class="popUp-container flex align_items">
  <div class="share-popup popup-wrapper" id="sharePostModal" role="dialog" aria-modal="true" aria-labelledby="shareTitle">
    <button class="share-close close_pop" type="button" aria-label="Close">
      <?php echo render_icon('close', true); ?>
    </button>

    <header class="share-header">
      <h2 class="share-title" id="shareTitle"><?php echo customLang('share_modal_title', 'Share'); ?></h2>
    </header>

    <section class="share-external" aria-label="<?php echo iN_HelpSecure(customLang('share_external_label', 'Share outside CreatorPulse')); ?>">
      <button type="button" class="share-external-btn" data-external-share="native">
        <span><?php echo customLang('share_external_native', 'Share'); ?></span>
      </button>
      <button type="button" class="share-external-btn" data-external-share="copy">
        <span><?php echo customLang('share_external_copy', 'Copy link'); ?></span>
      </button>
      <button type="button" class="share-external-btn" data-external-share="whatsapp">
        <span>WhatsApp</span>
      </button>
      <button type="button" class="share-external-btn" data-external-share="facebook">
        <span>Facebook</span>
      </button>
      <button type="button" class="share-external-btn" data-external-share="x">
        <span>X</span>
      </button>
      <button type="button" class="share-external-btn" data-external-share="telegram">
        <span>Telegram</span>
      </button>
      <button type="button" class="share-external-btn" data-external-share="linkedin">
        <span>LinkedIn</span>
      </button>
    </section>

    <div class="share-search">
      <input type="text" class="share-search-input" placeholder="<?php echo iN_HelpSecure(customLang('share_search_placeholder', 'Search people')); ?>" autocomplete="off">
    </div>

    <section class="share-suggestions" aria-label="<?php echo iN_HelpSecure(customLang('share_people_label', 'People')); ?>">
      <div class="share-list" id="shareList">
        <?php foreach ($suggested as $u):
            $uid = (int)($u['user_id'] ?? 0);
            if ($uid <= 0) continue;
            $name = ($u['user_fullname'] ?? '') ?: ($u['username'] ?? '');
            $usr  = (string)($u['username'] ?? '');
            $av   = (string)($u['avatar'] ?? 'uploads/user_avatars/default.jpeg');
            $avatarUrl = storage_url($av);
        ?>
          <div class="share-item transition" data-id="<?php echo $uid; ?>" role="button" tabindex="0" aria-pressed="false">
            <div class="share-avatar">
              <img src="<?php echo iN_HelpSecure($avatarUrl); ?>" alt="@<?php echo iN_HelpSecure($usr); ?>">
              <div class="share-check" aria-hidden="true"></div>
            </div>
            <div class="share-name"><?php echo iN_HelpSecure($name); ?></div>
          </div>
        <?php endforeach; ?>
      </div>
      <div class="share-empty flex align_items_justify_content full-width none" id="shareEmpty"><?php echo customLang('share_no_results', 'No results'); ?></div>
    </section>

    <section class="share-compose">
      <input type="text" class="share-message-input" id="shareMessageInput" placeholder="<?php echo iN_HelpSecure(customLang('share_message_placeholder', 'Write a message...')); ?>" maxlength="500">
    </section>

    <footer class="share-actions">
      <button type="button" class="share-send-btn" id="shareSendBtn" disabled><?php echo customLang('chat_send', 'Send'); ?></button>
    </footer>

    <input type="hidden" id="sharePostId" value="<?php echo (int)$postID; ?>">
    <input type="hidden" id="shareUrl" value="<?php echo iN_HelpSecure($shareUrl); ?>">
    <input type="hidden" id="shareText" value="<?php echo iN_HelpSecure($shareText); ?>">
  </div>

</div>
