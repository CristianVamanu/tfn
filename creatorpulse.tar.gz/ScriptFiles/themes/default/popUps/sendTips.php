<?php
// Guard: Ensure expected variables exist
$recipient      = isset($userDetails) && is_array($userDetails) ? $userDetails : [];
$recipientId    = isset($postOwnerID) ? (int)$postOwnerID : (int)($postData['post_owner_id'] ?? 0);
$recipientName  = trim((string)($recipient['user_fullname'] ?? $recipient['username'] ?? ''));
$recipientUser  = (string)($recipient['username'] ?? '');
$recipientAvatarRel = isset($RL) ? (string)$RL->RL_userAvatar($recipientId) : '';
if (function_exists('storage_resolve_media_url')) {
    $recipientAvatar = storage_resolve_media_url($recipientAvatarRel, $base_url ?? '');
} else {
    $recipientAvatar = (string)($base_url ?? '') . ltrim($recipientAvatarRel, '/');
}

$buyer          = isset($userData) && is_array($userData) ? $userData : [];
$buyerName      = trim((string)($buyer['user_fullname'] ?? $buyer['username'] ?? ''));
$buyerUser      = (string)($buyer['username'] ?? '');
$buyerEmail     = (string)($buyer['contact_email'] ?? $buyer['user_email'] ?? '');


// Provider currencies come from inc.php: $globalCurCode, $stripeCurCode, $paypalCurCode, $nowpayCurCode, $coinbaseCurCode
// Provide fallbacks to avoid running with undefined notices.
$globalCurCode = isset($globalCurCode) && $globalCurCode !== ''
    ? (string) $globalCurCode
    : ((isset($currency) && $currency !== '') ? (string) $currency : 'USD');
$stripeCurCode   = isset($stripeCurCode) && $stripeCurCode !== '' ? (string) $stripeCurCode : $globalCurCode;
$paypalCurCode   = isset($paypalCurCode) && $paypalCurCode !== '' ? (string) $paypalCurCode : $globalCurCode;
$nowpayCurCode   = isset($nowpayCurCode) && $nowpayCurCode !== '' ? (string) $nowpayCurCode : $globalCurCode;
$coinbaseCurCode = isset($coinbaseCurCode) && $coinbaseCurCode !== '' ? (string) $coinbaseCurCode : $globalCurCode;
$paystackCurCode = isset($paystackCurCode) && $paystackCurCode !== '' ? (string) $paystackCurCode : $globalCurCode;
$iyzicoCurCode   = isset($iyzicoCurCode) && $iyzicoCurCode !== '' ? (string) $iyzicoCurCode : $globalCurCode;
$payuCurCode     = isset($payuCurCode) && $payuCurCode !== '' ? (string) $payuCurCode : $globalCurCode;

// Determine default provider and currency by first enabled method
$defaultProvider = null;
if (!empty($enableStripe))      { $defaultProvider = 'stripe'; }
elseif (!empty($enablePaypal))  { $defaultProvider = 'paypal'; }
elseif (!empty($enablePayu)) { $defaultProvider = 'payu'; }
elseif (!empty($enablePaystack)) { $defaultProvider = 'paystack'; }
elseif (!empty($enableIyziCo)) { $defaultProvider = 'iyzico'; }
elseif (!empty($enableFlutterwave)) { $defaultProvider = 'flutterwave'; }
elseif (!empty($enableNowpayments)) { $defaultProvider = 'nowpayments'; }
elseif (!empty($enableCoinbase))    { $defaultProvider = 'coinbase'; }
else { $defaultProvider = 'wallet'; }

switch ($defaultProvider) {
  case 'stripe':      $curCode = $stripeCurCode; break;
  case 'paypal':      $curCode = $paypalCurCode; break;
  case 'payu':        $curCode = $payuCurCode; break;
  case 'paystack':    $curCode = $paystackCurCode; break;
  case 'iyzico':      $curCode = $iyzicoCurCode; break;
  case 'flutterwave': $curCode = $flutterwaveCurCode ?? $globalCurCode; break;
  case 'nowpayments': $curCode = $nowpayCurCode; break;
  case 'coinbase':    $curCode = $coinbaseCurCode; break;
  default:            $curCode = $globalCurCode; break;
}

$currencyFormatSettings = isset($currencyFormatSettings)
    ? $currencyFormatSettings
    : ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
$curSymbolMap = (isset($currencies) && is_array($currencies)) ? $currencies : [];
$curSymbol = (string) ($curSymbolMap[$curCode] ?? $curCode);
$curPrecision = dz_currency_resolve_precision($curCode, $currencyFormatSettings['decimal_places'] ?? 2);
$formatMoney = static function (float $amount, ?string $code = null, ?string $symbol = null) use ($curCode, $curSymbol, $currencyFormatSettings): string {
    return dz_format_currency($amount, $code ?? $curCode, $symbol ?? $curSymbol, $currencyFormatSettings);
};

$walletBalanceRaw     = isset($userWallet) ? (float) $userWallet : 0.0;
$walletCurrencyCode   = $globalCurCode !== '' ? $globalCurCode : (string) $curCode;
$walletCurrencySymbol = (string) ($curSymbolMap[$walletCurrencyCode] ?? '');
$walletPrecision      = dz_currency_resolve_precision($walletCurrencyCode, $currencyFormatSettings['decimal_places'] ?? 2);
$walletBalanceValue   = number_format($walletBalanceRaw, $walletPrecision, '.', '');
$walletProviderTemplate = customLang('pay_provider_wallet');
$walletProviderLabel    = strtr(
    $walletProviderTemplate,
    ['{balance}' => $formatMoney($walletBalanceRaw, $walletCurrencyCode, $walletCurrencySymbol)]
);
?>

<div class="popUp-container flex align_items">
    <div class="tips popup-wrapper" id="tipsModal" role="dialog" aria-modal="true" aria-labelledby="tipsTitle">
      <button class="tips-close close_pop" type="button" aria-label="Close">
        <?php echo render_icon('close', true); ?>
      </button>

      <header class="tips-header">
        <h2 class="tips-title" id="tipsTitle"><?php echo customLang('pay_send_tip_title'); ?></h2>
      </header>

      <!-- Unified inline tooltip for all tips messages -->
      <div class="tips-alert" role="status" aria-live="polite" aria-atomic="true"></div>

      <section class="tips-user">
        <div class="tips-avatar">
          <img src="<?php echo iN_HelpSecure($recipientAvatar); ?>" alt="<?php echo iN_HelpSecure($recipientUser); ?>">
        </div>
        <div class="tips-identity">
          <div class="tips-name"><?php echo iN_HelpSecure($recipientName); ?></div>
          <div class="tips-handle">@<?php echo iN_HelpSecure($recipientUser); ?></div>
        </div>
      </section>

      <?php
        $bf = [
          'first_name' => (string)($billignDataFirstName ?? ''),
          'last_name'  => (string)($billignDataLastName ?? ''),
          'country'    => (string)($billignDataCountry ?? ''),
          'city'       => (string)($billignDataCity ?? ''),
          'state'      => (string)($billignDataState ?? ''),
          'postcode'   => (string)($billignDataPostCode ?? ''),
          'address'    => (string)($billignDataAddress ?? ''),
        ];

        if (isset($RL) && method_exists($RL, 'RL_GetUserDetails') && isset($userID) && (int)$userID > 0) {
            $viewerDetails = (array) $RL->RL_GetUserDetails((int)$userID);
            foreach (
                [
                    'for_billing_first_name' => 'first_name',
                    'for_billing_last_name'  => 'last_name',
                    'for_billing_country'    => 'country',
                    'for_billing_city'       => 'city',
                    'for_billing_state'      => 'state',
                    'for_billing_postcode'   => 'postcode',
                    'for_billing_address'    => 'address',
                ] as $fieldKey => $bfKey
            ) {
                if (empty($bf[$bfKey]) && !empty($viewerDetails[$fieldKey])) {
                    $bf[$bfKey] = (string) $viewerDetails[$fieldKey];
                }
            }
        }

        $hasSavedBilling = array_filter($bf, static fn($v) => trim((string) $v) !== '');
        $billingPayload = [
          'billing_first_name' => (string)($bf['first_name'] ?? ''),
          'billing_last_name'  => (string)($bf['last_name'] ?? ''),
          'billing_country'    => (string)($bf['country'] ?? ''),
          'billing_city'       => (string)($bf['city'] ?? ''),
          'billing_state'      => (string)($bf['state'] ?? ''),
          'billing_postcode'   => (string)($bf['postcode'] ?? ''),
          'billing_address'    => (string)($bf['address'] ?? ''),
        ];
        $billingJsonAttr = $hasSavedBilling
          ? htmlspecialchars(json_encode($billingPayload, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8')
          : '';

        $countries = [];
        $countriesFile = __DIR__ . '/../../../includes/helpers/countries.php';
        if (is_file($countriesFile)) {
          require $countriesFile; // expects $countries = [...]
        }
        if (!is_array($countries) || empty($countries)) {
          $countries = ['US' => 'United States', 'TR' => 'Turkey', 'GB' => 'United Kingdom'];
        }
        $billingCountryCode = strtoupper((string)($bf['country'] ?? ''));
        $billingCountryLabel = $billingCountryCode !== '' ? ($countries[$billingCountryCode] ?? $bf['country']) : '';

        $renderBillingFields = function(string $extraAttrs = '') use ($bf, $countries, $buyerName, $buyerUser, $buyerEmail) {
          ?>
          <div class="tips-accordion-body" data-billing-fields<?php echo $extraAttrs ? ' ' . $extraAttrs : ''; ?>>
            <div class="buyer-section">
              <div><strong><?php echo customLang('pay_buyer_label'); ?></strong> <?php echo iN_HelpSecure($buyerName); ?> (@<?php echo iN_HelpSecure($buyerUser); ?>)</div>
              <?php if (!empty($buyerEmail)) : ?>
                <div><strong><?php echo customLang('pay_email_label'); ?></strong> <?php echo iN_HelpSecure($buyerEmail); ?></div>
              <?php endif; ?>
            </div>

            <div class="billing-fields grid gap">
              <div class="tips-field">
                <label class="tips-label" for="bill_first_name"><?php echo customLang('pay_first_name_label'); ?></label>
                <input id="bill_first_name" name="billing_first_name" class="tips-input" type="text" value="<?php echo iN_HelpSecure($bf['first_name']); ?>" placeholder="<?php echo customLang('pay_first_name_placeholder'); ?>" autocomplete="given-name" />
              </div>
              <div class="tips-field">
                <label class="tips-label" for="bill_last_name"><?php echo customLang('pay_last_name_label'); ?></label>
                <input id="bill_last_name" name="billing_last_name" class="tips-input" type="text" value="<?php echo iN_HelpSecure($bf['last_name']); ?>" placeholder="<?php echo customLang('pay_last_name_placeholder'); ?>" autocomplete="family-name" />
              </div>

              <div class="tips-field">
                <label class="tips-label" for="bill_country"><?php echo customLang('pay_country_label'); ?></label>
                <select id="bill_country" name="billing_country" class="tips-input">
                  <option value=""><?php echo customLang('pay_country_placeholder'); ?></option>
                  <?php foreach ($countries as $code => $name): ?>
                    <option value="<?php echo iN_HelpSecure($code); ?>" <?php echo (strtoupper($bf['country']) === $code ? 'selected' : ''); ?>><?php echo iN_HelpSecure($name); ?></option>
                  <?php endforeach; ?>
                </select>
              </div>

              <div class="tips-field">
                <label class="tips-label" for="bill_city"><?php echo customLang('pay_city_label'); ?></label>
                <input id="bill_city" name="billing_city" class="tips-input" type="text" value="<?php echo iN_HelpSecure($bf['city']); ?>" placeholder="<?php echo customLang('pay_city_placeholder'); ?>" autocomplete="address-level2" />
              </div>

              <div class="tips-field">
                <label class="tips-label" for="bill_state"><?php echo customLang('pay_state_label'); ?></label>
                <input id="bill_state" name="billing_state" class="tips-input" type="text" value="<?php echo iN_HelpSecure($bf['state']); ?>" placeholder="<?php echo customLang('pay_state_placeholder'); ?>" autocomplete="address-level1" />
              </div>

              <div class="tips-field">
                <label class="tips-label" for="bill_postcode"><?php echo customLang('pay_postcode_label'); ?></label>
                <input id="bill_postcode" name="billing_postcode" class="tips-input" type="text" value="<?php echo iN_HelpSecure($bf['postcode']); ?>" placeholder="<?php echo customLang('pay_postcode_placeholder'); ?>" autocomplete="postal-code" />
              </div>

              <div class="tips-field full-span">
                <label class="tips-label" for="bill_address"><?php echo customLang('pay_address_label'); ?></label>
                <textarea id="bill_address" name="billing_address" class="tips-input" rows="3" placeholder="<?php echo customLang('pay_address_placeholder'); ?>" autocomplete="street-address"><?php echo iN_HelpSecure($bf['address']); ?></textarea>
              </div>
            </div>
          </div>
          <?php
        };
      ?>

      <form class="tips-form" action="#" method="post" novalidate
            data-fee-percent="<?php echo iN_HelpSecure((string)($paymentFeePercent ?? 0)); ?>"
            data-fee-fixed="<?php echo iN_HelpSecure((string)($paymentFeeFixed ?? 0)); ?>"
            data-tax-percent="<?php echo iN_HelpSecure((string)($paymentTaxPercent ?? 0)); ?>"
            data-currency="<?php echo iN_HelpSecure($curCode); ?>"
            data-currency-symbol="<?php echo iN_HelpSecure($curSymbol); ?>"
            data-amount-precision="<?php echo (int) $curPrecision; ?>"<?php echo $billingJsonAttr !== '' ? ' data-billing-json="' . $billingJsonAttr . '"' : ''; ?>>
        <!-- Amount -->
        <div class="tips-field">
          <label class="tips-label" for="tipAmount"><?php echo customLang('pay_amount_label'); ?></label>
          <input name="tipAmount" id="tipAmount" class="tips-input" type="text"
                 placeholder="<?php echo iN_HelpSecure($formatMoney(0.0)); ?>"
                 inputmode="decimal" pattern="^\d*(?:[.,]\d{0,8})?$" autocomplete="off"
                 data-min="1" data-max="500" />
        </div>

        <!-- Billing agreement -->
        <?php if (!empty($hasSavedBilling)): ?>
        <?php $billingAccordionId = 'billing-accordion-' . uniqid(); ?>
        <section class="tips-accordion tips-accordion--summary" data-billing-summary>
          <header class="billing-summary-card">
            <div class="billing-summary-card__title"><?php echo customLang('pay_billing_details_title'); ?></div>
            <div class="billing-summary-card__lines">
              <?php if (!empty($bf['first_name']) || !empty($bf['last_name'])): ?>
                <div><?php echo iN_HelpSecure(trim($bf['first_name'] . ' ' . $bf['last_name'])); ?></div>
              <?php endif; ?>
              <?php if (!empty($bf['address'])): ?>
                <div><?php echo iN_HelpSecure($bf['address']); ?></div>
              <?php endif; ?>
              <?php if (!empty($bf['postcode']) || !empty($bf['city'])): ?>
                <div><?php echo iN_HelpSecure(trim($bf['postcode'] . ' ' . $bf['city'])); ?></div>
              <?php endif; ?>
              <?php if (!empty($billingCountryLabel)): ?>
                <div><?php echo iN_HelpSecure($billingCountryLabel); ?></div>
              <?php endif; ?>
            </div>
            <p class="billing-summary-card__hint"><?php echo customLang('pay_billing_saved_hint', 'We will reuse this billing profile unless you choose to edit it.'); ?></p>
          </header>
          <button type="button"
                  class="billing-edit-toggle"
                  data-billing-edit
                  data-billing-target="#<?php echo iN_HelpSecure($billingAccordionId); ?>">
            <?php echo customLang('pay_billing_edit_button', 'Edit billing details'); ?>
          </button>
        </section>
        <div class="tips-accordion tips-accordion--form is-collapsed"
             id="<?php echo iN_HelpSecure($billingAccordionId); ?>">
          <?php $renderBillingFields('hidden="hidden"'); ?>
        </div>
        <?php else: ?>
        <details class="tips-accordion" open>
          <summary>
            <?php echo customLang('pay_billing_details_title'); ?>
            <img class="icon-16" src="<?php echo iN_HelpSecure($iconPath . 'down_arrow.svg'); ?>" alt="" aria-hidden="true">
          </summary>
          <?php $renderBillingFields(); ?>
        </details>
        <?php endif; ?>

        <!-- Payment summary -->
        <?php
          $feeParts = [];
          $feePercentVal = isset($paymentFeePercent) ? (float)$paymentFeePercent : 0.0;
          $feeFixedVal   = isset($paymentFeeFixed) ? (float)$paymentFeeFixed : 0.0;
          if ($feePercentVal > 0) {
              $feeParts[] = rtrim(rtrim(number_format($feePercentVal, 2, '.', ''), '0'), '.') . '%';
          }
          if ($feeFixedVal > 0) {
              $feeParts[] = $formatMoney($feeFixedVal);
          }
          $feeLabel = customLang('pay_summary_fees');
          if ($feeParts) {
              $feeLabel .= ' (' . implode(' + ', $feeParts) . ')';
          }

          $taxLabel = customLang('pay_summary_taxes');
          $taxPercentVal = isset($paymentTaxPercent) ? (float)$paymentTaxPercent : 0.0;
          if ($taxPercentVal > 0) {
              $taxLabel .= ' (' . rtrim(rtrim(number_format($taxPercentVal, 2, '.', ''), '0'), '.') . '%)';
          }
        ?>
        <div>
          <div class="tips-section-title"><?php echo customLang('pay_summary_title'); ?></div>
          <div class="tips-summary">
            <dl>
              <div class="row"><dt><?php echo customLang('pay_summary_subtotal'); ?></dt><dd><span class="tips-subtotal-amount"><?php echo iN_HelpSecure($formatMoney(0.0)); ?></span></dd></div>
              <div class="row"><dt><?php echo iN_HelpSecure($feeLabel); ?></dt><dd><span class="tips-fee-amount"><?php echo iN_HelpSecure($formatMoney(0.0)); ?></span></dd></div>
              <div class="row"><dt><?php echo iN_HelpSecure($taxLabel); ?></dt><dd><span class="tips-taxes-amount"><?php echo iN_HelpSecure($formatMoney(0.0)); ?></span></dd></div>
              <div class="row"><dt><?php echo customLang('pay_summary_total'); ?></dt><dd><span class="tips-total-amount"><?php echo iN_HelpSecure($formatMoney(0.0)); ?></span></dd></div>
            </dl>
          </div>
        </div>

        <!-- Payment methods -->
        <div class="tips-methods">
          <div class="tips-section-title"><?php echo customLang('pay_method_title'); ?></div>

          <div class="provider_list full-width flex align_items column-gap">
            <?php $first = true; ?>
            <?php if (!empty($enableStripe)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="stripe" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($stripeCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_stripe'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enablePaypal)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="paypal" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($paypalCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_paypal'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enablePayu)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="payu" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($payuCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_payu'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enablePaystack)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="paystack" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($paystackCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_paystack'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enableIyziCo)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="iyzico" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($iyzicoCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_iyzico'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enableNowpayments)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="nowpayments" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($nowpayCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_nowpayments'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enableFlutterwave)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="flutterwave" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($flutterwaveCurCode ?? $globalCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_flutterwave'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enableCoinbase)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="coinbase" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($coinbaseCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_coinbase'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <label class="provider-item flex align_items column-gap">
              <input type="radio" name="tip_provider" value="wallet" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($globalCurCode); ?>">
              <span class="provider-name"
                    data-wallet-balance-text
                    data-wallet-balance="<?php echo iN_HelpSecure($walletBalanceValue, false); ?>"
                    data-wallet-balance-currency="<?php echo iN_HelpSecure($walletCurrencyCode, false); ?>"
                    data-wallet-balance-symbol="<?php echo iN_HelpSecure($walletCurrencySymbol, false); ?>"
                    data-wallet-balance-template="<?php echo iN_HelpSecure($walletProviderTemplate, false); ?>">
                <?php echo iN_HelpSecure($walletProviderLabel, false); ?>
              </span>
            </label>
          </div>
        </div>

        <p class="tips-note">
          <?php echo customLang('pay_note_redirect_info'); ?>
        </p>

        <div class="tips-actions">
          <button type="submit" class="tips-cta"><?php echo customLang('pay_continue'); ?></button>
        </div>

        <!-- Hidden context for client-side handlers -->
        <input type="hidden" name="post_id" value="<?php echo isset($postData['post_id']) ? (int)$postData['post_id'] : 0; ?>">
        <input type="hidden" name="recipient_id" value="<?php echo (int)$recipientId; ?>">
        <input type="hidden" name="buyer_name" value="<?php echo iN_HelpSecure($buyerName); ?>">
        <input type="hidden" name="live_id" value="<?php echo isset($liveContextId) ? (int)$liveContextId : 0; ?>">
      </form>
    </div>
<?php
$assetVersion = isset($version) && $version !== '' ? (string) $version : (defined('APP_VERSION') ? (string) APP_VERSION : '1');
?>
<script defer src="<?php echo iN_HelpSecure($base_url);?>themes/<?php echo iN_HelpSecure($currentTheme);?>/js/tipsHandler.js?v=<?php echo iN_HelpSecure($assetVersion);?>"></script>

</div>
