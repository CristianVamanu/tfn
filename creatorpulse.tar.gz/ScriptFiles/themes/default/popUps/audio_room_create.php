<?php
declare(strict_types=1);

$audioRoomsEnabledPopup = isset($audioRoomsEnabled)
    ? (bool) $audioRoomsEnabled
    : (bool) ($GLOBALS['audioRoomsEnabled'] ?? false);

$viewerId = isset($userID) ? (int) $userID : 0;
$isApprovedCreator = false;
if ($viewerId > 0 && isset($RL) && method_exists($RL, 'RL_IsApprovedCreator')) {
    try {
        $isApprovedCreator = (bool) $RL->RL_IsApprovedCreator($viewerId);
    } catch (Throwable $__) {
        $isApprovedCreator = false;
    }
}

$paidRoomsEnabled = isset($audioRoomPaidEnabled)
    ? (bool) $audioRoomPaidEnabled
    : (bool) ($GLOBALS['audioRoomPaidEnabled'] ?? false);
$customPriceEnabled = isset($audioRoomCustomPriceEnabled)
    ? (bool) $audioRoomCustomPriceEnabled
    : (bool) ($GLOBALS['audioRoomCustomPriceEnabled'] ?? false);
$pricePresets = isset($audioRoomPricePresets) && is_array($audioRoomPricePresets)
    ? $audioRoomPricePresets
    : (is_array($GLOBALS['audioRoomPricePresets'] ?? null) ? $GLOBALS['audioRoomPricePresets'] : [5, 10, 15, 20]);
$priceMin = isset($audioRoomPriceMinimum) ? (float) $audioRoomPriceMinimum : (float) ($GLOBALS['audioRoomPriceMinimum'] ?? 1);
$priceMax = isset($audioRoomPriceMaximum) ? (float) $audioRoomPriceMaximum : (float) ($GLOBALS['audioRoomPriceMaximum'] ?? 500);
$dailyMinutes = isset($audioRoomNonCreatorDailyMinutes) ? (int) $audioRoomNonCreatorDailyMinutes : (int) ($GLOBALS['audioRoomNonCreatorDailyMinutes'] ?? 60);
$titlePrefix = isset($audioRoomTitlePrefix) ? (string) $audioRoomTitlePrefix : (string) ($GLOBALS['audioRoomTitlePrefix'] ?? '');
$currencyCode = strtoupper((string)($paymentsCurrency ?? $currency ?? 'USD'));
$audioRoomFormatPrice = static function ($amount, string $code) {
    if (function_exists('dz_format_currency')) {
        return dz_format_currency((float)$amount, $code);
    }
    return strtoupper($code) . ' ' . rtrim(rtrim(number_format((float)$amount, 2, '.', ''), '0'), '.');
};
$csrfToken = function_exists('generateCsrfToken') ? generateCsrfToken() : '';

$canCreatePaid = $audioRoomsEnabledPopup && $paidRoomsEnabled && $isApprovedCreator;
$presetsForClient = array_values(array_map('floatval', $pricePresets));
$presetsJson = htmlspecialchars(json_encode($presetsForClient, JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8');
?>
<div class="popUp-container flex align_items_justify_content audio-room-create-shell" data-audio-disabled="<?php echo $audioRoomsEnabledPopup ? '0' : '1'; ?>">
    <div class="popup-wrapper flex flexBoxColumn align_items audio-room-create-popup">
        <div class="click_box_header flex align_items_justify_content">
            <button class="goBack flex align_items none" type="button"></button>
            <div class="full-width flex align_items_justify_content"><?php echo iN_HelpSecure(customLang('audio_room_modal_title', 'Create audio room'), false); ?></div>
            <button
                id="createAudioRoomBtn"
                class="goNext flex align_items disabled<?php echo !$audioRoomsEnabledPopup ? ' is-disabled' : ''; ?>"
                <?php echo !$audioRoomsEnabledPopup ? 'disabled aria-disabled="true"' : 'disabled'; ?>
                type="button"
            ><?php echo iN_HelpSecure(customLang('audio_room_start_button', 'Start'), false); ?></button>
            <button type="button" class="close_pop flex align_items"><?php echo iN_HelpSecure(customLang('close'), false); ?></button>
        </div>

        <div class="arrow"></div>

        <div
            class="create_media_box flex flexBoxColumn align_items_justify_content audio-room-create"
            data-can-paid="<?php echo $canCreatePaid ? '1' : '0'; ?>"
            data-custom-price="<?php echo $customPriceEnabled ? '1' : '0'; ?>"
            data-price-min="<?php echo htmlspecialchars((string)$priceMin, ENT_QUOTES, 'UTF-8'); ?>"
            data-price-max="<?php echo htmlspecialchars((string)$priceMax, ENT_QUOTES, 'UTF-8'); ?>"
            data-currency="<?php echo htmlspecialchars($currencyCode, ENT_QUOTES, 'UTF-8'); ?>"
            data-presets="<?php echo $presetsJson; ?>"
        >
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
            <div class="flex align_items_justify_content icon_upload audio-room-create__icon">
                <?php echo render_icon('podcast', true); ?>
            </div>
            <div class="upload-text audio-room-create__title"><?php echo iN_HelpSecure(customLang('audio_room_add_details_title', 'Add room details'), false); ?></div>
            <div class="advanced_settings_description full-width flex align_items audio-room-create__desc">
                <?php
                    echo $audioRoomsEnabledPopup
                        ? iN_HelpSecure(customLang('audio_room_add_details_desc', 'Open an audio-first live room for your audience.'), false)
                        : iN_HelpSecure(customLang('audio_room_disabled_hint', 'Audio rooms are currently disabled.'), false);
                ?>
            </div>

            <div class="full-width live-input-holder">
                <input id="audioRoomTitle" type="text" class="text-field full-width" maxlength="180" placeholder="<?php echo iN_HelpSecure(customLang('audio_room_title_placeholder', 'Room title'), false); ?>" value="<?php echo iN_HelpSecure($titlePrefix, false); ?>" <?php echo !$audioRoomsEnabledPopup ? 'disabled' : ''; ?>>
            </div>

            <div class="full-width live-input-holder">
                <textarea id="audioRoomDescription" class="text-field full-width audio-room-create__textarea" maxlength="500" placeholder="<?php echo iN_HelpSecure(customLang('audio_room_description_placeholder', 'Description (optional)'), false); ?>" <?php echo !$audioRoomsEnabledPopup ? 'disabled' : ''; ?>></textarea>
            </div>

            <div class="full-width live-input-holder">
                <div class="advanced_settings_title live-audience-title"><?php echo iN_HelpSecure(customLang('live_audience_label'), false); ?></div>
                <div class="audio-room-segmented" role="radiogroup" aria-label="<?php echo iN_HelpSecure(customLang('live_audience_label'), false); ?>">
                    <button type="button" class="audio-room-segmented__item active" data-audience="everyone"><?php echo iN_HelpSecure(customLang('live_audience_everyone'), false); ?></button>
                    <button type="button" class="audio-room-segmented__item" data-audience="followers"><?php echo iN_HelpSecure(customLang('live_audience_followers'), false); ?></button>
                    <button type="button" class="audio-room-segmented__item" data-audience="subscribers"><?php echo iN_HelpSecure(customLang('live_audience_subscribers'), false); ?></button>
                </div>
                <input type="hidden" id="audioRoomAudience" value="everyone">
            </div>

            <?php if ($paidRoomsEnabled): ?>
            <div class="audio-room-paid-panel full-width<?php echo !$canCreatePaid ? ' is-muted' : ''; ?>">
                <label class="audio-room-switch flex align_items space_between">
                    <span class="flex flexBoxColumn">
                        <strong><?php echo iN_HelpSecure(customLang('audio_room_paid_label', 'Paid entry'), false); ?></strong>
                        <small>
                            <?php
                                echo $canCreatePaid
                                    ? iN_HelpSecure(customLang('audio_room_paid_hint', 'Charge an entry ticket for this room.'), false)
                                    : iN_HelpSecure(customLang('audio_room_paid_creator_only', 'Paid rooms are available for approved creators.'), false);
                            ?>
                        </small>
                    </span>
                    <input id="audioRoomPaid" type="checkbox" <?php echo !$canCreatePaid ? 'disabled' : ''; ?>>
                </label>
                <div class="audio-room-price-panel none" id="audioRoomPricePanel">
                    <div class="audio-room-price-presets">
                        <?php foreach ($pricePresets as $preset): ?>
                            <?php $presetValue = number_format((float)$preset, 2, '.', ''); ?>
                            <button type="button" class="audio-room-price" data-price="<?php echo htmlspecialchars($presetValue, ENT_QUOTES, 'UTF-8'); ?>">
                                <?php echo htmlspecialchars($audioRoomFormatPrice((float)$preset, $currencyCode), ENT_QUOTES, 'UTF-8'); ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                    <?php if ($customPriceEnabled): ?>
                    <input id="audioRoomCustomPrice" type="number" min="<?php echo htmlspecialchars((string)$priceMin, ENT_QUOTES, 'UTF-8'); ?>" max="<?php echo htmlspecialchars((string)$priceMax, ENT_QUOTES, 'UTF-8'); ?>" step="0.01" class="text-field full-width" placeholder="<?php echo iN_HelpSecure(customLang('audio_room_custom_price_placeholder', 'Custom price'), false); ?>">
                    <?php endif; ?>
                    <input type="hidden" id="audioRoomEntryPrice" value="">
                </div>
            </div>
            <?php elseif (!$isApprovedCreator && $dailyMinutes > 0): ?>
            <div class="audio-room-limit-note full-width">
                <?php echo iN_HelpSecure(sprintf(customLang('audio_room_daily_limit_note', 'Non-creator rooms are limited to %d minutes per day.'), $dailyMinutes), false); ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script defer src="<?php echo iN_HelpSecure($base_url);?>themes/<?php echo iN_HelpSecure($currentTheme);?>/js/audioRoomCreate.js?v=<?php echo iN_HelpSecure($version);?>"></script>
</div>
