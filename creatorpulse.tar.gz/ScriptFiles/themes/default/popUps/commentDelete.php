<?php
    if (!isset($commentIdLocal) || $commentIdLocal <= 0) {
        return;
    }

    $commentDeleteDomId = 'commentDeletePopup-' . $commentIdLocal;
?>
<div
    id="<?php echo iN_HelpSecure($commentDeleteDomId); ?>"
    class="comment-delete-popup none"
    data-comment-id="<?php echo $commentIdLocal; ?>"
    data-post-id="<?php echo $postIdLocal; ?>"
    role="dialog"
    aria-modal="true"
    aria-hidden="true"
>
    <div class="cd-sheet-container">
        <div class="cd-sheet">
            <div class="cd-header">
                <div class="cd-title"><?php echo customLang('comment_delete_title', 'Delete comment'); ?></div>
                <div class="cd-sub"><?php echo customLang('comment_delete_subtitle', 'This action cannot be undone.'); ?></div>
            </div>
            <div class="cd-actions">
                <button type="button" class="cd-confirm is-danger"><?php echo customLang('comment_delete_confirm', 'Delete'); ?></button>
                <button type="button" class="cd-cancel"><?php echo customLang('menu_cancel'); ?></button>
            </div>
        </div>
    </div>
</div>
