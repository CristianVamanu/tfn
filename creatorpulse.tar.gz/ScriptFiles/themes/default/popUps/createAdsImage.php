<?php
declare(strict_types=1);

$creatorStatusRaw = isset($creatorStatus) ? strtolower((string) $creatorStatus) : 'none';
$isCreatorUser = in_array($creatorStatusRaw, ['approved', 'open', 'active'], true);
$paymentsActive = !empty($hasActivePaymentProviders);

$baseForLinks = isset($base_url) ? (string) $base_url : '';
$creatorSettingsUrl = $baseForLinks !== ''
    ? rtrim($baseForLinks, '/') . '/settings?tab=creator_identity'
    : 'settings?tab=creator_identity';

$creatorGuardMessage = customLang('post_visibility_creator_required', 'Only approved creators can share subscriber or paywalled posts. Become a creator to unlock these options.');
if (!is_string($creatorGuardMessage) || $creatorGuardMessage === '') {
    $creatorGuardMessage = 'Only approved creators can share subscriber or paywalled posts. Become a creator to unlock these options.';
}
$creatorGuardAction = customLang('post_visibility_open_creator', 'Become a creator');
if (!is_string($creatorGuardAction) || $creatorGuardAction === '') {
    $creatorGuardAction = 'Become a creator';
}
$paymentsGuardMessage = customLang('post_visibility_payments_disabled', 'Payment methods are currently being improved. Please try again later.');
if (!is_string($paymentsGuardMessage) || $paymentsGuardMessage === '') {
    $paymentsGuardMessage = 'Payment methods are currently being improved. Please try again later.';
}
$paymentsGuardAction = customLang('ui_ok', 'OK');
if (!is_string($paymentsGuardAction) || $paymentsGuardAction === '') {
    $paymentsGuardAction = 'OK';
}
$guardCancelLabel = customLang('menu_cancel', 'Cancel');
if (!is_string($guardCancelLabel) || $guardCancelLabel === '') {
    $guardCancelLabel = 'Cancel';
}
$adsGuardMessage = '';
if (empty($enableAds)) {
    $adsGuardMessage = customLang('content_disabled_ads');
} elseif (empty($enableImagePosts)) {
    $adsGuardMessage = customLang('content_disabled_images');
}
if ($adsGuardMessage !== '') {
    echo '<div class="popUp-container flex align_items_justify_content"><div class="popup-wrapper create_ads_image_popup flex align_items_justify_content flexBoxColumn"><div class="notice small">' . iN_HelpSecure($adsGuardMessage) . '</div></div></div>';
    return;
}

$currencyFormatSettings = isset($currencyFormatSettings)
    ? $currencyFormatSettings
    : ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
$currencyCode = isset($globalCurCode) && $globalCurCode !== '' ? (string) $globalCurCode : (isset($currency) ? (string) $currency : 'USD');
$currencySymbolMap = (isset($currencies) && is_array($currencies)) ? $currencies : [];
$currencySymbol = (string) ($currencySymbolMap[$currencyCode] ?? '');
$currencyPrecision = dz_currency_resolve_precision($currencyCode, $currencyFormatSettings['decimal_places'] ?? 2);
$formatMoney = static function (float $amount, ?string $code = null, ?string $symbol = null) use ($currencyCode, $currencySymbol, $currencyFormatSettings): string {
    return dz_format_currency($amount, $code ?? $currencyCode, $symbol ?? $currencySymbol, $currencyFormatSettings);
};
$currencyToken = $currencySymbol !== '' ? $currencySymbol : $currencyCode;
?>
<!----->
<div
  class="popUp-container flex align_items_justify_content"
  data-is-creator="<?php echo $isCreatorUser ? '1' : '0'; ?>"
  data-payments-active="<?php echo $paymentsActive ? '1' : '0'; ?>"
  data-creator-url="<?php echo iN_HelpSecure($creatorSettingsUrl); ?>"
  data-creator-message="<?php echo iN_HelpSecure($creatorGuardMessage); ?>"
  data-creator-action="<?php echo iN_HelpSecure($creatorGuardAction); ?>"
  data-payments-message="<?php echo iN_HelpSecure($paymentsGuardMessage); ?>"
  data-payments-action="<?php echo iN_HelpSecure($paymentsGuardAction); ?>"
  data-guard-cancel="<?php echo iN_HelpSecure($guardCancelLabel); ?>"
>
  <!----->
  <div class="popup-wrapper flex flexBoxColumn align_items">
    <!---->
    <div class="click_box_header flex align_items_justify_content">
      <button id="goBack" class="goBack flex align_items none">
        <?php echo customLang('nav_back'); ?>
      </button>
      <div class="full-width flex align_items_justify_content"><?php echo customLang('ads_modal_title_image', 'Create image advertisement'); ?></div>
      <button id="goNext" class="goNext flex align_items none">
        <?php echo customLang('nav_next'); ?>
      </button>

      <span id="uploadBtn" class="finishPost flex align_items none">
        <?php echo customLang('nav_share'); ?>
      </span>
      <button type="button" class="close_pop flex align_items"><?php echo customLang('close'); ?></button>
    </div>
    <!---->
    <div class="arrow"></div>
    <div class="create_media_box flex flexBoxColumn align_items_justify_content">
          <div class="flex align_items_justify_content icon_upload"><?php echo render_icon('image', true); ?></div>
          <div class="upload-text"><?php echo customLang('upload_photos'); ?></div>
          <label class="upload-btn flex align_items" for="imageFileInput"><?php echo customLang('select_images_from_device');?></label>
          <input type="file" id="imageFileInput" class="none" multiple />
    </div>
    <!---->
    <div class="crop-container flex align_items">
      <div class="crop-frame">
            <div class="crop_setting_buttons flex align_items_justify_content flexBoxColumn">
            <!---->
            <div class="filter-container flex flexBoxColumn">
              <div class="open-filters flex align_items_justify_content"><?php echo render_icon('filters', false); ?></div>
              <div class="filter-wrapper">
                <div class="filter-buttons flex flexBoxColumn flex_start">
                  <button class="filter-btn" data-filter="none"><?php echo customLang('filter_original');;?></button>
                  <button class="filter-btn" data-filter="moon"><?php echo customLang('filter_moon');;?></button>
                  <button class="filter-btn" data-filter="gingham"><?php echo customLang('filter_gingham');;?></button>
                  <button class="filter-btn" data-filter="reyes"><?php echo customLang('filter_reyes');;?></button>
                  <button class="filter-btn" data-filter="sepia"><?php echo customLang('filter_sepia');;?></button>
                  <button class="filter-btn" data-filter="invert"><?php echo customLang('filter_invert');;?></button>
                  <button class="filter-btn" data-filter="brighten"><?php echo customLang('filter_brighten');;?></button>
                  <button class="filter-btn" data-filter="contrast"><?php echo customLang('filter_contrast_plus');;?></button>
                </div>
              </div>
            </div>
            <!---->
            <!---->
            <div class="original_view flex align_items_justify_content ">
              <button class="flex align_items_justify_content"  id="originalView"><?php echo render_icon('original_view', true); ?></button>
            </div>
            <!---->
            <!---->
              <div class="restove_view flex align_items_justify_content ">
                <button class="flex align_items_justify_content"  id="restorePreviousView"><?php echo render_icon('back', true); ?></button>
              </div>
            <!---->
            </div>
            <!---->
            <div class="fileInputMore flex align_items_justify_content flexBoxColumn">
              <label class="add-more-btn flex align_items" for="fileInputMore">
                <?php echo render_icon('plus_image', true); ?>
              </label>
              <input type="file" id="fileInputMore" class="none" multiple />
            </div>
            <!---->
              <div class="grid-overlay none"></div>
              <div class="crop-images-wrapper">

              </div>
              <div class="crop-controls">
                <input type="range" id="zoom" min="1" max="3" step="0.01" value="1" />
              </div>
              <button class="prev_button flex align_items_justify_content" id="prev"><?php echo render_icon('prev', false); ?></button>
              <button class="next_button flex align_items_justify_content" id="next"><?php echo render_icon('next', false); ?></button>
        </div>
    </div>
      <!---->
    <div class="crop-finish-and-post flex align_items flexBoxColumn none"
         data-currency-code="<?php echo iN_HelpSecure($currencyCode); ?>"
         data-currency-symbol="<?php echo iN_HelpSecure($currencySymbol); ?>"
         data-amount-precision="<?php echo (int) $currencyPrecision; ?>">
      <!-- Advertisement: Details & Budgeting -->
      <div class="advanced_settings_box full-width relative flex align_items flexBoxColumn">
        <div class="full-width post-settings-title ads-section-heading"><?php echo customLang('ads_settings_title'); ?></div>

        <!-- Title -->
        <div class="ads-campaign-section full-width gap flex align_items flexBoxColumn">
          <div class="full-width flex align_items">
            <div class="advanced_settings_title flex align_items ads-field-label">
              <span><?php echo customLang('ads_title_label'); ?></span>
              <button type="button" class="ads-help-button" data-tooltip="<?php echo iN_HelpSecure(customLang('ads_help_title', 'This headline appears on your ad card.')); ?>" aria-label="<?php echo iN_HelpSecure(customLang('ads_help_title', 'This headline appears on your ad card.')); ?>">?</button>
            </div>
          </div>
          <div class="full-width flex align_items">
                <input type="text" name="ad_title" class="set-price full-width" maxlength="255" placeholder="<?php echo customLang('ads_title_placeholder'); ?>" />
          </div>
        </div>

        <!-- Description -->
        <div class="full-width gap flex align_items flexBoxColumn">
          <div class="full-width flex align_items">
            <div class="advanced_settings_title flex align_items ads-field-label">
              <span><?php echo customLang('ads_description_label'); ?></span>
              <button type="button" class="ads-help-button" data-tooltip="<?php echo iN_HelpSecure(customLang('ads_help_description', 'Use this space to describe your offer or message.')); ?>" aria-label="<?php echo iN_HelpSecure(customLang('ads_help_description', 'Use this space to describe your offer or message.')); ?>">?</button>
            </div>
          </div>
          <div class="ads-post-text full-width flex align_items">
            <textarea name="ad_description" class="create_text full-width" placeholder="<?php echo customLang('ads_description_placeholder'); ?>"></textarea>
          </div>
        </div>

        <!-- Destination URL -->
        <div class="full-width gap flex align_items flexBoxColumn">
          <div class="full-width flex align_items">
            <div class="advanced_settings_title flex align_items ads-field-label">
              <span><?php echo iN_HelpSecure(customLang('ads_link_label', 'Destination URL')); ?></span>
              <button type="button" class="ads-help-button" data-tooltip="<?php echo iN_HelpSecure(customLang('ads_help_link', 'People who tap the ad will be sent to this link.')); ?>" aria-label="<?php echo iN_HelpSecure(customLang('ads_help_link', 'People who tap the ad will be sent to this link.')); ?>">?</button>
            </div>
          </div>
          <div class="full-width flex align_items">
            <input type="text" name="ad_link" class="set-price full-width" placeholder="<?php echo iN_HelpSecure(customLang('ads_link_placeholder', 'https://your-site.com')); ?>" />
          </div>
        </div>

        <!-- Campaign Objectives -->
        <div class="full-width gap flex align_items flexBoxColumn">
          <div class="full-width flex align_items"><div class="advanced_settings_title flex align_items ads-field-label"><span><?php echo customLang('ads_campaign_label'); ?></span><button type="button" class="ads-help-button" data-tooltip="<?php echo iN_HelpSecure(customLang('ads_help_campaign', 'Set how many impressions you want, what each costs, and how long the campaign should run.')); ?>" aria-label="<?php echo iN_HelpSecure(customLang('ads_help_campaign', 'Set how many impressions you want, what each costs, and how long the campaign should run.')); ?>">?</button></div></div>

          <div class="full-width column-gap flex align_items">
            <div class="flex flexBoxColumn full-width">
                  <label class="advanced_settings_title ads-field-label"><span><?php echo customLang('ads_target_impressions'); ?></span><button type="button" class="ads-help-button" data-tooltip="<?php echo iN_HelpSecure(customLang('ads_help_impressions', 'Enter the number of times you want the ad to be displayed.')); ?>" aria-label="<?php echo iN_HelpSecure(customLang('ads_help_impressions', 'Enter the number of times you want the ad to be displayed.')); ?>">?</button></label>
              <input type="number" min="0" step="1" name="target_impressions" class="set-price" placeholder="<?php echo customLang('ads_target_impressions_placeholder'); ?>" />
            </div>
            <div class="flex flexBoxColumn full-width">
                  <label class="advanced_settings_title ads-field-label"><span><?php echo strtr(customLang('ads_price_per_impression'), ['{currency}' => iN_HelpSecure($currencyToken)]); ?></span><button type="button" class="ads-help-button" data-tooltip="<?php echo iN_HelpSecure(customLang('ads_help_ppi', 'How much you are willing to pay for each impression.')); ?>" aria-label="<?php echo iN_HelpSecure(customLang('ads_help_ppi', 'How much you are willing to pay for each impression.')); ?>">?</button></label>
              <input type="number" min="0" step="0.0001" name="price_per_impression" class="set-price" placeholder="<?php echo customLang('ads_price_per_impression_placeholder'); ?>" />
            </div>
          </div>

          <div class="full-width column-gap flex align_items">
            <div class="flex flexBoxColumn full-width">
                  <label class="advanced_settings_title ads-field-label"><span><?php echo customLang('ads_duration_days'); ?></span><button type="button" class="ads-help-button" data-tooltip="<?php echo iN_HelpSecure(customLang('ads_help_duration', 'Number of days the campaign should remain active.')); ?>" aria-label="<?php echo iN_HelpSecure(customLang('ads_help_duration', 'Number of days the campaign should remain active.')); ?>">?</button></label>
              <input type="number" min="1" step="1" name="duration_days" class="set-price" placeholder="<?php echo customLang('ads_duration_days_placeholder'); ?>" />
            </div>
            <div class="flex flexBoxColumn full-width">
                  <label class="advanced_settings_title ads-field-label"><span><?php echo strtr(customLang('ads_total_budget'), ['{currency}' => iN_HelpSecure($currencyToken)]); ?></span><button type="button" class="ads-help-button" data-tooltip="<?php echo iN_HelpSecure(customLang('ads_help_budget', 'Your maximum spend for this campaign. Must cover impressions × price.')); ?>" aria-label="<?php echo iN_HelpSecure(customLang('ads_help_budget', 'Your maximum spend for this campaign. Must cover impressions × price.')); ?>">?</button></label>
                  <input type="number" min="0" step="0.01" name="total_budget" class="set-price" placeholder="<?php echo customLang('ads_total_budget_placeholder'); ?>" />
                  <div class="advanced_settings_description calc-hint"><?php echo customLang('ads_estimated_label'); ?> <span class="calc-value"><?php echo iN_HelpSecure($formatMoney(0.0)); ?></span> <?php echo customLang('ads_estimated_formula'); ?></div>
            </div>
          </div>
        </div>

        <!-- Status -->
        <div class="full-width gap flex align_items flexBoxColumn">
          <div class="full-width flex align_items">
            <div class="advanced_settings_title flex align_items ads-field-label"><span><?php echo customLang('ads_status_label'); ?></span><button type="button" class="ads-help-button" data-tooltip="<?php echo iN_HelpSecure(customLang('ads_help_status', 'Draft ads stay inactive until you activate them.')); ?>" aria-label="<?php echo iN_HelpSecure(customLang('ads_help_status', 'Draft ads stay inactive until you activate them.')); ?>">?</button></div>
          </div>
          <div class="full-width flex align_items">
            <select name="ad_status" class="set-price full-width">
              <option value="draft" selected><?php echo customLang('ads_status_draft'); ?></option>
              <option value="active"><?php echo customLang('ads_status_active'); ?></option>
              <option value="paused"><?php echo customLang('ads_status_paused'); ?></option>
            </select>
          </div>
        </div>

        <!-- Hidden: media type (image) -->
        <input type="hidden" name="media_type" value="image">
        <input type="hidden" name="ad_id" value="">
      </div>

      <!-- Payment Section -->
      <div class="payment_box full-width relative flex align_items flexBoxColumn none">
        <div class="full-width post-settings-title ads-section-heading"><?php echo customLang('pay_method_title'); ?></div>

        <div class="full-width advanced_settings_description"><?php echo customLang('ads_payment_intro') ?? 'Choose your payment provider and charge type, then complete checkout to activate your advertisement.'; ?></div>

        <!-- Providers -->
        <div class="full-width gap flex flexBoxColumn">
          <div class="full-width flex align_items">
            <div class="advanced_settings_title"><?php echo customLang('pay_method_title'); ?></div>
          </div>
          <?php // Provider currencies come from inc.php: $globalCurCode, $stripeCurCode, $paypalCurCode, $nowpayCurCode, $coinbaseCurCode ?>
          <div class="provider_list full-width flex align_items column-gap">
                <?php
                  $walletBalanceRaw       = isset($userWallet) ? (float) $userWallet : 0.0;
                  $walletCurrencyCode     = isset($globalCurCode) ? (string) $globalCurCode : $currencyCode;
                  $walletCurrencySymbol   = (string) ($currencySymbolMap[$walletCurrencyCode] ?? '');
                  $payuCurCode            = isset($payuCurCode) && $payuCurCode !== '' ? (string) $payuCurCode : $walletCurrencyCode;
                  $walletPrecision        = dz_currency_resolve_precision($walletCurrencyCode, $currencyFormatSettings['decimal_places'] ?? 2);
                  $walletBalanceValue     = number_format($walletBalanceRaw, $walletPrecision, '.', '');
                  $walletProviderTemplate = customLang('pay_provider_wallet');
                  $walletProviderLabel    = strtr($walletProviderTemplate, ['{balance}' => $formatMoney($walletBalanceRaw, $walletCurrencyCode, $walletCurrencySymbol)]);
                ?>
            <?php $first = true; ?>
            <?php if (!empty($enableStripe)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="pay_provider" value="stripe" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($stripeCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_stripe'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enablePaypal)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="pay_provider" value="paypal" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($paypalCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_paypal'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enablePayu)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="pay_provider" value="payu" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($payuCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_payu'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enableFlutterwave)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="pay_provider" value="flutterwave" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($flutterwaveCurCode ?? $globalCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_flutterwave'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enableNowpayments)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="pay_provider" value="nowpayments" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($nowpayCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_nowpayments'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enableCoinbase)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="pay_provider" value="coinbase" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($coinbaseCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_coinbase'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <label class="provider-item flex align_items column-gap">
              <input type="radio" name="pay_provider" value="wallet" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($globalCurCode); ?>">
              <span class="provider-name"
                    data-wallet-balance-text
                    data-wallet-balance="<?php echo iN_HelpSecure($walletBalanceValue, false); ?>"
                    data-wallet-balance-currency="<?php echo iN_HelpSecure($walletCurrencyCode, false); ?>"
                    data-wallet-balance-symbol="<?php echo iN_HelpSecure($walletCurrencySymbol, false); ?>"
                    data-wallet-balance-template="<?php echo iN_HelpSecure($walletProviderTemplate, false); ?>">
                <?php echo iN_HelpSecure($walletProviderLabel, false); ?>
              </span>
            </label>
          </div>
          <div class="advanced_settings_description">
            <?php echo customLang('pay_crypto_note'); ?>
          </div>
        </div>

        <!-- Charge Type -->
        <div class="full-width gap flex flexBoxColumn">
          <div class="full-width flex align_items">
            <div class="advanced_settings_title"><?php echo customLang('ads_charge_type_label') ?? 'Charge Type'; ?></div>
          </div>
          <div class="charge_type full-width flex align_items column-gap">
            <label class="pill flex align_items column-gap">
              <input type="radio" name="pay_mode" value="one_time" checked>
              <span><?php echo customLang('ads_one_time_label') ?? 'One‑Time'; ?></span>
            </label>
            <label class="pill flex align_items column-gap">
              <input type="radio" name="pay_mode" value="subscription">
              <span><?php echo customLang('tab_subscriber'); ?></span>
            </label>
          </div>
        </div>

        <!-- Policy / Minimum -->
        <div class="full-width advanced_settings_description">
          <?php echo customLang('ads_payment_policy_note') ?? 'Minimum budget applies. You will be redirected to the selected provider to complete payment securely.'; ?>
        </div>

        <div class="payment_actions full-width flex align_items">
          <button type="button" id="startPayment" class="upload-btn flex align_items"><?php echo customLang('ads_pay_and_publish') ?? 'Pay & Publish'; ?></button>
        </div>
      </div>
    </div>
    <!---->
    <!--Set Price PopUp-->
    <div class="set-price-popup flex align_items_justify_content none">
      <div class="set-price-popup-container relative flex align_items flexBoxColumn">
        <div class="set-price-popup-title flex align_items"><?php echo customLang('set_post_price');?></div>
        <div class="arrow"></div>
        <div class="set-price-container gap full-width flex align_items flexBoxColumn">
          <div class="advanced_settings_description full-width flex align_items"><?php echo customLang('ppv_locked_notice');?></div>
          <div class="set-price-area flex align_items relative">
            <div class="price_svg flex align_items"><?php echo render_icon('locked', true); ?></div>
            <input type="number" name="set-price" class="set-price" placeholder="<?php echo customLang('write_price');?>">
          </div>
          <div class="advanced_settings_description full-width flex align_items warn"><?php echo customLang('price_range_error');?></div>
        </div>
        <div class="arrow"></div>
        <!---->
        <div class="set-price-footer full-width flex align_items">
          <div class="set-price-clear flex align_items"><?php echo customLang('clear');?></div>
          <div class="set-price-done flex align_items"><?php echo customLang('save');?></div>
        </div>
        <!---->
      </div>
    </div>
    <!--/Set Price PopUp-->
    </div>
    <!---->
    <script src="<?php echo iN_HelpSecure($base_url);?>themes/<?php echo iN_HelpSecure($currentTheme);?>/js/advertisementCrop.js?v=<?php echo iN_HelpSecure($version);?>"></script>
  </div>
  <!----->
</div>
<!----->
