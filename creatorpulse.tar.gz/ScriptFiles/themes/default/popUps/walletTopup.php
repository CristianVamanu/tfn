<?php
global $base_url, $currentTheme, $version, $currencies, $currencys, $currency_format_client, $globalCurCode, $currency;
// Guard + defaults
$minAmount = isset($__walletTopupMin) ? (float) $__walletTopupMin : 0.0;
$maxAmount = isset($__walletTopupMax) ? (float) $__walletTopupMax : 0.0;
$providerQuickAmounts = isset($__walletTopupProviderQuickAmounts) && is_array($__walletTopupProviderQuickAmounts)
    ? $__walletTopupProviderQuickAmounts
    : [];
$providerCurrencies = isset($__walletTopupProviderCurrencies) && is_array($__walletTopupProviderCurrencies)
    ? $__walletTopupProviderCurrencies
    : [];
$providers = isset($__walletTopupProviders) && is_array($__walletTopupProviders) ? $__walletTopupProviders : [];
$quickAmounts = isset($__walletTopupQuickAmounts) && is_array($__walletTopupQuickAmounts)
    ? array_values(array_filter(array_map('floatval', $__walletTopupQuickAmounts), static function ($value) {
        return $value > 0;
    }))
    : [];
$walletBalance = isset($__walletTopupBalance) ? (float) $__walletTopupBalance : 0.0;
$currencyCode = '';
if (!empty($globalCurCode)) {
    $currencyCode = strtoupper((string) $globalCurCode);
} elseif (!empty($currency)) {
    $currencyCode = strtoupper((string) $currency);
} elseif (!empty($__walletTopupCurrencyCode)) {
    $currencyCode = strtoupper((string) $__walletTopupCurrencyCode);
}
if ($currencyCode === '') {
    $currencyCode = 'USD';
}
$currenciesMap = [];
if (isset($currencies) && is_array($currencies)) {
    $currenciesMap = $currencies;
} elseif (isset($currencys) && is_array($currencys)) {
    $currenciesMap = $currencys;
}

$currencySymbolInput = isset($__walletTopupCurrencySymbol) ? (string) $__walletTopupCurrencySymbol : '';
$clientSymbol = isset($currency_format_client['symbol']) ? (string) $currency_format_client['symbol'] : '';
$currencySymbol = $currencySymbolInput !== '' ? $currencySymbolInput : $clientSymbol;
$currencyFormatSettings = isset($currencyFormatSettings)
    ? $currencyFormatSettings
    : ($GLOBALS['currencyFormatSettings'] ?? ($GLOBALS['currency_format_settings'] ?? []));
// Only normalize when raw site data is provided; if already normalized (has 'position'), keep as-is.
if (!is_array($currencyFormatSettings) || !isset($currencyFormatSettings['position'])) {
    $currencyFormatSettings = dz_currency_normalize_settings((array) $currencyFormatSettings);
}

$resolveSymbol = static function (string $code, ?string $preferred = null) use ($currenciesMap, $currency_format_client): string {
    $code = strtoupper(trim($code));
    $candidate = trim((string) ($preferred ?? ''));
    if ($candidate !== '' && $candidate !== $code && mb_strlen($candidate) <= 4) {
        return $candidate;
    }
    $symbolsMap = [];
    if (isset($currency_format_client['symbols']) && is_array($currency_format_client['symbols'])) {
        $symbolsMap = $currency_format_client['symbols'];
    }
    if (isset($symbolsMap[$code]) && is_string($symbolsMap[$code])) {
        $symbolVal = trim((string) $symbolsMap[$code]);
        if ($symbolVal !== '' && mb_strlen($symbolVal) <= 4) {
            return $symbolVal;
        }
    }
    if (isset($currency_format_client['symbol'])) {
        $symbolVal = trim((string) $currency_format_client['symbol']);
        if ($symbolVal !== '' && $symbolVal !== $code && mb_strlen($symbolVal) <= 4) {
            return $symbolVal;
        }
    }
    if (isset($currenciesMap[$code])) {
        $symbolVal = trim((string) $currenciesMap[$code]);
        if ($symbolVal !== '' && mb_strlen($symbolVal) <= 4) {
            return $symbolVal;
        }
    }
    return $code;
};

$currencySymbol = $resolveSymbol($currencyCode, $currencySymbol);
$currencyPrecision = dz_currency_resolve_precision($currencyCode, $currencyFormatSettings['decimal_places'] ?? 2);
$initialProvider = reset($providers);
$initialPrecision = $currencyPrecision;
$initialCurrencySymbol = $currencySymbol;
$initialCurrencyCode = $currencyCode;
if (($currencySymbol === '') || ($currencySymbol === $currencyCode) || mb_strlen($currencySymbol) > 4) {
    if (isset($currenciesMap[$currencyCode])) {
        $currencySymbol = (string) $currenciesMap[$currencyCode];
    }
}
if ($currencySymbol === '') {
    $currencySymbol = $currencyCode;
}

if ($initialProvider !== false) {
    $initialProviderKey = strtolower((string) $initialProvider);
    $initialCurrency = strtoupper((string) ($providerCurrencies[$initialProviderKey] ?? $currencyCode));
    $initialPrecision = dz_currency_resolve_precision($initialCurrency, $currencyFormatSettings['decimal_places'] ?? 2);
    $initialCurrencyCode = $initialCurrency;
    $initialCurrencySymbol = $resolveSymbol($initialCurrency, $initialCurrencySymbol);
    if (!is_array($quickAmounts) || empty($quickAmounts)) {
        $quickAmounts = isset($providerQuickAmounts[$initialProviderKey]) ? $providerQuickAmounts[$initialProviderKey] : [];
    }
}
$initialCurrencySymbol = $resolveSymbol($initialCurrencyCode, $initialCurrencySymbol);
$currencyStep = $initialPrecision > 0
    ? ('0.' . str_repeat('0', $initialPrecision - 1) . '1')
    : '1';
$feePercent = isset($__walletTopupFeePercent) ? (float) $__walletTopupFeePercent : 0.0;
$userId = isset($userID) ? (int) $userID : 0;

// Resolve base asset path safely (prevents undefined notices when popup renders standalone)
$popupBaseUrl = isset($base_url) ? (string) $base_url : (isset($GLOBALS['base_url']) ? (string) $GLOBALS['base_url'] : '');
$popupTheme = isset($currentTheme) && $currentTheme !== ''
    ? (string) $currentTheme
    : (isset($GLOBALS['currentTheme']) ? (string) $GLOBALS['currentTheme'] : 'default');
$popupAssetVersion = isset($version) && $version !== ''
    ? (string) $version
    : (defined('APP_VERSION') ? (string) APP_VERSION : '1');
$popupBaseUrl = $popupBaseUrl !== '' ? rtrim($popupBaseUrl, '/') . '/' : '';
$currencyFormatClient = isset($currency_format_client) && is_array($currency_format_client)
    ? $currency_format_client
    : ($GLOBALS['currency_format_client'] ?? dz_currency_settings_for_js($currencyFormatSettings, $currencyCode, $currencySymbol));
$currencyFormatClient['position'] = $currencyFormatSettings['position'] ?? ($currencyFormatClient['position'] ?? 'left');
$currencyFormatClient['decimalPlaces'] = $currencyFormatSettings['decimal_places'] ?? ($currencyFormatClient['decimalPlaces'] ?? 2);
$currencyFormatClient['decimalSep'] = $currencyFormatSettings['decimal_sep'] ?? ($currencyFormatClient['decimalSep'] ?? '.');
$currencyFormatClient['thousandsSep'] = $currencyFormatSettings['thousands_sep'] ?? ($currencyFormatClient['thousandsSep'] ?? ',');
$symbolsMap = [];
if (!empty($currenciesMap)) {
    foreach ($currenciesMap as $code => $sym) {
        if (!is_string($code) || !is_string($sym)) {
            continue;
        }
        $trimmed = trim($sym);
        if ($trimmed === '' || strlen($trimmed) > 4) {
            continue;
        }
        $symbolsMap[strtoupper((string) $code)] = $trimmed;
    }
}
if (!isset($currencyFormatClient['symbols']) && !empty($symbolsMap)) {
    $currencyFormatClient['symbols'] = $symbolsMap;
} elseif (isset($currencyFormatClient['symbols']) && is_array($currencyFormatClient['symbols']) && !empty($symbolsMap)) {
    $currencyFormatClient['symbols'] = $symbolsMap + $currencyFormatClient['symbols'];
}
$resolvedDefaultSymbol = $resolveSymbol($currencyFormatClient['code'] ?? $currencyCode, $currencyFormatClient['symbol'] ?? $currencySymbol);
$currencyFormatClient['symbol'] = $resolvedDefaultSymbol;
if (!isset($currencyFormatClient['symbols'][$currencyCode]) && $resolvedDefaultSymbol !== $currencyCode && mb_strlen($resolvedDefaultSymbol) <= 4) {
    $currencyFormatClient['symbols'][$currencyCode] = $resolvedDefaultSymbol;
}
$currencyFormatJson = htmlspecialchars(
    json_encode($currencyFormatClient, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
    ENT_QUOTES,
    'UTF-8'
);
$walletTopupFormatJson = $currencyFormatJson;

$formatMoney = static function (float $amount, ?string $overrideCode = null, ?string $overrideSymbol = null) use ($currencyCode, $currencySymbol, $currencyFormatSettings): string {
    $code = $overrideCode ?? $currencyCode;
    $symbol = ($overrideSymbol !== null) ? $overrideSymbol : $currencySymbol;
    if ($symbol === '') {
        $symbol = $code;
    }
    return dz_format_currency($amount, $code, $symbol, $currencyFormatSettings ?? null);
};

$zeroDisplay = dz_format_currency(0, $initialCurrencyCode, $initialCurrencySymbol, $currencyFormatSettings ?? null);
$amountPlaceholder = $zeroDisplay;

// Prepare billing defaults (re-use existing variables from inc.php if available)
$billingDefaults = [
    'first_name' => isset($billignDataFirstName) ? (string) $billignDataFirstName : '',
    'last_name'  => isset($billignDataLastName) ? (string) $billignDataLastName : '',
    'country'    => isset($billignDataCountry) ? strtoupper((string) $billignDataCountry) : '',
    'city'       => isset($billignDataCity) ? (string) $billignDataCity : '',
    'state'      => isset($billignDataState) ? (string) $billignDataState : '',
    'postcode'   => isset($billignDataPostCode) ? (string) $billignDataPostCode : '',
    'address'    => isset($billignDataAddress) ? (string) $billignDataAddress : '',
];

// Ensure at least one provider is available; otherwise the modal should not render but guard anyway.
if (empty($providers)) {
    echo '<div class="settings-placeholder">' . customLang('wallet_topup_provider_unavailable') . '</div>';
    return;
}
?>

<div class="popUp-container flex align_items wallet-topup-container">
    <div class="tips popup-wrapper wallet-topup" id="walletTopupModal" role="dialog" aria-modal="true" aria-labelledby="walletTopupTitle">
        <button class="tips-close close_pop" type="button" aria-label="<?php echo customLang('close'); ?>">
            <?php echo render_icon('close', true); ?>
        </button>

        <header class="tips-header">
            <h2 class="tips-title" id="walletTopupTitle"><?php echo customLang('wallet_topup_title', 'Top Up Wallet'); ?></h2>
        </header>

        <div class="wallet-topup-balance" data-wallet-balance-wrapper>
            <span class="wallet-topup-balance-label"><?php echo customLang('wallet_topup_balance_label', 'Wallet balance'); ?></span>
            <span class="wallet-topup-balance-value"
                  data-wallet-balance="<?php echo iN_HelpSecure(number_format($walletBalance, $initialPrecision, '.', '')); ?>"
                  data-wallet-balance-currency="<?php echo iN_HelpSecure($initialCurrencyCode); ?>"
                  data-wallet-balance-symbol="<?php echo iN_HelpSecure($initialCurrencySymbol); ?>"
                  data-wallet-balance-text>
                <?php echo iN_HelpSecure($formatMoney($walletBalance, $initialCurrencyCode, $initialCurrencySymbol)); ?>
            </span>
        </div>

        <div class="wallet-topup-alert" role="status" aria-live="polite" aria-atomic="true"></div>

        <form class="tips-form wallet-topup-form"
              action="#"
              method="post"
              novalidate
              data-form-type="wallet_topup"
              data-min-amount="<?php echo iN_HelpSecure(number_format($minAmount, $currencyPrecision, '.', '')); ?>"
              data-max-amount="<?php echo iN_HelpSecure(number_format($maxAmount, $currencyPrecision, '.', '')); ?>"
              data-currency-code="<?php echo iN_HelpSecure($initialCurrencyCode); ?>"
              data-currency-symbol="<?php echo iN_HelpSecure($initialCurrencySymbol); ?>"
              data-currency-config="<?php echo htmlspecialchars($currencyFormatJson, ENT_QUOTES, 'UTF-8'); ?>"
              data-currency-position="<?php echo iN_HelpSecure($currencyFormatSettings['position'] ?? 'left'); ?>"
              data-decimal-sep="<?php echo iN_HelpSecure($currencyFormatSettings['decimal_sep'] ?? '.'); ?>"
              data-thousands-sep="<?php echo iN_HelpSecure($currencyFormatSettings['thousands_sep'] ?? ','); ?>"
              data-fee-percent="<?php echo iN_HelpSecure((string) $feePercent); ?>"
              data-amount-precision="<?php echo (int) $currencyPrecision; ?>"
              data-provider-mins="<?php echo htmlspecialchars(json_encode($__walletTopupProviderMinimums ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8'); ?>"
              data-provider-quick="<?php echo htmlspecialchars(json_encode($providerQuickAmounts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8'); ?>"
              data-user-id="<?php echo (int) $userId; ?>">

            <div class="tips-field">
                <label class="tips-label" for="walletTopupAmount"><?php echo customLang('pay_amount_label'); ?></label>
                <input name="amount" id="walletTopupAmount" class="tips-input wallet-topup-input" type="text"
                       placeholder="<?php echo iN_HelpSecure($amountPlaceholder); ?>"
                       data-placeholder-template="<?php echo iN_HelpSecure(customLang('wallet_topup_amount_placeholder', '0.00 {currency}')); ?>"
                       inputmode="decimal" autocomplete="off"
                       data-min="<?php echo iN_HelpSecure(number_format($minAmount, $currencyPrecision, '.', '')); ?>"
                       data-max="<?php echo iN_HelpSecure(number_format($maxAmount, $currencyPrecision, '.', '')); ?>" />
            </div>

    <div class="wallet-topup-quick<?php echo empty($quickAmounts) ? ' is-disabled' : ''; ?>"
         aria-label="<?php echo customLang('wallet_topup_quick_label', 'Quick amounts'); ?>"
         <?php echo empty($quickAmounts) ? 'hidden="hidden" aria-hidden="true"' : ''; ?>>
        <span class="wallet-topup-quick-label"><?php echo customLang('wallet_topup_quick_label', 'Quick amounts'); ?></span>
        <div class="wallet-topup-quick-chips" role="group" aria-label="<?php echo customLang('wallet_topup_quick_label', 'Quick amounts'); ?>">
            <?php if (!empty($quickAmounts)) :
                $firstChip = true;
                foreach ($quickAmounts as $chipAmount) :
                    $displayAmount = $formatMoney($chipAmount, $initialCurrencyCode, $initialCurrencySymbol);
                    $chipValue = number_format($chipAmount, $initialPrecision, '.', '');
                    $isActive = $firstChip;
                    $firstChip = false;
                    ?>
                    <button type="button"
                            class="wallet-topup-chip<?php echo $isActive ? ' is-active' : ''; ?>"
                            data-amount="<?php echo iN_HelpSecure($chipValue); ?>"
                            aria-pressed="<?php echo $isActive ? 'true' : 'false'; ?>">
                        <?php echo iN_HelpSecure($displayAmount); ?>
                    </button>
                <?php endforeach;
            endif; ?>
        </div>
    </div>

            <div class="wallet-topup-providers">
                <div class="tips-section-title"><?php echo customLang('pay_method_title'); ?></div>
                <div class="provider_list full-width flex align_items column-gap">
                    <?php
                    $firstProvider = true;
                    foreach ($providers as $providerKey) :
                        $providerKey = strtolower((string) $providerKey);
                        $currencyForProvider = strtoupper((string) ($providerCurrencies[$providerKey] ?? $currencyCode));
                        $symbolForProvider = '';
                        if (isset($currenciesMap[$currencyForProvider])) {
                            $symbolForProvider = (string) $currenciesMap[$currencyForProvider];
                        } else {
                            $symbolForProvider = $currencySymbol !== '' ? $currencySymbol : $currencyForProvider;
                        }
                        $labelKeyMap = [
                            'stripe'      => 'pay_provider_stripe',
                            'paypal'      => 'pay_provider_paypal',
                            'nowpayments' => 'pay_provider_nowpayments',
                            'coinbase'    => 'pay_provider_coinbase',
                            'flutterwave' => 'pay_provider_flutterwave',
                            'iyzico'      => 'pay_provider_iyzico',
                            'payu'        => 'pay_provider_payu',
                        ];
                        if (!isset($labelKeyMap[$providerKey])) {
                            continue;
                        }
                        $checked = $firstProvider ? 'checked' : '';
                        $firstProvider = false;
                        ?>
                        <label class="provider-item flex align_items column-gap">
                            <input type="radio"
                                   name="wallet_topup_provider"
                                   value="<?php echo iN_HelpSecure($providerKey); ?>"
                                   <?php echo $checked; ?>
                                   data-currency="<?php echo iN_HelpSecure($currencyForProvider); ?>"
                                   data-symbol="<?php echo iN_HelpSecure($symbolForProvider); ?>">
                            <span class="provider-name" data-provider-label="<?php echo iN_HelpSecure($providerKey); ?>">
                                <?php echo customLang($labelKeyMap[$providerKey]); ?>
                            </span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <p class="tips-note wallet-topup-note">
                <?php echo customLang('pay_note_redirect_info'); ?>
            </p>

            <div class="tips-actions">
                <button type="submit" class="tips-cta wallet-topup-submit"><?php echo customLang('wallet_topup_submit', customLang('pay_continue')); ?></button>
            </div>

            <?php foreach ($billingDefaults as $fieldKey => $fieldValue) : ?>
                <input type="hidden" name="billing_<?php echo iN_HelpSecure($fieldKey); ?>" value="<?php echo iN_HelpSecure($fieldValue); ?>" data-billing-field="<?php echo iN_HelpSecure($fieldKey); ?>">
            <?php endforeach; ?>
            <input type="hidden" name="user_id" value="<?php echo (int) $userId; ?>">
        </form>
    </div>
    <script defer src="<?php echo iN_HelpSecure($popupBaseUrl); ?>themes/<?php echo iN_HelpSecure($popupTheme); ?>/js/walletTopupHandler.js?v=<?php echo iN_HelpSecure($popupAssetVersion); ?>"></script>
</div>
