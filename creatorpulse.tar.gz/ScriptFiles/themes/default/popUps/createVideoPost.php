<?php
declare(strict_types=1);

$creatorStatusRaw = isset($creatorStatus) ? strtolower((string) $creatorStatus) : 'none';
$isCreatorUser = in_array($creatorStatusRaw, ['approved', 'open', 'active'], true);
$paymentsActive = !empty($hasActivePaymentProviders);

$baseForLinks = isset($base_url) ? (string) $base_url : '';
$creatorSettingsUrl = $baseForLinks !== ''
    ? rtrim($baseForLinks, '/') . '/settings?tab=creator_identity'
    : 'settings?tab=creator_identity';

$creatorGuardMessage = customLang('post_visibility_creator_required', 'Only approved creators can share subscriber or paywalled posts. Become a creator to unlock these options.');
if (!is_string($creatorGuardMessage) || $creatorGuardMessage === '') {
    $creatorGuardMessage = 'Only approved creators can share subscriber or paywalled posts. Become a creator to unlock these options.';
}
$creatorGuardAction = customLang('post_visibility_open_creator', 'Become a creator');
if (!is_string($creatorGuardAction) || $creatorGuardAction === '') {
    $creatorGuardAction = 'Become a creator';
}
$paymentsGuardMessage = customLang('post_visibility_payments_disabled', 'Payment methods are currently being improved. Please try again later.');
if (!is_string($paymentsGuardMessage) || $paymentsGuardMessage === '') {
    $paymentsGuardMessage = 'Payment methods are currently being improved. Please try again later.';
}
$paymentsGuardAction = customLang('ui_ok', 'OK');
if (!is_string($paymentsGuardAction) || $paymentsGuardAction === '') {
    $paymentsGuardAction = 'OK';
}
$guardCancelLabel = customLang('menu_cancel', 'Cancel');
if (!is_string($guardCancelLabel) || $guardCancelLabel === '') {
    $guardCancelLabel = 'Cancel';
}
$uploadProcessingNotice = customLang(
    'upload_processing_notice',
    'Upload complete. Video is being checked and processed, this may take a moment. Please wait.'
);
if (!is_string($uploadProcessingNotice) || $uploadProcessingNotice === '') {
    $uploadProcessingNotice = 'Upload complete. Video is being checked and processed, this may take a moment. Please wait.';
}
if (empty($enableVideoPosts)) {
    echo '<div class="popUp-container flex align_items_justify_content"><div class="popup-wrapper create_post flex align_items_justify_content flexBoxColumn"><div class="notice small">' . iN_HelpSecure(customLang('content_disabled_videos')) . '</div></div></div>';
    return;
}
?>
<!----->
<div
    class="popUp-container flex align_items_justify_content"
    data-is-creator="<?php echo $isCreatorUser ? '1' : '0'; ?>"
    data-payments-active="<?php echo $paymentsActive ? '1' : '0'; ?>"
    data-creator-url="<?php echo iN_HelpSecure($creatorSettingsUrl); ?>"
    data-creator-message="<?php echo iN_HelpSecure($creatorGuardMessage); ?>"
    data-creator-action="<?php echo iN_HelpSecure($creatorGuardAction); ?>"
    data-payments-message="<?php echo iN_HelpSecure($paymentsGuardMessage); ?>"
    data-payments-action="<?php echo iN_HelpSecure($paymentsGuardAction); ?>"
    data-guard-cancel="<?php echo iN_HelpSecure($guardCancelLabel); ?>"
>
    <!----->
    <div class="popup-wrapper flex flexBoxColumn align_items">
        <!---->
        <div class="click_box_header flex align_items_justify_content">
            <button id="goBack" class="goBack flex align_items none">
                <?php echo customLang('nav_back'); ?>
            </button>
            <div class="full-width flex align_items_justify_content"><?php echo customLang('createpost_create'); ?></div>
            <button id="goNext" class="goNext flex align_items none">
                <?php echo customLang('nav_next'); ?>
            </button>

            <span id="uploadBtn" class="finishPost flex align_items none">
                <?php echo customLang('nav_share'); ?>
            </span>
            <button type="button" class="close_pop flex align_items"><?php echo customLang('close'); ?></button>
        </div>
        <!---->
        <!---->
        <div class="arrow"></div>
        <div class="create_media_box flex flexBoxColumn align_items_justify_content">
            <div class="flex align_items_justify_content icon_upload"><?php echo render_icon('video', true); ?></div>
            <div class="upload-text"><?php echo customLang('upload_video'); ?></div>
            <label class="upload-btn flex align_items" for="fileInput"><?php echo customLang('select_video_from_device');?></label>
            <input type="file" id="fileInput" class="none" multiple />
        </div>
        <!---->
        <!---->
        <div class="set_video_container flex align_items none">

        </div>
        <template id="ve-upload-progress-template">
            <div class="ve-upload-progress-stack none" aria-live="polite">
                <div class="ve-upload-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
                    <span class="ve-upload-progress-fill" style="width:0%;"></span>
                </div>
                <div class="ve-upload-progress-percent">0%</div>
                <p class="ve-upload-processing-notice none"><?php echo iN_HelpSecure($uploadProcessingNotice); ?></p>
            </div>
        </template>
        <!---->
        <!---->
        <div class="finish_video_container flex align_items flexBoxColumn none">
        <!---->
        <!---->
            <div class="post-title flex align_items">
                <input type="text" name="post_title" class="create_title full-width" maxlength="255" placeholder="<?php echo customLang('post_title_placeholder', 'Add a title (optional)'); ?>">
            </div>
            <div class="post-text flex align_items">
                <textarea name="post_text" class="create_text full-width" placeholder="<?php echo customLang('post_placeholder');?>"></textarea>
            </div>
            <div class="advanced_settings_box full-width relative flex align_items flexBoxColumn">
                <div class="full-width post-settings-title"><?php echo customLang('post_advanced_settings');?></div>
                <!---->
                <div class="full-width gap flex align_items flexBoxColumn">
                <div class="full-width flex align_items">
                    <div class="advanced_settings_title flex align_items">
                    <?php echo customLang('post_visibility_title');?>
                    </div>
                </div>
                <div class="relative column-gap full-width flex align_items visibility-options">
                    <!---->
                    <div class="post-visiblity flex align_items column-gap active" data-type="everyone">
                    <div class="svg_ flex align_items"><?php echo render_icon('world', true); ?></div>
                    <?php echo customLang('visibility_everyone');?>
                    </div>
                    <!---->
                    <!---->
                    <div class="post-visiblity flex align_items column-gap" data-type="followers">
                    <div class="svg_ flex align_items"><?php echo render_icon('follower', true); ?></div>
                    <?php echo customLang('visibility_followers');?>
                    </div>
                    <!---->
                    <!---->
                    <div class="post-visiblity flex align_items column-gap" data-type="subscribers">
                    <div class="svg_ flex align_items"><?php echo render_icon('subscriber', true); ?></div>
                    <?php echo customLang('visibility_subscribers');?>
                    </div>
                    <!---->
                    <!---->
                    <div class="post-visiblity flex align_items column-gap" data-type="locked">
                    <div class="svg_ flex align_items"><?php echo render_icon('locked', true); ?></div>
                    <?php echo customLang('visibility_paid');?> <span class="post-price flex align_items">($)</span>
                    </div>
                    <!---->

                </div>
                </div>
                <div class="full-width gap flex align_items flexBoxColumn video-teaser-field none" data-video-teaser>
                    <div class="full-width flex align_items setting-row">
                        <div class="advanced_settings_title flex align_items">
                        <?php echo customLang('video_teaser_label'); ?>
                        </div>
                    </div>
                    <div class="advanced_settings_description full-width flex align_items"><?php echo customLang('video_teaser_hint'); ?></div>
                    <label class="upload-btn flex align_items" for="videoTeaserInput">
                        <?php echo customLang('video_teaser_optional'); ?>
                    </label>
                    <input type="file" id="videoTeaserInput" name="video_teaser" accept="video/*" class="none" />
                    <div class="video-teaser-filename"></div>
                </div>
                <!---->
                <!---->
                <div class="full-width gap flex align_items flexBoxColumn">
                <div class="full-width flex align_items setting-row">
                    <div class="advanced_settings_title flex align_items">
                    <?php echo customLang('post_hide_likes_views');?>
                    </div>
                    <div class="advanced_sttings_switch flex align_items">
                    <label class="el-switch el-switch-sm">
                        <input type="checkbox" id="hide_likes_view" name="hide_likes_view" value="on">
                        <span class="el-switch-style"></span>
                    </label>
                    </div>
                </div>
                <div class="advanced_settings_description full-width flex align_items"><?php echo customLang('post_hide_likes_views_desc');?></div>
                </div>
                <!---->
                <!---->
                <div class="full-width gap flex align_items flexBoxColumn">
                <div class="full-width flex align_items setting-row">
                    <div class="advanced_settings_title flex align_items">
                    <?php echo customLang('post_turn_off_commenting');?>
                    </div>
                    <div class="advanced_sttings_switch flex align_items">
                    <label class="el-switch el-switch-sm">
                        <input type="checkbox" id="turn_on_off_comment" name="turn_on_off_comment" value="on">
                        <span class="el-switch-style"></span>
                    </label>
                    </div>
                </div>
                <div class="advanced_settings_description full-width flex align_items"><?php echo customLang('post_turn_off_commenting_desc');?></div>
                </div>
                <!---->
                <input type="hidden" name="post_type" value="everyone">
                <input type="hidden" name="min-price" value="<?php echo iN_HelpSecure($premiumPostPriceMinimum );?>">
                <input type="hidden" name="max-price" value="<?php echo iN_HelpSecure($premiumPostPriceMaximum );?>">
            </div>
        <!---->
        <!--Set Price PopUp-->
        <div class="set-price-popup flex align_items_justify_content none">
            <div class="set-price-popup-container relative flex align_items flexBoxColumn">
                <div class="set-price-popup-title flex align_items"><?php echo customLang('set_post_price');?></div>
                <div class="arrow"></div>
                <div class="set-price-container gap full-width flex align_items flexBoxColumn">
                <div class="advanced_settings_description full-width flex align_items"><?php echo customLang('ppv_locked_notice');?></div>
                <div class="set-price-area flex align_items relative">
                    <div class="price_svg flex align_items"><?php echo render_icon('locked', true); ?></div>
                    <input type="number" name="set-price" class="set-price" placeholder="<?php echo customLang('write_price');?>">
                </div>
                <div class="advanced_settings_description full-width flex align_items warn"><?php echo customLang('price_range_error');?></div>
                </div>
                <div class="arrow"></div>
                <!---->
                <div class="set-price-footer full-width flex align_items">
                <div class="set-price-clear flex align_items"><?php echo customLang('clear');?></div>
                <div class="set-price-done flex align_items"><?php echo customLang('save');?></div>
                </div>
                <!---->
            </div>
        </div>
        <!--/Set Price PopUp-->
        <!---->
        </div>
        <!---->
    </div>
    <!----->
<script defer src="<?php echo iN_HelpSecure($base_url);?>themes/<?php echo iN_HelpSecure($currentTheme);?>/js/videoEdit.js?v=<?php echo iN_HelpSecure($version);?>"></script>
</div>
