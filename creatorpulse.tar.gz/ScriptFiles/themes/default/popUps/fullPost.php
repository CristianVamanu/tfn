<?php
$viewMode = 'full';
//include __DIR__ . '/../layouts/post_view.php';
$currentPostId = isset($postIdParam) ? (int) $postIdParam : 0;
if ($currentPostId <= 0) {
    echo '<!-- Invalid post id -->';
    return;
}
?>
<div class="post-close flex align_items"><?php echo render_icon('close', true); ?></div>
<div class="nav-buttons flex align_items flexBoxColumn" aria-label="Post navigation">
    <button type="button" class="post-nav post-nav-prev flex align_items" aria-label="Previous (Up)" data-dir="prev">
        <span class="icon-arrow-up flex align_items" aria-hidden="true"><?php echo render_icon('up_arrow', true); ?></span>
    </button>
    <button type="button" class="post-nav post-nav-next flex align_items" aria-label="Next (Down)" data-dir="next">
        <span class="icon-arrow-down flex align_items" aria-hidden="true"><?php echo render_icon('down_arrow', true); ?></span>
    </button>
</div>
<?php
// Change content in a single place:
?>
<div class="full-post-inner" data-post-id="<?php echo (int) $postIdParam; ?>">
    <?php
    // Render only the post body here (layout, comments, etc.)
    // Example: include __DIR__ . '/../layouts/post_view.php';
    include __DIR__ . '/../layouts/post_view.php';
    ?>
</div>
