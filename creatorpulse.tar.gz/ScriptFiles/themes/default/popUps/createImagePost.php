<?php
declare(strict_types=1);

$creatorStatusRaw = isset($creatorStatus) ? strtolower((string) $creatorStatus) : 'none';
$isCreatorUser = in_array($creatorStatusRaw, ['approved', 'open', 'active'], true);
$paymentsActive = !empty($hasActivePaymentProviders);

$baseForLinks = isset($base_url) ? (string) $base_url : '';
$creatorSettingsUrl = $baseForLinks !== ''
    ? rtrim($baseForLinks, '/') . '/settings?tab=creator_identity'
    : 'settings?tab=creator_identity';

$creatorGuardMessage = customLang('post_visibility_creator_required', 'Only approved creators can share subscriber or paywalled posts. Become a creator to unlock these options.');
if (!is_string($creatorGuardMessage) || $creatorGuardMessage === '') {
    $creatorGuardMessage = 'Only approved creators can share subscriber or paywalled posts. Become a creator to unlock these options.';
}
$creatorGuardAction = customLang('post_visibility_open_creator', 'Become a creator');
if (!is_string($creatorGuardAction) || $creatorGuardAction === '') {
    $creatorGuardAction = 'Become a creator';
}
$paymentsGuardMessage = customLang('post_visibility_payments_disabled', 'Payment methods are currently being improved. Please try again later.');
if (!is_string($paymentsGuardMessage) || $paymentsGuardMessage === '') {
    $paymentsGuardMessage = 'Payment methods are currently being improved. Please try again later.';
}
$paymentsGuardAction = customLang('ui_ok', 'OK');
if (!is_string($paymentsGuardAction) || $paymentsGuardAction === '') {
    $paymentsGuardAction = 'OK';
}
$guardCancelLabel = customLang('menu_cancel', 'Cancel');
if (!is_string($guardCancelLabel) || $guardCancelLabel === '') {
    $guardCancelLabel = 'Cancel';
}
if (empty($enableImagePosts)) {
    echo '<div class="popUp-container flex align_items_justify_content"><div class="popup-wrapper create_post flex align_items_justify_content flexBoxColumn"><div class="notice small">' . iN_HelpSecure(customLang('content_disabled_images')) . '</div></div></div>';
    return;
}
?>
<!----->
<div
  class="popUp-container flex align_items_justify_content"
  data-is-creator="<?php echo $isCreatorUser ? '1' : '0'; ?>"
  data-payments-active="<?php echo $paymentsActive ? '1' : '0'; ?>"
  data-creator-url="<?php echo iN_HelpSecure($creatorSettingsUrl); ?>"
  data-creator-message="<?php echo iN_HelpSecure($creatorGuardMessage); ?>"
  data-creator-action="<?php echo iN_HelpSecure($creatorGuardAction); ?>"
  data-payments-message="<?php echo iN_HelpSecure($paymentsGuardMessage); ?>"
  data-payments-action="<?php echo iN_HelpSecure($paymentsGuardAction); ?>"
  data-guard-cancel="<?php echo iN_HelpSecure($guardCancelLabel); ?>"
>
  <!----->
  <div class="popup-wrapper flex flexBoxColumn align_items">
    <!---->
    <div class="click_box_header flex align_items_justify_content">
      <button id="goBack" class="goBack flex align_items none">
        <?php echo customLang('nav_back'); ?>
      </button>
      <div class="full-width flex align_items_justify_content"><?php echo customLang('createpost_create'); ?></div>
      <button id="goNext" class="goNext flex align_items none">
        <?php echo customLang('nav_next'); ?>
      </button>

      <span id="uploadBtn" class="finishPost flex align_items none">
        <?php echo customLang('nav_share'); ?>
      </span>
      <button type="button" class="close_pop flex align_items"><?php echo customLang('close'); ?></button>
    </div>
    <!---->
    <div class="arrow"></div>
    <div class="create_media_box flex flexBoxColumn align_items_justify_content">
          <div class="flex align_items_justify_content icon_upload"><?php echo render_icon('image', true); ?></div>
          <div class="upload-text"><?php echo customLang('upload_photos'); ?></div>
          <label class="upload-btn flex align_items" for="imageFileInput"><?php echo customLang('select_images_from_device');?></label>
          <input type="file" id="imageFileInput" class="none" multiple />
    </div>
    <!---->
    <div class="crop-container flex align_items">
      <div class="crop-frame">
            <div class="crop_setting_buttons flex align_items_justify_content flexBoxColumn">
            <!---->
            <div class="filter-container flex flexBoxColumn">
              <div class="open-filters flex align_items_justify_content"><?php echo render_icon('filters', false); ?></div>
              <div class="filter-wrapper">
                <div class="filter-buttons flex flexBoxColumn flex_start">
                  <button class="filter-btn" data-filter="none"><?php echo customLang('filter_original');;?></button>
                  <button class="filter-btn" data-filter="moon"><?php echo customLang('filter_moon');;?></button>
                  <button class="filter-btn" data-filter="gingham"><?php echo customLang('filter_gingham');;?></button>
                  <button class="filter-btn" data-filter="reyes"><?php echo customLang('filter_reyes');;?></button>
                  <button class="filter-btn" data-filter="sepia"><?php echo customLang('filter_sepia');;?></button>
                  <button class="filter-btn" data-filter="invert"><?php echo customLang('filter_invert');;?></button>
                  <button class="filter-btn" data-filter="brighten"><?php echo customLang('filter_brighten');;?></button>
                  <button class="filter-btn" data-filter="contrast"><?php echo customLang('filter_contrast_plus');;?></button>
                </div>
              </div>
            </div>
            <!---->
            <!---->
            <div class="original_view flex align_items_justify_content ">
              <button class="flex align_items_justify_content"  id="originalView"><?php echo render_icon('original_view', true); ?></button>
            </div>
            <!---->
            <!---->
              <div class="restove_view flex align_items_justify_content ">
                <button class="flex align_items_justify_content"  id="restorePreviousView"><?php echo render_icon('back', true); ?></button>
              </div>
            <!---->
            </div>
            <!---->
            <div class="fileInputMore flex align_items_justify_content flexBoxColumn">
              <label class="add-more-btn flex align_items" for="fileInputMore">
                <?php echo render_icon('plus_image', true); ?>
              </label>
              <input type="file" id="fileInputMore" class="none" multiple />
            </div>
            <!---->
              <div class="grid-overlay none"></div>
              <div class="crop-images-wrapper">

              </div>
              <div class="crop-controls">
                <input type="range" id="zoom" min="1" max="3" step="0.01" value="1" />
              </div>
              <button class="prev_button flex align_items_justify_content" id="prev"><?php echo render_icon('prev', false); ?></button>
              <button class="next_button flex align_items_justify_content" id="next"><?php echo render_icon('next', false); ?></button>
        </div>
      </div>
      <!---->
    <div class="crop-finish-and-post flex align_items flexBoxColumn none">
      <div class="post-title flex align_items">
        <input type="text" name="post_title" class="create_title full-width" maxlength="255" placeholder="<?php echo customLang('post_title_placeholder', 'Add a title (optional)'); ?>">
      </div>
      <div class="post-text flex align_items">
        <textarea name="post_text" class="create_text full-width" placeholder="<?php echo customLang('post_placeholder');?>"></textarea>
      </div>
      <div class="advanced_settings_box full-width relative flex align_items flexBoxColumn">
        <div class="full-width post-settings-title"><?php echo customLang('post_advanced_settings');?></div>
        <!---->
        <div class="full-width gap flex align_items flexBoxColumn">
          <div class="full-width flex align_items">
            <div class="advanced_settings_title flex align_items">
              <?php echo customLang('post_visibility_title');?>
            </div>
          </div>
          <div class="relative column-gap full-width flex align_items visibility-options">
            <!---->
            <div class="post-visiblity flex align_items column-gap active" data-type="everyone">
              <div class="svg_ flex align_items"><?php echo render_icon('world', true); ?></div>
              <?php echo customLang('visibility_everyone');?>
            </div>
            <!---->
            <!---->
            <div class="post-visiblity flex align_items column-gap" data-type="followers">
              <div class="svg_ flex align_items"><?php echo render_icon('follower', true); ?></div>
              <?php echo customLang('visibility_followers');?>
            </div>
            <!---->
            <!---->
            <div class="post-visiblity flex align_items column-gap" data-type="subscribers">
              <div class="svg_ flex align_items"><?php echo render_icon('subscriber', true); ?></div>
              <?php echo customLang('visibility_subscribers');?>
            </div>
            <!---->
            <!---->
            <div class="post-visiblity flex align_items column-gap" data-type="locked">
              <div class="svg_ flex align_items"><?php echo render_icon('locked', true); ?></div>
              <?php echo customLang('visibility_paid');?> <span class="post-price flex align_items">($)</span>
            </div>
            <!---->

          </div>
        </div>
        <!---->
        <!---->
        <div class="full-width gap flex align_items flexBoxColumn">
          <div class="full-width flex align_items setting-row">
            <div class="advanced_settings_title flex align_items">
              <?php echo customLang('post_hide_likes_views');?>
            </div>
            <div class="advanced_sttings_switch flex align_items">
              <label class="el-switch el-switch-sm">
                <input type="checkbox" id="hide_likes_view" name="hide_likes_view" value="on">
                <span class="el-switch-style"></span>
              </label>
            </div>
          </div>
          <div class="advanced_settings_description full-width flex align_items"><?php echo customLang('post_hide_likes_views_desc');?></div>
        </div>
        <!---->
        <!---->
        <div class="full-width gap flex align_items flexBoxColumn">
          <div class="full-width flex align_items setting-row">
            <div class="advanced_settings_title flex align_items">
              <?php echo customLang('post_turn_off_commenting');?>
            </div>
            <div class="advanced_sttings_switch flex align_items">
              <label class="el-switch el-switch-sm">
                <input type="checkbox" id="turn_on_off_comment" name="turn_on_off_comment" value="on">
                <span class="el-switch-style"></span>
              </label>
            </div>
          </div>
          <div class="advanced_settings_description full-width flex align_items"><?php echo customLang('post_turn_off_commenting_desc');?></div>
        </div>
        <!---->
        <input type="hidden" name="post_type" value="everyone">
        <input type="hidden" name="min-price" value="<?php echo iN_HelpSecure($premiumPostPriceMinimum );?>">
        <input type="hidden" name="max-price" value="<?php echo iN_HelpSecure($premiumPostPriceMaximum );?>">
      </div>
    </div>
    <!---->
    <!--Set Price PopUp-->
    <div class="set-price-popup flex align_items_justify_content none">
      <div class="set-price-popup-container relative flex align_items flexBoxColumn">
        <div class="set-price-popup-title flex align_items"><?php echo customLang('set_post_price');?></div>
        <div class="arrow"></div>
        <div class="set-price-container gap full-width flex align_items flexBoxColumn">
          <div class="advanced_settings_description full-width flex align_items"><?php echo customLang('ppv_locked_notice');?></div>
          <div class="set-price-area flex align_items relative">
            <div class="price_svg flex align_items"><?php echo render_icon('locked', true); ?></div>
            <input type="number" name="set-price" class="set-price" placeholder="<?php echo customLang('write_price');?>">
          </div>
          <div class="advanced_settings_description full-width flex align_items warn"><?php echo customLang('price_range_error');?></div>
        </div>
        <div class="arrow"></div>
        <!---->
        <div class="set-price-footer full-width flex align_items">
          <div class="set-price-clear flex align_items"><?php echo customLang('clear');?></div>
          <div class="set-price-done flex align_items"><?php echo customLang('save');?></div>
        </div>
        <!---->
      </div>
    </div>
    <!--/Set Price PopUp-->
    </div>
    <!---->
    <script src="<?php echo iN_HelpSecure($base_url);?>themes/<?php echo iN_HelpSecure($currentTheme);?>/js/crop.js?v=<?php echo iN_HelpSecure($version);?>"></script>
  </div>
</div>
<!----->
