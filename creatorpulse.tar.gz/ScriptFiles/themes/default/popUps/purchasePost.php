<?php
// Expected: $postData, $postOwnerID, $userDetails, $currency, $paymentFeePercent, $paymentFeeFixed, $paymentTaxPercent
$recipient      = isset($userDetails) && is_array($userDetails) ? $userDetails : [];
$recipientId    = isset($postOwnerID) ? (int)$postOwnerID : (int)($postData['post_owner_id'] ?? 0);
$recipientName  = trim((string)($recipient['user_fullname'] ?? $recipient['username'] ?? ''));
$recipientUser  = (string)($recipient['username'] ?? '');
$recipientAvatarRel = isset($RL) ? (string)$RL->RL_userAvatar($recipientId) : '';
if (function_exists('storage_resolve_media_url')) {
    $recipientAvatar = storage_resolve_media_url($recipientAvatarRel, $base_url ?? '');
} else {
    $recipientAvatar = (string)($base_url ?? '') . ltrim($recipientAvatarRel, '/');
}

$buyer          = isset($userData) && is_array($userData) ? $userData : [];
$buyerName      = trim((string)($buyer['user_fullname'] ?? $buyer['username'] ?? ''));
$buyerUser      = (string)($buyer['username'] ?? '');
$buyerEmail     = (string)($buyer['contact_email'] ?? $buyer['user_email'] ?? '');

// Provider currencies come from inc.php: $globalCurCode, $stripeCurCode, $paypalCurCode, $nowpayCurCode, $coinbaseCurCode
$currencies = isset($currencies) && is_array($currencies)
    ? $currencies
    : ((isset($currencys) && is_array($currencys)) ? $currencys : []);
$globalCurCodeRaw = $globalCurCode ?? ($currency ?? 'USD');
if (!is_string($globalCurCodeRaw)) {
    $globalCurCodeRaw = (string) $globalCurCodeRaw;
}
if ($globalCurCodeRaw === '') {
    $globalCurCodeRaw = 'USD';
}
$globalCurCode = strtoupper($globalCurCodeRaw);
$stripeCurCode   = isset($stripeCurCode) && $stripeCurCode !== '' ? (string) $stripeCurCode : $globalCurCode;
$paypalCurCode   = isset($paypalCurCode) && $paypalCurCode !== '' ? (string) $paypalCurCode : $globalCurCode;
$nowpayCurCode   = isset($nowpayCurCode) && $nowpayCurCode !== '' ? (string) $nowpayCurCode : $globalCurCode;
$coinbaseCurCode = isset($coinbaseCurCode) && $coinbaseCurCode !== '' ? (string) $coinbaseCurCode : $globalCurCode;
$paystackCurCode = isset($paystackCurCode) && $paystackCurCode !== '' ? (string) $paystackCurCode : $globalCurCode;
$iyzicoCurCode   = isset($iyzicoCurCode) && $iyzicoCurCode !== '' ? (string) $iyzicoCurCode : $globalCurCode;
$payuCurCode     = isset($payuCurCode) && $payuCurCode !== '' ? (string) $payuCurCode : $globalCurCode;

$defaultProvider = null;
if (!empty($enableStripe))      { $defaultProvider = 'stripe'; }
elseif (!empty($enablePaypal))  { $defaultProvider = 'paypal'; }
elseif (!empty($enablePayu)) { $defaultProvider = 'payu'; }
elseif (!empty($enablePaystack)) { $defaultProvider = 'paystack'; }
elseif (!empty($enableIyziCo)) { $defaultProvider = 'iyzico'; }
elseif (!empty($enableFlutterwave)) { $defaultProvider = 'flutterwave'; }
elseif (!empty($enableNowpayments)) { $defaultProvider = 'nowpayments'; }
elseif (!empty($enableCoinbase))    { $defaultProvider = 'coinbase'; }
else { $defaultProvider = 'wallet'; }

switch ($defaultProvider) {
  case 'stripe':      $curCode = $stripeCurCode; break;
  case 'paypal':      $curCode = $paypalCurCode; break;
  case 'payu':        $curCode = $payuCurCode; break;
  case 'paystack':    $curCode = $paystackCurCode; break;
  case 'iyzico':      $curCode = $iyzicoCurCode; break;
  case 'flutterwave': $curCode = $flutterwaveCurCode ?? $globalCurCode; break;
  case 'nowpayments': $curCode = $nowpayCurCode; break;
  case 'coinbase':    $curCode = $coinbaseCurCode; break;
  default:            $curCode = $globalCurCode; break;
}

$currencyFormatSettings = isset($currencyFormatSettings)
    ? $currencyFormatSettings
    : ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
$curSymbolMap = (isset($currencies) && is_array($currencies)) ? $currencies : [];
$curSymbol    = (string) ($curSymbolMap[$curCode] ?? $curCode);
$walletBalanceRaw     = isset($userWallet) ? (float) $userWallet : 0.0;
$walletCurrencyCode   = isset($globalCurCode) ? (string) $globalCurCode : (string) $curCode;
$walletCurrencySymbol = (string) ($curSymbolMap[$walletCurrencyCode] ?? '');
$walletPrecision      = dz_currency_resolve_precision($walletCurrencyCode, $currencyFormatSettings['decimal_places'] ?? 2);
$walletBalanceValue   = number_format($walletBalanceRaw, $walletPrecision, '.', '');
$walletProviderTemplate = customLang('pay_provider_wallet');
$walletProviderLabel    = strtr(
    $walletProviderTemplate,
    ['{balance}' => dz_format_currency($walletBalanceRaw, $walletCurrencyCode, $walletCurrencySymbol, $currencyFormatSettings)]
);
$priceRaw       = isset($postData['post_price']) ? (string) $postData['post_price'] : '0';
if ($priceRaw === '' || !is_numeric($priceRaw)) {
    $priceRaw = '0';
}
$priceAmount    = (float) $priceRaw;
$pricePrecision = dz_currency_resolve_precision($curCode, $currencyFormatSettings['decimal_places'] ?? 2);
$priceDisplay   = dz_format_currency($priceAmount, $curCode, $curSymbol, $currencyFormatSettings);
$priceDataValue = number_format($priceAmount, $pricePrecision, '.', '');
$feePercent     = isset($paymentFeePercent) ? (float) $paymentFeePercent : 0.0;
$feeFixed       = isset($paymentFeeFixed) ? (float) $paymentFeeFixed : 0.0;
$taxPercent     = isset($paymentTaxPercent) ? (float) $paymentTaxPercent : 0.0;
$feeAmount      = ($priceAmount * ($feePercent / 100)) + $feeFixed;
$taxAmount      = $priceAmount * ($taxPercent / 100);
$totalAmount    = $priceAmount + $feeAmount + $taxAmount;
$feeDisplay     = dz_format_currency($feeAmount, $curCode, $curSymbol, $currencyFormatSettings);
$taxDisplay     = dz_format_currency($taxAmount, $curCode, $curSymbol, $currencyFormatSettings);
$totalDisplay   = dz_format_currency($totalAmount, $curCode, $curSymbol, $currencyFormatSettings);
$unlockTemplate = customLang('unlock_not');
$symbolFromMap = (string) ($curSymbolMap[strtoupper($walletCurrencyCode)] ?? '');
$unlockAmount = '';
if ($symbolFromMap !== '') {
    $unlockAmount = dz_format_currency($priceAmount, $walletCurrencyCode, $symbolFromMap, $currencyFormatSettings);
}
if ($unlockAmount === '') {
    $unlockAmount = $priceDisplay;
}
if ($unlockAmount === '') {
    $unlockAmount = $priceDisplay;
}
$unlockTemplate = is_string($unlockTemplate) && $unlockTemplate !== '' && $unlockTemplate !== 'unlock_not'
    ? $unlockTemplate
    : 'Unlock this exclusive post for just {{amount}}.';
$unlockTemplate = str_replace([
    '{{unlockPrice}}{{currency}}',
    '{{unlockPrice}} {{currency}}',
    '{{currency}}{{unlockPrice}}',
    '{{unlockPrice}}',
    '{{currency}}'
], ['{{amount}}', '{{amount}}', '{{amount}}', '{{amount}}', ''], $unlockTemplate);
// collapse any duplicate spaces while preserving punctuation
$unlockTemplate = preg_replace('/\s+/', ' ', $unlockTemplate);
if (strpos($unlockTemplate, '{{amount}}') === false) {
    $unlockTemplate .= ' {{amount}}';
}
$unlockMessageHtml = htmlspecialchars($unlockTemplate, ENT_QUOTES | ENT_HTML5, 'UTF-8');
$unlockMessageHtml = str_replace('{{amount}}', '<span class="tips-price-amount">' . htmlspecialchars($unlockAmount, ENT_QUOTES | ENT_HTML5, 'UTF-8') . '</span>', $unlockMessageHtml);
?>

<div class="popUp-container flex align_items">
  <div class="tips popup-wrapper" id="tipsModal" role="dialog" aria-modal="true" aria-labelledby="tipsTitle">
    <button class="tips-close close_pop" type="button" aria-label="Close">
      <?php echo render_icon('close', true); ?>
    </button>

    <header class="tips-header">
      <h2 class="tips-title" id="tipsTitle"><?php echo customLang('pay_purchase_title'); ?></h2>
    </header>

    <section class="tips-user">
      <div class="tips-avatar">
        <img src="<?php echo iN_HelpSecure($recipientAvatar); ?>" alt="<?php echo iN_HelpSecure($recipientUser); ?>">
      </div>
      <div class="tips-identity">
        <div class="tips-name"><?php echo iN_HelpSecure($recipientName); ?></div>
        <div class="tips-handle">@<?php echo iN_HelpSecure($recipientUser); ?></div>
      </div>
    </section>

    <form class="tips-form" action="#" method="post" novalidate data-form-type="purchase"
          data-fee-percent="<?php echo iN_HelpSecure((string)($paymentFeePercent ?? 0)); ?>"
          data-fee-fixed="<?php echo iN_HelpSecure((string)($paymentFeeFixed ?? 0)); ?>"
          data-tax-percent="<?php echo iN_HelpSecure((string)($paymentTaxPercent ?? 0)); ?>"
          data-currency="<?php echo iN_HelpSecure($curCode); ?>"
          data-currency-symbol="<?php echo iN_HelpSecure($curSymbol); ?>"
          data-amount-precision="<?php echo (int) $pricePrecision; ?>"
          data-fixed-amount="<?php echo iN_HelpSecure($priceDataValue); ?>">
      <!-- Fixed Amount Notice -->
      <div class="tips-field">
        <div class="tips-title-box" aria-readonly="true"><?php echo $unlockMessageHtml; ?></div>
        <input type="hidden"
               id="tipAmount"
               name="amount"
               value="<?php echo iN_HelpSecure($priceDataValue); ?>"
               data-min="<?php echo iN_HelpSecure($priceDataValue); ?>"
               data-max="<?php echo iN_HelpSecure($priceDataValue); ?>"
               data-display="<?php echo iN_HelpSecure($priceDisplay); ?>">
      </div>

      <!-- Billing agreement -->
      <details class="tips-accordion">
        <summary>
          <?php echo customLang('pay_billing_details_title'); ?>
          <img class="icon-16" src="<?php echo iN_HelpSecure($iconPath . 'down_arrow.svg'); ?>" alt="" aria-hidden="true">
        </summary>
        <div class="tips-accordion-body">
          <?php
            $bf = [
              'first_name' => (string)($billignDataFirstName ?? ''),
              'last_name'  => (string)($billignDataLastName ?? ''),
              'country'    => (string)($billignDataCountry ?? ''),
              'city'       => (string)($billignDataCity ?? ''),
              'state'      => (string)($billignDataState ?? ''),
              'postcode'   => (string)($billignDataPostCode ?? ''),
              'address'    => (string)($billignDataAddress ?? ''),
            ];
            $countries = [];
            $countriesFile = __DIR__ . '/../../../includes/helpers/countries.php';
            if (is_file($countriesFile)) { require $countriesFile; }
          ?>
          <div class="buyer-section">
            <div><strong><?php echo customLang('pay_buyer_label'); ?></strong> <?php echo iN_HelpSecure($buyerName); ?> (@<?php echo iN_HelpSecure($buyerUser); ?>)</div>
            <?php if (!empty($buyerEmail)) : ?>
              <div><strong><?php echo customLang('pay_email_label'); ?></strong> <?php echo iN_HelpSecure($buyerEmail); ?></div>
            <?php endif; ?>
          </div>

          <div class="billing-fields grid gap">
            <div class="tips-field">
              <label class="tips-label" for="bill_first_name"><?php echo customLang('pay_first_name_label'); ?></label>
              <input id="bill_first_name" name="billing_first_name" class="tips-input" type="text" value="<?php echo iN_HelpSecure($bf['first_name']); ?>" placeholder="<?php echo customLang('pay_first_name_placeholder'); ?>" autocomplete="given-name" />
            </div>
            <div class="tips-field">
              <label class="tips-label" for="bill_last_name"><?php echo customLang('pay_last_name_label'); ?></label>
              <input id="bill_last_name" name="billing_last_name" class="tips-input" type="text" value="<?php echo iN_HelpSecure($bf['last_name']); ?>" placeholder="<?php echo customLang('pay_last_name_placeholder'); ?>" autocomplete="family-name" />
            </div>
            <div class="tips-field">
              <label class="tips-label" for="bill_country"><?php echo customLang('pay_country_label'); ?></label>
              <select id="bill_country" name="billing_country" class="tips-input">
                <option value=""><?php echo customLang('pay_country_placeholder'); ?></option>
                <?php foreach ($countries as $code => $name): ?>
                  <option value="<?php echo iN_HelpSecure($code); ?>" <?php echo (strtoupper($bf['country']) === $code ? 'selected' : ''); ?>><?php echo iN_HelpSecure($name); ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="tips-field">
              <label class="tips-label" for="bill_city"><?php echo customLang('pay_city_label'); ?></label>
              <input id="bill_city" name="billing_city" class="tips-input" type="text" value="<?php echo iN_HelpSecure($bf['city']); ?>" placeholder="<?php echo customLang('pay_city_placeholder'); ?>" autocomplete="address-level2" />
            </div>
            <div class="tips-field">
              <label class="tips-label" for="bill_state"><?php echo customLang('pay_state_label'); ?></label>
              <input id="bill_state" name="billing_state" class="tips-input" type="text" value="<?php echo iN_HelpSecure($bf['state']); ?>" placeholder="<?php echo customLang('pay_state_placeholder'); ?>" autocomplete="address-level1" />
            </div>
            <div class="tips-field">
              <label class="tips-label" for="bill_postcode"><?php echo customLang('pay_postcode_label'); ?></label>
              <input id="bill_postcode" name="billing_postcode" class="tips-input" type="text" value="<?php echo iN_HelpSecure($bf['postcode']); ?>" placeholder="<?php echo customLang('pay_postcode_placeholder'); ?>" autocomplete="postal-code" />
            </div>
            <div class="tips-field full-span">
              <label class="tips-label" for="bill_address"><?php echo customLang('pay_address_label'); ?></label>
              <textarea id="bill_address" name="billing_address" class="tips-input" rows="3" placeholder="<?php echo customLang('pay_address_placeholder'); ?>" autocomplete="street-address"><?php echo iN_HelpSecure($bf['address']); ?></textarea>
            </div>
          </div>
        </div>
      </details>

      <!-- Payment summary -->
      <div>
        <div class="tips-section-title"><?php echo customLang('pay_summary_title'); ?></div>
        <div class="tips-summary">
          <dl>
            <div class="row"><dt><?php echo customLang('pay_summary_subtotal'); ?></dt><dd><span class="tips-subtotal-amount"><?php echo iN_HelpSecure($priceDisplay); ?></span></dd></div>
            <div class="row"><dt><?php echo customLang('pay_summary_fees'); ?></dt><dd><span class="tips-fee-amount"><?php echo iN_HelpSecure($feeDisplay); ?></span></dd></div>
            <div class="row"><dt><?php echo customLang('pay_summary_taxes'); ?></dt><dd><span class="tips-taxes-amount"><?php echo iN_HelpSecure($taxDisplay); ?></span></dd></div>
            <div class="row"><dt><?php echo customLang('pay_summary_total'); ?></dt><dd><span class="tips-total-amount"><?php echo iN_HelpSecure($totalDisplay); ?></span></dd></div>
          </dl>
        </div>
      </div>

      <!-- Payment methods -->
      <div class="tips-methods">
        <div class="tips-section-title"><?php echo customLang('pay_method_title'); ?></div>
        <div class="provider_list full-width flex align_items column-gap">
          <?php $first = true; ?>
          <?php if (!empty($enableStripe)) : ?>
            <label class="provider-item flex align_items column-gap">
              <input type="radio" name="tip_provider" value="stripe" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($stripeCurCode); ?>">
              <span class="provider-name"><?php echo customLang('pay_provider_stripe'); ?></span>
            </label>
            <?php $first = false; ?>
          <?php endif; ?>
            <?php if (!empty($enablePaypal)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="paypal" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($paypalCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_paypal'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enablePayu)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="payu" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($payuCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_payu'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enablePaystack)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="paystack" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($paystackCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_paystack'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enableIyziCo)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="iyzico" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($iyzicoCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_iyzico'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enableNowpayments)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="nowpayments" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($nowpayCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_nowpayments'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enableFlutterwave)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="flutterwave" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($flutterwaveCurCode ?? $globalCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_flutterwave'); ?></span>
              </label>
              <?php $first = false; ?>
            <?php endif; ?>
            <?php if (!empty($enableCoinbase)) : ?>
              <label class="provider-item flex align_items column-gap">
                <input type="radio" name="tip_provider" value="coinbase" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($coinbaseCurCode); ?>">
                <span class="provider-name"><?php echo customLang('pay_provider_coinbase'); ?></span>
              </label>
            <?php $first = false; ?>
          <?php endif; ?>
          <label class="provider-item flex align_items column-gap">
            <input type="radio" name="tip_provider" value="wallet" <?php echo $first ? 'checked' : ''; ?> data-currency="<?php echo iN_HelpSecure($globalCurCode); ?>">
            <span class="provider-name"
                  data-wallet-balance-text
                  data-wallet-balance="<?php echo iN_HelpSecure($walletBalanceValue, false); ?>"
                  data-wallet-balance-currency="<?php echo iN_HelpSecure($walletCurrencyCode, false); ?>"
                  data-wallet-balance-symbol="<?php echo iN_HelpSecure($walletCurrencySymbol, false); ?>"
                  data-wallet-balance-template="<?php echo iN_HelpSecure($walletProviderTemplate, false); ?>">
              <?php echo iN_HelpSecure($walletProviderLabel, false); ?>
            </span>
          </label>
        </div>
      </div>

      <p class="tips-note">
        <?php echo customLang('pay_note_redirect_info'); ?>
      </p>

      <div class="tips-actions">
        <button type="submit" class="tips-cta"><?php echo customLang('pay_continue'); ?></button>
      </div>

      <input type="hidden" name="post_id" value="<?php echo isset($postData['post_id']) ? (int)$postData['post_id'] : 0; ?>">
      <input type="hidden" name="recipient_id" value="<?php echo (int)$recipientId; ?>">
    </form>
  </div>
</div>

<?php
$assetVersion = isset($version) && $version !== '' ? (string) $version : (defined('APP_VERSION') ? (string) APP_VERSION : '1');
?>
<script defer src="<?php echo iN_HelpSecure($base_url);?>themes/<?php echo iN_HelpSecure($currentTheme);?>/js/tipsHandler.js?v=<?php echo iN_HelpSecure($assetVersion);?>"></script>
