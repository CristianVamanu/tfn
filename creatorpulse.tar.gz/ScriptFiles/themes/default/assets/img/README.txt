Royalty-free placeholder image (SVG) used across landing areas to avoid hotlinks.
Replace with your own images under this folder as needed.

File: placeholder.svg — created in-house, no third-party license required.

