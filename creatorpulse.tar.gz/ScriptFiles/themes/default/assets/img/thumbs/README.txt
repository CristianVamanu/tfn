Local Thumbnail Set

These thumbnails are simple, in-house generated SVG images intended for
demo/welcome grids and offline compliance. No third-party assets are used.

- Count: 12 (thumb_01.svg … thumb_12.svg)
- Dimensions: 720×960 (vector, scales cleanly)
- Source: Created in-house for ReelsProject
- License: CC0 1.0 / Public Domain dedication (no attribution required)

Usage: The theme helper `themeThumbs()` scans this folder and returns web URLs
for available images. The welcome grid shuffles/rotates through these.

