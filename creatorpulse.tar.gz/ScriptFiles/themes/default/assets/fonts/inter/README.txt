Place the following Inter font files here (download from https://rsms.me/inter/ or Google Fonts):

- Inter-Variable.woff2 (preferred)
- Inter-Regular.woff (fallback for older browsers)

These files enable offline, local font loading. The app will fall back to system fonts if not present.

