
<div class="click_box"></div>
<?php $themePath = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme);?>

<?php
  $gdprConsentPath = __DIR__ . '/../js/gdprConsent.js';
  $gdprConsentVersion = is_file($gdprConsentPath) ? filemtime($gdprConsentPath) : $version;
  $currencyFormatClientSafe = null;
  if (isset($currencyFormatClient) && is_array($currencyFormatClient)) {
      $currencyFormatClientSafe = $currencyFormatClient;
  } elseif (isset($GLOBALS['currency_format_client']) && is_array($GLOBALS['currency_format_client'])) {
      $currencyFormatClientSafe = $GLOBALS['currency_format_client'];
  }
  if ($currencyFormatClientSafe === null) {
      $currencyFormatClientSafe = [
          'position'      => 'left',
          'decimalPlaces' => 2,
          'decimalSep'    => '.',
          'thousandsSep'  => ',',
          'code'          => isset($currency) ? strtoupper((string) $currency) : 'USD',
          'symbol'        => '$',
      ];
  }
  $currencyFormatJson = htmlspecialchars(
      json_encode($currencyFormatClientSafe, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
      ENT_QUOTES,
      'UTF-8'
  );
?>
<div id="dz-currency-config" data-json="<?php echo $currencyFormatJson; ?>" hidden></div>
<script defer src="<?php echo $themePath; ?>/js/utils.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/currencyFormatter.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/gdprConsent.js?v=<?php echo iN_HelpSecure($gdprConsentVersion);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/vendor/marqueeSlider.js"></script>
<script defer src="<?php echo $themePath; ?>/js/vendor/vanilla-tilt.min.js"></script>
<script defer src="<?php echo $themePath; ?>/js/vendor/marker-animation.js"></script>
<script defer src="<?php echo $themePath; ?>/js/vendor/aos.min.js"></script>
<script defer src="<?php echo $themePath; ?>/vendor/lightgallery/lightgallery.umd.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/vendor/lightgallery/lg-zoom.umd.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/vendor/lightgallery/lg-video.umd.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<?php $includeChatCallGlobal = isset($loggedIn) && $loggedIn === '1'; ?>
<?php $includeAgoraRealtime = !empty($includeAgoraLive) || !empty($includeAgoraAudioRoom) || !empty($includeAgoraChatCall) || !empty($includeChatCallGlobal); ?>
<?php if ($includeAgoraRealtime) { ?>
  <?php
    // Local-only loading policy for Agora SDKs (no CDN fallbacks)
    $rtcLocalFs = __DIR__ . '/../js/vendor/agora/AgoraRTC_N.js';
    $rtmLocalFs = __DIR__ . '/../js/vendor/agora/AgoraRTM.min.js';

    $rtcSrcLocal = is_file($rtcLocalFs)
        ? ($themePath . '/js/vendor/agora/AgoraRTC_N.js')
        : null;

    // RTM remains local-only. If missing, it stays disabled gracefully.
    $rtmSrcLocal = is_file($rtmLocalFs)
        ? ($themePath . '/js/vendor/agora/AgoraRTM.min.js')
        : null;
  ?>
  
  <?php if (!empty($rtcSrcLocal)) { ?>
    <script defer src="<?php echo $rtcSrcLocal; ?>"></script>
    
  <?php } else { ?>
    
  <?php } ?>

  <?php if (!empty($agoraEnableRTM)) { ?>
    <?php if (!empty($rtmSrcLocal)) { ?>
      <script id="agora-rtm-script" defer src="<?php echo $rtmSrcLocal; ?>"></script>
    <?php } else { ?>
      
    <?php } ?>
    
  <?php } ?>
  <script defer src="<?php echo $themePath; ?>/js/agoraBoot.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<?php } ?>
<script defer src="<?php echo $themePath; ?>/js/main-out.js"></script>
<script defer src="<?php echo $themePath; ?>/js/header.js?v=<?php echo iN_HelpSecure($version);?>&fix=language-label-20260721-v2"></script>
<script defer src="<?php echo $themePath; ?>/js/suggestedUsers.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/liveHandler.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<?php if (!empty($includeAgoraLive)) { ?>
  <script defer src="<?php echo $themePath; ?>/js/agoraLive.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<?php } ?>
<?php if (!empty($includeAgoraAudioRoom)) { ?>
  <script defer src="<?php echo $themePath; ?>/js/audioRoom.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<?php } ?>
<?php if (!empty($includeChatCallGlobal)) { ?>
  <script defer src="<?php echo $themePath; ?>/js/chatCall.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<?php } ?>
<script defer src="<?php echo $themePath; ?>/js/carousel3d-counter.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/vendor/swiper/swiper-bundle.min.js"></script>
<script defer src="<?php echo $themePath; ?>/js/main.js?v=<?php echo iN_HelpSecure($version);?>&fix=chat-emoji-20260721-v20"></script>
<script defer src="<?php echo $themePath; ?>/js/sidebarSticky.js?v=<?php echo iN_HelpSecure($version);?>&fix=sidebar-header-collapse-20260721-v21"></script>
<script defer src="<?php echo $themePath; ?>/js/sidebarWidthLock.js?v=<?php echo iN_HelpSecure($version);?>&fix=sidebar-width-guard-20260721-v20"></script>
<script defer src="<?php echo $themePath; ?>/js/post.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/postView.tracking.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/premiumTeaser.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/videoAds.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/sharePost.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/settingsProfile.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/settingsSecurity.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/settingsPreferences.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/settingsSubscription.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/settingsCreator.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/settingsSubscriptionFees.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/vendor/chart.umd.min.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/settingsDashboard.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/settingsPayments.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/settingsPayouts.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/adsDashboard.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/podcastAds.js?v=<?php echo iN_HelpSecure($version);?>"></script>
<script defer src="<?php echo $themePath; ?>/js/podcastsPage.js?v=<?php echo iN_HelpSecure($version);?>"></script>
