<?php
$themePath = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme);
$versionToken = iN_HelpSecure($version);
$styleHref = $themePath . '/css/style.css?v=' . $versionToken . '&fix=language-row-layout-20260721-v30';
$fontsHref = $themePath . '/css/fonts.css?v=' . $versionToken;
$rtlHref = $themePath . '/css/rtl.css?v=' . $versionToken;
$animateHref = $themePath . '/css/vendor/animate.min.css?v=' . $versionToken;
$lightgalleryHref = $themePath . '/vendor/lightgallery/css/lightgallery.css?v=' . $versionToken;
$aosHref = $themePath . '/css/aos.css?v=' . $versionToken;
?>
<link rel="stylesheet" href="<?php echo $styleHref; ?>" />
<link rel="stylesheet" href="<?php echo $fontsHref; ?>" />
<?php if (!empty($isRTLLocale)): ?>
<link rel="stylesheet" href="<?php echo $rtlHref; ?>" />
<?php endif; ?>
<link rel="stylesheet" href="<?php echo $animateHref; ?>" />
<link rel="stylesheet" href="<?php echo $lightgalleryHref; ?>" />
<link rel="stylesheet" href="<?php echo $aosHref; ?>" />
