<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="description" content="<?php echo iN_HelpSecure($siteDescription);?>">
<?php if (!empty($iconPath)): ?>
<meta name="icon-theme-base" content="<?php echo iN_HelpSecure(rtrim((string)$iconPath, '/')); ?>">
<?php endif; ?>
<?php
$faviconSource = '';
if (!empty($siteMobileDarkLogo)) {
    $faviconSource = (string) $siteMobileDarkLogo;
} elseif (!empty($siteMobileWhiteLogo)) {
    $faviconSource = (string) $siteMobileWhiteLogo;
} elseif (!empty($siteDarkLogo)) {
    $faviconSource = (string) $siteDarkLogo;
} elseif (!empty($siteWhiteLogo)) {
    $faviconSource = (string) $siteWhiteLogo;
}
$faviconUrl = '';
if ($faviconSource !== '') {
    if (preg_match('~^https?://~i', $faviconSource)) {
        $faviconUrl = $faviconSource;
    } elseif (!empty($base_url)) {
        $faviconUrl = rtrim((string) $base_url, '/') . '/' . ltrim($faviconSource, '/');
    }
}
if ($faviconUrl !== ''): ?>
<link rel="icon" type="image/png" href="<?php echo iN_HelpSecure($faviconUrl); ?>" sizes="any">
<link rel="apple-touch-icon" href="<?php echo iN_HelpSecure($faviconUrl); ?>">
<?php endif; ?>
<?php $maintenanceMetaStatus = strtolower((string)($GLOBALS['__MAINTENANCE_MODE_STATUS'] ?? 'off')); ?>
<meta name="maintenance-mode" content="<?php echo iN_HelpSecure($maintenanceMetaStatus); ?>">
<?php
// Open Graph / Twitter Cards for share previews
try {
  $og = null;
  $canonical = '';
  $absBase = rtrim((string)($base_url ?? ''), '/');

  // Small helpers
  $defOgW = 1200; $defOgH = 630; // sensible defaults
  $siteDark = isset($siteDarkLogo) ? (string)$siteDarkLogo : '';
  $siteWhite= isset($siteWhiteLogo) ? (string)$siteWhiteLogo : '';
  $fallbackLogoRel = $siteDark !== '' ? $siteDark : ($siteWhite !== '' ? $siteWhite : '');

  $toAbs = function($rel) use ($absBase){ return $absBase . '/' . ltrim((string)$rel, '/'); };
  $imgDims = function($absUrl) use ($defOgW, $defOgH) {
    $w = $defOgW; $h = $defOgH;
    try {
      $path = parse_url((string)$absUrl, PHP_URL_PATH);
      if ($path) {
        $doc = rtrim((string)($_SERVER['DOCUMENT_ROOT'] ?? ''), '/');
        if ($doc !== '') {
          $local = $doc . $path;
          if (@is_file($local)) {
            $info = @getimagesize($local);
            if (is_array($info) && isset($info[0], $info[1]) && $info[0] && $info[1]) {
              $w = (int)$info[0]; $h = (int)$info[1];
            }
          }
        }
      }
    } catch (Throwable $__) {}
    return [$w, $h];
  };
  $pickLockedImage = function() use ($absBase, $toAbs, $fallbackLogoRel){
    // Preferred candidates (override by placing one of these files)
    $candidates = [
      'uploads/og/locked-share.png',
      'uploads/og/locked-share.jpg',
      'themes/default/assets/og/locked-share.png',
      'themes/default/assets/og/locked-share.jpg',
    ];
    $doc = rtrim((string)($_SERVER['DOCUMENT_ROOT'] ?? ''), '/');
    if ($doc !== '') {
      foreach ($candidates as $rel) {
        $local = $doc . '/' . ltrim($rel, '/');
        if (@is_file($local)) {
          if (strpos($rel, 'uploads/') === 0) {
            return storage_url($rel, 3600);
          }
          return $toAbs($rel);
        }
      }
    }
    // Fallback to configured site logo (absolute)
    return $fallbackLogoRel !== '' ? $toAbs($fallbackLogoRel) : '';
  };

  // If we are on a post permalink route (index.php maps /posts/{id}/{username?})
  $postId = isset($_GET['post_id']) && preg_match('/^\d+$/', (string)$_GET['post_id']) ? (int)$_GET['post_id'] : 0;
  if ($postId > 0 && isset($RL) && method_exists($RL, 'RL_GetPostById')) {
    $viewerId = isset($userID) ? (int)$userID : 0;
    $expected = isset($_GET['username']) && preg_match('/^[A-Za-z0-9_]+$/', (string)$_GET['username']) ? (string)$_GET['username'] : '';
    $p = $RL->RL_GetPostById($postId, $viewerId, $expected ?: null);
    if (is_array($p) && !empty($p)) {
      // Title & description
      $owner = (string)($p['owner_fullname'] ?? $p['owner_username'] ?? '');
      $text  = trim((string)($p['post_text'] ?? ''));

      // URL
      $username = (string)($p['owner_username'] ?? '');
      $canonical = $absBase . '/posts/' . $postId . ($username !== '' ? ('/' . rawurlencode($username)) : '');

      // Avoid leaking non-public content in meta title/desc
      $visibility = strtolower((string)($p['post_visibility'] ?? 'everyone'));
      $isPublic = ($visibility === 'everyone');
      if ($isPublic) {
        $title = $text !== '' ? mb_substr(strip_tags($text), 0, 70) : ($owner ? ($owner . ' – ' . ($siteTitle ?? '')) : ($siteTitle ?? ''));
        $desc  = $text !== '' ? mb_substr(strip_tags($text), 0, 160) : (string)($siteDescription ?? '');
      } else {
        // Generic, non-revealing copy per visibility
        $siteN = isset($siteTitle) ? (string)$siteTitle : '';
        if ($visibility === 'followers') {
          $title = trim(($owner ? ($owner . ' – ') : '') . (function_exists('customLang') ? customLang('followers_only') : 'Followers-Only'));
          $desc  = function_exists('customLang') ? customLang('post_only_followers') : 'This post is visible to followers only.';
        } elseif ($visibility === 'subscribers') {
          $title = trim(($owner ? ($owner . ' – ') : '') . (function_exists('customLang') ? customLang('subscribers_only') : 'Subscribers-Only'));
          $desc  = function_exists('customLang') ? customLang('post_only_subscribers') : 'This post is visible to subscribers only.';
        } else { // locked / premium
          $title = trim(($owner ? ($owner . ' – ') : '') . (function_exists('customLang') ? customLang('pricing_premium_title') : 'Premium Video Access'));
          $desc  = function_exists('customLang') ? customLang('post_hidden_generic') : 'This post is locked.';
        }
        if ($siteN !== '') { $desc .= ' '; $desc .= $siteN; }
      }

      // Image (avoid leaking locked media to crawlers)
      $imgUrl = '';
      $ptype  = (string)($p['post_type'] ?? '');
      if ($isPublic && $ptype === 'image') {
        $files = array_filter(array_map('trim', explode(',', (string)($p['post_file'] ?? ''))));
        if (!empty($files)) {
          $first = reset($files);
          if (preg_match('~^https?://~i', $first)) {
            $imgUrl = $first;
          } else {
            $imgUrl = storage_url($first, 3600);
          }
        }
      } elseif ($isPublic && $ptype === 'video') {
        // Video: prefer poster (or poster_url) if available, else fall back to site logo
        $poster = (string)($p['poster'] ?? ($p['poster_url'] ?? ''));
        if ($poster !== '') {
          $imgUrl = preg_match('~^https?://~i', $poster) ? $poster : storage_url($poster, 3600);
        }
      }

      if ($imgUrl === '') {
        // Fallback image: for public use site logo; for protected use locked image
        if ($isPublic) {
          $logoRel = $fallbackLogoRel;
          if ($logoRel !== '') {
            $imgUrl = (strpos($logoRel, 'uploads/') === 0)
              ? storage_url($logoRel, 3600)
              : $toAbs($logoRel);
          }
        } else {
          $imgUrl = $pickLockedImage();
        }
      }

      // Emit tags
      echo '<meta property="og:type" content="' . ($ptype === 'video' ? 'video.other' : 'article') . '" />';
      if (!empty($siteTitle)) { echo '<meta property="og:site_name" content="' . iN_HelpSecure((string)$siteTitle) . '" />'; }
      echo '<meta property="og:title" content="' . iN_HelpSecure($title) . '" />';
      echo '<meta property="og:description" content="' . iN_HelpSecure($desc) . '" />';
      if ($imgUrl) {
        echo '<meta property="og:image" content="' . iN_HelpSecure($imgUrl) . '" />';
        if (stripos($imgUrl, 'https://') === 0) {
          echo '<meta property="og:image:secure_url" content="' . iN_HelpSecure($imgUrl) . '" />';
        }
        echo '<meta property="og:image:alt" content="' . iN_HelpSecure($title) . '" />';
        list($ogw,$ogh) = $imgDims($imgUrl);
        echo '<meta property="og:image:width" content="' . (int)$ogw . '" />';
        echo '<meta property="og:image:height" content="' . (int)$ogh . '" />';
      }

      // If public video, include og:video tags for richer previews (FB, etc.)
      if ($isPublic && $ptype === 'video') {
        $vRaw = (string)($p['post_file'] ?? '');
        if ($vRaw !== '') {
          $videoUrl = preg_match('~^https?://~i', $vRaw) ? $vRaw : storage_url($vRaw, 3600);
          $path = parse_url($videoUrl, PHP_URL_PATH);
          $ext  = strtolower(pathinfo((string)$path, PATHINFO_EXTENSION));
          $mime = 'video/mp4';
          if ($ext === 'webm') { $mime = 'video/webm'; }
          elseif ($ext === 'ogv' || $ext === 'ogg') { $mime = 'video/ogg'; }
          elseif ($ext === 'm3u8') { $mime = 'application/x-mpegURL'; }
          elseif ($ext === 'mov') { $mime = 'video/quicktime'; }
          echo '<meta property="og:video" content="' . iN_HelpSecure($videoUrl) . '" />';
          if (stripos($videoUrl, 'https://') === 0) {
            echo '<meta property="og:video:secure_url" content="' . iN_HelpSecure($videoUrl) . '" />';
          }
          echo '<meta property="og:video:type" content="' . iN_HelpSecure($mime) . '" />';
        }
      }
      if ($canonical) { echo '<meta property="og:url" content="' . iN_HelpSecure($canonical) . '" />'; }
      echo '<meta name="twitter:card" content="summary_large_image" />';
      echo '<meta name="twitter:title" content="' . iN_HelpSecure($title) . '" />';
      echo '<meta name="twitter:description" content="' . iN_HelpSecure($desc) . '" />';
      if ($imgUrl) { echo '<meta name="twitter:image" content="' . iN_HelpSecure($imgUrl) . '" />'; }

      // Twitter Player (when applicable): only for public video
      if ($isPublic && $ptype === 'video') {
        // Basic player hints. Note: Twitter may require whitelisting for full Player Card.
        $playerUrl = $canonical; // use canonical as player landing
        $twW = 720; $twH = 1280; // vertical video default
        echo '<meta name="twitter:player" content="' . iN_HelpSecure($playerUrl) . '" />';
        echo '<meta name="twitter:player:width" content="' . (int)$twW . '" />';
        echo '<meta name="twitter:player:height" content="' . (int)$twH . '" />';
        // Provide stream hint if direct video URL detected
        $vRaw2 = (string)($p['post_file'] ?? '');
        if ($vRaw2 !== '') {
          $videoUrl2 = preg_match('~^https?://~i', $vRaw2) ? $vRaw2 : storage_url($vRaw2, 3600);
          $path2 = parse_url($videoUrl2, PHP_URL_PATH);
          $ext2  = strtolower(pathinfo((string)$path2, PATHINFO_EXTENSION));
          $mime2 = 'video/mp4';
          if ($ext2 === 'webm') { $mime2 = 'video/webm'; }
          elseif ($ext2 === 'ogv' || $ext2 === 'ogg') { $mime2 = 'video/ogg'; }
          elseif ($ext2 === 'm3u8') { $mime2 = 'application/x-mpegURL'; }
          elseif ($ext2 === 'mov') { $mime2 = 'video/quicktime'; }
          echo '<meta name="twitter:player:stream" content="' . iN_HelpSecure($videoUrl2) . '" />';
          echo '<meta name="twitter:player:stream:content_type" content="' . iN_HelpSecure($mime2) . '" />';
        }
      }
    }
  }

  // Generic fallbacks for non-post pages
  if (empty($canonical)) {
    $canonical = $absBase . rtrim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/', '/');
  }
  echo '<link rel="canonical" href="' . iN_HelpSecure($canonical) . '" />' . "\n";
} catch (Throwable $__) { /* no-op */ }
?>
<?php
// Lightweight i18n exposure for JS via <meta> tags
// Envato-safe: no inline JS in <body>; metas live in <head>
if (!function_exists('i18nMeta')) {
  function i18nMeta(string $key): void {
    if (!function_exists('customLang')) { return; }
    $val = (string) customLang($key);
    echo '<meta name="i18n.' . htmlspecialchars($key, ENT_QUOTES, 'UTF-8') . '" content="' . iN_HelpSecure($val, false) . '" />' . "\n";
  }
}

// Chat labels
i18nMeta('chat_day_today');
i18nMeta('chat_day_yesterday');
i18nMeta('chat_day_days_ago');
i18nMeta('chat_send');
i18nMeta('chat_ended');
i18nMeta('chat_wait_seconds');
i18nMeta('chat_user_fallback');
i18nMeta('chat_locked_post_placeholder');

$chatI18nMetaKeys = [
  'chat_action_copy',
  'chat_action_delete_everyone',
  'chat_action_delete_self',
  'chat_action_reply',
  'chat_action_report',
  'chat_cancel_reply',
  'chat_deleted_message',
  'chat_delete_everyone_confirm_text',
  'chat_delete_everyone_confirm_title',
  'chat_delete_self_confirm_text',
  'chat_delete_self_confirm_title',
  'chat_message_actions',
  'chat_message_empty_preview',
  'chat_open_messages_manage_hint',
  'chat_paid_media_label',
  'chat_paid_media_locked_badge',
  'chat_paid_media_locked_desc',
  'chat_paid_media_locked_title',
  'chat_paid_media_set_price',
  'chat_paid_media_unlock_button',
  'chat_paid_media_unlocked',
  'chat_preview_image',
  'chat_preview_sent_attachment',
  'chat_preview_sent_image',
  'chat_preview_sent_video',
  'chat_preview_shared_post',
  'chat_preview_shared_post_short',
  'chat_preview_video',
  'chat_react_to_message',
  'chat_reaction_fire',
  'chat_reaction_heart',
  'chat_reaction_laugh',
  'chat_reaction_like',
  'chat_reaction_sad',
  'chat_reaction_wow',
  'chat_reply_label',
  'chat_reply_message_fallback',
  'chat_reply_you',
  'chat_replying_to_message',
  'chat_report_message_title',
  'chat_report_note_label',
  'chat_report_note_placeholder',
  'chat_report_reason_adult',
  'chat_report_reason_harassment',
  'chat_report_reason_label',
  'chat_report_reason_other',
  'chat_report_reason_scam',
  'chat_report_reason_scam_short',
  'chat_report_reason_spam',
  'chat_report_reason_unsafe_content',
  'chat_report_submit',
  'chat_send_paid_media',
  'chat_send_tip',
  'chat_tip_message_label',
  'chat_tip_error_generic',
  'chat_tip_error_insufficient_wallet',
  'chat_tip_error_invalid_amount',
  'chat_tip_error_network',
  'chat_tip_error_recipient_not_creator',
  'chat_tip_support_creator',
  'chat_toast_message_copied',
  'chat_toast_message_copy_failed',
  'chat_toast_message_delete_failed',
  'chat_toast_message_deleted',
  'chat_toast_reaction_added',
  'chat_toast_reaction_failed',
  'chat_toast_reaction_removed',
  'chat_toast_report_failed',
  'chat_toast_report_submitted',
  'close',
  'continue',
  'delete',
  'loading',
  'menu_cancel',
  'messages_action_failed',
  'messages_assets_load_failed',
  'messages_block_user_text',
  'messages_block_user_title',
  'messages_clear_chat_text',
  'messages_clear_chat_title',
  'messages_confirm_default_text',
  'messages_confirm_default_title',
  'messages_conversation_load_failed',
  'messages_detail_links',
  'messages_detail_media',
  'messages_detail_posts',
  'messages_link_fallback',
  'messages_loading_conversation',
  'messages_loading_shared_items',
  'messages_no_shared_items',
  'messages_no_shared_links',
  'messages_no_shared_media',
  'messages_no_shared_posts',
  'messages_open_message',
  'messages_paid_badge',
  'messages_pinned_chip',
  'messages_report_chat_text',
  'messages_report_chat_title',
  'messages_report_optional_details',
  'messages_select_conversation_info',
  'messages_select_conversation_title',
  'messages_select_first',
  'messages_shared_content_label',
  'messages_shared_items_count',
  'messages_shared_items_load_failed',
  'messages_shared_links',
  'messages_shared_media',
  'messages_shared_post_fallback',
  'messages_shared_posts',
  'messages_toast_chat_cleared',
  'messages_toast_chat_deleted',
  'messages_toast_chat_pinned',
  'messages_toast_chat_unpinned',
  'messages_toast_download_prepared',
  'messages_toast_report_sent',
  'messages_toast_user_blocked',
  'messages_try_again',
  'post_type_post',
  'post_type_reel',
  'see_all',
  'view_profile',
];
foreach ($chatI18nMetaKeys as $chatI18nMetaKey) {
  i18nMeta($chatI18nMetaKey);
}

$audioRoomI18nMetaKeys = [
  'audio_room_accept',
  'audio_room_add_details_desc',
  'audio_room_add_details_title',
  'audio_room_agora_certificate_missing',
  'audio_room_agora_connect_error',
  'audio_room_agora_invalid_app',
  'audio_room_agora_join_missing',
  'audio_room_agora_mic_denied',
  'audio_room_agora_network_error',
  'audio_room_agora_sdk_missing',
  'audio_room_ban',
  'audio_room_banned_message',
  'audio_room_chat_disabled',
  'audio_room_chat_empty',
  'audio_room_chat_muted_for',
  'audio_room_chat_muted_for_sentence',
  'audio_room_chat_placeholder',
  'audio_room_chat_button',
  'audio_room_chat_title',
  'audio_room_close_chat',
  'audio_room_create',
  'audio_room_create_failed',
  'audio_room_creating_room',
  'audio_room_custom_price_placeholder',
  'audio_room_daily_limit_note',
  'audio_room_description_placeholder',
  'audio_room_disabled_hint',
  'audio_room_end_button',
  'audio_room_end_failed',
  'audio_room_end_request_failed',
  'audio_room_ended',
  'audio_room_ended_message',
  'audio_room_ended_title',
  'audio_room_error_banned',
  'audio_room_error_capacity_reached',
  'audio_room_error_chat_disabled',
  'audio_room_error_chat_muted',
  'audio_room_error_custom_price_disabled',
  'audio_room_error_daily_limit_reached',
  'audio_room_error_disabled',
  'audio_room_error_generic',
  'audio_room_error_invalid_price',
  'audio_room_error_invalid_room',
  'audio_room_error_muted_by_moderator',
  'audio_room_error_paid_not_allowed',
  'audio_room_error_price_out_of_range',
  'audio_room_error_removed',
  'audio_room_error_room_ended',
  'audio_room_error_room_not_found',
  'audio_room_host_label',
  'audio_room_join_button',
  'audio_room_join_failed',
  'audio_room_join_request_failed',
  'audio_room_join_to_use_mic',
  'audio_room_joining',
  'audio_room_kick',
  'audio_room_leave_button',
  'audio_room_left_room',
  'audio_room_listeners_short',
  'audio_room_listening',
  'audio_room_live_badge',
  'audio_room_locked_hint',
  'audio_room_make_moderator',
  'audio_room_manage_counts',
  'audio_room_manage_loading',
  'audio_room_manage_title',
  'audio_room_management_action_failed',
  'audio_room_management_action_request_failed',
  'audio_room_message_request_failed',
  'audio_room_message_send_failed',
  'audio_room_meta_chat_muted',
  'audio_room_meta_mic_on',
  'audio_room_meta_muted',
  'audio_room_microphone_live',
  'audio_room_mic_update_failed',
  'audio_room_minute_mute',
  'audio_room_speaking_now',
  'audio_room_modal_title',
  'audio_room_mute_mic',
  'audio_room_muted_by_moderator',
  'audio_room_no_active_participants',
  'audio_room_no_pending_requests',
  'audio_room_not_found',
  'audio_room_open_badge',
  'audio_room_paid_creator_only',
  'audio_room_paid_hint',
  'audio_room_paid_label',
  'audio_room_participants_title',
  'audio_room_ready_hint',
  'audio_room_redirect_seconds',
  'audio_room_reject',
  'audio_room_remove_mic',
  'audio_room_removed_message',
  'audio_room_removed_title',
  'audio_room_request_failed',
  'audio_room_request_mic_after_mute',
  'audio_room_request_speak',
  'audio_room_role_host',
  'audio_room_role_label',
  'audio_room_role_listener',
  'audio_room_role_moderator',
  'audio_room_role_speaker',
  'audio_room_role_updated_rejoining',
  'audio_room_role_refresh_failed',
  'audio_room_role_refresh_request_failed',
  'audio_room_speaker_request_error',
  'audio_room_speaker_request_failed',
  'audio_room_speaker_request_sent',
  'audio_room_speaker_requests_title',
  'audio_room_speakers_short',
  'audio_room_start_button',
  'audio_room_ticket_payment_failed',
  'audio_room_ticket_payment_request_failed',
  'audio_room_ticket_payment_starting',
  'audio_room_ticket_required',
  'audio_room_ticket_title',
  'audio_room_time_remaining',
  'audio_room_tip_button',
  'audio_room_tip_chat_fallback',
  'audio_room_tip_chat_with_amount',
  'audio_room_tip_failed',
  'audio_room_tip_invalid_amount',
  'audio_room_tip_request_failed',
  'audio_room_tip_send',
  'audio_room_tip_sending',
  'audio_room_tip_sent_thanks',
  'audio_room_tip_sheet_hint',
  'audio_room_tip_sheet_title',
  'audio_room_unlock_button',
  'audio_room_unmute_chat',
  'audio_room_unmute_mic',
  'audio_room_untitled',
  'audio_room_user_number',
  'audio_room_username_fallback',
  'audio_rooms_empty_state',
  'page_audio_rooms_heading',
  'page_audio_rooms_subheading',
];
foreach ($audioRoomI18nMetaKeys as $audioRoomI18nMetaKey) {
  i18nMeta($audioRoomI18nMetaKey);
}

// Payments common
i18nMeta('pay_error_invalid_amount');
i18nMeta('pay_error_select_provider');
i18nMeta('pay_error_missing_recipient');
i18nMeta('pay_error_complete_billing');
i18nMeta('pay_error_choose_plan');
i18nMeta('pay_error_init_failed');
i18nMeta('pay_unexpected_response');
i18nMeta('pay_request_failed');
i18nMeta('pay_success_tip');
i18nMeta('pay_success_wallet_tip');
i18nMeta('pay_success_wallet_purchase');
i18nMeta('pay_processing_message');
i18nMeta('pay_subscription_activated_wallet');
i18nMeta('wallet_topup_title');
i18nMeta('wallet_topup_description');
i18nMeta('wallet_topup_amount_label');
i18nMeta('wallet_topup_quick_amounts_label');
i18nMeta('wallet_topup_success');
i18nMeta('wallet_topup_disabled_message');
i18nMeta('wallet_topup_min_limit_error');
i18nMeta('wallet_topup_max_limit_error');
i18nMeta('wallet_topup_choose_provider');
i18nMeta('wallet_topup_button_label');

// Share modal
i18nMeta('share_no_friends');
i18nMeta('share_send_separately');
i18nMeta('share_link_copied');

// Media viewer
i18nMeta('viewer.close');
i18nMeta('viewer.next');
i18nMeta('viewer.prev');
i18nMeta('viewer.reset');
i18nMeta('viewer.zoom_in');
i18nMeta('viewer.zoom_out');
i18nMeta('viewer.image');
i18nMeta('viewer.video');
i18nMeta('viewer.play');
i18nMeta('viewer.pause');
i18nMeta('viewer.fullscreen');

// Live
i18nMeta('live_create_failed');
i18nMeta('live_request_failed');
i18nMeta('live_session_not_found');
i18nMeta('live_ending');
i18nMeta('live_end_failed');
i18nMeta('live_end_button');
i18nMeta('live_follow');
i18nMeta('live_following');
i18nMeta('live_unfollow');
i18nMeta('rtm_unavailable_offline');
i18nMeta('rtc_unavailable_offline');
i18nMeta('rtx_unavailable_offline');

// Settings & profile
i18nMeta('saving');
i18nMeta('save_failed');
i18nMeta('network_error');
i18nMeta('profile_saved');
i18nMeta('settings_preferences_updated');

// UI generic toasts
i18nMeta('ui_link_copied');
i18nMeta('ui_missing_parameters');
i18nMeta('ui_missing_csrf');
i18nMeta('ui_ok');
i18nMeta('ui_error');
i18nMeta('ui_network_error');
i18nMeta('ui_unreport');
i18nMeta('menu_report');
i18nMeta('ui_visibility_updated');
i18nMeta('ui_post_updated');
i18nMeta('ui_deleted');
i18nMeta('ui_price_range');
i18nMeta('ui_unexpected_response');
i18nMeta('ui_request_failed_retry');
i18nMeta('ui_failed_to_start_payment');
i18nMeta('ui_payment_completed_wallet');
i18nMeta('ui_payment_could_not_be_initiated');
i18nMeta('ui_payment_init_failed');
i18nMeta('ui_no_content_to_insert');
i18nMeta('ui_unexpected_server_response_retry');
i18nMeta('ui_upload_failed_crop_zero');
i18nMeta('upload_processing_notice');
i18nMeta('ui_unable_prepare_image');
i18nMeta('ui_error_during_upload_retry');
i18nMeta('ui_min_total_budget');
i18nMeta('ui_logging_in_wait');
i18nMeta('ui_unknown_error');
i18nMeta('ui_invalid_server_response');
i18nMeta('ui_server_error_code');
i18nMeta('ui_error_label');
i18nMeta('ui_uploading_wait');
i18nMeta('ui_saving_advertisement');
i18nMeta('ui_uploading_images');
i18nMeta('ui_creating_checkout');
i18nMeta('ui_coming_soon');
i18nMeta('ads_enter_title');
i18nMeta('ads_enter_description');
i18nMeta('ads_missing_video_url');
i18nMeta('ads_target_impressions_gt_zero');
i18nMeta('ads_ppi_gt_zero');
i18nMeta('ads_duration_days_min');
i18nMeta('ads_no_draft_to_pay');
i18nMeta('ads_dashboard_loading');
i18nMeta('ads_dashboard_fetch_failed');
i18nMeta('ads_dashboard_status_updated');
i18nMeta('ads_dashboard_status_update_failed');
i18nMeta('ads_dashboard_copy_updated');
i18nMeta('ads_dashboard_copy_update_failed');
i18nMeta('ads_dashboard_toggle_activate');
i18nMeta('ads_dashboard_toggle_pause');
i18nMeta('ads_dashboard_total_active');
i18nMeta('ads_dashboard_total_paused');
i18nMeta('ads_dashboard_total_budget');
i18nMeta('ads_dashboard_total_spent');
i18nMeta('ads_dashboard_total_remaining');
i18nMeta('ads_dashboard_chart_views');
i18nMeta('ads_dashboard_chart_spend');
i18nMeta('ads_dashboard_error');
i18nMeta('ads_dashboard_empty');
i18nMeta('ads_dashboard_spent_meta');
i18nMeta('ads_dashboard_remaining_meta');
i18nMeta('ads_dashboard_over_budget_meta');
i18nMeta('ads_dashboard_no_budget');
i18nMeta('ads_dashboard_toggle_hint');
i18nMeta('ads_dashboard_metric_impressions');
i18nMeta('ads_dashboard_metric_clicks');
i18nMeta('ads_dashboard_budget_allocated');
i18nMeta('ads_dashboard_budget_spent');
i18nMeta('ads_dashboard_budget_remaining');
i18nMeta('ads_dashboard_media_image');
i18nMeta('ads_dashboard_media_video');
i18nMeta('ads_dashboard_untitled');
i18nMeta('ads_status_active');
i18nMeta('ads_status_paused');
i18nMeta('ads_status_draft');
i18nMeta('ads_status_ended');
// Blocking
i18nMeta('cannot_block_subscriber');
i18nMeta('cannot_block_subscription_target');

// Admin interface strings for JS
i18nMeta('admin_reauth_prompt');
i18nMeta('admin_reauth_unlocked');
i18nMeta('admin_reauth_failed');
i18nMeta('admin_network_error');
i18nMeta('admin_network_error_short');
i18nMeta('admin_network_error_retry');
i18nMeta('admin_upload_failed');
i18nMeta('admin_upload_failed_reason');
i18nMeta('admin_image_uploaded');
i18nMeta('admin_uploaded');
i18nMeta('admin_saved');
i18nMeta('admin_loading');
i18nMeta('admin_settings_saved');
i18nMeta('admin_save_failed_generic');
i18nMeta('admin_save_failed_with_reason');
i18nMeta('admin_test_email_sent');
i18nMeta('admin_test_email_success_detail');
i18nMeta('admin_price_locked_warning');
i18nMeta('admin_price_range');
i18nMeta('admin_moderation_refresh');
i18nMeta('admin_moderation_network_error');
i18nMeta('admin_missing_csrf');
i18nMeta('admin_done');
i18nMeta('admin_operation_failed');
i18nMeta('admin_operation_failed_reason');
i18nMeta('admin_generic_success');
i18nMeta('admin_page_default_required');
i18nMeta('admin_confirm_delete_user');
i18nMeta('admin_confirm_delete_post');
i18nMeta('admin_contact_page_info');
i18nMeta('admin_contact_error_fetch');
i18nMeta('admin_contact_error_update');
i18nMeta('admin_contact_status_updated');
i18nMeta('admin_contact_status_update_failed');
i18nMeta('admin_contact_delete_confirm');
i18nMeta('admin_contact_delete_success');
i18nMeta('admin_contact_delete_failed');
i18nMeta('admin_contact_reply_success');
i18nMeta('admin_contact_reply_error');
i18nMeta('admin_contact_preview_expand');
i18nMeta('admin_contact_preview_collapse');
i18nMeta('admin_contact_empty');
i18nMeta('admin_contact_view');
i18nMeta('admin_contact_status_new');
i18nMeta('admin_contact_status_read');
i18nMeta('admin_contact_status_resolved');
i18nMeta('admin_chart_subscriptions');
i18nMeta('admin_chart_tips');
i18nMeta('admin_chart_total');
i18nMeta('admin_visibility_everyone');
i18nMeta('admin_visibility_followers');
i18nMeta('admin_visibility_subscribers');
i18nMeta('admin_visibility_locked');
i18nMeta('admin_owner_protected');
i18nMeta('admin_self_role_forbidden');
i18nMeta('admin_bad_action');
i18nMeta('admin_bad_user');
i18nMeta('admin_cannot_target_self');
i18nMeta('admin_forbidden');
i18nMeta('invalid_csrf_token');
i18nMeta('ui_unknown_error');
i18nMeta('server_error');
i18nMeta('admin_invalid_media_mode');
i18nMeta('admin_invalid_target');
i18nMeta('admin_invalid_length');
i18nMeta('admin_invalid_email');
i18nMeta('admin_contact_invalid_rate');
i18nMeta('invalid_subject');
i18nMeta('invalid_message_body');
i18nMeta('admin_smtp_invalid_host');
i18nMeta('admin_smtp_invalid_port');
i18nMeta('admin_smtp_invalid_secure');
i18nMeta('admin_smtp_not_configured');
i18nMeta('admin_smtp_test_rate_limited');
i18nMeta('admin_smtp_send_failed');
i18nMeta('admin_smtp_encrypt_failed');
i18nMeta('contact_message_not_found');
i18nMeta('contact_invalid_status');
?>
