<?php
declare(strict_types=1);

$gtmActive = isset($gtmTrackingEnabled) ? (bool) $gtmTrackingEnabled : (bool) ($GLOBALS['gtmTrackingEnabled'] ?? false);
$gtmContainerId = isset($gtmId) ? (string) $gtmId : (string) ($GLOBALS['gtmId'] ?? '');
$gtmContainerId = strtoupper(trim($gtmContainerId));
if (!$gtmActive || $gtmContainerId === '' || !preg_match('/^GTM-[A-Z0-9]+$/', $gtmContainerId)) {
    return;
}

$gtmSnippet = "(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','{$gtmContainerId}');";

if (function_exists('dz_csp_register_source')) {
    dz_csp_register_source('script-src', 'https://www.googletagmanager.com');
    dz_csp_register_source('connect-src', 'https://www.googletagmanager.com');
    dz_csp_register_source('frame-src', 'https://www.googletagmanager.com');
    // Dynamic hash for the inline bootstrap to satisfy strict CSP.
    $gtmHash = base64_encode(hash('sha256', $gtmSnippet, true));
    if ($gtmHash !== '') {
        dz_csp_register_source('script-src', "'sha256-{$gtmHash}'");
    }
}
?>
<script><?php echo $gtmSnippet; ?></script>
