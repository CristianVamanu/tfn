<?php
$themePath = iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme);
$oneSignalClientConfig = $GLOBALS['oneSignalClientConfig'] ?? [];
$isUserLoggedIn = isset($loggedIn) && $loggedIn === '1';
$oneSignalShouldBoot = false;
if ($isUserLoggedIn && is_array($oneSignalClientConfig) && !empty($oneSignalClientConfig['active']) && !empty($oneSignalClientConfig['appId'])) {
    $oneSignalShouldBoot = true;
}
$GLOBALS['__THEME_ONESIGNAL_ACTIVE'] = $oneSignalShouldBoot;
?>
<script src="<?php echo $themePath; ?>/js/jquery-3.7.1.min.js" defer></script>
<link rel="stylesheet" href="<?php echo $themePath; ?>/js/vendor/swiper/swiper-bundle.min.css">
<script src="<?php echo $themePath; ?>/head/boot.js.php" defer></script>
<script defer src="<?php echo $themePath; ?>/js/i18n-meta.js"></script>
<?php if ($oneSignalShouldBoot): ?>
  <link rel="manifest" href="<?php echo iN_HelpSecure($base_url); ?>manifestOneSignal.json">
  <?php dz_csp_register_source('script-src', 'https://cdn.onesignal.com'); ?>
  <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async defer></script>
<?php endif; ?>
