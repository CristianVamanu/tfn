<?php
declare(strict_types=1);
header('Content-Type: application/javascript; charset=UTF-8');
if (!headers_sent()) {
    header('Cache-Control: public, max-age=900, stale-while-revalidate=86400');
    header('Vary: Accept-Encoding');
}

// Bring in base_url from the app bootstrap
// Path: themes/default/head/ -> up 3 dirs to project root, then includes/connect.php
$connect = __DIR__ . '/../../../includes/connect.php';
if (is_file($connect)) { require_once $connect; }

// Fallback: infer base URL if include failed (installer or custom setups)
// Robust against being requested from within /themes/<theme>/head/boot.js.php
if (!isset($base_url) || !$base_url) {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $reqUri = (string)($_SERVER['REQUEST_URI'] ?? '/');
    $path   = (string)parse_url($reqUri, PHP_URL_PATH);
    $path   = $path !== '' ? $path : '/';
    $dir    = rtrim($path, '/');

    // If the request path contains /themes/, strip everything from there to get app root
    $posThemes = stripos($dir, '/themes/');
    if ($posThemes !== false) {
        $dir = substr($dir, 0, $posThemes);
    } else {
        // Otherwise, trim known top-level routes
        $dir = preg_replace('~/(profile|settings|posts|images|reels|bookmarks|premium)(/.*)?$~i', '', $dir) ?? $dir;
    }
    $base_url = rtrim($scheme . '://' . $host . $dir, '/') . '/';
}

// Ensure trailing slash and escape safely for JS
$u = rtrim((string)$base_url, '/') . '/';
$u_js = json_encode($u, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);

?>
// Base URL bootstrap (external, CSP-safe)
// This file guarantees a global `site_url` and `window.DZ.buildUrl`.
// Source of truth is PHP $base_url.
(function(){
  function computeBase(seed){
    var origin = '';
    try { origin = window.location.origin; } catch(_) {}
    if (!origin) {
      try { origin = (window.location.protocol || 'http:') + '//' + (window.location.host || ''); } catch(_) {}
    }

    var fallbackPath = '';
    try {
      var path = window.location.pathname || '/';
      fallbackPath = path.replace(/[^\/]*$/, '');
    } catch(_) { fallbackPath = '/'; }
    if (fallbackPath === '') { fallbackPath = '/'; }
    if (fallbackPath.slice(-1) !== '/') { fallbackPath += '/'; }
    var fallback = (origin || '') + fallbackPath;

    var candidate = (typeof seed === 'string' && seed) ? seed : fallback;
    try {
      var resolved = new URL(candidate, fallback);
      var pathName = resolved.pathname || '/';
      if (pathName.slice(-1) !== '/') {
        pathName = pathName.replace(/[^\/]*$/, '');
        if (pathName.slice(-1) !== '/') { pathName += '/'; }
      }
      if (origin && resolved.origin !== origin) {
        candidate = origin + pathName;
      } else {
        candidate = resolved.origin + pathName;
      }
    } catch(_) {
      candidate = fallback;
    }
    if (candidate.slice(-1) !== '/') { candidate += '/'; }
    return candidate;
  }

  var rawBase = <?php echo $u_js; ?>;
  var resolvedBase = computeBase(rawBase);
  try { window.DZ = window.DZ || {}; window.DZ.__computeBase = computeBase; } catch(_) {}
  try { window.site_url = resolvedBase; } catch(_) {}
})();

// Ensure a bare global identifier for legacy code
try { /* eslint-disable no-var */ var site_url = window.site_url; /* eslint-enable */ } catch(_){ }

// Canonical URL builder
(function(){
  try {
    window.DZ = window.DZ || {};
    if (typeof window.DZ.buildUrl !== 'function') {
      window.DZ.buildUrl = function(path){
        var base = '';
        try {
          base = (typeof window.site_url === 'string' && window.site_url) ? window.site_url : '';
          if (!base && typeof window.DZ.__computeBase === 'function') {
            base = window.DZ.__computeBase('');
          }
        } catch(_) { base = ''; }

        if (!base) {
          try {
            var origin = window.location.origin || ((window.location.protocol || 'http:') + '//' + (window.location.host || ''));
            var path = (window.location.pathname || '/').replace(/[^\/]*$/, '');
            base = origin + (path ? path : '/');
          } catch(_) {
            base = '';
          }
        }

        try {
          var url = new URL(String(path || ''), base || window.location.href);
          return url.toString();
        } catch(_) {
          if (base) {
            if (base.slice(-1) !== '/') { base += '/'; }
            return base + String(path || '').replace(/^\/+/, '');
          }
          return String(path || '');
        }
      };
    }
    // Also expose a global helper
    if (typeof window.buildUrl !== 'function') { window.buildUrl = window.DZ.buildUrl; }
  } catch(_){}
})();

// Debug flag (from PHP APP_DEBUG), exposed without inline scripts (CSP-safe)
(function(){
  try {
    // Set once; later scripts can read window.DZ_DEBUG
    window.DZ_DEBUG = <?php echo (defined('APP_DEBUG') && APP_DEBUG) ? 'true' : 'false'; ?>;
  } catch(_) {}
})();
