<?php
$isRTLLocale = isset($isRTLLocale) ? (bool) $isRTLLocale : false;
$currentLocale = strtolower((string)($currentLang ?? 'eng'));
$pageCsrfToken = htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8');
$themePreference = null;
if (isset($_COOKIE['theme_preference'])) {
    $themePreference = strtolower((string) $_COOKIE['theme_preference']);
} elseif (isset($_COOKIE['landing_theme_mode'])) {
    $themePreference = strtolower((string) $_COOKIE['landing_theme_mode']);
}
if ($themePreference !== 'dark' && $themePreference !== 'light') {
    $themePreference = 'auto';
}
$initialThemeClass = $themePreference === 'dark'
    ? 'theme-dark'
    : ($themePreference === 'light' ? 'theme-light' : '');
$initialToggleMode = $themePreference === 'dark' ? 'dark' : 'light';
$initialToggleIcon = $initialToggleMode === 'dark' ? '☀️' : '🌙';
$initialToggleAria = $initialToggleMode === 'dark'
    ? customLang('theme_toggle_light', 'Switch to light mode')
    : customLang('theme_toggle_dark', 'Switch to dark mode');
?>
<!doctype html>
<html
  lang="<?php echo htmlspecialchars($currentLocale, ENT_QUOTES, 'UTF-8'); ?>"
  dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
  data-theme="<?php echo htmlspecialchars($themePreference, ENT_QUOTES, 'UTF-8'); ?>"
  class="<?php echo $initialThemeClass; ?>"
>
  <head>
    <meta charset="UTF-8" />
    <title><?php echo iN_HelpSecure($siteTitle);?></title>
    <?php include "head/meta.php";?>
    <?php include "head/css.php";?>
    <?php include "head/js.php";?>
  </head>
  <body
    class="<?php echo trim(($isRTLLocale ? 'rtl-locale ' : '') . $initialThemeClass); ?>"
    dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
    data-dir="<?php echo $isRTLLocale ? 'rtl' : 'ltr'; ?>"
    data-logged-in="<?php echo (isset($loggedIn) && $loggedIn === '1') ? '1' : '0'; ?>"
    data-theme="<?php echo htmlspecialchars($themePreference, ENT_QUOTES, 'UTF-8'); ?>"
  >
    <input type="hidden" name="csrf_token" value="<?php echo $pageCsrfToken; ?>" />
    <header class="main-header" data-aos="fade-down">
      <div class="main-header-inner">
        <div class="container-nav">
          <?php
            $hasMobileLogo = (!empty($siteMobileDarkLogo) || !empty($siteMobileWhiteLogo));
            $primaryNavLabel = customLang('nav_primary_label');
            if (!$primaryNavLabel) {
                $primaryNavLabel = 'Primary navigation';
            }
            $menuToggleLabel = customLang('nav_menu');
            if (!$menuToggleLabel) {
                $menuToggleLabel = 'Menu';
            }
            $menuToggleAria = customLang('nav_toggle_menu');
            if (!$menuToggleAria) {
                $menuToggleAria = customLang('nav_toggle_navigation') ?: 'Toggle navigation';
            }
          ?>
          <a class="site-logo<?php echo $hasMobileLogo ? ' has-mobile-logo' : ''; ?>" href="#wrapper" aria-label="<?php echo iN_HelpSecure($siteName ?? 'Home'); ?>">
          <?php
            $alt = iN_HelpSecure($siteName ?? 'Logo');
            // Desktop variants
              if (!empty($siteDarkLogo)) {
                echo '<img class="logo-image logo--for-light logo--desktop" src="' . iN_HelpSecure($base_url . $siteDarkLogo) . '" alt="' . $alt . '" />';
              }
              if (!empty($siteWhiteLogo)) {
                echo '<img class="logo-image logo--for-dark logo--desktop" src="' . iN_HelpSecure($base_url . $siteWhiteLogo) . '" alt="' . $alt . '" />';
              }
              if (!empty($siteMobileDarkLogo)) {
                echo '<img class="logo-image logo--for-light logo--mobile" src="' . iN_HelpSecure($base_url . $siteMobileDarkLogo) . '" alt="' . $alt . '" />';
              }
              if (!empty($siteMobileWhiteLogo)) {
                echo '<img class="logo-image logo--for-dark logo--mobile" src="' . iN_HelpSecure($base_url . $siteMobileWhiteLogo) . '" alt="' . $alt . '" />';
              }
            ?>
          </a>
          <button
            type="button"
            class="nav-toggle"
            data-nav-toggle
            aria-expanded="false"
            aria-controls="primary-navigation"
            aria-label="<?php echo iN_HelpSecure($menuToggleAria); ?>"
          >
            <span class="nav-toggle__box" aria-hidden="true">
              <span class="nav-toggle__line nav-toggle__line--top"></span>
              <span class="nav-toggle__line nav-toggle__line--middle"></span>
              <span class="nav-toggle__line nav-toggle__line--bottom"></span>
            </span>
            <span class="nav-toggle__label"><?php echo iN_HelpSecure($menuToggleLabel); ?></span>
          </button>
          <div class="nav-cluster" data-nav-panel>
            <nav id="primary-navigation" class="primary-navigation" aria-label="<?php echo iN_HelpSecure($primaryNavLabel); ?>">
              <a class="menu-item" href="#how-it-works"><?php echo customLang('nav_how_it_works');?></a>
              <a class="menu-item" href="#features"><?php echo customLang('nav_features');?></a>
              <a class="menu-item" href="#samples"><?php echo customLang('nav_explore');?></a>
              <a class="menu-item" href="#pricing"><?php echo customLang('nav_subscriptions');?></a>
              <a class="menu-item" href="#no-hassle"><?php echo customLang('nav_why_dizzyreel');?></a>
              <a class="menu-item" href="#faqs"><?php echo customLang('nav_faqs');?></a>
              <a href="login.php" class="btn-call"><?php echo customLang('nav_start_earning');?></a>
            </nav>
            <div class="welcome_language_switcher_wrapper">
              <?php
                $languageSwitcherContext = [
                    'button_classes' => 'welcome_language_switcher flex align_items',
                    'label_class' => 'welcome_language_switcher__label',
                    'show_label_text' => false,
                ];
                include __DIR__ . '/partials/language_switcher.php';
                unset($languageSwitcherContext);
              ?>
            </div>
          </div>
        </div>
      </div>
    </header>
    <!---->
    <section class="hero hero-top-space" id="wrapper">
      <h1 class="hero-title"><?php echo customLang('hero_title');?></h1>
      <p class="zoom-in delay-3">
        <?php echo customLang('hero_description');?>
      </p>
      <div class="carousel-wrapper" data-aos="fade-up">
        <?php $viewIconMarkup = render_icon('view', true); ?>
        <div class="carousel" id="carousel"></div>
        <?php if ($viewIconMarkup !== ''): ?>
          <template id="viewIconTemplate"><?php echo $viewIconMarkup; ?></template>
        <?php endif; ?>
      </div>
      <a href="login.php" class="btn-start zoom-in delay-4"><?php echo customLang('hero_start_button');?></a>

        <?php
          $thumbs = themeThumbs();
          if (count($thumbs) > 1) { shuffle($thumbs); }
          $tn = count($thumbs);
          $imgAlt = customLang('thumb_alt_generic');
          $landingTheme = 'welcome_default';
          $imageListDefaults = [
              'media_mode' => 'mixed',
              'target' => 'profile',
              'show_views' => true,
              'show_likes' => true,
          ];
          $imageListConfig = $imageListDefaults;
          $imageListItems = [];
          if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionConfig') && method_exists($RL, 'RL_GetLandingImageList')) {
              $fetchedConfig = $RL->RL_GetLandingSectionConfig($landingTheme, 'image_list');
              if (is_array($fetchedConfig)) {
                  $imageListConfig = array_replace($imageListDefaults, array_intersect_key($fetchedConfig, $imageListDefaults));
              }
              $imageListItems = $RL->RL_GetLandingImageList($landingTheme, $imageListConfig, 8);
          }
          $showImageListViews = !empty($imageListConfig['show_views']);
          $showImageListLikes = !empty($imageListConfig['show_likes']);
          $linkTargetMode = in_array($imageListConfig['target'], ['profile', 'post'], true) ? $imageListConfig['target'] : 'profile';
        ?>
        <ul class="image-list">
          <?php if (!empty($imageListItems)): ?>
            <?php foreach ($imageListItems as $i => $item):
              $fallbackSrc = $thumbs[$i % $tn] ?? '';
              $imgSrc = (string)($item['image_url'] ?? '');
              if ($imgSrc === '' && $fallbackSrc !== '') {
                  $imgSrc = $fallbackSrc;
              }
              if ($imgSrc === '') { continue; }
              $views = (int)($item['views'] ?? 0);
              $likes = (int)($item['likes'] ?? 0);
              $handle = (string)($item['owner_username'] ?? '');
              $display = (string)($item['owner_display'] ?? '');
              $label = $display !== '' ? $display : ($handle !== '' ? $handle : 'creator');
              $verified = !empty($item['owner_verified']);
              $postId = (int)($item['post_id'] ?? 0);
              $targetUrl = '#';
              if ($linkTargetMode === 'profile' && $handle !== '') {
                  $targetUrl = rtrim((string)$base_url, '/') . '/profile/' . rawurlencode($handle);
              } elseif ($linkTargetMode === 'post' && $postId > 0) {
                  $targetUrl = rtrim((string)$base_url, '/') . '/posts/' . $postId;
                  if ($handle !== '') {
                      $targetUrl .= '/' . rawurlencode($handle);
                  }
              }
            ?>
              <li data-img="<?php echo iN_HelpSecure($imgSrc); ?>"
                  data-url="<?php echo iN_HelpSecure($targetUrl); ?>"
                  data-views="<?php echo $showImageListViews ? $views : 0; ?>"
                  data-likes="<?php echo $showImageListLikes ? $likes : 0; ?>"
                  data-show-views="<?php echo $showImageListViews ? 'true' : 'false'; ?>"
                  data-show-likes="<?php echo $showImageListLikes ? 'true' : 'false'; ?>"
                  data-username="<?php echo iN_HelpSecure($label); ?>"
                  data-handle="<?php echo iN_HelpSecure($handle); ?>"
                  data-verified="<?php echo $verified ? 'true' : 'false'; ?>"
                  aria-label="<?php echo iN_HelpSecure($imgAlt); ?>"></li>
            <?php endforeach; ?>
          <?php else: ?>
            <?php for ($i = 0; $i < 8; $i++): $src = $thumbs[$i % $tn]; ?>
              <li data-img="<?php echo iN_HelpSecure($src); ?>"
                  data-url="#"
                  data-views="0"
                  data-likes="0"
                  data-show-views="true"
                  data-show-likes="true"
                  data-username="<?php echo iN_HelpSecure('creator'); ?>"
                  data-handle="<?php echo iN_HelpSecure('creator'); ?>"
                  data-verified="false"
                  aria-label="<?php echo iN_HelpSecure($imgAlt); ?>"></li>
            <?php endfor; ?>
          <?php endif; ?>
        </ul>
        <?php
          $marqueeDefaults = [
              'list_count' => 4,
              'show_avatar' => true,
              'name_mode' => 'full',
          ];
          $marqueeConfig = $marqueeDefaults;
          $marqueeData = [
              'lists' => [],
              'show_avatar' => true,
              'name_mode' => 'full',
          ];
          if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionConfig') && method_exists($RL, 'RL_GetLandingMarquee')) {
              $fetchedMarquee = $RL->RL_GetLandingSectionConfig($landingTheme, 'marquee');
              if (is_array($fetchedMarquee)) {
                  $marqueeConfig = array_replace($marqueeDefaults, array_intersect_key($fetchedMarquee, $marqueeDefaults));
              }
              $marqueeData = $RL->RL_GetLandingMarquee($landingTheme, $marqueeConfig, 10);
          }
          $marqueeLists = isset($marqueeData['lists']) && is_array($marqueeData['lists']) ? $marqueeData['lists'] : [];
          $marqueeShowAvatar = !empty($marqueeData['show_avatar']);
          $marqueeNameMode = $marqueeData['name_mode'] ?? 'full';
        ?>
    </section>
    <!---->
    <!---->
    <section class="section recent-work" id="how-it-works">
        <h2 class="max-width-640px marker-animation" data-ma_color="#4F86F7">
            <?php echo customLang('hero2_heading_share_reels');?>
        </h2>
        <p class="text-center text-gray-500 mt-2">
            <?php echo customLang('hero2_paragraph_earn_money');?>
        </p>
      <div class="marquee-slider marquee-slider2">
        <?php if (!empty($marqueeLists)): ?>
          <?php foreach ($marqueeLists as $listIndex => $listItems): ?>
            <div class="marquee-slider__list">
              <?php foreach ($listItems as $itemIndex => $entry):
                $label = (string)($entry['label'] ?? 'Creator');
                if ($label === '') { $label = 'Creator'; }
                $avatarUrl = (string)($entry['avatar_url'] ?? '');
                if ($avatarUrl === '' && $marqueeShowAvatar && $tn > 0) {
                    $avatarUrl = $thumbs[($listIndex + $itemIndex) % $tn] ?? $thumbs[0];
                }
              ?>
                <div class="marquee-slider__list--item">
                  <?php if ($marqueeShowAvatar && $avatarUrl !== ''): ?>
                    <span class="marquee-slider__avatar">
                      <img src="<?php echo iN_HelpSecure($avatarUrl); ?>" alt="<?php echo iN_HelpSecure($imgAlt); ?>">
                    </span>
                  <?php endif; ?>
                  <?php echo iN_HelpSecure($label); ?>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="marquee-slider__list">
            <div class="marquee-slider__list--item">Creator</div>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <!---->
    <!---->
    <?php
      $featureLang = isset($currentLang) ? strtolower((string) $currentLang) : 'eng';
      if ($featureLang === '') {
          $featureLang = 'eng';
      }
      $featureFallbackLangs = [];
      if ($featureLang !== 'eng') {
          $featureFallbackLangs[] = 'eng';
      }

      $defaultFeatures = [
          [
              'icon' => icon_public_url('security'),
              'color' => '#FF3C3C',
              'variant' => 'dark',
              'title' => customLang('feature_card_flexible_privacy_title'),
              'description' => customLang('feature_card_flexible_privacy_desc'),
          ],
          [
              'icon' => icon_public_url('subscription_fees'),
              'color' => '#43E97B',
              'variant' => 'light',
              'title' => customLang('feature_card_recurring_title'),
              'description' => customLang('feature_card_recurring_desc'),
          ],
          [
              'icon' => icon_public_url('super_thanks'),
              'color' => '#FFD700',
              'variant' => 'light',
              'title' => customLang('feature_card_premium_sales_title'),
              'description' => customLang('feature_card_premium_sales_desc'),
          ],
          [
              'icon' => icon_public_url('sparkles'),
              'color' => '#8A63F2',
              'variant' => 'light',
              'title' => customLang('feature_card_short_format_title'),
              'description' => customLang('feature_card_short_format_desc'),
          ],
          [
              'icon' => icon_public_url('world'),
              'color' => '#4F86F7',
              'variant' => 'light',
              'title' => customLang('feature_card_explore_title'),
              'description' => customLang('feature_card_explore_desc'),
          ],
          [
              'icon' => icon_public_url('payments'),
              'color' => '#F67D2E',
              'variant' => 'muted',
              'title' => customLang('feature_card_earnings_title'),
              'description' => customLang('feature_card_earnings_desc'),
          ],
      ];

      $featureData = ['items' => []];
      if (isset($RL) && method_exists($RL, 'RL_GetLandingFeatures')) {
          $featureData = $RL->RL_GetLandingFeatures($landingTheme, $featureLang, $featureFallbackLangs);
      }
      $fetchedFeatures = isset($featureData['items']) && is_array($featureData['items']) ? $featureData['items'] : [];
      $featureCards = [];
      foreach ($fetchedFeatures as $item) {
          $featureCards[] = [
              'icon' => (string) ($item['icon'] ?? ''),
              'color' => (string) ($item['color'] ?? ''),
              'variant' => (string) ($item['variant'] ?? 'light'),
              'title' => (string) ($item['title'] ?? ''),
              'description' => (string) ($item['description'] ?? ''),
          ];
      }
      if (!$featureCards) {
          $featureCards = $defaultFeatures;
      }

      $presetIndex = 0;
      while (count($featureCards) < 6 && $presetIndex < count($defaultFeatures)) {
          $featureCards[] = $defaultFeatures[$presetIndex++];
      }
      $featureCards = array_slice($featureCards, 0, 6);

      $hasDark = false;
      $hasMuted = false;
      foreach ($featureCards as $card) {
          $variantCheck = isset($card['variant']) ? strtolower((string) $card['variant']) : 'light';
          if ($variantCheck === 'dark') { $hasDark = true; }
          if ($variantCheck === 'muted') { $hasMuted = true; }
      }
      if (!$hasDark && $featureCards) {
          $featureCards[0]['variant'] = 'dark';
      }
      if (!$hasMuted && $featureCards) {
          $lastIndex = count($featureCards) - 1;
          if ($lastIndex >= 0) {
              $featureCards[$lastIndex]['variant'] = 'muted';
          }
      }

      $featureCount = count($featureCards);
      $firstCardId = 'w-node-aea8b5ca-52a4-8b83-6b6f-c151ec2e246f-d11c69fb';
      $lastCardId  = 'w-node-_60d4259f-237b-0bfc-b28c-409ccff0396f-d11c69fb';
      $darkIndex = null;
      $mutedIndex = null;
      foreach ($featureCards as $idx => $feature) {
          $variantProbe = isset($feature['variant']) ? strtolower((string) $feature['variant']) : 'light';
          if ($darkIndex === null && $variantProbe === 'dark') {
              $darkIndex = $idx;
          }
          if ($mutedIndex === null && $variantProbe === 'muted') {
              $mutedIndex = $idx;
          }
      }
      if ($darkIndex === null && $featureCount) { $darkIndex = 0; }
      if ($mutedIndex === null && $featureCount) { $mutedIndex = $featureCount - 1; }
    ?>
    <section class="features-section" id="features">
        <h2 class="features-title marker-animation" data-ma_color="#FF3C3C">
            <?php echo customLang('features_title_why_choose');?>
        </h2>
        <p class="features-subtitle">
            <?php echo customLang('features_subtitle_publish_protect');?>
        </p>

        <div class="features-container w-layout-blockcontainer">
            <div class="benefit-cards">
              <?php foreach ($featureCards as $idx => $feature):
                $fallback = $defaultFeatures[$idx % count($defaultFeatures)];
                $title = trim((string) ($feature['title'] ?? ''));
                if ($title === '') {
                    $title = (string) ($fallback['title'] ?? '');
                }
                $description = trim((string) ($feature['description'] ?? ''));
                if ($description === '') {
                    $description = (string) ($fallback['description'] ?? '');
                }
                $color = trim((string) ($feature['color'] ?? ''));
                if ($color === '' || !preg_match('/^#[0-9a-f]{3,8}$/i', $color)) {
                    $color = (string) ($fallback['color'] ?? '#4F86F7');
                }
                $variant = isset($feature['variant']) ? strtolower((string) $feature['variant']) : 'light';
                if (!in_array($variant, ['light', 'dark', 'muted'], true)) {
                    $variant = isset($fallback['variant']) ? $fallback['variant'] : 'light';
                }
                $iconValue = trim((string) ($feature['icon'] ?? ''));
                $iconUrl = '';
                $iconLabel = '';
                if ($iconValue !== '') {
                    $resolvedIcon = icon_public_url($iconValue);
                    if ($resolvedIcon !== '') {
                        $iconUrl = $resolvedIcon;
                    } else {
                        $path = parse_url($iconValue, PHP_URL_PATH);
                        $path = $path !== null ? $path : $iconValue;
                        $hasImageExt = is_string($path) && preg_match('/\.(svg|png|jpe?g|gif|webp)$/i', $path);
                        if ($hasImageExt || preg_match('#^(https?:)?//#i', $iconValue) || strpos($iconValue, 'data:image') === 0 || ($iconValue !== '' && $iconValue[0] === '/')) {
                            if (strpos($iconValue, 'data:image') === 0) {
                                $iconUrl = $iconValue;
                            } elseif (preg_match('#^https?://#i', $iconValue)) {
                                $iconUrl = $iconValue;
                            } elseif (strpos($iconValue, '//') === 0) {
                                $iconUrl = 'https:' . $iconValue;
                            } else {
                                $iconUrl = rtrim((string) $base_url, '/') . '/' . ltrim($iconValue, '/');
                            }
                        } else {
                            $iconLabel = $iconValue;
                        }
                    }
                }
                if ($iconUrl === '' && $iconLabel === '' && $title !== '') {
                    $iconLabel = mb_strtoupper(mb_substr($title, 0, 2));
                }

                $cardClasses = 'card';
                $headingClass = '';
                $paragraphClass = '';
                $cardIdAttr = '';

                if ($idx === $darkIndex) {
                    $cardClasses .= ' black';
                    $headingClass = 'card-black-heading';
                    $paragraphClass = 'card-black-text';
                    $cardIdAttr = $firstCardId;
                } elseif ($idx === $mutedIndex) {
                    $cardClasses .= ' grey';
                    $cardIdAttr = $lastCardId;
                }

                $accentColorEsc = htmlspecialchars($color, ENT_QUOTES, 'UTF-8');
                $iconHtml = '';
                $iconClasses = ['feature-heading-icon'];
                if ($headingClass === 'card-black-heading') {
                    $iconClasses[] = 'feature-heading-icon--inverse';
                }

                if ($iconUrl !== '') {
                    $iconHtml = '<span class="' . implode(' ', $iconClasses) . '">' . renderVerifiedBadge($iconUrl, true) . '</span>';
                } elseif ($iconLabel !== '') {
                    $iconClasses[] = 'feature-heading-icon--text';
                    $iconHtml = '<span class="' . implode(' ', $iconClasses) . '">' . iN_HelpSecure($iconLabel) . '</span>';
                }
              ?>
              <div <?php echo $cardIdAttr !== '' ? 'id="' . $cardIdAttr . '" ' : ''; ?>class="<?php echo $cardClasses; ?>" data-aos="zoom-in-up">
                <h3<?php echo $headingClass !== '' ? ' class="' . $headingClass . '"' : ''; ?>><?php echo $iconHtml; ?><?php echo iN_HelpSecure($title); ?></h3>
                <?php if ($description !== ''): ?>
                  <p<?php echo $paragraphClass !== '' ? ' class="' . $paragraphClass . '"' : ''; ?>><?php echo iN_HelpSecure($description); ?></p>
                <?php endif; ?>
              </div>
              <?php endforeach; ?>
            </div>
        </div>
    </section>
    <!---->
    <!---->
    <?php
      $defaultSampleKeys = [
          'public_videos',
          'followers_only',
          'subscribers_only',
          'premium_access',
          'seven_second_reels',
          'fourteen_second_reels',
          'hashtag_discovery',
          'creator_tips',
          'subscription_revenue',
          'explore_feed',
          'fast_payouts',
          'responsive_design',
          'more_tags',
      ];
      $samplesData = ['items' => []];
      if (isset($RL) && method_exists($RL, 'RL_GetLandingSamples')) {
          $samplesData = $RL->RL_GetLandingSamples($landingTheme, strtolower((string) ($currentLang ?? 'eng')), ['eng']);
      }
      $sampleItems = isset($samplesData['items']) && is_array($samplesData['items']) ? $samplesData['items'] : [];
      $maxSamples = max(count($sampleItems), count($defaultSampleKeys));
      $samplesForView = [];
      for ($i = 0; $i < $maxSamples; $i++) {
          $item = $sampleItems[$i] ?? [];
          $fallbackKey = $defaultSampleKeys[$i % count($defaultSampleKeys)];
          $label = trim((string) ($item['label'] ?? ''));
          if ($label === '') {
              $label = customLang($fallbackKey);
          }
          $style = isset($item['style']) ? strtolower((string) $item['style']) : 'narrow';
          if (!in_array($style, ['narrow', 'wide'], true)) {
              $style = 'narrow';
          }
          $samplesForView[] = [
              'label' => $label,
              'style' => $style,
          ];
      }
      if (!$samplesForView) {
          foreach ($defaultSampleKeys as $key) {
              $samplesForView[] = [
                  'label' => customLang($key),
                  'style' => 'narrow',
              ];
          }
      }
      $samplesTitle = customLang('features_tags_title');
      $samplesSubtitle = trim((string) customLang('features_tags_subtitle'));
    ?>
    <section class="features-tags-section" id="samples">
      <h2 class="features-tags-title marker-animation" data-ma_color="#4F86F7">
        <?php echo iN_HelpSecure($samplesTitle); ?>
      </h2>
      <?php if ($samplesSubtitle !== ''): ?>
        <p class="features-tags-subtitle"><?php echo iN_HelpSecure($samplesSubtitle); ?></p>
      <?php endif; ?>

      <div class="features-tags-grid">
        <?php foreach ($samplesForView as $sample):
          $style = $sample['style'] === 'wide' ? 'wide' : 'narrow';
        ?>
          <div class="tag <?php echo $style === 'wide' ? 'wide' : 'narrow'; ?> box-follow" data-aos="fade-up">
            <h3><?php echo iN_HelpSecure($sample['label']); ?></h3>
          </div>
        <?php endforeach; ?>
      </div>
    </section>
    <?php
      $pricingData = ['config' => [], 'items' => []];
      if (isset($RL) && method_exists($RL, 'RL_GetLandingPricing')) {
          $pricingData = $RL->RL_GetLandingPricing($landingTheme, strtolower((string) ($currentLang ?? 'eng')), ['eng']);
      }
      $pricingTitle = customLang('pricing_section_title');
      $pricingSubtitle = trim((string) customLang('pricing_section_description'));
      $pricingNote = trim((string) customLang('pricing_note'));

      $defaultPricingPlans = [
          [
              'variant' => 'default',
              'highlight' => false,
              'cta_url' => '',
              'title_key' => 'pricing_public_title',
              'tagline_key' => 'pricing_visible_to_explore',
              'description_key' => 'pricing_public_desc',
              'badge_key' => 'pricing_public_price',
              'cta_label_key' => 'pricing_cta_default',
              'features_keys' => [
                  'pricing_public_info_1',
                  'pricing_public_info_2',
                  'pricing_public_info_3',
                  'pricing_public_info_4',
                  'pricing_public_info_5',
              ],
          ],
          [
              'variant' => 'highlight',
              'highlight' => true,
              'cta_url' => '',
              'title_key' => 'pricing_subscriber_title',
              'tagline_key' => 'pricing_only_visible_for_subscribers',
              'description_key' => 'pricing_subscriber_desc',
              'badge_key' => 'pricing_subscriber_price',
              'cta_label_key' => 'pricing_cta_subscriber',
              'features_keys' => [
                  'pricing_subscriber_info_1',
                  'pricing_subscriber_info_2',
                  'pricing_subscriber_info_3',
                  'pricing_subscriber_info_4',
                  'pricing_subscriber_info_5',
              ],
          ],
          [
              'variant' => 'muted',
              'highlight' => false,
              'cta_url' => '',
              'title_key' => 'pricing_premium_title',
              'tagline_key' => 'pricing_premium_label',
              'description_key' => 'pricing_premium_desc',
              'badge_key' => 'pricing_premium_price',
              'cta_label_key' => 'pricing_cta_premium',
              'features_keys' => [
                  'pricing_premium_info_1',
                  'pricing_premium_info_2',
                  'pricing_premium_info_3',
                  'pricing_premium_info_4',
              ],
          ],
      ];

      $storedPlans = isset($pricingData['items']) && is_array($pricingData['items']) ? $pricingData['items'] : [];
      $maxPlans = max(count($storedPlans), count($defaultPricingPlans));
      $pricingPlans = [];
      $variantIconMap = [
          'default' => 'explore.svg',
          'highlight' => 'subscriber.svg',
          'muted' => 'locked.svg',
      ];
      for ($i = 0; $i < $maxPlans; $i++) {
          $fallback = $defaultPricingPlans[$i % count($defaultPricingPlans)];
          $stored = $storedPlans[$i] ?? [];

          $variant = isset($stored['variant']) && in_array($stored['variant'], ['default', 'highlight', 'muted'], true)
              ? $stored['variant']
              : $fallback['variant'];
          $highlight = isset($stored['highlight']) ? (bool) $stored['highlight'] : !empty($fallback['highlight']);
          if ($variant === 'default' && $highlight) {
              $variant = 'highlight';
          }

          $ctaUrl = isset($stored['cta_url']) ? trim((string) $stored['cta_url']) : $fallback['cta_url'];

          $features = [];
          if (!empty($stored['features']) && is_array($stored['features'])) {
              foreach ($stored['features'] as $line) {
                  $text = trim((string) $line);
                  if ($text !== '') {
                      $features[] = $text;
                  }
              }
          }
          if (!$features) {
              foreach ($fallback['features_keys'] as $featureKey) {
                  $text = customLang($featureKey);
                  if ($text !== '') {
                      $features[] = $text;
                  }
              }
          }

          $title = trim((string) ($stored['title'] ?? ''));
          if ($title === '') {
              $title = customLang($fallback['title_key']);
          }

          $tagline = trim((string) ($stored['tagline'] ?? ''));
          if ($tagline === '') {
              $tagline = customLang($fallback['tagline_key']);
          }

          $description = trim((string) ($stored['description'] ?? ''));
          if ($description === '') {
              $description = customLang($fallback['description_key']);
          }

          $ctaLabel = trim((string) ($stored['cta_label'] ?? ''));
          if ($ctaLabel === '' && !empty($fallback['cta_label_key'])) {
              $ctaLabel = customLang($fallback['cta_label_key']);
          }

          $badgeLabel = trim((string) ($stored['badge'] ?? ''));
          if ($badgeLabel === '' && !empty($fallback['badge_key'])) {
              $badgeLabel = customLang($fallback['badge_key']);
          }

          $iconFile = (string) ($variantIconMap[$variant] ?? ($fallback['icon'] ?? ''));
          $iconMarkup = '';
          if ($iconFile !== '') {
              $iconKey = icon_asset_key($iconFile);
              if ($iconKey !== '') {
                  $iconMarkup = render_icon($iconKey, true);
              }
          }

          $pricingPlans[] = [
              'variant' => $variant,
              'highlight' => $highlight,
              'title' => $title,
              'tagline' => $tagline,
              'description' => $description,
              'features' => $features,
              'badge_label' => $badgeLabel,
              'cta_url' => $ctaUrl,
              'cta_label' => $ctaLabel,
              'icon' => $iconMarkup,
          ];
      }

      $renderStandardPricingPlan = static function (array $plan, string $aos) {
          ob_start();
          ?>
          <div class="card <?php echo $plan['variant'] === 'highlight' ? 'black ' : ''; ?>flex-vertical-40px" data-aos="<?php echo iN_HelpSecure($aos, false); ?>">
            <div class="pricing-card-title">
              <?php if (!empty($plan['icon'])): ?>
                <span class="profilephoto profilephoto--icon" aria-hidden="true"><?php echo $plan['icon']; ?></span>
              <?php endif; ?>
              <h4 class="black-text margin-bottom-0"><?php echo iN_HelpSecure($plan['title']); ?></h4>
            </div>
            <div class="pricing-card-cost">
              <?php if ($plan['badge_label'] !== ''): ?>
                <div class="pricing-cost<?php echo $plan['variant'] === 'highlight' ? ' white' : ''; ?>"><?php echo iN_HelpSecure($plan['badge_label']); ?></div>
              <?php endif; ?>
              <?php if ($plan['tagline'] !== ''): ?>
                <p class="<?php echo $plan['variant'] === 'highlight' ? 'white-text' : ''; ?>"><?php echo iN_HelpSecure($plan['tagline']); ?></p>
              <?php endif; ?>
            </div>
            <?php if ($plan['description'] !== ''): ?>
              <p class="black-text"><?php echo iN_HelpSecure($plan['description']); ?></p>
            <?php endif; ?>
            <?php if (!empty($plan['features'])): ?>
              <div class="divider"></div>
              <ul role="list" class="pricing-card-list">
                <?php foreach ($plan['features'] as $feature): ?>
                  <li class="pricing-card-list-item"><?php echo iN_HelpSecure($feature); ?></li>
                <?php endforeach; ?>
              </ul>
            <?php endif; ?>
            <?php if ($plan['cta_label'] !== '' && $plan['cta_url'] !== ''): ?>
              <div class="pricing-card-buttons">
                <a href="<?php echo iN_HelpSecure($plan['cta_url']); ?>" class="button-large w-button<?php echo $plan['variant'] === 'highlight' ? '' : ' is-secondary'; ?>"><?php echo iN_HelpSecure($plan['cta_label']); ?></a>
              </div>
            <?php endif; ?>
          </div>
          <?php
          return ob_get_clean();
      };

      $renderMutedPricingPlan = static function (array $plan) {
          ob_start();
          ?>
          <div class="card grey flex-vertical-40px">
            <?php if (!empty($plan['icon'])): ?>
              <span class="profilephoto profilephoto--icon" aria-hidden="true"><?php echo $plan['icon']; ?></span>
            <?php endif; ?>
            <h4 class="padding-bottom-0"><?php echo iN_HelpSecure($plan['title']); ?></h4>
            <div class="pricing-card-cost">
              <?php if ($plan['badge_label'] !== ''): ?>
                <div class="pricing-cost"><?php echo iN_HelpSecure($plan['badge_label']); ?></div>
              <?php endif; ?>
              <?php if ($plan['tagline'] !== ''): ?>
                <p class="text-black"><?php echo iN_HelpSecure($plan['tagline']); ?></p>
              <?php endif; ?>
            </div>
            <div class="divider"></div>
          </div>
          <div class="card grey padding-top-0">
            <?php if ($plan['description'] !== ''): ?>
              <div class="pricing-description">
                <p class="card-grey-text"><?php echo iN_HelpSecure($plan['description']); ?></p>
              </div>
            <?php endif; ?>
            <?php if (!empty($plan['features'])): ?>
              <ul role="list" class="pricing-card-list dark-grey">
                <?php foreach ($plan['features'] as $feature): ?>
                  <li class="pricing-card-list-item dark-grey"><?php echo iN_HelpSecure($feature); ?></li>
                <?php endforeach; ?>
              </ul>
            <?php endif; ?>
            <?php if ($plan['cta_label'] !== '' && $plan['cta_url'] !== ''): ?>
              <div class="pricing-card-buttons">
                <a href="<?php echo iN_HelpSecure($plan['cta_url']); ?>" class="button-large w-button is-secondary"><?php echo iN_HelpSecure($plan['cta_label']); ?></a>
              </div>
            <?php endif; ?>
          </div>
          <?php
          return ob_get_clean();
      };
    ?>

<!---->
<!---->
<section class="features-section" id="pricing">
      <h2 class="features-title marker-animation" data-ma_color="#43E97B">
        <?php echo iN_HelpSecure($pricingTitle); ?>
      </h2>
      <?php if ($pricingSubtitle !== ''): ?>
        <p class="features-subtitle"><?php echo iN_HelpSecure($pricingSubtitle); ?></p>
      <?php endif; ?>

      <div class="features-container w-layout-blockcontainer">
        <div class="pricing-cards">
          <?php
            $planCount = count($pricingPlans);
            $pairCount = min(2, $planCount);
            if ($pairCount > 0):
          ?>
            <div class="pricing-card pricing-card--pair">
              <?php for ($i = 0; $i < $pairCount; $i++):
                $plan = $pricingPlans[$i];
                $aos = $i === 0 ? 'fade-right' : 'fade-left';
                echo $renderStandardPricingPlan($plan, $aos);
              endfor; ?>
            </div>
          <?php endif; ?>

          <?php for ($i = $pairCount; $i < $planCount; $i++):
            $plan = $pricingPlans[$i];
            if ($plan['variant'] === 'muted') {
              echo '<div class="pricing-card grey" data-aos="fade-up">';
              echo $renderMutedPricingPlan($plan);
              echo '</div>';
            } else {
              echo '<div class="pricing-card pricing-card--single">';
              echo $renderStandardPricingPlan($plan, 'fade-up');
              echo '</div>';
            }
          endfor; ?>

          <?php if ($pricingNote !== ''): ?>
            <div class="pricing-small-print">
              <p class="paragraph-small"><?php echo iN_HelpSecure($pricingNote); ?></p>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </section>
<!---->
<!---->
<?php
      $earningsSimulatorDefaults = [
          'default_followers' => 1000,
          'default_price' => 10.0,
          'conversion_rate' => 0.2,
      ];
      $earningsSimulatorConfig = $earningsSimulatorDefaults;
      if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionConfig')) {
          $fetchedSimulator = $RL->RL_GetLandingSectionConfig($landingTheme, 'earnings_simulator');
          if (is_array($fetchedSimulator)) {
              $earningsSimulatorConfig = array_replace($earningsSimulatorDefaults, array_intersect_key($fetchedSimulator, $earningsSimulatorDefaults));
          }
      }
      $followersDefault = max(0, min((int) ($earningsSimulatorConfig['default_followers'] ?? 1000), 1000000));
      $priceDefault = (float) ($earningsSimulatorConfig['default_price'] ?? 10.0);
      if (!is_finite($priceDefault)) {
          $priceDefault = 10.0;
      }
      $priceDefault = round($priceDefault, 2);
      if ($priceDefault < 1.0) {
          $priceDefault = 1.0;
      }
      if ($priceDefault > 1000.0) {
          $priceDefault = 1000.0;
      }
      $conversionRate = (float) ($earningsSimulatorConfig['conversion_rate'] ?? 0.2);
      if (!is_finite($conversionRate)) {
          $conversionRate = 0.2;
      }
      if ($conversionRate < 0.0) {
          $conversionRate = 0.0;
      }
      if ($conversionRate > 1.0) {
          $conversionRate = 1.0;
      }

      $currencyCode = '';
      if (isset($globalCurCode) && $globalCurCode !== '') {
          $currencyCode = strtoupper((string) $globalCurCode);
      } elseif (isset($currency) && $currency !== '') {
          $currencyCode = strtoupper((string) $currency);
      }
      if ($currencyCode === '' && isset($RL) && method_exists($RL, 'RL_configs')) {
          $siteConfig = $RL->RL_configs();
          if (is_array($siteConfig)) {
              if (!empty($siteConfig['payments_currency'])) {
                  $currencyCode = strtoupper((string) $siteConfig['payments_currency']);
              } elseif (!empty($siteConfig['site_currency'])) {
                  $currencyCode = strtoupper((string) $siteConfig['site_currency']);
              }
          }
      }
      if ($currencyCode === '') {
          $currencyCode = 'USD';
      }

      $currencyMap = [];
      if (isset($currencies) && is_array($currencies)) {
          $currencyMap = $currencies;
      } elseif (isset($currencys) && is_array($currencys)) {
          $currencyMap = $currencys;
      }
      $currencySymbol = '';
      if (isset($currencyMap[$currencyCode])) {
          $currencySymbol = (string) $currencyMap[$currencyCode];
      }
      if ($currencySymbol === '') {
          $currencySymbol = $currencyCode;
      }

      $currencyFormatSettings = $currencyFormatSettings ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
      $currencyPrecision = dz_currency_resolve_precision($currencyCode, (int) ($currencyFormatSettings['decimal_places'] ?? 2));
      $formatCurrency = static function (float $amount) use ($currencySymbol, $currencyCode, $currencyFormatSettings): string {
          return dz_format_currency($amount, $currencyCode, $currencySymbol, $currencyFormatSettings);
      };
      $formatNumber = static function (float $value, int $precision, array $settings) use ($currencyCode): string {
          $settings['decimal_places'] = $precision;
          return dz_format_number($value, $currencyCode, $settings);
      };
      $inputNumber = static function (float $value, int $precision, array $settings) use ($currencyCode): string {
          $settings['decimal_places'] = $precision;
          $settings['decimal_sep'] = '.';
          $settings['thousands_sep'] = '';

          return dz_format_number($value, $currencyCode, $settings);
      };
      $followersDisplay = $formatNumber((float) $followersDefault, 0, $currencyFormatSettings);
      $priceValueAttr = $inputNumber($priceDefault, $currencyPrecision, $currencyFormatSettings);
      $priceDisplay = $formatCurrency($priceDefault);
      $estimatedSubscribers = (int) round($followersDefault * $conversionRate);
      $estimatedIncome = $estimatedSubscribers * $priceDefault;
      $monthlyDisplay = $formatCurrency($estimatedIncome);
      $conversionPercentRaw = $inputNumber($conversionRate * 100, 2, $currencyFormatSettings);
      $conversionPercentDisplay = rtrim(rtrim($conversionPercentRaw, '0'), '.');
      if ($conversionPercentDisplay === '') {
          $conversionPercentDisplay = '0';
      }
      $resultSuffix = customLang('earnings_simulator_result_suffix', 'USD per month*');
      if (strpos($resultSuffix, '{{currency}}') !== false) {
          $resultSuffix = str_replace('{{currency}}', $currencyCode, $resultSuffix);
      } elseif (strpos($resultSuffix, 'USD') !== false) {
          $resultSuffix = str_replace('USD', $currencyCode, $resultSuffix);
      }
      $disclaimerText = customLang('earnings_simulator_disclaimer', '* Estimate assumes 20% of followers subscribe and excludes platform fees, taxes, payment processor charges, tips, pay-per-view or locked content sales.');
      if (strpos($disclaimerText, '{{conversion}}') !== false) {
          $disclaimerText = str_replace('{{conversion}}', $conversionPercentDisplay . '%', $disclaimerText);
      } elseif (strpos($disclaimerText, '20%') !== false) {
          $disclaimerText = str_replace('20%', $conversionPercentDisplay . '%', $disclaimerText);
      }
      $currencyBadge = $currencySymbol;
      if ($currencyBadge === '' || $currencyBadge === $currencyCode || mb_strlen($currencyBadge) > 4) {
          $currencyBadge = $currencyCode;
      }

      $earningsSimulatorFollowersIcon = render_icon('follow.svg', true);
      if ($earningsSimulatorFollowersIcon === '') {
          $earningsSimulatorFollowersIcon = '<span class="earnings-simulator__icon-fallback" aria-hidden="true">👥</span>';
      }
      $earningsSimulatorCreatorIcon = render_icon('creator_icon.svg', true);
      if ($earningsSimulatorCreatorIcon === '') {
          $earningsSimulatorCreatorIcon = '<span class="earnings-simulator__icon-fallback" aria-hidden="true">⭐</span>';
      }

?>
    <section
      id="earnings-simulator"
      class="earnings-simulator"
      data-conversion-rate="<?php echo iN_HelpSecure((string) $conversionRate, false); ?>"
    >
      <div class="earnings-simulator__inner w-layout-blockcontainer">
        <h2 class="earnings-simulator__title">
          <?php echo iN_HelpSecure(customLang('earnings_simulator_title', 'Creators Earnings Simulator')); ?>
        </h2>
        <p class="earnings-simulator__subtitle">
          <?php echo iN_HelpSecure(customLang('earnings_simulator_subtitle', 'Estimate subscription revenue based on your audience size and price.')); ?>
        </p>
        <div class="earnings-simulator__controls">
          <div class="earnings-simulator__column">
            <label class="earnings-simulator__label" for="followers">
              <span class="earnings-simulator__label-text">
                <?php echo iN_HelpSecure(customLang('earnings_simulator_followers_label', 'Number of followers?')); ?>
              </span>
              <span class="earnings-simulator__icons" aria-hidden="true">
                <?php echo $earningsSimulatorFollowersIcon; ?>
              </span>
            </label>
            <div class="earnings-simulator__slider">
              <input
                type="range"
                id="followers"
                min="0"
                max="1000000"
                step="50"
                value="<?php echo iN_HelpSecure((string) $followersDefault, false); ?>"
                data-default-value="<?php echo iN_HelpSecure((string) $followersDefault, false); ?>"
                aria-label="<?php echo iN_HelpSecure(customLang('earnings_simulator_followers_aria', 'Followers count')); ?>"
              />
              <span id="followersCount" class="earnings-simulator__value"><?php echo iN_HelpSecure($followersDisplay, false); ?></span>
            </div>
          </div>
          <div class="earnings-simulator__column">
            <label class="earnings-simulator__label" for="price">
              <span class="earnings-simulator__label-text">
                <?php echo iN_HelpSecure(customLang('earnings_simulator_price_label', 'Monthly subscription price?')); ?>
              </span>
              <span class="earnings-simulator__icons" aria-hidden="true">
                <?php echo $earningsSimulatorCreatorIcon; ?>
              </span>
            </label>
            <div class="earnings-simulator__slider">
              <input
                type="range"
                id="price"
                min="1"
                max="1000"
                step="0.5"
                value="<?php echo iN_HelpSecure($priceValueAttr, false); ?>"
                data-default-value="<?php echo iN_HelpSecure($priceValueAttr, false); ?>"
                aria-label="<?php echo iN_HelpSecure(customLang('earnings_simulator_price_aria', 'Monthly price')); ?>"
              />
              <span
                id="priceCount"
                class="earnings-simulator__value"
                data-currency-symbol="<?php echo iN_HelpSecure($currencySymbol, false); ?>"
                data-currency-code="<?php echo iN_HelpSecure($currencyCode, false); ?>"
              ><?php echo iN_HelpSecure($priceDisplay, false); ?></span>
            </div>
          </div>
        </div>
        <div class="earnings-simulator__summary">
          <p class="earnings-simulator__result">
            <?php echo iN_HelpSecure(customLang('earnings_simulator_result_prefix', 'You could earn an estimated')); ?>
            <span
              id="monthlyEarning"
              class="earnings-simulator__amount"
              data-currency-symbol="<?php echo iN_HelpSecure($currencySymbol, false); ?>"
              data-currency-code="<?php echo iN_HelpSecure($currencyCode, false); ?>"
              data-conversion-rate="<?php echo iN_HelpSecure((string) $conversionRate, false); ?>"
            ><?php echo iN_HelpSecure($monthlyDisplay, false); ?></span>
            <?php echo iN_HelpSecure($resultSuffix); ?>
          </p>
          <p class="earnings-simulator__disclaimer">
            <?php echo iN_HelpSecure($disclaimerText); ?>
          </p>
          <p class="earnings-simulator__note">
            <?php echo iN_HelpSecure(customLang('earnings_simulator_additional_note', 'Additional revenue from tips, pay-per-view posts, paid messages or merchandise can increase earnings.')); ?>
          </p>
        </div>
      </div>
    </section>
<!---->
<!---->
<?php
      $noHassleFallback = [
          ['label' => customLang('no_hassle_post_reels'),    'color' => '#FF3C3C'],
          ['label' => customLang('no_hassle_grow_fans'),     'color' => '#F67D2E'],
          ['label' => customLang('no_hassle_monetize_subs'), 'color' => '#FFD700'],
          ['label' => customLang('no_hassle_set_access'),    'color' => '#43E97B'],
          ['label' => customLang('no_hassle_sell_videos'),   'color' => '#4F86F7'],
          ['label' => customLang('no_hassle_create_earn'),   'color' => '#9B59B6'],
      ];
      $noHassleLang = isset($currentLang) ? strtolower((string) $currentLang) : 'eng';
      if ($noHassleLang === '') { $noHassleLang = 'eng'; }
      $noHassleFallbackLangs = $noHassleLang !== 'eng' ? ['eng'] : [];
      $noHassleData = ['items' => [], 'config' => ['ma_color' => '#4F86F7']];
      if (isset($RL) && method_exists($RL, 'RL_GetLandingNoHassle')) {
          $noHassleData = $RL->RL_GetLandingNoHassle($landingTheme, $noHassleLang, $noHassleFallbackLangs);
      }
      $noHassleItems = isset($noHassleData['items']) && is_array($noHassleData['items']) ? array_values($noHassleData['items']) : [];
      $noHassleConfig = isset($noHassleData['config']) && is_array($noHassleData['config']) ? $noHassleData['config'] : [];
      $noHassleDefaultColor = isset($noHassleConfig['ma_color']) ? trim((string) $noHassleConfig['ma_color']) : '#4F86F7';
      if ($noHassleDefaultColor === '' || !preg_match('/^#[0-9a-fA-F]{3,8}$/', $noHassleDefaultColor)) {
          $noHassleDefaultColor = '#4F86F7';
      }
      $noHassleDisplay = [];
      if ($noHassleItems) {
          $fallbackCount = count($noHassleFallback);
          foreach ($noHassleItems as $idx => $item) {
              $fallback = $fallbackCount > 0 ? $noHassleFallback[$idx % $fallbackCount] : ['label' => customLang('no_hassle_post_reels'), 'color' => $noHassleDefaultColor];
              $label = trim((string) ($item['label'] ?? ''));
              if ($label === '') {
                  $label = (string) ($fallback['label'] ?? '');
              }
              if ($label === '') {
                  continue;
              }
              $color = trim((string) ($item['color'] ?? ''));
              if ($color === '' || !preg_match('/^#[0-9a-fA-F]{3,8}$/', $color)) {
                  $fallbackColor = (string) ($fallback['color'] ?? '');
                  if ($fallbackColor === '' || !preg_match('/^#[0-9a-fA-F]{3,8}$/', $fallbackColor)) {
                      $fallbackColor = $noHassleDefaultColor;
                  }
                  $color = $fallbackColor;
              }
              $type = isset($item['type']) ? strtolower((string) $item['type']) : 'feature';
              if (!in_array($type, ['feature', 'badge'], true)) {
                  $type = 'feature';
              }
              $icon = trim((string) ($item['icon'] ?? ''));
              $noHassleDisplay[] = [
                  'label' => $label,
                  'color' => $color,
                  'type'  => $type,
                  'icon'  => $icon,
              ];
          }
      }
      if (!$noHassleDisplay) {
          foreach ($noHassleFallback as $fallback) {
              $label = trim((string) ($fallback['label'] ?? ''));
              if ($label === '') { continue; }
              $color = isset($fallback['color']) && preg_match('/^#[0-9a-fA-F]{3,8}$/', $fallback['color']) ? $fallback['color'] : $noHassleDefaultColor;
              $noHassleDisplay[] = [
                  'label' => $label,
                  'color' => $color,
                  'type'  => 'feature',
                  'icon'  => '',
              ];
          }
      }
      $noHassleCount = count($noHassleDisplay);
    ?>
    <section class="no-hassle-section" id="no-hassle">
      <div class="features-container w-layout-blockcontainer-paragraph">
        <h1 class="big-bold-list text-center">
          <?php foreach ($noHassleDisplay as $index => $entry):
        $itemLabel = (string) ($entry['label'] ?? '');
        $itemColor = (string) ($entry['color'] ?? $noHassleDefaultColor);
        if ($itemColor === '' || !preg_match('/^#[0-9a-fA-F]{3,8}$/', $itemColor)) {
            $itemColor = $noHassleDefaultColor;
        }
        $itemType = isset($entry['type']) ? strtolower((string) $entry['type']) : 'feature';
        if (!in_array($itemType, ['feature', 'badge'], true)) {
            $itemType = 'feature';
        }
        $itemIcon = trim((string) ($entry['icon'] ?? ''));
        $iconMarkup = '';
        if ($itemIcon !== '') {
            $iconUrl = '';
            $iconText = '';
            $path = parse_url($itemIcon, PHP_URL_PATH);
            $path = $path !== null ? $path : $itemIcon;
            $looksImage = is_string($path) && preg_match('/\.(svg|png|jpe?g|gif|webp)$/i', $path);
            $isAbsolute = preg_match('#^(https?:)?//#i', $itemIcon) === 1 || strpos($itemIcon, 'data:image') === 0;
            $isRootRelative = !$isAbsolute && $itemIcon !== '' && $itemIcon[0] === '/';
            if ($looksImage || $isAbsolute || $isRootRelative) {
                if (strpos($itemIcon, 'data:image') === 0) {
                    $iconUrl = $itemIcon;
                } elseif (preg_match('#^https?://#i', $itemIcon)) {
                    $iconUrl = $itemIcon;
                } elseif (strpos($itemIcon, '//') === 0) {
                    $iconUrl = 'https:' . $itemIcon;
                } else {
                    $iconUrl = rtrim((string) $base_url, '/') . '/' . ltrim($itemIcon, '/');
                }
            } else {
                $iconText = $itemIcon;
            }
            if ($iconUrl !== '') {
                $iconMarkup = '<span class="no-hassle-icon no-hassle-icon--img">' . renderVerifiedBadge($iconUrl, true) . '</span>';
            } elseif ($iconText !== '') {
                $iconMarkup = '<span class="no-hassle-icon no-hassle-icon--text">' . iN_HelpSecure($iconText) . '</span>';
            }
        }
        $classList = 'marker-animation no-hassle-item';
        if ($itemType === 'badge') {
            $classList .= ' no-hassle-item--badge';
        }
        $classAttr = htmlspecialchars($classList, ENT_QUOTES, 'UTF-8');
        $colorAttr = htmlspecialchars($itemColor, ENT_QUOTES, 'UTF-8');
        $typeAttr = htmlspecialchars($itemType, ENT_QUOTES, 'UTF-8');
        $markerLightColor = $colorAttr;
        $markerDarkRaw = 'var(--bg-elevated)';
        $markerDarkColor = htmlspecialchars($markerDarkRaw, ENT_QUOTES, 'UTF-8');
        $initialMarkerColor = $markerLightColor;
        if ($themePreference === 'dark') {
            $initialMarkerColor = $markerDarkColor;
        }
      ?>
            <p
              class="<?php echo $classAttr; ?>"
              data-ma_color="<?php echo $initialMarkerColor; ?>"
              data-ma_color_light="<?php echo $markerLightColor; ?>"
              data-ma_color_dark="<?php echo $markerDarkColor; ?>"
              data-item-type="<?php echo $typeAttr; ?>"
            >
              <?php if ($iconMarkup !== '') { echo $iconMarkup; } ?>
              <?php echo iN_HelpSecure($itemLabel); ?>
            </p>
            <?php if ($index < $noHassleCount - 1): ?>
              <br />
            <?php endif; ?>
          <?php endforeach; ?>
        </h1>
      </div>
    </section>
<!---->
<!---->
<?php
  $faqLang = isset($currentLang) ? strtolower((string) $currentLang) : 'eng';
  if ($faqLang === '') {
      $faqLang = 'eng';
  }
  $faqFallbackLangs = [];
  if ($faqLang !== 'eng') {
      $faqFallbackLangs[] = 'eng';
  }
  if (!in_array('tr', $faqFallbackLangs, true)) {
      $faqFallbackLangs[] = 'tr';
  }

  $faqFetched = [];
  if (isset($RL) && method_exists($RL, 'RL_GetLandingFaqs')) {
      $faqFetched = $RL->RL_GetLandingFaqs($landingTheme, $faqLang, $faqFallbackLangs);
  }

  $faqDisplayItems = [];
  foreach ($faqFetched as $faqRow) {
      $question = trim((string) ($faqRow['question'] ?? ''));
      $answer = trim((string) ($faqRow['answer'] ?? ''));
      if ($question === '' && $answer === '') {
          continue;
      }
      $faqDisplayItems[] = [
          'question_html' => iN_HelpSecure($question),
          'answer_html' => nl2br(iN_HelpSecure($answer)),
      ];
  }

  if (!$faqDisplayItems) {
      for ($i = 1; $i <= 8; $i++) {
          $questionVal = (string) customLang('faq_q_' . $i);
          $answerVal = (string) customLang('faq_a_' . $i);
          if (trim($questionVal) === '' && trim($answerVal) === '') {
              continue;
          }
          $faqDisplayItems[] = [
              'question_html' => $questionVal,
              'answer_html' => $answerVal,
          ];
      }
  }
?>
<section class="features-section last" id="faqs">
  <h2 class="features-title marker-animation" data-ma_color="#F67D2E">
    <?php echo customLang('faq_title'); ?>
  </h2>
  <div class="features-container w-layout-blockcontainer">
    <div class="faq-container">
      <?php foreach ($faqDisplayItems as $faqItem): ?>
        <div class="faq-item">
          <button class="faq-question">
            <?php echo $faqItem['question_html']; ?><span>+</span>
          </button>
          <div class="faq-answer">
            <p><?php echo $faqItem['answer_html']; ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<!---->
<!---->
<div class="wave-transition"></div>
<!---->
<?php
  $getStartedLang = isset($currentLang) ? strtolower((string) $currentLang) : 'eng';
  if ($getStartedLang === '') {
      $getStartedLang = 'eng';
  }
  $getStartedFallbackLangs = [];
  if ($getStartedLang !== 'eng') {
      $getStartedFallbackLangs[] = 'eng';
  }
  if ($getStartedLang !== 'tr') {
      $getStartedFallbackLangs[] = 'tr';
  }

  $getStartedColor = '#FF3C3C';
  $getStartedContent = [
      'title' => (string) customLang('footer_cta_title'),
      'description' => (string) customLang('footer_cta_subtitle'),
      'button' => (string) customLang('footer_cta_button'),
  ];

  if (isset($RL) && method_exists($RL, 'RL_GetLandingGetStarted')) {
      $ctaData = $RL->RL_GetLandingGetStarted($landingTheme, $getStartedLang, $getStartedFallbackLangs);
      if (isset($ctaData['config']['data_ma_color'])) {
          $rawColor = (string) $ctaData['config']['data_ma_color'];
          if ($rawColor !== '' && preg_match('/^#[0-9a-fA-F]{3,8}$/', $rawColor)) {
              $getStartedColor = $rawColor;
          }
      }
      if (isset($ctaData['content']) && is_array($ctaData['content'])) {
          foreach (['title', 'description', 'button'] as $key) {
              if (!empty($ctaData['content'][$key])) {
                  $getStartedContent[$key] = (string) $ctaData['content'][$key];
              }
          }
      }
  }

  $getStartedContent['title'] = str_ireplace(['<br />','<br/>','<br>'], "\n", $getStartedContent['title']);
  $getStartedContent['description'] = str_ireplace(['<br />','<br/>','<br>'], "\n", $getStartedContent['description']);
  $getStartedContent['button'] = str_ireplace(['<br />','<br/>','<br>'], "\n", $getStartedContent['button']);

  $getStartedTitleHtml = iN_HelpSecure($getStartedContent['title'], true);
  $getStartedTitleHtml = str_replace([' <br>', ' <br/>', ' <br />'], '<br>', $getStartedTitleHtml);

  $getStartedDescriptionHtml = iN_HelpSecure($getStartedContent['description'], true);
  $getStartedDescriptionHtml = str_replace([' <br>', ' <br/>', ' <br />'], '<br>', $getStartedDescriptionHtml);

  $getStartedButtonHtml = iN_HelpSecure($getStartedContent['button'], true);
  $getStartedButtonHtml = str_replace([' <br>', ' <br/>', ' <br />'], '<br>', $getStartedButtonHtml);

?>
<section class="footer" id="get-started">
  <div class="container w-layout-blockcontainer hero-copy">
    <h1 class="marker-animation" data-ma_color="<?php echo iN_HelpSecure($getStartedColor, false); ?>">
      <?php echo $getStartedTitleHtml; ?>
    </h1>
    <p class="p-intro max-width-680px light-grey">
      <?php echo $getStartedDescriptionHtml; ?>
    </p>
    <a href="register.php" class="button-hero light-grey w-button">
      <?php echo $getStartedButtonHtml; ?>
    </a>
  </div>
  <!---->
  <div class="footer-small-print">
    <div class="copyright">
      <p class="white-text"><?php echo customLang('footer_copyright'); ?></p>
    </div>
    <?php include __DIR__ . '/partials/footer_links.php'; ?>
  </div>
  <!---->
</section>
<!---->
    <button
      type="button"
      class="theme-toggle"
      data-theme-toggle
      data-storage-key="landing_theme_mode"
      data-label-light="<?php echo customLang('theme_toggle_light', 'Switch to light mode'); ?>"
      data-label-dark="<?php echo customLang('theme_toggle_dark', 'Switch to dark mode'); ?>"
      data-icon-light="☀️"
      data-icon-dark="🌙"
      aria-label="<?php echo iN_HelpSecure($initialToggleAria); ?>"
      data-mode="<?php echo $initialToggleMode; ?>"
    ><?php echo $initialToggleIcon; ?></button>
<!-- Inline script removed for CSP compliance; handled by js/welcome.js -->
    <?php $welcomeJsVersion = (int) @filemtime(__DIR__ . '/js/welcome.js'); ?>
    <script defer src="<?php echo iN_HelpSecure($base_url) . 'themes/' . iN_HelpSecure($currentTheme); ?>/js/welcome.js?v=<?php echo $welcomeJsVersion; ?>"></script>
    <?php include "head/footer_js.php";?>
  </body>
</html>
