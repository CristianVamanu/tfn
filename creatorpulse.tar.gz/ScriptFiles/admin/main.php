<?php
declare(strict_types=1);

// Admin shell identical to themes/default/main.php but routing to admin pages
// Pre-req: _bootstrap.php and _init.php should be required by caller (index.php)

$themeName = isset($currentTheme) && is_string($currentTheme) && $currentTheme !== '' ? $currentTheme : 'default';
$themeBase = __DIR__ . '/../themes/' . $themeName;
if (!is_dir($themeBase)) { $themeBase = __DIR__ . '/../themes/default'; }

// Resolve layout file but restrict to admin/pages only
$requested = isset($layoutFile) ? (string)$layoutFile : '';
$pagesDir  = realpath(__DIR__ . '/pages') ?: (__DIR__ . '/pages');
$realReq   = realpath($requested);
if (!$realReq || strpos($realReq, $pagesDir) !== 0 || !is_file($realReq)) {
    $realReq = __DIR__ . '/pages/dashboard.php';
}

$__isLoggedIn = isset($loggedIn) && $loggedIn === '1';
$__frontendCsrf = generateCsrfToken();
$isRTLLocale = isset($isRTLLocale) ? (bool) $isRTLLocale : false;
$currentLocale = isset($currentLocale) && $currentLocale !== ''
    ? strtolower((string) $currentLocale)
    : strtolower((string) ($currentLang ?? 'eng'));
if ($currentLocale === '') {
    $currentLocale = 'eng';
}
$__langAttr = $currentLocale;
$__dirAttr = $isRTLLocale ? 'rtl' : 'ltr';
$__bodyClasses = ['admin-shell'];
if ($isRTLLocale) { $__bodyClasses[] = 'rtl-locale'; }

$__themePreference = null;
if (isset($_COOKIE['theme_preference'])) {
    $__themePreference = strtolower((string) $_COOKIE['theme_preference']);
} elseif (isset($_COOKIE['landing_theme_mode'])) {
    $__themePreference = strtolower((string) $_COOKIE['landing_theme_mode']);
}
if ($__themePreference !== 'dark' && $__themePreference !== 'light') {
    $__themePreference = 'auto';
}
$__initialThemeClass = $__themePreference === 'dark'
    ? 'theme-dark'
    : ($__themePreference === 'light' ? 'theme-light' : '');
if ($__initialThemeClass !== '') {
    $__bodyClasses[] = $__initialThemeClass;
}
$__bodyClassAttr = implode(' ', $__bodyClasses);

// Bust caches when admin assets update by appending file mtimes
$adminCssVersion = isset($version) ? (string) $version : '1.0.0';
$adminJsVersion  = $adminCssVersion;
$adminCssFile = __DIR__ . '/assets/admin.css';
$adminJsFile  = __DIR__ . '/assets/admin.js';
if (is_file($adminCssFile)) {
    $adminCssVersion .= '.' . (string) filemtime($adminCssFile);
}
if (is_file($adminJsFile)) {
    $adminJsVersion .= '.' . (string) filemtime($adminJsFile);
}

?>
<!doctype html>
<html
  lang="<?php echo htmlspecialchars($__langAttr, ENT_QUOTES, 'UTF-8'); ?>"
  dir="<?php echo $__dirAttr; ?>"
  data-theme="<?php echo htmlspecialchars($__themePreference, ENT_QUOTES, 'UTF-8'); ?>"
  <?php if ($__initialThemeClass !== ''): ?>
  class="<?php echo htmlspecialchars($__initialThemeClass, ENT_QUOTES, 'UTF-8'); ?>"
  <?php endif; ?>
>
  <head>
    <meta charset="UTF-8" />
    <title><?php echo iN_HelpSecure('Admin – ' . ($siteTitle ?? '')); ?></title>
    <?php if (is_file($themeBase . '/head/meta.php')) { include $themeBase . '/head/meta.php'; } ?>
    <?php if (is_file($themeBase . '/head/css.php'))  { include $themeBase . '/head/css.php'; } ?>
    <link rel="stylesheet" href="<?php echo iN_HelpSecure($base_url); ?>admin/assets/admin.css?v=<?php echo iN_HelpSecure($adminCssVersion);?>" />
    <?php if ($isRTLLocale): ?>
    <link rel="stylesheet" href="<?php echo iN_HelpSecure($base_url); ?>admin/assets/rtl.css?v=<?php echo iN_HelpSecure($adminCssVersion);?>" />
    <?php endif; ?>
    <meta name="admin-csrf" content="<?php echo htmlspecialchars($ADMIN_CSRF ?? generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
    <?php if (is_file($themeBase . '/head/js.php'))   { include $themeBase . '/head/js.php'; } ?>
  </head>
<body
  class="<?php echo htmlspecialchars($__bodyClassAttr, ENT_QUOTES, 'UTF-8'); ?>"
  dir="<?php echo $__dirAttr; ?>"
  data-dir="<?php echo $__dirAttr; ?>"
  data-logged-in="<?php echo $__isLoggedIn ? '1' : '0'; ?>"
  data-layout="admin"
  data-theme="<?php echo htmlspecialchars($__themePreference, ENT_QUOTES, 'UTF-8'); ?>"
>
  <input
      type="hidden"
      name="csrf_token"
      value="<?php echo htmlspecialchars($ADMIN_CSRF ?? generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>"
  />
  <input type="hidden" id="frontendCsrfToken" value="<?php echo htmlspecialchars($__frontendCsrf, ENT_QUOTES, 'UTF-8'); ?>">
  <div class="site_container flex flexBoxColumn">
    <?php if (is_file($themeBase . '/header/header.php')) { include $themeBase . '/header/header.php'; } ?>
    <?php echo '<div class="sidebar_container flex relative sidebar_scroll">'; ?>
      <?php include __DIR__ . '/menu.php'; ?>
      <div class="main-content flex align_items">
        <div class="content-area flex">
          <div class="content-left-admin">
            <div class="content-left-container-admin flex align_items flexBoxColumn">
              <div class="full-width">
                <?php if (defined('APP_DEBUG') && APP_DEBUG === true && function_exists('opcache_invalidate')) { @opcache_invalidate($realReq, true); } include $realReq; ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    <?php echo '</div>'; ?>
    <?php if (is_file($themeBase . '/head/footer_js.php')) { include $themeBase . '/head/footer_js.php'; } ?>
  </div>
  <div id="popup-root"></div>
  <?php
    // Load Chart.js from preferred paths
    $chartRel = null;
    $candidates = [
      '/js/vendor/chart.umd.min.js',           // requested path
      '/js/vendor/chartJs/chart.umd.min.js',   // legacy path
      '/assets/vendor/chart.umd.min.js',       // older assets path
    ];
    foreach ($candidates as $rel) {
      if (is_file(__DIR__ . $rel)) { $chartRel = 'admin' . $rel; break; }
    }
    if ($chartRel): ?>
    <script defer src="<?php echo iN_HelpSecure($base_url . $chartRel); ?>?v=<?php echo iN_HelpSecure($version);?>"></script>
  <?php endif; ?>
  <script defer src="<?php echo iN_HelpSecure($base_url); ?>admin/assets/admin.js?v=<?php echo iN_HelpSecure($adminJsVersion);?>"></script>
</body>
</html>
