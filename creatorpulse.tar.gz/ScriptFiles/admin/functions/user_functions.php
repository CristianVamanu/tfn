<?php
declare(strict_types=1);

trait AdminUserFunctions
{
    /**
     * Cache for i_users column listing to avoid repeated DESCRIBE calls.
     *
     * @var array<int, string>|null
     */
    private ?array $admUserColumnCache = null;

    /** Ensure schema has is_banned column; portable fallback if IF NOT EXISTS unsupported. */
    protected function ensureUserBanColumn(): void
    {
        try {
            // MySQL 8+ supports IF NOT EXISTS; wrap with fallback check
            $this->db()->exec("ALTER TABLE i_users ADD COLUMN IF NOT EXISTS is_banned TINYINT(1) NOT NULL DEFAULT 0");
        } catch (\Throwable $__) {
            try { $this->db()->query("SELECT is_banned FROM i_users LIMIT 0"); } catch (\Throwable $___) {}
        }
    }

    /** Ensure schema has is_fake column available for generated accounts. */
    protected function ensureFakeUserColumn(): void
    {
        try {
            $this->db()->exec("ALTER TABLE i_users ADD COLUMN IF NOT EXISTS is_fake TINYINT(1) NOT NULL DEFAULT 0");
        } catch (\Throwable $__) {
            try { $this->db()->query("SELECT is_fake FROM i_users LIMIT 0"); } catch (\Throwable $___) {}
        }
    }

    /**
     * List columns available on i_users table.
     *
     * @return array<int,string>
     */
    protected function getUserTableColumns(): array
    {
        if ($this->admUserColumnCache !== null) {
            return $this->admUserColumnCache;
        }

        $cols = [];
        try {
            $stmt = $this->db()->query('SHOW COLUMNS FROM i_users');
            if ($stmt) {
                $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
                foreach ($rows as $row) {
                    if (isset($row['Field'])) {
                        $cols[] = (string) $row['Field'];
                    }
                }
            }
        } catch (\Throwable $__) {
            // Ignore; fallback to empty list.
        }

        $this->admUserColumnCache = $cols;
        return $cols;
    }

    /**
     * Bulk-create fake user accounts for testing purposes.
     *
     * @param int    $count    Number of users to create (clamped 1-1000).
     * @param string $password Plaintext password applied to each generated account.
     *
     * @return array{created:int,users:array<int,array{id:int,username:string,email:string}>,errors:array<int,string>}
     */
    public function ADM_CreateFakeUsers(int $count, string $password): array
    {
        $result = [
            'created' => 0,
            'users'   => [],
            'errors'  => [],
        ];

        $count = max(1, min(1000, $count));
        $password = trim($password);
        if ($password === '') {
            $result['errors'][] = 'missing_password';
            return $result;
        }

        $this->ensureFakeUserColumn();
        $columns = $this->getUserTableColumns();
        $columnSet = array_flip($columns);

        // Username, email, and password columns are mandatory; abort if schema differs.
        foreach (['username', 'user_email', 'user_password'] as $required) {
            if (!isset($columnSet[$required])) {
                $this->logError('ADM_CreateFakeUsers missing required column: ' . $required);
                $result['errors'][] = 'missing_columns';
                return $result;
            }
        }

        $db = $this->db();
        $now = time();
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $defaultAvatar = isset($columnSet['user_avatar']) ? 'uploads/user_avatars/default.jpeg' : null;
        $bioText = 'Generated user for engagement testing.';
        $firstNames = ['Avery', 'Blake', 'Casey', 'Devin', 'Eden', 'Felix', 'Harper', 'Indie', 'Jordan', 'Kai', 'Luca', 'Mira', 'Niko', 'Oakley', 'Pax', 'Quinn'];
        $lastNames  = ['Adler', 'Bennett', 'Cameron', 'Dalton', 'Ellis', 'Fletcher', 'Grayson', 'Hayes', 'Irwin', 'Jennings', 'Keaton', 'Lang', 'Monroe', 'Nolan', 'Orion', 'Prescott'];

        // Prepare reusable statements for uniqueness checks.
        $usernameCheck = $db->prepare('SELECT COUNT(*) FROM i_users WHERE username = :u LIMIT 1');
        $emailCheck    = $db->prepare('SELECT COUNT(*) FROM i_users WHERE user_email = :e LIMIT 1');

        $insertColumns = [
            'username',
            'user_fullname',
            'user_email',
            'user_password',
            'user_type',
            'user_mode',
            'last_login_time',
            'user_avatar',
            'verified_status',
            'subscrition_status',
            'about_me',
            'wallet',
            'earned',
            'for_billing_first_name',
            'for_billing_last_name',
            'who_can_send_message',
            'subscription_status',
            'is_fake',
            'created_at',
        ];
        // Retain only columns present in schema
        $insertColumns = array_values(array_filter($insertColumns, static function (string $col) use ($columnSet): bool {
            return isset($columnSet[$col]);
        }));

        $placeholderList = array_map(static function (string $col): string {
            return ':' . $col;
        }, $insertColumns);
        $insertSql = 'INSERT INTO i_users (' . implode(', ', $insertColumns) . ') VALUES (' . implode(', ', $placeholderList) . ')';
        $insertStmt = $db->prepare($insertSql);

        try {
            $db->beginTransaction();

            for ($i = 0; $i < $count; $i++) {
                $firstName = $firstNames[random_int(0, count($firstNames) - 1)];
                $lastName  = $lastNames[random_int(0, count($lastNames) - 1)];
                $fullName  = $firstName . ' ' . $lastName;

                $createdAt   = max(0, $now - random_int(0, 604800));
                $lastLoginAt = min($now, $createdAt + random_int(0, 86400));

                $username = '';
                for ($attempt = 0; $attempt < 10; $attempt++) {
                    $candidate = 'fake_user_' . strtolower(bin2hex(random_bytes(3)));
                    $usernameCheck->execute([':u' => $candidate]);
                    $exists = (int) ($usernameCheck->fetchColumn() ?: 0);
                    $usernameCheck->closeCursor();
                    if ($exists === 0) {
                        $username = $candidate;
                        break;
                    }
                }
                if ($username === '') {
                    throw new \RuntimeException('Unable to generate unique username');
                }

                $email = '';
                for ($attempt = 0; $attempt < 10; $attempt++) {
                    $seed = (string) ((int) (microtime(true) * 1000000));
                    $candidate = 'fake+' . $seed . $i . random_int(100, 999) . '@example.com';
                    $emailCheck->execute([':e' => $candidate]);
                    $exists = (int) ($emailCheck->fetchColumn() ?: 0);
                    $emailCheck->closeCursor();
                    if ($exists === 0) {
                        $email = $candidate;
                        break;
                    }
                }
                if ($email === '') {
                    throw new \RuntimeException('Unable to generate unique email');
                }

                $params = [];
                foreach ($insertColumns as $column) {
                    switch ($column) {
                        case 'username':
                            $params[':username'] = $username;
                            break;
                        case 'user_fullname':
                            $params[':user_fullname'] = $fullName;
                            break;
                        case 'user_email':
                            $params[':user_email'] = $email;
                            break;
                        case 'user_password':
                            $params[':user_password'] = $hash;
                            break;
                        case 'user_type':
                            $params[':user_type'] = 1;
                            break;
                        case 'user_mode':
                            $params[':user_mode'] = 'user';
                            break;
                        case 'last_login_time':
                            $params[':last_login_time'] = $lastLoginAt;
                            break;
                        case 'user_avatar':
                            $params[':user_avatar'] = $defaultAvatar;
                            break;
                        case 'verified_status':
                            $params[':verified_status'] = 1;
                            break;
                        case 'subscrition_status':
                            $params[':subscrition_status'] = 'passive';
                            break;
                        case 'about_me':
                            $params[':about_me'] = $bioText;
                            break;
                        case 'wallet':
                            $params[':wallet'] = '0';
                            break;
                        case 'earned':
                            $params[':earned'] = '0';
                            break;
                        case 'for_billing_first_name':
                            $params[':for_billing_first_name'] = $firstName;
                            break;
                        case 'for_billing_last_name':
                            $params[':for_billing_last_name'] = $lastName;
                            break;
                        case 'who_can_send_message':
                            $params[':who_can_send_message'] = 'everyone';
                            break;
                        case 'subscription_status':
                            $params[':subscription_status'] = 'close';
                            break;
                        case 'is_fake':
                            $params[':is_fake'] = 1;
                            break;
                        case 'created_at':
                            $params[':created_at'] = $createdAt;
                            break;
                        default:
                            // Should not reach due to filtered columns, but guard just in case
                            $params[':' . $column] = null;
                            break;
                    }
                }

                $insertStmt->execute($params);
                $newId = (int) $db->lastInsertId();
                $result['users'][] = [
                    'id'       => $newId,
                    'username' => $username,
                    'email'    => $email,
                ];
            }

            $db->commit();
            $result['created'] = count($result['users']);
        } catch (\Throwable $e) {
            try { $db->rollBack(); } catch (\Throwable $__) {}
            $this->logError('ADM_CreateFakeUsers failed: ' . $e->getMessage());
            $result['errors'][] = 'server_error';
        }

        return $result;
    }

    public function ADM_BanUser(int $userId): bool
    {
        if ($userId <= 0 || $userId === 1) { return false; }
        try {
            $this->ensureUserBanColumn();
            $st = $this->db()->prepare('UPDATE i_users SET is_banned = 1 WHERE user_id = :u LIMIT 1');
            return (bool) $st->execute([':u' => $userId]);
        } catch (\Throwable $e) {
            $this->logError('ADM_BanUser failed: ' . $e->getMessage());
            return false;
        }
    }

    public function ADM_UnbanUser(int $userId): bool
    {
        if ($userId <= 0 || $userId === 1) { return false; }
        try {
            $this->ensureUserBanColumn();
            $st = $this->db()->prepare('UPDATE i_users SET is_banned = 0 WHERE user_id = :u LIMIT 1');
            return (bool) $st->execute([':u' => $userId]);
        } catch (\Throwable $e) {
            $this->logError('ADM_UnbanUser failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Overview stats for a user (posts/followers/following/subscribers/tips).
     * Returns: [posts, followers, following, subscribers, tips_count, tips_sum]
     */
    public function ADM_UserOverviewStats(int $userId): array
    {
        $out = [
            'posts'       => 0,
            'followers'   => 0,
            'following'   => 0,
            'subscribers' => 0,
            'tips_count'  => 0,
            'tips_sum'    => 0.0,
        ];
        if ($userId <= 0) { return $out; }
        $db = $this->db();
        $now = time();
        try {
            $out['posts'] = (int) $db->query('SELECT COUNT(*) FROM i_user_posts WHERE post_owner_id = ' . (int)$userId)->fetchColumn();
        } catch (\Throwable $__) {}
        try {
            $st = $db->prepare("SELECT COUNT(*) FROM i_friends WHERE fr_two = :u AND fr_status IN ('flwr','subscriber')");
            $st->execute([':u'=>$userId]);
            $out['followers'] = (int)$st->fetchColumn();
        } catch (\Throwable $__) {}
        try {
            $st = $db->prepare("SELECT COUNT(*) FROM i_friends WHERE fr_one = :u AND fr_status IN ('flwr','subscriber')");
            $st->execute([':u'=>$userId]);
            $out['following'] = (int)$st->fetchColumn();
        } catch (\Throwable $__) {}
        try {
            $st = $db->prepare("SELECT COUNT(DISTINCT buyer_id) FROM i_subscription_payments WHERE recipient_id = :u AND status = 'succeeded' AND (current_period_end IS NULL OR current_period_end > :now)");
            $st->execute([':u'=>$userId, ':now'=>$now]);
            $out['subscribers'] = (int)$st->fetchColumn();
        } catch (\Throwable $__) {}
        try {
            $st = $db->prepare("SELECT COUNT(*), COALESCE(SUM(net_amount),0) FROM i_tip_payments WHERE recipient_id = :u AND status = 'succeeded'");
            $st->execute([':u'=>$userId]);
            $row = $st->fetch(\PDO::FETCH_NUM);
            if ($row) { $out['tips_count'] = (int)$row[0]; $out['tips_sum'] = (float)$row[1]; }
        } catch (\Throwable $__) {}

        return $out;
    }

    /**
     * Handle avatar/cover upload for a user. Validates mime, moves file under
     * uploads/user_avatars or uploads/user_covers, removes previous file if local,
     * and updates DB column (user_avatar or user_cover). Returns relative path on success.
     *
     * @param int   $userId
     * @param string $type   'avatar'|'cover'
     * @param array $file    $_FILES[$type]
     * @return string|false  Relative path or false on failure
     */
    public function ADM_UpdateUserMedia(int $userId, string $type, array $file)
    {
        if ($userId <= 0) { return false; }
        $type = strtolower(trim($type));
        if (!in_array($type, ['avatar','cover'], true)) { return false; }
        if (empty($file) || !isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) { return false; }
        $tmp = $file['tmp_name'];
        $info = @getimagesize($tmp);
        if (!$info) { return false; }
        $mime = (string)($info['mime'] ?? '');
        if (!in_array($mime, ['image/jpeg','image/png','image/webp'], true)) { return false; }
        $ext = $mime === 'image/png' ? 'png' : ($mime === 'image/webp' ? 'webp' : 'jpg');
        $dir = $type === 'avatar' ? 'uploads/user_avatars' : 'uploads/user_covers';
        $base = dirname(__DIR__, 2);
        $absDir = $base . '/' . $dir;
        if (!is_dir($absDir)) { @mkdir($absDir, 0775, true); }
        $name = $type . '_' . $userId . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $relPath = $dir . '/' . $name;
        $absPath = $base . '/' . $relPath;
        if (!@move_uploaded_file($tmp, $absPath)) { return false; }
        @chmod($absPath, 0664);

        // Remove previous local file
        $col = $type === 'avatar' ? 'user_avatar' : 'user_cover';
        try {
            $st = $this->db()->prepare('SELECT ' . $col . ' FROM i_users WHERE user_id = :u LIMIT 1');
            $st->execute([':u'=>$userId]);
            $prev = (string)($st->fetchColumn() ?: '');
            if ($prev !== '' && strpos($prev, $dir . '/') === 0) {
                $old = $base . '/' . $prev;
                if (is_file($old)) { @unlink($old); }
            }
        } catch (\Throwable $__) {}

        // Update DB
        try {
            $st = $this->db()->prepare('UPDATE i_users SET ' . $col . ' = :p WHERE user_id = :u LIMIT 1');
            if (!$st->execute([':p'=>$relPath, ':u'=>$userId])) { return false; }
            return $relPath;
        } catch (\Throwable $__) { return false; }
    }

    /** Set user role. If user_mode column exists, set it; always update numeric fallback user_type. */
    public function ADM_SetUserRole(int $userId, string $role): bool
    {
        if ($userId <= 0 || $userId === 1) { return false; }
        $role = strtolower(trim($role));
        $allowed = ['user','moderator','admin'];
        if (!in_array($role, $allowed, true)) { return false; }
        $type = ($role === 'admin') ? 3 : (($role === 'moderator') ? 2 : 1);
        try {
            $db = $this->db();
            // Detect user_mode column
            $hasUserMode = false;
            try { $db->query('SELECT user_mode FROM i_users LIMIT 0'); $hasUserMode = true; } catch (\Throwable $__) { $hasUserMode = false; }
            if ($hasUserMode) {
                $st = $db->prepare('UPDATE i_users SET user_mode = :m, user_type = :t WHERE user_id = :u LIMIT 1');
                return (bool)$st->execute([':m'=>$role, ':t'=>$type, ':u'=>$userId]);
            }
            $st = $db->prepare('UPDATE i_users SET user_type = :t WHERE user_id = :u LIMIT 1');
            return (bool)$st->execute([':t'=>$type, ':u'=>$userId]);
        } catch (\Throwable $e) {
            $this->logError('ADM_SetUserRole failed: ' . $e->getMessage());
            return false;
        }
    }

    /** Delete a user and main related data with a best-effort cascade. */
    public function ADM_DeleteUserCascade(int $userId): bool
    {
        if ($userId <= 0 || $userId === 1) { return false; }
        try {
            // 1) Delete user's posts using existing cascade util
            try {
                $stp = $this->db()->prepare('SELECT post_id FROM i_user_posts WHERE post_owner_id = :u');
                $stp->execute([':u'=>$userId]);
                $postIds = $stp->fetchAll(\PDO::FETCH_COLUMN, 0) ?: [];
                foreach ($postIds as $pid) {
                    $this->ADM_DeletePostCascade((int)$pid);
                }
            } catch (\Throwable $__) { /* ignore */ }

            $db = $this->db();
            $db->beginTransaction();
            // 2) Messages
            try { $db->prepare('DELETE FROM i_messages WHERE user_one = :u OR user_two = :u')->execute([':u'=>$userId]); } catch (\Throwable $__) {}
            // 3) Followers / Following
            try { $db->prepare('DELETE FROM i_friends WHERE fr_one = :u OR fr_two = :u')->execute([':u'=>$userId]); } catch (\Throwable $__) {}
            // 4) Likes & bookmarks
            try { $db->prepare('DELETE FROM i_post_liked WHERE uid_fk = :u')->execute([':u'=>$userId]); } catch (\Throwable $__) {}
            try { $db->prepare('DELETE FROM i_comment_liked WHERE uid_fk = :u')->execute([':u'=>$userId]); } catch (\Throwable $__) {}
            try { $db->prepare('DELETE FROM i_bookmarks WHERE uid_fk = :u')->execute([':u'=>$userId]); } catch (\Throwable $__) {}
            // 5) Comments
            try { $db->prepare('DELETE FROM i_comments WHERE uid_fk = :u')->execute([':u'=>$userId]); } catch (\Throwable $__) {}
            // 6) Sessions
            try { $db->prepare('DELETE FROM i_sessions WHERE session_uid = :u')->execute([':u'=>$userId]); } catch (\Throwable $__) {}
            // 7) Finally delete the user row
            $ok = false;
            try { $ok = (bool)$db->prepare('DELETE FROM i_users WHERE user_id = :u LIMIT 1')->execute([':u'=>$userId]); } catch (\Throwable $__) { $ok = false; }
            $db->commit();
            return $ok;
        } catch (\Throwable $e) {
            try { $this->db()->rollBack(); } catch (\Throwable $__) {}
            $this->logError('ADM_DeleteUserCascade failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * List users for admin table with optional search.
     * Returns fields: user_id, username, user_email, user_type, verified_status, is_banned
     */
    public function ADM_ListUsers(string $q = '', int $limit = 50): array
    {
        $limit = max(1, min(200, $limit));
        $this->ensureUserBanColumn();

        $sql = 'SELECT user_id, username, user_email, user_type, verified_status, is_banned FROM i_users';
        $params = [];
        if ($q !== '') {
            $sql .= ' WHERE (username LIKE :q OR user_email LIKE :q)';
            $params[':q'] = '%' . $q . '%';
        }
        $sql .= ' ORDER BY user_id DESC LIMIT ' . $limit;

        try {
            $st = $this->db()->prepare($sql);
            $st->execute($params);
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            $this->logError('ADM_ListUsers failed: ' . $e->getMessage());
            return [];
        }
    }
}
