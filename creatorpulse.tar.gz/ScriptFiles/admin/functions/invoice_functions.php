<?php
declare(strict_types=1);

/**
 * Admin Invoice Functions
 *
 * - Encapsulates read-only invoice queries for Subscriptions and Tips
 * - Keeps SQL out of view files to satisfy code quality guidelines
 */
trait AdminInvoiceFunctions
{
    /**
     * Fetch a single subscription payment with buyer/recipient display fields.
     *
     * Output keys (subset):
     *  - All columns from i_subscription_payments (id, buyer_id, recipient_id, amount, currency, status, provider, reference,
     *    plan_interval, interval_count, created_at, started_at, current_period_end, cancelled_at, ...)
     *  - buyer_username, buyer_fullname, buyer_email, buyer_avatar
     *  - recip_username, recip_fullname, recip_email, recip_avatar
     *
     * @return array|null Normalized associative row or null when not found.
     */
    public function ADM_GetSubscriptionInvoice(int $id): ?array
    {
        if ($id <= 0) { return null; }
        try {
            $sql = 'SELECT sp.*, 
                           ub.username AS buyer_username,
                           COALESCE(ub.user_fullname, ub.username) AS buyer_fullname,
                           ub.user_email AS buyer_email,
                           ub.user_avatar AS buyer_avatar,
                           ur.username AS recip_username,
                           COALESCE(ur.user_fullname, ur.username) AS recip_fullname,
                           ur.user_email AS recip_email,
                           ur.user_avatar AS recip_avatar
                    FROM i_subscription_payments sp
                    INNER JOIN i_users ub ON ub.user_id = sp.buyer_id
                    INNER JOIN i_users ur ON ur.user_id = sp.recipient_id
                    WHERE sp.id = :id
                    LIMIT 1';
            $st = $this->db()->prepare($sql);
            $st->execute([':id' => $id]);
            $row = $st->fetch(\PDO::FETCH_ASSOC) ?: null;
            if (!$row) { return null; }

            // Normalize: ensure avatars fallback
            if (empty($row['buyer_fullname'])) { $row['buyer_fullname'] = $row['buyer_username'] ?? ''; }
            if (empty($row['recip_fullname'])) { $row['recip_fullname'] = $row['recip_username'] ?? ''; }
            if (empty($row['buyer_avatar']))  { $row['buyer_avatar']  = 'uploads/user_avatars/default.jpeg'; }
            if (empty($row['recip_avatar']))  { $row['recip_avatar']  = 'uploads/user_avatars/default.jpeg'; }
            return $row;
        } catch (\Throwable $e) {
            $this->logError('ADM_GetSubscriptionInvoice failed: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Fetch a single tip payment with buyer/recipient display fields.
     *
     * Output keys (subset):
     *  - All columns from i_tip_payments (id, buyer_id, recipient_id, post_id, amount, net_amount, fee_amount, currency,
     *    status, provider, reference, created_at, ...)
     *  - buyer_username, buyer_fullname, buyer_email, buyer_avatar
     *  - recip_username, recip_fullname, recip_email, recip_avatar
     *
     * @return array|null Normalized associative row or null when not found.
     */
    public function ADM_GetTipInvoice(int $id): ?array
    {
        if ($id <= 0) { return null; }
        try {
            $sql = 'SELECT tp.*, 
                           ub.username AS buyer_username,
                           COALESCE(ub.user_fullname, ub.username) AS buyer_fullname,
                           ub.user_email AS buyer_email,
                           ub.user_avatar AS buyer_avatar,
                           ur.username AS recip_username,
                           COALESCE(ur.user_fullname, ur.username) AS recip_fullname,
                           ur.user_email AS recip_email,
                           ur.user_avatar AS recip_avatar
                    FROM i_tip_payments tp
                    INNER JOIN i_users ub ON ub.user_id = tp.buyer_id
                    INNER JOIN i_users ur ON ur.user_id = tp.recipient_id
                    WHERE tp.id = :id
                    LIMIT 1';
            $st = $this->db()->prepare($sql);
            $st->execute([':id' => $id]);
            $row = $st->fetch(\PDO::FETCH_ASSOC) ?: null;
            if (!$row) { return null; }

            if (empty($row['buyer_fullname'])) { $row['buyer_fullname'] = $row['buyer_username'] ?? ''; }
            if (empty($row['recip_fullname'])) { $row['recip_fullname'] = $row['recip_username'] ?? ''; }
            if (empty($row['buyer_avatar']))  { $row['buyer_avatar']  = 'uploads/user_avatars/default.jpeg'; }
            if (empty($row['recip_avatar']))  { $row['recip_avatar']  = 'uploads/user_avatars/default.jpeg'; }
            return $row;
        } catch (\Throwable $e) {
            $this->logError('ADM_GetTipInvoice failed: ' . $e->getMessage());
            return null;
        }
    }

    public function ADM_GetAudioRoomInvoice(string $type, int $id): ?array
    {
        if ($id <= 0 || !in_array($type, ['audio_room_ticket', 'audio_room_tip'], true)) {
            return null;
        }
        try {
            $sourceTable = $type === 'audio_room_ticket' ? 'i_audio_room_tickets' : 'i_audio_room_tip_events';
            $sql = 'SELECT inv.*,
                           src.room_id,
                           room.title AS room_title,
                           ub.username AS buyer_username,
                           COALESCE(ub.user_fullname, ub.username) AS buyer_fullname,
                           ub.user_email AS buyer_email,
                           ub.user_avatar AS buyer_avatar,
                           ur.username AS recip_username,
                           COALESCE(ur.user_fullname, ur.username) AS recip_fullname,
                           ur.user_email AS recip_email,
                           ur.user_avatar AS recip_avatar
                    FROM i_invoices inv
                    INNER JOIN ' . $sourceTable . ' src ON src.id = inv.source_id
                    LEFT JOIN i_audio_rooms room ON room.room_id = src.room_id
                    LEFT JOIN i_users ub ON ub.user_id = inv.buyer_id
                    LEFT JOIN i_users ur ON ur.user_id = inv.seller_id
                    WHERE inv.source_type = :type AND inv.source_id = :id
                    LIMIT 1';
            $st = $this->db()->prepare($sql);
            $st->execute([':type' => $type, ':id' => $id]);
            return $st->fetch(\PDO::FETCH_ASSOC) ?: null;
        } catch (\Throwable $e) {
            $this->logError('ADM_GetAudioRoomInvoice failed: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Mask potentially sensitive values in strings.
     * - Emails -> first char + *** + domain
     * - Long digit/hex sequences -> keep last 4
     * - Common secret/token patterns -> redact value portion
     */
    protected function ADM_MaskSensitive(?string $text): string
    {
        if (!is_string($text) || $text === '') { return ''; }
        $out = $text;
        // Emails
        $out = preg_replace_callback('/([A-Za-z0-9_\.+-])[^@\s]*(@[^\s@]+)\b/', function($m){ return $m[1] . '***' . $m[2]; }, (string)$out) ?? $out;
        // Long tokens or numbers
        $out = preg_replace_callback('/\b([A-Fa-f0-9]{12,}|[0-9]{12,})\b/', function($m){ $s=$m[1]; return str_repeat('*', max(0, strlen($s)-4)) . substr($s,-4); }, (string)$out) ?? $out;
        // Key=Value like pairs
        $out = preg_replace('/(secret|token|signature|auth|api[_-]?key|access[_-]?token)\s*[:=]\s*([^\s,\"]+)/i', '$1=***', (string)$out) ?? $out;
        return $out;
    }

    /** Pretty print possibly-JSON raw payload with masking. */
    protected function ADM_SanitizeRawPayload(?string $raw): string
    {
        if (!is_string($raw) || trim($raw) === '') { return ''; }
        $s = trim($raw);
        try {
            $data = json_decode($s, true, 512, JSON_INVALID_UTF8_SUBSTITUTE);
            if (is_array($data)) {
                $maskKeys = ['secret','token','signature','auth','apikey','api_key','access_token','card','number','iban','account'];
                $walker = function(&$v, $k) use (&$walker, $maskKeys) {
                    if (is_array($v)) { foreach ($v as $kk=>&$vv) { $walker($vv, (string)$kk); } return; }
                    $lk = strtolower((string)$k);
                    foreach ($maskKeys as $mk) {
                        if (strpos($lk, $mk) !== false) { $v = '***'; return; }
                    }
                    if (is_string($v)) { $v = $this->ADM_MaskSensitive($v); }
                };
                array_walk_recursive($data, $walker);
                return json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
            }
        } catch (\Throwable $__) {}
        // Fallback: plain text masking
        return $this->ADM_MaskSensitive($s);
    }

    /** Subscription gateway details (masked). */
    public function ADM_GetSubscriptionInvoiceLog(int $id): ?array
    {
        $row = $this->ADM_GetSubscriptionInvoice($id);
        if (!$row) { return null; }
        $maskedRef = $this->ADM_MaskSensitive((string)($row['reference'] ?? ''));
        $maskedRaw = $this->ADM_SanitizeRawPayload(isset($row['raw_payload']) ? (string)$row['raw_payload'] : '');
        return [
            'id'        => (int)($row['id'] ?? 0),
            'provider'  => (string)($row['provider'] ?? ''),
            'reference' => $maskedRef,
            'status'    => (string)($row['status'] ?? ''),
            'event'     => (string)($row['event'] ?? ''),
            'created_at'=> isset($row['created_at']) ? (int)$row['created_at'] : null,
            'raw'       => $maskedRaw,
        ];
    }

    /** Tip gateway details (masked). */
    public function ADM_GetTipInvoiceLog(int $id): ?array
    {
        $row = $this->ADM_GetTipInvoice($id);
        if (!$row) { return null; }
        $maskedRef = $this->ADM_MaskSensitive((string)($row['reference'] ?? ''));
        $maskedRaw = $this->ADM_SanitizeRawPayload(isset($row['raw_payload']) ? (string)$row['raw_payload'] : '');
        return [
            'id'        => (int)($row['id'] ?? 0),
            'provider'  => (string)($row['provider'] ?? ''),
            'reference' => $maskedRef,
            'status'    => (string)($row['status'] ?? ''),
            'event'     => (string)($row['event'] ?? ''),
            'created_at'=> isset($row['created_at']) ? (int)$row['created_at'] : null,
            'raw'       => $maskedRaw,
        ];
    }

    /**
     * Try to extract tax/fee from subscription raw_payload (Stripe/PayPal/Paddle patterns).
     * Returns ['tax'=>float,'fee'=>float,'discount'=>float]. Missing fields default to 0.
     */
    public function ADM_ExtractSubscriptionAmounts(array $row): array
    {
        $tax = 0.0; $fee = 0.0; $discount = 0.0;
        $raw = isset($row['raw_payload']) ? (string)$row['raw_payload'] : '';
        if ($raw === '') { return ['tax'=>$tax,'fee'=>$fee,'discount'=>$discount]; }
        try {
            $data = json_decode($raw, true, 512, JSON_INVALID_UTF8_SUBSTITUTE);
            if (!is_array($data)) { return ['tax'=>$tax,'fee'=>$fee,'discount'=>$discount]; }

            // Helper to safely parse monetary values from various shapes
            $parseMoney = function($v, ?string $key = null): float {
                if (is_array($v)) {
                    if (isset($v['value'])) { return (float)$v['value']; }
                    if (isset($v['amount'])) { return (float)$v['amount']; }
                }
                if (is_string($v) || is_numeric($v)) {
                    $num = (float)$v;
                    // Stripe amounts are usually in cents for keys like amount_* or *_amount
                    $k = strtolower((string)$key);
                    if ($k !== '' && (str_contains($k, 'amount_') || str_ends_with($k, '_amount'))) {
                        if (abs($num) >= 100.0) { return $num / 100.0; }
                    }
                    return $num;
                }
                return 0.0;
            };

            $walk = function($arr, $path = '') use (&$walk, &$tax, &$fee, &$discount, $parseMoney) {
                if (!is_array($arr)) { return; }
                foreach ($arr as $k => $v) {
                    $kp = $path === '' ? (string)$k : ($path . '.' . $k);
                    $lk = strtolower((string)$k);
                    if (is_array($v)) {
                        // Stripe: total_details.amount_tax / breakdown
                        if ($lk === 'amount_tax' || $lk === 'tax_total') { $tax += $parseMoney($v, $k); continue; }
                        if ($lk === 'paypal_fee') { $fee += $parseMoney($v, $k); continue; }
                        if ($lk === 'application_fee_amount') { $fee += $parseMoney($v, $k); continue; }
                        if ($lk === 'discount' || $lk === 'amount_discount') { $discount += $parseMoney($v, $k); continue; }
                        $walk($v, $kp);
                        continue;
                    }
                    // Scalar
                    if (in_array($lk, ['amount_tax','tax','tax_total'], true)) { $tax += $parseMoney($v, $k); continue; }
                    if (in_array($lk, ['paypal_fee','fee','application_fee_amount'], true)) { $fee += $parseMoney($v, $k); continue; }
                    if (in_array($lk, ['discount','amount_discount'], true)) { $discount += $parseMoney($v, $k); continue; }
                }
            };
            $walk($data, '');
        } catch (\Throwable $__) {}
        // Ensure non-negative sane values
        $tax = max(0.0, (float)$tax); $fee = max(0.0, (float)$fee); $discount = max(0.0, (float)$discount);
        return ['tax'=>$tax,'fee'=>$fee,'discount'=>$discount];
    }
}
