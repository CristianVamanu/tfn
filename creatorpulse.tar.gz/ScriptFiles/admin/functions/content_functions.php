<?php
declare(strict_types=1);

trait AdminContentFunctions
{
    /** Hide a post from everyone (set visibility to 'locked'). */
    public function ADM_HidePost(int $postId): bool
    {
        if ($postId <= 0) { return false; }
        try {
            $st = $this->db()->prepare("UPDATE i_user_posts SET post_visibility = 'locked' WHERE post_id = :p LIMIT 1");
            return (bool) $st->execute([':p' => $postId]);
        } catch (\Throwable $e) {
            $this->logError('ADM_HidePost failed: ' . $e->getMessage());
            return false;
        }
    }

    /** Unhide a post (set visibility to 'everyone'). */
    public function ADM_UnhidePost(int $postId): bool
    {
        if ($postId <= 0) { return false; }
        try {
            $st = $this->db()->prepare("UPDATE i_user_posts SET post_visibility = 'everyone' WHERE post_id = :p LIMIT 1");
            return (bool) $st->execute([':p' => $postId]);
        } catch (\Throwable $e) {
            $this->logError('ADM_UnhidePost failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Delete a post and its related rows using front-side cascade if available,
     * otherwise fallback to a minimal local cascade.
     */
    public function ADM_DeletePostCascade(int $postId): bool
    {
        if ($postId <= 0) { return false; }
        try {
            $rl = $this->rl();
            if ($rl && method_exists($rl, 'RL_DeletePostCascade')) {
                return (bool) $rl->RL_DeletePostCascade($postId);
            }

            // Fallback minimal delete
            $db = $this->db();
            $db->beginTransaction();
            $db->prepare('DELETE FROM i_post_reports WHERE post_id = :p')->execute([':p' => $postId]);
            $db->prepare('DELETE FROM i_post_media   WHERE post_id = :p')->execute([':p' => $postId]);
            $db->prepare('DELETE FROM i_comments      WHERE item_id   = :p')->execute([':p' => $postId]);
            $db->prepare('DELETE FROM i_likes         WHERE post_id   = :p')->execute([':p' => $postId]);
            $db->prepare('DELETE FROM i_user_posts    WHERE post_id   = :p LIMIT 1')->execute([':p' => $postId]);
            $db->commit();
            return true;
        } catch (\Throwable $e) {
            try { $this->db()->rollBack(); } catch (\Throwable $__) {}
            $this->logError('ADM_DeletePostCascade failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * List latest posts with owner username for admin table.
     * @return array<int, array<string, mixed>>
     */
    public function ADM_ListRecentPosts(int $limit = 20): array
    {
        $limit = max(1, min(100, $limit));
        try {
            $sql = 'SELECT p.post_id, p.post_owner_id, p.post_visibility, p.post_price, p.post_created_time, '
                 . 'u.username '
                 . 'FROM i_user_posts p '
                 . 'INNER JOIN i_users u ON u.user_id = p.post_owner_id '
                 . 'ORDER BY p.post_id DESC LIMIT ' . $limit;
            $st = $this->db()->query($sql);
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            $this->logError('ADM_ListRecentPosts failed: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * List recent reports for admin table.
     * @return array<int, array<string, mixed>>
     */
    public function ADM_ListReports(int $limit = 50): array
    {
        $limit = max(1, min(200, $limit));
        try {
            $sql = 'SELECT r.id, r.post_id, r.reporter_id, r.reason, r.created_at, '
                 . 'u.username AS reporter '
                 . 'FROM i_post_reports r '
                 . 'LEFT JOIN i_users u ON u.user_id = r.reporter_id '
                 . 'ORDER BY r.id DESC LIMIT ' . $limit;
            $st = $this->db()->query($sql);
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            $this->logError('ADM_ListReports failed: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * List recent comment reports for admin view.
     * @return array<int, array<string, mixed>>
     */
    public function ADM_ListCommentReports(int $limit = 50): array
    {
        $limit = max(1, min(200, $limit));
        try {
            $sql = 'SELECT '
                 . 'r.id, r.comment_id, r.reporter_id, r.reason, r.created_at AS reported_at, '
                 . 'c.c_id AS comment_id_alias, c.comment AS comment_body, '
                 . 'c.item_id AS post_id, c.uid_fk AS comment_owner_id, '
                 . 'c.created_time AS comment_created_time, c.updated_time AS comment_updated_time, '
                 . 'ru.username AS reporter_username, ru.user_fullname AS reporter_fullname, '
                 . 'cu.username AS comment_username, cu.user_fullname AS comment_fullname, '
                 . 'p.post_owner_id, p.post_text, '
                 . 'pu.username AS post_owner_username '
                 . 'FROM i_comment_reports r '
                 . 'LEFT JOIN i_comments c ON c.c_id = r.comment_id '
                 . 'LEFT JOIN i_users ru ON ru.user_id = r.reporter_id '
                 . 'LEFT JOIN i_users cu ON cu.user_id = c.uid_fk '
                 . 'LEFT JOIN i_user_posts p ON p.post_id = c.item_id '
                 . 'LEFT JOIN i_users pu ON pu.user_id = p.post_owner_id '
                 . 'ORDER BY r.id DESC LIMIT ' . $limit;
            $st = $this->db()->query($sql);
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            $this->logError('ADM_ListCommentReports failed: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * List posts by approval status for moderation.
     *
     * @param array{status?:string,type?:string,user_id?:int} $filters
     * @return array<int,array<string,mixed>>
     */
    public function ADM_ListPostApprovals(array $filters = [], int $limit = 50, int $offset = 0): array
    {
        $limit = max(1, min(200, $limit));
        $offset = max(0, (int)$offset);
        $status = isset($filters['status']) && in_array($filters['status'], ['pending','approved','rejected'], true)
            ? $filters['status']
            : 'pending';
        $type = isset($filters['type']) && in_array($filters['type'], ['image','video'], true)
            ? $filters['type']
            : null;
        $userId = isset($filters['user_id']) ? (int)$filters['user_id'] : null;

        $where = ['p.approval_status = :status'];
        $params = [':status' => $status];
        if ($type !== null) {
            $where[] = 'p.post_type = :ptype';
            $params[':ptype'] = $type;
        }
        if ($userId && $userId > 0) {
            $where[] = 'p.post_owner_id = :uid';
            $params[':uid'] = $userId;
        }

        try {
            $sql = "SELECT
                        p.post_id,
                        p.post_owner_id,
                        p.post_type,
                        p.post_visibility,
                        p.approval_status,
                        p.approval_notes,
                        p.approved_at,
                        p.approved_by,
                        p.post_created_time,
                        u.username,
                        u.user_fullname,
                        u.verified_status
                    FROM i_user_posts p
                    INNER JOIN i_users u ON u.user_id = p.post_owner_id
                    WHERE " . implode(' AND ', $where) . "
                    ORDER BY p.post_created_time DESC
                    LIMIT :off, :lim";
            $st = $this->db()->prepare($sql);
            foreach ($params as $k => $v) {
                $typeFlag = is_int($v) ? \PDO::PARAM_INT : \PDO::PARAM_STR;
                $st->bindValue($k, $v, $typeFlag);
            }
            $st->bindValue(':off', $offset, \PDO::PARAM_INT);
            $st->bindValue(':lim', $limit, \PDO::PARAM_INT);
            $st->execute();
            return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            $this->logError('ADM_ListPostApprovals failed: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Approve or reject a post.
     */
    public function ADM_UpdatePostApprovalStatus(int $postId, string $status, int $adminId, ?string $note = null): bool
    {
        $normalized = strtolower(trim($status));
        if (!in_array($normalized, ['pending','approved','rejected'], true) || $postId <= 0) {
            return false;
        }
        $noteValue = ($note !== null && trim($note) !== '') ? trim($note) : null;
        $ownerId = 0;
        try {
            $stOwner = $this->db()->prepare('SELECT post_owner_id FROM i_user_posts WHERE post_id = :pid LIMIT 1');
            $stOwner->bindValue(':pid', $postId, \PDO::PARAM_INT);
            $stOwner->execute();
            $ownerId = (int) ($stOwner->fetchColumn() ?: 0);
        } catch (\Throwable $__) {
            $ownerId = 0;
        }
        try {
            $sql = "UPDATE i_user_posts
                    SET approval_status = :s,
                        approval_notes = :n,
                        approved_at = :t,
                        approved_by = :b
                    WHERE post_id = :p
                    LIMIT 1";
            $st = $this->db()->prepare($sql);
            $ok = $st->execute([
                ':s' => $normalized,
                ':n' => $noteValue,
                ':t' => time(),
                ':b' => $adminId > 0 ? $adminId : null,
                ':p' => $postId,
            ]);
            if ($ok && $ownerId > 0) {
                $rl = $this->rl();
                if ($rl && method_exists($rl, 'RL_CreatePostApprovalNotification')) {
                    $rl->RL_CreatePostApprovalNotification($ownerId, $adminId, $postId, $normalized, $noteValue, time());
                }
            }
            return $ok;
        } catch (\Throwable $e) {
            $this->logError('ADM_UpdatePostApprovalStatus failed: ' . $e->getMessage());
            return false;
        }
    }
}
