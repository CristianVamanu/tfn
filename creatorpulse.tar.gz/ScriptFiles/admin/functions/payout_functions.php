<?php
declare(strict_types=1);

trait AdminPayoutFunctions
{
    public function ADM_ListPayoutVerifications(array $filters = []): array
    {
        $rl = $this->rl();
        if ($rl && method_exists($rl, 'RL_ListPayoutVerificationQueue')) {
            return $rl->RL_ListPayoutVerificationQueue($filters);
        }
        return ['items' => [], 'total_items' => 0];
    }

    public function ADM_UpdatePayoutMethodStatus(
        int $adminId,
        int $userId,
        string $method,
        string $status,
        ?string $note = null,
        array $options = []
    ): array {
        $rl = $this->rl();
        if ($rl && method_exists($rl, 'RL_AdminUpdatePayoutMethodStatus')) {
            return $rl->RL_AdminUpdatePayoutMethodStatus($adminId, $userId, $method, $status, $note, $options);
        }
        return ['ok' => false, 'error' => 'UNSUPPORTED'];
    }

    public function ADM_GetPayoutReviewHistory(int $userId, string $method, int $limit = 10, int $offset = 0): array
    {
        $rl = $this->rl();
        if ($rl && method_exists($rl, 'RL_GetPayoutReviewHistory')) {
            return $rl->RL_GetPayoutReviewHistory($userId, $method, $limit, $offset);
        }
        return [];
    }

    public function ADM_ListWithdrawalRequests(array $filters = []): array
    {
        $rl = $this->rl();
        if ($rl && method_exists($rl, 'RL_AdminListWithdrawalRequests')) {
            return $rl->RL_AdminListWithdrawalRequests($filters);
        }
        return [
            'rows'    => [],
            'total'   => 0,
            'page'    => 1,
            'per'     => isset($filters['per']) ? (int) $filters['per'] : 20,
            'pages'   => 1,
            'filters' => [
                'status' => $filters['status'] ?? '',
                'method' => $filters['method'] ?? '',
                'search' => $filters['search'] ?? '',
            ],
        ];
    }

    public function ADM_GetWithdrawalDetails(int $payoutId): ?array
    {
        $rl = $this->rl();
        if ($rl && method_exists($rl, 'RL_AdminGetWithdrawalDetails')) {
            return $rl->RL_AdminGetWithdrawalDetails($payoutId);
        }
        return null;
    }

    public function ADM_UpdateWithdrawalStatus(int $adminId, int $payoutId, string $status, array $options = []): array
    {
        $rl = $this->rl();
        if ($rl && method_exists($rl, 'RL_AdminUpdateWithdrawalStatus')) {
            return $rl->RL_AdminUpdateWithdrawalStatus($adminId, $payoutId, $status, $options);
        }
        return ['ok' => false, 'error' => 'UNSUPPORTED'];
    }
}
