<?php
declare(strict_types=1);

trait AdminPodcastAdFunctions
{
    public function ADM_ListPodcastAds(array $filters = [], int $limit = 50): array
    {
        $limit = max(1, min(200, $limit));
        try {
            $rl = $this->rl();
            if ($rl && method_exists($rl, 'RL_ListPodcastAds')) {
                return $rl->RL_ListPodcastAds($filters, $limit, 0);
            }
        } catch (\Throwable $e) {
            $this->logError('ADM_ListPodcastAds via RL failed: ' . $e->getMessage());
        }

        try {
            $conditions = [];
            $params = [];

            if (!empty($filters['status'])) {
                $status = strtolower(trim((string) $filters['status']));
                if (in_array($status, ['pending', 'approved', 'rejected'], true)) {
                    $conditions[] = 'a.status = :status';
                    $params[':status'] = $status;
                }
            }

            if (!empty($filters['created_by'])) {
                $uid = (int) $filters['created_by'];
                if ($uid > 0) {
                    $conditions[] = 'a.created_by = :uid';
                    $params[':uid'] = $uid;
                }
            }

            if (!empty($filters['q'])) {
                $search = '%' . trim((string) $filters['q']) . '%';
                $conditions[] = '(a.title LIKE :q OR a.subtitle LIKE :q)';
                $params[':q'] = $search;
            }

            $where = $conditions ? ('WHERE ' . implode(' AND ', $conditions)) : '';
            $sql = 'SELECT a.*, u.username, u.user_fullname
                    FROM i_podcast_ads a
                    LEFT JOIN i_users u ON u.user_id = a.created_by
                    ' . $where . '
                    ORDER BY a.created_at DESC, a.id DESC
                    LIMIT :limit';

            $stmt = $this->db()->prepare($sql);
            foreach ($params as $key => $val) {
                $stmt->bindValue($key, $val, is_int($val) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
            }
            $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
            $stmt->execute();
            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            return is_array($rows) ? $rows : [];
        } catch (\Throwable $e) {
            $this->logError('ADM_ListPodcastAds failed: ' . $e->getMessage());
            return [];
        }
    }

    public function ADM_GetPodcastAdById(int $adId): ?array
    {
        $adId = max(0, $adId);
        if ($adId <= 0) {
            return null;
        }
        try {
            $rl = $this->rl();
            if ($rl && method_exists($rl, 'RL_GetPodcastAdById')) {
                return $rl->RL_GetPodcastAdById($adId);
            }
        } catch (\Throwable $e) {
            $this->logError('ADM_GetPodcastAdById via RL failed: ' . $e->getMessage());
        }

        try {
            $stmt = $this->db()->prepare('SELECT a.*, u.username, u.user_fullname, pkg.name AS package_name, pay.amount AS payment_amount, pay.currency AS payment_currency, pay.provider AS payment_provider, pay.status AS payment_status
                FROM i_podcast_ads a
                LEFT JOIN i_users u ON u.user_id = a.created_by
                LEFT JOIN i_podcast_ad_packages pkg ON pkg.id = a.package_id
                LEFT JOIN i_podcast_ad_payments pay ON pay.id = a.payment_id
                WHERE a.id = :id LIMIT 1');
            $stmt->bindValue(':id', $adId, \PDO::PARAM_INT);
            $stmt->execute();
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            return is_array($row) ? $row : null;
        } catch (\Throwable $e) {
            $this->logError('ADM_GetPodcastAdById failed: ' . $e->getMessage());
            return null;
        }
    }

    public function ADM_UpdatePodcastAdStatus(int $adId, string $status, int $adminId): bool
    {
        $adId = max(0, $adId);
        $adminId = max(0, $adminId);
        $status = strtolower(trim($status));
        if ($adId <= 0 || !in_array($status, ['pending', 'approved', 'rejected'], true)) {
            return false;
        }
        try {
            $rl = $this->rl();
            if ($rl && method_exists($rl, 'RL_UpdatePodcastAdStatus')) {
                $updated = (bool) $rl->RL_UpdatePodcastAdStatus($adId, $status, $adminId, time());
                if ($updated) {
                    try {
                        $adRow = $this->ADM_GetPodcastAdById($adId);
                        if ($adRow) {
                            $this->ADM_NotifyPodcastAdStatus($adRow, $status, $adminId);
                        }
                    } catch (\Throwable $e) {
                        $this->logError('ADM_UpdatePodcastAdStatus notify via RL failed: ' . $e->getMessage());
                    }
                }
                return $updated;
            }
        } catch (\Throwable $e) {
            $this->logError('ADM_UpdatePodcastAdStatus via RL failed: ' . $e->getMessage());
        }

        try {
            $stmt = $this->db()->prepare('UPDATE i_podcast_ads SET status = :status, approved_by = :admin, approved_at = :ts WHERE id = :id LIMIT 1');
            $stmt->bindValue(':status', $status, \PDO::PARAM_STR);
            $stmt->bindValue(':admin', $adminId, \PDO::PARAM_INT);
            $stmt->bindValue(':ts', time(), \PDO::PARAM_INT);
            $stmt->bindValue(':id', $adId, \PDO::PARAM_INT);
            $updated = $stmt->execute();
            if ($updated) {
                try {
                    $adRow = $this->ADM_GetPodcastAdById($adId);
                    if ($adRow) {
                        $this->ADM_NotifyPodcastAdStatus($adRow, $status, $adminId);
                    }
                } catch (\Throwable $e) {
                    $this->logError('ADM_UpdatePodcastAdStatus notify failed: ' . $e->getMessage());
                }
            }
            return $updated;
        } catch (\Throwable $e) {
            $this->logError('ADM_UpdatePodcastAdStatus failed: ' . $e->getMessage());
            return false;
        }
    }

    public function ADM_DeletePodcastAd(int $adId): bool
    {
        $adId = max(0, $adId);
        if ($adId <= 0) {
            return false;
        }
        $actorId = isset($GLOBALS['userData']['user_id']) ? (int) $GLOBALS['userData']['user_id'] : 0;
        $adRow = null;
        try {
            $adRow = $this->ADM_GetPodcastAdById($adId);
        } catch (\Throwable $e) {
            $adRow = null;
        }
        try {
            $rl = $this->rl();
            if ($rl && method_exists($rl, 'RL_DeletePodcastAd')) {
                $deleted = (bool) $rl->RL_DeletePodcastAd($adId);
                if ($deleted && $adRow) {
                    try {
                        $this->ADM_NotifyPodcastAdStatus($adRow, 'deleted', $actorId);
                    } catch (\Throwable $e) {
                        $this->logError('ADM_DeletePodcastAd notify via RL failed: ' . $e->getMessage());
                    }
                }
                return $deleted;
            }
        } catch (\Throwable $e) {
            $this->logError('ADM_DeletePodcastAd via RL failed: ' . $e->getMessage());
        }

        try {
            $stmt = $this->db()->prepare('DELETE FROM i_podcast_ads WHERE id = :id LIMIT 1');
            $stmt->bindValue(':id', $adId, \PDO::PARAM_INT);
            $deleted = $stmt->execute();
            if ($deleted && $adRow) {
                try {
                    $this->ADM_NotifyPodcastAdStatus($adRow, 'deleted', $actorId);
                } catch (\Throwable $e) {
                    $this->logError('ADM_DeletePodcastAd notify failed: ' . $e->getMessage());
                }
            }
            return $deleted;
        } catch (\Throwable $e) {
            $this->logError('ADM_DeletePodcastAd failed: ' . $e->getMessage());
            return false;
        }
    }

    public function ADM_ListPodcastAdPackages(?string $status = null, ?string $lang = null, ?array $languages = null): array
    {
        $status = $status !== null ? strtolower(trim($status)) : null;
        $allowed = ['active', 'inactive'];
        if ($status !== null && !in_array($status, $allowed, true)) {
            $status = null;
        }
        try {
            $rl = $this->rl();
            if ($rl && method_exists($rl, 'RL_ListPodcastAdPackages')) {
                return $rl->RL_ListPodcastAdPackages($status, $lang, $languages);
            }
        } catch (\Throwable $e) {
            $this->logError('ADM_ListPodcastAdPackages via RL failed: ' . $e->getMessage());
        }

        try {
            $conditions = [];
            $params = [];
            if ($status !== null) {
                $conditions[] = 'status = :status';
                $params[':status'] = $status;
            }
            $where = $conditions ? ('WHERE ' . implode(' AND ', $conditions)) : '';
            $langNormalized = $lang !== null ? strtolower(trim($lang)) : null;
            $sql = 'SELECT pkg.*, ' . ($langNormalized ? 'COALESCE(pt.name, pkg.name) AS name, COALESCE(pt.description, pkg.description) AS description' : 'pkg.name, pkg.description') . '
                    FROM i_podcast_ad_packages AS pkg';
            if ($langNormalized) {
                $sql .= ' LEFT JOIN i_podcast_ad_package_translations AS pt
                          ON pt.package_id = pkg.id AND pt.language = :lang';
            }
            $sql .= ' ' . $where . ' ORDER BY sort_order ASC, id ASC';

            $stmt = $this->db()->prepare($sql);
            foreach ($params as $key => $val) {
                $stmt->bindValue($key, $val, \PDO::PARAM_STR);
            }
            if ($langNormalized) {
                $stmt->bindValue(':lang', $langNormalized, \PDO::PARAM_STR);
            }
            $stmt->execute();
            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            $rows = is_array($rows) ? $rows : [];

            $langOptions = [];
            if ($languages !== null) {
                $langOptions = array_map(static function ($lng) {
                    return strtolower(trim((string) $lng));
                }, $languages);
                $langOptions = array_values(array_filter(array_unique($langOptions), static fn($lng) => $lng !== ''));
            }

            if ($rows && $langOptions) {
                $ids = array_values(array_filter(array_map(static fn($r) => (int) ($r['id'] ?? 0), $rows), static fn($v) => $v > 0));
                if ($ids) {
                    $placeholdersPkg = implode(',', array_fill(0, count($ids), '?'));
                    $placeholdersLang = implode(',', array_fill(0, count($langOptions), '?'));
                    $sqlTrans = 'SELECT package_id, language, name, description FROM i_podcast_ad_package_translations WHERE package_id IN (' . $placeholdersPkg . ')';
                    if ($langOptions) {
                        $sqlTrans .= ' AND language IN (' . $placeholdersLang . ')';
                    }
                    $stmtTrans = $this->db()->prepare($sqlTrans);
                    $bind = array_merge($ids, $langOptions);
                    foreach ($bind as $idx => $val) {
                        $stmtTrans->bindValue($idx + 1, $val, is_int($val) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
                    }
                    $stmtTrans->execute();
                    $map = [];
                    while ($row = $stmtTrans->fetch(\PDO::FETCH_ASSOC)) {
                        $pid = (int) ($row['package_id'] ?? 0);
                        $lng = strtolower((string) ($row['language'] ?? ''));
                        if ($pid <= 0 || $lng === '') {
                            continue;
                        }
                        $map[$pid][$lng] = [
                            'name'        => (string) ($row['name'] ?? ''),
                            'description' => isset($row['description']) ? (string) $row['description'] : '',
                        ];
                    }
                    foreach ($rows as &$pkg) {
                        $pid = (int) ($pkg['id'] ?? 0);
                        $pkg['translations'] = $map[$pid] ?? [];
                    }
                    unset($pkg);
                }
            }
            return is_array($rows) ? $rows : [];
        } catch (\Throwable $e) {
            $this->logError('ADM_ListPodcastAdPackages failed: ' . $e->getMessage());
            return [];
        }
    }

    public function ADM_SavePodcastAdPackage(array $data, ?int $id = null): ?int
    {
        $id = $id !== null ? max(0, (int) $id) : null;
        try {
            $rl = $this->rl();
            if ($rl && method_exists($rl, 'RL_SavePodcastAdPackage')) {
                return $rl->RL_SavePodcastAdPackage($data, $id);
            }
        } catch (\Throwable $e) {
            $this->logError('ADM_SavePodcastAdPackage via RL failed: ' . $e->getMessage());
        }

        try {
            $languages = isset($data['languages']) && is_array($data['languages'])
                ? array_values(array_filter(array_unique(array_map(static function ($lng) {
                    return strtolower(trim((string) $lng));
                }, $data['languages']))))
                : (function_exists('discoverAvailableLanguages') ? discoverAvailableLanguages() : ['eng']);
            if (!$languages) { $languages = ['eng']; }
            $defaultLang = isset($data['default_lang']) ? strtolower(trim((string) $data['default_lang'])) : ($languages[0] ?? 'eng');
            if ($defaultLang === '') { $defaultLang = $languages[0] ?? 'eng'; }
            if (!in_array($defaultLang, $languages, true)) { $languages[] = $defaultLang; }

            $translations = [];
            if (isset($data['translations']) && is_array($data['translations'])) {
                $translations = $data['translations'];
            }
            if (isset($data['name']) && is_array($data['name'])) {
                foreach ($data['name'] as $lng => $val) {
                    $lngKey = strtolower(trim((string) $lng));
                    if ($lngKey === '') { continue; }
                    if (!isset($translations[$lngKey])) { $translations[$lngKey] = []; }
                    $translations[$lngKey]['name'] = (string) $val;
                }
            }
            if (isset($data['description']) && is_array($data['description'])) {
                foreach ($data['description'] as $lng => $val) {
                    $lngKey = strtolower(trim((string) $lng));
                    if ($lngKey === '') { continue; }
                    if (!isset($translations[$lngKey])) { $translations[$lngKey] = []; }
                    $translations[$lngKey]['description'] = (string) $val;
                }
            }

            $baseName = trim((string) ($translations[$defaultLang]['name'] ?? ($data['name'] ?? '')));
            if ($baseName === '' && $translations) {
                foreach ($translations as $vals) {
                    if (is_array($vals) && !empty($vals['name'])) {
                        $baseName = trim((string) $vals['name']);
                        if ($baseName !== '') { break; }
                    }
                }
            }
            $baseDescription = isset($translations[$defaultLang]['description'])
                ? trim((string) $translations[$defaultLang]['description'])
                : trim((string) ($data['description'] ?? ''));

            $normalizedTranslations = [];
            foreach ($languages as $lng) {
                $lngKey = strtolower((string) $lng);
                $nameVal = isset($translations[$lngKey]['name']) ? trim((string) $translations[$lngKey]['name']) : $baseName;
                $descVal = isset($translations[$lngKey]['description']) ? trim((string) $translations[$lngKey]['description']) : $baseDescription;
                $normalizedTranslations[$lngKey] = [
                    'name'        => $nameVal !== '' ? $nameVal : $baseName,
                    'description' => $descVal,
                ];
            }

            $name = $baseName;
            if (mb_strlen($name) > 120) { $name = mb_substr($name, 0, 120); }
            $description = $baseDescription;
            if ($description !== '' && mb_strlen($description) > 255) { $description = mb_substr($description, 0, 255); }
            $price = round((float) ($data['price'] ?? 0), 2);
            if ($name === '' || $price <= 0) {
                return null;
            }
            $currency = strtoupper(trim((string) ($data['currency'] ?? 'USD')));
            $duration = max(1, (int) ($data['duration_days'] ?? 7));
            $dailyCap = isset($data['daily_cap']) && $data['daily_cap'] !== '' ? (int) $data['daily_cap'] : null;
            $totalCap = isset($data['total_cap']) && $data['total_cap'] !== '' ? (int) $data['total_cap'] : null;
            $premiumMultiplier = (float) ($data['premium_multiplier'] ?? 1.0);
            $targetingFee = isset($data['targeting_fee']) && $data['targeting_fee'] !== '' ? (float) $data['targeting_fee'] : null;
            $status = strtolower((string) ($data['status'] ?? 'active'));
            if (!in_array($status, ['active', 'inactive'], true)) {
                $status = 'active';
            }
            $sortOrder = isset($data['sort_order']) ? (int) $data['sort_order'] : 0;
            $now = time();

            if ($id !== null && $id > 0) {
                $sql = 'UPDATE i_podcast_ad_packages
                        SET name = :name, description = :description, price = :price, currency = :currency, duration_days = :duration_days,
                            daily_cap = :daily_cap, total_cap = :total_cap, premium_multiplier = :premium_multiplier,
                            targeting_fee = :targeting_fee, status = :status, sort_order = :sort_order, updated_at = :updated_at
                        WHERE id = :id LIMIT 1';
                $stmt = $this->db()->prepare($sql);
                $stmt->bindValue(':id', $id, \PDO::PARAM_INT);
                $stmt->bindValue(':updated_at', $now, \PDO::PARAM_INT);
            } else {
                $sql = 'INSERT INTO i_podcast_ad_packages
                        (name, description, price, currency, duration_days, daily_cap, total_cap, premium_multiplier, targeting_fee, status, sort_order, created_at, updated_at)
                        VALUES
                        (:name, :description, :price, :currency, :duration_days, :daily_cap, :total_cap, :premium_multiplier, :targeting_fee, :status, :sort_order, :created_at, NULL)';
                $stmt = $this->db()->prepare($sql);
                $stmt->bindValue(':created_at', $now, \PDO::PARAM_INT);
            }

            $stmt->bindValue(':name', $name, \PDO::PARAM_STR);
            $stmt->bindValue(':description', $description !== '' ? $description : null, $description !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
            $stmt->bindValue(':price', $price);
            $stmt->bindValue(':currency', $currency, \PDO::PARAM_STR);
            $stmt->bindValue(':duration_days', $duration, \PDO::PARAM_INT);
            $stmt->bindValue(':daily_cap', $dailyCap, $dailyCap !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':total_cap', $totalCap, $totalCap !== null ? \PDO::PARAM_INT : \PDO::PARAM_NULL);
            $stmt->bindValue(':premium_multiplier', $premiumMultiplier);
            $stmt->bindValue(':targeting_fee', $targetingFee, $targetingFee !== null ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
            $stmt->bindValue(':status', $status, \PDO::PARAM_STR);
            $stmt->bindValue(':sort_order', $sortOrder, \PDO::PARAM_INT);

            if ($stmt->execute()) {
                if ($id !== null && $id > 0) {
                    $this->ADM_SyncPodcastPackageTranslations($id, $normalizedTranslations, $now);
                    return $id;
                }
                $newId = (int) $this->db()->lastInsertId();
                if ($newId > 0) {
                    $this->ADM_SyncPodcastPackageTranslations($newId, $normalizedTranslations, $now);
                }
                return $newId;
            }
        } catch (\Throwable $e) {
            $this->logError('ADM_SavePodcastAdPackage failed: ' . $e->getMessage());
        }
        return null;
    }

    private function ADM_SyncPodcastPackageTranslations(int $packageId, array $translations, int $timestamp): void
    {
        if ($packageId <= 0 || !$translations) {
            return;
        }
        try {
            $this->db()->exec("CREATE TABLE IF NOT EXISTS i_podcast_ad_package_translations (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                package_id INT UNSIGNED NOT NULL,
                language VARCHAR(16) NOT NULL,
                name VARCHAR(120) NOT NULL,
                description VARCHAR(255) NULL,
                created_at INT UNSIGNED NOT NULL,
                updated_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_pkg_lang (package_id, language),
                KEY idx_pkg (package_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
        } catch (\Throwable $__) {
            // ignore ensure failures
        }
        try {
            $del = $this->db()->prepare('DELETE FROM i_podcast_ad_package_translations WHERE package_id = :pid');
            $del->bindValue(':pid', $packageId, \PDO::PARAM_INT);
            $del->execute();
        } catch (\Throwable $__) {
            // ignore
        }

        try {
            $ins = $this->db()->prepare('INSERT INTO i_podcast_ad_package_translations
                (package_id, language, name, description, created_at, updated_at)
                VALUES (:pid, :lang, :name, :description, :created, :updated)
                ON DUPLICATE KEY UPDATE name = VALUES(name), description = VALUES(description), updated_at = VALUES(updated_at)');
            foreach ($translations as $lang => $vals) {
                $lng = strtolower(trim((string) $lang));
                if ($lng === '') {
                    continue;
                }
                $nameVal = '';
                $descVal = null;
                if (is_array($vals)) {
                    $nameVal = trim((string) ($vals['name'] ?? ''));
                    $descVal = isset($vals['description']) ? trim((string) $vals['description']) : null;
                } else {
                    $nameVal = trim((string) $vals);
                }
                if ($nameVal === '') {
                    continue;
                }
                if (mb_strlen($nameVal) > 120) {
                    $nameVal = mb_substr($nameVal, 0, 120);
                }
                if ($descVal !== null && mb_strlen($descVal) > 255) {
                    $descVal = mb_substr($descVal, 0, 255);
                }
                $ins->bindValue(':pid', $packageId, \PDO::PARAM_INT);
                $ins->bindValue(':lang', $lng, \PDO::PARAM_STR);
                $ins->bindValue(':name', $nameVal, \PDO::PARAM_STR);
                $ins->bindValue(':description', $descVal !== null && $descVal !== '' ? $descVal : null, $descVal !== null && $descVal !== '' ? \PDO::PARAM_STR : \PDO::PARAM_NULL);
                $ins->bindValue(':created', $timestamp, \PDO::PARAM_INT);
                $ins->bindValue(':updated', $timestamp, \PDO::PARAM_INT);
                $ins->execute();
            }
        } catch (\Throwable $__) {
            // ignore sync failures
        }
    }

    public function ADM_DeletePodcastAdPackage(int $id): bool
    {
        $id = max(0, $id);
        if ($id <= 0) {
            return false;
        }
        try {
            $rl = $this->rl();
            if ($rl && method_exists($rl, 'RL_DeletePodcastAdPackage')) {
                return $rl->RL_DeletePodcastAdPackage($id);
            }
        } catch (\Throwable $e) {
            $this->logError('ADM_DeletePodcastAdPackage via RL failed: ' . $e->getMessage());
        }

        try {
            $delTrans = $this->db()->prepare('DELETE FROM i_podcast_ad_package_translations WHERE package_id = :pid');
            $delTrans->bindValue(':pid', $id, \PDO::PARAM_INT);
            $delTrans->execute();
        } catch (\Throwable $e) {
            $this->logError('ADM_DeletePodcastAdPackage translation cleanup failed: ' . $e->getMessage());
        }

        try {
            $stmt = $this->db()->prepare('DELETE FROM i_podcast_ad_packages WHERE id = :id LIMIT 1');
            $stmt->bindValue(':id', $id, \PDO::PARAM_INT);
            return $stmt->execute();
        } catch (\Throwable $e) {
            $this->logError('ADM_DeletePodcastAdPackage failed: ' . $e->getMessage());
            return false;
        }
    }

    public function ADM_NotifyPodcastAdStatus(array $adRow, string $status, int $adminId): void
    {
        $rl = $this->rl();
        if (!$rl || !method_exists($rl, 'RL_CreatePodcastAdStatusNotification')) {
            return;
        }
        $status = strtolower(trim($status));
        $allowed = ['pending', 'approved', 'rejected', 'deleted'];
        if (!in_array($status, $allowed, true)) {
            return;
        }
        $ownerId = isset($adRow['created_by']) ? (int) $adRow['created_by'] : 0;
        $title = isset($adRow['title']) ? (string) $adRow['title'] : '';
        $adId = isset($adRow['id']) ? (int) $adRow['id'] : 0;
        $actorId = max(0, $adminId);
        if ($actorId <= 0 && isset($GLOBALS['userData']['user_id'])) {
            $actorId = (int) $GLOBALS['userData']['user_id'];
        }
        if ($actorId <= 0 && isset($adRow['approved_by'])) {
            $actorId = (int) $adRow['approved_by'];
        }
        if ($ownerId <= 0 || $adId <= 0 || $actorId <= 0) {
            return;
        }
        // avoid duplicate notifications when multiple layers trigger (admin + request)
        try {
            $st = $this->db()->prepare('SELECT id FROM i_notifications WHERE recipient_id = :rid AND type = :type AND object_id = :oid AND created_at >= :ts LIMIT 1');
            $st->bindValue(':rid', $ownerId, \PDO::PARAM_INT);
            $st->bindValue(':type', 'podcast_ad_status', \PDO::PARAM_STR);
            $st->bindValue(':oid', $adId, \PDO::PARAM_INT);
            $st->bindValue(':ts', time() - 10, \PDO::PARAM_INT);
            $st->execute();
            if ($st->fetch(\PDO::FETCH_ASSOC)) {
                return;
            }
        } catch (\Throwable $e) {
            $this->logError('ADM_NotifyPodcastAdStatus dedupe check failed: ' . $e->getMessage());
        }

        try {
            $rl->RL_CreatePodcastAdStatusNotification($ownerId, $actorId, $adId, $status, $title);
        } catch (\Throwable $e) {
            $this->logError('ADM_NotifyPodcastAdStatus failed: ' . $e->getMessage());
        }
    }
}
