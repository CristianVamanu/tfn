<?php
declare(strict_types=1);

trait AdminIconFunctions
{
    /** @var array<string,array{id:int,file_path:string}>|null */
    private ?array $admIconCache = null;

    /** @var array<int,array<string,mixed>>|null */
    private ?array $admIconRows = null;

    /**
     * Ensure the icon schema is aligned with the expected structure and alias table exists.
     */
    private function admEnsureIconSchema(): void
    {
        static $ensured = false;
        if ($ensured) {
            return;
        }

        $db = $this->db();

        try { $db->exec('ALTER TABLE i_icons CHANGE COLUMN icon_id id INT UNSIGNED NOT NULL AUTO_INCREMENT'); } catch (\Throwable $__) {}
        try { $db->exec('ALTER TABLE i_icons DROP COLUMN file_name'); } catch (\Throwable $__) {}
        try { $db->exec('ALTER TABLE i_icons DROP COLUMN label'); } catch (\Throwable $__) {}
        try { $db->exec('ALTER TABLE i_icons DROP INDEX icon_file_unique'); } catch (\Throwable $__) {}

        try {
            $db->exec(
                'CREATE TABLE IF NOT EXISTS i_icon_aliases (
                    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    icon_id INT UNSIGNED NOT NULL,
                    alias_key VARCHAR(100) NOT NULL,
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (id),
                    UNIQUE KEY alias_key_unique (alias_key),
                    KEY icon_alias_icon_idx (icon_id),
                    CONSTRAINT icon_alias_icon_fk FOREIGN KEY (icon_id) REFERENCES i_icons (id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci'
            );
        } catch (\Throwable $__) {
            // Ignore failures here; downstream code will continue without alias table if creation fails.
        }

        $ensured = true;
    }

    /**
     * Clear cached icon metadata (local + global helper cache).
     */
    private function admResetIconCache(): void
    {
        $this->admIconCache = null;
        $this->admIconRows  = null;

        if (function_exists('icon_asset_cache_reset')) {
            icon_asset_cache_reset();
        } else {
            unset($GLOBALS['__iconAssetLoaded'], $GLOBALS['__iconAssetMap'], $GLOBALS['__iconAssetIdMap']);
        }
    }

    /**
     * Fetch and cache icon metadata from i_icons and alias table.
     */
    private function admLoadIcons(): void
    {
        if ($this->admIconCache !== null && $this->admIconRows !== null) {
            return;
        }

        $this->admIconCache = [];
        $this->admIconRows  = [];

        $this->admEnsureIconSchema();

        try {
            $db = $this->db();
            $stmt = $db->query('SELECT id, icon_key, file_path, created_at, updated_at FROM i_icons');
            if (!$stmt) {
                return;
            }

            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            $byId = [];
            foreach ($rows as $row) {
                $id       = (int) ($row['id'] ?? 0);
                $iconKey  = icon_asset_key((string) ($row['icon_key'] ?? ''));
                $filePath = (string) ($row['file_path'] ?? '');

                if ($id <= 0 || $iconKey === '') {
                    continue;
                }

                $record = [
                    'id'         => $id,
                    'icon_key'   => $iconKey,
                    'file_path'  => $filePath,
                    'created_at' => $row['created_at'] ?? null,
                    'updated_at' => $row['updated_at'] ?? null,
                    'aliases'    => [],
                ];

                $this->admIconCache[$iconKey] = [
                    'id'        => $id,
                    'file_path' => $filePath,
                ];

                $byId[$id] = $record;
            }

            // Load alias mappings if available.
            try {
                $aliasStmt = $db->query('SELECT icon_id, alias_key FROM i_icon_aliases');
                if ($aliasStmt) {
                    $aliases = $aliasStmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
                    foreach ($aliases as $alias) {
                        $aliasKey = icon_asset_key((string) ($alias['alias_key'] ?? ''));
                        $iconId   = (int) ($alias['icon_id'] ?? 0);
                        if ($aliasKey === '' || $iconId <= 0 || !isset($byId[$iconId])) {
                            continue;
                        }
                        $byId[$iconId]['aliases'][] = $aliasKey;
                        $this->admIconCache[$aliasKey] = [
                            'id'        => $iconId,
                            'file_path' => (string) $byId[$iconId]['file_path'],
                        ];
                    }
                }
            } catch (\Throwable $aliasEx) {
                $this->logError('admLoadIcons alias query failed: ' . $aliasEx->getMessage());
            }

            $this->admIconRows = array_values($byId);
        } catch (\Throwable $e) {
            $this->logError('admLoadIcons failed: ' . $e->getMessage());
            $this->admIconCache = [];
            $this->admIconRows  = [];
        }
    }

    /**
     * Retrieve all icons with their aliases ordered by icon key.
     *
     * @return array<int,array<string,mixed>>
     */
    public function ADM_GetIcons(): array
    {
        $this->admLoadIcons();
        $rows = $this->admIconRows ?? [];
        usort($rows, static function (array $a, array $b): int {
            return strcmp((string) ($a['icon_key'] ?? ''), (string) ($b['icon_key'] ?? ''));
        });
        return $rows;
    }

    /**
     * Return the stored file path for the given icon key (or alias).
     */
    public function ADM_GetIconPath(string $iconKey): ?string
    {
        $iconKey = icon_asset_key($iconKey);
        if ($iconKey === '') {
            return null;
        }

        $this->admLoadIcons();
        $entry = $this->admIconCache[$iconKey] ?? null;
        if (is_array($entry)) {
            $path = (string) ($entry['file_path'] ?? '');
            return $path !== '' ? $path : null;
        }
        if (is_string($entry) && $entry !== '') {
            return $entry;
        }
        return null;
    }

    /**
     * Retrieve a single icon row by identifier.
     */
    public function ADM_GetIconById(int $iconId): ?array
    {
        if ($iconId <= 0) {
            return null;
        }
        $this->admLoadIcons();
        foreach ($this->admIconRows ?? [] as $row) {
            if ((int) ($row['id'] ?? 0) === $iconId) {
                return $row;
            }
        }
        return null;
    }

    /**
     * Retrieve a single icon row by canonical key or alias.
     */
    public function ADM_GetIconByKey(string $iconKey): ?array
    {
        $iconKey = icon_asset_key($iconKey);
        if ($iconKey === '') {
            return null;
        }

        $this->admLoadIcons();
        $entry = $this->admIconCache[$iconKey] ?? null;
        if (!is_array($entry) || !isset($entry['id'])) {
            return null;
        }

        return $this->ADM_GetIconById((int) $entry['id']);
    }

    /**
     * Insert a new icon record.
     *
     * @return array{status:string,icon_id?:int,message?:string}
     */
    public function ADM_CreateIcon(string $iconKey, string $filePath): array
    {
        $iconKey = icon_asset_key($iconKey);
        $filePath = trim($filePath);

        if ($iconKey === '' || $filePath === '') {
            return ['status' => 'error', 'message' => 'invalid_params'];
        }

        try {
            $stmt = $this->db()->prepare('INSERT INTO i_icons (icon_key, file_path) VALUES (:key, :path)');
            if (!$stmt || !$stmt->execute([':key' => $iconKey, ':path' => $filePath])) {
                return ['status' => 'error', 'message' => 'db_insert_failed'];
            }

            $iconId = (int) $this->db()->lastInsertId();
            $this->admResetIconCache();

            return ['status' => 'success', 'icon_id' => $iconId];
        } catch (\PDOException $pdo) {
            $code = isset($pdo->errorInfo[1]) ? (int) $pdo->errorInfo[1] : null;
            if ($code === 1062) {
                return ['status' => 'error', 'message' => 'duplicate_key'];
            }
            $this->logError('ADM_CreateIcon failed: ' . $pdo->getMessage());
            return ['status' => 'error', 'message' => 'db_error'];
        } catch (\Throwable $e) {
            $this->logError('ADM_CreateIcon error: ' . $e->getMessage());
            return ['status' => 'error', 'message' => 'exception'];
        }
    }

    /**
     * Update icon metadata and optionally track key aliases.
     *
     * @return array{status:string,message?:string}
     */
    public function ADM_UpdateIcon(int $iconId, string $iconKey, ?string $filePath = null, bool $recordAlias = true): array
    {
        $iconId = (int) $iconId;
        $iconKey = icon_asset_key($iconKey);
        $filePath = $filePath !== null ? trim($filePath) : null;

        if ($iconId <= 0 || $iconKey === '') {
            return ['status' => 'error', 'message' => 'invalid_params'];
        }

        $current = $this->ADM_GetIconById($iconId);
        if (!$current) {
            return ['status' => 'error', 'message' => 'not_found'];
        }

        $updates = [];
        $params = [':id' => $iconId];

        $currentKey = (string) ($current['icon_key'] ?? '');
        $currentPath = (string) ($current['file_path'] ?? '');

        if ($currentKey !== $iconKey) {
            $updates[] = 'icon_key = :key';
            $params[':key'] = $iconKey;
        }

        if ($filePath !== null) {
            if ($filePath === '') {
                return ['status' => 'error', 'message' => 'invalid_path'];
            }
            if ($filePath !== $currentPath) {
                $updates[] = 'file_path = :path';
                $params[':path'] = $filePath;
            }
        }

        if (empty($updates)) {
            return ['status' => 'noop'];
        }

        if ($currentKey !== $iconKey && $recordAlias) {
            $this->admCreateAlias($iconId, $currentKey);
        }

        $updates[] = 'updated_at = CURRENT_TIMESTAMP';
        $sql = 'UPDATE i_icons SET ' . implode(', ', $updates) . ' WHERE id = :id';

        try {
            $stmt = $this->db()->prepare($sql);
            if (!$stmt || !$stmt->execute($params)) {
                return ['status' => 'error', 'message' => 'db_update_failed'];
            }
            $this->admResetIconCache();
            return ['status' => 'success'];
        } catch (\PDOException $pdo) {
            $code = isset($pdo->errorInfo[1]) ? (int) $pdo->errorInfo[1] : null;
            if ($code === 1062) {
                return ['status' => 'error', 'message' => 'duplicate_key'];
            }
            $this->logError('ADM_UpdateIcon failed: ' . $pdo->getMessage());
            return ['status' => 'error', 'message' => 'db_error'];
        } catch (\Throwable $e) {
            $this->logError('ADM_UpdateIcon error: ' . $e->getMessage());
            return ['status' => 'error', 'message' => 'exception'];
        }
    }

    /**
     * Delete an icon and cascading aliases.
     *
     * @return array{status:string,message?:string,deleted?:int}
     */
    public function ADM_DeleteIcon(int $iconId): array
    {
        $iconId = (int) $iconId;
        if ($iconId <= 0) {
            return ['status' => 'error', 'message' => 'invalid_params'];
        }

        try {
            $stmt = $this->db()->prepare('DELETE FROM i_icons WHERE id = :id');
            if (!$stmt || !$stmt->execute([':id' => $iconId])) {
                return ['status' => 'error', 'message' => 'db_delete_failed'];
            }

            $deleted = (int) $stmt->rowCount();
            if ($deleted === 0) {
                return ['status' => 'error', 'message' => 'not_found'];
            }

            $this->admResetIconCache();
            return ['status' => 'success', 'deleted' => $deleted];
        } catch (\Throwable $e) {
            $this->logError('ADM_DeleteIcon failed: ' . $e->getMessage());
            return ['status' => 'error', 'message' => 'db_error'];
        }
    }

    /**
     * Persist an alias pointing to the given icon id.
     */
    private function admCreateAlias(int $iconId, string $aliasKey): bool
    {
        $aliasKey = icon_asset_key($aliasKey);
        if ($iconId <= 0 || $aliasKey === '') {
            return false;
        }

        try {
            $stmt = $this->db()->prepare(
                'INSERT INTO i_icon_aliases (icon_id, alias_key) VALUES (:id, :alias)
                 ON DUPLICATE KEY UPDATE icon_id = VALUES(icon_id), created_at = VALUES(created_at)'
            );
            if (!$stmt) {
                return false;
            }
            return $stmt->execute([':id' => $iconId, ':alias' => $aliasKey]);
        } catch (\Throwable $e) {
            $this->logError('admCreateAlias failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Remove a specific alias for an icon.
     */
    public function ADM_DeleteIconAlias(int $iconId, string $aliasKey): bool
    {
        $iconId = (int) $iconId;
        $aliasKey = icon_asset_key($aliasKey);
        if ($iconId <= 0 || $aliasKey === '') {
            return false;
        }

        try {
            $stmt = $this->db()->prepare('DELETE FROM i_icon_aliases WHERE icon_id = :id AND alias_key = :alias');
            if (!$stmt) {
                return false;
            }
            $ok = $stmt->execute([':id' => $iconId, ':alias' => $aliasKey]);
            if ($ok && $stmt->rowCount() > 0) {
                $this->admResetIconCache();
            }
            return $ok;
        } catch (\Throwable $e) {
            $this->logError('ADM_DeleteIconAlias failed: ' . $e->getMessage());
            return false;
        }
    }
}
