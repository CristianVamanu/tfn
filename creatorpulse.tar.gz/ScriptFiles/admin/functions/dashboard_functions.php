<?php
declare(strict_types=1);

trait AdminDashboardFunctions
{
    private function ADM_WalletCurrencyPrecision(string $currency): int
    {
        $currency = strtoupper($currency);
        $cryptoCurrencies = [
            'BTC', 'ETH', 'BCH', 'LTC', 'DOGE', 'XMR', 'SOL', 'ADA', 'MATIC', 'XRP',
            'USDT', 'USDC', 'DAI', 'BNB', 'TRX'
        ];
        return in_array($currency, $cryptoCurrencies, true) ? 8 : 2;
    }

    private function ADM_WalletMinorToMajor(?int $minor, string $currency): float
    {
        if ($minor === null) {
            return 0.0;
        }
        $precision = $this->ADM_WalletCurrencyPrecision($currency);
        $factor = pow(10, max(0, $precision));
        return (float)$minor / $factor;
    }

    /** Sum platform fees across revenue streams in time range. */
    public function ADM_PostEarningsTotal(?int $fromTs = null, ?int $toTs = null): float
    {
        $total = 0.0;
        $total += $this->ADM_SumTableFee('i_post_purchases', $fromTs, $toTs);
        $total += $this->ADM_SumGenericTipFees($fromTs, $toTs);
        $audioRoomRevenue = $this->ADM_AudioRoomRevenueSummary($fromTs, $toTs);
        $total += (float)($audioRoomRevenue['platform_fee'] ?? 0.0);
        $total += $this->ADM_SumTableFee('i_ebook_purchases', $fromTs, $toTs);
        $total += $this->ADM_SumTableFee('i_ad_payments', $fromTs, $toTs);
        $total += $this->ADM_SumSubscriptionFees($fromTs, $toTs);
        $total += $this->ADM_SumWalletTopupFees($fromTs, $toTs);
        return round($total, 2);
    }

    /** Sum platform fees from tips that are not attached to an Audio Room. */
    private function ADM_SumGenericTipFees(?int $fromTs, ?int $toTs): float
    {
        $sql = "SELECT SUM(
                    CASE
                        WHEN tp.fee_amount IS NOT NULL THEN tp.fee_amount
                        WHEN tp.amount IS NOT NULL AND tp.net_amount IS NOT NULL THEN GREATEST(tp.amount - tp.net_amount, 0)
                        ELSE 0
                    END
                ) AS fee_sum
                FROM i_tip_payments tp
                WHERE tp.status = 'succeeded'
                  AND NOT EXISTS (
                      SELECT 1
                      FROM i_audio_room_tip_events arte
                      WHERE arte.provider = tp.provider
                        AND arte.reference = tp.reference
                        AND arte.recipient_id = tp.recipient_id
                  )";
        $params = [];
        if ($fromTs !== null) { $sql .= " AND tp.created_at >= :from"; $params[':from'] = (int)$fromTs; }
        if ($toTs !== null) { $sql .= " AND tp.created_at < :to"; $params[':to'] = (int)$toTs; }

        try {
            $st = $this->db()->prepare($sql);
            $st->execute($params);
            return (float)($st->fetchColumn() ?: 0.0);
        } catch (\Throwable $e) {
            $this->logError('ADM_SumGenericTipFees failed: ' . $e->getMessage());
            return 0.0;
        }
    }

    /**
     * Return verified Audio Room commerce totals without counting event-only audit rows.
     * Gross volume, creator net earnings, platform fees and taxes are deliberately separate.
     */
    public function ADM_AudioRoomRevenueSummary(?int $fromTs = null, ?int $toTs = null): array
    {
        $summary = [
            'tip_gross' => 0.0,
            'tip_net' => 0.0,
            'tip_fee' => 0.0,
            'tip_tax' => 0.0,
            'ticket_gross' => 0.0,
            'ticket_net' => 0.0,
            'ticket_fee' => 0.0,
            'ticket_tax' => 0.0,
            'gross' => 0.0,
            'creator_net' => 0.0,
            'platform_fee' => 0.0,
            'tax' => 0.0,
        ];

        $params = [];
        $tipTime = '';
        $ticketTime = '';
        if ($fromTs !== null) {
            $tipTime .= ' AND tp.created_at >= :from';
            $ticketTime .= ' AND art.created_at >= :from';
            $params[':from'] = (int)$fromTs;
        }
        if ($toTs !== null) {
            $tipTime .= ' AND tp.created_at < :to';
            $ticketTime .= ' AND art.created_at < :to';
            $params[':to'] = (int)$toTs;
        }

        try {
            $sql = "SELECT
                        SUM(COALESCE(tp.amount, 0)) AS gross,
                        SUM(COALESCE(tp.net_amount, tp.amount, 0)) AS net,
                        SUM(CASE
                            WHEN tp.fee_amount IS NOT NULL THEN tp.fee_amount
                            WHEN tp.amount IS NOT NULL AND tp.net_amount IS NOT NULL THEN GREATEST(tp.amount - tp.net_amount, 0)
                            ELSE 0
                        END) AS fee,
                        SUM(COALESCE(tp.tax_amount, 0)) AS tax
                    FROM i_tip_payments tp
                    WHERE tp.status IN ('succeeded','paid','completed')
                      AND EXISTS (
                          SELECT 1
                          FROM i_audio_room_tip_events arte
                          WHERE arte.provider = tp.provider
                            AND arte.reference = tp.reference
                            AND arte.recipient_id = tp.recipient_id
                      ){$tipTime}";
            $st = $this->db()->prepare($sql);
            $st->execute($params);
            $row = $st->fetch(\PDO::FETCH_ASSOC) ?: [];
            $summary['tip_gross'] = (float)($row['gross'] ?? 0.0);
            $summary['tip_net'] = (float)($row['net'] ?? 0.0);
            $summary['tip_fee'] = (float)($row['fee'] ?? 0.0);
            $summary['tip_tax'] = (float)($row['tax'] ?? 0.0);
        } catch (\Throwable $e) {
            $this->logError('ADM_AudioRoomRevenueSummary tips failed: ' . $e->getMessage());
        }

        try {
            $sql = "SELECT
                        SUM(COALESCE(art.amount, 0)) AS gross,
                        SUM(COALESCE(art.net_amount, art.amount, 0)) AS net,
                        SUM(CASE
                            WHEN art.fee_amount IS NOT NULL THEN art.fee_amount
                            WHEN art.amount IS NOT NULL AND art.net_amount IS NOT NULL THEN GREATEST(art.amount - art.net_amount, 0)
                            ELSE 0
                        END) AS fee,
                        SUM(COALESCE(art.tax_amount, 0)) AS tax
                    FROM i_audio_room_tickets art
                    WHERE art.status IN ('succeeded','paid','completed'){$ticketTime}";
            $st = $this->db()->prepare($sql);
            $st->execute($params);
            $row = $st->fetch(\PDO::FETCH_ASSOC) ?: [];
            $summary['ticket_gross'] = (float)($row['gross'] ?? 0.0);
            $summary['ticket_net'] = (float)($row['net'] ?? 0.0);
            $summary['ticket_fee'] = (float)($row['fee'] ?? 0.0);
            $summary['ticket_tax'] = (float)($row['tax'] ?? 0.0);
        } catch (\Throwable $e) {
            $this->logError('ADM_AudioRoomRevenueSummary tickets failed: ' . $e->getMessage());
        }

        $summary['gross'] = $summary['tip_gross'] + $summary['ticket_gross'];
        $summary['creator_net'] = $summary['tip_net'] + $summary['ticket_net'];
        $summary['platform_fee'] = $summary['tip_fee'] + $summary['ticket_fee'];
        $summary['tax'] = $summary['tip_tax'] + $summary['ticket_tax'];

        return array_map(static fn($value): float => round((float)$value, 2), $summary);
    }

    /** Sum subscriptions revenue in time range. */
    public function ADM_SubscriptionsTotal(?int $fromTs = null, ?int $toTs = null): float
    {
        try {
            $sql = "SELECT SUM(amount) AS s FROM i_subscription_payments WHERE status='succeeded'";
            $params = [];
            if ($fromTs !== null) { $sql .= " AND created_at >= :from"; $params[':from'] = (int)$fromTs; }
            if ($toTs   !== null) { $sql .= " AND created_at < :to";   $params[':to']   = (int)$toTs; }
            $st = $this->db()->prepare($sql);
            $st->execute($params);
            return (float)($st->fetchColumn() ?: 0.0);
        } catch (\Throwable $e) {
            $this->logError('ADM_SubscriptionsTotal failed: ' . $e->getMessage());
            return 0.0;
        }
    }

    private function ADM_SumTableFee(string $table, ?int $fromTs, ?int $toTs, string $timeColumn = 'created_at'): float
    {
        $allowedTables = [
            'i_post_purchases',
            'i_tip_payments',
            'i_ebook_purchases',
            'i_ad_payments',
        ];
        if (!in_array($table, $allowedTables, true)) {
            return 0.0;
        }

        $timeColumn = $timeColumn === 'created_at' ? 'created_at' : 'created_at';
        $sql = "SELECT SUM(
                    CASE
                        WHEN fee_amount IS NOT NULL THEN fee_amount
                        WHEN amount IS NOT NULL AND net_amount IS NOT NULL THEN GREATEST(amount - net_amount, 0)
                        ELSE 0
                    END
                ) AS fee_sum
                FROM {$table}
                WHERE status = 'succeeded'";
        $params = [];
        if ($fromTs !== null) { $sql .= " AND {$timeColumn} >= :from"; $params[':from'] = (int)$fromTs; }
        if ($toTs   !== null) { $sql .= " AND {$timeColumn} < :to";   $params[':to']   = (int)$toTs; }

        try {
            $st = $this->db()->prepare($sql);
            $st->execute($params);
            return (float)($st->fetchColumn() ?: 0.0);
        } catch (\Throwable $e) {
            $this->logError('ADM_SumTableFee failed for ' . $table . ': ' . $e->getMessage());
            return 0.0;
        }
    }

    private function ADM_SumWalletTopupFees(?int $fromTs, ?int $toTs): float
    {
        $sql = "SELECT currency,
                       SUM(
                           CASE
                               WHEN fee_minor IS NOT NULL THEN fee_minor
                               WHEN amount_minor IS NOT NULL AND net_minor IS NOT NULL THEN GREATEST(amount_minor - net_minor, 0)
                               ELSE 0
                           END
                       ) AS fee_minor_sum
                FROM i_wallet_topups
                WHERE status = :st";
        $params = [':st' => 'succeeded'];
        if ($fromTs !== null) { $sql .= " AND created_at >= :from"; $params[':from'] = (int)$fromTs; }
        if ($toTs   !== null) { $sql .= " AND created_at < :to";   $params[':to']   = (int)$toTs; }
        $sql .= ' GROUP BY currency';

        try {
            $st = $this->db()->prepare($sql);
            $st->execute($params);
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            $this->logError('ADM_SumWalletTopupFees failed: ' . $e->getMessage());
            $rows = [];
        }

        $total = 0.0;
        foreach ($rows as $row) {
            $currency = isset($row['currency']) ? (string)$row['currency'] : '';
            $minor    = isset($row['fee_minor_sum']) ? (int)$row['fee_minor_sum'] : null;
            if ($minor !== null) {
                $total += $this->ADM_WalletMinorToMajor($minor, $currency);
            }
        }
        return $total;
    }

    private function ADM_SumSubscriptionFees(?int $fromTs, ?int $toTs): float
    {
        $sql = "SELECT * FROM i_subscription_payments WHERE status = 'succeeded'";
        $params = [];
        if ($fromTs !== null) { $sql .= " AND created_at >= :from"; $params[':from'] = (int)$fromTs; }
        if ($toTs   !== null) { $sql .= " AND created_at < :to";   $params[':to']   = (int)$toTs; }

        try {
            $st = $this->db()->prepare($sql);
            $st->execute($params);
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            $this->logError('ADM_SumSubscriptionFees failed: ' . $e->getMessage());
            $rows = [];
        }

        $total = 0.0;
        foreach ($rows as $row) {
            $fee = 0.0;
            if (array_key_exists('fee_amount', $row) && $row['fee_amount'] !== null) {
                $fee = (float)$row['fee_amount'];
            } elseif (method_exists($this, 'ADM_ExtractSubscriptionAmounts')) {
                try {
                    $derived = $this->ADM_ExtractSubscriptionAmounts($row);
                    if (is_array($derived) && isset($derived['fee'])) {
                        $fee = (float)$derived['fee'];
                    }
                } catch (\Throwable $__) {
                }
            }
            if ($fee > 0.0) {
                $total += $fee;
            }
        }
        return $total;
    }

    /** Sum tips revenue (net if available) in time range. */
    public function ADM_TipsTotal(?int $fromTs = null, ?int $toTs = null): float
    {
        try {
            $sql = "SELECT SUM(COALESCE(tp.net_amount, tp.amount)) AS s
                    FROM i_tip_payments tp
                    WHERE tp.status='succeeded'
                      AND NOT EXISTS (
                          SELECT 1
                          FROM i_audio_room_tip_events arte
                          WHERE arte.provider = tp.provider
                            AND arte.reference = tp.reference
                            AND arte.recipient_id = tp.recipient_id
                      )";
            $params = [];
            if ($fromTs !== null) { $sql .= " AND tp.created_at >= :from"; $params[':from'] = (int)$fromTs; }
            if ($toTs   !== null) { $sql .= " AND tp.created_at < :to";   $params[':to']   = (int)$toTs; }
            $st = $this->db()->prepare($sql);
            $st->execute($params);
            return (float)($st->fetchColumn() ?: 0.0);
        } catch (\Throwable $e) {
            $this->logError('ADM_TipsTotal failed: ' . $e->getMessage());
            return 0.0;
        }
    }

    /** Sum creator eBook earnings (net if available) in time range. */
    public function ADM_EbookSalesTotal(?int $fromTs = null, ?int $toTs = null): float
    {
        try {
            $sql = "SELECT SUM(COALESCE(net_amount, amount, 0)) AS s
                    FROM i_ebook_purchases
                    WHERE status IN ('succeeded','paid','completed')";
            $params = [];
            if ($fromTs !== null) { $sql .= " AND created_at >= :from"; $params[':from'] = (int)$fromTs; }
            if ($toTs   !== null) { $sql .= " AND created_at < :to";   $params[':to']   = (int)$toTs; }
            $st = $this->db()->prepare($sql);
            $st->execute($params);
            return (float)($st->fetchColumn() ?: 0.0);
        } catch (\Throwable $e) {
            $this->logError('ADM_EbookSalesTotal failed: ' . $e->getMessage());
            return 0.0;
        }
    }

    /** Monthly totals for subscriptions, generic tips, eBooks and Audio Room earnings. */
    public function ADM_MonthlyEarningsSeries(int $months = 12): array
    {
        $months = max(1, min(24, $months));
        $now   = time();
        $startMonth = strtotime(date('Y-m-01 00:00:00', strtotime('-' . ($months - 1) . ' months', $now)));
        $fmt = "%Y-%m";

        // Subscriptions
        $subs = [];
        try {
            $sql = "SELECT DATE_FORMAT(FROM_UNIXTIME(created_at), '{$fmt}') AS m, SUM(amount) AS s
                    FROM i_subscription_payments
                    WHERE status='succeeded' AND created_at >= :s
                    GROUP BY m";
            $st  = $this->db()->prepare($sql);
            $st->execute([':s' => $startMonth]);
            $rows = $st->fetchAll(\PDO::FETCH_KEY_PAIR) ?: [];
            for ($i = 0; $i < $months; $i++) {
                $ts  = strtotime('+' . $i . ' months', $startMonth);
                $key = date('Y-m', $ts);
                $subs[] = ['t' => $ts, 'v' => (float)($rows[$key] ?? 0.0)];
            }
        } catch (\Throwable $e) {
            for ($i = 0; $i < $months; $i++) { $subs[] = ['t'=>strtotime('+' . $i . ' months', $startMonth), 'v'=>0.0]; }
        }

        // Tips
        $tips = [];
        try {
            $sql = "SELECT DATE_FORMAT(FROM_UNIXTIME(tp.created_at), '{$fmt}') AS m, SUM(COALESCE(tp.net_amount, tp.amount)) AS s
                    FROM i_tip_payments tp
                    WHERE tp.status='succeeded' AND tp.created_at >= :s
                      AND NOT EXISTS (
                          SELECT 1
                          FROM i_audio_room_tip_events arte
                          WHERE arte.provider = tp.provider
                            AND arte.reference = tp.reference
                            AND arte.recipient_id = tp.recipient_id
                      )
                    GROUP BY m";
            $st  = $this->db()->prepare($sql);
            $st->execute([':s' => $startMonth]);
            $rows = $st->fetchAll(\PDO::FETCH_KEY_PAIR) ?: [];
            for ($i = 0; $i < $months; $i++) {
                $ts  = strtotime('+' . $i . ' months', $startMonth);
                $key = date('Y-m', $ts);
                $tips[] = ['t' => $ts, 'v' => (float)($rows[$key] ?? 0.0)];
            }
        } catch (\Throwable $e) {
            for ($i = 0; $i < $months; $i++) { $tips[] = ['t'=>strtotime('+' . $i . ' months', $startMonth), 'v'=>0.0]; }
        }

        // eBooks
        $ebooks = [];
        try {
            $sql = "SELECT DATE_FORMAT(FROM_UNIXTIME(created_at), '{$fmt}') AS m, SUM(COALESCE(net_amount, amount, 0)) AS s
                    FROM i_ebook_purchases
                    WHERE status IN ('succeeded','paid','completed') AND created_at >= :s
                    GROUP BY m";
            $st  = $this->db()->prepare($sql);
            $st->execute([':s' => $startMonth]);
            $rows = $st->fetchAll(\PDO::FETCH_KEY_PAIR) ?: [];
            for ($i = 0; $i < $months; $i++) {
                $ts  = strtotime('+' . $i . ' months', $startMonth);
                $key = date('Y-m', $ts);
                $ebooks[] = ['t' => $ts, 'v' => (float)($rows[$key] ?? 0.0)];
            }
        } catch (\Throwable $e) {
            for ($i = 0; $i < $months; $i++) { $ebooks[] = ['t'=>strtotime('+' . $i . ' months', $startMonth), 'v'=>0.0]; }
        }

        $audioRoomTips = [];
        try {
            $sql = "SELECT DATE_FORMAT(FROM_UNIXTIME(tp.created_at), '{$fmt}') AS m,
                           SUM(COALESCE(tp.net_amount, tp.amount, 0)) AS s
                    FROM i_tip_payments tp
                    WHERE tp.status IN ('succeeded','paid','completed') AND tp.created_at >= :s
                      AND EXISTS (
                          SELECT 1
                          FROM i_audio_room_tip_events arte
                          WHERE arte.provider = tp.provider
                            AND arte.reference = tp.reference
                            AND arte.recipient_id = tp.recipient_id
                      )
                    GROUP BY m";
            $st = $this->db()->prepare($sql);
            $st->execute([':s' => $startMonth]);
            $rows = $st->fetchAll(\PDO::FETCH_KEY_PAIR) ?: [];
            for ($i = 0; $i < $months; $i++) {
                $ts = strtotime('+' . $i . ' months', $startMonth);
                $audioRoomTips[] = ['t' => $ts, 'v' => (float)($rows[date('Y-m', $ts)] ?? 0.0)];
            }
        } catch (\Throwable $e) {
            for ($i = 0; $i < $months; $i++) { $audioRoomTips[] = ['t'=>strtotime('+' . $i . ' months', $startMonth), 'v'=>0.0]; }
        }

        $audioRoomTickets = [];
        try {
            $sql = "SELECT DATE_FORMAT(FROM_UNIXTIME(created_at), '{$fmt}') AS m,
                           SUM(COALESCE(net_amount, amount, 0)) AS s
                    FROM i_audio_room_tickets
                    WHERE status IN ('succeeded','paid','completed') AND created_at >= :s
                    GROUP BY m";
            $st = $this->db()->prepare($sql);
            $st->execute([':s' => $startMonth]);
            $rows = $st->fetchAll(\PDO::FETCH_KEY_PAIR) ?: [];
            for ($i = 0; $i < $months; $i++) {
                $ts = strtotime('+' . $i . ' months', $startMonth);
                $audioRoomTickets[] = ['t' => $ts, 'v' => (float)($rows[date('Y-m', $ts)] ?? 0.0)];
            }
        } catch (\Throwable $e) {
            for ($i = 0; $i < $months; $i++) { $audioRoomTickets[] = ['t'=>strtotime('+' . $i . ' months', $startMonth), 'v'=>0.0]; }
        }

        return [
            'subs' => $subs,
            'tips' => $tips,
            'ebooks' => $ebooks,
            'audio_room_tips' => $audioRoomTips,
            'audio_room_tickets' => $audioRoomTickets,
        ];
    }

    /** Post visibility counts for donut chart. */
    public function ADM_PostVisibilityBreakdown(): array
    {
        $out = [
            'everyone'   => 0,
            'followers'  => 0,
            'subscribers'=> 0,
            'locked'     => 0,
        ];
        try {
            $rows = $this->db()->query('SELECT post_visibility, COUNT(*) AS c FROM i_user_posts GROUP BY post_visibility')->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            foreach ($rows as $r) {
                $k = (string)($r['post_visibility'] ?? '');
                $c = (int)($r['c'] ?? 0);
                if (isset($out[$k])) { $out[$k] = $c; }
            }
        } catch (\Throwable $e) {}
        return $out;
    }

    // ---------- Totals for counts ----------
    public function ADM_TotalUsers(): int
    {
        try { return (int)$this->db()->query('SELECT COUNT(*) FROM i_users')->fetchColumn(); } catch (\Throwable $e) { return 0; }
    }
    public function ADM_TotalPosts(): int
    {
        try { return (int)$this->db()->query('SELECT COUNT(*) FROM i_user_posts')->fetchColumn(); } catch (\Throwable $e) { return 0; }
    }
    public function ADM_TotalReports(): int
    {
        try { return (int)$this->db()->query('SELECT COUNT(*) FROM i_post_reports')->fetchColumn(); } catch (\Throwable $e) { return 0; }
    }

    // ---------- Ranged counters (for WoW deltas) ----------
    public function ADM_CountActiveUsersBetween(int $fromTs, int $toTs): int
    {
        try {
            $st = $this->db()->prepare('SELECT COUNT(DISTINCT session_uid) FROM i_sessions WHERE session_uid IS NOT NULL AND session_uid > 0 AND session_time >= :f AND session_time < :t');
            $st->execute([':f'=>$fromTs, ':t'=>$toTs]);
            return (int)$st->fetchColumn();
        } catch (\Throwable $e) { return 0; }
    }
    public function ADM_CountPostsBetween(int $fromTs, int $toTs): int
    {
        try {
            $st = $this->db()->prepare('SELECT COUNT(*) FROM i_user_posts WHERE post_created_time IS NOT NULL AND post_created_time >= :f AND post_created_time < :t');
            $st->execute([':f'=>$fromTs, ':t'=>$toTs]);
            return (int)$st->fetchColumn();
        } catch (\Throwable $e) { return 0; }
    }
    public function ADM_CountReportsBetween(int $fromTs, int $toTs): int
    {
        try {
            $st = $this->db()->prepare('SELECT COUNT(*) FROM i_post_reports WHERE created_at >= :f AND created_at < :t');
            $st->execute([':f'=>$fromTs, ':t'=>$toTs]);
            return (int)$st->fetchColumn();
        } catch (\Throwable $e) { return 0; }
    }

    // ---------- Daily series (7 days) ----------
    private function ADM_NormalizeDailySeries(array $rows, int $days): array
    {
        $map = [];
        foreach ($rows as $r) { $map[$r['d']] = (int)$r['c']; }
        $out = [];
        for ($i=$days-1; $i>=0; $i--) {
            $d = date('Y-m-d', time() - $i*86400);
            $out[] = ['t'=>strtotime($d.' 00:00:00'), 'v'=>(float)($map[$d] ?? 0)];
        }
        return $out;
    }
    public function ADM_ActiveUsersSeries(int $days = 7): array
    {
        $since = strtotime(date('Y-m-d 00:00:00', time() - ($days-1)*86400));
        try {
            $sql = "SELECT FROM_UNIXTIME(session_time, '%Y-%m-%d') AS d, COUNT(DISTINCT session_uid) AS c
                    FROM i_sessions
                    WHERE session_uid IS NOT NULL AND session_uid > 0 AND session_time >= :s
                    GROUP BY d ORDER BY d";
            $st = $this->db()->prepare($sql);
            $st->execute([':s'=>$since]);
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            return $this->ADM_NormalizeDailySeries($rows, $days);
        } catch (\Throwable $e) { return $this->ADM_NormalizeDailySeries([], $days); }
    }
    public function ADM_PostsSeries(int $days = 7): array
    {
        $since = strtotime(date('Y-m-d 00:00:00', time() - ($days-1)*86400));
        try {
            $sql = "SELECT FROM_UNIXTIME(post_created_time, '%Y-%m-%d') AS d, COUNT(*) AS c
                    FROM i_user_posts WHERE post_created_time IS NOT NULL AND post_created_time >= :s
                    GROUP BY d ORDER BY d";
            $st = $this->db()->prepare($sql);
            $st->execute([':s'=>$since]);
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            return $this->ADM_NormalizeDailySeries($rows, $days);
        } catch (\Throwable $e) { return $this->ADM_NormalizeDailySeries([], $days); }
    }
    public function ADM_ReportsSeries(int $days = 7): array
    {
        $since = strtotime(date('Y-m-d 00:00:00', time() - ($days-1)*86400));
        try {
            $sql = "SELECT FROM_UNIXTIME(created_at, '%Y-%m-%d') AS d, COUNT(*) AS c
                    FROM i_post_reports WHERE created_at >= :s
                    GROUP BY d ORDER BY d";
            $st = $this->db()->prepare($sql);
            $st->execute([':s'=>$since]);
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            return $this->ADM_NormalizeDailySeries($rows, $days);
        } catch (\Throwable $e) { return $this->ADM_NormalizeDailySeries([], $days); }
    }

    /** Simple daily series for last N days (inclusive today) for a given metric. */
    public function ADM_DailySeries(string $metric, int $days = 7): array
    {
        $days = max(1, min(60, $days));
        $now = time();
        $tzOffset = 0; // UTC baseline
        $series = [];
        for ($i = $days - 1; $i >= 0; $i--) {
            $start = strtotime(date('Y-m-d 00:00:00', $now - $i * 86400));
            $end   = $start + 86400;
            if ($metric === 'posts') {
                $val = $this->ADM_PostEarningsTotal($start, $end);
            } elseif ($metric === 'subs') {
                $val = $this->ADM_SubscriptionsTotal($start, $end);
            } elseif ($metric === 'tips') {
                $val = $this->ADM_TipsTotal($start, $end);
            } elseif ($metric === 'ebooks') {
                $val = $this->ADM_EbookSalesTotal($start, $end);
            } else {
                $val = 0.0;
            }
            $series[] = [ 't' => $start, 'v' => (float)$val ];
        }
        return $series;
    }

    /** Percent change helper: (current - previous) / max(previous, eps) * 100. */
    public function ADM_PercentChange(float $current, float $previous): float
    {
        // Avoid explosive percentages when previous period is zero or near-zero.
        if ($previous <= 0.0) {
            return 0.0;
        }
        $pct = (($current - $previous) / $previous) * 100.0;
        // Clamp to a sane visual range
        if ($pct > 999.99) { $pct = 999.99; }
        if ($pct < -999.99) { $pct = -999.99; }
        return $pct;
    }

    /**
     * Ratio percent of current vs previous period for gauges.
     * Returns a 0–100 clamped percentage where 100 means current >= previous.
     */
    public function ADM_RatioPercent(float $current, float $previous): float
    {
        if ($previous <= 0.0) {
            return ($current > 0.0) ? 100.0 : 0.0;
        }
        $pct = ($current / $previous) * 100.0;
        if ($pct > 100.0) { $pct = 100.0; }
        if ($pct < 0.0) { $pct = 0.0; }
        return $pct;
    }

    /** Active visitors percent (unique session_uid in last 7 days / total users). */
    public function ADM_ActiveVisitorsPercent(int $days = 7): float
    {
        $since = time() - max(1, $days) * 86400;
        try {
            $st = $this->db()->prepare('SELECT COUNT(DISTINCT session_uid) FROM i_sessions WHERE session_time >= :t AND session_uid IS NOT NULL AND session_uid > 0');
            $st->execute([':t' => $since]);
            $active = (int)($st->fetchColumn() ?: 0);
        } catch (\Throwable $e) { $active = 0; }
        try {
            $total = (int)($this->db()->query('SELECT COUNT(*) FROM i_users')->fetchColumn() ?: 0);
        } catch (\Throwable $e) { $total = 0; }
        if ($total <= 0) { return 0.0; }
        $p = ($active / $total) * 100.0;
        return max(0.0, min(100.0, $p));
    }

    /**
     * Paged Users with optional search.
     * @return array{rows:array,total:int,page:int,perPage:int}
     */
    public function ADM_PagedUsers(string $q = '', int $page = 1, int $perPage = 20, array $filters = []): array
    {
        $page    = max(1, $page);
        $perPage = max(1, min(200, $perPage));
        $offset  = ($page - 1) * $perPage;

        $params = [];
        $columns = $this->getUserTableColumns();
        $hasUsername = in_array('username', $columns, true);
        $hasUserFullname = in_array('user_fullname', $columns, true);
        $hasUserEmail = in_array('user_email', $columns, true);
        $hasUserType = in_array('user_type', $columns, true);
        $hasUserMode = in_array('user_mode', $columns, true);
        $hasVerifiedStatus = in_array('verified_status', $columns, true);
        $hasUserAvatar = in_array('user_avatar', $columns, true);
        $hasLastLoginTime = in_array('last_login_time', $columns, true);
        $hasIsBanned = in_array('is_banned', $columns, true);
        $hasIsFake = in_array('is_fake', $columns, true);
        $hasCreated = in_array('created_at', $columns, true);
        $hasAdminPerms = in_array('admin_permissions', $columns, true);

        $whereParts = [];
        $filterWhereParts = [];

        // Search
        if ($q !== '') {
            $searchParts = [];
            if ($hasUsername) {
                $searchParts[] = "CAST(COALESCE(u.username, '') AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci LIKE :q";
            }
            if ($hasUserEmail) {
                $searchParts[] = "CAST(COALESCE(u.user_email, '') AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci LIKE :q";
            }
            if ($hasUserFullname) {
                $searchParts[] = "CAST(COALESCE(u.user_fullname, '') AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci LIKE :q";
            }
            if ($searchParts) {
                $whereParts[] = '(' . implode(' OR ', $searchParts) . ')';
                $params[':q'] = '%' . $q . '%';
            }
        }

        // Optional filters
        $verified = isset($filters['verified']) ? trim((string)$filters['verified']) : '';
        if ($hasVerifiedStatus && $verified !== '' && ($verified === '0' || $verified === '1')) {
            $clause = 'u.verified_status = :v';
            $whereParts[] = $clause;
            $filterWhereParts[] = $clause;
            $params[':v'] = (int)$verified;
        }

        $banned = isset($filters['banned']) ? trim((string)$filters['banned']) : '';
        if ($hasIsBanned && $banned !== '' && ($banned === '0' || $banned === '1')) {
            $clause = 'COALESCE(u.is_banned,0) = :b';
            $whereParts[] = $clause;
            $filterWhereParts[] = $clause;
            $params[':b'] = (int)$banned;
        }

        $fakeFlag = isset($filters['fake']) ? trim((string)$filters['fake']) : '';
        if ($hasIsFake && $fakeFlag !== '' && in_array($fakeFlag, ['0', '1'], true)) {
            $clause = 'COALESCE(u.is_fake,0) = :f';
            $whereParts[] = $clause;
            $filterWhereParts[] = $clause;
            $params[':f'] = (int)$fakeFlag;
        }

        $role = isset($filters['role']) ? strtolower(trim((string)$filters['role'])) : '';
        if (in_array($role, ['user', 'moderator', 'admin'], true)) {
            if ($hasUserMode) {
                $clause = 'LOWER(u.user_mode) = :um';
                $whereParts[] = $clause;
                $filterWhereParts[] = $clause;
                $params[':um'] = $role;
            } elseif ($hasUserType) {
                if ($role === 'admin') {
                    $clause = 'u.user_type >= 3';
                    $whereParts[] = $clause;
                    $filterWhereParts[] = $clause;
                } elseif ($role === 'moderator') {
                    $clause = 'u.user_type = 2';
                    $whereParts[] = $clause;
                    $filterWhereParts[] = $clause;
                } elseif ($role === 'user') {
                    $clause = 'u.user_type = 1';
                    $whereParts[] = $clause;
                    $filterWhereParts[] = $clause;
                }
            }
        }

        $where = $whereParts ? (' WHERE ' . implode(' AND ', $whereParts)) : '';
        $filterWhere = $filterWhereParts ? (' WHERE ' . implode(' AND ', $filterWhereParts)) : '';

        // Count
        try {
            $st = $this->db()->prepare('SELECT COUNT(*) FROM i_users u' . $where);
            $st->execute($params);
            $total = (int)($st->fetchColumn() ?: 0);
        } catch (\Throwable $e) {
            if ($q !== '') {
                $this->logError('ADM_PagedUsers count failed: ' . $e->getMessage());
            }
            $total = 0;
        }

        $usernameExpr = $hasUsername ? 'u.username' : "''";
        $fullnameExpr = $hasUserFullname ? 'u.user_fullname' : $usernameExpr;
        $emailExpr = $hasUserEmail ? 'u.user_email' : "''";
        $userTypeExpr = $hasUserType ? 'u.user_type' : '0';
        $userModeExpr = $hasUserMode ? 'u.user_mode' : 'NULL';
        $verifiedExpr = $hasVerifiedStatus ? 'u.verified_status' : '0';
        $avatarExpr = $hasUserAvatar ? 'u.user_avatar' : "''";
        $lastLoginExpr = $hasLastLoginTime ? 'u.last_login_time' : 'NULL';
        $bannedExpr = $hasIsBanned ? 'COALESCE(u.is_banned, 0)' : '0';
        $isFakeExpr = $hasIsFake ? 'COALESCE(u.is_fake, 0)' : '0';
        $createdExpr = $hasCreated ? 'u.created_at' : 'NULL';
        $adminPermsExpr = $hasAdminPerms ? 'u.admin_permissions' : 'NULL';

        $selectPrefix = 'SELECT u.user_id'
            . ', ' . $usernameExpr . ' AS username'
            . ', ' . $fullnameExpr . ' AS user_fullname'
            . ', ' . $emailExpr . ' AS user_email'
            . ', ' . $userTypeExpr . ' AS user_type'
            . ', ' . $userModeExpr . ' AS user_mode'
            . ', ' . $verifiedExpr . ' AS verified_status'
            . ', ' . $avatarExpr . ' AS user_avatar'
            . ', ' . $lastLoginExpr . ' AS last_login_time'
            . ', ' . $bannedExpr . ' AS is_banned'
            . ', ' . $isFakeExpr . ' AS is_fake'
            . ', ' . $createdExpr . ' AS created_at'
            . ', ' . $adminPermsExpr . ' AS admin_permissions';

        $baseSql = ' FROM i_users u'
            . $where
            . ' ORDER BY u.user_id DESC'
            . ' LIMIT ' . $perPage . ' OFFSET ' . $offset;

        $rows = [];
        try {
            $sql = $selectPrefix
                . ', (SELECT MIN(s.session_time) FROM i_sessions s WHERE s.session_uid = u.user_id) AS first_seen'
                . $baseSql;
            $st = $this->db()->prepare($sql);
            $st->execute($params);
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            if ($q !== '') {
                $this->logError('ADM_PagedUsers rows failed: ' . $e->getMessage());
            }
            try {
                $sql = $selectPrefix . ', NULL AS first_seen' . $baseSql;
                $st = $this->db()->prepare($sql);
                $st->execute($params);
                $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            } catch (\Throwable $__) {
                $rows = [];
            }
        }

        if ($q !== '' && $total === 0) {
            try {
                $fallbackParams = $params;
                unset($fallbackParams[':q']);

                $sqlAll = $selectPrefix
                    . ', NULL AS first_seen'
                    . ' FROM i_users u'
                    . $filterWhere
                    . ' ORDER BY u.user_id DESC';
                $st = $this->db()->prepare($sqlAll);
                $st->execute($fallbackParams);
                $allRows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];

                $needle = function_exists('mb_strtolower') ? mb_strtolower($q, 'UTF-8') : strtolower($q);
                $matched = [];
                foreach ($allRows as $row) {
                    $username = (string) ($row['username'] ?? '');
                    $email = (string) ($row['user_email'] ?? '');
                    $fullname = (string) ($row['user_fullname'] ?? '');
                    $hay = function_exists('mb_strtolower')
                        ? mb_strtolower($username . ' ' . $email . ' ' . $fullname, 'UTF-8')
                        : strtolower($username . ' ' . $email . ' ' . $fullname);
                    if (strpos($hay, $needle) !== false) {
                        $matched[] = $row;
                    }
                }

                if ($matched) {
                    $total = count($matched);
                    $rows = array_slice($matched, $offset, $perPage);
                }
            } catch (\Throwable $e) {
                $this->logError('ADM_PagedUsers fallback search failed: ' . $e->getMessage());
            }
        }

        foreach ($rows as &$r) {
            if (empty($r['user_fullname'])) { $r['user_fullname'] = $r['username'] ?? ''; }
            if (empty($r['user_avatar'])) { $r['user_avatar'] = 'uploads/user_avatars/default.jpeg'; }
            $r['first_seen'] = isset($r['first_seen']) ? (int)$r['first_seen'] : null;
            $r['last_login_time'] = isset($r['last_login_time']) ? (int)$r['last_login_time'] : null;
            if (!isset($r['is_fake'])) { $r['is_fake'] = 0; }
            $r['created_at'] = isset($r['created_at']) ? (int)$r['created_at'] : null;
        }
        unset($r);

        return ['rows'=>$rows,'total'=>$total,'page'=>$page,'perPage'=>$perPage];
    }

    /**
     * Paged Subscriptions with optional search and status filter.
     * @return array{rows:array,total:int,page:int,perPage:int}
     */
    public function ADM_PagedSubscriptions(string $q = '', string $status = '', int $page = 1, int $perPage = 20): array
    {
        $page    = max(1, $page);
        $perPage = max(1, min(200, $perPage));
        $offset  = ($page - 1) * $perPage;

        $w = [];$p = [];
        if ($q !== '') {
            $w[] = '(ub.username LIKE :q OR ur.username LIKE :q OR sp.provider LIKE :q OR sp.reference LIKE :q)';
            $p[':q'] = '%' . $q . '%';
        }
        if ($status !== '') {
            $w[] = 'sp.status = :st';
            $p[':st'] = $status;
        }
        $where = $w ? ('WHERE ' . implode(' AND ', $w)) : '';

        // Count
        try {
            $sql = 'SELECT COUNT(*) FROM i_subscription_payments sp
                    INNER JOIN i_users ub ON ub.user_id = sp.buyer_id
                    INNER JOIN i_users ur ON ur.user_id = sp.recipient_id ' . $where;
            $st = $this->db()->prepare($sql);
            $st->execute($p);
            $total = (int)($st->fetchColumn() ?: 0);
        } catch (\Throwable $e) { $total = 0; }

        // Rows
        try {
            $sql = 'SELECT sp.*, ub.username AS buyer_username, COALESCE(ub.user_fullname, ub.username) AS buyer_fullname, ub.user_avatar AS buyer_avatar,
                           ur.username AS recip_username, COALESCE(ur.user_fullname, ur.username) AS recip_fullname, ur.user_avatar AS recip_avatar
                    FROM i_subscription_payments sp
                    INNER JOIN i_users ub ON ub.user_id = sp.buyer_id
                    INNER JOIN i_users ur ON ur.user_id = sp.recipient_id '
                    . $where .
                   ' ORDER BY sp.created_at DESC, sp.id DESC
                     LIMIT ' . $perPage . ' OFFSET ' . $offset;
            $st = $this->db()->prepare($sql);
            $st->execute($p);
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) { $rows = []; }

        foreach ($rows as &$r) {
            if (empty($r['buyer_avatar'])) { $r['buyer_avatar'] = 'uploads/user_avatars/default.jpeg'; }
            if (empty($r['recip_avatar'])) { $r['recip_avatar'] = 'uploads/user_avatars/default.jpeg'; }
            $r['created_at'] = isset($r['created_at']) ? (int)$r['created_at'] : null;
            $r['current_period_end'] = isset($r['current_period_end']) ? (int)$r['current_period_end'] : null;
            $r['started_at'] = isset($r['started_at']) ? (int)$r['started_at'] : null;
            $r['cancelled_at'] = isset($r['cancelled_at']) ? (int)$r['cancelled_at'] : null;
        }
        unset($r);

        return ['rows'=>$rows,'total'=>$total,'page'=>$page,'perPage'=>$perPage];
    }

    /**
     * Paged Tips with optional search and status filter.
     * @return array{rows:array,total:int,page:int,perPage:int}
     */
    public function ADM_PagedTips(string $q = '', string $status = '', int $page = 1, int $perPage = 20): array
    {
        $page    = max(1, $page);
        $perPage = max(1, min(200, $perPage));
        $offset  = ($page - 1) * $perPage;

        $w = [];$p = [];
        if ($q !== '') {
            $w[] = '(ub.username LIKE :q OR ur.username LIKE :q OR tp.provider LIKE :q OR tp.reference LIKE :q)';
            $p[':q'] = '%' . $q . '%';
        }
        if ($status !== '') {
            $w[] = 'tp.status = :st';
            $p[':st'] = $status;
        }
        $where = $w ? ('WHERE ' . implode(' AND ', $w)) : '';

        // Count
        try {
            $sql = 'SELECT COUNT(*) FROM i_tip_payments tp
                    INNER JOIN i_users ub ON ub.user_id = tp.buyer_id
                    INNER JOIN i_users ur ON ur.user_id = tp.recipient_id ' . $where;
            $st = $this->db()->prepare($sql);
            $st->execute($p);
            $total = (int)($st->fetchColumn() ?: 0);
        } catch (\Throwable $e) { $total = 0; }

        // Rows
        try {
            $sql = 'SELECT tp.*, ub.username AS buyer_username, COALESCE(ub.user_fullname, ub.username) AS buyer_fullname, ub.user_avatar AS buyer_avatar,
                           ur.username AS recip_username, COALESCE(ur.user_fullname, ur.username) AS recip_fullname, ur.user_avatar AS recip_avatar
                    FROM i_tip_payments tp
                    INNER JOIN i_users ub ON ub.user_id = tp.buyer_id
                    INNER JOIN i_users ur ON ur.user_id = tp.recipient_id '
                    . $where .
                   ' ORDER BY tp.created_at DESC, tp.id DESC
                     LIMIT ' . $perPage . ' OFFSET ' . $offset;
            $st = $this->db()->prepare($sql);
            $st->execute($p);
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) { $rows = []; }

        foreach ($rows as &$r) {
            if (empty($r['buyer_avatar'])) { $r['buyer_avatar'] = 'uploads/user_avatars/default.jpeg'; }
            if (empty($r['recip_avatar'])) { $r['recip_avatar'] = 'uploads/user_avatars/default.jpeg'; }
            $r['created_at'] = isset($r['created_at']) ? (int)$r['created_at'] : null;
            $r['credited_at'] = isset($r['credited_at']) ? (int)$r['credited_at'] : null;
            $r['net_amount'] = isset($r['net_amount']) ? (float)$r['net_amount'] : null;
        }
        unset($r);

        return ['rows'=>$rows,'total'=>$total,'page'=>$page,'perPage'=>$perPage];
    }

    public function ADM_PagedContactMessages(string $q = '', string $status = '', string $msgType = '', int $page = 1, int $perPage = 20): array
    {
        $page    = max(1, $page);
        $perPage = max(1, min(200, $perPage));
        $offset  = ($page - 1) * $perPage;

        $whereParts = [];
        $params = [];

        if ($q !== '') {
            $whereParts[] = '(cm.name LIKE :q OR cm.email LIKE :q OR cm.subject LIKE :q OR cm.message LIKE :q OR u.username LIKE :q)';
            $params[':q'] = '%' . $q . '%';
        }

        if ($status !== '') {
            $whereParts[] = 'cm.status = :status';
            $params[':status'] = $status;
        }

        if ($msgType !== '') {
            $whereParts[] = 'cm.msg_type = :msg_type';
            $params[':msg_type'] = $msgType;
        }

        $whereSql = $whereParts ? ('WHERE ' . implode(' AND ', $whereParts)) : '';

        try {
            $countSql = 'SELECT COUNT(*) FROM i_contact_messages cm LEFT JOIN i_users u ON u.user_id = cm.user_id ' . $whereSql;
            $countStmt = $this->db()->prepare($countSql);
            $countStmt->execute($params);
            $total = (int) ($countStmt->fetchColumn() ?: 0);
        } catch (\Throwable $e) {
            $total = 0;
        }

        try {
            $listSql = 'SELECT cm.*, u.username AS user_username, COALESCE(u.user_fullname, u.username) AS user_fullname, u.user_avatar
                        FROM i_contact_messages cm
                        LEFT JOIN i_users u ON u.user_id = cm.user_id '
                        . $whereSql .
                        ' ORDER BY cm.created_at DESC, cm.id DESC
                          LIMIT ' . $perPage . ' OFFSET ' . $offset;
            $listStmt = $this->db()->prepare($listSql);
            $listStmt->execute($params);
            $rows = $listStmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            $rows = [];
        }

        foreach ($rows as &$row) {
            if (empty($row['user_avatar'])) {
                $row['user_avatar'] = 'uploads/user_avatars/default.jpeg';
            }
            $row['created_at'] = isset($row['created_at']) ? (string) $row['created_at'] : '';
        }
        unset($row);

        return ['rows' => $rows, 'total' => $total, 'page' => $page, 'perPage' => $perPage];
    }
    /**
     * Latest users for dashboard cards.
     * Returns fields: user_id, username, user_fullname, user_avatar, verified_status, first_seen.
     */
    public function ADM_ListLatestUsers(int $limit = 10): array
    {
        $limit = max(1, min(50, $limit));
        try {
            $sql = "SELECT u.user_id, u.username, u.user_fullname, u.user_avatar, u.verified_status,
                           MIN(s.session_time) AS first_seen
                    FROM i_users u
                    LEFT JOIN i_sessions s ON s.session_uid = u.user_id
                    GROUP BY u.user_id, u.username, u.user_fullname, u.user_avatar, u.verified_status
                    ORDER BY u.user_id DESC
                    LIMIT {$limit}";
            $rows = $this->db()->query($sql)->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            foreach ($rows as &$r) {
                if (empty($r['user_fullname'])) { $r['user_fullname'] = $r['username'] ?? ''; }
                if (empty($r['user_avatar'])) { $r['user_avatar'] = 'uploads/user_avatars/default.jpeg'; }
                $r['first_seen'] = isset($r['first_seen']) ? (int)$r['first_seen'] : null;
                $r['verified_status'] = (int)($r['verified_status'] ?? 0);
            }
            unset($r);
            return $rows;
        } catch (\Throwable $e) {
            $this->logError('ADM_ListLatestUsers failed: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Latest succeeded subscriptions with buyer/recipient display fields.
     */
    public function ADM_ListLatestSubscriptions(int $limit = 10): array
    {
        $limit = max(1, min(50, $limit));
        try {
            $sql = "SELECT sp.id,
                           sp.buyer_id, sp.recipient_id, sp.plan_interval, sp.interval_count, sp.amount, sp.currency, sp.created_at,
                           ub.username  AS buyer_username,
                           COALESCE(ub.user_fullname, ub.username) AS buyer_fullname,
                           ub.user_avatar AS buyer_avatar,
                           ur.username  AS recip_username,
                           COALESCE(ur.user_fullname, ur.username) AS recip_fullname,
                           ur.user_avatar AS recip_avatar
                    FROM i_subscription_payments sp
                    INNER JOIN i_users ub ON ub.user_id = sp.buyer_id
                    INNER JOIN i_users ur ON ur.user_id = sp.recipient_id
                    WHERE sp.status = 'succeeded'
                    ORDER BY sp.created_at DESC, sp.id DESC
                    LIMIT {$limit}";
            $rows = $this->db()->query($sql)->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            foreach ($rows as &$r) {
                if (empty($r['buyer_avatar']))  { $r['buyer_avatar']  = 'uploads/user_avatars/default.jpeg'; }
                if (empty($r['recip_avatar']))  { $r['recip_avatar']  = 'uploads/user_avatars/default.jpeg'; }
                $r['created_at']   = isset($r['created_at']) ? (int)$r['created_at'] : null;
                $r['interval']     = trim((string)($r['plan_interval'] ?? ''));
                $r['interval_cnt'] = (int)($r['interval_count'] ?? 1);
            }
            unset($r);
            return $rows;
        } catch (\Throwable $e) {
            $this->logError('ADM_ListLatestSubscriptions failed: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Latest succeeded tips with buyer/recipient display fields.
     */
    public function ADM_ListLatestTips(int $limit = 10): array
    {
        $limit = max(1, min(50, $limit));
        try {
            $sql = "SELECT tp.id,
                           tp.buyer_id, tp.recipient_id, tp.post_id, tp.amount, tp.currency, tp.created_at,
                           ub.username  AS buyer_username,
                           COALESCE(ub.user_fullname, ub.username) AS buyer_fullname,
                           ub.user_avatar AS buyer_avatar,
                           ur.username  AS recip_username,
                           COALESCE(ur.user_fullname, ur.username) AS recip_fullname,
                           ur.user_avatar AS recip_avatar
                    FROM i_tip_payments tp
                    INNER JOIN i_users ub ON ub.user_id = tp.buyer_id
                    INNER JOIN i_users ur ON ur.user_id = tp.recipient_id
                    WHERE tp.status = 'succeeded'
                      AND NOT EXISTS (
                          SELECT 1
                          FROM i_audio_room_tip_events arte
                          WHERE arte.provider = tp.provider
                            AND arte.reference = tp.reference
                            AND arte.recipient_id = tp.recipient_id
                      )
                    ORDER BY tp.created_at DESC, tp.id DESC
                    LIMIT {$limit}";
            $rows = $this->db()->query($sql)->fetchAll(\PDO::FETCH_ASSOC) ?: [];
            foreach ($rows as &$r) {
                if (empty($r['buyer_avatar']))  { $r['buyer_avatar']  = 'uploads/user_avatars/default.jpeg'; }
                if (empty($r['recip_avatar']))  { $r['recip_avatar']  = 'uploads/user_avatars/default.jpeg'; }
                $r['created_at'] = isset($r['created_at']) ? (int)$r['created_at'] : null;
                $r['amount']     = (float)($r['amount'] ?? 0);
                $r['post_id']    = (int)($r['post_id'] ?? 0);
            }
            unset($r);
            return $rows;
        } catch (\Throwable $e) {
            $this->logError('ADM_ListLatestTips failed: ' . $e->getMessage());
            return [];
        }
    }

    public function ADM_TotalWalletBalance(): float
    {
        try {
            $st = $this->db()->query('SELECT SUM(wallet) FROM i_users');
            return (float)($st->fetchColumn() ?: 0.0);
        } catch (\Throwable $e) {
            $this->logError('ADM_TotalWalletBalance failed: ' . $e->getMessage());
            return 0.0;
        }
    }

    public function ADM_WalletTopupsTotal(?int $fromTs = null, ?int $toTs = null, ?string $currency = null, array $providers = []): float
    {
        $where = ['status = :st'];
        $params = [':st' => 'succeeded'];
        if ($fromTs !== null) {
            $where[] = 'created_at >= :from';
            $params[':from'] = (int)$fromTs;
        }
        if ($toTs !== null) {
            $where[] = 'created_at < :to';
            $params[':to'] = (int)$toTs;
        }
        if ($currency !== null && $currency !== '') {
            $where[] = 'UPPER(currency) = :cur';
            $params[':cur'] = strtoupper($currency);
        }
        if (!empty($providers)) {
            $placeholders = [];
            foreach (array_values($providers) as $idx => $prov) {
                $ph = ':prov_' . $idx;
                $placeholders[] = $ph;
                $params[$ph] = (string)$prov;
            }
            if (!empty($placeholders)) {
                $where[] = 'provider IN (' . implode(',', $placeholders) . ')';
            }
        }
        $sql = 'SELECT currency, SUM(COALESCE(net_minor, amount_minor)) AS total_minor
                FROM i_wallet_topups
                WHERE ' . implode(' AND ', $where) . '
                GROUP BY currency';
        try {
            $st = $this->db()->prepare($sql);
            $st->execute($params);
            $rows = $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            $this->logError('ADM_WalletTopupsTotal failed: ' . $e->getMessage());
            $rows = [];
        }

        $total = 0.0;
        foreach ($rows as $row) {
            $cur = isset($row['currency']) ? (string)$row['currency'] : '';
            $minor = isset($row['total_minor']) ? (int)$row['total_minor'] : 0;
            $total += $this->ADM_WalletMinorToMajor($minor, $cur);
        }
        return $total;
    }

    public function ADM_WalletTopupProviders(): array
    {
        try {
            $st = $this->db()->query("SELECT DISTINCT provider FROM i_wallet_topups ORDER BY provider ASC");
            $rows = $st->fetchAll(\PDO::FETCH_COLUMN) ?: [];
            return array_values(array_filter(array_map('strval', $rows)));
        } catch (\Throwable $e) {
            return [];
        }
    }

    public function ADM_WalletTopupStatuses(): array
    {
        try {
            $st = $this->db()->query("SELECT DISTINCT status FROM i_wallet_topups ORDER BY status ASC");
            $rows = $st->fetchAll(\PDO::FETCH_COLUMN) ?: [];
            return array_values(array_filter(array_map('strval', $rows)));
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * @return array{rows:array,total:int,page:int,perPage:int}
     */
    public function ADM_PagedWalletTopups(string $q = '', string $status = '', string $provider = '', int $page = 1, int $perPage = 20): array
    {
        $page    = max(1, $page);
        $perPage = max(1, min(200, $perPage));
        $offset  = ($page - 1) * $perPage;

        $conditions = [];
        $params = [];
        if ($q !== '') {
            $conditions[] = '(u.username LIKE :q OR u.user_fullname LIKE :q OR wt.provider LIKE :q OR wt.reference LIKE :q)';
            $params[':q'] = '%' . $q . '%';
        }
        if ($status !== '') {
            $conditions[] = 'wt.status = :status';
            $params[':status'] = $status;
        }
        if ($provider !== '') {
            $conditions[] = 'wt.provider = :provider';
            $params[':provider'] = $provider;
        }
        $whereSql = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';

        try {
            $sqlCount = 'SELECT COUNT(*) FROM i_wallet_topups wt
                         INNER JOIN i_users u ON u.user_id = wt.user_id ' . $whereSql;
            $stCount = $this->db()->prepare($sqlCount);
            $stCount->execute($params);
            $total = (int)($stCount->fetchColumn() ?: 0);
        } catch (\Throwable $e) {
            $this->logError('ADM_PagedWalletTopups count failed: ' . $e->getMessage());
            $total = 0;
        }

        try {
            $sqlRows = 'SELECT wt.*,
                               u.username AS user_username,
                               COALESCE(u.user_fullname, u.username) AS user_fullname,
                               u.user_avatar AS user_avatar
                        FROM i_wallet_topups wt
                        INNER JOIN i_users u ON u.user_id = wt.user_id '
                        . $whereSql .
                        ' ORDER BY wt.created_at DESC, wt.id DESC
                          LIMIT ' . $perPage . ' OFFSET ' . $offset;
            $stRows = $this->db()->prepare($sqlRows);
            $stRows->execute($params);
            $rows = $stRows->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            $this->logError('ADM_PagedWalletTopups rows failed: ' . $e->getMessage());
            $rows = [];
        }

        $rlInstance = null;
        if (method_exists($this, 'rl')) {
            $rlInstance = $this->rl();
        }

        foreach ($rows as &$row) {
            if (empty($row['user_avatar'])) {
                $row['user_avatar'] = 'uploads/user_avatars/default.jpeg';
            }
            $row['created_at'] = isset($row['created_at']) ? (int)$row['created_at'] : null;
            $row['credited_at'] = isset($row['credited_at']) ? (int)$row['credited_at'] : null;
            $row['amount_minor'] = isset($row['amount_minor']) ? (int)$row['amount_minor'] : null;
            $row['fee_minor'] = isset($row['fee_minor']) ? (int)$row['fee_minor'] : null;
            $row['tax_minor'] = isset($row['tax_minor']) ? (int)$row['tax_minor'] : null;
            $row['net_minor'] = isset($row['net_minor']) ? (int)$row['net_minor'] : null;

            if ($row['credited_at'] && (int)$row['credited_at'] > 0 && isset($row['status']) && strtolower((string)$row['status']) !== 'succeeded') {
                $providerRef = [
                    'provider'  => (string)($row['provider'] ?? ''),
                    'reference' => (string)($row['reference'] ?? ''),
                ];
                if ($providerRef['provider'] !== '' && $providerRef['reference'] !== '' && $rlInstance instanceof Reel_Data && method_exists($rlInstance, 'RL_UpdateWalletTopupStatusByReference')) {
                    try {
                        $updated = $rlInstance->RL_UpdateWalletTopupStatusByReference(
                            $providerRef['provider'],
                            $providerRef['reference'],
                            'succeeded',
                            (string)($row['event'] ?? ''),
                            []
                        );
                        if ($updated) {
                            $row['status'] = 'succeeded';
                        }
                    } catch (\Throwable $__) {
                        // ignore, best effort only
                    }
                }
            }
        }
        unset($row);

        return [
            'rows'    => $rows,
            'total'   => $total,
            'page'    => $page,
            'perPage' => $perPage,
        ];
    }
}
