<?php
declare(strict_types=1);

trait AdminAudioRoomFunctions
{
    private function ADM_AudioRoomValidPaymentStatuses(): string
    {
        return "'succeeded','paid','completed'";
    }

    private function ADM_AudioRoomLedgerSql(): string
    {
        return "SELECT 'ticket' AS transaction_type,
                    'audio_room_ticket' AS source_type,
                    t.id, t.room_id, t.buyer_id, t.owner_id AS recipient_id,
                    t.provider, t.reference, t.amount, t.currency,
                    COALESCE(t.fee_amount,0) AS fee_amount,
                    COALESCE(t.tax_amount,0) AS tax_amount,
                    COALESCE(t.net_amount,0) AS net_amount,
                    t.status, t.created_at, t.updated_at
                FROM i_audio_room_tickets t
                UNION ALL
                SELECT 'tip' AS transaction_type,
                    'audio_room_tip' AS source_type,
                    p.id, p.room_id, p.buyer_id, p.recipient_id,
                    tp.provider, tp.reference,
                    COALESCE(tp.amount,0) AS amount,
                    COALESCE(NULLIF(tp.currency,''), p.currency) AS currency,
                    COALESCE(tp.fee_amount,0) AS fee_amount,
                    COALESCE(tp.tax_amount,0) AS tax_amount,
                    COALESCE(tp.net_amount,tp.amount,0) AS net_amount,
                    tp.status, tp.created_at,
                    COALESCE(tp.updated_at,tp.created_at) AS updated_at
                FROM i_audio_room_tip_events p
                INNER JOIN i_tip_payments tp
                    ON tp.provider = p.provider
                   AND tp.reference = p.reference
                   AND tp.recipient_id = p.recipient_id";
    }

    private function ADM_AudioRoomLedgerFilters(string $query, array $filters): array
    {
        $query = trim($query);
        $type = strtolower(trim((string)($filters['type'] ?? '')));
        $status = strtolower(trim((string)($filters['status'] ?? '')));
        $dateFrom = max(0, (int)($filters['date_from'] ?? 0));
        $dateTo = max(0, (int)($filters['date_to'] ?? 0));

        if (!in_array($type, ['', 'ticket', 'tip'], true)) {
            $type = '';
        }
        $validStatuses = ['', 'succeeded', 'paid', 'completed', 'pending', 'failed', 'canceled', 'cancelled', 'refunded'];
        if (!in_array($status, $validStatuses, true)) {
            $status = '';
        }

        $where = ['1=1'];
        $params = [];
        if ($query !== '') {
            $search = '%' . $query . '%';
            $where[] = '(r.title LIKE :search_title
                OR ub.username LIKE :search_buyer_username
                OR ub.user_fullname LIKE :search_buyer_name
                OR ur.username LIKE :search_recipient_username
                OR ur.user_fullname LIKE :search_recipient_name
                OR ledger.reference LIKE :search_reference
                OR CAST(ledger.room_id AS CHAR) = :search_room
                OR CAST(ledger.id AS CHAR) = :search_id)';
            $params = [
                ':search_title' => $search,
                ':search_buyer_username' => $search,
                ':search_buyer_name' => $search,
                ':search_recipient_username' => $search,
                ':search_recipient_name' => $search,
                ':search_reference' => $search,
                ':search_room' => ctype_digit($query) ? $query : '-1',
                ':search_id' => ctype_digit($query) ? $query : '-1',
            ];
        }
        if ($type !== '') {
            $where[] = 'ledger.transaction_type = :transaction_type';
            $params[':transaction_type'] = $type;
        }
        if ($status !== '') {
            $where[] = 'LOWER(ledger.status) = :transaction_status';
            $params[':transaction_status'] = $status;
        }
        if ($dateFrom > 0) {
            $where[] = 'ledger.created_at >= :date_from';
            $params[':date_from'] = $dateFrom;
        }
        if ($dateTo > 0) {
            $where[] = 'ledger.created_at <= :date_to';
            $params[':date_to'] = $dateTo;
        }

        return [implode(' AND ', $where), $params];
    }

    private function ADM_AudioRoomLedgerFromSql(): string
    {
        return ' FROM (' . $this->ADM_AudioRoomLedgerSql() . ') ledger
            LEFT JOIN i_audio_rooms r ON r.room_id = ledger.room_id
            LEFT JOIN i_users ub ON ub.user_id = ledger.buyer_id
            LEFT JOIN i_users ur ON ur.user_id = ledger.recipient_id ';
    }

    private function ADM_AudioRoomLedgerColumns(): string
    {
        return 'ledger.*, r.title AS room_title,
            ub.username AS buyer_username,
            COALESCE(NULLIF(ub.user_fullname,\'\'), ub.username) AS buyer_fullname,
            ub.user_avatar AS buyer_avatar,
            ur.username AS recipient_username,
            COALESCE(NULLIF(ur.user_fullname,\'\'), ur.username) AS recipient_fullname,
            ur.user_avatar AS recipient_avatar';
    }

    public function ADM_AudioRoomEarningsSummary(string $query = '', array $filters = []): array
    {
        $summary = [
            'transactions' => 0,
            'successful_transactions' => 0,
            'ticket_count' => 0,
            'tip_count' => 0,
            'gross' => 0.0,
            'creator_net' => 0.0,
            'platform_revenue' => 0.0,
            'currency_codes' => '',
            'by_currency' => [],
        ];

        try {
            [$whereSql, $params] = $this->ADM_AudioRoomLedgerFilters($query, $filters);
            $paid = $this->ADM_AudioRoomValidPaymentStatuses();
            $sql = 'SELECT COUNT(*) AS transactions,
                    SUM(LOWER(ledger.status) IN (' . $paid . ')) AS successful_transactions,
                    SUM(ledger.transaction_type = \'ticket\') AS ticket_count,
                    SUM(ledger.transaction_type = \'tip\') AS tip_count,
                    COALESCE(SUM(CASE WHEN LOWER(ledger.status) IN (' . $paid . ') THEN ledger.amount ELSE 0 END),0) AS gross,
                    COALESCE(SUM(CASE WHEN LOWER(ledger.status) IN (' . $paid . ') THEN ledger.net_amount ELSE 0 END),0) AS creator_net,
                    COALESCE(SUM(CASE WHEN LOWER(ledger.status) IN (' . $paid . ') THEN ledger.fee_amount + ledger.tax_amount ELSE 0 END),0) AS platform_revenue,
                    GROUP_CONCAT(DISTINCT CASE WHEN LOWER(ledger.status) IN (' . $paid . ') THEN UPPER(ledger.currency) END ORDER BY ledger.currency SEPARATOR \',\') AS currency_codes'
                . $this->ADM_AudioRoomLedgerFromSql() . ' WHERE ' . $whereSql;
            $stmt = $this->db()->prepare($sql);
            $stmt->execute($params);
            $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
            $summary['transactions'] = (int)($row['transactions'] ?? 0);
            $summary['successful_transactions'] = (int)($row['successful_transactions'] ?? 0);
            $summary['ticket_count'] = (int)($row['ticket_count'] ?? 0);
            $summary['tip_count'] = (int)($row['tip_count'] ?? 0);
            $summary['gross'] = (float)($row['gross'] ?? 0);
            $summary['creator_net'] = (float)($row['creator_net'] ?? 0);
            $summary['platform_revenue'] = (float)($row['platform_revenue'] ?? 0);
            $summary['currency_codes'] = (string)($row['currency_codes'] ?? '');

            $currencySql = 'SELECT UPPER(COALESCE(NULLIF(ledger.currency,\'\'),\'USD\')) AS currency,
                    COUNT(*) AS transactions,
                    COALESCE(SUM(ledger.amount),0) AS gross,
                    COALESCE(SUM(ledger.net_amount),0) AS creator_net,
                    COALESCE(SUM(ledger.fee_amount + ledger.tax_amount),0) AS platform_revenue'
                . $this->ADM_AudioRoomLedgerFromSql()
                . ' WHERE ' . $whereSql . ' AND LOWER(ledger.status) IN (' . $paid . ')
                    GROUP BY UPPER(COALESCE(NULLIF(ledger.currency,\'\'),\'USD\'))
                    ORDER BY currency';
            $currencyStmt = $this->db()->prepare($currencySql);
            $currencyStmt->execute($params);
            $summary['by_currency'] = $currencyStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable $e) {
            $this->logError('Audio room earnings summary: ' . $e->getMessage());
        }

        return $summary;
    }

    public function ADM_PagedAudioRoomTransactions(string $query, int $page, int $perPage, array $filters = []): array
    {
        $page = max(1, $page);
        $perPage = max(10, min(100, $perPage));
        $offset = ($page - 1) * $perPage;

        try {
            [$whereSql, $params] = $this->ADM_AudioRoomLedgerFilters($query, $filters);
            $count = $this->db()->prepare('SELECT COUNT(*)' . $this->ADM_AudioRoomLedgerFromSql() . ' WHERE ' . $whereSql);
            $count->execute($params);
            $total = (int)$count->fetchColumn();

            $sql = 'SELECT ' . $this->ADM_AudioRoomLedgerColumns()
                . $this->ADM_AudioRoomLedgerFromSql()
                . ' WHERE ' . $whereSql
                . ' ORDER BY ledger.created_at DESC, ledger.id DESC LIMIT :limit OFFSET :offset';
            $stmt = $this->db()->prepare($sql);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value, in_array($key, [':date_from', ':date_to'], true) ? PDO::PARAM_INT : PDO::PARAM_STR);
            }
            $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            return [
                'rows' => $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [],
                'total' => $total,
                'page' => $page,
                'per' => $perPage,
            ];
        } catch (Throwable $e) {
            $this->logError('Audio room earnings list: ' . $e->getMessage());
            return ['rows' => [], 'total' => 0, 'page' => $page, 'per' => $perPage];
        }
    }

    public function ADM_AudioRoomTransactionExport(string $query, array $filters = [], int $limit = 5000): array
    {
        $limit = max(1, min(5000, $limit));
        try {
            [$whereSql, $params] = $this->ADM_AudioRoomLedgerFilters($query, $filters);
            $sql = 'SELECT ' . $this->ADM_AudioRoomLedgerColumns()
                . $this->ADM_AudioRoomLedgerFromSql()
                . ' WHERE ' . $whereSql
                . ' ORDER BY ledger.created_at DESC, ledger.id DESC LIMIT :limit';
            $stmt = $this->db()->prepare($sql);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value, in_array($key, [':date_from', ':date_to'], true) ? PDO::PARAM_INT : PDO::PARAM_STR);
            }
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable $e) {
            $this->logError('Audio room earnings export: ' . $e->getMessage());
            return [];
        }
    }

    public function ADM_AudioRoomOverview(): array
    {
        $overview = [
            'total_rooms' => 0,
            'live_rooms' => 0,
            'paid_rooms' => 0,
            'ticket_gross' => 0.0,
            'tip_gross' => 0.0,
            'creator_net' => 0.0,
            'platform_revenue' => 0.0,
        ];

        try {
            $roomStats = $this->db()->query("SELECT COUNT(*) AS total_rooms,
                    SUM(status = 'live') AS live_rooms,
                    SUM(is_paid = 1) AS paid_rooms
                FROM i_audio_rooms")->fetch(PDO::FETCH_ASSOC) ?: [];
            $overview['total_rooms'] = (int)($roomStats['total_rooms'] ?? 0);
            $overview['live_rooms'] = (int)($roomStats['live_rooms'] ?? 0);
            $overview['paid_rooms'] = (int)($roomStats['paid_rooms'] ?? 0);

            $statuses = $this->ADM_AudioRoomValidPaymentStatuses();
            $ticket = $this->db()->query("SELECT COALESCE(SUM(amount),0) AS gross,
                    COALESCE(SUM(net_amount),0) AS net,
                    COALESCE(SUM(fee_amount + tax_amount),0) AS platform
                FROM i_audio_room_tickets WHERE status IN ({$statuses})")->fetch(PDO::FETCH_ASSOC) ?: [];
            $tip = $this->db()->query("SELECT COALESCE(SUM(tp.amount),0) AS gross,
                    COALESCE(SUM(COALESCE(tp.net_amount,tp.amount)),0) AS net,
                    COALESCE(SUM(COALESCE(tp.fee_amount,0) + COALESCE(tp.tax_amount,0)),0) AS platform
                FROM i_tip_payments tp
                WHERE tp.status IN ({$statuses})
                  AND EXISTS (
                      SELECT 1
                      FROM i_audio_room_tip_events arte
                      WHERE arte.provider = tp.provider
                        AND arte.reference = tp.reference
                        AND arte.recipient_id = tp.recipient_id
                  )")->fetch(PDO::FETCH_ASSOC) ?: [];
            $overview['ticket_gross'] = (float)($ticket['gross'] ?? 0);
            $overview['tip_gross'] = (float)($tip['gross'] ?? 0);
            $overview['creator_net'] = (float)($ticket['net'] ?? 0) + (float)($tip['net'] ?? 0);
            $overview['platform_revenue'] = (float)($ticket['platform'] ?? 0) + (float)($tip['platform'] ?? 0);
        } catch (Throwable $e) {
            $this->logError('Audio room overview: ' . $e->getMessage());
        }

        return $overview;
    }

    public function ADM_PagedAudioRooms(string $query, int $page, int $perPage, array $filters = []): array
    {
        $page = max(1, $page);
        $perPage = max(10, min(100, $perPage));
        $offset = ($page - 1) * $perPage;
        $query = trim($query);
        $status = strtolower(trim((string)($filters['status'] ?? '')));
        $access = strtolower(trim((string)($filters['access'] ?? '')));
        if (!in_array($status, ['', 'created', 'live', 'ended', 'cancelled'], true)) {
            $status = '';
        }
        if (!in_array($access, ['', 'free', 'paid'], true)) {
            $access = '';
        }

        $where = ['1=1'];
        $params = [];
        if ($query !== '') {
            $where[] = '(r.title LIKE :search OR u.username LIKE :search OR u.user_fullname LIKE :search OR CAST(r.room_id AS CHAR) = :room_exact)';
            $params[':search'] = '%' . $query . '%';
            $params[':room_exact'] = ctype_digit($query) ? $query : '-1';
        }
        if ($status !== '') {
            $where[] = 'r.status = :status';
            $params[':status'] = $status;
        }
        if ($access !== '') {
            $where[] = 'r.is_paid = :is_paid';
            $params[':is_paid'] = $access === 'paid' ? 1 : 0;
        }
        $whereSql = implode(' AND ', $where);
        $statuses = $this->ADM_AudioRoomValidPaymentStatuses();

        try {
            $count = $this->db()->prepare("SELECT COUNT(*) FROM i_audio_rooms r
                INNER JOIN i_users u ON u.user_id = r.owner_id WHERE {$whereSql}");
            $count->execute($params);
            $total = (int)$count->fetchColumn();

            $sql = "SELECT r.*, u.username, u.user_fullname, u.user_avatar, u.verified_status,
                    COALESCE(pa.participant_count,0) AS participant_count,
                    COALESCE(pa.online_count,0) AS online_count,
                    COALESCE(pa.speaker_count,0) AS speaker_count,
                    COALESCE(tk.ticket_count,0) AS ticket_count,
                    COALESCE(tk.ticket_gross,0) AS ticket_gross,
                    COALESCE(tk.ticket_net,0) AS ticket_net,
                    COALESCE(tp.tip_count,0) AS tip_count,
                    COALESCE(tp.tip_gross,0) AS tip_gross,
                    COALESCE(tp.tip_net,0) AS tip_net
                FROM i_audio_rooms r
                INNER JOIN i_users u ON u.user_id = r.owner_id
                LEFT JOIN (
                    SELECT room_id, COUNT(DISTINCT COALESCE(user_id, id)) AS participant_count,
                        SUM(status='joined' AND last_seen >= UNIX_TIMESTAMP()-60) AS online_count,
                        SUM(status='joined' AND role IN ('host','moderator','speaker') AND last_seen >= UNIX_TIMESTAMP()-60) AS speaker_count
                    FROM i_audio_room_participants GROUP BY room_id
                ) pa ON pa.room_id = r.room_id
                LEFT JOIN (
                    SELECT room_id, COUNT(*) AS ticket_count, SUM(amount) AS ticket_gross, SUM(net_amount) AS ticket_net
                    FROM i_audio_room_tickets WHERE status IN ({$statuses}) GROUP BY room_id
                ) tk ON tk.room_id = r.room_id
                LEFT JOIN (
                    SELECT room_id, COUNT(*) AS tip_count, SUM(amount) AS tip_gross, SUM(net_amount) AS tip_net
                    FROM i_audio_room_tip_events WHERE status IN ({$statuses}) GROUP BY room_id
                ) tp ON tp.room_id = r.room_id
                WHERE {$whereSql}
                ORDER BY FIELD(r.status,'live','created','ended','cancelled'), COALESCE(r.started_at,r.created_at) DESC, r.room_id DESC
                LIMIT :limit OFFSET :offset";
            $stmt = $this->db()->prepare($sql);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value, $key === ':is_paid' ? PDO::PARAM_INT : PDO::PARAM_STR);
            }
            $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
            return ['rows' => $rows, 'total' => $total, 'page' => $page, 'per' => $perPage];
        } catch (Throwable $e) {
            $this->logError('Audio room list: ' . $e->getMessage());
            return ['rows' => [], 'total' => 0, 'page' => $page, 'per' => $perPage];
        }
    }

    public function ADM_CloseAudioRoom(int $roomId, int $adminId, string $reason): array
    {
        $reason = trim(preg_replace('/\s+/u', ' ', $reason) ?? '');
        if ($roomId <= 0 || $adminId <= 0) {
            return ['ok' => false, 'code' => 'invalid_request'];
        }
        if (mb_strlen($reason) < 3 || mb_strlen($reason) > 255) {
            return ['ok' => false, 'code' => 'invalid_reason'];
        }

        $db = $this->db();
        try {
            $db->beginTransaction();
            $lock = $db->prepare('SELECT room_id, owner_id, title, status FROM i_audio_rooms WHERE room_id = :room FOR UPDATE');
            $lock->execute([':room' => $roomId]);
            $room = $lock->fetch(PDO::FETCH_ASSOC);
            if (!$room) {
                $db->rollBack();
                return ['ok' => false, 'code' => 'not_found'];
            }

            $oldStatus = strtolower((string)$room['status']);
            if (!in_array($oldStatus, ['created', 'live'], true)) {
                $db->rollBack();
                return ['ok' => false, 'code' => 'already_closed'];
            }
            $newStatus = $oldStatus === 'live' ? 'ended' : 'cancelled';
            $now = time();
            $marker = $newStatus === 'ended' ? 'admin_ended' : 'admin_cancelled';

            $update = $db->prepare('UPDATE i_audio_rooms SET status = :status, ended_at = :ended, end_reason = :reason, updated_at = :updated WHERE room_id = :room');
            $update->execute([':status' => $newStatus, ':ended' => $now, ':reason' => $marker, ':updated' => $now, ':room' => $roomId]);

            $participants = $db->prepare("UPDATE i_audio_room_participants
                SET status='removed', left_at=COALESCE(left_at,:now), last_seen=:now, removed_by=:admin, moderation_reason=:reason
                WHERE room_id=:room AND status='joined'");
            $participants->execute([':now' => $now, ':admin' => $adminId, ':reason' => mb_substr($reason, 0, 255), ':room' => $roomId]);

            $speakers = $db->prepare("UPDATE i_audio_room_speakers SET status='removed', updated_at=:now
                WHERE room_id=:room AND status IN ('invited','active','muted')");
            $speakers->execute([':now' => $now, ':room' => $roomId]);

            $requests = $db->prepare("UPDATE i_audio_room_speaker_requests SET status='rejected', reviewed_at=:now, reviewed_by=:admin
                WHERE room_id=:room AND status='pending'");
            $requests->execute([':now' => $now, ':admin' => $adminId, ':room' => $roomId]);

            $message = $db->prepare("INSERT INTO i_audio_room_messages (room_id, uid_fk, message, message_type, meta_json, created_at)
                VALUES (:room,:admin,:message,'system',:meta,:created)");
            $message->execute([
                ':room' => $roomId,
                ':admin' => $adminId,
                ':message' => 'Room closed by an administrator.',
                ':meta' => json_encode(['event' => 'room_ended', 'actor_id' => $adminId, 'reason' => $reason], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                ':created' => $now,
            ]);

            $db->commit();
            $this->ADM_Audit($adminId, 'audio_room_' . $newStatus, 'room:' . $roomId . ':' . mb_substr($reason, 0, 40), $now);
            return ['ok' => true, 'status' => $newStatus, 'room_id' => $roomId];
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            $this->logError('Close audio room: ' . $e->getMessage());
            return ['ok' => false, 'code' => 'server_error'];
        }
    }
}
