<?php
declare(strict_types=1);

trait AdminAuditFunctions
{
    protected function ensureAuditTable(): void
    {
        try {
            $this->db()->exec(
                "CREATE TABLE IF NOT EXISTS i_admin_audit (
                    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    user_id INT UNSIGNED NOT NULL,
                    action VARCHAR(64) NOT NULL,
                    target_key VARCHAR(64) NOT NULL,
                    created_at INT UNSIGNED NOT NULL,
                    PRIMARY KEY(id),
                    KEY idx_user_time(user_id, created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
        } catch (\Throwable $__) {
            // ignore
        }
    }

    public function ADM_Audit(int $adminUserId, string $action, string $targetKey, ?int $ts = null): void
    {
        $this->ensureAuditTable();
        $ts = $ts ?? time();
        try {
            $st = $this->db()->prepare('INSERT INTO i_admin_audit (user_id, action, target_key, created_at) VALUES (:u,:a,:t,:c)');
            $st->execute([':u' => $adminUserId, ':a' => $action, ':t' => $targetKey, ':c' => $ts]);
        } catch (\Throwable $__) {
            // ignore
        }
    }
}

