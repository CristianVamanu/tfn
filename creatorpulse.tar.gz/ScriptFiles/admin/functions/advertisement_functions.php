<?php
declare(strict_types=1);

trait AdminAdvertisementFunctions
{
    /**
     * Retrieve advertisements with optional filters.
     * @return array{rows:array<int,array<string,mixed>>,total:int,page:int,per_page:int}
     */
    public function ADM_PaginateAdvertisements(int $page = 1, int $perPage = 20, string $mediaType = '', string $status = '', string $search = ''): array
    {
        $page = max(1, $page);
        $perPage = max(1, min(100, $perPage));
        $offset = ($page - 1) * $perPage;

        $mediaType = strtolower(trim($mediaType));
        if (!in_array($mediaType, ['image', 'video'], true)) {
            $mediaType = '';
        }

        $status = strtolower(trim($status));
        if (!in_array($status, ['draft', 'active', 'paused', 'ended'], true)) {
            $status = '';
        }

        $search = trim($search);
        $conditions = [];
        $params = [];

        if ($mediaType !== '') {
            $conditions[] = 'a.media_type = :media_type';
            $params[':media_type'] = $mediaType;
        }
        if ($status !== '') {
            $conditions[] = 'a.status = :status';
            $params[':status'] = $status;
        }
        if ($search !== '') {
            $conditions[] = '(a.title LIKE :term OR a.description LIKE :term OR u.username LIKE :term OR u.user_fullname LIKE :term)';
            $params[':term'] = '%' . $search . '%';
        }

        $where = $conditions ? ('WHERE ' . implode(' AND ', $conditions)) : '';

        try {
            $db = $this->db();

            $countSql = 'SELECT COUNT(*) FROM i_user_advertisements a '
                . 'LEFT JOIN i_users u ON u.user_id = a.user_id '
                . $where;
            $countStmt = $db->prepare($countSql);
            foreach ($params as $key => $value) {
                $countStmt->bindValue($key, $value, \PDO::PARAM_STR);
            }
            $countStmt->execute();
            $total = (int) $countStmt->fetchColumn();

            $dataSql = 'SELECT a.*, u.username, u.user_fullname, u.user_avatar '
                . 'FROM i_user_advertisements a '
                . 'LEFT JOIN i_users u ON u.user_id = a.user_id '
                . $where
                . ' ORDER BY a.created_at DESC LIMIT :offset, :per_page';
            $dataStmt = $db->prepare($dataSql);
            foreach ($params as $key => $value) {
                $dataStmt->bindValue($key, $value, \PDO::PARAM_STR);
            }
            $dataStmt->bindValue(':offset', (int) $offset, \PDO::PARAM_INT);
            $dataStmt->bindValue(':per_page', (int) $perPage, \PDO::PARAM_INT);
            $dataStmt->execute();
            $rows = $dataStmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];

            return [
                'rows'     => $rows,
                'total'    => $total,
                'page'     => $page,
                'per_page' => $perPage,
            ];
        } catch (\Throwable $e) {
            $this->logError('ADM_PaginateAdvertisements failed: ' . $e->getMessage());
            return [
                'rows'     => [],
                'total'    => 0,
                'page'     => $page,
                'per_page' => $perPage,
            ];
        }
    }

    public function ADM_GetAdvertisementById(int $adId): ?array
    {
        $adId = max(0, $adId);
        if ($adId <= 0) {
            return null;
        }

        try {
            $stmt = $this->db()->prepare(
                'SELECT a.*, u.username, u.user_fullname, u.user_avatar '
                . 'FROM i_user_advertisements a '
                . 'LEFT JOIN i_users u ON u.user_id = a.user_id '
                . 'WHERE a.ad_id = :id LIMIT 1'
            );
            $stmt->bindValue(':id', $adId, \PDO::PARAM_INT);
            $stmt->execute();
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (\Throwable $e) {
            $this->logError('ADM_GetAdvertisementById failed: ' . $e->getMessage());
            return null;
        }
    }

    public function ADM_UpdateAdvertisement(int $adId, array $fields): bool
    {
        $adId = max(0, $adId);
        if ($adId <= 0 || empty($fields)) {
            return false;
        }

        $allowed = [
            'title'                => \PDO::PARAM_STR,
            'description'          => \PDO::PARAM_STR,
            'target_impressions'   => \PDO::PARAM_INT,
            'price_per_impression' => 'float',
            'duration_days'        => \PDO::PARAM_INT,
            'total_budget'         => 'float',
            'status'               => \PDO::PARAM_STR,
            'ad_media'             => \PDO::PARAM_STR,
        ];

        $set = [];
        $params = [':id' => $adId];

        foreach ($allowed as $column => $type) {
            if (!array_key_exists($column, $fields)) {
                continue;
            }

            $value = $fields[$column];
            if (is_string($value)) {
                $value = trim($value);
            }

            if ($column === 'status' && !in_array($value, ['draft', 'active', 'paused', 'ended'], true)) {
                continue;
            }

            $set[] = "$column = :$column";
            $params[":$column"] = $value;
            $allowed[$column] = $type;
        }

        if ($set === []) {
            return false;
        }

        $set[] = 'updated_at = :updated_at';
        $params[':updated_at'] = time();

        try {
            $stmt = $this->db()->prepare('UPDATE i_user_advertisements SET ' . implode(', ', $set) . ' WHERE ad_id = :id LIMIT 1');
            foreach ($params as $key => $value) {
                if ($key === ':id') {
                    $stmt->bindValue($key, (int) $value, \PDO::PARAM_INT);
                    continue;
                }
                if ($key === ':updated_at') {
                    $stmt->bindValue($key, (int) $value, \PDO::PARAM_INT);
                    continue;
                }

                $column = ltrim($key, ':');
                $type = $allowed[$column] ?? \PDO::PARAM_STR;
                if ($type === 'float') {
                    $stmt->bindValue($key, (string) ((float) $value), \PDO::PARAM_STR);
                } elseif ($type === \PDO::PARAM_INT) {
                    $stmt->bindValue($key, (int) $value, \PDO::PARAM_INT);
                } else {
                    $stmt->bindValue($key, (string) $value, \PDO::PARAM_STR);
                }
            }

            return (bool) $stmt->execute();
        } catch (\Throwable $e) {
            $this->logError('ADM_UpdateAdvertisement failed: ' . $e->getMessage());
            return false;
        }
    }

    public function ADM_RemoveAdvertisementMediaFiles(array $paths, string $mediaType): void
    {
        if (empty($paths)) {
            return;
        }

        $projectRoot = dirname(__DIR__, 2);
        $uploadsRoot = $projectRoot . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR;

        foreach ($paths as $rawPath) {
            $relative = trim(str_replace(['\\'], ['/' ], (string) $rawPath), '/');
            if ($relative === '') {
                continue;
            }

            if ($mediaType === 'image' && strpos($relative, 'uploads/advertisement_ifiles/') !== 0) {
                continue;
            }
            if ($mediaType === 'video' && strpos($relative, 'uploads/advertisement_vfiles/') !== 0) {
                continue;
            }

            $fullPath = $projectRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
            $realPath = @realpath($fullPath);
            if ($realPath === false) {
                continue;
            }
            if (strpos($realPath, $uploadsRoot) !== 0) {
                continue;
            }
            if (is_file($realPath)) {
                @unlink($realPath);
            }
        }
    }

    public function ADM_UpdateAdvertisementStatus(int $adId, string $status): bool
    {
        $adId = max(0, $adId);
        $status = strtolower(trim($status));
        if ($adId <= 0 || !in_array($status, ['draft', 'active', 'paused', 'ended'], true)) {
            return false;
        }

        try {
            $rl = $this->rl();
            if ($rl && method_exists($rl, 'RL_UpdateAdvertisementStatus')) {
                return (bool) $rl->RL_UpdateAdvertisementStatus($adId, $status);
            }

            $stmt = $this->db()->prepare('UPDATE i_user_advertisements SET status = :st, updated_at = :t WHERE ad_id = :id');
            $stmt->bindValue(':st', $status, \PDO::PARAM_STR);
            $stmt->bindValue(':t', time(), \PDO::PARAM_INT);
            $stmt->bindValue(':id', $adId, \PDO::PARAM_INT);
            return (bool) $stmt->execute();
        } catch (\Throwable $e) {
            $this->logError('ADM_UpdateAdvertisementStatus failed: ' . $e->getMessage());
            return false;
        }
    }

    public function ADM_DeleteAdvertisement(int $adId): bool
    {
        $adId = max(0, $adId);
        if ($adId <= 0) { return false; }
        try {
            $rl = $this->rl();
            if ($rl && method_exists($rl, 'RL_DeleteAdvertisement')) {
                return (bool) $rl->RL_DeleteAdvertisement($adId);
            }

            $stmt = $this->db()->prepare('DELETE FROM i_user_advertisements WHERE ad_id = :id LIMIT 1');
            $stmt->bindValue(':id', $adId, \PDO::PARAM_INT);
            return (bool) $stmt->execute();
        } catch (\Throwable $e) {
            $this->logError('ADM_DeleteAdvertisement failed: ' . $e->getMessage());
            return false;
        }
    }
}
