<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';
require_once __DIR__ . '/_init.php';

// Ensure sidebar highlights the correct entry
$_GET['page'] = 'fake_user_generator';

$layoutFile = __DIR__ . '/pages/generate_fake_user.php';
require __DIR__ . '/main.php';
