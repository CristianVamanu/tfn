<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

$csrf = isset($_POST['csrf_token']) ? (string) $_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

if (!isset($RL) || !($RL instanceof Reel_Data)) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}

$action = isset($_POST['action']) ? trim((string) $_POST['action']) : '';
$theme  = isset($_POST['theme']) ? (string) $_POST['theme'] : 'welcome_default';
$theme  = preg_replace('/[^a-z0-9_-]/i', '', strtolower($theme)) ?: 'welcome_default';

if (!function_exists('landingNormalizeLangKey')) {
    function landingNormalizeLangKey(string $langCode): string
    {
        $langCode = strtolower(trim($langCode));
        $map = [
            'eng' => 'en',
            'en' => 'en',
            'english' => 'en',
            'tr' => 'tr',
            'tur' => 'tr',
            'trk' => 'tr',
            'turkish' => 'tr',
        ];
        if (isset($map[$langCode])) {
            return $map[$langCode];
        }
        if (strlen($langCode) >= 2) {
            return substr($langCode, 0, 2);
        }
        return $langCode;
    }
}

if (!function_exists('landingAvailableLanguages')) {
    function landingAvailableLanguages(): array
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }

        $dir = dirname(__DIR__, 2) . '/langs';
        $langs = [];
        if (is_dir($dir)) {
            foreach (scandir($dir) as $entry) {
                if (!is_string($entry)) {
                    continue;
                }
                if (preg_match('/^(\w+)\.php$/', $entry, $match)) {
                    $langs[] = strtolower($match[1]);
                }
            }
        }

        if (!$langs) {
            $langs = ['eng'];
        }

        return $cache = array_values(array_unique($langs));
    }
}

if (!class_exists('LandingPageAdminPageService')) {
    final class LandingPageAdminPageService
    {
        use PageCmsFunctions;

        private PDO $db;

        public function __construct(PDO $db)
        {
            $this->db = $db;
        }

        protected function logError(string $msg): void
        {
            error_log('[LandingPageAdmin] ' . $msg);
        }
    }
}

if ($action === 'save_image_list') {
    $mediaMode = isset($_POST['media_mode']) ? strtolower(trim((string) $_POST['media_mode'])) : 'mixed';
    if (!in_array($mediaMode, ['mixed', 'image', 'video'], true)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_media_mode']);
        exit;
    }

    $target = isset($_POST['target']) ? strtolower(trim((string) $_POST['target'])) : 'profile';
    if (!in_array($target, ['profile', 'post'], true)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_target']);
        exit;
    }

    $showViews = isset($_POST['show_views']) && ($_POST['show_views'] === '1' || strtolower((string) $_POST['show_views']) === 'on');
    $showLikes = isset($_POST['show_likes']) && ($_POST['show_likes'] === '1' || strtolower((string) $_POST['show_likes']) === 'on');

    $cfg = [
        'media_mode' => $mediaMode,
        'target' => $target,
        'show_views' => $showViews,
        'show_likes' => $showLikes,
    ];

    if ($RL->RL_SaveLandingSectionConfig($theme, 'image_list', $cfg)) {
        echo json_encode(['status' => 'success']);
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
    }
    exit;
}

if ($action === 'save_marquee') {
    $listCount = isset($_POST['list_count']) ? (int) $_POST['list_count'] : 4;
    if ($listCount < 1) { $listCount = 1; }
    if ($listCount > 10) { $listCount = 10; }

    $showAvatar = isset($_POST['show_avatar']) && ($_POST['show_avatar'] === '1' || strtolower((string) $_POST['show_avatar']) === 'on');
    $nameMode = isset($_POST['name_mode']) ? strtolower(trim((string) $_POST['name_mode'])) : 'full';
    if (!in_array($nameMode, ['full', 'username'], true)) {
        $nameMode = 'full';
    }

    $cfg = [
        'list_count' => $listCount,
        'show_avatar' => $showAvatar,
        'name_mode' => $nameMode,
    ];

    $displayNames = isset($_POST['display_name']) && is_array($_POST['display_name']) ? $_POST['display_name'] : [];
    $usernames = isset($_POST['username']) && is_array($_POST['username']) ? $_POST['username'] : [];
    $avatars = isset($_POST['avatar']) && is_array($_POST['avatar']) ? $_POST['avatar'] : [];
    $ids = isset($_POST['item_id']) && is_array($_POST['item_id']) ? $_POST['item_id'] : [];
    $verifiedInput = isset($_POST['verified']) && is_array($_POST['verified']) ? $_POST['verified'] : [];

    $items = [];
    foreach ($displayNames as $key => $displayVal) {
        $display = iN_CleanTranslationInput((string) $displayVal);
        $username = iN_CleanTranslationInput((string) ($usernames[$key] ?? ''));
        $avatar = trim((string) ($avatars[$key] ?? ''));
        $verified = isset($verifiedInput[$key]);
        $itemId = isset($ids[$key]) ? (int) $ids[$key] : 0;

        if ($display === '' && $username === '' && $avatar === '') {
            continue;
        }

        $items[] = [
            'id' => $itemId,
            'display' => $display,
            'username' => $username,
            'avatar' => $avatar,
            'verified' => $verified,
        ];
    }

    if (!$RL->RL_SaveLandingSectionConfig($theme, 'marquee', $cfg)) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }

    if (!$RL->RL_SaveLandingSectionItems($theme, 'marquee', $items)) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }

    echo json_encode(['status' => 'success']);
    exit;
}

if ($action === 'save_get_started') {
    $colorRaw = isset($_POST['data_ma_color']) ? trim((string) $_POST['data_ma_color']) : '';
    if ($colorRaw !== '' && !preg_match('/^#[0-9a-fA-F]{3,8}$/', $colorRaw)) {
        $colorRaw = '';
    }
    if ($colorRaw === '') {
        $colorRaw = '#FF3C3C';
    }

    $itemId = isset($_POST['get_started_item_id']) ? (int) $_POST['get_started_item_id'] : 0;

    $titleInput = isset($_POST['get_started_title']) && is_array($_POST['get_started_title']) ? $_POST['get_started_title'] : [];
    $descInput = isset($_POST['get_started_desc']) && is_array($_POST['get_started_desc']) ? $_POST['get_started_desc'] : [];
    $buttonInput = isset($_POST['get_started_button']) && is_array($_POST['get_started_button']) ? $_POST['get_started_button'] : [];

    $langKeys = array_keys($titleInput);
    foreach ([$descInput, $buttonInput] as $pool) {
        if ($pool) {
            foreach ($pool as $lang => $_) {
                if (!in_array($lang, $langKeys, true)) {
                    $langKeys[] = $lang;
                }
            }
        }
    }

    $langKeys = array_values(array_unique(array_map('strval', $langKeys)));

    $translations = [];
    foreach ($langKeys as $langCodeRaw) {
        $langCode = strtolower(trim((string) $langCodeRaw));
        if ($langCode === '') {
            continue;
        }

        $titleRaw = isset($titleInput[$langCode]) ? (string) $titleInput[$langCode] : '';
        $descRaw = isset($descInput[$langCode]) ? (string) $descInput[$langCode] : '';
        $buttonRaw = isset($buttonInput[$langCode]) ? (string) $buttonInput[$langCode] : '';

        $titleRaw = preg_replace('/<\/?br\s*\/?\s*>/i', "\n", $titleRaw);
        $descRaw = preg_replace('/<\/?br\s*\/?\s*>/i', "\n", $descRaw);
        $buttonRaw = preg_replace('/<\/?br\s*\/?\s*>/i', "\n", $buttonRaw);

        $title = iN_CleanTranslationInput($titleRaw);
        if ($title !== '' && mb_strlen($title) > 200) {
            http_response_code(400);
            echo json_encode([
                'status' => 'error',
                'message' => 'invalid_length',
                'field' => 'title',
                'language' => $langCode,
            ]);
            exit;
        }

        $desc = iN_CleanTranslationInput($descRaw);
        if ($desc !== '' && mb_strlen($desc) > 600) {
            http_response_code(400);
            echo json_encode([
                'status' => 'error',
                'message' => 'invalid_length',
                'field' => 'description',
                'language' => $langCode,
            ]);
            exit;
        }

        $button = iN_CleanTranslationInput($buttonRaw);
        if ($button !== '' && mb_strlen($button) > 100) {
            http_response_code(400);
            echo json_encode([
                'status' => 'error',
                'message' => 'invalid_length',
                'field' => 'button',
                'language' => $langCode,
            ]);
            exit;
        }

        if ($title === '' && $desc === '' && $button === '') {
            continue;
        }

        $storageKey = landingNormalizeLangKey($langCode);
        $translations[$storageKey] = [
            'title' => $title,
            'desc' => $desc,
            'button' => $button,
        ];
    }

    $cfg = [
        'data_ma_color' => $colorRaw,
    ];

    if (!$RL->RL_SaveLandingSectionConfig($theme, 'get_started', $cfg)) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }

    $items = [];
    if ($translations) {
        $items[] = [
            'id' => $itemId,
            'translations' => $translations,
        ];
    }

    if (!$RL->RL_SaveLandingSectionItems($theme, 'get_started', $items)) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }

    echo json_encode(['status' => 'success']);
    exit;
}

if ($action === 'save_faqs') {
    $idInput = isset($_POST['faq_id']) && is_array($_POST['faq_id']) ? $_POST['faq_id'] : [];
    $orderInput = isset($_POST['faq_order']) && is_array($_POST['faq_order']) ? $_POST['faq_order'] : [];
    $questionInput = isset($_POST['faq_question']) && is_array($_POST['faq_question']) ? $_POST['faq_question'] : [];
    $answerInput = isset($_POST['faq_answer']) && is_array($_POST['faq_answer']) ? $_POST['faq_answer'] : [];

    $langKeys = array_keys($questionInput);
    foreach ($answerInput as $lang => $_) {
        if (!in_array($lang, $langKeys, true)) {
            $langKeys[] = $lang;
        }
    }
    if (!$langKeys) {
        $langKeys = ['eng'];
    }

    $orderKeys = [];
    foreach ($orderInput as $key) {
        $key = trim((string) $key);
        if ($key !== '') {
            $orderKeys[] = $key;
        }
    }
    if (!$orderKeys) {
        foreach ($questionInput as $langPool) {
            if (is_array($langPool)) {
                foreach ($langPool as $key => $_) {
                    $key = trim((string) $key);
                    if ($key !== '') {
                        $orderKeys[] = $key;
                    }
                }
            }
        }
        foreach ($answerInput as $langPool) {
            if (is_array($langPool)) {
                foreach ($langPool as $key => $_) {
                    $key = trim((string) $key);
                    if ($key !== '') {
                        $orderKeys[] = $key;
                    }
                }
            }
        }
    }
    $orderKeys = array_values(array_unique($orderKeys));

    $items = [];
    $questionLimit = 200;
    $answerLimit = 600;
    foreach ($orderKeys as $rawKey) {
        $key = (string) $rawKey;
        if ($key === '') {
            continue;
        }
        $itemId = isset($idInput[$key]) ? (int) $idInput[$key] : 0;
        $translations = [];
        foreach ($langKeys as $langCodeRaw) {
            $langCode = strtolower((string) $langCodeRaw);
            if ($langCode === '') {
                continue;
            }
            $qPool = isset($questionInput[$langCode]) && is_array($questionInput[$langCode]) ? $questionInput[$langCode] : [];
            $aPool = isset($answerInput[$langCode]) && is_array($answerInput[$langCode]) ? $answerInput[$langCode] : [];
            $questionRaw = isset($qPool[$key]) ? (string) $qPool[$key] : '';
            $answerRaw = isset($aPool[$key]) ? (string) $aPool[$key] : '';

            $questionRaw = preg_replace('/<\/?br\s*\/?\s*>/i', "\n", $questionRaw);
            $answerRaw = preg_replace('/<\/?br\s*\/?\s*>/i', "\n", $answerRaw);

            $question = iN_CleanTranslationInput($questionRaw);
            if ($question !== '' && mb_strlen($question) > $questionLimit) {
                http_response_code(400);
                echo json_encode([
                    'status' => 'error',
                    'message' => 'invalid_length',
                    'field' => 'question',
                    'language' => $langCode,
                ]);
                exit;
            }

            $answer = iN_CleanTranslationInput($answerRaw);
            if ($answer !== '' && mb_strlen($answer) > $answerLimit) {
                http_response_code(400);
                echo json_encode([
                    'status' => 'error',
                    'message' => 'invalid_length',
                    'field' => 'answer',
                    'language' => $langCode,
                ]);
                exit;
            }

            if ($question === '' && $answer === '') {
                continue;
            }

            $storageKey = landingNormalizeLangKey($langCode);
            $translations[$storageKey] = [
                'q' => $question,
                'a' => $answer,
            ];
        }

        if (!$translations) {
            continue;
        }

        $items[] = [
            'id' => $itemId,
            'item_type' => 'faq',
            'translations' => $translations,
        ];
    }

    if (!$RL->RL_SaveLandingSectionItems($theme, 'faqs', $items)) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }

    echo json_encode(['status' => 'success']);
    exit;
}

if ($action === 'save_footer_pages') {
    $pageIdsInput = isset($_POST['page_id']) && is_array($_POST['page_id']) ? $_POST['page_id'] : [];
    $slugInput = isset($_POST['page_slug']) && is_array($_POST['page_slug']) ? $_POST['page_slug'] : [];
    $sortInput = isset($_POST['page_sort']) && is_array($_POST['page_sort']) ? $_POST['page_sort'] : [];
    $activeInput = isset($_POST['page_active']) && is_array($_POST['page_active']) ? $_POST['page_active'] : [];
    $titleInput = isset($_POST['page_title']) && is_array($_POST['page_title']) ? $_POST['page_title'] : [];
    $contentInput = isset($_POST['page_content']) && is_array($_POST['page_content']) ? $_POST['page_content'] : [];
    $orderInput = isset($_POST['page_order']) && is_array($_POST['page_order']) ? $_POST['page_order'] : [];
    $removedInput = isset($_POST['page_removed']) && is_array($_POST['page_removed']) ? $_POST['page_removed'] : [];

    $availableLangs = landingAvailableLanguages();
    $defaultLangRaw = isset($_POST['default_lang']) ? strtolower(trim((string) $_POST['default_lang'])) : '';
    if (!in_array($defaultLangRaw, $availableLangs, true)) {
        $defaultLangRaw = $availableLangs[0] ?? 'eng';
    }
    $defaultLang = $defaultLangRaw ?: 'eng';

    $normalizeLangArray = static function (array $data): array {
        $out = [];
        foreach ($data as $lang => $pool) {
            if (!is_array($pool)) {
                continue;
            }
            $key = strtolower((string) $lang);
            $out[$key] = $pool;
        }
        return $out;
    };

    $titles = $normalizeLangArray($titleInput);
    $contents = $normalizeLangArray($contentInput);

    $langKeys = array_unique(array_merge(array_keys($titles), array_keys($contents)));
    if (!$langKeys) {
        $langKeys = $availableLangs;
    }
    $langKeys = array_values(array_filter($langKeys, static function ($lang) use ($availableLangs): bool {
        return in_array($lang, $availableLangs, true);
    }));
    if (!$langKeys) {
        $langKeys = $availableLangs;
    }

    $orderKeys = [];
    foreach ($orderInput as $key) {
        $key = trim((string) $key);
        if ($key !== '') {
            $orderKeys[] = $key;
        }
    }
    if (!$orderKeys) {
        foreach ($pageIdsInput as $key => $_) {
            $orderKeys[] = (string) $key;
        }
    }
    $orderKeys = array_values(array_unique($orderKeys));

    $pagesPayload = [];
    foreach ($orderKeys as $rawKey) {
        $key = (string) $rawKey;
        if ($key === '') {
            continue;
        }

        $pageId = isset($pageIdsInput[$key]) ? (int) $pageIdsInput[$key] : 0;
        $slugRaw = isset($slugInput[$key]) ? trim((string) $slugInput[$key]) : '';
        if (mb_strlen($slugRaw) > 120) {
            $slugRaw = mb_substr($slugRaw, 0, 120);
        }
        $sortOrder = isset($sortInput[$key]) ? (int) $sortInput[$key] : 0;
        $isActive = isset($activeInput[$key]) && (string) $activeInput[$key] !== '0' ? 1 : 0;

        $translations = [];
        $hasContent = false;
        foreach ($langKeys as $langCode) {
            $titlePool = $titles[$langCode] ?? [];
            $contentPool = $contents[$langCode] ?? [];
            $titleVal = isset($titlePool[$key]) ? trim((string) $titlePool[$key]) : '';
            $contentVal = isset($contentPool[$key]) ? (string) $contentPool[$key] : '';
            if (!$hasContent) {
                if ($titleVal !== '' || trim($contentVal) !== '') {
                    $hasContent = true;
                }
            }
            $translations[$langCode] = [
                'title' => $titleVal,
                'content' => $contentVal,
            ];
        }

        $defaultTitle = $translations[$defaultLang]['title'] ?? '';
        $slugPresent = $slugRaw !== '';
        if (!$hasContent && !$slugPresent && $pageId <= 0) {
            continue;
        }
        if ($defaultTitle === '') {
            http_response_code(422);
            echo json_encode(['status' => 'error', 'message' => 'default_title_required']);
            exit;
        }

        $pagesPayload[] = [
            'id' => $pageId,
            'slug' => $slugRaw,
            'is_active' => $isActive,
            'sort_order' => $sortOrder,
            'default_title' => $defaultTitle,
            'translations' => $translations,
        ];
    }

    $removedIds = array_values(array_filter(array_map('intval', $removedInput), static function (int $id): bool {
        return $id > 0;
    }));

    $pageService = ($RL && method_exists($RL, 'RL_SavePagesDetailed')) ? $RL : new LandingPageAdminPageService($db);

    try {
        if ($pagesPayload) {
            $pageService->RL_SavePagesDetailed($pagesPayload, $defaultLang);
        }
    } catch (InvalidArgumentException $e) {
        http_response_code(422);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage() ?: 'default_title_required']);
        exit;
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }

    if ($removedIds) {
        try {
            if (!$pageService->RL_DeletePages($removedIds)) {
                http_response_code(500);
                echo json_encode(['status' => 'error', 'message' => 'server_error']);
                exit;
            }
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'server_error']);
            exit;
        }
    }

    echo json_encode(['status' => 'success']);
    exit;
}

http_response_code(400);
echo json_encode(['status' => 'error', 'message' => 'bad_action']);
