<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

global $db, $siteData, $userData;

$csrf = isset($_POST['csrf_token']) ? (string) $_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$normalizeToggle = static function ($value, bool $default = false): string {
    $raw = is_string($value) ? strtolower(trim($value)) : (is_numeric($value) ? (string) $value : '');
    if ($raw === '') {
        return $default ? '1' : '0';
    }
    return in_array($raw, ['1', 'true', 'on', 'yes', 'enabled'], true) ? '1' : '0';
};

try {
    $enabled     = $normalizeToggle($_POST['onesignal_enabled'] ?? '', false);
    $autoPrompt  = $normalizeToggle($_POST['onesignal_auto_prompt'] ?? '', true);

    $appIdRaw    = array_key_exists('onesignal_app_id', $_POST) ? trim((string) $_POST['onesignal_app_id']) : null;
    $safariRaw   = array_key_exists('onesignal_safari_web_id', $_POST) ? trim((string) $_POST['onesignal_safari_web_id']) : null;
    $welcomeTitleRaw   = array_key_exists('onesignal_welcome_title', $_POST) ? trim((string) $_POST['onesignal_welcome_title']) : null;
    $welcomeMessageRaw = array_key_exists('onesignal_welcome_message', $_POST) ? trim((string) $_POST['onesignal_welcome_message']) : null;

    $restKeyClear = ((string)($_POST['onesignal_rest_api_key_clear'] ?? '0') === '1');
    $restKeyRaw = trim((string) ($_POST['onesignal_rest_api_key'] ?? ''));
    $restKeyValue = null;

    if ($restKeyRaw !== '') {
        if (!preg_match('/^[\x21-\x7E]{8,191}$/', $restKeyRaw)) {
            http_response_code(422);
            echo json_encode(['status' => 'error', 'message' => 'invalid_rest_key']);
            exit;
        }
        $restKeyValue = $restKeyRaw;
    }

    if ($appIdRaw !== null && $appIdRaw !== '') {
        if (!preg_match('/^[A-Za-z0-9-]{8,64}$/', $appIdRaw)) {
            http_response_code(422);
            echo json_encode(['status' => 'error', 'message' => 'invalid_app_id']);
            exit;
        }
    }

    if ($safariRaw !== null && $safariRaw !== '') {
        if (strlen($safariRaw) > 191 || !preg_match('/^[A-Za-z0-9_.-]{4,191}$/', $safariRaw)) {
            http_response_code(422);
            echo json_encode(['status' => 'error', 'message' => 'invalid_safari_web_id']);
            exit;
        }
    }

    if ($welcomeTitleRaw !== null && mb_strlen($welcomeTitleRaw, 'UTF-8') > 80) {
        http_response_code(422);
        echo json_encode(['status' => 'error', 'message' => 'invalid_welcome_title']);
        exit;
    }

    if ($welcomeMessageRaw !== null && mb_strlen($welcomeMessageRaw, 'UTF-8') > 240) {
        http_response_code(422);
        echo json_encode(['status' => 'error', 'message' => 'invalid_welcome_message']);
        exit;
    }

    $existingAppId  = isset($siteData['onesignal_app_id']) ? (string) $siteData['onesignal_app_id'] : '';
    $existingRest   = isset($siteData['onesignal_rest_api_key']) ? (string) $siteData['onesignal_rest_api_key'] : '';

    $futureAppId = $appIdRaw !== null ? $appIdRaw : $existingAppId;
    if ($appIdRaw !== null && $appIdRaw === '') {
        $futureAppId = '';
    }

    $futureRestKey = $existingRest;
    if ($restKeyClear) {
        $futureRestKey = '';
    } elseif ($restKeyValue !== null) {
        $futureRestKey = $restKeyValue;
    }

    if ($enabled === '1') {
        if ($futureAppId === '') {
            http_response_code(422);
            echo json_encode(['status' => 'error', 'message' => 'missing_app_id']);
            exit;
        }
        if ($futureRestKey === '') {
            http_response_code(422);
            echo json_encode(['status' => 'error', 'message' => 'missing_rest_key']);
            exit;
        }
    }

    $columnDefs = [
        'onesignal_enabled TINYINT(1) NOT NULL DEFAULT 0',
        'onesignal_app_id VARCHAR(64) NULL',
        'onesignal_rest_api_key VARCHAR(191) NULL',
        'onesignal_safari_web_id VARCHAR(191) NULL',
        'onesignal_auto_prompt TINYINT(1) NOT NULL DEFAULT 1',
        'onesignal_welcome_title VARCHAR(120) NULL',
        'onesignal_welcome_message VARCHAR(255) NULL'
    ];

    foreach ($columnDefs as $definition) {
        try {
            $db->exec('ALTER TABLE i_site_configurations ADD COLUMN ' . $definition);
        } catch (Throwable $e) {
            $msg = strtolower($e->getMessage());
            if (strpos($msg, 'duplicate') !== false || strpos($msg, 'exists') !== false) {
                continue;
            }
            throw $e;
        }
    }

    $updates = [
        'onesignal_enabled'    => $enabled,
        'onesignal_auto_prompt'=> $autoPrompt,
    ];

    if ($appIdRaw !== null) {
        $updates['onesignal_app_id'] = $appIdRaw !== '' ? $appIdRaw : null;
    }
    if ($safariRaw !== null) {
        $updates['onesignal_safari_web_id'] = $safariRaw !== '' ? $safariRaw : null;
    }
    if ($welcomeTitleRaw !== null) {
        $updates['onesignal_welcome_title'] = $welcomeTitleRaw !== '' ? $welcomeTitleRaw : null;
    }
    if ($welcomeMessageRaw !== null) {
        $updates['onesignal_welcome_message'] = $welcomeMessageRaw !== '' ? $welcomeMessageRaw : null;
    }

    if ($restKeyClear) {
        $updates['onesignal_rest_api_key'] = null;
    } elseif ($restKeyValue !== null) {
        $updates['onesignal_rest_api_key'] = $restKeyValue;
    }

    $set = [];
    foreach ($updates as $column => $value) {
        $set[] = "$column = :$column";
    }

    if ($set) {
        $sql = 'UPDATE i_site_configurations SET ' . implode(', ', $set) . ' WHERE id = :id';
        $stmt = $db->prepare($sql);
        foreach ($updates as $column => $value) {
            $param = ':' . $column;
            if ($value === null) {
                $stmt->bindValue($param, null, PDO::PARAM_NULL);
            } else {
                $stmt->bindValue($param, $value, PDO::PARAM_STR);
            }
        }
        $stmt->bindValue(':id', 1, PDO::PARAM_INT);
        $stmt->execute();
    }

    // Optional audit trail
    try {
        $db->exec('CREATE TABLE IF NOT EXISTS i_admin_audit (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            action VARCHAR(64) NOT NULL,
            target_key VARCHAR(64) NOT NULL,
            created_at INT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY idx_user_time (user_id, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    } catch (Throwable $__) {
    }

    try {
        $auditStmt = $db->prepare('INSERT INTO i_admin_audit (user_id, action, target_key, created_at) VALUES (:uid, :action, :target, :ts)');
        $uid = isset($userData['user_id']) ? (int) $userData['user_id'] : 0;
        $ts = time();
        foreach (array_keys($updates) as $column) {
            $auditStmt->execute([
                ':uid'    => $uid,
                ':action' => 'update_onesignal_settings',
                ':target' => $column,
                ':ts'     => $ts,
            ]);
        }
    } catch (Throwable $__) {
    }

    echo json_encode(['status' => 'success']);
    exit;
} catch (Throwable $e) {
    if (isset($db) && $db instanceof PDO && $db->inTransaction()) {
        $db->rollBack();
    }
    if (isset($RL) && is_object($RL) && method_exists($RL, 'logError')) {
        try {
            $RL->logError('onesignal_settings failed: ' . $e->getMessage());
        } catch (Throwable $__) {
        }
    }
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}
