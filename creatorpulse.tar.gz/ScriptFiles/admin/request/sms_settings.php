<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

global $db, $siteData, $userData;

$csrf = isset($_POST['csrf_token']) ? (string) $_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$normalizeToggle = static function ($value, bool $default = false): string {
    $raw = is_string($value) ? strtolower(trim($value)) : (is_numeric($value) ? (string) $value : '');
    if ($raw === '') {
        return $default ? '1' : '0';
    }
    return in_array($raw, ['1', 'true', 'on', 'yes', 'enabled'], true) ? '1' : '0';
};

try {
    $enabled = $normalizeToggle($_POST['sms_enabled'] ?? '', false);
    $sidRaw  = array_key_exists('sms_twilio_sid', $_POST) ? trim((string) $_POST['sms_twilio_sid']) : null;
    $tokenRaw = array_key_exists('sms_twilio_token', $_POST) ? trim((string) $_POST['sms_twilio_token']) : null;
    $tokenClear = ((string)($_POST['sms_twilio_token_clear'] ?? '0') === '1');
    $fromRaw = array_key_exists('sms_twilio_from', $_POST) ? trim((string) $_POST['sms_twilio_from']) : null;
    $rateRaw = array_key_exists('sms_rate_limit_per_hour', $_POST) ? (int) $_POST['sms_rate_limit_per_hour'] : null;

    if ($sidRaw !== null && $sidRaw !== '') {
        if (!preg_match('/^AC[a-zA-Z0-9]{30,40}$/', $sidRaw)) {
            http_response_code(422);
            echo json_encode(['status' => 'error', 'message' => 'invalid_twilio_sid']);
            exit;
        }
    }

    $tokenValue = null;
    if ($tokenRaw !== null && $tokenRaw !== '') {
        if (!preg_match('/^[A-Za-z0-9]{16,128}$/', $tokenRaw)) {
            http_response_code(422);
            echo json_encode(['status' => 'error', 'message' => 'invalid_twilio_token']);
            exit;
        }
        $tokenValue = $tokenRaw;
    }

    if ($fromRaw !== null && $fromRaw !== '') {
        if (!preg_match('/^\\+?[0-9]{8,20}$/', $fromRaw)) {
            http_response_code(422);
            echo json_encode(['status' => 'error', 'message' => 'invalid_twilio_from']);
            exit;
        }
    }

    $rateLimit = 30;
    if ($rateRaw !== null && $rateRaw > 0) {
        $rateLimit = min(max((int) $rateRaw, 1), 500);
    }

    $existingSid   = isset($siteData['sms_twilio_sid']) ? (string) $siteData['sms_twilio_sid'] : '';
    $existingToken = isset($siteData['sms_twilio_token']) ? (string) $siteData['sms_twilio_token'] : '';
    $existingFrom  = isset($siteData['sms_twilio_from']) ? (string) $siteData['sms_twilio_from'] : '';

    $futureSid = $sidRaw !== null ? $sidRaw : $existingSid;
    if ($sidRaw !== null && $sidRaw === '') {
        $futureSid = '';
    }

    $futureFrom = $fromRaw !== null ? $fromRaw : $existingFrom;
    if ($fromRaw !== null && $fromRaw === '') {
        $futureFrom = '';
    }

    $futureToken = $existingToken;
    if ($tokenClear) {
        $futureToken = '';
    } elseif ($tokenValue !== null) {
        $futureToken = $tokenValue;
    }

    if ($enabled === '1') {
        if ($futureSid === '' || $futureToken === '' || $futureFrom === '') {
            http_response_code(422);
            echo json_encode(['status' => 'error', 'message' => 'missing_credentials']);
            exit;
        }
    }

    $columnDefs = [
        'sms_enabled TINYINT(1) NOT NULL DEFAULT 0',
        'sms_provider VARCHAR(32) DEFAULT "twilio"',
        'sms_twilio_sid VARCHAR(64) DEFAULT NULL',
        'sms_twilio_token VARCHAR(128) DEFAULT NULL',
        'sms_twilio_from VARCHAR(32) DEFAULT NULL',
        'sms_rate_limit_per_hour INT UNSIGNED DEFAULT 30',
    ];
    foreach ($columnDefs as $definition) {
        try {
            $db->exec('ALTER TABLE i_site_configurations ADD COLUMN ' . $definition);
        } catch (Throwable $e) {
            $msg = strtolower($e->getMessage());
            if (strpos($msg, 'duplicate') !== false || strpos($msg, 'exists') !== false) {
                continue;
            }
            throw $e;
        }
    }

    $updates = [
        'sms_enabled' => $enabled,
        'sms_provider' => 'twilio',
        'sms_rate_limit_per_hour' => $rateLimit,
    ];
    if ($sidRaw !== null) {
        $updates['sms_twilio_sid'] = $sidRaw !== '' ? $sidRaw : null;
    }
    if ($fromRaw !== null) {
        $updates['sms_twilio_from'] = $fromRaw !== '' ? $fromRaw : null;
    }
    if ($tokenClear) {
        $updates['sms_twilio_token'] = null;
    } elseif ($tokenValue !== null) {
        $updates['sms_twilio_token'] = $tokenValue;
    }

    $set = [];
    foreach ($updates as $column => $value) {
        $set[] = "$column = :$column";
    }

    if ($set) {
        $sql = 'UPDATE i_site_configurations SET ' . implode(', ', $set) . ' WHERE id = :id';
        $stmt = $db->prepare($sql);
        foreach ($updates as $column => $value) {
            $param = ':' . $column;
            if ($value === null) {
                $stmt->bindValue($param, null, PDO::PARAM_NULL);
            } else {
                $stmt->bindValue($param, $value, PDO::PARAM_STR);
            }
        }
        $stmt->bindValue(':id', 1, PDO::PARAM_INT);
        $stmt->execute();
    }

    try {
        $db->exec('CREATE TABLE IF NOT EXISTS i_admin_audit (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            action VARCHAR(64) NOT NULL,
            target_key VARCHAR(64) NOT NULL,
            created_at INT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY idx_user_time (user_id, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    } catch (Throwable $__) {
    }

    try {
        $auditStmt = $db->prepare('INSERT INTO i_admin_audit (user_id, action, target_key, created_at) VALUES (:uid, :action, :target, :ts)');
        $uid = isset($userData['user_id']) ? (int) $userData['user_id'] : 0;
        $ts = time();
        foreach (array_keys($updates) as $column) {
            $auditStmt->execute([
                ':uid'    => $uid,
                ':action' => 'update_sms_settings',
                ':target' => $column,
                ':ts'     => $ts,
            ]);
        }
    } catch (Throwable $__) {
    }

    echo json_encode(['status' => 'success']);
    exit;
} catch (Throwable $e) {
    if (isset($db) && $db instanceof PDO && $db->inTransaction()) {
        $db->rollBack();
    }
    if (is_callable([$this ?? null, 'logError'])) {
        $this->logError('sms_settings failed: ' . $e->getMessage());
    }
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}
