<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $ADM, $ADMIN_CSRF, $base_url, $userData;

$redirectTarget = $base_url . 'admin/index.php?page=content_approvals';
$providedRedirect = isset($_POST['redirect']) ? (string)$_POST['redirect'] : '';
if ($providedRedirect !== '' && strpos($providedRedirect, $base_url . 'admin/') === 0) {
    $redirectTarget = $providedRedirect;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Location: ' . $redirectTarget . '&flash=error');
    exit;
}

$csrfToken = (string)($_POST['csrf_token'] ?? '');
if (!hash_equals((string)$ADMIN_CSRF, $csrfToken)) {
    header('Location: ' . $redirectTarget . '&flash=invalid_csrf');
    exit;
}

if (!admin_has_permission('content.approve')) {
    header('Location: ' . $redirectTarget . '&flash=forbidden');
    exit;
}

$postId = (int)($_POST['post_id'] ?? 0);
$actionRaw = strtolower((string)($_POST['submit_action'] ?? $_POST['action'] ?? ''));
$noteRaw = isset($_POST['note']) ? trim((string)$_POST['note']) : '';

$status = null;
if ($actionRaw === 'approve') {
    $status = 'approved';
} elseif ($actionRaw === 'reject') {
    $status = 'rejected';
}

if ($postId <= 0 || $status === null) {
    header('Location: ' . $redirectTarget . '&flash=error');
    exit;
}

$adminId = (int)($userData['user_id'] ?? 0);
$updated = $ADM->ADM_UpdatePostApprovalStatus($postId, $status, $adminId, $noteRaw);
$flashKey = $updated ? $status : 'error';

header('Location: ' . $redirectTarget . '&flash=' . rawurlencode($flashKey));
exit;
