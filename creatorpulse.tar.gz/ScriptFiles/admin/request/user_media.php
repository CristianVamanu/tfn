<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

$csrf = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) { http_response_code(403); echo json_encode(['status'=>'error','message'=>'invalid_csrf']); exit; }

$uid  = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
$type = isset($_POST['type']) ? (string)$_POST['type'] : '';
if ($uid <= 0 || !in_array($type, ['avatar','cover'], true)) { http_response_code(400); echo json_encode(['status'=>'error','message'=>'bad_request']); exit; }
if (!isset($_FILES[$type]) || !is_uploaded_file($_FILES[$type]['tmp_name'])) { http_response_code(400); echo json_encode(['status'=>'error','message'=>'no_file']); exit; }

// Validate image
$rel = $ADM->ADM_UpdateUserMedia($uid, $type, $_FILES[$type]);
if (!$rel) { http_response_code(400); echo json_encode(['status'=>'error','message'=>'upload_failed']); exit; }
$ADM->ADM_Audit((int)($userData['user_id'] ?? 0), 'user_media_' . $type, 'user:' . $uid);
echo json_encode(['status'=>'success','path'=>$rel]);
exit;
