<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $RL, $db, $userData;

header('Content-Type: application/json; charset=utf-8');

$csrf = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$action = isset($_POST['action']) ? strtolower((string)$_POST['action']) : '';
if ($action === '' && isset($_POST['bulk_action'])) {
    $action = strtolower((string)$_POST['bulk_action']);
}

$allowedActions = ['approve', 'reject'];
if (!in_array($action, $allowedActions, true)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'bad_action']);
    exit;
}

$note = trim((string)($_POST['note'] ?? ''));
if (strlen($note) > 2000) {
    $note = substr($note, 0, 2000);
}

$requestIds = [];
if (isset($_POST['request_id'])) {
    $requestIds[] = (int)$_POST['request_id'];
}
if (isset($_POST['request_ids']) && is_array($_POST['request_ids'])) {
    foreach ($_POST['request_ids'] as $rid) {
        $requestIds[] = (int)$rid;
    }
}
$requestIds = array_values(array_unique(array_filter($requestIds, static fn(int $id): bool => $id > 0)));

if (empty($requestIds)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'admin_verification_select_one']);
    exit;
}

if (!isset($RL) || !is_object($RL) || !method_exists($RL, 'RL_UpdateCreatorVerificationStatus')) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}

if (!admin_has_permission('verification.approve')) {
    admin_forbidden_json();
}

$adminId = (int)($userData['user_id'] ?? 0);
$targetStatus = $action === 'approve' ? 'approved' : 'rejected';

$updated = 0;
$failed = [];
$notified = 0;

foreach ($requestIds as $rid) {
    try {
        $stmt = $db->prepare('SELECT request_id, user_id FROM i_verification_requests WHERE request_id = :rid LIMIT 1');
        $stmt->bindValue(':rid', $rid, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        if (!$row) {
            $failed[] = $rid;
            continue;
        }
        $userId = (int)($row['user_id'] ?? 0);
        if ($userId <= 0) {
            $failed[] = $rid;
            continue;
        }

        $ok = $RL->RL_UpdateCreatorVerificationStatus($rid, $targetStatus, $adminId, $note);
        if (!$ok) {
            $failed[] = $rid;
            continue;
        }

        $updated++;
        if (method_exists($RL, 'RL_CreateCreatorStatusNotification')) {
            try {
                if ($RL->RL_CreateCreatorStatusNotification($userId, $adminId, $targetStatus, $note)) {
                    $notified++;
                }
            } catch (Throwable $notifyError) {
                if (method_exists($RL, 'logError')) {
                    $RL->logError('verification_notify_failed: ' . $notifyError->getMessage());
                }
            }
        }
    } catch (Throwable $exception) {
        if (method_exists($RL, 'logError')) {
            $RL->logError('verification_update_failed: ' . $exception->getMessage());
        }
        $failed[] = $rid;
    }
}

if ($updated === 0) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}

$isBulk = count($requestIds) > 1;
$messageKey = $isBulk ? 'admin_verification_success_bulk' : 'admin_verification_success_single';

echo json_encode([
    'status'    => 'success',
    'message'   => $messageKey,
    'updated'   => $updated,
    'failed'    => $failed,
    'notified'  => $notified,
]);
exit;
