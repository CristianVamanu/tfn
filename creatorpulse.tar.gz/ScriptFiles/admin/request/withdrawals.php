<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $ADM, $userData, $base_url, $currencys, $currencies;

header('Content-Type: application/json; charset=utf-8');

if (!isset($ADM) || !($ADM instanceof Admin_Data)) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}

$csrf = isset($_POST['csrf_token']) ? (string) $_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$action = isset($_POST['action']) ? strtolower(trim((string) $_POST['action'])) : '';
if ($action === '') {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'bad_action']);
    exit;
}

$adminId = (int) ($userData['user_id'] ?? 0);
if ($action === 'details' && !admin_has_permission('withdrawals.review')) {
    admin_forbidden_json();
}
if ($action === 'update_status' && !admin_has_permission('withdrawals.update')) {
    admin_forbidden_json();
}

$currencyMap = (isset($currencys) && is_array($currencys))
    ? $currencys
    : ((isset($currencies) && is_array($currencies)) ? $currencies : []);

$formatMoney = static function (float $amount, string $currency) use ($currencyMap): string {
    $symbol = isset($currencyMap[$currency]) ? (string) $currencyMap[$currency] : '';
    $formatted = number_format($amount, 2, '.', ',');
    if ($symbol === '') {
        return $formatted . ' ' . $currency;
    }
    if (mb_strlen($symbol) <= 3 && $symbol !== $currency) {
        $spacing = $symbol === '$' ? '' : ' ';
        return $symbol . $spacing . $formatted;
    }
    return $formatted . ' ' . $currency;
};

$statusClasses = [
    'pending'   => 'status-badge--pending',
    'processing'=> 'status-badge--pending',
    'review'    => 'status-badge--pending',
    'approved'  => 'status-badge--success',
    'completed' => 'status-badge--success',
    'paid'      => 'status-badge--success',
    'rejected'  => 'status-badge--danger',
    'failed'    => 'status-badge--danger',
    'canceled'  => 'status-badge--danger',
    'cancelled' => 'status-badge--danger',
];

$methodOptions = [
    'bank'     => customLang('settings_payout_bank_title', 'Bank transfer'),
    'paypal'   => 'PayPal',
    'stripe'   => customLang('settings_payout_stripe_title', 'Stripe Connect'),
    'payoneer' => customLang('settings_payout_payoneer_title', 'Payoneer'),
    'other'    => customLang('settings_payout_other_title', 'Other method'),
];

$methodIcons = [
    'bank'    => 'bank.svg',
    'paypal'  => 'payments.svg',
    'stripe'  => 'payments.svg',
    'payoneer'=> 'payments.svg',
    'other'   => 'payments.svg',
];

$summariseDetails = static function (array $details, string $method): array {
    $pairs = [];
    $map = [
        'account_name'   => customLang('creator_bank_account_name', 'Account holder name'),
        'bank_name'      => customLang('creator_bank_name', 'Bank name'),
        'iban'           => customLang('creator_bank_iban', 'IBAN'),
        'account_number' => customLang('creator_bank_account_number', 'Account number'),
        'swift'          => customLang('creator_bank_swift', 'SWIFT/BIC'),
        'email'          => customLang('email', 'Email'),
        'notes'          => customLang('creator_bank_notes', 'Notes'),
        'account_id'     => customLang('creator_stripe_account_id', 'Account ID'),
    ];
    foreach ($details as $key => $val) {
        if (!is_scalar($val) || $val === '') {
            continue;
        }
        $label = $map[$key] ?? ucfirst(str_replace('_', ' ', (string) $key));
        $pairs[] = [$label, (string) $val];
    }
    return $pairs;
};

$formatPayload = static function (array $row) use ($base_url, $formatMoney, $statusClasses, $methodOptions, $methodIcons, $summariseDetails): array {
    $payoutId = (int) ($row['payout_id'] ?? 0);
    $userId = (int) ($row['user_id'] ?? 0);
    $username = (string) ($row['username'] ?? '');
    $fullName = (string) ($row['user_fullname'] ?? $username);
    $email = (string) ($row['user_email'] ?? '');
    $amount = isset($row['amount']) ? (float) $row['amount'] : 0.0;
    $currency = isset($row['currency']) && $row['currency'] !== '' ? (string) $row['currency'] : 'USD';
    $method = isset($row['method']) ? strtolower((string) $row['method']) : '';
    $status = isset($row['status']) ? strtolower((string) $row['status']) : 'pending';
    $reference = isset($row['reference_display']) ? (string) $row['reference_display'] : (isset($row['reference']) ? (string) $row['reference'] : '');
    $requestedAt = isset($row['requested_at']) ? (int) $row['requested_at'] : 0;
    $processedAt = isset($row['processed_at']) && $row['processed_at'] !== null ? (int) $row['processed_at'] : null;
    $userNote = isset($row['notes']) ? (string) $row['notes'] : '';
    $adminNote = isset($row['admin_note']) ? (string) $row['admin_note'] : '';
    $statusLabel = customLang('withdrawal_status_' . $status, ucfirst($status));
    $statusClass = $statusClasses[$status] ?? 'status-badge--neutral';
    $methodLabel = $methodOptions[$method] ?? ucfirst($method ?: '-');
    $methodIcon = $methodIcons[$method] ?? 'payments.svg';
    $requestedLabel = $requestedAt > 0 ? date('Y-m-d H:i', $requestedAt) : '—';
    $processedLabel = ($processedAt !== null && $processedAt > 0) ? date('Y-m-d H:i', $processedAt) : '—';
    $profileUrl = ($base_url ?? '/') . 'profile/' . rawurlencode($username);
    $adminUrl = ($base_url ?? '/') . 'admin/index.php?page=user_detail&id=' . $userId;
    $destination = isset($row['destination']) && is_array($row['destination']) ? $row['destination'] : [];

    return [
        'payout_id'         => $payoutId,
        'user_id'           => $userId,
        'username'          => $username,
        'full_name'         => $fullName,
        'email'             => $email,
        'amount'            => $amount,
        'amount_label'      => $formatMoney($amount, $currency),
        'currency'          => $currency,
        'method'            => $method,
        'method_label'      => $methodLabel,
        'method_icon'       => $methodIcon,
        'status'            => $status,
        'status_label'      => $statusLabel,
        'status_class'      => $statusClass,
        'reference'         => isset($row['reference']) ? (string) $row['reference'] : '',
        'reference_display' => $reference,
        'requested_at'      => $requestedAt,
        'requested_label'   => $requestedLabel,
        'processed_at'      => $processedAt,
        'processed_label'   => $processedLabel,
        'user_note'         => $userNote,
        'admin_note'        => $adminNote,
        'profile_url'       => $profileUrl,
        'admin_url'         => $adminUrl,
        'destination_pairs' => $summariseDetails($destination, $method),
    ];
};

if ($action === 'details') {
    $payoutId = isset($_POST['payout_id']) ? (int) $_POST['payout_id'] : 0;
    if ($payoutId <= 0) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'bad_request']);
        exit;
    }

    $row = $ADM->ADM_GetWithdrawalDetails($payoutId);
    if (!$row) {
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'not_found']);
        exit;
    }

    echo json_encode([
        'status' => 'success',
        'data'   => $formatPayload($row),
    ]);
    exit;
}

if ($action === 'update_status') {
    $payoutId = isset($_POST['payout_id']) ? (int) $_POST['payout_id'] : 0;
    $status   = isset($_POST['status']) ? (string) $_POST['status'] : '';
    $note     = isset($_POST['note']) ? trim((string) $_POST['note']) : '';

    if ($payoutId <= 0 || $status === '') {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'bad_request']);
        exit;
    }

    if (function_exists('mb_substr')) {
        $note = mb_substr($note, 0, 1000, 'UTF-8');
    } else {
        $note = substr($note, 0, 1000);
    }

    $result = $ADM->ADM_UpdateWithdrawalStatus($adminId, $payoutId, $status, [
        'admin_note' => $note,
        'timestamp'  => time(),
    ]);

    if (empty($result['ok'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'server_error']);
        exit;
    }

    $row = $result['withdrawal'] ?? null;
    if (!$row) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }

    echo json_encode([
        'status' => 'success',
        'data'   => $formatPayload($row),
    ]);
    exit;
}

http_response_code(400);
echo json_encode(['status' => 'error', 'message' => 'bad_action']);
exit;
