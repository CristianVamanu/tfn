<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

global $siteData, $db, $userData, $ADM;

$csrf = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$liveStreamingEnabledRaw = array_key_exists('live_streaming_enabled', $_POST)
    ? trim((string)$_POST['live_streaming_enabled'])
    : (isset($siteData['live_streaming_enabled']) ? (string)$siteData['live_streaming_enabled'] : '1');
$liveChatEnabledRaw = array_key_exists('live_chat_enabled', $_POST)
    ? trim((string)$_POST['live_chat_enabled'])
    : (isset($siteData['live_chat_enabled']) ? (string)$siteData['live_chat_enabled'] : '1');
$agoraAppIdRaw = array_key_exists('agora_app_id', $_POST)
    ? trim((string)$_POST['agora_app_id'])
    : (isset($siteData['agora_app_id']) ? (string)$siteData['agora_app_id'] : '');
$agoraAppCertificateRaw = array_key_exists('agora_app_certificate', $_POST)
    ? trim((string)$_POST['agora_app_certificate'])
    : (isset($siteData['agora_app_certificate']) ? (string)$siteData['agora_app_certificate'] : '');
$agoraReadOnlyTokenRaw = array_key_exists('agora_readonly_token', $_POST)
    ? trim((string)$_POST['agora_readonly_token'])
    : (isset($siteData['agora_readonly_token']) ? (string)$siteData['agora_readonly_token'] : '');
$liveViewerLimitRaw = array_key_exists('live_viewer_limit', $_POST)
    ? trim((string)$_POST['live_viewer_limit'])
    : (isset($siteData['live_viewer_limit']) ? (string)$siteData['live_viewer_limit'] : '');
$liveTitlePrefixRaw = array_key_exists('live_title_prefix', $_POST)
    ? trim((string)$_POST['live_title_prefix'])
    : (isset($siteData['live_title_prefix']) ? (string)$siteData['live_title_prefix'] : '');
$audioRoomsEnabledRaw = array_key_exists('audio_rooms_enabled', $_POST)
    ? trim((string)$_POST['audio_rooms_enabled'])
    : (isset($siteData['audio_rooms_enabled']) ? (string)$siteData['audio_rooms_enabled'] : '1');
$audioRoomChatEnabledRaw = array_key_exists('audio_room_chat_enabled', $_POST)
    ? trim((string)$_POST['audio_room_chat_enabled'])
    : (isset($siteData['audio_room_chat_enabled']) ? (string)$siteData['audio_room_chat_enabled'] : '1');
$audioRoomPaidEnabledRaw = array_key_exists('audio_room_paid_enabled', $_POST)
    ? trim((string)$_POST['audio_room_paid_enabled'])
    : (isset($siteData['audio_room_paid_enabled']) ? (string)$siteData['audio_room_paid_enabled'] : '1');
$audioRoomCustomPriceEnabledRaw = array_key_exists('audio_room_custom_price_enabled', $_POST)
    ? trim((string)$_POST['audio_room_custom_price_enabled'])
    : (isset($siteData['audio_room_custom_price_enabled']) ? (string)$siteData['audio_room_custom_price_enabled'] : '1');
$audioRoomPricePresetsRaw = array_key_exists('audio_room_price_presets', $_POST)
    ? trim((string)$_POST['audio_room_price_presets'])
    : (isset($siteData['audio_room_price_presets']) ? (string)$siteData['audio_room_price_presets'] : '5,10,15,20');
$audioRoomPriceMinimumRaw = array_key_exists('audio_room_price_minimum', $_POST)
    ? trim((string)$_POST['audio_room_price_minimum'])
    : (isset($siteData['audio_room_price_minimum']) ? (string)$siteData['audio_room_price_minimum'] : '1.00');
$audioRoomPriceMaximumRaw = array_key_exists('audio_room_price_maximum', $_POST)
    ? trim((string)$_POST['audio_room_price_maximum'])
    : (isset($siteData['audio_room_price_maximum']) ? (string)$siteData['audio_room_price_maximum'] : '500.00');
$audioRoomNonCreatorDailyMinutesRaw = array_key_exists('audio_room_non_creator_daily_minutes', $_POST)
    ? trim((string)$_POST['audio_room_non_creator_daily_minutes'])
    : (isset($siteData['audio_room_non_creator_daily_minutes']) ? (string)$siteData['audio_room_non_creator_daily_minutes'] : '60');
$audioRoomMaxSpeakersRaw = array_key_exists('audio_room_max_speakers', $_POST)
    ? trim((string)$_POST['audio_room_max_speakers'])
    : (isset($siteData['audio_room_max_speakers']) ? (string)$siteData['audio_room_max_speakers'] : '12');
$audioRoomMaxListenersRaw = array_key_exists('audio_room_max_listeners', $_POST)
    ? trim((string)$_POST['audio_room_max_listeners'])
    : (isset($siteData['audio_room_max_listeners']) ? (string)$siteData['audio_room_max_listeners'] : '');
$audioRoomTitlePrefixRaw = array_key_exists('audio_room_title_prefix', $_POST)
    ? trim((string)$_POST['audio_room_title_prefix'])
    : (isset($siteData['audio_room_title_prefix']) ? (string)$siteData['audio_room_title_prefix'] : '');

$normalizeToggle = static function (string $raw, bool $default = false): string {
    if ($raw === '') {
        return $default ? '1' : '0';
    }
    $value = strtolower($raw);
    return in_array($value, ['1', 'true', 'yes', 'on', 'enabled'], true) ? '1' : '0';
};

$liveStreamingEnabled = $normalizeToggle($liveStreamingEnabledRaw, true);
$liveChatEnabled = $normalizeToggle($liveChatEnabledRaw, true);
$audioRoomsEnabled = $normalizeToggle($audioRoomsEnabledRaw, true);
$audioRoomChatEnabled = $normalizeToggle($audioRoomChatEnabledRaw, true);
$audioRoomPaidEnabled = $normalizeToggle($audioRoomPaidEnabledRaw, true);
$audioRoomCustomPriceEnabled = $normalizeToggle($audioRoomCustomPriceEnabledRaw, true);

$agoraAppId = null;
if ($agoraAppIdRaw !== '') {
    $appIdCanonical = preg_replace('/[^0-9A-Fa-f]/', '', $agoraAppIdRaw);
    if ($appIdCanonical === null || strlen($appIdCanonical) !== 32 || !preg_match('/^[0-9A-Fa-f]{32}$/', $appIdCanonical)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_agora_app_id']);
        exit;
    }
    $agoraAppId = $appIdCanonical;
}

$agoraAppCertificate = null;
if ($agoraAppCertificateRaw !== '') {
    $certCanonical = preg_replace('/[^0-9A-Fa-f]/', '', $agoraAppCertificateRaw);
    if ($certCanonical === null) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_agora_app_certificate']);
        exit;
    }
    if ($certCanonical !== '' && (strlen($certCanonical) !== 32 || !preg_match('/^[0-9A-Fa-f]{32}$/', $certCanonical))) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_agora_app_certificate']);
        exit;
    }
    if ($agoraAppId !== null && $certCanonical !== '' && strcasecmp($agoraAppId, $certCanonical) === 0) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_agora_app_certificate_match']);
        exit;
    }
    $agoraAppCertificate = $certCanonical !== '' ? $certCanonical : null;
}

if (($liveStreamingEnabled === '1' || $audioRoomsEnabled === '1') && $agoraAppId === null) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'missing_agora_app_id']);
    exit;
}

$agoraReadOnlyToken = null;
if ($agoraReadOnlyTokenRaw !== '') {
    if (mb_strlen($agoraReadOnlyTokenRaw, 'UTF-8') > 512) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_agora_readonly_token']);
        exit;
    }
    if (preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', $agoraReadOnlyTokenRaw)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_agora_readonly_token']);
        exit;
    }
    $agoraReadOnlyToken = $agoraReadOnlyTokenRaw;
}

$liveViewerLimit = null;
if ($liveViewerLimitRaw !== '') {
    if (!ctype_digit($liveViewerLimitRaw)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_live_viewer_limit']);
        exit;
    }
    $limitInt = (int)$liveViewerLimitRaw;
    if ($limitInt < 0) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_live_viewer_limit']);
        exit;
    }
    if ($limitInt > 500000) {
        $limitInt = 500000;
    }
    $liveViewerLimit = (string)$limitInt;
}

$liveTitlePrefix = null;
if ($liveTitlePrefixRaw !== '') {
    if (mb_strlen($liveTitlePrefixRaw, 'UTF-8') > 180) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_live_title_prefix']);
        exit;
    }
    $prefixClean = preg_replace('/\s+/u', ' ', $liveTitlePrefixRaw);
    if ($prefixClean === null) {
        $prefixClean = $liveTitlePrefixRaw;
    }
    $prefixClean = trim($prefixClean);
    if ($prefixClean !== '') {
        $liveTitlePrefix = $prefixClean;
    }
}

$audioRoomPresets = [];
foreach (preg_split('/[,;\s]+/', $audioRoomPricePresetsRaw) ?: [] as $presetRaw) {
    if ($presetRaw === '') { continue; }
    if (!is_numeric($presetRaw)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_audio_room_price_presets']);
        exit;
    }
    $preset = round((float)$presetRaw, 2);
    if ($preset <= 0 || $preset > 100000) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_audio_room_price_presets']);
        exit;
    }
    $audioRoomPresets[(string)number_format($preset, 2, '.', '')] = $preset;
}
if (!$audioRoomPresets) {
    $audioRoomPresets = ['5.00' => 5.0, '10.00' => 10.0, '15.00' => 15.0, '20.00' => 20.0];
}
$audioRoomPricePresets = implode(',', array_map(static function (float $amount): string {
    return rtrim(rtrim(number_format($amount, 2, '.', ''), '0'), '.');
}, array_values($audioRoomPresets)));

if (!is_numeric($audioRoomPriceMinimumRaw) || !is_numeric($audioRoomPriceMaximumRaw)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_audio_room_price_range']);
    exit;
}
$audioRoomPriceMinimum = round((float)$audioRoomPriceMinimumRaw, 2);
$audioRoomPriceMaximum = round((float)$audioRoomPriceMaximumRaw, 2);
if ($audioRoomPriceMinimum < 0 || $audioRoomPriceMaximum < $audioRoomPriceMinimum || $audioRoomPriceMaximum > 100000) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_audio_room_price_range']);
    exit;
}

if ($audioRoomNonCreatorDailyMinutesRaw === '' || !ctype_digit($audioRoomNonCreatorDailyMinutesRaw)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_audio_room_daily_limit']);
    exit;
}
$audioRoomNonCreatorDailyMinutes = min(1440, max(0, (int)$audioRoomNonCreatorDailyMinutesRaw));

if ($audioRoomMaxSpeakersRaw === '' || !ctype_digit($audioRoomMaxSpeakersRaw)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_audio_room_max_speakers']);
    exit;
}
$audioRoomMaxSpeakers = min(100, max(1, (int)$audioRoomMaxSpeakersRaw));

$audioRoomMaxListeners = null;
if ($audioRoomMaxListenersRaw !== '') {
    if (!ctype_digit($audioRoomMaxListenersRaw)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_audio_room_max_listeners']);
        exit;
    }
    $audioRoomMaxListenersInt = (int)$audioRoomMaxListenersRaw;
    $audioRoomMaxListeners = $audioRoomMaxListenersInt > 0 ? min(500000, $audioRoomMaxListenersInt) : null;
}

$audioRoomTitlePrefix = null;
if ($audioRoomTitlePrefixRaw !== '') {
    if (mb_strlen($audioRoomTitlePrefixRaw, 'UTF-8') > 180) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_audio_room_title_prefix']);
        exit;
    }
    $audioPrefixClean = preg_replace('/\s+/u', ' ', $audioRoomTitlePrefixRaw);
    if ($audioPrefixClean === null) { $audioPrefixClean = $audioRoomTitlePrefixRaw; }
    $audioPrefixClean = trim($audioPrefixClean);
    if ($audioPrefixClean !== '') { $audioRoomTitlePrefix = $audioPrefixClean; }
}

$set = [
    'live_streaming_enabled' => $liveStreamingEnabled,
    'live_chat_enabled'      => $liveChatEnabled,
    'agora_app_id'           => $agoraAppId,
    'agora_app_certificate'  => $agoraAppCertificate,
    'agora_readonly_token'   => $agoraReadOnlyToken,
    'live_viewer_limit'      => $liveViewerLimit,
    'live_title_prefix'      => $liveTitlePrefix,
    'audio_rooms_enabled' => $audioRoomsEnabled,
    'audio_room_chat_enabled' => $audioRoomChatEnabled,
    'audio_room_paid_enabled' => $audioRoomPaidEnabled,
    'audio_room_custom_price_enabled' => $audioRoomCustomPriceEnabled,
    'audio_room_price_presets' => $audioRoomPricePresets,
    'audio_room_price_minimum' => number_format($audioRoomPriceMinimum, 2, '.', ''),
    'audio_room_price_maximum' => number_format($audioRoomPriceMaximum, 2, '.', ''),
    'audio_room_non_creator_daily_minutes' => $audioRoomNonCreatorDailyMinutes,
    'audio_room_max_speakers' => $audioRoomMaxSpeakers,
    'audio_room_max_listeners' => $audioRoomMaxListeners,
    'audio_room_title_prefix' => $audioRoomTitlePrefix,
];

try {
    $columnDefs = [
        'live_streaming_enabled TINYINT(1) NOT NULL DEFAULT 1',
        'live_chat_enabled TINYINT(1) NOT NULL DEFAULT 1',
        'agora_readonly_token VARCHAR(512) NULL',
        'live_viewer_limit INT NULL',
        'live_title_prefix VARCHAR(180) NULL',
        'audio_rooms_enabled TINYINT(1) NOT NULL DEFAULT 1',
        'audio_room_chat_enabled TINYINT(1) NOT NULL DEFAULT 1',
        'audio_room_paid_enabled TINYINT(1) NOT NULL DEFAULT 1',
        'audio_room_custom_price_enabled TINYINT(1) NOT NULL DEFAULT 1',
        'audio_room_price_presets VARCHAR(191) NOT NULL DEFAULT \'5,10,15,20\'',
        'audio_room_price_minimum DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT \'1.00\'',
        'audio_room_price_maximum DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT \'500.00\'',
        'audio_room_non_creator_daily_minutes INT UNSIGNED NOT NULL DEFAULT 60',
        'audio_room_max_speakers INT UNSIGNED NOT NULL DEFAULT 12',
        'audio_room_max_listeners INT UNSIGNED NULL',
        'audio_room_title_prefix VARCHAR(180) NULL',
    ];

    foreach ($columnDefs as $definition) {
        try {
            $db->exec('ALTER TABLE i_site_configurations ADD COLUMN ' . $definition);
        } catch (Throwable $e) {
            $msg = strtolower($e->getMessage());
            if (strpos($msg, 'duplicate') !== false || strpos($msg, 'exists') !== false) {
                continue;
            }
            throw $e;
        }
    }

    $parts = [];
    $params = [];
    foreach ($set as $k => $v) {
        $parts[] = "$k = :$k";
        $params[':' . $k] = $v;
    }
    $params[':id'] = 1;

    $sql = 'UPDATE i_site_configurations SET ' . implode(', ', $parts) . ' WHERE id = :id';
    $st = $db->prepare($sql);
    $st->execute($params);

    if (isset($ADM) && $ADM instanceof Admin_Data) {
        $summary = 'live:' . ($liveStreamingEnabled === '1' ? 'enabled' : 'disabled');
        if ($liveChatEnabled === '0') {
            $summary .= '|chat=off';
        }
        $summary .= '|audio:' . ($audioRoomsEnabled === '1' ? 'enabled' : 'disabled');
        $ADM->ADM_Audit((int)($userData['user_id'] ?? 0), 'update_live_settings', substr($summary, 0, 60), time());
    }

    echo json_encode(['status' => 'success']);
    exit;
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}
