<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

global $siteData, $db;

$status = strtolower((string)($siteData['maintenance'] ?? 'off')) === 'on' ? 'on' : 'off';

$etaTs = null;
if (isset($siteData['maintenance_eta']) && is_numeric($siteData['maintenance_eta'])) {
    $candidate = (int)$siteData['maintenance_eta'];
    if ($candidate > 0) {
        $etaTs = $candidate;
    }
}

$message = trim((string)($siteData['maintenance_message'] ?? ''));

$updatedAt = null;
if (isset($siteData['maintenance_updated_at']) && is_numeric($siteData['maintenance_updated_at'])) {
    $candidate = (int)$siteData['maintenance_updated_at'];
    if ($candidate > 0) {
        $updatedAt = $candidate;
    }
}

$updatedBy = isset($siteData['maintenance_updated_by']) ? (int)$siteData['maintenance_updated_by'] : 0;
$updatedByName = '';
if ($updatedBy > 0 && isset($db) && $db instanceof PDO) {
    try {
        $stmt = $db->prepare('SELECT user_fullname, username FROM i_users WHERE user_id = :uid LIMIT 1');
        $stmt->execute([':uid' => $updatedBy]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $updatedByName = (string)($row['user_fullname'] ?: $row['username'] ?: '');
        }
    } catch (Throwable $__) {
        $updatedByName = '';
    }
}

$canon = static function ($value): ?string {
    $value = trim((string)$value);
    return $value === '' ? null : $value;
};

$links = [
    'maintenance_status_url'   => $canon($siteData['maintenance_status_url'] ?? ($siteData['status_page_url'] ?? '')),
    'maintenance_support_url'  => $canon($siteData['maintenance_support_url'] ?? ($siteData['support_url'] ?? '')),
    'maintenance_twitter_url'  => $canon($siteData['maintenance_twitter_url'] ?? ($siteData['twitter_url'] ?? '')),
    'maintenance_facebook_url' => $canon($siteData['maintenance_facebook_url'] ?? ($siteData['facebook_url'] ?? '')),
    'maintenance_instagram_url'=> $canon($siteData['maintenance_instagram_url'] ?? ($siteData['instagram_url'] ?? '')),
    'maintenance_tiktok_url'   => $canon($siteData['maintenance_tiktok_url'] ?? ($siteData['tiktok_url'] ?? '')),
];
$links = array_filter($links, static fn($v) => $v !== null);

$response = [
    'status'             => 'ok',
    'maintenance'        => $status,
    'eta'                => $etaTs,
    'eta_iso'            => $etaTs ? gmdate('c', $etaTs) : null,
    'eta_input'          => $etaTs ? gmdate('Y-m-d\TH:i', $etaTs) : null,
    'eta_status'         => $etaTs ? ($etaTs > time() ? 'future' : 'elapsed') : 'unset',
    'message'            => $message,
    'updated_at'         => $updatedAt,
    'updated_at_iso'     => $updatedAt ? gmdate('c', $updatedAt) : null,
    'updated_by'         => $updatedBy > 0 ? $updatedBy : null,
    'updated_by_name'    => $updatedByName,
    'links'              => $links,
    'last_updated_label'   => (function () use ($updatedAt, $updatedByName) {
        if (!$updatedAt) {
            return '';
        }
        $timeLabel = gmdate('M j, Y H:i', $updatedAt) . ' UTC';
        if ($updatedByName !== '') {
            return sprintf(customLang('admin_maintenance_last_updated_by') ?: 'Last updated %s by %s.', $timeLabel, $updatedByName);
        }
        return sprintf(customLang('admin_maintenance_last_updated_unknown') ?: 'Last updated %s.', $timeLabel);
    })(),
];

echo json_encode($response, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
