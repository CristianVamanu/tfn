<?php

declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

$csrf = isset($_POST['csrf_token']) ? (string) $_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$action = isset($_POST['action']) ? (string) $_POST['action'] : 'create';
$allowedActions = ['create', 'update', 'delete', 'status'];
if (!in_array($action, $allowedActions, true)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'admin_announcements_invalid_action']);
    exit;
}

$now = time();

$parseDate = static function (string $value, string $errorKey): ?int {
    if ($value === '') {
        return null;
    }
    $formats = ['Y-m-d\TH:i', 'Y-m-d\TH:i:s'];
    foreach ($formats as $format) {
        $dt = DateTimeImmutable::createFromFormat($format, $value, new DateTimeZone('UTC'));
        if ($dt instanceof DateTimeImmutable) {
            return $dt->getTimestamp();
        }
    }
    throw new InvalidArgumentException($errorKey);
};

$handleImageUpload = static function (array $file): string {
    if (!isset($file['error']) || (int)$file['error'] === UPLOAD_ERR_NO_FILE) {
        return '';
    }
    if ((int)$file['error'] !== UPLOAD_ERR_OK) {
        throw new InvalidArgumentException('admin_announcements_image_upload_failed');
    }
    $maxBytes = 5 * 1024 * 1024;
    if (($file['size'] ?? 0) > $maxBytes) {
        throw new InvalidArgumentException('admin_announcements_image_too_large');
    }
    $info = @getimagesize($file['tmp_name']);
    if ($info === false) {
        throw new InvalidArgumentException('admin_announcements_image_invalid');
    }
    $allowedTypes = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
    $type = (int)($info[2] ?? 0);
    if (!isset($allowedTypes[$type])) {
        throw new InvalidArgumentException('admin_announcements_image_type');
    }
    $ext = $allowedTypes[$type];
    $subDir = '/uploads/announcements/' . date('Y/m');
    $targetDir = dirname(__DIR__, 2) . $subDir;
    if (!is_dir($targetDir) && !mkdir($targetDir, 0775, true) && !is_dir($targetDir)) {
        throw new InvalidArgumentException('admin_announcements_image_write');
    }
    $fileName = uniqid('announcement_', true) . '.' . $ext;
    $targetPath = $targetDir . '/' . $fileName;
    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        throw new InvalidArgumentException('admin_announcements_image_upload_failed');
    }
    return ltrim($subDir . '/' . $fileName, '/');
};

$deleteImageFile = static function (?string $path): void {
    if (!$path) { return; }
    $path = trim($path);
    if ($path === '') { return; }
    $full = dirname(__DIR__, 2) . '/' . ltrim($path, '/');
    $real = @realpath($full);
    $uploadsRoot = realpath(dirname(__DIR__, 2) . '/uploads');
    if ($real && $uploadsRoot && str_starts_with($real, $uploadsRoot)) {
        @unlink($real);
    }
};

try {
    if ($action === 'delete') {
        $id = isset($_POST['announcement_id']) ? (int) $_POST['announcement_id'] : 0;
        if ($id <= 0) {
            throw new InvalidArgumentException('admin_announcements_not_found');
        }
        $existing = $db->prepare('SELECT image_path FROM i_announcements WHERE id = :id LIMIT 1');
        $existing->bindValue(':id', $id, PDO::PARAM_INT);
        $existing->execute();
        $row = $existing->fetch(PDO::FETCH_ASSOC) ?: null;

        $stmt = $db->prepare('DELETE FROM i_announcements WHERE id = :id LIMIT 1');
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        if ($stmt->rowCount() === 0) {
            throw new InvalidArgumentException('admin_announcements_not_found');
        }
        if ($row && !empty($row['image_path'])) {
            $deleteImageFile((string)$row['image_path']);
        }
        echo json_encode(['status' => 'success', 'message' => 'admin_announcements_deleted']);
        exit;
    }

    if ($action === 'status') {
        $id = isset($_POST['announcement_id']) ? (int) $_POST['announcement_id'] : 0;
        $status = isset($_POST['status']) ? strtolower(trim((string) $_POST['status'])) : '';
        if ($id <= 0) {
            throw new InvalidArgumentException('admin_announcements_not_found');
        }
        if (!in_array($status, ['active', 'inactive'], true)) {
            throw new InvalidArgumentException('admin_announcements_invalid_status');
        }
        $check = $db->prepare('SELECT id FROM i_announcements WHERE id = :id LIMIT 1');
        $check->bindValue(':id', $id, PDO::PARAM_INT);
        $check->execute();
        if ($check->fetchColumn() === false) {
            throw new InvalidArgumentException('admin_announcements_not_found');
        }
        $stmt = $db->prepare('UPDATE i_announcements SET status = :status, updated_at = :updated WHERE id = :id LIMIT 1');
        $stmt->bindValue(':status', $status, PDO::PARAM_STR);
        $stmt->bindValue(':updated', $now, PDO::PARAM_INT);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        echo json_encode(['status' => 'success', 'message' => 'admin_announcements_status_updated']);
        exit;
    }

    $title = isset($_POST['title']) ? trim((string) $_POST['title']) : '';
    if ($title !== '' && mb_strlen($title) > 160) {
        throw new InvalidArgumentException('admin_announcements_invalid_title');
    }

$rawMessage = isset($_POST['message']) ? (string) $_POST['message'] : '';
$rawMessage = trim($rawMessage);
if ($rawMessage === '') {
    throw new InvalidArgumentException('admin_announcements_invalid_message');
}
$cleanMessage = sanitizeAnnouncementContent($rawMessage);
$cleanMessage = trim($cleanMessage);
$plainMessage = trim(strip_tags(html_entity_decode(str_replace('&nbsp;', ' ', $cleanMessage), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
if ($plainMessage === '' || mb_strlen($plainMessage) > 4000) {
    throw new InvalidArgumentException('admin_announcements_invalid_message');
}
$message = $cleanMessage;

    $ctaLabel = isset($_POST['cta_label']) ? trim((string) $_POST['cta_label']) : '';
    if ($ctaLabel !== '' && mb_strlen($ctaLabel) > 120) {
        throw new InvalidArgumentException('admin_announcements_invalid_cta_label');
    }

    $ctaUrl = isset($_POST['cta_url']) ? trim((string) $_POST['cta_url']) : '';
    if ($ctaUrl !== '' && filter_var($ctaUrl, FILTER_VALIDATE_URL) === false) {
        throw new InvalidArgumentException('admin_announcements_invalid_cta_url');
    }

    $status = isset($_POST['status']) ? strtolower(trim((string) $_POST['status'])) : 'inactive';
    if (!in_array($status, ['active', 'inactive'], true)) {
        throw new InvalidArgumentException('admin_announcements_invalid_status');
    }

    $allowClose = isset($_POST['allow_close']) ? 1 : 0;

    $startRaw = isset($_POST['start_at']) ? trim((string) $_POST['start_at']) : '';
    $endRaw   = isset($_POST['end_at']) ? trim((string) $_POST['end_at']) : '';

    try {
        $startAt = $parseDate($startRaw, 'admin_announcements_invalid_start');
        $endAt   = $parseDate($endRaw, 'admin_announcements_invalid_end');
    } catch (InvalidArgumentException $e) {
        throw $e;
    }

    if ($startAt !== null && $endAt !== null && $startAt > $endAt) {
        throw new InvalidArgumentException('admin_announcements_invalid_range');
    }

    $imagePath = null;
    $removeImage = isset($_POST['image_remove']) ? (int)$_POST['image_remove'] === 1 : false;

    if ($action === 'update') {
        $id = isset($_POST['announcement_id']) ? (int) $_POST['announcement_id'] : 0;
        if ($id <= 0) {
            throw new InvalidArgumentException('admin_announcements_not_found');
        }
        $existing = $db->prepare('SELECT image_path FROM i_announcements WHERE id = :id LIMIT 1');
        $existing->bindValue(':id', $id, PDO::PARAM_INT);
        $existing->execute();
        $existingRow = $existing->fetch(PDO::FETCH_ASSOC) ?: null;
        $currentImage = (string)($existingRow['image_path'] ?? '');

        if (isset($_FILES['image']) && (int)$_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
            $imagePath = $handleImageUpload($_FILES['image']);
            if ($imagePath !== '' && $currentImage !== '') {
                $deleteImageFile($currentImage);
            }
        } elseif ($removeImage && $currentImage !== '') {
            $deleteImageFile($currentImage);
            $currentImage = '';
        }

        $stmt = $db->prepare('UPDATE i_announcements SET message = :message, status = :status, start_at = :start_at, end_at = :end_at, allow_close = :allow_close, updated_at = :updated_at, title = :title, cta_label = :cta_label, cta_url = :cta_url, image_path = :image_path WHERE id = :id LIMIT 1');
        $stmt->bindValue(':message', $message, PDO::PARAM_STR);
        $stmt->bindValue(':status', $status, PDO::PARAM_STR);
        if ($startAt === null) {
            $stmt->bindValue(':start_at', null, PDO::PARAM_NULL);
        } else {
            $stmt->bindValue(':start_at', $startAt, PDO::PARAM_INT);
        }
        if ($endAt === null) {
            $stmt->bindValue(':end_at', null, PDO::PARAM_NULL);
        } else {
            $stmt->bindValue(':end_at', $endAt, PDO::PARAM_INT);
        }
        $stmt->bindValue(':allow_close', $allowClose, PDO::PARAM_INT);
        $stmt->bindValue(':updated_at', $now, PDO::PARAM_INT);
        $stmt->bindValue(':title', $title === '' ? null : $title, $title === '' ? PDO::PARAM_NULL : PDO::PARAM_STR);
        $stmt->bindValue(':cta_label', $ctaLabel === '' ? null : $ctaLabel, $ctaLabel === '' ? PDO::PARAM_NULL : PDO::PARAM_STR);
        $stmt->bindValue(':cta_url', $ctaUrl === '' ? null : $ctaUrl, $ctaUrl === '' ? PDO::PARAM_NULL : PDO::PARAM_STR);
        $finalImage = $imagePath !== null ? $imagePath : $currentImage;
        $stmt->bindValue(':image_path', $finalImage === '' ? null : $finalImage, $finalImage === '' ? PDO::PARAM_NULL : PDO::PARAM_STR);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        echo json_encode(['status' => 'success', 'message' => 'admin_announcements_saved', 'id' => $id]);
        exit;
    }

    if (isset($_FILES['image'])) {
        $imagePath = $handleImageUpload($_FILES['image']);
    }

    $stmt = $db->prepare('INSERT INTO i_announcements (message, status, start_at, end_at, allow_close, title, cta_label, cta_url, image_path, created_at, updated_at) VALUES (:message, :status, :start_at, :end_at, :allow_close, :title, :cta_label, :cta_url, :image_path, :created_at, :updated_at)');
    $stmt->bindValue(':message', $message, PDO::PARAM_STR);
    $stmt->bindValue(':status', $status, PDO::PARAM_STR);
    if ($startAt === null) {
        $stmt->bindValue(':start_at', null, PDO::PARAM_NULL);
    } else {
        $stmt->bindValue(':start_at', $startAt, PDO::PARAM_INT);
    }
    if ($endAt === null) {
        $stmt->bindValue(':end_at', null, PDO::PARAM_NULL);
    } else {
        $stmt->bindValue(':end_at', $endAt, PDO::PARAM_INT);
    }
    $stmt->bindValue(':allow_close', $allowClose, PDO::PARAM_INT);
    $stmt->bindValue(':title', $title === '' ? null : $title, $title === '' ? PDO::PARAM_NULL : PDO::PARAM_STR);
    $stmt->bindValue(':cta_label', $ctaLabel === '' ? null : $ctaLabel, $ctaLabel === '' ? PDO::PARAM_NULL : PDO::PARAM_STR);
    $stmt->bindValue(':cta_url', $ctaUrl === '' ? null : $ctaUrl, $ctaUrl === '' ? PDO::PARAM_NULL : PDO::PARAM_STR);
    $stmt->bindValue(':image_path', ($imagePath ?? '') === '' ? null : $imagePath, (($imagePath ?? '') === '') ? PDO::PARAM_NULL : PDO::PARAM_STR);
    $stmt->bindValue(':created_at', $now, PDO::PARAM_INT);
    $stmt->bindValue(':updated_at', $now, PDO::PARAM_INT);
    $stmt->execute();
    $id = (int) $db->lastInsertId();
    echo json_encode(['status' => 'success', 'message' => 'admin_announcements_saved', 'id' => $id]);
    exit;
} catch (InvalidArgumentException $e) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    exit;
} catch (Throwable $e) {
    if (defined('APP_DEBUG') && APP_DEBUG === true) {
        error_log('Announcements request failed: ' . $e->getMessage());
    }
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}
