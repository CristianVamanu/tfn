<?php

declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

global $db, $siteData, $userData;

$respond = static function (int $status, array $payload): void {
    http_response_code($status);
    echo json_encode($payload);
    exit;
};

$csrf = isset($_POST['csrf_token']) ? (string) $_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    $respond(403, ['status' => 'error', 'message' => 'invalid_csrf']);
}

$provider = isset($_POST['provider']) ? strtolower(trim((string) $_POST['provider'])) : '';
$validProviders = ['local', 's3', 'do_spaces', 'wasabi', 'backblaze'];
if (!in_array($provider, $validProviders, true)) {
    $respond(400, ['status' => 'error', 'message' => 'invalid_provider']);
}

$action = isset($_POST['action']) ? strtolower(trim((string) $_POST['action'])) : 'save';
if (!in_array($action, ['save', 'test'], true)) {
    $respond(400, ['status' => 'error', 'message' => 'bad_action']);
}

$rawConfig = isset($siteData['storage_settings']) ? $siteData['storage_settings'] : null;
$storageConfig = [];
if (is_string($rawConfig) && $rawConfig !== '') {
    $decoded = json_decode($rawConfig, true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
        $storageConfig = $decoded;
    }
}
if (!is_array($storageConfig)) {
    $storageConfig = [];
}
if (!isset($storageConfig['providers']) || !is_array($storageConfig['providers'])) {
    $storageConfig['providers'] = [];
}
$existingProviderConfig = $storageConfig['providers'][$provider] ?? [];
if (!is_array($existingProviderConfig)) {
    $existingProviderConfig = [];
}

$getFlag = static function ($value, bool $default = false): bool {
    if ($value === null) {
        return $default;
    }
    $normalized = strtolower(trim((string) $value));
    if ($normalized === '') {
        return $default;
    }
    if (in_array($normalized, ['0', 'false', 'off', 'no', 'closed', 'close'], true)) {
        return false;
    }
    if (in_array($normalized, ['1', 'true', 'yes', 'on', 'enabled', 'open'], true)) {
        return true;
    }
    return $default;
};

$normalizeVisibility = static function ($value, string $fallback = 'public'): string {
    $candidate = strtolower(trim((string) $value));
    if ($candidate === 'public' || $candidate === 'private') {
        return $candidate;
    }
    return $fallback === 'private' ? 'private' : 'public';
};

$filterSecret = static function (string $value, int $maxLength = 255): string {
    $trimmed = trim($value);
    if ($trimmed === '') {
        return '';
    }
    if ($maxLength > 0 && strlen($trimmed) > $maxLength) {
        throw new InvalidArgumentException('invalid_length');
    }
    if (!preg_match('/^[\x21-\x7E]+$/', $trimmed)) {
        throw new InvalidArgumentException('invalid_chars');
    }

    return $trimmed;
};

$sanitizeUrl = static function ($value) {
    $value = trim((string) $value);
    if ($value === '') {
        return '';
    }
    if (!filter_var($value, FILTER_VALIDATE_URL)) {
        throw new InvalidArgumentException('invalid_url');
    }
    return rtrim($value, '/') . '/';
};

$sanitizeBucket = static function ($value, ?string $existing = null): string {
    $value = trim((string) $value);
    if ($value === '') {
        $value = (string) ($existing ?? '');
    }
    if ($value === '') {
        throw new InvalidArgumentException('invalid_bucket');
    }
    if (!preg_match('/^[a-z0-9][a-z0-9.-]{1,62}[a-z0-9]$/', $value)) {
        throw new InvalidArgumentException('invalid_bucket');
    }
    return $value;
};

$sanitizeRegion = static function ($value, ?string $existing = null): string {
    $value = trim((string) $value);
    if ($value === '') {
        $value = (string) ($existing ?? '');
    }
    if ($value === '') {
        throw new InvalidArgumentException('invalid_region');
    }
    if (!preg_match('/^[a-z0-9-]{3,32}$/', $value)) {
        throw new InvalidArgumentException('invalid_region');
    }
    return $value;
};

$sanitizePrefix = static function ($value, ?string $existing = null): string {
    $value = trim((string) $value);
    if ($value === '') {
        $value = (string) ($existing ?? '');
    }
    $value = str_replace('\\', '/', $value);
    $value = trim($value, '/');
    if ($value === '') {
        return '';
    }
    if (!preg_match('/^[A-Za-z0-9._\/-]{1,255}$/', $value)) {
        throw new InvalidArgumentException('invalid_prefix');
    }
    return $value;
};

$sanitizeIntRange = static function ($value, int $min, int $max, int $fallback, ?int $existing = null): int {
    $value = trim((string) $value);
    if ($value === '') {
        return $existing !== null ? $existing : $fallback;
    }
    if (!ctype_digit($value)) {
        throw new InvalidArgumentException('invalid_number');
    }
    $number = (int) $value;
    if ($number < $min || $number > $max) {
        throw new InvalidArgumentException('invalid_number');
    }
    return $number;
};

$resolveSecretField = static function (
    string $field,
    array $source,
    array $existing,
    callable $filter,
    bool $required = true,
    int $maxLength = 255
): string {
    $clearField = $field . '_clear';
    if (isset($source[$clearField]) && $source[$clearField] !== '') {
        $clear = strtolower(trim((string) $source[$clearField]));
        if (in_array($clear, ['1', 'true', 'yes', 'on'], true)) {
            return '';
        }
    }

    if (isset($source[$field])) {
        $candidate = trim((string) $source[$field]);
        if ($candidate !== '') {
            return $filter($candidate, $maxLength);
        }
    }

    if (isset($existing[$field]) && $existing[$field] !== '') {
        return (string) $existing[$field];
    }

    if ($required) {
        throw new InvalidArgumentException('missing_required');
    }

    return '';
};

$providerConfig = [];
$enabled = $getFlag($_POST['enable_provider'] ?? ($existingProviderConfig['enabled'] ?? null), $provider === 'local');
$makeDefault = $getFlag($_POST['set_default'] ?? '');

try {
    if ($provider === 'local') {
        $defaultVisibility = $normalizeVisibility($_POST['default_visibility'] ?? ($existingProviderConfig['default_visibility'] ?? 'public'));
        $publicBase = '';
        try {
            $publicBase = $sanitizeUrl($_POST['public_base_url'] ?? ($existingProviderConfig['public_base_url'] ?? ''));
        } catch (InvalidArgumentException $e) {
            if ($e->getMessage() === 'invalid_url') {
                throw new InvalidArgumentException('invalid_public_base_url');
            }
            throw $e;
        }

        $root = isset($_POST['root_path']) ? trim((string) $_POST['root_path']) : '';
        if ($root === '' && isset($existingProviderConfig['root_path'])) {
            $root = (string) $existingProviderConfig['root_path'];
        }
        if ($root === '') {
            $uploadRoot = isset($GLOBALS['uploadFile']) ? dirname((string) $GLOBALS['uploadFile']) : null;
            if ($uploadRoot && $uploadRoot !== '.') {
                $root = $uploadRoot;
            }
        }
        if ($root === '') {
            $root = dirname(__DIR__, 2) . '/uploads';
        }

        $providerConfig = [
            'enabled' => $enabled,
            'root_path' => $root,
            'public_base_url' => $publicBase,
            'default_visibility' => $defaultVisibility,
        ];
    } elseif (in_array($provider, ['s3', 'do_spaces', 'wasabi', 'backblaze'], true)) {
        $existing = $existingProviderConfig;
        $existingDecrypted = $existingProviderConfig;
        foreach (['access_key', 'secret_key', 'session_token'] as $secretField) {
            if (isset($existingDecrypted[$secretField]) && is_string($existingDecrypted[$secretField]) && $existingDecrypted[$secretField] !== '') {
                $existingDecrypted[$secretField] = storage_decrypt_secret($existingDecrypted[$secretField]);
            }
        }

        $accessKey = $resolveSecretField('access_key', $_POST, $existingDecrypted, $filterSecret, true, 191);
        $secretKey = $resolveSecretField('secret_key', $_POST, $existingDecrypted, $filterSecret, true, 191);
        $sessionToken = $resolveSecretField('session_token', $_POST, $existingDecrypted, $filterSecret, false, 255);

        $encIfNeeded = static function (string $raw, string $existingEnc, string $existingRaw): string {
            if ($raw === '') {
                return '';
            }
            if ($existingEnc !== '' && $raw === $existingRaw) {
                return $existingEnc;
            }
            return storage_encrypt_secret($raw);
        };

        $accessKeyStored = $encIfNeeded($accessKey, (string)($existing['access_key'] ?? ''), (string)($existingDecrypted['access_key'] ?? ''));
        $secretKeyStored = $encIfNeeded($secretKey, (string)($existing['secret_key'] ?? ''), (string)($existingDecrypted['secret_key'] ?? ''));
        $sessionTokenStored = $sessionToken !== ''
            ? $encIfNeeded($sessionToken, (string)($existing['session_token'] ?? ''), (string)($existingDecrypted['session_token'] ?? ''))
            : '';

        $regionField = $_POST['region'] ?? '';
        if ($provider === 'do_spaces' && empty($regionField) && !empty($_POST['space_region'])) {
            $regionField = $_POST['space_region'];
        }
        if ($provider === 'wasabi' && empty($regionField) && !empty($_POST['wasabi_region'])) {
            $regionField = $_POST['wasabi_region'];
        }
        if ($provider === 'backblaze') {
            if (!empty($_POST['backblaze_region_custom'])) {
                $regionField = $_POST['backblaze_region_custom'];
            } elseif (empty($regionField) && !empty($_POST['backblaze_region'])) {
                $regionField = $_POST['backblaze_region'];
            }
        }
        $region = $sanitizeRegion($regionField, $existing['region'] ?? null);

        $bucketField = $_POST['bucket'] ?? ($existing['bucket'] ?? null);
        if ($provider === 'do_spaces' && empty($bucketField) && !empty($_POST['space_name'])) {
            $bucketField = $_POST['space_name'];
        }
        $bucket = $sanitizeBucket($bucketField, $existing['bucket'] ?? null);

        $prefix = '';
        try {
            $prefix = $sanitizePrefix($_POST['prefix'] ?? ($existing['prefix'] ?? '')); 
        } catch (InvalidArgumentException $e) {
            if ($e->getMessage() === 'invalid_prefix') {
                throw new InvalidArgumentException('invalid_prefix');
            }
            throw $e;
        }

        $endpoint = trim((string) ($_POST['endpoint'] ?? ($existing['endpoint'] ?? '')));
        if ($endpoint !== '') {
            if (!filter_var($endpoint, FILTER_VALIDATE_URL)) {
                throw new InvalidArgumentException('invalid_endpoint');
            }
            $endpoint = rtrim($endpoint, '/');
        }

        $publicBaseInput = $_POST['public_base_url'] ?? ($_POST['cdn_domain'] ?? ($existing['public_base_url'] ?? ''));
        $publicBase = '';
        if ($publicBaseInput !== null && trim((string) $publicBaseInput) !== '') {
            try {
                $publicBase = $sanitizeUrl($publicBaseInput);
            } catch (InvalidArgumentException $e) {
                if ($e->getMessage() === 'invalid_url') {
                    throw new InvalidArgumentException('invalid_public_base_url');
                }
                throw $e;
            }
        } elseif (!empty($existing['public_base_url'])) {
            $publicBase = (string) $existing['public_base_url'];
        }

        $defaultVisibility = $normalizeVisibility($_POST['default_visibility'] ?? ($existing['default_visibility'] ?? 'private'), 'private');
        $pathStyle = $getFlag($_POST['path_style'] ?? ($existing['path_style'] ?? null), (bool) ($existing['path_style'] ?? false));
        $deferNetwork = $getFlag($_POST['defer_network'] ?? ($existing['defer_network'] ?? null), (bool) ($existing['defer_network'] ?? false));
        $ttl = $sanitizeIntRange($_POST['default_presign_ttl'] ?? '', 60, 604800, 3600, isset($existing['default_presign_ttl']) ? (int) $existing['default_presign_ttl'] : null);
        $keepLocalCopy = $getFlag($_POST['keep_local_copy'] ?? ($existing['keep_local_copy'] ?? null), true);
        $syncModeRaw = isset($_POST['sync_mode']) ? (string) $_POST['sync_mode'] : (string) ($existing['sync_mode'] ?? 'manual');
        $syncMode = strtolower(trim($syncModeRaw));
        if (!in_array($syncMode, ['manual', 'background'], true)) {
            $syncMode = 'manual';
        }

        $providerConfig = [
            'enabled' => $enabled,
            'access_key' => $accessKeyStored,
            'secret_key' => $secretKeyStored,
            'session_token' => $sessionTokenStored,
            'region' => $region,
            'bucket' => $bucket,
            'prefix' => $prefix,
            'endpoint' => $endpoint,
            'path_style' => $pathStyle,
            'public_base_url' => $publicBase,
            'default_visibility' => $defaultVisibility,
            'default_presign_ttl' => $ttl,
            'defer_network' => $deferNetwork,
            'keep_local_copy' => $keepLocalCopy,
            'sync_mode' => $syncMode,
        ];

        if ($provider === 'do_spaces' && $publicBase === '' && !empty($_POST['cdn_domain'])) {
            // store original domain for reference
            $providerConfig['cdn_domain'] = trim((string) $_POST['cdn_domain']);
        }
        if ($provider === 'wasabi' && $publicBase === '' && !empty($_POST['cdn_domain'])) {
            $providerConfig['cdn_domain'] = trim((string) $_POST['cdn_domain']);
        }
        if ($provider === 'backblaze' && $publicBase === '' && !empty($_POST['cdn_domain'])) {
            $providerConfig['cdn_domain'] = trim((string) $_POST['cdn_domain']);
        }
    }
} catch (InvalidArgumentException $e) {
    $respond(400, ['status' => 'error', 'message' => $e->getMessage() ?: 'invalid_request']);
} catch (Throwable $e) {
    $respond(500, ['status' => 'error', 'message' => 'server_error']);
}

$storageConfig['providers'][$provider] = $providerConfig;
$storageConfig['providers'][$provider]['enabled'] = $makeDefault ? true : $providerConfig['enabled'];

if ($makeDefault) {
    $storageConfig['driver'] = $provider;
    foreach ($validProviders as $other) {
        if ($other === $provider) {
            continue;
        }
        if (!isset($storageConfig['providers'][$other]) || !is_array($storageConfig['providers'][$other])) {
            continue;
        }
        $storageConfig['providers'][$other]['enabled'] = false;
    }
} elseif (!isset($storageConfig['driver']) || $storageConfig['driver'] === '') {
    $storageConfig['driver'] = 'local';
}

$storageConfig['updated_at'] = time();
$storageConfig['updated_by'] = isset($userData['user_id']) ? (int) $userData['user_id'] : null;

if ($action === 'test') {
    $logResult = static function (string $providerKey, string $status, string $code, array $extra = []) use ($userData, $storageConfig): void {
        $payload = [
            'provider' => $providerKey,
            'status'   => $status,
            'code'     => $code,
            'user'     => isset($userData['user_id']) ? (int) $userData['user_id'] : 0,
            'driver'   => isset($storageConfig['driver']) ? (string) $storageConfig['driver'] : '',
        ];
        foreach ($extra as $k => $v) {
            if (is_scalar($v) || $v === null) {
                $payload[$k] = $v;
            }
        }
        try {
            error_log('[StorageTest] ' . json_encode($payload, JSON_UNESCAPED_SLASHES));
        } catch (Throwable $__) {
            // best-effort logging only
        }
    };

    if ($provider === 'local') {
        $root = (string) ($providerConfig['root_path'] ?? '');
        if ($root === '' || !is_dir($root)) {
            $logResult($provider, 'error', 'storage_test_local_missing_root');
            $respond(400, ['status' => 'error', 'message' => 'storage_test_local_missing_root']);
        }
        if (!is_readable($root)) {
            $logResult($provider, 'error', 'storage_test_local_unreadable');
            $respond(400, ['status' => 'error', 'message' => 'storage_test_local_unreadable']);
        }
        if (!is_writable($root)) {
            $logResult($provider, 'error', 'storage_test_local_not_writable');
            $respond(400, ['status' => 'error', 'message' => 'storage_test_local_not_writable']);
        }

        $logResult($provider, 'success', 'storage_test_success');
        $respond(200, ['status' => 'success', 'message' => 'storage_test_success']);
    }

    $adapterConfig = $providerConfig;
    $adapterConfig['defer_network'] = isset($adapterConfig['defer_network']) ? (bool) $adapterConfig['defer_network'] : false;
    if (!defined('APP_DEBUG') || APP_DEBUG !== true) {
        $adapterConfig['defer_network'] = false;
    }

    try {
        if ($provider === 's3') {
            $adapter = new S3Adapter($adapterConfig);
        } elseif ($provider === 'do_spaces') {
            $adapter = new DoSpacesAdapter($adapterConfig);
        } elseif ($provider === 'wasabi') {
            $adapter = new WasabiAdapter($adapterConfig);
        } else {
            $adapter = new BackblazeAdapter($adapterConfig);
        }

        $prefix = (string) ($adapterConfig['prefix'] ?? '');
        $testKeyBase = $prefix !== '' ? rtrim($prefix, '/') . '/__storage_test__/' : '__storage_test__/';
        $testKey = $testKeyBase . bin2hex(random_bytes(6));

        $signedUrl = '';
        try {
            $signedUrl = $adapter->url($testKey, 300);
        } catch (Throwable $e) {
            $logResult($provider, 'error', 'storage_test_remote_sign_failed', [
                'error_class' => get_class($e),
                'error_message' => $e->getMessage(),
                'keep_local' => $providerConfig['keep_local_copy'] ? '1' : '0',
                'sync_mode' => $providerConfig['sync_mode'] ?? 'manual',
            ]);
            $respond(400, ['status' => 'error', 'message' => 'storage_test_remote_sign_failed']);
        }

        $networkAttempted = !($adapterConfig['defer_network'] ?? false);
        if ($networkAttempted) {
            try {
                $adapter->exists($testKey);
            } catch (StorageException $storageException) {
                if ($storageException->getErrorCode() !== 'network_deferred') {
                    $logResult($provider, 'error', 'storage_test_remote_network_failed', [
                        'error_code' => $storageException->getErrorCode(),
                        'error_message' => $storageException->getMessage(),
                        'keep_local' => $providerConfig['keep_local_copy'] ? '1' : '0',
                        'sync_mode' => $providerConfig['sync_mode'] ?? 'manual',
                    ]);
                    $respond(400, ['status' => 'error', 'message' => 'storage_test_remote_network_failed']);
                }
                $networkAttempted = false;
            } catch (Throwable $e) {
                $logResult($provider, 'error', 'storage_test_remote_network_failed', [
                    'error_class' => get_class($e),
                    'error_message' => $e->getMessage(),
                    'keep_local' => $providerConfig['keep_local_copy'] ? '1' : '0',
                    'sync_mode' => $providerConfig['sync_mode'] ?? 'manual',
                ]);
                $respond(400, ['status' => 'error', 'message' => 'storage_test_remote_network_failed']);
            }
        }

        $logResult($provider, 'success', $networkAttempted ? 'storage_test_success' : 'storage_test_deferred', [
            'defer' => $adapterConfig['defer_network'] ? '1' : '0',
            'signed' => $signedUrl !== '' ? '1' : '0',
            'keep_local' => $providerConfig['keep_local_copy'] ? '1' : '0',
            'sync_mode' => $providerConfig['sync_mode'] ?? 'manual',
        ]);

        $respond(200, ['status' => 'success', 'message' => $networkAttempted ? 'storage_test_success' : 'storage_test_deferred']);
    } catch (Throwable $e) {
        $logResult($provider, 'error', 'storage_test_failed', [
            'error_class' => get_class($e),
            'error_message' => $e->getMessage(),
            'keep_local' => $providerConfig['keep_local_copy'] ?? false ? '1' : '0',
            'sync_mode' => $providerConfig['sync_mode'] ?? 'manual',
        ]);
        $respond(400, ['status' => 'error', 'message' => 'storage_test_failed']);
    }
}

try {
    $json = json_encode($storageConfig, JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('json_encode_failed');
    }
    $stmt = $db->prepare('UPDATE i_site_configurations SET storage_settings = :settings WHERE id = 1');
    $stmt->execute([':settings' => $json]);
    $siteData['storage_settings'] = $json;
    $respond(200, ['status' => 'success']);
} catch (Throwable $e) {
    $respond(500, ['status' => 'error', 'message' => 'server_error']);
}
