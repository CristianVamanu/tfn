<?php
declare(strict_types=1);
require_once __DIR__.'/../_bootstrap.php';
global $db,$userData,$ADM,$RL;
header('Content-Type: application/json; charset=utf-8');
$reply=static function(bool $ok,string $message,array $extra=[],int $http=200):void{http_response_code($http);echo json_encode(array_merge(['status'=>$ok?'success':'error','message'=>$message],$extra),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;};
if(!checkCsrfToken((string)($_POST['csrf_token']??''))){$reply(false,'Invalid security token.',[],403);}
$action=strtolower(trim((string)($_POST['ebook_action']??'')));$ebookId=max(0,(int)($_POST['ebook_id']??0));$adminId=(int)($userData['user_id']??0);
$moderationActions=['approve','reject'];$manageActions=['archive','restore','feature','unfeature','coupon_create','coupon_delete'];
if(!in_array($action,array_merge($moderationActions,$manageActions),true)){$reply(false,'Invalid action.',[],422);}
if(in_array($action,$moderationActions,true)&&!admin_has_permission('content.approve')){$reply(false,'You do not have permission to moderate eBooks.',[],403);}
if(in_array($action,$manageActions,true)&&!admin_has_permission('content.edit')){$reply(false,'You do not have permission to manage eBooks.',[],403);}
try{
  $now=time();$before=null;
  if($action==='coupon_delete'){
    $couponId=max(0,(int)($_POST['coupon_id']??0));if($couponId<=0){$reply(false,'Coupon not found.',[],404);}
    $st=$db->prepare('UPDATE i_ebook_coupons SET status=\'inactive\',updated_at=:now WHERE coupon_id=:id');$st->execute([':now'=>$now,':id'=>$couponId]);
    if($st->rowCount()!==1){$reply(false,'Coupon not found.',[],404);}
    if(isset($ADM)&&$ADM instanceof Admin_Data){$ADM->ADM_Audit($adminId,'ebook_coupon_delete',(string)$couponId,$now);}
    $reply(true,'Coupon deactivated.',['coupon_id'=>$couponId]);
  }
  if($ebookId<=0){$reply(false,'eBook not found.',[],404);}
  $st=$db->prepare('SELECT * FROM i_ebooks WHERE ebook_id=:ebook AND deleted_at IS NULL LIMIT 1');$st->execute([':ebook'=>$ebookId]);$before=$st->fetch(PDO::FETCH_ASSOC);
  if(!$before){$reply(false,'eBook not found.',[],404);}
  $current=strtolower((string)$before['status']);
  if($action==='coupon_create'){
    $code=strtoupper(preg_replace('/[^A-Z0-9_-]/','',strtoupper(trim((string)($_POST['coupon_code']??'')))));if($code===''){$reply(false,'Coupon code is required.',[],422);}
    $type=(string)($_POST['discount_type']??'')==='fixed'?'fixed':'percent';$value=round((float)($_POST['discount_value']??0),2);$minOrder=round(max(0,(float)($_POST['min_order']??0)),2);$maxUses=max(0,(int)($_POST['max_uses']??0));
    if($value<=0||($type==='percent'&&$value>=100)||($type==='fixed'&&$value>=(float)$before['price'])){$reply(false,'Enter a discount smaller than the product price.',[],422);}
    $starts=trim((string)($_POST['starts_at']??''));$ends=trim((string)($_POST['ends_at']??''));$startsAt=$starts!==''?strtotime($starts):null;$endsAt=$ends!==''?strtotime($ends):null;
    if(($starts!==''&&!$startsAt)||($ends!==''&&!$endsAt)||($startsAt&&$endsAt&&$startsAt>=$endsAt)){$reply(false,'Enter a valid coupon date range.',[],422);}
    $duplicate=$db->prepare('SELECT coupon_id FROM i_ebook_coupons WHERE code=:code LIMIT 1');$duplicate->execute([':code'=>$code]);if($duplicate->fetchColumn()){$reply(false,'This coupon code already exists.',[],409);}
    $st=$db->prepare("INSERT INTO i_ebook_coupons(code,ebook_id,discount_type,discount_value,min_order,max_uses,used_count,starts_at,ends_at,status,created_at,updated_at) VALUES(:code,:ebook,:type,:value,:min_order,:max_uses,0,:starts,:ends,'active',:now,:updated)");
    $st->execute([':code'=>$code,':ebook'=>$ebookId,':type'=>$type,':value'=>$value,':min_order'=>$minOrder,':max_uses'=>$maxUses,':starts'=>$startsAt?:null,':ends'=>$endsAt?:null,':now'=>$now,':updated'=>$now]);
    $couponId=(int)$db->lastInsertId();if(isset($ADM)&&$ADM instanceof Admin_Data){$ADM->ADM_Audit($adminId,'ebook_coupon_create',(string)$couponId,$now);}
    $reply(true,'Coupon created.',['coupon_id'=>$couponId,'ebook_id'=>$ebookId]);
  }
  $allowedTransitions=['approve'=>['pending'],'reject'=>['pending'],'archive'=>['active','draft','pending','rejected'],'restore'=>['archived'],'feature'=>['active'],'unfeature'=>['active']];
  if(!in_array($current,$allowedTransitions[$action]??[],true)){$reply(false,'This action is not available for the current eBook status.',['current_status'=>$current],409);}
  if($action==='approve'){$sql="UPDATE i_ebooks SET status='active',owner_hidden=0,moderation_note=NULL,approved_at=:approved,approved_by=:admin,updated_at=:updated WHERE ebook_id=:ebook AND status='pending'";$params=[':approved'=>$now,':updated'=>$now,':admin'=>$adminId,':ebook'=>$ebookId];$new='active';}
  elseif($action==='reject'){$note=trim((string)($_POST['moderation_note']??''));if(strlen($note)<3){$reply(false,'A rejection reason is required.',[],422);}if(strlen($note)>500){$reply(false,'The rejection reason is too long.',[],422);}$sql="UPDATE i_ebooks SET status='rejected',moderation_note=:note,approved_at=NULL,approved_by=NULL,updated_at=:updated WHERE ebook_id=:ebook AND status='pending'";$params=[':note'=>$note,':updated'=>$now,':ebook'=>$ebookId];$new='rejected';}
  elseif($action==='archive'){$sql="UPDATE i_ebooks SET status='archived',owner_hidden=1,owner_hidden_at=:hidden_at,featured=0,updated_at=:updated WHERE ebook_id=:ebook";$params=[':hidden_at'=>$now,':updated'=>$now,':ebook'=>$ebookId];$new='archived';}
  elseif($action==='restore'){$sql="UPDATE i_ebooks SET status='draft',owner_hidden=1,updated_at=:updated WHERE ebook_id=:ebook AND status='archived'";$params=[':updated'=>$now,':ebook'=>$ebookId];$new='draft';}
  elseif($action==='feature'){$sql="UPDATE i_ebooks SET featured=1,updated_at=:now WHERE ebook_id=:ebook AND status='active'";$params=[':now'=>$now,':ebook'=>$ebookId];$new='active';}
  else{$sql="UPDATE i_ebooks SET featured=0,updated_at=:now WHERE ebook_id=:ebook AND status='active'";$params=[':now'=>$now,':ebook'=>$ebookId];$new='active';}
  $st=$db->prepare($sql);$st->execute($params);if($st->rowCount()!==1){$reply(false,'The eBook changed before this action completed. Refresh and try again.',[],409);}
  if(in_array($action,['approve','reject'],true)&&isset($RL)&&method_exists($RL,'RL_CreateEbookStatusNotification')){$RL->RL_CreateEbookStatusNotification($adminId,(int)$before['owner_id'],$ebookId,$new,(string)$before['title'],$action==='reject'?(string)($note??''):'',$now);}
  if(isset($ADM)&&$ADM instanceof Admin_Data){$ADM->ADM_Audit($adminId,'ebook_'.$action,(string)$ebookId,$now);}
  $reply(true,'eBook updated.',['ebook_id'=>$ebookId,'status'=>$new,'action'=>$action]);
}catch(Throwable $e){$reply(false,'The action could not be completed.',[],500);}
