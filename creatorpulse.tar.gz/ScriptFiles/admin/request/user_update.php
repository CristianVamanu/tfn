<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $RL;

header('Content-Type: application/json; charset=utf-8');

$csrf = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status'=>'error','message'=>'invalid_csrf']);
    exit;
}

$uid = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
// Allow editing owner (id=1); only destructive actions are restricted elsewhere
if ($uid <= 0) { http_response_code(400); echo json_encode(['status'=>'error','message'=>'bad_user']); exit; }

// Permissions: moderators can edit profile fields; only admin/owner can change role or delete (handled elsewhere)
$myType = (int)($userData['user_type'] ?? 0);
$isOwnerOrAdmin = (($userData['user_id'] ?? 0) === 1) || ($myType >= 3);
$canEditProfile = admin_has_permission('users.edit_profile');
$canEditEmail = admin_has_permission('users.edit_email');
$canManageAccount = admin_has_permission('users.manage');
$canBan = admin_has_permission('users.ban');
$canEditWallet = admin_has_permission('users.edit_wallet');
$canResetPassword = admin_has_permission('users.reset_password');
$canVerify = admin_has_permission('verification.approve');
$canSetRole = admin_has_permission('users.set_role');

// Helper: does column exist?
$hasCol = function(string $name) use ($db): bool {
    try { $db->query('SELECT ' . $name . ' FROM i_users LIMIT 0'); return true; } catch (Throwable $__) { return false; }
};

// Incoming values
$fields = [
    'username'               => isset($_POST['username']) ? (string)$_POST['username'] : null,
    'user_fullname'          => isset($_POST['user_fullname']) ? (string)$_POST['user_fullname'] : null,
    'user_email'             => isset($_POST['user_email']) ? (string)$_POST['user_email'] : null,
    'user_phone'             => isset($_POST['user_phone']) ? (string)$_POST['user_phone'] : null,
    'about_me'               => isset($_POST['about_me']) ? (string)$_POST['about_me'] : null,
    'verified_status'        => isset($_POST['verified_status']) ? (int)$_POST['verified_status'] : null,
    'is_banned'              => isset($_POST['is_banned']) ? (int)$_POST['is_banned'] : null,
    'who_can_send_message'   => isset($_POST['who_can_send_message']) ? (string)$_POST['who_can_send_message'] : null,
    'subscription_status'    => isset($_POST['subscription_status']) ? (string)$_POST['subscription_status'] : null,
    'subscrition_status'     => isset($_POST['subscrition_status']) ? (string)$_POST['subscrition_status'] : null,
    'wallet'                 => isset($_POST['wallet']) ? (string)$_POST['wallet'] : null,
    'earned'                 => isset($_POST['earned']) ? (string)$_POST['earned'] : null,
    'for_billing_first_name' => isset($_POST['for_billing_first_name']) ? (string)$_POST['for_billing_first_name'] : null,
    'for_billing_last_name'  => isset($_POST['for_billing_last_name']) ? (string)$_POST['for_billing_last_name'] : null,
    'for_billing_country'    => isset($_POST['for_billing_country']) ? (string)$_POST['for_billing_country'] : null,
    'for_billing_city'       => isset($_POST['for_billing_city']) ? (string)$_POST['for_billing_city'] : null,
    'for_billing_state'      => isset($_POST['for_billing_state']) ? (string)$_POST['for_billing_state'] : null,
    'for_billing_postcode'   => isset($_POST['for_billing_postcode']) ? (string)$_POST['for_billing_postcode'] : null,
    'for_billing_address'    => isset($_POST['for_billing_address']) ? (string)$_POST['for_billing_address'] : null,
    'payout_method'          => isset($_POST['payout_method']) ? (string)$_POST['payout_method'] : null,
    'payout_details_json'    => isset($_POST['payout_details_json']) ? (string)$_POST['payout_details_json'] : null,
];

if (!$canEditProfile) {
    unset($fields['username'], $fields['user_fullname'], $fields['about_me']);
}
if (!$canEditEmail) {
    unset($fields['user_email']);
}
if (!$canManageAccount) {
    unset($fields['verified_status'], $fields['who_can_send_message'], $fields['subscription_status'], $fields['subscrition_status']);
}
if (!$canBan) {
    unset($fields['is_banned']);
}
if (!$canEditWallet) {
    unset(
        $fields['wallet'],
        $fields['earned'],
        $fields['for_billing_first_name'],
        $fields['for_billing_last_name'],
        $fields['for_billing_country'],
        $fields['for_billing_city'],
        $fields['for_billing_state'],
        $fields['for_billing_postcode'],
        $fields['for_billing_address'],
        $fields['payout_method'],
        $fields['payout_details_json']
    );
}

$creatorStatusRaw = isset($_POST['creator_status']) ? strtolower(trim((string)$_POST['creator_status'])) : '';
$creatorAdminNote = isset($_POST['creator_admin_note']) ? trim((string)$_POST['creator_admin_note']) : '';
$creatorUpdated = false;
if (!$canVerify) {
    $creatorStatusRaw = '';
    $creatorAdminNote = '';
}
if ($creatorStatusRaw !== '') {
    $allowedCreatorStates = ['none','pending','approved','rejected'];
    if (!in_array($creatorStatusRaw, $allowedCreatorStates, true)) {
        $creatorStatusRaw = '';
    }
}

// Normalize country: prefer country_code if valid, otherwise convert 2-letter code to name
if ($canEditWallet) {
    if (isset($_POST['country_code'])) {
        $cc = strtoupper(trim((string)$_POST['country_code']));
        if (isset($countries) && is_array($countries) && isset($countries[$cc])) {
            $fields['for_billing_country'] = $countries[$cc];
        }
    } else {
        $raw = isset($fields['for_billing_country']) ? (string)$fields['for_billing_country'] : '';
        if ($raw !== '' && strlen($raw) === 2) {
            $cc = strtoupper($raw);
            if (isset($countries) && is_array($countries) && isset($countries[$cc])) {
                $fields['for_billing_country'] = $countries[$cc];
            }
        }
    }
}

// Role: only admin/owner can change; prevent owner and self-demotion
$newRole = isset($_POST['role']) ? strtolower((string)$_POST['role']) : '';
if ($newRole !== '') {
    if (!$canSetRole || !$isOwnerOrAdmin) {
        unset($_POST['role']);
        $newRole = '';
    } elseif ($uid === 1) {
        http_response_code(400);
        echo json_encode(['status'=>'error','message'=>'owner_protected']);
        exit;
    } elseif ($uid === (int)($userData['user_id'] ?? 0) && $newRole !== 'admin') {
        http_response_code(400);
        echo json_encode(['status'=>'error','message'=>'self_role_forbidden']);
        exit;
    }
}

// Password: optional
$newPassword = isset($_POST['new_password']) ? (string)$_POST['new_password'] : '';
if (!$canResetPassword) {
    $newPassword = '';
}

// Build dynamic SET
$set = [];
$bind = [':u' => $uid];
foreach ($fields as $col => $val) {
    if ($val === null) { continue; }
    if (!$hasCol($col)) { continue; }
    $set[] = "$col = :$col";
    $bind[':'.$col] = $val;
}

// Role mapping: try user_mode if present + always update user_type
if ($newRole !== '') {
    $type = ($newRole === 'admin') ? 3 : (($newRole === 'moderator') ? 2 : 1);
    if ($hasCol('user_mode')) { $set[] = 'user_mode = :user_mode'; $bind[':user_mode'] = $newRole; }
    $set[] = 'user_type = :user_type'; $bind[':user_type'] = $type;
}

// Password
if ($newPassword !== '') {
    $hash = password_hash($newPassword, PASSWORD_DEFAULT);
    $set[] = 'user_password = :user_password';
    $bind[':user_password'] = $hash;
}

// Handle avatar/cover files if provided (admin can upload via this form as in settings/profile)
try {
    if ($canEditProfile) {
        if (!empty($_FILES['avatar']) && is_uploaded_file($_FILES['avatar']['tmp_name'])) {
            $rel = $ADM->ADM_UpdateUserMedia($uid, 'avatar', $_FILES['avatar']);
            if ($rel) { $ADM->ADM_Audit((int)($userData['user_id'] ?? 0), 'user_media_avatar', 'user:' . $uid); }
        }
        if (!empty($_FILES['cover']) && is_uploaded_file($_FILES['cover']['tmp_name'])) {
            $rel = $ADM->ADM_UpdateUserMedia($uid, 'cover', $_FILES['cover']);
            if ($rel) { $ADM->ADM_Audit((int)($userData['user_id'] ?? 0), 'user_media_cover', 'user:' . $uid); }
        }
    }
} catch (Throwable $__) { /* ignore media errors but continue updating fields */ }

if ($creatorStatusRaw !== '' && isset($RL) && is_object($RL)) {
    try {
        if ($creatorStatusRaw === 'none') {
            $creatorUpdated = $RL->RL_UpdateCreatorStatus($uid, 'none');
        } else {
            $existing = $RL->RL_GetCreatorVerificationRequest($uid);
            if ($existing && isset($existing['request_id'])) {
                $reqId = (int)$existing['request_id'];
                $creatorUpdated = $RL->RL_UpdateCreatorVerificationStatus(
                    $reqId,
                    $creatorStatusRaw,
                    (int)($userData['user_id'] ?? 0),
                    $creatorAdminNote
                );
                if ($creatorUpdated && $creatorStatusRaw !== 'pending' && method_exists($RL, 'RL_CreateCreatorStatusNotification')) {
                    $RL->RL_CreateCreatorStatusNotification(
                        $uid,
                        (int)($userData['user_id'] ?? 0),
                        $creatorStatusRaw,
                        $creatorAdminNote
                    );
                }
            } else {
                $creatorUpdated = $RL->RL_UpdateCreatorStatus($uid, $creatorStatusRaw);
            }
        }
    } catch (Throwable $__) {
        $creatorUpdated = false;
    }
}

if (isset($fields['payout_method'])) {
    $pm = strtolower(trim((string)$fields['payout_method']));
    if (!in_array($pm, ['none','bank','paypal','other'], true)) {
        $pm = 'none';
    }
    $fields['payout_method'] = $pm;
}

if (isset($fields['payout_details_json'])) {
    $detailsRaw = trim((string)$fields['payout_details_json']);
    if ($detailsRaw === '') {
        $fields['payout_details_json'] = null;
    } else {
        // Ensure valid JSON; if plain text, wrap into JSON object with "note"
        $decoded = json_decode($detailsRaw, true);
        if (!is_array($decoded)) {
            $decoded = ['note' => $detailsRaw];
        }
        $fields['payout_details_json'] = json_encode($decoded, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
}

if (empty($set)) {
    echo json_encode(['status'=>'success','updated'=>$creatorUpdated ? 1 : 0, 'creator_updated' => $creatorUpdated ? 1 : 0]);
    exit;
}

try {
    $sql = 'UPDATE i_users SET ' . implode(', ', $set) . ' WHERE user_id = :u LIMIT 1';
    $st = $db->prepare($sql);
    $ok = $st->execute($bind);
    if (!$ok) { http_response_code(500); echo json_encode(['status'=>'error','message'=>'op_failed']); exit; }
    $ADM->ADM_Audit((int)($userData['user_id'] ?? 0), 'user_update', 'user:' . $uid);
    echo json_encode(['status'=>'success','updated'=>1, 'creator_updated' => $creatorUpdated ? 1 : 0]);
    exit;
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status'=>'error','message'=>'server_error']);
    exit;
}
