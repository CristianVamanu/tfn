<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $ADM, $userData;

header('Content-Type: application/json; charset=utf-8');

$csrf = isset($_POST['csrf_token']) ? (string) $_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$action = isset($_POST['action']) ? strtolower(trim((string) $_POST['action'])) : '';
if ($action === '') {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'bad_action']);
    exit;
}

$userId = isset($_POST['user_id']) ? (int) $_POST['user_id'] : 0;
$method = isset($_POST['method']) ? strtolower(trim((string) $_POST['method'])) : '';
$note = isset($_POST['note']) ? (string) $_POST['note'] : '';

if ($userId <= 0 || $method === '') {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'bad_request']);
    exit;
}

$note = trim($note);
if (function_exists('mb_substr')) {
    $note = mb_substr($note, 0, 1000, 'UTF-8');
} else {
    $note = substr($note, 0, 1000);
}

$statusMap = [
    'approve'       => 'approved',
    'reject'        => 'rejected',
    'request_update'=> 'review',
];

if (!isset($statusMap[$action])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'bad_action']);
    exit;
}

$targetStatus = $statusMap[$action];
$adminId = (int) ($userData['user_id'] ?? 0);
if (!admin_has_permission('payouts.update')) {
    admin_forbidden_json();
}

$notifyInapp = !empty($_POST['notify_inapp']);
$notifyEmail = !empty($_POST['notify_email']);
$setDefault = !empty($_POST['set_default']);
$requiresUpdate = $action === 'request_update' ? true : null;

if (!isset($ADM) || !method_exists($ADM, 'ADM_UpdatePayoutMethodStatus')) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}

$options = [
    'notify_inapp'    => $notifyInapp,
    'notify_email'    => $notifyEmail,
    'set_default'     => $setDefault,
];
if ($requiresUpdate !== null) {
    $options['requires_update'] = $requiresUpdate;
}

try {
    $result = $ADM->ADM_UpdatePayoutMethodStatus($adminId, $userId, $method, $targetStatus, $note, $options);
} catch (Throwable $e) {
    error_log('ADM_UpdatePayoutMethodStatus failed: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}

if (empty($result['ok'])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'server_error']);
    exit;
}

$response = [
    'status'        => 'success',
    'payload'       => $result['payload'] ?? [],
    'payout'        => $result['payout'] ?? null,
    'method'        => $result['method'] ?? $method,
    'state'         => $result['status'] ?? $targetStatus,
    'notifications' => $result['notifications'] ?? [],
];

if (!empty($_POST['include_history'])) {
    $historyLimit = isset($_POST['history_limit']) ? (int) $_POST['history_limit'] : 5;
    $historyLimit = max(1, min(20, $historyLimit));
    $history = method_exists($ADM, 'ADM_GetPayoutReviewHistory')
        ? $ADM->ADM_GetPayoutReviewHistory($userId, $method, $historyLimit, 0)
        : [];
    $response['history'] = $history;
}

echo json_encode($response);
exit;
