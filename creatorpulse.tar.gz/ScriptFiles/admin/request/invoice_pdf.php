<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

header('X-Content-Type-Options: nosniff');

$type = isset($_GET['type']) ? (string)$_GET['type'] : '';
$id   = isset($_GET['id'])   ? (int)$_GET['id']   : 0;
if (!in_array($type, ['subscription','tip','ebook','audio_room_ticket','audio_room_tip'], true) || $id <= 0) {
    http_response_code(400);
    echo 'Bad request';
    exit;
}

// Fetch invoice data
if ($type === 'subscription') {
    $inv = $ADM->ADM_GetSubscriptionInvoice($id);
} elseif ($type === 'tip') {
    $inv = $ADM->ADM_GetTipInvoice($id);
} elseif (in_array($type, ['audio_room_ticket', 'audio_room_tip'], true)) {
    $inv = $ADM->ADM_GetAudioRoomInvoice($type, $id);
} else {
    $stmt = $db->prepare(
        'SELECT ep.*,
                inv.invoice_number AS stored_invoice_number,
                e.title AS ebook_title,
                ub.username AS buyer_username,
                COALESCE(ub.user_fullname, ub.username) AS buyer_fullname,
                ur.username AS recip_username,
                COALESCE(ur.user_fullname, ur.username) AS recip_fullname
         FROM i_ebook_purchases ep
         LEFT JOIN i_invoices inv
           ON inv.source_type = "ebook_purchase"
          AND inv.source_id = ep.purchase_id
         LEFT JOIN i_ebooks e ON e.ebook_id = ep.ebook_id
         LEFT JOIN i_users ub ON ub.user_id = ep.buyer_id
         LEFT JOIN i_users ur ON ur.user_id = ep.seller_id
         WHERE ep.purchase_id = :id
         LIMIT 1'
    );
    $stmt->execute([':id' => $id]);
    $inv = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}
if (!$inv) { http_response_code(404); echo 'Not found'; exit; }

// Common helpers
$siteTitle = $siteTitle ?? 'ReelsProject';
$currency  = (string)($inv['currency'] ?? '');
$currenciesMap = isset($currencies) && is_array($currencies) ? $currencies : [];
$curSym   = $currency !== '' ? ($currenciesMap[$currency] ?? $currency) : '';
$fmt = function(float $v) use ($curSym): string {
    $hasFraction = abs($v - round($v)) > 0.004;
    if ($v < 1000 && $hasFraction) { return $curSym . number_format($v, 2, '.', '.'); }
    return $curSym . number_format($v, 0, ',', '.');
};

if ($type === 'subscription') {
    $amount = (float)($inv['amount'] ?? 0);
    $qty    = max(1, (int)($inv['interval_count'] ?? 1));
    $tax = (float)($inv['tax_amount'] ?? 0);
    $fee = (float)($inv['fee_amount'] ?? 0);
    $derived = $ADM->ADM_ExtractSubscriptionAmounts($inv);
    if (($derived['tax'] ?? 0) > 0) { $tax = (float)$derived['tax']; }
    if (($derived['fee'] ?? 0) > 0) { $fee = (float)$derived['fee']; }
    $gross = $amount * $qty;
    $total = $gross + $tax + $fee;
    $title = 'Invoice SP-' . (int)$inv['id'];
    $line  = 'SUBSCRIPTION – ' . strtoupper((string)($inv['plan_interval'] ?? ''));
} elseif ($type === 'tip') {
    $amount = (float)($inv['amount'] ?? 0);
    $tax    = (float)($inv['tax_amount'] ?? 0);
    $fee    = (float)($inv['fee_amount'] ?? 0);
    $gross  = $amount;
    $total  = $gross + $tax + $fee;
    $title  = 'Invoice TIP-' . (int)$inv['id'];
    $line   = 'TIP – @' . (string)($inv['recip_username'] ?? '');
} elseif (in_array($type, ['audio_room_ticket', 'audio_room_tip'], true)) {
    $amount = (float)($inv['amount'] ?? 0);
    $tax    = (float)($inv['tax_amount'] ?? 0);
    $fee    = (float)($inv['fee_amount'] ?? 0);
    $gross  = $amount;
    $total  = $gross;
    $invoiceNumber = trim((string)($inv['invoice_number'] ?? ''));
    if ($invoiceNumber === '') {
        $invoiceNumber = ($type === 'audio_room_ticket' ? 'AR-TKT-' : 'AR-TIP-') . $id;
    }
    $title = 'Invoice ' . $invoiceNumber;
    $roomTitle = trim((string)($inv['room_title'] ?? ''));
    $line = ($type === 'audio_room_ticket' ? 'AUDIO ROOM TICKET – ' : 'AUDIO ROOM TIP – ')
        . ($roomTitle !== '' ? $roomTitle : ('#' . (int)($inv['room_id'] ?? 0)));
} else {
    $amount = (float)($inv['amount'] ?? 0);
    $tax    = (float)($inv['tax_amount'] ?? 0);
    $fee    = (float)($inv['fee_amount'] ?? 0);
    $gross  = $amount;
    $total  = $gross + $tax + $fee;
    $invoiceNumber = trim((string)($inv['stored_invoice_number'] ?? ''));
    if ($invoiceNumber === '') {
        $invoiceNumber = 'EB-' . (int)$inv['purchase_id'];
    }
    $title = 'Invoice ' . $invoiceNumber;
    $ebookTitle = trim((string)($inv['ebook_title'] ?? ''));
    $line = 'EBOOK – ' . ($ebookTitle !== '' ? $ebookTitle : ('#' . (int)$inv['ebook_id']));
}

$created = isset($inv['created_at']) && $inv['created_at'] ? date('d/m/Y', (int)$inv['created_at']) : '-';

// Minimal standalone HTML for PDF rendering (inline CSS acceptable for server-side PDF)
$html = '<!doctype html><html><head><meta charset="utf-8">
<style>
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Helvetica,Arial,sans-serif;color:#111827}
.wrap{max-width:800px;margin:0 auto;padding:12px}
.top{display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #e5e7eb;padding-bottom:8px;margin-bottom:12px}
.brand{font-weight:900;font-size:22px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:10px 0}
.box-title{font-weight:800;font-size:12px;color:#6b7280;text-transform:uppercase}
table{width:100%;border-collapse:collapse;margin-top:6px}
th,td{padding:8px 10px;border-bottom:1px solid #e5e7eb;text-align:left}
.right{float:right}
.totals{width:320px;margin-left:auto;margin-top:10px}
.row{display:flex;justify-content:space-between}
</style></head><body><div class="wrap">'
. '<div class="top"><div class="brand">' . htmlspecialchars(strtoupper($siteTitle), ENT_QUOTES, 'UTF-8') . '</div>'
. '<div>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '<br>' . htmlspecialchars($created, ENT_QUOTES, 'UTF-8') . '</div></div>'
. '<div class="grid">'
. '<div><div class="box-title">From</div>' . htmlspecialchars((string)($inv['recip_fullname'] ?? ''), ENT_QUOTES, 'UTF-8') . ' (@' . htmlspecialchars((string)($inv['recip_username'] ?? ''), ENT_QUOTES, 'UTF-8') . ')</div>'
. '<div><div class="box-title">Billed To</div>' . htmlspecialchars((string)($inv['buyer_fullname'] ?? ''), ENT_QUOTES, 'UTF-8') . ' (@' . htmlspecialchars((string)($inv['buyer_username'] ?? ''), ENT_QUOTES, 'UTF-8') . ')</div>'
. '</div>'
. '<table><thead><tr><th>Description</th><th>Price</th><th>Discount</th><th>Amount ' . htmlspecialchars($currency, ENT_QUOTES, 'UTF-8') . '</th></tr></thead><tbody>'
. '<tr><td>' . htmlspecialchars($line, ENT_QUOTES, 'UTF-8') . '</td><td>' . htmlspecialchars($fmt($amount), ENT_QUOTES, 'UTF-8') . '</td><td>-</td><td>' . htmlspecialchars($fmt($total), ENT_QUOTES, 'UTF-8') . '</td></tr>'
. '</tbody></table>'
. '<div class="totals">'
. '<div class="row"><span>Subtotal:</span><strong>' . htmlspecialchars($fmt($gross), ENT_QUOTES, 'UTF-8') . '</strong></div>'
. '<div class="row"><span>Tax:</span><strong>' . htmlspecialchars($fmt($tax), ENT_QUOTES, 'UTF-8') . '</strong></div>'
. '<div class="row"><span>Fee:</span><strong>' . htmlspecialchars($fmt($fee), ENT_QUOTES, 'UTF-8') . '</strong></div>'
. '<div class="row"><span>Total:</span><strong>' . htmlspecialchars($fmt($total), ENT_QUOTES, 'UTF-8') . '</strong></div>'
. '</div>'
. '</div></body></html>';

// Try Dompdf if available
if (class_exists('Dompdf\\Dompdf')) {
    try {
        $dompdf = new Dompdf\Dompdf(['isRemoteEnabled' => true]);
        $dompdf->loadHtml($html, 'UTF-8');
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        $fnamePrefix = $type === 'subscription'
            ? 'invoice_sp_'
            : ($type === 'ebook'
                ? 'invoice_ebook_'
                : ($type === 'audio_room_ticket'
                    ? 'invoice_audio_room_ticket_'
                    : ($type === 'audio_room_tip' ? 'invoice_audio_room_tip_' : 'invoice_tip_')));
        $fname = $fnamePrefix . $id . '.pdf';
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename=' . $fname);
        echo $dompdf->output();
        exit;
    } catch (\Throwable $e) {
        // fall through to HTML output
    }
}

// Fallback: HTML output with instructions
http_response_code(501);
header('Content-Type: text/html; charset=utf-8');
echo $html;
exit;
