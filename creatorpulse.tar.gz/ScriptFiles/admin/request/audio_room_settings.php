<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

global $siteData, $db, $userData, $ADM;

$respond = static function (string $status, string $message, int $http = 200): void {
    http_response_code($http);
    echo json_encode(['status' => $status, 'message' => $message], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
};

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    $respond('error', 'method_not_allowed', 405);
}
if (!admin_has_permission('settings.manage')) {
    admin_forbidden_json();
}
if (!checkCsrfToken((string)($_POST['csrf_token'] ?? ''))) {
    $respond('error', 'invalid_csrf', 403);
}

$normalizeToggle = static function ($value): string {
    return in_array(strtolower(trim((string)$value)), ['1', 'true', 'yes', 'on', 'enabled'], true) ? '1' : '0';
};
$value = static function (string $key, string $fallback = '') use ($siteData): string {
    return array_key_exists($key, $_POST)
        ? trim((string)$_POST[$key])
        : trim((string)($siteData[$key] ?? $fallback));
};

$enabled = $normalizeToggle($value('audio_rooms_enabled', '1'));
$chatEnabled = $normalizeToggle($value('audio_room_chat_enabled', '1'));
$paidEnabled = $normalizeToggle($value('audio_room_paid_enabled', '1'));
$customPriceEnabled = $normalizeToggle($value('audio_room_custom_price_enabled', '1'));

if ($enabled === '1') {
    $appId = preg_replace('/[^0-9a-f]/i', '', (string)($siteData['agora_app_id'] ?? ''));
    if (!is_string($appId) || preg_match('/^[0-9a-f]{32}$/i', $appId) !== 1) {
        $respond('error', 'missing_agora_app_id', 422);
    }
}

$presets = [];
foreach (preg_split('/[,;\s]+/', $value('audio_room_price_presets', '5,10,15,20')) ?: [] as $raw) {
    if ($raw === '') {
        continue;
    }
    if (!is_numeric($raw)) {
        $respond('error', 'invalid_audio_room_price_presets', 422);
    }
    $amount = round((float)$raw, 2);
    if ($amount <= 0 || $amount > 100000) {
        $respond('error', 'invalid_audio_room_price_presets', 422);
    }
    $presets[number_format($amount, 2, '.', '')] = $amount;
}
if (!$presets) {
    $respond('error', 'invalid_audio_room_price_presets', 422);
}
ksort($presets, SORT_NATURAL);
$pricePresets = implode(',', array_map(static function (float $amount): string {
    return rtrim(rtrim(number_format($amount, 2, '.', ''), '0'), '.');
}, array_values($presets)));

$minimumRaw = $value('audio_room_price_minimum', '1.00');
$maximumRaw = $value('audio_room_price_maximum', '500.00');
if (!is_numeric($minimumRaw) || !is_numeric($maximumRaw)) {
    $respond('error', 'invalid_audio_room_price_range', 422);
}
$minimum = round((float)$minimumRaw, 2);
$maximum = round((float)$maximumRaw, 2);
if ($minimum < 0 || $maximum < $minimum || $maximum > 100000) {
    $respond('error', 'invalid_audio_room_price_range', 422);
}
foreach ($presets as $preset) {
    if ($preset < $minimum || $preset > $maximum) {
        $respond('error', 'invalid_audio_room_price_presets', 422);
    }
}

$integer = static function (string $raw, int $min, int $max, string $error) use ($respond): int {
    if ($raw === '' || !ctype_digit($raw)) {
        $respond('error', $error, 422);
    }
    $number = (int)$raw;
    if ($number < $min || $number > $max) {
        $respond('error', $error, 422);
    }
    return $number;
};
$dailyMinutes = $integer($value('audio_room_non_creator_daily_minutes', '60'), 0, 1440, 'invalid_audio_room_daily_limit');
$maxSpeakers = $integer($value('audio_room_max_speakers', '12'), 1, 100, 'invalid_audio_room_max_speakers');
$maxListenersNumber = $integer($value('audio_room_max_listeners', '0'), 0, 500000, 'invalid_audio_room_max_listeners');
$maxListeners = $maxListenersNumber === 0 ? null : $maxListenersNumber;

$titlePrefix = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $value('audio_room_title_prefix'));
$titlePrefix = trim(preg_replace('/\s+/u', ' ', is_string($titlePrefix) ? $titlePrefix : '') ?? '');
if (mb_strlen($titlePrefix, 'UTF-8') > 180) {
    $respond('error', 'invalid_audio_room_title_prefix', 422);
}
$titlePrefix = $titlePrefix === '' ? null : $titlePrefix;

$settings = [
    'audio_rooms_enabled' => $enabled,
    'audio_room_chat_enabled' => $chatEnabled,
    'audio_room_paid_enabled' => $paidEnabled,
    'audio_room_custom_price_enabled' => $customPriceEnabled,
    'audio_room_price_presets' => $pricePresets,
    'audio_room_price_minimum' => number_format($minimum, 2, '.', ''),
    'audio_room_price_maximum' => number_format($maximum, 2, '.', ''),
    'audio_room_non_creator_daily_minutes' => $dailyMinutes,
    'audio_room_max_speakers' => $maxSpeakers,
    'audio_room_max_listeners' => $maxListeners,
    'audio_room_title_prefix' => $titlePrefix,
];

try {
    $definitions = [
        "audio_rooms_enabled TINYINT(1) NOT NULL DEFAULT 1",
        "audio_room_chat_enabled TINYINT(1) NOT NULL DEFAULT 1",
        "audio_room_paid_enabled TINYINT(1) NOT NULL DEFAULT 1",
        "audio_room_custom_price_enabled TINYINT(1) NOT NULL DEFAULT 1",
        "audio_room_price_presets VARCHAR(191) NOT NULL DEFAULT '5,10,15,20'",
        "audio_room_price_minimum DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT '1.00'",
        "audio_room_price_maximum DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT '500.00'",
        "audio_room_non_creator_daily_minutes INT UNSIGNED NOT NULL DEFAULT 60",
        "audio_room_max_speakers INT UNSIGNED NOT NULL DEFAULT 12",
        "audio_room_max_listeners INT UNSIGNED NULL",
        "audio_room_title_prefix VARCHAR(180) NULL",
    ];
    foreach ($definitions as $definition) {
        try {
            $db->exec('ALTER TABLE i_site_configurations ADD COLUMN ' . $definition);
        } catch (Throwable $e) {
            $message = strtolower($e->getMessage());
            if (strpos($message, 'duplicate') === false && strpos($message, 'exists') === false) {
                throw $e;
            }
        }
    }

    $assignments = [];
    $params = [':id' => 1];
    foreach ($settings as $key => $setting) {
        $assignments[] = $key . '=:' . $key;
        $params[':' . $key] = $setting;
    }
    $statement = $db->prepare('UPDATE i_site_configurations SET ' . implode(',', $assignments) . ' WHERE id=:id');
    $statement->execute($params);

    if (isset($ADM) && $ADM instanceof Admin_Data) {
        $summary = sprintf('enabled:%s|paid:%s|speakers:%d|listeners:%d', $enabled, $paidEnabled, $maxSpeakers, $maxListenersNumber);
        $ADM->ADM_Audit((int)($userData['user_id'] ?? 0), 'update_audio_room_settings', mb_substr($summary, 0, 60), time());
    }
    $respond('success', 'saved');
} catch (Throwable $e) {
    error_log('Audio Room settings update failed: ' . $e->getMessage());
    $respond('error', 'server_error', 500);
}
