<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $ADM;

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}
if (!admin_has_permission('settings.manage')) {
    http_response_code(403);
    exit('Forbidden.');
}
if (!checkCsrfToken((string)($_POST['csrf_token'] ?? ''))) {
    http_response_code(403);
    exit('Invalid security token.');
}

$parseDate = static function (string $value, bool $endOfDay = false): int {
    if ($value === '' || preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) !== 1) {
        return 0;
    }
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    if (!$date || $date->format('Y-m-d') !== $value) {
        return 0;
    }
    return ($endOfDay ? $date->setTime(23, 59, 59) : $date)->getTimestamp();
};
$q = trim((string)($_POST['q'] ?? ''));
$filters = [
    'type' => trim((string)($_POST['type'] ?? '')),
    'status' => trim((string)($_POST['status'] ?? '')),
    'date_from' => $parseDate(trim((string)($_POST['date_from'] ?? ''))),
    'date_to' => $parseDate(trim((string)($_POST['date_to'] ?? '')), true),
];
$rows = $ADM->ADM_AudioRoomTransactionExport($q, $filters, 5000);

$safeCsv = static function ($value): string {
    $text = str_replace(["\r\n", "\r", "\n"], ' ', (string)$value);
    if ($text !== '' && preg_match('/^[=+\-@]/', ltrim($text)) === 1) {
        $text = "'" . $text;
    }
    return $text;
};

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="audio-room-earnings-' . date('Y-m-d-His') . '.csv"');
header('X-Content-Type-Options: nosniff');
echo "\xEF\xBB\xBF";
$out = fopen('php://output', 'wb');
if ($out === false) {
    http_response_code(500);
    exit;
}
fputcsv($out, ['Type','Transaction ID','Room ID','Room','Buyer','Creator','Status','Gross','Currency','Fee','Tax','Creator net','Provider','Reference','Created']);
foreach ($rows as $row) {
    fputcsv($out, array_map($safeCsv, [
        $row['transaction_type'] ?? '',
        $row['id'] ?? '',
        $row['room_id'] ?? '',
        $row['room_title'] ?? '',
        $row['buyer_username'] ?? '',
        $row['recipient_username'] ?? '',
        $row['status'] ?? '',
        number_format((float)($row['amount'] ?? 0), 2, '.', ''),
        strtoupper((string)($row['currency'] ?? '')),
        number_format((float)($row['fee_amount'] ?? 0), 2, '.', ''),
        number_format((float)($row['tax_amount'] ?? 0), 2, '.', ''),
        number_format((float)($row['net_amount'] ?? 0), 2, '.', ''),
        $row['provider'] ?? '',
        $row['reference'] ?? '',
        date('Y-m-d H:i:s', (int)($row['created_at'] ?? 0)),
    ]));
}
fclose($out);
exit;
