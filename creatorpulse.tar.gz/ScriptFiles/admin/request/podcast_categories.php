<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

$csrf = isset($_POST['csrf_token']) ? (string) $_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf_token']);
    exit;
}

$action = isset($_POST['action']) ? strtolower(trim((string) $_POST['action'])) : 'create';
$allowedActions = ['create', 'update', 'delete', 'status', 'sort'];
if (!in_array($action, $allowedActions, true)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'bad_action']);
    exit;
}

$ensureSchema = static function (PDO $dbConn): void {
    try {
        $dbConn->exec("CREATE TABLE IF NOT EXISTS i_podcast_categories (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(120) NOT NULL,
            slug VARCHAR(160) NOT NULL,
            status ENUM('active','inactive') NOT NULL DEFAULT 'active',
            sort_order INT NOT NULL DEFAULT 0,
            created_at INT UNSIGNED NOT NULL,
            updated_at INT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_slug (slug),
            KEY idx_status_sort (status, sort_order),
            KEY idx_sort (sort_order)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $__) {}

    try {
        $dbConn->exec("CREATE TABLE IF NOT EXISTS i_podcast_category_translations (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            category_id INT UNSIGNED NOT NULL,
            language VARCHAR(16) NOT NULL,
            name VARCHAR(120) NOT NULL,
            created_at INT UNSIGNED NOT NULL,
            updated_at INT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_cat_lang (category_id, language),
            KEY idx_cat (category_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $__) {}

    try {
        $columns = [];
        $stmt = $dbConn->query("SHOW COLUMNS FROM i_user_posts");
        if ($stmt) {
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if (!isset($row['Field'])) { continue; }
                $columns[$row['Field']] = $row;
            }
        }
        if (!isset($columns['podcast_category_id'])) {
            $dbConn->exec("ALTER TABLE i_user_posts ADD COLUMN podcast_category_id INT UNSIGNED NULL AFTER audio_duration_seconds");
        }
        try { $dbConn->exec("ALTER TABLE i_user_posts ADD INDEX idx_podcast_category (podcast_category_id)"); } catch (Throwable $__) {}
    } catch (Throwable $__) {}
};

$ensureSchema($db);

$now = time();

$availableLanguages = function_exists('discoverAvailableLanguages') ? discoverAvailableLanguages() : ['eng'];
if (!$availableLanguages) {
    $availableLanguages = ['eng'];
}
$availableLanguages = array_values(array_unique(array_map(static function ($lng) {
    return strtolower(trim((string) $lng));
}, $availableLanguages)));

$defaultLang = isset($_POST['default_lang']) ? strtolower(trim((string) $_POST['default_lang'])) : ($availableLanguages[0] ?? 'eng');
if ($defaultLang === '' || !in_array($defaultLang, $availableLanguages, true)) {
    $defaultLang = $availableLanguages[0] ?? 'eng';
}

$makeSlug = static function (string $value): string {
    $slug = trim($value);
    if ($slug === '') {
        return '';
    }
    if (class_exists('\Transliterator')) {
        $trans = \Transliterator::create('Any-Latin; Latin-ASCII');
        if ($trans) {
            $slug = $trans->transliterate($slug);
        }
    } elseif (function_exists('iconv')) {
        $slug = iconv('UTF-8', 'ASCII//TRANSLIT', $slug);
    }
    $slug = strtolower((string) $slug);
    $slug = preg_replace('/[^a-z0-9\-]+/i', '-', $slug);
    $slug = preg_replace('/-+/', '-', (string) $slug);
    $slug = trim((string) $slug, '-');
    if (!is_string($slug)) {
        return '';
    }
    return $slug;
};

$normalizeStatus = static function (string $value): string {
    $value = strtolower(trim($value));
    return in_array($value, ['active', 'inactive'], true) ? $value : 'inactive';
};

try {
    if ($action === 'delete') {
        $categoryId = isset($_POST['category_id']) ? (int) $_POST['category_id'] : 0;
        if ($categoryId <= 0) {
            throw new InvalidArgumentException('admin_podcast_category_not_found');
        }
        $check = $db->prepare('SELECT id FROM i_podcast_categories WHERE id = :id LIMIT 1');
        $check->bindValue(':id', $categoryId, PDO::PARAM_INT);
        $check->execute();
        if ($check->fetchColumn() === false) {
            throw new InvalidArgumentException('admin_podcast_category_not_found');
        }

        $del = $db->prepare('DELETE FROM i_podcast_categories WHERE id = :id LIMIT 1');
        $del->bindValue(':id', $categoryId, PDO::PARAM_INT);
        $del->execute();

        try {
            $delTrans = $db->prepare('DELETE FROM i_podcast_category_translations WHERE category_id = :id');
            $delTrans->bindValue(':id', $categoryId, PDO::PARAM_INT);
            $delTrans->execute();
        } catch (Throwable $__) {
            // ignore
        }

        try {
            $clear = $db->prepare('UPDATE i_user_posts SET podcast_category_id = NULL WHERE podcast_category_id = :id');
            $clear->bindValue(':id', $categoryId, PDO::PARAM_INT);
            $clear->execute();
        } catch (Throwable $__) {
            // best effort
        }

        echo json_encode(['status' => 'success', 'message' => 'admin_podcast_category_deleted']);
        exit;
    }

    if ($action === 'status') {
        $categoryId = isset($_POST['category_id']) ? (int) $_POST['category_id'] : 0;
        $status = $normalizeStatus((string) ($_POST['status'] ?? 'inactive'));
        if ($categoryId <= 0) {
            throw new InvalidArgumentException('admin_podcast_category_not_found');
        }
        $check = $db->prepare('SELECT id FROM i_podcast_categories WHERE id = :id LIMIT 1');
        $check->bindValue(':id', $categoryId, PDO::PARAM_INT);
        $check->execute();
        if ($check->fetchColumn() === false) {
            throw new InvalidArgumentException('admin_podcast_category_not_found');
        }

        $stmt = $db->prepare('UPDATE i_podcast_categories SET status = :status, updated_at = :updated WHERE id = :id LIMIT 1');
        $stmt->bindValue(':status', $status, PDO::PARAM_STR);
        $stmt->bindValue(':updated', $now, PDO::PARAM_INT);
        $stmt->bindValue(':id', $categoryId, PDO::PARAM_INT);
        $stmt->execute();
        echo json_encode(['status' => 'success', 'message' => 'admin_podcast_category_status_updated']);
        exit;
    }

    if ($action === 'sort') {
        $orderRaw = $_POST['order'] ?? [];
        $orderIds = [];
        if (is_array($orderRaw)) {
            foreach ($orderRaw as $idVal) {
                $val = (int) $idVal;
                if ($val > 0 && !in_array($val, $orderIds, true)) {
                    $orderIds[] = $val;
                }
            }
        }

        $stmtAll = $db->query('SELECT id FROM i_podcast_categories ORDER BY sort_order ASC, id ASC');
        $allIds = $stmtAll ? $stmtAll->fetchAll(PDO::FETCH_COLUMN, 0) : [];
        $allIds = array_values(array_map('intval', $allIds));

        if (empty($allIds)) {
            throw new InvalidArgumentException('admin_podcast_category_not_found');
        }

        $remaining = array_values(array_filter($allIds, static function($id) use ($orderIds) {
            return !in_array((int)$id, $orderIds, true);
        }));
        $finalOrder = array_merge($orderIds, $remaining);

        $sortVal = 10;
        $update = $db->prepare('UPDATE i_podcast_categories SET sort_order = :sort_order, updated_at = :updated_at WHERE id = :id LIMIT 1');
        foreach ($finalOrder as $cid) {
            $update->bindValue(':sort_order', $sortVal, PDO::PARAM_INT);
            $update->bindValue(':updated_at', $now, PDO::PARAM_INT);
            $update->bindValue(':id', (int)$cid, PDO::PARAM_INT);
            $update->execute();
            $sortVal += 10;
        }

        echo json_encode(['status' => 'success', 'message' => 'admin_saved']);
        exit;
    }

    $names = [];
    $nameInput = $_POST['name'] ?? '';
    if (is_array($nameInput)) {
        foreach ($nameInput as $langCode => $value) {
            $lng = strtolower(trim((string) $langCode));
            if ($lng === '' || !in_array($lng, $availableLanguages, true)) {
                continue;
            }
            $val = trim((string) $value);
            if (mb_strlen($val) > 120) {
                $val = mb_substr($val, 0, 120);
            }
            $names[$lng] = $val;
        }
    } else {
        $val = trim((string) $nameInput);
        if (mb_strlen($val) > 120) {
            $val = mb_substr($val, 0, 120);
        }
        $names[$defaultLang] = $val;
    }

    $primaryName = $names[$defaultLang] ?? '';
    if ($primaryName === '') {
        foreach ($names as $candidate) {
            if (trim((string) $candidate) !== '') {
                $primaryName = trim((string) $candidate);
                $names[$defaultLang] = $primaryName;
                break;
            }
        }
    }

    if ($primaryName === '' || mb_strlen($primaryName) > 120) {
        throw new InvalidArgumentException('admin_podcast_category_invalid_name');
    }

    $slugInput = isset($_POST['slug']) ? trim((string) $_POST['slug']) : '';
    $slug = $slugInput !== '' ? $makeSlug($slugInput) : $makeSlug($primaryName);
    if ($slug === '' || mb_strlen($slug) > 160) {
        throw new InvalidArgumentException('admin_podcast_category_invalid_slug');
    }

    $sortRaw = isset($_POST['sort_order']) ? trim((string) $_POST['sort_order']) : '0';
    $sortOrder = filter_var($sortRaw, FILTER_VALIDATE_INT);
    if ($sortOrder === false || $sortOrder < -1000000 || $sortOrder > 1000000) {
        throw new InvalidArgumentException('admin_podcast_category_invalid_sort');
    }

    $status = $normalizeStatus((string) ($_POST['status'] ?? 'active'));

    $syncTranslations = static function (int $categoryId, array $nameMap, PDO $dbConn, int $timestamp): void {
        if ($categoryId <= 0) {
            return;
        }
        try {
            $del = $dbConn->prepare('DELETE FROM i_podcast_category_translations WHERE category_id = :cid');
            $del->bindValue(':cid', $categoryId, PDO::PARAM_INT);
            $del->execute();
        } catch (Throwable $__) {
            // ignore
        }

        try {
            $ins = $dbConn->prepare('INSERT INTO i_podcast_category_translations (category_id, language, name, created_at, updated_at)
                VALUES (:cid, :lang, :name, :created, :updated)
                ON DUPLICATE KEY UPDATE name = VALUES(name), updated_at = VALUES(updated_at)');
            foreach ($nameMap as $lng => $val) {
                $language = strtolower(trim((string) $lng));
                $value = trim((string) $val);
                if ($language === '' || $value === '') {
                    continue;
                }
                if (mb_strlen($value) > 120) {
                    $value = mb_substr($value, 0, 120);
                }
                $ins->bindValue(':cid', $categoryId, PDO::PARAM_INT);
                $ins->bindValue(':lang', $language, PDO::PARAM_STR);
                $ins->bindValue(':name', $value, PDO::PARAM_STR);
                $ins->bindValue(':created', $timestamp, PDO::PARAM_INT);
                $ins->bindValue(':updated', $timestamp, PDO::PARAM_INT);
                $ins->execute();
            }
        } catch (Throwable $__) {
            // ignore translation sync failures
        }
    };

    $excludeId = 0;
    if ($action === 'update') {
        $excludeId = isset($_POST['category_id']) ? (int) $_POST['category_id'] : 0;
        if ($excludeId <= 0) {
            throw new InvalidArgumentException('admin_podcast_category_not_found');
        }
    }

    $slugCheckSql = 'SELECT id FROM i_podcast_categories WHERE slug = :slug';
    if ($excludeId > 0) {
        $slugCheckSql .= ' AND id != :exclude_id';
    }
    $slugCheckSql .= ' LIMIT 1';

    $slugStmt = $db->prepare($slugCheckSql);
    $slugStmt->bindValue(':slug', $slug, PDO::PARAM_STR);
    if ($excludeId > 0) {
        $slugStmt->bindValue(':exclude_id', $excludeId, PDO::PARAM_INT);
    }
    $slugStmt->execute();
    if ($slugStmt->fetchColumn() !== false) {
        throw new InvalidArgumentException('admin_podcast_category_slug_exists');
    }

    if ($action === 'update') {
        $existing = $db->prepare('SELECT id FROM i_podcast_categories WHERE id = :id LIMIT 1');
        $existing->bindValue(':id', $excludeId, PDO::PARAM_INT);
        $existing->execute();
        if ($existing->fetchColumn() === false) {
            throw new InvalidArgumentException('admin_podcast_category_not_found');
        }

        $update = $db->prepare('UPDATE i_podcast_categories SET name = :name, slug = :slug, status = :status, sort_order = :sort_order, updated_at = :updated_at WHERE id = :id LIMIT 1');
        $update->bindValue(':name', $primaryName, PDO::PARAM_STR);
        $update->bindValue(':slug', $slug, PDO::PARAM_STR);
        $update->bindValue(':status', $status, PDO::PARAM_STR);
        $update->bindValue(':sort_order', (int) $sortOrder, PDO::PARAM_INT);
        $update->bindValue(':updated_at', $now, PDO::PARAM_INT);
        $update->bindValue(':id', $excludeId, PDO::PARAM_INT);
        $update->execute();

        $syncTranslations($excludeId, $names, $db, $now);

        echo json_encode(['status' => 'success', 'message' => 'admin_podcast_category_saved', 'id' => $excludeId]);
        exit;
    }

    $insert = $db->prepare('INSERT INTO i_podcast_categories (name, slug, status, sort_order, created_at, updated_at) VALUES (:name, :slug, :status, :sort_order, :created_at, :updated_at)');
    $insert->bindValue(':name', $primaryName, PDO::PARAM_STR);
    $insert->bindValue(':slug', $slug, PDO::PARAM_STR);
    $insert->bindValue(':status', $status, PDO::PARAM_STR);
    $insert->bindValue(':sort_order', (int) $sortOrder, PDO::PARAM_INT);
    $insert->bindValue(':created_at', $now, PDO::PARAM_INT);
    $insert->bindValue(':updated_at', $now, PDO::PARAM_INT);
    $insert->execute();

    $newId = (int) $db->lastInsertId();
    if ($newId > 0) {
        $syncTranslations($newId, $names, $db, $now);
    }

    echo json_encode(['status' => 'success', 'message' => 'admin_podcast_category_saved', 'id' => $newId]);
    exit;
} catch (InvalidArgumentException $e) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    exit;
} catch (Throwable $e) {
    if (function_exists('logErrorToFile')) {
        logErrorToFile('podcast_categories_admin: ' . $e->getMessage());
    }
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}
