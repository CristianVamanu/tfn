<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $ADM, $userData;

header('Content-Type: application/json; charset=utf-8');
$respond = static function (bool $ok, string $message, array $extra = [], int $http = 200): void {
    http_response_code($http);
    echo json_encode(array_merge(['status' => $ok ? 'success' : 'error', 'message' => $message], $extra), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
};

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $respond(false, 'Method not allowed.', [], 405);
}
if (!checkCsrfToken((string)($_POST['csrf_token'] ?? ''))) {
    $respond(false, 'Invalid security token.', [], 403);
}
if (!admin_has_permission('content.edit')) {
    $respond(false, 'You do not have permission to manage Audio Rooms.', [], 403);
}

$action = strtolower(trim((string)($_POST['audio_room_action'] ?? '')));
$roomId = max(0, (int)($_POST['room_id'] ?? 0));
$reason = trim((string)($_POST['reason'] ?? ''));
$adminId = (int)($userData['user_id'] ?? 0);
if ($action !== 'close') {
    $respond(false, 'Invalid action.', [], 422);
}

$result = $ADM->ADM_CloseAudioRoom($roomId, $adminId, $reason);
if (!empty($result['ok'])) {
    $respond(true, 'Audio Room closed.', $result);
}

$code = (string)($result['code'] ?? 'server_error');
$messages = [
    'invalid_request' => ['Invalid room request.', 422],
    'invalid_reason' => ['Enter a reason between 3 and 255 characters.', 422],
    'not_found' => ['Audio Room not found.', 404],
    'already_closed' => ['This Audio Room has already ended.', 409],
    'server_error' => ['The Audio Room could not be closed.', 500],
];
[$message, $http] = $messages[$code] ?? $messages['server_error'];
$respond(false, $message, ['code' => $code], $http);
