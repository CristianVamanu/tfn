<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

if ($loggedIn !== '1') {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

echo json_encode([
    'status' => 'error',
    'message' => 'storage_sync_not_available',
]);
