<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php'; // Centralized admin guard
header('Content-Type: application/json; charset=utf-8');

// CSRF
$csrf = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$action = isset($_POST['action']) ? strtolower(trim((string)$_POST['action'])) : '';

// Minimal password re-auth: verify user password
$password = isset($_POST['password']) ? (string)$_POST['password'] : '';
$reauthOk = (isset($_SESSION['reauth_ok_until']) && (int)$_SESSION['reauth_ok_until'] > time());

try {
    $uid = (int)$userData['user_id'];
    $st = $db->prepare('SELECT user_password FROM i_users WHERE user_id = :uid LIMIT 1');
    $st->execute([':uid' => $uid]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    $hash = is_array($row) ? (string)($row['user_password'] ?? '') : '';
    $pwOk = ($password !== '' && $hash !== '' && password_verify($password, $hash));

    if ($action === 'reauth') {
        if (!$pwOk) {
            http_response_code(401);
            echo json_encode(['status' => 'error', 'message' => 'invalid_password']);
            exit;
        }
        $_SESSION['reauth_ok_until'] = time() + 300; // 5 minutes
        echo json_encode(['status' => 'success']);
        exit;
    }

    if ($action === 'update') {
        if (!$pwOk && !$reauthOk) {
            http_response_code(401);
            echo json_encode(['status' => 'error', 'message' => 'reauth_required']);
            exit;
        }

        // Validation: ASCII visible only, length <= 191, trimmed. Return null to keep existing secret.
        $sentinelMasks = [
            '********',
            '••••••••',
            '••••••••••••',
        ];
        $filterSecret = function ($v) use ($sentinelMasks): ?string {
            $v = trim((string)$v);
            if ($v === '') {
                return null;
            }
            if (in_array($v, $sentinelMasks, true)) {
                return null;
            }
            if (strpos($v, '•') !== false) {
                return null;
            }
            if (strlen($v) > 191) {
                throw new InvalidArgumentException('too_long');
            }
            if (!preg_match('/^[\x21-\x7E]+$/', $v)) {
                throw new InvalidArgumentException('invalid_chars');
            }
            return $v;
        };
        // Normalize checkbox-like inputs to '0' | '1'
        $filterFlag = function ($v): string {
            $v = strtolower(trim((string)$v));
            return in_array($v, ['1','true','on','yes','open'], true) ? 'open' : 'close';
        };

        $siteConfigColumns = [];
        if (isset($siteData) && is_array($siteData)) {
            $siteConfigColumns = array_fill_keys(array_keys($siteData), true);
        }
        // Allow new currency formatting columns even if not yet present in cached config
        $siteConfigColumns['currency_symbol_position'] = true;
        $siteConfigColumns['currency_decimal_places'] = true;
        $siteConfigColumns['currency_thousands_sep'] = true;
        $siteConfigColumns['currency_decimal_sep'] = true;
        $allowColumn = static function (string $column) use ($siteConfigColumns): bool {
            return isset($siteConfigColumns[$column]);
        };

        $currencyMap = [];
        if (isset($currencies) && is_array($currencies) && $currencies) {
            $currencyMap = $currencies;
        } elseif (isset($currencys) && is_array($currencys) && $currencys) {
            $currencyMap = $currencys;
        } else {
            $currencyFile = dirname(__DIR__, 2) . '/includes/currencies.php';
            if (is_file($currencyFile)) {
                require_once $currencyFile;
            }
            if (isset($currencys) && is_array($currencys)) {
                $currencyMap = $currencys;
            }
        }
        $allowedCurrencies = [];
        foreach ($currencyMap as $code => $__) {
            $code = strtoupper(trim((string) $code));
            if ($code !== '') {
                $allowedCurrencies[$code] = true;
            }
        }
        $normalizeCurrency = static function ($raw) use ($allowedCurrencies): ?string {
            $code = strtoupper(trim((string) $raw));
            if ($code === '') {
                return null;
            }
            return isset($allowedCurrencies[$code]) ? $code : null;
        };

        $update = [];
        // Provider statuses (enum open/close)
        if (isset($_POST['stripe_status']) && $allowColumn('stripe_status')) {
            $update['stripe_status'] = $filterFlag($_POST['stripe_status']);
        }
        if (isset($_POST['paypal_status']) && $allowColumn('paypal_status')) {
            $update['paypal_status'] = $filterFlag($_POST['paypal_status']);
        }
        if (isset($_POST['nowpayment_status']) && $allowColumn('nowpayment_status')) {
            $update['nowpayment_status'] = $filterFlag($_POST['nowpayment_status']);
        }
        if (isset($_POST['coinbase_status']) && $allowColumn('coinbase_status')) {
            $update['coinbase_status'] = $filterFlag($_POST['coinbase_status']);
        }
        if (isset($_POST['flutterwave_status']) && $allowColumn('flutterwave_status')) {
            $update['flutterwave_status'] = $filterFlag($_POST['flutterwave_status']);
        }
        if (isset($_POST['paystack_status']) && $allowColumn('paystack_status')) {
            $update['paystack_status'] = $filterFlag($_POST['paystack_status']);
        }
        if (isset($_POST['iyzico_status']) && $allowColumn('iyzico_status')) {
            $update['iyzico_status'] = $filterFlag($_POST['iyzico_status']);
        }
        if (isset($_POST['payu_status']) && $allowColumn('payu_status')) {
            $update['payu_status'] = $filterFlag($_POST['payu_status']);
        }
        if (isset($_POST['wallet_topup_status']) && $allowColumn('wallet_topup_status')) {
            $update['wallet_topup_status'] = $filterFlag($_POST['wallet_topup_status']);
        }

        $parseAmount = static function ($value): float {
            $raw = trim((string)$value);
            if ($raw === '') {
                throw new InvalidArgumentException('empty');
            }
            if (!preg_match('/^(?:\d+)(?:\.\d{1,2})?$/', $raw)) {
                throw new InvalidArgumentException('format');
            }
            $amount = round((float)$raw, 2);
            return $amount;
        };

        if ($allowColumn('wallet_topup_minimum') && $allowColumn('wallet_topup_maximum') && (isset($_POST['wallet_topup_minimum']) || isset($_POST['wallet_topup_maximum']))) {
            if (!isset($_POST['wallet_topup_minimum'], $_POST['wallet_topup_maximum'])) {
                http_response_code(422);
                echo json_encode(['status' => 'error', 'message' => 'invalid_wallet_limits']);
                exit;
            }
            try {
                $walletMin = $parseAmount($_POST['wallet_topup_minimum']);
                $walletMax = $parseAmount($_POST['wallet_topup_maximum']);
            } catch (Throwable $__) {
                http_response_code(422);
                echo json_encode(['status' => 'error', 'message' => 'invalid_wallet_limits']);
                exit;
            }

            if ($walletMin < 1.0 || $walletMax < $walletMin) {
                http_response_code(422);
                echo json_encode(['status' => 'error', 'message' => 'invalid_wallet_limits']);
                exit;
            }

            $update['wallet_topup_minimum'] = number_format($walletMin, 2, '.', '');
            $update['wallet_topup_maximum'] = number_format($walletMax, 2, '.', '');
        }
        // Currency formatting
        if (isset($_POST['currency_symbol_position']) && $allowColumn('currency_symbol_position')) {
            $raw = strtolower(trim((string)$_POST['currency_symbol_position']));
            $pos = in_array($raw, ['left','right','left_space','right_space'], true) ? $raw : 'left';
            $update['currency_symbol_position'] = $pos;
        }
        if (isset($_POST['currency_decimal_places']) && $allowColumn('currency_decimal_places')) {
            $places = (int) $_POST['currency_decimal_places'];
            if ($places < 0) { $places = 0; }
            if ($places > 8) { $places = 8; }
            $update['currency_decimal_places'] = $places;
        }
        $postedThousands = null;
        if (isset($_POST['currency_thousands_sep']) && $allowColumn('currency_thousands_sep')) {
            $val = strtolower(trim((string)$_POST['currency_thousands_sep']));
            $map = [
                'comma' => ',',
                ','     => ',',
                'dot'   => '.',
                '.'     => '.',
                'space' => ' ',
                ' '     => ' ',
                'none'  => '',
                ''      => '',
            ];
            $postedThousands = $map[$val] ?? ',';
        }
        $postedDecimal = null;
        if (isset($_POST['currency_decimal_sep']) && $allowColumn('currency_decimal_sep')) {
            $val = strtolower(trim((string)$_POST['currency_decimal_sep']));
            $postedDecimal = ($val === 'comma' || $val === ',') ? ',' : '.';
        }
        if ($postedDecimal !== null) {
            $update['currency_decimal_sep'] = $postedDecimal;
        }
        if ($postedThousands !== null) {
            if ($postedDecimal !== null && $postedThousands === $postedDecimal) {
                $postedThousands = '';
            }
            $update['currency_thousands_sep'] = $postedThousands;
        }
        if (isset($_POST['payments_currency']) && $allowColumn('payments_currency')) {
            $code = $normalizeCurrency($_POST['payments_currency']);
            if ($code !== null) {
                $update['payments_currency'] = $code;
            }
        }
        // Stripe
        if (isset($_POST['stripe_secret']) && $allowColumn('stripe_secret')) {
            try {
                $val = $filterSecret($_POST['stripe_secret']);
                if ($val !== null) { $update['stripe_secret'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['stripe_webhook_secret']) && $allowColumn('stripe_webhook_secret')) {
            try {
                $val = $filterSecret($_POST['stripe_webhook_secret']);
                if ($val !== null) { $update['stripe_webhook_secret'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['stripe_currency']) && $allowColumn('stripe_currency')) {
            $code = $normalizeCurrency($_POST['stripe_currency']);
            if ($code !== null) {
                $update['stripe_currency'] = $code;
            }
        }
        // PayPal
        if (isset($_POST['paypal_client_id']) && $allowColumn('paypal_client_id')) {
            try {
                $val = $filterSecret($_POST['paypal_client_id']);
                if ($val !== null) { $update['paypal_client_id'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['paypal_client_secret']) && $allowColumn('paypal_client_secret')) {
            try {
                $val = $filterSecret($_POST['paypal_client_secret']);
                if ($val !== null) { $update['paypal_client_secret'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['paypal_webhook_id']) && $allowColumn('paypal_webhook_id')) {
            try {
                $val = $filterSecret($_POST['paypal_webhook_id']);
                if ($val !== null) { $update['paypal_webhook_id'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['paypal_env']) && $allowColumn('paypal_env')) {
            $env = strtolower(trim((string)$_POST['paypal_env']));
            if (!in_array($env, ['sandbox','live'], true)) { $env = 'sandbox'; }
            $update['paypal_env'] = $env;
        }
        if (isset($_POST['paypal_currency']) && $allowColumn('paypal_currency')) {
            $code = $normalizeCurrency($_POST['paypal_currency']);
            if ($code !== null) {
                $update['paypal_currency'] = $code;
            }
        }
        // NOWPayments
        if (isset($_POST['nowpayments_api_key']) && $allowColumn('nowpayments_api_key')) {
            try {
                $val = $filterSecret($_POST['nowpayments_api_key']);
                if ($val !== null) { $update['nowpayments_api_key'] = $val; }
            } catch (Throwable $__) {}
        }
        if ($allowColumn('nowpayment_webhook_secret_key')) {
            $postedNowWebhook = null;
            if (isset($_POST['nowpayment_webhook_secret_key'])) {
                $postedNowWebhook = $_POST['nowpayment_webhook_secret_key'];
            } elseif (isset($_POST['nowpayments_webhook_secret'])) {
                // Backward compatibility with legacy field name
                $postedNowWebhook = $_POST['nowpayments_webhook_secret'];
            }
            if ($postedNowWebhook !== null) {
                try {
                    $val = $filterSecret($postedNowWebhook);
                    if ($val !== null) { $update['nowpayment_webhook_secret_key'] = $val; }
                } catch (Throwable $__) {}
            }
        } elseif (isset($_POST['nowpayments_webhook_secret']) && $allowColumn('nowpayments_webhook_secret')) {
            // Legacy column fallback (pre-migration)
            try {
                $val = $filterSecret($_POST['nowpayments_webhook_secret']);
                if ($val !== null) { $update['nowpayments_webhook_secret'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['now_payment_currency']) && $allowColumn('now_payment_currency')) {
            $code = $normalizeCurrency($_POST['now_payment_currency']);
            if ($code !== null) {
                $update['now_payment_currency'] = $code;
            }
        }
        // Coinbase Commerce
        if (isset($_POST['coinbase_commerce_api_key']) && $allowColumn('coinbase_commerce_api_key')) {
            try {
                $val = $filterSecret($_POST['coinbase_commerce_api_key']);
                if ($val !== null) { $update['coinbase_commerce_api_key'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['coinbase_commerce_webhook_secret']) && $allowColumn('coinbase_commerce_webhook_secret')) {
            try {
                $val = $filterSecret($_POST['coinbase_commerce_webhook_secret']);
                if ($val !== null) { $update['coinbase_commerce_webhook_secret'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['coinbase_currency']) && $allowColumn('coinbase_currency')) {
            $code = $normalizeCurrency($_POST['coinbase_currency']);
            if ($code !== null) {
                $update['coinbase_currency'] = $code;
            }
        }
        // Paystack
        if (isset($_POST['paystack_public_key']) && $allowColumn('paystack_public_key')) {
            try {
                $val = $filterSecret($_POST['paystack_public_key']);
                if ($val !== null) { $update['paystack_public_key'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['paystack_secret_key']) && $allowColumn('paystack_secret_key')) {
            try {
                $val = $filterSecret($_POST['paystack_secret_key']);
                if ($val !== null) { $update['paystack_secret_key'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['paystack_webhook_secret']) && $allowColumn('paystack_webhook_secret')) {
            try {
                $val = $filterSecret($_POST['paystack_webhook_secret']);
                if ($val !== null) { $update['paystack_webhook_secret'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['paystack_currency']) && $allowColumn('paystack_currency')) {
            $raw = trim((string)$_POST['paystack_currency']);
            if ($raw === '') {
                $update['paystack_currency'] = null;
            } else {
                $code = $normalizeCurrency($raw);
                if ($code !== null) {
                    $update['paystack_currency'] = $code;
                }
            }
        }
        if (isset($_POST['paystack_merchant_email']) && $allowColumn('paystack_merchant_email')) {
            $val = trim((string)$_POST['paystack_merchant_email']);
            if ($val !== '') {
                if (strlen($val) > 191) {
                    throw new InvalidArgumentException('too_long');
                }
                $update['paystack_merchant_email'] = $val;
            }
        }

        // PayU
        if (isset($_POST['payu_merchant_pos_id']) && $allowColumn('payu_merchant_pos_id')) {
            $val = trim((string)$_POST['payu_merchant_pos_id']);
            if ($val !== '') {
                if (strlen($val) > 191) { throw new InvalidArgumentException('too_long'); }
                $update['payu_merchant_pos_id'] = $val;
            }
        }
        if (isset($_POST['payu_merchant_id']) && $allowColumn('payu_merchant_id')) {
            $val = trim((string)$_POST['payu_merchant_id']);
            if ($val !== '') {
                if (strlen($val) > 191) { throw new InvalidArgumentException('too_long'); }
                $update['payu_merchant_id'] = $val;
            }
        }
        if (isset($_POST['payu_client_id']) && $allowColumn('payu_client_id')) {
            try {
                $val = $filterSecret($_POST['payu_client_id']);
                if ($val !== null) { $update['payu_client_id'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['payu_client_secret']) && $allowColumn('payu_client_secret')) {
            try {
                $val = $filterSecret($_POST['payu_client_secret']);
                if ($val !== null) { $update['payu_client_secret'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['payu_signature_key']) && $allowColumn('payu_signature_key')) {
            try {
                $val = $filterSecret($_POST['payu_signature_key']);
                if ($val !== null) { $update['payu_signature_key'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['payu_currency']) && $allowColumn('payu_currency')) {
            $raw = trim((string)$_POST['payu_currency']);
            if ($raw === '') {
                $update['payu_currency'] = null;
            } else {
                $code = $normalizeCurrency($raw);
                if ($code !== null) {
                    $update['payu_currency'] = $code;
                }
            }
        }
        if (isset($_POST['payu_api_base']) && $allowColumn('payu_api_base')) {
            $val = trim((string) $_POST['payu_api_base']);
            if ($val !== '') {
                if (strlen($val) > 191) { throw new InvalidArgumentException('too_long'); }
                $update['payu_api_base'] = $val;
            }
        }

        // IyziCo
        if (isset($_POST['iyzico_api_key']) && $allowColumn('iyzico_api_key')) {
            try {
                $val = $filterSecret($_POST['iyzico_api_key']);
                if ($val !== null) { $update['iyzico_api_key'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['iyzico_secret_key']) && $allowColumn('iyzico_secret_key')) {
            try {
                $val = $filterSecret($_POST['iyzico_secret_key']);
                if ($val !== null) { $update['iyzico_secret_key'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['iyzico_webhook_secret']) && $allowColumn('iyzico_webhook_secret')) {
            try {
                $val = $filterSecret($_POST['iyzico_webhook_secret']);
                if ($val !== null) { $update['iyzico_webhook_secret'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['iyzico_currency']) && $allowColumn('iyzico_currency')) {
            $raw = trim((string)$_POST['iyzico_currency']);
            if ($raw === '') {
                $update['iyzico_currency'] = null;
            } else {
                $code = $normalizeCurrency($raw);
                if ($code !== null) {
                    $update['iyzico_currency'] = $code;
                }
            }
        }
        if (isset($_POST['iyzico_api_base']) && $allowColumn('iyzico_api_base')) {
            $val = trim((string) $_POST['iyzico_api_base']);
            if ($val !== '') {
                if (strlen($val) > 191) { throw new InvalidArgumentException('too_long'); }
                $update['iyzico_api_base'] = $val;
            }
        }

        // Flutterwave
        if (isset($_POST['flutterwave_public_key']) && $allowColumn('flutterwave_public_key')) {
            try {
                $val = $filterSecret($_POST['flutterwave_public_key']);
                if ($val !== null) { $update['flutterwave_public_key'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['flutterwave_secret_key']) && $allowColumn('flutterwave_secret_key')) {
            try {
                $val = $filterSecret($_POST['flutterwave_secret_key']);
                if ($val !== null) { $update['flutterwave_secret_key'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['flutterwave_encryption_key']) && $allowColumn('flutterwave_encryption_key')) {
            try {
                $val = $filterSecret($_POST['flutterwave_encryption_key']);
                if ($val !== null) { $update['flutterwave_encryption_key'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['flutterwave_secret_hash']) && $allowColumn('flutterwave_secret_hash')) {
            try {
                $val = $filterSecret($_POST['flutterwave_secret_hash']);
                if ($val !== null) { $update['flutterwave_secret_hash'] = $val; }
            } catch (Throwable $__) {}
        }
        if (isset($_POST['flutterwave_currency']) && $allowColumn('flutterwave_currency')) {
            $raw = trim((string)$_POST['flutterwave_currency']);
            if ($raw === '') {
                $update['flutterwave_currency'] = null;
            } else {
                $code = $normalizeCurrency($raw);
                if ($code !== null) {
                    $update['flutterwave_currency'] = $code;
                }
            }
        }

        if (!empty($update)) {
            $set = [];
            $params = [];
            foreach ($update as $col => $val) {
                $set[] = "$col = :$col";
                $params[":$col"] = ($val === '') ? null : $val;
            }
            $params[':id'] = 1;
            $sql = 'UPDATE i_site_configurations SET ' . implode(', ', $set) . ' WHERE id = :id';
            $up = $db->prepare($sql);
            $up->execute($params);

            // Audit trail (no secret values)
            try {
                $db->exec("CREATE TABLE IF NOT EXISTS i_admin_audit (
                    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    user_id INT UNSIGNED NOT NULL,
                    action VARCHAR(64) NOT NULL,
                    target_key VARCHAR(64) NOT NULL,
                    created_at INT UNSIGNED NOT NULL,
                    PRIMARY KEY (id),
                    KEY idx_user_time (user_id, created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            } catch (Throwable $__) {}
            try {
                $au = $db->prepare('INSERT INTO i_admin_audit (user_id, action, target_key, created_at) VALUES (:u,:a,:t,:c)');
                foreach ($update as $k => $v) {
                    $au->execute([':u' => $uid, ':a' => 'update_payment_config', ':t' => $k, ':c' => time()]);
                }
            } catch (Throwable $__) {}
        }

        echo json_encode(['status' => 'success']);
        exit;
    }

    if ($action === 'update_currency_format') {
        // Allow saving only currency formatting without password re-auth.
        $siteConfigColumns = [];
        if (isset($siteData) && is_array($siteData)) {
            $siteConfigColumns = array_fill_keys(array_keys($siteData), true);
        }
        $siteConfigColumns['currency_symbol_position'] = true;
        $siteConfigColumns['currency_decimal_places'] = true;
        $siteConfigColumns['currency_thousands_sep'] = true;
        $siteConfigColumns['currency_decimal_sep'] = true;
        $allowColumn = static function (string $column) use ($siteConfigColumns): bool {
            return isset($siteConfigColumns[$column]);
        };
        $update = [];
        if ($allowColumn('currency_symbol_position')) {
            $raw = isset($_POST['currency_symbol_position']) ? strtolower(trim((string) $_POST['currency_symbol_position'])) : '';
            $update['currency_symbol_position'] = in_array($raw, ['left','right','left_space','right_space'], true) ? $raw : 'left';
        }
        if ($allowColumn('currency_decimal_places')) {
            $places = isset($_POST['currency_decimal_places']) ? (int) $_POST['currency_decimal_places'] : 2;
            if ($places < 0) { $places = 0; }
            if ($places > 8) { $places = 8; }
            $update['currency_decimal_places'] = $places;
        }
        if ($allowColumn('currency_decimal_sep')) {
            $val = isset($_POST['currency_decimal_sep']) ? strtolower(trim((string) $_POST['currency_decimal_sep'])) : '';
            $update['currency_decimal_sep'] = ($val === 'comma' || $val === ',') ? ',' : '.';
        }
        if ($allowColumn('currency_thousands_sep')) {
            $val = isset($_POST['currency_thousands_sep']) ? strtolower(trim((string) $_POST['currency_thousands_sep'])) : '';
            $map = [
                'comma' => ',',
                ','     => ',',
                'dot'   => '.',
                '.'     => '.',
                'space' => ' ',
                ' '     => ' ',
                'none'  => '',
                ''      => '',
            ];
            $thousands = $map[$val] ?? ',';
            if (isset($update['currency_decimal_sep']) && $thousands === $update['currency_decimal_sep']) {
                $thousands = '';
            }
            $update['currency_thousands_sep'] = $thousands;
        }

        if (!empty($update)) {
            $set = [];
            $params = [];
            foreach ($update as $col => $val) {
                $set[] = "$col = :$col";
                $params[":$col"] = ($val === '') ? null : $val;
            }
            $params[':id'] = 1;
            $sql = 'UPDATE i_site_configurations SET ' . implode(', ', $set) . ' WHERE id = :id';
            $up = $db->prepare($sql);
            $up->execute($params);
        }

        echo json_encode(['status' => 'success']);
        exit;
    }

    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'bad_action']);
    exit;
} catch (Throwable $e) {
    error_log('admin/payment_settings.php failed: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    error_log($e->getTraceAsString());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}
