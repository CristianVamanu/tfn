<?php
declare(strict_types=1);
require_once __DIR__ . '/../_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

global $RL, $ADM, $userData;

// CSRF
$csrf = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
  http_response_code(403);
  echo json_encode(['status'=>'error','message'=>'invalid_csrf']);
  exit;
}

if (!admin_has_permission('content.edit')) {
  admin_forbidden_json();
}

$pid = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;
if ($pid <= 0) {
  http_response_code(400);
  echo json_encode(['status'=>'error','message'=>'bad_post']);
  exit;
}

$okAll = true;
$notice = '';

try {
  // Load current post for context
  $cur = ($RL && method_exists($RL, 'RL_GetPostData')) ? ($RL->RL_GetPostData($pid) ?: []) : [];
  $curType = (string)($cur['post_type'] ?? '');
  $curVis  = (string)($cur['post_visibility'] ?? '');

  // Delete selected media
  if (!empty($_POST['delete_media']) && is_array($_POST['delete_media'])) {
    foreach ($_POST['delete_media'] as $mpath) {
      if ($RL && method_exists($RL, 'RL_DeletePostMediaPath')) {
        $ok = (bool)$RL->RL_DeletePostMediaPath($pid, (string)$mpath);
        $okAll = $okAll && $ok;
      }
    }
  }

  // Reorder (images only)
  if (!empty($_POST['media_order']) && $curType === 'image') {
    $order = json_decode((string)$_POST['media_order'], true);
    if (is_array($order) && $RL && method_exists($RL, 'RL_ReorderImageMedia')) {
      $ok = (bool)$RL->RL_ReorderImageMedia($pid, $order);
      $okAll = $okAll && $ok;
    }
  }
  // Post text
  if (isset($_POST['post_text'])) {
    $txt = trim((string)$_POST['post_text']);
    if ($RL && method_exists($RL, 'RL_UpdatePostText')) {
      $ok = (bool)$RL->RL_UpdatePostText($pid, $txt);
      $okAll = $okAll && $ok;
    }
  }

  // Visibility + price
  $visibility = isset($_POST['visibility']) ? strtolower((string)$_POST['visibility']) : '';
  $price      = isset($_POST['price']) && $_POST['price'] !== '' ? (int)$_POST['price'] : null;
  $allowedVis = ['everyone','followers','subscribers','locked'];
  if ($visibility && in_array($visibility, $allowedVis, true)) {
    if ($visibility === 'locked') {
      // Apply visibility first
      if ($RL && method_exists($RL, 'RL_UpdatePostVisibility')) {
        $ok = (bool)$RL->RL_UpdatePostVisibility($pid, 'locked');
        $okAll = $okAll && $ok;
      }
      // Price optional; if provided and >0 set and keep locked
      if ($price !== null) {
        $minP = (int)($premiumPostPriceMinimum ?? 1);
        $maxP = (int)($premiumPostPriceMaximum ?? 500);
        $p    = (int)$price;
        if ($p < $minP || $p > $maxP) {
          http_response_code(400);
          echo json_encode(['status'=>'error','message'=>'PRICE_RANGE','min'=>$minP,'max'=>$maxP]);
          exit;
        }
        if ($RL && method_exists($RL, 'RL_UpdatePostPriceAndLock')) {
          $ok = (bool)$RL->RL_UpdatePostPriceAndLock($pid, $p);
          $okAll = $okAll && $ok;
        }
      }
    } else {
      // Non-locked: set visibility and clear price if any
      if ($RL && method_exists($RL, 'RL_UpdatePostVisibility')) {
        $ok = (bool)$RL->RL_UpdatePostVisibility($pid, $visibility);
        $okAll = $okAll && $ok;
      }
      if ($price !== null && $price > 0) {
        if ($RL && method_exists($RL, 'RL_ClearPostPrice')) { $RL->RL_ClearPostPrice($pid); }
        $notice = 'price_only_locked';
      }
    }
  }

  // Comments on/off
  if (isset($_POST['comment_status'])) {
    $cs = ((string)$_POST['comment_status']) === 'off' ? 'off' : 'on';
    if ($RL && method_exists($RL, 'RL_TogglePostCommentStatus')) {
      $ok = (bool)$RL->RL_TogglePostCommentStatus($pid, $cs);
      $okAll = $okAll && $ok;
    }
  }

  // Likes on/off
  if (isset($_POST['like_status'])) {
    $ls = ((string)$_POST['like_status']) === 'off' ? 'off' : 'on';
    if ($RL && method_exists($RL, 'RL_TogglePostLikeStatus')) {
      $ok = (bool)$RL->RL_TogglePostLikeStatus($pid, $ls);
      $okAll = $okAll && $ok;
    }
  }

  // Audit
  try { $ADM->ADM_Audit((int)($userData['user_id'] ?? 0), 'post_edit', 'post:' . $pid); } catch (\Throwable $__) {}

  if ($okAll) {
    $res = ['status'=>'success'];
    if ($notice) { $res['notice'] = $notice; }
    echo json_encode($res);
  } else {
    echo json_encode(['status'=>'error','message'=>'op_failed']);
  }
  exit;
} catch (\Throwable $e) {
  http_response_code(500);
  echo json_encode(['status'=>'error','message'=>'server_error']);
  exit;
}
