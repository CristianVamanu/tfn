<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

$csrf = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$providers = [
    'google' => [
        'status' => 'google_status',
        'id'     => 'google_client_id',
        'secret' => 'google_client_secret',
    ],
    'facebook' => [
        'status' => 'facebook_status',
        'id'     => 'facebook_app_id',
        'secret' => 'facebook_app_secret',
    ],
    'twitter' => [
        'status' => 'twitter_status',
        'id'     => 'twitter_client_id',
        'secret' => 'twitter_client_secret',
    ],
];

$filterFlag = static function ($raw): string {
    $raw = strtolower(trim((string)$raw));
    return $raw === 'open' ? 'open' : 'close';
};

$filterSecret = static function ($raw): string {
    $value = trim((string)$raw);
    if ($value === '') {
        return '';
    }
    if (strlen($value) > 191) {
        throw new InvalidArgumentException('too_long');
    }
    if (!preg_match('/^[\x20-\x7E]+$/', $value)) {
        throw new InvalidArgumentException('invalid_chars');
    }
    return $value;
};

$update = [];

try {
    foreach ($providers as $provider => $map) {
        if (isset($_POST[$map['status']])) {
            $update[$map['status']] = $filterFlag($_POST[$map['status']]);
        }
        if (array_key_exists($map['id'], $_POST)) {
            try {
                $value = $filterSecret($_POST[$map['id']]);
                $update[$map['id']] = $value === '' ? null : $value;
            } catch (InvalidArgumentException $__) {
                // Ignore masked placeholder values (e.g., ••••) to keep existing secret.
            }
        }
        if (array_key_exists($map['secret'], $_POST)) {
            try {
                $value = $filterSecret($_POST[$map['secret']]);
                $update[$map['secret']] = $value === '' ? null : $value;
            } catch (InvalidArgumentException $__) {
                // Ignore masked placeholder values (e.g., ••••) to keep existing secret.
            }
        }
    }

    if ($update !== []) {
        $parts = [];
        $params = [':id' => 1];
        foreach ($update as $column => $value) {
            $parts[] = "$column = :$column";
            $params[':' . $column] = $value;
        }
        $sql = 'UPDATE i_site_configurations SET ' . implode(', ', $parts) . ' WHERE id = :id';
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
    }

    echo json_encode(['status' => 'success']);
    exit;
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}
