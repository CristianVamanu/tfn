<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php'; // Centralized admin guard + $ADM
header('Content-Type: application/json; charset=utf-8');

$meId = (int)($userData['user_id'] ?? 0); // From inc.php

// CSRF
$csrf = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$action = isset($_POST['action']) ? (string)$_POST['action'] : '';
$pid    = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;

try {
    if ($pid <= 0) { throw new InvalidArgumentException('bad_post'); }

    $permMap = [
        'hide' => 'content.hide',
        'unhide' => 'content.hide',
        'delete' => 'content.delete',
    ];
    $permKey = $permMap[$action] ?? '';
    if ($permKey !== '' && !admin_has_permission($permKey)) {
        admin_forbidden_json();
    }

    $ok = false;
    if ($action === 'hide') {
        $ok = $ADM->ADM_HidePost($pid);
    } elseif ($action === 'unhide') {
        $ok = $ADM->ADM_UnhidePost($pid);
    } elseif ($action === 'delete') {
        $ok = $ADM->ADM_DeletePostCascade($pid);
    } else {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'bad_action']);
        exit;
    }

    if (!$ok) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'op_failed']);
        exit;
    }

    // Audit
    $ADM->ADM_Audit($meId, $action, 'post:' . $pid);

    echo json_encode(['status' => 'success']);
    exit;
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'bad_request']);
    exit;
}
