<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

$csrf = (string) ($_POST['csrf_token'] ?? '');
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$action = strtolower(trim((string) ($_POST['action'] ?? '')));
$adId = isset($_POST['ad_id']) ? (int) $_POST['ad_id'] : 0;
$adminId = isset($userData['user_id']) ? (int) $userData['user_id'] : 0;

if ($adId <= 0 || !in_array($action, ['approve', 'reject', 'delete'], true)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_request']);
    exit;
}

$adRow = $ADM->ADM_GetPodcastAdById($adId);
if (!$adRow) {
    http_response_code(404);
    echo json_encode(['status' => 'error', 'message' => 'not_found']);
    exit;
}

try {
    if ($action === 'delete') {
        $deleted = $ADM->ADM_DeletePodcastAd($adId);
        if ($deleted) {
            $ADM->ADM_NotifyPodcastAdStatus($adRow, 'deleted', $adminId);
        }
        echo json_encode([
            'status'  => $deleted ? 'success' : 'error',
            'message' => $deleted ? customLang('hero_ads_action_delete') : customLang('hero_ads_error', 'Failed.'),
            'state'   => 'deleted',
        ]);
        exit;
    }

    $targetStatus = $action === 'approve' ? 'approved' : 'rejected';
    $updated = $ADM->ADM_UpdatePodcastAdStatus($adId, $targetStatus, $adminId);
    $freshRow = $ADM->ADM_GetPodcastAdById($adId);
    $freshStatus = strtolower((string) ($freshRow['status'] ?? ''));
    $ok = $updated && $freshStatus === $targetStatus;
    if ($ok && $freshRow) {
        $ADM->ADM_NotifyPodcastAdStatus($freshRow, $targetStatus, $adminId);
    }

    echo json_encode([
        'status'  => $ok ? 'success' : 'error',
        'message' => $ok ? customLang('hero_ads_' . $targetStatus, ucfirst($targetStatus)) : customLang('hero_ads_error', 'Failed.'),
        'state'   => $freshStatus ?: $targetStatus,
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
}
