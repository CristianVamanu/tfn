<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php'; // Centralized admin guard + $ADM
header('Content-Type: application/json; charset=utf-8');

$meId = (int)($userData['user_id'] ?? 0); // From inc.php

// CSRF
$csrf = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$action   = isset($_POST['action']) ? (string)$_POST['action'] : (isset($_POST['bulk_action']) ? (string)$_POST['bulk_action'] : '');
$uid      = isset($_POST['user_id']) ? (int)$_POST['user_id'] : (isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0);
$userList = isset($_POST['user_ids']) && is_array($_POST['user_ids']) ? array_map('intval', (array)$_POST['user_ids']) : [];
// Role payload (for set_role)
$newRole  = isset($_POST['role']) ? (string)$_POST['role'] : '';

try {
    $allowed = ['ban','unban','delete','set_role'];
    if (!in_array($action, $allowed, true)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'bad_action']);
        exit;
    }

    $permMap = [
        'ban' => 'users.ban',
        'unban' => 'users.ban',
        'delete' => 'users.delete',
        'set_role' => 'users.set_role',
    ];
    $permKey = $permMap[$action] ?? '';
    if ($permKey !== '' && !admin_has_permission($permKey)) {
        admin_forbidden_json();
    }

    // Only admins (owner or user_type >= 3) can delete or set roles
    $myType = (int)($userData['user_type'] ?? 0);
    $isOwnerOrAdmin = (($userData['user_id'] ?? 0) === 1) || ($myType >= 3);
    if (in_array($action, ['delete','set_role'], true) && !$isOwnerOrAdmin) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'forbidden']);
        exit;
    }

    // Bulk path
    if (!empty($userList)) {
        $okCount = 0; $fail = [];
        foreach ($userList as $id) {
            if ($id <= 0 || $id === 1 || ($id === $meId && $action === 'ban')) { $fail[] = $id; continue; }
            $ok = ($action === 'ban') ? $ADM->ADM_BanUser($id) : $ADM->ADM_UnbanUser($id);
            if ($ok) { $okCount++; $ADM->ADM_Audit($meId, $action, 'user:' . $id); } else { $fail[] = $id; }
        }
        echo json_encode(['status'=>'success','updated'=>$okCount,'failed'=>$fail]);
        exit;
    }

    // Single path
    if ($uid <= 0) { throw new InvalidArgumentException('bad_user'); }
    if ($uid === 1) { throw new InvalidArgumentException('owner_protected'); }
    if ($uid === $meId && in_array($action, ['ban','delete'], true)) { throw new InvalidArgumentException('cannot_target_self'); }

    $ok = false;
    if ($action === 'ban') {
        $ok = $ADM->ADM_BanUser($uid);
    } elseif ($action === 'unban') {
        $ok = $ADM->ADM_UnbanUser($uid);
    } elseif ($action === 'delete') {
        $ok = $ADM->ADM_DeleteUserCascade($uid);
    } elseif ($action === 'set_role') {
        $role = strtolower(trim($newRole));
        // Disallow self-demotion: admin cannot set own role to moderator/user
        if ($uid === $meId && $role !== 'admin') {
            throw new InvalidArgumentException('self_role_forbidden');
        }
        $ok = $ADM->ADM_SetUserRole($uid, $role);
        if ($ok && admin_permission_column_exists($ADM->db())) {
            $permProvided = array_key_exists('permissions', $_POST);
            $permRaw = $permProvided ? $_POST['permissions'] : '';
            $permList = admin_normalize_permissions($permRaw);
            $permJson = null;
            if ($role === 'moderator') {
                $permJson = $permProvided
                    ? json_encode(array_values($permList), JSON_UNESCAPED_SLASHES)
                    : null;
            }
            $stmt = $ADM->db()->prepare('UPDATE i_users SET admin_permissions = :p WHERE user_id = :uid LIMIT 1');
            $stmt->bindValue(':uid', $uid, PDO::PARAM_INT);
            if ($permJson === null) {
                $stmt->bindValue(':p', null, PDO::PARAM_NULL);
            } else {
                $stmt->bindValue(':p', $permJson, PDO::PARAM_STR);
            }
            $stmt->execute();
        }
    }

    if (!$ok) { http_response_code(500); echo json_encode(['status'=>'error','message'=>'op_failed']); exit; }
    $ADM->ADM_Audit($meId, $action, 'user:' . $uid . ($action==='set_role' ? (':'.$newRole) : ''));
    echo json_encode(['status'=>'success','updated'=>1]);
    exit;
} catch (InvalidArgumentException $e) {
    // Surface specific, known validation failures (e.g., owner_protected)
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    exit;
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'bad_request']);
    exit;
}
