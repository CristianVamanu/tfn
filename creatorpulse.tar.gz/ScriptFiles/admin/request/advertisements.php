<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

$adminId = (int) ($userData['user_id'] ?? 0);

$csrf = (string) ($_POST['csrf_token'] ?? '');
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$action = strtolower(trim((string) ($_POST['action'] ?? '')));

if ($action === 'upload_images') {
    $adId = (int) ($_POST['ad_id'] ?? 0);
    if ($adId <= 0) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_target']);
        exit;
    }

    $adRow = $ADM->ADM_GetAdvertisementById($adId);
    if (!$adRow) {
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'invalid_target']);
        exit;
    }

    $mediaType = strtolower((string) ($adRow['media_type'] ?? ''));
    if ($mediaType !== 'image') {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_media_mode']);
        exit;
    }

    if (!isset($_FILES['images'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => customLang('no_image_uploaded')]);
        exit;
    }

    global $base_url, $availableUploadFileSize;

    try {
        $todayDir = date('Y-m-d');
        $projectRoot = dirname(__DIR__, 2);
        $absDir = $projectRoot . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'advertisement_ifiles' . DIRECTORY_SEPARATOR . $todayDir . DIRECTORY_SEPARATOR;
        if (!is_dir($absDir) && !@mkdir($absDir, 0755, true)) {
            throw new RuntimeException('dir_create_failed');
        }

        $relativePrefix = 'uploads/advertisement_ifiles/' . $todayDir . '/';
        $allowedMimes = ['image/jpeg', 'image/png'];
        $maxMb = isset($availableUploadFileSize) ? (float) $availableUploadFileSize : 5.0;
        if ($maxMb <= 0) { $maxMb = 5.0; }
        $maxMb = min($maxMb, 10.0);
        $maxBytes = (int) round($maxMb * 1048576);
        $finfo = function_exists('finfo_open') ? @finfo_open(FILEINFO_MIME_TYPE) : null;

        $saved = [];
        foreach ((array) ($_FILES['images']['tmp_name'] ?? []) as $idx => $tmpName) {
            $err = (int) ($_FILES['images']['error'][$idx] ?? UPLOAD_ERR_OK);
            $size = (int) ($_FILES['images']['size'][$idx] ?? 0);
            if ($err !== UPLOAD_ERR_OK || empty($tmpName) || !is_uploaded_file($tmpName)) {
                continue;
            }
            if ($size <= 0 || $size > $maxBytes) {
                continue;
            }

            $mime = '';
            if ($finfo) {
                $mime = (string) @finfo_file($finfo, $tmpName);
            } elseif (function_exists('mime_content_type')) {
                $mime = (string) @mime_content_type($tmpName);
            }
            if ($mime === '' || !in_array($mime, $allowedMimes, true)) {
                continue;
            }

            $info = @getimagesize($tmpName);
            if ($info === false) {
                continue;
            }
            $imgType = (int) ($info[2] ?? 0);
            if (!in_array($imgType, [IMAGETYPE_JPEG, IMAGETYPE_PNG], true)) {
                continue;
            }

            $gd = null;
            $outExt = 'jpg';
            if ($imgType === IMAGETYPE_JPEG) {
                $gd = @imagecreatefromjpeg($tmpName);
                $outExt = 'jpg';
            } elseif ($imgType === IMAGETYPE_PNG) {
                $gd = @imagecreatefrompng($tmpName);
                $outExt = 'png';
            }
            if (!$gd) {
                continue;
            }

            try {
                $rand = bin2hex(random_bytes(8));
            } catch (\Throwable $__) {
                $rand = str_replace('.', '', uniqid('ad_', true));
            }
            $fileName = 'adimg_' . $rand . '.' . $outExt;
            $dest = $absDir . $fileName;

            $ok = false;
            if ($outExt === 'jpg') {
                $ok = @imagejpeg($gd, $dest, 90);
            } else {
                @imagealphablending($gd, false);
                @imagesavealpha($gd, true);
                $ok = @imagepng($gd, $dest, 6);
            }
            @imagedestroy($gd);

            if (!$ok || !is_file($dest)) {
                continue;
            }

            $saved[] = $relativePrefix . $fileName;
        }

        if ($finfo) {
            @finfo_close($finfo);
        }

        if (empty($saved)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => customLang('upload_failed')]);
            exit;
        }

        $base = rtrim((string) $base_url, '/');
        $items = [];
        foreach ($saved as $path) {
            $items[] = [
                'path' => $path,
                'url'  => $base . '/' . ltrim($path, '/'),
            ];
        }

        // Persist new media paths on the advertisement
        try {
            $adRow = $ADM->ADM_GetAdvertisementById($adId);
            if ($adRow) {
                $existingRaw = trim((string) ($adRow['ad_media'] ?? ''));
                $existing = [];
                if ($existingRaw !== '') {
                    foreach (explode(',', $existingRaw) as $piece) {
                        $piece = trim(str_replace('\\', '/', (string) $piece));
                        if ($piece !== '') {
                            $existing[] = trim($piece, '/');
                        }
                    }
                }
                $merge = $existing;
                foreach ($saved as $pathValue) {
                    $normalized = trim(str_replace('\\', '/', (string) $pathValue));
                    $normalized = trim($normalized, '/');
                    if ($normalized === '') { continue; }
                    if (!in_array($normalized, $merge, true)) {
                        $merge[] = $normalized;
                    }
                }
                $ADM->ADM_UpdateAdvertisement($adId, ['ad_media' => implode(',', $merge)]);
            }
        } catch (\Throwable $__) { /* ignore */ }

        echo json_encode([
            'status'      => 'success',
            'media_paths' => $saved,
            'items'       => $items,
        ]);
        exit;
    } catch (\Throwable $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }
}

$adId = (int) ($_POST['ad_id'] ?? 0);
if ($adId <= 0) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_target']);
    exit;
}

$statusMap = [
    'approve' => 'active',
    'resume'  => 'active',
    'pause'   => 'paused',
    'reject'  => 'ended',
];

try {
    if ($action === 'remove_media') {
        $mediaRaw = trim((string) ($_POST['media_path'] ?? ''));
        if ($mediaRaw === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'invalid_media']);
            exit;
        }

        $adRow = $ADM->ADM_GetAdvertisementById($adId);
        if (!$adRow) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'invalid_target']);
            exit;
        }

        $mediaType = strtolower((string) ($adRow['media_type'] ?? ''));
        if ($mediaType !== 'image') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'invalid_media_mode']);
            exit;
        }

        $normalized = trim(str_replace('\\', '/', $mediaRaw));
        $normalized = trim($normalized, '/');
        if ($normalized === '' || strpos($normalized, 'uploads/advertisement_ifiles/') !== 0) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'invalid_media']);
            exit;
        }

        $currentRaw = trim((string) ($adRow['ad_media'] ?? ''));
        $currentList = [];
        if ($currentRaw !== '') {
            foreach (explode(',', $currentRaw) as $piece) {
                $piece = trim(str_replace('\\', '/', (string) $piece));
                if ($piece !== '') {
                    $currentList[] = trim($piece, '/');
                }
            }
        }

        if (!in_array($normalized, $currentList, true)) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'invalid_media']);
            exit;
        }

        $remaining = array_values(array_filter($currentList, static function ($item) use ($normalized) {
            return $item !== $normalized;
        }));

        $updateOk = $ADM->ADM_UpdateAdvertisement($adId, ['ad_media' => implode(',', $remaining)]);
        if (!$updateOk) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'op_failed']);
            exit;
        }

        try {
            $ADM->ADM_RemoveAdvertisementMediaFiles([$normalized], 'image');
        } catch (\Throwable $__) {
            // ignore unlink errors
        }

        try { $ADM->ADM_Audit($adminId, 'ad_media_remove', 'ad:' . $adId); } catch (\Throwable $__) {}

        echo json_encode([
            'status'   => 'success',
            'removed'  => $normalized,
            'remaining_count' => count($remaining),
        ]);
        exit;
    }

    if ($action === 'update') {
        global $base_url, $minimumAdsAmount;

        $adRow = $ADM->ADM_GetAdvertisementById($adId);
        if (!$adRow) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'invalid_target']);
            exit;
        }

        $mediaType = strtolower((string) ($adRow['media_type'] ?? ''));
        if (!in_array($mediaType, ['image', 'video'], true)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'invalid_media_mode']);
            exit;
        }

        $title = trim((string) ($_POST['title'] ?? ''));
        $description = trim((string) ($_POST['description'] ?? ''));
        if ($title === '' || $description === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => customLang('admin_ads_edit_error_required')]);
            exit;
        }

        $targetImpressions = max(0, (int) ($_POST['target_impressions'] ?? 0));
        $pricePer = isset($_POST['price_per_impression']) ? (float) $_POST['price_per_impression'] : 0.0;
        $durationDays = max(1, (int) ($_POST['duration_days'] ?? 1));
        $totalBudget = isset($_POST['total_budget']) ? (float) $_POST['total_budget'] : 0.0;

        if ($targetImpressions <= 0 || $pricePer <= 0 || $durationDays < 1) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => customLang('ads_values_must_be_greater_than_zero')]);
            exit;
        }

        if ($totalBudget <= 0 && $targetImpressions > 0) {
            $totalBudget = round($targetImpressions * $pricePer, 2);
        }
        $minBudget = isset($minimumAdsAmount) ? (float) $minimumAdsAmount : 10.0;
        if ($totalBudget < $minBudget) {
            $msg = strtr(customLang('ui_min_total_budget'), ['{amount}' => '$' . number_format($minBudget, 2)]);
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $msg]);
            exit;
        }

        $updateData = [
            'title'                => $title,
            'description'          => $description,
            'target_impressions'   => $targetImpressions,
            'price_per_impression' => round($pricePer, 4),
            'duration_days'        => $durationDays,
            'total_budget'         => round($totalBudget, 2),
        ];

        $removedMedia = [];
        if ($mediaType === 'image') {
            $rawExisting = trim((string) ($adRow['ad_media'] ?? ''));
            $existingMedia = [];
            if ($rawExisting !== '') {
                foreach (explode(',', $rawExisting) as $piece) {
                    $piece = trim(str_replace('\\', '/', $piece));
                    if ($piece !== '') {
                        $existingMedia[] = trim($piece, '/');
                    }
                }
            }

            $mediaInput = $_POST['media'] ?? [];
            if (!is_array($mediaInput)) {
                $mediaInput = [];
            }

            $cleanMedia = [];
            foreach ($mediaInput as $value) {
                $value = trim(str_replace('\\', '/', (string) $value));
                if ($value === '') {
                    continue;
                }
                $value = trim($value, '/');
                if (strpos($value, 'uploads/advertisement_ifiles/') !== 0) {
                    continue;
                }
                if (!in_array($value, $cleanMedia, true)) {
                    $cleanMedia[] = $value;
                }
            }

            if (empty($cleanMedia)) {
                http_response_code(400);
                echo json_encode(['status' => 'error', 'message' => customLang('admin_ads_edit_error_media')]);
                exit;
            }

            $removedMedia = array_values(array_diff($existingMedia, $cleanMedia));
            $updateData['ad_media'] = implode(',', $cleanMedia);
        }

        $ok = $ADM->ADM_UpdateAdvertisement($adId, $updateData);
        if (!$ok) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'op_failed']);
            exit;
        }

        if (!empty($removedMedia)) {
            try {
                $ADM->ADM_RemoveAdvertisementMediaFiles($removedMedia, 'image');
            } catch (\Throwable $__) {
                // ignore cleanup failures
            }
        }

        try { $ADM->ADM_Audit($adminId, 'ad_update', 'ad:' . $adId); } catch (\Throwable $__) {}

        $pageKey = trim((string) ($_POST['page_key'] ?? ''));
        $adminBase = rtrim((string) $base_url, '/') . '/admin/index.php';
        $redirect = $adminBase;
        if ($pageKey !== '') {
            $redirect .= '?page=' . rawurlencode($pageKey);
        }

        echo json_encode([
            'status'   => 'success',
            'message'  => customLang('admin_ads_edit_saved') ?: 'Advertisement updated.',
            'redirect' => $redirect,
        ]);
        exit;
    }

    if ($action === 'delete') {
        $ok = $ADM->ADM_DeleteAdvertisement($adId);
        if (!$ok) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'op_failed']);
            exit;
        }
        try { $ADM->ADM_Audit($adminId, 'ad_delete', 'ad:' . $adId); } catch (\Throwable $__) {}
        echo json_encode(['status' => 'success']);
        exit;
    }

    if ($action === 'set_status') {
        $requested = strtolower(trim((string) ($_POST['status'] ?? '')));
        if (!in_array($requested, ['draft', 'active', 'paused', 'ended'], true)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'invalid_status']);
            exit;
        }
        $status = $requested;
    } elseif (isset($statusMap[$action])) {
        $status = $statusMap[$action];
    } else {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'bad_action']);
        exit;
    }

    $ok = $ADM->ADM_UpdateAdvertisementStatus($adId, $status);
    if (!$ok) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'op_failed']);
        exit;
    }

    $labelKey = 'admin_ads_status_' . $status;
    $label = customLang($labelKey);
    if ($label === $labelKey || $label === '') {
        $label = ucfirst($status);
    }

    try { $ADM->ADM_Audit($adminId, 'ad_status_' . $status, 'ad:' . $adId); } catch (\Throwable $__) {}

    echo json_encode([
        'status'      => 'success',
        'new_status'  => $status,
        'status_label'=> $label,
    ]);
    exit;
} catch (\Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}
