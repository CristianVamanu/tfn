<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
if (!class_exists('AdminMail', false)) {
    require_once __DIR__ . '/../../includes/helpers/mail_helper.php';
}
header('Content-Type: application/json; charset=utf-8');

use PHPMailer\PHPMailer\Exception as PHPMailerException;
use PHPMailer\PHPMailer\PHPMailer;

if (!function_exists('adminContactRespond')) {
    function adminContactRespond(int $status, string $message, array $extra = []): void
    {
        http_response_code($status);
        echo json_encode(array_merge(['status' => $status === 200 ? 'success' : 'error', 'message' => $message], $extra));
        exit;
    }
}

$csrf = isset($_POST['csrf_token']) ? (string) $_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    adminContactRespond(403, 'invalid_csrf');
}

$action = isset($_POST['action']) ? trim((string) $_POST['action']) : '';
if ($action === '') {
    adminContactRespond(400, 'bad_action');
}

if (!isset($ADM) || !($ADM instanceof Admin_Data)) {
    adminContactRespond(500, 'server_error');
}

$db = $ADM->db();
$mailSettings = null;
$loadMailSettings = static function () use (&$mailSettings, $db): void {
    if ($mailSettings !== null) {
        return;
    }
    try {
        $mailSettings = AdminMail::loadSettings($db);
    } catch (RuntimeException $e) {
        if ($e->getMessage() === 'smtp_not_configured') {
            $mailSettings = [];
            return;
        }
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('admin mail settings load failed: ' . $e->getMessage());
        }
        $mailSettings = [];
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('admin mail settings load threw: ' . $e->getMessage());
        }
        $mailSettings = [];
    }
};

if ($action === 'save_contact_cfg') {
    $allowGuests = isset($_POST['allow_guest_messages']) && (string) $_POST['allow_guest_messages'] === '1' ? 1 : 0;
    $guestRecaptchaRequired = isset($_POST['guest_recaptcha_required']) && (string) $_POST['guest_recaptcha_required'] === '1' ? 1 : 0;
    if ($allowGuests === 0) {
        $guestRecaptchaRequired = 0;
    }

    $maxMessageLength = isset($_POST['max_message_length']) ? (int) $_POST['max_message_length'] : 1000;
    if ($maxMessageLength < 100 || $maxMessageLength > 5000) {
        adminContactRespond(400, 'invalid_length', ['field' => 'max_message_length']);
    }

    $rateLimit = isset($_POST['rate_limit_per_hour']) ? (int) $_POST['rate_limit_per_hour'] : 0;
    if ($rateLimit < 0 || $rateLimit > 1000) {
        adminContactRespond(400, 'invalid_rate_limit');
    }

    $labelDefaults = [
        'subject_label_feedback' => 'Feedback',
        'subject_label_complaint' => 'Complaint',
        'subject_label_suggestion' => 'Suggestion',
        'subject_label_bug' => 'Bug',
    ];
    $labels = [];
    foreach ($labelDefaults as $key => $fallback) {
        $raw = isset($_POST[$key]) ? (string) $_POST[$key] : '';
        $clean = trim(strip_tags($raw));
        if ($clean === '') {
            $clean = $fallback;
        }
        if (function_exists('mb_substr')) {
            $clean = mb_substr($clean, 0, 120);
        } else {
            $clean = substr($clean, 0, 120);
        }
        $labels[$key] = $clean;
    }

    ($loadMailSettings)();
    $hasSettings = !empty($mailSettings);

    try {
        $db->beginTransaction();
        if ($hasSettings) {
            $stmt = $db->prepare('UPDATE i_mail_settings
                SET allow_guest_messages = :allow_guests,
                    guest_recaptcha_required = :guest_recaptcha,
                    max_message_length = :max_length,
                    subject_label_feedback = :label_feedback,
                    subject_label_complaint = :label_complaint,
                    subject_label_suggestion = :label_suggestion,
                    subject_label_bug = :label_bug,
                    rate_limit_per_hour = :rate_limit,
                    updated_at = CURRENT_TIMESTAMP
              WHERE id = 1');
            $stmt->execute([
                ':allow_guests' => $allowGuests,
                ':guest_recaptcha' => $guestRecaptchaRequired,
                ':max_length' => $maxMessageLength,
                ':label_feedback' => $labels['subject_label_feedback'],
                ':label_complaint' => $labels['subject_label_complaint'],
                ':label_suggestion' => $labels['subject_label_suggestion'],
                ':label_bug' => $labels['subject_label_bug'],
                ':rate_limit' => $rateLimit,
            ]);
        } else {
            $stmt = $db->prepare('INSERT INTO i_mail_settings (
                    id, host, port, secure, username, password_enc,
                    from_email, from_name, to_email,
                    recaptcha_site_key, recaptcha_secret_key, recaptcha_enabled,
                    allow_guest_messages, guest_recaptcha_required, max_message_length,
                    subject_label_feedback, subject_label_complaint, subject_label_suggestion, subject_label_bug,
                    rate_limit_per_hour, updated_at
                ) VALUES (
                    1, :host, :port, :secure, :username, :password_enc,
                    :from_email, :from_name, :to_email,
                    :recaptcha_site_key, :recaptcha_secret_key, :recaptcha_enabled,
                    :allow_guests, :guest_recaptcha, :max_length,
                    :label_feedback, :label_complaint, :label_suggestion, :label_bug,
                    :rate_limit, CURRENT_TIMESTAMP
                )');
            $stmt->execute([
                ':host' => '',
                ':port' => 587,
                ':secure' => 'none',
                ':username' => '',
                ':password_enc' => null,
                ':from_email' => '',
                ':from_name' => '',
                ':to_email' => '',
                ':recaptcha_site_key' => '',
                ':recaptcha_secret_key' => '',
                ':recaptcha_enabled' => 0,
                ':allow_guests' => $allowGuests,
                ':guest_recaptcha' => $guestRecaptchaRequired,
                ':max_length' => $maxMessageLength,
                ':label_feedback' => $labels['subject_label_feedback'],
                ':label_complaint' => $labels['subject_label_complaint'],
                ':label_suggestion' => $labels['subject_label_suggestion'],
                ':label_bug' => $labels['subject_label_bug'],
                ':rate_limit' => $rateLimit,
            ]);
        }
        $db->commit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('admin contact email save_contact_cfg failed: ' . $e->getMessage());
        }
        adminContactRespond(500, 'server_error');
    }

    adminContactRespond(200, 'success', ['ok' => true]);
}

if ($action === 'list_messages') {
    $page = max(1, (int) ($_POST['page'] ?? 1));
    $perPage = (int) ($_POST['per_page'] ?? 20);
    if ($perPage < 1) { $perPage = 1; }
    if ($perPage > 100) { $perPage = 100; }
    $status = strtolower(trim((string) ($_POST['status'] ?? 'all')));
    $msgType = strtolower(trim((string) ($_POST['msg_type'] ?? 'all')));
    $startDate = trim((string) ($_POST['start_date'] ?? ''));
    $endDate = trim((string) ($_POST['end_date'] ?? ''));

    $conditions = [];
    $params = [];

    if ($status !== '' && $status !== 'all') {
        $conditions[] = 'status = :status';
        $params[':status'] = $status;
    }

    if ($msgType !== '' && $msgType !== 'all') {
        $conditions[] = 'msg_type = :msg_type';
        $params[':msg_type'] = $msgType;
    }

    if ($startDate !== '') {
        $start = \DateTimeImmutable::createFromFormat('Y-m-d', $startDate);
        if ($start !== false) {
            $conditions[] = 'created_at >= :start_date';
            $params[':start_date'] = $start->setTime(0, 0, 0)->format('Y-m-d H:i:s');
        }
    }

    if ($endDate !== '') {
        $end = \DateTimeImmutable::createFromFormat('Y-m-d', $endDate);
        if ($end !== false) {
            $conditions[] = 'created_at <= :end_date';
            $params[':end_date'] = $end->setTime(23, 59, 59)->format('Y-m-d H:i:s');
        }
    }

    $whereSql = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';
    $offset = ($page - 1) * $perPage;

    try {
        $countStmt = $db->prepare('SELECT COUNT(*) FROM i_contact_messages' . $whereSql);
        foreach ($params as $key => $value) {
            $countStmt->bindValue($key, $value);
        }
        $countStmt->execute();
        $total = (int) $countStmt->fetchColumn();

        $totalPages = $perPage > 0 ? (int) ceil($total / $perPage) : 1;
        if ($totalPages < 1) { $totalPages = 1; }
        if ($total > 0 && $page > $totalPages) {
            $page = $totalPages;
            $offset = ($page - 1) * $perPage;
        }

        $listSql = 'SELECT id, user_id, name, email, subject, msg_type, status, created_at, SUBSTRING(message, 1, 200) AS preview'
            . ' FROM i_contact_messages' . $whereSql . ' ORDER BY created_at DESC LIMIT :limit OFFSET :offset';
        $stmt = $db->prepare($listSql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        $items = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $items[] = [
                'id' => (int) ($row['id'] ?? 0),
                'user_id' => isset($row['user_id']) ? (int) $row['user_id'] : null,
                'name' => (string) ($row['name'] ?? ''),
                'email' => (string) ($row['email'] ?? ''),
                'subject' => (string) ($row['subject'] ?? ''),
                'msg_type' => (string) ($row['msg_type'] ?? ''),
                'status' => (string) ($row['status'] ?? ''),
                'created_at' => (string) ($row['created_at'] ?? ''),
                'preview' => trim((string) ($row['preview'] ?? '')),
            ];
        }

        adminContactRespond(200, 'success', [
            'ok' => true,
            'data' => [
                'items' => $items,
                'pagination' => [
                    'page' => $page,
                    'per_page' => $perPage,
                    'total' => $total,
                    'total_pages' => $totalPages,
                ],
            ],
        ]);
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('admin contact list_messages failed: ' . $e->getMessage());
        }
        adminContactRespond(500, 'server_error');
    }
}

if ($action === 'get_message') {
    $messageId = (int) ($_POST['message_id'] ?? $_POST['id'] ?? 0);
    if ($messageId <= 0) {
        adminContactRespond(400, 'contact_message_not_found');
    }

    $stmt = $db->prepare('SELECT * FROM i_contact_messages WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $messageId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        adminContactRespond(404, 'contact_message_not_found');
    }

    $status = (string) ($row['status'] ?? '');
    if ($status === 'new') {
        try {
            $update = $db->prepare('UPDATE i_contact_messages SET status = "read" WHERE id = :id');
            $update->execute([':id' => $messageId]);
            $row['status'] = 'read';
        } catch (Throwable $e) {
            if (defined('APP_DEBUG') && APP_DEBUG === true) {
                error_log('admin contact auto-read failed: ' . $e->getMessage());
            }
        }
    }

    adminContactRespond(200, 'success', [
        'ok' => true,
        'data' => [
            'id' => (int) ($row['id'] ?? 0),
            'user_id' => isset($row['user_id']) ? (int) $row['user_id'] : null,
            'name' => (string) ($row['name'] ?? ''),
            'email' => (string) ($row['email'] ?? ''),
            'subject' => (string) ($row['subject'] ?? ''),
            'msg_type' => (string) ($row['msg_type'] ?? ''),
            'status' => (string) ($row['status'] ?? ''),
            'created_at' => (string) ($row['created_at'] ?? ''),
            'ip' => (string) ($row['ip'] ?? ''),
            'user_agent' => (string) ($row['user_agent'] ?? ''),
            'message' => (string) ($row['message'] ?? ''),
        ],
    ]);
}

if ($action === 'set_status') {
    $messageId = (int) ($_POST['message_id'] ?? 0);
    $newStatus = strtolower(trim((string) ($_POST['status'] ?? '')));
    if ($messageId <= 0) {
        adminContactRespond(400, 'contact_message_not_found');
    }
    $allowedStatuses = ['new', 'read', 'resolved'];
    if (!in_array($newStatus, $allowedStatuses, true)) {
        adminContactRespond(400, 'contact_invalid_status');
    }

    $stmt = $db->prepare('UPDATE i_contact_messages SET status = :status WHERE id = :id');
    $stmt->execute([
        ':status' => $newStatus,
        ':id' => $messageId,
    ]);
    if ($stmt->rowCount() === 0) {
        $check = $db->prepare('SELECT id FROM i_contact_messages WHERE id = :id LIMIT 1');
        $check->execute([':id' => $messageId]);
        if (!$check->fetchColumn()) {
            adminContactRespond(404, 'contact_message_not_found');
        }
    }

    adminContactRespond(200, 'success', ['ok' => true, 'data' => ['status' => $newStatus]]);
}

if ($action === 'mark_answered') {
    $messageId = isset($_POST['message_id']) ? (int) $_POST['message_id'] : (int) ($_POST['id'] ?? 0);
    if ($messageId <= 0) {
        adminContactRespond(400, 'contact_message_not_found');
    }

    try {
        $stmt = $db->prepare('UPDATE i_contact_messages SET status = :status WHERE id = :id');
        $stmt->execute([
            ':status' => 'resolved',
            ':id' => $messageId,
        ]);
        if ($stmt->rowCount() === 0) {
            $check = $db->prepare('SELECT id FROM i_contact_messages WHERE id = :id LIMIT 1');
            $check->execute([':id' => $messageId]);
            if (!$check->fetchColumn()) {
                adminContactRespond(404, 'contact_message_not_found');
            }
        }
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('mark_answered failed: ' . $e->getMessage());
        }
        adminContactRespond(500, 'server_error');
    }

    adminContactRespond(200, 'success', ['ok' => true, 'data' => ['status' => 'resolved']]);
}

if ($action === 'delete') {
    $messageId = isset($_POST['message_id']) ? (int) $_POST['message_id'] : (int) ($_POST['id'] ?? 0);
    if ($messageId <= 0) {
        adminContactRespond(400, 'contact_message_not_found');
    }

    try {
        $stmt = $db->prepare('DELETE FROM i_contact_messages WHERE id = :id');
        $stmt->execute([':id' => $messageId]);
        if ($stmt->rowCount() === 0) {
            adminContactRespond(404, 'contact_message_not_found');
        }
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('delete contact message failed: ' . $e->getMessage());
        }
        adminContactRespond(500, 'server_error');
    }

    adminContactRespond(200, 'success', ['ok' => true]);
}

if ($action === 'reply_send') {
    $messageId = isset($_POST['message_id']) ? (int) $_POST['message_id'] : (int) ($_GET['id'] ?? 0);
    if ($messageId <= 0) {
        adminContactRespond(400, 'contact_message_not_found');
    }

    $toEmail = trim((string) ($_POST['to'] ?? ''));
    $subject = trim((string) ($_POST['subject'] ?? ''));
    $body    = trim((string) ($_POST['message'] ?? ''));

    if ($subject === '' || mb_strlen($subject) > 191) {
        adminContactRespond(400, 'invalid_subject');
    }
    if ($body === '') {
        adminContactRespond(400, 'invalid_message_body');
    }

    try {
        $stmt = $db->prepare('SELECT id, email, name, subject FROM i_contact_messages WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $messageId]);
        $messageRow = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('load contact message for reply failed: ' . $e->getMessage());
        }
        $messageRow = null;
    }

    if (!$messageRow) {
        adminContactRespond(404, 'contact_message_not_found');
    }

    if ($toEmail === '') {
        $toEmail = (string) ($messageRow['email'] ?? '');
    }
    if ($toEmail === '' || filter_var($toEmail, FILTER_VALIDATE_EMAIL) === false) {
        adminContactRespond(400, 'invalid_email', ['field' => 'to']);
    }

    ($loadMailSettings)();
    if (empty($mailSettings)) {
        adminContactRespond(400, 'smtp_not_configured');
    }

    try {
        [$mailer, $normalised] = AdminMail::buildMailer($mailSettings);
    } catch (RuntimeException $e) {
        adminContactRespond(400, 'smtp_not_configured', ['details' => $e->getMessage()]);
    }

    $recipientName = (string) ($messageRow['name'] ?? '');
    $plainBody = strip_tags(preg_replace('/\r\n|\r|\n/', PHP_EOL, $body));

    $sendOk = false;
    $errorMessage = '';
    try {
        $mailer->clearAddresses();
        $mailer->addAddress($toEmail, $recipientName !== '' ? $recipientName : null);
        $mailer->isHTML(true);
        $mailer->Subject = $subject;
        $mailer->Body    = $body;
        $mailer->AltBody = $plainBody;
        $mailer->send();
        $sendOk = true;
    } catch (PHPMailerException $e) {
        $errorMessage = trim($e->getMessage() ?: ($mailer->ErrorInfo ?? ''));
    } catch (Throwable $e) {
        $errorMessage = trim($e->getMessage());
    }

    $meta = [
        'message_id' => $messageId,
        'email' => $toEmail,
        'subject' => $subject,
    ];

    try {
        $logStmt = $db->prepare('INSERT INTO i_mail_logs (event, ok, error, meta, created_at) VALUES (:event, :ok, :error, :meta, CURRENT_TIMESTAMP)');
        $logStmt->execute([
            ':event' => 'contact_reply',
            ':ok'    => $sendOk ? 1 : 0,
            ':error' => $sendOk ? null : ($errorMessage !== '' ? $errorMessage : null),
            ':meta'  => json_encode($meta, JSON_UNESCAPED_SLASHES) ?: null,
        ]);
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('contact reply log insert failed: ' . $e->getMessage());
        }
    }

    if (!$sendOk) {
        adminContactRespond(500, 'smtp_send_failed', ['details' => $errorMessage !== '' ? $errorMessage : 'Unable to send message']);
    }

    try {
        $update = $db->prepare('UPDATE i_contact_messages SET status = :status WHERE id = :id');
        $update->execute([
            ':status' => 'resolved',
            ':id' => $messageId,
        ]);
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('contact reply status update failed: ' . $e->getMessage());
        }
    }

    adminContactRespond(200, 'success', ['ok' => true, 'data' => ['status' => 'resolved']]);
}

if ($action === 'save_smtp') {
    $host = trim((string) ($_POST['host'] ?? ''));
    $port = isset($_POST['port']) ? (int) $_POST['port'] : 0;
    $secure = strtolower(trim((string) ($_POST['secure'] ?? '')));
    $username = trim((string) ($_POST['username'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $clearPassword = isset($_POST['clear_password']) && (string) $_POST['clear_password'] === '1';
    $fromName = trim((string) ($_POST['from_name'] ?? ''));
    $fromEmail = trim((string) ($_POST['from_email'] ?? ''));
    $toEmail = trim((string) ($_POST['to_email'] ?? ''));
    $recaptchaEnabled = isset($_POST['recaptcha_enabled']) && (string) $_POST['recaptcha_enabled'] === '1' ? 1 : 0;
    $recaptchaSite = trim((string) ($_POST['recaptcha_site_key'] ?? ''));
    $recaptchaSecret = trim((string) ($_POST['recaptcha_secret_key'] ?? ''));

    ($loadMailSettings)();
    $hasSettings = !empty($mailSettings);

    if ($hasSettings) {
        if ($host === '') {
            $host = trim((string) ($mailSettings['host'] ?? ''));
        }
        if ($port < 1 || $port > 65535) {
            $existingPort = (int) ($mailSettings['port'] ?? 0);
            if ($existingPort > 0) {
                $port = $existingPort;
            }
        }
        if ($secure === '' || !in_array($secure, ['tls', 'ssl', 'none'], true)) {
            $secure = (string) ($mailSettings['secure'] ?? 'none');
        }
        if ($username === '') {
            $username = trim((string) ($mailSettings['username'] ?? ''));
        }
        if ($fromName === '') {
            $fromName = trim((string) ($mailSettings['from_name'] ?? ''));
        }
        if ($fromEmail === '') {
            $fromEmail = trim((string) ($mailSettings['from_email'] ?? ''));
        }
        if ($toEmail === '') {
            $toEmail = trim((string) ($mailSettings['to_email'] ?? ''));
        }
    }

    $isHostProvided = $host !== '';
    if ($isHostProvided) {
        $isValidHost = false;
        if (filter_var($host, FILTER_VALIDATE_IP) !== false) {
            $isValidHost = true;
        } elseif ($host === 'localhost') {
            $isValidHost = true;
        } elseif (filter_var($host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) !== false) {
            $isValidHost = true;
        }
        if (!$isValidHost) {
            adminContactRespond(400, 'invalid_host');
        }
        if ($port < 1 || $port > 65535) {
            adminContactRespond(400, 'invalid_port');
        }
    }

    if (!$isHostProvided && $host === '' && isset($mailSettings['host'])) {
        $host = trim((string) $mailSettings['host']);
    }
    if ($port < 1 || $port > 65535) {
        $port = (int) ($mailSettings['port'] ?? 587);
        if ($port < 1 || $port > 65535) {
            $port = 587;
        }
    }
    if ($secure === '' && isset($mailSettings['secure'])) {
        $secure = (string) $mailSettings['secure'];
    }
    $secureOptions = ['tls', 'ssl', 'none'];
    if (!in_array($secure, $secureOptions, true)) {
        $secure = 'none';
    }

    if ($username !== '' && mb_strlen($username) > 191) {
        adminContactRespond(400, 'invalid_length', ['field' => 'username']);
    }

    if ($password !== '' && mb_strlen($password) > 191) {
        adminContactRespond(400, 'invalid_length', ['field' => 'password']);
    }

    if ($fromName !== '' && mb_strlen($fromName) > 120) {
        adminContactRespond(400, 'invalid_length', ['field' => 'from_name']);
    }

    if ($fromEmail !== '' && filter_var($fromEmail, FILTER_VALIDATE_EMAIL) === false) {
        adminContactRespond(400, 'invalid_email', ['field' => 'from_email']);
    }

    if ($toEmail !== '' && filter_var($toEmail, FILTER_VALIDATE_EMAIL) === false) {
        adminContactRespond(400, 'invalid_email', ['field' => 'to_email']);
    }

    if ($recaptchaSite !== '' && mb_strlen($recaptchaSite) > 191) {
        adminContactRespond(400, 'invalid_length', ['field' => 'recaptcha_site_key']);
    }

    if ($recaptchaSecret !== '' && mb_strlen($recaptchaSecret) > 191) {
        adminContactRespond(400, 'invalid_length', ['field' => 'recaptcha_secret_key']);
    }

    $passwordClause = '';
    $params = [
        ':host' => $host,
        ':port' => $port,
        ':secure' => $secure,
        ':username' => $username,
        ':from_name' => $fromName,
        ':from_email' => $fromEmail,
        ':to_email' => $toEmail,
        ':recaptcha_site_key' => $recaptchaSite,
        ':recaptcha_secret_key' => $recaptchaSecret,
        ':recaptcha_enabled' => $recaptchaEnabled,
    ];

    if ($password !== '') {
        try {
            $encryptedPassword = AdminMail::encryptPassword($password);
        } catch (Throwable $e) {
            adminContactRespond(500, 'encrypt_failed');
        }
        $passwordClause = ', password_enc = :password_enc';
        $params[':password_enc'] = $encryptedPassword;
        $clearPassword = false; // override clear if new password provided
    } elseif ($clearPassword) {
        $passwordClause = ', password_enc = NULL';
    }

    try {
        $db->beginTransaction();
        if ($hasSettings) {
            $sql = 'UPDATE i_mail_settings
                SET host = :host,
                    port = :port,
                    secure = :secure,
                    username = :username' . $passwordClause . ',
                    from_name = :from_name,
                    from_email = :from_email,
                    to_email = :to_email,
                    recaptcha_site_key = :recaptcha_site_key,
                    recaptcha_secret_key = :recaptcha_secret_key,
                    recaptcha_enabled = :recaptcha_enabled,
                    updated_at = CURRENT_TIMESTAMP
              WHERE id = 1';
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
        } else {
            $stmt = $db->prepare('INSERT INTO i_mail_settings (
                    id, host, port, secure, username, password_enc,
                    from_email, from_name, to_email,
                    recaptcha_site_key, recaptcha_secret_key, recaptcha_enabled,
                    rate_limit_per_hour, updated_at
                ) VALUES (
                    1, :host, :port, :secure, :username, :password_enc,
                    :from_email, :from_name, :to_email,
                    :recaptcha_site_key, :recaptcha_secret_key, :recaptcha_enabled,
                    :rate_limit, CURRENT_TIMESTAMP
                )');
            $insertPassword = null;
            if (!$clearPassword && $password !== '') {
                try {
                    $insertPassword = AdminMail::encryptPassword($password);
                } catch (Throwable $e) {
                    adminContactRespond(500, 'encrypt_failed');
                }
            }
            $stmt->execute([
                ':host' => $host,
                ':port' => $port,
                ':secure' => $secure,
                ':username' => $username,
                ':password_enc' => $clearPassword ? null : $insertPassword,
                ':from_email' => $fromEmail,
                ':from_name' => $fromName,
                ':to_email' => $toEmail,
                ':recaptcha_site_key' => $recaptchaSite,
                ':recaptcha_secret_key' => $recaptchaSecret,
                ':recaptcha_enabled' => $recaptchaEnabled,
                ':rate_limit' => (int) ($mailSettings['rate_limit_per_hour'] ?? 1),
            ]);
        }
        $db->commit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('admin contact email save_smtp failed: ' . $e->getMessage());
        }
        adminContactRespond(500, 'server_error');
    }

    adminContactRespond(200, 'success', ['ok' => true]);
}

if ($action === 'smtp_test') {
    $testEmail = trim((string) ($_POST['test_email'] ?? ''));
    if ($testEmail === '' || filter_var($testEmail, FILTER_VALIDATE_EMAIL) === false) {
        adminContactRespond(400, 'invalid_email', ['field' => 'test_email', 'ok' => false]);
    }

    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        $ip = '0.0.0.0';
    }

    try {
        $limitStmt = $db->prepare("SELECT COUNT(*) FROM i_mail_logs WHERE event = 'smtp_test' AND created_at >= (NOW() - INTERVAL 1 MINUTE) AND JSON_EXTRACT(meta, '$.ip') = :ip");
        $limitStmt->execute([':ip' => $ip]);
        $sentCount = (int) $limitStmt->fetchColumn();
        if ($sentCount >= 5) {
            adminContactRespond(429, 'smtp_test_rate_limited', ['ok' => false]);
        }
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('smtp test rate limit check failed: ' . $e->getMessage());
        }
    }

    ($loadMailSettings)();
    if (empty($mailSettings)) {
        adminContactRespond(400, 'smtp_not_configured', ['ok' => false]);
    }

    try {
        [$mailer, $normalised] = AdminMail::buildMailer($mailSettings);
        unset($normalised['password'], $normalised['username']);
    } catch (RuntimeException $e) {
        adminContactRespond(400, 'smtp_not_configured', ['ok' => false, 'details' => $e->getMessage()]);
    }

    $meta = [
        'ip' => $ip,
        'test_email' => $testEmail,
        'host' => $normalised['host'],
        'secure' => $normalised['secure'],
        'uses_auth' => $normalised['uses_auth'] ? 1 : 0,
    ];

    $errorMessage = '';
    $ok = false;

    try {
        global $base_url;

        $mailer->addAddress($testEmail);
        $mailer->Subject = 'SMTP Test';
        $origin = isset($base_url) ? (string) $base_url : '';
        $mailer->Body = 'This is a test email from the ReelsProject admin panel (' . $origin . ') sent at ' . date('c');
        $mailer->AltBody = 'Test email from ReelsProject admin panel sent at ' . date('c');

        $mailer->send();
        $ok = true;
    } catch (PHPMailerException $e) {
        $extraInfo = $mailer instanceof PHPMailer ? (string) $mailer->ErrorInfo : '';
        $errorMessage = trim($e->getMessage() ?: $extraInfo);
    } catch (Throwable $e) {
        $errorMessage = trim($e->getMessage());
    }

    try {
        $logStmt = $db->prepare('INSERT INTO i_mail_logs (event, ok, error, meta, created_at) VALUES (:event, :ok, :error, :meta, CURRENT_TIMESTAMP)');
        $logStmt->execute([
            ':event' => 'smtp_test',
            ':ok' => $ok ? 1 : 0,
            ':error' => $ok ? null : ($errorMessage !== '' ? $errorMessage : null),
            ':meta' => json_encode($meta + ['error' => $ok ? null : $errorMessage], JSON_UNESCAPED_SLASHES) ?: null,
        ]);
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('smtp test log insert failed: ' . $e->getMessage());
        }
    }

    if ($ok) {
        adminContactRespond(200, 'success', ['ok' => true]);
    }

    $details = $errorMessage !== '' ? $errorMessage : 'Unknown error';
    adminContactRespond(500, 'smtp_send_failed', ['ok' => false, 'details' => $details]);
}

adminContactRespond(400, 'bad_action');
