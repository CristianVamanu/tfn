<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    echo json_encode(['status' => 'error', 'message' => 'invalid_method']);
    exit;
}

$csrf = isset($_POST['csrf_token']) ? (string) $_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

if (!isset($_FILES['image']) || !is_array($_FILES['image'])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'no_file']);
    exit;
}

$file = $_FILES['image'];
$error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
if ($error !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'upload_failed']);
    exit;
}

$tmp = (string) ($file['tmp_name'] ?? '');
if ($tmp === '' || !is_uploaded_file($tmp)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'no_file']);
    exit;
}

$maxBytes = 3 * 1024 * 1024; // 3 MB limit
$size = isset($file['size']) ? (int) $file['size'] : 0;
if ($size <= 0 || $size > $maxBytes) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'file_too_large']);
    exit;
}

$imageInfo = @getimagesize($tmp);
if ($imageInfo === false) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_image']);
    exit;
}

$mime = isset($imageInfo['mime']) ? strtolower((string) $imageInfo['mime']) : '';
$allowedMime = [
    'image/jpeg' => 'jpg',
    'image/png'  => 'png',
    'image/gif'  => 'gif',
    'image/webp' => 'webp',
];

if (!isset($allowedMime[$mime])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'unsupported_type']);
    exit;
}

$ext = $allowedMime[$mime];
$baseDir = dirname(__DIR__, 2) . '/uploads/page_content/';
if (!is_dir($baseDir) && !@mkdir($baseDir, 0755, true) && !is_dir($baseDir)) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}

$filename = generateUniqueFilename('page', $ext);
$targetPath = $baseDir . $filename;

if (!move_uploaded_file($tmp, $targetPath)) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'upload_failed']);
    exit;
}

@chmod($targetPath, 0644);

$relative = 'uploads/page_content/' . $filename;

$baseAbsolute = '';
if (isset($base_url) && $base_url !== '') {
    $baseAbsolute = rtrim((string) $base_url, '/');
} else {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = isset($_SERVER['HTTP_HOST']) ? (string) $_SERVER['HTTP_HOST'] : 'localhost';
    $scriptName = isset($_SERVER['SCRIPT_NAME']) ? str_replace('\\', '/', (string) $_SERVER['SCRIPT_NAME']) : '';
    $dir = trim(dirname($scriptName), '/');
    $baseAbsolute = $scheme . '://' . $host;
    if ($dir !== '' && $dir !== '.') {
        $baseAbsolute .= '/' . $dir;
    }
}

$absolute = $baseAbsolute . '/' . ltrim($relative, '/');
$relativeRooted = '/' . ltrim($relative, '/');

echo json_encode([
    'status'   => 'success',
    'location' => $absolute,
    'relative' => $relativeRooted,
]);
exit;
