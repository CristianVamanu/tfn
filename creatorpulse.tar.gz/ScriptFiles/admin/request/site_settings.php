<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php'; // Centralized admin guard
header('Content-Type: application/json; charset=utf-8');

global $siteData, $ADM;

if (!function_exists('admin_expand_user_path')) {
    function admin_expand_user_path(string $path): string
    {
        $trimmed = trim($path);
        if ($trimmed === '' || $trimmed[0] !== '~') {
            return $trimmed;
        }

        $home = getenv('HOME');
        if (!$home && DIRECTORY_SEPARATOR === '\\') {
            $drive = getenv('HOMEDRIVE');
            $homePath = getenv('HOMEPATH');
            if ($drive && $homePath) {
                $home = $drive . $homePath;
            }
        }

        if (!$home && function_exists('posix_getpwuid')) {
            try {
                $data = posix_getpwuid(posix_getuid());
                if (is_array($data) && !empty($data['dir'])) {
                    $home = $data['dir'];
                }
            } catch (Throwable $__) {
                $home = false;
            }
        }

        if (!$home) {
            return $trimmed;
        }

        if ($trimmed === '~') {
            return rtrim($home, "\\/") . DIRECTORY_SEPARATOR;
        }

        if (str_starts_with($trimmed, '~/')) {
            return rtrim($home, '/') . substr($trimmed, 1);
        }

        if (str_starts_with($trimmed, '~\\')) {
            return rtrim($home, '\\') . substr($trimmed, 1);
        }

        return $trimmed;
    }
}

if (!function_exists('admin_resolve_binary_path')) {
    function admin_resolve_binary_path(string $input): ?string
    {
        $candidateList = [];
        $normalized = trim($input);
        if ($normalized === '') {
            return null;
        }

        $containsSeparator = preg_match('/[\\\\\/]/', $normalized) === 1;
        if ($containsSeparator || preg_match('/^[A-Za-z]:\\\//', $normalized) === 1) {
            $candidateList[] = admin_expand_user_path($normalized);
        } else {
            $pathEnv = getenv('PATH') ?: '';
            $paths = $pathEnv !== '' ? explode(PATH_SEPARATOR, $pathEnv) : [];
            foreach ($paths as $dir) {
                $dir = trim($dir, " \"'");
                if ($dir === '') {
                    continue;
                }
                $candidate = rtrim($dir, '\\/') . DIRECTORY_SEPARATOR . $normalized;
                $candidateList[] = $candidate;
                if (DIRECTORY_SEPARATOR === '\\') {
                    foreach (['.exe', '.bat', '.cmd'] as $suffix) {
                        $candidateList[] = $candidate . $suffix;
                    }
                }
            }
        }

        foreach ($candidateList as $candidate) {
            if ($candidate === '' || !is_file($candidate)) {
                continue;
            }
            $real = @realpath($candidate);
            $resolved = $real ?: $candidate;
            if (!is_readable($resolved)) {
                continue;
            }
            if (DIRECTORY_SEPARATOR === '\\') {
                if (preg_match('/\.(exe|bat|cmd)$/i', $resolved) || @is_executable($resolved)) {
                    return $resolved;
                }
                continue;
            }
            if (@is_executable($resolved)) {
                return $resolved;
            }
        }

        return null;
    }
}

if (!function_exists('admin_normalize_binary_input')) {
    function admin_normalize_binary_input(?string $raw, string $type): array
    {
        $trimmed = trim((string) ($raw ?? ''));
        if ($trimmed === '') {
            return [
                'input' => '',
                'value' => null,
                'resolved' => null,
                'error' => null,
            ];
        }

        $expanded = admin_expand_user_path($trimmed);
        $resolved = admin_resolve_binary_path($expanded);
        if ($resolved === null) {
            return [
                'input' => $trimmed,
                'value' => null,
                'resolved' => null,
                'error' => $type === 'ffprobe' ? 'invalid_ffprobe_path' : 'invalid_ffmpeg_path',
            ];
        }

        if (DIRECTORY_SEPARATOR !== '\\' && !@is_executable($resolved)) {
            return [
                'input' => $trimmed,
                'value' => null,
                'resolved' => null,
                'error' => $type === 'ffprobe' ? 'invalid_ffprobe_not_executable' : 'invalid_ffmpeg_not_executable',
            ];
        }

        $storeValue = $expanded !== '' ? $expanded : $trimmed;

        return [
            'input' => $trimmed,
            'value' => $storeValue,
            'resolved' => $resolved,
            'error' => null,
        ];
    }
}

if (!function_exists('admin_run_binary_test')) {
    function admin_run_binary_test(?string $resolved, string $type): array
    {
        if ($resolved === null || $resolved === '') {
            $key = 'admin_ffmpeg_empty_path';
            $text = customLang($key) ?: 'No custom path provided. The default application fallback will be used.';
            return ['status' => 'empty', 'key' => $key, 'message_text' => $text];
        }

        if (!function_exists('proc_open')) {
            $key = 'admin_ffmpeg_test_proc_disabled';
            $text = customLang($key) ?: 'Process execution is disabled on this server. Test skipped.';
            return ['status' => 'skipped', 'key' => $key, 'message_text' => $text];
        }

        $cmd = escapeshellarg($resolved) . ' -version';
        $descriptor = [
            0 => ['pipe', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ];

        try {
            $process = @proc_open($cmd, $descriptor, $pipes, null, null, ['bypass_shell' => true]);
        } catch (Throwable $__) {
            $process = false;
        }

        if (!is_resource($process)) {
            $key = 'admin_ffmpeg_test_failed';
            $text = customLang($key) ?: 'The binary could not be executed. Double-check the path.';
            return ['status' => 'error', 'key' => $key, 'message_text' => $text];
        }

        $timeoutSeconds = 5.0;
        $start = microtime(true);
        if (isset($pipes[0]) && is_resource($pipes[0])) {
            fclose($pipes[0]);
        }
        foreach ([1, 2] as $pipeIndex) {
            if (isset($pipes[$pipeIndex]) && is_resource($pipes[$pipeIndex])) {
                stream_set_blocking($pipes[$pipeIndex], false);
            }
        }

        $output = '';
        $timedOut = false;

        while (true) {
            $status = @proc_get_status($process);
            if (!is_array($status) || !$status['running']) {
                break;
            }

            $elapsed = microtime(true) - $start;
            if ($elapsed > $timeoutSeconds) {
                $timedOut = true;
                @proc_terminate($process, 9);
                break;
            }

            $read = [];
            foreach ([1, 2] as $pipeIndex) {
                if (isset($pipes[$pipeIndex]) && is_resource($pipes[$pipeIndex])) {
                    $read[] = $pipes[$pipeIndex];
                }
            }

            if ($read) {
                $write = null;
                $except = null;
                @stream_select($read, $write, $except, 0, 150000);
                foreach ($read as $stream) {
                    $chunk = stream_get_contents($stream);
                    if ($chunk !== false) {
                        $output .= $chunk;
                    }
                }
            } else {
                usleep(100000);
            }
        }

        foreach ([1, 2] as $pipeIndex) {
            if (isset($pipes[$pipeIndex]) && is_resource($pipes[$pipeIndex])) {
                fclose($pipes[$pipeIndex]);
            }
        }

        $exitCode = @proc_close($process);

        if ($timedOut) {
            $key = 'admin_ffmpeg_test_timeout';
            $text = customLang($key) ?: 'Timed out while waiting for the binary to respond.';
            return ['status' => 'error', 'key' => $key, 'message_text' => $text];
        }

        $normalizedOutput = trim($output);
        if ($exitCode !== 0) {
            $versionPattern = $type === 'ffprobe' ? '/ffprobe\s+version/i' : '/ffmpeg\s+version/i';
            if ($normalizedOutput !== '' && preg_match($versionPattern, $normalizedOutput)) {
                $exitCode = 0;
            }
        }
        if ($exitCode !== 0) {
            $key = 'admin_ffmpeg_test_failed';
            $fallback = 'The binary did not respond successfully. Double-check the path.';
            $text = customLang($key) ?: $fallback;
            if ($normalizedOutput !== '') {
                $text .= ' (' . $normalizedOutput . ')';
            }
            return ['status' => 'error', 'key' => $key, 'message_text' => $text];
        }

        if ($normalizedOutput === '') {
            $normalizedOutput = $output;
        }

        $successKey = $type === 'ffprobe' ? 'admin_ffmpeg_test_ffprobe_ok' : 'admin_ffmpeg_test_ffmpeg_ok';
        $template = customLang($successKey) ?: ($type === 'ffprobe' ? 'FFprobe binary responded successfully (%s).' : 'FFmpeg binary responded successfully (%s).');
        $message = sprintf($template, $resolved);

        return ['status' => 'ok', 'key' => $successKey, 'message_text' => $message, 'details' => $normalizedOutput];
    }
}

if (!function_exists('admin_build_binary_test_response')) {
    function admin_build_binary_test_response(array $normalized, string $type): array
    {
        if ($normalized['input'] === '') {
            $key = 'admin_ffmpeg_empty_path';
            $text = customLang($key) ?: 'No custom path provided. The default application fallback will be used.';
            return ['status' => 'empty', 'message' => $key, 'message_text' => $text, 'resolved_path' => null];
        }

        if (!empty($normalized['error'])) {
            $key = $normalized['error'];
            $text = customLang($key) ?: $key;
            return ['status' => 'error', 'message' => $key, 'message_text' => $text, 'resolved_path' => null];
        }

        $test = admin_run_binary_test($normalized['resolved'], $type);

        return [
            'status' => $test['status'],
            'message' => $test['key'],
            'message_text' => $test['message_text'],
            'resolved_path' => $normalized['resolved'],
        ];
    }
}

$action = isset($_POST['action']) ? (string) $_POST['action'] : 'save';

// CSRF
$csrf = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

if ($action === 'test_ffmpeg') {
    $ffmpegPathRaw = isset($_POST['ffmpeg_path']) ? (string) $_POST['ffmpeg_path'] : '';
    $ffprobePathRaw = isset($_POST['ffprobe_bin']) ? (string) $_POST['ffprobe_bin'] : '';

    $ffmpegNormalized = admin_normalize_binary_input($ffmpegPathRaw, 'ffmpeg');
    $ffprobeNormalized = admin_normalize_binary_input($ffprobePathRaw, 'ffprobe');

    $ffmpegResponse = admin_build_binary_test_response($ffmpegNormalized, 'ffmpeg');
    $ffprobeResponse = admin_build_binary_test_response($ffprobeNormalized, 'ffprobe');

    $status = 'success';
    $messageKey = null;
    $messageText = null;

    if ($ffmpegResponse['status'] === 'error' || $ffprobeResponse['status'] === 'error') {
        $status = 'error';
        $messageKey = 'admin_ffmpeg_test_error';
        $messageText = customLang($messageKey) ?: 'One or more binaries failed validation.';
    }

    echo json_encode([
        'status' => $status,
        'message' => $messageKey,
        'message_text' => $messageText,
        'ffmpeg' => $ffmpegResponse,
        'ffprobe' => $ffprobeResponse,
    ]);
    exit;
}

// Inputs
$siteName        = isset($_POST['site_name']) ? trim((string)$_POST['site_name']) : '';
$siteTitle       = isset($_POST['site_title']) ? trim((string)$_POST['site_title']) : '';
$siteDescription = isset($_POST['site_description']) ? trim((string)$_POST['site_description']) : '';
$siteDescriptionMaxLength = 1000;
$siteKeywords    = isset($_POST['site_keywords']) ? trim((string)$_POST['site_keywords']) : '';
$siteLang        = isset($_POST['site_language']) ? trim((string)$_POST['site_language']) : 'eng';
$siteTheme       = isset($_POST['site_theme']) ? trim((string)$_POST['site_theme']) : 'default';
$siteBase        = isset($_POST['site_base_url']) ? trim((string)$_POST['site_base_url']) : '';
$gtmIdRaw        = isset($_POST['gtm_id']) ? strtoupper(trim((string)$_POST['gtm_id'])) : '';
$gtmDisableAdminsRaw = isset($_POST['gtm_disable_admins']) ? (string) $_POST['gtm_disable_admins'] : '0';
$premiumMinRaw   = isset($_POST['premium_post_price_minimum']) ? trim((string)$_POST['premium_post_price_minimum']) : '';
$premiumMaxRaw   = isset($_POST['premium_post_price_maximum']) ? trim((string)$_POST['premium_post_price_maximum']) : '';
$subscriptionFeeRaw = isset($_POST['subscription_fee']) ? trim((string)$_POST['subscription_fee']) : '';
$paymentFeePercentRaw = isset($_POST['payment_fee_percent']) ? trim((string)$_POST['payment_fee_percent']) : '';
$paymentFeeFixedRaw   = isset($_POST['payment_fee_fixed']) ? trim((string)$_POST['payment_fee_fixed']) : '';
$paymentTaxRaw   = isset($_POST['payment_tax_percent']) ? trim((string)$_POST['payment_tax_percent']) : '';
$videoExts       = isset($_POST['available_video_extensions']) ? trim((string)$_POST['available_video_extensions']) : '';
$uploadSizeRaw   = isset($_POST['available_file_upload_size']) ? trim((string)$_POST['available_file_upload_size']) : '';
$maxVideoDurationRaw = isset($_POST['maximum_video_duration']) ? trim((string)$_POST['maximum_video_duration']) : '';
$maxAudioDurationRaw = isset($_POST['maximum_audio_duration']) ? trim((string)$_POST['maximum_audio_duration']) : '';
$imagePostsStatusRaw = isset($_POST['image_posts_status']) ? strtolower(trim((string)$_POST['image_posts_status'])) : 'open';
$videoPostsStatusRaw = isset($_POST['video_posts_status']) ? strtolower(trim((string)$_POST['video_posts_status'])) : 'open';
$podcastPostsStatusRaw = isset($_POST['podcast_posts_status']) ? strtolower(trim((string)$_POST['podcast_posts_status'])) : 'open';
$adsStatusRaw        = isset($_POST['ads_status']) ? strtolower(trim((string)$_POST['ads_status'])) : 'open';
$suggestedUsersStatusRaw = isset($_POST['suggested_users_status']) ? strtolower(trim((string)$_POST['suggested_users_status'])) : 'open';
$suggestedUsersReloadRaw = isset($_POST['suggested_users_reload']) ? strtolower(trim((string)$_POST['suggested_users_reload'])) : 'open';
$suggestedUsersLimitRaw  = isset($_POST['suggested_users_limit']) ? trim((string)$_POST['suggested_users_limit']) : '5';
$suggestedUsersModeRaw   = isset($_POST['suggested_users_mode']) ? strtolower(trim((string)$_POST['suggested_users_mode'])) : 'creators';
$postApprovalRequiredRaw = isset($_POST['post_approval_required']) ? strtolower(trim((string)$_POST['post_approval_required'])) : 'close';
$lockedPreviewModeRaw = isset($_POST['locked_preview_mode']) ? strtolower(trim((string)$_POST['locked_preview_mode'])) : 'off';
$lockedPreviewModeImagesRaw = isset($_POST['locked_preview_mode_images'])
    ? strtolower(trim((string)$_POST['locked_preview_mode_images']))
    : $lockedPreviewModeRaw;
$lockedPreviewModeVideosRaw = isset($_POST['locked_preview_mode_videos'])
    ? strtolower(trim((string)$_POST['locked_preview_mode_videos']))
    : $lockedPreviewModeRaw;
$messageScrollRaw= isset($_POST['message_scroll_limit']) ? trim((string)$_POST['message_scroll_limit']) : '';
$pageScrollRaw   = isset($_POST['page_scroll_limit']) ? trim((string)$_POST['page_scroll_limit']) : '';
$maintenanceStatusRaw = isset($_POST['maintenance']) ? strtolower(trim((string)$_POST['maintenance'])) : 'off';
$maintenanceEtaInput  = isset($_POST['maintenance_eta']) ? trim((string)$_POST['maintenance_eta']) : '';
$maintenanceMessage   = isset($_POST['maintenance_message']) ? trim((string)$_POST['maintenance_message']) : '';
$maintenanceStatusUrlRaw   = isset($_POST['maintenance_status_url']) ? trim((string)$_POST['maintenance_status_url']) : '';
$maintenanceSupportUrlRaw  = isset($_POST['maintenance_support_url']) ? trim((string)$_POST['maintenance_support_url']) : '';
$maintenanceTwitterUrlRaw  = isset($_POST['maintenance_twitter_url']) ? trim((string)$_POST['maintenance_twitter_url']) : '';
$maintenanceFacebookUrlRaw = isset($_POST['maintenance_facebook_url']) ? trim((string)$_POST['maintenance_facebook_url']) : '';
$maintenanceInstagramUrlRaw= isset($_POST['maintenance_instagram_url']) ? trim((string)$_POST['maintenance_instagram_url']) : '';
$maintenanceTiktokUrlRaw   = isset($_POST['maintenance_tiktok_url']) ? trim((string)$_POST['maintenance_tiktok_url']) : '';
$ffmpegPathRaw             = isset($_POST['ffmpeg_path']) ? (string) $_POST['ffmpeg_path'] : '';
$ffprobePathRaw            = isset($_POST['ffprobe_bin']) ? (string) $_POST['ffprobe_bin'] : '';
$registerAutoUsernameRaw   = isset($_POST['register_auto_username']) ? strtolower(trim((string)$_POST['register_auto_username'])) : 'open';
$registerPhoneEnabledRaw   = isset($_POST['register_phone_enabled']) ? strtolower(trim((string)$_POST['register_phone_enabled'])) : 'open';
$registerDialCodesInput    = $_POST['register_phone_dial_codes'] ?? [];

if ($siteName === '' || mb_strlen($siteName) > 120) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_site_name']);
    exit;
}

if (mb_strlen($siteTitle) > 255) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_site_title']);
    exit;
}

if (mb_strlen($siteDescription) > $siteDescriptionMaxLength) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_site_description']);
    exit;
}

if (mb_strlen($siteKeywords) > 500) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_site_keywords']);
    exit;
}

if ($siteBase !== '' && !filter_var($siteBase, FILTER_VALIDATE_URL)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_base_url']);
    exit;
}

$gtmId = '';
if ($gtmIdRaw !== '') {
    if (!preg_match('/^GTM-[A-Z0-9]+$/', $gtmIdRaw)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_gtm_id']);
        exit;
    }
    $gtmId = $gtmIdRaw;
}
$gtmDisableAdmins = in_array(strtolower($gtmDisableAdminsRaw), ['1', 'true', 'yes', 'on'], true);

// Language allowlist from folder
$langDir = dirname(__DIR__, 2) . '/langs';
$allowedLangs = [];
if (is_dir($langDir)) {
    foreach (scandir($langDir) as $f) { if (preg_match('/^(\w+)\.php$/', $f, $m)) { $allowedLangs[] = $m[1]; } }
}
if (!in_array($siteLang, $allowedLangs, true)) { $siteLang = 'eng'; }

// Dial code lists per language (stored in lang overrides).
$registerDialCodesByLang = [];
if (!is_array($registerDialCodesInput)) {
    $registerDialCodesInput = [];
}
foreach ($registerDialCodesInput as $langCodeRaw => $valueRaw) {
    $langCode = strtolower(trim((string) $langCodeRaw));
    if ($langCode === '' || !in_array($langCode, $allowedLangs, true)) {
        continue;
    }
    $value = str_replace("\0", '', (string) $valueRaw);
    if (mb_strlen($value) > 5000) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_register_dial_codes']);
        exit;
    }
    $registerDialCodesByLang[$langCode] = trim($value);
}

// Theme allowlist from themes directory
$themesDir = dirname(__DIR__, 2) . '/themes';
$allowedThemes = [];
if (is_dir($themesDir)) {
    foreach (scandir($themesDir) as $f) {
        if ($f === '.' || $f === '..') { continue; }
        $path = $themesDir . '/' . $f;
        if (is_dir($path) && !str_starts_with($f, '.')) {
            $allowedThemes[] = $f;
        }
    }
}
if (!in_array($siteTheme, $allowedThemes, true) && $allowedThemes) {
    $siteTheme = $allowedThemes[0];
}

// Helper to normalise decimal input
$normDecimal = static function (string $raw, int $scale = 2, bool $allowNull = true): ?string {
    if ($raw === '') { return $allowNull ? null : number_format(0, $scale, '.', ''); }
    $normalized = str_replace([',', ' '], ['.', ''], $raw);
    if (!is_numeric($normalized)) {
        return null;
    }
    $value = round((float)$normalized, $scale);
    if ($value < 0) { $value = 0.0; }
    return number_format($value, $scale, '.', '');
};

$premiumMin = $normDecimal($premiumMinRaw);
if ($premiumMinRaw !== '' && $premiumMin === null) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_premium_min']);
    exit;
}
$premiumMax = $normDecimal($premiumMaxRaw);
if ($premiumMaxRaw !== '' && $premiumMax === null) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_premium_max']);
    exit;
}
if ($premiumMin !== null && $premiumMax !== null && (float)$premiumMin > (float)$premiumMax) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_premium_range']);
    exit;
}

$subscriptionFee = $normDecimal($subscriptionFeeRaw);
if ($subscriptionFeeRaw !== '' && $subscriptionFee === null) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_subscription_fee']);
    exit;
}
if ($subscriptionFee !== null && (float)$subscriptionFee > 100) {
    $subscriptionFee = number_format(100, 2, '.', '');
}

$paymentFeePercent = $normDecimal($paymentFeePercentRaw);
if ($paymentFeePercentRaw !== '' && $paymentFeePercent === null) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_payment_fee_percent']);
    exit;
}
if ($paymentFeePercent !== null && (float)$paymentFeePercent > 100) {
    $paymentFeePercent = number_format(100, 2, '.', '');
}

$paymentFeeFixed = $normDecimal($paymentFeeFixedRaw);
if ($paymentFeeFixedRaw !== '' && $paymentFeeFixed === null) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_payment_fee_fixed']);
    exit;
}

$paymentTaxPercent = $normDecimal($paymentTaxRaw);
if ($paymentTaxRaw !== '' && $paymentTaxPercent === null) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_payment_tax']);
    exit;
}
if ($paymentTaxPercent !== null && (float)$paymentTaxPercent > 100) {
    $paymentTaxPercent = number_format(100, 2, '.', '');
}

if ($videoExts !== '' && !preg_match('/^[a-zA-Z0-9,._\s-]+$/', $videoExts)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_video_extensions']);
    exit;
}

$uploadSize = null;
if ($uploadSizeRaw !== '') {
    if (!ctype_digit($uploadSizeRaw) || (int)$uploadSizeRaw <= 0) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_upload_size']);
        exit;
    }
    $uploadSize = (string)(int)$uploadSizeRaw;
}

$maxVideoDuration = null;
if ($maxVideoDurationRaw !== '') {
    if (!ctype_digit($maxVideoDurationRaw) || (int)$maxVideoDurationRaw <= 0) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_video_duration']);
        exit;
    }
    $maxVideoDuration = (string)(int)$maxVideoDurationRaw;
}

$maxAudioDuration = null;
if ($maxAudioDurationRaw !== '') {
    if (!ctype_digit($maxAudioDurationRaw) || (int)$maxAudioDurationRaw <= 0) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_audio_duration']);
        exit;
    }
    $maxAudioDuration = (string)(int)$maxAudioDurationRaw;
}

$allowedLockedPreviewModes = ['off', 'static', 'animated'];
foreach ([
    $lockedPreviewModeRaw,
    $lockedPreviewModeImagesRaw,
    $lockedPreviewModeVideosRaw
] as $modeCandidate) {
    if (!in_array($modeCandidate, $allowedLockedPreviewModes, true)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_locked_preview_mode']);
        exit;
    }
}
$lockedPreviewMode = $lockedPreviewModeVideosRaw;
$lockedPreviewModeImages = $lockedPreviewModeImagesRaw;
$lockedPreviewModeVideos = $lockedPreviewModeVideosRaw;

$normalizeOpenClose = static function (string $raw, string $default = 'open'): string {
    $v = strtolower(trim($raw));
    if ($v === 'open' || $v === 'close') {
        return $v;
    }
    return $default;
};
$imagePostsStatus = $normalizeOpenClose($imagePostsStatusRaw, 'open');
$videoPostsStatus = $normalizeOpenClose($videoPostsStatusRaw, 'open');
$podcastPostsStatus = $normalizeOpenClose($podcastPostsStatusRaw, 'open');
$adsStatus        = $normalizeOpenClose($adsStatusRaw, 'open');
$suggestedUsersStatus = $normalizeOpenClose($suggestedUsersStatusRaw, 'open');
$suggestedUsersReload = $normalizeOpenClose($suggestedUsersReloadRaw, 'open');
$postApprovalRequired = $normalizeOpenClose($postApprovalRequiredRaw, 'close');
$registerAutoUsername = $normalizeOpenClose($registerAutoUsernameRaw, 'open');
$registerPhoneEnabled = $normalizeOpenClose($registerPhoneEnabledRaw, 'open');

$suggestedUsersLimit = 5;
if ($suggestedUsersLimitRaw !== '') {
    if (!ctype_digit($suggestedUsersLimitRaw)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_suggested_users_limit']);
        exit;
    }
    $suggestedUsersLimit = (int) $suggestedUsersLimitRaw;
    if ($suggestedUsersLimit < 1 || $suggestedUsersLimit > 20) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_suggested_users_limit']);
        exit;
    }
}

$allowedSuggestedModes = ['creators', 'users', 'mixed'];
$suggestedUsersMode = in_array($suggestedUsersModeRaw, $allowedSuggestedModes, true) ? $suggestedUsersModeRaw : 'creators';

$messageScroll = $siteData['message_scroll_limit'] ?? '5';
$pageScroll    = $siteData['page_scroll_limit'] ?? '10';

if ($messageScrollRaw !== '') {
    if (!ctype_digit($messageScrollRaw)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_message_scroll']);
        exit;
    }
    $val = max(1, min(100, (int)$messageScrollRaw));
    $messageScroll = (string)$val;
}

if ($pageScrollRaw !== '') {
    if (!ctype_digit($pageScrollRaw)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_page_scroll']);
        exit;
    }
    $val = max(1, min(100, (int)$pageScrollRaw));
    $pageScroll = (string)$val;
}

$ffmpegBinary = admin_normalize_binary_input($ffmpegPathRaw, 'ffmpeg');
if ($ffmpegBinary['error'] !== null) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $ffmpegBinary['error']]);
    exit;
}

$ffprobeBinary = admin_normalize_binary_input($ffprobePathRaw, 'ffprobe');
if ($ffprobeBinary['error'] !== null) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $ffprobeBinary['error']]);
    exit;
}

$maintenanceStatus = $maintenanceStatusRaw === 'on' ? 'on' : 'off';

$maintenanceEta = null;
if ($maintenanceEtaInput !== '') {
    $timezoneId = @date_default_timezone_get() ?: 'UTC';
    try {
        $maintenanceTz = new DateTimeZone($timezoneId);
    } catch (Throwable $__) {
        $maintenanceTz = new DateTimeZone('UTC');
    }
    $maintenanceDate = DateTime::createFromFormat('Y-m-d\TH:i', $maintenanceEtaInput, $maintenanceTz);
    if (!$maintenanceDate) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_maintenance_eta']);
        exit;
    }
    $maintenanceEta = $maintenanceDate->getTimestamp();
    if ($maintenanceEta <= 0) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_maintenance_eta']);
        exit;
    }
}

if ($maintenanceMessage !== '') {
    if (mb_strlen($maintenanceMessage) > 2000) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_maintenance_message']);
        exit;
    }
}

$validateMaintenanceUrl = static function (string $value) {
    $value = trim($value);
    if ($value === '') {
        return null;
    }
    if (!preg_match('~^https?://~i', $value) || !filter_var($value, FILTER_VALIDATE_URL)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_maintenance_url']);
        exit;
    }
    return $value;
};

$maintenanceStatusUrl   = $validateMaintenanceUrl($maintenanceStatusUrlRaw);
$maintenanceSupportUrl  = $validateMaintenanceUrl($maintenanceSupportUrlRaw);
$maintenanceTwitterUrl  = $validateMaintenanceUrl($maintenanceTwitterUrlRaw);
$maintenanceFacebookUrl = $validateMaintenanceUrl($maintenanceFacebookUrlRaw);
$maintenanceInstagramUrl= $validateMaintenanceUrl($maintenanceInstagramUrlRaw);
$maintenanceTiktokUrl   = $validateMaintenanceUrl($maintenanceTiktokUrlRaw);

$canon = static function ($value): ?string {
    $value = trim((string)$value);
    return $value === '' ? null : $value;
};

$prevMaintenanceStatus = strtolower((string)($siteData['maintenance'] ?? 'off')) === 'on' ? 'on' : 'off';
$prevMaintenanceEta = null;
if (isset($siteData['maintenance_eta']) && is_numeric($siteData['maintenance_eta'])) {
    $prevMaintenanceEta = (int)$siteData['maintenance_eta'];
    if ($prevMaintenanceEta <= 0) {
        $prevMaintenanceEta = null;
    }
}
$prevMaintenanceMessage = trim((string)($siteData['maintenance_message'] ?? ''));
$prevMaintenanceStatusUrl   = $canon($siteData['maintenance_status_url'] ?? ($siteData['status_page_url'] ?? ''));
$prevMaintenanceSupportUrl  = $canon($siteData['maintenance_support_url'] ?? ($siteData['support_url'] ?? ''));
$prevMaintenanceTwitterUrl  = $canon($siteData['maintenance_twitter_url'] ?? ($siteData['twitter_url'] ?? ''));
$prevMaintenanceFacebookUrl = $canon($siteData['maintenance_facebook_url'] ?? ($siteData['facebook_url'] ?? ''));
$prevMaintenanceInstagramUrl= $canon($siteData['maintenance_instagram_url'] ?? ($siteData['instagram_url'] ?? ''));
$prevMaintenanceTiktokUrl   = $canon($siteData['maintenance_tiktok_url'] ?? ($siteData['tiktok_url'] ?? ''));

$maintenanceDirty = (
    $maintenanceStatus !== $prevMaintenanceStatus
    || ($maintenanceEta ?? null) !== ($prevMaintenanceEta ?? null)
    || $maintenanceMessage !== $prevMaintenanceMessage
    || $maintenanceStatusUrl !== $prevMaintenanceStatusUrl
    || $maintenanceSupportUrl !== $prevMaintenanceSupportUrl
    || $maintenanceTwitterUrl !== $prevMaintenanceTwitterUrl
    || $maintenanceFacebookUrl !== $prevMaintenanceFacebookUrl
    || $maintenanceInstagramUrl !== $prevMaintenanceInstagramUrl
    || $maintenanceTiktokUrl !== $prevMaintenanceTiktokUrl
);

$maintenanceMessageForDb = $maintenanceMessage === '' ? null : $maintenanceMessage;


// Handle logo uploads with MIME validation and re-encode
function saveLogo(string $fileKey): array
{
    $maxBytes = 5 * 1024 * 1024; // 5MB limit

    if (!isset($_FILES[$fileKey]) || !isset($_FILES[$fileKey]['tmp_name'])) {
        return ['path' => null, 'error' => null];
    }

    $file = $_FILES[$fileKey];
    if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return ['path' => null, 'error' => null];
    }

    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
        return ['path' => null, 'error' => 'upload_failed'];
    }

    $tmp = (string)($file['tmp_name'] ?? '');
    if ($tmp === '' || !is_uploaded_file($tmp)) {
        return ['path' => null, 'error' => 'upload_failed'];
    }

    $size = (int)($file['size'] ?? 0);
    if ($size <= 0 || $size > $maxBytes) {
        return ['path' => null, 'error' => 'file_too_large'];
    }

    $fi = @finfo_open(FILEINFO_MIME_TYPE);
    $mime = $fi ? (string)@finfo_file($fi, $tmp) : '';
    if ($fi) { @finfo_close($fi); }

    $allowedMimes = ['image/png', 'image/jpeg', 'image/webp'];
    if (!in_array($mime, $allowedMimes, true)) {
        return ['path' => null, 'error' => 'invalid_image_type']; // i18n key
    }

    // Decode using GD and re-encode to PNG or JPEG
    $img = null;
    $targetExt = 'jpg';
    $preserveAlpha = false;
    try {
        if ($mime === 'image/png') {
            $img = @imagecreatefrompng($tmp);
            $targetExt = 'png';
            $preserveAlpha = true;
        } elseif ($mime === 'image/jpeg') {
            $img = @imagecreatefromjpeg($tmp);
            $targetExt = 'jpg';
        } elseif ($mime === 'image/webp') {
            if (function_exists('imagecreatefromwebp')) {
                $img = @imagecreatefromwebp($tmp);
                $targetExt = 'png'; // Preserve transparency from WebP by re-encoding to PNG
                $preserveAlpha = true;
            } else {
                return ['path' => null, 'error' => 'invalid_image_type'];
            }
        }
    } catch (Throwable $__) {
        $img = null;
    }

    if (!$img) {
        return ['path' => null, 'error' => 'invalid_image_file'];
    }

    if ($preserveAlpha) {
        if (function_exists('imagepalettetotruecolor')) {
            @imagepalettetotruecolor($img);
        }
        @imagealphablending($img, false);
        @imagesavealpha($img, true);
    }

    $targetDir = dirname(__DIR__, 2) . '/uploads/logo';
    if (!is_dir($targetDir)) {
        @mkdir($targetDir, 0755, true);
        @chmod($targetDir, 0755);
    }

    try {
        $random = bin2hex(random_bytes(16));
    } catch (Throwable $__) {
        $random = md5(uniqid('', true));
    }

    $fileName = 'logo-' . $fileKey . '-' . $random . '.' . $targetExt;
    $path = $targetDir . '/' . $fileName;

    $writeOk = false;
    if ($targetExt === 'png') {
        // Compression level 0 (no compression) to 9. Use 6 as balance.
        $writeOk = @imagepng($img, $path, 6);
    } else {
        // JPEG quality 0-100
        $writeOk = @imagejpeg($img, $path, 85);
    }
    @imagedestroy($img);

    if (!$writeOk || !file_exists($path)) {
        return ['path' => null, 'error' => 'upload_failed'];
    }

    @chmod($path, 0644);

    return ['path' => 'uploads/logo/' . $fileName, 'error' => null];
}

$resWhite = saveLogo('logo_white');
if ($resWhite['error'] !== null) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $resWhite['error']]);
    exit;
}
$logoWhite = $resWhite['path'];

$resDark = saveLogo('logo_dark');
if ($resDark['error'] !== null) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $resDark['error']]);
    exit;
}
$logoDark = $resDark['path'];

$resMobileWhite = saveLogo('logo_mobile_white');
if ($resMobileWhite['error'] !== null) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $resMobileWhite['error']]);
    exit;
}
$logoMobileWhite = $resMobileWhite['path'];

$resMobileDark = saveLogo('logo_mobile_dark');
if ($resMobileDark['error'] !== null) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $resMobileDark['error']]);
    exit;
}
$logoMobileDark = $resMobileDark['path'];

// Build update
$set = [
    'site_name'                 => $siteName,
    'site_language'             => $siteLang,
    'site_title'                => $siteTitle,
    'site_description'          => $siteDescription,
    'site_keywords'             => $siteKeywords,
    'site_theme'                => $siteTheme,
    'gtm_id'                    => $gtmId !== '' ? $gtmId : null,
    'gtm_disable_admins'        => $gtmDisableAdmins ? 1 : 0,
    'message_scroll_limit'      => $messageScroll,
    'page_scroll_limit'         => $pageScroll,
    'register_auto_username'    => $registerAutoUsername,
    'register_phone_enabled'    => $registerPhoneEnabled,
    'maintenance'              => $maintenanceStatus,
    'maintenance_eta'          => $maintenanceEta,
    'maintenance_message'      => $maintenanceMessageForDb,
    'maintenance_status_url'   => $maintenanceStatusUrl,
    'maintenance_support_url'  => $maintenanceSupportUrl,
    'maintenance_twitter_url'  => $maintenanceTwitterUrl,
    'maintenance_facebook_url' => $maintenanceFacebookUrl,
    'maintenance_instagram_url'=> $maintenanceInstagramUrl,
    'maintenance_tiktok_url'   => $maintenanceTiktokUrl,
    'ffmpeg_path'               => $ffmpegBinary['value'],
    'ffmpeg_probe_bin'          => $ffprobeBinary['value'],
];
if ($siteBase !== '') { $set['site_base_url'] = rtrim($siteBase, '/') . '/'; } else { $set['site_base_url'] = null; }
if ($logoWhite !== null) { $set['logo_white'] = $logoWhite; }
if ($logoDark  !== null) { $set['logo_dark']  = $logoDark; }
if ($logoMobileWhite !== null) { $set['logo_mobile_white'] = $logoMobileWhite; }
if ($logoMobileDark  !== null) { $set['logo_mobile_dark']  = $logoMobileDark; }
if ($premiumMin !== null) { $set['premium_post_price_minimum'] = $premiumMin; }
if ($premiumMax !== null) { $set['premium_post_price_maximum'] = $premiumMax; }
$set['payment_fee_percent'] = $paymentFeePercent;
$set['payment_fee_fixed'] = $paymentFeeFixed;
$set['payment_tax_percent'] = $paymentTaxPercent;
if ($subscriptionFee !== null) { $set['subscription_fee'] = $subscriptionFee; }
$set['available_video_extensions'] = $videoExts;
$set['available_file_upload_size'] = $uploadSize;
$set['maximum_video_duration']     = $maxVideoDuration;
$set['maximum_audio_duration']     = $maxAudioDuration;
$set['locked_preview_mode']        = $lockedPreviewMode;
$set['locked_preview_mode_images'] = $lockedPreviewModeImages;
$set['locked_preview_mode_videos'] = $lockedPreviewModeVideos;
$set['image_posts_status']         = $imagePostsStatus;
$set['video_posts_status']         = $videoPostsStatus;
$set['podcast_posts_status']       = $podcastPostsStatus;
$set['ads_status']                 = $adsStatus;
$set['suggested_users_status']     = $suggestedUsersStatus;
$set['suggested_users_limit']      = $suggestedUsersLimit;
$set['suggested_users_reload']     = $suggestedUsersReload;
$set['suggested_users_mode']       = $suggestedUsersMode;
$set['post_approval_required']     = $postApprovalRequired;

if ($maintenanceDirty) {
    $maintenanceUpdatedAtTs = time();
    $set['maintenance_updated_at'] = $maintenanceUpdatedAtTs;
    $maintenanceUpdaterId = isset($userData['user_id']) ? (int)$userData['user_id'] : 0;
    $set['maintenance_updated_by'] = $maintenanceUpdaterId > 0 ? $maintenanceUpdaterId : null;
} else {
    $maintenanceUpdatedAtTs = null;
}

try {
    // Ensure DB columns
    try { $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS gtm_id VARCHAR(32) NULL"); } catch (Throwable $__) {}
    try { $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS gtm_disable_admins TINYINT(1) NOT NULL DEFAULT 0"); } catch (Throwable $__) {}
    try { $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS site_base_url VARCHAR(255) NULL"); } catch (Throwable $__) {}
    try { $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS ffmpeg_path TEXT NULL"); } catch (Throwable $__) {}
    try { $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS ffmpeg_probe_bin TEXT NULL"); } catch (Throwable $__) {}
    try {
        $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS locked_preview_mode ENUM('off','static','animated') NOT NULL DEFAULT 'off'");
    } catch (Throwable $__) {}
    try {
        $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS locked_preview_mode_images ENUM('off','static','animated') NOT NULL DEFAULT 'off'");
    } catch (Throwable $__) {}
    try {
        $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS locked_preview_mode_videos ENUM('off','static','animated') NOT NULL DEFAULT 'off'");
    } catch (Throwable $__) {}
    try { $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS image_posts_status ENUM('open','close') NOT NULL DEFAULT 'open'"); } catch (Throwable $__) {}
    try { $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS video_posts_status ENUM('open','close') NOT NULL DEFAULT 'open'"); } catch (Throwable $__) {}
    try { $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS podcast_posts_status ENUM('open','close') NOT NULL DEFAULT 'open'"); } catch (Throwable $__) {}
    try { $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS ads_status ENUM('open','close') NOT NULL DEFAULT 'open'"); } catch (Throwable $__) {}
    try { $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS maximum_audio_duration INT NULL"); } catch (Throwable $__) {}
    try { $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS suggested_users_status ENUM('open','close') NOT NULL DEFAULT 'open'"); } catch (Throwable $__) {}
    try { $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS suggested_users_limit INT UNSIGNED NOT NULL DEFAULT 5"); } catch (Throwable $__) {}
    try { $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS suggested_users_reload ENUM('open','close') NOT NULL DEFAULT 'open'"); } catch (Throwable $__) {}
    try { $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS suggested_users_mode ENUM('creators','users','mixed') NOT NULL DEFAULT 'creators'"); } catch (Throwable $__) {}
    try { $db->exec("ALTER TABLE i_site_configurations ADD COLUMN IF NOT EXISTS post_approval_required ENUM('open','close') NOT NULL DEFAULT 'close'"); } catch (Throwable $__) {}
    $parts = [];
    $params = [];
    foreach ($set as $k => $v) {
        $parts[] = "$k = :$k";
        $params[':' . $k] = $v;
    }
    $params[':id'] = 1;
    $sql = 'UPDATE i_site_configurations SET ' . implode(', ', $parts) . ' WHERE id = :id';
    $st = $db->prepare($sql);
    $st->execute($params);

    // Update per-language dial code lists in lang overrides.
    if (!empty($registerDialCodesByLang)) {
        $nowTs = time();
        $upsert = $db->prepare(
            'INSERT INTO i_lang_overrides (language, lang_key, value, updated_at)
             VALUES (:lang, :key, :val, :t)
             ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = VALUES(updated_at)'
        );
        $delete = $db->prepare('DELETE FROM i_lang_overrides WHERE language = :lang AND lang_key = :key');
        foreach ($registerDialCodesByLang as $langCode => $dialList) {
            if ($dialList === '') {
                $delete->execute([':lang' => $langCode, ':key' => 'register_phone_dial_codes_list']);
                continue;
            }
            $upsert->execute([
                ':lang' => $langCode,
                ':key' => 'register_phone_dial_codes_list',
                ':val' => $dialList,
                ':t' => $nowTs,
            ]);
        }
    }

    // Audit
    try { $db->exec("CREATE TABLE IF NOT EXISTS i_admin_audit (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, user_id INT UNSIGNED NOT NULL, action VARCHAR(64) NOT NULL, target_key VARCHAR(64) NOT NULL, created_at INT UNSIGNED NOT NULL, PRIMARY KEY(id), KEY idx_user_time(user_id, created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"); } catch (Throwable $__) {}
    try {
        $au = $db->prepare('INSERT INTO i_admin_audit (user_id, action, target_key, created_at) VALUES (:u,:a,:t,:c)');
        foreach (array_keys($set) as $k) {
            $au->execute([':u' => (int)$userData['user_id'], ':a' => 'update_setting', ':t' => $k, ':c' => time()]);
        }
        if ($maintenanceDirty && isset($ADM) && $ADM instanceof Admin_Data) {
            $summary = 'maintenance:' . $maintenanceStatus;
            if ($maintenanceEta !== null) {
                $summary .= '|eta=' . $maintenanceEta;
            }
            if ($maintenanceMessage !== '') {
                $preview = preg_replace('/\s+/', ' ', $maintenanceMessage);
                if ($preview === null) {
                    $preview = $maintenanceMessage;
                }
                if (function_exists('mb_substr')) {
                    $preview = mb_substr($preview, 0, 40);
                } else {
                    $preview = substr($preview, 0, 40);
                }
                if ($preview !== '') {
                    $summary .= '|msg=' . $preview;
                }
            }
            $summary = substr($summary, 0, 60);
            $ADM->ADM_Audit((int)$userData['user_id'], 'maintenance_update', $summary, $maintenanceUpdatedAtTs ?? time());
        }
    } catch (Throwable $__) {}

    echo json_encode(['status' => 'success']);
    exit;
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}
