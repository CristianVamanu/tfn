<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

$acceptHeader = (string)($_SERVER['HTTP_ACCEPT'] ?? '');
$xhrHeader    = (string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '');
$isAjax       = (stripos($acceptHeader, 'application/json') !== false)
    || (strcasecmp($xhrHeader, 'XMLHttpRequest') === 0);

if ($isAjax) {
    header('Content-Type: application/json; charset=utf-8');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if ($isAjax) {
        http_response_code(405);
        echo json_encode(['status' => 'error', 'message' => 'method_not_allowed']);
        exit;
    }
    http_response_code(405);
    exit;
}

$csrfToken = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
if (!checkCsrfToken($csrfToken)) {
    if ($isAjax) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
        exit;
    }
    $_SESSION['admin_fake_generator_flash'] = [
        'type'    => 'error',
        'message' => customLang('invalid_csrf_token') ?: 'Invalid request token.',
    ];
    header('Location: ' . $base_url . 'admin/generate_fake_user.php');
    exit;
}

$action = isset($_POST['action']) ? trim((string)$_POST['action']) : 'generate';

if (!in_array($action, ['generate', 'delete_selected'], true)) {
    if ($isAjax) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'bad_action']);
        exit;
    }
    $_SESSION['admin_fake_generator_flash'] = [
        'type'    => 'error',
        'message' => customLang('admin_fake_generator_error') ?: 'Unable to create fake users.',
    ];
    header('Location: ' . $base_url . 'admin/generate_fake_user.php');
    exit;
}

if ($action === 'delete_selected') {
    $selected = isset($_POST['user_ids']) && is_array($_POST['user_ids']) ? array_map('intval', (array)$_POST['user_ids']) : [];
    $selected = array_values(array_unique(array_filter($selected, static function (int $v): bool { return $v > 0; })));

    if (empty($selected)) {
        $message = customLang('admin_fake_generator_delete_none') ?: 'Select at least one fake user.';
        if ($isAjax) {
            http_response_code(422);
            echo json_encode(['status' => 'error', 'message' => $message]);
            exit;
        }
        $_SESSION['admin_fake_generator_flash'] = [
            'type'    => 'error',
            'message' => $message,
        ];
        header('Location: ' . $base_url . 'admin/generate_fake_user.php');
        exit;
    }

    $db = $ADM->db();
    $placeholders = implode(',', array_fill(0, count($selected), '?'));
    $validIds = [];
    try {
        $stmt = $db->prepare('SELECT user_id FROM i_users WHERE is_fake = 1 AND user_id IN (' . $placeholders . ')');
        $stmt->execute($selected);
        $validIds = $stmt->fetchAll(PDO::FETCH_COLUMN, 0) ?: [];
    } catch (Throwable $e) {
        $errMessage = customLang('admin_fake_generator_delete_error') ?: 'Unable to delete fake users.';
        if ($isAjax) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => $errMessage]);
            exit;
        }
        $_SESSION['admin_fake_generator_flash'] = [
            'type'    => 'error',
            'message' => $errMessage,
        ];
        header('Location: ' . $base_url . 'admin/generate_fake_user.php');
        exit;
    }

    if (empty($validIds)) {
        $message = customLang('admin_fake_generator_delete_invalid') ?: 'Selected users are not fake anymore.';
        if ($isAjax) {
            http_response_code(422);
            echo json_encode(['status' => 'error', 'message' => $message]);
            exit;
        }
        $_SESSION['admin_fake_generator_flash'] = [
            'type'    => 'error',
            'message' => $message,
        ];
        header('Location: ' . $base_url . 'admin/generate_fake_user.php');
        exit;
    }

    $deleted = 0;
    $adminId = (int)($userData['user_id'] ?? 0);
    foreach ($validIds as $id) {
        $uid = (int) $id;
        if ($uid <= 0) { continue; }
        if ($ADM->ADM_DeleteUserCascade($uid)) {
            $deleted++;
            $ADM->ADM_Audit($adminId, 'fake_user_delete', 'user:' . $uid);
        }
    }

    $perPage = isset($_POST['per']) ? max(5, min(100, (int)$_POST['per'])) : 20;
    $paginated = $ADM->ADM_PagedUsers('', 1, $perPage, ['fake' => '1']);
    $rows      = $paginated['rows'];
    $total     = (int)($paginated['total'] ?? 0);
    $pages     = (int)max(1, ceil($total / max(1, $perPage)));

    $iconPath = $iconPath ?? ($base_url . 'themes/default/icons/');

    ob_start();
    $adminUsersTableRows          = $rows;
    $adminUsersTableBaseUrl       = $base_url;
    $adminUsersTableIconPath      = $iconPath;
    $adminUsersTableUserData      = $userData;
    $adminUsersShowFakeBadge      = true;
    $adminUsersTablePagination    = [
        'base_url' => $base_url . 'admin/generate_fake_user.php',
        'params'   => ['per' => (string)$perPage],
        'page'     => 1,
        'pages'    => $pages,
        'options'  => ['show_goto' => true, 'radius' => 1],
    ];
    include __DIR__ . '/../pages/partials/users_table.php';
    $tableHtml = ob_get_clean();

    $messageTpl = customLang('admin_fake_generator_delete_success') ?: 'Deleted :count fake users.';
    $message    = str_replace(':count', (string)$deleted, $messageTpl);

    if ($isAjax) {
        echo json_encode([
            'status'        => 'success',
            'deleted_count' => $deleted,
            'table_html'    => $tableHtml,
            'message'       => $message,
        ]);
        exit;
    }

    $_SESSION['admin_fake_generator_flash'] = [
        'type'    => 'success',
        'message' => $message,
    ];
    header('Location: ' . $base_url . 'admin/generate_fake_user.php');
    exit;
}

$countRaw  = $_POST['fake_user_count'] ?? null;
$password  = isset($_POST['fake_user_password']) ? trim((string)$_POST['fake_user_password']) : '';
$count     = is_numeric($countRaw) ? (int)$countRaw : 0;

$errors = [];
if ($count < 1 || $count > 1000) {
    $errors[] = 'invalid_count';
}
$pwLen = strlen($password);
if ($pwLen < 8 || $pwLen > 64) {
    $errors[] = 'invalid_password';
}

if (!empty($errors)) {
    if ($isAjax) {
        http_response_code(422);
        echo json_encode([
            'status' => 'error',
            'message' => $errors[0],
            'errors'  => $errors,
        ]);
        exit;
    }
    $msg = $errors[0] === 'invalid_password'
        ? (customLang('admin_fake_generator_invalid_password') ?: 'Password must be between 8 and 64 characters.')
        : (customLang('admin_fake_generator_invalid_count') ?: 'Count must be between 1 and 1000.');
    $_SESSION['admin_fake_generator_flash'] = [
        'type'    => 'error',
        'message' => $msg,
    ];
    header('Location: ' . $base_url . 'admin/generate_fake_user.php');
    exit;
}

$result = $ADM->ADM_CreateFakeUsers($count, $password);

if (!empty($result['errors'])) {
    if ($isAjax) {
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => $result['errors'][0] ?? 'server_error',
            'errors'  => $result['errors'],
        ]);
        exit;
    }
    $_SESSION['admin_fake_generator_flash'] = [
        'type'    => 'error',
        'message' => customLang('admin_fake_generator_error') ?: 'Unable to create fake users.',
    ];
    header('Location: ' . $base_url . 'admin/generate_fake_user.php');
    exit;
}

$created = (int)($result['created'] ?? 0);
$createdUsers = $result['users'] ?? [];

$adminId = (int)($userData['user_id'] ?? 0);
foreach ($createdUsers as $userRow) {
    if (!isset($userRow['id'])) {
        continue;
    }
    $target = 'user:' . (int)$userRow['id'];
    $ADM->ADM_Audit($adminId, 'fake_user_create', $target);
}

$perPage = isset($_POST['per']) ? max(5, min(100, (int)$_POST['per'])) : 20;
$paginated = $ADM->ADM_PagedUsers('', 1, $perPage, ['fake' => '1']);
$rows      = $paginated['rows'];
$total     = (int)($paginated['total'] ?? 0);
$pages     = (int)max(1, ceil($total / max(1, $perPage)));

$iconPath = $iconPath ?? ($base_url . 'themes/default/icons/'); // ensure defined for partial

ob_start();
$adminUsersTableRows          = $rows;
$adminUsersTableBaseUrl       = $base_url;
$adminUsersTableIconPath      = $iconPath;
$adminUsersTableUserData      = $userData;
$adminUsersShowFakeBadge      = true;
$adminUsersTablePagination    = [
    'base_url' => $base_url . 'admin/generate_fake_user.php',
    'params'   => ['per' => (string)$perPage],
    'page'     => 1,
    'pages'    => $pages,
    'options'  => ['show_goto' => false, 'radius' => 1],
];
include __DIR__ . '/../pages/partials/users_table.php';
$tableHtml = ob_get_clean();

if ($isAjax) {
    echo json_encode([
        'status'        => 'success',
        'created_count' => $created,
        'users'         => $createdUsers,
        'table_html'    => $tableHtml,
        'message'       => customLang('admin_fake_generator_success') ? str_replace(':count', (string)$created, customLang('admin_fake_generator_success')) : ($created . ' fake users created.'),
    ]);
    exit;
}

$successMsg = customLang('admin_fake_generator_success') ? str_replace(':count', (string)$created, customLang('admin_fake_generator_success')) : ($created . ' fake users created.');
$_SESSION['admin_fake_generator_flash'] = [
    'type'    => 'success',
    'message' => $successMsg,
];
header('Location: ' . $base_url . 'admin/generate_fake_user.php');
exit;
