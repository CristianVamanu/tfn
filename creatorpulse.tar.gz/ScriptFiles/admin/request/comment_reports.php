<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

$csrf = isset($_POST['csrf_token']) ? (string) $_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$action    = isset($_POST['action']) ? (string) $_POST['action'] : '';
$reportId  = isset($_POST['report_id']) ? (int) $_POST['report_id'] : 0;
$commentId = isset($_POST['comment_id']) ? (int) $_POST['comment_id'] : 0;
$meId      = (int) ($userData['user_id'] ?? 0);

$permMap = [
    'resolve' => 'reports.resolve',
    'delete_comment' => 'reports.delete_comment',
];
$permKey = $permMap[$action] ?? '';
if ($permKey !== '' && !admin_has_permission($permKey)) {
    admin_forbidden_json();
}

try {
    if ($action === 'resolve') {
        if ($reportId <= 0) {
            throw new InvalidArgumentException('bad_report');
        }

        $st = $ADM->db()->prepare('DELETE FROM i_comment_reports WHERE id = :id LIMIT 1');
        $st->bindValue(':id', $reportId, \PDO::PARAM_INT);
        $st->execute();
        if ($st->rowCount() <= 0) {
            throw new RuntimeException('not_found');
        }

        $ADM->ADM_Audit($meId, 'resolve_comment_report', 'comment_report:' . $reportId);

        $responseData = [
            'report_id'  => $reportId,
            'comment_id' => $commentId > 0 ? $commentId : null,
        ];
        echo json_encode(['status' => 'success', 'data' => $responseData]);
        exit;
    }

    if ($action === 'delete_comment') {
        if ($commentId <= 0 && $reportId > 0) {
            try {
                $lookup = $ADM->db()->prepare('SELECT comment_id FROM i_comment_reports WHERE id = :id LIMIT 1');
                $lookup->bindValue(':id', $reportId, \PDO::PARAM_INT);
                $lookup->execute();
                $commentId = (int) ($lookup->fetchColumn() ?: 0);
            } catch (\Throwable $e) {
                // fallthrough - will trigger invalid argument below if still 0
            }
        }

        if ($commentId <= 0) {
            throw new InvalidArgumentException('bad_comment');
        }

        $deleted = false;
        $rl = $ADM->rl();

        if ($rl && method_exists($rl, 'RL_DeleteComment')) {
            $res = $rl->RL_DeleteComment($commentId, $meId > 0 ? $meId : 0, true);
            $deleted = !empty($res['deleted']);
        }

        if (!$deleted) {
            $db = $ADM->db();
            $db->beginTransaction();
            try {
                $del = $db->prepare('DELETE FROM i_comments WHERE c_id = :cid LIMIT 1');
                $del->bindValue(':cid', $commentId, \PDO::PARAM_INT);
                $del->execute();
                if ($del->rowCount() <= 0) {
                    throw new RuntimeException('delete_failed');
                }

                $db->prepare('DELETE FROM i_comment_reports WHERE comment_id = :cid')->execute([':cid' => $commentId]);
                if ($reportId > 0) {
                    $db->prepare('DELETE FROM i_comment_reports WHERE id = :id')->execute([':id' => $reportId]);
                }
                $db->prepare('DELETE FROM i_comment_liked WHERE c_liked_comment_id = :cid')->execute([':cid' => $commentId]);
                $db->prepare("DELETE FROM i_notifications WHERE type IN ('comment','comment_like','mention') AND object_id = :cid")->execute([':cid' => $commentId]);

                $db->commit();
                $deleted = true;
            } catch (\Throwable $inner) {
                if ($db->inTransaction()) {
                    $db->rollBack();
                }
                throw $inner;
            }
        }

        if (!$deleted) {
            throw new RuntimeException('delete_failed');
        }

        $ADM->ADM_Audit($meId, 'delete_comment', 'comment:' . $commentId);

        echo json_encode(['status' => 'success', 'data' => ['comment_id' => $commentId, 'report_id' => $reportId > 0 ? $reportId : null]]);
        exit;
    }

    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'bad_action']);
    exit;
} catch (InvalidArgumentException $e) {
    http_response_code(400);
    $msg = $e->getMessage();
    echo json_encode(['status' => 'error', 'message' => $msg !== '' ? $msg : 'bad_request']);
    exit;
} catch (\RuntimeException $e) {
    $msg = $e->getMessage();
    $status = ($msg === 'not_found') ? 404 : 500;
    http_response_code($status);
    echo json_encode(['status' => 'error', 'message' => $msg !== '' ? $msg : 'op_failed']);
    exit;
} catch (\Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'op_failed']);
    exit;
}
