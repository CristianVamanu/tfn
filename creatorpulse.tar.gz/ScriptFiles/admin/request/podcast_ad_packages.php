<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

$csrf = (string) ($_POST['csrf_token'] ?? '');
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$action = strtolower(trim((string) ($_POST['action'] ?? 'save')));
$packageId = isset($_POST['package_id']) ? (int) $_POST['package_id'] : null;

if (!in_array($action, ['save', 'delete'], true)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'invalid_request']);
    exit;
}

if ($action === 'delete') {
    $pid = $packageId !== null ? $packageId : 0;
    if ($pid <= 0) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_id']);
        exit;
    }
    $deleted = $ADM->ADM_DeletePodcastAdPackage($pid);
    echo json_encode([
        'status'  => $deleted ? 'success' : 'error',
        'message' => $deleted ? customLang('hero_ads_package_deleted', 'Package removed.') : customLang('hero_ads_payment_failed', 'Operation failed.'),
    ]);
    exit;
}

$availableLanguages = function_exists('discoverAvailableLanguages') ? discoverAvailableLanguages() : ['eng'];
if (!$availableLanguages) {
    $availableLanguages = ['eng'];
}
$availableLanguages = array_values(array_unique(array_map(static function ($lng) {
    return strtolower(trim((string) $lng));
}, $availableLanguages)));

$defaultLang = isset($_POST['default_lang']) ? strtolower(trim((string) $_POST['default_lang'])) : ($availableLanguages[0] ?? 'eng');
if ($defaultLang === '' || !in_array($defaultLang, $availableLanguages, true)) {
    $defaultLang = $availableLanguages[0] ?? 'eng';
}

$nameInput = $_POST['name'] ?? '';
$descriptionInput = $_POST['description'] ?? '';
$nameMap = [];
if (is_array($nameInput)) {
    foreach ($nameInput as $lng => $val) {
        $lngKey = strtolower(trim((string) $lng));
        if ($lngKey === '' || !in_array($lngKey, $availableLanguages, true)) {
            continue;
        }
        $nameMap[$lngKey] = trim((string) $val);
    }
} else {
    $nameMap[$defaultLang] = trim((string) $nameInput);
}

$descMap = [];
if (is_array($descriptionInput)) {
    foreach ($descriptionInput as $lng => $val) {
        $lngKey = strtolower(trim((string) $lng));
        if ($lngKey === '' || !in_array($lngKey, $availableLanguages, true)) {
            continue;
        }
        $descMap[$lngKey] = trim((string) $val);
    }
} else {
    $descMap[$defaultLang] = trim((string) $descriptionInput);
}

$name = $nameMap[$defaultLang] ?? '';
if ($name === '') {
    foreach ($nameMap as $val) {
        if ($val !== '') {
            $name = $val;
            break;
        }
    }
}
$price = isset($_POST['price']) ? (float) $_POST['price'] : 0.0;
$currency = strtoupper(trim((string) ($_POST['currency'] ?? 'USD')));
$durationDays = isset($_POST['duration_days']) ? (int) $_POST['duration_days'] : 0;
$dailyCap = isset($_POST['daily_cap']) && $_POST['daily_cap'] !== '' ? (int) $_POST['daily_cap'] : null;
$totalCap = isset($_POST['total_cap']) && $_POST['total_cap'] !== '' ? (int) $_POST['total_cap'] : null;
$premiumMultiplier = isset($_POST['premium_multiplier']) ? (float) $_POST['premium_multiplier'] : 1.0;
$targetingFee = isset($_POST['targeting_fee']) && $_POST['targeting_fee'] !== '' ? (float) $_POST['targeting_fee'] : null;
$status = strtolower(trim((string) ($_POST['status'] ?? 'active')));
$sortOrder = isset($_POST['sort_order']) ? (int) $_POST['sort_order'] : 0;
$description = $descMap[$defaultLang] ?? '';
if ($description === '' && $descMap) {
    foreach ($descMap as $val) {
        if ($val !== '') {
            $description = $val;
            break;
        }
    }
}

if ($name === '' || $price <= 0) {
    http_response_code(422);
    echo json_encode(['status' => 'error', 'message' => customLang('hero_ads_package_required', 'Name and price are required.')]);
    exit;
}

if ($durationDays <= 0) {
    $durationDays = 7;
}

$translations = [];
foreach ($availableLanguages as $lng) {
    $lngKey = strtolower((string) $lng);
    $translations[$lngKey] = [
        'name'        => $nameMap[$lngKey] ?? $name,
        'description' => $descMap[$lngKey] ?? $description,
    ];
}

$data = [
    'name'               => $name,
    'description'        => $description,
    'price'              => $price,
    'currency'           => $currency !== '' ? $currency : 'USD',
    'duration_days'      => $durationDays,
    'daily_cap'          => $dailyCap,
    'total_cap'          => $totalCap,
    'premium_multiplier' => $premiumMultiplier > 0 ? $premiumMultiplier : 1.0,
    'targeting_fee'      => $targetingFee,
    'status'             => in_array($status, ['active', 'inactive'], true) ? $status : 'active',
    'sort_order'         => $sortOrder,
    'translations'       => $translations,
    'languages'          => $availableLanguages,
    'default_lang'       => $defaultLang,
];

$savedId = $ADM->ADM_SavePodcastAdPackage($data, $packageId);
if ($savedId === null) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => customLang('hero_ads_payment_failed', 'Operation failed.')]);
    exit;
}

echo json_encode([
    'status'  => 'success',
    'message' => customLang('hero_ads_package_saved', 'Package saved.'),
    'id'      => $savedId,
]);
