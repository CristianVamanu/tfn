<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

global $siteData, $db, $userData, $ADM, $RL, $currentLang;

$csrf = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$normalizeToggle = static function ($raw, bool $default = true): string {
    $value = strtolower(trim((string)$raw));
    if ($value === '') {
        return $default ? '1' : '0';
    }
    return in_array($value, ['1', 'true', 'yes', 'on', 'enabled'], true) ? '1' : '0';
};

$ebookSettingsAction = strtolower(trim((string)($_POST['ebook_settings_action'] ?? 'settings')));
$currentLocale = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)($currentLang ?? 'eng')) ?: 'eng';

if ($ebookSettingsAction !== 'settings') {
    try {
        if (!isset($RL) || !is_object($RL)) {
            throw new RuntimeException('ebook_helper_missing');
        }

        if ($ebookSettingsAction === 'save_language') {
            $result = $RL->RL_SaveEbookLanguage([
                'language_id' => (int)($_POST['language_id'] ?? 0),
                'language_tag' => (string)($_POST['language_tag'] ?? ''),
                'english_name' => (string)($_POST['english_name'] ?? ''),
                'native_name' => (string)($_POST['native_name'] ?? ''),
                'display_name' => (string)($_POST['display_name'] ?? ''),
                'sort_order' => (int)($_POST['sort_order'] ?? 100),
                'is_active' => array_key_exists('is_active', $_POST) ? (int)$_POST['is_active'] : 1,
                'is_default' => array_key_exists('is_default', $_POST) ? (int)$_POST['is_default'] : 0,
            ], $currentLocale);
        } elseif ($ebookSettingsAction === 'set_default') {
            $result = $RL->RL_SetEbookLanguageDefault((int)($_POST['language_id'] ?? 0));
        } elseif ($ebookSettingsAction === 'toggle_language') {
            $result = $RL->RL_ToggleEbookLanguage((int)($_POST['language_id'] ?? 0));
        } elseif ($ebookSettingsAction === 'delete_language') {
            $result = $RL->RL_DeleteEbookLanguage((int)($_POST['language_id'] ?? 0));
        } else {
            $result = ['ok' => false, 'error' => 'invalid_action'];
        }

        if (empty($result['ok'])) {
            http_response_code(422);
            $errorKey = (string)($result['error'] ?? 'server_error');
            echo json_encode([
                'status' => 'error',
                'message' => customLang($errorKey, customLang('admin_ebook_language_save_failed', 'Language could not be saved.')),
                'error' => $errorKey,
            ]);
            exit;
        }

        if (isset($ADM) && $ADM instanceof Admin_Data) {
            $ADM->ADM_Audit((int)($userData['user_id'] ?? 0), 'update_ebook_language', substr($ebookSettingsAction, 0, 60), time());
        }

        echo json_encode([
            'status' => 'success',
            'message' => customLang('admin_ebook_language_action_saved', 'Language action saved.'),
        ]);
        exit;
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }
}

$ebooksEnabledRaw = array_key_exists('ebooks_enabled', $_POST)
    ? $_POST['ebooks_enabled']
    : ($siteData['ebooks_enabled'] ?? '1');
$ebookCreatorUploadsRaw = array_key_exists('ebook_creator_uploads_enabled', $_POST)
    ? $_POST['ebook_creator_uploads_enabled']
    : ($siteData['ebook_creator_uploads_enabled'] ?? '1');

$ebooksEnabled = $normalizeToggle($ebooksEnabledRaw, true);
$ebookCreatorUploadsEnabled = $normalizeToggle($ebookCreatorUploadsRaw, true);
$ebookMinPrice = round(max(0, (float)($_POST['ebook_min_price'] ?? 0)), 2);
$ebookMaxPrice = round(max($ebookMinPrice, (float)($_POST['ebook_max_price'] ?? 500)), 2);
$ebookMaxFileMb = max(1, min(2048, (int)($_POST['ebook_max_file_mb'] ?? 120)));
$ebookDownloadLimit = max(0, min(1000, (int)($_POST['ebook_download_limit'] ?? 5)));
$ebookAccessDays = max(0, min(36500, (int)($_POST['ebook_access_days'] ?? 0)));

try {
    $columnDefs = [
        'ebooks_enabled TINYINT(1) NOT NULL DEFAULT 1',
        'ebook_creator_uploads_enabled TINYINT(1) NOT NULL DEFAULT 1',
        'ebook_min_price DECIMAL(10,2) NOT NULL DEFAULT 0.00',
        'ebook_max_price DECIMAL(10,2) NOT NULL DEFAULT 500.00',
        'ebook_max_file_mb INT UNSIGNED NOT NULL DEFAULT 120',
        'ebook_download_limit INT UNSIGNED NOT NULL DEFAULT 5',
        'ebook_access_days INT UNSIGNED NOT NULL DEFAULT 0',
    ];

    foreach ($columnDefs as $definition) {
        try {
            $db->exec('ALTER TABLE i_site_configurations ADD COLUMN ' . $definition);
        } catch (Throwable $e) {
            $msg = strtolower($e->getMessage());
            if (strpos($msg, 'duplicate') !== false || strpos($msg, 'exists') !== false) {
                continue;
            }
            throw $e;
        }
    }

    $st = $db->prepare('
        UPDATE i_site_configurations
        SET ebooks_enabled = :ebooks_enabled,
            ebook_creator_uploads_enabled = :ebook_creator_uploads_enabled,
            ebook_min_price = :ebook_min_price,
            ebook_max_price = :ebook_max_price,
            ebook_max_file_mb = :ebook_max_file_mb,
            ebook_download_limit = :ebook_download_limit,
            ebook_access_days = :ebook_access_days
        WHERE id = 1
    ');
    $st->execute([
        ':ebooks_enabled' => $ebooksEnabled,
        ':ebook_creator_uploads_enabled' => $ebookCreatorUploadsEnabled,
        ':ebook_min_price' => $ebookMinPrice,
        ':ebook_max_price' => $ebookMaxPrice,
        ':ebook_max_file_mb' => $ebookMaxFileMb,
        ':ebook_download_limit' => $ebookDownloadLimit,
        ':ebook_access_days' => $ebookAccessDays,
    ]);

    if (isset($ADM) && $ADM instanceof Admin_Data) {
        $summary = 'ebooks:' . ($ebooksEnabled === '1' ? 'enabled' : 'disabled');
        $summary .= '|uploads:' . ($ebookCreatorUploadsEnabled === '1' ? 'enabled' : 'disabled');
        $ADM->ADM_Audit((int)($userData['user_id'] ?? 0), 'update_ebook_settings', substr($summary, 0, 60), time());
    }

    echo json_encode(['status' => 'success']);
    exit;
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}
