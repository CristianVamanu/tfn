<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

$csrf = isset($_POST['csrf_token']) ? (string) $_POST['csrf_token'] : '';
if (!checkCsrfToken($csrf)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
    exit;
}

$action = isset($_POST['action']) ? trim((string) $_POST['action']) : '';
if ($action === '') {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'bad_action']);
    exit;
}

if (!isset($RL) || !($RL instanceof Reel_Data)) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'server_error']);
    exit;
}

$requestedTheme = isset($_POST['theme']) ? (string) $_POST['theme'] : '';
$requestedTheme = preg_replace('/[^a-z0-9_-]/i', '', strtolower($requestedTheme)) ?: '';

if ($action === 'activate_theme') {
    if ($requestedTheme === '') {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_theme']);
        exit;
    }

    if (!$RL->RL_SetActiveLandingTheme($requestedTheme)) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }

    echo json_encode(['status' => 'success', 'theme' => $requestedTheme]);
    exit;
}

$theme = $requestedTheme !== '' ? $requestedTheme : 'welcome_default';

$langDir = dirname(__DIR__, 2) . '/langs';
$langOptions = [];
if (is_dir($langDir)) {
    foreach (scandir($langDir) as $entry) {
        if (preg_match('/^(\\w+)\\.php$/', $entry, $m)) {
            $langOptions[] = $m[1];
        }
    }
}
if (!$langOptions) {
    $langOptions = ['eng'];
}

$heroKeys = ['hero_title', 'hero_description', 'hero_start_button'];
$maxLengths = [
    'hero_title' => 180,
    'hero_description' => 420,
    'hero_start_button' => 80,
];

if ($action === 'save_hero') {
    $inputTitle = isset($_POST['hero_title']) && is_array($_POST['hero_title']) ? $_POST['hero_title'] : [];
    $inputDescription = isset($_POST['hero_description']) && is_array($_POST['hero_description']) ? $_POST['hero_description'] : [];
    $inputButton = isset($_POST['hero_start_button']) && is_array($_POST['hero_start_button']) ? $_POST['hero_start_button'] : [];

    $payload = [
        'hero_title' => $inputTitle,
        'hero_description' => $inputDescription,
        'hero_start_button' => $inputButton,
    ];

    try {
        $thisLangs = $langOptions;
        foreach ($thisLangs as $lang) {
            $lang = (string) $lang;
            foreach ($heroKeys as $key) {
                $rawVal = '';
                if (isset($payload[$key][$lang])) {
                    $rawVal = (string) $payload[$key][$lang];
                }
                $cleanVal = iN_CleanTranslationInput($rawVal);
                if ($cleanVal !== '' && mb_strlen($cleanVal) > $maxLengths[$key]) {
                    http_response_code(400);
                    echo json_encode([
                        'status' => 'error',
                        'message' => 'invalid_length',
                        'field' => $key,
                        'language' => $lang,
                    ]);
                    exit;
                }

                if ($cleanVal === '') {
                    $RL->RL_DeleteLangOverride($lang, $key);
                } else {
                    $RL->RL_UpsertLangOverride($lang, $key, $cleanVal);
                }
            }
        }

        echo json_encode(['status' => 'success']);
        exit;
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('admin landing hero save failed: ' . $e->getMessage());
        }
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }
}

if ($action === 'save_image_list') {
    $mediaMode = isset($_POST['media_mode']) ? strtolower(trim((string) $_POST['media_mode'])) : 'mixed';
    if (!in_array($mediaMode, ['mixed', 'image', 'video'], true)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_media_mode']);
        exit;
    }

    $target = isset($_POST['target']) ? strtolower(trim((string) $_POST['target'])) : 'profile';
    if (!in_array($target, ['profile', 'post'], true)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid_target']);
        exit;
    }

    $showViews = isset($_POST['show_views']) && ($_POST['show_views'] === '1' || strtolower((string) $_POST['show_views']) === 'on');
    $showLikes = isset($_POST['show_likes']) && ($_POST['show_likes'] === '1' || strtolower((string) $_POST['show_likes']) === 'on');

    $config = [
        'media_mode' => $mediaMode,
        'target' => $target,
        'show_views' => $showViews,
        'show_likes' => $showLikes,
    ];

    try {
        if (!$RL->RL_SaveLandingSectionConfig($theme, 'image_list', $config)) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'server_error']);
            exit;
        }
        echo json_encode(['status' => 'success']);
        exit;
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('admin landing image_list save failed: ' . $e->getMessage());
        }
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }
}

if ($action === 'save_marquee') {
    $listCount = isset($_POST['list_count']) ? (int) $_POST['list_count'] : 4;
    if ($listCount < 1) { $listCount = 1; }
    if ($listCount > 10) { $listCount = 10; }

    $showAvatar = isset($_POST['show_avatar']) && ($_POST['show_avatar'] === '1' || strtolower((string) $_POST['show_avatar']) === 'on');
    $nameMode = isset($_POST['name_mode']) ? strtolower(trim((string) $_POST['name_mode'])) : 'full';
    if (!in_array($nameMode, ['full', 'username'], true)) {
        $nameMode = 'full';
    }

    $config = [
        'list_count' => $listCount,
        'show_avatar' => $showAvatar,
        'name_mode' => $nameMode,
    ];

    $displayNames = isset($_POST['display_name']) && is_array($_POST['display_name']) ? $_POST['display_name'] : [];
    $usernames = isset($_POST['username']) && is_array($_POST['username']) ? $_POST['username'] : [];
    $avatars = isset($_POST['avatar']) && is_array($_POST['avatar']) ? $_POST['avatar'] : [];
    $ids = isset($_POST['item_id']) && is_array($_POST['item_id']) ? $_POST['item_id'] : [];
    $verifiedInput = isset($_POST['verified']) && is_array($_POST['verified']) ? $_POST['verified'] : [];

    $items = [];
    foreach ($displayNames as $key => $displayValue) {
        $display = iN_CleanTranslationInput((string) $displayValue);
        $username = iN_CleanTranslationInput((string) ($usernames[$key] ?? ''));
        $avatar = trim((string) ($avatars[$key] ?? ''));
        $verified = isset($verifiedInput[$key]);
        $itemId = isset($ids[$key]) ? (int) $ids[$key] : 0;

        if ($display === '' && $username === '' && $avatar === '') {
            continue;
        }

        $items[] = [
            'id' => $itemId,
            'display' => $display,
            'username' => $username,
            'avatar' => $avatar,
            'verified' => $verified,
        ];
    }

    try {
        if (!$RL->RL_SaveLandingSectionConfig($theme, 'marquee', $config)) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'server_error']);
            exit;
        }
        if (!$RL->RL_SaveLandingSectionItems($theme, 'marquee', $items)) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'server_error']);
            exit;
        }
        echo json_encode(['status' => 'success']);
        exit;
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('admin landing marquee save failed: ' . $e->getMessage());
        }
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }
}

if ($action === 'save_features') {
    $iconInput    = isset($_POST['feature_icon']) && is_array($_POST['feature_icon']) ? $_POST['feature_icon'] : [];
    $colorInput   = isset($_POST['feature_color']) && is_array($_POST['feature_color']) ? $_POST['feature_color'] : [];
    $idInput      = isset($_POST['feature_id']) && is_array($_POST['feature_id']) ? $_POST['feature_id'] : [];
    $orderInput   = isset($_POST['feature_order']) && is_array($_POST['feature_order']) ? $_POST['feature_order'] : [];
    $titleInput   = isset($_POST['feature_title']) && is_array($_POST['feature_title']) ? $_POST['feature_title'] : [];
    $descInput    = isset($_POST['feature_desc']) && is_array($_POST['feature_desc']) ? $_POST['feature_desc'] : [];
    $variantInput = isset($_POST['feature_variant']) && is_array($_POST['feature_variant']) ? $_POST['feature_variant'] : [];
    $sectionTitleInput = isset($_POST['feature_section_title']) && is_array($_POST['feature_section_title']) ? $_POST['feature_section_title'] : [];
    $sectionSubtitleInput = isset($_POST['feature_section_subtitle']) && is_array($_POST['feature_section_subtitle']) ? $_POST['feature_section_subtitle'] : [];

    $featureTextMap = [
        'features_title_why_choose' => $sectionTitleInput,
        'features_subtitle_publish_protect' => $sectionSubtitleInput,
    ];
    $featureTextLimits = [
        'features_title_why_choose' => 180,
        'features_subtitle_publish_protect' => 420,
    ];

    foreach ($langOptions as $langCode) {
        $langCode = (string) $langCode;
        foreach ($featureTextMap as $key => $pool) {
            $rawVal = '';
            if (isset($pool[$langCode])) {
                $rawVal = (string) $pool[$langCode];
            }
            $cleanVal = iN_CleanTranslationInput($rawVal);
            if ($cleanVal !== '' && mb_strlen($cleanVal) > ($featureTextLimits[$key] ?? 255)) {
                http_response_code(400);
                echo json_encode([
                    'status' => 'error',
                    'message' => 'invalid_length',
                    'field' => $key,
                    'language' => $langCode,
                ]);
                exit;
            }

            if ($cleanVal === '') {
                $RL->RL_DeleteLangOverride($langCode, $key);
            } else {
                $RL->RL_UpsertLangOverride($langCode, $key, $cleanVal);
            }
        }
    }

    $orderKeys = [];
    foreach ($orderInput as $key) {
        $key = trim((string) $key);
        if ($key !== '') {
            $orderKeys[] = $key;
        }
    }
    if (!$orderKeys) {
        $orderKeys = array_keys($iconInput);
    }

    $items = [];
    foreach ($orderKeys as $rawKey) {
        $key = (string) $rawKey;
        if ($key === '') {
            continue;
        }

        $icon  = isset($iconInput[$key]) ? trim((string) $iconInput[$key]) : '';
        if ($icon !== '' && mb_strlen($icon) > 200) {
            $icon = mb_substr($icon, 0, 200);
        }

        $color = isset($colorInput[$key]) ? trim((string) $colorInput[$key]) : '';
        if ($color !== '' && !preg_match('/^#[0-9a-f]{3,8}$/i', $color)) {
            $color = '';
        }

        $itemId = isset($idInput[$key]) ? (int) $idInput[$key] : 0;
        $variant = isset($variantInput[$key]) ? strtolower(trim((string) $variantInput[$key])) : 'light';
        if (!in_array($variant, ['light', 'dark', 'muted'], true)) {
            $variant = 'light';
        }

        $translations = [];
        foreach ($langOptions as $langCode) {
            $langKey = strtolower((string) $langCode);
            if ($langKey === '') {
                continue;
            }
            $titleRaw = '';
            if (isset($titleInput[$langKey]) && is_array($titleInput[$langKey]) && array_key_exists($key, $titleInput[$langKey])) {
                $titleRaw = (string) $titleInput[$langKey][$key];
            }
            $descRaw = '';
            if (isset($descInput[$langKey]) && is_array($descInput[$langKey]) && array_key_exists($key, $descInput[$langKey])) {
                $descRaw = (string) $descInput[$langKey][$key];
            }

            $title = iN_CleanTranslationInput($titleRaw);
            $desc  = iN_CleanTranslationInput($descRaw);

            if ($title !== '' && mb_strlen($title) > 120) {
                $title = mb_substr($title, 0, 120);
            }
            if ($desc !== '' && mb_strlen($desc) > 400) {
                $desc = mb_substr($desc, 0, 400);
            }

            if ($title === '' && $desc === '') {
                continue;
            }

            $translations[$langKey] = [
                'title' => $title,
                'desc'  => $desc,
            ];
        }

        $hasContent = ($icon !== '') || ($color !== '') || !empty($translations);
        if (!$hasContent && $variant === 'light') {
            continue;
        }

        $items[] = [
            'id' => $itemId,
            'icon' => $icon,
            'color' => $color,
            'translations' => $translations,
            'variant' => $variant,
        ];
    }

    try {
        if (!$RL->RL_SaveLandingSectionItems($theme, 'features', $items)) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'server_error']);
            exit;
        }
        echo json_encode(['status' => 'success']);
        exit;
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('admin landing features save failed: ' . $e->getMessage());
        }
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }
}

if ($action === 'save_samples') {
    $sectionTitleInput = isset($_POST['sample_section_title']) && is_array($_POST['sample_section_title']) ? $_POST['sample_section_title'] : [];
    $sectionSubtitleInput = isset($_POST['sample_section_subtitle']) && is_array($_POST['sample_section_subtitle']) ? $_POST['sample_section_subtitle'] : [];
    $idInput = isset($_POST['sample_id']) && is_array($_POST['sample_id']) ? $_POST['sample_id'] : [];
    $styleInput = isset($_POST['sample_style']) && is_array($_POST['sample_style']) ? $_POST['sample_style'] : [];
    $orderInput = isset($_POST['sample_order']) && is_array($_POST['sample_order']) ? $_POST['sample_order'] : [];
    $labelInput = isset($_POST['sample_label']) && is_array($_POST['sample_label']) ? $_POST['sample_label'] : [];

    $sectionTextMap = [
        'features_tags_title' => $sectionTitleInput,
        'features_tags_subtitle' => $sectionSubtitleInput,
    ];
    $sectionTextLimits = [
        'features_tags_title' => 160,
        'features_tags_subtitle' => 400,
    ];

    foreach ($langOptions as $langCode) {
        $langCode = (string) $langCode;
        foreach ($sectionTextMap as $key => $pool) {
            $rawVal = '';
            if (isset($pool[$langCode])) {
                $rawVal = (string) $pool[$langCode];
            }
            $cleanVal = iN_CleanTranslationInput($rawVal);
            if ($cleanVal !== '' && mb_strlen($cleanVal) > ($sectionTextLimits[$key] ?? 255)) {
                http_response_code(400);
                echo json_encode([
                    'status' => 'error',
                    'message' => 'invalid_length',
                    'field' => $key,
                    'language' => $langCode,
                ]);
                exit;
            }

            if ($cleanVal === '') {
                $RL->RL_DeleteLangOverride($langCode, $key);
            } else {
                $RL->RL_UpsertLangOverride($langCode, $key, $cleanVal);
            }
        }
    }

    $orderKeys = [];
    foreach ($orderInput as $key) {
        $key = trim((string) $key);
        if ($key !== '') {
            $orderKeys[] = $key;
        }
    }
    if (!$orderKeys) {
        $orderKeys = array_keys($styleInput);
    }

    $items = [];
    foreach ($orderKeys as $rawKey) {
        $key = (string) $rawKey;
        if ($key === '') {
            continue;
        }

        $style = isset($styleInput[$key]) ? strtolower(trim((string) $styleInput[$key])) : 'narrow';
        if (!in_array($style, ['narrow', 'wide'], true)) {
            $style = 'narrow';
        }

        $itemId = isset($idInput[$key]) ? (int) $idInput[$key] : 0;

        $translations = [];
        foreach ($langOptions as $langCode) {
            $langKey = strtolower((string) $langCode);
            if ($langKey === '') {
                continue;
            }
            $label = '';
            if (isset($labelInput[$langKey]) && is_array($labelInput[$langKey]) && array_key_exists($key, $labelInput[$langKey])) {
                $label = iN_CleanTranslationInput((string) $labelInput[$langKey][$key]);
            }
            if ($label === '') {
                continue;
            }
            $translations[$langKey] = ['label' => $label];
        }

        if (!$translations) {
            continue;
        }

        $items[] = [
            'id' => $itemId,
            'style' => $style,
            'translations' => $translations,
        ];
    }

    try {
        if (!$RL->RL_SaveLandingSectionItems($theme, 'samples', $items)) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'server_error']);
            exit;
        }
        echo json_encode(['status' => 'success']);
        exit;
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('admin landing samples save failed: ' . $e->getMessage());
        }
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }
}

if ($action === 'save_no_hassle') {
    $maColorInput = isset($_POST['no_hassle_ma_color']) ? trim((string) $_POST['no_hassle_ma_color']) : '#4F86F7';
    if ($maColorInput !== '' && !preg_match('/^#[0-9a-fA-F]{3,8}$/', $maColorInput)) {
        $maColorInput = '#4F86F7';
    }
    if ($maColorInput === '') {
        $maColorInput = '#4F86F7';
    }

    if (!$RL->RL_SaveLandingSectionConfig($theme, 'no_hassle', ['ma_color' => $maColorInput])) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }

    $idInput = isset($_POST['no_hassle_id']) && is_array($_POST['no_hassle_id']) ? $_POST['no_hassle_id'] : [];
    $iconInput = isset($_POST['no_hassle_icon']) && is_array($_POST['no_hassle_icon']) ? $_POST['no_hassle_icon'] : [];
    $colorInput = isset($_POST['no_hassle_color']) && is_array($_POST['no_hassle_color']) ? $_POST['no_hassle_color'] : [];
    $typeInput = isset($_POST['no_hassle_type']) && is_array($_POST['no_hassle_type']) ? $_POST['no_hassle_type'] : [];
    $orderInput = isset($_POST['no_hassle_order']) && is_array($_POST['no_hassle_order']) ? $_POST['no_hassle_order'] : [];
    $labelInput = isset($_POST['no_hassle_label']) && is_array($_POST['no_hassle_label']) ? $_POST['no_hassle_label'] : [];

    $orderKeys = [];
    foreach ($orderInput as $key) {
        $key = trim((string) $key);
        if ($key !== '') {
            $orderKeys[] = $key;
        }
    }
    if (!$orderKeys) {
        $orderKeys = array_keys($iconInput ?: $colorInput ?: $typeInput ?: []);
    }

    $items = [];
    foreach ($orderKeys as $rawKey) {
        $key = (string) $rawKey;
        if ($key === '') {
            continue;
        }

        $iconVal = '';
        if (isset($iconInput[$key])) {
            $iconVal = trim((string) $iconInput[$key]);
            if ($iconVal !== '' && mb_strlen($iconVal) > 200) {
                $iconVal = mb_substr($iconVal, 0, 200);
            }
        }

        $colorVal = '';
        if (isset($colorInput[$key])) {
            $colorVal = trim((string) $colorInput[$key]);
            if ($colorVal !== '' && !preg_match('/^#[0-9a-fA-F]{3,8}$/', $colorVal)) {
                $colorVal = '';
            }
        }

        $typeVal = isset($typeInput[$key]) ? strtolower(trim((string) $typeInput[$key])) : 'feature';
        if (!in_array($typeVal, ['feature', 'badge'], true)) {
            $typeVal = 'feature';
        }

        $translations = [];
        foreach ($langOptions as $langCode) {
            $langKey = strtolower((string) $langCode);
            if ($langKey === '') { continue; }
            if (isset($labelInput[$langKey]) && is_array($labelInput[$langKey]) && array_key_exists($key, $labelInput[$langKey])) {
                $labelVal = iN_CleanTranslationInput((string) $labelInput[$langKey][$key]);
                if ($labelVal !== '') {
                    $translations[$langKey] = ['label' => $labelVal];
                }
            }
        }

        $items[] = [
            'id' => isset($idInput[$key]) ? (int) $idInput[$key] : 0,
            'item_type' => $typeVal,
            'icon' => $iconVal,
            'color' => $colorVal,
            'translations' => $translations,
        ];
    }

    try {
        if (!$RL->RL_SaveLandingSectionItems($theme, 'no_hassle', $items)) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'server_error']);
            exit;
        }
        echo json_encode(['status' => 'success']);
        exit;
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('admin landing no_hassle save failed: ' . $e->getMessage());
        }
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }
}

if ($action === 'save_earnings_simulator') {
    $followersInput = isset($_POST['default_followers']) ? (int) $_POST['default_followers'] : 1000;
    $priceInput = isset($_POST['default_price']) ? (float) $_POST['default_price'] : 10.0;
    $conversionInput = null;
    if (array_key_exists('conversion_rate', $_POST)) {
        $rawConversion = $_POST['conversion_rate'];
        if (is_string($rawConversion)) {
            $rawConversion = trim($rawConversion);
            if ($rawConversion !== '') {
                $conversionInput = (float) $rawConversion;
            }
        } elseif (is_numeric($rawConversion)) {
            $conversionInput = (float) $rawConversion;
        }
    }

    $followers = max(0, min($followersInput, 1000000));

    if (!is_finite($priceInput)) {
        $priceInput = 10.0;
    }
    $price = round($priceInput, 2);
    if ($price < 1.0) {
        $price = 1.0;
    }
    if ($price > 1000.0) {
        $price = 1000.0;
    }

    $conversionRate = 0.2;
    if ($conversionInput !== null) {
        if (!is_finite($conversionInput)) {
            $conversionInput = 20.0;
        }
        if ($conversionInput > 1.0) {
            $conversionInput = $conversionInput / 100.0;
        }
        if ($conversionInput < 0.0) {
            $conversionInput = 0.0;
        }
        if ($conversionInput > 1.0) {
            $conversionInput = 1.0;
        }
        $conversionRate = $conversionInput;
    }

    $config = [
        'default_followers' => $followers,
        'default_price' => $price,
        'conversion_rate' => $conversionRate,
    ];

    try {
        if (!$RL->RL_SaveLandingSectionConfig($theme, 'earnings_simulator', $config)) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'server_error']);
            exit;
        }
        echo json_encode(['status' => 'success']);
        exit;
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('admin landing earnings simulator save failed: ' . $e->getMessage());
        }
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }
}

if ($action === 'save_pricing') {

    $sectionTitleInput = isset($_POST['pricing_section_title']) && is_array($_POST['pricing_section_title']) ? $_POST['pricing_section_title'] : [];
    $sectionSubtitleInput = isset($_POST['pricing_section_subtitle']) && is_array($_POST['pricing_section_subtitle']) ? $_POST['pricing_section_subtitle'] : [];
    $noteInput = isset($_POST['pricing_section_note']) && is_array($_POST['pricing_section_note']) ? $_POST['pricing_section_note'] : [];

    $pricingTextMap = [
        'pricing_section_title' => $sectionTitleInput,
        'pricing_section_description' => $sectionSubtitleInput,
        'pricing_note' => $noteInput,
    ];
    $pricingTextLimits = [
        'pricing_section_title' => 160,
        'pricing_section_description' => 400,
        'pricing_note' => 400,
    ];

    foreach ($langOptions as $langCode) {
        $langCode = (string) $langCode;
        foreach ($pricingTextMap as $key => $pool) {
            $rawVal = '';
            if (isset($pool[$langCode])) {
                $rawVal = (string) $pool[$langCode];
            }
            $cleanVal = iN_CleanTranslationInput($rawVal);
            if ($cleanVal !== '' && mb_strlen($cleanVal) > ($pricingTextLimits[$key] ?? 255)) {
                http_response_code(400);
                echo json_encode([
                    'status' => 'error',
                    'message' => 'invalid_length',
                    'field' => $key,
                    'language' => $langCode,
                ]);
                exit;
            }

            if ($cleanVal === '') {
                $RL->RL_DeleteLangOverride($langCode, $key);
            } else {
                $RL->RL_UpsertLangOverride($langCode, $key, $cleanVal);
            }
        }
    }

    $pricingConfig = [
        'mode' => 'earning_cards_v1',
    ];
    if (!$RL->RL_SaveLandingSectionConfig($theme, 'pricing', $pricingConfig)) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }

    $idInput = isset($_POST['plan_id']) && is_array($_POST['plan_id']) ? $_POST['plan_id'] : [];
    $orderInput = isset($_POST['plan_order']) && is_array($_POST['plan_order']) ? $_POST['plan_order'] : [];
    $badgeInput = isset($_POST['plan_badge']) && is_array($_POST['plan_badge']) ? $_POST['plan_badge'] : [];
    $highlightInput = isset($_POST['plan_highlight']) && is_array($_POST['plan_highlight']) ? $_POST['plan_highlight'] : [];
    $variantInput = isset($_POST['plan_variant']) && is_array($_POST['plan_variant']) ? $_POST['plan_variant'] : [];
    $ctaUrlInput = isset($_POST['plan_cta_url']) && is_array($_POST['plan_cta_url']) ? $_POST['plan_cta_url'] : [];
    $featuresInput = isset($_POST['plan_features']) && is_array($_POST['plan_features']) ? $_POST['plan_features'] : [];
    $titleInput = isset($_POST['plan_title']) && is_array($_POST['plan_title']) ? $_POST['plan_title'] : [];
    $taglineInput = isset($_POST['plan_tagline']) && is_array($_POST['plan_tagline']) ? $_POST['plan_tagline'] : [];
    $descriptionInput = isset($_POST['plan_description']) && is_array($_POST['plan_description']) ? $_POST['plan_description'] : [];
    $ctaLabelInput = isset($_POST['plan_cta_label']) && is_array($_POST['plan_cta_label']) ? $_POST['plan_cta_label'] : [];

    $orderKeys = [];
    foreach ($orderInput as $key) {
        $key = trim((string) $key);
        if ($key !== '') {
            $orderKeys[] = $key;
        }
    }
    if (!$orderKeys) {
        $orderKeys = array_keys($badgeInput);
    }

    $items = [];
    foreach ($orderKeys as $rawKey) {
        $key = (string) $rawKey;
        if ($key === '') {
            continue;
        }

        $badgeVal   = isset($badgeInput[$key]) ? iN_CleanTranslationInput((string) $badgeInput[$key]) : '';
        if ($badgeVal !== '' && mb_strlen($badgeVal) > 80) {
            $badgeVal = mb_substr($badgeVal, 0, 80);
        }
        $highlight  = isset($highlightInput[$key]);
        $variant    = isset($variantInput[$key]) ? (string) $variantInput[$key] : 'default';
        $ctaUrl     = isset($ctaUrlInput[$key]) ? trim((string) $ctaUrlInput[$key]) : '';
        if ($ctaUrl !== '' && !preg_match('#^(https?:)?//#i', $ctaUrl)) {
            $ctaUrl = '';
        }

        $features = [];
        if (isset($featuresInput[$key])) {
            $lines = preg_split('/\r\n|\r|\n/', (string) $featuresInput[$key]) ?: [];
            foreach ($lines as $line) {
                $clean = iN_CleanTranslationInput((string) $line);
                if ($clean !== '') {
                    $features[] = $clean;
                }
            }
        }

        $translations = [];
        foreach ($langOptions as $langCode) {
            $langKey = strtolower((string) $langCode);
            if ($langKey === '') { continue; }

            $titleVal = '';
            if (isset($titleInput[$langKey]) && is_array($titleInput[$langKey]) && array_key_exists($key, $titleInput[$langKey])) {
                $titleVal = iN_CleanTranslationInput((string) $titleInput[$langKey][$key]);
            }

            $taglineVal = '';
            if (isset($taglineInput[$langKey]) && is_array($taglineInput[$langKey]) && array_key_exists($key, $taglineInput[$langKey])) {
                $taglineVal = iN_CleanTranslationInput((string) $taglineInput[$langKey][$key]);
            }

            $descriptionVal = '';
            if (isset($descriptionInput[$langKey]) && is_array($descriptionInput[$langKey]) && array_key_exists($key, $descriptionInput[$langKey])) {
                $descriptionVal = iN_CleanTranslationInput((string) $descriptionInput[$langKey][$key]);
            }

            $ctaLabelVal = '';
            if (isset($ctaLabelInput[$langKey]) && is_array($ctaLabelInput[$langKey]) && array_key_exists($key, $ctaLabelInput[$langKey])) {
                $ctaLabelVal = iN_CleanTranslationInput((string) $ctaLabelInput[$langKey][$key]);
            }

            $translations[$langKey] = [
                'title' => $titleVal,
                'tagline' => $taglineVal,
                'description' => $descriptionVal,
                'cta_label' => $ctaLabelVal,
            ];
        }

        if ($badgeVal === '' && $ctaUrl === '' && !$highlight && !$features) {
            $hasTranslationContent = false;
            foreach ($translations as $langData) {
                if (!empty(array_filter($langData))) {
                    $hasTranslationContent = true;
                    break;
                }
            }
            if (!$hasTranslationContent) {
                continue;
            }
        }

        $items[] = [
            'id' => isset($idInput[$key]) ? (int) $idInput[$key] : 0,
            'badge' => $badgeVal,
            'highlight' => $highlight,
            'variant' => $variant,
            'cta_url' => $ctaUrl,
            'features' => $features,
            'translations' => $translations,
        ];
    }

    try {
        if (!$RL->RL_SaveLandingSectionItems($theme, 'pricing', $items)) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'server_error']);
            exit;
        }
        echo json_encode(['status' => 'success']);
        exit;
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('admin landing pricing save failed: ' . $e->getMessage());
        }
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'server_error']);
        exit;
    }
}

http_response_code(400);
echo json_encode(['status' => 'error', 'message' => 'bad_action']);
