<?php
declare(strict_types=1);

// Central admin bootstrap guard.
// - Includes the main app bootstrap.
// - Enforces RBAC using $userMode when available (fallback maps from $userData['user_type']).
// - Deny-by-default with proper HTML or JSON responses.

require_once __DIR__ . '/../includes/inc.php'; // sets $loggedIn, $userData, helpers
// Load admin function pack (mirrors includes/functions pattern)
require_once __DIR__ . '/functions.php';

// Detect if current endpoint is an AJAX/JSON request (admin requests live under admin/request/).
$scriptPath = (string)($_SERVER['SCRIPT_FILENAME'] ?? '');
$acceptHdr  = (string)($_SERVER['HTTP_ACCEPT'] ?? '');
$xhrHeader  = (string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '');
$isJson     = (stripos($scriptPath, DIRECTORY_SEPARATOR . 'request' . DIRECTORY_SEPARATOR) !== false)
    || (stripos($acceptHdr, 'application/json') !== false)
    || (strcasecmp($xhrHeader, 'XMLHttpRequest') === 0);

// Not authenticated → redirect (HTML) or JSON error.
if (!isset($loggedIn) || $loggedIn !== '1') {
    if ($isJson) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(401);
        echo json_encode([
            'status'  => 'error',
            'code'    => 'AUTH',
            'message' => customLang('err_session_expired'),
        ]);
        exit;
    }

    $loginUrl = rtrim($base_url ?? '/', '/') . '/login?err=err_session_expired';
    header('Location: ' . $loginUrl);
    exit;
}

// Resolve $userMode safely from inc.php, or map from $userData as a fallback.
$resolvedMode = null;
if (isset($userMode) && is_string($userMode) && $userMode !== '') {
    $resolvedMode = strtolower($userMode);
} else {
    // Fallback mapping: owner/admin/moderator based on numeric user_type.
    $uid  = (int)($userData['user_id'] ?? 0);
    $type = (int)($userData['user_type'] ?? 0);
    if ($uid === 1 || $type >= 3) {
        $resolvedMode = 'admin';
    } elseif ($type === 2) {
        $resolvedMode = 'moderator';
    } else {
        $resolvedMode = 'user';
    }
}

$isAllowed = in_array($resolvedMode, ['admin', 'moderator'], true);
if (!$isAllowed) {
    if ($isJson) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(403);
        echo json_encode([
            'status'  => 'error',
            'code'    => 'FORBIDDEN',
            'message' => customLang('err_forbidden_admin_only'),
        ]);
        exit;
    }

    // Non-admin HTML access → pretend not found (redirect to 404).
    $dest404 = rtrim($base_url ?? '/', '/') . '/404';
    header('Location: ' . $dest404);
    exit;
}

// Expose an admin-only CSRF token for forms if needed by views.
if (!isset($ADMIN_CSRF)) {
    $ADMIN_CSRF = generateCsrfToken();
}

// Initialize admin function hub
if (!isset($ADM) || !($ADM instanceof Admin_Data)) {
    $ADM = new Admin_Data($db, isset($RL) && ($RL instanceof Reel_Data) ? $RL : null);
}

$ADMIN_USER_ID = (int)($userData['user_id'] ?? 0);
$ADMIN_USER_TYPE = (int)($userData['user_type'] ?? 0);
$ADMIN_ROLE = $resolvedMode;
$ADMIN_IS_OWNER = ($ADMIN_USER_ID === 1);
$ADMIN_IS_ADMIN = $ADMIN_IS_OWNER || ($ADMIN_USER_TYPE >= 3) || ($ADMIN_ROLE === 'admin');
$ADMIN_IS_MODERATOR = ($ADMIN_ROLE === 'moderator');
$ADMIN_IS_JSON_REQUEST = $isJson;

if (!function_exists('admin_default_permissions')) {
    function admin_default_permissions(string $role): array
    {
        $role = strtolower(trim($role));
        if ($role !== 'moderator') {
            return [];
        }

        return [
            'dashboard.view',
            'users.view',
            'content.view',
        ];
    }
}

if (!function_exists('admin_permission_column_exists')) {
    function admin_permission_column_exists(PDO $db): bool
    {
        static $exists = null;
        if ($exists !== null) {
            return $exists;
        }

        try {
            $stmt = $db->prepare(
                'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = :t
                   AND COLUMN_NAME = :c'
            );
            $stmt->execute([':t' => 'i_users', ':c' => 'admin_permissions']);
            $exists = ((int)$stmt->fetchColumn() > 0);
        } catch (Throwable $__) {
            $exists = false;
        }

        return $exists;
    }
}

if (!function_exists('admin_normalize_permissions')) {
    function admin_normalize_permissions($raw): array
    {
        $perms = [];
        if (is_string($raw)) {
            $raw = trim($raw);
            if ($raw === '') {
                return [];
            }
            $decoded = json_decode($raw, true);
            $raw = $decoded;
        }

        if (!is_array($raw)) {
            return [];
        }

        $keys = array_keys($raw);
        $isList = $keys === range(0, count($keys) - 1);
        if ($isList) {
            foreach ($raw as $val) {
                if (!is_string($val)) {
                    continue;
                }
                $key = strtolower(trim($val));
                if ($key !== '') {
                    $perms[$key] = true;
                }
            }
        } else {
            foreach ($raw as $key => $allowed) {
                if (!$allowed) {
                    continue;
                }
                if (!is_string($key)) {
                    continue;
                }
                $permKey = strtolower(trim($key));
                if ($permKey !== '') {
                    $perms[$permKey] = true;
                }
            }
        }

        return array_keys($perms);
    }
}

if (!function_exists('admin_current_permissions')) {
    function admin_current_permissions(): array
    {
        static $cached = null;
        if ($cached !== null) {
            return $cached;
        }

        $user = $GLOBALS['userData'] ?? [];
        $db = $GLOBALS['db'] ?? null;
        $role = $GLOBALS['ADMIN_ROLE'] ?? '';
        $raw = null;
        $hasStoredValue = false;

        if (is_array($user) && array_key_exists('admin_permissions', $user)) {
            $raw = $user['admin_permissions'];
            $hasStoredValue = is_array($raw) || (is_string($raw) && trim($raw) !== '');
        }

        if (!$hasStoredValue && $db instanceof PDO && admin_permission_column_exists($db)) {
            try {
                $uid = (int)($user['user_id'] ?? 0);
                if ($uid > 0) {
                    $stmt = $db->prepare('SELECT admin_permissions FROM i_users WHERE user_id = :uid LIMIT 1');
                    $stmt->execute([':uid' => $uid]);
                    $raw = $stmt->fetchColumn();
                    $hasStoredValue = is_string($raw) && trim((string)$raw) !== '';
                }
            } catch (Throwable $__) {
                $raw = null;
                $hasStoredValue = false;
            }
        }

        $perms = admin_normalize_permissions($raw);
        if (!$hasStoredValue && empty($perms)) {
            $perms = admin_default_permissions((string)$role);
        }

        $cached = $perms;
        return $cached;
    }
}

if (!function_exists('admin_has_permission')) {
    function admin_has_permission(string $key): bool
    {
        $key = strtolower(trim($key));
        if ($key === '') {
            return false;
        }

        if (!empty($GLOBALS['ADMIN_IS_ADMIN'])) {
            return true;
        }

        if (empty($GLOBALS['ADMIN_IS_MODERATOR'])) {
            return false;
        }

        $perms = admin_current_permissions();
        return in_array($key, $perms, true);
    }
}

if (!function_exists('admin_forbidden_json')) {
    function admin_forbidden_json(string $messageKey = 'admin_permission_denied'): void
    {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(403);
        echo json_encode([
            'status' => 'error',
            'message' => $messageKey,
        ]);
        exit;
    }
}

if (!function_exists('admin_page_permission_key')) {
    function admin_page_permission_key(string $page): string
    {
        $page = trim($page);
        $map = [
            'dashboard' => 'dashboard.view',
            'users' => 'users.view',
            'activity_users' => 'users.view',
            'user_detail' => 'users.view',
            'verification_requests' => 'verification.view',
            'payout_verifications' => 'payouts.review',
            'withdrawals' => 'withdrawals.review',
            'content' => 'content.view',
            'content_everyone' => 'content.view',
            'content_subscribers' => 'content.view',
            'content_locked' => 'content.view',
            'content_followers' => 'content.view',
            'reported_posts' => 'content.view',
            'reported_comments' => 'content.view',
            'content_approvals' => 'content.approve',
            'post_edit' => 'content.edit',
            'wallet_topups' => 'settings.manage',
            'activity_subs' => 'settings.manage',
            'activity_tips' => 'settings.manage',
            'subs_active' => 'settings.manage',
            'subs_pending' => 'settings.manage',
            'subs_declined' => 'settings.manage',
            'subs_failed' => 'settings.manage',
            'tips_paid' => 'settings.manage',
            'tips_pending' => 'settings.manage',
            'tips_canceled' => 'settings.manage',
            'tips_failed' => 'settings.manage',
            'invoice_subscription' => 'settings.manage',
            'invoice_tip' => 'settings.manage',
            'invoice_subscription_detail' => 'settings.manage',
            'invoice_tip_detail' => 'settings.manage',
            'icons' => 'settings.manage',
            'ebooks' => 'settings.manage',
            'audio_rooms' => 'content.view',
            'audio_room_earnings' => 'settings.manage',
            'invoice_audio_room' => 'settings.manage',
            'ebook_languages' => 'settings.manage',
            'contact_reply' => 'settings.manage',
            'contact_messages_all' => 'settings.manage',
            'contact_messages_new' => 'settings.manage',
            'contact_messages_read' => 'settings.manage',
            'contact_messages_resolved' => 'settings.manage',
            'announcements' => 'settings.manage',
            'social_login' => 'settings.manage',
            'podcast_categories' => 'settings.manage',
            'podcast_ads' => 'settings.manage',
            'podcast_ad_packages' => 'settings.manage',
            'ads_all' => 'settings.manage',
            'ads_videos' => 'settings.manage',
            'ads_images' => 'settings.manage',
            'settings_site' => 'settings.manage',
            'settings_live' => 'settings.manage',
            'settings_audio_rooms' => 'settings.manage',
            'settings_ebooks' => 'settings.manage',
            'settings_payments' => 'settings.manage',
            'settings_onesignal' => 'settings.manage',
            'settings_sms' => 'settings.manage',
            'settings_landing' => 'settings.manage',
            'settings_contact_email' => 'settings.manage',
            'settings_footer_links' => 'settings.manage',
            'settings_faqs' => 'settings.manage',
            'settings_storage_local' => 'storage.manage',
            'settings_storage_s3' => 'storage.manage',
            'settings_storage_spaces' => 'storage.manage',
            'settings_storage_wasabi' => 'storage.manage',
            'settings_storage_backblaze' => 'storage.manage',
        ];

        if (isset($map[$page])) {
            return $map[$page];
        }

        return 'settings.manage';
    }
}

if (!function_exists('admin_resolve_media_url')) {
    function admin_resolve_media_url($path, ?string $fallbackBase = null): string
    {
        $fallback = $fallbackBase ?? ($GLOBALS['base_url'] ?? '');
        if (function_exists('storage_resolve_media_url')) {
            return storage_resolve_media_url((string)$path, $fallback);
        }

        $trimmed = trim((string)$path);
        if ($trimmed === '') {
            return '';
        }

        return rtrim((string)$fallback, '/') . '/' . ltrim($trimmed, '/');
    }
}
