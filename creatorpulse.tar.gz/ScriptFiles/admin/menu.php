<?php
declare(strict_types=1);

// Requires _init.php to be included first so $base_url exists
if (!isset($base_url)) { require_once __DIR__ . '/_init.php'; }

$currentPage = isset($_GET['page']) ? (string)$_GET['page'] : '';

// Build admin sidebar with the same structure/classes as themes/default/menu/left_menu.php
$items = [
  [
    'href'  => $base_url . 'admin/index.php?page=dashboard',
    'label' => customLang('admin_menu_dashboard') ?: 'Dashboard',
    'icon'  => 'dashboard_user',
    'cls'   => 'dashboard_user',
    'key'   => 'dashboard',
  ],
  [
    'href'  => $base_url . 'admin/index.php?page=users',
    'label' => customLang('admin_menu_users') ?: 'Users',
    'icon'  => 'users',
    'cls'   => 'creators',
    'key'   => 'users',
  ],
  [
    'href'  => $base_url . 'admin/index.php?page=verification_requests',
    'label' => customLang('admin_menu_verification_requests') ?: 'Verification Requests',
    'icon'  => 'creator_icon',
    'cls'   => 'verification_requests',
    'key'   => 'verification_requests',
  ],
  [
    'href'  => '#',
    'label' => customLang('admin_menu_user_posts') ?: 'User Posts',
    'icon'  => 'trending',
    'cls'   => 'trending',
    'key'   => 'content',
    'submenu' => [
      [ 'href' => $base_url . 'admin/index.php?page=content',              'label' => customLang('admin_menu_user_posts_all') ?: 'All Posts',               'key' => 'content' ],
      [ 'href' => $base_url . 'admin/index.php?page=content_everyone',     'label' => customLang('admin_menu_user_posts_everyone') ?: 'Posts for Everyone', 'key' => 'content_everyone' ],
      [ 'href' => $base_url . 'admin/index.php?page=content_subscribers',  'label' => customLang('admin_menu_user_posts_subscribers') ?: 'Posts for Subscribers', 'key' => 'content_subscribers' ],
      [ 'href' => $base_url . 'admin/index.php?page=content_locked',       'label' => customLang('admin_menu_user_posts_locked') ?: 'Locked Posts', 'key' => 'content_locked' ],
      [ 'href' => $base_url . 'admin/index.php?page=content_followers',    'label' => customLang('admin_menu_user_posts_followers') ?: 'Posts for Followers', 'key' => 'content_followers' ],
      [ 'href' => $base_url . 'admin/index.php?page=reported_posts',       'label' => customLang('admin_menu_user_posts_reported') ?: 'Reported Posts', 'key' => 'reported_posts' ],
      [ 'href' => $base_url . 'admin/index.php?page=reported_comments',    'label' => customLang('admin_menu_user_posts_reported_comments') ?: 'Reported Comments', 'key' => 'reported_comments' ],
    ],
  ],
  [
    'href'  => $base_url . 'admin/index.php?page=content_approvals',
    'label' => customLang('admin_menu_post_approvals') ?: 'Post Approvals',
    'icon'  => 'complete',
    'cls'   => 'content_approvals',
    'key'   => 'content_approvals',
  ],
  [
    'href'  => $base_url . 'admin/index.php?page=ebooks',
    'label' => customLang('admin_menu_ebooks') ?: 'eBooks',
    'icon'  => 'ebook',
    'cls'   => 'ebooks',
    'key'   => 'ebooks',
  ],
  [
    'href'  => $base_url . 'admin/index.php?page=audio_rooms',
    'label' => customLang('admin_menu_audio_rooms') ?: 'Audio Rooms',
    'icon'  => 'podcast',
    'cls'   => 'audio_rooms',
    'key'   => 'audio_rooms',
  ],
  [
    'href'  => $base_url . 'admin/index.php?page=audio_room_earnings',
    'label' => customLang('admin_menu_audio_room_earnings') ?: 'Audio Room earnings',
    'icon'  => 'payments',
    'cls'   => 'audio_room_earnings',
    'key'   => 'audio_room_earnings',
  ],
  [
    'href'  => '#',
    'label' => customLang('admin_menu_podcasts', 'Podcasts'),
    'icon'  => 'podcast',
    'cls'   => 'podcast',
    'key'   => 'podcasts',
    'submenu' => [
      [
        'href'  => $base_url . 'admin/index.php?page=podcast_ads',
        'label' => customLang('hero_ads_manage', 'Podcast Hero Ads'),
        'key'   => 'podcast_ads',
        'icon'  => 'podcast',
      ],
      [
        'href'  => $base_url . 'admin/index.php?page=podcast_ad_packages',
        'label' => customLang('admin_menu_podcast_packages', 'Ad Packages'),
        'key'   => 'podcast_ad_packages',
        'icon'  => 'media',
      ],
      [
        'href'  => $base_url . 'admin/index.php?page=podcast_categories',
        'label' => customLang('admin_menu_podcast_categories', 'Podcast categories'),
        'key'   => 'podcast_categories',
        'icon'  => 'category',
      ],
    ],
  ],
  [
    'href'  => '#',
    'label' => customLang('admin_menu_ads') ?: 'Advertisements',
    'icon'  => 'media',
    'cls'   => 'ads_menu',
    'key'   => 'ads_all',
    'submenu' => [
      [
        'href'  => $base_url . 'admin/index.php?page=ads_all',
        'label' => customLang('admin_menu_ads_all') ?: 'All Advertisements',
        'key'   => 'ads_all',
        'icon'  => 'media',
      ],
      [
        'href'  => $base_url . 'admin/index.php?page=ads_videos',
        'label' => customLang('admin_menu_ads_videos') ?: 'Video Advertisements',
        'key'   => 'ads_videos',
        'icon'  => 'reels',
      ],
      [
        'href'  => $base_url . 'admin/index.php?page=ads_images',
        'label' => customLang('admin_menu_ads_images') ?: 'Image Advertisements',
        'key'   => 'ads_images',
        'icon'  => 'images',
      ],
    ],
  ],
  [
    'href'  => '#',
    'label' => customLang('admin_menu_subscriptions') ?: 'Subscriptions',
    'icon'  => 'subscription_fees',
    'cls'   => 'subscriptions',
    'key'   => 'subscriptions',
    'submenu' => [
      [
        'href'  => $base_url . 'admin/index.php?page=subs_active',
        'label' => customLang('admin_menu_subscriptions_active') ?: 'Active Subscriptions',
        'key'   => 'subs_active',
        'icon'  => 'complete',
      ],
      [
        'href'  => $base_url . 'admin/index.php?page=subs_pending',
        'label' => customLang('admin_menu_subscriptions_pending') ?: 'Pending Subscriptions',
        'key'   => 'subs_pending',
        'icon'  => 'in_progress',
      ],
      [
        'href'  => $base_url . 'admin/index.php?page=subs_declined',
        'label' => customLang('admin_menu_subscriptions_declined') ?: 'Declined Subscriptions',
        'key'   => 'subs_declined',
        'icon'  => 'draft',
      ],
      [
        'href'  => $base_url . 'admin/index.php?page=subs_failed',
        'label' => customLang('admin_menu_subscriptions_failed') ?: 'Failed Subscriptions',
        'key'   => 'subs_failed',
        'icon'  => 'failed',
      ],
      [
        'href'  => $base_url . 'admin/index.php?page=activity_subs',
        'label' => customLang('admin_menu_subscriptions_latest') ?: 'Latest Subscriptions',
        'key'   => 'activity_subs',
        'icon'  => 'subscription_fees',
      ],
    ],
  ],
  [
    'href'  => '#',
    'label' => customLang('admin_menu_tips') ?: 'Tips',
    'icon'  => 'super_thanks',
    'cls'   => 'tips_menu',
    'key'   => 'tips',
    'submenu' => [
      [
        'href'  => $base_url . 'admin/index.php?page=tips_paid',
        'label' => customLang('admin_tips_paid'),
        'key'   => 'tips_paid',
        'icon'  => 'super_thanks',
      ],
      [
        'href'  => $base_url . 'admin/index.php?page=tips_pending',
        'label' => customLang('admin_tips_pending'),
        'key'   => 'tips_pending',
        'icon'  => 'time_alert',
      ],
      [
        'href'  => $base_url . 'admin/index.php?page=tips_failed',
        'label' => customLang('admin_tips_failed'),
        'key'   => 'tips_failed',
        'icon'  => 'close',
      ],
      [
        'href'  => $base_url . 'admin/index.php?page=tips_canceled',
        'label' => customLang('admin_tips_canceled'),
        'key'   => 'tips_canceled',
        'icon'  => 'ban',
      ],
      [
        'href'  => $base_url . 'admin/index.php?page=activity_tips',
        'label' => customLang('admin_tips_latest'),
        'key'   => 'activity_tips',
        'icon'  => 'super_thanks',
      ],
    ],
  ],
  [
    'href'  => $base_url . 'admin/index.php?page=wallet_topups',
    'label' => customLang('admin_menu_wallet_topups') ?: 'Wallet Top-ups',
    'icon'  => 'payments',
    'cls'   => 'wallet_topups',
    'key'   => 'wallet_topups',
  ],
  [
    'href'  => $base_url . 'admin/index.php?page=withdrawals',
    'label' => customLang('admin_menu_withdrawals') ?: 'Withdrawal Requests',
    'icon'  => 'bank',
    'cls'   => 'withdrawals',
    'key'   => 'withdrawals',
  ],
  [
    'href'  => $base_url . 'admin/index.php?page=payout_verifications',
    'label' => customLang('admin_menu_payout_verifications') ?: 'Payout Reviews',
    'icon'  => 'payout_methods',
    'cls'   => 'payout_verifications',
    'key'   => 'payout_verifications',
  ],
  [
    'href'  => '#',
    'label' => customLang('admin_menu_contact_messages') ?: 'Contact Messages',
    'icon'  => 'email',
    'cls'   => 'contact_messages_menu',
    'key'   => 'contact_messages',
    'submenu' => [
      [
        'href'  => $base_url . 'admin/index.php?page=contact_messages_all',
        'label' => customLang('admin_contact_messages_all'),
        'key'   => 'contact_messages_all',
        'icon'  => 'email',
      ],
      [
        'href'  => $base_url . 'admin/index.php?page=contact_messages_new',
        'label' => customLang('admin_contact_messages_new'),
        'key'   => 'contact_messages_new',
        'icon'  => 'email',
      ],
      [
        'href'  => $base_url . 'admin/index.php?page=contact_messages_read',
        'label' => customLang('admin_contact_messages_read'),
        'key'   => 'contact_messages_read',
        'icon'  => 'view',
      ],
      [
        'href'  => $base_url . 'admin/index.php?page=contact_messages_resolved',
        'label' => customLang('admin_contact_messages_resolved'),
        'key'   => 'contact_messages_resolved',
        'icon'  => 'tick',
      ],
    ],
  ],
  [
    'href'  => $base_url . 'admin/index.php?page=announcements',
    'label' => customLang('admin_menu_announcements') ?: 'Announcements',
    'icon'  => 'announcement-91c6a25a14',
    'cls'   => 'announcements',
    'key'   => 'announcements',
  ],
  [
    'href'  => $base_url . 'admin/index.php?page=social_login',
    'label' => customLang('admin_menu_social_login') ?: 'Social Login Management',
    'icon'  => 'social_media',
    'cls'   => 'social_login',
    'key'   => 'social_login',
  ],
  [
    'href'  => $base_url . 'admin/index.php?page=icons',
    'label' => customLang('admin_menu_icons') ?: 'Icons',
    'icon'  => 'grid_view',
    'cls'   => 'icons_library',
    'key'   => 'icons',
  ],
  [
    'href'  => $base_url . 'admin/generate_fake_user.php',
    'label' => customLang('admin_menu_fake_user_generator') ?: 'Fake User Generator',
    'icon'  => 'make_user',
    'cls'   => 'fake_user_generator',
    'key'   => 'fake_user_generator',
  ],
  'divider',
  [
    'href'  => '#',
    'label' => customLang('admin_menu_settings') ?: 'Settings',
    'icon'  => 'site_settings',
    'cls'   => 'settings',
    'key'   => 'settings',
    'submenu' => [
      [ 'href' => $base_url . 'admin/index.php?page=settings_site',     'label' => customLang('admin_menu_settings_site') ?: 'Site Settings', 'key' => 'settings_site' ],
      [ 'href' => $base_url . 'admin/index.php?page=settings_live',     'label' => customLang('admin_menu_settings_live') ?: 'Live Settings', 'key' => 'settings_live' ],
      [ 'href' => $base_url . 'admin/index.php?page=settings_audio_rooms', 'label' => customLang('admin_menu_settings_audio_rooms') ?: 'Audio Room Settings', 'key' => 'settings_audio_rooms' ],
      [ 'href' => $base_url . 'admin/index.php?page=settings_ebooks',   'label' => customLang('admin_menu_settings_ebooks') ?: 'eBook Settings', 'key' => 'settings_ebooks' ],
      [ 'href' => $base_url . 'admin/index.php?page=ebook_languages',   'label' => customLang('admin_menu_ebook_languages') ?: 'eBook Languages', 'key' => 'ebook_languages' ],
      [ 'href' => $base_url . 'admin/index.php?page=settings_payments', 'label' => customLang('admin_menu_settings_payments') ?: 'Payment Settings', 'key' => 'settings_payments' ],
      [ 'href' => $base_url . 'admin/index.php?page=settings_onesignal', 'label' => customLang('admin_menu_settings_onesignal') ?: 'OneSignal', 'key' => 'settings_onesignal' ],
      [ 'href' => $base_url . 'admin/index.php?page=settings_sms', 'label' => customLang('admin_menu_settings_sms') ?: 'SMS', 'key' => 'settings_sms' ],
      [ 'href' => $base_url . 'admin/index.php?page=settings_landing',  'label' => customLang('admin_menu_settings_landing') ?: 'Landing Settings', 'key' => 'settings_landing' ],
      [ 'href' => $base_url . 'admin/index.php?page=settings_contact_email', 'label' => customLang('admin_settings_contact_email') ?: 'Contact & Email Settings', 'key' => 'settings_contact_email' ],
      [ 'href' => $base_url . 'admin/index.php?page=settings_footer_links',  'label' => customLang('admin_menu_footer_links') ?: 'Footer Links', 'key' => 'settings_footer_links' ],
      [ 'href' => $base_url . 'admin/index.php?page=settings_faqs',     'label' => customLang('admin_settings_faqs') ?: 'FAQs', 'key' => 'settings_faqs' ],
    ],
  ],
  [
    'href'  => '#',
    'label' => customLang('admin_menu_settings_storage') ?: 'Storage',
    'icon'  => 'storage_icon',
    'cls'   => 'settings_storage',
    'key'   => 'settings_storage_local',
    'submenu' => [
      [ 'href' => $base_url . 'admin/index.php?page=settings_storage_local',  'label' => customLang('storage_nav_local') ?: 'Local',          'key' => 'settings_storage_local' ],
      [ 'href' => $base_url . 'admin/index.php?page=settings_storage_s3',     'label' => customLang('storage_nav_s3') ?: 'Amazon S3',          'key' => 'settings_storage_s3' ],
      [ 'href' => $base_url . 'admin/index.php?page=settings_storage_spaces', 'label' => customLang('storage_nav_spaces') ?: 'DigitalOcean',    'key' => 'settings_storage_spaces' ],
      [ 'href' => $base_url . 'admin/index.php?page=settings_storage_wasabi', 'label' => customLang('storage_nav_wasabi') ?: 'Wasabi',         'key' => 'settings_storage_wasabi' ],
      [ 'href' => $base_url . 'admin/index.php?page=settings_storage_backblaze', 'label' => customLang('storage_nav_backblaze') ?: 'Backblaze B2', 'key' => 'settings_storage_backblaze' ],
    ],
  ],
];

$filteredItems = [];
foreach ($items as $item) {
  if ($item === 'divider') {
    if (!empty($filteredItems) && end($filteredItems) !== 'divider') {
      $filteredItems[] = 'divider';
    }
    continue;
  }

  $key = isset($item['key']) ? (string)$item['key'] : '';
  $hasSub = isset($item['submenu']) && is_array($item['submenu']);
  if ($hasSub) {
    $allowedSub = [];
    foreach ($item['submenu'] as $subItem) {
      $subKey = isset($subItem['key']) ? (string)$subItem['key'] : '';
      if ($subKey !== '' && !admin_has_permission(admin_page_permission_key($subKey))) {
        continue;
      }
      $allowedSub[] = $subItem;
    }
    if (empty($allowedSub)) {
      continue;
    }
    $item['submenu'] = $allowedSub;
    $filteredItems[] = $item;
    continue;
  }

  if ($key !== '' && !admin_has_permission(admin_page_permission_key($key))) {
    continue;
  }

  $filteredItems[] = $item;
}

$items = $filteredItems;

echo '<div class="sidebar sidebar--left sticky_top">';
echo '  <div class="sidebar__inner flex align_items flexBoxColumn sidebar_scroll">';
echo '    <div class="sidebar__menu_wrapper full-width flex align_items flexBoxColumn">';

foreach ($items as $it) {
  if ($it === 'divider') { echo '<div class="arrow flex full-width"></div>'; continue; }
  $href  = iN_HelpSecure((string)$it['href']);
  $label = iN_HelpSecure((string)$it['label']);
  $iconKey = isset($it['icon']) ? preg_replace('~[^a-z0-9_.-]+~i', '', (string)$it['icon']) : '';
  $iconKey = preg_replace('~\.svg$~i', '', $iconKey ?? '');
  $iconKey = $iconKey !== '' ? strtolower($iconKey) : 'reels';
  $iconMarkup = render_icon($iconKey, true);
  $cls   = preg_replace('~[^a-z0-9_-]+~i','-', (string)$it['cls']);
  $key   = isset($it['key']) ? (string)$it['key'] : '';
  $isActiveTop = $key !== '' && $currentPage === $key;
  $ariaAttr = $isActiveTop ? ' aria-current="page"' : '';

  $hasSub = isset($it['submenu']) && is_array($it['submenu']);
  if (!$hasSub) {
    $activeClass = $isActiveTop ? ' is-active' : '';
    echo '<a href="' . $href . '" class="sidebar__menu_box full-width flex align_items ' . $cls . $activeClass . '"' . $ariaAttr . '>';
    echo '  <span class="' . $cls . ' flex align_items">' . $iconMarkup . '</span>';
    echo    $label;
    echo '</a>';
    continue;
  }

  // Submenu parent (clickable label navigates to All Posts; chevron toggles submenu)
  $subItems = $it['submenu'];
  $subKeys  = array_map(function($x){ return (string)($x['key'] ?? ''); }, $subItems);
  $open     = in_array($currentPage, $subKeys, true);
  $isActiveContainer = $open || $isActiveTop;
  // Find All Posts href from submenu
  $allHref = '';
  foreach ($subItems as $si) { if (($si['key'] ?? '') === 'content') { $allHref = (string)$si['href']; break; } }
  if ($allHref === '') { $allHref = (string)$subItems[0]['href']; }
  $allHref = iN_HelpSecure($allHref);

  $parentClass = $isActiveContainer ? ' is-active' : '';
  echo '<div class="sidebar__menu_box full-width flex align_items ' . $cls . ' has-submenu' . $parentClass . '">';
  echo '  <span class="' . $cls . ' flex align_items">' . $iconMarkup . '</span>';
  $submenuLabelAttr = $isActiveContainer ? ' aria-current="page"' : '';
  echo '  <a class="submenu-label" href="' . $allHref . '"' . $submenuLabelAttr . '>' . $label . '</a>';
  echo '  <button type="button" class="submenu-toggle' . ($open ? ' is-open' : '') . '" data-submenu-toggle aria-label="Toggle submenu" aria-expanded="' . ($open ? 'true' : 'false') . '"><span class="chev"></span></button>';
  echo '</div>';

  // Submenu container (next sibling of the parent row)
  echo '<div class="sidebar__submenu full-width flex flexBoxColumn' . ($open ? '' : ' is-hidden') . '">';
  foreach ($subItems as $sub) {
    $sHref  = iN_HelpSecure((string)$sub['href']);
    $sLabel = iN_HelpSecure((string)$sub['label']);
    $isAct  = (string)$sub['key'] === $currentPage ? ' is-active' : '';
    $sk = (string)($sub['key'] ?? '');
    $sicon = isset($sub['icon']) ? (string)$sub['icon'] : '';
    if ($sicon !== '') {
      $sicon = preg_replace('~[^a-z0-9_.-]+~i', '', $sicon);
      $sicon = preg_replace('~\.svg$~i', '', $sicon);
    } else {
      $sicon = 'reels';
      if ($sk === 'content_everyone') { $sicon = 'world'; }
      elseif ($sk === 'content_subscribers') { $sicon = 'subscriber'; }
      elseif ($sk === 'content_locked') { $sicon = 'locked'; }
      elseif ($sk === 'content_followers') { $sicon = 'follower'; }
      elseif ($sk === 'reported_posts') { $sicon = 'notification'; }
      elseif ($sk === 'reported_comments') { $sicon = 'comment'; }
      elseif ($sk === 'settings_landing') { $sicon = 'landing_settings'; }
      elseif ($sk === 'settings_payments') { $sicon = 'payments'; }
      elseif ($sk === 'settings_ebooks') { $sicon = 'saved'; }
      elseif ($sk === 'ebook_languages') { $sicon = 'ebook'; }
      elseif ($sk === 'settings_site') { $sicon = 'site_setting'; }
      elseif ($sk === 'settings_live') { $sicon = 'live'; }
      elseif ($sk === 'settings_audio_rooms') { $sicon = 'podcast'; }
      elseif ($sk === 'settings_faqs') { $sicon = 'help_center'; }
      elseif ($sk === 'settings_footer_links') { $sicon = 'link'; }
      elseif ($sk === 'settings_contact_email') { $sicon = 'email'; }
      elseif ($sk === 'settings_onesignal'){ $sicon = 'onesignal_icon'; }
      else if($sk === 'settings_storage_local'){ $sicon = 'local_storage_icon'; }
      else if($sk === 'settings_storage_s3'){ $sicon = 's3_icon'; }
      else if($sk === 'settings_storage_spaces'){ $sicon = 'digital_ocean_icon'; }
      else if($sk === 'settings_storage_wasabi'){ $sicon = 'wasabi_icon'; }
      else if($sk === 'settings_storage_backblaze'){ $sicon = 'backblaze_icon'; }
      elseif ($sk === 'content') { $sicon = 'reels'; }
    }
    $sicon = strtolower($sicon);
    $siconMarkup = render_icon($sicon !== '' ? $sicon : 'reels', true);
    echo '<a href="' . $sHref . '" class="sidebar__menu_box submenu-item full-width flex align_items' . $isAct . '">';
    echo '  <span class="submenu-icon flex align_items">' . $siconMarkup . '</span>';
    echo    $sLabel;
    echo '</a>';
  }
  echo '</div>';
}
echo '    </div>';
echo '  </div>';
echo '</div>';
