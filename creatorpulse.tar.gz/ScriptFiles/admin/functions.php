<?php
declare(strict_types=1);

// Admin function loader similar to includes/functions.php

require_once __DIR__ . '/functions/content_functions.php';
require_once __DIR__ . '/functions/user_functions.php';
require_once __DIR__ . '/functions/audit_functions.php';
require_once __DIR__ . '/functions/dashboard_functions.php';
require_once __DIR__ . '/functions/invoice_functions.php';
require_once __DIR__ . '/functions/icon_functions.php';
require_once __DIR__ . '/functions/advertisement_functions.php';
require_once __DIR__ . '/functions/podcast_ad_functions.php';
require_once __DIR__ . '/functions/payout_functions.php';
require_once __DIR__ . '/functions/audio_room_functions.php';

class Admin_Data
{
    use AdminContentFunctions,
        AdminUserFunctions,
        AdminAuditFunctions,
        AdminDashboardFunctions,
        AdminInvoiceFunctions,
        AdminIconFunctions,
        AdminAdvertisementFunctions,
        AdminPodcastAdFunctions,
        AdminPayoutFunctions,
        AdminAudioRoomFunctions;

    private PDO $db;
    private ?Reel_Data $rl; // Optional access to front-side functions

    public function __construct(PDO $db, ?Reel_Data $rl = null)
    {
        $this->db = $db;
        $this->rl = $rl;
    }

    public function db(): PDO
    {
        return $this->db;
    }

    public function rl(): ?Reel_Data
    {
        return $this->rl ?? null;
    }

    public function setRL(?Reel_Data $rl): void
    {
        $this->rl = $rl;
    }

    protected function logError(string $msg): void
    {
        error_log('[Admin] ' . $msg);
    }
}
