"use strict";

// (reverted) Do not override site theme preference here; let theme/header.js handle it.

// Minimal admin helpers (no dependencies)
(function(){
  window._adminUnlocked = false;

  function post(url, data) {
    return fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: Object.entries(data).map(([k,v]) => encodeURIComponent(k)+'='+encodeURIComponent(v)).join('&')
    }).then(r => r.json());
  }

  function getCsrf() {
    var meta = document.querySelector('meta[name="admin-csrf"]');
    return meta ? (meta.getAttribute('content') || '') : '';
  }

  window.adminReauthStart = function adminReauthStart(){
    if (typeof window.adminPrompt !== 'function') {
      var fallback = window.prompt(adminLang('admin_reauth_prompt', 'Re-enter your password to edit payment secrets:'));
      handleReauthSubmit(fallback || '');
      return;
    }
    window.adminPrompt({
      title: adminLang('admin_reauth_modal_title', 'Unlock payment secrets'),
      message: adminLang('admin_reauth_modal_message', 'Re-enter your password to edit payment secrets.'),
      placeholder: adminLang('admin_reauth_modal_placeholder', 'Password'),
      confirmLabel: adminLang('admin_reauth_modal_confirm', 'Unlock'),
      cancelLabel: adminLang('cancel', 'Cancel'),
      inputType: 'password',
      required: true,
    }).then(function(pw){
      handleReauthSubmit(pw || '');
    });
  };

  function handleReauthSubmit(pw) {
    if (!pw) { return; }
    var url = (window.location.origin + window.location.pathname).replace(/admin\/index\.php.*/, '') + 'admin/request/payment_settings.php';
    post(url, { action: 'reauth', password: pw, csrf_token: getCsrf() })
      .then(function(res){
        if (res && res.status === 'success') {
          window._adminUnlocked = true;
          // Allow editing by switching password inputs to text, do not reveal current values
          document.querySelectorAll('form input[type="password"]').forEach(function(inp){
            try { inp.type = 'text'; inp.value = ''; } catch(e) {}
          });
          adminToast(adminLang('admin_reauth_unlocked', 'Unlocked. You can now edit and save.'), 'success');
        } else {
          adminToast(adminLang('admin_reauth_failed', 'Re-authentication failed.'), 'error');
        }
      })
      .catch(function(){ adminToast(adminLang('admin_network_error', 'Network error.'), 'error'); });
  }

  window.adminReauthEnsure = function adminReauthEnsure(ev){
    if (!window._adminUnlocked) {
      ev.preventDefault();
      window.adminReauthStart();
      return false;
    }
    return true;
  };
})();

/* Audio Room administration */
(function(){
  var root = document.querySelector('[data-admin-audio-rooms]');
  if (!root) { return; }

  function setFeedback(message, error){
    var output = root.querySelector('[data-audio-room-feedback]');
    if (!output) { return; }
    output.textContent = message || '';
    output.classList.toggle('is-error', !!error);
  }

  function closeMenus(){
    root.querySelectorAll('.post-menu-popup').forEach(function(menu){
      menu.classList.add('none');
      menu.setAttribute('aria-hidden', 'true');
    });
    root.querySelectorAll('.post-settings-btn[aria-expanded="true"]').forEach(function(button){
      button.setAttribute('aria-expanded', 'false');
    });
  }

  function submitClose(button, reason){
    var body = new FormData();
    body.append('csrf_token', root.getAttribute('data-csrf') || '');
    body.append('audio_room_action', 'close');
    body.append('room_id', button.getAttribute('data-room-id') || '0');
    body.append('reason', reason);
    button.disabled = true;
    setFeedback('', false);
    fetch(root.getAttribute('data-action-url') || '', {method:'POST', body:body, credentials:'same-origin', headers:{'X-Requested-With':'XMLHttpRequest'}})
      .then(function(response){ return response.json().catch(function(){ return {status:'error',message:'Unexpected server response.'}; }); })
      .then(function(data){
        if (!data || data.status !== 'success') { throw new Error(data && data.message ? data.message : 'The action could not be completed.'); }
        var row = root.querySelector('[data-audio-room-row="' + String(data.room_id || '') + '"]');
        if (row) {
          row.setAttribute('data-status', data.status || 'ended');
          var badge = row.querySelector('.admin-audio-room-status');
          if (badge) {
            badge.className = 'admin-audio-room-status admin-audio-room-status--' + (data.status || 'ended');
            badge.textContent = data.status === 'cancelled' ? 'Cancelled' : 'Ended';
          }
          button.remove();
        }
        setFeedback(data.message || 'Audio Room closed.', false);
      })
      .catch(function(error){ setFeedback(error.message || 'The action could not be completed.', true); button.disabled = false; });
  }

  root.addEventListener('click', function(event){
    var button = event.target && event.target.closest ? event.target.closest('.js-admin-audio-room-close') : null;
    if (!button) { return; }
    event.preventDefault();
    closeMenus();
    var title = button.getAttribute('data-room-title') || 'Audio Room';
    var promptOptions = {
      title: 'End Audio Room',
      message: 'Explain why "' + title + '" is being closed. Everyone currently in the room will be removed.',
      label: 'Reason',
      placeholder: 'Write a clear administrative reason',
      required: true,
      confirmLabel: 'End room',
      cancelLabel: 'Cancel'
    };
    var prompt = typeof window.adminPrompt === 'function'
      ? window.adminPrompt(promptOptions)
      : Promise.resolve(window.prompt(promptOptions.label));
    prompt.then(function(reason){
      reason = reason === null ? '' : String(reason).trim();
      if (reason.length >= 3) { submitClose(button, reason); }
    });
  });
})();

// Bind admin UI events and provide stubs for actions
// Simple toast helper (uses theme's DZ.toast if available; DOM fallback without alerts)
function adminToast(msg, type){
  try { if (typeof ensureDzToast === 'function') ensureDzToast(); } catch(_){}
  try {
    if (window.DZ && typeof DZ.toast === 'function') {
      DZ.toast(String(msg||''), { type: type || 'info', duration: 2000 });
      return;
    }
  } catch(_){}
  // Minimal DOM toast fallback
  try {
    var host = document.getElementById('admin-toast-host');
    if (!host) {
      host = document.createElement('div');
      host.id = 'admin-toast-host';
      host.style.position = 'fixed';
      host.style.top = '16px';
      host.style.right = '16px';
      host.style.left = '';
      host.style.bottom = '';
      host.style.transform = '';
      host.style.zIndex = '3005';
      host.style.display = 'flex';
      host.style.flexDirection = 'column';
      host.style.gap = '8px';
      host.style.alignItems = 'flex-end';
      host.setAttribute('aria-live','polite');
      document.body.appendChild(host);
    }
    var el = document.createElement('div');
    el.textContent = String(msg||'');
    el.style.padding = '10px 14px';
    el.style.color = '#fff';
    el.style.font = '500 14px system-ui, -apple-system, Segoe UI, Roboto, sans-serif';
    el.style.borderRadius = '30px';
    el.style.boxShadow = '0 4px 16px rgba(0,0,0,0.25)';
    el.style.background = 'rgba(0,0,0,0.8)';
    el.style.opacity = '0';
    el.style.transition = 'opacity 160ms ease, transform 160ms ease';
    el.style.transform = 'translateY(-6px)';
    host.appendChild(el);
    requestAnimationFrame(function(){ el.style.opacity = '1'; el.style.transform = 'translateY(0)'; });
    setTimeout(function(){
      try { el.style.opacity = '0'; el.style.transform = 'translateY(-6px)'; } catch(_){}
      setTimeout(function(){ try { host.removeChild(el); } catch(_){} }, 220);
    }, 2200);
  } catch(_){}
}

function adminLang(key, fallback, params) {
  var value = '';
  try {
    if (window.DZ && typeof window.DZ.i18n === 'function') {
      value = window.DZ.i18n(key, params);
    } else if (typeof window.I18N === 'function') {
      value = window.I18N(key, params);
    }
  } catch(_) {}
  if (!value) {
    value = fallback || '';
    if (value && params && typeof params === 'object') {
      Object.keys(params).forEach(function(k){
        value = value.replace(new RegExp('\\{' + k + '\\}', 'g'), String(params[k]));
      });
    }
  }
  return value;
}

// Map backend error codes to friendly messages
function adminMsg(msg){
  var m = String(msg || '');
  switch (m) {
    case 'owner_protected': return adminLang('admin_owner_protected', 'This action is not allowed for the owner account.');
    case 'self_role_forbidden': return adminLang('admin_self_role_forbidden', 'You cannot change your own role to a lower level.');
    case 'bad_action': return adminLang('admin_bad_action', 'Unknown or invalid action.');
    case 'bad_user': return adminLang('admin_bad_user', 'Invalid user.');
    case 'cannot_target_self': return adminLang('admin_cannot_target_self', 'You cannot apply this action to your own account.');
    case 'forbidden': return adminLang('admin_forbidden', 'You do not have permission for this action.');
    case 'invalid_csrf': return adminLang('invalid_csrf_token', 'Invalid CSRF token.');
    case 'op_failed': return adminLang('ui_unknown_error', 'Operation failed. Please try again.');
    case 'server_error': return adminLang('server_error', 'Server error. Please try again later.');
    case 'invalid_media_mode': return adminLang('admin_invalid_media_mode', 'Invalid media mode option.');
    case 'invalid_target': return adminLang('admin_invalid_target', 'Invalid navigation target.');
    case 'invalid_length': return adminLang('admin_invalid_length', 'One or more fields exceed the allowed length.');
    case 'invalid_email': return adminLang('admin_invalid_email', 'Invalid email address provided.');
    case 'invalid_rate_limit': return adminLang('admin_contact_invalid_rate', 'Rate limit must be between 0 and 1000.');
    case 'invalid_subject': return adminLang('invalid_subject', 'Subject is required.');
    case 'invalid_message_body': return adminLang('invalid_message_body', 'Message body is required.');
    case 'invalid_media': return adminLang('admin_ads_edit_media_remove_error', 'Unable to remove image.');
    case 'invalid_host': return adminLang('admin_smtp_invalid_host', 'SMTP host is invalid.');
    case 'invalid_port': return adminLang('admin_smtp_invalid_port', 'SMTP port must be between 1 and 65535.');
    case 'invalid_secure_option': return adminLang('admin_smtp_invalid_secure', 'Invalid encryption option selected.');
    case 'smtp_not_configured': return adminLang('admin_smtp_not_configured', 'Configure SMTP settings before sending tests.');
    case 'smtp_test_rate_limited': return adminLang('admin_smtp_test_rate_limited', 'Too many test emails. Please wait a minute.');
    case 'smtp_send_failed': return adminLang('admin_smtp_send_failed', 'Test email failed to send.');
    case 'encrypt_failed': return adminLang('admin_smtp_encrypt_failed', 'Unable to secure the SMTP password.');
    case 'contact_message_not_found': return adminLang('contact_message_not_found', 'Message not found.');
    case 'contact_invalid_status': return adminLang('contact_invalid_status', 'Invalid status value.');
    case 'invalid_provider': return adminLang('storage_error_invalid_provider', 'Invalid storage provider selected.');
    case 'invalid_bucket': return adminLang('storage_error_invalid_bucket', 'Bucket or space name is invalid.');
    case 'invalid_region': return adminLang('storage_error_invalid_region', 'Region value is invalid.');
    case 'invalid_public_base_url': return adminLang('storage_error_invalid_public_base', 'Public base URL is invalid.');
    case 'invalid_endpoint': return adminLang('storage_error_invalid_endpoint', 'Endpoint URL is invalid.');
    case 'invalid_prefix': return adminLang('storage_error_invalid_prefix', 'Prefix may only contain letters, numbers, dashes, underscores, and slashes.');
    case 'missing_required': return adminLang('storage_error_missing_required', 'Missing required field.');
    case 'invalid_number': return adminLang('storage_error_invalid_number', 'Numeric value is out of range.');
    case 'storage_test_success': return adminLang('storage_test_success', 'Connection successful.');
    case 'storage_test_deferred': return adminLang('storage_test_deferred', 'Connection not attempted (network access deferred).');
    case 'storage_test_failed': return adminLang('storage_test_failed', 'Connection test failed.');
    case 'storage_test_local_missing_root': return adminLang('storage_test_local_missing_root', 'Uploads directory not found.');
    case 'storage_test_local_unreadable': return adminLang('storage_test_local_unreadable', 'Uploads directory is not readable.');
    case 'storage_test_local_not_writable': return adminLang('storage_test_local_not_writable', 'Uploads directory is not writable.');
    case 'storage_test_remote_sign_failed': return adminLang('storage_test_remote_sign_failed', 'Failed to generate signed request.');
    case 'storage_test_remote_network_failed': return adminLang('storage_test_remote_network_failed', 'Network check failed for the storage provider.');
    case 'storage_sync_not_available': return adminLang('storage_sync_not_available', 'Storage sync service is not available in this build.');
    case 'admin_podcast_category_saved': return adminLang('admin_podcast_category_saved', 'Category saved.');
    case 'admin_podcast_category_deleted': return adminLang('admin_podcast_category_deleted', 'Category deleted.');
    case 'admin_podcast_category_status_updated': return adminLang('admin_podcast_category_status_updated', 'Category status updated.');
    case 'admin_podcast_category_invalid_name': return adminLang('admin_podcast_category_invalid_name', 'Category name is required.');
    case 'admin_podcast_category_invalid_slug': return adminLang('admin_podcast_category_invalid_slug', 'Slug is required and must only include letters, numbers, or dashes.');
    case 'admin_podcast_category_invalid_status': return adminLang('admin_podcast_category_invalid_status', 'Invalid status value.');
    case 'admin_podcast_category_invalid_sort': return adminLang('admin_podcast_category_invalid_sort', 'Invalid sort order.');
    case 'admin_podcast_category_slug_exists': return adminLang('admin_podcast_category_slug_exists', 'Slug is already in use.');
    case 'admin_podcast_category_not_found': return adminLang('admin_podcast_category_not_found', 'Category not found.');
    default: return adminLang(m, m || 'unknown');
  }
}

function slugifyPage(value){
  if (value == null) { return ''; }
  var str = String(value).trim().toLowerCase();
  if (str && typeof str.normalize === 'function') {
    str = str.normalize('NFKD').replace(/[\u0300-\u036f]/g, '');
  }
  str = str.replace(/[^a-z0-9]+/g, '-');
  str = str.replace(/-+/g, '-');
  str = str.replace(/^-+|-+$/g, '');
  if (str.length > 120) {
    str = str.slice(0, 120);
  }
  return str;
}

function sanitizeEditorHtml(html, options){
  if (typeof html !== 'string') {
    return html;
  }

  var opts = options || {};
  var allowStyles = !!opts.allowStyles;
  var safeStyleProperties = opts.allowedStyleProps || ['color', 'background-color', 'text-decoration', 'font-weight', 'font-style', 'text-align'];

  function cleanStyleValue(value) {
    if (!allowStyles || typeof value !== 'string') {
      return '';
    }
    var rules = value.split(';');
    var kept = [];
    for (var i = 0; i < rules.length; i += 1) {
      var rule = rules[i].trim();
      if (!rule) { continue; }
      var parts = rule.split(':');
      if (parts.length < 2) { continue; }
      var prop = parts[0].trim().toLowerCase();
      var val = parts.slice(1).join(':').trim();
      if (!prop || !val) { continue; }
      if (safeStyleProperties.indexOf(prop) === -1) { continue; }
      if (/expression\(|javascript:|data:|url\(/i.test(val)) { continue; }
      if (val.length > 120) { continue; }
      kept.push(prop + ': ' + val);
    }
    return kept.join('; ');
  }

  var sanitized = html
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/\son[a-z]+\s*=\s*"[^"]*"/gi, '')
    .replace(/\son[a-z]+\s*=\s*'[^']*'/gi, '')
    .replace(/\son[a-z]+\s*=\s*[^\s>]+/gi, '')
    .replace(/\shref\s*=\s*"javascript:[^"]*"/gi, ' href="#"')
    .replace(/\shref\s*=\s*'javascript:[^']*'/gi, " href='#'")
    .replace(/<\?(?:php)?[\s\S]*?\?>/gi, '');

  if (allowStyles) {
    sanitized = sanitized
      .replace(/\sstyle\s*=\s*"([^"]*)"/gi, function(match, value){
        var cleaned = cleanStyleValue(value);
        return cleaned ? ' style="' + cleaned + '"' : '';
      })
      .replace(/\sstyle\s*=\s*'([^']*)'/gi, function(match, value){
        var cleaned = cleanStyleValue(value);
        return cleaned ? " style='" + cleaned + "'" : '';
      });
  } else {
    sanitized = sanitized
      .replace(/\sstyle\s*=\s*"[^"]*"/gi, '')
      .replace(/\sstyle\s*=\s*'[^']*'/gi, '');
  }

  return sanitized;
}

var __tinymceWaiters = [];
var __tinymceCheckTimer = null;

function waitForTinymce(callback){
  if (window.tinymce && typeof window.tinymce.init === 'function') {
    callback(window.tinymce);
    return;
  }
  __tinymceWaiters.push(callback);
  if (!__tinymceCheckTimer) {
    __tinymceCheckTimer = window.setInterval(function(){
      if (window.tinymce && typeof window.tinymce.init === 'function') {
        window.clearInterval(__tinymceCheckTimer);
        __tinymceCheckTimer = null;
        var queue = __tinymceWaiters.slice();
        __tinymceWaiters.length = 0;
        queue.forEach(function(fn){
          try { fn(window.tinymce); } catch(_){}
        });
      }
    }, 120);
  }
}

var __cmsEditorCounter = 0;

var ANNOUNCEMENT_COLOR_PRESETS = [
  { value: '#111827', className: 'ann-color-111827', labelKey: 'admin_color_charcoal', fallback: 'Charcoal' },
  { value: '#ffffff', className: 'ann-color-ffffff', labelKey: 'admin_color_white', fallback: 'White' },
  { value: '#475569', className: 'ann-color-475569', labelKey: 'admin_color_slate', fallback: 'Slate' },
  { value: '#2563eb', className: 'ann-color-2563eb', labelKey: 'admin_color_blue', fallback: 'Blue' },
  { value: '#0891b2', className: 'ann-color-0891b2', labelKey: 'admin_color_cyan', fallback: 'Cyan' },
  { value: '#10b981', className: 'ann-color-10b981', labelKey: 'admin_color_green', fallback: 'Green' },
  { value: '#f59e0b', className: 'ann-color-f59e0b', labelKey: 'admin_color_amber', fallback: 'Amber' },
  { value: '#e11d48', className: 'ann-color-e11d48', labelKey: 'admin_color_rose', fallback: 'Rose' },
  { value: '#7c3aed', className: 'ann-color-7c3aed', labelKey: 'admin_color_purple', fallback: 'Purple' },
  { value: '#0f172a', className: 'ann-color-0f172a', labelKey: 'admin_color_midnight', fallback: 'Midnight' },
  { value: '#f1f5f9', className: 'ann-color-f1f5f9', labelKey: 'admin_color_slate_light', fallback: 'Soft Slate' }
];

var __annColorPluginRegistered = false;

function buildAnnouncementColorMap() {
  var map = [];
  ANNOUNCEMENT_COLOR_PRESETS.forEach(function (entry) {
    map.push(entry.value, adminLang(entry.labelKey, entry.fallback));
  });
  return map;
}

function ensureAnnouncementColorPlugin(tiny) {
  if (__annColorPluginRegistered || !tiny || !tiny.PluginManager) {
    return;
  }
  try {
    if (tiny.PluginManager.lookup && tiny.PluginManager.lookup('anncolor')) {
      __annColorPluginRegistered = true;
      return;
    }
  } catch (_) {}

  try {
    tiny.PluginManager.add('anncolor', function (editor) {
      function normalizeHex(value) {
        if (!value) { return ''; }
        var val = String(value).trim().toLowerCase();
        if (val === 'transparent') {
          return '';
        }
        if (val.indexOf('#') === 0) {
          val = val.slice(1);
        } else if (val.indexOf('rgb') === 0) {
          var match = val.match(/rgba?\s*\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})(?:\s*,\s*([\d.]+))?/i);
          if (match) {
            if (typeof match[4] !== 'undefined' && parseFloat(match[4]) === 0) {
              return '';
            }
            val = [match[1], match[2], match[3]].map(function (part) {
              var num = Math.max(0, Math.min(255, parseInt(part, 10) || 0));
              var hex = num.toString(16);
              return hex.length === 1 ? '0' + hex : hex;
            }).join('');
          }
        }
        if (val.length === 3) {
          val = val[0] + val[0] + val[1] + val[1] + val[2] + val[2];
        }
        return val.length === 6 ? ('#' + val) : '';
      }

      var palette = ANNOUNCEMENT_COLOR_PRESETS.map(function (entry) {
        return {
          value: entry.value,
          label: adminLang(entry.labelKey, entry.fallback),
          normalized: normalizeHex(entry.value)
        };
      });

      function applyColor(format, value) {
        editor.undoManager.transact(function () {
          editor.focus();
          if (value) {
            editor.formatter.apply(format, { value: value });
          } else {
            editor.formatter.remove(format, {}, null, true);
          }
          editor.nodeChanged();
        });
      }

      function getCurrentColor(format) {
        var startNode = editor.selection ? editor.selection.getStart(true) : null;
        if (startNode && editor.dom) {
          var prop = format === 'forecolor' ? 'color' : 'background-color';
          var styleValue = editor.dom.getStyle(startNode, prop, true);
          return normalizeHex(styleValue);
        }
        return '';
      }

      function buildMenuItems(format, removeLabel) {
        var items = palette.map(function (item) {
          return {
            type: 'menuitem',
            text: item.label,
            onAction: function () {
              applyColor(format, item.value);
            },
            onSetup: function (api) {
              var listener = function () {
                api.setActive(normalizeHex(getCurrentColor(format)) === item.normalized);
              };
              editor.on('NodeChange', listener);
              listener();
              return function () {
                editor.off('NodeChange', listener);
              };
            }
          };
        });

        items.push({
          type: 'menuitem',
          text: removeLabel,
          onAction: function () {
            applyColor(format, '');
          },
          onSetup: function (api) {
            var listener = function () {
              api.setActive(normalizeHex(getCurrentColor(format)) === '');
            };
            editor.on('NodeChange', listener);
            listener();
            return function () {
              editor.off('NodeChange', listener);
            };
          }
        });

        return items;
      }

      function registerMenuButton(name, format, icon, tooltip, removeLabel) {
        editor.ui.registry.addMenuButton(name, {
          icon: icon,
          tooltip: tooltip,
          fetch: function (callback) {
            callback(buildMenuItems(format, removeLabel));
          }
        });
      }

      registerMenuButton(
        'anntextcolor',
        'forecolor',
        'color-picker',
        adminLang('admin_color_text_tooltip', 'Text color'),
        adminLang('admin_color_remove', 'Remove color')
      );

      registerMenuButton(
        'annbgcolor',
        'hilitecolor',
        'highlight-bg-color',
        adminLang('admin_color_bg_tooltip', 'Background color'),
        adminLang('admin_color_remove', 'Remove highlight')
      );

      return {
        getMetadata: function () {
          return {
            name: 'Announcement Color Tools'
          };
        }
      };
    });

    __annColorPluginRegistered = true;
  } catch (__) {}
}

function getCmsEditorConfig(target){
  var base = adminRootUrl();
  var uploadUrl = base + 'admin/request/page_media.php';
  var allowImages = true;
  var dataImages = (target && target.getAttribute) ? (target.getAttribute('data-editor-images') || '').toLowerCase() : '';
  if (dataImages === '0' || dataImages === 'false' || dataImages === 'no' || dataImages === 'off') {
    allowImages = false;
  }

  var allowColors = false;
  var allowInlineStyles = false;
  var colorsAttr = (target && target.getAttribute) ? (target.getAttribute('data-editor-colors') || '').toLowerCase() : '';
  if (colorsAttr && colorsAttr !== '0' && colorsAttr !== 'false' && colorsAttr !== 'no' && colorsAttr !== 'off') {
    allowColors = true;
  }
  var stylesAttr = (target && target.getAttribute) ? (target.getAttribute('data-editor-styles') || '').toLowerCase() : '';
  if (stylesAttr && stylesAttr !== '0' && stylesAttr !== 'false' && stylesAttr !== 'no' && stylesAttr !== 'off') {
    allowInlineStyles = true;
  }

  function uploadImage(blob, fileName) {
    var wrapped = blob;
    try {
      if (blob && typeof blob.blob === 'function') {
        wrapped = blob.blob();
      }
    } catch (_) {}
    var csrfEl = document.querySelector('meta[name="admin-csrf"]');
    var csrf = csrfEl ? (csrfEl.getAttribute('content') || '') : '';
    var formData = new FormData();
    formData.append('csrf_token', csrf);
    formData.append('image', wrapped, fileName || ('image_' + Date.now()));
    return fetch(uploadUrl, {
      method: 'POST',
      body: formData
    })
      .then(function(resp){
        return resp.json().catch(function(){ return {}; });
      })
      .then(function(data){
        if (data && data.status === 'success' && data.location) {
          return data.location;
        }
        var msg = (data && data.message) ? adminMsg(data.message) : adminLang('admin_upload_failed', 'Upload failed.');
        throw new Error(msg);
      });
  }

  var plugins = ['link', 'lists', 'code'];
  if (allowImages) {
    plugins.push('image');
  }
  if (allowColors && allowInlineStyles) {
    if (window && window.tinymce) {
      ensureAnnouncementColorPlugin(window.tinymce);
    }
    plugins.push('anncolor');
  }
  var toolbar = 'undo redo | bold italic underline';
  if (allowColors && allowInlineStyles) {
    toolbar += ' anntextcolor annbgcolor';
  }
  toolbar += ' | alignleft aligncenter alignright | bullist numlist | link';
  if (allowImages) {
    toolbar += ' image';
  }
  toolbar += ' | removeformat | code';

  var validElements = 'p,h1,h2,h3,h4,h5,h6,strong/b,em/i,ul,ol,li,blockquote,code,pre,a[href|target|rel|title],img[src|alt],br,hr';
  if (allowInlineStyles) {
    validElements += ',span[style]';
  }

  var docEl = document.documentElement;
  var bodyEl = document.body || document.documentElement;
  var themeAttr = docEl ? (docEl.getAttribute('data-theme') || '') : '';
  var isDark = false;
  if (themeAttr.toLowerCase() === 'dark') {
    isDark = true;
  } else if (themeAttr.toLowerCase() !== 'light') {
    if (docEl && docEl.classList.contains('theme-dark')) {
      isDark = true;
    } else if (bodyEl && bodyEl.classList.contains('theme-dark')) {
      isDark = true;
    } else if (typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      isDark = true;
    }
  }

  var skinBase = base + 'admin/js/tinymce/skins/';
  var uiSkin = isDark ? 'ui/oxide-dark' : 'ui/oxide';
  var contentSkin = isDark ? 'content/dark' : 'content/default';

  var config = {
    target: target,
    menubar: false,
    branding: false,
    statusbar: true,
    toolbar_sticky: true,
    plugins: plugins.join(' '),
    toolbar: toolbar,
    skin_url: skinBase + uiSkin,
    content_css: skinBase + contentSkin + '/content.min.css',
    valid_elements: validElements,
    valid_styles: allowInlineStyles ? { '*': 'color,background-color,text-decoration,font-weight,font-style,text-align' } : { '*': '' },
    automatic_uploads: allowImages,
    paste_data_images: false,
    default_link_target: '_self',
    link_default_target: '_self',
    link_default_rel: 'noopener nofollow',
    setup: function (editor) {
      // Use TinyMCE default color buttons when inline styles are allowed
      editor.on('change keyup', function () {
        editor.save();
      });
      editor.on('Paste', function (event) {
        if (event.clipboardData && typeof event.clipboardData.getData === 'function') {
          var pasted = event.clipboardData.getData('text/html');
          if (pasted) {
            event.preventDefault();
            editor.insertContent(sanitizeEditorHtml(pasted, { allowStyles: allowInlineStyles }));
          }
        }
      });
      editor.on('BeforeSetContent', function (evt) {
        if (evt && typeof evt.content === 'string') {
          evt.content = sanitizeEditorHtml(evt.content, { allowStyles: allowInlineStyles });
        }
      });
    }
  };

  if (allowColors && allowInlineStyles) {
    config.color_map = buildAnnouncementColorMap();
    config.color_default_foreground = ANNOUNCEMENT_COLOR_PRESETS[0].value;
    config.color_default_background = '#f1f5f9';
  }

  if (allowImages) {
    config.images_upload_handler = function (blobInfo, success, failure) {
      return uploadImage(blobInfo, blobInfo.filename())
        .then(function(url){
          success(url);
          if (typeof adminToast === 'function') {
            adminToast(adminLang('admin_image_uploaded', 'Image uploaded.'), 'success');
          }
          return url;
        })
        .catch(function(err){
          var msg = err && err.message ? err.message : adminLang('admin_upload_failed', 'Upload failed.');
          if (typeof adminToast === 'function') {
            adminToast(msg, 'error');
          }
          failure(msg);
          throw err;
        });
    };
    config.image_dimensions = false;
    config.convert_urls = false;
    config.relative_urls = false;
    config.remove_script_host = false;
    config.file_picker_types = 'image';
    config.file_picker_callback = function (cb, value, meta) {
      if (meta.filetype !== 'image') {
        return;
      }
      var input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.addEventListener('change', function(){
        if (!input.files || !input.files.length) { return; }
        var file = input.files[0];
        uploadImage(file, file.name)
          .then(function(url){
            cb(url, { title: file.name });
            if (typeof adminToast === 'function') {
              adminToast(adminLang('admin_image_uploaded', 'Image uploaded.'), 'success');
            }
            return url;
          })
          .catch(function(err){
            var msg = err && err.message ? err.message : adminLang('admin_upload_failed', 'Upload failed.');
            if (typeof adminToast === 'function') {
              adminToast(msg, 'error');
            }
            throw err;
          });
      });
      input.click();
    };
  } else {
    config.valid_elements = config.valid_elements.replace(/,?img\[[^]]*\]/, '');
  }

  return config;
}

function initCmsEditor(textarea){
  if (!textarea) { return; }
  if (!textarea.id) {
    __cmsEditorCounter += 1;
    textarea.id = 'cms_editor_' + __cmsEditorCounter;
  }
  waitForTinymce(function(tiny){
    if (tiny.get(textarea.id)) {
      return;
    }
    tiny.init(getCmsEditorConfig(textarea));
  });
}

function initCmsEditors(root){
  if (!root) { return; }
  var editors = root.querySelectorAll('.js-page-editor');
  if (!editors.length) { return; }
  editors.forEach(function(textarea){ initCmsEditor(textarea); });
}

function initLangTabs(root){
  if (!root) { return; }
  root.querySelectorAll('[data-lang-tabs]').forEach(function(tabGroup){
    if (tabGroup.__langTabsBound) { return; }
    tabGroup.__langTabsBound = true;
    var container = tabGroup.closest('[data-lang-switcher]') || root;
    var buttons = tabGroup.querySelectorAll('[data-lang-target]');
    var panels = container.querySelectorAll('[data-lang-panel]');
    buttons.forEach(function(btn){
      btn.addEventListener('click', function(){
        var lang = btn.getAttribute('data-lang-target') || '';
        buttons.forEach(function(other){
          var active = other === btn;
          other.classList.toggle('is-active', active);
          other.setAttribute('aria-selected', active ? 'true' : 'false');
        });
        panels.forEach(function(panel){
          var match = panel.getAttribute('data-lang-panel') === lang;
          panel.classList.toggle('is-active', match);
          if (match) {
            panel.removeAttribute('hidden');
            panel.setAttribute('aria-hidden', 'false');
          } else {
            panel.setAttribute('hidden', '');
            panel.setAttribute('aria-hidden', 'true');
          }
        });
      });
    });
  });
}

function initLandingPagesForm(form){
  if (!form) { return; }
  var list = form.querySelector('[data-sortable-list="pages"]');
  var template = document.getElementById('footerPageTemplate');
  if (!list || !template) { return; }

  var deletedHost = form.querySelector('.pages-deleted');
  var addBtn = form.querySelector('[data-action="add-page"]');
  var defaultTitleMsg = form.getAttribute('data-error-default-title') || adminLang('admin_page_default_required', 'Default language title is required.');
  var slugLimit = 120;

  function bindCard(card){
    if (!card || card.__landingPageBound) { return; }
    card.__landingPageBound = true;
    initLangTabs(card);
    initCmsEditors(card);

    var slugInput = card.querySelector('[data-page-slug]');
    var defaultTitleInput = card.querySelector('[data-page-title="default"]');
    if (slugInput) {
      slugInput.value = slugifyPage(slugInput.value);
      if (slugInput.value.length > slugLimit) {
        slugInput.value = slugInput.value.slice(0, slugLimit);
      }
      card.dataset.slugDirty = slugInput.value.trim() !== '' ? '1' : '0';
      slugInput.addEventListener('input', function(){
        card.dataset.slugDirty = '1';
        var slug = slugifyPage(slugInput.value);
        slugInput.value = slug.length > slugLimit ? slug.slice(0, slugLimit) : slug;
      });
      slugInput.addEventListener('blur', function(){
        var slug = slugifyPage(slugInput.value);
        slugInput.value = slug.length > slugLimit ? slug.slice(0, slugLimit) : slug;
      });
    }
    if (defaultTitleInput && slugInput) {
      var maybeSetSlug = function(){
        if (card.dataset.slugDirty !== '1' || slugInput.value.trim() === '') {
          var auto = slugifyPage(defaultTitleInput.value);
          slugInput.value = auto.length > slugLimit ? auto.slice(0, slugLimit) : auto;
          if (slugInput.value !== '') {
            card.dataset.slugDirty = '1';
          }
        }
      };
      defaultTitleInput.addEventListener('input', maybeSetSlug);
      if (slugInput.value.trim() === '' && defaultTitleInput.value.trim() !== '') {
        maybeSetSlug();
      }
    }

    var removeBtn = card.querySelector('[data-remove-page]');
    if (removeBtn && !removeBtn.__landingRemoveBound) {
      removeBtn.__landingRemoveBound = true;
      removeBtn.addEventListener('click', function(){
        var pageIdInput = card.querySelector('input[name^="page_id"]');
        var pageId = pageIdInput ? parseInt(pageIdInput.value, 10) || 0 : 0;
        if (pageId > 0 && deletedHost) {
          var exists = deletedHost.querySelector('input[name="page_removed[]"][value="' + pageId + '"]');
          if (!exists) {
            var hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.name = 'page_removed[]';
            hidden.value = String(pageId);
            deletedHost.appendChild(hidden);
          }
        }
        if (window.tinymce) {
          card.querySelectorAll('.js-page-editor').forEach(function(area){
            if (area.id) {
              var inst = window.tinymce.get(area.id);
              if (inst) { inst.remove(); }
            }
          });
        }
        card.remove();
      });
    }
  }

  list.querySelectorAll('[data-sortable-item]').forEach(function(card){ bindCard(card); });

  if (addBtn) {
    addBtn.addEventListener('click', function(){
      var key = 'new_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      var html = template.innerHTML.replace(/__KEY__/g, key);
      var wrapper = document.createElement('div');
      wrapper.innerHTML = html;
      var card = wrapper.firstElementChild;
      if (!card) { return; }
      list.appendChild(card);
      bindCard(card);
    });
  }

  form.addEventListener('submit', function(ev){
    ev.preventDefault();
    if (window.tinymce && typeof window.tinymce.triggerSave === 'function') {
      window.tinymce.triggerSave();
    }
    list.querySelectorAll('[data-page-slug]').forEach(function(input){
      var slug = slugifyPage(input.value);
      input.value = slug.length > slugLimit ? slug.slice(0, slugLimit) : slug;
    });

    var defaultMissing = null;
    list.querySelectorAll('[data-sortable-item]').forEach(function(card){
      if (defaultMissing) { return; }
      var defaultInput = card.querySelector('[data-page-title="default"]');
      var slugField = card.querySelector('[data-page-slug]');
      var pageIdInput = card.querySelector('input[name^="page_id"]');
      var hasContent = false;
      card.querySelectorAll('input[name^="page_title"], textarea[name^="page_content"]').forEach(function(field){
        if (hasContent) { return; }
        if (field.value && field.value.trim() !== '') { hasContent = true; }
      });
      var existingId = pageIdInput ? parseInt(pageIdInput.value, 10) || 0 : 0;
      var slugVal = slugField ? slugField.value.trim() : '';
      if (defaultInput && defaultInput.value.trim() === '' && (hasContent || existingId > 0 || slugVal !== '')) {
        defaultMissing = defaultInput;
      }
    });
    if (defaultMissing) {
      adminToast(defaultTitleMsg, 'error');
      try { defaultMissing.focus(); } catch(_){}
      return;
    }

    var url = adminRootUrl() + 'admin/request/landing_sections.php';
    var fd = new FormData(form);
    var csrfEl = document.querySelector('meta[name="admin-csrf"]');
    if (csrfEl) {
      fd.set('csrf_token', csrfEl.getAttribute('content') || '');
    }
    try { fd.delete('page_order[]'); } catch(_){}
    list.querySelectorAll('[data-sortable-item]').forEach(function(card){
      var key = card.getAttribute('data-row-key') || '';
      if (key) { fd.append('page_order[]', key); }
    });

    var submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.setAttribute('aria-busy', 'true');
    }

    fetch(url, { method: 'POST', body: fd })
      .then(function(r){ return r.json().catch(function(){ return {}; }); })
      .then(function(res){
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.removeAttribute('aria-busy');
        }
        if (res && res.status === 'success') {
          adminToast(adminLang('admin_saved', 'Saved'), 'success');
          try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {}
        } else {
          var msg = adminMsg(res && res.message);
          if (!msg) { msg = adminLang('admin_save_failed_generic', 'Save failed.'); }
          adminToast(adminLang('admin_save_failed_with_reason', 'Save failed: {reason}', { reason: msg }), 'error');
        }
      })
      .catch(function(){
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.removeAttribute('aria-busy');
        }
        adminToast(adminLang('admin_network_error_short', 'Network error'), 'error');
      });
  });
}

document.addEventListener('DOMContentLoaded', function () {
  var btn = document.getElementById('btnModerate');
  if (btn) btn.addEventListener('click', handleModerateClick);

  initLangTabs(document);
  initCmsEditors(document);

  var form = document.querySelector('[data-action="save-payments"]');
  if (form) form.addEventListener('submit', handlePaymentsSubmit);

  var siteForm = document.querySelector('form[data-action="save-site"]');
  if (siteForm) {
    siteForm.addEventListener('submit', handleSiteSubmit);
    siteForm.querySelectorAll('input[type="file"]').forEach(function(input){
      input.addEventListener('change', function(){
        var key = input.getAttribute('data-status-target') || '';
        var statusEl = key ? siteForm.querySelector('.file-picker-status[data-status-for="' + key + '"]') : null;
        if (!statusEl) { return; }
        if (input.files && input.files.length) {
          var fileName = input.files[0].name;
          var prefix = '';
          if (window.DZ && typeof DZ.i18n === 'function') {
            prefix = DZ.i18n('admin_file_selected') || '';
          }
          if (!prefix) { prefix = 'Selected: '; }
          if (prefix.indexOf('%s') !== -1) {
            statusEl.textContent = prefix.replace('%s', fileName);
          } else {
            statusEl.textContent = prefix + fileName;
          }
          statusEl.style.display = 'block';
        } else {
          statusEl.textContent = '';
          statusEl.style.display = 'none';
        }
      });
    });
  }

  document.querySelectorAll('form[data-action="save-contact-settings"], form[data-action="save-smtp-settings"]').forEach(function(form){
    form.addEventListener('submit', handleSiteSubmit);
  });

  document.querySelectorAll('form[data-action="save-onesignal-settings"]').forEach(function(form){
    form.addEventListener('submit', handleSiteSubmit);
  });
  document.querySelectorAll('form[data-action="save-sms-settings"]').forEach(function(form){
    form.addEventListener('submit', handleSiteSubmit);
  });

  document.querySelectorAll('form[data-action="storage-settings"]').forEach(function(form){
    form.addEventListener('submit', handleSiteSubmit);
  });

  document.querySelectorAll('[data-action="ffmpeg-test"]').forEach(function(button){
    button.addEventListener('click', handleFfmpegTest);
  });

  document.querySelectorAll('[data-action="storage-test"]').forEach(function(button){
    button.addEventListener('click', handleStorageTest);
  });

  document.querySelectorAll('[data-role="onesignal-rest-input"]').forEach(function(input){
    input.addEventListener('input', function(){
      var form = input.closest('form');
      if (!form) { return; }
      var clearField = form.querySelector('input[name="onesignal_rest_api_key_clear"]');
      if (!clearField) { return; }
      if (input.value && input.value.trim() !== '') {
        clearField.value = '0';
      }
    });
  });

  document.querySelectorAll('[data-action="onesignal-clear-rest-key"]').forEach(function(btn){
    btn.addEventListener('click', function(ev){
      ev.preventDefault();
      var form = btn.closest('form');
      if (!form) { return; }
      var clearField = form.querySelector('input[name="onesignal_rest_api_key_clear"]');
      if (clearField) {
        clearField.value = '1';
      }
      var input = form.querySelector('input[name="onesignal_rest_api_key"]');
      if (input) {
        input.value = '';
        input.setAttribute('data-cleared', '1');
        try { input.focus(); } catch (_) {}
      }
      adminToast(adminLang('admin_onesignal_rest_key_cleared', 'REST API key will be cleared on save.'), 'info');
    });
  });

  document.querySelectorAll('[data-action="sms-clear-token"]').forEach(function(btn){
    btn.addEventListener('click', function(ev){
      ev.preventDefault();
      var form = btn.closest('form');
      if (!form) { return; }
      var clearField = form.querySelector('input[name="sms_twilio_token_clear"]');
      if (clearField) {
        clearField.value = '1';
      }
      var input = form.querySelector('input[name="sms_twilio_token"]');
      if (input) {
        input.value = '';
        try { input.focus(); } catch(_) {}
      }
      adminToast(adminLang('admin_sms_token_cleared', 'Twilio Auth Token will be cleared on save.'), 'info');
    });
  });

  function initPodcastCategoriesAdmin() {
    var modal = document.getElementById('podcastCategoryModal');
    var form = document.getElementById('podcastCategoryForm');
    var addBtn = document.getElementById('addPodcastCategory');
    if (!modal || !form) {
      return;
    }

    var titleEl = document.getElementById('podcastCategoryModalTitle');
    var submitBtn = document.getElementById('podcastCategorySubmit');
    var saveOrderBtn = document.getElementById('savePodcastCategoryOrder');
    var orderList = document.querySelector('[data-sortable-list="podcast-categories"]');
    var langList = [];
    try {
      var langAttr = form.getAttribute('data-languages') || '[]';
      var parsed = JSON.parse(langAttr);
      if (Array.isArray(parsed)) {
        langList = parsed.map(function(item){ return String(item || '').toLowerCase(); }).filter(function(v){ return v !== ''; });
      }
    } catch (_) {}
    var defaultLang = (form.getAttribute('data-default-lang') || '').toLowerCase() || (langList[0] || '');
    if (defaultLang === '' && langList.length) {
      defaultLang = String(langList[0] || '').toLowerCase();
    }
    var nameInputs = Array.prototype.slice.call(form.querySelectorAll('[data-lang-field]'));
    function getNameInput(code) {
      var lc = (code || '').toLowerCase();
      for (var i = 0; i < nameInputs.length; i += 1) {
        var inp = nameInputs[i];
        if (!inp) { continue; }
        var lang = (inp.getAttribute('data-lang-field') || '').toLowerCase();
        if (lang === lc) { return inp; }
      }
      return null;
    }
    var defaultNameInput = getNameInput(defaultLang) || (nameInputs.length ? nameInputs[0] : null);
    var slugInput = document.getElementById('podcastCategorySlug');
    var statusSelect = document.getElementById('podcastCategoryStatus');
    var sortInput = document.getElementById('podcastCategorySort');
    var actionInput = form.querySelector('input[name="action"]');
    var idInput = form.querySelector('input[name="category_id"]');
    var labels = {
      addTitle: modal.getAttribute('data-add-title') || '',
      editTitle: modal.getAttribute('data-edit-title') || '',
      saveLabel: modal.getAttribute('data-save-label') || '',
      updateLabel: modal.getAttribute('data-update-label') || ''
    };
    var maxSlugLength = 160;
    var slugDirty = false;

    function setSlugDirtyFlag() {
      slugDirty = slugInput ? (slugInput.value || '').trim() !== '' : false;
    }

    function sanitizeSlugInput() {
      if (!slugInput) { return; }
      var slug = slugifyPage(slugInput.value || '');
      if (slug.length > maxSlugLength) {
        slug = slug.slice(0, maxSlugLength);
      }
      slugInput.value = slug;
      setSlugDirtyFlag();
    }

    function maybeAutoSlug() {
      if (!defaultNameInput || !slugInput || slugDirty) { return; }
      var slug = slugifyPage(defaultNameInput.value || '');
      if (slug.length > maxSlugLength) {
        slug = slug.slice(0, maxSlugLength);
      }
      slugInput.value = slug;
    }

    if (defaultNameInput) {
      defaultNameInput.addEventListener('input', maybeAutoSlug);
    }
    if (slugInput) {
      slugInput.addEventListener('input', sanitizeSlugInput);
      slugInput.addEventListener('blur', sanitizeSlugInput);
    }

    function setNameValues(values) {
      nameInputs.forEach(function(input){
        if (!input) { return; }
        var code = (input.getAttribute('data-lang-field') || '').toLowerCase();
        var val = values && typeof values === 'object' && values.hasOwnProperty(code) ? values[code] : '';
        input.value = val || '';
      });
    }

    function closeModal() {
      modal.classList.remove('is-open');
      modal.setAttribute('hidden', '');
      modal.setAttribute('aria-hidden', 'true');
    }

    function openModal(mode, payload) {
      var isEdit = mode === 'edit';
      modal.classList.add('is-open');
      modal.removeAttribute('hidden');
      modal.setAttribute('aria-hidden', 'false');

      if (titleEl) {
        titleEl.textContent = isEdit ? (labels.editTitle || labels.addTitle) : labels.addTitle;
      }
      if (submitBtn) {
        submitBtn.textContent = isEdit ? (labels.updateLabel || labels.saveLabel) : (labels.saveLabel || submitBtn.textContent);
      }
      if (actionInput) {
        actionInput.value = isEdit ? 'update' : 'create';
      }
      if (idInput) {
        idInput.value = isEdit ? String(payload && payload.id ? payload.id : '') : '';
      }
      var nameValues = (payload && payload.names && typeof payload.names === 'object') ? payload.names : {};
      if ((!nameValues || Object.keys(nameValues).length === 0) && payload && payload.name) {
        nameValues = {};
        if (defaultLang) {
          nameValues[defaultLang] = payload.name;
        }
      }
      setNameValues(nameValues);
      if (slugInput) {
        slugInput.value = (payload && payload.slug) ? payload.slug : '';
        setSlugDirtyFlag();
      }
      if (statusSelect) {
        statusSelect.value = (payload && payload.status) ? payload.status : 'active';
      }
      if (sortInput) {
        var sortVal = payload && typeof payload.sort !== 'undefined' ? payload.sort : 0;
        sortInput.value = sortVal;
      }

      try {
        if (nameInput) { nameInput.focus(); nameInput.select(); }
      } catch (_) {}
    }

    modal.querySelectorAll('[data-modal-close]').forEach(function(btn){
      btn.addEventListener('click', function(ev){
        ev.preventDefault();
        closeModal();
      });
    });

    modal.addEventListener('click', function(ev){
      if (ev.target === modal) {
        closeModal();
      }
    });

    if (addBtn) {
      addBtn.addEventListener('click', function(ev){
        ev.preventDefault();
        slugDirty = false;
        openModal('add', {});
      });
    }

    function handleEditClick(ev) {
      var btn = ev.target.closest('.js-edit-category');
      if (!btn) { return; }
      ev.preventDefault();
      var payload = {
        id: parseInt(btn.getAttribute('data-id') || '0', 10) || 0,
        name: btn.getAttribute('data-name') || '',
        slug: btn.getAttribute('data-slug') || '',
        status: btn.getAttribute('data-status') || 'inactive',
        sort: parseInt(btn.getAttribute('data-sort') || '0', 10) || 0
      };
      var namesAttr = btn.getAttribute('data-names') || '';
      if (namesAttr) {
        try {
          var parsedNames = JSON.parse(namesAttr);
          if (parsedNames && typeof parsedNames === 'object') {
            payload.names = parsedNames;
          }
        } catch (_) {}
      }
      slugDirty = true;
      openModal('edit', payload);
    }
    document.addEventListener('click', function(ev){
      var btn = ev.target.closest('.js-edit-category');
      if (!btn) { return; }
      handleEditClick(ev);
      closeAnyCatMenu(ev);
    }, true);

    function handleResponse(res, defaultSuccess, reloadOnSuccess) {
      var ok = res && res.status === 'success';
      var code = res && res.message;
      var msg = adminMsg(code);
      if (!msg && code) {
        msg = adminLang(code, code);
      }
      if (!msg) {
        msg = ok ? (defaultSuccess || adminLang('admin_saved', 'Saved')) : adminLang('admin_save_failed_generic', 'Save failed.');
      }
      adminToast(msg, ok ? 'success' : 'error');
      if (ok && reloadOnSuccess !== false) {
        try { setTimeout(function(){ window.location.reload(); }, 550); } catch (_) {}
      }
    }

    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      ev.stopPropagation();
      sanitizeSlugInput();
      var fd = new FormData(form);
      var csrf = adminCsrfToken();
      if (csrf) {
        fd.set('csrf_token', csrf);
      }
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.setAttribute('aria-busy', 'true');
      }
      fetch(form.getAttribute('action') || (adminRootUrl() + 'admin/request/podcast_categories.php'), {
        method: 'POST',
        body: fd,
        credentials: 'same-origin'
      }).then(function(r){
        return r.json().catch(function(){ return {}; });
      }).then(function(res){
        handleResponse(res, labels.updateLabel || labels.saveLabel, true);
      }).catch(function(){
        adminToast(adminLang('admin_network_error_short', 'Network error'), 'error');
      }).finally(function(){
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.removeAttribute('aria-busy');
        }
      });
    });

    function bindActionForm(actionForm) {
      if (!actionForm || actionForm.__boundCategoryAction) { return; }
      actionForm.__boundCategoryAction = true;
      actionForm.addEventListener('submit', function(ev){
        ev.preventDefault();
        ev.stopPropagation();
        var submitBtn = actionForm.querySelector('button[type="submit"]');
        var proceed = function(){
          var fd = new FormData(actionForm);
          var csrf = adminCsrfToken();
          if (csrf) {
            fd.set('csrf_token', csrf);
          }
          if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.setAttribute('aria-busy', 'true');
          }
          fetch(actionForm.getAttribute('action') || (adminRootUrl() + 'admin/request/podcast_categories.php'), {
            method: 'POST',
            body: fd,
            credentials: 'same-origin'
          }).then(function(r){
            return r.json().catch(function(){ return {}; });
          }).then(function(res){
            handleResponse(res, labels.saveLabel, true);
            closeAnyCatMenu(ev);
          }).catch(function(){
            adminToast(adminLang('admin_network_error_short', 'Network error'), 'error');
          }).finally(function(){
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.removeAttribute('aria-busy');
            }
          });
        };

        var confirmMsg = actionForm.getAttribute('data-confirm');
        if (confirmMsg) {
          if (typeof adminConfirm === 'function') {
            adminConfirm(confirmMsg).then(function(ok){ if (ok) { proceed(); } });
          } else if (window.confirm(confirmMsg)) {
            proceed();
          }
          return;
        }
        proceed();
      });
    }

    document.querySelectorAll('.js-category-action').forEach(bindActionForm);

    document.addEventListener('click', function(ev){
      var btn = ev.target.closest('.js-cat-action');
      if (!btn) { return; }
      ev.preventDefault();
      ev.stopPropagation();
      var action = (btn.getAttribute('data-action') || '').toLowerCase();
      var cid = parseInt(btn.getAttribute('data-category-id') || '0', 10) || 0;
      var status = (btn.getAttribute('data-status') || '').toLowerCase();
      var url = btn.getAttribute('data-url') || (form.getAttribute('action') || (adminRootUrl() + 'admin/request/podcast_categories.php'));
      var confirmMsg = btn.getAttribute('data-confirm') || '';
      if (!cid || !action) { return; }
      var run = function(){
        var fd = new FormData();
        fd.set('csrf_token', adminCsrfToken());
        fd.set('action', action);
        fd.set('category_id', String(cid));
        if (action === 'status') {
          fd.set('status', status || 'inactive');
        }
        btn.disabled = true;
        btn.setAttribute('aria-busy', 'true');
        fetch(url, { method: 'POST', body: fd, credentials: 'same-origin' })
          .then(function(r){ return r.json().catch(function(){ return {}; }); })
          .then(function(res){
            handleResponse(res, labels.saveLabel, true);
            closeAnyCatMenu(ev);
          })
          .catch(function(){
            adminToast(adminLang('admin_network_error_short', 'Network error'), 'error');
          })
          .finally(function(){
            btn.disabled = false;
            btn.removeAttribute('aria-busy');
          });
      };
      if (confirmMsg) {
        if (typeof adminConfirm === 'function') {
          adminConfirm(confirmMsg).then(function(ok){ if (ok) { run(); } });
        } else if (window.confirm(confirmMsg)) {
          run();
        }
        return;
      }
      run();
    }, true);

    function closeAnyCatMenu(ev){
      var popup = ev && ev.target ? ev.target.closest('.post-menu-popup') : null;
      if (!popup) { return; }
      popup.classList.add('none');
      popup.setAttribute('aria-hidden', 'true');
      var btnId = popup.id ? popup.id.replace('catMenuPopup-', '') : '';
      if (btnId) {
        var toggle = document.querySelector('.js-cat-actions[data-id="' + btnId + '"]');
        if (toggle) {
          toggle.setAttribute('aria-expanded', 'false');
        }
      }
    }

    document.addEventListener('click', function(ev){
      var toggle = ev.target.closest('.js-cat-actions');
      if (!toggle) { return; }
      ev.preventDefault();
      ev.stopPropagation();
      var id = toggle.getAttribute('data-id') || '';
      if (!id) { return; }
      var popup = document.getElementById('catMenuPopup-' + id);
      if (!popup) { return; }
      var isOpen = popup.classList.contains('none') === false;
      document.querySelectorAll('.post-menu-popup').forEach(function(p){ p.classList.add('none'); p.setAttribute('aria-hidden','true'); });
      document.querySelectorAll('.js-cat-actions').forEach(function(btn){ btn.setAttribute('aria-expanded','false'); });
      if (!isOpen) {
        popup.classList.remove('none');
        popup.setAttribute('aria-hidden','false');
        toggle.setAttribute('aria-expanded','true');
      }
    }, true);

    document.addEventListener('click', function(ev){
      var cancel = ev.target.closest('.pm-cancel');
      if (cancel) {
        closeAnyCatMenu(ev);
      }
      var outsidePopup = ev.target && ev.target.closest ? ev.target.closest('.post-menu-popup') : null;
      var toggle = ev.target && ev.target.closest ? ev.target.closest('.js-cat-actions') : null;
      if (!outsidePopup && !toggle) {
        document.querySelectorAll('.post-menu-popup').forEach(function(p){ p.classList.add('none'); p.setAttribute('aria-hidden','true'); });
        document.querySelectorAll('.js-cat-actions').forEach(function(btn){ btn.setAttribute('aria-expanded','false'); });
      }
    });

    if (orderList) {
      orderList.querySelectorAll('[data-sortable-item]').forEach(function(row){
        row.setAttribute('draggable', 'true');
      });
      if (typeof makeSortableList === 'function') {
        makeSortableList(orderList);
      }
    }

    function saveOrder() {
      if (!orderList) { return; }
      var rows = orderList.querySelectorAll('[data-sortable-item]');
      if (!rows.length) { return; }
      var ids = [];
      rows.forEach(function(row){
        var key = row.getAttribute('data-row-key') || '';
        if (key) { ids.push(key); }
      });
      if (!ids.length) { return; }
      var btn = saveOrderBtn;
      if (btn) {
        btn.disabled = true;
        btn.setAttribute('aria-busy', 'true');
      }
      var fd = new FormData();
      var csrf = adminCsrfToken();
      fd.set('csrf_token', csrf);
      fd.set('action', 'sort');
      ids.forEach(function(id){ fd.append('order[]', id); });
      var targetUrl = form.getAttribute('action') || (adminRootUrl() + 'admin/request/podcast_categories.php');
      fetch(targetUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
          var msg = adminMsg(res && res.message);
          if (!msg && res && res.status === 'success') {
            msg = adminLang('admin_saved', 'Saved');
          }
          adminToast(msg || adminLang('admin_saved', 'Saved'), (res && res.status === 'success') ? 'success' : 'error');
          if (res && res.status === 'success') {
            // Update order cells without reload
            var orderVal = 10;
            rows.forEach(function(row){
              var cells = row.querySelectorAll('td');
              if (cells.length >= 6) {
                cells[5].textContent = String(orderVal);
              }
              orderVal += 10;
            });
          }
        })
        .catch(function(){
          adminToast(adminLang('admin_network_error_short', 'Network error'), 'error');
        })
        .finally(function(){
          if (btn) {
            btn.disabled = false;
            btn.removeAttribute('aria-busy');
          }
        });
    }

    if (saveOrderBtn) {
      saveOrderBtn.addEventListener('click', function(ev){
        ev.preventDefault();
        saveOrder();
      });
    }
  }

  initPodcastCategoriesAdmin();

  document.querySelectorAll('form[data-action="save-announcement"], form[data-action="announcement-status"], form[data-action="announcement-delete"]').forEach(function(form){
    form.addEventListener('submit', handleAnnouncementSubmit);
  });

  initContactMessages();

  document.querySelectorAll('form[data-action="save-landing-theme"]').forEach(function(form){
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var url = adminRootUrl() + 'admin/request/landing_settings.php';
      var fd  = new FormData(form);
      var csrfEl = document.querySelector('meta[name="admin-csrf"]');
      var csrf   = csrfEl ? (csrfEl.getAttribute('content') || '') : '';
      if (csrf) {
        fd.set('csrf_token', csrf);
      }
      fetch(url, { method: 'POST', body: fd })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
          if (res && res.status === 'success') {
            adminToast(adminLang('admin_saved', 'Saved'), 'success');
            try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {}
          } else {
            var fail = adminMsg(res && res.message);
            if (!fail) { fail = adminLang('admin_save_failed_generic', 'Save failed.'); }
            adminToast(adminLang('admin_save_failed_with_reason', 'Save failed: {reason}', { reason: fail }), 'error');
          }
        })
        .catch(function(){ adminToast(adminLang('admin_network_error_short', 'Network error'), 'error'); });
    });
  });

  document.querySelectorAll('form[data-action="save-landing-hero"]').forEach(function(form){
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var url = adminRootUrl() + 'admin/request/landing_settings.php';
      var fd  = new FormData(form);
      var csrfEl = document.querySelector('meta[name="admin-csrf"]');
      var csrf   = csrfEl ? (csrfEl.getAttribute('content') || '') : '';
      if (csrf) {
        fd.set('csrf_token', csrf);
      }
      fetch(url, { method: 'POST', body: fd })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
        if (res && res.status === 'success') {
          adminToast(adminLang('admin_saved', 'Saved'), 'success');
          try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {}
        } else {
          var fail = adminMsg(res && res.message);
          if (!fail) { fail = adminLang('admin_save_failed_generic', 'Save failed.'); }
          adminToast(adminLang('admin_save_failed_with_reason', 'Save failed: {reason}', { reason: fail }), 'error');
        }
      })
      .catch(function(){ adminToast(adminLang('admin_network_error_short', 'Network error'), 'error'); });
    });
  });

  document.querySelectorAll('form[data-action="save-landing-image-list"]').forEach(function(form){
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var url = adminRootUrl() + 'admin/request/landing_sections.php';
      var fd  = new FormData(form);
      var csrfEl = document.querySelector('meta[name="admin-csrf"]');
      var csrf   = csrfEl ? (csrfEl.getAttribute('content') || '') : '';
      if (csrf) {
        fd.set('csrf_token', csrf);
      }
      fetch(url, { method: 'POST', body: fd })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
        if (res && res.status === 'success') {
          adminToast(adminLang('admin_saved', 'Saved'), 'success');
          try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {}
        } else {
          var fail = adminMsg(res && res.message);
          if (!fail) { fail = adminLang('admin_save_failed_generic', 'Save failed.'); }
          adminToast(adminLang('admin_save_failed_with_reason', 'Save failed: {reason}', { reason: fail }), 'error');
        }
      })
      .catch(function(){ adminToast(adminLang('admin_network_error_short', 'Network error'), 'error'); });
    });
  });

  document.querySelectorAll('form[data-action="save-landing-pages"]').forEach(function(pagesForm){
    initLandingPagesForm(pagesForm);
  });

  document.querySelectorAll('form[data-action="save-landing-features"]').forEach(function(form){
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var url = adminRootUrl() + 'admin/request/landing_settings.php';
      var fd  = new FormData(form);
      var csrfEl = document.querySelector('meta[name="admin-csrf"]');
      var csrf   = csrfEl ? (csrfEl.getAttribute('content') || '') : '';
      if (csrf) {
        fd.set('csrf_token', csrf);
      }
      try { fd.delete('feature_order[]'); } catch(_){}
      var list = form.querySelector('[data-sortable-list="features"]');
      if (list) {
        list.querySelectorAll('[data-sortable-item]').forEach(function(card){
          var key = card.getAttribute('data-row-key') || '';
          if (key) {
            fd.append('feature_order[]', key);
          }
        });
      }
      fetch(url, { method: 'POST', body: fd })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
        if (res && res.status === 'success') {
          adminToast(adminLang('admin_saved', 'Saved'), 'success');
          try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {}
        } else {
          var fail = adminMsg(res && res.message);
          if (!fail) { fail = adminLang('admin_save_failed_generic', 'Save failed.'); }
          adminToast(adminLang('admin_save_failed_with_reason', 'Save failed: {reason}', { reason: fail }), 'error');
        }
      })
      .catch(function(){ adminToast(adminLang('admin_network_error_short', 'Network error'), 'error'); });
    });
  });

  document.querySelectorAll('form[data-action="save-landing-no-hassle"]').forEach(function(form){
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var url = adminRootUrl() + 'admin/request/landing_settings.php';
      var fd  = new FormData(form);
      var csrfEl = document.querySelector('meta[name="admin-csrf"]');
      var csrf   = csrfEl ? (csrfEl.getAttribute('content') || '') : '';
      if (csrf) {
        fd.set('csrf_token', csrf);
      }
      try { fd.delete('no_hassle_order[]'); } catch(_){}
      var list = form.querySelector('[data-sortable-list="no-hassle"]');
      if (list) {
        list.querySelectorAll('[data-sortable-item]').forEach(function(card){
          var key = card.getAttribute('data-row-key') || '';
          if (key) {
            fd.append('no_hassle_order[]', key);
          }
        });
      }
      fetch(url, { method: 'POST', body: fd })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
        if (res && res.status === 'success') {
          adminToast(adminLang('admin_saved', 'Saved'), 'success');
          try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {}
        } else {
          var fail = adminMsg(res && res.message);
          if (!fail) { fail = adminLang('admin_save_failed_generic', 'Save failed.'); }
          adminToast(adminLang('admin_save_failed_with_reason', 'Save failed: {reason}', { reason: fail }), 'error');
        }
      })
      .catch(function(){ adminToast(adminLang('admin_network_error_short', 'Network error'), 'error'); });
    });
  });

  document.querySelectorAll('form[data-action="save-landing-samples"]').forEach(function(form){
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var url = adminRootUrl() + 'admin/request/landing_settings.php';
      var fd  = new FormData(form);
      var csrfEl = document.querySelector('meta[name="admin-csrf"]');
      var csrf   = csrfEl ? (csrfEl.getAttribute('content') || '') : '';
      if (csrf) {
        fd.set('csrf_token', csrf);
      }
      try { fd.delete('sample_order[]'); } catch(_){}
      var list = form.querySelector('[data-sortable-list="samples"]');
      if (list) {
        list.querySelectorAll('[data-sortable-item]').forEach(function(card){
          var key = card.getAttribute('data-row-key') || '';
          if (key) {
            fd.append('sample_order[]', key);
          }
        });
      }
      fetch(url, { method: 'POST', body: fd })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
        if (res && res.status === 'success') {
          adminToast(adminLang('admin_saved', 'Saved'), 'success');
          try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {}
        } else {
          var fail = adminMsg(res && res.message);
          if (!fail) { fail = adminLang('admin_save_failed_generic', 'Save failed.'); }
          adminToast(adminLang('admin_save_failed_with_reason', 'Save failed: {reason}', { reason: fail }), 'error');
        }
      })
      .catch(function(){ adminToast(adminLang('admin_network_error_short', 'Network error'), 'error'); });
    });
  });

  document.querySelectorAll('form[data-action="save-landing-pricing"]').forEach(function(form){
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var url = adminRootUrl() + 'admin/request/landing_settings.php';
      var fd  = new FormData(form);
      var csrfEl = document.querySelector('meta[name="admin-csrf"]');
      var csrf   = csrfEl ? (csrfEl.getAttribute('content') || '') : '';
      if (csrf) {
        fd.set('csrf_token', csrf);
      }
      try { fd.delete('plan_order[]'); } catch(_){}
      var list = form.querySelector('[data-sortable-list="pricing"]');
      if (list) {
        list.querySelectorAll('[data-sortable-item]').forEach(function(card){
          var key = card.getAttribute('data-row-key') || '';
          if (key) {
            fd.append('plan_order[]', key);
          }
        });
      }
      fetch(url, { method: 'POST', body: fd })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
        if (res && res.status === 'success') {
          adminToast(adminLang('admin_saved', 'Saved'), 'success');
          try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {}
        } else {
          var fail = adminMsg(res && res.message);
          if (!fail) { fail = adminLang('admin_save_failed_generic', 'Save failed.'); }
          adminToast(adminLang('admin_save_failed_with_reason', 'Save failed: {reason}', { reason: fail }), 'error');
        }
      })
      .catch(function(){ adminToast(adminLang('admin_network_error_short', 'Network error'), 'error'); });
    });
  });

  document.querySelectorAll('form[data-action="save-landing-faqs"]').forEach(function(form){
    var searchInput = form.querySelector('[data-faq-search]');
    if (searchInput) {
      searchInput.addEventListener('input', function(){ applyFaqFilter(form); });
    }
    updateFaqEmptyState(form);
    applyFaqFilter(form);
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var url = adminRootUrl() + 'admin/request/landing_sections.php';
      var fd  = new FormData(form);
      var csrfEl = document.querySelector('meta[name="admin-csrf"]');
      var csrf   = csrfEl ? (csrfEl.getAttribute('content') || '') : '';
      if (csrf) {
        fd.set('csrf_token', csrf);
      }
      try { fd.delete('faq_order[]'); } catch(_){}
      var list = form.querySelector('[data-sortable-list="faqs"]');
      if (list) {
        list.querySelectorAll('[data-sortable-item]').forEach(function(card){
          var key = card.getAttribute('data-row-key') || '';
          if (key) {
            fd.append('faq_order[]', key);
          }
        });
      }
      fetch(url, { method: 'POST', body: fd })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
        if (res && res.status === 'success') {
          adminToast(adminLang('admin_saved', 'Saved'), 'success');
          try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {}
        } else {
          var fail = adminMsg(res && res.message);
          if (!fail) { fail = adminLang('admin_save_failed_generic', 'Save failed.'); }
          adminToast(adminLang('admin_save_failed_with_reason', 'Save failed: {reason}', { reason: fail }), 'error');
        }
      })
      .catch(function(){ adminToast(adminLang('admin_network_error_short', 'Network error'), 'error'); });
    });
  });

  document.querySelectorAll('form[data-action="smtp-test"]').forEach(function(form){
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var submitBtn = form.querySelector('[data-action="smtp-test-send"]');
      var statusEl = form.querySelector('[data-smtp-test-status]');
      if (statusEl) {
        statusEl.textContent = '';
        statusEl.setAttribute('hidden', '');
      }
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.setAttribute('aria-busy', 'true');
      }

      var fd = new FormData(form);
      var csrfEl = document.querySelector('meta[name="admin-csrf"]');
      var csrf = csrfEl ? (csrfEl.getAttribute('content') || '') : '';
      if (csrf) {
        fd.set('csrf_token', csrf);
      }

      fetch(form.getAttribute('action') || adminRootUrl() + 'admin/request/contact_email.php', {
        method: 'POST',
        body: fd
      })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
          var success = res && (res.status === 'success' || res.ok === true) && res.ok !== false;
          if (success) {
            adminToast(adminLang('admin_test_email_sent', 'Test email sent.'), 'success');
            if (statusEl) {
              statusEl.textContent = adminLang('admin_test_email_success_detail', 'Test email sent successfully.');
              statusEl.removeAttribute('hidden');
            }
          } else {
            var code = (res && (res.error || res.message)) || 'smtp_send_failed';
            var msg = adminMsg(code);
            if (res && res.details) {
              msg += ' (' + res.details + ')';
            }
            adminToast(msg, 'error');
            if (statusEl) {
              statusEl.textContent = msg;
              statusEl.removeAttribute('hidden');
            }
          }
        })
        .catch(function(){
          adminToast(adminLang('admin_network_error', 'Network error.'), 'error');
          if (statusEl) {
            statusEl.textContent = adminLang('admin_network_error_retry', 'Network error. Please try again.');
            statusEl.removeAttribute('hidden');
          }
        })
        .finally(function(){
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.removeAttribute('aria-busy');
          }
        });
    });
  });

  document.querySelectorAll('form[data-action="save-landing-get-started"]').forEach(function(form){
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var url = adminRootUrl() + 'admin/request/landing_sections.php';
      var fd  = new FormData(form);
      var csrfEl = document.querySelector('meta[name="admin-csrf"]');
      var csrf   = csrfEl ? (csrfEl.getAttribute('content') || '') : '';
      if (csrf) {
        fd.set('csrf_token', csrf);
      }
      fetch(url, { method: 'POST', body: fd })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
          if (res && res.status === 'success') {
            adminToast(adminLang('admin_saved', 'Saved'), 'success');
            try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {}
          } else {
            var fail = adminMsg(res && res.message);
            if (!fail) { fail = adminLang('admin_save_failed_generic', 'Save failed.'); }
            adminToast(adminLang('admin_save_failed_with_reason', 'Save failed: {reason}', { reason: fail }), 'error');
          }
        })
        .catch(function(){ adminToast(adminLang('admin_network_error_short', 'Network error'), 'error'); });
    });
  });

  document.querySelectorAll('[data-landing-tabs]').forEach(function(tabGroup){
    var root = tabGroup.parentElement || document;
    var buttons = Array.prototype.slice.call(tabGroup.querySelectorAll('[data-section-target]'));
    var panels = Array.prototype.slice.call(root.querySelectorAll('[data-section-panel]'));

    var toggleTab = function(target, sourceBtn){
      buttons.forEach(function(other){
        var isMatch = other === sourceBtn;
        other.classList.toggle('is-active', isMatch);
        other.setAttribute('aria-selected', isMatch ? 'true' : 'false');
      });
      panels.forEach(function(panel){
        var match = panel.getAttribute('data-section-panel') === target;
        panel.classList.toggle('is-active', match);
        if (match) {
          panel.removeAttribute('hidden');
          panel.setAttribute('aria-hidden', 'false');
        } else {
          panel.setAttribute('hidden', '');
          panel.setAttribute('aria-hidden', 'true');
        }
      });
    };

    var activateTab = function(target){
      if (!target) { return false; }
      var matchedButton = null;
      buttons.forEach(function(btn){
        if (!matchedButton && (btn.getAttribute('data-section-target') || '') === target) {
          matchedButton = btn;
        }
      });
      if (!matchedButton) { return false; }
      toggleTab(target, matchedButton);
      return true;
    };

    buttons.forEach(function(btn){
      btn.addEventListener('click', function(){
        var target = btn.getAttribute('data-section-target') || '';
        toggleTab(target, btn);
        if (target) {
          try { window.location.hash = target; } catch (_) {}
        }
      });
    });

    var initialiseTabs = function(){
      var hashTarget = (window.location.hash || '').replace('#', '');
      if (hashTarget && activateTab(hashTarget)) {
        return;
      }
      var defaultTarget = tabGroup.getAttribute('data-default-tab') || '';
      if (!defaultTarget) { return; }
      var activeButton = tabGroup.querySelector('.landing-section-tab.is-active');
      if (activeButton && (activeButton.getAttribute('data-section-target') || '') === defaultTarget) {
        return;
      }
      activateTab(defaultTarget);
    };

    initialiseTabs();

    tabGroup.__landingTabsActivate = activateTab;
  });

  window.addEventListener('hashchange', function(){
    var hashTarget = (window.location.hash || '').replace('#', '');
    if (!hashTarget) { return; }
    document.querySelectorAll('[data-landing-tabs]').forEach(function(tabGroup){
      var activator = tabGroup.__landingTabsActivate;
      if (typeof activator === 'function') {
        activator(hashTarget);
      }
    });
  });

  document.querySelectorAll('[data-open-tab]').forEach(function(trigger){
    trigger.addEventListener('click', function(){
      var target = trigger.getAttribute('data-open-tab') || '';
      if (!target) { return; }
      var groupName = trigger.getAttribute('data-tab-group') || '';
      var tabGroup = groupName ? document.querySelector('[data-landing-tabs][data-tab-group="' + groupName + '"]') : trigger.closest('[data-landing-tabs]');
      if (!tabGroup) { return; }
      var activator = tabGroup.__landingTabsActivate;
      if (typeof activator === 'function') {
        activator(target);
      } else {
        var button = tabGroup.querySelector('[data-section-target="' + target + '"]');
        if (button) { button.click(); }
      }
      try { window.location.hash = target; } catch (_) {}
    });
  });

  document.querySelectorAll('[data-action="add-marquee-item"]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var tpl = document.getElementById('marqueeItemTemplate');
      if (!tpl) { return; }
      var form = btn.closest('form');
      if (!form) { return; }
      var tbody = form.querySelector('[data-sortable-list="marquee"]');
      if (!tbody) { return; }
      var key = 'new_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      var html = tpl.innerHTML.replace(/__KEY__/g, key);
      var temp = document.createElement('tbody');
      temp.innerHTML = html;
      var row = temp.firstElementChild;
      if (row) { tbody.appendChild(row); }
    });
  });

  document.querySelectorAll('[data-action="add-feature-item"]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var tpl = document.getElementById('featureItemTemplate');
      if (!tpl) { return; }
      var form = btn.closest('form');
      if (!form) { return; }
      var list = form.querySelector('[data-sortable-list="features"]');
      if (!list) { return; }
      var key = 'new_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      var html = tpl.innerHTML.replace(/__KEY__/g, key);
      var temp = document.createElement('div');
      temp.innerHTML = html.trim();
      var card = temp.firstElementChild;
      if (card) {
        list.appendChild(card);
        var focusTarget = card.querySelector('input.form-input, textarea.form-input');
        if (focusTarget) {
          try { focusTarget.focus(); } catch(_) {}
        }
      }
    });
  });

  document.querySelectorAll('[data-action="add-no-hassle-item"]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var tpl = document.getElementById('noHassleItemTemplate');
      if (!tpl) { return; }
      var form = btn.closest('form');
      if (!form) { return; }
      var list = form.querySelector('[data-sortable-list="no-hassle"]');
      if (!list) { return; }
      var key = 'new_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      var html = tpl.innerHTML.replace(/__KEY__/g, key);
      var temp = document.createElement('div');
      temp.innerHTML = html.trim();
      var card = temp.firstElementChild;
      if (card) {
        list.appendChild(card);
        var focusTarget = card.querySelector('input.form-input');
        if (focusTarget) {
          try { focusTarget.focus(); } catch(_) {}
        }
      }
    });
  });

  document.querySelectorAll('[data-action="add-sample-item"]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var tpl = document.getElementById('sampleItemTemplate');
      if (!tpl) { return; }
      var form = btn.closest('form');
      if (!form) { return; }
      var list = form.querySelector('[data-sortable-list="samples"]');
      if (!list) { return; }
      var key = 'new_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      var html = tpl.innerHTML.replace(/__KEY__/g, key);
      var temp = document.createElement('div');
      temp.innerHTML = html.trim();
      var card = temp.firstElementChild;
      if (card) {
        list.appendChild(card);
        var focusTarget = card.querySelector('input.form-input');
        if (focusTarget) {
          try { focusTarget.focus(); } catch(_) {}
        }
      }
    });
  });

  document.querySelectorAll('[data-action="add-faq-item"]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var tpl = document.getElementById('faqItemTemplate');
      if (!tpl) { return; }
      var form = btn.closest('form');
      if (!form) { return; }
      var list = form.querySelector('[data-sortable-list="faqs"]');
      if (!list) { return; }
      var key = 'faq_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      var html = tpl.innerHTML.replace(/__KEY__/g, key);
      var temp = document.createElement('div');
      temp.innerHTML = html.trim();
      var card = temp.firstElementChild;
      if (card) {
        list.appendChild(card);
        updateFaqEmptyState(form);
        applyFaqFilter(form);
        var focusTarget = card.querySelector('input.form-input, textarea.form-input');
        if (focusTarget) {
          try { focusTarget.focus(); } catch(_) {}
        }
      }
    });
  });

  document.querySelectorAll('[data-action="add-pricing-plan"]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var tpl = document.getElementById('pricingPlanTemplate');
      if (!tpl) { return; }
      var form = btn.closest('form');
      if (!form) { return; }
      var list = form.querySelector('[data-sortable-list="pricing"]');
      if (!list) { return; }
      var key = 'new_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      var html = tpl.innerHTML.replace(/__KEY__/g, key);
      var temp = document.createElement('div');
      temp.innerHTML = html.trim();
      var card = temp.firstElementChild;
      if (card) {
        list.appendChild(card);
        var focusTarget = card.querySelector('input.form-input');
        if (focusTarget) {
          try { focusTarget.focus(); } catch(_) {}
        }
      }
    });
  });

  document.addEventListener('click', function(ev){
    var marqueeBtn = ev.target.closest('[data-remove-marquee]');
    if (marqueeBtn) {
      ev.preventDefault();
      var row = marqueeBtn.closest('.landing-marquee-row');
      if (row) { row.remove(); }
      return;
    }
    var faqBtn = ev.target.closest('[data-remove-faq]');
    if (faqBtn) {
      ev.preventDefault();
      var form = faqBtn.closest('form');
      var faqCard = faqBtn.closest('.landing-feature-card');
      if (faqCard) { faqCard.remove(); }
      if (form) {
        updateFaqEmptyState(form);
        applyFaqFilter(form);
      }
      return;
    }
    var featureBtn = ev.target.closest('[data-remove-feature]');
    if (featureBtn) {
      ev.preventDefault();
      var card = featureBtn.closest('.landing-feature-card');
      if (card) { card.remove(); }
      return;
    }
    var noHassleBtn = ev.target.closest('[data-remove-no-hassle]');
    if (noHassleBtn) {
      ev.preventDefault();
      var noHassleCard = noHassleBtn.closest('.landing-feature-card');
      if (noHassleCard) { noHassleCard.remove(); }
      return;
    }
    var sampleBtn = ev.target.closest('[data-remove-sample]');
    if (sampleBtn) {
      ev.preventDefault();
      var sampleCard = sampleBtn.closest('.landing-feature-card');
      if (sampleCard) { sampleCard.remove(); }
      return;
    }
    var pricingBtn = ev.target.closest('[data-remove-plan]');
    if (pricingBtn) {
      ev.preventDefault();
      var pricingCard = pricingBtn.closest('.landing-feature-card');
      if (pricingCard) { pricingCard.remove(); }
    }
  });

  function makeSortableList(list) {
    var active = null;

    list.addEventListener('dragstart', function(ev){
      var item = ev.target && ev.target.closest ? ev.target.closest('[data-sortable-item]') : null;
      if (!item) { return; }
      active = item;
      item.classList.add('is-dragging');
      if (ev.dataTransfer) {
        ev.dataTransfer.effectAllowed = 'move';
        try { ev.dataTransfer.setData('text/plain', item.getAttribute('data-row-key') || ''); } catch(_) {}
      }
    });

    list.addEventListener('dragover', function(ev){
      if (!active) { return; }
      ev.preventDefault();
      if (ev.dataTransfer) {
        ev.dataTransfer.dropEffect = 'move';
      }
      var target = ev.target && ev.target.closest ? ev.target.closest('[data-sortable-item]') : null;
      if (!target || target === active) { return; }
      var rect = target.getBoundingClientRect();
      var isAfter = ev.clientY > rect.top + rect.height / 2;
      var parent = target.parentNode;
      if (!parent) { return; }
      if (isAfter) {
        parent.insertBefore(active, target.nextSibling);
      } else {
        parent.insertBefore(active, target);
      }
    });

    list.addEventListener('drop', function(ev){
      if (active) {
        ev.preventDefault();
      }
    });

    list.addEventListener('dragend', function(){
      if (active) {
        active.classList.remove('is-dragging');
      }
      active = null;
    });
  }

  function updateFaqEmptyState(form) {
    if (!form) { return; }
    var list = form.querySelector('[data-sortable-list="faqs"]');
    var emptyMsg = form.querySelector('[data-faq-empty]');
    var total = list ? list.querySelectorAll('[data-faq-item]').length : 0;
    if (emptyMsg) {
      if (total === 0) {
        emptyMsg.removeAttribute('hidden');
      } else {
        emptyMsg.setAttribute('hidden', '');
      }
    }
    var noResults = form.querySelector('[data-faq-no-results]');
    if (noResults && total === 0) {
      noResults.setAttribute('hidden', '');
    }
  }

  function applyFaqFilter(form) {
    if (!form) { return; }
    var list = form.querySelector('[data-sortable-list="faqs"]');
    if (!list) { return; }
    var input = form.querySelector('[data-faq-search]');
    var term = input ? (input.value || '').trim().toLowerCase() : '';
    var cards = list.querySelectorAll('[data-faq-item]');
    var matches = 0;
    cards.forEach(function(card){
      if (!term) {
        card.removeAttribute('hidden');
        matches += 1;
        return;
      }
      var text = '';
      card.querySelectorAll('[data-faq-question-field], [data-faq-answer-field]').forEach(function(field){
        var value = '';
        if (field.tagName === 'INPUT' || field.tagName === 'TEXTAREA') {
          value = field.value || '';
        } else if (typeof field.textContent === 'string') {
          value = field.textContent;
        }
        text += ' ' + value.toLowerCase();
      });
      if (text.indexOf(term) !== -1) {
        card.removeAttribute('hidden');
        matches += 1;
      } else {
        card.setAttribute('hidden', '');
      }
    });
    var noResults = form.querySelector('[data-faq-no-results]');
    if (noResults) {
      if (term && matches === 0 && cards.length > 0) {
        noResults.removeAttribute('hidden');
      } else {
        noResults.setAttribute('hidden', '');
      }
    }
  }

  document.querySelectorAll('[data-sortable-list]').forEach(makeSortableList);

  var revealBtn = document.querySelector('[data-action="reauth-payments"]');
  if (revealBtn) revealBtn.addEventListener('click', function(ev){ ev.preventDefault(); window.adminReauthStart(); });

  if (window.Chart) {
    try { initRevenueChart(); } catch(e) { if (window.DZ_DEBUG) console.warn(e); }
    try { initPostVisibilityChart(); } catch(e) { if (window.DZ_DEBUG) console.warn(e); }
  }

  // Invoice actions (CSP-safe)
  document.querySelectorAll('.js-invoice-print').forEach(function(el){
    el.addEventListener('click', function(ev){ ev.preventDefault(); try { window.print(); } catch(_) {} });
  });
  document.querySelectorAll('.js-invoice-download').forEach(function(el){
    el.addEventListener('click', function(ev){ ev.preventDefault(); try { window.print(); } catch(_) {} });
  });

  // Admin Users: master checkbox (CSP-safe, replaces inline onclick)
  attachAdminUserMasterCheckbox();
  bindAdminUserSelectionCheckboxes();
  updateAdminBulkDeleteState();

  // Fake user generator progressive enhancement
  (function(){
    if (typeof window.fetch !== 'function') {
      return;
    }
    var feedback = document.getElementById('fakeUserFeedback');
    var tableRegion = document.getElementById('fakeUserTableRegion');

    function bindFakeUserForm(form, options) {
      if (!form || form.getAttribute('data-bound') === '1') {
        return;
      }
      form.setAttribute('data-bound', '1');
      var opts = options || {};
      form.addEventListener('submit', function(ev){
        ev.preventDefault();
        var submitButton = form.querySelector('button[type="submit"]');
        if (submitButton) {
          submitButton.disabled = true;
          submitButton.setAttribute('aria-busy', 'true');
        }
        if (feedback) {
          feedback.textContent = '';
        }

        var endpoint = form.getAttribute('action');
        if (!endpoint || typeof endpoint !== 'string') {
          if (typeof form.action === 'string') {
            endpoint = form.action;
          } else {
            endpoint = window.location.href;
          }
        }

        var fd = new FormData(form);
        fetch(endpoint, {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'X-Requested-With': 'XMLHttpRequest' },
          body: fd
        }).then(function(response){
          return response.json().catch(function(){ return {}; }).then(function(body){
            return { ok: response.ok, status: response.status, body: body };
          });
        }).then(function(payload){
          var res = payload.body || {};
          if (payload.ok && res.status === 'success') {
            var message = res.message || adminLang('admin_generic_success', 'Success.');
            if (feedback) {
              feedback.textContent = '';
            }
            adminToast(message, 'success');
            if (tableRegion && typeof res.table_html === 'string') {
              tableRegion.innerHTML = res.table_html;
              attachAdminUserMasterCheckbox();
              bindAdminPaginationForms();
              bindAll();
            }
            if (opts.resetFields) {
              var countField = form.querySelector('#fake_user_count');
              if (countField) { countField.value = '5'; }
              var passwordField = form.querySelector('#fake_user_password');
              if (passwordField) { passwordField.value = ''; }
            }
          } else {
            var msg = res.message || 'server_error';
            var friendly = adminMsg(msg);
            if (feedback) {
              feedback.textContent = '';
            }
            adminToast(friendly || msg, 'error');
          }
        }).catch(function(){
          if (feedback) {
            feedback.textContent = '';
          }
          adminToast(adminLang('admin_network_error_short', 'Network error'), 'error');
        }).finally(function(){
          if (submitButton) {
            submitButton.disabled = false;
            submitButton.removeAttribute('aria-busy');
          }
          updateAdminBulkDeleteState();
        });
      });
    }

    function bindAll() {
      document.querySelectorAll('[data-module="fake-user-generator"]').forEach(function(form){
        bindFakeUserForm(form, { resetFields: true });
      });
      document.querySelectorAll('[data-module="fake-user-delete"]').forEach(function(form){
        bindFakeUserForm(form, {});
      });
      bindAdminUserSelectionCheckboxes();
      updateAdminBulkDeleteState();
    }

    bindAll();
  })();

  (function(){
    function root(){
      return document.querySelector('.admin-ebook-languages-page');
    }

    function field(form, name){
      return form && form.elements ? form.elements.namedItem(name) : null;
    }

    function rowById(languageId){
      var page = root();
      if (!page || !languageId) { return null; }
      var safeId = String(languageId).replace(/"/g, '\\"');
      return page.querySelector('tr[data-language-row][data-id="' + safeId + '"]');
    }

    function rowFromTrigger(trigger){
      if (!trigger) { return null; }
      var row = trigger.closest ? trigger.closest('tr[data-language-row]') : null;
      if (row) { return row; }
      return rowById(trigger.getAttribute('data-language-id') || '');
    }

    function modalParts(){
      var page = root();
      if (!page) { return null; }
      return {
        page: page,
        actionUrl: page.getAttribute('data-language-action-url') || '',
        csrf: page.getAttribute('data-language-csrf') || '',
        modal: page.querySelector('[data-ebook-language-modal]'),
        form: page.querySelector('[data-ebook-language-form]'),
        message: page.querySelector('[data-language-message]'),
        title: page.querySelector('[data-language-modal-title]')
      };
    }

    function closeMenus(){
      var page = root();
      if (!page) { return; }
      page.querySelectorAll('.post-menu-popup').forEach(function(menu){
        menu.classList.add('none');
        menu.setAttribute('aria-hidden', 'true');
      });
      page.querySelectorAll('.js-ebook-language-actions').forEach(function(button){
        button.setAttribute('aria-expanded', 'false');
      });
    }

    function closeModal(){
      var parts = modalParts();
      if (!parts || !parts.modal) { return; }
      parts.modal.classList.remove('is-open');
      parts.modal.setAttribute('aria-hidden', 'true');
    }

    function setMessage(parts, text, isError){
      if (!parts || !parts.message) { return; }
      parts.message.textContent = text || '';
      parts.message.classList.toggle('is-error', !!isError);
    }

    function openModal(row){
      var parts = modalParts();
      if (!parts || !parts.modal || !parts.form) { return; }
      closeMenus();
      parts.form.reset();
      setMessage(parts, '', false);

      var values = {
        language_id: row ? (row.getAttribute('data-id') || '0') : '0',
        language_tag: row ? (row.getAttribute('data-tag') || '') : '',
        english_name: row ? (row.getAttribute('data-english') || '') : '',
        native_name: row ? (row.getAttribute('data-native') || '') : '',
        display_name: row ? (row.getAttribute('data-display') || '') : '',
        sort_order: row ? (row.getAttribute('data-sort') || '100') : '100'
      };

      Object.keys(values).forEach(function(name){
        var input = field(parts.form, name);
        if (input) { input.value = values[name]; }
      });

      var active = field(parts.form, 'is_active');
      if (active) { active.checked = !row || row.getAttribute('data-active') === '1'; }
      var isDefault = field(parts.form, 'is_default');
      if (isDefault) { isDefault.checked = !!row && row.getAttribute('data-default') === '1'; }
      if (parts.title) {
        parts.title.textContent = row ? adminLang('admin_ebook_language_edit', 'Edit language') : adminLang('admin_ebook_language_add', 'Add language');
      }
      parts.modal.classList.add('is-open');
      parts.modal.setAttribute('aria-hidden', 'false');
      window.setTimeout(function(){
        var first = parts.form.querySelector('input[name="language_tag"]');
        if (first) { first.focus(); }
      }, 50);
    }

    function postLanguageAction(parts, action, languageId){
      var fd = new FormData();
      fd.set('csrf_token', parts.csrf || '');
      fd.set('ebook_settings_action', action || '');
      fd.set('language_id', languageId || '0');
      return fetch(parts.actionUrl, {
        method: 'POST',
        body: fd,
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      }).then(function(response){
        return response.json().catch(function(){ return {}; }).then(function(json){
          json.httpStatus = response.status;
          return json;
        });
      });
    }

    function submitLanguageForm(form){
      var parts = modalParts();
      if (!parts || !parts.actionUrl) { return; }
      var submit = form.querySelector('[type="submit"]');
      setMessage(parts, '', false);
      if (submit) {
        submit.disabled = true;
        submit.setAttribute('aria-busy', 'true');
      }
      fetch(parts.actionUrl, {
        method: 'POST',
        body: new FormData(form),
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      }).then(function(response){
        return response.json().catch(function(){ return {}; });
      }).then(function(res){
        if (res && res.status === 'success') {
          adminToast(res.message || adminLang('admin_ebook_language_action_saved', 'Language action saved.'), 'success');
          window.setTimeout(function(){ window.location.reload(); }, 180);
          return;
        }
        setMessage(parts, (res && res.message) || adminLang('admin_ebook_language_save_failed', 'Language could not be saved.'), true);
      }).catch(function(){
        setMessage(parts, adminLang('admin_ebook_language_save_failed', 'Language could not be saved.'), true);
      }).finally(function(){
        if (submit) {
          submit.disabled = false;
          submit.removeAttribute('aria-busy');
        }
      });
    }

    document.addEventListener('click', function(event){
      var page = root();
      if (!page) { return; }

      var opener = event.target.closest ? event.target.closest('[data-ebook-language-open]') : null;
      if (opener) {
        event.preventDefault();
        event.stopImmediatePropagation();
        openModal(null);
        return;
      }

      var closer = event.target.closest ? event.target.closest('[data-language-close]') : null;
      if (closer && page.contains(closer)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        closeModal();
        return;
      }

      var edit = event.target.closest ? event.target.closest('[data-language-edit]') : null;
      if (edit) {
        event.preventDefault();
        event.stopImmediatePropagation();
        openModal(rowFromTrigger(edit));
        return;
      }

      var actionButton = event.target.closest ? event.target.closest('[data-language-action]') : null;
      if (actionButton) {
        event.preventDefault();
        event.stopImmediatePropagation();
        var parts = modalParts();
        var row = rowFromTrigger(actionButton);
        var action = actionButton.getAttribute('data-language-action') || '';
        var languageId = actionButton.getAttribute('data-language-id') || (row ? row.getAttribute('data-id') : '0');
        var confirmText = actionButton.getAttribute('data-confirm') || '';
        var run = function(){
          actionButton.disabled = true;
          postLanguageAction(parts, action, languageId).then(function(res){
            if (res && res.status === 'success') {
              adminToast(res.message || adminLang('admin_ebook_language_action_saved', 'Language action saved.'), 'success');
              window.setTimeout(function(){ window.location.reload(); }, 180);
              return;
            }
            adminToast((res && res.message) || adminLang('admin_ebook_language_save_failed', 'Language could not be saved.'), 'error');
          }).catch(function(){
            adminToast(adminLang('admin_ebook_language_save_failed', 'Language could not be saved.'), 'error');
          }).finally(function(){
            actionButton.disabled = false;
          });
        };
        closeMenus();
        if (confirmText) {
          if (typeof window.adminConfirm === 'function') {
            window.adminConfirm(confirmText).then(function(ok){ if (ok) { run(); } });
          } else if (window.confirm(confirmText)) {
            run();
          }
          return;
        }
        run();
      }
    }, true);

    document.addEventListener('submit', function(event){
      var form = event.target && event.target.matches && event.target.matches('[data-ebook-language-form]') ? event.target : null;
      if (!form) { return; }
      event.preventDefault();
      event.stopImmediatePropagation();
      submitLanguageForm(form);
    }, true);

    document.addEventListener('keydown', function(event){
      if (event.key !== 'Escape') { return; }
      var parts = modalParts();
      if (parts && parts.modal && parts.modal.classList.contains('is-open')) {
        closeModal();
      }
    });
  })();

  // Accessible admin confirm modal (progressive enhancement)
  var adminConfirm = (function(){
    var overlay, dialog, messageNode, confirmBtn, cancelBtn;
    var resolver = null;
    var lastActive = null;
    var titleId = 'adminConfirmTitle';
    var messageId = 'adminConfirmMessage';

    function close(result) {
      if (!overlay) { return; }
      overlay.classList.remove('is-visible');
      overlay.setAttribute('aria-hidden', 'true');
      if (document.body && document.body.classList) {
        document.body.classList.remove('admin-confirm-open');
      }
      var resolve = resolver;
      resolver = null;
      var target = lastActive;
      lastActive = null;
      if (typeof resolve === 'function') {
        resolve(Boolean(result));
      }
      if (target && typeof target.focus === 'function') {
        try { target.focus(); } catch(_){}
      }
    }

    function onBackdropClick(ev) {
      if (ev && ev.target === overlay) {
        ev.preventDefault();
        close(false);
      }
    }

    function onKeyDown(ev) {
      if (!overlay || overlay.getAttribute('aria-hidden') === 'true') { return; }
      if (ev.key === 'Escape') {
        ev.preventDefault();
        close(false);
        return;
      }
      if (ev.key === 'Tab') {
        var focusables = [confirmBtn, cancelBtn].filter(function(el){ return el && !el.disabled; });
        if (focusables.length === 0) { return; }
        var current = document.activeElement;
        var idx = focusables.indexOf(current);
        if (idx === -1) {
          idx = 0;
        } else {
          idx = ev.shiftKey ? (idx === 0 ? focusables.length - 1 : idx - 1)
                            : (idx === focusables.length - 1 ? 0 : idx + 1);
        }
        ev.preventDefault();
        try { focusables[idx].focus(); } catch(_){}
      }
    }

    function ensureElements() {
      if (overlay) { return; }
      var bodyEl = document.body;
      if (!bodyEl) { return; }
      var I = (window.DZ && typeof window.DZ.i18n === 'function') ? window.DZ.i18n : function(){ return ''; };

      try {
        overlay = document.createElement('div');
        overlay.className = 'admin-confirm-backdrop';
        overlay.setAttribute('aria-hidden', 'true');

        dialog = document.createElement('div');
        dialog.className = 'admin-confirm-dialog';
        dialog.setAttribute('role', 'dialog');
        dialog.setAttribute('aria-modal', 'true');
        dialog.setAttribute('aria-labelledby', titleId);
        dialog.setAttribute('aria-describedby', messageId);
        dialog.setAttribute('tabindex', '-1');

        var body = document.createElement('div');
        body.className = 'admin-confirm-body flex flexBoxColumn';

        var title = document.createElement('h2');
        title.className = 'admin-confirm-title';
        title.id = titleId;
        title.textContent = I('confirm_action_title') || 'Confirm action';

        messageNode = document.createElement('p');
        messageNode.className = 'admin-confirm-message';
        messageNode.id = messageId;
        messageNode.textContent = '';

        body.appendChild(title);
        body.appendChild(messageNode);

        var actions = document.createElement('div');
        actions.className = 'admin-confirm-actions';

        cancelBtn = document.createElement('button');
        cancelBtn.type = 'button';
        cancelBtn.className = 'btn-hover admin-confirm-cancel';
        cancelBtn.textContent = I('cancel') || 'Cancel';

        confirmBtn = document.createElement('button');
        confirmBtn.type = 'button';
        confirmBtn.className = 'btn-hover admin-confirm-approve';
        confirmBtn.textContent = I('confirm') || 'Confirm';

        actions.appendChild(cancelBtn);
        actions.appendChild(confirmBtn);

        dialog.appendChild(body);
        dialog.appendChild(actions);
        overlay.appendChild(dialog);

        cancelBtn.addEventListener('click', function(ev){
          ev.preventDefault();
          close(false);
        });
        confirmBtn.addEventListener('click', function(ev){
          ev.preventDefault();
          close(true);
        });
        overlay.addEventListener('click', onBackdropClick);
        document.addEventListener('keydown', onKeyDown, true);

        bodyEl.appendChild(overlay);
      } catch(err) {
        overlay = null;
        dialog = null;
        messageNode = null;
        confirmBtn = null;
        cancelBtn = null;
      }
    }

    function open(message) {
      ensureElements();
      if (!overlay) {
        return Promise.resolve(window.confirm(String(message || '')));
      }
      overlay.classList.add('is-visible');
      overlay.setAttribute('aria-hidden', 'false');
      if (document.body && document.body.classList) {
        document.body.classList.add('admin-confirm-open');
      }
      messageNode.textContent = String(message || '');
      lastActive = document.activeElement;
      return new Promise(function(resolve){
        resolver = resolve;
        setTimeout(function(){
          try {
            if (dialog) {
              dialog.focus();
              if (confirmBtn) { confirmBtn.focus(); }
            }
          } catch(_){}
        }, 0);
      });
    }

    return open;
  })();
  if (typeof window !== 'undefined') {
    window.adminConfirm = adminConfirm;
  }

  var adminPrompt = (function(){
    var overlay, dialog, titleNode, messageNode, labelNode, inputNode, errorNode, formNode, confirmBtn, cancelBtn;
    var resolver = null;
    var lastActive = null;
    var activeOptions = {};
    var titleId = 'adminPromptTitle';
    var messageId = 'adminPromptMessage';
    var inputId = 'adminPromptInput';

    function ensureElements() {
      if (overlay) { return; }
      var bodyEl = document.body;
      if (!bodyEl) { return; }
      var I = (window.DZ && typeof window.DZ.i18n === 'function') ? window.DZ.i18n : function(){ return ''; };

      try {
        overlay = document.createElement('div');
        overlay.className = 'admin-confirm-backdrop admin-prompt-backdrop';
        overlay.setAttribute('aria-hidden', 'true');

        dialog = document.createElement('div');
        dialog.className = 'admin-confirm-dialog admin-prompt-dialog';
        dialog.setAttribute('role', 'dialog');
        dialog.setAttribute('aria-modal', 'true');
        dialog.setAttribute('aria-labelledby', titleId);
        dialog.setAttribute('aria-describedby', messageId);
        dialog.setAttribute('tabindex', '-1');

        formNode = document.createElement('form');
        formNode.className = 'admin-prompt-form flex flexBoxColumn';

        var body = document.createElement('div');
        body.className = 'admin-confirm-body flex flexBoxColumn';

        titleNode = document.createElement('h2');
        titleNode.className = 'admin-confirm-title';
        titleNode.id = titleId;
        titleNode.textContent = I('admin_reauth_modal_title') || 'Unlock payment secrets';

        messageNode = document.createElement('p');
        messageNode.className = 'admin-confirm-message';
        messageNode.id = messageId;
        messageNode.textContent = '';

        var field = document.createElement('div');
        field.className = 'admin-prompt-field';

        labelNode = document.createElement('label');
        labelNode.className = 'admin-prompt-label';
        labelNode.setAttribute('for', inputId);
        labelNode.textContent = I('password');

        inputNode = document.createElement('input');
        inputNode.className = 'form-input admin-prompt-input';
        inputNode.id = inputId;
        inputNode.type = 'password';
        inputNode.setAttribute('autocomplete', 'current-password');

        errorNode = document.createElement('p');
        errorNode.className = 'admin-prompt-error';
        errorNode.setAttribute('role', 'alert');
        errorNode.hidden = true;
        errorNode.textContent = I('admin_prompt_required') || 'This field is required.';

        field.appendChild(labelNode);
        field.appendChild(inputNode);
        field.appendChild(errorNode);

        body.appendChild(titleNode);
        body.appendChild(messageNode);
        body.appendChild(field);

        var actions = document.createElement('div');
        actions.className = 'admin-confirm-actions admin-prompt-actions';

        cancelBtn = document.createElement('button');
        cancelBtn.type = 'button';
        cancelBtn.className = 'btn-hover admin-confirm-cancel';
        cancelBtn.textContent = I('cancel') || 'Cancel';

        confirmBtn = document.createElement('button');
        confirmBtn.type = 'submit';
        confirmBtn.className = 'btn-hover admin-confirm-approve';
        confirmBtn.textContent = I('confirm') || 'Confirm';

        actions.appendChild(cancelBtn);
        actions.appendChild(confirmBtn);

        formNode.appendChild(body);
        formNode.appendChild(actions);
        dialog.appendChild(formNode);
        overlay.appendChild(dialog);

        cancelBtn.addEventListener('click', function(ev){
          ev.preventDefault();
          close(null);
        });
        formNode.addEventListener('submit', function(ev){
          ev.preventDefault();
          submit();
        });
        inputNode.addEventListener('input', function(){
          if (!errorNode) { return; }
          errorNode.hidden = true;
          errorNode.textContent = '';
        });
        overlay.addEventListener('click', function(ev){
          if (ev && ev.target === overlay) {
            ev.preventDefault();
            close(null);
          }
        });
        document.addEventListener('keydown', onKeyDown, true);

        bodyEl.appendChild(overlay);
      } catch(err) {
        overlay = null;
        dialog = null;
        formNode = null;
        titleNode = null;
        messageNode = null;
        labelNode = null;
        inputNode = null;
        errorNode = null;
        confirmBtn = null;
        cancelBtn = null;
      }
    }

    function setError(message) {
      if (!errorNode) { return; }
      if (message) {
        errorNode.textContent = String(message);
        errorNode.hidden = false;
      } else {
        errorNode.textContent = '';
        errorNode.hidden = true;
      }
    }

    function close(result) {
      if (!overlay) {
        if (typeof resolver === 'function') {
          resolver(result);
        }
        resolver = null;
        return;
      }
      overlay.classList.remove('is-visible');
      overlay.setAttribute('aria-hidden', 'true');
      if (document.body && document.body.classList) {
        document.body.classList.remove('admin-confirm-open');
      }
      setError('');
      if (inputNode) {
        inputNode.value = '';
      }
      var resolve = resolver;
      resolver = null;
      var target = lastActive;
      lastActive = null;
      activeOptions = {};
      if (typeof resolve === 'function') {
        resolve(result);
      }
      if (target && typeof target.focus === 'function') {
        try { target.focus(); } catch(_){}
      }
    }

    function submit() {
      if (!inputNode) {
        close('');
        return;
      }
      var value = inputNode.value || '';
      if (activeOptions.required && value.trim() === '') {
        setError(activeOptions.errorMessage || adminLang('admin_prompt_required', 'This field is required.'));
        try { inputNode.focus(); } catch(_){}
        return;
      }
      close(value);
    }

    function onKeyDown(ev) {
      if (!overlay || overlay.getAttribute('aria-hidden') === 'true') { return; }
      if (ev.key === 'Escape') {
        ev.preventDefault();
        close(null);
        return;
      }
      if (ev.key === 'Tab') {
        var focusables = [inputNode, confirmBtn, cancelBtn].filter(function(el){ return el && !el.disabled; });
        if (focusables.length === 0) { return; }
        var current = document.activeElement;
        var idx = focusables.indexOf(current);
        if (idx === -1) {
          idx = 0;
        } else {
          idx = ev.shiftKey ? (idx === 0 ? focusables.length - 1 : idx - 1)
                            : (idx === focusables.length - 1 ? 0 : idx + 1);
        }
        ev.preventDefault();
        try { focusables[idx].focus(); } catch(_){}
      }
    }

    function open(options) {
      options = options || {};
      ensureElements();
      if (!overlay) {
        return Promise.resolve(options.required ? '' : null);
      }
      activeOptions = {
        required: options.required !== false,
        errorMessage: options.errorMessage || options.requiredMessage
      };
      overlay.classList.add('is-visible');
      overlay.setAttribute('aria-hidden', 'false');
      if (document.body && document.body.classList) {
        document.body.classList.add('admin-confirm-open');
      }
      if (titleNode) {
        titleNode.textContent = options.title || adminLang('admin_prompt_title', 'Confirm');
      }
      if (messageNode) {
        messageNode.textContent = options.message || '';
      }
      if (labelNode) {
        labelNode.textContent = options.label || options.placeholder || adminLang('admin_prompt_label', 'Value');
      }
      if (inputNode) {
        inputNode.type = options.inputType || 'text';
        if (options.inputMode) {
          inputNode.setAttribute('inputmode', options.inputMode);
        } else {
          inputNode.removeAttribute('inputmode');
        }
        if (options.autocomplete !== undefined) {
          inputNode.setAttribute('autocomplete', options.autocomplete);
        } else {
          inputNode.setAttribute('autocomplete', options.inputType === 'password' ? 'current-password' : 'off');
        }
        inputNode.value = options.defaultValue || '';
        if (options.placeholder) {
          inputNode.setAttribute('placeholder', options.placeholder);
        } else {
          inputNode.removeAttribute('placeholder');
        }
      }
      if (confirmBtn) {
        confirmBtn.textContent = options.confirmLabel || adminLang('confirm', 'Confirm');
      }
      if (cancelBtn) {
        cancelBtn.textContent = options.cancelLabel || adminLang('cancel', 'Cancel');
      }
      setError('');
      lastActive = document.activeElement;
      return new Promise(function(resolve){
        resolver = resolve;
        setTimeout(function(){
          try {
            if (dialog) {
              dialog.focus();
            }
            if (inputNode) {
              inputNode.focus();
              if (options.selectText !== false) {
                inputNode.select();
              }
            }
          } catch(_){}
        }, 0);
      });
    }

    return open;
  })();

  window.adminPrompt = function(options){
    return adminPrompt(options || {});
  };

  document.addEventListener('submit', function(ev){
    var form = ev.target;
    if (!form || form.tagName !== 'FORM') {
      return;
    }
    var msg = form.getAttribute('data-confirm');
    if (!msg) {
      return;
    }
    if (form.__adminConfirmBypass === true) {
      delete form.__adminConfirmBypass;
      return;
    }
    ev.preventDefault();
    if (typeof ev.stopImmediatePropagation === 'function') {
      ev.stopImmediatePropagation();
    } else if (typeof ev.stopPropagation === 'function') {
      ev.stopPropagation();
    }
    var submitter = ev.submitter;
    adminConfirm(msg).then(function(confirmed){
      if (!confirmed) {
        return;
      }
      form.__adminConfirmBypass = true;
      if (typeof form.requestSubmit === 'function') {
        try {
          if (submitter && typeof submitter === 'object') {
            form.requestSubmit(submitter);
            return;
          }
          form.requestSubmit();
          return;
        } catch(_){}
      }
      var retryEvent = new Event('submit', { bubbles: true, cancelable: true });
      var dispatched = form.dispatchEvent(retryEvent);
      if (!dispatched && retryEvent.defaultPrevented) {
        delete form.__adminConfirmBypass;
        return;
      }
      delete form.__adminConfirmBypass;
      if (!retryEvent.defaultPrevented) {
        HTMLFormElement.prototype.submit.call(form);
      }
    });
  }, true);

  // Sidebar submenu toggle (no inline handlers)
  document.addEventListener('click', function(ev){
    var t = ev.target;
    if (!t) return;
    var toggleEl = t.closest('[data-submenu-toggle]');
    if (!toggleEl) return;
    ev.preventDefault();
    var row = toggleEl.closest('.sidebar__menu_box');
    var sib = row ? row.nextElementSibling : null;
    // Find the adjacent submenu container
    while (sib && !(sib.classList && sib.classList.contains('sidebar__submenu'))) { sib = sib.nextElementSibling; }
    if (!sib) return;
    var isHidden = sib.classList.contains('is-hidden');
    if (isHidden) {
      sib.classList.remove('is-hidden');
      toggleEl.setAttribute('aria-expanded', 'true');
      try { toggleEl.classList.add('is-open'); } catch(_) {}
    } else {
      sib.classList.add('is-hidden');
      toggleEl.setAttribute('aria-expanded', 'false');
      try { toggleEl.classList.remove('is-open'); } catch(_) {}
    }
  });

  // Removed auto row-click navigation (was too aggressive).
  // If we later want targeted navigation, prefer explicit elements
  // (e.g., <span data-row-link="/posts/123">...</span>) and bind only to those.

  // Pagination: clamp goto input to valid range
  bindAdminPaginationForms();

  // Generic admin actions menu (post/users/contact/etc.)
  (function(){
    function menuFromToggle(toggle){
      if (!toggle) { return null; }
      var id = toggle.getAttribute('data-id') || '';
      if (id) {
        var byId = document.getElementById('postMenuPopup-' + id);
        if (byId) { return byId; }
      }
      var cell = toggle.closest ? toggle.closest('td') : null;
      return cell ? cell.querySelector('.post-menu-popup') : null;
    }

    function closeMenu(menu){
      if (!menu) { return; }
      menu.classList.add('none');
      menu.setAttribute('aria-hidden', 'true');
      if (menu.id && menu.id.indexOf('postMenuPopup-') === 0) {
        var refId = menu.id.replace('postMenuPopup-', '');
        if (refId) {
          var btn = document.querySelector('.post-settings-btn[data-id="' + refId + '"]');
          if (btn) { btn.setAttribute('aria-expanded', 'false'); }
        }
      }
    }

    function closeAllGeneric(exceptMenu){
      document.querySelectorAll('.post-menu-popup').forEach(function(menu){
        if (menu === exceptMenu) { return; }
        if (!menu.id || menu.id.indexOf('postMenuPopup-') !== 0) { return; }
        closeMenu(menu);
      });
    }

    document.addEventListener('click', function(ev){
      var cancel = ev.target && ev.target.closest ? ev.target.closest('.pm-cancel') : null;
      if (cancel) {
        ev.preventDefault();
        var pm = cancel.closest ? cancel.closest('.post-menu-popup') : null;
        closeMenu(pm);
        return;
      }

      var toggle = ev.target && ev.target.closest ? ev.target.closest('.post-settings-btn') : null;
      if (!toggle) { return; }
      if (!document.body || !document.body.classList || !document.body.classList.contains('admin-shell')) {
        return;
      }
      // Let specialized handlers manage their own toggles
      if (toggle.closest && (toggle.closest('[data-withdrawals-root]') || toggle.closest('[data-content-approvals-root]'))) {
        return;
      }
      ev.preventDefault();
      ev.stopPropagation();
      var menu = menuFromToggle(toggle);
      if (!menu) { return; }
      var isOpen = menu.classList.contains('none') === false;
      closeAllGeneric(menu);
      if (isOpen) {
        closeMenu(menu);
        return;
      }
      toggle.setAttribute('aria-expanded', 'true');
      menu.classList.remove('none');
      menu.setAttribute('aria-hidden', 'false');
      menu.removeAttribute('hidden');
    }, true);

    document.addEventListener('click', function(ev){
      if (!document.body || !document.body.classList || !document.body.classList.contains('admin-shell')) {
        return;
      }
      var insideMenu = ev.target && ev.target.closest ? ev.target.closest('.post-menu-popup') : null;
      var onToggle = ev.target && ev.target.closest ? ev.target.closest('.post-settings-btn') : null;
      if (!insideMenu && !onToggle) {
        closeAllGeneric();
      }
    }, true);
  })();

  function normalizePermissionList(raw) {
    if (!raw) { return []; }
    var data = raw;
    if (typeof raw === 'string') {
      try {
        data = JSON.parse(raw);
      } catch (_) {
        data = [];
      }
    }
    if (!data) { return []; }
    var out = [];
    if (Array.isArray(data)) {
      data.forEach(function(item){
        if (typeof item === 'string' && item.trim()) {
          out.push(item.trim().toLowerCase());
        }
      });
    } else if (typeof data === 'object') {
      Object.keys(data).forEach(function(key){
        if (!data[key]) { return; }
        if (typeof key === 'string' && key.trim()) {
          out.push(key.trim().toLowerCase());
        }
      });
    }
    return out;
  }

  function closestByClass(target, className) {
    var el = target;
    while (el && el !== document && el !== window) {
      if (el.classList && el.classList.contains(className)) {
        return el;
      }
      el = el.parentElement || el.parentNode;
    }
    return null;
  }

  function defaultModeratorPermissions() {
    return ['dashboard.view', 'users.view', 'content.view'];
  }

  function closeUserActionPopup(btn) {
    if (!btn) { return; }
    var popup = btn.closest ? btn.closest('.post-menu-popup') : null;
    if (popup) {
      popup.classList.add('none');
      popup.setAttribute('aria-hidden', 'true');
    }
    var row = btn.closest ? btn.closest('tr') : null;
    var toggle = null;
    if (row) {
      toggle = row.querySelector('.post-settings-btn');
    }
    if (!toggle && popup && popup.id && popup.id.indexOf('postMenuPopup-') === 0) {
      var refId = popup.id.replace('postMenuPopup-', '');
      if (refId) {
        toggle = document.querySelector('.post-settings-btn[data-id="' + refId + '"]');
      }
    }
    if (toggle) {
      toggle.setAttribute('aria-expanded', 'false');
    }
  }

  function permissionGroups() {
    return [
      {
        label: adminLang('admin_perm_group_dashboard', 'Dashboard'),
        items: [
          { key: 'dashboard.view', label: adminLang('admin_perm_dashboard_view', 'View dashboard') }
        ]
      },
      {
        label: adminLang('admin_perm_group_users', 'Users'),
        items: [
          { key: 'users.view', label: adminLang('admin_perm_users_view', 'View users') },
          { key: 'users.edit_profile', label: adminLang('admin_perm_users_edit_profile', 'Edit profile') },
          { key: 'users.edit_email', label: adminLang('admin_perm_users_edit_email', 'Edit email') },
          { key: 'users.manage', label: adminLang('admin_perm_users_manage', 'Manage account status') },
          { key: 'users.ban', label: adminLang('admin_perm_users_ban', 'Ban/unban users') },
          { key: 'users.delete', label: adminLang('admin_perm_users_delete', 'Delete users') },
          { key: 'users.set_role', label: adminLang('admin_perm_users_set_role', 'Change roles') },
          { key: 'users.reset_password', label: adminLang('admin_perm_users_reset_password', 'Reset passwords') },
          { key: 'users.edit_wallet', label: adminLang('admin_perm_users_edit_wallet', 'Edit wallet and payout details') }
        ]
      },
      {
        label: adminLang('admin_perm_group_verification', 'Verification'),
        items: [
          { key: 'verification.view', label: adminLang('admin_perm_verification_view', 'View verification requests') },
          { key: 'verification.approve', label: adminLang('admin_perm_verification_approve', 'Approve/reject verification') }
        ]
      },
      {
        label: adminLang('admin_perm_group_content', 'Content'),
        items: [
          { key: 'content.view', label: adminLang('admin_perm_content_view', 'View posts') },
          { key: 'content.edit', label: adminLang('admin_perm_content_edit', 'Edit posts') },
          { key: 'content.hide', label: adminLang('admin_perm_content_hide', 'Hide/unhide posts') },
          { key: 'content.delete', label: adminLang('admin_perm_content_delete', 'Delete posts') },
          { key: 'content.approve', label: adminLang('admin_perm_content_approve', 'Approve/reject posts') }
        ]
      },
      {
        label: adminLang('admin_perm_group_reports', 'Reports'),
        items: [
          { key: 'reports.resolve', label: adminLang('admin_perm_reports_resolve', 'Resolve reports') },
          { key: 'reports.delete_comment', label: adminLang('admin_perm_reports_delete_comment', 'Delete reported comments') }
        ]
      },
      {
        label: adminLang('admin_perm_group_finance', 'Finance'),
        items: [
          { key: 'payouts.review', label: adminLang('admin_perm_payouts_review', 'View payout reviews') },
          { key: 'payouts.update', label: adminLang('admin_perm_payouts_update', 'Approve/reject payout methods') },
          { key: 'withdrawals.review', label: adminLang('admin_perm_withdrawals_review', 'View withdrawals') },
          { key: 'withdrawals.update', label: adminLang('admin_perm_withdrawals_update', 'Update withdrawals') }
        ]
      },
      {
        label: adminLang('admin_perm_group_settings', 'Settings'),
        items: [
          { key: 'settings.manage', label: adminLang('admin_perm_settings_manage', 'Manage system settings') },
          { key: 'storage.manage', label: adminLang('admin_perm_storage_manage', 'Manage storage settings') }
        ]
      }
    ];
  }

  var permissionModal = null;
  var permissionModalState = {
    userId: 0,
    userName: '',
    isModerator: false
  };

  function ensurePermissionModal() {
    if (permissionModal) { return permissionModal; }

    var modal = document.createElement('div');
    modal.className = 'admin-permissions-modal';
    modal.setAttribute('aria-hidden', 'true');
    modal.innerHTML =
      '<div class="admin-permissions-backdrop" data-modal-close></div>' +
      '<div class="admin-permissions-panel" role="dialog" aria-modal="true" aria-labelledby="adminPermissionsTitle">' +
        '<div class="admin-permissions-header">' +
          '<div class="admin-permissions-heading">' +
            '<h3 id="adminPermissionsTitle"></h3>' +
            '<div class="admin-permissions-subtitle"></div>' +
          '</div>' +
          '<button type="button" class="admin-permissions-close" data-modal-close aria-label="' + adminLang('admin_moderator_permissions_close', 'Close') + '">&times;</button>' +
        '</div>' +
        '<div class="admin-permissions-body">' +
          '<div class="admin-permissions-list"></div>' +
        '</div>' +
        '<div class="admin-permissions-footer">' +
          '<button type="button" class="admin-button admin-button--danger" data-action="demote" hidden>' + adminLang('admin_moderator_permissions_remove', 'Remove moderator') + '</button>' +
          '<div class="admin-permissions-footer-actions">' +
            '<button type="button" class="admin-button admin-button--neutral" data-modal-close>' + adminLang('admin_moderator_permissions_cancel', 'Cancel') + '</button>' +
            '<button type="button" class="admin-button admin-button--primary" data-action="save">' + adminLang('admin_moderator_permissions_save', 'Save') + '</button>' +
          '</div>' +
        '</div>' +
      '</div>';

    document.body.appendChild(modal);
    permissionModal = modal;

    modal.querySelectorAll('[data-modal-close]').forEach(function(btn){
      btn.addEventListener('click', function(){
        closePermissionModal();
      });
    });

    modal.addEventListener('click', function(ev){
      if (ev.target && ev.target.classList && ev.target.classList.contains('admin-permissions-backdrop')) {
        closePermissionModal();
      }
    });

    var saveBtn = modal.querySelector('[data-action="save"]');
    var demoteBtn = modal.querySelector('[data-action="demote"]');
    if (saveBtn) {
      saveBtn.addEventListener('click', function(){
        submitPermissionModal('moderator');
      });
    }
    if (demoteBtn) {
      demoteBtn.addEventListener('click', function(){
        var msg = adminLang('admin_confirm_remove_moderator', 'Remove moderator role and reset permissions?');
        if (window.confirm(msg)) {
          submitPermissionModal('user');
        }
      });
    }

    return modal;
  }

  function closePermissionModal() {
    if (!permissionModal) { return; }
    permissionModal.setAttribute('aria-hidden', 'true');
    permissionModal.classList.remove('is-open');
  }

  function openPermissionModal(opts) {
    var modal = ensurePermissionModal();
    if (!modal) { return; }

    permissionModalState.userId = opts.userId || 0;
    permissionModalState.userName = opts.userName || '';
    permissionModalState.isModerator = !!opts.isModerator;

    var title = adminLang('admin_moderator_permissions_title', 'Moderator permissions');
    var heading = modal.querySelector('#adminPermissionsTitle');
    if (heading) {
      if (permissionModalState.userName) {
        heading.textContent = adminLang('admin_moderator_permissions_for', 'Permissions for {user}', {
          user: permissionModalState.userName
        });
      } else {
        heading.textContent = title;
      }
    }

    var subtitle = modal.querySelector('.admin-permissions-subtitle');
    if (subtitle) {
      subtitle.textContent = adminLang('admin_moderator_permissions_subtitle', 'Select what this moderator can view or do.');
    }

    var demoteBtn = modal.querySelector('[data-action="demote"]');
    if (demoteBtn) {
      if (permissionModalState.isModerator) {
        demoteBtn.removeAttribute('hidden');
      } else {
        demoteBtn.setAttribute('hidden', '');
      }
    }

    var selected = normalizePermissionList(opts.permissions || []);
    if (!selected.length && !opts.permissionsSet) {
      selected = defaultModeratorPermissions();
    }

    renderPermissionList(modal, selected);
    modal.setAttribute('aria-hidden', 'false');
    modal.classList.add('is-open');
  }

  function renderPermissionList(modal, selected) {
    var list = modal.querySelector('.admin-permissions-list');
    if (!list) { return; }
    list.innerHTML = '';
    var selectedMap = {};
    selected.forEach(function(key){
      selectedMap[key] = true;
    });

    permissionGroups().forEach(function(group){
      var groupEl = document.createElement('div');
      groupEl.className = 'admin-permissions-group';

      var title = document.createElement('div');
      title.className = 'admin-permissions-group-title';
      title.textContent = group.label;
      groupEl.appendChild(title);

      group.items.forEach(function(item){
        var label = document.createElement('label');
        label.className = 'admin-permissions-item';
        var input = document.createElement('input');
        input.type = 'checkbox';
        input.value = item.key;
        input.checked = !!selectedMap[item.key];
        var span = document.createElement('span');
        span.textContent = item.label;
        label.appendChild(input);
        label.appendChild(span);
        groupEl.appendChild(label);
      });

      list.appendChild(groupEl);
    });
  }

  function collectSelectedPermissions(modal) {
    var list = [];
    modal.querySelectorAll('.admin-permissions-item input[type="checkbox"]').forEach(function(cb){
      if (cb.checked && cb.value) {
        list.push(cb.value);
      }
    });
    return list;
  }

  function submitPermissionModal(targetRole) {
    if (!permissionModal) { return; }
    var uid = permissionModalState.userId;
    if (!uid) { return; }
    var saveBtn = permissionModal.querySelector('[data-action="save"]');
    var demoteBtn = permissionModal.querySelector('[data-action="demote"]');
    if (saveBtn) { saveBtn.disabled = true; saveBtn.setAttribute('aria-busy', 'true'); }
    if (demoteBtn) { demoteBtn.disabled = true; demoteBtn.setAttribute('aria-busy', 'true'); }

    var permissions = [];
    if (targetRole === 'moderator') {
      permissions = collectSelectedPermissions(permissionModal);
    }

    var data = {
      action: 'set_role',
      user_id: uid,
      role: targetRole,
      csrf_token: adminCsrfToken(),
      permissions: JSON.stringify(permissions)
    };

    fetch(adminRootUrl() + 'admin/request/users.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: Object.keys(data).map(function(k){ return encodeURIComponent(k) + '=' + encodeURIComponent(data[k]); }).join('&')
    }).then(function(r){ return r.json().catch(function(){ return {}; }); })
      .then(function(res){
        if (res && res.status === 'success') {
          adminToast(adminLang('admin_done', 'Done'), 'success');
          try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {}
        } else {
          var fail = adminMsg(res && res.message);
          if (!fail) { fail = adminLang('admin_operation_failed_reason', 'Operation failed.'); }
          adminToast(adminLang('admin_operation_failed', 'Operation failed: {reason}', { reason: fail }), 'error');
        }
      })
      .catch(function(){ adminToast(adminLang('admin_network_error_short', 'Network error'), 'error'); })
      .finally(function(){
        if (saveBtn) { saveBtn.disabled = false; saveBtn.removeAttribute('aria-busy'); }
        if (demoteBtn) { demoteBtn.disabled = false; demoteBtn.removeAttribute('aria-busy'); }
      });
  }

  // Admin user actions (popup menu items)
  document.addEventListener('click', function(ev){
    var t = ev.target;
    var btn = (t && t.closest) ? t.closest('.js-uact') : closestByClass(t, 'js-uact');
    if (!btn || !btn.classList || !btn.classList.contains('js-uact')) return;
    ev.preventDefault();
    // Prevent frontend post menu handlers from also firing
    try { ev.stopPropagation(); } catch(_){}

    // Do nothing if element is visually disabled
    if (btn.hasAttribute('disabled') || btn.getAttribute('aria-disabled') === 'true' || btn.classList.contains('is-disabled')) {
      return;
    }

    var action = (btn.getAttribute('data-action') || '').toLowerCase();
    var uid    = parseInt(btn.getAttribute('data-user-id') || '0', 10) || 0;
    var role   = (btn.getAttribute('data-role') || '').toLowerCase();
    if (!action || !uid) return;

    if (action === 'set_role' && role === 'moderator') {
      closeUserActionPopup(btn);
      var currentPerms = btn.getAttribute('data-permissions') || '';
      openPermissionModal({
        userId: uid,
        userName: btn.getAttribute('data-user-name') || '',
        permissions: currentPerms,
        permissionsSet: btn.getAttribute('data-permissions-set') === '1',
        isModerator: btn.classList.contains('is-role-active')
      });
      return;
    }

    if (action === 'delete') {
      if (!window.confirm(adminLang('admin_confirm_delete_user', 'This will permanently remove the user and related data. Continue?'))) return;
    }

    closeUserActionPopup(btn);

    var csrfEl = document.querySelector('meta[name="admin-csrf"]');
    var csrf   = csrfEl ? (csrfEl.getAttribute('content')||'') : '';
    var url    = (window.location.origin + window.location.pathname).replace(/admin\/index\.php.*/, '') + 'admin/request/users.php';
    var data   = { action: action, user_id: uid, csrf_token: csrf };
    if (action === 'set_role') { data.role = role; }

    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: Object.keys(data).map(function(k){ return encodeURIComponent(k)+'='+encodeURIComponent(data[k]); }).join('&')
    }).then(function(r){ return r.json().catch(function(){ return {}; }); })
      .then(function(res){
        if (res && res.status === 'success') { adminToast(adminLang('admin_done', 'Done'), 'success'); try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {} }
        else {
          var fail = adminMsg(res && res.message);
          if (!fail) { fail = adminLang('admin_operation_failed_reason', 'Operation failed.'); }
          adminToast(adminLang('admin_operation_failed', 'Operation failed: {reason}', { reason: fail }), 'error');
        }
      })
      .catch(function(){ adminToast(adminLang('admin_network_error_short', 'Network error'), 'error'); });
  }, true);

  // Admin post actions (popup menu items on content pages)
  document.addEventListener('click', function(ev){
    var t = ev.target;
    var btn = (t && t.closest) ? t.closest('.js-pact') : null;
    if (!btn || !btn.classList || !btn.classList.contains('js-pact')) return;
    ev.preventDefault();
    try { ev.stopPropagation(); } catch(_){}

    // Do nothing if element is visually disabled
    if (btn.hasAttribute('disabled') || btn.getAttribute('aria-disabled') === 'true' || btn.classList.contains('is-disabled')) {
      return;
    }

    var action = (btn.getAttribute('data-action') || '').toLowerCase();
    var pid    = parseInt(btn.getAttribute('data-post-id') || '0', 10) || 0;
    if (!action || !pid) return;

    if (action === 'delete') {
      var cmsg = adminLang('admin_confirm_delete_post', 'This will permanently delete post #{id}. Continue?', { id: pid });
      if (!window.confirm(cmsg)) return;
    }

    var csrfEl = document.querySelector('meta[name="admin-csrf"]');
    var csrf   = csrfEl ? (csrfEl.getAttribute('content')||'') : '';
    var url    = adminRootUrl() + 'admin/request/content.php';
    var data   = { action: action, post_id: pid, csrf_token: csrf };

    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: toUrlEncoded(data)
    }).then(function(r){ return r.json().catch(function(){ return {}; }); })
      .then(function(res){
        if (res && res.status === 'success') { adminToast(adminLang('admin_done', 'Done'), 'success'); try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {} }
        else {
          var fail = adminMsg(res && res.message);
          if (!fail) { fail = adminLang('admin_operation_failed_reason', 'Operation failed.'); }
          adminToast(adminLang('admin_operation_failed', 'Operation failed: {reason}', { reason: fail }), 'error');
        }
      })
      .catch(function(){ adminToast(adminLang('admin_network_error_short', 'Network error'), 'error'); });
  });

  function closeReportedCommentMenu(btn, row) {
    var popup = btn ? btn.closest('.post-menu-popup') : null;
    if (!popup && row) {
      popup = row.querySelector('.post-menu-popup');
    }
    if (popup) {
      popup.classList.add('none');
      popup.setAttribute('aria-hidden', 'true');
    }

    var toggle = null;
    if (row) {
      toggle = row.querySelector('.post-settings-btn');
    }
    if (!toggle && popup && popup.id) {
      var refId = popup.id.replace('postMenuPopup-', '');
      if (refId) {
        toggle = document.querySelector('.post-settings-btn[data-id="' + refId + '"]');
      }
    }
    if (toggle) {
      toggle.setAttribute('aria-expanded', 'false');
    }
  }

  function ensureReportedCommentsEmptyState(table) {
    if (!table) { return; }
    var tbody = table.tBodies && table.tBodies[0] ? table.tBodies[0] : table.querySelector('tbody');
    if (!tbody) { return; }

    var hasRows = false;
    Array.prototype.slice.call(tbody.rows || []).forEach(function(tr){
      if (tr && tr.getAttribute('data-empty-row') === '1') {
        if (hasRows) {
          tr.remove();
        }
        return;
      }
      hasRows = true;
    });

    if (hasRows) { return; }

    // Remove lingering placeholders before inserting a new one.
    Array.prototype.slice.call(tbody.querySelectorAll('[data-empty-row="1"]')).forEach(function(node){ node.remove(); });

    var emptyRow = document.createElement('tr');
    emptyRow.setAttribute('data-empty-row', '1');
    var td = document.createElement('td');
    var colSpan = (table.tHead && table.tHead.rows[0] ? table.tHead.rows[0].cells.length : 1) || 1;
    td.colSpan = colSpan;
    td.className = 'text-center text-muted empty_class_table';
    td.textContent = table.getAttribute('data-empty-text') || adminLang('admin_comments_empty', 'No reported comments.');
    emptyRow.appendChild(td);
    tbody.appendChild(emptyRow);
  }

  function removeReportedCommentRows(table, commentId, reportId, action) {
    if (!table) { return false; }
    var tbody = table.tBodies && table.tBodies[0] ? table.tBodies[0] : table.querySelector('tbody');
    if (!tbody) { return false; }
    var removed = false;

    if (action === 'delete_comment' && commentId) {
      Array.prototype.slice.call(tbody.querySelectorAll('tr[data-comment-id="' + commentId + '"]')).forEach(function(row){
        row.remove();
        removed = true;
      });
    }

    if (!removed && reportId) {
      Array.prototype.slice.call(tbody.querySelectorAll('tr[data-report-id="' + reportId + '"]')).forEach(function(row){
        row.remove();
        removed = true;
      });
    }

    return removed;
  }

  // Admin comment report actions
  function handleReportedCommentAction(ev){
    var target = ev.target;
    if (!target) { return; }
    var btn = target.closest ? target.closest('.js-cact') : null;
    if (!btn) { return; }
    ev.preventDefault();
    try { ev.stopPropagation(); } catch (_){}

    if (btn.classList.contains('is-disabled') || btn.getAttribute('aria-disabled') === 'true' || btn.dataset.processing === '1') {
      return;
    }

    var action = (btn.getAttribute('data-action') || '').toLowerCase();
    var commentId = parseInt(btn.getAttribute('data-comment-id') || '0', 10) || 0;
    var reportId = parseInt(btn.getAttribute('data-report-id') || '0', 10) || 0;
    if (!action) { return; }

    function runAction() {
      var csrf = adminCsrfToken();
      if (!csrf) {
        adminToast(adminLang('admin_missing_csrf', 'Missing CSRF token.'), 'error');
        return;
      }

      var payload = { action: action, csrf_token: csrf };
      if (commentId) { payload.comment_id = commentId; }
      if (reportId) { payload.report_id = reportId; }

      btn.dataset.processing = '1';
      btn.classList.add('is-disabled');
      btn.setAttribute('aria-busy', 'true');

      var row = btn.closest('tr[data-report-id]');
      var table = row ? row.closest('table[data-table-role="reported-comments"]') : null;

      try { console.info('Reported comment action', action, { commentId: commentId, reportId: reportId }); } catch(_) {}
      adminToast(adminLang('admin_processing', 'Processing…'), 'info');
      try { console.info('Reported comment action request', adminRootUrl() + 'admin/request/comment_reports.php', payload); } catch(_) {}

      fetch(adminRootUrl() + 'admin/request/comment_reports.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'X-Requested-With': 'XMLHttpRequest'
        },
        credentials: 'same-origin',
        body: toUrlEncoded(payload)
      }).then(function(res){
        return res.json().catch(function(){ return {}; });
      }).then(function(result){
        if (result && result.status === 'success') {
          closeReportedCommentMenu(btn, row);
          var data = result.data || {};
          var resolvedCommentId = data.comment_id != null ? parseInt(data.comment_id, 10) || 0 : commentId;
          var resolvedReportId = data.report_id != null ? parseInt(data.report_id, 10) || 0 : reportId;
          var removed = removeReportedCommentRows(table, resolvedCommentId, resolvedReportId, action);
          if (removed && table) {
            ensureReportedCommentsEmptyState(table);
          }
          adminToast(adminLang('admin_done', 'Done'), 'success');
          try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {}
        } else {
          var msgRaw = result && result.message ? String(result.message) : '';
          var msg = adminMsg(msgRaw) || msgRaw || adminLang('admin_operation_failed_reason', 'Operation failed.');
          adminToast(adminLang('admin_operation_failed', 'Operation failed: {reason}', { reason: msg }), 'error');
          try { console.error('Reported comment action failed', action, result); } catch(_) {}
        }
      }).catch(function(err){
        adminToast(adminLang('admin_network_error_short', 'Network error'), 'error');
        try { console.error('Reported comment action network error', action, err); } catch(_) {}
      }).finally(function(){
        btn.dataset.processing = '';
        btn.classList.remove('is-disabled');
        btn.removeAttribute('aria-busy');
      });
    }

    if (action === 'delete_comment') {
      var confirmMsg = adminLang('admin_comments_confirm_delete', 'Delete this comment? This cannot be undone.');
      if (typeof adminConfirm === 'function') {
        adminConfirm(confirmMsg).then(function(ok){ if (ok) { runAction(); } });
      } else if (window.confirm(confirmMsg)) {
        runAction();
      }
      return;
    }

    runAction();
  }

  document.addEventListener('click', handleReportedCommentAction, true);

  // Save user (admin user_detail form via AJAX)
  document.querySelectorAll('form[data-action="save-user"]').forEach(function(form){
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var url = adminRootUrl() + 'admin/request/user_update.php';
      var csrfEl = document.querySelector('meta[name="admin-csrf"]');
      var csrf   = csrfEl ? (csrfEl.getAttribute('content')||'') : '';
      var fd = new FormData(form);
      // Always set CSRF from meta to avoid repeating hidden inputs
      fd.set('csrf_token', csrf);
      // Map country code select to country name (for backward-compat DB field)
      try {
        var sel = form.querySelector('select[name="country_code"]');
        if (sel && sel.options && sel.selectedIndex >= 0) {
          var name = sel.options[sel.selectedIndex].text || '';
          if (!fd.get('for_billing_country')) fd.set('for_billing_country', name);
        }
      } catch(_){}
      // Inject cropped blobs if present (mirror settings/profile behavior)
      try {
        if (window.__PROFILE_CROP) {
          if (window.__PROFILE_CROP.avatarBlob) {
            try { fd.delete('avatar'); } catch(_){}
            fd.append('avatar', window.__PROFILE_CROP.avatarBlob, 'avatar.png');
          }
          if (window.__PROFILE_CROP.coverBlob) {
            try { fd.delete('cover'); } catch(_){}
            fd.append('cover', window.__PROFILE_CROP.coverBlob, 'cover.png');
          }
        }
      } catch(_){}
      fetch(url, { method:'POST', body: fd })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
          if (res && res.status === 'success') { adminToast(adminLang('admin_saved', 'Saved'), 'success'); try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {} }
          else {
            var fail = adminMsg(res && res.message);
            if (!fail) { fail = adminLang('admin_save_failed_generic', 'Save failed.'); }
            adminToast(adminLang('admin_save_failed_with_reason', 'Save failed: {reason}', { reason: fail }), 'error');
          }
        })
        .catch(function(){ adminToast(adminLang('admin_network_error_short', 'Network error'), 'error'); });
    });
  });

  // Save post (admin post_edit form via AJAX)
  document.querySelectorAll('form[data-action="save-post"]').forEach(function(form){
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var url = adminRootUrl() + 'admin/request/post_update.php';
      var fd  = new FormData(form);
      var csrfEl = document.querySelector('meta[name="admin-csrf"]');
      var csrf   = csrfEl ? (csrfEl.getAttribute('content')||'') : '';
      fd.set('csrf_token', csrf);
      // Client-side price validation when locked
      try {
        var vis = (fd.get('visibility') || '').toString().toLowerCase();
        var priceRaw = fd.get('price');
        var price = (priceRaw === null || priceRaw === '') ? null : parseInt(priceRaw, 10);
        var min = parseInt((document.getElementById('pp-min')||{}).value || '1', 10) || 1;
        var max = parseInt((document.getElementById('pp-max')||{}).value || '500', 10) || 500;
        if (vis === 'locked' && price !== null && (isNaN(price) || price < min || price > max)) {
          adminToast(adminLang('admin_price_range', 'Price must be between {min} and {max}.', { min: min, max: max }), 'warning');
          return;
        }
      } catch(_){}
      fetch(url, { method:'POST', body: fd })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
          if (res && res.status === 'success') {
            adminToast(adminLang('admin_saved', 'Saved'), 'success');
            try {
              if (res.notice === 'price_only_locked') {
                adminToast(adminLang('admin_price_locked_warning', 'Only locked posts can be priced. Price was cleared.'), 'warning');
              }
            } catch(_){}
            try { setTimeout(function(){ window.location.reload(); }, 800); } catch(_) {}
          } else {
            if (res && res.message === 'PRICE_RANGE') {
              var min = res && typeof res.min !== 'undefined' ? res.min : 1;
              var max = res && typeof res.max !== 'undefined' ? res.max : 500;
              adminToast(adminLang('admin_price_range', 'Price must be between {min} and {max}.', { min: min, max: max }), 'error');
            } else {
              var fail = adminMsg(res && res.message);
              if (!fail) { fail = adminLang('admin_save_failed_generic', 'Save failed.'); }
              adminToast(adminLang('admin_save_failed_with_reason', 'Save failed: {reason}', { reason: fail }), 'error');
            }
          }
        })
        .catch(function(){ adminToast(adminLang('admin_network_error_short', 'Network error'), 'error'); });
    });
  });

  // UI: Enable price only when visibility is 'locked'
  (function(){
    var vis = document.getElementById('visibility');
    var price = document.getElementById('price');
    function sync() {
      if (!vis || !price) return;
      var v = (vis.value || '').toLowerCase();
      var isLocked = (v === 'locked');
      if (isLocked) { price.disabled = false; }
      else { try { price.value = '0'; } catch(_){} price.disabled = true; }
      try {
        var hintLocked = document.querySelector('.price-hint--locked');
        var hintDisabled = document.querySelector('.price-hint--disabled');
        if (hintLocked) hintLocked.classList.toggle('is-hidden', !isLocked);
        if (hintDisabled) hintDisabled.classList.toggle('is-hidden', isLocked);
      } catch(_){}
    }
    if (vis && price) { vis.addEventListener('change', sync); sync(); }
  })();

  // Post-edit media grid: delete toggle + drag-and-drop reorder (UI only)
  document.querySelectorAll('[data-media-grid]').forEach(function(grid){
    // Delete toggle
    grid.addEventListener('click', function(ev){
      var t = ev.target;
      var btn = t.closest('.media-del');
      if (!btn) return;
      ev.preventDefault();
      var item = btn.closest('.media-item');
      if (!item) return;
      item.classList.toggle('is-selected');
      var cb = item.querySelector('input[type="checkbox"][name="delete_media[]"]');
      if (cb) { cb.checked = item.classList.contains('is-selected'); }
    });

    // Drag-n-drop reorder
    var dragging = null;
    grid.querySelectorAll('.media-item').forEach(function(it){ it.setAttribute('draggable','true'); });
    grid.addEventListener('dragstart', function(e){ var it = e.target.closest('.media-item'); if (!it) return; dragging = it; it.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; });
    grid.addEventListener('dragend',   function(){ if (dragging) dragging.classList.remove('dragging'); dragging = null; updateOrder(); });
    grid.addEventListener('dragover', function(e){ e.preventDefault(); var after = getAfterElement(grid, e.clientY, e.clientX); if (!dragging) return; if (after == null) { grid.appendChild(dragging); } else { grid.insertBefore(dragging, after); } });

    function getAfterElement(container, y, x){
      var items = [].slice.call(container.querySelectorAll('.media-item:not(.dragging)'));
      return items.reduce(function(closest, child){
        var box = child.getBoundingClientRect();
        var offset = y - (box.top + box.height / 2);
        if (offset < 0 && offset > closest.offset) { return { offset: offset, element: child }; }
        else { return closest; }
      }, { offset: Number.NEGATIVE_INFINITY }).element || null;
    }
    function updateOrder(){
      try {
        var order = [].map.call(grid.querySelectorAll('.media-item'), function(el){ return (el.getAttribute('data-path')||''); });
        var h = document.getElementById('media_order');
        if (!h) { h = document.createElement('input'); h.type = 'hidden'; h.name = 'media_order'; h.id='media_order'; grid.parentNode.appendChild(h); }
        h.value = JSON.stringify(order);
      } catch(_){}
    }
  });

  // Upload avatar/cover (multipart)
  document.querySelectorAll('form[data-action="upload-user-media"]').forEach(function(form){
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var url = adminRootUrl() + 'admin/request/user_media.php';
      var fd = new FormData(form);
      var csrfEl = document.querySelector('meta[name="admin-csrf"]');
      var csrf   = csrfEl ? (csrfEl.getAttribute('content')||'') : '';
      // Always include CSRF via meta to prevent hidden input duplication
      fd.set('csrf_token', csrf);
      try {
        var t = (fd.get('type') || '').toString();
        if (window.__PROFILE_CROP) {
          if (t === 'avatar' && window.__PROFILE_CROP.avatarBlob) {
            try { fd.delete('avatar'); } catch(_){}
            fd.append('avatar', window.__PROFILE_CROP.avatarBlob, 'avatar.png');
          }
          if (t === 'cover' && window.__PROFILE_CROP.coverBlob) {
            try { fd.delete('cover'); } catch(_){}
            fd.append('cover', window.__PROFILE_CROP.coverBlob, 'cover.png');
          }
        }
      } catch(_){}
      fetch(url, { method:'POST', body: fd })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
          if (res && res.status === 'success') { adminToast(adminLang('admin_uploaded', 'Uploaded'), 'success'); try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {} }
          else {
            var fail = adminMsg(res && res.message);
            if (!fail) { fail = adminLang('admin_upload_failed', 'Upload failed.'); }
            adminToast(adminLang('admin_upload_failed_reason', 'Upload failed: {reason}', { reason: fail }), 'error');
          }
        })
        .catch(function(){ adminToast(adminLang('admin_network_error_short', 'Network error'), 'error'); });
    });
  });
});

function adminRootUrl() {
  var o = window.location.origin || (window.location.protocol + '//' + window.location.host);
  var p = window.location.pathname || '/';
  // Strip everything from "/admin/" onward to get site root.
  return (o + p).replace(/\/admin\/.*/, '/');
}

function adminCsrfToken() {
  var meta = document.querySelector('meta[name="admin-csrf"]');
  return meta ? (meta.getAttribute('content') || '') : '';
}

function bindAdminUserSelectionCheckboxes() {
  document.querySelectorAll('.csel').forEach(function (cb) {
    if (!cb || cb.getAttribute('data-select-bound') === '1') {
      return;
    }
    cb.setAttribute('data-select-bound', '1');
    cb.addEventListener('change', function () {
      updateAdminBulkDeleteState();
    });
  });
}

function updateAdminBulkDeleteState() {
  document.querySelectorAll('form[data-module="fake-user-delete"]').forEach(function (form) {
    if (!form) { return; }
    var submitButton = form.querySelector('[data-bulk-button]');
    if (!submitButton) { return; }
    var checkboxes = form.querySelectorAll('.csel');
    var selectedCount = 0;
    checkboxes.forEach(function (cb) {
      if (cb && cb.checked) {
        selectedCount += 1;
      }
    });
    var countBadge = form.querySelector('[data-bulk-count]');
    if (countBadge) {
      countBadge.textContent = String(selectedCount);
      if (selectedCount > 0) {
        countBadge.classList.remove('is-hidden');
      } else {
        countBadge.classList.add('is-hidden');
      }
    }
    if (selectedCount > 0) {
      submitButton.disabled = false;
      submitButton.removeAttribute('aria-disabled');
    } else {
      submitButton.disabled = true;
      submitButton.setAttribute('aria-disabled', 'true');
    }
  });
}

function attachAdminUserMasterCheckbox() {
  var master = document.getElementById('chk_all');
  if (!master || master.getAttribute('data-bound') === '1') {
    return;
  }
  master.setAttribute('data-bound', '1');
  master.addEventListener('change', function () {
    var checked = !!master.checked;
    document.querySelectorAll('.csel').forEach(function (cb) {
      try { cb.checked = checked; } catch (_) {}
    });
    updateAdminBulkDeleteState();
  });
  bindAdminUserSelectionCheckboxes();
  updateAdminBulkDeleteState();
}

function bindAdminPaginationForms() {
  document.querySelectorAll('.dz-pagination .page-goto').forEach(function (form) {
    if (form.getAttribute('data-bound') === '1') {
      return;
    }
    form.setAttribute('data-bound', '1');
    form.addEventListener('submit', function (ev) {
      var input = form.querySelector('input[name="page_no"]');
      if (!input) { return; }
      var value = parseInt(input.value, 10);
      if (isNaN(value)) {
        ev.preventDefault();
        return;
      }
      var min = parseInt(input.getAttribute('min') || '1', 10) || 1;
      var max = parseInt(input.getAttribute('max') || '1', 10) || 1;
      if (value < min) { input.value = String(min); }
      if (value > max) { input.value = String(max); }
    });
  });
}

function toUrlEncoded(obj) {
  return Object.keys(obj).map(function (k) {
    return encodeURIComponent(k) + '=' + encodeURIComponent(obj[k] == null ? '' : obj[k]);
  }).join('&');
}

// TODO: refine parameters for moderation (e.g., data-action, data-post-id)
function handleModerateClick(ev) {
  ev.preventDefault();
  try {
    var t = ev.currentTarget || ev.target;
    var action = (t && t.getAttribute) ? (t.getAttribute('data-action') || 'moderate') : 'moderate';
    var postId = (t && t.getAttribute) ? (t.getAttribute('data-post-id') || '') : '';
    if (!postId) {
      console.warn('handleModerateClick: missing data-post-id (TODO)');
    }
    var url = adminRootUrl() + 'admin/request/content.php';
    var meta = document.querySelector('meta[name="admin-csrf"]');
    var csrf = meta ? (meta.getAttribute('content') || '') : '';
    var body = toUrlEncoded({ action: action, post_id: postId, csrf_token: csrf });
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body
    }).then(function (r) { return r.json().catch(function(){ return {}; }); })
      .then(function (res) {
        if (res && (res.status === 'success' || res.ok)) {
          if (window.DZ_DEBUG) { console.log('Moderation OK'); }
          try { window.location.reload(); } catch (e) {}
        } else {
          console.warn('Moderation response', res);
          adminToast(adminLang('admin_moderation_refresh', 'Moderation request sent. Please refresh to see updates.'), 'info');
        }
      })
      .catch(function () { adminToast(adminLang('admin_moderation_network_error', 'Network error while moderating.'), 'error'); });
  } catch (e) {
    console.error(e);
  }
}

function handlePaymentsSubmit(ev) {
  var submitter = ev && ev.submitter ? ev.submitter : null;
  var actionVal = '';
  if (submitter && typeof submitter.getAttribute === 'function') {
    actionVal = submitter.getAttribute('value') || '';
  }
  var skipReauth = actionVal === 'update_currency_format';

  if (!skipReauth && typeof window.adminReauthEnsure === 'function' && window.adminReauthEnsure(ev) === false) {
    return false;
  }

  ev.preventDefault();

  var form = ev.currentTarget;
  if (!form) { return false; }

  var submitBtn = form.querySelector('button[type="submit"]');
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.setAttribute('aria-busy', 'true');
  }

  var formData = new FormData(form);
  if (actionVal) {
    formData.set('action', actionVal);
  } else if (!formData.has('action')) {
    formData.set('action', 'update');
  }
  var url = form.getAttribute('action') || (adminRootUrl() + 'admin/request/payment_settings.php');

  fetch(url, { method: 'POST', body: formData })
    .then(function (response) {
      return response.json().catch(function () {
        return { status: response.ok ? 'success' : 'error', message: 'invalid_json' };
      });
    })
    .then(function (payload) {
      var status = payload && payload.status ? payload.status : 'error';
      var messageKey = payload && payload.message ? adminMsg(payload.message) : '';

      if (status === 'success') {
        if (!messageKey) {
          messageKey = adminLang('admin_saved', 'Saved');
        }
        adminToast(messageKey, 'success');
      } else {
        if (!messageKey) {
          messageKey = adminLang('admin_save_failed_generic', 'Save failed.');
        }
        adminToast(messageKey, 'error');
        if (payload && payload.message === 'reauth_required' && typeof window.adminReauthStart === 'function') {
          try { window._adminUnlocked = false; } catch (_) {}
          window.adminReauthStart();
        }
      }
    })
    .catch(function () {
      adminToast(adminLang('admin_network_error_short', 'Network error'), 'error');
    })
    .finally(function () {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.removeAttribute('aria-busy');
      }
    });

  return false;
}

function handleAnnouncementSubmit(ev) {
  var form = ev.currentTarget;
  if (!form) { return false; }

  var confirmMsg = form.getAttribute('data-confirm');
  if (confirmMsg && !window.confirm(confirmMsg)) {
    ev.preventDefault();
    return false;
  }

  ev.preventDefault();

  var submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.dataset.loading = 'true';
  }

  var formData = new FormData(form);
  var url = form.getAttribute('action') || (adminRootUrl() + 'admin/request/announcements.php');

  fetch(url, {
    method: 'POST',
    body: formData
  })
    .then(function(res){ return res.json().catch(function(){ return { status: 'error', message: 'server_error' }; }); })
    .then(function(payload){
      if (payload && payload.status === 'success') {
        var msg = payload.message ? adminMsg(payload.message) : '';
        if (!msg) { msg = adminLang('admin_saved', 'Saved'); }
        adminToast(msg, 'success');
        setTimeout(function(){ try { window.location.reload(); } catch (_) {} }, 600);
      } else {
        var err = payload && payload.message ? adminMsg(payload.message) : '';
        if (!err) { err = adminLang('admin_save_failed_generic', 'Save failed.'); }
        adminToast(err, 'error');
      }
    })
    .catch(function(){
      adminToast(adminLang('admin_network_error_retry', 'Network error. Please try again.'), 'error');
    })
    .finally(function(){
      if (submitBtn) {
        submitBtn.disabled = false;
        delete submitBtn.dataset.loading;
      }
    });

  return false;
}

function handleSiteSubmit(ev) {
  ev.preventDefault();
  var form = ev.currentTarget;
  if (!form) { return false; }
  var submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.dataset.loading = 'true';
  }

  var formData = new FormData(form);
  fetch(form.getAttribute('action') || window.location.href, {
    method: 'POST',
    body: formData,
  })
    .then(function(res){ return res.json().catch(function(){ return { status:'error', message:'server_error' }; }); })
    .then(function(payload){
      if (payload && payload.status === 'success') {
        var successMsg = '';
        if (window.DZ && typeof DZ.i18n === 'function') {
          successMsg = DZ.i18n('admin_save_success') || '';
        }
        if (!successMsg) { successMsg = adminLang('admin_settings_saved', 'Settings saved.'); }
        adminToast(successMsg, 'success');
        setTimeout(function(){ try { window.location.reload(); } catch(_) {} }, 900);
      } else {
        var msg = payload && payload.message ? adminMsg(payload.message) : adminLang('admin_save_failed_generic', 'Save failed.');
        adminToast(msg, 'error');
      }
    })
    .catch(function(){ adminToast(adminLang('admin_network_error_retry', 'Network error. Please try again.'), 'error'); })
    .finally(function(){
      if (submitBtn) {
        submitBtn.disabled = false;
        delete submitBtn.dataset.loading;
      }
    });

  return false;
}

function setFfmpegStatusElement(el, result) {
  if (!el) { return; }
  el.classList.remove('text-success', 'text-warning', 'text-danger', 'text-muted');
  el.classList.add('is-hidden');
  el.textContent = '';
  if (!result) {
    return;
  }

  var text = '';
  if (result.message_text) {
    text = String(result.message_text);
  } else if (result.message) {
    text = adminMsg(result.message) || adminLang(result.message, result.message);
  }
  var status = result.status ? String(result.status) : '';
  if (status === 'ok') {
    el.classList.add('text-success');
  } else if (status === 'skipped') {
    el.classList.add('text-warning');
  } else if (status === 'empty') {
    el.classList.add('text-muted');
  } else if (status === 'error') {
    el.classList.add('text-danger');
  }

  if (text) {
    el.textContent = text;
    el.classList.remove('is-hidden');
  } else if (status) {
    el.classList.remove('is-hidden');
  }
  if (result.resolved_path) {
    el.setAttribute('data-resolved-path', result.resolved_path);
  } else {
    el.removeAttribute('data-resolved-path');
  }
}

function handleFfmpegTest(ev) {
  if (ev) { ev.preventDefault(); }
  var button = ev && ev.currentTarget ? ev.currentTarget : null;
  if (!button) { return false; }

  var form = button.closest('form');
  if (!form) { return false; }

  var section = button.closest('[data-ffmpeg-section]');
  var ffmpegEl = section ? section.querySelector('[data-ffmpeg-status="ffmpeg"]') : null;
  var ffprobeEl = section ? section.querySelector('[data-ffmpeg-status="ffprobe"]') : null;
  var overallEl = section ? section.querySelector('[data-ffmpeg-status="overall"]') : null;

  setFfmpegStatusElement(ffmpegEl, null);
  setFfmpegStatusElement(ffprobeEl, null);
  setFfmpegStatusElement(overallEl, null);

  var fd = new FormData(form);
  fd.set('action', 'test_ffmpeg');

  var url = form.getAttribute('action') || (adminRootUrl() + 'admin/request/site_settings.php');

  button.disabled = true;
  button.setAttribute('aria-busy', 'true');

  fetch(url, { method: 'POST', body: fd })
    .then(function(res){
      return res.json().catch(function(){ return {}; });
    })
    .then(function(payload){
      setFfmpegStatusElement(ffmpegEl, payload && payload.ffmpeg ? payload.ffmpeg : null);
      setFfmpegStatusElement(ffprobeEl, payload && payload.ffprobe ? payload.ffprobe : null);

      var status = payload && payload.status ? String(payload.status) : '';
      var overallResult = null;
      if (status) {
        var messageText = payload && payload.message_text ? String(payload.message_text) : '';
        if (!messageText) {
          if (status === 'success') {
            messageText = adminLang('admin_ffmpeg_test_success', 'Binary validation completed.');
          } else {
            messageText = adminLang('admin_ffmpeg_test_error', 'One or more binaries failed validation.');
          }
        }
        overallResult = {
          status: status === 'success' ? 'ok' : 'error',
          message_text: messageText,
        };
        if (payload && payload.message) {
          overallResult.message = String(payload.message);
        }
      }

      setFfmpegStatusElement(overallEl, overallResult);

      if (overallResult && overallResult.message_text) {
        adminToast(overallResult.message_text, status === 'success' ? 'success' : 'error');
      }
    })
    .catch(function(){
      adminToast(adminLang('admin_network_error_retry', 'Network error. Please try again.'), 'error');
    })
    .finally(function(){
      button.disabled = false;
      button.removeAttribute('aria-busy');
    });

  return false;
}

function handleStorageTest(ev) {
  if (ev) { ev.preventDefault(); }
  var button = ev && ev.currentTarget ? ev.currentTarget : null;
  if (!button) { return false; }
  var form = button.closest('form');
  if (!form) { return false; }

  var fd = new FormData(form);
  fd.set('action', 'test');

  var url = form.getAttribute('action') || (adminRootUrl() + 'admin/request/storage_settings.php');

  button.disabled = true;
  button.setAttribute('aria-busy', 'true');

  fetch(url, { method: 'POST', body: fd })
    .then(function(res){
      return res.json().catch(function(){ return {}; });
    })
    .then(function(payload){
      var status = payload && payload.status ? String(payload.status) : '';
      var messageKey = payload && payload.message ? String(payload.message) : '';
      if (status === 'success') {
        var toastMsg = messageKey ? adminMsg(messageKey) : '';
        if (!toastMsg && messageKey) {
          toastMsg = adminLang(messageKey, messageKey);
        }
        if (!toastMsg) {
          toastMsg = adminLang('storage_test_success', 'Connection successful.');
        }
        adminToast(toastMsg, 'success');
      } else {
        var errMsg = messageKey ? adminMsg(messageKey) : '';
        if (!errMsg && messageKey) {
          errMsg = adminLang(messageKey, messageKey);
        }
        if (!errMsg) {
          errMsg = adminLang('storage_test_failed', 'Test failed.');
        }
        adminToast(errMsg, 'error');
      }
    })
    .catch(function(){
      adminToast(adminLang('admin_network_error_retry', 'Network error. Please try again.'), 'error');
    })
    .finally(function(){
      button.disabled = false;
      button.removeAttribute('aria-busy');
    });

  return false;
}

function contactMessagesRequest(payload) {
  var fd = new FormData();
  var csrfMeta = document.querySelector('meta[name="admin-csrf"]');
  var csrf = csrfMeta ? (csrfMeta.getAttribute('content') || '') : '';
  if (csrf) { fd.append('csrf_token', csrf); }
  Object.keys(payload || {}).forEach(function(key){
    var value = payload[key];
    if (value !== undefined && value !== null) {
      fd.append(key, value);
    }
  });
  return fetch(adminRootUrl() + 'admin/request/contact_email.php', {
    method: 'POST',
    body: fd,
    credentials: 'same-origin'
  }).then(function(r){
    return r.json().catch(function(){ return {}; });
  });
}

function formatContactDate(value) {
  if (!value) { return ''; }
  var iso = String(value).replace(' ', 'T');
  var d = new Date(iso);
  if (Number.isNaN(d.getTime())) {
    d = new Date(value);
  }
  if (Number.isNaN(d.getTime())) {
    return String(value);
  }
  try {
    return d.toLocaleString();
  } catch (_) {
    return d.toString();
  }
}

function initContactMessages() {
  var panel = document.querySelector('[data-role="contact-messages-panel"]');
  if (!panel) { return; }

  var filtersForm = panel.querySelector('[data-role="contact-messages-filters"]');
  var tableBody = panel.querySelector('[data-role="contact-messages-body"]');
  var emptyRow = panel.querySelector('[data-role="contact-messages-empty"]');
  var pagination = panel.querySelector('[data-role="contact-messages-pagination"]');
  var dialog = document.querySelector('[data-role="contact-message-dialog"]');
  var statusSelect = dialog ? dialog.querySelector('[data-field="status-select"]') : null;

  var statusLabels = {
    'new': panel.dataset.statusNew || adminLang('admin_contact_status_new', 'New'),
    'read': panel.dataset.statusRead || adminLang('admin_contact_status_read', 'Read'),
    'resolved': panel.dataset.statusResolved || adminLang('admin_contact_status_resolved', 'Resolved')
  };
  var typeLabels = {
    'feedback': panel.dataset.typeFeedback || adminLang('admin_contact_type_feedback', 'Feedback'),
    'complaint': panel.dataset.typeComplaint || adminLang('admin_contact_type_complaint', 'Complaint'),
    'suggestion': panel.dataset.typeSuggestion || adminLang('admin_contact_type_suggestion', 'Suggestion'),
    'bug': panel.dataset.typeBug || adminLang('admin_contact_type_bug', 'Bug')
  };

  var state = {
    page: 1,
    per_page: 20,
    status: 'all',
    msg_type: 'all',
    start_date: '',
    end_date: ''
  };
  var totalPages = 1;
  var loadingRow = null;
  var currentRow = null;

  function applyFilters() {
    if (!filtersForm) { return; }
    state.status = (filtersForm.elements.status && filtersForm.elements.status.value) || 'all';
    state.msg_type = (filtersForm.elements.msg_type && filtersForm.elements.msg_type.value) || 'all';
    state.start_date = (filtersForm.elements.start_date && filtersForm.elements.start_date.value) || '';
    state.end_date = (filtersForm.elements.end_date && filtersForm.elements.end_date.value) || '';
    state.per_page = parseInt(filtersForm.elements.per_page && filtersForm.elements.per_page.value, 10) || 20;
  }

  function clearDataRows() {
    if (!tableBody) { return; }
    Array.prototype.slice.call(tableBody.querySelectorAll('tr[data-message-row="1"]')).forEach(function(row){ row.remove(); });
  }

  function setLoading(loading) {
    if (!tableBody) { return; }
    if (loading) {
      clearDataRows();
      if (emptyRow) { emptyRow.setAttribute('hidden', ''); }
      loadingRow = document.createElement('tr');
      var cell = document.createElement('td');
      cell.colSpan = 6;
      cell.textContent = panel.dataset.loadingText || adminLang('admin_loading', 'Loading…');
      loadingRow.appendChild(cell);
      tableBody.appendChild(loadingRow);
    } else if (loadingRow) {
      loadingRow.remove();
      loadingRow = null;
    }
  }

  function formatStatus(status) {
    return statusLabels[status] || status;
  }

  function formatType(type) {
    return typeLabels[type] || type;
  }

  function renderRows(items) {
    if (!tableBody) { return; }
    clearDataRows();
    if (!items || !items.length) {
      if (emptyRow) { emptyRow.removeAttribute('hidden'); }
      return;
    }
    if (emptyRow) { emptyRow.setAttribute('hidden', ''); }

    var viewLabel = panel.dataset.viewLabel || adminLang('admin_contact_view', 'View');

    items.forEach(function(item){
      var tr = document.createElement('tr');
      tr.setAttribute('data-message-row', '1');
      tr.dataset.id = String(item.id);

      var createdTd = document.createElement('td');
      createdTd.textContent = formatContactDate(item.created_at);
      tr.appendChild(createdTd);

      var subjectTd = document.createElement('td');
      subjectTd.textContent = item.subject || '—';
      if (item.preview) {
        var preview = document.createElement('div');
        preview.textContent = item.preview;
        subjectTd.appendChild(preview);
      }
      tr.appendChild(subjectTd);

      var senderTd = document.createElement('td');
      senderTd.textContent = item.name || '—';
      if (item.email) {
        var emailLine = document.createElement('div');
        emailLine.textContent = item.email;
        senderTd.appendChild(emailLine);
      }
      tr.appendChild(senderTd);

      var typeTd = document.createElement('td');
      typeTd.textContent = formatType(item.msg_type || '');
      tr.appendChild(typeTd);

      var statusTd = document.createElement('td');
      statusTd.setAttribute('data-col', 'status');
      statusTd.textContent = formatStatus(item.status || '');
      tr.appendChild(statusTd);

      var actionsTd = document.createElement('td');
      var viewBtn = document.createElement('button');
      viewBtn.type = 'button';
      viewBtn.className = 'btn-outline';
      viewBtn.textContent = viewLabel;
      viewBtn.setAttribute('data-action', 'contact-view');
      viewBtn.setAttribute('data-id', String(item.id));
      actionsTd.appendChild(viewBtn);
      tr.appendChild(actionsTd);

      tableBody.appendChild(tr);
    });
  }

  function renderPagination(meta) {
    if (!pagination) { return; }
    pagination.innerHTML = '';
    totalPages = meta && meta.total_pages ? Math.max(1, parseInt(meta.total_pages, 10)) : 1;
    var current = meta && meta.page ? Math.max(1, parseInt(meta.page, 10)) : 1;
    state.page = current;
    if (totalPages <= 1) { return; }

    var prevBtn = document.createElement('button');
    prevBtn.type = 'button';
    prevBtn.className = 'btn-outline';
    prevBtn.textContent = '‹';
    prevBtn.disabled = current <= 1;
    prevBtn.dataset.page = String(current - 1);
    pagination.appendChild(prevBtn);

    var pageInfo = document.createElement('span');
    var tpl = panel.dataset.pageTemplate || adminLang('admin_contact_page_info', 'Page %current% of %total%');
    pageInfo.textContent = tpl.replace('%current%', current).replace('%total%', totalPages);
    pagination.appendChild(pageInfo);

    var nextBtn = document.createElement('button');
    nextBtn.type = 'button';
    nextBtn.className = 'btn-outline';
    nextBtn.textContent = '›';
    nextBtn.disabled = current >= totalPages;
    nextBtn.dataset.page = String(current + 1);
    pagination.appendChild(nextBtn);
  }

  function fetchMessages() {
    applyFilters();
    setLoading(true);
    contactMessagesRequest({
      action: 'list_messages',
      page: state.page,
      per_page: state.per_page,
      status: state.status,
      msg_type: state.msg_type,
      start_date: state.start_date,
      end_date: state.end_date
    }).then(function(res){
      setLoading(false);
      if (res && res.status === 'success' && res.data) {
        renderRows(res.data.items || []);
        renderPagination(res.data.pagination || {});
      } else {
        renderRows([]);
        var msg = adminMsg(res && res.message) || panel.dataset.errorFetch || adminLang('admin_contact_error_fetch', 'Unable to load messages.');
        adminToast(msg, 'error');
      }
    }).catch(function(){
      setLoading(false);
      renderRows([]);
      adminToast(panel.dataset.errorFetch || adminLang('admin_contact_error_fetch', 'Unable to load messages.'), 'error');
    });
  }

  if (filtersForm) {
    filtersForm.addEventListener('submit', function(ev){
      ev.preventDefault();
      state.page = 1;
      fetchMessages();
    });
  }

  if (pagination) {
    pagination.addEventListener('click', function(ev){
      var btn = ev.target.closest('button[data-page]');
      if (!btn) { return; }
      ev.preventDefault();
      var nextPage = parseInt(btn.dataset.page, 10);
      if (Number.isNaN(nextPage) || nextPage < 1 || nextPage > totalPages) { return; }
      state.page = nextPage;
      fetchMessages();
    });
  }

  if (tableBody) {
    tableBody.addEventListener('click', function(ev){
      var btn = ev.target.closest('[data-action="contact-view"]');
      if (!btn) { return; }
      var id = parseInt(btn.getAttribute('data-id'), 10);
      if (!id) { return; }
      currentRow = btn.closest('tr');
      contactMessagesRequest({ action: 'get_message', message_id: id })
        .then(function(res){
          if (!(res && res.status === 'success' && res.data)) {
            var msg = adminMsg(res && res.message) || panel.dataset.errorFetch || adminLang('admin_contact_error_fetch', 'Unable to load messages.');
            adminToast(msg, 'error');
            return;
          }
          var data = res.data;
          if (currentRow) {
            var statusCell = currentRow.querySelector('[data-col="status"]');
            if (statusCell && data.status) {
              statusCell.textContent = formatStatus(data.status);
            }
          }
          if (!dialog || typeof dialog.showModal !== 'function') {
            var fallbackMsg = (data.subject || '') + '\n\n' + (data.message || '');
            window.alert(fallbackMsg.trim());
            return;
          }
          dialog.dataset.messageId = String(data.id);
          var setField = function(selector, value){
            var el = dialog.querySelector('[data-field="' + selector + '"]');
            if (!el) { return; }
            if (selector === 'message') {
              el.textContent = value || '';
            } else {
              el.textContent = value || '—';
            }
          };
          setField('subject', data.subject || '');
          setField('name', data.name || '—');
          setField('email', data.email || '—');
          setField('msg_type', formatType(data.msg_type || ''));
          setField('status', formatStatus(data.status || ''));
          setField('created_at', formatContactDate(data.created_at || ''));
          setField('ip', data.ip || '—');
          setField('user_agent', data.user_agent || '—');
          setField('user_id', data.user_id ? ('#' + data.user_id) : '—');
          setField('message', data.message || '');
          if (statusSelect && data.status) {
            statusSelect.value = data.status;
          }
          try {
            dialog.showModal();
          } catch (e) {
            adminToast(formatStatus(data.status || ''), 'info');
          }
        })
        .catch(function(){
          adminToast(panel.dataset.errorFetch || adminLang('admin_contact_error_fetch', 'Unable to load messages.'), 'error');
        });
    });
  }

  if (dialog) {
    dialog.addEventListener('close', function(){
      dialog.dataset.messageId = '';
      currentRow = null;
    });

    dialog.addEventListener('click', function(ev){
      var btn = ev.target.closest('[data-action="contact-message-update"]');
      if (!btn) { return; }
      var messageId = parseInt(dialog.dataset.messageId || '0', 10);
      if (!messageId || !statusSelect) { dialog.close(); return; }
      var newStatus = statusSelect.value;
      btn.disabled = true;
      contactMessagesRequest({ action: 'set_status', message_id: messageId, status: newStatus })
        .then(function(res){
          if (res && res.status === 'success' && res.data && res.data.status) {
            var updatedStatus = res.data.status;
            if (statusSelect) { statusSelect.value = updatedStatus; }
            var statusText = formatStatus(updatedStatus);
            var statusField = dialog.querySelector('[data-field="status"]');
            if (statusField) { statusField.textContent = statusText; }
            if (currentRow) {
              var statusCell = currentRow.querySelector('[data-col="status"]');
              if (statusCell) { statusCell.textContent = statusText; }
            }
            var successText = panel.dataset.updatedText || adminLang('admin_contact_status_updated', 'Status updated.');
            adminToast(successText, 'success');
          } else {
            var msg = adminMsg(res && res.message) || panel.dataset.errorFetch || adminLang('admin_contact_error_update', 'Unable to update.');
            adminToast(msg, 'error');
          }
        })
        .catch(function(){
          adminToast(panel.dataset.errorFetch || adminLang('admin_contact_error_update', 'Unable to update.'), 'error');
        })
        .finally(function(){
          btn.disabled = false;
        });
    });
  }

  fetchMessages();
}

// Contact message action menus (list pages)
(function(){
  var root = document.querySelector('[data-contact-table-root]');
  if (!root) { return; }

  function closeMenus() {
    document.querySelectorAll('.post-menu-popup').forEach(function(pp){
      pp.classList.add('none');
      pp.setAttribute('aria-hidden', 'true');
    });
    document.querySelectorAll('.post-settings-btn[aria-expanded="true"]').forEach(function(btn){
      btn.setAttribute('aria-expanded', 'false');
    });
  }

  function updateStatus(row, status) {
    if (!row) { return; }
    var label = root.getAttribute('data-status-label-' + status) || statusLabels[status] || status;
    var pillClass = root.getAttribute('data-status-pill-' + status) || 'pill-gray';
    row.dataset.status = status;
    var pill = row.querySelector('[data-status-pill]');
    if (pill) {
      pill.textContent = label;
      pill.className = 'pill ' + pillClass;
    }
  }

  function removeRow(row) {
    if (!row) { return; }
    var tbody = row.parentElement;
    row.remove();
    if (!tbody) { return; }
    if (!tbody.querySelector('tr[data-message-id]')) {
      var tr = document.createElement('tr');
      tr.setAttribute('data-empty-row', 'true');
      var td = document.createElement('td');
      td.colSpan = 8;
      td.className = 'text-center text-muted';
      td.textContent = root.getAttribute('data-empty-text') || adminLang('admin_contact_empty', 'No contact messages found.');
      tr.appendChild(td);
      tbody.appendChild(tr);
    }
  }

  document.addEventListener('click', function(ev){
    var actionBtn = ev.target.closest('.js-contact-action');
    if (!actionBtn) { return; }
    var section = actionBtn.closest('[data-contact-table-root]');
    if (!section) { return; }

    var action = actionBtn.getAttribute('data-contact-action');
    if (!action) {
      closeMenus();
      return;
    }

    var messageId = parseInt(actionBtn.getAttribute('data-message-id') || '0', 10);

    if (action === 'reply') {
      ev.preventDefault();
      closeMenus();
      if (!messageId) { return; }
      var replyHref = actionBtn.getAttribute('data-reply-href') || '';
      if (!replyHref) {
        var replyBase = section.getAttribute('data-reply-url') || (adminRootUrl() + 'admin/index.php?page=contact_reply');
        var joinChar = replyBase.indexOf('?') === -1 ? '?' : '&';
        replyHref = replyBase + joinChar + 'id=' + messageId;
      }
      if (!replyHref) { return; }
      try {
        window.location.href = replyHref;
      } catch (_) {
        window.location.assign(replyHref);
      }
      return;
    }

    if (!messageId) {
      closeMenus();
      return;
    }

    ev.preventDefault();

    var csrfMeta = document.querySelector('meta[name="admin-csrf"]');
    var csrf = csrfMeta ? (csrfMeta.getAttribute('content') || '') : '';
    var row = actionBtn.closest('tr[data-message-id]');

    if (!csrf) {
      adminToast(adminLang('admin_missing_csrf', 'Missing CSRF token.'), 'error');
      closeMenus();
      return;
    }

    var endpoint = adminRootUrl() + 'admin/request/contact_email.php';

    if (action === 'set-status' || action === 'mark') {
      var statusValue = action === 'mark' ? 'resolved' : String(actionBtn.getAttribute('data-status-value') || '').toLowerCase();
      if (!statusValue) {
        closeMenus();
        return;
      }
      actionBtn.disabled = true;
      fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: toUrlEncoded({ action: 'set_status', message_id: messageId, status: statusValue, csrf_token: csrf })
      }).then(function(res){ return res.json().catch(function(){ return {}; }); })
        .then(function(payload){
          if (payload && payload.status === 'success') {
            updateStatus(row, statusValue);
            var toastKey = 'data-status-toast-' + statusValue;
            var toastMsg = section.getAttribute(toastKey) || section.getAttribute('data-toast-answered') || adminLang('admin_contact_status_updated', 'Status updated.');
            adminToast(toastMsg, 'success');
          } else {
            var msg = adminMsg(payload && payload.message) || adminLang('admin_contact_status_update_failed', 'Unable to update message status.');
            adminToast(msg, 'error');
          }
        })
        .catch(function(){ adminToast(adminLang('admin_network_error', 'Network error.'), 'error'); })
        .finally(function(){ actionBtn.disabled = false; closeMenus(); });
      return;
    }

    if (action === 'delete') {
      var confirmMsg = section.getAttribute('data-confirm-delete') || adminLang('admin_contact_delete_confirm', 'Delete this message?');
      if (!window.confirm(confirmMsg)) {
        closeMenus();
        return;
      }
      actionBtn.disabled = true;
      fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: toUrlEncoded({ action: 'delete', message_id: messageId, csrf_token: csrf })
      }).then(function(res){ return res.json().catch(function(){ return {}; }); })
        .then(function(payload){
          if (payload && payload.status === 'success') {
            removeRow(row);
            adminToast(section.getAttribute('data-toast-deleted') || adminLang('admin_contact_delete_success', 'Message deleted.'), 'success');
          } else {
            var msg = adminMsg(payload && payload.message) || adminLang('admin_contact_delete_failed', 'Unable to delete message.');
            adminToast(msg, 'error');
          }
        })
        .catch(function(){ adminToast(adminLang('admin_network_error', 'Network error.'), 'error'); })
        .finally(function(){ actionBtn.disabled = false; closeMenus(); });
      return;
    }
  });

  root.addEventListener('click', function(ev){
    var toggle = ev.target && ev.target.closest ? ev.target.closest('[data-preview-toggle]') : null;
    if (!toggle) { return; }
    ev.preventDefault();
    var previewRoot = toggle.closest('[data-preview-root]');
    if (!previewRoot) { return; }
    var full = previewRoot.querySelector('[data-preview-full]');
    if (!full) { return; }
    var moreLabel = root.getAttribute('data-preview-more') || adminLang('admin_contact_preview_expand', 'Show full message');
    var lessLabel = root.getAttribute('data-preview-less') || adminLang('admin_contact_preview_collapse', 'Hide full message');
    var isHidden = full.hasAttribute('hidden');
    if (isHidden) {
      full.removeAttribute('hidden');
      toggle.textContent = lessLabel;
      toggle.setAttribute('data-preview-state', 'less');
      toggle.setAttribute('aria-expanded', 'true');
    } else {
      full.setAttribute('hidden', '');
      toggle.textContent = moreLabel;
      toggle.setAttribute('data-preview-state', 'more');
      toggle.setAttribute('aria-expanded', 'false');
    }
  });
})();

// Content approval action menus (pending posts)
(function(){
  var root = document.querySelector('[data-content-approvals-root]');
  if (!root) { return; }

  function closeMenus() {
    root.querySelectorAll('.post-menu-popup').forEach(function(menu){
      menu.classList.add('none');
      menu.setAttribute('aria-hidden', 'true');
    });
    root.querySelectorAll('.post-settings-btn[aria-expanded="true"]').forEach(function(btn){
      btn.setAttribute('aria-expanded', 'false');
    });
  }

  function toggleMenu(btn) {
    if (!btn) { return; }
    var id = btn.getAttribute('data-id') || '';
    if (!id) { return; }
    var popup = root.querySelector('#postMenuPopup-' + id);
    if (!popup) { return; }
    var isOpen = popup.classList.contains('none') === false;
    closeMenus();
    if (isOpen) { return; }
    btn.setAttribute('aria-expanded', 'true');
    popup.classList.remove('none');
    popup.setAttribute('aria-hidden', 'false');
  }

  root.addEventListener('click', function(ev){
    var toggle = ev.target && ev.target.closest ? ev.target.closest('.post-settings-btn') : null;
    if (toggle && root.contains(toggle)) {
      ev.preventDefault();
      ev.stopPropagation();
      toggleMenu(toggle);
      return;
    }

    var cancelBtn = ev.target && ev.target.closest ? ev.target.closest('.pm-cancel') : null;
    if (cancelBtn && root.contains(cancelBtn)) {
      ev.preventDefault();
      closeMenus();
    }
  });

  document.addEventListener('click', function(ev){
    if (!root.contains(ev.target)) {
      closeMenus();
      return;
    }
    var insideMenu = ev.target && ev.target.closest ? ev.target.closest('.post-menu-popup') : null;
    var onToggle = ev.target && ev.target.closest ? ev.target.closest('.post-settings-btn') : null;
    if (!insideMenu && !onToggle) {
      closeMenus();
    }
  });
})();

// Withdrawal request modal & actions
(function(){
  var root = document.querySelector('[data-withdrawals-root]');
  if (!root) { return; }

  var dialog = document.querySelector('[data-withdrawal-dialog]');
  if (!dialog) { return; }

  var form = dialog.querySelector('[data-withdrawal-form]');
  if (!form) { return; }

  var statusSelect = form.querySelector('[data-field="status-select"]');
  var adminNoteInput = form.querySelector('[data-field="admin-note"]');
  var statusBadge = form.querySelector('[data-field="status-badge"]');
  var amountField = form.querySelector('[data-field="amount"]');
  var methodField = form.querySelector('[data-field="method"]');
  var requestedField = form.querySelector('[data-field="requested"]');
  var processedField = form.querySelector('[data-field="processed"]');
  var referenceField = form.querySelector('[data-field="reference"]');
  var requestIdField = form.querySelector('[data-field="request-id"]');
  var userNoteField = form.querySelector('[data-field="user-note"]');
  var destinationList = form.querySelector('[data-destination-list]');
  var destinationEmpty = form.querySelector('[data-destination-empty]');
  var subtitleField = form.querySelector('[data-field="subtitle"]');
  var userNameField = form.querySelector('[data-field="user-name"]');
  var userHandleField = form.querySelector('[data-field="user-handle"]');
  var adminLink = form.querySelector('[data-field="admin-link"]');
  var profileLink = form.querySelector('[data-field="profile-link"]');
  var userEmailField = form.querySelector('[data-field="user-email"]');
  var footerMeta = form.querySelector('[data-footer-meta]');
  var closeButtons = form.querySelectorAll('[data-withdrawal-close]');
  var markPaidBtn = form.querySelector('[data-action="mark-paid"]');
  var saveBtn = form.querySelector('[data-action="save"]');

  var state = { row: null, data: null, busy: false };

  function adminEndpoint() {
    return adminRootUrl() + 'admin/request/withdrawals.php';
  }

  function parseRow(row) {
    if (!row) { return null; }
    var raw = row.getAttribute('data-withdrawal');
    if (!raw) { return null; }
    try {
      return JSON.parse(raw);
    } catch (_) {
      return null;
    }
  }

  function setBusy(isBusy) {
    state.busy = !!isBusy;
    if (saveBtn) { saveBtn.disabled = state.busy; }
    if (markPaidBtn) { markPaidBtn.disabled = state.busy; }
    form.classList.toggle('is-busy', state.busy);
  }

  function closePopup(trigger) {
    var popup = trigger ? trigger.closest('.post-menu-popup') : null;
    if (!popup) { return; }
    popup.classList.add('none');
    popup.setAttribute('aria-hidden', 'true');
    try {
      var id = popup.id ? popup.id.replace('withdrawalMenu-', '') : '';
      if (id) {
        var toggle = root.querySelector('.post-settings-btn[data-id="' + id + '"]');
        if (toggle) { toggle.setAttribute('aria-expanded', 'false'); }
      }
    } catch (_) {}
  }

  function closeMenus() {
    var menus = root.querySelectorAll('.post-menu-popup');
    menus.forEach(function(menu){
      menu.classList.add('none');
      menu.setAttribute('aria-hidden', 'true');
    });
    root.querySelectorAll('.post-settings-btn[aria-expanded="true"]').forEach(function(btn){
      btn.setAttribute('aria-expanded', 'false');
    });
  }

  function toggleMenu(btn) {
    if (!btn) { return; }
    var id = btn.getAttribute('data-id') || '';
    if (!id) { return; }
    var menu = document.getElementById('withdrawalMenu-' + id);
    if (!menu) { return; }
    var isOpen = btn.getAttribute('aria-expanded') === 'true';
    closeMenus();
    if (isOpen) {
      return;
    }
    btn.setAttribute('aria-expanded', 'true');
    menu.classList.remove('none');
    menu.setAttribute('aria-hidden', 'false');
  }

  function renderPairs(list, items) {
    if (!list) { return; }
    list.innerHTML = '';
    if (destinationEmpty) {
      destinationEmpty.hidden = !!(items && items.length);
    }
    if (!items || !items.length) {
      return;
    }
    items.forEach(function(pair){
      if (!Array.isArray(pair) || pair.length < 2) { return; }
      var li = document.createElement('li');
      li.innerHTML = '<span class="title"></span><span class="value"></span>';
      li.querySelector('.title').textContent = String(pair[0] || '');
      li.querySelector('.value').textContent = String(pair[1] || '');
      list.appendChild(li);
    });
  }

  function safeText(target, value, fallback) {
    if (!target) { return; }
    var text = value == null || value === '' ? (fallback || '—') : value;
    target.textContent = String(text);
  }

  function populateDialog(data) {
    if (!data) { return; }
    form.dataset.payoutId = String(data.payout_id || '');
    safeText(subtitleField, '#'+(data.payout_id || '') + ' · ' + (data.status_label || ''));
    safeText(userNameField, data.full_name || data.username || '');
    safeText(userHandleField, data.username || '');
    safeText(userEmailField, data.email || '');
    safeText(amountField, data.amount_label || '');
    safeText(methodField, data.method_label || '');
    safeText(requestedField, data.requested_label || '—');
    safeText(processedField, data.processed_label || '—');
    var refDisplay = data.reference_display || data.reference || ('REQ-' + String(data.payout_id || '').padStart(6, '0'));
    safeText(referenceField, data.reference && data.reference !== '' ? data.reference : '—');
    safeText(requestIdField, refDisplay);
    safeText(userNoteField, data.user_note || '—');
    if (userNoteField) {
      userNoteField.classList.toggle('is-empty', !(data.user_note && data.user_note.trim()));
    }
    if (statusBadge) {
      statusBadge.textContent = String(data.status_label || '');
      var badgeClass = data.status_class || '';
      statusBadge.className = 'status-badge' + (badgeClass ? ' ' + badgeClass : '');
    }
    if (adminLink) {
      adminLink.href = data.admin_url || '#';
    }
    if (profileLink) {
      profileLink.href = data.profile_url || '#';
    }
    if (footerMeta) {
      var footerBits = [];
      if (data.requested_label) {
        footerBits.push(
          adminLang('admin_withdrawals_meta_requested', 'Requested {time}', { time: data.requested_label })
        );
      }
      if (data.processed_label && data.processed_label !== '—') {
        footerBits.push(
          adminLang('admin_withdrawals_meta_processed', 'Processed {time}', { time: data.processed_label })
        );
      }
      footerMeta.textContent = footerBits.join(' · ');
    }
    if (statusSelect) {
      if (data.status && statusSelect.querySelector('option[value="' + data.status + '"]')) {
        statusSelect.value = data.status;
      }
    }
    if (adminNoteInput) {
      adminNoteInput.value = data.admin_note || '';
    }
    renderPairs(destinationList, data.destination_pairs || []);
  }

  function updateRow(row, data) {
    if (!row || !data) { return; }
    try {
      row.setAttribute('data-withdrawal', JSON.stringify(data));
    } catch (_) {}
    var statusEl = row.querySelector('[data-status-badge]');
    if (statusEl) {
      statusEl.textContent = String(data.status_label || '');
      var badgeClass = data.status_class || '';
      statusEl.className = 'status-badge' + (badgeClass ? ' ' + badgeClass : '');
    }
    var amountEl = row.querySelector('[data-col="amount"] .amount-mono');
    if (amountEl && data.amount_label) {
      amountEl.textContent = String(data.amount_label);
    }
    var processedText = row.querySelector('[data-processed-label]');
    if (processedText) {
      processedText.textContent = String(data.processed_label || '—');
    }
    var requestedText = row.querySelector('[data-requested-label]');
    if (requestedText && data.requested_label) {
      requestedText.textContent = String(data.requested_label);
    }
    var referenceEl = row.querySelector('[data-reference]');
    if (referenceEl) {
      var ref = data.reference_display || data.reference || ('REQ-' + String(data.payout_id || '').padStart(6, '0'));
      referenceEl.textContent = ref;
    }
  }

  function openDialog(row, data) {
    state.row = row;
    state.data = data;
    populateDialog(data);
    try {
      dialog.showModal();
    } catch (e) {
      adminToast(root.getAttribute('data-error-fetch') || adminLang('admin_withdrawals_error_fetch', 'Unable to load withdrawal details.'), 'error');
    }
  }

  function submitUpdate(targetStatus) {
    if (state.busy) { return; }
    var payoutId = form.dataset.payoutId || '';
    if (!payoutId) { return; }
    var csrf = adminCsrfToken();
    if (!csrf) {
      adminToast(adminLang('admin_missing_csrf', 'Missing CSRF token.'), 'error');
      return;
    }
    var note = adminNoteInput ? adminNoteInput.value.trim() : '';
    setBusy(true);
    fetch(adminEndpoint(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: toUrlEncoded({
        action: 'update_status',
        payout_id: payoutId,
        status: targetStatus,
        note: note,
        csrf_token: csrf
      })
    }).then(function(res){
      return res.json().catch(function(){ return {}; });
    }).then(function(payload){
      if (payload && payload.status === 'success' && payload.data) {
        state.data = payload.data;
        populateDialog(state.data);
        updateRow(state.row, state.data);
        adminToast(root.getAttribute('data-toast-updated') || adminLang('admin_withdrawals_toast_updated', 'Withdrawal updated.'), 'success');
      } else {
        var msg = adminMsg(payload && payload.message) || root.getAttribute('data-error-update') || adminLang('admin_withdrawals_error_update', 'Unable to update withdrawal.');
        adminToast(msg, 'error');
      }
    }).catch(function(){
      adminToast(root.getAttribute('data-error-update') || adminLang('admin_withdrawals_error_update', 'Unable to update withdrawal.'), 'error');
    }).finally(function(){
      setBusy(false);
    });
  }

  root.addEventListener('click', function(ev){
    var toggle = ev.target && ev.target.closest ? ev.target.closest('.post-settings-btn') : null;
    if (toggle) {
      ev.preventDefault();
      ev.stopPropagation();
      toggleMenu(toggle);
      return;
    }

    var trigger = ev.target && ev.target.closest ? ev.target.closest('.js-withdrawal-review') : null;
    if (!trigger) { return; }
    ev.preventDefault();
    closePopup(trigger);
    var row = trigger.closest('tr[data-payout-id]');
    if (!row) { return; }
    var data = parseRow(row);
    if (!data) {
      adminToast(root.getAttribute('data-error-fetch') || adminLang('admin_withdrawals_error_fetch', 'Unable to load withdrawal details.'), 'error');
      return;
    }
    openDialog(row, data);
  });

  if (markPaidBtn) {
    markPaidBtn.addEventListener('click', function(){
      if (statusSelect && statusSelect.querySelector('option[value="paid"]')) {
        statusSelect.value = 'paid';
      }
      submitUpdate('paid');
    });
  }

  if (saveBtn) {
    saveBtn.addEventListener('click', function(ev){
      ev.preventDefault();
      if (!statusSelect) { return; }
      submitUpdate(statusSelect.value || 'pending');
    });
  }

  if (statusSelect) {
    statusSelect.addEventListener('change', function(){
      if (statusBadge && state.data) {
        statusBadge.textContent = statusSelect.options[statusSelect.selectedIndex].textContent;
      }
    });
  }

  if (form) {
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      if (!statusSelect) { return; }
      submitUpdate(statusSelect.value || 'pending');
    });
  }

  dialog.addEventListener('close', function(){
    state.row = null;
    state.data = null;
    form.dataset.payoutId = '';
    if (adminNoteInput) { adminNoteInput.value = ''; }
    if (destinationList) { destinationList.innerHTML = ''; }
    if (footerMeta) { footerMeta.textContent = ''; }
  });

  Array.prototype.forEach.call(closeButtons, function(btn){
    btn.addEventListener('click', function(ev){
      ev.preventDefault();
      try { dialog.close(); } catch (_) {}
    });
  });

  document.addEventListener('click', function(ev){
    if (!dialog.open) {
      var insideMenu = ev.target && ev.target.closest ? ev.target.closest('.post-menu-popup') : null;
      var onToggle = ev.target && ev.target.closest ? ev.target.closest('.post-settings-btn, .js-podcast-ad-actions') : null;
      if (!insideMenu && !onToggle) {
        closeMenus();
      }
    }
  });
})();

// Podcast ad action menus (mirror post actions)
(function(){
  function hideAllMenus() {
    document.querySelectorAll('.post-menu-popup').forEach(function(p){
      p.classList.add('none');
      p.setAttribute('aria-hidden','true');
    });
    document.querySelectorAll('.js-podcast-ad-actions').forEach(function(btn){
      btn.setAttribute('aria-expanded','false');
    });
  }

  document.addEventListener('click', function(ev){
    var toggle = ev.target && ev.target.closest ? ev.target.closest('.js-podcast-ad-actions') : null;
    if (!toggle) { return; }
    ev.preventDefault();
    ev.stopPropagation();
    var adId = toggle.getAttribute('data-ad-id') || '';
    if (!adId) { return; }
    var popup = document.getElementById('podcastAdMenu-' + adId);
    if (!popup) { return; }
    var isOpen = popup.classList.contains('none') === false;
    hideAllMenus();
    if (!isOpen) {
        popup.classList.remove('none');
        popup.setAttribute('aria-hidden','false');
        toggle.setAttribute('aria-expanded','true');
    }
  }, true);

  document.addEventListener('click', function(ev){
    var actionBtn = ev.target && ev.target.closest ? ev.target.closest('.js-podcast-ad-act') : null;
    if (actionBtn) {
      ev.preventDefault();
      ev.stopPropagation();
      var action = String(actionBtn.getAttribute('data-podcast-ad-action') || actionBtn.getAttribute('data-action') || '').trim();
      var adId = actionBtn.getAttribute('data-ad-id') || '';
      if (!adId && actionBtn.closest) {
        var parentRow = actionBtn.closest('[data-ad-id]');
        if (parentRow) { adId = parentRow.getAttribute('data-ad-id') || ''; }
      }
      runPodcastAdAction(action, parseInt(adId, 10), actionBtn);
      hideAllMenus();
      ev._podcastAdActionHandled = true;
      return;
    }

    var cancel = ev.target && ev.target.closest ? ev.target.closest('.pm-cancel') : null;
    if (cancel) {
      hideAllMenus();
      return;
    }

    var inside = ev.target && ev.target.closest ? ev.target.closest('.post-menu-popup') : null;
    var toggle = ev.target && ev.target.closest ? ev.target.closest('.js-podcast-ad-actions') : null;
    if (!inside && !toggle) {
      hideAllMenus();
    }
  });
})();

document.addEventListener("click", function(ev){
    var summary = ev.target.closest('details.admin-guide-item summary');
    if (!summary) { return; }
    var accordion = summary.closest('[data-smtp-guide]');
    if (!accordion) { return; }
    var current = summary.parentElement;
    if (!current) { return; }
    var open = current.hasAttribute('open');
    if (open) { return; }
    accordion.querySelectorAll('details.admin-guide-item[open]').forEach(function(item){
      if (item !== current) { item.removeAttribute('open'); }
    });
  });

// Contact reply form
(function(){
  var form = document.querySelector('form[data-action="contact-reply"]');
  if (!form) { return; }
  var section = form.closest('[data-contact-reply]');
  var submitBtn = form.querySelector('[data-role="contact-reply-submit"]');
  var successToast = section ? (section.getAttribute('data-toast-success') || adminLang('admin_contact_reply_success', 'Reply sent successfully.')) : adminLang('admin_contact_reply_success', 'Reply sent successfully.');
  var errorToast = section ? (section.getAttribute('data-toast-error') || adminLang('admin_contact_reply_error', 'Unable to send reply.')) : adminLang('admin_contact_reply_error', 'Unable to send reply.');
  var redirectUrl = section ? (section.getAttribute('data-redirect-url') || '') : '';
  if (!redirectUrl) {
    redirectUrl = adminRootUrl() + 'admin/index.php?page=contact_messages_all';
  }

  var statusPanel = section ? section.querySelector('[data-role="contact-reply-status"]') : null;
  var statusButtons = statusPanel ? Array.prototype.slice.call(statusPanel.querySelectorAll('[data-role="contact-reply-status-option"]')) : [];
  var statusSkip = statusPanel ? statusPanel.querySelector('[data-role="contact-reply-status-skip"]') : null;
  var messageId = section ? parseInt(section.getAttribute('data-message-id') || '0', 10) : 0;
  var replyCompleted = false;
  var statusBusy = false;
  var statusShown = false;
  var messageField = form.querySelector('#contact-reply-message');

  if (messageField && typeof initCmsEditor === 'function') {
    initCmsEditor(messageField);
  }

  if (statusSkip && section) {
    var skipLabel = section.getAttribute('data-status-skip-label');
    if (skipLabel) { statusSkip.textContent = skipLabel; }
  }

  function lockReplyFields() {
    Array.prototype.forEach.call(form.querySelectorAll('input, textarea, select, button'), function(el){
      if (!el || el === submitBtn || el.type === 'hidden') { return; }
      var tag = el.tagName;
      if (tag === 'TEXTAREA' || tag === 'INPUT') {
        try { el.readOnly = true; } catch (_) {}
      } else {
        try { el.disabled = true; } catch (_) {}
      }
    });
  }

  function revealStatusPanel() {
    if (!statusPanel) {
      setTimeout(function(){ window.location.href = redirectUrl; }, 900);
      return;
    }
    if (statusShown) { return; }
    statusShown = true;
    statusPanel.removeAttribute('hidden');
    statusPanel.setAttribute('data-visible', '1');
    try { statusPanel.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (_) {}
    if (statusButtons.length) {
      try { statusButtons[0].focus(); } catch (_) {}
    }
  }

  form.addEventListener('submit', function(ev){
    ev.preventDefault();
    if (replyCompleted) { return false; }
    if (submitBtn) { submitBtn.disabled = true; submitBtn.dataset.loading = 'true'; }
    var formData = new FormData(form);
    fetch(form.getAttribute('action') || (adminRootUrl() + 'admin/request/contact_email.php?action=reply_send'), {
      method: 'POST',
      body: formData
    }).then(function(res){ return res.json().catch(function(){ return {}; }); })
      .then(function(payload){
        if (payload && payload.status === 'success') {
          replyCompleted = true;
          adminToast(successToast, 'success');
          lockReplyFields();
          if (submitBtn) { submitBtn.disabled = true; }
          revealStatusPanel();
        } else {
          var msg = adminMsg(payload && payload.message) || errorToast;
          adminToast(msg, 'error');
        }
      })
      .catch(function(){ adminToast(errorToast, 'error'); })
      .finally(function(){
        if (submitBtn) {
          if (!replyCompleted) {
            submitBtn.disabled = false;
          } else {
            submitBtn.disabled = true;
          }
          delete submitBtn.dataset.loading;
        }
      });
    return false;
  });

  if (statusPanel && messageId) {
    statusPanel.addEventListener('click', function(ev){
      var btn = ev.target && ev.target.closest ? ev.target.closest('[data-role="contact-reply-status-option"]') : null;
      if (!btn) { return; }
      if (!replyCompleted || statusBusy) { return; }
      ev.preventDefault();
      var statusValue = String(btn.getAttribute('data-status-value') || '').toLowerCase();
      if (!statusValue) { return; }
      var csrf = getCsrf();
      if (!csrf) {
        adminToast(adminLang('admin_missing_csrf', 'Missing CSRF token.'), 'error');
        return;
      }
      statusBusy = true;
      var keepDisabled = false;
      btn.disabled = true;
      btn.dataset.loading = 'true';
      fetch(adminRootUrl() + 'admin/request/contact_email.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: toUrlEncoded({ action: 'set_status', message_id: messageId, status: statusValue, csrf_token: csrf })
      }).then(function(res){ return res.json().catch(function(){ return {}; }); })
        .then(function(payload){
          if (payload && payload.status === 'success') {
            keepDisabled = true;
            var toastKey = 'data-status-toast-' + statusValue;
            var toastMsg = section ? (section.getAttribute(toastKey) || successToast) : successToast;
            adminToast(toastMsg, 'success');
            var redirectKey = 'data-status-redirect-' + statusValue;
            var targetUrl = section ? (section.getAttribute(redirectKey) || redirectUrl) : redirectUrl;
            setTimeout(function(){ window.location.href = targetUrl || redirectUrl; }, 900);
          } else {
            var msg = adminMsg(payload && payload.message) || errorToast;
            adminToast(msg, 'error');
          }
        })
        .catch(function(){ adminToast(errorToast, 'error'); })
        .finally(function(){
          statusBusy = false;
          delete btn.dataset.loading;
          if (!keepDisabled) {
            btn.disabled = false;
          }
        });
    });
  }
  })();

  // Icon management modal (admin icons page)
  (function(){
    var table = document.querySelector('[data-icon-table]');
    if (!table) { return; }

    var dialogId = table.getAttribute('data-modal-target') || '';
    var dialog = dialogId ? document.getElementById(dialogId) : null;
    if (!dialog) { return; }

    var form = dialog.querySelector('[data-role="icon-edit-form"]');
    if (!form) { return; }

    var actionInput = form.querySelector('[data-field="icon-action"]');
    var idInput = form.querySelector('[data-field="icon-id"]');
    var keyInput = form.querySelector('[data-field="input-key"]');
    var uploadInput = form.querySelector('[data-field="input-upload"]');
    var keepInput = form.querySelector('[data-field="input-keep"]');
    var previewNode = form.querySelector('[data-field="preview"]');
    var publicLink = form.querySelector('[data-field="public"]');
    var createdField = form.querySelector('[data-field="created"]');
    var updatedField = form.querySelector('[data-field="updated"]');
    var aliasField = form.querySelector('[data-field="aliases"]');
    var titleField = form.querySelector('[data-field="icon-title"]');

    var closeButtons = dialog.querySelectorAll('[data-role="icon-close"]');
    var deleteButton = dialog.querySelector('[data-role="icon-delete"]');

    var urlDialog = document.querySelector('[data-role="icon-url-dialog"]');
    var urlTarget = urlDialog ? urlDialog.querySelector('[data-role="icon-url-target"]') : null;
    var urlOpenLink = urlDialog ? urlDialog.querySelector('[data-role="icon-url-open"]') : null;
    var urlCloseButtons = urlDialog ? urlDialog.querySelectorAll('[data-role="icon-url-close"]') : [];

    function resetUrlDialog() {
      if (!urlDialog) { return; }
      if (urlTarget) {
        urlTarget.textContent = '—';
        urlTarget.removeAttribute('href');
      }
      if (urlOpenLink) {
        urlOpenLink.setAttribute('href', '#');
      }
    }

    function closeUrlDialog() {
      if (!urlDialog) { return; }
      resetUrlDialog();
      if (typeof urlDialog.close === 'function') {
        try { urlDialog.close(); return; } catch(_) {}
      }
      urlDialog.removeAttribute('open');
    }

    function openUrlDialog(url) {
      if (!url) { return; }
      if (!urlDialog || !urlTarget || !urlOpenLink) {
        window.open(url, '_blank');
        return;
      }

      urlTarget.textContent = url;
      urlTarget.setAttribute('href', url);
      urlTarget.setAttribute('target', '_blank');
      urlTarget.setAttribute('rel', 'noopener');
      urlOpenLink.setAttribute('href', url);

      var opened = false;
      if (typeof urlDialog.showModal === 'function') {
        try { urlDialog.showModal(); opened = true; } catch(_) {}
      }
      if (!opened) {
        urlDialog.setAttribute('open', 'true');
      }
    }

    if (urlDialog) {
      urlDialog.addEventListener('cancel', function(ev){
        ev.preventDefault();
        closeUrlDialog();
      });
      urlDialog.addEventListener('close', function(){
        resetUrlDialog();
      });
    }

    urlCloseButtons.forEach(function(btn){
      btn.addEventListener('click', function(ev){
        ev.preventDefault();
        closeUrlDialog();
      });
    });

    table.addEventListener('click', function(ev){
      var urlTrigger = ev.target && ev.target.closest ? ev.target.closest('[data-role="icon-url"]') : null;
      if (!urlTrigger) { return; }
      ev.preventDefault();
      var url = urlTrigger.getAttribute('data-url') || '';
      if (!url) {
        var urlRow = urlTrigger.closest('[data-icon-row]');
        if (urlRow) {
          url = urlRow.getAttribute('data-icon-public') || '';
        }
      }
      if (!url) { return; }
      openUrlDialog(url);
    });
    var deleteConfirm = dialog.getAttribute('data-delete-confirm') || table.getAttribute('data-delete-confirm') || '';
    var headingBase = dialog.getAttribute('data-heading-base') || (titleField ? titleField.textContent : '');
    var noAliasesText = dialog.getAttribute('data-no-aliases') || '—';

    function renderAliases(list) {
      if (!aliasField) { return; }
      aliasField.innerHTML = '';
      if (!Array.isArray(list) || list.length === 0) {
        var emptyChip = document.createElement('span');
        emptyChip.className = 'icon-edit-dialog__alias icon-edit-dialog__alias--empty';
        emptyChip.textContent = noAliasesText;
        aliasField.appendChild(emptyChip);
        return;
      }
      list.forEach(function(name){
        if (!name) { return; }
        var chip = document.createElement('span');
        chip.className = 'icon-edit-dialog__alias';
        chip.textContent = String(name);
        aliasField.appendChild(chip);
      });
    }

    function parseAliasList(row) {
      if (!row) { return []; }
      var raw = row.getAttribute('data-icon-aliases') || '[]';
      try {
        var parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          return parsed.map(function(item){ return typeof item === 'string' ? item : ''; }).filter(function(item){ return item !== ''; });
        }
      } catch(_) {}
      if (typeof raw === 'string' && raw && raw !== '[]') {
        return raw.split(',').map(function(item){ return item.trim(); }).filter(function(item){ return item.length > 0; });
      }
      return [];
    }

    function hideMenu(iconId) {
      if (!iconId) { return; }
      var popup = document.getElementById('postMenuPopup-' + iconId);
      if (popup) {
        popup.classList.add('none');
        popup.setAttribute('aria-hidden', 'true');
      }
      var btn = table.querySelector('.post-settings-btn[data-id="' + iconId + '"]');
      if (btn) {
        btn.setAttribute('aria-expanded', 'false');
      }
    }

    function resetDialog() {
      if (typeof form.reset === 'function') {
        try { form.reset(); } catch(_){}
      }
      if (previewNode) { previewNode.innerHTML = ''; }
      if (publicLink) {
        publicLink.textContent = '—';
        publicLink.removeAttribute('href');
        publicLink.removeAttribute('target');
        publicLink.removeAttribute('rel');
        publicLink.removeAttribute('title');
      }
      if (createdField) { createdField.textContent = '—'; }
      if (updatedField) { updatedField.textContent = '—'; }
      renderAliases([]);
      if (titleField) { titleField.textContent = headingBase || ''; }
      if (actionInput) { actionInput.value = 'update'; }
    }

    function closeDialog() {
      if (typeof dialog.close === 'function') {
        try { dialog.close(); } catch(_) { dialog.removeAttribute('open'); }
      } else {
        dialog.removeAttribute('open');
      }
    }

    function openDialogFor(row) {
      if (!row) { return; }
      resetDialog();

      var iconId = row.getAttribute('data-icon-id') || '';
      if (idInput) { idInput.value = iconId; }

      var iconKey = row.getAttribute('data-icon-key') || '';
      if (keyInput) { keyInput.value = iconKey; }

      if (keepInput) { keepInput.checked = true; }
      if (uploadInput) {
        try { uploadInput.value = ''; } catch(_){}
      }

      if (titleField) {
        var headingText = headingBase || '';
        if (iconKey) {
          headingText = headingText ? (headingText + ' - ' + iconKey) : iconKey;
        }
        titleField.textContent = headingText || headingBase || iconKey;
      }

      if (previewNode) {
        var previewId = 'iconPreview-' + iconId;
        var source = document.getElementById(previewId);
        if (source) {
          previewNode.innerHTML = source.innerHTML;
        }
      }

      var publicUrl = row.getAttribute('data-icon-public') || '';
      if (publicLink) {
        publicLink.textContent = publicUrl || '—';
        if (publicUrl) {
          publicLink.setAttribute('href', publicUrl);
          publicLink.setAttribute('target', '_blank');
          publicLink.setAttribute('rel', 'noopener');
          publicLink.setAttribute('title', publicUrl);
        } else {
          publicLink.removeAttribute('href');
          publicLink.removeAttribute('target');
          publicLink.removeAttribute('rel');
          publicLink.removeAttribute('title');
        }
      }

      var created = row.getAttribute('data-icon-created') || '—';
      var updated = row.getAttribute('data-icon-updated') || '—';
      if (createdField) { createdField.textContent = created || '—'; }
      if (updatedField) { updatedField.textContent = updated || '—'; }

      renderAliases(parseAliasList(row));

      var opened = false;
      if (typeof dialog.showModal === 'function') {
        try { dialog.showModal(); opened = true; } catch(_){}
      }
      if (!opened) {
        dialog.setAttribute('open', 'true');
      }
      if (keyInput) {
        try { keyInput.focus(); keyInput.select(); } catch(_){}
      }
    }

    table.addEventListener('click', function(ev){
      var trigger = ev.target && ev.target.closest ? ev.target.closest('.js-icon-edit-trigger') : null;
      if (!trigger) { return; }
      ev.preventDefault();
      var iconId = trigger.getAttribute('data-icon-id');
      if (!iconId) { return; }
      hideMenu(iconId);
      var row = table.querySelector('tr[data-icon-id="' + iconId + '"]');
      if (!row) { return; }
      openDialogFor(row);
    });

    closeButtons.forEach(function(btn){
      btn.addEventListener('click', function(ev){
        ev.preventDefault();
        closeDialog();
      });
    });

    dialog.addEventListener('cancel', function(ev){
      ev.preventDefault();
      closeDialog();
    });

    dialog.addEventListener('close', function(){
      resetDialog();
    });

    form.addEventListener('submit', function(){
      if (actionInput && actionInput.value !== 'delete') {
        actionInput.value = 'update';
      }
    });

    if (deleteButton) {
      deleteButton.addEventListener('click', function(ev){
        ev.preventDefault();
        var proceed = function(){
          if (actionInput) { actionInput.value = 'delete'; }
          try { form.submit(); }
          catch(_) {
            form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
          }
        };
        if (typeof adminConfirm === 'function' && deleteConfirm) {
          adminConfirm(deleteConfirm).then(function(ok){ if (ok) { proceed(); } });
        } else if (!deleteConfirm || window.confirm(deleteConfirm)) {
          proceed();
        }
      });
    }
  })();

// Lightweight tooltip for data-tip elements (charts, etc.)
(function(){
  var tipEl;
  function ensure(){
    if (!tipEl){
      tipEl = document.createElement('div');
      tipEl.className = 'dz-tip';
      tipEl.style.position = 'fixed';
      tipEl.style.zIndex = '3002';
      tipEl.style.display = 'none';
      document.body.appendChild(tipEl);
    }
    return tipEl;
  }
  function show(text, x, y){
    var el = ensure();
    el.textContent = text || '';
    el.style.display = 'block';
    // basic viewport-aware placement
    var pad = 12;
    var nx = x + 12, ny = y + 12;
    // measure after text set
    var r = el.getBoundingClientRect();
    if (nx + r.width + pad > window.innerWidth) nx = x - r.width - 12;
    if (ny + r.height + pad > window.innerHeight) ny = y - r.height - 12;
    el.style.left = nx + 'px';
    el.style.top  = ny + 'px';
  }
  function hide(){ if (tipEl){ tipEl.style.display = 'none'; } }

  document.addEventListener('mouseover', function(e){
    var t = e.target && e.target.closest ? e.target.closest('[data-tip]') : null;
    if (!t) return;
    show(String(t.getAttribute('data-tip') || ''), e.clientX, e.clientY);
  });
  document.addEventListener('mousemove', function(e){
    if (!tipEl || tipEl.style.display !== 'block') return;
    var t = e.target && e.target.closest ? e.target.closest('[data-tip]') : null;
    if (!t) { hide(); return; }
    show(String(t.getAttribute('data-tip') || ''), e.clientX, e.clientY);
  });
  document.addEventListener('mouseout', function(e){
    var t = e.target && e.target.closest ? e.target.closest('[data-tip]') : null;
    if (t) hide();
  });
})();

function readJsonAttr(el, name){
  try { return JSON.parse(el.getAttribute(name) || 'null'); } catch(_) { return null; }
}

function initRevenueChart(){
  var cv = document.getElementById('revChart');
  if (!cv) return;
  var labels = readJsonAttr(cv, 'data-labels') || [];
  var subs   = readJsonAttr(cv, 'data-subs') || [];
  var tips   = readJsonAttr(cv, 'data-tips') || [];
  var ebooks = readJsonAttr(cv, 'data-ebooks') || [];
  var audioRoomTips = readJsonAttr(cv, 'data-audio-room-tips') || [];
  var audioRoomTickets = readJsonAttr(cv, 'data-audio-room-tickets') || [];
  var ctx = cv.getContext('2d');
  var subsLabel = adminLang('admin_chart_subscriptions', 'Subscriptions');
  var tipsLabel = adminLang('admin_chart_tips', 'Tips');
  var ebooksLabel = adminLang('admin_chart_ebooks', 'eBooks');
  var audioRoomTipsLabel = adminLang('admin_chart_audio_room_tips', 'Audio Room tips');
  var audioRoomTicketsLabel = adminLang('admin_chart_audio_room_tickets', 'Audio Room tickets');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [
        {
          label: subsLabel,
          data: subs,
          backgroundColor: 'rgba(31,75,216,0.25)',
          borderColor: '#1f4bd8',
          borderWidth: 1,
          borderRadius: 8,
          borderSkipped: false,
          maxBarThickness: 28,
        },
        {
          label: tipsLabel,
          data: tips,
          backgroundColor: 'rgba(255,107,96,0.25)',
          borderColor: '#ff6b60',
          borderWidth: 1,
          borderRadius: 8,
          borderSkipped: false,
          maxBarThickness: 28,
        },
        {
          label: ebooksLabel,
          data: ebooks,
          backgroundColor: 'rgba(36,184,199,0.25)',
          borderColor: '#24b8c7',
          borderWidth: 1,
          borderRadius: 8,
          borderSkipped: false,
          maxBarThickness: 28,
        },
        {
          label: audioRoomTipsLabel,
          data: audioRoomTips,
          backgroundColor: 'rgba(124,58,237,0.22)',
          borderColor: '#7c3aed',
          borderWidth: 1,
          borderRadius: 8,
          borderSkipped: false,
          maxBarThickness: 28,
        },
        {
          label: audioRoomTicketsLabel,
          data: audioRoomTickets,
          backgroundColor: 'rgba(217,119,6,0.22)',
          borderColor: '#d97706',
          borderWidth: 1,
          borderRadius: 8,
          borderSkipped: false,
          maxBarThickness: 28,
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      layout: { padding: { top: 8, bottom: 8 } },
      plugins: {
        legend: { display: true, position: 'bottom' },
        tooltip: { enabled: true }
      },
      scales: {
        x: { grid: { display: false }, stacked: false },
        y: { grid: { color: 'rgba(0,0,0,0.06)' }, beginAtZero: true }
      }
    }
  });
  var fb = cv.nextElementSibling; if (fb && fb.classList.contains('chart-fallback')) { fb.classList.add('is-hidden'); }
}

function initPostVisibilityChart(){
  var cv = document.getElementById('postVisChart');
  if (!cv) return;
  var data = readJsonAttr(cv, 'data-breakdown') || {};
  var labels = ['everyone','followers','subscribers','locked'];
  var vals = labels.map(function(k){ return data[k] || 0; });
  var ctx = cv.getContext('2d');
  var visibilityLabels = {
    everyone: adminLang('admin_visibility_everyone', 'Everyone'),
    followers: adminLang('admin_visibility_followers', 'Followers'),
    subscribers: adminLang('admin_visibility_subscribers', 'Subscribers'),
    locked: adminLang('admin_visibility_locked', 'Locked')
  };
  var totalLabel = adminLang('admin_chart_total', 'Total');
  var donutCenter = {
    id: 'donutCenterText',
    beforeDraw: function(chart){
      var width = chart.width, height = chart.height;
      var ctx = chart.ctx;
      var dataset = chart.data && chart.data.datasets && chart.data.datasets[0];
      var total = 0; if (dataset && Array.isArray(dataset.data)) { dataset.data.forEach(function(v){ total += (v||0); }); }
      ctx.save();
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#6b7280';
      ctx.font = '600 16px system-ui, -apple-system, Segoe UI, Roboto, sans-serif';
      ctx.fillText(totalLabel, width/2, height/2 - 8);
      ctx.fillStyle = '#111827';
      ctx.font = '700 18px system-ui, -apple-system, Segoe UI, Roboto, sans-serif';
      ctx.fillText(String(total), width/2, height/2 + 12);
      ctx.restore();
    }
  };
  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: labels.map(function(s){ return visibilityLabels[s] || (s.charAt(0).toUpperCase()+s.slice(1)); }),
      datasets: [{
        data: vals,
        backgroundColor: ['#f59e0b','#8b5cf6','#ef4444','#14b8a6'],
        borderWidth: 0,
        borderRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      layout: { padding: { top: 8, bottom: 8 } },
      plugins: { legend: { display: true, position: 'bottom' }, tooltip: { enabled: true } },
      cutout: '60%'
    },
    plugins: [donutCenter]
  });
  var fb = cv.nextElementSibling; if (fb && fb.classList.contains('chart-fallback')) { fb.classList.add('is-hidden'); }
}

document.addEventListener('click', function(ev){
  var btn = ev.target.closest('[data-ad-action]');
  if (!btn || btn.disabled) { return; }
  var action = String(btn.getAttribute('data-ad-action') || '').trim();
  var adId = parseInt(String(btn.getAttribute('data-ad-id') || '0'), 10);
  if (!action || !(adId > 0)) { return; }

  ev.preventDefault();

  if (action === 'delete') {
    var confirmMsg = adminLang('admin_ads_confirm_delete', 'Delete this advertisement?');
    if (!window.confirm(confirmMsg)) { return; }
  }

  if (action === 'edit') {
    var editUrl = btn.getAttribute('data-edit-url') || '';
    if (editUrl) {
      window.location.href = editUrl;
    } else {
      adminToast(adminLang('admin_invalid_target', 'Invalid target.'), 'error');
    }
    return;
  }

  var endpoint = adminRootUrl() + 'admin/request/advertisements.php';
  var payload = new URLSearchParams();
  payload.append('action', action);
  payload.append('ad_id', String(adId));
  payload.append('csrf_token', adminCsrfToken());

  btn.disabled = true;
  btn.setAttribute('aria-busy', 'true');

  fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
    body: payload.toString()
  })
    .then(function(r){ return r.json().catch(function(){ return {}; }); })
    .then(function(res){
      btn.disabled = false;
      btn.removeAttribute('aria-busy');
      if (!res || res.status !== 'success') {
        var err = adminMsg(res && res.message);
        if (!err) { err = adminLang('admin_ads_action_failed', 'Operation failed.'); }
        adminToast(err, 'error');
        return;
      }

      var successMsg;
      if (action === 'delete') {
        successMsg = adminLang('admin_ads_deleted', 'Advertisement deleted.');
      } else if (res.status_label) {
        successMsg = adminLang('admin_ads_status_updated', 'Status updated to {status}.', { status: res.status_label });
      } else {
        successMsg = adminLang('admin_ads_status_updated_generic', 'Advertisement updated.');
      }
      adminToast(successMsg, 'success');
      try { setTimeout(function(){ window.location.reload(); }, 600); } catch(_) {}
    })
    .catch(function(){
      btn.disabled = false;
      btn.removeAttribute('aria-busy');
      adminToast(adminLang('admin_network_error', 'Network error.'), 'error');
    });
});

// Podcast ad packages CRUD
(function(){
  var endpoint = adminRootUrl() + 'admin/request/podcast_ad_packages.php';
  var form = document.getElementById('podcastAdPackageForm');
  var langList = [];
  var defaultLang = '';
  var nameInputs = [];
  var descInputs = [];
  if (form) {
    try {
      var langsAttr = form.getAttribute('data-languages') || '[]';
      var parsedLangs = JSON.parse(langsAttr);
      if (Array.isArray(parsedLangs)) {
        langList = parsedLangs.map(function(l){ return String(l || '').toLowerCase(); }).filter(function(v){ return v !== ''; });
      }
    } catch (_) {}
    defaultLang = (form.getAttribute('data-default-lang') || '').toLowerCase() || (langList[0] || '');
    if (!defaultLang && langList.length) { defaultLang = String(langList[0] || '').toLowerCase(); }
    nameInputs = Array.prototype.slice.call(form.querySelectorAll('[data-package-name-lang]'));
    descInputs = Array.prototype.slice.call(form.querySelectorAll('[data-package-desc-lang]'));
  }

  function setPackageTranslations(map){
    nameInputs.forEach(function(inp){
      if (!inp) { return; }
      var lng = (inp.getAttribute('data-package-name-lang') || '').toLowerCase();
      var val = '';
      if (map && typeof map === 'object' && map.hasOwnProperty(lng)) {
        var entry = map[lng];
        if (entry && typeof entry === 'object' && entry.hasOwnProperty('name')) {
          val = entry.name || '';
        } else if (typeof entry === 'string') {
          val = entry;
        }
      } else if (defaultLang && map && typeof map === 'object' && map.hasOwnProperty(defaultLang)) {
        var defEntry = map[defaultLang];
        if (defEntry && typeof defEntry === 'object' && defEntry.hasOwnProperty('name')) {
          val = defEntry.name || '';
        } else if (typeof defEntry === 'string') {
          val = defEntry;
        }
      }
      inp.value = val || '';
    });
    descInputs.forEach(function(inp){
      if (!inp) { return; }
      var lng = (inp.getAttribute('data-package-desc-lang') || '').toLowerCase();
      var val = '';
      if (map && typeof map === 'object' && map.hasOwnProperty(lng)) {
        var entry = map[lng];
        if (entry && typeof entry === 'object' && entry.hasOwnProperty('description')) {
          val = entry.description || '';
        }
      } else if (defaultLang && map && typeof map === 'object' && map.hasOwnProperty(defaultLang)) {
        var defEntry = map[defaultLang];
        if (defEntry && typeof defEntry === 'object' && defEntry.hasOwnProperty('description')) {
          val = defEntry.description || '';
        }
      }
      inp.value = val || '';
    });
  }

  function resetPackageForm(){
    if (!form) { return; }
    try { form.reset(); } catch(_) {}
    var idField = form.querySelector('input[name="package_id"]');
    if (idField) { idField.value = ''; }
    setPackageTranslations({});
  }

  if (form) {
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var fd = new FormData(form);
      var btn = form.querySelector('[data-podcast-package-action=\"save\"]');
      if (btn) { btn.disabled = true; btn.setAttribute('aria-busy','true'); }
      fetch(endpoint, { method:'POST', body: fd, credentials:'same-origin' })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
          if (!res || res.status !== 'success') {
            adminToast(adminMsg(res && res.message) || adminLang('admin_ads_action_failed', 'Operation failed.'), 'error');
            return;
          }
          adminToast(adminMsg(res.message) || adminLang('hero_ads_package_saved', 'Package saved.'), 'success');
          try { setTimeout(function(){ window.location.reload(); }, 400); } catch(_) {}
        })
        .catch(function(){
          adminToast(adminLang('admin_network_error', 'Network error.'), 'error');
        })
        .finally(function(){
          if (btn) { btn.disabled = false; btn.removeAttribute('aria-busy'); }
        });
    });
  }

  document.addEventListener('click', function(ev){
    var resetBtn = ev.target.closest('[data-podcast-package-action=\"reset\"]');
    if (!resetBtn) { return; }
    ev.preventDefault();
    resetPackageForm();
  });

  document.addEventListener('click', function(ev){
    var btn = ev.target.closest('[data-podcast-package-action=\"delete\"]');
    if (!btn) { return; }
    ev.preventDefault();
    var pid = parseInt(String(btn.getAttribute('data-package-id') || '0'), 10);
    if (!(pid > 0)) { return; }
    var confirmMsg = adminLang('hero_ads_package_confirm_delete', 'Delete this package? All translations will be removed.');
    var proceedDelete = function(){
      var fd = new FormData();
      fd.append('action','delete');
      fd.append('package_id', String(pid));
      fd.append('csrf_token', adminCsrfToken());
      btn.disabled = true;
      btn.setAttribute('aria-busy','true');
      fetch(endpoint, { method:'POST', body: fd, credentials:'same-origin' })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
          if (!res || res.status !== 'success') {
            adminToast(adminMsg(res && res.message) || adminLang('admin_ads_action_failed', 'Operation failed.'), 'error');
            return;
          }
          adminToast(adminLang('hero_ads_package_deleted', 'Package deleted.'), 'success');
          try { setTimeout(function(){ window.location.reload(); }, 400); } catch(_) {}
        })
        .catch(function(){
          adminToast(adminLang('admin_network_error', 'Network error.'), 'error');
        })
        .finally(function(){
          btn.disabled = false;
          btn.removeAttribute('aria-busy');
        });
    };

    if (typeof adminConfirm === 'function') {
      adminConfirm(confirmMsg).then(function(ok){ if (ok) { proceedDelete(); } });
    }
  });

  document.addEventListener('click', function(ev){
    var btn = ev.target.closest('[data-podcast-package-edit]');
    if (!btn || !form) { return; }
    ev.preventDefault();
    var map = {
      package_id: 'package-id',
      price: 'package-price',
      currency: 'package-currency',
      duration_days: 'package-duration',
      daily_cap: 'package-daily',
      total_cap: 'package-total',
      premium_multiplier: 'package-premium',
      targeting_fee: 'package-targeting',
      status: 'package-status',
      sort_order: 'package-sort'
    };
    Object.keys(map).forEach(function(key){
      var target = form.querySelector('[name=\"' + key + '\"]');
      var attr = map[key];
      var val = btn.getAttribute('data-' + attr);
      if (!target) { return; }
      if (target.tagName === 'SELECT') {
        target.value = val || '';
      } else {
        target.value = val || '';
      }
    });
    var translationsRaw = btn.getAttribute('data-package-translations') || '{}';
    var translations = {};
    try {
      var parsed = JSON.parse(translationsRaw);
      if (parsed && typeof parsed === 'object') {
        translations = parsed;
      }
    } catch (_) {}
    setPackageTranslations(translations);
  });
})();

// Podcast hero ads moderation (separate endpoint to avoid conflicting with standard ads)
function runPodcastAdAction(action, adId, btn){
  action = String(action || '').trim().toLowerCase();
  adId = parseInt(adId, 10) || 0;
  if (!action || !(adId > 0)) {
    adminToast(adminLang('admin_operation_failed_reason', 'Operation failed.'), 'error');
    return;
  }
  if (action === 'delete') {
    var confirmMsg = adminLang('hero_ads_confirm_delete', 'Delete this ad?');
    if (!window.confirm(confirmMsg)) { return; }
  }

  var endpoint = adminRootUrl() + 'admin/request/podcast_ads.php';
  var fd = new FormData();
  fd.append('action', action);
  fd.append('ad_id', String(adId));
  fd.append('csrf_token', adminCsrfToken());

  if (btn) {
    btn.disabled = true;
    btn.setAttribute('aria-busy', 'true');
  }

  fetch(endpoint, {
    method: 'POST',
    body: fd,
    credentials: 'same-origin'
  })
    .then(function(r){ return r.json().catch(function(){ return {}; }); })
    .then(function(res){
      if (btn) {
        btn.disabled = false;
        btn.removeAttribute('aria-busy');
      }
      if (!res || res.status !== 'success') {
        var err = adminMsg(res && res.message);
        if (!err) { err = adminLang('admin_ads_action_failed', 'Operation failed.'); }
        adminToast(err, 'error');
        return;
      }
      var stateLabel = res.state || res.status_label || '';
      var successMsg;
      if (action === 'delete') {
        successMsg = adminLang('hero_ads_action_delete', 'Ad deleted.');
      } else if (stateLabel) {
        successMsg = adminLang('admin_ads_status_updated', 'Status updated to {status}.', { status: stateLabel });
      } else {
        successMsg = adminLang('admin_ads_status_updated_generic', 'Advertisement updated.');
      }
      adminToast(successMsg, 'success');
      try { setTimeout(function(){ window.location.reload(); }, 500); } catch(_) {}
    })
    .catch(function(){
      if (btn) {
        btn.disabled = false;
        btn.removeAttribute('aria-busy');
      }
      adminToast(adminLang('admin_network_error', 'Network error.'), 'error');
    });
}

document.addEventListener('click', function(ev){
  if (ev && ev._podcastAdActionHandled) { return; }
  var btn = ev.target.closest('[data-podcast-ad-action]');
  if (!btn || btn.disabled) { return; }
  ev.preventDefault();
  var action = String(btn.getAttribute('data-podcast-ad-action') || '').trim();
  var adIdAttr = btn.getAttribute('data-ad-id') || '';
  if (!adIdAttr && btn.closest) {
    var row = btn.closest('[data-ad-id]');
    if (row) { adIdAttr = row.getAttribute('data-ad-id') || ''; }
  }
  var adId = parseInt(String(adIdAttr || '0'), 10);
  runPodcastAdAction(action, adId, btn);
});

// Explicitly bind podcast ad actions without inline JS (CSP-safe)
(function(){
  function safeLang(key, fallback, params){
    return typeof adminLang === 'function' ? adminLang(key, fallback, params) : (fallback || '');
  }
  function safeMsg(msg){
    return typeof adminMsg === 'function' ? adminMsg(msg) : (msg || '');
  }
  function safeToast(msg, type){
    if (typeof adminToast === 'function') { adminToast(msg, type); return; }
    if (window.console && msg) { console.warn(msg); }
  }
  function resolveCsrf(){
    if (typeof adminCsrfToken === 'function') { return adminCsrfToken(); }
    var meta = document.querySelector('meta[name="admin-csrf"]');
    return meta ? (meta.getAttribute('content') || '') : '';
  }
  function resolveRoot(){
    if (typeof adminRootUrl === 'function') { return adminRootUrl(); }
    var o = window.location.origin || (window.location.protocol + '//' + window.location.host);
    var p = window.location.pathname || '/';
    return (o + p).replace(/\/admin\/.*/, '/');
  }
  function fallbackAction(action, adId, btn){
    action = String(action || '').trim().toLowerCase();
    adId = parseInt(adId, 10) || 0;
    if (!action || adId <= 0) {
      safeToast(safeLang('admin_operation_failed_reason', 'Operation failed.'), 'error');
      return;
    }
    if (action === 'delete') {
      var confirmMsg = safeLang('hero_ads_confirm_delete', 'Delete this ad?');
      if (!window.confirm(confirmMsg)) { return; }
    }
    if (btn) {
      btn.disabled = true;
      btn.setAttribute('aria-busy', 'true');
    }
    var fd = new FormData();
    fd.append('action', action);
    fd.append('ad_id', String(adId));
    fd.append('csrf_token', resolveCsrf());
    fetch(resolveRoot() + 'admin/request/podcast_ads.php', {
      method: 'POST',
      body: fd,
      credentials: 'same-origin'
    })
      .then(function(r){ return r.json().catch(function(){ return {}; }); })
      .then(function(res){
        if (btn) {
          btn.disabled = false;
          btn.removeAttribute('aria-busy');
        }
        if (!res || res.status !== 'success') {
          var err = safeMsg(res && res.message);
          if (!err) { err = safeLang('admin_ads_action_failed', 'Operation failed.'); }
          safeToast(err, 'error');
          return;
        }
        var stateLabel = res.state || res.status_label || '';
        var successMsg;
        if (action === 'delete') {
          successMsg = safeLang('hero_ads_action_delete', 'Ad deleted.');
        } else if (stateLabel) {
          successMsg = safeLang('admin_ads_status_updated', 'Status updated to {status}.', { status: stateLabel });
        } else {
          successMsg = safeLang('admin_ads_status_updated_generic', 'Advertisement updated.');
        }
        safeToast(successMsg, 'success');
        try { setTimeout(function(){ window.location.reload(); }, 500); } catch(_){}
      })
      .catch(function(){
        if (btn) {
          btn.disabled = false;
          btn.removeAttribute('aria-busy');
        }
        safeToast(safeLang('admin_network_error', 'Network error.'), 'error');
      });
  }
  function handle(ev){
    if (ev && ev._podcastAdActionHandled) { return; }
    var btn = ev.target && ev.target.closest ? ev.target.closest('.js-podcast-ad-act, [data-podcast-ad-action]') : null;
    if (!btn || btn.disabled) { return; }
    ev.preventDefault();
    ev.stopPropagation();
    var action = (btn.getAttribute('data-podcast-ad-action') || btn.getAttribute('data-action') || '').trim();
    var adIdAttr = btn.getAttribute('data-ad-id') || '';
    if (!adIdAttr && btn.closest) {
      var row = btn.closest('[data-ad-id]');
      if (row) { adIdAttr = row.getAttribute('data-ad-id') || ''; }
    }
    var adId = parseInt(String(adIdAttr || '0'), 10);
    if (typeof runPodcastAdAction === 'function') {
      runPodcastAdAction(action, adId, btn);
    } else {
      fallbackAction(action, adId, btn);
    }
    ev._podcastAdActionHandled = true;
  }
  function bind(){
    var wrap = document.getElementById('podcastAdsTableWrapper');
    if (wrap) {
      wrap.addEventListener('click', handle, true);
    }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind);
  } else {
    bind();
  }
})();

(function(){
  function updateMediaEmptyState(list, emptyEl) {
    if (!emptyEl) { return; }
    var total = list ? list.querySelectorAll('[data-sortable-item]').length : 0;
    emptyEl.hidden = total > 0;
  }

  function appendMediaItem(list, removeLabel, path, url) {
    if (!list || !path) { return; }
    var item = document.createElement('li');
    item.className = 'admin-ad-edit__media-item';
    item.setAttribute('data-sortable-item', '');
    item.setAttribute('draggable', 'true');

    var hidden = document.createElement('input');
    hidden.type = 'hidden';
    hidden.name = 'media[]';
    hidden.value = path;
    item.appendChild(hidden);

    var handle = document.createElement('span');
    handle.className = 'admin-ad-edit__media-handle';
    handle.setAttribute('aria-hidden', 'true');
    handle.innerHTML = '&#9776;';
    item.appendChild(handle);

    var img = document.createElement('img');
    img.src = url || path;
    img.alt = '';
    img.loading = 'lazy';
    item.appendChild(img);

    var removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'admin-ad-edit__media-remove';
    removeBtn.setAttribute('data-remove-media', '');
    removeBtn.setAttribute('aria-label', removeLabel);
    removeBtn.innerHTML = '&times;';
    item.appendChild(removeBtn);

    list.appendChild(item);
  }

  function initAdminAdvertisementEdit(form) {
    if (!form || typeof window.fetch !== 'function') {
      return;
    }

    var mediaType = String(form.getAttribute('data-ad-media-type') || '').toLowerCase();
    var requestUrl = String(form.getAttribute('action') || '');
    var uploadUrl = String(form.getAttribute('data-upload-url') || requestUrl);
    var submitBtn = form.querySelector('[data-ad-save]');
    var adIdInput = form.querySelector('input[name="ad_id"]');
    var csrfInput = form.querySelector('input[name="csrf_token"]');
    var mediaManager = form.querySelector('[data-ad-media-manager]');
    var mediaList = mediaManager ? mediaManager.querySelector('[data-ad-media-list]') : null;
    var emptyEl = mediaManager ? mediaManager.querySelector('[data-ad-media-empty]') : null;
    var addBtn = mediaManager ? mediaManager.querySelector('[data-ad-media-add]') : null;
    var fileInput = mediaManager ? mediaManager.querySelector('[data-ad-media-input]') : null;

    function getAdId() {
      return adIdInput ? String(adIdInput.value || '') : '';
    }

    function getCsrf() {
      return csrfInput ? String(csrfInput.value || '') : adminCsrfToken();
    }

    if (mediaManager && mediaType === 'image') {
      if (addBtn && fileInput) {
        addBtn.addEventListener('click', function(ev){
          ev.preventDefault();
          if (!addBtn.disabled) {
            fileInput.click();
          }
        });
      }

      var fileQueue = [];
      var activeCropper = null;

      function resetFileInput(){
        if (fileInput) {
          try { fileInput.value = ''; } catch(_) {}
        }
      }

      function dequeueNextFile() {
        if (!fileQueue.length) {
          activeCropper = null;
          return;
        }
        var next = fileQueue.shift();
        var reader = new FileReader();
        reader.onload = function(){
          var dataUrl = reader.result;
          activeCropper = openAdminAdImageCropperOverlay(dataUrl, {
            title: adminLang('admin_ads_edit_popup_title', 'Add new ads image'),
            onCancel: function(){
              activeCropper = null;
              dequeueNextFile();
            },
            onSubmit: function(canvas, done){
              if (!uploadUrl) {
                adminToast(adminLang('admin_invalid_target', 'Invalid target.'), 'error');
                if (typeof done === 'function') done();
                if (activeCropper) { activeCropper.close(); activeCropper = null; }
                dequeueNextFile();
                return;
              }

              canvas.toBlob(function(blob){
                if (!blob) {
                  adminToast(adminLang('admin_upload_failed', 'Upload failed.'), 'error');
                  if (typeof done === 'function') done();
                  return;
                }

                var fd = new FormData();
                fd.append('action', 'upload_images');
                fd.append('ad_id', getAdId());
                fd.append('csrf_token', getCsrf());

                var ext = (blob.type === 'image/png') ? 'png' : 'jpg';
                var safeName = (next && next.name) ? String(next.name) : '';
                if (!safeName || !/\.(png|jpe?g)$/i.test(safeName)) {
                  safeName = 'ad-image-' + Date.now();
                } else {
                  safeName = safeName.replace(/[^a-z0-9_.-]+/gi, '_').replace(/_{2,}/g, '_');
                }
                if (!safeName.toLowerCase().endsWith('.png') && !safeName.toLowerCase().endsWith('.jpg') && !safeName.toLowerCase().endsWith('.jpeg')) {
                  safeName += '.' + ext;
                }

                try {
                  var file = new File([blob], safeName, { type: blob.type || 'image/jpeg' });
                  fd.append('images[]', file);
                } catch(_) {
                  fd.append('images[]', blob, safeName);
                }

                if (addBtn) {
                  addBtn.disabled = true;
                  addBtn.setAttribute('aria-busy', 'true');
                }
                if (activeCropper) {
                  activeCropper.setBusy(true);
                }

                fetch(uploadUrl, { method: 'POST', body: fd })
                  .then(function(r){ return r.json().catch(function(){ return {}; }); })
                  .then(function(res){
                    if (addBtn) {
                      addBtn.disabled = false;
                      addBtn.removeAttribute('aria-busy');
                    }
                    if (activeCropper) {
                      activeCropper.setBusy(false);
                      activeCropper.close();
                      activeCropper = null;
                    }
                    if (typeof done === 'function') done();

                    if (!res || res.status !== 'success') {
                      var fail = adminMsg(res && res.message);
                      if (!fail) { fail = adminLang('admin_upload_failed', 'Upload failed.'); }
                      adminToast(adminLang('admin_upload_failed_reason', 'Upload failed: {reason}', { reason: fail }), 'error');
                      dequeueNextFile();
                      return;
                    }

                    var items = Array.isArray(res.items) ? res.items : [];
                    if (!items.length && Array.isArray(res.media_paths)) {
                      items = res.media_paths.map(function(path){
                        return { path: path, url: path };
                      });
                    }

                    if (!items.length) {
                      adminToast(adminLang('admin_upload_failed', 'Upload failed.'), 'error');
                      dequeueNextFile();
                      return;
                    }

                    if (mediaList) {
                      var removeLabel = adminLang('admin_ads_edit_media_remove', 'Remove image');
                      items.forEach(function(item){
                        var path = item && item.path ? String(item.path) : '';
                        var url = item && item.url ? String(item.url) : path;
                        if (!path) { return; }
                        appendMediaItem(mediaList, removeLabel, path, url);
                      });
                      updateMediaEmptyState(mediaList, emptyEl);
                    }

                    adminToast(adminLang('admin_image_uploaded', 'Image uploaded.'), 'success');
                    dequeueNextFile();
                  })
                  .catch(function(){
                    if (addBtn) {
                      addBtn.disabled = false;
                      addBtn.removeAttribute('aria-busy');
                    }
                    if (activeCropper) {
                      activeCropper.setBusy(false);
                    }
                    if (typeof done === 'function') done();
                    adminToast(adminLang('admin_network_error_short', 'Network error'), 'error');
                    dequeueNextFile();
                  });
              }, 'image/jpeg', 0.92);
            }
          });
        };
        reader.onerror = function(){
          adminToast(adminLang('admin_upload_failed', 'Upload failed.'), 'error');
          dequeueNextFile();
        };
        reader.readAsDataURL(next);
      }

      if (fileInput) {
        fileInput.addEventListener('change', function(){
          var files = fileInput.files ? Array.prototype.slice.call(fileInput.files) : [];
          resetFileInput();
          if (!files.length) {
            return;
          }
          files.forEach(function(file){
            if (file && /^image\//i.test(file.type)) {
              fileQueue.push(file);
            }
          });
          if (!activeCropper) {
            dequeueNextFile();
          }
        });
      }

      mediaManager.addEventListener('click', function(ev){
        var removeBtn = ev.target.closest('[data-remove-media]');
        if (!removeBtn || removeBtn.disabled) {
          return;
        }
        ev.preventDefault();

        var item = removeBtn.closest('[data-sortable-item]');
        if (!item) {
          return;
        }

        var hiddenInput = item.querySelector('input[name="media[]"]');
        var mediaValue = hiddenInput ? String(hiddenInput.value || '') : '';
        if (mediaValue === '') {
          item.remove();
          updateMediaEmptyState(mediaList, emptyEl);
          return;
        }

        if (!uploadUrl) {
          adminToast(adminLang('admin_invalid_target', 'Invalid target.'), 'error');
          return;
        }

        removeBtn.disabled = true;
        removeBtn.setAttribute('aria-busy', 'true');

        var confirmOverlay = openAdminAdConfirmOverlay({
          title: adminLang('admin_ads_edit_media_remove', 'Remove image'),
          message: adminLang('admin_ads_edit_media_confirm', 'Remove this image?'),
          confirmLabel: adminLang('admin_ads_edit_media_remove_confirm', 'Remove'),
          cancelLabel: adminLang('cancel', 'Cancel'),
          onCancel: function(){
            removeBtn.disabled = false;
            removeBtn.removeAttribute('aria-busy');
          },
          onConfirm: function(ctrl){
            ctrl.setBusy(true, adminLang('admin_ads_edit_media_removing', 'Removing...'));

            var fd = new FormData();
            fd.append('action', 'remove_media');
            fd.append('ad_id', getAdId());
            fd.append('csrf_token', getCsrf());
            fd.append('media_path', mediaValue);

            fetch(uploadUrl, { method: 'POST', body: fd })
              .then(function(r){ return r.json().catch(function(){ return {}; }); })
              .then(function(res){
                if (!res || res.status !== 'success') {
                  var fail = adminMsg(res && res.message);
                  if (!fail) { fail = adminLang('admin_ads_edit_media_remove_error', 'Unable to remove image.'); }
                  ctrl.setBusy(false);
                  removeBtn.disabled = false;
                  removeBtn.removeAttribute('aria-busy');
                  adminToast(fail, 'error');
                  return;
                }

                ctrl.close();
                item.remove();
                updateMediaEmptyState(mediaList, emptyEl);
                adminToast(adminLang('admin_ads_edit_media_removed', 'Image removed.'), 'success');
              })
              .catch(function(){
                ctrl.setBusy(false);
                removeBtn.disabled = false;
                removeBtn.removeAttribute('aria-busy');
                adminToast(adminLang('admin_network_error_short', 'Network error'), 'error');
              });
          }
        });
      });

      updateMediaEmptyState(mediaList, emptyEl);
    }

    form.addEventListener('submit', function(ev){
      ev.preventDefault();

      var fd = new FormData(form);
      fd.set('csrf_token', getCsrf());
      if (!fd.get('action')) {
        fd.set('action', 'update');
      }
      if (!fd.get('ad_id')) {
        fd.set('ad_id', getAdId());
      }

      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.setAttribute('aria-busy', 'true');
      }

      fetch(requestUrl || window.location.href, { method: 'POST', body: fd })
        .then(function(r){ return r.json().catch(function(){ return {}; }); })
        .then(function(res){
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.removeAttribute('aria-busy');
          }

          if (!res || res.status !== 'success') {
            var fail = adminMsg(res && res.message);
            if (!fail) { fail = adminLang('admin_save_failed_generic', 'Save failed.'); }
            adminToast(adminLang('admin_save_failed_with_reason', 'Save failed: {reason}', { reason: fail }), 'error');
            return;
          }

          var success = res.message ? adminMsg(res.message) : adminLang('admin_ads_edit_saved', 'Advertisement updated.');
          adminToast(success, 'success');
          if (res.redirect) {
            try { setTimeout(function(){ window.location.href = res.redirect; }, 600); } catch (_) {}
          }
        })
        .catch(function(){
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.removeAttribute('aria-busy');
          }
          adminToast(adminLang('admin_network_error_short', 'Network error'), 'error');
        });
    });
  }

  document.addEventListener('DOMContentLoaded', function(){
    var form = document.querySelector('form[data-action="save-advertisement"]');
    if (form) {
      initAdminAdvertisementEdit(form);
    }
  });
})();

function openAdminAdImageCropperOverlay(dataUrl, options) {
  options = options || {};
  var titleText = String(options.title || 'Add new ads image');
  var previousOverflow = document.body.style.overflow;
  document.body.style.overflow = 'hidden';

  var overlay = document.createElement('div');
  overlay.className = 'admin-ad-crop';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.tabIndex = -1;
  overlay.innerHTML = '' +
    '<div class="admin-ad-crop__dialog" role="document">' +
      '<div class="admin-ad-crop__header">' +
        '<button type="button" class="admin-ad-crop__btn admin-ad-crop__btn--ghost" data-action="cancel">' + adminLang('cancel', 'Cancel') + '</button>' +
        '<div class="admin-ad-crop__title">' + adminLang('admin_ads_edit_popup_title', titleText) + '</div>' +
        '<button type="button" class="admin-ad-crop__btn admin-ad-crop__btn--primary" data-action="confirm">' + adminLang('upload', 'Upload') + '</button>' +
      '</div>' +
      '<div class="admin-ad-crop__body">' +
        '<div class="admin-ad-crop__frame">' +
          '<div class="admin-ad-crop__viewport">' +
            '<img class="admin-ad-crop__image" alt="" draggable="false" />' +
          '</div>' +
        '</div>' +
        '<input type="range" class="admin-ad-crop__zoom" min="1" max="3" step="0.01" value="1" aria-label="Zoom" />' +
      '</div>' +
    '</div>';

  var image = overlay.querySelector('.admin-ad-crop__image');
  image.src = dataUrl;
  document.body.appendChild(overlay);
  try { overlay.focus(); } catch(_) {}

  var frame = overlay.querySelector('.admin-ad-crop__frame');
  var viewport = overlay.querySelector('.admin-ad-crop__viewport');
  var zoomInput = overlay.querySelector('.admin-ad-crop__zoom');
  var cancelBtn = overlay.querySelector('[data-action="cancel"]');
  var confirmBtn = overlay.querySelector('[data-action="confirm"]');

  var state = { baseScale: 1, zoom: 1, left: 0, top: 0, naturalW: 0, naturalH: 0 };
  var resizeHandler = null;
  var busy = false;

  function applyPosition() {
    image.style.transform = 'translate(' + state.left + 'px, ' + state.top + 'px) scale(1)';
  }

  function updateDimensions() {
    var fw = frame.clientWidth;
    var fh = frame.clientHeight;
    var iw = image.naturalWidth;
    var ih = image.naturalHeight;
    state.naturalW = iw;
    state.naturalH = ih;
    var scale = Math.max(fw / iw, fh / ih);
    state.baseScale = scale;
    state.zoom = 1;
    var dw = iw * scale;
    var dh = ih * scale;
    state.left = (fw - dw) / 2;
    state.top = (fh - dh) / 2;
    image.style.width = dw + 'px';
    image.style.height = dh + 'px';
    applyPosition();
  }

  function enforceBounds() {
    var fw = frame.clientWidth;
    var fh = frame.clientHeight;
    var dw = parseFloat(image.style.width) || 0;
    var dh = parseFloat(image.style.height) || 0;

    if (dw < fw) { dw = fw; image.style.width = dw + 'px'; state.baseScale = dw / state.naturalW / state.zoom; }
    if (dh < fh) { dh = fh; image.style.height = dh + 'px'; state.baseScale = dh / state.naturalH / state.zoom; }

    if (state.left > 0) { state.left = 0; }
    if (state.top > 0) { state.top = 0; }
    if (state.left + dw < fw) { state.left = fw - dw; }
    if (state.top + dh < fh) { state.top = fh - dh; }

    applyPosition();
  }

  image.addEventListener('load', function(){
    updateDimensions();
    enforceBounds();
    resizeHandler = function(){
      updateDimensions();
      enforceBounds();
    };
    try { window.addEventListener('resize', resizeHandler, { passive: true }); } catch (_) { window.addEventListener('resize', resizeHandler); }
  }, { once: true });

  // Dragging
  (function(){
    var dragging = false;
    var startX = 0;
    var startY = 0;
    var startLeft = 0;
    var startTop = 0;

    function onMove(ev) {
      if (!dragging) { return; }
      ev.preventDefault();
      var point = ev.touches ? ev.touches[0] : ev;
      var dx = point.pageX - startX;
      var dy = point.pageY - startY;
      state.left = startLeft + dx;
      state.top = startTop + dy;
      applyPosition();
      enforceBounds();
    }

    function onUp() {
      dragging = false;
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      document.removeEventListener('touchmove', onMove, { passive: false });
      document.removeEventListener('touchend', onUp);
    }

    image.addEventListener('mousedown', function(ev){
      ev.preventDefault();
      dragging = true;
      startX = ev.pageX;
      startY = ev.pageY;
      startLeft = state.left;
      startTop = state.top;
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });

    image.addEventListener('touchstart', function(ev){
      dragging = true;
      var p = ev.touches[0];
      startX = p.pageX;
      startY = p.pageY;
      startLeft = state.left;
      startTop = state.top;
      document.addEventListener('touchmove', onMove, { passive: false });
      document.addEventListener('touchend', onUp);
    }, { passive: true });
  })();

  zoomInput.addEventListener('input', function(){
    var prevW = parseFloat(image.style.width) || 0;
    var prevH = parseFloat(image.style.height) || 0;
    state.zoom = parseFloat(zoomInput.value) || 1;
    var dw = state.naturalW * state.baseScale * state.zoom;
    var dh = state.naturalH * state.baseScale * state.zoom;
    state.left = state.left - (dw - prevW) / 2;
    state.top = state.top - (dh - prevH) / 2;
    image.style.width = dw + 'px';
    image.style.height = dh + 'px';
    applyPosition();
    enforceBounds();
  });

  function doCrop(){
    var fw = viewport.clientWidth;
    var fh = viewport.clientHeight;
    var s = state.baseScale * state.zoom;
    var srcX = Math.max(0, -state.left) / s;
    var srcY = Math.max(0, -state.top) / s;
    var srcW = fw / s;
    var srcH = fh / s;
    if (srcX + srcW > state.naturalW) { srcX = state.naturalW - srcW; }
    if (srcY + srcH > state.naturalH) { srcY = state.naturalH - srcH; }
    if (srcX < 0) { srcX = 0; }
    if (srcY < 0) { srcY = 0; }

    var canvas = document.createElement('canvas');
    canvas.width = 1080;
    canvas.height = 1080;
    var ctx = canvas.getContext('2d');
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(image, srcX, srcY, srcW, srcH, 0, 0, canvas.width, canvas.height);
    return canvas;
  }

  function closeOverlay(){
    if (resizeHandler) {
      window.removeEventListener('resize', resizeHandler);
      resizeHandler = null;
    }
    document.body.style.overflow = previousOverflow || '';
    if (overlay && overlay.parentNode) {
      overlay.parentNode.removeChild(overlay);
    }
    if (typeof options.onClose === 'function') {
      options.onClose();
    }
  }

  function cancelFlow(){
    closeOverlay();
    if (typeof options.onCancel === 'function') {
      options.onCancel();
    }
  }

  cancelBtn.addEventListener('click', function(ev){ ev.preventDefault(); if (!busy) cancelFlow(); });
  overlay.addEventListener('click', function(ev){ if (ev.target === overlay) { ev.preventDefault(); ev.stopPropagation(); } });
  try {
    overlay.addEventListener('keydown', function(ev){ if (ev.key === 'Escape') { ev.preventDefault(); } });
  } catch(_) {}

  confirmBtn.addEventListener('click', function(ev){
    ev.preventDefault();
    if (busy) { return; }
    var canvas = doCrop();
    busy = true;
    confirmBtn.disabled = true;
    confirmBtn.setAttribute('aria-busy', 'true');
    confirmBtn.textContent = adminLang('ui_uploading_images', 'Uploading images...');
    if (typeof options.onSubmit === 'function') {
      var doneOnce = false;
      options.onSubmit(canvas, function(){
        if (doneOnce) { return; }
        doneOnce = true;
        busy = false;
        confirmBtn.disabled = false;
        confirmBtn.removeAttribute('aria-busy');
        confirmBtn.textContent = adminLang('upload', 'Upload');
      });
    }
  });

  return {
    close: function(){ busy = false; closeOverlay(); },
    setBusy: function(flag){
      busy = !!flag;
      if (flag) {
        confirmBtn.disabled = true;
        confirmBtn.setAttribute('aria-busy', 'true');
        confirmBtn.textContent = adminLang('ui_uploading_images', 'Uploading images...');
      } else {
        confirmBtn.disabled = false;
        confirmBtn.removeAttribute('aria-busy');
        confirmBtn.textContent = adminLang('upload', 'Upload');
      }
    }
  };
}

function openAdminAdConfirmOverlay(options) {
  options = options || {};
  var prevOverflow = document.body.style.overflow;
  document.body.style.overflow = 'hidden';

  var overlay = document.createElement('div');
  overlay.className = 'admin-confirm';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.tabIndex = -1;

  var titleText = options.title || adminLang('admin_confirm_title', 'Confirm');
  var messageText = options.message || adminLang('admin_confirm_message', 'Are you sure?');
  var confirmText = options.confirmLabel || adminLang('confirm', 'Confirm');
  var cancelText = options.cancelLabel || adminLang('cancel', 'Cancel');

  overlay.innerHTML = '' +
    '<div class="admin-confirm__dialog" role="document">' +
      '<div class="admin-confirm__body">' +
        '<div class="admin-confirm__title">' + titleText + '</div>' +
        '<p class="admin-confirm__message">' + messageText + '</p>' +
      '</div>' +
      '<div class="admin-confirm__actions">' +
        '<button type="button" class="admin-confirm__btn admin-confirm__btn--ghost" data-action="cancel">' + cancelText + '</button>' +
        '<button type="button" class="admin-confirm__btn admin-confirm__btn--danger" data-action="confirm">' + confirmText + '</button>' +
      '</div>' +
    '</div>';

  document.body.appendChild(overlay);
  try { overlay.focus(); } catch (_) {}

  var confirmBtn = overlay.querySelector('[data-action="confirm"]');
  var cancelBtn = overlay.querySelector('[data-action="cancel"]');
  var busy = false;

  function close() {
    document.body.style.overflow = prevOverflow || '';
    if (overlay && overlay.parentNode) {
      overlay.parentNode.removeChild(overlay);
    }
    if (typeof options.onClose === 'function') {
      options.onClose();
    }
  }

  function setBusy(flag, busyText) {
    busy = !!flag;
    if (busy) {
      confirmBtn.disabled = true;
      confirmBtn.setAttribute('aria-busy', 'true');
      confirmBtn.textContent = busyText || confirmText;
    } else {
      confirmBtn.disabled = false;
      confirmBtn.removeAttribute('aria-busy');
      confirmBtn.textContent = confirmText;
    }
  }

  cancelBtn.addEventListener('click', function(ev){
    ev.preventDefault();
    if (busy) { return; }
    close();
    if (typeof options.onCancel === 'function') {
      options.onCancel();
    }
  });

  confirmBtn.addEventListener('click', function(ev){
    ev.preventDefault();
    if (busy) { return; }
    if (typeof options.onConfirm === 'function') {
      options.onConfirm({
        close: close,
        setBusy: setBusy
      });
    } else {
      close();
    }
  });

  overlay.addEventListener('click', function(ev){
    if (ev.target === overlay) {
      ev.preventDefault();
      ev.stopPropagation();
    }
  });

  try {
    overlay.addEventListener('keydown', function(ev){
      if (ev.key === 'Escape') {
        ev.preventDefault();
      }
    });
  } catch (_) {}

  return {
    close: close,
    setBusy: setBusy
  };
}

(function(){
  function onReady(fn){
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  function initMaintenanceAdmin(){
    var section = document.querySelector('[data-maintenance-section]');
    if (!section) { return; }
    var endpoint = section.getAttribute('data-maintenance-endpoint');
    if (!endpoint) { return; }

    var indicator = section.querySelector('[data-maintenance-indicator]');
    var lastUpdate = section.querySelector('[data-maintenance-last-update]');
    var conflict = section.querySelector('[data-maintenance-conflict]');
    var toggle = section.querySelector('[data-maintenance-toggle]');
    var etaInput = section.querySelector('[data-maintenance-eta]');
    var messageInput = section.querySelector('[data-maintenance-message]');
    var linkInputs = section.querySelectorAll('[data-maintenance-link]');

    var labelOn = section.getAttribute('data-maintenance-label-on') || 'Maintenance is currently ON';
    var labelOff = section.getAttribute('data-maintenance-label-off') || 'Maintenance is currently OFF';
    var labelRefresh = section.getAttribute('data-maintenance-label-refresh') || 'Refreshing…';
    var lastIndicatorText = indicator ? indicator.textContent : '';

    var dirtyLinks = {};
    linkInputs.forEach(function(input){
      var key = String(input.getAttribute('data-maintenance-link') || '') || ('link-' + Math.random().toString(16).slice(2));
      dirtyLinks[key] = false;
      input.addEventListener('input', function(){ dirtyLinks[key] = true; renderConflict(false); });
      input.setAttribute('data-maintenance-link-key', key);
    });

    var dirty = {
      toggle: false,
      eta: false,
      message: false,
      links: dirtyLinks
    };

    function renderConflict(show) {
      if (!conflict) { return; }
      conflict.style.display = show ? 'block' : 'none';
    }

    if (toggle) {
      toggle.addEventListener('change', function(){ dirty.toggle = true; renderConflict(false); });
    }
    if (etaInput) {
      etaInput.addEventListener('input', function(){ dirty.eta = true; renderConflict(false); });
    }
    if (messageInput) {
      messageInput.addEventListener('input', function(){ dirty.message = true; renderConflict(false); });
    }

    function setIndicator(text) {
      if (indicator) { indicator.textContent = text; }
    }

    function applyRemoteValue(input, value, isDirty) {
      if (!input) { return false; }
      var current = input.value || '';
      var next = value || '';
      if (!isDirty) {
        if (current !== next) {
          input.value = next;
        }
        return false;
      }
      if (current !== next) {
        return true;
      }
      return false;
    }

    function fetchState(){
      var priorIndicator = lastIndicatorText;
      setIndicator(labelRefresh);
      fetch(endpoint, { credentials: 'same-origin', cache: 'no-store' })
        .then(function(resp){ return resp.json(); })
        .then(function(data){
          if (!data || data.status !== 'ok') {
            setIndicator(labelOff);
            lastIndicatorText = labelOff;
            return;
          }

          var remoteOn = String(data.maintenance || '').toLowerCase() === 'on';
          var indicatorText = remoteOn ? labelOn : labelOff;
          setIndicator(indicatorText);
          lastIndicatorText = indicatorText;

          var hasConflict = false;

          if (toggle) {
            if (!dirty.toggle) {
              toggle.checked = remoteOn;
            } else if (toggle.checked !== remoteOn) {
              hasConflict = true;
            }
          }

          var remoteEta = data.eta_input || '';
          if (applyRemoteValue(etaInput, remoteEta, dirty.eta)) {
            hasConflict = true;
          }

          var remoteMessage = data.message || '';
          if (applyRemoteValue(messageInput, remoteMessage, dirty.message)) {
            hasConflict = true;
          }

          var remoteLinks = data.links || {};
          linkInputs.forEach(function(input){
            var key = input.getAttribute('data-maintenance-link-key') || '';
            var rawKey = input.getAttribute('data-maintenance-link') || '';
            var mapKey = 'maintenance_' + rawKey + '_url';
            var remoteValue = remoteLinks[mapKey] || '';
            if (applyRemoteValue(input, remoteValue, dirty.links[key])) {
              hasConflict = true;
            }
          });

          if (lastUpdate) {
            lastUpdate.textContent = data.last_updated_label || '';
          }

          renderConflict(hasConflict);
        })
        .catch(function(){
          setIndicator(priorIndicator);
        });
    }

    fetchState();
    setInterval(fetchState, 20000);
  }

  onReady(initMaintenanceAdmin);
})();

function initPayoutVerificationsModule() {
  var host = document.querySelector('[data-module="payout-verifications"]');
  if (!host) { return; }
  var actionUrl = host.getAttribute('data-action-url') || '';
  if (!actionUrl) { return; }

  var statusFilter = (host.getAttribute('data-status-filter') || 'open').toLowerCase();
  var emptyMessage = host.getAttribute('data-empty-message') || adminLang('admin_payout_empty', 'No payout submissions match this filter.');

  var STATUS_META = {
    approved: { label: adminLang('settings_payout_status_approved', 'Approved'), cls: 'status-badge--success' },
    rejected: { label: adminLang('settings_payout_status_rejected', 'Rejected'), cls: 'status-badge--danger' },
    review: { label: adminLang('settings_payout_status_review', 'In review'), cls: 'status-badge--pending' },
    pending: { label: adminLang('settings_payout_status_pending', 'Pending'), cls: 'status-badge--pending' },
    processing: { label: adminLang('settings_payout_status_processing', 'Processing'), cls: 'status-badge--pending' },
    failed: { label: adminLang('settings_payout_status_failed', 'Failed'), cls: 'status-badge--danger' },
    none: { label: adminLang('settings_payout_status_none', 'Not submitted'), cls: 'status-badge--neutral' }
  };

  function normalizeStatus(value) {
    if (!value) { return 'pending'; }
    var key = String(value).toLowerCase();
    if (STATUS_META[key]) { return key; }
    return 'pending';
  }

  function statusMatchesFilter(status) {
    if (statusFilter === 'all') { return true; }
    if (statusFilter === 'open') {
      return status === 'pending' || status === 'review' || status === 'processing';
    }
    return status === statusFilter;
  }

  function formatDate(value) {
    if (!value) { return '—'; }
    var numeric = Number(value);
    if (!isFinite(numeric) || numeric <= 0) { return '—'; }
    if (numeric < 1e11) { numeric = numeric * 1000; }
    try {
      var formatter = new Intl.DateTimeFormat(undefined, { dateStyle: 'short', timeStyle: 'short' });
      return formatter.format(new Date(numeric));
    } catch (err) {
      return new Date(numeric).toLocaleString();
    }
  }

  function updateSummary() {
    var cards = host.querySelectorAll('.payout-verification-card');
    var summary = host.querySelector('[data-total-count]');
    if (!summary) { return; }
    var count = cards.length;
    summary.setAttribute('data-total-count', String(count));
    summary.textContent = adminLang('admin_payout_summary_count', '{count} payout method(s) in this view.', { count: count });
  }

  function ensureEmptyState() {
    if (host.querySelector('.payout-verification-card')) { return; }
    var empty = host.querySelector('.admin-empty');
    if (!empty) {
      empty = document.createElement('div');
      empty.className = 'admin-empty';
      var icon = document.createElement('span');
      icon.className = 'icon';
      icon.innerHTML = renderIcon('payments');
      empty.appendChild(icon);
      var text = document.createElement('p');
      text.textContent = emptyMessage;
      empty.appendChild(text);
      host.querySelector('.payout-verification-list').appendChild(empty);
    }
  }

  function renderIcon(name) {
    if (typeof window.renderIcon === 'function') {
      return window.renderIcon(name, true);
    }
    return '';
  }

  function updateHistory(card, history, statusMeta) {
    var historyContainer = card.querySelector('.payout-card__history');
    var emptyState = card.querySelector('.payout-card__history-empty');

    if (!history || !history.length) {
      if (historyContainer) {
        var list = historyContainer.querySelector('ul');
        if (list) { list.innerHTML = ''; }
      }
      if (emptyState) {
        emptyState.removeAttribute('hidden');
      }
      return;
    }

    if (!historyContainer) {
      historyContainer = document.createElement('div');
      historyContainer.className = 'payout-card__history';
      var list = document.createElement('ul');
      historyContainer.appendChild(list);
      var body = card.querySelector('.payout-table__history-body') || card.querySelector('.payout-card__body');
      if (body) {
        body.appendChild(historyContainer);
      }
      if (emptyState) {
        emptyState.setAttribute('hidden', '');
      }
    } else if (emptyState) {
      emptyState.setAttribute('hidden', '');
    }

    var listEl = historyContainer.querySelector('ul');
    if (!listEl) {
      listEl = document.createElement('ul');
      historyContainer.appendChild(listEl);
    }
    listEl.innerHTML = '';
    history.forEach(function (entry) {
      var entryStatus = normalizeStatus(entry && entry.status_after);
      var meta = STATUS_META[entryStatus] || statusMeta;
      var item = document.createElement('li');
      var time = formatDate(entry && entry.created_at);
      var strong = document.createElement('strong');
      strong.textContent = meta.label;
      item.appendChild(strong);
      var timeSpan = document.createElement('span');
      timeSpan.textContent = ' · ' + time;
      item.appendChild(timeSpan);
      if (entry && entry.admin_note) {
        var note = document.createElement('div');
        note.className = 'payout-card__history-note';
        note.textContent = '"' + entry.admin_note + '"';
        item.appendChild(note);
      }
      listEl.appendChild(item);
    });
  }

  host.querySelectorAll('[data-payout-form]').forEach(function (form) {
    if (form.getAttribute('data-bound') === '1') { return; }
    form.setAttribute('data-bound', '1');
    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var submitter = ev.submitter || form.querySelector('button[type="submit"]');
      if (!submitter) { return; }
      var actionValue = String(submitter.value || '').toLowerCase();
      if (!actionValue) {
        adminToast(adminLang('admin_payout_select_action', 'Select an action first.'), 'warning');
        return;
      }
      var card = form.closest('.payout-verification-card');
      if (!card) { return; }

      submitter.disabled = true;
      submitter.setAttribute('aria-busy', 'true');

      var fd = new FormData(form);
      fd.set('action', actionValue);
      fd.append('include_history', '1');

      fetch(actionUrl, { method: 'POST', body: fd })
        .then(function (res) {
          return res.json().catch(function () {
            return { status: 'error', message: 'server_error' };
          });
        })
        .then(function (payload) {
          if (!payload || payload.status !== 'success') {
            var err = adminMsg(payload && payload.message);
            adminToast(err || adminLang('server_error', 'Server error. Please try again.'), 'error');
            return;
          }

          var newStatus = normalizeStatus(payload.state);
          var meta = STATUS_META[newStatus] || STATUS_META.pending;
          card.setAttribute('data-status', newStatus);

          var badge = card.querySelector('[data-status-label]');
          if (badge) {
            badge.textContent = meta.label;
            badge.className = 'status-badge ' + meta.cls;
          }

          var statusUpdated = card.querySelector('[data-status-updated]');
          if (statusUpdated) {
            var ts = payload.payload && (payload.payload.status_updated_at || payload.payload.updated_at);
            statusUpdated.textContent = formatDate(ts);
          }

          var noteField = form.querySelector('[data-note-field]');
          if (noteField) {
            noteField.value = payload.payload && payload.payload.admin_note ? payload.payload.admin_note : '';
          }

          var reqChip = card.querySelector('[data-requires-update]');
          var requiresUpdate = payload.payload && !!payload.payload.requires_update;
          if (reqChip) {
            if (requiresUpdate) {
              reqChip.removeAttribute('hidden');
            } else {
              reqChip.setAttribute('hidden', '');
            }
          }

          if (payload.history) {
            updateHistory(card, payload.history, meta);
          }

          adminToast(adminLang('admin_payout_toast_success', 'Payout status updated.'), 'success');

          updateSummary();

          if (!statusMatchesFilter(newStatus)) {
            card.classList.add('is-dismissed');
            setTimeout(function () {
              card.remove();
              updateSummary();
              ensureEmptyState();
            }, 200);
          }
        })
        .catch(function () {
          adminToast(adminLang('admin_network_error_retry', 'Network error. Please try again.'), 'error');
        })
        .finally(function () {
          submitter.disabled = false;
          submitter.removeAttribute('aria-busy');
        });
    });
  });
}

function initVerificationRequestsModule() {
  var host = document.querySelector('[data-module="verification-requests"]');
  if (!host) { return; }

  var actionUrl = host.getAttribute('data-action-url') || '';
  if (!actionUrl) { return; }

  var form = host.querySelector('form[data-role="bulk"]');
  if (!form || form.getAttribute('data-verify-bound') === '1') { return; }
  form.setAttribute('data-verify-bound', '1');

  var submitBtn = form.querySelector('[data-bulk-submit]');
  var countEl = form.querySelector('[data-selected-count]');
  var actionSelect = form.querySelector('select[name="bulk_action"]');
  var noteField = form.querySelector('input[name="note"]');
  var master = host.querySelector('[data-verify-master]');
  var checkboxes = Array.prototype.slice.call(host.querySelectorAll('[data-verify-select]'));
  var allowedActions = ['approve', 'reject'];

  function selectedCheckboxes() {
    return checkboxes.filter(function (cb) {
      return cb && cb.checked && !cb.disabled;
    });
  }

  function updateSelectionState() {
    var selected = selectedCheckboxes();
    if (countEl) {
      countEl.textContent = String(selected.length);
    }
    if (submitBtn) {
      if (selected.length === 0) {
        submitBtn.disabled = true;
        submitBtn.setAttribute('aria-disabled', 'true');
      } else {
        submitBtn.disabled = false;
        submitBtn.removeAttribute('aria-disabled');
      }
    }
    if (master) {
      var allChecked = selected.length === checkboxes.length && checkboxes.length > 0;
      master.indeterminate = selected.length > 0 && !allChecked;
      if (!master.indeterminate) {
        master.checked = allChecked;
      }
    }
  }

  if (master) {
    master.addEventListener('change', function () {
      var checked = !!master.checked;
      checkboxes.forEach(function (cb) {
        if (!cb || cb.disabled) { return; }
        cb.checked = checked;
      });
      updateSelectionState();
    });
  }

  checkboxes.forEach(function (cb) {
    if (!cb) { return; }
    cb.addEventListener('change', updateSelectionState);
  });

  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    var selected = selectedCheckboxes();
    if (!selected.length) {
      adminToast(adminLang('admin_verification_select_one', 'Select at least one request first.'), 'info');
      return;
    }
    var actionValue = actionSelect ? String(actionSelect.value || '').toLowerCase() : '';
    if (!actionValue || allowedActions.indexOf(actionValue) === -1) {
      adminToast(adminLang('admin_verification_bulk_action_placeholder', 'Select action'), 'warning');
      return;
    }

    var actionLabel = actionValue === 'approve'
      ? adminLang('admin_verification_action_approve', 'Approve')
      : adminLang('admin_verification_action_reject', 'Reject');
    var confirmMsg = adminLang('admin_verification_confirm_bulk', 'Are you sure you want to {action} {count} request(s)?', {
      action: actionLabel.toLowerCase(),
      count: selected.length
    });
    if (!window.confirm(confirmMsg)) {
      return;
    }

    var fd = new FormData();
    fd.append('csrf_token', adminCsrfToken());
    fd.append('action', actionValue);
    if (noteField && noteField.value.trim() !== '') {
      fd.append('note', noteField.value.trim());
    }
    selected.forEach(function (cb) {
      fd.append('request_ids[]', cb.value);
    });

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.setAttribute('aria-busy', 'true');
    }

    fetch(actionUrl, { method: 'POST', body: fd })
      .then(function (res) {
        return res.json().catch(function () {
          return { status: 'error', message: 'server_error' };
        });
      })
      .then(function (payload) {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.removeAttribute('aria-busy');
        }
        if (!payload || payload.status !== 'success') {
          var err = adminMsg(payload && payload.message);
          adminToast(err || adminLang('server_error', 'Server error. Please try again.'), 'error');
          return;
        }
        var toastMessage = adminLang(payload.message || 'admin_verification_success_bulk', 'Verification updated for {count} request(s).', {
          count: payload.updated || selected.length
        });
        adminToast(toastMessage, 'success');
        if (payload.failed && payload.failed.length) {
          adminToast(adminLang('admin_save_failed_generic', 'Save failed.') + ' (' + payload.failed.length + ')', 'warning');
        }
        setTimeout(function () {
          try { window.location.reload(); } catch (_) {}
        }, 600);
      })
      .catch(function () {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.removeAttribute('aria-busy');
        }
        adminToast(adminLang('admin_network_error_retry', 'Network error. Please try again.'), 'error');
      });
  });

  updateSelectionState();

  host.querySelectorAll('[data-verify-action]').forEach(function (btn) {
    if (!btn || btn.getAttribute('data-verify-bound') === '1') { return; }
    btn.setAttribute('data-verify-bound', '1');
    btn.addEventListener('click', function (ev) {
      ev.preventDefault();
      if (btn.disabled) { return; }
      var actionValue = String(btn.getAttribute('data-verify-action') || '').toLowerCase();
      if (allowedActions.indexOf(actionValue) === -1) { return; }
      var requestId = parseInt(btn.getAttribute('data-request-id') || '0', 10);
      if (!requestId) { return; }
      var actionLabel = btn.getAttribute('data-action-label') || (actionValue === 'approve'
        ? adminLang('admin_verification_action_approve', 'Approve')
        : adminLang('admin_verification_action_reject', 'Reject'));

      var confirmMsg = adminLang('admin_verification_confirm_single', 'Are you sure you want to {action} this request?', {
        action: actionLabel.toLowerCase()
      });
      if (!window.confirm(confirmMsg)) {
        return;
      }

      var noteValue = '';
      if (noteField && noteField.value.trim() !== '') {
        noteValue = noteField.value.trim();
      } else {
        var promptMsg = adminLang('admin_verification_prompt_note', 'Add an optional note for the creator (leave blank to skip).');
        var promptValue = window.prompt(promptMsg, '');
        if (promptValue === null) {
          return;
        }
        noteValue = promptValue.trim();
      }

      btn.disabled = true;
      btn.setAttribute('aria-busy', 'true');

      var fd = new FormData();
      fd.append('csrf_token', adminCsrfToken());
      fd.append('action', actionValue);
      fd.append('request_id', String(requestId));
      if (noteValue !== '') {
        fd.append('note', noteValue);
      }

      fetch(actionUrl, { method: 'POST', body: fd })
        .then(function (res) {
          return res.json().catch(function () {
            return { status: 'error', message: 'server_error' };
          });
        })
        .then(function (payload) {
          if (!payload || payload.status !== 'success') {
            var err = adminMsg(payload && payload.message);
            adminToast(err || adminLang('server_error', 'Server error. Please try again.'), 'error');
            return;
          }
          var toastMessage = adminLang(payload.message || 'admin_verification_success_single', 'Verification updated.');
          adminToast(toastMessage, 'success');
          if (payload.failed && payload.failed.length) {
            adminToast(adminLang('admin_save_failed_generic', 'Save failed.'), 'warning');
          }
          setTimeout(function () {
            try { window.location.reload(); } catch (_) {}
          }, 500);
        })
        .catch(function () {
          adminToast(adminLang('admin_network_error_retry', 'Network error. Please try again.'), 'error');
        })
        .finally(function () {
          btn.disabled = false;
          btn.removeAttribute('aria-busy');
        });
    });
  });
}

document.addEventListener('DOMContentLoaded', initPayoutVerificationsModule);
document.addEventListener('DOMContentLoaded', initVerificationRequestsModule);

document.addEventListener('DOMContentLoaded', function(){
  initLiveSettingsForm();
  var master = document.querySelector('[data-live-master]');
  if (!master) { return; }
  var dependents = document.querySelectorAll('[data-live-dependent]');
  var chatToggle = document.querySelector('[data-live-chat]');
  var statusLabel = document.querySelector('[data-live-status]');
  var chatStatusLabel = document.querySelector('[data-live-chat-status]');
  var statusOn = adminLang('admin_live_streaming_status_on', 'Live streaming is enabled.');
  var statusOff = adminLang('admin_live_streaming_status_off', 'Live streaming is disabled.');
  var chatOn = adminLang('admin_live_chat_status_on', 'Live chat is enabled.');
  var chatOff = adminLang('admin_live_chat_status_off', 'Live chat is disabled.');

  function renderStatuses(liveEnabled) {
    if (statusLabel) {
      statusLabel.textContent = liveEnabled ? statusOn : statusOff;
    }
    if (chatStatusLabel) {
      var chatEnabled = liveEnabled && chatToggle && chatToggle.checked;
      chatStatusLabel.textContent = chatEnabled ? chatOn : chatOff;
    }
  }

  function setDependentState(liveEnabled) {
    dependents.forEach(function(input){
      if (!input) { return; }
      var readonlyFlag = input.getAttribute('data-live-original-readonly');
      if (!liveEnabled) {
        if (!readonlyFlag) {
          var hadReadonly = input.hasAttribute('readonly');
          input.setAttribute('data-live-original-readonly', hadReadonly ? 'keep' : 'add');
          if (!hadReadonly) {
            input.setAttribute('readonly', 'readonly');
          }
        } else if (readonlyFlag === 'add' && !input.hasAttribute('readonly')) {
          input.setAttribute('readonly', 'readonly');
        }
        input.setAttribute('aria-readonly', 'true');
        input.setAttribute('aria-disabled', 'true');
      } else {
        if (readonlyFlag === 'add') {
          input.removeAttribute('readonly');
        }
        if (readonlyFlag) {
          input.removeAttribute('data-live-original-readonly');
        }
        input.removeAttribute('aria-readonly');
        input.removeAttribute('aria-disabled');
      }
      var wrap = input.closest('.form-input-wrapper');
      if (wrap) {
        wrap.classList.toggle('admin-live-disabled', !liveEnabled);
      }
    });
  }

  function syncChatToggle(liveEnabled) {
    if (!chatToggle) { return; }
    if (!liveEnabled) {
      if (!chatToggle.dataset.liveStored) {
        chatToggle.dataset.liveStored = chatToggle.checked ? '1' : '0';
      }
      chatToggle.checked = false;
      chatToggle.disabled = true;
    } else {
      chatToggle.disabled = false;
      if (chatToggle.dataset.liveStored) {
        chatToggle.checked = chatToggle.dataset.liveStored === '1';
        delete chatToggle.dataset.liveStored;
      }
    }
  }

  function handleMasterChange(){
    var liveEnabled = !!master.checked;
    setDependentState(liveEnabled);
    syncChatToggle(liveEnabled);
    renderStatuses(liveEnabled);
  }

  if (chatToggle) {
    chatToggle.addEventListener('change', function(){
      renderStatuses(master.checked);
    });
  }

  master.addEventListener('change', handleMasterChange);
  handleMasterChange();
});

function initLiveSettingsForm(){
  var form = document.querySelector('form[data-action="save-live-settings"]');
  if (!form || form.getAttribute('data-ajax-bound') === '1') { return; }
  form.setAttribute('data-ajax-bound', '1');

  var liveDirtyState = false;
  var liveInitialSnapshot = null;
  var liveUnloadBound = false;
  var liveDirtyTimer = null;

  function liveBeforeUnload(ev){
    if (!liveDirtyState) { return; }
    ev.preventDefault();
    ev.returnValue = '';
    return '';
  }

  function bindBeforeUnload(){
    if (liveUnloadBound) { return; }
    window.addEventListener('beforeunload', liveBeforeUnload);
    liveUnloadBound = true;
  }

  function unbindBeforeUnload(){
    if (!liveUnloadBound) { return; }
    window.removeEventListener('beforeunload', liveBeforeUnload);
    liveUnloadBound = false;
  }

  function serializeLiveForm(){
    var entries = [];
    var fields = form.querySelectorAll('input[name], textarea[name], select[name]');
    fields.forEach(function(field){
      var name = field.name || field.getAttribute('name');
      if (!name) { return; }
      var type = (field.type || '').toLowerCase();
      if (type === 'checkbox') {
        entries.push(name + '=' + (field.checked ? '1' : '0'));
      } else if (type === 'radio') {
        if (field.checked) {
          entries.push(name + '=' + (field.value || ''));
        }
      } else {
        entries.push(name + '=' + (field.value || ''));
      }
    });
    return entries.join('&');
  }

  function setLiveDirtyState(state){
    liveDirtyState = !!state;
    if (liveDirtyState) { bindBeforeUnload(); }
    else { unbindBeforeUnload(); }
    form.dataset.liveDirty = liveDirtyState ? '1' : '0';
  }

  function evaluateLiveDirty(){
    var current = serializeLiveForm();
    if (liveInitialSnapshot === null) {
      liveInitialSnapshot = current;
      setLiveDirtyState(false);
      return;
    }
    setLiveDirtyState(current !== liveInitialSnapshot);
  }

  function scheduleDirtyCheck(){
    if (liveDirtyTimer) {
      clearTimeout(liveDirtyTimer);
    }
    liveDirtyTimer = setTimeout(function(){
      liveDirtyTimer = null;
      evaluateLiveDirty();
    }, 120);
  }

  liveInitialSnapshot = serializeLiveForm();
  evaluateLiveDirty();

  form.addEventListener('input', scheduleDirtyCheck);
  form.addEventListener('change', scheduleDirtyCheck, true);

  form.addEventListener('submit', function(ev){
    ev.preventDefault();
    clearFieldErrors();
    var submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.classList.add('disabled');
      submitBtn.setAttribute('aria-busy', 'true');
    }
    var fd = new FormData(form);
    var targetUrl = form.getAttribute('action') || window.location.href;
    fetch(targetUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function(resp){
        return resp.json().catch(function(){ return { status: 'error', message: 'server_error' }; });
      })
      .then(function(res){
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.classList.remove('disabled');
          submitBtn.removeAttribute('aria-busy');
        }
        if (!res || res.status !== 'success') {
          handleLiveFormError(res && res.message ? String(res.message) : 'server_error');
          return;
        }
        liveInitialSnapshot = serializeLiveForm();
        setLiveDirtyState(false);
        adminToast(adminLang('admin_saved_changes', 'Changes saved.'), 'success');
      })
      .catch(function(){
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.classList.remove('disabled');
          submitBtn.removeAttribute('aria-busy');
        }
        handleLiveFormError('server_error');
      });
  });

  var errorFieldMap = {
    'missing_agora_app_id': '#agora_app_id',
    'invalid_agora_app_id': '#agora_app_id',
    'invalid_agora_app_certificate': '#agora_app_certificate',
    'invalid_agora_app_certificate_match': '#agora_app_certificate',
    'invalid_agora_readonly_token': '#agora_readonly_token',
    'invalid_live_viewer_limit': '#live_viewer_limit',
    'invalid_live_title_prefix': '#live_title_prefix',
    'invalid_audio_room_price_presets': '#audio_room_price_presets',
    'invalid_audio_room_price_range': '#audio_room_price_minimum',
    'invalid_audio_room_daily_limit': '#audio_room_non_creator_daily_minutes',
    'invalid_audio_room_max_speakers': '#audio_room_max_speakers',
    'invalid_audio_room_max_listeners': '#audio_room_max_listeners',
    'invalid_audio_room_title_prefix': '#audio_room_title_prefix'
  };

  function clearFieldErrors(){
    form.querySelectorAll('.form-input--error').forEach(function(input){
      input.classList.remove('form-input--error');
    });
    form.querySelectorAll('[data-live-error-msg]').forEach(function(msg){
      if (msg.parentNode) { msg.parentNode.removeChild(msg); }
    });
  }

  function handleLiveFormError(code){
    var friendly = adminMsg(code || 'server_error');
    var selector = errorFieldMap[code || ''];
    if (selector) {
      showFieldError(selector, friendly);
    } else {
      adminToast(friendly || adminLang('server_error', 'Server error. Please try again.'), 'error');
    }
  }

  function showFieldError(selector, message){
    var input = form.querySelector(selector);
    if (!input) {
      adminToast(message || adminLang('server_error', 'Server error. Please try again.'), 'error');
      return;
    }
    input.classList.add('form-input--error');
    var wrapper = input.closest('.form-input-wrapper') || input.closest('label');
    if (wrapper) {
      var msg = document.createElement('p');
      msg.className = 'form-feedback';
      msg.setAttribute('data-live-error-msg', '');
      msg.textContent = message || adminLang('server_error', 'Server error. Please try again.');
      var insertionTarget = wrapper.querySelector('.form-text:last-of-type');
      if (insertionTarget && insertionTarget.parentNode) {
        insertionTarget.parentNode.insertBefore(msg, insertionTarget.nextSibling);
      } else {
        wrapper.appendChild(msg);
      }
    } else {
      adminToast(message || adminLang('server_error', 'Server error. Please try again.'), 'error');
    }
    try { input.focus(); } catch(_) {}
  }
}
  (function(){
    var root=document.querySelector('[data-ebook-admin]');if(!root){return;}
    var endpoint=root.getAttribute('data-action-url')||'';var csrf=root.getAttribute('data-csrf')||'';
    function send(data){data.set('csrf_token',csrf);return fetch(endpoint,{method:'POST',body:data,credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}}).then(function(r){return r.json().catch(function(){return{};}).then(function(j){j.httpStatus=r.status;return j;});});}
    function feedback(message,type){adminToast(message,type||'info');}
    function closeMenus(){root.querySelectorAll('.post-menu-popup').forEach(function(m){m.classList.add('none');m.setAttribute('aria-hidden','true');});}
    function runAction(button,note){var fd=new FormData();fd.set('ebook_action',button.getAttribute('data-action')||'');fd.set('ebook_id',button.getAttribute('data-id')||'');if(button.getAttribute('data-coupon-id')){fd.set('coupon_id',button.getAttribute('data-coupon-id'));}if(note){fd.set('moderation_note',note);}button.disabled=true;send(fd).then(function(res){if(res&&res.status==='success'){feedback(res.message||adminLang('admin_ebook_updated','eBook updated.'),'success');window.setTimeout(function(){window.location.reload();},250);return;}feedback((res&&res.message)||adminLang('admin_ebook_action_failed','The action could not be completed.'),'error');}).catch(function(){feedback(adminLang('admin_ebook_action_failed','The action could not be completed.'),'error');}).finally(function(){button.disabled=false;});}
    root.addEventListener('click',function(event){
      var action=event.target.closest('.js-ebook-admin-action');if(action){event.preventDefault();closeMenus();var type=action.getAttribute('data-action')||'';var title=action.getAttribute('data-title')||'this eBook';
        if(type==='reject'){var p=typeof window.adminPrompt==='function'?window.adminPrompt({title:adminLang('admin_ebook_reject_title','Reject eBook'),message:adminLang('admin_ebook_reject_message','Explain why {title} was rejected.',{title:title}),label:adminLang('admin_ebook_reject_reason','Rejection reason'),placeholder:adminLang('admin_ebook_reject_placeholder','Write a clear reason for the creator'),required:true,confirmLabel:adminLang('reject','Reject'),cancelLabel:adminLang('cancel','Cancel')}):Promise.resolve(window.prompt(adminLang('admin_ebook_reject_reason','Rejection reason')));p.then(function(note){if(note!==null&&String(note).trim()!==''){runAction(action,String(note).trim());}});return;}
        var promptText=type==='approve'?adminLang('admin_ebook_approve_confirm','Approve {title}?',{title:title}):(type==='coupon_delete'?adminLang('admin_ebook_coupon_deactivate_confirm','Deactivate this coupon?'):adminLang('admin_confirm_action','Confirm this action?'));var confirm=typeof window.adminConfirm==='function'?window.adminConfirm(promptText):Promise.resolve(window.confirm(promptText));confirm.then(function(ok){if(ok){runAction(action);}});return;
      }
      var open=event.target.closest('.js-ebook-coupon-open');if(open){event.preventDefault();closeMenus();var modal=root.querySelector('[data-ebook-coupon-modal]');var form=root.querySelector('[data-ebook-coupon-form]');if(!modal||!form){return;}form.reset();form.querySelector('[name="ebook_id"]').value=open.getAttribute('data-id')||'';var product=root.querySelector('[data-ebook-coupon-product]');if(product){product.textContent=(open.getAttribute('data-title')||'')+' · '+(open.getAttribute('data-price')||'0')+' '+(open.getAttribute('data-currency')||'');}modal.classList.add('is-open');modal.setAttribute('aria-hidden','false');setTimeout(function(){var input=form.querySelector('[name="coupon_code"]');if(input){input.focus();}},50);return;}
      if(event.target.closest('[data-ebook-coupon-close]')){event.preventDefault();var m=root.querySelector('[data-ebook-coupon-modal]');if(m){m.classList.remove('is-open');m.setAttribute('aria-hidden','true');}}
    });
    var couponForm=root.querySelector('[data-ebook-coupon-form]');if(couponForm){couponForm.addEventListener('submit',function(event){event.preventDefault();var submit=couponForm.querySelector('[type="submit"]');var msg=couponForm.querySelector('.admin-ebook-coupon-message');submit.disabled=true;if(msg){msg.textContent='';msg.classList.remove('is-error');}send(new FormData(couponForm)).then(function(res){if(res&&res.status==='success'){feedback(res.message||adminLang('admin_ebook_coupon_created','Coupon created.'),'success');window.setTimeout(function(){window.location.reload();},250);return;}if(msg){msg.textContent=(res&&res.message)||adminLang('admin_ebook_coupon_failed','Coupon could not be created.');msg.classList.add('is-error');}}).catch(function(){if(msg){msg.textContent=adminLang('admin_ebook_coupon_failed','Coupon could not be created.');msg.classList.add('is-error');}}).finally(function(){submit.disabled=false;});});}
    document.addEventListener('keydown',function(event){if(event.key==='Escape'){var modal=root.querySelector('[data-ebook-coupon-modal]');if(modal){modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');}}});
  })();
