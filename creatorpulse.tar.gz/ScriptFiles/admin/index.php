<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php'; // Enforce RBAC early
require_once __DIR__ . '/_init.php';

$page = isset($_GET['page']) ? (string)$_GET['page'] : 'dashboard';
$landingLogFile = dirname(__DIR__) . '/includes/functions_error.txt';
// Disable verbose admin dispatch logging unless enabled explicitly via env flag
$landingVerboseLog = getenv('ADMIN_VERBOSE_LOG') ?: '';
$landingLogger = static function (string $message) use ($landingLogFile, $landingVerboseLog): void {
    if (strcasecmp($landingVerboseLog, '1') === 0 || strcasecmp($landingVerboseLog, 'true') === 0) {
        $line = '[' . date('c') . "] admin_index · " . $message . PHP_EOL;
        @file_put_contents($landingLogFile, $line, FILE_APPEND | LOCK_EX);
    }
};
$landingLogger('dispatch start: ' . $page);

// Map to file
$routes = [
    'dashboard'         => __DIR__ . '/pages/dashboard.php',
    'users'             => __DIR__ . '/pages/users.php',
    'verification_requests' => __DIR__ . '/pages/verification/index.php',
    'payout_verifications'  => __DIR__ . '/pages/payouts/index.php',
    'withdrawals'        => __DIR__ . '/pages/withdrawals.php',
    'icons'             => __DIR__ . '/pages/icons.php',
    'ebooks'            => __DIR__ . '/pages/ebooks.php',
    'audio_rooms'       => __DIR__ . '/pages/audio_rooms.php',
    'audio_room_earnings' => __DIR__ . '/pages/audio_room_earnings.php',
    'invoice_audio_room' => __DIR__ . '/pages/invoice/audio_room.php',
    'ebook_languages'   => __DIR__ . '/pages/ebook_languages.php',
    'content'           => __DIR__ . '/pages/content.php',
    // Content filters
    'content_everyone'     => __DIR__ . '/pages/content_everyone.php',
    'content_subscribers'  => __DIR__ . '/pages/content_subscribers.php',
    'content_locked'       => __DIR__ . '/pages/content_locked.php',
    'content_followers'    => __DIR__ . '/pages/content_followers.php',
    'reported_posts'       => __DIR__ . '/pages/reported_posts.php',
    'reported_comments'    => __DIR__ . '/pages/reported_comments.php',
    'content_approvals'    => __DIR__ . '/pages/content_approvals.php',
    'podcast_categories'   => __DIR__ . '/pages/podcast_categories/index.php',
    'podcast_ads'          => __DIR__ . '/pages/podcast_ads/index.php',
    'podcast_ad_packages'  => __DIR__ . '/pages/podcast_ads/packages.php',
    // Advertisements
    'ads_all'          => __DIR__ . '/pages/advertisements/all.php',
    'ads_videos'       => __DIR__ . '/pages/advertisements/video.php',
    'ads_images'       => __DIR__ . '/pages/advertisements/image.php',
    'subs_active'       => __DIR__ . '/pages/subscriptions/active.php',
    'subs_pending'      => __DIR__ . '/pages/subscriptions/pending.php',
    'subs_declined'     => __DIR__ . '/pages/subscriptions/declined.php',
    'subs_failed'       => __DIR__ . '/pages/subscriptions/failed.php',
    'tips_paid'         => __DIR__ . '/pages/tips/paid.php',
    'tips_pending'      => __DIR__ . '/pages/tips/pending.php',
    'tips_canceled'     => __DIR__ . '/pages/tips/canceled.php',
    'tips_failed'       => __DIR__ . '/pages/tips/failed.php',
    'wallet_topups'     => __DIR__ . '/pages/wallet_topups.php',
    'contact_reply'     => __DIR__ . '/pages/contact_reply.php',
    'contact_messages_all'      => __DIR__ . '/pages/contact_messages/all.php',
    'contact_messages_new'      => __DIR__ . '/pages/contact_messages/new.php',
    'contact_messages_read'     => __DIR__ . '/pages/contact_messages/read.php',
    'contact_messages_resolved' => __DIR__ . '/pages/contact_messages/resolved.php',
    'settings_site'     => __DIR__ . '/pages/settings/site.php',
    'settings_live'     => __DIR__ . '/pages/settings/live.php',
    'settings_audio_rooms' => __DIR__ . '/pages/settings/audio_rooms.php',
    'settings_ebooks'   => __DIR__ . '/pages/settings/ebooks.php',
    'settings_payments' => __DIR__ . '/pages/settings/payments.php',
    'settings_onesignal' => __DIR__ . '/pages/settings/onesignal.php',
    'settings_sms'      => __DIR__ . '/pages/settings/sms.php',
    'settings_landing'  => __DIR__ . '/pages/settings/landing.php',
    'settings_contact_email' => __DIR__ . '/pages/settings/contact_email.php',
    'settings_footer_links' => __DIR__ . '/pages/settings/footer_links.php',
    'settings_faqs'     => __DIR__ . '/pages/settings/faqs.php',
    'settings_storage_local'  => __DIR__ . '/pages/settings/storage_local.php',
    'settings_storage_s3'     => __DIR__ . '/pages/settings/storage_s3.php',
    'settings_storage_spaces' => __DIR__ . '/pages/settings/storage_spaces.php',
    'settings_storage_wasabi' => __DIR__ . '/pages/settings/storage_wasabi.php',
    'settings_storage_backblaze' => __DIR__ . '/pages/settings/storage_backblaze.php',
    'announcements'     => __DIR__ . '/pages/announcements/index.php',
    'social_login'      => __DIR__ . '/pages/social_login.php',
    // Activity pages (full lists)
    'activity_users'    => __DIR__ . '/pages/users.php',
    'activity_subs'     => __DIR__ . '/pages/activity/subscriptions.php',
    'activity_tips'     => __DIR__ . '/pages/activity/tips.php',
    'user_detail'       => __DIR__ . '/pages/user_detail.php',
    'post_edit'         => __DIR__ . '/pages/post_edit.php',
    // Invoices
    'invoice_subscription' => __DIR__ . '/pages/invoice/subscription.php',
    'invoice_tip'          => __DIR__ . '/pages/invoice/tip.php',
    // Invoice details (gateway logs)
    'invoice_subscription_detail' => __DIR__ . '/pages/invoice/subscription_detail.php',
    'invoice_tip_detail'          => __DIR__ . '/pages/invoice/tip_detail.php',
];

$requestedPage = array_key_exists($page, $routes) ? $page : 'dashboard';
$requiredPermission = admin_page_permission_key($requestedPage);
if (!admin_has_permission($requiredPermission)) {
    $file = __DIR__ . '/pages/permission_denied.php';
} else {
    $file = $routes[$requestedPage];
}
$landingLogger('dispatch resolved: ' . $file);

// Dev convenience: force opcode cache to refresh the selected page file
if (defined('APP_DEBUG') && APP_DEBUG === true && function_exists('opcache_invalidate')) {
    @opcache_invalidate($file, true);
}
// Keep users search fixes hot even on environments with sticky opcache settings.
if ($requestedPage === 'users' && function_exists('opcache_invalidate')) {
    @opcache_invalidate(__DIR__ . '/functions/dashboard_functions.php', true);
    @opcache_invalidate(__DIR__ . '/pages/users.php', true);
}

// Use admin main shell identical to theme main.php
$layoutFile = $file; // constrained pages included in admin/main.php
try {
    require __DIR__ . '/main.php';
    $landingLogger('dispatch done');
} catch (Throwable $e) {
    $landingLogger('dispatch error: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    throw $e;
}
