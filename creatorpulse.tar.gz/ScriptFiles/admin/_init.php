<?php
declare(strict_types=1);

// Bootstrap application + centralized admin guard
require_once __DIR__ . '/_bootstrap.php';

/**
 * Ensure a column exists; if missing, run provided ALTER TABLE DDL.
 *
 * @param PDO    $db
 * @param string $table
 * @param string $column
 * @param string $ddl Full ALTER TABLE ... ADD COLUMN ... (without IF NOT EXISTS)
 */
function admin_ensure_column(PDO $db, string $table, string $column, string $ddl): void
{
    $checkSql = 'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = :t
                   AND COLUMN_NAME = :c';
    $stmt = $db->prepare($checkSql);
    $stmt->execute([':t' => $table, ':c' => $column]);
    $exists = (int) $stmt->fetchColumn();
    if ($exists === 0) {
        $db->exec($ddl);
    }
}

/**
 * Ensure a table exists; if missing, run provided CREATE TABLE DDL.
 */
function admin_ensure_table(PDO $db, string $table, string $ddl): void
{
    $checkSql = 'SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
                 WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = :t';
    $stmt = $db->prepare($checkSql);
    $stmt->execute([':t' => $table]);
    $exists = (int) $stmt->fetchColumn();
    if ($exists === 0) {
        $db->exec($ddl);
    }
}

// Ensure announcements table exists for site-wide announcements module
try {
    $db->exec(
        "CREATE TABLE IF NOT EXISTS i_announcements (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            message TEXT NOT NULL,
            status ENUM('active','inactive') NOT NULL DEFAULT 'inactive',
            start_at INT UNSIGNED DEFAULT NULL,
            end_at INT UNSIGNED DEFAULT NULL,
            allow_close TINYINT(1) NOT NULL DEFAULT 1,
            title VARCHAR(160) NULL,
            cta_label VARCHAR(120) NULL,
            cta_url VARCHAR(255) NULL,
            image_path VARCHAR(255) NULL,
            created_at INT UNSIGNED NOT NULL,
            updated_at INT UNSIGNED DEFAULT NULL,
            PRIMARY KEY (id),
            KEY idx_status_window (status, start_at, end_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
} catch (Throwable $__) {
    // Best-effort guard; failures surface during insert/update calls.
}

admin_ensure_column(
    $db,
    'i_announcements',
    'title',
    "ALTER TABLE i_announcements ADD COLUMN title VARCHAR(160) NULL AFTER message"
);

admin_ensure_column(
    $db,
    'i_announcements',
    'cta_label',
    "ALTER TABLE i_announcements ADD COLUMN cta_label VARCHAR(120) NULL AFTER allow_close"
);

admin_ensure_column(
    $db,
    'i_announcements',
    'cta_url',
    "ALTER TABLE i_announcements ADD COLUMN cta_url VARCHAR(255) NULL AFTER cta_label"
);

admin_ensure_column(
    $db,
    'i_announcements',
    'image_path',
    "ALTER TABLE i_announcements ADD COLUMN image_path VARCHAR(255) NULL AFTER cta_url"
);

admin_ensure_table(
    $db,
    'i_wallet_topups',
    <<<SQL
CREATE TABLE i_wallet_topups (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    provider VARCHAR(32) NOT NULL,
    reference VARCHAR(191) NOT NULL,
    amount_minor BIGINT NOT NULL,
    currency CHAR(3) NOT NULL,
    status VARCHAR(32) NOT NULL,
    event VARCHAR(64) DEFAULT NULL,
    fee_minor BIGINT DEFAULT NULL,
    tax_minor BIGINT DEFAULT NULL,
    net_minor BIGINT DEFAULT NULL,
    raw_payload JSON DEFAULT NULL,
    credited_at INT UNSIGNED DEFAULT NULL,
    created_at INT UNSIGNED NOT NULL,
    updated_at INT UNSIGNED DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_provider_reference (provider, reference),
    KEY idx_user_status_created (user_id, status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
SQL
);

admin_ensure_table(
    $db,
    'i_wallet_ledger',
    <<<SQL
CREATE TABLE i_wallet_ledger (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    type ENUM('topup','spend','refund') NOT NULL,
    amount_minor BIGINT NOT NULL,
    currency CHAR(3) NOT NULL,
    ref_provider VARCHAR(32) NOT NULL,
    ref_id VARCHAR(191) NOT NULL,
    meta JSON DEFAULT NULL,
    created_at INT UNSIGNED NOT NULL,
    PRIMARY KEY (id),
    KEY idx_user_created (user_id, created_at),
    KEY idx_ref (ref_provider, ref_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
SQL
);

// i_users.is_banned
admin_ensure_column(
    $db,
    'i_users',
    'is_banned',
    "ALTER TABLE i_users ADD COLUMN is_banned TINYINT(1) NOT NULL DEFAULT 0 AFTER subscription_status"
);

// i_users.is_fake
admin_ensure_column(
    $db,
    'i_users',
    'is_fake',
    "ALTER TABLE i_users ADD COLUMN is_fake TINYINT(1) NOT NULL DEFAULT 0 AFTER is_banned"
);

// i_site_configurations.site_base_url
admin_ensure_column(
    $db,
    'i_site_configurations',
    'site_base_url',
    "ALTER TABLE i_site_configurations ADD COLUMN site_base_url VARCHAR(255) NULL AFTER site_keywords"
);

// i_site_configurations.paypal_webhook_id
admin_ensure_column(
    $db,
    'i_site_configurations',
    'paypal_webhook_id',
    "ALTER TABLE i_site_configurations ADD COLUMN paypal_webhook_id VARCHAR(191) NULL AFTER paypal_env"
);

// Provider statuses (enum open/close)
admin_ensure_column(
    $db,
    'i_site_configurations',
    'stripe_status',
    "ALTER TABLE i_site_configurations ADD COLUMN stripe_status ENUM('open','close') NOT NULL DEFAULT 'close' AFTER payments_currency"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'paypal_status',
    "ALTER TABLE i_site_configurations ADD COLUMN paypal_status ENUM('open','close') NOT NULL DEFAULT 'close' AFTER paypal_webhook_id"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'nowpayment_status',
    "ALTER TABLE i_site_configurations ADD COLUMN nowpayment_status ENUM('open','close') NOT NULL DEFAULT 'close' AFTER nowpayments_api_key"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'coinbase_status',
    "ALTER TABLE i_site_configurations ADD COLUMN coinbase_status ENUM('open','close') NOT NULL DEFAULT 'close' AFTER coinbase_commerce_webhook_secret"
);

// Provider currencies
admin_ensure_column(
    $db,
    'i_site_configurations',
    'stripe_currency',
    "ALTER TABLE i_site_configurations ADD COLUMN stripe_currency VARCHAR(10) NULL DEFAULT 'USD' AFTER stripe_status"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'paypal_currency',
    "ALTER TABLE i_site_configurations ADD COLUMN paypal_currency VARCHAR(10) NULL DEFAULT 'USD' AFTER paypal_status"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'now_payment_currency',
    "ALTER TABLE i_site_configurations ADD COLUMN now_payment_currency VARCHAR(10) NULL DEFAULT 'BTC' AFTER nowpayment_status"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'coinbase_currency',
    "ALTER TABLE i_site_configurations ADD COLUMN coinbase_currency VARCHAR(10) NULL DEFAULT 'USD' AFTER coinbase_status"
);

// Flutterwave provider columns
admin_ensure_column(
    $db,
    'i_site_configurations',
    'flutterwave_status',
    "ALTER TABLE i_site_configurations ADD COLUMN flutterwave_status ENUM('open','close') NOT NULL DEFAULT 'close' AFTER coinbase_currency"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'flutterwave_currency',
    "ALTER TABLE i_site_configurations ADD COLUMN flutterwave_currency VARCHAR(10) NULL DEFAULT 'USD' AFTER flutterwave_status"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'flutterwave_public_key',
    "ALTER TABLE i_site_configurations ADD COLUMN flutterwave_public_key TEXT NULL AFTER flutterwave_currency"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'flutterwave_secret_key',
    "ALTER TABLE i_site_configurations ADD COLUMN flutterwave_secret_key TEXT NULL AFTER flutterwave_public_key"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'flutterwave_encryption_key',
    "ALTER TABLE i_site_configurations ADD COLUMN flutterwave_encryption_key TEXT NULL AFTER flutterwave_secret_key"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'flutterwave_secret_hash',
    "ALTER TABLE i_site_configurations ADD COLUMN flutterwave_secret_hash TEXT NULL AFTER flutterwave_encryption_key"
);

// Social login provider columns
admin_ensure_column(
    $db,
    'i_site_configurations',
    'google_status',
    "ALTER TABLE i_site_configurations ADD COLUMN google_status ENUM('open','close') NOT NULL DEFAULT 'close' AFTER coinbase_currency"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'google_client_id',
    "ALTER TABLE i_site_configurations ADD COLUMN google_client_id VARCHAR(191) NULL AFTER google_status"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'google_client_secret',
    "ALTER TABLE i_site_configurations ADD COLUMN google_client_secret VARCHAR(191) NULL AFTER google_client_id"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'facebook_status',
    "ALTER TABLE i_site_configurations ADD COLUMN facebook_status ENUM('open','close') NOT NULL DEFAULT 'close' AFTER google_client_secret"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'facebook_app_id',
    "ALTER TABLE i_site_configurations ADD COLUMN facebook_app_id VARCHAR(191) NULL AFTER facebook_status"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'facebook_app_secret',
    "ALTER TABLE i_site_configurations ADD COLUMN facebook_app_secret VARCHAR(191) NULL AFTER facebook_app_id"
);

admin_ensure_column(
    $db,
    'i_site_configurations',
    'maintenance',
    "ALTER TABLE i_site_configurations ADD COLUMN maintenance ENUM('on','off') NOT NULL DEFAULT 'off' AFTER subscription_fee"
);

admin_ensure_column(
    $db,
    'i_site_configurations',
    'maintenance_eta',
    "ALTER TABLE i_site_configurations ADD COLUMN maintenance_eta INT UNSIGNED NULL AFTER maintenance"
);

admin_ensure_column(
    $db,
    'i_site_configurations',
    'maintenance_message',
    "ALTER TABLE i_site_configurations ADD COLUMN maintenance_message TEXT NULL AFTER maintenance_eta"
);

admin_ensure_column(
    $db,
    'i_site_configurations',
    'maintenance_updated_at',
    "ALTER TABLE i_site_configurations ADD COLUMN maintenance_updated_at INT UNSIGNED NULL AFTER maintenance_message"
);

admin_ensure_column(
    $db,
    'i_site_configurations',
    'maintenance_updated_by',
    "ALTER TABLE i_site_configurations ADD COLUMN maintenance_updated_by INT UNSIGNED NULL AFTER maintenance_updated_at"
);

foreach ([
    'maintenance_status_url',
    'maintenance_support_url',
    'maintenance_twitter_url',
    'maintenance_facebook_url',
    'maintenance_instagram_url',
    'maintenance_tiktok_url',
] as $column) {
    admin_ensure_column(
        $db,
        'i_site_configurations',
        $column,
        "ALTER TABLE i_site_configurations ADD COLUMN {$column} VARCHAR(255) NULL AFTER maintenance_updated_by"
    );
}
admin_ensure_column(
    $db,
    'i_site_configurations',
    'twitter_status',
    "ALTER TABLE i_site_configurations ADD COLUMN twitter_status ENUM('open','close') NOT NULL DEFAULT 'close' AFTER facebook_app_secret"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'twitter_client_id',
    "ALTER TABLE i_site_configurations ADD COLUMN twitter_client_id VARCHAR(191) NULL AFTER twitter_status"
);
admin_ensure_column(
    $db,
    'i_site_configurations',
    'twitter_client_secret',
    "ALTER TABLE i_site_configurations ADD COLUMN twitter_client_secret VARCHAR(191) NULL AFTER twitter_client_id"
);

admin_ensure_column(
    $db,
    'i_site_configurations',
    'storage_settings',
    "ALTER TABLE i_site_configurations ADD COLUMN storage_settings LONGTEXT NULL AFTER onesignal_welcome_message"
);

admin_ensure_column(
    $db,
    'i_site_configurations',
    'wallet_topup_status',
    "ALTER TABLE i_site_configurations ADD COLUMN wallet_topup_status ENUM('open','close') NOT NULL DEFAULT 'close' AFTER storage_settings"
);

admin_ensure_column(
    $db,
    'i_site_configurations',
    'wallet_topup_minimum',
    "ALTER TABLE i_site_configurations ADD COLUMN wallet_topup_minimum DECIMAL(10,2) NOT NULL DEFAULT '10.00' AFTER wallet_topup_status"
);

admin_ensure_column(
    $db,
    'i_site_configurations',
    'wallet_topup_maximum',
    "ALTER TABLE i_site_configurations ADD COLUMN wallet_topup_maximum DECIMAL(10,2) NOT NULL DEFAULT '1000.00' AFTER wallet_topup_minimum"
);

// Social login identifiers on i_users
admin_ensure_column(
    $db,
    'i_users',
    'google_id',
    "ALTER TABLE i_users ADD COLUMN google_id VARCHAR(191) NULL AFTER is_fake"
);
admin_ensure_column(
    $db,
    'i_users',
    'facebook_id',
    "ALTER TABLE i_users ADD COLUMN facebook_id VARCHAR(191) NULL AFTER google_id"
);
admin_ensure_column(
    $db,
    'i_users',
    'twitter_id',
    "ALTER TABLE i_users ADD COLUMN twitter_id VARCHAR(191) NULL AFTER facebook_id"
);

try { $db->exec('ALTER TABLE i_users ADD UNIQUE KEY idx_i_users_google_id (google_id)'); } catch (Throwable $__) {}
try { $db->exec('ALTER TABLE i_users ADD UNIQUE KEY idx_i_users_facebook_id (facebook_id)'); } catch (Throwable $__) {}
try { $db->exec('ALTER TABLE i_users ADD UNIQUE KEY idx_i_users_twitter_id (twitter_id)'); } catch (Throwable $__) {}

// CSRF helper (ensure available)
if (!isset($ADMIN_CSRF)) {
    $ADMIN_CSRF = generateCsrfToken();
}

// Simple view helpers
function adminLayout(string $title, callable $body): void {
    global $base_url, $ADMIN_CSRF, $currentTheme;
    $themeDir = __DIR__ . '/../themes/' . ($currentTheme ?: 'default');
    $themeDir = is_dir($themeDir) ? $themeDir : (__DIR__ . '/../themes/default');

    echo '<!doctype html><html lang="en"><head><meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</title>';
    // Theme head includes for consistent header/skeleton
    if (is_file($themeDir . '/head/meta.php')) { include $themeDir . '/head/meta.php'; }
    if (is_file($themeDir . '/head/css.php'))  { include $themeDir . '/head/css.php'; }
    // Admin overrides last
    echo '<link rel="stylesheet" href="/ReelsProject/admin/assets/admin.css">';
    // CSRF for JS (no inline <script>)
    echo '<meta name="admin-csrf" content="' . htmlspecialchars($ADMIN_CSRF, ENT_QUOTES, 'UTF-8') . '">';
    // Load minimal theme boot/js helpers (CSP-safe, local)
    if (is_file($themeDir . '/head/js.php')) { include $themeDir . '/head/js.php'; }
    echo '</head><body>';
    echo '<div class="site_container flex flexBoxColumn">';
      // Theme header
      if (is_file($themeDir . '/header/header.php')) { include $themeDir . '/header/header.php'; }
      // Shell with left sidebar
      echo '<div class="sidebar_container flex relative sidebar_scroll">';
        if (is_file($themeDir . '/menu/left_menu.php')) { include $themeDir . '/menu/left_menu.php'; }
        echo '<div class="main-content flex align_items">';
          echo '<div class="content-area flex">';
            echo '<div class="content-left">';
              echo '<div class="content-left-container flex align_items flexBoxColumn">';
                // Admin local nav (themed) + page body
                include __DIR__ . '/menu.php';
                echo '<div class="admin-container full-width">';
                $body();
                echo '</div>';
              echo '</div>';
            echo '</div>';
          echo '</div>';
        echo '</div>';
      echo '</div>';
    echo '<script src="' . htmlspecialchars($base_url . 'admin/assets/admin.js', ENT_QUOTES, 'UTF-8') . '"></script>';
    echo '</body></html>';
}
