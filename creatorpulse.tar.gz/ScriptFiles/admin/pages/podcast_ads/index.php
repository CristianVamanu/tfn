<?php
declare(strict_types=1);

$csrfToken = isset($ADMIN_CSRF) ? (string) $ADMIN_CSRF : generateCsrfToken();
$statusFilter = isset($_GET['status']) ? strtolower(trim((string) $_GET['status'])) : '';
$allowedStatuses = ['pending', 'approved', 'rejected'];
if ($statusFilter !== '' && !in_array($statusFilter, $allowedStatuses, true)) {
    $statusFilter = '';
}

$filters = [];
if ($statusFilter !== '') {
    $filters['status'] = $statusFilter;
}

$ads = $ADM->ADM_ListPodcastAds($filters, 200);
$currencyCode = isset($currency) && is_string($currency) ? (string) $currency : (isset($default_currency) ? (string) $default_currency : 'USD');

$title = customLang('hero_ads_manage', 'Podcast Hero Ads');
$subtitle = customLang('hero_ads_subtitle', 'High-impact hero placements for podcasts.');
$filterLabel = customLang('hero_ads_filter_status', 'Filter by status');
$noAdsLabel = customLang('hero_ads_no_ads', 'No ads yet.');
$sponsoredLabel = customLang('hero_ads_sponsored', 'Sponsored');
$statusLabels = [
    'pending'  => customLang('hero_ads_status_pending', 'Pending'),
    'approved' => customLang('hero_ads_status_approved', 'Approved'),
    'rejected' => customLang('hero_ads_status_rejected', 'Rejected'),
];
$actionApprove = customLang('hero_ads_action_approve', 'Approve');
$actionReject = customLang('hero_ads_action_reject', 'Reject');
$actionDelete = customLang('hero_ads_action_delete', 'Delete');
$dateLabel = customLang('hero_ads_date_range', 'Dates');
$impressionsLabel = customLang('hero_ads_impressions', 'Impressions');
$clickLabel = customLang('hero_ads_click', 'Clicks');
$deleteConfirm = customLang('hero_ads_confirm_delete', 'Delete this ad?');
$packageColumnLabel = customLang('hero_ads_package_column', 'Package / Payment');

$statusCounts = ['pending' => 0, 'approved' => 0, 'rejected' => 0];
$totalImpressions = 0;
$totalClicks = 0;
foreach ($ads as $ad) {
    $status = strtolower((string) ($ad['status'] ?? 'pending'));
    if (isset($statusCounts[$status])) {
        $statusCounts[$status]++;
    }
    $totalImpressions += (int) ($ad['impressions'] ?? 0);
    $totalClicks += (int) ($ad['clicks_primary'] ?? 0) + (int) ($ad['clicks_secondary'] ?? 0);
}
$totalAds = count($ads);
$packagesLink = rtrim((string) $base_url, '/') . '/admin/index.php?page=podcast_ad_packages';
$categoriesLink = rtrim((string) $base_url, '/') . '/admin/index.php?page=podcast_categories';
?>
<section class="admin-hero podcast-ads-hero rounded-2xl flex align_items space_between">
    <div class="admin-hero__text">
        <h1 class="admin-hero__title"><?php echo iN_HelpSecure($title); ?></h1>
        <p class="admin-hero__subtitle"><?php echo iN_HelpSecure($subtitle); ?></p>
        <div class="admin-hero__chips">
            <span class="admin-chip admin-chip--primary"><?php echo iN_HelpSecure(customLang('hero_ads_status_approved', 'Approved')); ?>: <?php echo (int) $statusCounts['approved']; ?></span>
            <span class="admin-chip admin-chip--warning"><?php echo iN_HelpSecure(customLang('hero_ads_status_pending', 'Pending')); ?>: <?php echo (int) $statusCounts['pending']; ?></span>
            <span class="admin-chip admin-chip--muted"><?php echo iN_HelpSecure(customLang('hero_ads_status_rejected', 'Rejected')); ?>: <?php echo (int) $statusCounts['rejected']; ?></span>
        </div>
        <div class="admin-hero__actions">
            <a class="admin-button admin-button--primary" href="<?php echo iN_HelpSecure($packagesLink); ?>">
                <?php echo iN_HelpSecure(customLang('admin_menu_podcast_packages', 'Ad Packages')); ?>
            </a>
            <a class="admin-button admin-button--neutral" href="<?php echo iN_HelpSecure($categoriesLink); ?>">
                <?php echo iN_HelpSecure(customLang('admin_menu_podcast_categories', 'Podcast categories')); ?>
            </a>
        </div>
    </div>
    <div class="admin-hero__meta">
        <div class="hero-kpi">
            <div class="hero-kpi__label"><?php echo iN_HelpSecure(customLang('total', 'Total')); ?></div>
            <div class="hero-kpi__value"><?php echo (int) $totalAds; ?></div>
        </div>
        <div class="hero-kpi">
            <div class="hero-kpi__label"><?php echo iN_HelpSecure(customLang('hero_ads_impressions', 'Impressions')); ?></div>
            <div class="hero-kpi__value"><?php echo number_format($totalImpressions); ?></div>
        </div>
        <div class="hero-kpi">
            <div class="hero-kpi__label"><?php echo iN_HelpSecure($clickLabel); ?></div>
            <div class="hero-kpi__value"><?php echo number_format($totalClicks); ?></div>
        </div>
    </div>
</section>


<section class="card rounded-2xl mt-6" role="region" aria-labelledby="podcastAdsHeading">
    <div class="card-header flex align_items space_between">
        <div>
            <h1 id="podcastAdsHeading"><?php echo iN_HelpSecure($title); ?></h1>
            <p class="text-muted"><?php echo iN_HelpSecure(customLang('hero_ads_filter_status', 'Filter by status')); ?></p>
        </div>
        <form method="get" class="flex align_items gap filter-bar">
            <input type="hidden" name="page" value="podcast_ads">
            <label class="form-label" for="podcastAdStatus"><?php echo iN_HelpSecure(customLang('admin_filter_status', 'Status')); ?></label>
            <select id="podcastAdStatus" class="form-input" name="status">
                <option value=""><?php echo iN_HelpSecure(customLang('admin_filter_status', 'Status')); ?></option>
                <?php foreach ($allowedStatuses as $statusOpt): ?>
                    <option value="<?php echo iN_HelpSecure($statusOpt); ?>"<?php echo $statusFilter === $statusOpt ? ' selected' : ''; ?>>
                        <?php echo iN_HelpSecure($statusLabels[$statusOpt] ?? ucfirst($statusOpt)); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button class="admin-button admin-button--primary" type="submit"><?php echo iN_HelpSecure(customLang('apply', 'Apply')); ?></button>
            <?php if ($statusFilter !== ''): ?>
                <a class="admin-button admin-button--ghost" href="<?php echo iN_HelpSecure(rtrim((string)$base_url, '/') . '/admin/index.php?page=podcast_ads'); ?>"><?php echo iN_HelpSecure(customLang('reset', 'Reset')); ?></a>
            <?php endif; ?>
        </form>
    </div>
    <div class="table-responsive" id="podcastAdsTableWrapper">
        <table class="table table-striped table-sm table-subs table-users podcast-ads-table" aria-label="<?php echo iN_HelpSecure($title); ?>">
            <thead>
                <tr>
                    <th><?php echo iN_HelpSecure(customLang('hero_ads_title', 'Title')); ?></th>
                    <th><?php echo iN_HelpSecure($packageColumnLabel); ?></th>
                    <th><?php echo iN_HelpSecure(customLang('hero_ads_filter_status', 'Status')); ?></th>
                    <th><?php echo iN_HelpSecure($dateLabel); ?></th>
                    <th><?php echo iN_HelpSecure($impressionsLabel); ?></th>
                    <th><?php echo iN_HelpSecure($clickLabel); ?></th>
                    <th><?php echo iN_HelpSecure(customLang('hero_ads_action_approve', 'Approve')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$ads): ?>
                    <tr>
                        <td colspan="7"><?php echo iN_HelpSecure($noAdsLabel); ?></td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($ads as $ad):
                        $status = strtolower((string) ($ad['status'] ?? 'pending'));
                        $username = (string) ($ad['username'] ?? '');
                        $fullname = (string) ($ad['user_fullname'] ?? '');
                        $ownerLabel = $fullname !== '' ? $fullname : ($username !== '' ? $username : ('#' . (int) ($ad['created_by'] ?? 0)));
                        $startAt = isset($ad['start_at']) && $ad['start_at'] ? date('Y-m-d', (int) $ad['start_at']) : '—';
                        $endAt = isset($ad['end_at']) && $ad['end_at'] ? date('Y-m-d', (int) $ad['end_at']) : '—';
                        $impressions = (int) ($ad['impressions'] ?? 0);
                        $clicksPrimary = (int) ($ad['clicks_primary'] ?? 0);
                        $clicksSecondary = (int) ($ad['clicks_secondary'] ?? 0);
                        $coverPath = (string) ($ad['cover_path'] ?? '');
                        $coverUrl = $coverPath !== '' ? storage_url($coverPath) : '';
                        $packageName = (string) ($ad['package_name'] ?? '');
                        $paymentAmount = isset($ad['payment_amount']) ? (float) $ad['payment_amount'] : null;
                        $paymentCurrency = (string) ($ad['payment_currency'] ?? $currencyCode);
                        $paymentStatus = (string) ($ad['payment_status'] ?? '');
                        $pillClass = 'pill-gray';
                        if ($status === 'approved') { $pillClass = 'pill-green'; }
                        elseif ($status === 'pending') { $pillClass = 'pill-amber'; }
                        elseif ($status === 'rejected') { $pillClass = 'pill-red'; }
                    ?>
                    <tr class="podcast-ad-row" data-ad-id="<?php echo (int) ($ad['id'] ?? 0); ?>">
                        <td>
                            <div class="podcast-ad-meta">
                                <?php if ($coverUrl !== ''): ?>
                                    <img src="<?php echo iN_HelpSecure($coverUrl); ?>" alt="" class="table-thumb podcast-ad-thumb" loading="lazy">
                                <?php endif; ?>
                                <div class="podcast-ad-text">
                                    <div class="podcast-ad-title"><?php echo htmlspecialchars((string) ($ad['title'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></div>
                                    <div class="podcast-ad-owner text-muted">
                                        <?php echo iN_HelpSecure($ownerLabel); ?>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <?php if ($packageName !== ''): ?>
                                <div class="fw-600"><?php echo htmlspecialchars($packageName, ENT_QUOTES, 'UTF-8'); ?></div>
                            <?php endif; ?>
                            <?php if ($paymentAmount !== null): ?>
                                <div class="text-muted fs-13">
                                    <?php echo number_format($paymentAmount, 2); ?> <?php echo iN_HelpSecure(strtoupper($paymentCurrency)); ?>
                                    <?php if ($paymentStatus !== ''): ?>
                                        (<?php echo iN_HelpSecure(ucfirst($paymentStatus)); ?>)
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="pill <?php echo iN_HelpSecure($pillClass); ?>">
                                <?php echo iN_HelpSecure($statusLabels[$status] ?? ucfirst($status)); ?>
                            </span>
                        </td>
                        <td class="text-nowrap"><?php echo iN_HelpSecure($startAt . ' → ' . $endAt); ?></td>
                        <td><?php echo number_format($impressions); ?></td>
                        <td><?php echo number_format($clicksPrimary + $clicksSecondary); ?></td>
                        <td class="table-actions">
                            <div class="post-settings-btn-box flex align_items relative">
                                <button
                                    type="button"
                                    class="post-settings-btn flex align_items_justify_content relative js-podcast-ad-actions"
                                    aria-expanded="false"
                                    aria-haspopup="menu"
                                    title="<?php echo iN_HelpSecure($actionApprove); ?>"
                                    data-ad-id="<?php echo (int) ($ad['id'] ?? 0); ?>"
                                >
                                    <?php echo renderVerifiedBadge($iconPath . 'dots.svg', false); ?>
                                </button>
                            </div>

                            <div id="podcastAdMenu-<?php echo (int) ($ad['id'] ?? 0); ?>" class="post-menu-popup none" aria-hidden="true" role="dialog" aria-label="<?php echo iN_HelpSecure('Ad actions for #' . (int) ($ad['id'] ?? 0), false); ?>">
                                <div class="pm-sheet-container">
                                    <div class="pm-sheet">
                                        <button type="button" class="pm-item flex align_items_justify_content js-podcast-ad-act"
                                            data-action="approve"
                                            data-podcast-ad-action="approve"
                                            data-ad-id="<?php echo (int) ($ad['id'] ?? 0); ?>"<?php echo $status === 'approved' ? ' disabled' : ''; ?>>
                                            <?php echo renderVerifiedBadge($iconPath . 'tick.svg', true); ?>
                                            <span><?php echo iN_HelpSecure($actionApprove); ?></span>
                                        </button>
                                        <button type="button" class="pm-item flex align_items_justify_content js-podcast-ad-act"
                                            data-action="reject"
                                            data-podcast-ad-action="reject"
                                            data-ad-id="<?php echo (int) ($ad['id'] ?? 0); ?>"<?php echo $status === 'rejected' ? ' disabled' : ''; ?>>
                                            <?php echo renderVerifiedBadge($iconPath . 'ban.svg', true); ?>
                                            <span><?php echo iN_HelpSecure($actionReject); ?></span>
                                        </button>
                                        <button type="button" class="pm-item flex align_items_justify_content js-podcast-ad-act is-danger"
                                            data-action="delete"
                                            data-podcast-ad-action="delete"
                                            data-ad-id="<?php echo (int) ($ad['id'] ?? 0); ?>">
                                            <?php echo renderVerifiedBadge($iconPath . 'delete.svg', true); ?>
                                            <span><?php echo iN_HelpSecure($actionDelete); ?></span>
                                        </button>
                                        <button type="button" class="pm-item pm-cancel"><?php echo iN_HelpSecure(customLang('cancel', 'Cancel')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
