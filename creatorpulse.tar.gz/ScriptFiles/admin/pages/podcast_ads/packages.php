<?php
declare(strict_types=1);

global $currentLang, $currencyFormatSettings;
$csrfToken = isset($ADMIN_CSRF) ? (string) $ADMIN_CSRF : generateCsrfToken();
$langDir = dirname(__DIR__, 3) . '/langs';
$langOptions = [];
if (is_dir($langDir)) {
    foreach (scandir($langDir) as $entry) {
        if (preg_match('/^(\w+)\.php$/', (string) $entry, $m)) {
            $langOptions[] = strtolower((string) $m[1]);
        }
    }
}
if (!$langOptions) {
    $langOptions = ['eng'];
}
$defaultLang = strtolower((string) ($langOptions[0] ?? 'eng')) ?: 'eng';
$currentLocale = isset($currentLang) ? strtolower((string) $currentLang) : $defaultLang;
if (!in_array($currentLocale, $langOptions, true)) {
    $currentLocale = $defaultLang;
}
$defaultLang = $currentLocale !== '' ? $currentLocale : $defaultLang;

$packages = $ADM->ADM_ListPodcastAdPackages(null, $currentLocale, $langOptions);
$currencyCode = isset($currency) && is_string($currency) ? (string) $currency : (isset($default_currency) ? (string) $default_currency : 'USD');
$currencyMap = (isset($currencys) && is_array($currencys)) ? $currencys : ((isset($currencies) && is_array($currencies)) ? $currencies : []);
$formatCurrency = static function (float $amount, ?string $code = null) use ($currencyMap, $currencyFormatSettings): string {
    $currencyCode = strtoupper($code !== null && $code !== '' ? (string) $code : 'USD');
    $symbol = isset($currencyMap[$currencyCode]) ? (string) $currencyMap[$currencyCode] : '';
    return dz_format_currency($amount, $currencyCode, $symbol, $currencyFormatSettings ?? null);
};

$packages = is_array($packages) ? $packages : [];
if ($packages) {
    foreach ($packages as &$pkgRow) {
        if (!isset($pkgRow['translations']) || !is_array($pkgRow['translations'])) {
            $pkgRow['translations'] = [];
        }
    }
    unset($pkgRow);
}

$title = customLang('admin_menu_podcast_packages', 'Podcast ad packages');
$subtitle = customLang('hero_ads_subtitle', 'Curate premium inventory for podcast hero placements.');
$ctaLabel = customLang('hero_ads_manage', 'Podcast Hero Ads');
$packagesEmpty = customLang('hero_ads_package_empty', 'No packages available.');
$packageSave = customLang('hero_ads_package_save', 'Save package');
$packageTitle = customLang('hero_ads_package_admin_title', 'Packages');
$packageNameLabel = customLang('hero_ads_package_name', 'Name');
$packagePriceLabel = customLang('hero_ads_package_price', 'Price');
$packageDurationLabel = customLang('hero_ads_package_duration', 'Duration (days)');
$packageDailyLabel = customLang('hero_ads_package_daily', 'Daily cap');
$packageTotalLabel = customLang('hero_ads_package_total', 'Total cap');
$packagePremiumLabel = customLang('hero_ads_package_premium_multiplier', 'Premium multiplier');
$packageTargetingLabel = customLang('hero_ads_package_targeting_fee', 'Targeting fee');
$packageStatusLabel = customLang('hero_ads_package_status', 'Status');
$packageSortLabel = customLang('hero_ads_package_sort', 'Sort');

$totalPackages = count($packages);
$activePackages = 0;
$inactivePackages = 0;
$sumPrice = 0.0;
$premiumAverage = 0.0;
foreach ($packages as $pkg) {
    $status = strtolower((string) ($pkg['status'] ?? 'inactive'));
    if ($status === 'active') {
        $activePackages++;
    } else {
        $inactivePackages++;
    }
    $sumPrice += (float) ($pkg['price'] ?? 0);
    $premiumAverage += (float) ($pkg['premium_multiplier'] ?? 0);
}
$avgPrice = $totalPackages > 0 ? $sumPrice / $totalPackages : 0;
$avgPremium = $totalPackages > 0 ? $premiumAverage / $totalPackages : 0;
?>

<section class="admin-hero podcast-ads-hero rounded-2xl flex align_items space_between">
    <div class="admin-hero__text">
        <h1 class="admin-hero__title"><?php echo iN_HelpSecure($title); ?></h1>
        <p class="admin-hero__subtitle"><?php echo iN_HelpSecure($subtitle); ?></p>
        <div class="admin-hero__chips">
            <span class="admin-chip admin-chip--primary"><?php echo iN_HelpSecure(customLang('active', 'Active')); ?>: <?php echo (int) $activePackages; ?></span>
            <span class="admin-chip admin-chip--muted"><?php echo iN_HelpSecure(customLang('inactive', 'Inactive')); ?>: <?php echo (int) $inactivePackages; ?></span>
            <span class="admin-chip admin-chip--outline"><?php echo iN_HelpSecure(customLang('total', 'Total')); ?>: <?php echo (int) $totalPackages; ?></span>
        </div>
        <div class="admin-hero__actions">
            <a class="admin-button admin-button--neutral" href="<?php echo iN_HelpSecure(rtrim((string) $base_url, '/') . '/admin/index.php?page=podcast_ads'); ?>">
                <?php echo iN_HelpSecure($ctaLabel); ?>
            </a>
            <button type="button" class="admin-button admin-button--primary" data-podcast-package-action="reset">
                <?php echo iN_HelpSecure(customLang('create_new', 'Create new')); ?>
            </button>
        </div>
    </div>
    <div class="admin-hero__meta">
        <div class="hero-kpi">
            <div class="hero-kpi__label"><?php echo iN_HelpSecure(customLang('average', 'Average price')); ?></div>
            <div class="hero-kpi__value"><?php echo iN_HelpSecure($formatCurrency($avgPrice, $currencyCode)); ?></div>
        </div>
        <div class="hero-kpi">
            <div class="hero-kpi__label"><?php echo iN_HelpSecure(customLang('hero_ads_package_premium_multiplier', 'Premium multiplier')); ?></div>
            <div class="hero-kpi__value"><?php echo number_format($avgPremium, 1); ?>×</div>
        </div>
    </div>
</section>

<div class="admin-grid mt-6 podcast-package-grid">
    <section class="card rounded-2xl" role="region" aria-labelledby="podcastPackageFormHeading">
        <div class="card-header flex align_items space_between">
            <h2 id="podcastPackageFormHeading"><?php echo iN_HelpSecure($packageTitle); ?></h2>
            <span class="text-muted"><?php echo iN_HelpSecure(customLang('save_changes', 'Save changes')); ?></span>
        </div>
        <form
            id="podcastAdPackageForm"
            class="form-grid"
            action="<?php echo iN_HelpSecure(rtrim((string) $base_url, '/') . '/admin/request/podcast_ad_packages.php'); ?>"
            method="post"
            data-languages="<?php echo iN_HelpSecure(json_encode($langOptions, JSON_UNESCAPED_UNICODE), false, 0, false); ?>"
            data-default-lang="<?php echo iN_HelpSecure($defaultLang); ?>"
        >
            <input type="hidden" name="csrf_token" value="<?php echo iN_HelpSecure($csrfToken, false); ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="package_id" id="podcastPackageId" value="">
            <input type="hidden" name="default_lang" value="<?php echo iN_HelpSecure($defaultLang); ?>">

            <div class="form-group form-group--full" data-lang-switcher>
                <div class="landing-lang-tabs" data-lang-tabs role="tablist" aria-label="<?php echo iN_HelpSecure($packageNameLabel); ?>">
                    <?php foreach ($langOptions as $index => $langCode):
                        $langKey = strtolower((string) $langCode);
                        $langSafe = iN_HelpSecure($langKey);
                        $isActive = $langKey === $defaultLang || ($defaultLang === '' && $index === 0);
                    ?>
                        <button type="button" class="landing-lang-tab<?php echo $isActive ? ' is-active' : ''; ?>" data-lang-target="<?php echo $langSafe; ?>" aria-selected="<?php echo $isActive ? 'true' : 'false'; ?>"><?php echo iN_HelpSecure(strtoupper((string) $langCode)); ?></button>
                    <?php endforeach; ?>
                </div>

                <?php foreach ($langOptions as $index => $langCode):
                    $langKey = strtolower((string) $langCode);
                    $langSafe = iN_HelpSecure($langKey);
                    $isActive = $langKey === $defaultLang || ($defaultLang === '' && $index === 0);
                    $isDefaultLang = $langKey === $defaultLang;
                ?>
                <div class="landing-lang-panel<?php echo $isActive ? ' is-active' : ''; ?>" data-lang-panel="<?php echo $langSafe; ?>" aria-hidden="<?php echo $isActive ? 'false' : 'true'; ?>"<?php echo $isActive ? '' : ' hidden'; ?>>
                    <label class="form-label" for="packageName_<?php echo $langSafe; ?>">
                        <?php echo iN_HelpSecure($packageNameLabel); ?>
                        <span class="text-muted">(<?php echo iN_HelpSecure(strtoupper((string) $langCode)); ?>)</span>
                    </label>
                    <input
                        class="form-input"
                        type="text"
                        id="packageName_<?php echo $langSafe; ?>"
                        name="name[<?php echo $langSafe; ?>]"
                        data-package-name-lang="<?php echo $langSafe; ?>"
                        maxlength="120"
                        <?php echo $isDefaultLang ? 'required aria-required="true"' : ''; ?>
                    >

                    <label class="form-label" for="packageDescription_<?php echo $langSafe; ?>">
                        <?php echo iN_HelpSecure(customLang('hero_ads_subtitle', 'Subtitle')); ?>
                        <span class="text-muted">(<?php echo iN_HelpSecure(strtoupper((string) $langCode)); ?>)</span>
                    </label>
                    <textarea
                        class="form-input"
                        id="packageDescription_<?php echo $langSafe; ?>"
                        name="description[<?php echo $langSafe; ?>]"
                        data-package-desc-lang="<?php echo $langSafe; ?>"
                        rows="2"
                        maxlength="255"
                    ></textarea>
                </div>
                <?php endforeach; ?>
            </div>

            <label class="form-group">
                <span class="form-label"><?php echo iN_HelpSecure($packagePriceLabel); ?></span>
                <input class="form-input" type="number" step="0.01" min="0" id="packagePrice" name="price" required>
                <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('hero_ads_package_hint_price', 'Charge creators this amount for the package.')); ?></small>
            </label>
            <label class="form-group">
                <span class="form-label"><?php echo iN_HelpSecure(customLang('currency', 'Currency')); ?></span>
                <input class="form-input" type="text" id="packageCurrency" name="currency" value="<?php echo iN_HelpSecure($currencyCode); ?>" maxlength="5">
            </label>
            <label class="form-group">
                <span class="form-label"><?php echo iN_HelpSecure($packageDurationLabel); ?></span>
                <input class="form-input" type="number" min="1" id="packageDuration" name="duration_days" value="7" required>
                <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('hero_ads_package_hint_duration', 'How many days the campaign stays active.')); ?></small>
            </label>
            <label class="form-group">
                <span class="form-label"><?php echo iN_HelpSecure($packageDailyLabel); ?></span>
                <input class="form-input" type="number" min="0" id="packageDaily" name="daily_cap" placeholder="0">
                <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('hero_ads_package_hint_daily_cap', 'Max impressions per day (0 for unlimited).')); ?></small>
            </label>
            <label class="form-group">
                <span class="form-label"><?php echo iN_HelpSecure($packageTotalLabel); ?></span>
                <input class="form-input" type="number" min="0" id="packageTotal" name="total_cap" placeholder="0">
                <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('hero_ads_package_hint_total_cap', 'Max total impressions (0 for unlimited).')); ?></small>
            </label>
            <label class="form-group">
                <span class="form-label"><?php echo iN_HelpSecure($packagePremiumLabel); ?></span>
                <input class="form-input" type="number" step="0.1" min="1" id="packagePremium" name="premium_multiplier" value="2">
                <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('hero_ads_package_hint_premium', 'Multiplier applied when premium placement is chosen.')); ?></small>
            </label>
            <label class="form-group">
                <span class="form-label"><?php echo iN_HelpSecure($packageTargetingLabel); ?></span>
                <input class="form-input" type="number" step="0.01" min="0" id="packageTargeting" name="targeting_fee" placeholder="0">
                <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('hero_ads_package_hint_targeting', 'Extra fee when targeting is enabled (optional).')); ?></small>
            </label>
            <label class="form-group">
                <span class="form-label"><?php echo iN_HelpSecure($packageStatusLabel); ?></span>
                <select class="form-input" id="packageStatus" name="status">
                    <option value="active"><?php echo iN_HelpSecure(customLang('active', 'Active')); ?></option>
                    <option value="inactive"><?php echo iN_HelpSecure(customLang('inactive', 'Inactive')); ?></option>
                </select>
                <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('hero_ads_package_hint_status', 'Controls whether buyers can see this package.')); ?></small>
            </label>
            <label class="form-group">
                <span class="form-label"><?php echo iN_HelpSecure($packageSortLabel); ?></span>
                <input class="form-input" type="number" min="0" id="packageSort" name="sort_order" value="0">
                <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('hero_ads_package_hint_sort', 'Lower numbers appear first in the list.')); ?></small>
            </label>
            <div class="form-actions">
                <button type="submit" class="admin-button admin-button--primary" data-podcast-package-action="save">
                    <?php echo iN_HelpSecure($packageSave); ?>
                </button>
                <button type="button" class="admin-button admin-button--ghost" data-podcast-package-action="reset">
                    <?php echo iN_HelpSecure(customLang('reset', 'Reset')); ?>
                </button>
            </div>
        </form>
    </section>

    <section class="card rounded-2xl" role="region" aria-labelledby="podcastPackageTableHeading">
        <div class="list-header" id="podcastPackageTableHeading">
            <span class="icon"><?php echo renderVerifiedBadge($iconPath . 'dashboard_user.svg', true); ?></span>
            <span><strong><?php echo iN_HelpSecure(customLang('hero_ads_package_column', 'Package / Payment')); ?></strong></span>
            <span class="text-muted"><?php echo iN_HelpSecure(customLang('admin_total_records', 'Total')); ?>: <?php echo (int) $totalPackages; ?></span>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-sm table-subs table-users podcast-packages-table" aria-label="<?php echo iN_HelpSecure($packageTitle); ?>">
                <thead>
                    <tr>
                        <th><?php echo iN_HelpSecure($packageNameLabel); ?></th>
                        <th><?php echo iN_HelpSecure(customLang('hero_ads_package_description', 'Description')); ?></th>
                        <th><?php echo iN_HelpSecure($packagePriceLabel); ?></th>
                        <th><?php echo iN_HelpSecure($packageDurationLabel); ?></th>
                        <th><?php echo iN_HelpSecure($packageDailyLabel); ?></th>
                        <th><?php echo iN_HelpSecure($packageTotalLabel); ?></th>
                        <th><?php echo iN_HelpSecure($packagePremiumLabel); ?></th>
                        <th><?php echo iN_HelpSecure($packageTargetingLabel); ?></th>
                        <th><?php echo iN_HelpSecure($packageStatusLabel); ?></th>
                        <th><?php echo iN_HelpSecure(customLang('actions', 'Actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!$packages): ?>
                        <tr><td colspan="10" class="text-center text-muted"><?php echo iN_HelpSecure($packagesEmpty); ?></td></tr>
                    <?php else: ?>
                        <?php foreach ($packages as $pkg): ?>
                            <?php $status = strtolower((string) ($pkg['status'] ?? 'inactive')); ?>
                            <?php $translationsData = iN_HelpSecure(json_encode($pkg['translations'] ?? [], JSON_UNESCAPED_UNICODE), false, 0, false); ?>
                            <tr data-package-id="<?php echo (int) ($pkg['id'] ?? 0); ?>">
                                <td>
                                    <strong><?php echo htmlspecialchars((string) ($pkg['name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></strong>
                                </td>
                                <td class="package-description">
                                    <?php if (!empty($pkg['description'])): ?>
                                        <span><?php echo htmlspecialchars((string) $pkg['description'], ENT_QUOTES, 'UTF-8'); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>
                                <?php $pkgCurrencyCode = (string) ($pkg['currency'] ?? $currencyCode); ?>
                                <td><?php echo iN_HelpSecure($formatCurrency((float) ($pkg['price'] ?? 0), $pkgCurrencyCode)); ?></td>
                                <td><?php echo (int) ($pkg['duration_days'] ?? 0); ?></td>
                                <td><?php echo isset($pkg['daily_cap']) ? (int) $pkg['daily_cap'] : '—'; ?></td>
                                <td><?php echo isset($pkg['total_cap']) ? (int) $pkg['total_cap'] : '—'; ?></td>
                                <td><?php echo htmlspecialchars((string) ($pkg['premium_multiplier'] ?? '1'), ENT_QUOTES, 'UTF-8'); ?></td>
                                <td>
                                    <?php if (isset($pkg['targeting_fee'])): ?>
                                        <?php echo iN_HelpSecure($formatCurrency((float) $pkg['targeting_fee'], $pkgCurrencyCode)); ?>
                                    <?php else: ?>
                                        &mdash;
                                    <?php endif; ?>
                                </td>
                                <td><span class="pill <?php echo $status === 'active' ? 'pill-green' : 'pill-gray'; ?>"><?php echo iN_HelpSecure(ucfirst($status)); ?></span></td>
                                <td>
                                    <button type="button" class="admin-button admin-button--ghost" data-podcast-package-edit
                                        data-package-id="<?php echo (int) ($pkg['id'] ?? 0); ?>"
                                        data-package-name="<?php echo iN_HelpSecure((string) ($pkg['name'] ?? ''), false); ?>"
                                        data-package-description="<?php echo iN_HelpSecure((string) ($pkg['description'] ?? ''), false); ?>"
                                        data-package-price="<?php echo iN_HelpSecure((string) ($pkg['price'] ?? '0'), false); ?>"
                                        data-package-currency="<?php echo iN_HelpSecure((string) ($pkg['currency'] ?? $currencyCode), false); ?>"
                                        data-package-duration="<?php echo (int) ($pkg['duration_days'] ?? 0); ?>"
                                        data-package-daily="<?php echo isset($pkg['daily_cap']) ? (int) $pkg['daily_cap'] : ''; ?>"
                                        data-package-total="<?php echo isset($pkg['total_cap']) ? (int) $pkg['total_cap'] : ''; ?>"
                                        data-package-premium="<?php echo iN_HelpSecure((string) ($pkg['premium_multiplier'] ?? '1'), false); ?>"
                                        data-package-targeting="<?php echo isset($pkg['targeting_fee']) ? iN_HelpSecure((string) $pkg['targeting_fee'], false) : ''; ?>"
                                        data-package-status="<?php echo iN_HelpSecure((string) ($pkg['status'] ?? 'active'), false); ?>"
                                        data-package-sort="<?php echo (int) ($pkg['sort_order'] ?? 0); ?>"
                                        data-package-translations="<?php echo $translationsData; ?>">
                                        <?php echo iN_HelpSecure(customLang('edit', 'Edit')); ?>
                                    </button>
                                    <button type="button" class="admin-button admin-button--danger" data-podcast-package-action="delete" data-package-id="<?php echo (int) ($pkg['id'] ?? 0); ?>">
                                        <?php echo iN_HelpSecure(customLang('delete', 'Delete')); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>
