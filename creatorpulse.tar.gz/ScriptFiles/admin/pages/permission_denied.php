<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

$title = customLang('admin_permission_denied_title') ?: 'Permission denied';
$message = customLang('admin_permission_denied_message') ?: 'You do not have permission to access this page.';
?>

<section class="card rounded-2xl" role="region" aria-labelledby="adminPermissionDeniedHeading">
  <div class="list-header" id="adminPermissionDeniedHeading">
    <span><strong><?php echo iN_HelpSecure($title, false); ?></strong></span>
  </div>
  <div class="p-4 text-muted">
    <?php echo iN_HelpSecure($message, false); ?>
  </div>
</section>
