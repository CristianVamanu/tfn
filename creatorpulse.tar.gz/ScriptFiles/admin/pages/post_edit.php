<?php
declare(strict_types=1);
require_once __DIR__ . '/../_bootstrap.php';

global $base_url, $ADMIN_CSRF, $iconPath, $RL, $ADM, $userData;

$pid = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($pid <= 0) {
  echo '<section class="card rounded-2xl"><div class="list-header"><strong>Invalid post</strong></div></section>';
  return;
}

$post = ($RL && method_exists($RL, 'RL_GetPostData')) ? ($RL->RL_GetPostData($pid) ?: []) : [];
if (!$post) {
  echo '<section class="card rounded-2xl"><div class="list-header"><strong>Post not found</strong></div></section>';
  return;
}

$ownerId   = (int)($post['post_owner_id'] ?? 0);
$owner     = ($RL && method_exists($RL, 'RL_GetUserDetails')) ? ($RL->RL_GetUserDetails($ownerId) ?: []) : [];
$ownerU    = (string)($owner['username'] ?? '');
$ownerName = (string)($owner['user_fullname'] ?? $ownerU);
$ownerAvRel = ($RL && method_exists($RL, 'RL_userAvatar')) ? $RL->RL_userAvatar($ownerId) : 'uploads/user_avatars/default.jpeg';
$ownerAv   = admin_resolve_media_url($ownerAvRel);
$filePathsDb = ($RL && method_exists($RL, 'RL_GetPostMediaPaths')) ? $RL->RL_GetPostMediaPaths($pid) : [];
$postFilesRaw = (string)($post['post_file'] ?? '');
$postFilesArr = array_filter(array_map('trim', explode(',', $postFilesRaw)), static function($s){ return $s !== ''; });

// Build media list consistent with post_view.php behavior:
// - image: comma-separated list in i_user_posts.post_file (relative paths)
// - video: single path in i_user_posts.post_file
// - also include i_post_media rows if present
$__mediaSet = [];
$filePaths = [];
foreach ((array)$filePathsDb as $__p) {
  $__p = ltrim((string)$__p, '/'); if ($__p === '' || isset($__mediaSet[$__p])) continue; $__mediaSet[$__p] = true; $filePaths[] = $__p;
}
if (strtolower((string)($post['post_type'] ?? '')) === 'image') {
  foreach ($postFilesArr as $__p) { $__p = ltrim((string)$__p, '/'); if ($__p === '' || isset($__mediaSet[$__p])) continue; $__mediaSet[$__p] = true; $filePaths[] = $__p; }
} else {
  if ($postFilesRaw !== '') { $__p = ltrim($postFilesRaw, '/'); if ($__p !== '' && !isset($__mediaSet[$__p])) { $__mediaSet[$__p]=true; $filePaths[] = $__p; } }
}

$postType  = (string)($post['post_type'] ?? 'image');
$postText  = (string)($post['post_text'] ?? '');
$vis       = (string)($post['post_visibility'] ?? 'everyone');
$price     = (int)($post['post_price'] ?? 0);
$cStatus   = (string)($post['comment_status'] ?? 'on');
$createdTs = (int)($post['post_created_time'] ?? 0);
$created   = $createdTs > 0 ? date('Y-m-d H:i', $createdTs) : '-';

$postUrl   = iN_HelpSecure(($base_url ?? '/') . 'posts/' . (string)$pid, false);
$ownerUrl  = iN_HelpSecure(($base_url ?? '/') . 'profile/' . rawurlencode($ownerU), false);
?>

<section class="card rounded-2xl" role="region" aria-labelledby="adminPostEditHeading">
  <div class="list-header" id="adminPostEditHeading">
    <span class="icon"><?php echo renderVerifiedBadge($iconPath . 'reels.svg', true); ?></span>
    <span><strong>Edit Post #<?php echo (int)$pid; ?></strong></span>
  </div>

  <?php if (strtolower($vis) === 'subscribers'): ?>
    <div class="box-note box-note--subs full-width flex align_items">
      <span class="bn-icon flex align_items"><?php echo renderVerifiedBadge($iconPath . 'subscriber.svg', true); ?></span>
      <span><?php echo iN_HelpSecure(customLang('post_is_subscribers_only') ?: 'This is a subscribers-only post.', false); ?></span>
    </div>
  <?php elseif (strtolower($vis) === 'locked'): ?>
    <div class="box-note box-note--locked full-width flex align_items">
      <span class="bn-icon flex align_items"><?php echo renderVerifiedBadge($iconPath . 'locked.svg', true); ?></span>
      <span><?php echo iN_HelpSecure(customLang('post_is_locked') ?: 'This post is locked (PPV).', false); ?></span>
    </div>
  <?php endif; ?>

  <div class="admin-section">
    <div class="ud-row">
      <img class="ud-avatar" src="<?php echo iN_HelpSecure($ownerAv, false); ?>" alt="Owner avatar"/>
      <div>
        <div class="ud-title"><a href="<?php echo $ownerUrl; ?>"><?php echo iN_HelpSecure($ownerName, false); ?></a></div>
        <div class="ud-line flex flexBoxColumn gap">Post <?php echo (int)$pid; ?><a href="<?php echo $postUrl; ?>">Open on site</a><span class="meta-time"><?php echo renderVerifiedBadge($iconPath . 'time.svg', true); ?> <?php echo iN_HelpSecure($created, false); ?></span></div>
      </div>
    </div>
  </div>

  <form data-action="save-post" class="admin-section" method="post" action="<?php echo iN_HelpSecure(($base_url ?? '/') . 'admin/request/post_update.php', false); ?>">
    <input type="hidden" name="csrf_token" value="<?php echo iN_HelpSecure($ADMIN_CSRF, false); ?>">
    <input type="hidden" name="post_id" value="<?php echo (int)$pid; ?>">
    <h3>Edit data</h3>

    <div class="form-input-wrapper form-input-edit">
      <label class="form-label" for="post_text"><?php echo iN_HelpSecure(customLang('edit_field_text') ?: 'Text', false); ?></label>
      <textarea id="post_text" name="post_text" rows="5" maxlength="2000" class="form-input"><?php echo iN_HelpSecure($postText, false); ?></textarea>
    </div>

    <div class="form-input-wrapper form-input-edit">
      <?php if ($filePaths): ?>
        <div class="media-grid" data-media-grid>
          <?php foreach ($filePaths as $p):
            $pStr = (string)$p;
            $absUrl = admin_resolve_media_url($pStr);
            $abs  = iN_HelpSecure($absUrl, false);
            $ext  = strtolower(pathinfo($pStr, PATHINFO_EXTENSION));
          ?>
          <div class="media-item relative" data-path="<?php echo iN_HelpSecure($pStr, false); ?>">
            <input type="checkbox" name="delete_media[]" value="<?php echo iN_HelpSecure($pStr, false); ?>" class="sr-only" />
            <button type="button" class="media-del" aria-label="<?php echo iN_HelpSecure(customLang('media_delete_this') ?: 'Delete this media', false); ?>"><?php echo renderVerifiedBadge($iconPath . 'delete.svg', true); ?></button>
            <?php if (in_array($ext, ['mp4','webm','ogg'], true)): ?>
              <video class="media-thumb" src="<?php echo $abs; ?>" controls></video>
            <?php else: ?>
              <img class="media-thumb" src="<?php echo $abs; ?>" alt="media" />
            <?php endif; ?>
          </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('media_none') ?: 'No media listed for this post.', false); ?></div>
      <?php endif; ?>
    </div>



    <div class="form-grid">

      <div class="form-input-wrapper form-input-edit">
        <label class="form-label" for="visibility"><?php echo iN_HelpSecure(customLang('edit_field_visibility') ?: 'Visibility', false); ?></label>
        <select id="visibility" name="visibility" class="form-input">
          <?php foreach (['everyone'=>'Everyone','followers'=>'Followers','subscribers'=>'Subscribers','locked'=>'Locked'] as $vk=>$vt): ?>
            <option value="<?php echo $vk; ?>"<?php echo (strtolower($vis)===$vk?' selected':''); ?>><?php echo $vt; ?></option>
          <?php endforeach; ?>
        </select>
        <div class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('edit_visibility_hint_detail') ?: "Only 'Locked' posts can be sold (PPV). 'Subscribers' visibility shows content to subscribers without per‑post pricing.", false); ?></div>
      </div>

      <div class="form-input-wrapper form-input-edit">
        <label class="form-label" for="price"><?php echo iN_HelpSecure(customLang('edit_field_price') ?: 'Price', false); ?></label>
        <?php $minP = (int)($premiumPostPriceMinimum ?? 1); $maxP = (int)($premiumPostPriceMaximum ?? 500); ?>
        <input id="price" type="number" min="<?php echo $minP; ?>" max="<?php echo $maxP; ?>" step="1" name="price" value="<?php echo (int)$price; ?>" class="form-input"/>
        <input type="hidden" id="pp-min" value="<?php echo $minP; ?>" />
        <input type="hidden" id="pp-max" value="<?php echo $maxP; ?>" />
        <div class="form-text text-muted fs-13 price-hint price-hint--locked is-hidden">
          <?php echo iN_HelpSecure(customLang('edit_price_hint_locked') ?: ("Applies only when Visibility is 'Locked'. Allowed range: " . $minP . ' – ' . $maxP . '.'), false); ?>
        </div>
        <div class="form-text text-muted fs-13 price-hint price-hint--disabled is-hidden">
          <?php echo iN_HelpSecure(customLang('edit_price_hint_disabled') ?: "Price is disabled. Set Visibility to 'Locked' to enable.", false); ?>
        </div>
      </div>

      <div class="form-input-wrapper form-input-edit">
        <label class="form-label" for="comments"><?php echo iN_HelpSecure(customLang('edit_field_comments') ?: 'Comments', false); ?></label>
        <select id="comments" name="comment_status" class="form-input">
          <option value="on"<?php echo ($cStatus==='on'?' selected':''); ?>>Enabled</option>
          <option value="off"<?php echo ($cStatus==='off'?' selected':''); ?>>Disabled</option>
        </select>
      </div>

      <div class="form-input-wrapper form-input-edit">
        <label class="form-label" for="likes"><?php echo iN_HelpSecure(customLang('edit_field_likes') ?: 'Likes', false); ?></label>
        <?php $likeStatus = (string)($post['like_status'] ?? 'on'); ?>
        <select id="likes" name="like_status" class="form-input">
          <option value="on"<?php echo ($likeStatus==='on'?' selected':''); ?>>Enabled</option>
          <option value="off"<?php echo ($likeStatus==='off'?' selected':''); ?>>Disabled</option>
        </select>
      </div>
    </div>

    <div class="admin-actions">
      <button type="submit" class="btn btn-primary"><?php echo iN_HelpSecure(customLang('menu_save') ?: 'Save changes', false); ?></button>
      <a class="btn" href="<?php echo iN_HelpSecure(($base_url ?? '/') . 'admin/index.php?page=reported_posts', false); ?>"><?php echo iN_HelpSecure(customLang('menu_back') ?: 'Back', false); ?></a>
    </div>
  </form>
</section>
