<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $ADM, $base_url, $ADMIN_CSRF, $currency, $currencies, $currencyFormatSettings;

$translate = static fn(string $key, string $fallback): string => (string)(customLang($key, $fallback) ?: $fallback);
$currenciesMap = isset($currencies) && is_array($currencies) ? $currencies : [];
$currencyFormatSettings = $currencyFormatSettings ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
$formatMoney = static function (float $amount, string $code) use ($currenciesMap, $currencyFormatSettings): string {
    $resolvedCode = strtoupper(trim($code)) ?: strtoupper((string)($GLOBALS['currency'] ?? 'USD'));
    return dz_format_currency($amount, $resolvedCode, $currenciesMap[$resolvedCode] ?? null, $currencyFormatSettings);
};
$parseDate = static function (string $value, bool $endOfDay = false): int {
    if ($value === '' || preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) !== 1) {
        return 0;
    }
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    if (!$date || $date->format('Y-m-d') !== $value) {
        return 0;
    }
    return ($endOfDay ? $date->setTime(23, 59, 59) : $date)->getTimestamp();
};

$q = trim((string)($_GET['q'] ?? ''));
$type = strtolower(trim((string)($_GET['type'] ?? '')));
$status = strtolower(trim((string)($_GET['status'] ?? '')));
$dateFromRaw = trim((string)($_GET['date_from'] ?? ''));
$dateToRaw = trim((string)($_GET['date_to'] ?? ''));
$page = max(1, (int)($_GET['page_no'] ?? 1));
$per = max(10, min(100, (int)($_GET['per'] ?? 20)));
$filters = [
    'type' => $type,
    'status' => $status,
    'date_from' => $parseDate($dateFromRaw),
    'date_to' => $parseDate($dateToRaw, true),
];
$data = $ADM->ADM_PagedAudioRoomTransactions($q, $page, $per, $filters);
$summary = $ADM->ADM_AudioRoomEarningsSummary($q, $filters);
$rows = $data['rows'] ?? [];
$total = (int)($data['total'] ?? 0);
$pages = max(1, (int)ceil($total / max(1, $per)));

$summaryMoney = static function (string $field) use ($summary, $formatMoney): string {
    $parts = [];
    foreach (($summary['by_currency'] ?? []) as $row) {
        $parts[] = $formatMoney((float)($row[$field] ?? 0), (string)($row['currency'] ?? ''));
    }
    return $parts ? implode(' · ', $parts) : $formatMoney(0, (string)($GLOBALS['currency'] ?? 'USD'));
};

$typeOptions = [
    '' => $translate('admin_audio_room_earnings_type_all', 'All transaction types'),
    'ticket' => $translate('admin_audio_room_earnings_type_ticket', 'Room tickets'),
    'tip' => $translate('admin_audio_room_earnings_type_tip', 'Room tips'),
];
$statusOptions = [
    '' => $translate('admin_audio_room_earnings_status_all', 'All statuses'),
    'succeeded' => $translate('admin_audio_room_earnings_status_succeeded', 'Succeeded'),
    'paid' => $translate('admin_audio_room_earnings_status_paid', 'Paid'),
    'completed' => $translate('admin_audio_room_earnings_status_completed', 'Completed'),
    'pending' => $translate('admin_audio_room_earnings_status_pending', 'Pending'),
    'failed' => $translate('admin_audio_room_earnings_status_failed', 'Failed'),
    'canceled' => $translate('admin_audio_room_earnings_status_canceled', 'Canceled'),
    'cancelled' => $translate('admin_audio_room_earnings_status_cancelled', 'Cancelled'),
    'refunded' => $translate('admin_audio_room_earnings_status_refunded', 'Refunded'),
];
$paidStatuses = ['succeeded', 'paid', 'completed'];
$queryBase = array_filter([
    'page' => 'audio_room_earnings',
    'q' => $q,
    'type' => $type,
    'status' => $status,
    'date_from' => $dateFromRaw,
    'date_to' => $dateToRaw,
    'per' => $per,
], static fn($value): bool => $value !== '');
?>
<section class="admin-audio-earnings card rounded-2xl" role="region" aria-labelledby="audioRoomEarningsHeading">
  <div class="admin-audio-earnings__header list-header">
    <div class="admin-audio-earnings__identity">
      <span class="admin-audio-earnings__icon icon" aria-hidden="true"><?= render_icon('payments', true); ?></span>
      <div>
        <h1 id="audioRoomEarningsHeading"><?= iN_HelpSecure($translate('admin_audio_room_earnings_title', 'Audio Room earnings'), false); ?></h1>
        <p><?= iN_HelpSecure($translate('admin_audio_room_earnings_subtitle', 'Review room tickets, tips, creator net earnings and platform revenue.'), false); ?></p>
      </div>
    </div>
    <div class="admin-audio-earnings__header-actions">
      <a class="admin-button admin-button--neutral" href="<?= iN_HelpSecure($base_url . 'admin/index.php?page=audio_rooms', false); ?>"><?= iN_HelpSecure($translate('admin_audio_room_earnings_manage_rooms', 'Manage rooms'), false); ?></a>
      <a class="admin-button admin-button--neutral" href="<?= iN_HelpSecure($base_url . 'admin/index.php?page=settings_audio_rooms', false); ?>"><?= iN_HelpSecure($translate('admin_audio_room_earnings_settings', 'Room settings'), false); ?></a>
    </div>
  </div>

  <div class="admin-audio-earnings__stats" aria-label="<?= iN_HelpSecure($translate('admin_audio_room_earnings_summary', 'Earnings summary'), false); ?>">
    <article><span><?= iN_HelpSecure($translate('admin_audio_room_earnings_transactions', 'Transactions'), false); ?></span><strong><?= (int)($summary['transactions'] ?? 0); ?></strong><small><?= (int)($summary['successful_transactions'] ?? 0); ?> <?= iN_HelpSecure($translate('admin_audio_room_earnings_successful', 'successful'), false); ?></small></article>
    <article><span><?= iN_HelpSecure($translate('admin_audio_room_earnings_gross', 'Gross volume'), false); ?></span><strong><?= iN_HelpSecure($summaryMoney('gross'), false); ?></strong><small><?= (int)($summary['ticket_count'] ?? 0); ?> <?= iN_HelpSecure($translate('admin_audio_room_earnings_tickets', 'tickets'), false); ?> · <?= (int)($summary['tip_count'] ?? 0); ?> <?= iN_HelpSecure($translate('admin_audio_room_earnings_tips', 'tips'), false); ?></small></article>
    <article><span><?= iN_HelpSecure($translate('admin_audio_room_earnings_creator_net', 'Creator net'), false); ?></span><strong><?= iN_HelpSecure($summaryMoney('creator_net'), false); ?></strong><small><?= iN_HelpSecure($translate('admin_audio_room_earnings_creator_net_help', 'Credited to room creators'), false); ?></small></article>
    <article><span><?= iN_HelpSecure($translate('admin_audio_room_earnings_platform', 'Platform revenue'), false); ?></span><strong><?= iN_HelpSecure($summaryMoney('platform_revenue'), false); ?></strong><small><?= iN_HelpSecure($translate('admin_audio_room_earnings_platform_help', 'Fees and tax allocation'), false); ?></small></article>
  </div>

  <form class="admin-audio-earnings__filters form-container form-container--columns" method="get" action="<?= iN_HelpSecure($base_url . 'admin/index.php', false); ?>">
    <input type="hidden" name="page" value="audio_room_earnings">
    <div class="admin-audio-earnings__field admin-audio-earnings__field--search form-input-wrapper" data-field="search"><label class="form-label" for="audioEarningsSearch"><?= iN_HelpSecure($translate('admin_audio_room_earnings_search', 'Search'), false); ?></label><input class="form-input" id="audioEarningsSearch" type="search" name="q" value="<?= iN_HelpSecure($q, false); ?>" placeholder="<?= iN_HelpSecure($translate('admin_audio_room_earnings_search_placeholder', 'Room, user, reference or ID'), false); ?>"></div>
    <div class="admin-audio-earnings__field form-input-wrapper" data-field="type"><label class="form-label" for="audioEarningsType"><?= iN_HelpSecure($translate('admin_audio_room_earnings_type', 'Type'), false); ?></label><select class="form-input" id="audioEarningsType" name="type"><?php foreach ($typeOptions as $value => $label): ?><option value="<?= iN_HelpSecure($value, false); ?>"<?= $type === $value ? ' selected' : ''; ?>><?= iN_HelpSecure($label, false); ?></option><?php endforeach; ?></select></div>
    <div class="admin-audio-earnings__field form-input-wrapper" data-field="status"><label class="form-label" for="audioEarningsStatus"><?= iN_HelpSecure($translate('admin_audio_room_earnings_status', 'Status'), false); ?></label><select class="form-input" id="audioEarningsStatus" name="status"><?php foreach ($statusOptions as $value => $label): ?><option value="<?= iN_HelpSecure($value, false); ?>"<?= $status === $value ? ' selected' : ''; ?>><?= iN_HelpSecure($label, false); ?></option><?php endforeach; ?></select></div>
    <div class="admin-audio-earnings__field form-input-wrapper" data-field="date-from"><label class="form-label" for="audioEarningsFrom"><?= iN_HelpSecure($translate('admin_audio_room_earnings_from', 'From'), false); ?></label><input class="form-input" id="audioEarningsFrom" type="date" name="date_from" value="<?= iN_HelpSecure($dateFromRaw, false); ?>"></div>
    <div class="admin-audio-earnings__field form-input-wrapper" data-field="date-to"><label class="form-label" for="audioEarningsTo"><?= iN_HelpSecure($translate('admin_audio_room_earnings_to', 'To'), false); ?></label><input class="form-input" id="audioEarningsTo" type="date" name="date_to" value="<?= iN_HelpSecure($dateToRaw, false); ?>"></div>
    <div class="admin-audio-earnings__field form-input-wrapper" data-field="per-page"><label class="form-label" for="audioEarningsPer"><?= iN_HelpSecure($translate('admin_audio_room_earnings_per_page', 'Per page'), false); ?></label><select class="form-input" id="audioEarningsPer" name="per"><?php foreach ([10,20,50,100] as $value): ?><option value="<?= $value; ?>"<?= $per === $value ? ' selected' : ''; ?>><?= $value; ?></option><?php endforeach; ?></select></div>
    <div class="admin-audio-earnings__filter-actions form-input-wrapper form-actions">
      <button class="pe-save btn-hover" type="submit"><?= iN_HelpSecure($translate('admin_audio_room_earnings_apply', 'Apply'), false); ?></button>
      <?php if ($q !== '' || $type !== '' || $status !== '' || $dateFromRaw !== '' || $dateToRaw !== ''): ?><a class="admin-button admin-button--neutral" href="<?= iN_HelpSecure($base_url . 'admin/index.php?page=audio_room_earnings', false); ?>"><?= iN_HelpSecure($translate('admin_audio_room_earnings_clear', 'Clear'), false); ?></a><?php endif; ?>
    </div>
  </form>

  <div class="admin-audio-earnings__toolbar">
    <span><?= $total; ?> <?= iN_HelpSecure($translate('admin_audio_room_earnings_results', 'results'), false); ?></span>
    <form method="post" action="<?= iN_HelpSecure($base_url . 'admin/request/audio_room_earnings_export.php', false); ?>">
      <input type="hidden" name="csrf_token" value="<?= iN_HelpSecure((string)$ADMIN_CSRF, false); ?>">
      <?php foreach (['q'=>$q,'type'=>$type,'status'=>$status,'date_from'=>$dateFromRaw,'date_to'=>$dateToRaw] as $name=>$value): ?><input type="hidden" name="<?= iN_HelpSecure($name, false); ?>" value="<?= iN_HelpSecure($value, false); ?>"><?php endforeach; ?>
      <button class="admin-button admin-button--neutral" type="submit"><?= iN_HelpSecure($translate('admin_audio_room_earnings_export', 'Export CSV'), false); ?></button>
    </form>
  </div>

  <div class="admin-audio-earnings__table-wrap table-responsive">
    <table class="admin-audio-earnings__table table table-striped table-sm table-subs">
      <thead><tr>
        <th><?= iN_HelpSecure($translate('admin_audio_room_earnings_col_type', 'Type'), false); ?></th>
        <th><?= iN_HelpSecure($translate('admin_audio_room_earnings_col_room', 'Room'), false); ?></th>
        <th><?= iN_HelpSecure($translate('admin_audio_room_earnings_col_buyer', 'Buyer'), false); ?></th>
        <th><?= iN_HelpSecure($translate('admin_audio_room_earnings_col_creator', 'Creator'), false); ?></th>
        <th><?= iN_HelpSecure($translate('admin_audio_room_earnings_col_status', 'Status'), false); ?></th>
        <th><?= iN_HelpSecure($translate('admin_audio_room_earnings_col_gross', 'Gross'), false); ?></th>
        <th><?= iN_HelpSecure($translate('admin_audio_room_earnings_col_net', 'Creator net'), false); ?></th>
        <th><?= iN_HelpSecure($translate('admin_audio_room_earnings_col_platform', 'Platform'), false); ?></th>
        <th><?= iN_HelpSecure($translate('admin_audio_room_earnings_col_reference', 'Reference'), false); ?></th>
        <th><?= iN_HelpSecure($translate('admin_audio_room_earnings_col_date', 'Date'), false); ?></th>
        <th><?= iN_HelpSecure($translate('admin_audio_room_earnings_col_invoice', 'Invoice'), false); ?></th>
      </tr></thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="11" class="admin-audio-earnings__empty"><?= iN_HelpSecure($translate('admin_audio_room_earnings_empty', 'No Audio Room transactions match these filters.'), false); ?></td></tr>
      <?php else: foreach ($rows as $row):
        $rowType = (string)($row['transaction_type'] ?? '');
        $rowStatus = strtolower((string)($row['status'] ?? ''));
        $statusClass = in_array($rowStatus, $paidStatuses, true) ? 'is-success' : ($rowStatus === 'pending' ? 'is-pending' : 'is-failed');
        $roomId = (int)($row['room_id'] ?? 0);
        $sourceId = (int)($row['id'] ?? 0);
        $currencyCode = (string)($row['currency'] ?? ($currency ?? 'USD'));
        $platformAmount = (float)($row['fee_amount'] ?? 0) + (float)($row['tax_amount'] ?? 0);
        $buyerUsername = (string)($row['buyer_username'] ?? '');
        $recipientUsername = (string)($row['recipient_username'] ?? '');
        $buyerName = (string)($row['buyer_fullname'] ?? $buyerUsername);
        $recipientName = (string)($row['recipient_fullname'] ?? $recipientUsername);
        $buyerAvatar = admin_resolve_media_url((string)($row['buyer_avatar'] ?? 'uploads/user_avatars/default.jpeg'));
        $recipientAvatar = admin_resolve_media_url((string)($row['recipient_avatar'] ?? 'uploads/user_avatars/default.jpeg'));
        $invoiceUrl = $base_url . 'admin/index.php?page=invoice_audio_room&type=' . rawurlencode($rowType) . '&id=' . $sourceId;
      ?>
        <tr>
          <td data-label="<?= iN_HelpSecure($translate('admin_audio_room_earnings_col_type', 'Type'), false); ?>"><span class="admin-audio-earnings__type is-<?= iN_HelpSecure($rowType, false); ?>"><?= iN_HelpSecure($rowType === 'ticket' ? $translate('admin_audio_room_earnings_type_ticket_single', 'Ticket') : $translate('admin_audio_room_earnings_type_tip_single', 'Tip'), false); ?></span></td>
          <td data-label="<?= iN_HelpSecure($translate('admin_audio_room_earnings_col_room', 'Room'), false); ?>"><a class="admin-audio-earnings__room" href="<?= iN_HelpSecure($base_url . 'audio-room/' . $roomId, false); ?>"><strong><?= iN_HelpSecure((string)($row['room_title'] ?? ('#' . $roomId)), false); ?></strong><small>#<?= $roomId; ?></small></a></td>
          <td data-label="<?= iN_HelpSecure($translate('admin_audio_room_earnings_col_buyer', 'Buyer'), false); ?>"><a class="admin-audio-earnings__user" href="<?= iN_HelpSecure($base_url . 'profile/' . rawurlencode($buyerUsername), false); ?>"><img src="<?= iN_HelpSecure($buyerAvatar, false); ?>" alt=""><span><strong><?= iN_HelpSecure($buyerName, false); ?></strong><small>@<?= iN_HelpSecure($buyerUsername, false); ?></small></span></a></td>
          <td data-label="<?= iN_HelpSecure($translate('admin_audio_room_earnings_col_creator', 'Creator'), false); ?>"><a class="admin-audio-earnings__user" href="<?= iN_HelpSecure($base_url . 'profile/' . rawurlencode($recipientUsername), false); ?>"><img src="<?= iN_HelpSecure($recipientAvatar, false); ?>" alt=""><span><strong><?= iN_HelpSecure($recipientName, false); ?></strong><small>@<?= iN_HelpSecure($recipientUsername, false); ?></small></span></a></td>
          <td data-label="<?= iN_HelpSecure($translate('admin_audio_room_earnings_col_status', 'Status'), false); ?>"><span class="admin-audio-earnings__status <?= $statusClass; ?>"><?= iN_HelpSecure($statusOptions[$rowStatus] ?? ucfirst($rowStatus), false); ?></span></td>
          <td data-label="<?= iN_HelpSecure($translate('admin_audio_room_earnings_col_gross', 'Gross'), false); ?>" class="is-money"><?= iN_HelpSecure($formatMoney((float)($row['amount'] ?? 0), $currencyCode), false); ?></td>
          <td data-label="<?= iN_HelpSecure($translate('admin_audio_room_earnings_col_net', 'Creator net'), false); ?>" class="is-money"><?= iN_HelpSecure($formatMoney((float)($row['net_amount'] ?? 0), $currencyCode), false); ?></td>
          <td data-label="<?= iN_HelpSecure($translate('admin_audio_room_earnings_col_platform', 'Platform'), false); ?>" class="is-money"><?= iN_HelpSecure($formatMoney($platformAmount, $currencyCode), false); ?></td>
          <td data-label="<?= iN_HelpSecure($translate('admin_audio_room_earnings_col_reference', 'Reference'), false); ?>"><code><?= iN_HelpSecure((string)($row['reference'] ?? '-'), false); ?></code></td>
          <td data-label="<?= iN_HelpSecure($translate('admin_audio_room_earnings_col_date', 'Date'), false); ?>"><time datetime="<?= date('c', (int)($row['created_at'] ?? 0)); ?>"><?= date('Y-m-d H:i', (int)($row['created_at'] ?? 0)); ?></time></td>
          <td data-label="<?= iN_HelpSecure($translate('admin_audio_room_earnings_col_invoice', 'Invoice'), false); ?>"><a class="admin-audio-earnings__invoice" href="<?= iN_HelpSecure($invoiceUrl, false); ?>"><?= iN_HelpSecure($translate('admin_audio_room_earnings_view_invoice', 'View'), false); ?></a></td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <?php if ($pages > 1): ?><nav class="admin-audio-earnings__pagination" aria-label="<?= iN_HelpSecure($translate('admin_audio_room_earnings_pagination', 'Transaction pages'), false); ?>">
    <?php if ($page > 1): ?><a href="?<?= iN_HelpSecure(http_build_query(array_merge($queryBase, ['page_no'=>$page-1])), false); ?>"><?= iN_HelpSecure($translate('previous', 'Previous'), false); ?></a><?php endif; ?>
    <span><?= $page; ?> / <?= $pages; ?></span>
    <?php if ($page < $pages): ?><a href="?<?= iN_HelpSecure(http_build_query(array_merge($queryBase, ['page_no'=>$page+1])), false); ?>"><?= iN_HelpSecure($translate('next', 'Next'), false); ?></a><?php endif; ?>
  </nav><?php endif; ?>
</section>
