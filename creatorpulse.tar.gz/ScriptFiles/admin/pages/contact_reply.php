<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $ADM, $base_url, $iconPath, $ADMIN_CSRF, $version;

if (!isset($ADM) || !($ADM instanceof Admin_Data)) {
    throw new RuntimeException('Admin data layer not available.');
}

$messageId = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($messageId <= 0) {
    http_response_code(404);
    echo '<section class="card rounded-2xl"><div class="list-header"><strong>' . iN_HelpSecure(customLang('contact_message_not_found') ?: 'Message not found.', false) . '</strong></div></section>';
    return;
}

try {
    $stmt = $ADM->db()->prepare('SELECT id, email, subject, name FROM i_contact_messages WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $messageId]);
    $messageRow = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
} catch (Throwable $e) {
    if (defined('APP_DEBUG') && APP_DEBUG === true) {
        error_log('Load contact message failed: ' . $e->getMessage());
    }
    $messageRow = null;
}

if (!$messageRow) {
    http_response_code(404);
    echo '<section class="card rounded-2xl"><div class="list-header"><strong>' . iN_HelpSecure(customLang('contact_message_not_found') ?: 'Message not found.', false) . '</strong></div></section>';
    return;
}

$toEmail   = (string) ($messageRow['email'] ?? '');
$subject   = (string) ($messageRow['subject'] ?? '');
$contactName = (string) ($messageRow['name'] ?? '');
if ($subject !== '' && stripos($subject, 're:') !== 0) {
    $replySubject = 'Re: ' . $subject;
} else {
    $replySubject = $subject !== '' ? $subject : 'Re:';
}

$replyTitle   = customLang('admin_contact_reply_title') ?: 'Reply to message';
$toLabel      = customLang('admin_contact_reply_to') ?: 'To';
$subjectLabel = customLang('admin_contact_reply_subject') ?: 'Subject';
$messageLabel = customLang('admin_contact_reply_message') ?: 'Message';
$sendLabel    = customLang('admin_contact_reply_send') ?: 'Send reply';
$cancelLabel  = customLang('admin_contact_reply_cancel') ?: 'Back to list';
$successToast = customLang('admin_contact_reply_success') ?: 'Reply sent successfully.';
$errorToast   = customLang('admin_contact_reply_error') ?: 'Unable to send reply.';
$redirectUrl  = rtrim((string) ($base_url ?? ''), '/') . '/admin/index.php?page=contact_messages_all';

$statusTitle = customLang('admin_contact_reply_status_title') ?: 'Update message category';
$statusDescription = customLang('admin_contact_reply_status_description') ?: 'Choose how this message should be categorized after sending your reply.';
$statusSkipLabel = customLang('admin_contact_reply_status_skip') ?: 'Skip and return to list';

$statusLabels = [
    'new'      => customLang('contact_status_new') ?: 'New',
    'read'     => customLang('contact_status_read') ?: 'Read',
    'resolved' => customLang('contact_status_resolved') ?: 'Resolved',
];

$statusSuccessMessages = [
    'new'      => customLang('admin_contact_status_toast_new') ?: 'Message moved to New.',
    'read'     => customLang('admin_contact_status_toast_read') ?: 'Message marked as read.',
    'resolved' => customLang('admin_contact_status_toast_resolved') ?: 'Message marked as resolved.',
];

$statusRedirects = [
    'new'      => rtrim((string) ($base_url ?? ''), '/') . '/admin/index.php?page=contact_messages_new',
    'read'     => rtrim((string) ($base_url ?? ''), '/') . '/admin/index.php?page=contact_messages_read',
    'resolved' => rtrim((string) ($base_url ?? ''), '/') . '/admin/index.php?page=contact_messages_resolved',
];
?>
<section
  class="card rounded-2xl"
  role="region"
  aria-labelledby="contactReplyHeading"
  data-contact-reply
  data-message-id="<?= $messageId; ?>"
  data-toast-success="<?= iN_HelpSecure($successToast, false); ?>"
  data-toast-error="<?= iN_HelpSecure($errorToast, false); ?>"
  data-status-title="<?= iN_HelpSecure($statusTitle, false); ?>"
  data-status-description="<?= iN_HelpSecure($statusDescription, false); ?>"
  data-status-label-new="<?= iN_HelpSecure($statusLabels['new'], false); ?>"
  data-status-label-read="<?= iN_HelpSecure($statusLabels['read'], false); ?>"
  data-status-label-resolved="<?= iN_HelpSecure($statusLabels['resolved'], false); ?>"
  data-status-toast-new="<?= iN_HelpSecure($statusSuccessMessages['new'], false); ?>"
  data-status-toast-read="<?= iN_HelpSecure($statusSuccessMessages['read'], false); ?>"
  data-status-toast-resolved="<?= iN_HelpSecure($statusSuccessMessages['resolved'], false); ?>"
  data-status-redirect-new="<?= iN_HelpSecure($statusRedirects['new'], false); ?>"
  data-status-redirect-read="<?= iN_HelpSecure($statusRedirects['read'], false); ?>"
  data-status-redirect-resolved="<?= iN_HelpSecure($statusRedirects['resolved'], false); ?>"
  data-status-skip-label="<?= iN_HelpSecure($statusSkipLabel, false); ?>"
  data-redirect-url="<?= iN_HelpSecure($redirectUrl, false); ?>"
>
  <div class="list-header" id="contactReplyHeading">
    <span class="icon"><?= renderVerifiedBadge($iconPath . 'send.svg', true); ?></span>
    <span><strong><?= iN_HelpSecure($replyTitle, false); ?></strong></span>
  </div>

  <form
      class="form-container form-container--stacked flex flexBoxColumn"
      method="post"
      action="<?= iN_HelpSecure($base_url . 'admin/request/contact_email.php?action=reply_send&id=' . $messageId, false); ?>"
      data-action="contact-reply"
  >
    <input type="hidden" name="csrf_token" value="<?= iN_HelpSecure($ADMIN_CSRF ?? generateCsrfToken(), false); ?>">
    <input type="hidden" name="action" value="reply_send">
    <input type="hidden" name="message_id" value="<?= $messageId; ?>">

    <div class="form-input-wrapper">
      <label class="form-label" for="contact-reply-to"><?= iN_HelpSecure($toLabel, false); ?></label>
      <input id="contact-reply-to" class="form-input" type="email" name="to" value="<?= iN_HelpSecure($toEmail, false); ?>" readonly>
    </div>

    <div class="form-input-wrapper">
      <label class="form-label" for="contact-reply-subject"><?= iN_HelpSecure($subjectLabel, false); ?></label>
      <input id="contact-reply-subject" class="form-input" type="text" name="subject" value="<?= iN_HelpSecure($replySubject, false); ?>" maxlength="191" required>
    </div>

    <div class="form-input-wrapper">
      <label class="form-label" for="contact-reply-message"><?= iN_HelpSecure($messageLabel, false); ?></label>
      <textarea
          id="contact-reply-message"
          class="form-input js-page-editor"
          name="message"
          rows="8"
          data-editor-images="0"
          required
      ></textarea>
    </div>

    <div class="form-actions flex align_items_justify_content gap">
      <button type="submit" class="pe-save btn-hover" data-role="contact-reply-submit"><?= iN_HelpSecure($sendLabel, false); ?></button>
      <a class="btn-outline" href="<?= iN_HelpSecure($redirectUrl, false); ?>"><?= iN_HelpSecure($cancelLabel, false); ?></a>
    </div>
  </form>

  <div class="mt-4 contact-reply-status" data-role="contact-reply-status" hidden aria-live="polite">
    <div class="fw-600 mb-2"><?= iN_HelpSecure($statusTitle, false); ?></div>
    <p class="text-muted mb-3"><?= nl2br(iN_HelpSecure($statusDescription, false)); ?></p>
    <div class="contact-reply-status-options" data-role="contact-reply-status-buttons">
      <?php foreach ($statusLabels as $statusKey => $statusLabel): ?>
        <button
          type="button"
          class="btn-outline btn-sm"
          data-role="contact-reply-status-option"
          data-status-value="<?= iN_HelpSecure($statusKey, false); ?>"
        ><?= iN_HelpSecure($statusLabel, false); ?></button>
      <?php endforeach; ?>
    </div>
    <div class="form-actions flex align_items_justify_content gap mt-3">
      <a
        class="btn-outline"
        href="<?= iN_HelpSecure($redirectUrl, false); ?>"
        data-role="contact-reply-status-skip"
      ><?= iN_HelpSecure($statusSkipLabel, false); ?></a>
    </div>
  </div>
</section>
<?php
if (!defined('ADMIN_TINYMCE_LOADED')) {
    define('ADMIN_TINYMCE_LOADED', true);
    $tinymceSrc = rtrim((string)($base_url ?? ''), '/') . '/admin/js/tinymce/tinymce.min.js';
    if (isset($version) && $version !== '') {
        $tinymceSrc .= '?v=' . rawurlencode((string) $version);
    }
    echo '<script defer src="' . iN_HelpSecure($tinymceSrc, false) . '"></script>';
}
?>
