<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $base_url, $ADM, $iconPath, $RL;

$pageSlug = 'reported_comments';
$pageNo   = isset($_GET['page_no']) ? max(1, (int) $_GET['page_no']) : 1;
$per      = isset($_GET['per']) ? max(10, min(100, (int) $_GET['per'])) : 20;

$reportsAll = $ADM->ADM_ListCommentReports(300);
$total      = (int) count($reportsAll);
$pages      = (int) max(1, ceil($total / max(1, $per)));
$start      = (int) (($pageNo - 1) * $per);
$reports    = array_slice($reportsAll, $start, $per);
$canResolveReports = admin_has_permission('reports.resolve');
$canDeleteComment = admin_has_permission('reports.delete_comment');
$permissionTip = customLang('admin_permission_denied_tooltip') ?: 'You do not have permission to perform this action.';

$headingPrimary = customLang('admin_comments_heading') ?: 'Comments';
$headingReported = customLang('admin_comments_tab_reported') ?: 'Reported Comments';
$emptyText = customLang('admin_comments_empty') ?: 'No reported comments.';
$commentMissingText = customLang('admin_comments_comment_missing') ?: 'Comment no longer available.';
$statusPendingLabel = customLang('admin_comments_status_pending') ?: 'Pending';
$statusClearedLabel = customLang('admin_comments_status_cleared') ?: 'Cleared';
$unknownLabel = customLang('admin_unknown_user') ?: 'Unknown';
?>

<section class="card rounded-2xl" role="region" aria-labelledby="adminReportedCommentsHeading">
  <div class="list-header" id="adminReportedCommentsHeading">
    <span class="icon"><?php echo renderVerifiedBadge($iconPath . 'comment.svg', true); ?></span>
    <span><strong><?php echo iN_HelpSecure($headingPrimary . ' > ' . $headingReported, false); ?></strong></span>
  </div>
  <form method="get" class="form-container form-container--columns" action="<?php echo iN_HelpSecure($base_url . 'admin/index.php', false); ?>">
    <input type="hidden" name="page" value="<?php echo iN_HelpSecure($pageSlug, false); ?>">
    <div class="form-input-wrapper">
      <label class="form-label" for="reportedCommentsPer"><?php echo iN_HelpSecure(customLang('admin_posts_filter_per_page') ?: 'Per page', false); ?></label>
      <select id="reportedCommentsPer" name="per" class="form-input">
        <?php foreach ([10, 20, 50, 100] as $pp): ?>
          <option value="<?php echo $pp; ?>"<?php echo $pp === $per ? ' selected' : ''; ?>><?php echo $pp; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper form-actions">
      <label class="form-label sr-only" for="reportedCommentsApply"><?php echo iN_HelpSecure(customLang('admin_posts_filter_apply') ?: 'Apply', false); ?></label>
      <button id="reportedCommentsApply" type="submit" class="pe-save btn-hover"><?php echo iN_HelpSecure(customLang('admin_posts_filter_apply') ?: 'Apply', false); ?></button>
    </div>
  </form>

  <div class="table-responsive mt-4">
    <table
      class="table table-striped table-sm table-subs table-reports full-width"
      data-table-role="reported-comments"
      data-empty-text="<?php echo iN_HelpSecure($emptyText, false); ?>"
    >
      <thead>
        <tr>
          <th><?php echo iN_HelpSecure(customLang('admin_comments_col_id') ?: 'ID'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_comments_col_comment') ?: 'Comment'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_comments_col_post') ?: 'Post'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_comments_col_author') ?: 'Author'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_comments_col_reporter') ?: 'Reporter'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_comments_col_reason') ?: 'Reason'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_comments_col_reported_at') ?: 'Reported'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_comments_col_status') ?: 'Status'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_comments_col_actions') ?: 'Actions'); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$reports): ?>
          <tr data-empty-row="1">
            <td colspan="9" class="text-center text-muted empty_class_table">
              <?php echo iN_HelpSecure($emptyText, false); ?>
            </td>
          </tr>
        <?php else: foreach ($reports as $row):
            $reportId   = (int) ($row['id'] ?? 0);
            $commentId  = (int) ($row['comment_id'] ?? 0);
            $postId     = (int) ($row['post_id'] ?? 0);
            $commentRaw = (string) ($row['comment_body'] ?? '');
            $commentExists = ($commentId > 0) && ($commentRaw !== '' || $row['comment_body'] !== null);

            $commentSnippet = trim(preg_replace('/\s+/u', ' ', $commentRaw));
            if ($commentSnippet === '') {
                $commentSnippet = $commentMissingText;
            } else {
                $maxLen = 120;
                if (mb_strlen($commentSnippet, 'UTF-8') > $maxLen) {
                    $commentSnippet = mb_substr($commentSnippet, 0, $maxLen, 'UTF-8') . '…';
                }
            }

            $postUrl    = $postId > 0 ? ($base_url ?? '/') . 'posts/' . $postId : '';
            $commentUrl = ($postId > 0 && $commentId > 0) ? $postUrl . '#comment-' . $commentId : $postUrl;

            $commentOwnerId  = (int) ($row['comment_owner_id'] ?? 0);
            $commentUsername = (string) ($row['comment_username'] ?? '');
            $commentFullName = (string) ($row['comment_fullname'] ?? '');
            $commentProfile  = $commentUsername !== '' ? ($base_url ?? '/') . 'profile/' . rawurlencode($commentUsername) : '#';
            $commentAvatarRel = (isset($RL) && method_exists($RL, 'RL_userAvatar')) ? $RL->RL_userAvatar($commentOwnerId) : 'uploads/user_avatars/default.jpeg';
            $commentAvatar = admin_resolve_media_url($commentAvatarRel);
            $commentDetails = [];
            if ($commentOwnerId > 0 && isset($RL) && method_exists($RL, 'RL_GetUserDetails')) {
                $commentDetails = $RL->RL_GetUserDetails($commentOwnerId) ?: [];
            }
            if ($commentFullName === '' && $commentDetails) {
                $commentFullName = (string) ($commentDetails['user_fullname'] ?? '');
            }
            if ($commentUsername === '' && $commentDetails) {
                $commentUsername = (string) ($commentDetails['username'] ?? '');
                $commentProfile  = $commentUsername !== '' ? ($base_url ?? '/') . 'profile/' . rawurlencode($commentUsername) : '#';
            }
            $commentDisplayName = $commentFullName !== '' ? $commentFullName : ($commentUsername !== '' ? $commentUsername : $unknownLabel);

            $reporterId   = (int) ($row['reporter_id'] ?? 0);
            $reporterUser = (string) ($row['reporter_username'] ?? '');
            $reporterFull = (string) ($row['reporter_fullname'] ?? '');
            $reporterProfile = $reporterUser !== '' ? ($base_url ?? '/') . 'profile/' . rawurlencode($reporterUser) : '#';
            $reporterAvatarRel = (isset($RL) && method_exists($RL, 'RL_userAvatar')) ? $RL->RL_userAvatar($reporterId) : 'uploads/user_avatars/default.jpeg';
            $reporterAvatar = admin_resolve_media_url($reporterAvatarRel);
            $reporterDetails = [];
            if ($reporterId > 0 && isset($RL) && method_exists($RL, 'RL_GetUserDetails')) {
                $reporterDetails = $RL->RL_GetUserDetails($reporterId) ?: [];
            }
            if ($reporterFull === '' && $reporterDetails) {
                $reporterFull = (string) ($reporterDetails['user_fullname'] ?? '');
            }
            if ($reporterUser === '' && $reporterDetails) {
                $reporterUser = (string) ($reporterDetails['username'] ?? '');
                $reporterProfile = $reporterUser !== '' ? ($base_url ?? '/') . 'profile/' . rawurlencode($reporterUser) : '#';
            }
            $reporterDisplayName = $reporterFull !== '' ? $reporterFull : ($reporterUser !== '' ? $reporterUser : $unknownLabel);

            $reason = (string) ($row['reason'] ?? '');
            $reportedAtTs = (int) ($row['reported_at'] ?? 0);
            $reportedAt = $reportedAtTs > 0 ? date('Y-m-d H:i', $reportedAtTs) : '-';

            $statusLabel = $commentExists ? $statusPendingLabel : $statusClearedLabel;
            $statusClass = $commentExists ? 'pill-amber' : 'pill-gray';

            $postOwnerId = (int) ($row['post_owner_id'] ?? 0);
            $postOwnerUsername = (string) ($row['post_owner_username'] ?? '');
            $postOwnerUrl = $postOwnerId > 0 ? iN_HelpSecure(($base_url ?? '/') . 'admin/index.php?page=user_detail&id=' . (string) $postOwnerId, false) : '#';
            ?>
          <tr
            data-comment-row="<?php echo (int) $commentId; ?>"
            data-comment-id="<?php echo (int) $commentId; ?>"
            data-report-id="<?php echo (int) $reportId; ?>"
          >
            <td><?php echo $reportId; ?></td>
            <td>
              <?php if ($commentUrl): ?>
                <a class="fs-13" href="<?php echo iN_HelpSecure($commentUrl, false); ?>"><?php echo iN_HelpSecure($commentSnippet, false); ?></a>
              <?php else: ?>
                <span class="fs-13 text-muted"><?php echo iN_HelpSecure($commentSnippet, false); ?></span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ($postUrl): ?>
                <a class="fs-13" href="<?php echo iN_HelpSecure($postUrl, false); ?>">#<?php echo (int) $postId; ?></a>
              <?php else: ?>
                <span class="fs-13 text-muted">—</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ($commentOwnerId > 0): ?>
                <a class="user-pill" href="<?php echo iN_HelpSecure($commentProfile, false); ?>">
                  <img class="avatar-32" src="<?php echo iN_HelpSecure($commentAvatar, false); ?>" alt="<?php echo iN_HelpSecure('Avatar of ' . $commentDisplayName, false); ?>">
                  <span class="name"><?php echo iN_HelpSecure($commentDisplayName, false); ?></span>
                </a>
              <?php else: ?>
                <span class="fs-13 text-muted"><?php echo iN_HelpSecure($unknownLabel, false); ?></span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ($reporterId > 0): ?>
                <a class="user-pill" href="<?php echo iN_HelpSecure($reporterProfile, false); ?>">
                  <img class="avatar-32" src="<?php echo iN_HelpSecure($reporterAvatar, false); ?>" alt="<?php echo iN_HelpSecure('Avatar of ' . $reporterDisplayName, false); ?>">
                  <span class="name"><?php echo iN_HelpSecure($reporterDisplayName, false); ?></span>
                </a>
              <?php else: ?>
                <span class="fs-13 text-muted"><?php echo iN_HelpSecure($unknownLabel, false); ?></span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ($reason !== ''): ?>
                <span class="reason-chip">
                  <?php echo renderVerifiedBadge($iconPath . 'notification.svg', true); ?>
                  <span><?php echo iN_HelpSecure($reason); ?></span>
                </span>
              <?php else: ?>
                <span class="text-muted fs-13">—</span>
              <?php endif; ?>
            </td>
            <td>
              <span class="text-muted fs-13 meta-time"><?php echo renderVerifiedBadge($iconPath . 'time.svg', true); ?> <?php echo iN_HelpSecure($reportedAt, false); ?></span>
            </td>
            <td>
              <span class="pill <?php echo $statusClass; ?>"><?php echo iN_HelpSecure($statusLabel, false); ?></span>
            </td>
            <td>
              <div class="post-settings-btn-box flex align_items relative">
                <button
                  type="button"
                  class="post-settings-btn flex align_items_justify_content relative"
                  aria-expanded="false"
                  aria-haspopup="menu"
                  title="<?php echo iN_HelpSecure(customLang('admin_comments_actions_label') ?: 'Actions', false); ?>"
                  data-id="<?php echo (int) $commentId; ?>"
                  data-report-id="<?php echo $reportId; ?>"
                >
                  <?php echo renderVerifiedBadge($iconPath . 'dots.svg', false); ?>
                </button>
              </div>
              <div
                id="postMenuPopup-<?php echo (int) $commentId; ?>"
                class="post-menu-popup none"
                aria-hidden="true"
                role="dialog"
                aria-label="<?php echo iN_HelpSecure('Comment actions for #' . $commentId, false); ?>"
              >
                <div class="pm-sheet-container">
                  <div class="pm-sheet">
                    <?php if ($commentUrl): ?>
                      <a class="pm-item" href="<?php echo iN_HelpSecure($commentUrl, false); ?>">
                        <?php echo renderVerifiedBadge($iconPath . 'link_out.svg', true); ?>
                        <span><?php echo iN_HelpSecure(customLang('admin_comments_action_view_comment') ?: 'View comment', false); ?></span>
                      </a>
                    <?php endif; ?>
                    <?php if ($postUrl): ?>
                      <a class="pm-item" href="<?php echo iN_HelpSecure($postUrl, false); ?>">
                        <?php echo renderVerifiedBadge($iconPath . 'reels.svg', true); ?>
                        <span><?php echo iN_HelpSecure(customLang('admin_comments_action_view_post') ?: 'Open post', false); ?></span>
                      </a>
                    <?php endif; ?>
                    <?php if ($postOwnerId > 0): ?>
                      <a class="pm-item" href="<?php echo $postOwnerUrl; ?>">
                        <?php echo renderVerifiedBadge($iconPath . 'profile.svg', true); ?>
                        <span><?php echo iN_HelpSecure(customLang('admin_comments_action_post_owner') ?: 'Post owner details', false); ?></span>
                      </a>
                    <?php endif; ?>
                    <div class="pm-divider"></div>
                    <button
                      type="button"
                      class="pm-item flex align_items_justify_content js-cact<?= $canResolveReports ? '' : ' is-disabled'; ?>"
                      data-action="resolve"
                      data-comment-id="<?php echo (int) $commentId; ?>"
                      data-report-id="<?php echo $reportId; ?>"
                      <?= $canResolveReports ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>
                    >
                      <?php echo renderVerifiedBadge($iconPath . 'tick.svg', true); ?>
                      <span><?php echo iN_HelpSecure(customLang('admin_comments_action_resolve') ?: 'Mark as resolved', false); ?></span>
                    </button>
                    <button
                      type="button"
                      class="pm-item flex align_items_justify_content js-cact<?php echo ($commentExists && $canDeleteComment) ? '' : ' is-disabled'; ?>"
                      data-action="delete_comment"
                      data-comment-id="<?php echo (int) $commentId; ?>"
                      data-report-id="<?php echo $reportId; ?>"
                      <?php if (!$commentExists || !$canDeleteComment): ?>disabled aria-disabled="true" title="<?php echo iN_HelpSecure($permissionTip, false); ?>"<?php endif; ?>
                    >
                      <?php echo renderVerifiedBadge($iconPath . 'delete.svg', true); ?>
                      <span><?php echo iN_HelpSecure(customLang('admin_comments_action_delete_comment') ?: 'Delete comment', false); ?></span>
                    </button>
                    <button type="button" class="pm-item pm-cancel"><?php echo iN_HelpSecure(customLang('pm_cancel') ?: 'Cancel', false); ?></button>
                  </div>
                </div>
              </div>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
  <?php
    echo dz_render_pagination(
      $base_url . 'admin/index.php',
      ['page' => $pageSlug, 'per' => (string) $per],
      (int) $pageNo,
      (int) $pages,
      ['show_goto' => true, 'radius' => 1]
    );
  ?>
</section>
