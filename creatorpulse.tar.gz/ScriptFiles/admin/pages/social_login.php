<?php
declare(strict_types=1);
require_once __DIR__ . '/../_bootstrap.php';

global $siteData, $base_url, $ADMIN_CSRF, $socialLoginConfig;

$providers = social_login_get_config($siteData ?? []);
$actionUrl = iN_HelpSecure($base_url . 'admin/request/social_login.php', false);
$csrfToken = iN_HelpSecure($ADMIN_CSRF, false);

$maskSecret = static function (string $value, string $source): string {
    if ($source === 'env') {
        return '';
    }
    return $value !== '' ? str_repeat('•', 8) : '';
};

$redirects = [
    'google'   => iN_HelpSecure(social_login_redirect_uri('google'), false),
    'facebook' => iN_HelpSecure(social_login_redirect_uri('facebook'), false),
    'twitter'  => iN_HelpSecure(social_login_redirect_uri('twitter'), false),
];

$textToggle = iN_HelpSecure(customLang('admin_social_login_toggle') ?: 'Enable');
$textClientId = iN_HelpSecure(customLang('admin_social_login_client_id') ?: 'Client ID');
$textClientSecret = iN_HelpSecure(customLang('admin_social_login_client_secret') ?: 'Client Secret');
$textRedirect = iN_HelpSecure(customLang('admin_social_login_redirect') ?: 'Redirect URI');
$textEnvHint = customLang('admin_social_login_env_hint') ?: 'Configured via environment variable. Update .env to change this value.';
$textSubmit = iN_HelpSecure(customLang('admin_social_login_save') ?: 'Save Changes');
$introText = customLang('admin_social_login_intro') ?: 'Manage OAuth credentials for Google, Facebook, and Twitter sign in. When a value is provided via environment variables it will take precedence over what you enter here.';
$title = customLang('admin_social_login_title') ?: 'Social Login Management';
$stepsTitle = customLang('admin_social_login_steps_title') ?: 'Setup guide';
$stepsMap = [
    'google' => [
        customLang('admin_social_login_google_step1'),
        customLang('admin_social_login_google_step2'),
        customLang('admin_social_login_google_step3'),
    ],
    'facebook' => [
        customLang('admin_social_login_facebook_step1'),
        customLang('admin_social_login_facebook_step2'),
        customLang('admin_social_login_facebook_step3'),
    ],
    'twitter' => [
        customLang('admin_social_login_twitter_step1'),
        customLang('admin_social_login_twitter_step2'),
        customLang('admin_social_login_twitter_step3'),
    ],
];
?>

<section class="card rounded-2xl" role="region" aria-labelledby="adminSocialLoginHeading">
  <h1 id="adminSocialLoginHeading"><?php echo iN_HelpSecure($title); ?></h1>
  <p class="box-note full-width"><?php echo iN_HelpSecure($introText); ?></p>

  <form method="post" action="<?php echo $actionUrl; ?>" class="form-container flex flexBoxColumn" data-action="save-social-login" autocomplete="off">
    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

    <?php foreach (['google', 'facebook', 'twitter'] as $providerKey):
      $meta = $providers[$providerKey] ?? ['label' => ucfirst($providerKey), 'enabled' => false, 'client_id' => '', 'client_secret' => '', 'client_id_src' => 'unset', 'client_secret_src' => 'unset'];
      $label = iN_HelpSecure(customLang('admin_social_login_provider_' . $providerKey) ?: $meta['label']);
      $statusName = $providerKey . '_status';
      $idName = $providerKey === 'facebook' ? 'facebook_app_id' : $providerKey . '_client_id';
      $secretName = $providerKey === 'facebook' ? 'facebook_app_secret' : $providerKey . '_client_secret';
      $clientId = iN_HelpSecure((string)($meta['client_id'] ?? ''));
      $secretMask = iN_HelpSecure($maskSecret((string)($meta['client_secret'] ?? ''), (string)($meta['client_secret_src'] ?? 'unset')));
      $statusChecked = ($meta['enabled'] ?? false) ? 'checked' : '';
      $idSource = (string)($meta['client_id_src'] ?? 'unset');
      $secretSource = (string)($meta['client_secret_src'] ?? 'unset');
      $redirect = $redirects[$providerKey];
      $guideSteps = array_filter(array_map('trim', $stepsMap[$providerKey] ?? []), static function ($line) {
          return $line !== '';
      });
    ?>
    <fieldset class="form-input-wrapper social-login-block">
      <legend><?php echo $label; ?></legend>

      <div class="social-login-toggle">
        <span class="fs-13"><?php echo $textToggle; ?></span>
        <label class="el-switch el-switch-sm" aria-label="<?php echo $textToggle . ' ' . $label; ?>">
          <input type="hidden" name="<?php echo $statusName; ?>" value="close">
          <input type="checkbox" name="<?php echo $statusName; ?>" value="open" <?php echo $statusChecked; ?> />
          <span class="el-switch-style"></span>
        </label>
      </div>

      <div class="form-grid form-grid--half social-login-credentials">
        <div class="form-input-wrapper">
          <label class="form-label" for="<?php echo $idName; ?>"><?php echo $textClientId; ?></label>
          <input id="<?php echo $idName; ?>" class="form-input" type="text" name="<?php echo $idName; ?>" value="<?php echo $clientId; ?>" autocomplete="new-<?php echo $idName; ?>" placeholder="<?php echo $providerKey === 'twitter' ? iN_HelpSecure('Example: abc123...') : ''; ?>">
          <?php if ($idSource === 'env'): ?>
            <small class="form-text text-muted"><?php echo iN_HelpSecure(str_replace(['{VAR}'], [strtoupper($idName)], $textEnvHint)); ?></small>
          <?php endif; ?>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="<?php echo $secretName; ?>"><?php echo $textClientSecret; ?></label>
          <input id="<?php echo $secretName; ?>" class="form-input" type="password" name="<?php echo $secretName; ?>" value="<?php echo $secretMask; ?>" autocomplete="new-password" placeholder="<?php echo $secretMask === '' ? iN_HelpSecure(customLang('admin_social_login_secret_placeholder')) : ''; ?>">
          <?php if ($secretSource === 'env'): ?>
            <small class="form-text text-muted"><?php echo iN_HelpSecure(str_replace(['{VAR}'], [strtoupper($secretName)], $textEnvHint)); ?></small>
          <?php else: ?>
            <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('admin_social_login_secret_hint') ?: 'Leave blank to keep the existing secret.'); ?></small>
          <?php endif; ?>
        </div>
      </div>

      <label class="form-label" for="<?php echo $providerKey; ?>_redirect_uri"><?php echo $textRedirect; ?></label>
      <input id="<?php echo $providerKey; ?>_redirect_uri" class="form-input" type="text" value="<?php echo $redirect; ?>" readonly>
      <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('admin_social_login_redirect_hint') ?: 'Copy this URL into your provider console.'); ?></small>

      <?php if (!empty($guideSteps)): ?>
      <div class="social-login-help">
        <strong><?php echo iN_HelpSecure($stepsTitle); ?>:</strong>
        <ol>
          <?php foreach ($guideSteps as $step):
            $renderedStep = str_replace('{{redirect}}', '<code>' . iN_HelpSecure($redirect) . '</code>', $step);
          ?>
          <li><?php echo $renderedStep; ?></li>
          <?php endforeach; ?>
        </ol>
      </div>
      <?php endif; ?>
    </fieldset>
    <?php endforeach; ?>

    <div class="form-input-wrapper">
      <button type="submit" class="admin-button admin-button--primary"><?php echo $textSubmit; ?></button>
    </div>
  </form>
</section>
