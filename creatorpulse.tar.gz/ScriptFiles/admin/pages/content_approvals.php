<?php
declare(strict_types=1);
require_once __DIR__ . '/../_bootstrap.php';

global $ADM, $base_url, $ADMIN_CSRF, $iconPath, $db, $RL;
$canApprove = admin_has_permission('content.approve');
$permissionTip = customLang('admin_permission_denied_tooltip') ?: 'You do not have permission to perform this action.';

$statusFilter = strtolower((string)($_GET['status'] ?? 'pending'));
if (!in_array($statusFilter, ['pending', 'approved', 'rejected'], true)) {
    $statusFilter = 'pending';
}
$typeFilter = strtolower((string)($_GET['type'] ?? 'all'));
if (!in_array($typeFilter, ['all', 'image', 'video'], true)) {
    $typeFilter = 'all';
}
$userFilter = isset($_GET['user_id']) ? max(0, (int)$_GET['user_id']) : 0;
$pageNo = isset($_GET['page_no']) ? max(1, (int)$_GET['page_no']) : 1;
$per = isset($_GET['per']) ? max(5, min(100, (int)$_GET['per'])) : 20;
$offset = ($pageNo - 1) * $per;

$filters = ['status' => $statusFilter];
if ($typeFilter !== 'all') { $filters['type'] = $typeFilter; }
if ($userFilter > 0) { $filters['user_id'] = $userFilter; }

$posts = $ADM->ADM_ListPostApprovals($filters, $per, $offset);

// Count total for pagination
$where = ['p.approval_status = :status'];
$params = [':status' => $statusFilter];
if ($typeFilter !== 'all') { $where[] = 'p.post_type = :ptype'; $params[':ptype'] = $typeFilter; }
if ($userFilter > 0) { $where[] = 'p.post_owner_id = :uid'; $params[':uid'] = $userFilter; }
$total = 0;
try {
    $countSql = 'SELECT COUNT(*) FROM i_user_posts p WHERE ' . implode(' AND ', $where);
    $stCount = $db->prepare($countSql);
    foreach ($params as $k => $v) {
        $stCount->bindValue($k, $v, is_int($v) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
    }
    $stCount->execute();
    $total = (int) ($stCount->fetchColumn() ?: 0);
} catch (Throwable $__) {
    $total = 0;
}
$pages = max(1, (int) ceil($total / max(1, $per)));

$actionUrl = iN_HelpSecure($base_url . 'admin/request/content_approvals.php', false);
$currentUrl = iN_HelpSecure($base_url . 'admin/index.php?page=content_approvals&status=' . $statusFilter . '&type=' . $typeFilter . '&user_id=' . (string)$userFilter . '&page_no=' . (string)$pageNo . '&per=' . (string)$per, false);
$csrfToken = iN_HelpSecure($ADMIN_CSRF, false);

$flashKey = isset($_GET['flash']) ? (string)$_GET['flash'] : '';
$flashMessage = '';
if ($flashKey === 'approved') {
    $flashMessage = customLang('admin_post_approval_flash_approved') ?: 'Post approved and published.';
} elseif ($flashKey === 'rejected') {
    $flashMessage = customLang('admin_post_approval_flash_rejected') ?: 'Post marked as rejected.';
} elseif ($flashKey === 'invalid_csrf') {
    $flashMessage = customLang('invalid_csrf_token') ?: 'Security token invalid.';
} elseif ($flashKey === 'forbidden') {
    $flashMessage = customLang('admin_permission_denied_message') ?: 'You do not have permission to perform this action.';
} elseif ($flashKey === 'error') {
    $flashMessage = customLang('admin_post_approval_flash_error') ?: 'Unable to update approval status.';
}

$statusLabels = [
    'pending'  => customLang('post_status_pending') ?: 'Pending approval',
    'approved' => customLang('post_status_approved') ?: 'Approved',
    'rejected' => customLang('post_status_rejected') ?: 'Rejected',
];
$typeLabels = [
    'all'   => customLang('admin_filter_all_types') ?: 'All types',
    'image' => customLang('admin_filter_images') ?: 'Images',
    'video' => customLang('admin_filter_videos') ?: 'Videos',
];

$title = customLang('admin_post_approvals_title');
if (!is_string($title) || $title === 'admin_post_approvals_title') {
    $title = 'Post Approvals';
}
?>

<section class="card rounded-2xl admin-settings" role="region" aria-labelledby="adminPostApprovalsHeading" data-content-approvals-root>
  <div class="list-header" id="adminPostApprovalsHeading">
    <span class="icon"><?php echo renderVerifiedBadge($iconPath . 'admin.svg', true); ?></span>
    <span><strong><?php echo iN_HelpSecure($title, false); ?></strong></span>
  </div>

  <form method="get" action="<?php echo iN_HelpSecure($base_url . 'admin/index.php', false); ?>" class="form-container form-container--columns">
    <input type="hidden" name="page" value="content_approvals">
    <div class="form-input-wrapper">
      <label class="form-label" for="status"><?php echo iN_HelpSecure(customLang('admin_filter_status') ?: 'Status', false); ?></label>
      <select id="status" name="status" class="form-input">
        <?php foreach ($statusLabels as $value => $label): ?>
          <option value="<?php echo iN_HelpSecure($value, false); ?>"<?php echo $value === $statusFilter ? ' selected' : ''; ?>>
            <?php echo iN_HelpSecure($label, false); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="form-input-wrapper">
      <label class="form-label" for="type"><?php echo iN_HelpSecure(customLang('admin_filter_type') ?: 'Type', false); ?></label>
      <select id="type" name="type" class="form-input">
        <?php foreach ($typeLabels as $value => $label): ?>
          <option value="<?php echo iN_HelpSecure($value, false); ?>"<?php echo $value === $typeFilter ? ' selected' : ''; ?>>
            <?php echo iN_HelpSecure($label, false); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="form-input-wrapper">
      <label class="form-label" for="user_id"><?php echo iN_HelpSecure(customLang('admin_filter_user_id') ?: 'User ID', false); ?></label>
      <input id="user_id" class="form-input" type="number" name="user_id" min="0" value="<?php echo (int)$userFilter; ?>" placeholder="0">
    </div>

    <div class="form-input-wrapper">
      <label class="form-label" for="per"><?php echo iN_HelpSecure(customLang('admin_posts_filter_per_page') ?: 'Per page', false); ?></label>
      <select id="per" name="per" class="form-input">
        <?php foreach ([10,20,50,100] as $pp): ?>
          <option value="<?php echo $pp; ?>"<?php echo $pp===$per?' selected':''; ?>><?php echo $pp; ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="form-input-wrapper form-actions">
      <label class="form-label sr-only" for="filterSubmit"><?php echo iN_HelpSecure(customLang('admin_posts_filter_apply') ?: 'Apply', false); ?></label>
      <button id="filterSubmit" type="submit" class="pe-save btn-hover"><?php echo iN_HelpSecure(customLang('admin_posts_filter_apply') ?: 'Apply', false); ?></button>
    </div>
  </form>

  <?php if ($flashMessage !== ''): ?>
    <div class="post-approval-alert post-approval-alert--<?php echo iN_HelpSecure($flashKey === 'rejected' ? 'rejected' : 'pending'); ?>">
      <?php echo iN_HelpSecure($flashMessage); ?>
    </div>
  <?php endif; ?>

  <div class="table-responsive mt-4">
    <table class="table table-striped table-sm table-subs full-width">
      <thead>
        <tr>
          <th><?php echo iN_HelpSecure(customLang('admin_posts_col_id') ?: 'ID'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_posts_col_owner') ?: 'Owner'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_posts_col_type') ?: 'Type'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_posts_col_visibility') ?: 'Visibility'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_filter_status') ?: 'Status'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_posts_col_created') ?: 'Created'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_posts_col_actions') ?: 'Actions'); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$posts): ?>
        <tr>
          <td colspan="7" class="text-center text-muted empty_class_table">
            <?php echo iN_HelpSecure(customLang('admin_posts_empty_posts') ?: 'No posts found.', false); ?>
          </td>
        </tr>
        <?php else: foreach ($posts as $p):
          $pid = (int) ($p['post_id'] ?? 0);
          $ownerId = (int) ($p['post_owner_id'] ?? 0);
          $ownerUsername = (string) ($p['username'] ?? '');
          $ownerFullname = (string) ($p['user_fullname'] ?? $ownerUsername);
          $ownerUrl = ($base_url ?? '/') . 'profile/' . rawurlencode($ownerUsername);
          $ownerAvRel = (isset($RL) && method_exists($RL, 'RL_userAvatar')) ? $RL->RL_userAvatar($ownerId) : 'uploads/user_avatars/default.jpeg';
          $ownerAvUrl = admin_resolve_media_url($ownerAvRel);
          $postUrl = ($base_url ?? '/') . 'posts/' . $pid . '/' . rawurlencode($ownerUsername);
          $statusVal = strtolower((string)($p['approval_status'] ?? 'approved'));
          $statusLabel = $statusLabels[$statusVal] ?? ucfirst($statusVal);
          $createdTs = (int) ($p['post_created_time'] ?? 0);
          $createdTxt = $createdTs > 0 ? date('Y-m-d H:i', $createdTs) : '-';
          $note = isset($p['approval_notes']) ? (string)$p['approval_notes'] : '';
        ?>
        <tr>
          <td><?php echo $pid; ?></td>
          <td>
            <a class="user-pill" href="<?php echo iN_HelpSecure($ownerUrl, false); ?>">
              <img class="avatar-32" src="<?php echo iN_HelpSecure($ownerAvUrl, false); ?>" alt="<?php echo iN_HelpSecure('Avatar of ' . $ownerUsername, false); ?>">
              <span class="name"><?php echo iN_HelpSecure($ownerFullname, false); ?></span>
            </a>
          </td>
          <td><?php echo iN_HelpSecure(ucfirst((string)($p['post_type'] ?? '')), false); ?></td>
          <td><?php echo iN_HelpSecure(ucfirst((string)($p['post_visibility'] ?? '')), false); ?></td>
          <td>
            <span class="post-approval-chip post-approval-chip--<?php echo iN_HelpSecure($statusVal); ?>">
              <?php echo iN_HelpSecure($statusLabel); ?>
            </span>
            <?php if ($note !== ''): ?>
              <div class="text-muted fs-13"><?php echo iN_HelpSecure($note); ?></div>
            <?php endif; ?>
          </td>
          <td><?php echo iN_HelpSecure($createdTxt); ?></td>
          <td>
            <div class="post-settings-btn-box flex align_items relative">
              <button
                type="button"
                class="post-settings-btn flex align_items_justify_content relative"
                aria-expanded="false"
                aria-haspopup="menu"
                title="<?php echo iN_HelpSecure(customLang('admin_posts_col_actions') ?: 'Actions', false); ?>"
                data-id="<?php echo $pid; ?>"
              >
                <?php echo renderVerifiedBadge($iconPath . 'dots.svg', false); ?>
              </button>
            </div>

            <div id="postMenuPopup-<?php echo $pid; ?>" class="post-menu-popup none" aria-hidden="true" role="dialog" aria-label="<?php echo iN_HelpSecure('Approval actions for #' . $pid, false); ?>">
              <div class="pm-sheet-container">
                <div class="pm-sheet approval-popup">
                  <div class="approval-popup__header">
                    <div class="approval-popup__title"><?php echo iN_HelpSecure(customLang('admin_post_approval_actions') ?: 'Approval actions', false); ?></div>
                    <div class="approval-popup__meta">#<?php echo (int)$pid; ?></div>
                  </div>
                  <form method="post" action="<?php echo $actionUrl; ?>" class="approval-popup__form">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                    <input type="hidden" name="post_id" value="<?php echo $pid; ?>">
                    <input type="hidden" name="redirect" value="<?php echo $currentUrl; ?>">
                    <label class="form-label" for="note-<?php echo $pid; ?>"><?php echo iN_HelpSecure(customLang('admin_post_approval_note_placeholder') ?: 'Add note (optional)', false); ?></label>
                    <input
                      id="note-<?php echo $pid; ?>"
                      type="text"
                      name="note"
                      class="form-input"
                      value="<?php echo iN_HelpSecure($note); ?>"
                      placeholder="<?php echo iN_HelpSecure(customLang('admin_post_approval_note_placeholder') ?: 'Add note (optional)', false); ?>"
                      <?php echo $canApprove ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>
                    >
                    <div class="approval-popup__actions">
                      <button type="submit" name="submit_action" value="approve" class="pe-save btn-hover approval-popup__btn<?= $canApprove ? '' : ' is-disabled'; ?>"<?php echo $canApprove ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?php echo iN_HelpSecure(customLang('admin_action_approve') ?: 'Approve', false); ?></button>
                      <button type="submit" name="submit_action" value="reject" class="admin-button admin-button--ghost is-danger approval-popup__btn<?= $canApprove ? '' : ' is-disabled'; ?>"<?php echo $canApprove ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?php echo iN_HelpSecure(customLang('admin_action_reject') ?: 'Reject', false); ?></button>
                    </div>
                  </form>
                  <div class="pm-divider"></div>
                  <div class="approval-popup__secondary">
                    <a class="pm-item approval-popup__link" href="<?php echo iN_HelpSecure($postUrl, false); ?>" target="_blank" rel="noopener noreferrer">
                      <?php echo renderVerifiedBadge($iconPath . 'link_out.svg', true); ?>
                      <span><?php echo iN_HelpSecure(customLang('admin_post_open') ?: 'Open post'); ?></span>
                    </a>
                    <button type="button" class="pm-item pm-cancel approval-popup__cancel"><?php echo iN_HelpSecure(customLang('cancel') ?: 'Cancel', false); ?></button>
                  </div>
                </div>
              </div>
            </div>
          </td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <?php
    echo dz_render_pagination(
      $base_url . 'admin/index.php',
      [ 'page' => 'content_approvals', 'status' => $statusFilter, 'type' => $typeFilter, 'user_id' => (string)$userFilter, 'per' => (string)$per ],
      (int)$pageNo,
      (int)$pages,
      [ 'show_goto' => true, 'radius' => 1 ]
    );
  ?>
</section>
