<?php
declare(strict_types=1);
require_once __DIR__ . '/../_bootstrap.php';

global $base_url, $ADMIN_CSRF, $RL, $currentLang;

$pageTitleText = customLang('admin_ebook_languages_title') ?: 'eBook content languages';
$pageIntroText = customLang('admin_ebook_languages_intro') ?: 'Manage the languages creators can assign to eBooks. These labels describe the content language, not the website UI language.';
$actionUrl = iN_HelpSecure($base_url . 'admin/request/ebook_settings.php', false);
$csrfToken = iN_HelpSecure($ADMIN_CSRF, false);
$adminLocale = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)($currentLang ?? 'eng')) ?: 'eng';
$ebookLanguages = (isset($RL) && method_exists($RL, 'RL_GetEbookLanguages'))
    ? $RL->RL_GetEbookLanguages(false, $adminLocale)
    : [];
?>

<div class="admin-ebook-languages-page" data-page-title="<?php echo iN_HelpSecure($pageTitleText, false); ?>" data-language-action-url="<?php echo $actionUrl; ?>" data-language-csrf="<?php echo $csrfToken; ?>">
  <section class="card rounded-2xl admin-settings admin-ebook-language-shell" role="region" aria-labelledby="adminEbookLanguagesHeading">
    <div class="list-header admin-ebook-settings-header">
      <span class="icon"><?php echo render_icon('ebook', true); ?></span>
      <span>
        <strong id="adminEbookLanguagesHeading"><?php echo iN_HelpSecure($pageTitleText, false); ?></strong>
        <small><?php echo iN_HelpSecure($pageIntroText, false); ?></small>
      </span>
      <span class="admin-ebook-language-header-actions">
        <a class="admin-button admin-button--soft" href="<?php echo iN_HelpSecure($base_url . 'admin/index.php?page=settings_ebooks', false); ?>"><?php echo iN_HelpSecure(customLang('admin_menu_settings_ebooks') ?: 'eBook Settings', false); ?></a>
        <button type="button" class="admin-button admin-button--primary" data-ebook-language-open><?php echo iN_HelpSecure(customLang('admin_ebook_language_add') ?: 'Add language', false); ?></button>
      </span>
    </div>

    <?php if ($ebookLanguages): ?>
      <div class="table-responsive admin-ebook-language-table-wrap">
        <table class="table table-striped table-sm table-subs table-users admin-ebook-language-admin-table">
          <thead>
            <tr>
              <th><?php echo iN_HelpSecure(customLang('admin_ebook_language_tag') ?: 'Tag', false); ?></th>
              <th><?php echo iN_HelpSecure(customLang('admin_ebook_language_english_name') ?: 'Language', false); ?></th>
              <th><?php echo iN_HelpSecure(customLang('admin_ebook_language_display_name') ?: 'Store label', false); ?></th>
              <th><?php echo iN_HelpSecure(customLang('admin_ebook_language_status') ?: 'Status', false); ?></th>
              <th><?php echo iN_HelpSecure(customLang('admin_ebook_language_usage') ?: 'eBooks', false); ?></th>
              <th><?php echo iN_HelpSecure(customLang('updated') ?: 'Updated', false); ?></th>
              <th class="text-right"><?php echo iN_HelpSecure(customLang('actions') ?: 'Actions', false); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($ebookLanguages as $language): ?>
              <?php
                $languageId = (int)($language['language_id'] ?? 0);
                $isActive = (int)($language['is_active'] ?? 0) === 1;
                $isDefault = (int)($language['is_default'] ?? 0) === 1;
                $languageName = (string)($language['english_name'] ?? '');
                $nativeName = (string)($language['native_name'] ?? '');
                $displayName = (string)($language['display_name'] ?? '');
                $updatedAt = (string)($language['updated_at'] ?? '');
                $updatedLabel = '';
                if ($updatedAt !== '') {
                    $updatedLabel = ctype_digit($updatedAt) ? date('Y-m-d H:i', (int)$updatedAt) : $updatedAt;
                }
              ?>
              <tr
                data-language-row
                data-id="<?php echo $languageId; ?>"
                data-tag="<?php echo iN_HelpSecure((string)($language['language_tag'] ?? '')); ?>"
                data-english="<?php echo iN_HelpSecure($languageName); ?>"
                data-native="<?php echo iN_HelpSecure($nativeName); ?>"
                data-display="<?php echo iN_HelpSecure($displayName); ?>"
                data-sort="<?php echo (int)($language['sort_order'] ?? 100); ?>"
                data-active="<?php echo $isActive ? '1' : '0'; ?>"
                data-default="<?php echo $isDefault ? '1' : '0'; ?>"
              >
                <td><span class="pill pill-gray admin-ebook-language-tag"><?php echo iN_HelpSecure((string)($language['language_tag'] ?? '')); ?></span></td>
                <td>
                  <div class="user-pill admin-ebook-language-name">
                    <span class="avatar avatar-32 admin-ebook-language-avatar"><?php echo render_icon('ebook', true); ?></span>
                    <span>
                      <strong><?php echo iN_HelpSecure($languageName !== '' ? $languageName : (string)($language['language_tag'] ?? '')); ?></strong>
                      <small><?php echo iN_HelpSecure($nativeName !== '' ? $nativeName : $displayName); ?></small>
                    </span>
                  </div>
                </td>
                <td><?php echo iN_HelpSecure($displayName !== '' ? $displayName : $nativeName); ?></td>
                <td>
                  <span class="pill <?php echo $isActive ? 'pill-green' : 'pill-gray'; ?>"><?php echo $isActive ? iN_HelpSecure(customLang('admin_ebook_language_active') ?: 'Active', false) : iN_HelpSecure(customLang('disabled') ?: 'Disabled', false); ?></span>
                  <?php if ($isDefault): ?><span class="pill pill-amber"><?php echo iN_HelpSecure(customLang('admin_ebook_language_default') ?: 'Default', false); ?></span><?php endif; ?>
                </td>
                <td><span class="metric-mini"><?php echo (int)($language['ebook_count'] ?? 0); ?></span></td>
                <td><?php echo $updatedLabel !== '' ? iN_HelpSecure($updatedLabel) : '&mdash;'; ?></td>
                <td class="text-right">
                  <div class="post-settings-btn-box flex align_items relative admin-ebook-language-action-box">
                    <button type="button" class="post-settings-btn flex align_items_justify_content relative js-ebook-language-actions" data-id="lang-<?php echo $languageId; ?>" data-language-id="<?php echo $languageId; ?>" aria-expanded="false" aria-controls="postMenuPopup-lang-<?php echo $languageId; ?>">
                      <?php echo render_icon('dots', true); ?>
                    </button>
                    <div id="postMenuPopup-lang-<?php echo $languageId; ?>" class="post-menu-popup none" role="menu" aria-hidden="true">
                      <div class="pm-sheet-container">
                        <div class="pm-sheet">
                          <button type="button" class="pm-item" data-language-edit data-language-id="<?php echo $languageId; ?>"><?php echo iN_HelpSecure(customLang('edit') ?: 'Edit', false); ?></button>
                          <?php if (!$isDefault): ?>
                            <button type="button" class="pm-item" data-language-action="set_default" data-language-id="<?php echo $languageId; ?>"><?php echo iN_HelpSecure(customLang('admin_ebook_language_set_default') ?: 'Set default', false); ?></button>
                          <?php endif; ?>
                          <button type="button" class="pm-item" data-language-action="toggle_language" data-language-id="<?php echo $languageId; ?>">
                            <?php echo $isActive ? iN_HelpSecure(customLang('admin_ebook_language_deactivate') ?: 'Deactivate', false) : iN_HelpSecure(customLang('admin_ebook_language_activate') ?: 'Activate', false); ?>
                          </button>
                          <?php if (!$isDefault): ?>
                            <button type="button" class="pm-item danger" data-language-action="delete_language" data-language-id="<?php echo $languageId; ?>" data-confirm="<?php echo iN_HelpSecure(customLang('admin_ebook_language_delete_confirm') ?: 'Delete this eBook language?', false); ?>"><?php echo iN_HelpSecure(customLang('admin_ebook_language_delete') ?: 'Delete', false); ?></button>
                          <?php endif; ?>
                          <button type="button" class="pm-item pm-cancel"><?php echo iN_HelpSecure(customLang('cancel') ?: 'Cancel', false); ?></button>
                        </div>
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <div class="empty-state admin-ebook-language-empty"><?php echo iN_HelpSecure(customLang('admin_ebook_languages_empty') ?: 'No eBook languages have been created yet.', false); ?></div>
    <?php endif; ?>
  </section>

  <div class="admin-ebook-language-modal" data-ebook-language-modal aria-hidden="true">
    <div class="admin-ebook-language-modal__backdrop" data-language-close></div>
    <form class="admin-ebook-language-modal__panel" data-ebook-language-form>
      <button type="button" class="admin-ebook-language-modal__close" data-language-close aria-label="<?php echo iN_HelpSecure(customLang('close') ?: 'Close', false); ?>"><?php echo render_icon('close', true); ?></button>
      <h2 data-language-modal-title><?php echo iN_HelpSecure(customLang('admin_ebook_language_add') ?: 'Add language', false); ?></h2>
      <p><?php echo iN_HelpSecure(customLang('admin_ebook_language_tag_hint') ?: 'Use a standard content language tag such as en, tr or zh-Hans.', false); ?></p>
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
      <input type="hidden" name="ebook_settings_action" value="save_language">
      <input type="hidden" name="language_id" value="0">
      <div class="admin-ebook-language-grid">
        <label class="admin-ebook-language-field">
          <span><?php echo iN_HelpSecure(customLang('admin_ebook_language_tag') ?: 'Language tag', false); ?></span>
          <input type="text" name="language_tag" maxlength="35" placeholder="en, tr, zh-Hans" required>
        </label>
        <label class="admin-ebook-language-field">
          <span><?php echo iN_HelpSecure(customLang('admin_ebook_language_sort') ?: 'Sort order', false); ?></span>
          <input type="number" name="sort_order" min="0" max="9999" value="100">
        </label>
        <label class="admin-ebook-language-field">
          <span><?php echo iN_HelpSecure(customLang('admin_ebook_language_english_name') ?: 'English name', false); ?></span>
          <input type="text" name="english_name" maxlength="120" placeholder="English" required>
        </label>
        <label class="admin-ebook-language-field">
          <span><?php echo iN_HelpSecure(customLang('admin_ebook_language_native_name') ?: 'Native name', false); ?></span>
          <input type="text" name="native_name" maxlength="120" placeholder="English" required>
        </label>
        <label class="admin-ebook-language-field is-wide">
          <span><?php echo iN_HelpSecure(customLang('admin_ebook_language_display_name') ?: 'Store label', false); ?></span>
          <input type="text" name="display_name" maxlength="120" placeholder="<?php echo iN_HelpSecure(customLang('admin_ebook_language_display_name_hint') ?: 'Optional label shown for the current admin language.', false); ?>">
        </label>
      </div>
      <div class="admin-ebook-language-switches">
        <label class="admin-ebook-language-switch">
          <span class="el-switch el-switch-sm margin-bottom-zero">
            <input type="checkbox" name="is_active" value="1" checked>
            <span class="el-switch-style"></span>
          </span>
          <span><?php echo iN_HelpSecure(customLang('admin_ebook_language_active') ?: 'Active', false); ?></span>
        </label>
        <label class="admin-ebook-language-switch">
          <span class="el-switch el-switch-sm margin-bottom-zero">
            <input type="checkbox" name="is_default" value="1">
            <span class="el-switch-style"></span>
          </span>
          <span><?php echo iN_HelpSecure(customLang('admin_ebook_language_default') ?: 'Default', false); ?></span>
        </label>
      </div>
      <div class="admin-ebook-language-modal__message" data-language-message></div>
      <div class="admin-ebook-language-modal__actions">
        <button type="button" class="admin-button admin-button--soft" data-language-close><?php echo iN_HelpSecure(customLang('cancel') ?: 'Cancel', false); ?></button>
        <button type="submit" class="admin-button admin-button--primary"><?php echo iN_HelpSecure(customLang('admin_ebook_language_save') ?: 'Save language', false); ?></button>
      </div>
    </form>
  </div>
</div>
