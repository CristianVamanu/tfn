<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';

global $ADM, $base_url, $iconPath, $currencies, $currencyFormatSettings;

$currenciesMap = isset($currencies) && is_array($currencies) ? $currencies : [];
$currencyFormatSettings = $currencyFormatSettings ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
$formatAmount = static function (float $value, string $currencyCode) use ($currenciesMap, $currencyFormatSettings): string {
    $code = strtoupper($currencyCode ?: ($GLOBALS['currency'] ?? 'USD'));
    $symbol = $currenciesMap[$code] ?? null;

    return dz_format_currency($value, $code, $symbol, $currencyFormatSettings);
};

$pageKey       = 'subs_pending';
$pageTitle     = customLang('admin_subscriptions_pending');
$defaultStatus = 'pending';
$iconName      = 'time_alert.svg';

$q      = isset($_GET['q']) ? (string)trim($_GET['q']) : '';
$status = isset($_GET['status']) ? (string)trim($_GET['status']) : '';
if ($status === '' && $defaultStatus !== '') {
    $status = $defaultStatus;
}
$page   = isset($_GET['page_no']) ? max(1, (int)$_GET['page_no']) : 1;
$per    = isset($_GET['per']) ? max(5, min(100, (int)$_GET['per'])) : 20;
$data   = $ADM->ADM_PagedSubscriptions($q, $status, $page, $per);
$rows   = $data['rows'];
$total  = (int)$data['total'];
$pages  = (int)max(1, ceil($total / max(1, $per)));
$statusOptions = [
    ''          => customLang('admin_subscriptions_status_any'),
    'succeeded' => customLang('admin_subscriptions_status_succeeded'),
    'pending'   => customLang('admin_subscriptions_status_pending'),
    'failed'    => customLang('admin_subscriptions_status_failed'),
    'canceled'  => customLang('admin_subscriptions_status_canceled'),
];
?>
<section class="card rounded-2xl" role="region" aria-labelledby="subsPendingHeading">
  <div class="list-header" id="subsPendingHeading">
    <span class="icon"><?= renderVerifiedBadge($iconPath . $iconName, true); ?></span>
    <span><strong><?= iN_HelpSecure($pageTitle, false); ?></strong></span>
  </div>
  <form method="get" class="form-container form-container--columns" action="<?= iN_HelpSecure($base_url . 'admin/index.php', false); ?>">
    <input type="hidden" name="page" value="<?= iN_HelpSecure($pageKey, false); ?>">
    <div class="form-input-wrapper" data-field="search">
      <label class="form-label" for="subs-pending-q"><?= iN_HelpSecure(customLang('admin_subscriptions_search_label'), false); ?></label>
      <input
          id="subs-pending-q"
          class="form-input"
          type="text"
          name="q"
          value="<?= iN_HelpSecure($q, false); ?>"
          placeholder="<?= iN_HelpSecure(customLang('admin_subscriptions_search_placeholder'), false); ?>"
      >
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="subs-pending-status"><?= iN_HelpSecure(customLang('admin_subscriptions_status_label'), false); ?></label>
      <select id="subs-pending-status" name="status" class="form-input">
        <?php foreach ($statusOptions as $optValue => $optLabel): ?>
          <option value="<?= iN_HelpSecure($optValue, false); ?>"<?= $status === $optValue ? ' selected' : ''; ?>><?= iN_HelpSecure($optLabel, false); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="subs-pending-per"><?= iN_HelpSecure(customLang('admin_subscriptions_per_page'), false); ?></label>
      <select id="subs-pending-per" name="per" class="form-input">
        <?php foreach ([10, 20, 50, 100] as $pp): ?>
          <option value="<?= $pp; ?>"<?= $pp === $per ? ' selected' : ''; ?>><?= $pp; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper form-actions">
      <label class="form-label sr-only" for="subs-pending-submit"><?= iN_HelpSecure(customLang('admin_subscriptions_apply'), false); ?></label>
      <button id="subs-pending-submit" type="submit" class="pe-save btn-hover"><?= iN_HelpSecure(customLang('admin_subscriptions_apply'), false); ?></button>
    </div>
  </form>

  <div class="table-responsive mt-4">
    <table class="table table-striped table-sm table-subs">
      <thead>
        <tr>
          <th><?= iN_HelpSecure(customLang('admin_subscriptions_col_id'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_subscriptions_col_buyer'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_subscriptions_col_recipient'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_subscriptions_col_start'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_subscriptions_col_period_end'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_subscriptions_col_plan'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_subscriptions_col_status'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_subscriptions_col_amount'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_subscriptions_col_total'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_subscriptions_col_ref'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_subscriptions_col_invoice'), false); ?></th>
        </tr>
      </thead>
      <tbody>
      <?php if (empty($rows)): ?>
        <tr>
          <td colspan="11" class="text-center text-muted empty_class_table">
            <?= iN_HelpSecure(customLang('admin_subscriptions_empty_pending'), false); ?>
          </td>
        </tr>
      <?php else: foreach ($rows as $r):
        $id = (int)($r['id'] ?? 0);
        $bUser = (string)($r['buyer_username'] ?? '');
        $bName = (string)($r['buyer_fullname'] ?? $bUser);
        $rUser = (string)($r['recip_username'] ?? '');
        $rName = (string)($r['recip_fullname'] ?? $rUser);
        $bAv   = admin_resolve_media_url((string)($r['buyer_avatar'] ?? 'uploads/user_avatars/default.jpeg'));
        $rAv   = admin_resolve_media_url((string)($r['recip_avatar'] ?? 'uploads/user_avatars/default.jpeg'));
        $interval = (string)($r['plan_interval'] ?? '');
        $intervalCnt = (int)($r['interval_count'] ?? 1);
        $plan  = ucfirst($interval ?: '');
        $amountVal= (float)($r['amount'] ?? 0);
        $currency = (string)($r['currency'] ?? '');
        $provider = (string)($r['provider'] ?? '');
        $reference= (string)($r['reference'] ?? '');
        $statusRaw= (string)($r['status'] ?? '');
        $statusTxt = $statusRaw === 'succeeded'
            ? customLang('admin_subscriptions_status_active')
            : customLang('admin_subscriptions_status_' . $statusRaw);
        $started = isset($r['started_at']) && $r['started_at'] > 0 ? date('d/m/Y', (int)$r['started_at']) : '-';
        $periodEnd = isset($r['current_period_end']) && $r['current_period_end'] > 0 ? date('d/m/Y', (int)$r['current_period_end']) : '-';
        $bUrl = ($base_url ?? '/') . 'profile/' . rawurlencode($bUser);
        $rUrl = ($base_url ?? '/') . 'profile/' . rawurlencode($rUser);
        $amount = $formatAmount($amountVal, $currency);
        $total  = $formatAmount($amountVal * max(1, $intervalCnt), $currency);
        $planClass = 'pill-amber';
        $statusClass = $statusRaw === 'succeeded' ? 'pill-green' : ($statusRaw === 'pending' ? 'pill-gray' : 'pill-red');
        $providerLabel = $provider !== '' ? ucfirst($provider) : customLang('admin_subscriptions_provider');
        $referenceLabel = $reference !== '' ? $reference : '-';
      ?>
        <tr>
          <td><?= $id; ?></td>
          <td>
            <?php $buyerAlt = sprintf(customLang('alt_avatar_of_user'), $bName); ?>
            <a class="user-pill" href="<?= iN_HelpSecure($bUrl, false); ?>">
              <img class="avatar-32" src="<?= iN_HelpSecure($bAv, false); ?>" alt="<?= iN_HelpSecure($buyerAlt, false); ?>">
              <span class="name"><?= iN_HelpSecure($bName, false); ?></span>
            </a>
          </td>
          <td>
            <?php $recipientAlt = sprintf(customLang('alt_avatar_of_user'), $rName); ?>
            <a class="user-pill" href="<?= iN_HelpSecure($rUrl, false); ?>">
              <img class="avatar-32" src="<?= iN_HelpSecure($rAv, false); ?>" alt="<?= iN_HelpSecure($recipientAlt, false); ?>">
              <span class="name"><?= iN_HelpSecure($rName, false); ?></span>
            </a>
          </td>
          <td class="text-muted fs-13"><?= iN_HelpSecure($started, false); ?></td>
          <td class="text-muted fs-13"><?= iN_HelpSecure($periodEnd, false); ?></td>
          <td><span class="pill <?= $planClass; ?>"><?= iN_HelpSecure($plan, false); ?></span></td>
          <td><span class="pill <?= $statusClass; ?>" title="<?= iN_HelpSecure($provider . ' · ' . $reference, false); ?>"><?= iN_HelpSecure($statusTxt !== '' ? $statusTxt : ucfirst($statusRaw), false); ?></span></td>
          <td class="amount-mono"><?= iN_HelpSecure($amount, false); ?></td>
          <td class="amount-mono"><?= iN_HelpSecure($total, false); ?></td>
          <td>
            <div class="flex align_items gap fs-13">
              <span class="amount-mono fw-600"><?= iN_HelpSecure($providerLabel, false); ?></span>
              <span class="amount-mono">&middot;</span>
              <span class="amount-mono"><?= iN_HelpSecure($referenceLabel, false); ?></span>
            </div>
          </td>
          <td><a class="view-all vivew-invoice" href="<?= iN_HelpSecure(($base_url ?? '/') . 'admin/index.php?page=invoice_subscription&id=' . $id, false); ?>"><?= iN_HelpSecure(customLang('admin_subscriptions_invoice'), false); ?></a></td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <?php
    echo dz_render_pagination(
      $base_url . 'admin/index.php',
      [
        'page'   => $pageKey,
        'q'      => $q,
        'status' => $status,
        'per'    => (string)$per,
      ],
      (int)$page,
      (int)$pages,
      [ 'show_goto' => true, 'radius' => 1 ]
    );
  ?>
</section>
