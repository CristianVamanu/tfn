<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';

global $ADM, $base_url, $iconPath, $siteTitle, $currencies, $currencyFormatSettings;

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
  http_response_code(400);
  $message = iN_HelpSecure(customLang('invoice_error_invalid') ?: 'Invalid invoice id.', false);
  echo '<section class="card rounded-2xl"><div class="p-4">' . $message . '</div></section>';
  exit;
}

$inv = $ADM->ADM_GetTipInvoice($id);
if (!$inv) {
  http_response_code(404);
  $message = iN_HelpSecure(customLang('invoice_error_not_found') ?: 'Invoice could not be found.', false);
  echo '<section class="card rounded-2xl"><div class="p-4">' . $message . '</div></section>';
  exit;
}

$currency = (string)($inv['currency'] ?? '');
$currenciesMap = isset($currencies) && is_array($currencies) ? $currencies : [];
$currencyFormatSettings = $currencyFormatSettings ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
$currencyCode = $currency !== '' ? strtoupper($currency) : strtoupper((string) ($GLOBALS['currency'] ?? 'USD'));
$currencySymbol = $currenciesMap[$currencyCode] ?? null;
$amount   = (float)($inv['amount'] ?? 0);
$net      = isset($inv['net_amount']) ? (float)$inv['net_amount'] : null;
$fee      = isset($inv['fee_amount']) ? (float)$inv['fee_amount'] : 0.0;
$tax      = isset($inv['tax_amount']) ? (float)$inv['tax_amount'] : 0.0;

$fmtMoney = static function (float $v) use ($currencyCode, $currencySymbol, $currencyFormatSettings): string {
  return dz_format_currency($v, $currencyCode, $currencySymbol, $currencyFormatSettings);
};

$created = isset($inv['created_at']) && $inv['created_at'] ? date('d/m/Y', (int)$inv['created_at']) : '-';
$status  = (string)($inv['status'] ?? '');
$isPaid = ($status === 'succeeded');
$statusTxt = $isPaid ? (customLang('invoice_status_paid') ?: 'Paid') : ucfirst($status);
$statusClass = $status === 'succeeded' ? 'pill-green' : (($status === 'pending') ? 'pill-gray' : 'pill-red');

$invoiceNo = 'TIP-' . (int)$inv['id'];
$buyerUrl  = ($base_url ?? '/') . 'profile/' . rawurlencode((string)$inv['buyer_username']);
$recipUrl  = ($base_url ?? '/') . 'profile/' . rawurlencode((string)$inv['recip_username']);
$postUrl   = ($base_url ?? '/') . 'posts/' . (int)($inv['post_id'] ?? 0) . '/' . rawurlencode((string)$inv['recip_username']);
$logoDark  = $iconPath . 'super_thanks.svg';
$recipAvatarRel = (string)($inv['recip_avatar'] ?? 'uploads/user_avatars/default.jpeg');
$recipAvatarUrl = admin_resolve_media_url($recipAvatarRel);
$buyerAvatarRel = (string)($inv['buyer_avatar'] ?? 'uploads/user_avatars/default.jpeg');
$buyerAvatarUrl = admin_resolve_media_url($buyerAvatarRel);
?>

<section class="card rounded-2xl invoice invoice--saas" role="region" aria-labelledby="invHeading">
  <div class="invoice__top">
    <div class="brand-xl">
      <div class="brand-xl__logo"><?php echo renderVerifiedBadge($logoDark, true); ?></div>
      <div class="brand-xl__name"><?php echo iN_HelpSecure(strtoupper($siteTitle ?: 'ReelsProject'), false); ?></div>
    </div>
    <div class="invoice__actions">
      <a href="<?= iN_HelpSecure(($base_url ?? '/') . 'admin/request/invoice_pdf.php?type=tip&id=' . (int)$inv['id'], false); ?>" class="inv-action"><?= iN_HelpSecure(customLang('invoice_action_download') ?: 'Download', false); ?></a>
      <button type="button" class="inv-action js-invoice-print"><?= iN_HelpSecure(customLang('invoice_action_print') ?: 'Print', false); ?></button>
      <a href="<?= iN_HelpSecure(($base_url ?? '/') . 'admin/index.php?page=invoice_tip_detail&id=' . (int)$inv['id'], false); ?>" class="inv-action"><?= iN_HelpSecure(customLang('invoice_action_gateway_details') ?: 'Gateway details', false); ?></a>
    </div>
  </div>

  <div class="inv-section">
    <div>
      <div class="box-title"><?= iN_HelpSecure((customLang('invoice_label_from') ?: 'From') . ':', false); ?></div>
      <div class="party__row">
        <img class="avatar-32" src="<?php echo iN_HelpSecure($recipAvatarUrl, false); ?>" alt="">
        <div class="party__info">
          <div class="party__name"><?php echo iN_HelpSecure($inv['recip_fullname'] ?? '', false); ?></div>
          <div class="party__meta">@<?php echo iN_HelpSecure($inv['recip_username'] ?? '', false); ?> · <?php echo iN_HelpSecure((string)($inv['recip_email'] ?? ''), false); ?></div>
        </div>
      </div>
    </div>
    <div>
      <div class="box-title"><?= iN_HelpSecure((customLang('invoice_label_invoice_to') ?: 'Invoice To') . ':', false); ?></div>
      <div class="summary-list">
        <div><?= iN_HelpSecure(customLang('invoice_label_invoice_number') ?: 'Invoice #', false); ?> <strong><?php echo iN_HelpSecure($invoiceNo, false); ?></strong></div>
        <div><?= iN_HelpSecure(customLang('invoice_label_invoice_date') ?: 'Invoice date', false); ?> <strong><?php echo iN_HelpSecure($created, false); ?></strong></div>
        <?php $invoiceTotal = $amount + $tax + $fee; ?>
        <div><?= iN_HelpSecure(customLang('invoice_label_invoice_amount') ?: 'Invoice amount', false); ?> <strong><?php echo iN_HelpSecure($fmtMoney($invoiceTotal), false); ?></strong></div>
        <div><?= iN_HelpSecure(customLang('invoice_label_customer_id') ?: 'Customer ID', false); ?> <strong><?php echo (int)($inv['buyer_id'] ?? 0); ?></strong></div>
        <div class="paid"><?php echo $isPaid ? iN_HelpSecure(customLang('invoice_label_status_paid') ?: 'PAID', false) : iN_HelpSecure(strtoupper($statusTxt), false); ?></div>
      </div>
    </div>
  </div>

  <div class="inv-section">
    <div>
      <div class="box-title"><?= iN_HelpSecure(customLang('invoice_label_billed_to') ?: 'Billed To', false); ?></div>
      <div class="party__row">
        <img class="avatar-32" src="<?php echo iN_HelpSecure($buyerAvatarUrl, false); ?>" alt="">
        <div class="party__info">
          <a href="<?php echo iN_HelpSecure($buyerUrl, false); ?>" class="party__name"><?php echo iN_HelpSecure($inv['buyer_fullname'] ?? '', false); ?></a>
          <div class="party__meta">@<?php echo iN_HelpSecure($inv['buyer_username'] ?? '', false); ?> · <?php echo iN_HelpSecure((string)($inv['buyer_email'] ?? ''), false); ?></div>
        </div>
      </div>
    </div>
    <div>
      <div class="box-title"><?= iN_HelpSecure(customLang('invoice_label_details_tip') ?: 'Tip details', false); ?></div>
      <div class="summary-list">
        <div><?= iN_HelpSecure(customLang('invoice_label_post') ?: 'Post', false); ?>: <a href="<?php echo iN_HelpSecure($postUrl, false); ?>">#<?php echo (int)($inv['post_id'] ?? 0); ?></a></div>
        <div><?= iN_HelpSecure(customLang('invoice_label_provider') ?: 'Provider', false); ?>: <strong><?php echo iN_HelpSecure((string)($inv['provider'] ?? ''), false); ?></strong></div>
        <div><?= iN_HelpSecure(customLang('invoice_label_reference') ?: 'Reference', false); ?>: <strong><?php echo iN_HelpSecure((string)($inv['reference'] ?? ''), false); ?></strong></div>
      </div>
    </div>
  </div>

  <div class="divider"></div>

  <div class="invoice__items table-responsive inv-items">
    <table class="table table-sm">
      <thead>
        <tr>
          <th><?= iN_HelpSecure(customLang('invoice_table_description') ?: 'Description', false); ?></th>
          <th><?= iN_HelpSecure(customLang('invoice_table_price') ?: 'Price', false); ?></th>
          <th><?= iN_HelpSecure(customLang('invoice_table_discount') ?: 'Discount', false); ?></th>
          <th><?= iN_HelpSecure(customLang('invoice_table_amount') ?: 'Amount', false); ?> <?php echo iN_HelpSecure($currencyCode, false); ?></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <?php $tipHandle = '@' . (string)($inv['recip_username'] ?? ''); ?>
          <td><?= iN_HelpSecure(sprintf(customLang('invoice_line_tip_description') ?: 'Tip – %s', $tipHandle), false); ?></td>
          <td class="amount-mono"><?php echo iN_HelpSecure($fmtMoney($amount), false); ?></td>
          <td class="muted">-</td>
          <td class="amount-mono"><?php echo iN_HelpSecure($fmtMoney($invoiceTotal), false); ?></td>
        </tr>
      </tbody>
    </table>
  </div>

  <div class="inv-section">
    <div class="totals-box">
      <div class="row"><span><?= iN_HelpSecure((customLang('invoice_table_subtotal') ?: 'Subtotal') . ':', false); ?></span><strong class="amount-mono"><?php echo iN_HelpSecure($fmtMoney($amount), false); ?></strong></div>
      <div class="row"><span><?= iN_HelpSecure((customLang('invoice_table_tax') ?: 'Tax') . ':', false); ?></span><strong class="amount-mono"><?php echo iN_HelpSecure($fmtMoney($tax), false); ?></strong></div>
      <div class="row"><span><?= iN_HelpSecure((customLang('invoice_table_fee') ?: 'Fee') . ':', false); ?></span><strong class="amount-mono"><?php echo iN_HelpSecure($fmtMoney($fee), false); ?></strong></div>
      <div class="row"><span><?= iN_HelpSecure((customLang('invoice_table_total') ?: 'Total') . ':', false); ?></span><strong class="amount-mono"><?php echo iN_HelpSecure($fmtMoney($invoiceTotal), false); ?></strong></div>
    </div>
  </div>

  <div class="thanks"><?= iN_HelpSecure(customLang('invoice_footer_thanks') ?: 'Thank you for trusting us', false); ?></div>
  <div class="support-link"><a href="<?php echo iN_HelpSecure($base_url . 'support', false); ?>"><?php echo iN_HelpSecure($base_url);?>support</a></div>
  <div class="foot-note"><?= iN_HelpSecure('*' . (customLang('invoice_footer_note') ?: 'This invoice was generated automatically. Provider and reference details are sourced from the payment gateway.'), false); ?></div>
</section>
