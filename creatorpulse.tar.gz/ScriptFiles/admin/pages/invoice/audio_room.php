<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';

global $ADM, $base_url, $siteTitle, $currencies, $currencyFormatSettings;

$translate = static fn(string $key, string $fallback): string => (string)(customLang($key, $fallback) ?: $fallback);
$type = strtolower(trim((string)($_GET['type'] ?? '')));
$id = max(0, (int)($_GET['id'] ?? 0));
$sourceType = $type === 'ticket' ? 'audio_room_ticket' : ($type === 'tip' ? 'audio_room_tip' : '');
$invoice = $sourceType !== '' ? $ADM->ADM_GetAudioRoomInvoice($sourceType, $id) : null;

if (!$invoice) {
    http_response_code(404);
    ?>
    <section class="admin-audio-invoice admin-audio-invoice--empty card rounded-2xl">
      <h1><?= iN_HelpSecure($translate('admin_audio_room_invoice_not_found', 'Audio Room invoice not found'), false); ?></h1>
      <p><?= iN_HelpSecure($translate('admin_audio_room_invoice_not_found_help', 'The transaction may be incomplete or its invoice has not been issued.'), false); ?></p>
      <a class="admin-button admin-button--primary" href="<?= iN_HelpSecure($base_url . 'admin/index.php?page=audio_room_earnings', false); ?>"><span class="admin-audio-invoice__button-icon" aria-hidden="true"><?= render_icon('back', true); ?></span><span><?= iN_HelpSecure($translate('admin_audio_room_invoice_back', 'Back to earnings'), false); ?></span></a>
    </section>
    <?php
    return;
}

$currenciesMap = isset($currencies) && is_array($currencies) ? $currencies : [];
$currencyFormatSettings = $currencyFormatSettings ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
$currencyCode = strtoupper((string)($invoice['currency'] ?? ($GLOBALS['currency'] ?? 'USD')));
$formatMoney = static function (float $amount) use ($currencyCode, $currenciesMap, $currencyFormatSettings): string {
    return dz_format_currency($amount, $currencyCode, $currenciesMap[$currencyCode] ?? null, $currencyFormatSettings);
};
$invoiceNumber = trim((string)($invoice['invoice_number'] ?? ''));
if ($invoiceNumber === '') {
    $invoiceNumber = ($sourceType === 'audio_room_ticket' ? 'AR-TKT-' : 'AR-TIP-') . $id;
}
$gross = (float)($invoice['amount'] ?? 0);
$fee = (float)($invoice['fee_amount'] ?? 0);
$tax = (float)($invoice['tax_amount'] ?? 0);
$net = isset($invoice['net_amount']) ? (float)$invoice['net_amount'] : max(0, $gross - $fee - $tax);
$createdAt = (int)($invoice['created_at'] ?? 0);
$roomId = (int)($invoice['room_id'] ?? 0);
$buyerName = (string)($invoice['buyer_fullname'] ?? $invoice['buyer_username'] ?? '-');
$recipientName = (string)($invoice['recip_fullname'] ?? $invoice['recip_username'] ?? '-');
$pdfUrl = $base_url . 'admin/request/invoice_pdf.php?type=' . rawurlencode($sourceType) . '&id=' . $id;
?>
<section class="admin-audio-invoice card rounded-2xl" role="region" aria-labelledby="audioRoomInvoiceHeading">
  <div class="admin-audio-invoice__header">
    <div class="admin-audio-invoice__identity">
      <span class="admin-audio-invoice__icon" aria-hidden="true"><?= render_icon('payments', true); ?></span>
      <div class="admin-audio-invoice__identity-copy"><strong><?= iN_HelpSecure((string)($siteTitle ?? 'CreatorPulse'), false); ?></strong><small><?= iN_HelpSecure($translate('admin_audio_room_invoice_finance', 'Audio Room finance'), false); ?></small></div>
    </div>
    <div class="admin-audio-invoice__header-actions">
      <a class="admin-button admin-button--neutral" href="<?= iN_HelpSecure($base_url . 'admin/index.php?page=audio_room_earnings', false); ?>"><span class="admin-audio-invoice__button-icon" aria-hidden="true"><?= render_icon('back', true); ?></span><span><?= iN_HelpSecure($translate('admin_audio_room_invoice_back', 'Back to earnings'), false); ?></span></a>
      <a class="admin-button admin-button--primary" href="<?= iN_HelpSecure($pdfUrl, false); ?>"><span class="admin-audio-invoice__button-icon" aria-hidden="true"><?= render_icon('download', true); ?></span><span><?= iN_HelpSecure($translate('admin_audio_room_invoice_pdf', 'Download PDF'), false); ?></span></a>
    </div>
  </div>

  <div class="admin-audio-invoice__summary">
    <div><span><?= iN_HelpSecure($translate('admin_audio_room_invoice_label', 'Invoice'), false); ?></span><h1 id="audioRoomInvoiceHeading"><?= iN_HelpSecure($invoiceNumber, false); ?></h1></div>
    <div><span><?= iN_HelpSecure($translate('admin_audio_room_invoice_date', 'Issued'), false); ?></span><strong><?= $createdAt > 0 ? date('Y-m-d H:i', $createdAt) : '-'; ?></strong></div>
    <div><span><?= iN_HelpSecure($translate('admin_audio_room_invoice_status', 'Status'), false); ?></span><strong class="admin-audio-invoice__status"><?= iN_HelpSecure(ucfirst((string)($invoice['status'] ?? 'paid')), false); ?></strong></div>
  </div>

  <div class="admin-audio-invoice__parties">
    <article><span><?= iN_HelpSecure($translate('admin_audio_room_invoice_billed_to', 'Billed to'), false); ?></span><strong><?= iN_HelpSecure($buyerName, false); ?></strong><small>@<?= iN_HelpSecure((string)($invoice['buyer_username'] ?? ''), false); ?></small><small><?= iN_HelpSecure((string)($invoice['buyer_email'] ?? ''), false); ?></small></article>
    <article><span><?= iN_HelpSecure($translate('admin_audio_room_invoice_creator', 'Creator'), false); ?></span><strong><?= iN_HelpSecure($recipientName, false); ?></strong><small>@<?= iN_HelpSecure((string)($invoice['recip_username'] ?? ''), false); ?></small><small><?= iN_HelpSecure((string)($invoice['recip_email'] ?? ''), false); ?></small></article>
  </div>

  <div class="admin-audio-invoice__room">
    <span><?= iN_HelpSecure($sourceType === 'audio_room_ticket' ? $translate('admin_audio_room_invoice_ticket', 'Audio Room ticket') : $translate('admin_audio_room_invoice_tip', 'Audio Room tip'), false); ?></span>
    <a href="<?= iN_HelpSecure($base_url . 'audio-room/' . $roomId, false); ?>"><strong><?= iN_HelpSecure((string)($invoice['room_title'] ?? ('#' . $roomId)), false); ?></strong><small>#<?= $roomId; ?></small></a>
  </div>

  <div class="admin-audio-invoice__amounts">
    <div><span><?= iN_HelpSecure($translate('admin_audio_room_invoice_gross', 'Gross amount'), false); ?></span><strong><?= iN_HelpSecure($formatMoney($gross), false); ?></strong></div>
    <div><span><?= iN_HelpSecure($translate('admin_audio_room_invoice_fee', 'Platform fee'), false); ?></span><strong><?= iN_HelpSecure($formatMoney($fee), false); ?></strong></div>
    <div><span><?= iN_HelpSecure($translate('admin_audio_room_invoice_tax', 'Tax allocation'), false); ?></span><strong><?= iN_HelpSecure($formatMoney($tax), false); ?></strong></div>
    <div class="is-total"><span><?= iN_HelpSecure($translate('admin_audio_room_invoice_net', 'Creator net'), false); ?></span><strong><?= iN_HelpSecure($formatMoney($net), false); ?></strong></div>
  </div>

  <footer class="admin-audio-invoice__footer">
    <div><span><?= iN_HelpSecure($translate('admin_audio_room_invoice_provider', 'Provider'), false); ?></span><strong><?= iN_HelpSecure((string)($invoice['provider'] ?? '-'), false); ?></strong></div>
    <div><span><?= iN_HelpSecure($translate('admin_audio_room_invoice_reference', 'Reference'), false); ?></span><code><?= iN_HelpSecure((string)($invoice['reference'] ?? '-'), false); ?></code></div>
  </footer>
</section>
