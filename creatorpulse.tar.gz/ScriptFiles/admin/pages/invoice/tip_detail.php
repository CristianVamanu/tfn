<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';

global $ADM, $base_url;

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
  http_response_code(400);
  $message = iN_HelpSecure(customLang('invoice_error_invalid') ?: 'Invalid invoice id.', false);
  echo '<section class="card rounded-2xl p-4">' . $message . '</section>';
  exit;
}

$log = $ADM->ADM_GetTipInvoiceLog($id);
if (!$log) {
  http_response_code(404);
  $message = iN_HelpSecure(customLang('invoice_error_not_found') ?: 'Invoice could not be found.', false);
  echo '<section class="card rounded-2xl p-4">' . $message . '</section>';
  exit;
}

$created = isset($log['created_at']) && $log['created_at'] ? date('Y-m-d H:i', (int)$log['created_at']) : '-';
?>
<section class="card rounded-2xl" role="region" aria-labelledby="invTipLogHeading">
  <div class="list-header" id="invTipLogHeading">
    <span><strong><?= iN_HelpSecure(customLang('invoice_heading_tip_gateway') ?: 'Tip Gateway Details', false); ?></strong></span>
  </div>
  <div class="p-4">
    <div class="table-responsive">
      <table class="table table-sm">
        <thead><tr><th><?= iN_HelpSecure(customLang('invoice_detail_field') ?: 'Field', false); ?></th><th><?= iN_HelpSecure(customLang('invoice_detail_value') ?: 'Value', false); ?></th></tr></thead>
        <tbody>
          <tr><td>ID</td><td><?= (int)$log['id']; ?></td></tr>
          <tr><td><?= iN_HelpSecure(customLang('invoice_label_provider') ?: 'Provider', false); ?></td><td><?= iN_HelpSecure((string)$log['provider'], false); ?></td></tr>
          <tr><td><?= iN_HelpSecure(customLang('invoice_label_reference') ?: 'Reference', false); ?></td><td><?= iN_HelpSecure((string)$log['reference'], false); ?></td></tr>
          <tr><td><?= iN_HelpSecure(customLang('invoice_detail_status') ?: 'Status', false); ?></td><td><?= iN_HelpSecure((string)$log['status'], false); ?></td></tr>
          <tr><td><?= iN_HelpSecure(customLang('invoice_detail_event') ?: 'Event', false); ?></td><td><?= iN_HelpSecure((string)$log['event'], false); ?></td></tr>
          <tr><td><?= iN_HelpSecure(customLang('invoice_detail_created') ?: 'Created', false); ?></td><td><?= iN_HelpSecure($created, false); ?></td></tr>
        </tbody>
      </table>
    </div>
    <h3 class="h1"><?= iN_HelpSecure(customLang('invoice_section_raw_payload') ?: 'Raw Payload (masked)', false); ?></h3>
    <pre class="inv-code"><?= iN_HelpSecure($log['raw'] ?? '', false); ?></pre>
    <div class="mt-4">
      <a class="view-all" href="<?= iN_HelpSecure($base_url . 'admin/index.php?page=invoice_tip&id=' . (int)$log['id'], false); ?>"><?= iN_HelpSecure(customLang('invoice_action_back_to_invoice') ?: 'Back to Invoice', false); ?></a>
    </div>
  </div>
</section>
