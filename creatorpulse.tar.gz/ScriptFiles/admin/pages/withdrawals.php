<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $ADM, $base_url, $ADMIN_CSRF, $iconPath, $RL, $currencys, $currencies, $currencyFormatSettings;

$pageSlug = 'withdrawals';
$pageNo = isset($_GET['page_no']) ? max(1, (int) $_GET['page_no']) : 1;
$perPage = isset($_GET['per']) ? max(10, min(100, (int) $_GET['per'])) : 20;
$statusParam = isset($_GET['status']) ? strtolower((string) $_GET['status']) : 'all';
$methodParam = isset($_GET['method']) ? strtolower((string) $_GET['method']) : 'all';
$searchParam = isset($_GET['q']) ? trim((string) $_GET['q']) : '';

$data = is_object($ADM) && method_exists($ADM, 'ADM_ListWithdrawalRequests')
    ? $ADM->ADM_ListWithdrawalRequests([
        'page'   => $pageNo,
        'per'    => $perPage,
        'status' => $statusParam,
        'method' => $methodParam,
        'search' => $searchParam,
    ])
    : ['rows' => [], 'total' => 0, 'pages' => 1];

$rows = isset($data['rows']) && is_array($data['rows']) ? $data['rows'] : [];
$totalItems = isset($data['total']) ? (int) $data['total'] : (int) count($rows);
$totalPages = isset($data['pages']) ? (int) $data['pages'] : (int) max(1, ceil($totalItems / max(1, $perPage)));

$currencyMap = (isset($currencys) && is_array($currencys))
    ? $currencys
    : ((isset($currencies) && is_array($currencies)) ? $currencies : []);
$currencyFormatSettings = $currencyFormatSettings ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));

$formatMoney = static function (?float $amount, string $currency) use ($currencyMap, $currencyFormatSettings): string {
    if ($amount === null) {
        return '—';
    }

    $code = strtoupper($currency ?: ($GLOBALS['currency'] ?? 'USD'));
    $symbol = $currencyMap[$code] ?? null;

    return dz_format_currency(
        (float) $amount,
        $code,
        $symbol,
        $currencyFormatSettings
    );
};

$statusOptions = [
    'all'       => customLang('admin_withdrawals_filter_status_all', 'All statuses'),
    'open'      => customLang('admin_withdrawals_filter_status_open', 'Pending & Review'),
    'pending'   => customLang('withdrawal_status_pending', 'Pending'),
    'processing'=> customLang('withdrawal_status_processing', 'Processing'),
    'review'    => customLang('withdrawal_status_review', 'In review'),
    'approved'  => customLang('withdrawal_status_approved', 'Approved'),
    'completed' => customLang('withdrawal_status_completed', 'Completed'),
    'paid'      => customLang('withdrawal_status_paid', 'Paid'),
    'rejected'  => customLang('withdrawal_status_rejected', 'Rejected'),
    'failed'    => customLang('withdrawal_status_failed', 'Failed'),
    'canceled'  => customLang('withdrawal_status_canceled', 'Canceled'),
];

$statusSelectOptions = array_diff_key($statusOptions, ['all' => true, 'open' => true]);

$methodOptions = [
    'all'     => customLang('admin_withdrawals_filter_method_all', 'All methods'),
    'bank'    => customLang('settings_payout_bank_title', 'Bank transfer'),
    'paypal'  => 'PayPal',
    'stripe'  => customLang('settings_payout_stripe_title', 'Stripe Connect'),
    'payoneer'=> customLang('settings_payout_payoneer_title', 'Payoneer'),
    'other'   => customLang('settings_payout_other_title', 'Other method'),
];

$statusClasses = [
    'pending'   => 'status-badge--pending',
    'processing'=> 'status-badge--pending',
    'review'    => 'status-badge--pending',
    'approved'  => 'status-badge--success',
    'completed' => 'status-badge--success',
    'paid'      => 'status-badge--success',
    'rejected'  => 'status-badge--danger',
    'failed'    => 'status-badge--danger',
    'canceled'  => 'status-badge--danger',
    'cancelled' => 'status-badge--danger',
];

$methodIcons = [
    'bank'    => 'bank.svg',
    'paypal'  => 'payments.svg',
    'stripe'  => 'payments.svg',
    'payoneer'=> 'payments.svg',
    'other'   => 'payments.svg',
];

$maskSensitive = static function (?string $value, bool $mask = true): string {
    if ($value === null || $value === '') {
        return '—';
    }
    if (!$mask) {
        return (string) $value;
    }
    $trim = preg_replace('/\s+/', '', (string) $value);
    if (strlen($trim) <= 8) {
        return (string) $value;
    }
    $start = substr($trim, 0, 4);
    $end = substr($trim, -4);
    return $start . str_repeat('•', max(0, strlen($trim) - 8)) . $end;
};

$summariseDetails = static function (array $details, string $method, bool $maskValues = true) use ($maskSensitive): array {
    $pairs = [];
    $method = strtolower($method);
    $map = [
        'account_name'   => customLang('creator_bank_account_name', 'Account holder name'),
        'bank_name'      => customLang('creator_bank_name', 'Bank name'),
        'iban'           => customLang('creator_bank_iban', 'IBAN'),
        'account_number' => customLang('creator_bank_account_number', 'Account number'),
        'swift'          => customLang('creator_bank_swift', 'SWIFT/BIC'),
        'email'          => customLang('email', 'Email'),
        'notes'          => customLang('creator_bank_notes', 'Notes'),
        'account_id'     => customLang('creator_stripe_account_id', 'Account ID'),
    ];
    foreach ($details as $key => $val) {
        if (!is_scalar($val) || $val === '') {
            continue;
        }
        $label = $map[$key] ?? ucfirst(str_replace('_', ' ', $key));
        $value = (string) $val;
        if (in_array($key, ['iban', 'account_number', 'swift'], true)) {
            $value = $maskValues ? $maskSensitive($value, true) : $value;
        }
        $pairs[] = [$label, $value];
    }
    return $pairs;
};

$heading = customLang('admin_withdrawals_heading', 'Withdrawal Requests');
$activeStatus = $statusOptions[$statusParam] ?? $statusOptions['all'];
$subheading = customLang('admin_withdrawals_subheading', 'Review and process withdrawal submissions from creators.');
$emptyMessage = customLang('admin_withdrawals_empty', 'No withdrawal requests found for this filter.');
$searchPlaceholder = customLang('admin_withdrawals_search_placeholder', 'Search by username or reference');
$actionsProfileLabel = customLang('admin_withdrawals_action_view_profile', 'View public profile');
$actionsAdminLabel = customLang('admin_withdrawals_action_open_details', 'Open in admin');
$actionsEmailLabel = customLang('admin_withdrawals_action_email', 'Email user');
$reviewActionLabel = customLang('admin_withdrawals_action_review', 'Review details');
$cancelLabel = customLang('admin_users_action_cancel') ?: 'Cancel';
$toastUpdatedLabel = customLang('admin_withdrawals_toast_updated', 'Withdrawal updated.');
$fetchErrorLabel = customLang('admin_withdrawals_error_fetch', 'Unable to load withdrawal details.');
$updateErrorLabel = customLang('admin_withdrawals_error_update', 'Unable to update withdrawal.');

// Modal labels
$modalTitle = customLang('admin_withdrawals_modal_title', 'Withdrawal details');
$modalUserLabel = customLang('admin_withdrawals_modal_user_label', 'User');
$modalAmountLabel = customLang('admin_withdrawals_modal_amount_label', 'Amount');
$modalMethodLabel = customLang('admin_withdrawals_modal_method_label', 'Method');
$modalStatusLabel = customLang('admin_withdrawals_modal_status_label', 'Status');
$modalRequestedLabel = customLang('admin_withdrawals_modal_requested_label', 'Requested at');
$modalProcessedLabel = customLang('admin_withdrawals_modal_processed_label', 'Processed at');
$modalReferenceLabel = customLang('admin_withdrawals_modal_reference_label', 'Reference');
$modalRequestIdLabel = customLang('admin_withdrawals_modal_request_label', 'Request ID');
$modalDestinationLabel = customLang('admin_withdrawals_modal_destination_label', 'Destination details');
$modalUserNoteLabel = customLang('admin_withdrawals_modal_user_note_label', 'Creator note');
$modalAdminNoteLabel = customLang('admin_withdrawals_modal_admin_note_label', 'Admin note');
$modalNoDestination = customLang('admin_withdrawals_modal_no_destination', 'No payout destination data available.');
$modalCloseLabel = customLang('admin_withdrawals_modal_close', 'Close');
$modalSaveLabel = customLang('admin_withdrawals_modal_save', 'Save changes');
$modalMarkPaidLabel = customLang('admin_withdrawals_modal_mark_paid', 'Mark as paid');
$canWithdrawalUpdate = admin_has_permission('withdrawals.update');
$permissionTip = customLang('admin_permission_denied_tooltip') ?: 'You do not have permission to perform this action.';

?>

<section
  class="card rounded-2xl"
  role="region"
  aria-labelledby="adminWithdrawalsHeading"
  data-withdrawals-root
  data-toast-updated="<?= iN_HelpSecure($toastUpdatedLabel, false); ?>"
  data-error-fetch="<?= iN_HelpSecure($fetchErrorLabel, false); ?>"
  data-error-update="<?= iN_HelpSecure($updateErrorLabel, false); ?>"
>
  <div class="list-header" id="adminWithdrawalsHeading">
    <span class="icon"><?= renderVerifiedBadge($iconPath . 'payments.svg', true); ?></span>
    <span><strong><?= iN_HelpSecure($heading . ' > ' . $activeStatus, false); ?></strong></span>
  </div>
  <p class="text-muted mt-2"><?= iN_HelpSecure($subheading, false); ?></p>

  <form method="get" class="form-container form-container--columns" action="<?= iN_HelpSecure($base_url . 'admin/index.php', false); ?>">
    <input type="hidden" name="page" value="<?= iN_HelpSecure($pageSlug, false); ?>">
    <div class="form-input-wrapper">
      <label class="form-label" for="statusFilter"><?= iN_HelpSecure(customLang('admin_withdrawals_filter_status', 'Status'), false); ?></label>
      <select id="statusFilter" name="status" class="form-input">
        <?php foreach ($statusOptions as $key => $label): ?>
          <option value="<?= iN_HelpSecure($key, false); ?>"<?= $statusParam === $key ? ' selected' : ''; ?>><?= iN_HelpSecure($label, false); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="methodFilter"><?= iN_HelpSecure(customLang('admin_withdrawals_filter_method', 'Method'), false); ?></label>
      <select id="methodFilter" name="method" class="form-input">
        <?php foreach ($methodOptions as $key => $label): ?>
          <option value="<?= iN_HelpSecure($key, false); ?>"<?= $methodParam === $key ? ' selected' : ''; ?>><?= iN_HelpSecure($label, false); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="perFilter"><?= iN_HelpSecure(customLang('admin_withdrawals_filter_per_page', 'Per page'), false); ?></label>
      <select id="perFilter" name="per" class="form-input">
        <?php foreach ([10, 20, 50, 100] as $pp): ?>
          <option value="<?= $pp; ?>"<?= $pp === $perPage ? ' selected' : ''; ?>><?= $pp; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="withdrawalsSearch"><?= iN_HelpSecure(customLang('admin_withdrawals_filter_search', 'Search'), false); ?></label>
      <input
        id="withdrawalsSearch"
        type="search"
        name="q"
        value="<?= iN_HelpSecure($searchParam, false); ?>"
        placeholder="<?= iN_HelpSecure($searchPlaceholder, false); ?>"
        class="form-input"
      >
    </div>
    <div class="form-input-wrapper form-actions">
      <label class="form-label sr-only" for="withdrawalsApply"><?= iN_HelpSecure(customLang('admin_withdrawals_filter_apply', 'Apply'), false); ?></label>
      <button id="withdrawalsApply" type="submit" class="pe-save btn-hover"><?= iN_HelpSecure(customLang('admin_withdrawals_filter_apply', 'Apply'), false); ?></button>
    </div>
  </form>

  <div class="table-responsive mt-4">
    <table class="table table-striped table-sm table-subs full-width" data-withdrawal-table>
      <thead>
        <tr>
          <th><?= iN_HelpSecure(customLang('admin_withdrawals_col_id', 'ID')); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_withdrawals_col_user', 'User')); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_withdrawals_col_amount', 'Amount')); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_withdrawals_col_method', 'Method')); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_withdrawals_col_status', 'Status')); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_withdrawals_col_requested', 'Requested')); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_withdrawals_col_processed', 'Processed')); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_withdrawals_col_reference', 'Reference')); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_withdrawals_col_actions', 'Actions')); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$rows): ?>
          <tr>
            <td colspan="9" class="text-center text-muted empty_class_table"><?= iN_HelpSecure($emptyMessage, false); ?></td>
          </tr>
        <?php else: ?>
          <?php foreach ($rows as $row): ?>
            <?php
              $payoutId = (int) ($row['payout_id'] ?? 0);
              $userId = (int) ($row['user_id'] ?? 0);
              $username = (string) ($row['username'] ?? '');
              $fullName = (string) ($row['user_fullname'] ?? $username);
              $email = (string) ($row['user_email'] ?? '');
              $amount = (float) ($row['amount'] ?? 0);
              $currency = (string) ($row['currency'] ?? 'USD');
              $method = strtolower((string) ($row['method'] ?? ''));
              $status = strtolower((string) ($row['status'] ?? 'pending'));
              $reference = (string) ($row['reference'] ?? '');
              $requestedAt = isset($row['requested_at']) ? (int) $row['requested_at'] : 0;
              $processedAt = isset($row['processed_at']) && $row['processed_at'] !== null ? (int) $row['processed_at'] : null;
              $requestedTxt = $requestedAt > 0 ? date('Y-m-d H:i', $requestedAt) : '—';
              $processedTxt = ($processedAt !== null && $processedAt > 0) ? date('Y-m-d H:i', $processedAt) : '—';
              $statusLabel = customLang('withdrawal_status_' . $status, ucfirst($status));
              $statusClass = $statusClasses[$status] ?? 'status-badge--neutral';
              $methodLabel = $methodOptions[$method] ?? ucfirst($method ?: '-');
              $methodIcon = $methodIcons[$method] ?? 'payments.svg';
              $adminUserUrl = ($base_url ?? '/') . 'admin/index.php?page=user_detail&id=' . $userId;
              $profileUrl = ($base_url ?? '/') . 'profile/' . rawurlencode($username);
              $avatarRel = (isset($RL) && is_object($RL) && method_exists($RL, 'RL_userAvatar'))
                ? $RL->RL_userAvatar($userId)
                : 'uploads/user_avatars/default.jpeg';
              $avatarUrl = admin_resolve_media_url($avatarRel);
              $amountLabel = $formatMoney($amount, $currency);
              $destination = isset($row['destination']) && is_array($row['destination']) ? $row['destination'] : [];
              $referenceRaw = (string) ($row['reference'] ?? '');
              $referenceDisplay = (string) ($row['reference_display'] ?? ($referenceRaw !== '' ? $referenceRaw : 'REQ-' . str_pad((string) $payoutId, 6, '0', STR_PAD_LEFT)));
              $destinationPairsFull = $summariseDetails($destination, $method, false);
              $userNote = isset($row['notes']) ? (string) $row['notes'] : '';
              $adminNote = isset($row['admin_note']) ? (string) $row['admin_note'] : '';
              $payload = [
                  'payout_id'          => $payoutId,
                  'user_id'            => $userId,
                  'username'           => $username,
                  'full_name'          => $fullName,
                  'email'              => $email,
                  'amount'             => $amount,
                  'amount_label'       => $amountLabel,
                  'currency'           => $currency,
                  'method'             => $method,
                  'method_label'       => $methodLabel,
                  'method_icon'        => $methodIcon,
                  'status'             => $status,
                  'status_label'       => $statusLabel,
                  'status_class'       => $statusClass,
                  'reference'          => $referenceRaw,
                  'reference_display'  => $referenceDisplay,
                  'requested_at'       => $requestedAt,
                  'requested_label'    => $requestedTxt,
                  'processed_at'       => $processedAt,
                  'processed_label'    => $processedTxt,
                  'profile_url'        => $profileUrl,
                  'admin_url'          => $adminUserUrl,
                  'destination_pairs'  => $destinationPairsFull,
                  'user_note'          => $userNote,
                  'admin_note'         => $adminNote,
              ];
              $payloadAttr = htmlspecialchars(json_encode($payload, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
            ?>
            <tr
              data-row-href="<?= iN_HelpSecure($adminUserUrl, false); ?>"
              data-payout-id="<?= $payoutId; ?>"
              data-withdrawal="<?= $payloadAttr; ?>"
            >
              <td data-col="id"><?= $payoutId; ?></td>
              <td data-col="user">
                <a class="user-pill" href="<?= iN_HelpSecure($profileUrl, false); ?>">
                  <img class="avatar-32" src="<?= iN_HelpSecure($avatarUrl, false); ?>" alt="<?= iN_HelpSecure('Avatar of ' . $username, false); ?>">
                  <span class="name"><?= iN_HelpSecure($fullName ?: $username, false); ?></span>
                </a>
              </td>
              <td data-col="amount"><span class="amount-mono"><?= iN_HelpSecure($amountLabel, false); ?></span></td>
              <td data-col="method">
                <span class="type-tag type--<?= iN_HelpSecure($method ?: 'unknown', false); ?>">
                  <span class="tag-icon"><?= renderVerifiedBadge($iconPath . $methodIcon, true); ?></span>
                  <span class="type-label"><?= iN_HelpSecure($methodLabel, false); ?></span>
                </span>
              </td>
              <td data-col="status">
                <span class="status-badge <?= iN_HelpSecure($statusClass, false); ?>" data-status-badge><?= iN_HelpSecure($statusLabel, false); ?></span>
              </td>
              <td data-col="requested">
                <span class="text-muted fs-13 meta-time">
                  <?= renderVerifiedBadge($iconPath . 'time.svg', true); ?>
                  <span data-requested-label><?= iN_HelpSecure($requestedTxt, false); ?></span>
                </span>
              </td>
              <td data-col="processed">
                <span class="text-muted fs-13 meta-time">
                  <?= renderVerifiedBadge($iconPath . 'time.svg', true); ?>
                  <span data-processed-label><?= iN_HelpSecure($processedTxt, false); ?></span>
                </span>
              </td>
              <td data-col="reference"><span class="amount-mono ref-code" data-reference><?= iN_HelpSecure($referenceDisplay, false); ?></span></td>
              <td data-col="actions">
                <div class="post-settings-btn-box flex align_items relative">
                  <button
                    type="button"
                    class="post-settings-btn flex align_items_justify_content relative"
                    aria-expanded="false"
                    aria-haspopup="menu"
                    title="Actions"
                    data-id="<?= $payoutId; ?>"
                  >
                    <?= renderVerifiedBadge($iconPath . 'dots.svg', false); ?>
                  </button>
                </div>
                <div id="withdrawalMenu-<?= $payoutId; ?>" class="post-menu-popup none" aria-hidden="true" role="dialog" aria-label="<?= iN_HelpSecure('Withdrawal actions for #' . $payoutId, false); ?>">
                  <div class="pm-sheet-container">
                    <div class="pm-sheet">
                      <button type="button" class="pm-item flex align_items_justify_content gap js-withdrawal-review" data-payout-id="<?= $payoutId; ?>"><?= renderVerifiedBadge($iconPath . 'view.svg', true); ?> <span><?= iN_HelpSecure($reviewActionLabel, false); ?></span></button>
                      <a class="pm-item" href="<?= iN_HelpSecure($profileUrl, false); ?>"><?= renderVerifiedBadge($iconPath . 'profile.svg', true); ?> <span><?= iN_HelpSecure($actionsProfileLabel, false); ?></span></a>
                      <a class="pm-item" href="<?= iN_HelpSecure($adminUserUrl, false); ?>"><?= renderVerifiedBadge($iconPath . 'settings.svg', true); ?> <span><?= iN_HelpSecure($actionsAdminLabel, false); ?></span></a>
                      <?php if ($email !== ''): ?>
                        <a class="pm-item" href="mailto:<?= iN_HelpSecure($email, false); ?>"><?= renderVerifiedBadge($iconPath . 'email.svg', true); ?> <span><?= iN_HelpSecure($actionsEmailLabel, false); ?></span></a>
                      <?php endif; ?>
                      <div class="pm-divider"></div>
                      <button type="button" class="pm-item pm-cancel"><?= iN_HelpSecure($cancelLabel, false); ?></button>
                    </div>
                  </div>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php
    echo dz_render_pagination(
        $base_url . 'admin/index.php',
        [
            'page'   => $pageSlug,
            'status' => $statusParam,
            'method' => $methodParam,
            'per'    => (string) $perPage,
            'q'      => $searchParam,
        ],
        (int) $pageNo,
        (int) $totalPages,
        [ 'show_goto' => true, 'radius' => 1 ]
    );
  ?>
</section>

<dialog class="admin-withdrawal-dialog" data-withdrawal-dialog aria-labelledby="withdrawalDialogTitle">
  <form method="dialog" class="admin-withdrawal-dialog__form" data-withdrawal-form>
    <header class="admin-withdrawal-dialog__header">
      <div>
        <h2 id="withdrawalDialogTitle"><?= iN_HelpSecure($modalTitle, false); ?></h2>
        <p class="admin-withdrawal-dialog__subtitle" data-field="subtitle"></p>
      </div>
      <button type="button" class="btn-icon" data-withdrawal-close aria-label="<?= iN_HelpSecure($modalCloseLabel, false); ?>">
        <?= renderVerifiedBadge($iconPath . 'close.svg', true); ?>
      </button>
    </header>
    <div class="admin-withdrawal-dialog__body">
      <div class="admin-withdrawal-dialog__grid">
        <div>
          <dt><?= iN_HelpSecure($modalUserLabel, false); ?></dt>
          <dd>
            <div class="admin-withdrawal-user">
              <span data-field="user-name"></span>
              <span class="text-muted">@<span data-field="user-handle"></span></span>
            </div>
            <div class="admin-withdrawal-links">
              <a href="" target="_blank" rel="noopener" data-field="admin-link" aria-disabled="true" tabindex="-1" style="pointer-events:none;">
                <?= iN_HelpSecure($actionsAdminLabel, false); ?>
              </a>
              <span aria-hidden="true">·</span>
              <a href="" target="_blank" rel="noopener" data-field="profile-link" aria-disabled="true" tabindex="-1" style="pointer-events:none;">
                <?= iN_HelpSecure($actionsProfileLabel, false); ?>
              </a>
            </div>
            <div class="admin-withdrawal-email" data-field="user-email"></div>
          </dd>
        </div>
        <div>
          <dt><?= iN_HelpSecure($modalAmountLabel, false); ?></dt>
          <dd data-field="amount"></dd>
        </div>
        <div>
          <dt><?= iN_HelpSecure($modalMethodLabel, false); ?></dt>
          <dd data-field="method"></dd>
        </div>
        <div>
          <dt><?= iN_HelpSecure($modalStatusLabel, false); ?></dt>
          <dd><span class="status-badge" data-field="status-badge"></span></dd>
        </div>
        <div>
          <dt><?= iN_HelpSecure($modalRequestedLabel, false); ?></dt>
          <dd data-field="requested"></dd>
        </div>
        <div>
          <dt><?= iN_HelpSecure($modalProcessedLabel, false); ?></dt>
          <dd data-field="processed"></dd>
        </div>
        <div>
          <dt><?= iN_HelpSecure($modalReferenceLabel, false); ?></dt>
          <dd data-field="reference"></dd>
        </div>
        <div>
          <dt><?= iN_HelpSecure($modalRequestIdLabel, false); ?></dt>
          <dd data-field="request-id"></dd>
        </div>
      </div>

      <div class="admin-withdrawal-form-group">
        <label for="withdrawalStatusSelect"><?= iN_HelpSecure($modalStatusLabel, false); ?></label>
        <select id="withdrawalStatusSelect" name="status" data-field="status-select" class="form-input"<?= $canWithdrawalUpdate ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>>
          <?php foreach ($statusSelectOptions as $key => $label): ?>
            <option value="<?= iN_HelpSecure($key, false); ?>"><?= iN_HelpSecure($label, false); ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="admin-withdrawal-form-group">
        <label for="withdrawalAdminNote"><?= iN_HelpSecure($modalAdminNoteLabel, false); ?></label>
        <textarea id="withdrawalAdminNote" name="admin_note" rows="3" maxlength="1000" data-field="admin-note" class="form-input"<?= $canWithdrawalUpdate ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>></textarea>
      </div>

      <div class="admin-withdrawal-form-group">
        <label><?= iN_HelpSecure($modalUserNoteLabel, false); ?></label>
        <div class="admin-withdrawal-note" data-field="user-note"></div>
      </div>

      <div class="admin-withdrawal-form-group">
        <label><?= iN_HelpSecure($modalDestinationLabel, false); ?></label>
        <ul class="admin-withdrawal-destination" data-destination-list></ul>
        <p class="text-muted" data-destination-empty><?= iN_HelpSecure($modalNoDestination, false); ?></p>
      </div>
    </div>
    <footer class="admin-withdrawal-dialog__footer">
      <div class="admin-withdrawal-dialog__footer-meta" data-footer-meta></div>
      <button type="button" class="admin-button admin-button--danger<?= $canWithdrawalUpdate ? '' : ' is-disabled'; ?>" data-action="mark-paid"<?= $canWithdrawalUpdate ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?= iN_HelpSecure($modalMarkPaidLabel, false); ?></button>
      <div class="admin-withdrawal-dialog__footer-actions">
        <button type="button" class="admin-button admin-button--neutral" data-withdrawal-close><?= iN_HelpSecure($modalCloseLabel, false); ?></button>
        <button type="submit" class="admin-button admin-button--primary<?= $canWithdrawalUpdate ? '' : ' is-disabled'; ?>" data-action="save"<?= $canWithdrawalUpdate ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?= iN_HelpSecure($modalSaveLabel, false); ?></button>
      </div>
    </footer>
  </form>
</dialog>
