<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';

global $ADM, $base_url, $ADMIN_CSRF;

$statusParam = isset($_GET['status']) ? strtolower((string) $_GET['status']) : 'open';
$allowedStatuses = ['open', 'approved', 'rejected', 'all', 'pending', 'review'];
if (!in_array($statusParam, $allowedStatuses, true)) {
    $statusParam = 'open';
}

$methodParam = isset($_GET['method']) ? strtolower((string) $_GET['method']) : 'all';
$allowedMethods = ['all', 'bank', 'stripe', 'payoneer', 'paypal', 'other'];
if (!in_array($methodParam, $allowedMethods, true)) {
    $methodParam = 'all';
}

$filters = [
    'status'       => $statusParam === 'all' ? 'all' : $statusParam,
    'include_logs' => true,
    'logs_limit'   => 4,
];
if ($methodParam !== 'all') {
    $filters['method'] = $methodParam;
}

$data = is_object($ADM) && method_exists($ADM, 'ADM_ListPayoutVerifications')
    ? $ADM->ADM_ListPayoutVerifications($filters)
    : ['items' => [], 'total_items' => 0];

$items = isset($data['items']) && is_array($data['items']) ? $data['items'] : [];
$totalItems = isset($data['total_items']) ? (int) $data['total_items'] : count($items);

$actionUrl = rtrim($base_url ?? '', '/') . '/admin/request/payouts.php';
$csrfToken = isset($ADMIN_CSRF) ? (string) $ADMIN_CSRF : generateCsrfToken();

$statusLabels = [
    'pending'  => customLang('settings_payout_status_pending', 'Pending'),
    'review'   => customLang('settings_payout_status_review', 'In review'),
    'processing'=> customLang('settings_payout_status_processing', 'Processing'),
    'approved' => customLang('settings_payout_status_approved', 'Approved'),
    'rejected' => customLang('settings_payout_status_rejected', 'Rejected'),
    'failed'   => customLang('settings_payout_status_failed', 'Failed'),
    'none'     => customLang('settings_payout_status_none', 'Not submitted'),
];

$statusClasses = [
    'pending'   => 'status-badge--pending',
    'review'    => 'status-badge--pending',
    'processing'=> 'status-badge--pending',
    'approved'  => 'status-badge--success',
    'rejected'  => 'status-badge--danger',
    'failed'    => 'status-badge--danger',
    'none'      => 'status-badge--neutral',
];

$tabs = [
    'open'     => customLang('admin_payout_tab_open', 'Awaiting review'),
    'approved' => customLang('admin_payout_tab_approved', 'Approved'),
    'rejected' => customLang('admin_payout_tab_rejected', 'Rejected'),
    'all'      => customLang('admin_payout_tab_all', 'All'),
];

$methodLabels = [
    'all'     => customLang('admin_payout_filter_method_all', 'All methods'),
    'bank'    => customLang('settings_payout_bank_title', 'Bank transfer'),
    'stripe'  => customLang('settings_payout_stripe_title', 'Stripe Connect'),
    'payoneer'=> customLang('settings_payout_payoneer_title', 'Payoneer'),
    'paypal'  => 'PayPal',
    'other'   => customLang('settings_payout_other_title', 'Other method'),
];

$buildStatusUrl = static function (string $status) use ($methodParam): string {
    $params = ['page' => 'payout_verifications', 'status' => $status];
    if ($methodParam !== 'all') {
        $params['method'] = $methodParam;
    }
    return 'index.php?' . http_build_query($params);
};

$buildMethodUrl = static function (string $method, string $statusParam): string {
    $params = ['page' => 'payout_verifications'];
    if ($statusParam !== 'open') {
        $params['status'] = $statusParam;
    }
    if ($method !== 'all') {
        $params['method'] = $method;
    }
    return 'index.php?' . http_build_query($params);
};

$detailBase = rtrim($base_url ?? '', '/') . '/admin/index.php?page=user_detail&id=';
$heading = customLang('admin_payout_heading', 'Payout verification queue');
$intro = customLang('admin_payout_intro', 'Review connected payout destinations, approve or reject updates, and leave guidance for creators.');
$emptyMessage = customLang('admin_payout_empty', 'No payout submissions match this filter.');
$notePlaceholder = customLang('admin_payout_note_placeholder', 'Optional admin note (visible to user)');
$notifyInappLabel = customLang('admin_payout_notify_inapp', 'Send in-app notification');
$notifyEmailLabel = customLang('admin_payout_notify_email', 'Send email notification');
$defaultBadge = customLang('admin_payout_default_badge', 'Default');
$requiresUpdateLabel = customLang('admin_payout_requires_update_badge', 'Update requested');
$historyHeading = customLang('admin_payout_history_heading', 'Recent decisions');
$historyEmpty = customLang('admin_payout_history_empty', 'No previous decisions yet.');
$actionApproveLabel = customLang('admin_payout_action_approve', 'Approve');
$actionRejectLabel = customLang('admin_payout_action_reject', 'Reject');
$actionRequestLabel = customLang('admin_payout_action_request_update', 'Request update');
$summaryAwaiting = customLang('admin_payout_summary_count', '{count} payout method(s) in this view.', ['count' => number_format($totalItems)]);
$canPayoutUpdate = admin_has_permission('payouts.update');
$permissionTip = customLang('admin_permission_denied_tooltip') ?: 'You do not have permission to perform this action.';

$formatDate = static function ($value): string {
    if (is_numeric($value)) {
        $intVal = (int) $value;
        if ($intVal > 0) {
            return date('d.m.Y H:i', $intVal);
        }
    }
    return '—';
};

$maskSensitive = static function (?string $value): string {
    if ($value === null || $value === '') {
        return '—';
    }
    $trim = preg_replace('/\s+/', '', $value);
    if (strlen($trim) <= 8) {
        return $value;
    }
    $start = substr($trim, 0, 4);
    $end = substr($trim, -4);
    return $start . str_repeat('•', max(0, strlen($trim) - 8)) . $end;
};

$summariseDetails = static function (array $details, string $method) use ($maskSensitive): array {
    $normalised = [];

    $labelMap = [
        'account_name'     => customLang('creator_bank_account_name', 'Account holder name'),
        'bank_name'        => customLang('creator_bank_name', 'Bank name'),
        'iban'             => customLang('creator_bank_iban', 'IBAN'),
        'account_number'   => customLang('creator_bank_account_number', 'Account number'),
        'account'          => customLang('creator_bank_account_number', 'Account number'),
        'routing_number'   => customLang('creator_bank_routing', 'Routing number'),
        'sort_code'        => customLang('creator_bank_sort_code', 'Sort code'),
        'swift'            => customLang('creator_bank_swift', 'SWIFT/BIC'),
        'email'            => customLang('email', 'Email'),
        'notes'            => customLang('creator_bank_notes', 'Notes'),
        'account_id'       => customLang('creator_stripe_account_id', 'Account ID'),
        'beneficiary_name' => customLang('creator_bank_account_name', 'Account holder name'),
    ];
    $sensitiveKeys = [
        'iban',
        'account_number',
        'routing_number',
        'sort_code',
        'swift',
        'account',
        'account_id',
    ];

    $seenKeys = [];
    $push = static function (string $key, $rawValue, ?string $label) use (
        &$normalised,
        &$seenKeys,
        $labelMap,
        $maskSensitive,
        $sensitiveKeys
    ): void {
        if ($rawValue === null) {
            return;
        }
        if (is_string($rawValue)) {
            $rawValue = trim($rawValue);
        }
        if (!is_scalar($rawValue) || $rawValue === '') {
            return;
        }

        $normalisedKey = strtolower(trim($key));
        if ($normalisedKey === '') {
            return;
        }

        $labelText = $label !== null && $label !== ''
            ? $label
            : ($labelMap[$normalisedKey] ?? ucfirst(str_replace('_', ' ', $normalisedKey)));

        $rawString = (string) $rawValue;
        $displayValue = in_array($normalisedKey, $sensitiveKeys, true)
            ? $maskSensitive($rawString)
            : $rawString;

        $payload = [
            'key'   => $normalisedKey,
            'label' => $labelText,
            'value' => $displayValue,
            'raw'   => $rawString,
        ];

        if (array_key_exists($normalisedKey, $seenKeys)) {
            $normalised[$seenKeys[$normalisedKey]] = $payload;
        } else {
            $seenKeys[$normalisedKey] = count($normalised);
            $normalised[] = $payload;
        }
    };

    $walk = static function ($value, ?string $key) use (&$walk, $push): void {
        if (is_array($value)) {
            $isFieldLike = isset($value['value']) || isset($value['label']) || isset($value['key']);
            if ($isFieldLike) {
                $fieldKey = isset($value['key']) && $value['key'] !== '' ? (string) $value['key'] : (string) ($key ?? '');
                $fieldLabel = isset($value['label']) ? (string) $value['label'] : null;
                $fieldValue = $value['value'] ?? ($value['display'] ?? null);
                if (is_scalar($fieldValue) || $fieldValue === null) {
                    $push($fieldKey, $fieldValue, $fieldLabel);
                } else {
                    $walk($fieldValue, $fieldKey);
                }
                return;
            }
            foreach ($value as $childKey => $childValue) {
                $nextKey = is_string($childKey) && $childKey !== '' ? $childKey : (is_string($key) ? $key : '');
                $walk($childValue, $nextKey);
            }
            return;
        }

        if (is_scalar($value) && $value !== '') {
            $fieldKey = is_string($key) && $key !== '' ? $key : 'field';
            $push($fieldKey, $value, null);
        }
    };

    $walk($details, null);

    return array_values($normalised);
};

?>

<section class="card rounded-2xl" data-module="payout-verifications" data-action-url="<?= iN_HelpSecure($actionUrl, false); ?>" data-status-filter="<?= iN_HelpSecure($statusParam, false); ?>" data-method-filter="<?= iN_HelpSecure($methodParam, false); ?>" data-empty-message="<?= iN_HelpSecure($emptyMessage, false); ?>">
  <div class="list-header">
    <div class="list-header__meta">
      <h1 class="list-header__title"><?= iN_HelpSecure($heading, false); ?></h1>
      <p class="list-header__subtitle"><?= iN_HelpSecure($intro, false); ?></p>
      <p class="list-header__summary" data-total-count="<?= iN_HelpSecure((string) $totalItems, false); ?>"><?= iN_HelpSecure($summaryAwaiting, false); ?></p>
    </div>
    <nav class="list-header__tabs" aria-label="<?= iN_HelpSecure(customLang('admin_payout_status_filter', 'Filter by status'), false); ?>">
      <?php foreach ($tabs as $key => $label): ?>
        <?php
          $href = $buildStatusUrl($key);
          $isActive = $statusParam === $key || ($key === 'open' && !array_key_exists($statusParam, $tabs));
        ?>
        <a
          href="<?= iN_HelpSecure($href, false); ?>"
          class="list-header__tab<?= $isActive ? ' is-active' : ''; ?>"
          <?php if ($isActive): ?>aria-current="page"<?php endif; ?>
        ><?= iN_HelpSecure($label, false); ?></a>
      <?php endforeach; ?>
    </nav>
    <div class="list-header__filters">
      <label class="list-header__filter">
        <span class="sr-only"><?= iN_HelpSecure(customLang('admin_payout_filter_method_label', 'Filter by method'), false); ?></span>
        <select onchange="if(this.value){window.location.href=this.value;}" aria-label="<?= iN_HelpSecure(customLang('admin_payout_filter_method_label', 'Filter by method'), false); ?>">
          <?php foreach ($methodLabels as $key => $label): ?>
            <?php $href = $buildMethodUrl($key, $statusParam); ?>
            <option value="<?= iN_HelpSecure($href, false); ?>"<?= $methodParam === $key ? ' selected' : ''; ?>><?= iN_HelpSecure($label, false); ?></option>
          <?php endforeach; ?>
        </select>
      </label>
    </div>
  </div>

  <div class="payout-verification-list">
    <?php if (empty($items)): ?>
      <div class="admin-empty">
        <span class="icon"><?= render_icon('payments', true); ?></span>
        <p><?= iN_HelpSecure($emptyMessage, false); ?></p>
      </div>
    <?php else: ?>
      <?php
        $rlInstance = null;
        $canFetchUserDetails = false;
        if (isset($ADM) && ($ADM instanceof Admin_Data)) {
            $rlInstance = $ADM->rl();
            if ($rlInstance && method_exists($rlInstance, 'RL_GetUserDetails')) {
                $canFetchUserDetails = true;
            }
        }
        $userDetailCache = [];
      ?>
      <div class="table-responsive payout-table__wrapper">
        <table class="table payout-table">
          <thead>
            <tr>
              <th scope="col"><?= iN_HelpSecure(customLang('admin_payout_column_creator', 'Creator'), false); ?></th>
              <th scope="col"><?= iN_HelpSecure(customLang('admin_payout_method_label', 'Method'), false); ?></th>
              <th scope="col"><?= iN_HelpSecure(customLang('admin_payout_column_status', 'Status'), false); ?></th>
              <th scope="col"><?= iN_HelpSecure(customLang('admin_payout_updated_at', 'Last status change'), false); ?></th>
              <th scope="col"><?= iN_HelpSecure(customLang('admin_payout_column_priority', 'Priority'), false); ?></th>
              <th scope="col"><?= iN_HelpSecure(customLang('admin_payout_column_reviewer', 'Reviewed by'), false); ?></th>
              <th scope="col"><?= iN_HelpSecure(customLang('admin_payout_column_details', 'Details'), false); ?></th>
              <th scope="col"><?= iN_HelpSecure(customLang('admin_payout_column_actions', 'Actions'), false); ?></th>
            </tr>
          </thead>
          <?php foreach ($items as $item): ?>
            <?php
              $userId = (int) ($item['user_id'] ?? 0);
              $username = (string) ($item['username'] ?? '');
              $fullName = (string) ($item['user_fullname'] ?? $username);
              $method = (string) ($item['method'] ?? '');
              $status = (string) ($item['status'] ?? 'pending');
              $statusLabel = $statusLabels[$status] ?? ucfirst($status);
              $statusClass = $statusClasses[$status] ?? 'status-badge--pending';
              $methodLabel = (string) ($item['method_label'] ?? ucfirst($method));
              $defaultMethod = (string) ($item['default_method'] ?? 'none');
              $isDefault = $defaultMethod === $method;
              $requiresUpdate = !empty($item['requires_update']);
              $updatedAt = $formatDate($item['status_updated_at'] ?? $item['updated_at'] ?? null);
              $details = isset($item['details']) && is_array($item['details']) ? $item['details'] : [];
              $detailPairs = $summariseDetails($details, $method);
              $history = isset($item['history']) && is_array($item['history']) ? $item['history'] : [];
              $note = isset($item['admin_note']) ? (string) $item['admin_note'] : '';
              $priorityValue = isset($item['priority']) ? (int) $item['priority'] : 1;
              $priorityLabel = $priorityValue <= 1
                  ? customLang('admin_payout_priority_primary', 'Primary')
                  : customLang('admin_payout_priority_level', 'Priority #' . $priorityValue, ['priority' => $priorityValue]);

              $detailPairsForTable = array_values(array_filter($detailPairs, static function (array $pair): bool {
                  if (!isset($pair['key'], $pair['label'], $pair['value'])) {
                      return false;
                  }
                  return !in_array($pair['key'], ['priority', 'reviewed_by'], true);
              }));

              $creatorAvatar = (string) ($item['user_avatar'] ?? '');
              if (!array_key_exists($userId, $userDetailCache)) {
                  $userDetailCache[$userId] = null;
                  if ($userId > 0 && $canFetchUserDetails) {
                      try {
                          $userDetailCache[$userId] = (array) $rlInstance->RL_GetUserDetails($userId);
                      } catch (\Throwable $__) {
                          $userDetailCache[$userId] = null;
                      }
                  }
              }
              $creatorData = $userDetailCache[$userId] ?? null;
              if (is_array($creatorData)) {
                  if ($creatorAvatar === '') {
                      $creatorAvatar = (string) ($creatorData['user_avatar'] ?? '');
                  }
                  if ($fullName === '' || $fullName === $username) {
                      $cachedName = (string) ($creatorData['user_fullname'] ?? '');
                      if ($cachedName !== '') {
                          $fullName = $cachedName;
                      }
                  }
                  if ($username === '') {
                      $cachedUsername = (string) ($creatorData['username'] ?? '');
                      if ($cachedUsername !== '') {
                          $username = $cachedUsername;
                      }
                  }
              }
              $creatorAvatar = admin_resolve_media_url($creatorAvatar, $base_url ?? '');
              if ($creatorAvatar === '' && isset($base_url)) {
                  $creatorAvatar = rtrim((string) $base_url, '/') . '/uploads/user_avatars/default.jpeg';
              }
              $creatorDisplayName = $fullName !== '' ? $fullName : ($username !== '' ? $username : '—');
              $creatorHandle = $username !== '' ? '@' . $username : '—';
              $creatorAlt = $creatorDisplayName !== '—'
                  ? sprintf(customLang('alt_avatar_of_user', 'Avatar of %s'), $creatorDisplayName)
                  : customLang('admin_payout_creator_avatar_fallback', 'Creator avatar');

              $reviewerId = isset($item['reviewed_by']) && is_numeric($item['reviewed_by']) ? (int) $item['reviewed_by'] : 0;
              if ($reviewerId > 0 && !array_key_exists($reviewerId, $userDetailCache)) {
                  $userDetailCache[$reviewerId] = null;
                  if ($canFetchUserDetails) {
                      try {
                          $userDetailCache[$reviewerId] = (array) $rlInstance->RL_GetUserDetails($reviewerId);
                      } catch (\Throwable $__) {
                          $userDetailCache[$reviewerId] = null;
                      }
                  }
              }
              $reviewerData = $userDetailCache[$reviewerId] ?? null;
              $reviewerName = '';
              $reviewerHandle = '';
              $reviewerAvatar = '';
              if (is_array($reviewerData) && !empty($reviewerData)) {
                  $reviewerName = trim((string) ($reviewerData['user_fullname'] ?? ''));
                  if ($reviewerName === '') {
                      $reviewerName = (string) ($reviewerData['username'] ?? ('#' . $reviewerId));
                  }
                  $reviewerHandle = (string) ($reviewerData['username'] ?? '');
                  $reviewerAvatar = (string) ($reviewerData['user_avatar'] ?? '');
              }
              $reviewerAvatar = admin_resolve_media_url($reviewerAvatar, $base_url ?? '');
              if ($reviewerAvatar === '' && $reviewerId > 0 && isset($base_url)) {
                  $reviewerAvatar = rtrim((string) $base_url, '/') . '/uploads/user_avatars/default.jpeg';
              }
              $reviewerAlt = $reviewerName !== ''
                  ? sprintf(customLang('alt_avatar_of_user', 'Avatar of %s'), $reviewerName)
                  : customLang('admin_payout_reviewer_avatar_fallback', 'Reviewer avatar');
            ?>
            <tbody
              class="payout-verification-card payout-table__group"
              data-user-id="<?= iN_HelpSecure((string) $userId, false); ?>"
              data-method="<?= iN_HelpSecure($method, false); ?>"
              data-status="<?= iN_HelpSecure($status, false); ?>"
            >
              <tr class="payout-table__row">
                <td class="payout-table__cell payout-table__cell--creator">
                  <div class="payout-table__creator">
                    <span class="payout-table__creator-avatar">
                      <img src="<?= iN_HelpSecure($creatorAvatar, false); ?>" alt="<?= iN_HelpSecure($creatorAlt, false); ?>">
                    </span>
                    <div class="payout-table__creator-body">
                      <a href="<?= iN_HelpSecure($detailBase . $userId, false); ?>" class="payout-table__creator-name"><?= iN_HelpSecure($creatorDisplayName, false); ?></a>
                      <span class="payout-table__creator-handle"><?= iN_HelpSecure($creatorHandle, false); ?></span>
                    </div>
                  </div>
                </td>
                <td class="payout-table__cell payout-table__cell--method">
                  <div class="payout-table__method">
                    <span class="payout-table__method-label" data-method-label="true"><?= iN_HelpSecure($methodLabel, false); ?></span>
                    <div class="payout-table__method-chips">
                      <span class="payout-card__chip" data-default-chip<?= $isDefault ? '' : ' hidden'; ?>><?= iN_HelpSecure($defaultBadge, false); ?></span>
                      <span class="payout-card__chip payout-card__chip--warning" data-requires-update="true"<?= $requiresUpdate ? '' : ' hidden'; ?>><?= iN_HelpSecure($requiresUpdateLabel, false); ?></span>
                    </div>
                  </div>
                </td>
                <td class="payout-table__cell payout-table__cell--status">
                  <span class="status-badge <?= iN_HelpSecure($statusClass, false); ?>" data-status-label="true"><?= iN_HelpSecure($statusLabel, false); ?></span>
                </td>
                <td class="payout-table__cell payout-table__cell--updated">
                  <span class="payout-table__muted" data-status-updated="true"><?= iN_HelpSecure($updatedAt, false); ?></span>
                </td>
                <td class="payout-table__cell payout-table__cell--priority">
                  <span class="payout-table__priority"><?= iN_HelpSecure($priorityLabel, false); ?></span>
                </td>
                <td class="payout-table__cell payout-table__cell--reviewer">
                  <?php if ($reviewerId > 0 && is_array($reviewerData) && !empty($reviewerData)): ?>
                    <div class="payout-card__reviewer">
                      <span class="payout-card__reviewer-avatar">
                        <img src="<?= iN_HelpSecure($reviewerAvatar, false); ?>" alt="<?= iN_HelpSecure($reviewerAlt, false); ?>">
                      </span>
                      <span class="payout-card__reviewer-body">
                        <span class="payout-card__reviewer-name"><?= iN_HelpSecure($reviewerName, false); ?></span>
                        <?php if ($reviewerHandle !== ''): ?>
                          <span class="payout-card__reviewer-handle">@<?= iN_HelpSecure($reviewerHandle, false); ?></span>
                        <?php endif; ?>
                      </span>
                    </div>
                  <?php elseif ($reviewerId > 0): ?>
                    <?= iN_HelpSecure('User #' . $reviewerId, false); ?>
                  <?php else: ?>
                    <span class="payout-table__empty">—</span>
                  <?php endif; ?>
                </td>
                <td class="payout-table__cell payout-table__cell--details">
                  <?php if (!empty($detailPairsForTable)): ?>
                    <dl class="payout-card__details payout-table__details">
                      <?php foreach ($detailPairsForTable as $detail): ?>
                        <div class="payout-card__detail">
                          <dt><?= iN_HelpSecure($detail['label'], false); ?></dt>
                          <dd><?= iN_HelpSecure($detail['value'], false); ?></dd>
                        </div>
                      <?php endforeach; ?>
                    </dl>
                  <?php else: ?>
                    <span class="payout-table__empty">—</span>
                  <?php endif; ?>
                </td>
                <td class="payout-table__cell payout-table__cell--actions">
                  <form class="payout-card__form payout-table__form" method="post" data-payout-form>
                    <input type="hidden" name="csrf_token" value="<?= iN_HelpSecure($csrfToken, false); ?>">
                    <input type="hidden" name="user_id" value="<?= iN_HelpSecure((string) $userId, false); ?>">
                    <input type="hidden" name="method" value="<?= iN_HelpSecure($method, false); ?>">
                    <label class="payout-card__note payout-table__note">
                      <span class="payout-card__meta-label"><?= iN_HelpSecure(customLang('admin_payout_note_label', 'Admin note'), false); ?></span>
                      <textarea name="note" rows="2" maxlength="1000" placeholder="<?= iN_HelpSecure($notePlaceholder, false); ?>" data-note-field<?= $canPayoutUpdate ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?= iN_HelpSecure($note, false); ?></textarea>
                    </label>
                    <fieldset class="payout-card__notify payout-table__notify">
                      <legend class="payout-card__meta-label payout-card__meta-label--inline"><?= iN_HelpSecure(customLang('admin_payout_notifications', 'Notifications'), false); ?></legend>
                      <label>
                        <input type="checkbox" name="notify_inapp" value="1" checked<?= $canPayoutUpdate ? '' : ' disabled aria-disabled="true"'; ?>>
                        <span><?= iN_HelpSecure($notifyInappLabel, false); ?></span>
                      </label>
                      <label>
                        <input type="checkbox" name="notify_email" value="1"<?= $canPayoutUpdate ? '' : ' disabled aria-disabled="true"'; ?>>
                        <span><?= iN_HelpSecure($notifyEmailLabel, false); ?></span>
                      </label>
                    </fieldset>
                    <div class="payout-card__actions payout-table__actions">
                      <button type="submit" name="action" value="approve" class="btn-secondary<?= $canPayoutUpdate ? '' : ' is-disabled'; ?>" data-action-button="approve"<?= $canPayoutUpdate ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?= iN_HelpSecure($actionApproveLabel, false); ?></button>
                      <button type="submit" name="action" value="reject" class="btn-danger<?= $canPayoutUpdate ? '' : ' is-disabled'; ?>" data-action-button="reject"<?= $canPayoutUpdate ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?= iN_HelpSecure($actionRejectLabel, false); ?></button>
                      <button type="submit" name="action" value="request_update" class="btn-warning<?= $canPayoutUpdate ? '' : ' is-disabled'; ?>" data-action-button="request_update"<?= $canPayoutUpdate ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?= iN_HelpSecure($actionRequestLabel, false); ?></button>
                    </div>
                  </form>
                </td>
              </tr>
              <tr class="payout-table__history-row">
                <td colspan="8">
                  <div class="payout-card__body payout-table__history-body">
                    <div class="payout-table__history-heading">
                      <span><?= iN_HelpSecure($historyHeading, false); ?></span>
                    </div>
                    <?php if (!empty($history)): ?>
                      <div class="payout-card__history">
                        <ul>
                          <?php foreach ($history as $entry): ?>
                            <?php
                              $histStatus = isset($entry['status_after']) ? (string) $entry['status_after'] : 'pending';
                              $histLabel = $statusLabels[$histStatus] ?? ucfirst($histStatus);
                              $histTime = $formatDate($entry['created_at'] ?? null);
                              $histNote = isset($entry['admin_note']) ? (string) $entry['admin_note'] : '';
                            ?>
                            <li class="payout-card__history-item">
                              <div class="payout-card__history-meta">
                                <strong><?= iN_HelpSecure($histLabel, false); ?></strong>
                                <span>· <?= iN_HelpSecure($histTime, false); ?></span>
                              </div>
                              <?php if ($histNote !== ''): ?>
                                <div class="payout-card__history-note">"<?= iN_HelpSecure($histNote, false); ?>"</div>
                              <?php endif; ?>
                            </li>
                          <?php endforeach; ?>
                        </ul>
                      </div>
                    <?php else: ?>
                      <p class="payout-card__history-empty"><?= iN_HelpSecure($historyEmpty, false); ?></p>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            </tbody>
          <?php endforeach; ?>
        </table>
      </div>
    <?php endif; ?>
  </div>
</section>
