<?php
declare(strict_types=1);
require_once __DIR__ . '/../../_bootstrap.php';

global $db, $base_url, $ADMIN_CSRF;

$actionUrl = iN_HelpSecure($base_url . 'admin/request/announcements.php', false);
$csrfToken = iN_HelpSecure($ADMIN_CSRF, false);

$editId = isset($_GET['announcement_id']) ? (int) $_GET['announcement_id'] : 0;
$editing = null;

if ($editId > 0) {
    try {
        $stmt = $db->prepare('SELECT id, message, status, start_at, end_at, allow_close, title, cta_label, cta_url, image_path FROM i_announcements WHERE id = :id LIMIT 1');
        $stmt->bindValue(':id', $editId, PDO::PARAM_INT);
        $stmt->execute();
        $editing = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('Load announcement failed: ' . $e->getMessage());
        }
        $editing = null;
    }
}

$announcements = [];
try {
    $stmt = $db->query('SELECT id, title, message, status, start_at, end_at, allow_close, cta_url, image_path, created_at, updated_at FROM i_announcements ORDER BY created_at DESC LIMIT 50');
    if ($stmt !== false) {
        $announcements = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }
} catch (Throwable $e) {
    if (defined('APP_DEBUG') && APP_DEBUG === true) {
        error_log('List announcements failed: ' . $e->getMessage());
    }
}

$formatInputValue = static function ($value): string {
    if ($value === null) {
        return '';
    }
    $intValue = (int) $value;
    if ($intValue <= 0) {
        return '';
    }
    return gmdate('Y-m-d\TH:i', $intValue);
};

$formatTableDate = static function ($value): string {
    if ($value === null) {
        return '—';
    }
    $intValue = (int) $value;
    if ($intValue <= 0) {
        return '—';
    }
    return gmdate('Y-m-d H:i', $intValue) . ' UTC';
};

$resolve = static function (string $key, string $fallback) {
    $value = customLang($key);
    if (is_string($value) && $value !== '' && $value !== $key) {
        return $value;
    }
    return $fallback;
};

$title = $resolve('admin_announcements_title', 'Announcements');
$intro = $resolve('admin_announcements_intro_extended', $resolve('admin_announcements_intro', 'Create a site-wide announcement with optional scheduling, image, and call-to-action.'));
$formLegend = $resolve($editing ? 'admin_announcements_edit_heading' : 'admin_announcements_create_heading', $editing ? 'Edit announcement' : 'Add announcement');
$submitLabel = $resolve($editing ? 'admin_announcements_update_button' : 'admin_announcements_save_button', $editing ? 'Update announcement' : 'Save announcement');
$statusLabel = $resolve('admin_announcements_status_label', 'Status');
$statusActive = $resolve('admin_announcements_status_active', 'Active');
$statusInactive = $resolve('admin_announcements_status_inactive', 'Inactive');
$titleLabel = $resolve('admin_announcements_title_label', 'Headline');
$titlePlaceholder = $resolve('admin_announcements_title_placeholder', 'Short headline shown above the description');
$messageLabel = $resolve('admin_announcements_message_label', 'Description');
$messagePlaceholder = $resolve('admin_announcements_message_placeholder', 'Write the announcement copy. Rich text and links are supported.');
$messageRichHint = $resolve('admin_announcements_message_hint_rich', 'Formatting tools are available for emphasis, lists, colors, and links. Unsafe code is removed automatically.');
$mediaLabel = $resolve('admin_announcements_media_label', 'Cover image');
$mediaHint = $resolve('admin_announcements_media_hint', 'PNG, JPG or WEBP up to 5 MB. Landscape images look best.');
$mediaRemoveLabel = $resolve('admin_announcements_media_remove', 'Remove current image');
$ctaSectionLabel = $resolve('admin_announcements_cta_section', 'Call-to-action button');
$linkLabel = $resolve('admin_announcements_cta_label', 'Button label');
$linkPlaceholder = $resolve('admin_announcements_cta_placeholder', 'Example: Learn more');
$linkUrlLabel = $resolve('admin_announcements_cta_url', 'Button link (URL)');
$linkUrlPlaceholder = $resolve('admin_announcements_cta_url_placeholder', 'https://example.com/page');
$ctaHint = $resolve('admin_announcements_cta_hint', 'If both label and URL are provided, a primary button will appear in the popup.');
$visibilityLabel = $resolve('admin_announcements_visibility', 'Visibility & Timing');
$allowCloseLabel = $resolve('admin_announcements_allow_close_label', 'Allow visitors to dismiss');
$allowCloseHint = $resolve('admin_announcements_allow_close_hint_footer', 'If disabled, the modal cannot be dismissed by visitors.');
$startLabel = $resolve('admin_announcements_start_label', 'Start time');
$endLabel = $resolve('admin_announcements_end_label', 'End time');
$scheduleHint = $resolve('admin_announcements_schedule_hint', 'Leave blank to make the announcement visible immediately with no end date.');
$listHeading = $resolve('admin_announcements_list_heading', 'Recent announcements');
$noRowsLabel = $resolve('admin_announcements_empty', 'No announcements found yet.');
$actionsLabel = $resolve('admin_announcements_actions_label', 'Actions');
$editLinkLabel = $resolve('admin_announcements_action_edit', 'Edit');
$activateLabel = $resolve('admin_announcements_action_activate', 'Set active');
$deactivateLabel = $resolve('admin_announcements_action_deactivate', 'Set inactive');
$deleteLabel = $resolve('admin_announcements_action_delete', 'Delete');
$deleteConfirm = $resolve('admin_announcements_delete_confirm', 'Delete this announcement?');
$cancelEditLabel = $resolve('admin_announcements_cancel_edit', 'Cancel edit');
$statusColLabel = $resolve('admin_announcements_table_status', 'Status');
$startColLabel = $resolve('admin_announcements_table_start', 'Start');
$endColLabel = $resolve('admin_announcements_table_end', 'End');
$allowCloseColLabel = $resolve('admin_announcements_table_allow_close', 'Closable');
$titleColLabel = $resolve('admin_announcements_table_title', 'Headline');
$linkColLabel = $resolve('admin_announcements_table_link', 'CTA link');
$idColLabel = $resolve('admin_announcements_table_id', 'ID');
$createdColLabel = $resolve('admin_announcements_table_created', 'Created');
$updatedColLabel = $resolve('admin_announcements_table_updated', 'Updated');
$closeYes = $resolve('admin_announcements_close_yes', 'Yes');
$closeNo = $resolve('admin_announcements_close_no', 'No');

$currentStatus = $editing ? (string) ($editing['status'] ?? 'inactive') : 'inactive';
$editingTitle = $editing ? (string)($editing['title'] ?? '') : '';
$editingMessage = $editing ? (string) ($editing['message'] ?? '') : '';
if ($editingMessage !== '') {
    if (function_exists('convertAnnouncementClassesToInline')) {
        $editingMessage = convertAnnouncementClassesToInline($editingMessage);
    }
    $editingMessage = html_entity_decode($editingMessage, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}
$editingStart = $editing ? $formatInputValue($editing['start_at'] ?? null) : '';
$editingEnd = $editing ? $formatInputValue($editing['end_at'] ?? null) : '';
$editingAllowClose = $editing ? (int)($editing['allow_close'] ?? 1) === 1 : true;
$editingCtaLabel = $editing ? (string)($editing['cta_label'] ?? '') : '';
$editingCtaUrl = $editing ? (string)($editing['cta_url'] ?? '') : '';
$editingImagePath = $editing ? (string)($editing['image_path'] ?? '') : '';
$editingImageUrl = '';
if ($editingImagePath !== '') {
    $baseForMedia = isset($base_url) ? rtrim((string) $base_url, '/') : '';
    $editingImageUrl = $baseForMedia !== '' ? $baseForMedia . '/' . ltrim($editingImagePath, '/') : '/' . ltrim($editingImagePath, '/');
    $editingImageUrl = iN_HelpSecure($editingImageUrl, false);
}
?>

<section class="card rounded-2xl" role="region" aria-labelledby="adminAnnouncementHeading">
  <h1 id="adminAnnouncementHeading"><?php echo iN_HelpSecure($title); ?></h1>
  <p class="box-note full-width"><?php echo iN_HelpSecure($intro); ?></p>

  <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" enctype="multipart/form-data" data-action="save-announcement">
    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
    <input type="hidden" name="action" value="<?php echo $editing ? 'update' : 'create'; ?>">
    <?php if ($editing): ?>
      <input type="hidden" name="announcement_id" value="<?php echo (int) $editing['id']; ?>">
    <?php endif; ?>

    <fieldset class="form-input-wrapper">
      <legend><?php echo iN_HelpSecure($formLegend); ?></legend>
      <label class="form-label" for="announcement-title"><?php echo iN_HelpSecure($titleLabel); ?></label>
      <input id="announcement-title" class="form-input" type="text" name="title" maxlength="160" value="<?php echo iN_HelpSecure($editingTitle, false); ?>" placeholder="<?php echo iN_HelpSecure($titlePlaceholder, false); ?>">

      <label class="form-label" for="announcement-message"><?php echo iN_HelpSecure($messageLabel); ?></label>
      <textarea
        id="announcement-message"
        class="form-input js-page-editor"
        name="message"
        rows="8"
        required
        data-editor-images="0"
        data-editor-colors="1"
        data-editor-styles="1"
        placeholder="<?php echo iN_HelpSecure($messagePlaceholder, false); ?>"
      ><?php echo $editingMessage; ?></textarea>
      <small class="form-text text-muted"><?php echo iN_HelpSecure($messageRichHint, false); ?></small>
    </fieldset>

    <fieldset class="form-input-wrapper">
      <legend><?php echo iN_HelpSecure($mediaLabel); ?></legend>
      <?php if ($editingImageUrl !== ''): ?>
        <div class="announcement-media-preview">
          <img src="<?php echo $editingImageUrl; ?>" alt="<?php echo iN_HelpSecure($editingTitle !== '' ? $editingTitle : $resolve('announcement_label', 'Announcement'), false); ?>" loading="lazy">
        </div>
        <label class="form-checkbox announcement-media-remove">
          <input type="checkbox" name="image_remove" value="1">
          <span><?php echo iN_HelpSecure($mediaRemoveLabel); ?></span>
        </label>
      <?php endif; ?>
      <input id="announcement-image" class="form-input" type="file" name="image" accept="image/png,image/jpeg,image/webp">
      <small class="form-text text-muted"><?php echo iN_HelpSecure($mediaHint); ?></small>
    </fieldset>

    <fieldset class="form-input-wrapper">
      <legend><?php echo iN_HelpSecure($ctaSectionLabel); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="announcement-cta-label"><?php echo iN_HelpSecure($linkLabel); ?></label>
          <input id="announcement-cta-label" class="form-input" type="text" name="cta_label" maxlength="120" value="<?php echo iN_HelpSecure($editingCtaLabel, false); ?>" placeholder="<?php echo iN_HelpSecure($linkPlaceholder, false); ?>">
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="announcement-cta-url"><?php echo iN_HelpSecure($linkUrlLabel); ?></label>
          <input id="announcement-cta-url" class="form-input" type="url" name="cta_url" value="<?php echo iN_HelpSecure($editingCtaUrl, false); ?>" placeholder="<?php echo iN_HelpSecure($linkUrlPlaceholder, false); ?>">
        </div>
      </div>
      <small class="form-text text-muted"><?php echo iN_HelpSecure($ctaHint); ?></small>
    </fieldset>

    <fieldset class="form-input-wrapper">
      <legend><?php echo iN_HelpSecure($visibilityLabel); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="announcement-status"><?php echo iN_HelpSecure($statusLabel); ?></label>
          <select id="announcement-status" class="form-input" name="status">
            <option value="active"<?php echo $currentStatus === 'active' ? ' selected' : ''; ?>><?php echo iN_HelpSecure($statusActive); ?></option>
            <option value="inactive"<?php echo $currentStatus !== 'active' ? ' selected' : ''; ?>><?php echo iN_HelpSecure($statusInactive); ?></option>
          </select>
        </div>
        <div class="form-input-wrapper form-input-wrapper--checkbox">
          <label class="form-checkbox">
            <input type="checkbox" name="allow_close" value="1"<?php echo $editingAllowClose ? ' checked' : ''; ?>>
            <span><?php echo iN_HelpSecure($allowCloseLabel); ?></span>
          </label>
          <small class="form-text text-muted"><?php echo iN_HelpSecure($allowCloseHint); ?></small>
        </div>
      </div>

      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="announcement-start"><?php echo iN_HelpSecure($startLabel); ?></label>
          <input id="announcement-start" class="form-input" type="datetime-local" name="start_at" value="<?php echo iN_HelpSecure($editingStart, false); ?>">
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="announcement-end"><?php echo iN_HelpSecure($endLabel); ?></label>
          <input id="announcement-end" class="form-input" type="datetime-local" name="end_at" value="<?php echo iN_HelpSecure($editingEnd, false); ?>">
        </div>
      </div>
      <small class="form-text text-muted"><?php echo iN_HelpSecure($scheduleHint); ?></small>
    </fieldset>

    <div class="form-actions">
      <button type="submit" class="admin-button admin-button--primary"><?php echo iN_HelpSecure($submitLabel); ?></button>
      <?php if ($editing): ?>
        <a class="admin-button admin-button--neutral" href="<?php echo iN_HelpSecure($base_url . 'admin/index.php?page=announcements', false); ?>"><?php echo iN_HelpSecure($cancelEditLabel); ?></a>
      <?php endif; ?>
    </div>
  </form>
</section>

<?php
if (!defined('ADMIN_TINYMCE_LOADED')) {
    define('ADMIN_TINYMCE_LOADED', true);
    $tinymceSrc = rtrim((string) ($base_url ?? ''), '/') . '/admin/js/tinymce/tinymce.min.js';
    if (isset($version) && $version !== '') {
        $tinymceSrc .= '?v=' . rawurlencode((string) $version);
    }
    echo '<script defer src="' . iN_HelpSecure($tinymceSrc, false) . '"></script>';
}
?>

<section class="card rounded-2xl" role="region" aria-labelledby="announcementListHeading">
  <div class="card-header">
    <h2 id="announcementListHeading"><?php echo iN_HelpSecure($listHeading); ?></h2>
  </div>
  <div class="table-responsive">
    <table class="table table-striped table-sm table-announcements">
      <thead>
        <tr>
          <th><?php echo iN_HelpSecure($idColLabel); ?></th>
          <th><?php echo iN_HelpSecure($titleColLabel); ?></th>
          <th><?php echo iN_HelpSecure($statusColLabel); ?></th>
          <th><?php echo iN_HelpSecure($startColLabel); ?></th>
          <th><?php echo iN_HelpSecure($endColLabel); ?></th>
          <th><?php echo iN_HelpSecure($allowCloseColLabel); ?></th>
          <th><?php echo iN_HelpSecure($linkColLabel); ?></th>
          <th><?php echo iN_HelpSecure($createdColLabel); ?></th>
          <th><?php echo iN_HelpSecure($updatedColLabel); ?></th>
          <th><?php echo iN_HelpSecure($actionsLabel); ?></th>
        </tr>
      </thead>
      <tbody>
      <?php if (empty($announcements)): ?>
        <tr>
          <td colspan="10" class="text-center text-muted"><?php echo iN_HelpSecure($noRowsLabel); ?></td>
        </tr>
      <?php else: ?>
        <?php foreach ($announcements as $row):
          $rowId = (int) ($row['id'] ?? 0);
          $rowStatus = (string) ($row['status'] ?? 'inactive');
          $rowTitle = (string) ($row['title'] ?? '');
          $rowStart = $formatTableDate($row['start_at'] ?? null);
          $rowEnd = $formatTableDate($row['end_at'] ?? null);
          $rowCreated = $formatTableDate($row['created_at'] ?? null);
          $rowUpdated = $formatTableDate($row['updated_at'] ?? null);
          $rowAllowClose = (int) ($row['allow_close'] ?? 1) === 1 ? $closeYes : $closeNo;
          $toggleStatus = $rowStatus === 'active' ? 'inactive' : 'active';
          $toggleLabel = $rowStatus === 'active' ? $deactivateLabel : $activateLabel;
          $rowLink = (string)($row['cta_url'] ?? '');
          $hasImage = !empty($row['image_path']);
          $rowFallbackMessage = '';
          if ($rowTitle === '') {
              $decodedMessage = html_entity_decode((string)($row['message'] ?? ''), ENT_QUOTES | ENT_HTML5, 'UTF-8');
              $rowFallbackMessage = trim(strip_tags($decodedMessage));
          }
          $tableTitle = $rowTitle !== '' ? $rowTitle : $rowFallbackMessage;
        ?>
        <tr>
          <td><?php echo $rowId; ?></td>
          <td>
            <strong><?php echo iN_HelpSecure($tableTitle); ?></strong>
            <?php if ($hasImage): ?>
              <span class="announcement-table-badge">IMG</span>
            <?php endif; ?>
          </td>
          <td><?php echo iN_HelpSecure($rowStatus === 'active' ? $statusActive : $statusInactive); ?></td>
          <td><?php echo iN_HelpSecure($rowStart); ?></td>
          <td><?php echo iN_HelpSecure($rowEnd); ?></td>
          <td><?php echo iN_HelpSecure($rowAllowClose); ?></td>
          <td>
            <?php if ($rowLink !== ''): ?>
              <a href="<?php echo iN_HelpSecure($rowLink, false); ?>" target="_blank" rel="noopener">link</a>
            <?php else: ?>
              —
            <?php endif; ?>
          </td>
          <td><?php echo iN_HelpSecure($rowCreated); ?></td>
          <td><?php echo iN_HelpSecure($rowUpdated); ?></td>
          <td class="admin-table-actions">
            <a class="admin-button admin-button--neutral" href="<?php echo iN_HelpSecure($base_url . 'admin/index.php?page=announcements&announcement_id=' . $rowId, false); ?>"><?php echo iN_HelpSecure($editLinkLabel); ?></a>
            <form method="post" action="<?php echo $actionUrl; ?>" data-action="announcement-status">
              <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
              <input type="hidden" name="action" value="status">
              <input type="hidden" name="announcement_id" value="<?php echo $rowId; ?>">
              <input type="hidden" name="status" value="<?php echo $toggleStatus; ?>">
              <button type="submit" class="admin-button admin-button--ghost"><?php echo iN_HelpSecure($toggleLabel); ?></button>
            </form>
            <form method="post" action="<?php echo $actionUrl; ?>" data-action="announcement-delete" data-confirm="<?php echo iN_HelpSecure($deleteConfirm); ?>">
              <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="announcement_id" value="<?php echo $rowId; ?>">
              <button type="submit" class="admin-button admin-button--danger"><?php echo iN_HelpSecure($deleteLabel); ?></button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
