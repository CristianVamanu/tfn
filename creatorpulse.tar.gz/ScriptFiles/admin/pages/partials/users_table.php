<?php
declare(strict_types=1);

/**
 * Shared markup for admin user listings.
 *
 * Expected variables:
 * - array  $adminUsersTableRows          Rows from ADM_PagedUsers.
 * - string $adminUsersTableBaseUrl       Base URL for links.
 * - string $adminUsersTableIconPath      Relative icon path.
 * - array  $adminUsersTableUserData      Current admin user record.
 * - bool   $adminUsersShowFakeBadge      Whether to render the fake badge when is_fake = 1.
 * - array  $adminUsersTablePagination    Pagination metadata (base_url, params, page, pages, options).
 */

$rows        = $adminUsersTableRows ?? [];
$baseUrl     = isset($adminUsersTableBaseUrl) ? (string) $adminUsersTableBaseUrl : '';
$iconPath    = isset($adminUsersTableIconPath) ? (string) $adminUsersTableIconPath : '';
$currentUser = $adminUsersTableUserData ?? [];
$showFake    = isset($adminUsersShowFakeBadge) ? (bool) $adminUsersShowFakeBadge : false;
$pagination  = $adminUsersTablePagination ?? null;
$canUserBan = admin_has_permission('users.ban');
$canUserDelete = admin_has_permission('users.delete');
$canUserSetRole = admin_has_permission('users.set_role');
$permissionTip = customLang('admin_permission_denied_tooltip') ?: 'You do not have permission to perform this action.';
?>
<div class="table-responsive" id="adminUsersTableWrapper">
  <table class="table table-striped table-sm table-subs table-users">
    <thead>
      <tr>
        <th><input type="checkbox" id="chk_all"></th>
        <th><?= iN_HelpSecure(customLang('admin_users_col_id') ?: 'ID', false); ?></th>
        <th><?= iN_HelpSecure(customLang('admin_users_col_user') ?: 'User', false); ?></th>
        <th><?= iN_HelpSecure(customLang('admin_users_col_email') ?: 'Email', false); ?></th>
        <th><?= iN_HelpSecure(customLang('admin_users_col_joined') ?: 'Joined', false); ?></th>
        <th><?= iN_HelpSecure(customLang('admin_users_col_last_login') ?: 'Last Login', false); ?></th>
        <th><?= iN_HelpSecure(customLang('admin_users_col_verified') ?: 'Verified', false); ?></th>
        <th><?= iN_HelpSecure(customLang('admin_users_col_banned') ?: 'Banned', false); ?></th>
        <th><?= iN_HelpSecure(customLang('admin_users_col_fake_type') ?: 'Fake Type', false); ?></th>
        <th><?= iN_HelpSecure(customLang('admin_users_col_role') ?: 'Type', false); ?></th>
        <th><?= iN_HelpSecure(customLang('admin_users_col_actions') ?: 'Actions', false); ?></th>
      </tr>
    </thead>
    <tbody>
    <?php if (!empty($rows)): ?>
      <?php foreach ($rows as $r):
        $uid      = (int)($r['user_id'] ?? 0);
        $uname    = (string)($r['username'] ?? '');
        $fname    = (string)($r['user_fullname'] ?? $uname);
        $email    = (string)($r['user_email'] ?? '');
        $avatar   = admin_resolve_media_url((string)($r['user_avatar'] ?? 'uploads/user_avatars/default.jpeg'));
        $joinedTimestamp = isset($r['first_seen']) && $r['first_seen'] ? (int)$r['first_seen'] : (isset($r['created_at']) && $r['created_at'] ? (int)$r['created_at'] : 0);
        $first    = $joinedTimestamp > 0 ? date('d-m-Y', $joinedTimestamp) : '-';
        $last     = isset($r['last_login_time']) && $r['last_login_time'] ? date('d-m-Y', (int)$r['last_login_time']) : '-';
        $isVerified = (bool)($r['verified_status'] ?? false);
        $isBanned   = (bool)($r['is_banned'] ?? false);
        $isFake     = (int)($r['is_fake'] ?? 0) === 1;
        $profileUrl = $baseUrl . 'profile/' . rawurlencode($uname);
        $permRaw = $r['admin_permissions'] ?? '';
        $permList = admin_normalize_permissions($permRaw);
        $permJson = htmlspecialchars(json_encode(array_values($permList)), ENT_QUOTES, 'UTF-8');
        $permSet = is_string($permRaw) && trim($permRaw) !== '';
        $displayName = $fname !== '' ? $fname : $uname;
        $vClass = $isVerified ? 'pill-green' : 'pill-gray';
        $bClass = $isBanned   ? 'pill-red'   : 'pill-green';
        $vText  = $isVerified ? (customLang('admin_common_yes') ?: 'Yes') : (customLang('admin_common_no') ?: 'No');
        $bText  = $isBanned   ? (customLang('admin_common_yes') ?: 'Yes') : (customLang('admin_common_no') ?: 'No');
      ?>
        <tr>
          <td><input type="checkbox" class="csel" name="user_ids[]" value="<?= $uid; ?>"></td>
          <td><?= $uid; ?></td>
          <td>
            <a class="user-pill" href="<?= iN_HelpSecure($profileUrl, false); ?>">
              <img class="avatar-32" src="<?= iN_HelpSecure($avatar, false); ?>" alt="<?= iN_HelpSecure(customLang('alt_avatar_of_user') ? sprintf(customLang('alt_avatar_of_user'), $fname) : ('Avatar of ' . $fname), false); ?>">
              <span class="name"><?= iN_HelpSecure($fname, false); ?></span>
            </a>
          </td>
          <td>
            <span class="metric-mini">
              <?= renderVerifiedBadge($iconPath . 'email.svg', true); ?>
              <span class="user-email"><?= iN_HelpSecure($email, false); ?></span>
            </span>
          </td>
          <td>
            <span class="text-muted fs-13 meta-time">
              <?= renderVerifiedBadge($iconPath . 'time.svg', true); ?>
              <?= iN_HelpSecure($first, false); ?>
            </span>
          </td>
          <td>
            <span class="text-muted fs-13 meta-time">
              <?= renderVerifiedBadge($iconPath . 'time.svg', true); ?>
              <?= iN_HelpSecure($last, false); ?>
            </span>
          </td>
          <td>
            <span class="pill <?= $vClass; ?>">
              <span class="tag-icon"><?= renderVerifiedBadge($iconPath . ($isVerified ? 'verified.svg' : 'time.svg'), true); ?></span>
              <?= iN_HelpSecure($vText, false); ?>
            </span>
          </td>
          <td>
            <span class="pill <?= $bClass; ?>">
              <span class="tag-icon"><?= renderVerifiedBadge($iconPath . ($isBanned ? 'ban.svg' : 'tick.svg'), true); ?></span>
              <?= iN_HelpSecure($bText, false); ?>
            </span>
          </td>
          <td>
            <?php
              $fakeClass = $isFake ? 'pill-amber' : 'pill-gray';
              $fakeText  = $isFake
                  ? (customLang('admin_fake_type_fake') ?: 'Fake')
                  : (customLang('admin_fake_type_real') ?: 'Real');
            ?>
            <span class="pill <?= iN_HelpSecure($fakeClass, false); ?>">
              <?= iN_HelpSecure($fakeText, false); ?>
            </span>
          </td>
          <td class="u-mode">
            <?php
              $mode = isset($r['user_mode']) ? (string)$r['user_mode'] : '';
              $typeNum = (int)($r['user_type'] ?? 0);
              $roleKey = $mode !== '' ? strtolower($mode) : (($typeNum >= 3) ? 'admin' : (($typeNum === 2) ? 'moderator' : 'user'));
              $roleIcon = $roleKey === 'admin' ? 'admin.svg' : ($roleKey === 'moderator' ? 'moderator.svg' : 'make_user.svg');
              $rolePill = $roleKey === 'admin' ? 'pill-red' : ($roleKey === 'moderator' ? 'pill-amber' : 'pill-gray');
              $makeUserLabel = customLang('admin_users_action_make_user') ?: 'Make User';
              $makeModLabel = customLang('admin_users_action_make_moderator') ?: 'Make Moderator';
              $makeAdminLabel = customLang('admin_users_action_make_admin') ?: 'Make Admin';
              $isUserLabel = customLang('admin_users_action_is_user') ?: 'User is User';
              $isModLabel = customLang('admin_users_action_is_moderator') ?: 'User is Moderator';
              $isAdminLabel = customLang('admin_users_action_is_admin') ?: 'User is Admin';
              $roleIsUser = $roleKey === 'user';
              $roleIsMod = $roleKey === 'moderator';
              $roleIsAdmin = $roleKey === 'admin';
            ?>
            <span class="pill <?= iN_HelpSecure($rolePill, false); ?>">
              <span class="tag-icon"><?= renderVerifiedBadge($iconPath . $roleIcon, true); ?></span>
              <span><?= iN_HelpSecure(ucfirst($roleKey), false); ?></span>
            </span>
          </td>
          <td>
            <div class="post-settings-btn-box flex align_items relative">
              <button
                type="button"
                class="post-settings-btn flex align_items_justify_content relative js-user-actions"
                aria-expanded="false"
                aria-haspopup="menu"
                title="<?= iN_HelpSecure(customLang('admin_users_actions_label') ?: 'Actions', false); ?>"
                data-id="<?= $uid; ?>"
              >
              <?= renderVerifiedBadge($iconPath . 'dots.svg', false); ?>
              </button>
            </div>

            <div id="postMenuPopup-<?= $uid; ?>" class="post-menu-popup none" aria-hidden="true" role="dialog" aria-label="<?= iN_HelpSecure('User actions for #' . $uid, false); ?>">
              <div class="pm-sheet-container">
              <div class="pm-sheet">
                  <a class="pm-item" href="<?= iN_HelpSecure($baseUrl . 'admin/index.php?page=user_detail&id=' . (string)$uid, false); ?>"><?= iN_HelpSecure(customLang('admin_users_action_detail') ?: 'See user details', false); ?></a>
                  <?php if ($uid === 1): ?>
                    <div class="pm-item text-muted"><?= iN_HelpSecure(customLang('admin_users_owner_protected') ?: 'Owner account is protected', false); ?></div>
                  <?php else: ?>
                    <?php if ($isBanned): ?>
                      <button type="button" class="pm-item flex align_items_justify_content gap js-uact<?= $canUserBan ? '' : ' is-disabled'; ?>" data-action="unban" data-user-id="<?= $uid; ?>"<?= $canUserBan ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?php echo renderVerifiedBadge($iconPath . 'unban.svg', true); ?> <span><?= iN_HelpSecure(customLang('admin_users_action_unban') ?: 'Unban user', false); ?></span></button>
                    <?php else: ?>
                      <button type="button" class="pm-item flex align_items_justify_content gap js-uact<?= $canUserBan ? '' : ' is-disabled'; ?>" data-action="ban" data-user-id="<?= $uid; ?>"<?= $canUserBan ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?php echo renderVerifiedBadge($iconPath . 'ban.svg', true); ?> <span><?= iN_HelpSecure(customLang('admin_users_action_ban') ?: 'Ban user', false); ?></span></button>
                    <?php endif; ?>
                    <button type="button" class="pm-item flex align_items_justify_content js-uact is-danger<?= $canUserDelete ? '' : ' is-disabled'; ?>" data-action="delete" data-user-id="<?= $uid; ?>"<?= $canUserDelete ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?= iN_HelpSecure(customLang('admin_users_action_delete') ?: 'Delete user', false); ?></button>
                    <?php
                      $__myType = (int)($currentUser['user_type'] ?? 0);
                      $__meId   = (int)($currentUser['user_id'] ?? 0);
                      $__isOwnerOrAdmin = ($__meId === 1) || ($__myType >= 3);
                    ?>
                    <?php if ($__isOwnerOrAdmin): ?>
                      <div class="pm-divider"></div>
                      <?php if ($__meId === $uid): ?>
                        <button type="button" class="pm-item flex align_items_justify_content gap js-uact<?php echo $roleIsUser ? ' is-role-active is-role-user' : ''; ?><?= $canUserSetRole ? '' : ' is-disabled'; ?>" data-action="set_role" data-role="user" data-user-id="<?= $uid; ?>" disabled aria-disabled="true" title="<?= iN_HelpSecure(customLang('admin_users_action_self_role_tip') ?: 'Admins cannot change their own role.', false); ?>"><?php echo renderVerifiedBadge($iconPath . 'make_user.svg', true); ?> <span><?= iN_HelpSecure($roleIsUser ? $isUserLabel : $makeUserLabel, false); ?></span></button>
                        <button type="button" class="pm-item flex align_items_justify_content gap js-uact<?php echo $roleIsMod ? ' is-role-active is-role-moderator' : ''; ?><?= $canUserSetRole ? '' : ' is-disabled'; ?>" data-action="set_role" data-role="moderator" data-user-id="<?= $uid; ?>" disabled aria-disabled="true" title="<?= iN_HelpSecure(customLang('admin_users_action_self_role_tip') ?: 'Admins cannot change their own role.', false); ?>"><?php echo renderVerifiedBadge($iconPath . 'moderator.svg', true); ?> <span><?= iN_HelpSecure($roleIsMod ? $isModLabel : $makeModLabel, false); ?></span></button>
                        <button type="button" class="pm-item flex align_items_justify_content gap js-uact<?php echo $roleIsAdmin ? ' is-role-active is-role-admin' : ''; ?><?= $canUserSetRole ? '' : ' is-disabled'; ?>" data-action="set_role" data-role="admin" data-user-id="<?= $uid; ?>" disabled aria-disabled="true" title="<?= iN_HelpSecure(customLang('admin_users_action_self_role_tip') ?: 'Admins cannot change their own role.', false); ?>"><?php echo renderVerifiedBadge($iconPath . 'admin.svg', true); ?> <span><?= iN_HelpSecure($roleIsAdmin ? $isAdminLabel : $makeAdminLabel, false); ?></span></button>
                      <?php else: ?>
                        <button type="button" class="pm-item flex align_items_justify_content gap js-uact<?php echo $roleIsUser ? ' is-role-active is-role-user' : ''; ?><?= $canUserSetRole ? '' : ' is-disabled'; ?>" data-action="set_role" data-role="user" data-user-id="<?= $uid; ?>"<?php echo $roleIsUser || !$canUserSetRole ? ' disabled aria-disabled="true"' : ''; ?><?= $canUserSetRole ? '' : ' title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?php echo renderVerifiedBadge($iconPath . 'make_user.svg', true); ?> <span><?= iN_HelpSecure($roleIsUser ? $isUserLabel : $makeUserLabel, false); ?></span></button>
                        <button type="button" class="pm-item flex align_items_justify_content gap js-uact<?php echo $roleIsMod ? ' is-role-active is-role-moderator' : ''; ?><?= $canUserSetRole ? '' : ' is-disabled'; ?>" data-action="set_role" data-role="moderator" data-user-id="<?= $uid; ?>" data-permissions="<?= $permJson; ?>" data-permissions-set="<?= $permSet ? '1' : '0'; ?>" data-user-name="<?= iN_HelpSecure($displayName, false); ?>"<?php echo !$canUserSetRole ? ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"' : ''; ?>><?php echo renderVerifiedBadge($iconPath . 'moderator.svg', true); ?> <span><?= iN_HelpSecure($roleIsMod ? $isModLabel : $makeModLabel, false); ?></span></button>
                        <button type="button" class="pm-item flex align_items_justify_content gap js-uact<?php echo $roleIsAdmin ? ' is-role-active is-role-admin' : ''; ?><?= $canUserSetRole ? '' : ' is-disabled'; ?>" data-action="set_role" data-role="admin" data-user-id="<?= $uid; ?>"<?php echo $roleIsAdmin || !$canUserSetRole ? ' disabled aria-disabled="true"' : ''; ?><?= $canUserSetRole ? '' : ' title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?php echo renderVerifiedBadge($iconPath . 'admin.svg', true); ?> <span><?= iN_HelpSecure($roleIsAdmin ? $isAdminLabel : $makeAdminLabel, false); ?></span></button>
                      <?php endif; ?>
                    <?php endif; ?>
                  <?php endif; ?>
                  <button type="button" class="pm-item pm-cancel"><?= iN_HelpSecure(customLang('admin_users_action_cancel') ?: 'Cancel', false); ?></button>
                </div>
              </div>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
    <?php else: ?>
      <tr>
        <td colspan="11" class="text-center text-muted"><?= iN_HelpSecure(customLang('admin_fake_generator_no_results') ?: 'No users found.', false); ?></td>
      </tr>
    <?php endif; ?>
    </tbody>
  </table>
</div>
<?php if (is_array($pagination)): ?>
  <?php
    echo dz_render_pagination(
      (string)($pagination['base_url'] ?? ($baseUrl . 'admin/index.php')),
      (array)($pagination['params'] ?? []),
      (int)($pagination['page'] ?? 1),
      (int)($pagination['pages'] ?? 1),
      (array)($pagination['options'] ?? ['show_goto' => true, 'radius' => 1])
    );
  ?>
<?php endif; ?>
