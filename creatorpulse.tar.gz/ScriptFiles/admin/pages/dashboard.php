<?php
declare(strict_types=1);
require_once __DIR__ . '/../_bootstrap.php'; // Guard admin access

global $ADM, $currency, $iconPath, $db, $currencies, $currencyFormatSettings;

// Helpers
$currenciesMap = isset($currencies) && is_array($currencies) ? $currencies : [];
$currencyCode = isset($currency) && $currency !== '' ? strtoupper((string) $currency) : 'USD';
$currencyFormatSettings = $currencyFormatSettings ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
$fmtMoney = static function (float $value, ?string $code = null) use ($currenciesMap, $currencyFormatSettings, $currencyCode): string {
    $resolvedCode = strtoupper((string) ($code ?? $currencyCode));
    $symbol = $currenciesMap[$resolvedCode] ?? null;

    return dz_format_currency(
        $value,
        $resolvedCode,
        $symbol,
        $currencyFormatSettings
    );
};
$pctText = function(float $pct): string {
    $sign = $pct >= 0 ? '' : '- ';
    $abs  = abs($pct);
    return $sign . number_format($abs, 2) . '%';
};

function dash_delta_class(float $pct): string { return ($pct >= 0.0) ? 'text-primary' : 'text-danger'; }
function dash_delta_arrow(float $pct): string { return ($pct >= 0.0) ? '▲' : '▼'; }

// Periods
$now = time();
$monthStart = strtotime(date('Y-m-01 00:00:00', $now));
$nextMonthStart = strtotime(date('Y-m-01 00:00:00', strtotime('+1 month', $monthStart)));
$prevMonthStart = strtotime(date('Y-m-01 00:00:00', strtotime('-1 month', $monthStart)));
$weekStart = $now - 7 * 86400; $prevWeekStart = $now - 14 * 86400; $weekEnd = $now; $prevWeekEnd = $weekStart;

// Metrics
$earnNow = $ADM->ADM_PostEarningsTotal($monthStart, $nextMonthStart);
$earnPrev= $ADM->ADM_PostEarningsTotal($prevMonthStart, $monthStart);
$earnPct = $ADM->ADM_PercentChange($earnNow, $earnPrev);
$earnSeries = $ADM->ADM_DailySeries('posts', 7);

$subsNow  = $ADM->ADM_SubscriptionsTotal($weekStart, $weekEnd);
$subsPrev = $ADM->ADM_SubscriptionsTotal($prevWeekStart, $prevWeekEnd);
$subsPct  = $ADM->ADM_PercentChange($subsNow, $subsPrev);
$subsSeries = $ADM->ADM_DailySeries('subs', 7);

$tipsNow    = $ADM->ADM_TipsTotal($monthStart, $nextMonthStart);
$tipsPrev   = $ADM->ADM_TipsTotal($prevMonthStart, $monthStart);
$tipsPct    = $ADM->ADM_PercentChange($tipsNow, $tipsPrev);
$tipsSeries = $ADM->ADM_DailySeries('tips', 7);

// Gauge shows month-over-month tips ratio (this month vs last month)
$tipsRatio = $ADM->ADM_RatioPercent($tipsNow, $tipsPrev);

$yearStart     = strtotime(date('Y-01-01 00:00:00', $now));
$nextYearStart = strtotime(date('Y-01-01 00:00:00', strtotime('+1 year', $yearStart)));
$baseCurrency  = isset($currency) && $currency !== '' ? (string)$currency : null;
$walletTotalBalance   = $ADM->ADM_TotalWalletBalance();
$walletWeeklyTopups   = $ADM->ADM_WalletTopupsTotal($weekStart, $weekEnd, $baseCurrency);
$walletMonthlyTopups  = $ADM->ADM_WalletTopupsTotal($monthStart, $nextMonthStart, $baseCurrency);
$walletYearlyTopups   = $ADM->ADM_WalletTopupsTotal($yearStart, $nextYearStart, $baseCurrency);
$audioRoomNow = $ADM->ADM_AudioRoomRevenueSummary($monthStart, $nextMonthStart);
$audioRoomPrev = $ADM->ADM_AudioRoomRevenueSummary($prevMonthStart, $monthStart);
$audioRoomGrossPct = $ADM->ADM_PercentChange((float)$audioRoomNow['gross'], (float)$audioRoomPrev['gross']);
$audioRoomNetPct = $ADM->ADM_PercentChange((float)$audioRoomNow['creator_net'], (float)$audioRoomPrev['creator_net']);
$audioRoomFeePct = $ADM->ADM_PercentChange((float)$audioRoomNow['platform_fee'], (float)$audioRoomPrev['platform_fee']);

// Simple SVG renderers (no inline styles)
function dash_fmt_val(float $v): string {
    $int = (int)round($v);
    if (abs($v - $int) < 0.005) { return (string)$int; }
    $s = number_format($v, 2, '.', '');
    $s = rtrim(rtrim($s, '0'), '.');
    return $s;
}

function dash_svg_bars(array $series): string {
    $values = array_map(static fn($p)=> (float)($p['v'] ?? 0.0), $series);
    $max = max(1.0, (float)max($values));
    $bars = '';
    $x = 6; $w = 10; $gap = 8; $h = 48; $bottom = 54;
    foreach ($series as $idx => $pt) {
        $v = (float)($pt['v'] ?? 0.0);
        $t = (int)($pt['t'] ?? 0);
        $bh = (int)round(($max > 0 ? ($v / $max) : 0) * $h);
        $y = $bottom - $bh;
        $label = dash_fmt_val($v) . ' · ' . date('Y-m-d', $t);
        $safe  = htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
        $bars .= '<rect x="'.$x.'" y="'.$y.'" width="'.$w.'" height="'.$bh.'" rx="2" fill="#24b8c7" opacity="0.85" data-tip="'.$safe.'">'
               . '<title>'.$safe.'</title>'
               . '</rect>';
        $x += $w + $gap;
    }
    return '<svg width="160" height="60" viewBox="0 0 160 60" aria-hidden="true">'
         . '<rect x="0" y="0" width="160" height="60" rx="10" fill="#eaf7f8" opacity="0.5" />'
         . $bars . '</svg>';
}

function dash_svg_line(array $series): string {
    $values = array_map(static fn($p)=> (float)($p['v'] ?? 0.0), $series);
    $max = max(1.0, (float)max($values));
    $w = 220; $h = 80; $pad = 8; $usableW = $w - $pad*2; $usableH = $h - $pad*2;
    $n = max(1, count($values));
    $dx = $usableW / max(1, $n-1);
    $points = [];
    $hotspots = '';
    for ($i=0;$i<$n;$i++) {
        $x = $pad + $i * $dx;
        $v = (float)$values[$i];
        $y = $pad + ($usableH - ($max > 0 ? ($v / $max) * $usableH : 0));
        $points[] = $x.','.$y;
        $t = (int)($series[$i]['t'] ?? 0);
        $label = dash_fmt_val($v) . ' · ' . date('Y-m-d', $t);
        $safe  = htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
        $hotspots .= '<circle cx="'.$x.'" cy="'.$y.'" r="6" fill="transparent" data-tip="'.$safe.'">'
                  .  '<title>'.$safe.'</title>'
                  .  '</circle>';
    }
    $poly = implode(' ', $points);
    return '<svg width="220" height="80" viewBox="0 0 220 80" aria-hidden="true">'
         . '<defs><linearGradient id="g1" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#111b2e" stop-opacity="0.08"/><stop offset="100%" stop-color="#111b2e" stop-opacity="0"/></linearGradient></defs>'
         . '<polyline fill="none" stroke="#111b2e" stroke-width="2" points="'.$poly.'" />'
         . '<polygon fill="url(#g1)" points="'.$pad.','.$h.' '.$poly.' '.($w-$pad).','.$h.'" />'
         . $hotspots
         . '</svg>';
}

function dash_svg_gauge(float $pct): string {
    $pct = max(0, min(100, $pct));
    $w = 120; $h = 80; // canvas
    $r = 28; $cx = $w / 2; $cy = $h / 2; // perfectly centered
    $C = pi() * $r; // half circumference
    $len = $C * ($pct / 100.0);
    $bg = '<path d="M '.($cx-$r).' '.$cy.' A '.$r.' '.$r.' 0 0 1 '.($cx+$r).' '.$cy.'" stroke="#fde3df" stroke-width="10" fill="none" />';
    $fg = '<path d="M '.($cx-$r).' '.$cy.' A '.$r.' '.$r.' 0 0 1 '.($cx+$r).' '.$cy.'" stroke="#ff6b60" stroke-width="10" fill="none" stroke-dasharray="'.$len.' '.($C-$len).'" />';
    return '<svg width="'.$w.'" height="'.$h.'" viewBox="0 0 '.$w.' '.$h.'" aria-hidden="true">'.$bg.$fg.'</svg>';
}
?>

<section class="card_admin rounded-2xl" role="region" aria-labelledby="adminDashHeading">
  <h1 class="h1" id="adminDashHeading"><?= iN_HelpSecure(customLang('admin_menu_dashboard') ?: 'Dashboard', false); ?></h1>

  <div class="kpi-row mt-4">
    <div class="admin-card card kpi-card">
      <div class="kpi-left full-width">
        <div class="kpi-title">
          <span class="kpi-icon kpi-icon--earn"><?= renderVerifiedBadge($iconPath . 'payments.svg', true); ?></span>
          <strong><?= iN_HelpSecure(customLang('admin_dashboard_total_earnings') ?: 'Total earnings', false); ?></strong>
        </div>
        <div class="kpi-amount"><?= htmlspecialchars($fmtMoney($earnNow), ENT_QUOTES, 'UTF-8'); ?></div>
        <div class="kpi-delta <?= dash_delta_class($earnPct); ?>">
          <span class="arrow"><?= dash_delta_arrow($earnPct); ?></span>
          <span><?= htmlspecialchars($pctText($earnPct), ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <span class="text-muted"><?= iN_HelpSecure(customLang('admin_dashboard_since_last_month') ?: 'Since last month', false); ?></span>
      </div>
      <div class="kpi-chart kpi-chart--bars" aria-hidden="true"><?= dash_svg_bars($earnSeries); ?></div>
    </div>

    <div class="admin-card card kpi-card">
      <div class="kpi-left full-width">
        <div class="kpi-title">
          <span class="kpi-icon kpi-icon--subs"><?= renderVerifiedBadge($iconPath . 'subscription_fees.svg', true); ?></span>
          <strong><?= iN_HelpSecure(customLang('admin_dashboard_total_subscriptions') ?: 'Total subscriptions', false); ?></strong>
        </div>
        <div class="kpi-amount"><?= htmlspecialchars($fmtMoney($subsNow), ENT_QUOTES, 'UTF-8'); ?></div>
        <div class="kpi-delta <?= dash_delta_class($subsPct); ?>">
          <span class="arrow"><?= dash_delta_arrow($subsPct); ?></span>
          <span><?= htmlspecialchars($pctText($subsPct), ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <span class="text-muted"><?= iN_HelpSecure(customLang('admin_dashboard_than_last_week') ?: 'Than last week', false); ?></span>
      </div>
      <div class="kpi-chart kpi-chart--line" aria-hidden="true"><?= dash_svg_line($subsSeries); ?></div>
    </div>

    <div class="admin-card card kpi-card">
      <div class="kpi-left full-width">
        <div class="kpi-title">
          <span class="kpi-icon kpi-icon--tips"><?= renderVerifiedBadge($iconPath . 'super_thanks.svg', true); ?></span>
          <strong><?= iN_HelpSecure(customLang('admin_dashboard_total_tips') ?: 'Total tips earnings', false); ?></strong>
        </div>
        <div class="kpi-amount"><?= htmlspecialchars($fmtMoney($tipsNow), ENT_QUOTES, 'UTF-8'); ?></div>
        <div class="kpi-delta <?= dash_delta_class($tipsPct); ?>">
          <span class="arrow"><?= dash_delta_arrow($tipsPct); ?></span>
          <span><?= htmlspecialchars($pctText($tipsPct), ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <span class="text-muted"><?= iN_HelpSecure(customLang('admin_dashboard_since_last_month') ?: 'Since last month', false); ?></span>
      </div>
      <div class="kpi-chart kpi-chart--gauge">
        <div class="kpi-gauge">
          <?= dash_svg_gauge($tipsRatio); ?>
          <div class="kpi-gauge__center">
            <div class="kpi-gauge__label"><?= iN_HelpSecure(customLang('admin_dashboard_tips_ratio') ?: 'Tips ratio', false); ?></div>
            <div class="kpi-gauge__percent"><?= (int)round($tipsRatio); ?>%</div>
          </div>
        </div>
      </div>
    </div>

    <div class="admin-card card kpi-card">
      <div class="kpi-left full-width">
        <div class="kpi-title">
          <span class="kpi-icon kpi-icon--wallet"><?= renderVerifiedBadge($iconPath . 'payments.svg', true); ?></span>
          <strong><?= iN_HelpSecure(customLang('admin_dashboard_total_wallet_balance') ?: 'Wallet balance', false); ?></strong>
        </div>
        <div class="kpi-amount"><?= htmlspecialchars($fmtMoney($walletTotalBalance), ENT_QUOTES, 'UTF-8'); ?></div>
        <div class="wallet-kpi-breakdown">
          <div class="flex align_items space_between">
            <span class="text-muted fs-13"><?= iN_HelpSecure(customLang('admin_dashboard_wallet_topups_week') ?: 'Top-ups (7 days)', false); ?></span>
            <span class="amount-mono"><?= htmlspecialchars($fmtMoney($walletWeeklyTopups), ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
          <div class="flex align_items space_between">
            <span class="text-muted fs-13"><?= iN_HelpSecure(customLang('admin_dashboard_wallet_topups_month') ?: 'Top-ups (30 days)', false); ?></span>
            <span class="amount-mono"><?= htmlspecialchars($fmtMoney($walletMonthlyTopups), ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
          <div class="flex align_items space_between">
            <span class="text-muted fs-13"><?= iN_HelpSecure(customLang('admin_dashboard_wallet_topups_year') ?: 'Top-ups (year to date)', false); ?></span>
            <span class="amount-mono"><?= htmlspecialchars($fmtMoney($walletYearlyTopups), ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="kpi-row mt-4 admin-audio-room-kpis">
    <div class="admin-card card kpi-card">
      <div class="kpi-left full-width">
        <div class="kpi-title">
          <span class="kpi-icon kpi-icon--audio-room"><?= render_icon('speaker', true); ?></span>
          <strong><?= iN_HelpSecure(customLang('admin_dashboard_audio_room_gross') ?: 'Audio Room gross volume', false); ?></strong>
        </div>
        <div class="kpi-amount"><?= htmlspecialchars($fmtMoney((float)$audioRoomNow['gross']), ENT_QUOTES, 'UTF-8'); ?></div>
        <div class="kpi-delta <?= dash_delta_class($audioRoomGrossPct); ?>">
          <span class="arrow"><?= dash_delta_arrow($audioRoomGrossPct); ?></span>
          <span><?= htmlspecialchars($pctText($audioRoomGrossPct), ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <div class="wallet-kpi-breakdown">
          <div class="flex align_items space_between">
            <span class="text-muted fs-13"><?= iN_HelpSecure(customLang('admin_dashboard_audio_room_tips') ?: 'Tips', false); ?></span>
            <span class="amount-mono"><?= htmlspecialchars($fmtMoney((float)$audioRoomNow['tip_gross']), ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
          <div class="flex align_items space_between">
            <span class="text-muted fs-13"><?= iN_HelpSecure(customLang('admin_dashboard_audio_room_tickets') ?: 'Tickets', false); ?></span>
            <span class="amount-mono"><?= htmlspecialchars($fmtMoney((float)$audioRoomNow['ticket_gross']), ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
        </div>
      </div>
    </div>

    <div class="admin-card card kpi-card">
      <div class="kpi-left full-width">
        <div class="kpi-title">
          <span class="kpi-icon kpi-icon--audio-room"><?= render_icon('speaker', true); ?></span>
          <strong><?= iN_HelpSecure(customLang('admin_dashboard_audio_room_creator_net') ?: 'Creator Audio Room earnings', false); ?></strong>
        </div>
        <div class="kpi-amount"><?= htmlspecialchars($fmtMoney((float)$audioRoomNow['creator_net']), ENT_QUOTES, 'UTF-8'); ?></div>
        <div class="kpi-delta <?= dash_delta_class($audioRoomNetPct); ?>">
          <span class="arrow"><?= dash_delta_arrow($audioRoomNetPct); ?></span>
          <span><?= htmlspecialchars($pctText($audioRoomNetPct), ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <div class="wallet-kpi-breakdown">
          <div class="flex align_items space_between">
            <span class="text-muted fs-13"><?= iN_HelpSecure(customLang('admin_dashboard_audio_room_tips') ?: 'Tips', false); ?></span>
            <span class="amount-mono"><?= htmlspecialchars($fmtMoney((float)$audioRoomNow['tip_net']), ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
          <div class="flex align_items space_between">
            <span class="text-muted fs-13"><?= iN_HelpSecure(customLang('admin_dashboard_audio_room_tickets') ?: 'Tickets', false); ?></span>
            <span class="amount-mono"><?= htmlspecialchars($fmtMoney((float)$audioRoomNow['ticket_net']), ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
        </div>
      </div>
    </div>

    <div class="admin-card card kpi-card">
      <div class="kpi-left full-width">
        <div class="kpi-title">
          <span class="kpi-icon kpi-icon--audio-room"><?= render_icon('speaker', true); ?></span>
          <strong><?= iN_HelpSecure(customLang('admin_dashboard_audio_room_platform_fee') ?: 'Audio Room platform fees', false); ?></strong>
        </div>
        <div class="kpi-amount"><?= htmlspecialchars($fmtMoney((float)$audioRoomNow['platform_fee']), ENT_QUOTES, 'UTF-8'); ?></div>
        <div class="kpi-delta <?= dash_delta_class($audioRoomFeePct); ?>">
          <span class="arrow"><?= dash_delta_arrow($audioRoomFeePct); ?></span>
          <span><?= htmlspecialchars($pctText($audioRoomFeePct), ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <div class="wallet-kpi-breakdown">
          <div class="flex align_items space_between">
            <span class="text-muted fs-13"><?= iN_HelpSecure(customLang('admin_dashboard_audio_room_tips') ?: 'Tips', false); ?></span>
            <span class="amount-mono"><?= htmlspecialchars($fmtMoney((float)$audioRoomNow['tip_fee']), ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
          <div class="flex align_items space_between">
            <span class="text-muted fs-13"><?= iN_HelpSecure(customLang('admin_dashboard_audio_room_tickets') ?: 'Tickets', false); ?></span>
            <span class="amount-mono"><?= htmlspecialchars($fmtMoney((float)$audioRoomNow['ticket_fee']), ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <?php
  // Second KPI row: Users / Posts / Reports (weekly deltas)
  $usersTotal = $ADM->ADM_TotalUsers();
  $postsTotal = $ADM->ADM_TotalPosts();
  $reportsTotal = $ADM->ADM_TotalReports();

  $usersSeries = $ADM->ADM_ActiveUsersSeries(7);
  $postsSeries = $ADM->ADM_PostsSeries(7);
  $reportsSeries = $ADM->ADM_ReportsSeries(7);

  $usersNowW = $ADM->ADM_CountActiveUsersBetween($weekStart, $weekEnd);
  $usersPrevW= $ADM->ADM_CountActiveUsersBetween($prevWeekStart, $prevWeekEnd);
  $usersPct  = $ADM->ADM_PercentChange((float)$usersNowW, (float)$usersPrevW);

  $postsNowW = $ADM->ADM_CountPostsBetween($weekStart, $weekEnd);
  $postsPrevW= $ADM->ADM_CountPostsBetween($prevWeekStart, $prevWeekEnd);
  $postsPct  = $ADM->ADM_PercentChange((float)$postsNowW, (float)$postsPrevW);

  $repNowW   = $ADM->ADM_CountReportsBetween($weekStart, $weekEnd);
  $repPrevW  = $ADM->ADM_CountReportsBetween($prevWeekStart, $prevWeekEnd);
  $repPct    = $ADM->ADM_PercentChange((float)$repNowW, (float)$repPrevW);
  ?>

  <?php
  // Monthly revenue (Subscriptions + Tips) and Post visibility donut
  $mo = $ADM->ADM_MonthlyEarningsSeries(12);
  $moSubs = $mo['subs'];
  $moTips = $mo['tips'];
  $moEbooks = $mo['ebooks'] ?? [];
  $moAudioRoomTips = $mo['audio_room_tips'] ?? [];
  $moAudioRoomTickets = $mo['audio_room_tickets'] ?? [];
  // Prepare arrays for Chart.js
  $moLabels = [];$moSubsVals=[];$moTipsVals=[];$moEbookVals=[];$moAudioRoomTipVals=[];$moAudioRoomTicketVals=[];
  foreach ($moSubs as $i=>$p) {
      $moLabels[] = date('M', (int)($p['t'] ?? time()));
      $moSubsVals[] = (float)($p['v'] ?? 0);
      $moTipsVals[] = (float)($moTips[$i]['v'] ?? 0);
      $moEbookVals[] = (float)($moEbooks[$i]['v'] ?? 0);
      $moAudioRoomTipVals[] = (float)($moAudioRoomTips[$i]['v'] ?? 0);
      $moAudioRoomTicketVals[] = (float)($moAudioRoomTickets[$i]['v'] ?? 0);
  }
  $labelsJson = htmlspecialchars(json_encode($moLabels), ENT_QUOTES, 'UTF-8');
  $subsJson   = htmlspecialchars(json_encode($moSubsVals), ENT_QUOTES, 'UTF-8');
  $tipsJson   = htmlspecialchars(json_encode($moTipsVals), ENT_QUOTES, 'UTF-8');
  $ebooksJson = htmlspecialchars(json_encode($moEbookVals), ENT_QUOTES, 'UTF-8');
  $audioRoomTipsJson = htmlspecialchars(json_encode($moAudioRoomTipVals), ENT_QUOTES, 'UTF-8');
  $audioRoomTicketsJson = htmlspecialchars(json_encode($moAudioRoomTicketVals), ENT_QUOTES, 'UTF-8');
  $pv = $ADM->ADM_PostVisibilityBreakdown();
  $pvTotal = max(0, (int)array_sum($pv));
  ?>

  <div class="charts-row">
    <div class="admin-card card chart-card">
      <div class="chart-title"><?= iN_HelpSecure(customLang('admin_dashboard_revenue_title') ?: 'Revenue', false); ?></div>
      <div class="chart-legend">
        <span><span class="legend-dot legend-blue"></span><?= iN_HelpSecure(customLang('admin_dashboard_legend_subscriptions') ?: 'Subscriptions', false); ?></span>
        <span><span class="legend-dot legend-red"></span><?= iN_HelpSecure(customLang('admin_dashboard_legend_tips') ?: 'Tips', false); ?></span>
        <span><span class="legend-dot legend-cyan"></span><?= iN_HelpSecure(customLang('admin_dashboard_legend_ebooks') ?: 'eBooks', false); ?></span>
        <span><span class="legend-dot legend-purple"></span><?= iN_HelpSecure(customLang('admin_dashboard_legend_audio_room_tips') ?: 'Audio Room tips', false); ?></span>
        <span><span class="legend-dot legend-amber"></span><?= iN_HelpSecure(customLang('admin_dashboard_legend_audio_room_tickets') ?: 'Audio Room tickets', false); ?></span>
      </div>
      <div class="chart-box chart-box--rev">
        <canvas id="revChart" class="chart-canvas" data-labels='<?= $labelsJson; ?>' data-subs='<?= $subsJson; ?>' data-tips='<?= $tipsJson; ?>' data-ebooks='<?= $ebooksJson; ?>' data-audio-room-tips='<?= $audioRoomTipsJson; ?>' data-audio-room-tickets='<?= $audioRoomTicketsJson; ?>'></canvas>
      </div>
    </div>

    <div class="admin-card card donut-card">
      <div class="chart-title"><?= iN_HelpSecure(customLang('admin_dashboard_posts_visibility') ?: 'Posts by visibility', false); ?></div>
      <?php $brkJson = htmlspecialchars(json_encode($pv), ENT_QUOTES, 'UTF-8'); ?>
      <div class="chart-box chart-box--donut">
        <canvas id="postVisChart" class="chart-canvas" data-breakdown='<?= $brkJson; ?>'></canvas>
      </div>
    </div>
  </div>
  <div class="kpi-row mt-4">
    <div class="admin-card card kpi-card">
      <div class="kpi-left full-width">
        <div class="kpi-title">
          <span class="kpi-icon kpi-icon--users"><?= renderVerifiedBadge($iconPath . 'dashboard_user.svg', true); ?></span>
          <strong><?= iN_HelpSecure(customLang('admin_dashboard_total_users') ?: 'Total users', false); ?></strong>
        </div>
        <div class="kpi-amount"><?= number_format((int)$usersTotal, 0, ',', '.'); ?></div>
        <div class="kpi-delta <?= dash_delta_class($usersPct); ?>">
          <span class="arrow"><?= dash_delta_arrow($usersPct); ?></span>
          <span><?= htmlspecialchars($pctText($usersPct), ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <span class="text-muted"><?= iN_HelpSecure(customLang('admin_dashboard_than_last_week') ?: 'Than last week', false); ?></span>
      </div>
      <div class="kpi-chart kpi-chart--line" aria-hidden="true"><?= dash_svg_line($usersSeries); ?></div>
    </div>

    <div class="admin-card card kpi-card">
      <div class="kpi-left full-width">
        <div class="kpi-title">
          <span class="kpi-icon kpi-icon--posts"><?= renderVerifiedBadge($iconPath . 'reels.svg', true); ?></span>
          <strong><?= iN_HelpSecure(customLang('admin_dashboard_total_posts') ?: 'Total posts', false); ?></strong>
        </div>
        <div class="kpi-amount"><?= number_format((int)$postsTotal, 0, ',', '.'); ?></div>
        <div class="kpi-delta <?= dash_delta_class($postsPct); ?>">
          <span class="arrow"><?= dash_delta_arrow($postsPct); ?></span>
          <span><?= htmlspecialchars($pctText($postsPct), ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <span class="text-muted"><?= iN_HelpSecure(customLang('admin_dashboard_than_last_week') ?: 'Than last week', false); ?></span>
      </div>
      <div class="kpi-chart kpi-chart--bars" aria-hidden="true"><?= dash_svg_bars($postsSeries); ?></div>
    </div>

    <div class="admin-card card kpi-card">
      <div class="kpi-left full-width">
        <div class="kpi-title">
          <span class="kpi-icon kpi-icon--reports"><?= renderVerifiedBadge($iconPath . 'notification.svg', true); ?></span>
          <strong><?= iN_HelpSecure(customLang('admin_dashboard_pending_reports') ?: 'Pending reports', false); ?></strong>
        </div>
        <div class="kpi-amount"><?= number_format((int)$reportsTotal, 0, ',', '.'); ?></div>
        <div class="kpi-delta <?= dash_delta_class($repPct); ?>">
          <span class="arrow"><?= dash_delta_arrow($repPct); ?></span>
          <span><?= htmlspecialchars($pctText($repPct), ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <span class="text-muted"><?= iN_HelpSecure(customLang('admin_dashboard_than_last_week') ?: 'Than last week', false); ?></span>
      </div>
      <div class="kpi-chart kpi-chart--line" aria-hidden="true"><?= dash_svg_line($reportsSeries); ?></div>
    </div>
  </div>
  <?php
    // Latest activity blocks: users, subscriptions, tips
    $latestUsers = $ADM->ADM_ListLatestUsers(10);
    $latestSubs  = $ADM->ADM_ListLatestSubscriptions(10);
    $latestTips  = $ADM->ADM_ListLatestTips(10);

    // Helper for plain date (dd-mm-YYYY)
    $fmtDate = static function(?int $ts): string {
        return ($ts && $ts > 0) ? date('d-m-Y', $ts) : '-';
    };
  ?>

  <div class="kpi-row mt-4">
    <!-- Latest Users -->
    <div class="admin-card card list-card relative">
      <div class="list-header">
        <span class="icon"><?= renderVerifiedBadge($iconPath . 'dashboard_user.svg', true); ?></span>
        <span><strong><?= iN_HelpSecure(customLang('admin_dashboard_latest_users') ?: 'Latest users', false); ?></strong></span>
        <?php $urlAllUsers = ($base_url ?? '/') . 'admin/index.php?page=users'; ?>
        <a class="view-all" href="<?= iN_HelpSecure($urlAllUsers, false); ?>"><?= iN_HelpSecure(customLang('admin_dashboard_view_all') ?: 'View all', false); ?></a>
      </div>
      <ul class="activity-list">
        <?php foreach ($latestUsers as $u):
          $uid  = (int)($u['user_id'] ?? 0);
          $uname= (string)($u['username'] ?? '');
          $fname= (string)($u['user_fullname'] ?? $uname);
          $av   = admin_resolve_media_url((string)($u['user_avatar'] ?? 'uploads/user_avatars/default.jpeg'));
          $joined = $fmtDate(isset($u['first_seen']) ? (int)$u['first_seen'] : null);
          $profileUrl = ($base_url ?? '/') . 'profile/' . rawurlencode($uname);
          $adminUsersUrl = ($base_url ?? '/') . 'admin/index.php?page=users&q=' . urlencode($uname);
        ?>
        <li class="activity-item">
          <div class="avatar-stack">
            <?php $avatarAlt = sprintf(customLang('admin_dashboard_avatar_of') ?: 'Avatar of %s', $fname); ?>
            <img class="main" src="<?= iN_HelpSecure($av, false); ?>" alt="<?= iN_HelpSecure($avatarAlt, false); ?>">
          </div>
          <div class="activity-body">
            <div class="title">
              <a href="<?= iN_HelpSecure($profileUrl, false); ?>"><?= iN_HelpSecure($fname, false); ?></a>
              <span> (@<?= iN_HelpSecure($uname, false); ?>)</span>
            </div>
            <div class="meta"><?= iN_HelpSecure($joined, false); ?></div>
          </div>
          <div class="activity-actions">
            <a href="<?= iN_HelpSecure($profileUrl, false); ?>"><?= iN_HelpSecure(customLang('admin_dashboard_profile') ?: 'Profile', false); ?></a>
            <a href="<?= iN_HelpSecure($adminUsersUrl, false); ?>"><?= iN_HelpSecure(customLang('admin_dashboard_edit') ?: 'Edit', false); ?></a>
            <a href="<?= iN_HelpSecure($adminUsersUrl, false); ?>" class="danger"><?= iN_HelpSecure(customLang('admin_dashboard_delete') ?: 'Delete', false); ?></a>
          </div>
        </li>
        <?php endforeach; ?>
      </ul>
    </div>

    <!-- Latest Subscriptions -->
    <div class="admin-card card list-card relative">
      <div class="list-header">
        <span class="icon"><?= renderVerifiedBadge($iconPath . 'subscription_fees.svg', true); ?></span>
        <span><strong><?= iN_HelpSecure(customLang('admin_dashboard_latest_subscriptions') ?: 'Latest subscriptions', false); ?></strong></span>
        <?php $urlAllSubs = ($base_url ?? '/') . 'admin/index.php?page=activity_subs'; ?>
        <a class="view-all" href="<?= iN_HelpSecure($urlAllSubs, false); ?>"><?= iN_HelpSecure(customLang('admin_dashboard_view_all') ?: 'View all', false); ?></a>
      </div>
      <ul class="activity-list">
        <?php foreach ($latestSubs as $s):
          $bUser = (string)($s['buyer_username'] ?? '');
          $bName = (string)($s['buyer_fullname'] ?? $bUser);
          $bAv   = admin_resolve_media_url((string)($s['buyer_avatar'] ?? 'uploads/user_avatars/default.jpeg'));

          $rUser = (string)($s['recip_username'] ?? '');
          $rName = (string)($s['recip_fullname'] ?? $rUser);
          $rAv   = admin_resolve_media_url((string)($s['recip_avatar'] ?? 'uploads/user_avatars/default.jpeg'));

          $when  = $fmtDate(isset($s['created_at']) ? (int)$s['created_at'] : null);
          $ival  = trim((string)($s['interval'] ?? ''));
          $icnt  = (int)($s['interval_cnt'] ?? 1);
          $planLabel = ($icnt > 1 ? ($icnt . 'x ') : '') . ($ival !== '' ? ucfirst($ival) : (customLang('admin_dashboard_plan_default') ?: 'Plan'));

          $bUrl  = ($base_url ?? '/') . 'profile/' . rawurlencode($bUser);
          $rUrl  = ($base_url ?? '/') . 'profile/' . rawurlencode($rUser);
          $detailUrl = ($base_url ?? '/') . 'admin/index.php?page=dashboard'; // placeholder
        ?>
        <li class="activity-item">
          <div class="avatar-stack-plus">
            <div class="avatar-main">
              <?php $subBuyerAlt = sprintf(customLang('admin_dashboard_avatar_of') ?: 'Avatar of %s', $bName); ?>
              <img class="main" src="<?= iN_HelpSecure($bAv, false); ?>" alt="<?= iN_HelpSecure($subBuyerAlt, false); ?>">
            </div>
            <div class="avatar-overlay">
              <?php $subRecAlt = sprintf(customLang('admin_dashboard_avatar_of') ?: 'Avatar of %s', $rName); ?>
              <img class="overlay" src="<?= iN_HelpSecure($rAv, false); ?>" alt="<?= iN_HelpSecure($subRecAlt, false); ?>">
            </div>
          </div>
          <div class="activity-body">
            <div class="title">
              <a href="<?= iN_HelpSecure($bUrl, false); ?>"><?= iN_HelpSecure($bName, false); ?></a>
              <span> <?= iN_HelpSecure(customLang('admin_dashboard_phrase_subscribed_to') ?: 'subscribed to', false); ?> </span>
              <a href="<?= iN_HelpSecure($rUrl, false); ?>"><?= iN_HelpSecure($rName, false); ?></a>
            </div>
            <div class="meta"><?= iN_HelpSecure($when, false); ?> · <?= iN_HelpSecure($planLabel, false); ?></div>
          </div>
          <div class="activity-actions">
            <a href="<?= iN_HelpSecure($detailUrl, false); ?>"><?= iN_HelpSecure(customLang('admin_dashboard_details') ?: 'Details', false); ?></a>
          </div>
        </li>
        <?php endforeach; ?>
      </ul>
    </div>

    <!-- Latest Tips -->
    <div class="admin-card card list-card relative">
      <div class="list-header">
        <span class="icon"><?= renderVerifiedBadge($iconPath . 'super_thanks.svg', true); ?></span>
        <span><strong><?= iN_HelpSecure(customLang('admin_dashboard_latest_tips') ?: 'Latest tips', false); ?></strong></span>
        <?php $urlAllTips = ($base_url ?? '/') . 'admin/index.php?page=activity_tips'; ?>
        <a class="view-all" href="<?= iN_HelpSecure($urlAllTips, false); ?>"><?= iN_HelpSecure(customLang('admin_dashboard_view_all') ?: 'View all', false); ?></a>
      </div>
      <ul class="activity-list">
        <?php foreach ($latestTips as $t):
          $bUser = (string)($t['buyer_username'] ?? '');
          $bName = (string)($t['buyer_fullname'] ?? $bUser);
          $bAv   = admin_resolve_media_url((string)($t['buyer_avatar'] ?? 'uploads/user_avatars/default.jpeg'));

          $rUser = (string)($t['recip_username'] ?? '');
          $rName = (string)($t['recip_fullname'] ?? $rUser);
          $rAv   = admin_resolve_media_url((string)($t['recip_avatar'] ?? 'uploads/user_avatars/default.jpeg'));

          $amt   = (float)($t['amount'] ?? 0);
          $cur   = (string)($t['currency'] ?? ($currency ?? 'USD'));
          $amtText = $fmtMoney($amt, $cur);
          $when  = $fmtDate(isset($t['created_at']) ? (int)$t['created_at'] : null);
          $postId= (int)($t['post_id'] ?? 0);
          $postUrl = ($base_url ?? '/') . 'posts/' . $postId . '/' . rawurlencode($rUser);

          $bUrl  = ($base_url ?? '/') . 'profile/' . rawurlencode($bUser);
          $rUrl  = ($base_url ?? '/') . 'profile/' . rawurlencode($rUser);
        ?>
        <li class="activity-item">
          <div class="avatar-stack-plus">
            <div class="avatar-main">
              <?php $tipBuyerAlt = sprintf(customLang('admin_dashboard_avatar_of') ?: 'Avatar of %s', $bName); ?>
              <img class="main" src="<?= iN_HelpSecure($bAv, false); ?>" alt="<?= iN_HelpSecure($tipBuyerAlt, false); ?>">
            </div>
            <div class="avatar-overlay">
              <?php $tipRecAlt = sprintf(customLang('admin_dashboard_avatar_of') ?: 'Avatar of %s', $rName); ?>
              <img class="overlay" src="<?= iN_HelpSecure($rAv, false); ?>" alt="<?= iN_HelpSecure($tipRecAlt, false); ?>">
            </div>
          </div>
          <div class="activity-body">
            <div class="title">
              <a href="<?= iN_HelpSecure($bUrl, false); ?>"><?= iN_HelpSecure($bName, false); ?></a>
              <span> <?= iN_HelpSecure(customLang('admin_dashboard_phrase_tipped') ?: 'tipped', false); ?> </span>
              <a href="<?= iN_HelpSecure($rUrl, false); ?>"><?= iN_HelpSecure($rName, false); ?></a>
              <span> <?= iN_HelpSecure($amtText, false); ?> </span>
            </div>
            <div class="meta"><?= iN_HelpSecure($when, false); ?> · <a href="<?= iN_HelpSecure($postUrl, false); ?>"><?= iN_HelpSecure(customLang('admin_dashboard_view_post') ?: 'View post', false); ?></a></div>
          </div>
        </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</section>
