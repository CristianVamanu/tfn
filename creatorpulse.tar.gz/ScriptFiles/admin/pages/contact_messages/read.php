<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';

$contactPageConfig = [
    'page_key'        => 'contact_messages_read',
    'title_key'       => 'admin_contact_messages_read',
    'default_status'  => 'read',
    'icon'            => 'view.svg',
    'empty_lang_key'  => 'admin_contact_messages_empty_read',
    'redirect_page'   => 'contact_messages_read',
];

require __DIR__ . '/list_common.php';
