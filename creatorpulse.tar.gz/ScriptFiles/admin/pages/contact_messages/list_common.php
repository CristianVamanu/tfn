<?php
declare(strict_types=1);

/**
 * Shared renderer for contact message listing pages.
 * Expects $contactPageConfig to be defined by the caller before including
 * this file. The host page MUST have already required _bootstrap.php.
 */

global $ADM, $base_url, $iconPath;

if (!isset($ADM) || !($ADM instanceof Admin_Data)) {
    throw new RuntimeException('Admin data layer not available.');
}

$config = $contactPageConfig ?? [];
unset($contactPageConfig);

$pageKey       = (string)($config['page_key'] ?? 'contact_messages_all');
$titleKey      = (string)($config['title_key'] ?? 'admin_contact_messages_all');
$pageTitle     = customLang($titleKey) ?: (string)($config['title'] ?? 'Contact Messages');
$defaultStatus = (string)($config['default_status'] ?? '');
$iconName      = (string)($config['icon'] ?? 'email.svg');
$emptyLangKey  = (string)($config['empty_lang_key'] ?? 'admin_contact_messages_empty_all');
$redirectPage  = (string)($config['redirect_page'] ?? $pageKey);

$q       = isset($_GET['q']) ? trim((string) $_GET['q']) : '';
$status  = isset($_GET['status']) ? strtolower(trim((string) $_GET['status'])) : '';
$msgType = isset($_GET['msg_type']) ? strtolower(trim((string) $_GET['msg_type'])) : '';
if ($status === '' && $defaultStatus !== '') {
    $status = $defaultStatus;
}
$page    = isset($_GET['page_no']) ? max(1, (int) $_GET['page_no']) : 1;
$per     = isset($_GET['per']) ? max(5, min(100, (int) $_GET['per'])) : 20;

$data  = $ADM->ADM_PagedContactMessages($q, $status, $msgType, $page, $per);
$rows  = $data['rows'];
$total = (int) $data['total'];
$pages = (int) max(1, (int) ceil($total / max(1, $per)));

$statusOptions = [
    ''         => customLang('contact_status_all') ?: 'All',
    'new'      => customLang('contact_status_new') ?: 'New',
    'read'     => customLang('contact_status_read') ?: 'Read',
    'resolved' => customLang('contact_status_resolved') ?: 'Resolved',
];

$typeDefaults = [
    'feedback'   => customLang('admin_contact_type_feedback') ?: 'Feedback',
    'complaint'  => customLang('admin_contact_type_complaint') ?: 'Complaint',
    'suggestion' => customLang('admin_contact_type_suggestion') ?: 'Suggestion',
    'bug'        => customLang('admin_contact_type_bug') ?: 'Bug',
];

$typeOptions = $typeDefaults;
try {
    $settingsStmt = $ADM->db()->query('SELECT subject_label_feedback, subject_label_complaint, subject_label_suggestion, subject_label_bug FROM i_mail_settings WHERE id = 1 LIMIT 1');
    if ($settingsStmt !== false) {
        $settingsRow = $settingsStmt->fetch(PDO::FETCH_ASSOC);
        if ($settingsRow !== false) {
            $typeOptions['feedback']   = (string) ($settingsRow['subject_label_feedback'] ?? $typeOptions['feedback']);
            $typeOptions['complaint']  = (string) ($settingsRow['subject_label_complaint'] ?? $typeOptions['complaint']);
            $typeOptions['suggestion'] = (string) ($settingsRow['subject_label_suggestion'] ?? $typeOptions['suggestion']);
            $typeOptions['bug']        = (string) ($settingsRow['subject_label_bug'] ?? $typeOptions['bug']);
        }
    }
} catch (Throwable $e) {
    if (defined('APP_DEBUG') && APP_DEBUG === true) {
        error_log('Load contact type labels failed: ' . $e->getMessage());
    }
}

$typeSelect = ['' => customLang('contact_type_all') ?: 'All'] + $typeOptions;

$statusClassMap = [
    'new'      => 'pill-amber',
    'read'     => 'pill-gray',
    'resolved' => 'pill-green',
];

$statusLabelMap = [
    'new'      => $statusOptions['new'],
    'read'     => $statusOptions['read'],
    'resolved' => $statusOptions['resolved'],
];

$baseProfileUrl = rtrim((string) ($base_url ?? ''), '/');
$emptyText      = customLang($emptyLangKey) ?: 'No contact messages found.';
$markToast      = customLang('admin_contact_mark_success') ?: 'Message marked as answered.';
$statusToastResolved = customLang('admin_contact_status_toast_resolved') ?: $markToast;
$statusToastNew      = customLang('admin_contact_status_toast_new') ?: 'Message moved to New.';
$statusToastRead     = customLang('admin_contact_status_toast_read') ?: 'Message marked as read.';
$deleteToast    = customLang('admin_contact_delete_success') ?: 'Message deleted.';
$confirmDelete  = customLang('admin_contact_delete_confirm') ?: 'Delete this message?';
$replyToast     = customLang('admin_contact_reply_success') ?: 'Reply sent successfully.';
$previewMoreLabel = customLang('admin_contact_preview_expand') ?: 'Show full message';
$previewLessLabel = customLang('admin_contact_preview_collapse') ?: 'Hide full message';

$replyActionLabel      = customLang('admin_contact_action_reply') ?: 'Reply';
$markNewActionLabel    = customLang('admin_contact_action_mark_new') ?: 'Mark as new';
$markReadActionLabel   = customLang('admin_contact_action_mark_read') ?: 'Mark as read';
$markResolvedActionLabel = customLang('admin_contact_action_mark_answered') ?: 'Mark as answered';
$deleteActionLabel     = customLang('admin_contact_action_delete') ?: 'Delete';
$cancelLabel           = customLang('pm_cancel') ?: 'Cancel';

$replyBaseUrl = rtrim($baseProfileUrl, '/') . '/admin/index.php?page=contact_reply';
// Ensure admin root path for redirects
$redirectUrl = rtrim($baseProfileUrl, '/') . '/admin/index.php?page=' . $redirectPage;
?>
<section
  class="card rounded-2xl"
  role="region"
  aria-labelledby="contactMessagesHeading"
  data-contact-table-root
  data-status-label-new="<?= iN_HelpSecure($statusOptions['new'], false); ?>"
  data-status-label-read="<?= iN_HelpSecure($statusOptions['read'], false); ?>"
  data-status-label-resolved="<?= iN_HelpSecure($statusOptions['resolved'], false); ?>"
  data-status-pill-new="pill-amber"
  data-status-pill-read="pill-gray"
  data-status-pill-resolved="pill-green"
  data-empty-text="<?= iN_HelpSecure($emptyText, false); ?>"
  data-toast-answered="<?= iN_HelpSecure($statusToastResolved, false); ?>"
  data-status-toast-new="<?= iN_HelpSecure($statusToastNew, false); ?>"
  data-status-toast-read="<?= iN_HelpSecure($statusToastRead, false); ?>"
  data-status-toast-resolved="<?= iN_HelpSecure($statusToastResolved, false); ?>"
  data-toast-deleted="<?= iN_HelpSecure($deleteToast, false); ?>"
  data-toast-replied="<?= iN_HelpSecure($replyToast, false); ?>"
  data-confirm-delete="<?= iN_HelpSecure($confirmDelete, false); ?>"
  data-reply-url="<?= iN_HelpSecure($replyBaseUrl, false); ?>"
  data-redirect-url="<?= iN_HelpSecure($redirectUrl, false); ?>"
  data-preview-more="<?= iN_HelpSecure($previewMoreLabel, false); ?>"
  data-preview-less="<?= iN_HelpSecure($previewLessLabel, false); ?>"
>
  <div class="list-header" id="contactMessagesHeading">
    <span class="icon"><?= renderVerifiedBadge($iconPath . $iconName, true); ?></span>
    <span><strong><?= iN_HelpSecure($pageTitle, false); ?></strong></span>
  </div>
  <form method="get" class="form-container form-container--columns" action="<?= iN_HelpSecure($base_url . 'admin/index.php', false); ?>">
    <input type="hidden" name="page" value="<?= iN_HelpSecure($pageKey, false); ?>">
    <div class="form-input-wrapper" data-field="search">
      <label class="form-label" for="contact-search"><?= iN_HelpSecure(customLang('admin_contact_messages_search_label') ?: 'Search', false); ?></label>
      <input
          id="contact-search"
          class="form-input"
          type="text"
          name="q"
          value="<?= iN_HelpSecure($q, false); ?>"
          placeholder="<?= iN_HelpSecure(customLang('admin_contact_messages_search_placeholder') ?: 'name, email, subject, message', false); ?>"
      >
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="contact-status"><?= iN_HelpSecure(customLang('admin_contact_messages_status_label') ?: 'Status', false); ?></label>
      <select id="contact-status" name="status" class="form-input">
        <?php foreach ($statusOptions as $value => $label): ?>
          <option value="<?= iN_HelpSecure($value, false); ?>"<?= $status === $value ? ' selected' : ''; ?>><?= iN_HelpSecure($label, false); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="contact-type"><?= iN_HelpSecure(customLang('admin_contact_messages_type_label') ?: 'Type', false); ?></label>
      <select id="contact-type" name="msg_type" class="form-input">
        <?php foreach ($typeSelect as $value => $label): ?>
          <option value="<?= iN_HelpSecure($value, false); ?>"<?= $msgType === $value ? ' selected' : ''; ?>><?= iN_HelpSecure($label, false); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="contact-per"><?= iN_HelpSecure(customLang('admin_contact_messages_per_page') ?: 'Per page', false); ?></label>
      <select id="contact-per" name="per" class="form-input">
        <?php foreach ([10, 20, 50, 100] as $pp): ?>
          <option value="<?= $pp; ?>"<?= $pp == $per ? ' selected' : ''; ?>><?= $pp; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper form-actions">
      <label class="form-label sr-only" for="contact-apply"><?= iN_HelpSecure(customLang('admin_contact_messages_apply') ?: 'Apply', false); ?></label>
      <button id="contact-apply" type="submit" class="pe-save btn-hover"><?= iN_HelpSecure(customLang('admin_contact_messages_apply') ?: 'Apply', false); ?></button>
    </div>
  </form>

  <div class="table-responsive mt-4">
    <table class="table table-striped table-sm table-subs" data-contact-messages-table>
      <thead>
        <tr>
          <th><?= iN_HelpSecure(customLang('admin_contact_messages_col_id') ?: 'ID', false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_contact_messages_col_sender') ?: 'Sender', false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_contact_messages_col_subject') ?: 'Subject', false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_contact_messages_col_type') ?: 'Type', false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_contact_messages_col_status') ?: 'Status', false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_contact_messages_col_received') ?: 'Received', false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_contact_messages_col_preview') ?: 'Message', false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_contact_messages_col_actions') ?: 'Actions', false); ?></th>
        </tr>
      </thead>
      <tbody>
      <?php if (empty($rows)): ?>
        <tr data-empty-row="true">
          <td colspan="8" class="text-center text-muted">
            <?= iN_HelpSecure($emptyText, false); ?>
          </td>
        </tr>
      <?php else: foreach ($rows as $row):
        $id        = (int) ($row['id'] ?? 0);
        $userId    = (int) ($row['user_id'] ?? 0);
        $username  = (string) ($row['user_username'] ?? '');
        $userName  = (string) ($row['user_fullname'] ?? $username);
        $name      = (string) ($row['name'] ?? '');
        $email     = (string) ($row['email'] ?? '');
        $subject   = (string) ($row['subject'] ?? '');
        $message   = (string) ($row['message'] ?? '');
        $msgTypeRaw= (string) ($row['msg_type'] ?? '');
        $statusRaw = (string) ($row['status'] ?? '');
        $createdAt = (string) ($row['created_at'] ?? '');
        $statusLabel = $statusLabelMap[$statusRaw] ?? ucfirst($statusRaw);
        $statusClass = $statusClassMap[$statusRaw] ?? 'pill-gray';
        $typeLabel   = $typeOptions[$msgTypeRaw] ?? ucfirst($msgTypeRaw);

        $profileLink = '';
        if ($userId > 0 && $username !== '' && $baseProfileUrl !== '') {
            $profileLink = $baseProfileUrl . '/profile/' . rawurlencode($username);
        }

        $createdDisplay = '-';
        if ($createdAt !== '') {
            try {
                $dt = new DateTimeImmutable($createdAt);
                $createdDisplay = $dt->format('d/m/Y H:i');
            } catch (Throwable $e) {
                $createdDisplay = $createdAt;
            }
        }

        $previewLimit = 140;
        if (function_exists('mb_strlen')) {
            $isPreviewTrimmed = mb_strlen($message) > $previewLimit;
            $messagePreview = $isPreviewTrimmed ? mb_substr($message, 0, $previewLimit) : $message;
        } else {
            $isPreviewTrimmed = strlen($message) > $previewLimit;
            $messagePreview = $isPreviewTrimmed ? substr($message, 0, $previewLimit) : $message;
        }
        $previewSuffix = $isPreviewTrimmed ? '…' : '';

        $displayName = $name !== '' ? $name : ($userName !== '' ? $userName : $email);
        $subjectForReply = $subject !== '' ? 'Re: ' . $subject : 'Re:';

        $replyHref = $replyBaseUrl;
        $joinChar = strpos($replyHref, '?') === false ? '?' : '&';
        $replyHref .= $joinChar . 'id=' . $id;
      ?>
        <tr data-message-id="<?= $id; ?>" data-status="<?= iN_HelpSecure($statusRaw, false); ?>">
          <td><?= $id; ?></td>
          <td>
            <div class="flex flexBoxColumn gap-4">
              <span class="fw-600"><?= iN_HelpSecure($displayName, false); ?></span>
              <?php if ($email !== ''): ?>
                <a href="mailto:<?= iN_HelpSecure($email, false); ?>" class="text-muted fs-13"><?= iN_HelpSecure($email, false); ?></a>
              <?php endif; ?>
              <?php if ($profileLink !== ''): ?>
                <a href="<?= iN_HelpSecure($profileLink, false); ?>" class="fs-13">@<?= iN_HelpSecure($username, false); ?></a>
              <?php endif; ?>
            </div>
          </td>
          <td><?= iN_HelpSecure($subject !== '' ? $subject : '-', false); ?></td>
          <td><?= iN_HelpSecure($typeLabel, false); ?></td>
          <td data-col="status">
            <span class="pill <?= iN_HelpSecure($statusClass, false); ?>" data-status-pill><?= iN_HelpSecure($statusLabel, false); ?></span>
          </td>
          <td class="text-muted fs-13"><?= iN_HelpSecure($createdDisplay, false); ?></td>
          <td>
            <div class="contact-message-preview" data-preview-root>
              <div data-preview-short><?= nl2br(iN_HelpSecure($messagePreview . $previewSuffix, false)); ?></div>
              <?php if ($isPreviewTrimmed): ?>
                <div class="contact-message-full mt-2" data-preview-full hidden><?= nl2br(iN_HelpSecure($message, false)); ?></div>
                <button
                  type="button"
                  class="btn-outline btn-sm mt-3"
                  data-preview-toggle
                  data-preview-state="more"
                ><?= iN_HelpSecure($previewMoreLabel, false); ?></button>
              <?php endif; ?>
            </div>
          </td>
          <td class="text-right">
            <div class="post-settings-btn-box flex align_items relative">
              <button
                type="button"
                class="post-settings-btn flex align_items_justify_content relative"
                aria-expanded="false"
                aria-haspopup="menu"
                title="<?= iN_HelpSecure(customLang('admin_contact_messages_col_actions') ?: 'Actions', false); ?>"
                data-id="<?= $id; ?>"
              >
                <?= renderVerifiedBadge($iconPath . 'dots.svg', false); ?>
              </button>
            </div>
            <div id="postMenuPopup-<?= $id; ?>" class="post-menu-popup none" aria-hidden="true" role="dialog" aria-label="<?= iN_HelpSecure('Contact message actions for #' . $id, false); ?>">
              <div class="pm-sheet-container">
                <div class="pm-sheet">
                  <a
                    class="pm-item flex align_items_justify_content gap js-contact-action"
                    data-contact-action="reply"
                    data-message-id="<?= $id; ?>"
                    data-email="<?= iN_HelpSecure($email, false); ?>"
                    data-subject="<?= iN_HelpSecure($subjectForReply, false); ?>"
                    data-reply-href="<?= iN_HelpSecure($replyHref, false); ?>"
                    href="<?= iN_HelpSecure($replyHref, false); ?>"
                  ><?= renderVerifiedBadge($iconPath . 'send.svg', true); ?> <span><?= iN_HelpSecure($replyActionLabel, false); ?></span></a>
                  <button
                    type="button"
                    class="pm-item flex align_items_justify_content gap js-contact-action"
                    data-contact-action="set-status"
                    data-message-id="<?= $id; ?>"
                    data-status-value="new"
                  ><?= renderVerifiedBadge($iconPath . 'time.svg', true); ?> <span><?= iN_HelpSecure($markNewActionLabel, false); ?></span></button>
                  <button
                    type="button"
                    class="pm-item flex align_items_justify_content gap js-contact-action"
                    data-contact-action="set-status"
                    data-message-id="<?= $id; ?>"
                    data-status-value="read"
                  ><?= renderVerifiedBadge($iconPath . 'view.svg', true); ?> <span><?= iN_HelpSecure($markReadActionLabel, false); ?></span></button>
                  <button
                    type="button"
                    class="pm-item flex align_items_justify_content gap js-contact-action"
                    data-contact-action="set-status"
                    data-message-id="<?= $id; ?>"
                    data-status-value="resolved"
                  ><?= renderVerifiedBadge($iconPath . 'tick.svg', true); ?> <span><?= iN_HelpSecure($markResolvedActionLabel, false); ?></span></button>
                  <button
                    type="button"
                    class="pm-item flex align_items_justify_content gap js-contact-action is-danger"
                    data-contact-action="delete"
                    data-message-id="<?= $id; ?>"
                  ><?= renderVerifiedBadge($iconPath . 'delete.svg', true); ?> <span><?= iN_HelpSecure($deleteActionLabel, false); ?></span></button>
                  <button type="button" class="pm-item pm-cancel"><?= iN_HelpSecure($cancelLabel, false); ?></button>
                </div>
              </div>
            </div>
          </td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <?php
    echo dz_render_pagination(
      $base_url . 'admin/index.php',
      [
        'page'     => $pageKey,
        'q'        => $q,
        'status'   => $status,
        'msg_type' => $msgType,
        'per'      => (string) $per,
      ],
      (int) $page,
      (int) $pages,
      [ 'show_goto' => true, 'radius' => 1 ]
    );
  ?>
</section>
