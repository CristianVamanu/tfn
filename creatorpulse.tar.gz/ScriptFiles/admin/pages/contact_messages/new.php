<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';

$contactPageConfig = [
    'page_key'        => 'contact_messages_new',
    'title_key'       => 'admin_contact_messages_new',
    'default_status'  => 'new',
    'icon'            => 'email.svg',
    'empty_lang_key'  => 'admin_contact_messages_empty_new',
    'redirect_page'   => 'contact_messages_new',
];

require __DIR__ . '/list_common.php';
