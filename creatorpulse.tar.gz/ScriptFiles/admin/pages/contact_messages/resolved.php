<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';

$contactPageConfig = [
    'page_key'        => 'contact_messages_resolved',
    'title_key'       => 'admin_contact_messages_resolved',
    'default_status'  => 'resolved',
    'icon'            => 'tick.svg',
    'empty_lang_key'  => 'admin_contact_messages_empty_resolved',
    'redirect_page'   => 'contact_messages_resolved',
];

require __DIR__ . '/list_common.php';
