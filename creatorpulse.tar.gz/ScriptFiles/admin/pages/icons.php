<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $ADM, $base_url, $ADMIN_CSRF, $iconPath, $currentTheme;

if (!function_exists('_admin_icon_handle_upload')) {
    /**
     * Process an uploaded icon file and move it under uploads/icons.
     *
     * @return array{status:string,message?:string,path?:string}
     */
    function _admin_icon_handle_upload(?array $file, string $iconKey, string $targetDir, string $publicBase): array
    {
        if (!is_array($file) || !isset($file['error'])) {
            return ['status' => 'skip'];
        }

        $error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error === UPLOAD_ERR_NO_FILE) {
            return ['status' => 'skip'];
        }
        if ($error !== UPLOAD_ERR_OK) {
            return ['status' => 'error', 'message' => 'upload_failed'];
        }

        $tmpName = (string) ($file['tmp_name'] ?? '');
        if ($tmpName === '' || !is_uploaded_file($tmpName)) {
            return ['status' => 'error', 'message' => 'upload_invalid_tmp'];
        }

        $size = (int) ($file['size'] ?? 0);
        $maxSize = 2 * 1024 * 1024; // 2 MB safety cap for icons
        if ($size > $maxSize) {
            return ['status' => 'error', 'message' => 'upload_too_large'];
        }

        $originalName = (string) ($file['name'] ?? '');
        $ext = strtolower((string) pathinfo($originalName, PATHINFO_EXTENSION));
        $allowed = ['svg', 'png', 'jpg', 'jpeg', 'webp', 'gif'];
        if (!in_array($ext, $allowed, true)) {
            return ['status' => 'error', 'message' => 'upload_invalid_type'];
        }

        if ($ext === 'svg') {
            $raw = (string) file_get_contents($tmpName);
            if ($raw === '' || preg_match('~<(script|iframe|object|embed|link)\b~i', $raw) || preg_match('~on[a-z]+\s*=~i', $raw)) {
                return ['status' => 'error', 'message' => 'upload_svg_disallowed'];
            }
        }

        if (!is_dir($targetDir)) {
            if (!mkdir($targetDir, 0755, true) && !is_dir($targetDir)) {
                return ['status' => 'error', 'message' => 'upload_path_unwritable'];
            }
        }

        $base = $iconKey !== '' ? preg_replace('~[^a-z0-9_-]+~i', '-', $iconKey) : 'icon';
        $base = $base !== '' ? strtolower($base) : 'icon';
        try {
            $suffix = bin2hex(random_bytes(5));
        } catch (Throwable $__) {
            $suffix = substr(hash('sha256', microtime(true) . $base), 0, 10);
        }
        $filename = $base . '-' . $suffix . '.' . $ext;
        $destination = rtrim($targetDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $filename;

        if (!move_uploaded_file($tmpName, $destination)) {
            return ['status' => 'error', 'message' => 'upload_move_failed'];
        }

        return [
            'status' => 'success',
            'path'   => trim($publicBase, '/') . '/' . $filename,
        ];
    }
}

if (!function_exists('_admin_icon_normalize_input_path')) {
    /** Normalize a submitted path by trimming base URL prefixes. */
    function _admin_icon_normalize_input_path(string $path, string $baseUrl): string
    {
        $path = trim($path);
        if ($path === '') {
            return '';
        }
        $baseUrl = rtrim($baseUrl, '/');
        if ($baseUrl !== '' && stripos($path, $baseUrl) === 0) {
            $path = substr($path, strlen($baseUrl));
        }
        return ltrim($path, '/');
    }
}

if (!function_exists('_admin_icon_try_delete_file')) {
    /** Remove a stored icon file when it lives under uploads/icons. */
    function _admin_icon_try_delete_file(string $storedPath, string $projectRoot, string $publicBase): void
    {
        $publicBase = trim($publicBase, '/');
        if ($publicBase === '') {
            return;
        }

        $path = trim($storedPath);
        if ($path === '') {
            return;
        }
        $parsed = parse_url($path, PHP_URL_PATH);
        if (is_string($parsed) && $parsed !== '') {
            $path = $parsed;
        }

        $relative = ltrim($path, '/');
        if ($relative === '' || strpos($relative, $publicBase . '/') !== 0) {
            return;
        }

        $full = rtrim($projectRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
        if (is_file($full)) {
            @unlink($full);
        }
    }
}

if (!function_exists('_admin_icon_lang')) {
    /**
     * Resolve a translation key with a fallback when the key is missing.
     */
    function _admin_icon_lang(string $key, string $fallback): string
    {
        global $lang;

        $value = (string) customLang($key);
        $hasTranslation = is_array($lang ?? null) && array_key_exists($key, $lang);

        if ($value === '' || !$hasTranslation) {
            return $fallback;
        }

        return $value;
    }
}

if (!function_exists('_admin_icon_format')) {
    /**
     * Replace placeholders such as {{key}} or printf tokens with provided values.
     */
    function _admin_icon_format(string $key, string $fallback, array $replacements): string
    {
        $template = _admin_icon_lang($key, $fallback);
        $didReplace = false;

        foreach ($replacements as $name => $value) {
            $placeholder = '{{' . $name . '}}';
            $valueString = is_scalar($value) || $value === null ? (string) $value : '';
            if (strpos($template, $placeholder) !== false) {
                $template = str_replace($placeholder, $valueString, $template);
                $didReplace = true;
            }
        }

        if (preg_match('/%\d*\$?[bcdeEfFgGosuxX]/', $template) === 1) {
            $sprintfArgs = array_map(static function ($val) {
                return is_scalar($val) || $val === null ? (string) $val : '';
            }, array_values($replacements));
            $formatted = @vsprintf($template, $sprintfArgs);
            if ($formatted !== false) {
                $template = $formatted;
                $didReplace = true;
            }
        }

        if (!$didReplace && !empty($replacements)) {
            $suffix = array_map(static function ($val) {
                return is_scalar($val) || $val === null ? (string) $val : '';
            }, array_values($replacements));
            $template = trim($template . ' ' . implode(' ', $suffix));
        }

        return $template;
    }
}

if (!function_exists('_admin_icon_normalize_key')) {
    /**
     * Sanitize an incoming icon key, transliterating locale-specific characters and enforcing allowed set.
     */
    function _admin_icon_normalize_key(string $rawKey, string $fallback = 'icon'): string
    {
        $rawKey = trim($rawKey);
        if ($rawKey === '') {
            $rawKey = $fallback;
        }

        $candidate = $rawKey;

        if (class_exists(Transliterator::class)) {
            $transliterator = Transliterator::create('Any-Latin; Latin-ASCII');
            if ($transliterator instanceof Transliterator) {
                $converted = $transliterator->transliterate($candidate);
                if (is_string($converted) && $converted !== '') {
                    $candidate = $converted;
                }
            }
        } else {
            $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $candidate);
            if (is_string($converted) && $converted !== '') {
                $candidate = $converted;
            }
        }

        $candidate = strtolower((string) $candidate);
        $candidate = preg_replace('~[\s]+~', '-', $candidate ?? '') ?? '';
        $candidate = preg_replace('~[^a-z0-9_.-]+~', '-', $candidate) ?? '';
        $candidate = preg_replace('~[-_.]{2,}~', '-', $candidate) ?? '';
        $candidate = trim($candidate, '-_.');

        if ($candidate === '') {
            $candidate = $fallback;
        }

        return icon_asset_key($candidate);
    }
}

$projectRoot = dirname(__DIR__, 2);
$themeSlug   = is_string($currentTheme) && $currentTheme !== ''
    ? preg_replace('~[^a-z0-9_-]+~i', '', $currentTheme)
    : 'default';
if ($themeSlug === '') {
    $themeSlug = 'default';
}
$uploadDir  = $projectRoot . '/themes/' . $themeSlug . '/icons';
$publicBase = 'themes/' . $themeSlug . '/icons';
$redirectUrl = rtrim((string) ($base_url ?? ''), '/') . '/admin/index.php?page=icons';

$flash = $_SESSION['admin_icon_flash'] ?? null;
unset($_SESSION['admin_icon_flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? (string) $_POST['action'] : '';
    $csrf   = isset($_POST['csrf_token']) ? (string) $_POST['csrf_token'] : '';

    if (!checkCsrfToken($csrf)) {
        $_SESSION['admin_icon_flash'] = [
            'type'    => 'error',
            'message' => _admin_icon_lang('invalid_csrf_token', 'Invalid CSRF token. Please try again.'),
        ];
        header('Location: ' . $redirectUrl);
        exit;
    }

    $baseMsg = static function (string $key, string $fallback): string {
        return _admin_icon_lang($key, $fallback);
    };

    switch ($action) {
        case 'create':
            $iconKeyRaw = (string) ($_POST['icon_key'] ?? '');
            $iconKey    = _admin_icon_normalize_key($iconKeyRaw, 'icon');
            $pathInput  = _admin_icon_normalize_input_path((string) ($_POST['file_path'] ?? ''), (string) ($base_url ?? ''));

            if ($iconKey === '') {
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'error',
                    'message' => $baseMsg('admin_icons_error_key_required', 'Icon key is required.'),
                ];
                break;
            }

            $uploadResult = _admin_icon_handle_upload($_FILES['file_upload'] ?? null, $iconKey, $uploadDir, $publicBase);
            if (($uploadResult['status'] ?? '') === 'error') {
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'error',
                    'message' => $baseMsg('admin_icons_upload_error_' . $uploadResult['message'], 'Failed to upload icon file.'),
                ];
                break;
            }

            $finalPath = $pathInput;
            if (($uploadResult['status'] ?? '') === 'success') {
                $finalPath = (string) $uploadResult['path'];
            }

            if ($finalPath === '') {
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'error',
                    'message' => $baseMsg('admin_icons_error_path_required', 'Provide an icon file or enter a file path/URL.'),
                ];
                break;
            }

            $result = $ADM->ADM_CreateIcon($iconKey, $finalPath);
            if (($result['status'] ?? '') === 'success') {
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'success',
                    'message' => _admin_icon_format('admin_icons_created', 'Icon "%s" created successfully.', ['key' => $iconKey]),
                ];
            } else {
                $code = (string) ($result['message'] ?? 'db_error');
                $msgMap = [
                    'duplicate_key'   => $baseMsg('admin_icons_error_duplicate_key', 'Icon key already exists.'),
                    'invalid_params'  => $baseMsg('admin_icons_error_invalid_params', 'Invalid icon parameters supplied.'),
                    'db_insert_failed'=> $baseMsg('admin_icons_error_database', 'Unable to save the icon. Please try again.'),
                ];
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'error',
                    'message' => $msgMap[$code] ?? $baseMsg('admin_icons_error_generic', 'Unable to save the icon. Please try again.'),
                ];
            }
            break;

        case 'update':
            $iconId    = (int) ($_POST['icon_id'] ?? 0);
            $icon      = $ADM->ADM_GetIconById($iconId);
            if (!$icon) {
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'error',
                    'message' => $baseMsg('admin_icons_error_not_found', 'Icon was not found.'),
                ];
                break;
            }

            $iconKeyRaw = (string) ($_POST['icon_key'] ?? '');
            $iconKey    = _admin_icon_normalize_key($iconKeyRaw, 'icon');
            $pathInput  = _admin_icon_normalize_input_path((string) ($_POST['file_path'] ?? ''), (string) ($base_url ?? ''));
            $keepAlias  = isset($_POST['keep_alias']) && (string) $_POST['keep_alias'] === '1';

            if ($iconKey === '') {
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'error',
                    'message' => $baseMsg('admin_icons_error_key_required', 'Icon key is required.'),
                ];
                break;
            }

            $uploadResult = _admin_icon_handle_upload($_FILES['file_upload'] ?? null, $iconKey, $uploadDir, $publicBase);
            if (($uploadResult['status'] ?? '') === 'error') {
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'error',
                    'message' => $baseMsg('admin_icons_upload_error_' . $uploadResult['message'], 'Failed to upload icon file.'),
                ];
                break;
            }

            $finalPath = $pathInput !== '' ? $pathInput : null;
            if (($uploadResult['status'] ?? '') === 'success') {
                $finalPath = (string) $uploadResult['path'];
            }

            $result = $ADM->ADM_UpdateIcon($iconId, $iconKey, $finalPath, $keepAlias);
            $status = (string) ($result['status'] ?? 'error');

            if ($status === 'success') {
                if (($uploadResult['status'] ?? '') === 'success') {
                    _admin_icon_try_delete_file((string) ($icon['file_path'] ?? ''), $projectRoot, $publicBase);
                }
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'success',
                    'message' => _admin_icon_format('admin_icons_updated', 'Icon "%s" updated.', ['key' => $iconKey]),
                ];
            } elseif ($status === 'noop') {
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'info',
                    'message' => _admin_icon_lang('admin_icons_no_changes', 'No changes detected for this icon.'),
                ];
            } else {
                $code = (string) ($result['message'] ?? 'db_error');
                $msgMap = [
                    'duplicate_key'     => $baseMsg('admin_icons_error_duplicate_key', 'Icon key already exists.'),
                    'invalid_params'    => $baseMsg('admin_icons_error_invalid_params', 'Invalid icon parameters supplied.'),
                    'invalid_path'      => $baseMsg('admin_icons_error_path_required', 'Provide a valid file path.'),
                    'db_update_failed'  => $baseMsg('admin_icons_error_database', 'Unable to update the icon. Please try again.'),
                ];
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'error',
                    'message' => $msgMap[$code] ?? $baseMsg('admin_icons_error_generic', 'Unable to update the icon. Please try again.'),
                ];
            }
            break;

        case 'delete':
            $iconId = (int) ($_POST['icon_id'] ?? 0);
            $icon   = $ADM->ADM_GetIconById($iconId);
            if (!$icon) {
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'error',
                    'message' => $baseMsg('admin_icons_error_not_found', 'Icon was not found.'),
                ];
                break;
            }

            $result = $ADM->ADM_DeleteIcon($iconId);
            if (($result['status'] ?? '') === 'success') {
                _admin_icon_try_delete_file((string) ($icon['file_path'] ?? ''), $projectRoot, $publicBase);
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'success',
                    'message' => _admin_icon_format('admin_icons_deleted', 'Icon "%s" deleted.', ['key' => (string) ($icon['icon_key'] ?? '')]),
                ];
            } else {
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'error',
                    'message' => $baseMsg('admin_icons_error_generic', 'Unable to delete the icon. Please try again.'),
                ];
            }
            break;

        case 'delete_alias':
            $iconId   = (int) ($_POST['icon_id'] ?? 0);
            $aliasKey = icon_asset_key((string) ($_POST['alias_key'] ?? ''));
            if ($iconId <= 0 || $aliasKey === '') {
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'error',
                    'message' => $baseMsg('admin_icons_error_invalid_params', 'Invalid icon parameters supplied.'),
                ];
                break;
            }
            if ($ADM->ADM_DeleteIconAlias($iconId, $aliasKey)) {
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'success',
                    'message' => _admin_icon_format('admin_icons_alias_removed', 'Alias "%s" removed.', ['alias' => $aliasKey]),
                ];
            } else {
                $_SESSION['admin_icon_flash'] = [
                    'type'    => 'error',
                    'message' => $baseMsg('admin_icons_error_generic', 'Unable to update aliases. Please try again.'),
                ];
            }
            break;

        default:
            $_SESSION['admin_icon_flash'] = [
                'type'    => 'error',
                'message' => $baseMsg('admin_icons_error_invalid_action', 'Unknown action requested.'),
            ];
            break;
    }

    header('Location: ' . $redirectUrl);
    exit;
}

$allIcons = $ADM->ADM_GetIcons();
$totalIconsAll = count($allIcons);

$searchQuery = trim((string) ($_GET['q'] ?? ''));
$perOptions  = [12, 24, 48];
$per         = isset($_GET['per']) ? (int) $_GET['per'] : 12;
if (!in_array($per, $perOptions, true)) {
    $per = 12;
}

$pageNo = isset($_GET['page_no']) ? max(1, (int) $_GET['page_no']) : 1;

$filteredIcons = $allIcons;
if ($searchQuery !== '') {
    $filteredIcons = array_values(array_filter($allIcons, static function ($icon) use ($searchQuery): bool {
        $haystack = [
            (string) ($icon['icon_key'] ?? ''),
            (string) ($icon['file_path'] ?? ''),
        ];
        if (!empty($icon['aliases']) && is_array($icon['aliases'])) {
            foreach ($icon['aliases'] as $alias) {
                $haystack[] = (string) $alias;
            }
        }
        foreach ($haystack as $field) {
            if ($field !== '' && stripos($field, $searchQuery) !== false) {
                return true;
            }
        }
        return false;
    }));
}

$total = count($filteredIcons);
$per = max(1, $per);
$pages = (int) max(1, ceil($total / $per));
if ($pageNo > $pages) {
    $pageNo = $pages;
}
$offset = max(0, ($pageNo - 1) * $per);
$icons = array_slice($filteredIcons, $offset, $per);

$showFrom = $total > 0 ? $offset + 1 : 0;
$showTo   = $total > 0 ? min($offset + $per, $total) : 0;
$hasSearch = $searchQuery !== '';

$resolvedBaseUrl = rtrim((string) ($base_url ?? ''), '/');

$flashType = isset($flash['type']) ? (string) $flash['type'] : '';
$flashMsg  = isset($flash['message']) ? (string) $flash['message'] : '';

$createHeading = _admin_icon_lang('admin_icons_create_heading', 'Add a new icon');
$listHeading   = _admin_icon_lang('admin_icons_existing_heading', 'Existing icons');
$aliasesLabel  = _admin_icon_lang('admin_icons_aliases_label', 'Aliases (legacy keys):');
$deleteConfirm = _admin_icon_lang('admin_icons_delete_confirm', 'Delete this icon? This action cannot be undone.');
$aliasConfirm  = _admin_icon_lang('admin_icons_alias_delete_confirm', 'Remove this alias? Existing templates using it will stop working.');
$uploadHint    = _admin_icon_lang('admin_icons_upload_hint', 'Allowed: SVG, PNG, JPG, WEBP (max 2 MB). SVGs are sanitized automatically.');
$keepAliasHint = _admin_icon_lang('admin_icons_keep_alias_hint', 'Preserve the previous key as an alias so existing templates keep working.');

$singleTotalLabel = _admin_icon_lang('admin_icons_single_total', '1 icon stored.');
if (strpos($singleTotalLabel, '{{count}}') !== false) {
    $singleTotalLabel = str_replace('{{count}}', '1', $singleTotalLabel);
}

$manyTotalTemplate = _admin_icon_lang('admin_icons_many_total', '{{count}} icons stored.');
if (strpos($manyTotalTemplate, '{{count}}') !== false) {
    $manyTotalLabel = str_replace('{{count}}', (string) $totalIconsAll, $manyTotalTemplate);
} elseif (preg_match('/%\d*\$?[bcdeEfFgGosuxX]/', $manyTotalTemplate) === 1) {
    $manyTotalLabel = sprintf($manyTotalTemplate, $totalIconsAll);
} else {
    $manyTotalLabel = trim($manyTotalTemplate . ' ' . $totalIconsAll);
}

$iconCountLabel = $totalIconsAll === 1 ? $singleTotalLabel : $manyTotalLabel;

$editLabel           = _admin_icon_lang('admin_icons_edit_button', 'Edit');
$modalHeading        = _admin_icon_lang('admin_icons_modal_heading', 'Edit icon');
$modalHint           = _admin_icon_lang('admin_icons_modal_hint', 'Update the icon key or upload a replacement, then save your changes.');
$modalPublicLabel    = _admin_icon_lang('admin_icons_public_url', 'Public URL');
$modalCreatedLabel   = _admin_icon_lang('admin_icons_created_at', 'Created');
$modalUpdatedLabel   = _admin_icon_lang('admin_icons_updated_at', 'Updated');
$modalAliasesLabel   = _admin_icon_lang('admin_icons_aliases_heading', 'Aliases');
$modalNoAliasesLabel = _admin_icon_lang('admin_icons_aliases_empty', '—');
$modalKeepAliasLabel = _admin_icon_lang('admin_icons_keep_alias_label', 'Keep previous key as alias');
$modalCloseLabel     = _admin_icon_lang('cancel', 'Cancel');
$modalSaveLabel      = _admin_icon_lang('admin_icons_update_button', 'Update icon');
$modalDeleteLabel    = _admin_icon_lang('admin_icons_delete_button', 'Delete icon');
$idLabel             = _admin_icon_lang('ID', 'ID');
$iconColumnLabel     = _admin_icon_lang('admin_icons_column_icon', 'Icon');
$keyLabel            = _admin_icon_lang('admin_icons_column_key', 'Key');
$publicLabel         = _admin_icon_lang('admin_icons_public_url', 'Public URL');
$publicOpenLabel     = _admin_icon_lang('admin_icons_public_open', 'View public URL');
$publicDialogHeading = _admin_icon_lang('admin_icons_public_dialog_heading', 'Icon public URL');
$publicDialogHint    = _admin_icon_lang('admin_icons_public_dialog_hint', 'Use this link to preview the icon or reference it in templates.');
$publicDialogOpen    = _admin_icon_lang('admin_icons_public_dialog_open', 'Open in new tab');
$aliasHeadingLabel   = _admin_icon_lang('admin_icons_aliases_heading', 'Aliases');
$updatedLabel        = _admin_icon_lang('admin_icons_updated_at', 'Updated');
$actionsLabel        = _admin_icon_lang('admin_icons_actions', 'Actions');

$iconTitle    = _admin_icon_lang('admin_icons_title', 'Icons Library');
$iconIntro    = _admin_icon_lang('admin_icons_intro', 'Manage the icon registry stored in the database. Add new entries, upload replacements, or retire unused icons. Theme helpers resolve icons from this list and fall back to the legacy theme directory if nothing matches.');
$emptyState   = _admin_icon_lang('admin_icons_empty_state', 'No icons are stored yet. Add one using the form above.');
$emptySearchMessage = _admin_icon_lang('admin_icons_empty_search', 'No icons match your search.');
$searchLabel        = _admin_icon_lang('admin_icons_search_label', 'Search icons');
$searchPlaceholder  = _admin_icon_lang('admin_icons_search_placeholder', 'Search by key, alias, or path');
$searchButtonLabel  = _admin_icon_lang('admin_icons_search_button', 'Search');
$perPageLabel       = _admin_icon_lang('admin_icons_per_page', 'Per page');
$resultsSummary     = $total > 0
    ? _admin_icon_format('admin_icons_results_summary', 'Showing {{from}}–{{to}} of {{total}} icons.', [
        'from'  => (string) $showFrom,
        'to'    => (string) $showTo,
        'total' => (string) $total,
    ])
    : '';

$emptyMessage = $hasSearch ? $emptySearchMessage : $emptyState;

$keyFieldLabel      = _admin_icon_lang('admin_icons_key_label', 'Icon key');
$keyFieldHint       = _admin_icon_lang('admin_icons_key_hint', 'Lowercase letters, numbers, dots, underscores, and hyphens only.');
$keyPlaceholder     = _admin_icon_lang('admin_icons_key_placeholder', 'verified');
$uploadLabel        = _admin_icon_lang('admin_icons_upload_label', 'Upload Icon');
$createButtonLabel  = _admin_icon_lang('admin_icons_create_button', 'Save icon');
?>
<section class="card rounded-2xl" role="region" aria-labelledby="adminIconsHeading">
  <div class="list-header" id="adminIconsHeading">
    <span class="icon"><?= render_icon('grid_view', true); ?></span>
    <span><strong><?= iN_HelpSecure($iconTitle); ?></strong></span>
  </div>

  <p class="box-note full-width margin-top"><?= iN_HelpSecure($iconIntro); ?></p>
  <div class="kpi-amount margin-top-bottom"><?= iN_HelpSecure($iconCountLabel); ?></div>

  <?php if ($flashMsg !== ''): ?>
    <?php
      $flashClass = 'admin-alert';
      if ($flashType === 'success') {
          $flashClass .= ' admin-alert--success';
      } elseif ($flashType === 'error') {
          $flashClass .= ' admin-alert--error';
      } elseif ($flashType === 'info') {
          $flashClass .= ' admin-alert--info';
      } else {
          $flashClass .= ' admin-alert--muted';
      }
    ?>
    <div class="<?= $flashClass; ?>" role="status"><?= iN_HelpSecure($flashMsg); ?></div>
  <?php endif; ?>

  <form class="icon-form card-section" method="post" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?= iN_HelpSecure($ADMIN_CSRF, false); ?>">
    <input type="hidden" name="action" value="create">

    <h2 class="section-title"><?= iN_HelpSecure($createHeading); ?></h2>
    <div class="form-grid form-grid--half">
      <div class="form-input-wrapper">
        <label class="form-label" for="icon_key"><?= iN_HelpSecure($keyFieldLabel); ?></label>
        <input id="icon_key" class="form-input" type="text" name="icon_key" maxlength="100" placeholder="<?= iN_HelpSecure($keyPlaceholder, false); ?>" required>
        <p class="form-text text-muted fs-13"><?= iN_HelpSecure($keyFieldHint); ?></p>
      </div>
      <div class="form-input-wrapper">
        <label class="form-label" for="icon_file_upload"><?= iN_HelpSecure($uploadLabel); ?></label>
        <label class="mix-upload pseudo-input" for="icon_file_upload">
          <span class="mix-upload__icon" aria-hidden="true"><?= render_icon('upload_icon', true); ?></span>
          <span class="mix-upload__label"><?= iN_HelpSecure($uploadLabel); ?></span>
          <input id="icon_file_upload" class="mix-upload__input" type="file" name="file_upload" accept=".svg,.png,.jpg,.jpeg,.webp,.gif" required>
        </label>
        <p class="form-text text-muted fs-13 mix-upload__hint mix-upload__hint--note"><?= iN_HelpSecure($uploadHint); ?></p>
      </div>
    </div>


    <div class="form-actions">
      <button class="admin-button admin-button--primary" type="submit"><?= iN_HelpSecure($createButtonLabel); ?></button>
    </div>
  </form>

  <hr class="icon-manager-divider">

  <h2 class="section-title"><?= iN_HelpSecure($listHeading); ?></h2>

  <form class="form-container form-container--columns icon-filter-form" method="get" action="<?= iN_HelpSecure($resolvedBaseUrl . '/admin/index.php', false); ?>">
    <input type="hidden" name="page" value="icons">
    <input type="hidden" name="page_no" value="1">
    <div class="form-input-wrapper" data-field="search">
      <label class="form-label" for="iconSearch"><?= iN_HelpSecure($searchLabel); ?></label>
      <input id="iconSearch" class="form-input" type="search" name="q" value="<?= iN_HelpSecure($searchQuery, false); ?>" placeholder="<?= iN_HelpSecure($searchPlaceholder, false); ?>">
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="iconPer"><?= iN_HelpSecure($perPageLabel); ?></label>
      <select id="iconPer" class="form-input" name="per">
        <?php foreach ($perOptions as $option): ?>
          <option value="<?= $option; ?>"<?= $option === $per ? ' selected' : ''; ?>><?= $option; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper form-actions">
      <label class="form-label sr-only" for="iconSearchSubmit"><?= iN_HelpSecure($searchButtonLabel); ?></label>
      <button type="submit" id="iconSearchSubmit" class="pe-save btn-hover"><?= iN_HelpSecure($searchButtonLabel); ?></button>
    </div>
  </form>

  <?php if ($resultsSummary !== ''): ?>
    <p class="form-text text-muted fs-13 icon-results-summary"><?= iN_HelpSecure($resultsSummary); ?></p>
  <?php endif; ?>

  <div class="table-responsive mt-4">
    <table
      class="table table-striped table-sm table-subs full-width admin-icons-table"
      role="table"
      aria-label="<?= iN_HelpSecure($listHeading); ?>"
      data-icon-table="1"
      data-modal-target="iconEditDialog"
      data-delete-confirm="<?= iN_HelpSecure($deleteConfirm, false); ?>"
    >
      <thead>
        <tr>
          <th scope="col"><?= iN_HelpSecure($idLabel); ?></th>
          <th scope="col"><?= iN_HelpSecure($iconColumnLabel); ?></th>
          <th scope="col"><?= iN_HelpSecure($keyLabel); ?></th>
          <th scope="col"><?= iN_HelpSecure($publicLabel); ?></th>
          <th scope="col"><?= iN_HelpSecure($aliasHeadingLabel); ?></th>
          <th scope="col"><?= iN_HelpSecure($updatedLabel); ?></th>
          <th scope="col"><?= iN_HelpSecure($actionsLabel); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php if ($total === 0): ?>
          <tr data-icon-empty="1">
            <td colspan="7" class="text-center text-muted"><?= iN_HelpSecure($emptyMessage); ?></td>
          </tr>
        <?php else: ?>
          <?php foreach ($icons as $icon):
            $iconId      = (int) ($icon['id'] ?? 0);
            $iconKey     = (string) ($icon['icon_key'] ?? '');
            $aliases     = isset($icon['aliases']) && is_array($icon['aliases']) ? $icon['aliases'] : [];
            $publicUrl   = icon_public_url($iconKey, icon_theme_fallback($iconKey));
            $createdAt   = (string) ($icon['created_at'] ?? '');
            $updatedAt   = (string) ($icon['updated_at'] ?? '');

            $createdAtLabel = '—';
            if ($createdAt !== '' && ($__ts = strtotime($createdAt)) !== false) {
                $createdAtLabel = date('Y-m-d H:i', $__ts);
            }
            $updatedAtLabel = '—';
            if ($updatedAt !== '' && ($__tu = strtotime($updatedAt)) !== false) {
                $updatedAtLabel = date('Y-m-d H:i', $__tu);
            }

            $aliasJson   = htmlspecialchars(json_encode(array_values($aliases), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
            $menuLabel   = _admin_icon_format('admin_icons_row_actions_label', 'Actions for icon %s', ['key' => $iconKey]);
          ?>
          <tr
            data-icon-row
            data-icon-id="<?= $iconId; ?>"
            data-icon-key="<?= iN_HelpSecure($iconKey, false); ?>"
            data-icon-public="<?= iN_HelpSecure($publicUrl, false); ?>"
            data-icon-created="<?= iN_HelpSecure($createdAtLabel, false); ?>"
            data-icon-updated="<?= iN_HelpSecure($updatedAtLabel, false); ?>"
            data-icon-aliases='<?= $aliasJson; ?>'
          >
            <td class="text-muted fs-13" data-label="<?= iN_HelpSecure($idLabel); ?>"><?= $iconId; ?></td>
            <td data-label="<?= iN_HelpSecure($iconColumnLabel); ?>">
              <span id="iconPreview-<?= $iconId; ?>" class="icon-manager-preview icon-manager-preview--table" data-icon-preview aria-hidden="true">
                <?= render_icon($iconKey, true); ?>
              </span>
            </td>
            <td data-label="<?= iN_HelpSecure($keyLabel); ?>">
              <code class="icon-manager-code" data-icon-key-label><?= iN_HelpSecure($iconKey); ?></code>
            </td>
            <td data-label="<?= iN_HelpSecure($publicLabel); ?>">
              <button
                type="button"
                class="icon-manager-url-button"
                data-role="icon-url"
                data-url="<?= iN_HelpSecure($publicUrl, false); ?>"
                aria-label="<?= iN_HelpSecure($publicOpenLabel); ?>"
              >
                <?= render_icon('link', true); ?>
                <span class="sr-only"><?= iN_HelpSecure($publicOpenLabel); ?></span>
              </button>
            </td>
            <td data-label="<?= iN_HelpSecure($aliasHeadingLabel); ?>">
              <?php if (!empty($aliases)): ?>
                <div class="icon-manager-aliases" role="list">
                  <?php foreach ($aliases as $alias):
                    $aliasRemoveLabel = _admin_icon_format('admin_icons_alias_remove_label', 'Remove alias %s', ['alias' => $alias]);
                  ?>
                    <form method="post" class="icon-manager-alias" role="listitem" data-confirm="<?= iN_HelpSecure($aliasConfirm); ?>">
                      <input type="hidden" name="csrf_token" value="<?= iN_HelpSecure($ADMIN_CSRF, false); ?>">
                      <input type="hidden" name="action" value="delete_alias">
                      <input type="hidden" name="icon_id" value="<?= $iconId; ?>">
                      <input type="hidden" name="alias_key" value="<?= iN_HelpSecure($alias, false); ?>">
                      <span class="icon-manager-alias__text"><?= iN_HelpSecure($alias); ?></span>
                      <button type="submit" class="icon-manager-alias__remove" aria-label="<?= iN_HelpSecure($aliasRemoveLabel); ?>">&times;</button>
                    </form>
                  <?php endforeach; ?>
                </div>
              <?php else: ?>
                <span class="text-muted icon-manager-alias-empty"><?= iN_HelpSecure($modalNoAliasesLabel); ?></span>
              <?php endif; ?>
            </td>
            <td data-label="<?= iN_HelpSecure($updatedLabel); ?>">
              <div class="icon-manager-meta icon-manager-meta--timestamp">
                <span><?= iN_HelpSecure($modalCreatedLabel); ?>: <?= iN_HelpSecure($createdAtLabel); ?></span>
                <span><?= iN_HelpSecure($modalUpdatedLabel); ?>: <?= iN_HelpSecure($updatedAtLabel); ?></span>
              </div>
            </td>
            <td class="icon-manager-actions" data-label="<?= iN_HelpSecure($actionsLabel); ?>">
              <div class="post-settings-btn-box flex align_items relative">
                <button
                  type="button"
                  class="post-settings-btn flex align_items_justify_content relative js-icon-actions"
                  aria-expanded="false"
                  aria-haspopup="menu"
                  data-id="<?= $iconId; ?>"
                  title="<?= iN_HelpSecure($editLabel); ?>"
                >
                  <?php echo renderVerifiedBadge($iconPath . 'dots.svg', false); ?>
                  <span class="sr-only"><?= iN_HelpSecure($editLabel); ?></span>
                </button>
              </div>
              <div id="postMenuPopup-<?= $iconId; ?>" class="post-menu-popup none" aria-hidden="true" role="dialog" aria-label="<?= iN_HelpSecure($menuLabel, false); ?>">
                <div class="pm-sheet-container">
                  <div class="pm-sheet">
                    <button type="button" class="pm-item js-icon-edit-trigger" data-icon-id="<?= $iconId; ?>">
                      <?php echo renderVerifiedBadge($iconPath . 'settings.svg', true); ?>
                      <span><?= iN_HelpSecure($editLabel); ?></span>
                    </button>
                    <button type="button" class="pm-item pm-cancel"><?= iN_HelpSecure($modalCloseLabel); ?></button>
                  </div>
                </div>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php
    if ($total > 0 && $pages > 1) {
        echo dz_render_pagination(
            $resolvedBaseUrl . '/admin/index.php',
            [
                'page' => 'icons',
                'q'    => $searchQuery,
                'per'  => (string) $per,
            ],
            (int) $pageNo,
            (int) $pages,
            [ 'show_goto' => true, 'radius' => 3 ]
        );
    }
  ?>

  <dialog
    id="iconEditDialog"
    class="icon-edit-dialog"
    data-role="icon-edit-dialog"
    data-delete-confirm="<?= iN_HelpSecure($deleteConfirm, false); ?>"
    data-heading-base="<?= iN_HelpSecure($modalHeading, false); ?>"
    data-no-aliases="<?= iN_HelpSecure($modalNoAliasesLabel, false); ?>"
  >
    <form class="icon-edit-dialog__form" method="post" enctype="multipart/form-data" data-role="icon-edit-form">
      <input type="hidden" name="csrf_token" value="<?= iN_HelpSecure($ADMIN_CSRF, false); ?>">
      <input type="hidden" name="action" value="update" data-field="icon-action">
      <input type="hidden" name="icon_id" value="" data-field="icon-id">

      <header class="icon-edit-dialog__header">
        <h2 class="icon-edit-dialog__title" data-field="icon-title"><?= iN_HelpSecure($modalHeading); ?></h2>
      </header>

      <section class="icon-edit-dialog__body">
        <p class="text-muted fs-13 icon-edit-dialog__hint"><?= iN_HelpSecure($modalHint); ?></p>

        <div class="icon-edit-dialog__summary">
          <div class="icon-edit-dialog__preview-wrap">
            <div class="icon-edit-dialog__preview" data-field="preview" aria-hidden="true"></div>
          </div>

          <div class="icon-edit-dialog__meta-cards">
            <div class="icon-edit-dialog__meta-card icon-edit-dialog__meta-card--link">
              <span class="icon-edit-dialog__meta-label"><?= iN_HelpSecure($modalPublicLabel); ?></span>
              <a class="icon-edit-dialog__meta-value" target="_blank" rel="noopener" data-field="public">—</a>
            </div>
            <div class="icon-edit-dialog__meta-card">
              <span class="icon-edit-dialog__meta-label"><?= iN_HelpSecure($modalCreatedLabel); ?></span>
              <span class="icon-edit-dialog__meta-value" data-field="created">—</span>
            </div>
            <div class="icon-edit-dialog__meta-card">
              <span class="icon-edit-dialog__meta-label"><?= iN_HelpSecure($modalUpdatedLabel); ?></span>
              <span class="icon-edit-dialog__meta-value" data-field="updated">—</span>
            </div>
          </div>
        </div>

        <div class="icon-edit-dialog__aliases">
          <span class="icon-edit-dialog__meta-label"><?= iN_HelpSecure($modalAliasesLabel); ?></span>
          <div class="icon-edit-dialog__alias-list" data-field="aliases"></div>
        </div>

        <div class="form-grid form-grid--half icon-edit-dialog__fields">
          <div class="form-input-wrapper">
            <label class="form-label" for="iconModalKey"><?= iN_HelpSecure($keyFieldLabel); ?></label>
            <input id="iconModalKey" class="form-input" type="text" name="icon_key" maxlength="100" required data-field="input-key">
            <p class="form-text text-muted fs-13"><?= iN_HelpSecure($keyFieldHint); ?></p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="iconModalUpload"><?= iN_HelpSecure($uploadLabel); ?></label>
            <label class="mix-upload pseudo-input" for="iconModalUpload">
              <span class="mix-upload__icon" aria-hidden="true"><?= render_icon('upload_icon', true); ?></span>
              <span class="mix-upload__label"><?= iN_HelpSecure($uploadLabel); ?></span>
              <input id="iconModalUpload" class="mix-upload__input" type="file" name="file_upload" accept=".svg,.png,.jpg,.jpeg,.webp,.gif" data-field="input-upload">
            </label>
            <p class="form-text text-muted fs-13 mix-upload__hint mix-upload__hint--note"><?= iN_HelpSecure($uploadHint); ?></p>
          </div>
          <div class="form-input-wrapper form-input-wrapper--checkbox flexBoxColumn">
            <label class="form-checkbox">
              <input type="checkbox" name="keep_alias" value="1" checked data-field="input-keep">
              <span><?= iN_HelpSecure($modalKeepAliasLabel); ?></span>
            </label>
            <p class="form-text text-muted fs-13"><?= iN_HelpSecure($keepAliasHint); ?></p>
          </div>
        </div>
      </section>

      <footer class="icon-edit-dialog__footer">
        <button type="button" class="admin-button admin-button--danger icon-edit-dialog__delete" data-role="icon-delete"><?= iN_HelpSecure($modalDeleteLabel); ?></button>
        <div class="icon-edit-dialog__footer-actions">
          <button type="button" class="admin-button admin-button--neutral icon-edit-dialog__cancel" data-role="icon-close"><?= iN_HelpSecure($modalCloseLabel); ?></button>
          <button type="submit" class="admin-button admin-button--primary icon-edit-dialog__save" data-role="icon-save"><?= iN_HelpSecure($modalSaveLabel); ?></button>
        </div>
      </footer>
    </form>
  </dialog>
</section>

<dialog
  id="iconUrlDialog"
  class="icon-url-dialog"
  data-role="icon-url-dialog"
>
  <form method="dialog" class="icon-url-dialog__form">
    <header class="icon-url-dialog__header">
      <h2 class="icon-url-dialog__title"><?= iN_HelpSecure($publicDialogHeading); ?></h2>
    </header>
    <section class="icon-url-dialog__body">
      <p class="text-muted fs-13 icon-url-dialog__hint"><?= iN_HelpSecure($publicDialogHint); ?></p>
      <a
        class="icon-url-dialog__link"
        data-role="icon-url-target"
        href=""
        target="_blank"
        rel="noopener"
        aria-disabled="true"
        tabindex="-1"
        style="pointer-events:none;"
      >
        —
      </a>
    </section>
    <footer class="icon-url-dialog__footer">
      <a
        class="admin-button admin-button--primary icon-url-dialog__open"
        data-role="icon-url-open"
        href=""
        target="_blank"
        rel="noopener"
        aria-disabled="true"
        tabindex="-1"
        style="pointer-events:none;"
      ><?= iN_HelpSecure($publicDialogOpen); ?></a>
      <button type="submit" class="btn-outline icon-url-dialog__close" data-role="icon-url-close"><?= iN_HelpSecure($modalCloseLabel); ?></button>
    </footer>
  </form>
</dialog>
