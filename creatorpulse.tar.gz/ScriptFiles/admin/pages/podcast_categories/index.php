<?php
declare(strict_types=1);
require_once __DIR__ . '/../../_bootstrap.php';

global $db, $base_url, $ADMIN_CSRF, $RL, $currentLang;

$actionUrl = iN_HelpSecure($base_url . 'admin/request/podcast_categories.php');
$csrfToken = iN_HelpSecure($ADMIN_CSRF);

$langDir = dirname(__DIR__, 3) . '/langs';
$langOptions = [];
if (is_dir($langDir)) {
    foreach (scandir($langDir) as $entry) {
        if (preg_match('/^(\w+)\.php$/', (string) $entry, $m)) {
            $langOptions[] = strtolower((string) $m[1]);
        }
    }
}
if (!$langOptions) {
    $langOptions = ['eng'];
}
$defaultLang = strtolower((string) ($langOptions[0] ?? 'eng')) ?: 'eng';
$currentLocale = isset($currentLang) ? strtolower((string) $currentLang) : $defaultLang;
if (!in_array($currentLocale, $langOptions, true)) {
    $currentLocale = $defaultLang;
}

$categories = [];
if (isset($RL) && method_exists($RL, 'RL_GetPodcastCategories')) {
    $categories = $RL->RL_GetPodcastCategories(null, $currentLocale, $langOptions);
} else {
    try {
        $stmt = $db->query('SELECT id, name, slug, status, sort_order, created_at, updated_at FROM i_podcast_categories ORDER BY sort_order ASC, name ASC');
        if ($stmt) {
            $categories = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        }
    } catch (Throwable $__) {
        $categories = [];
    }
}

if (!isset($categories) || !is_array($categories)) {
    $categories = [];
}

if ($categories) {
    try {
        $ids = array_map(static function ($row) {
            return (int) ($row['id'] ?? 0);
        }, $categories);
        $ids = array_values(array_filter(array_unique($ids), static fn($v) => $v > 0));
        if ($ids) {
            $placeholdersCat = implode(',', array_fill(0, count($ids), '?'));
            $placeholdersLang = implode(',', array_fill(0, count($langOptions), '?'));
            $sqlTrans = 'SELECT category_id, language, name FROM i_podcast_category_translations WHERE category_id IN (' . $placeholdersCat . ')';
            if ($langOptions) {
                $sqlTrans .= ' AND language IN (' . $placeholdersLang . ')';
            }
            $stmtTrans = $db->prepare($sqlTrans);
            $bindValues = array_merge($ids, $langOptions);
            foreach ($bindValues as $idx => $val) {
                $stmtTrans->bindValue($idx + 1, $val, is_int($val) ? PDO::PARAM_INT : PDO::PARAM_STR);
            }
            $stmtTrans->execute();
            $translations = [];
            while ($row = $stmtTrans->fetch(PDO::FETCH_ASSOC)) {
                $cid = (int) ($row['category_id'] ?? 0);
                $lng = strtolower((string) ($row['language'] ?? ''));
                if ($cid <= 0 || $lng === '') {
                    continue;
                }
                $translations[$cid][$lng] = (string) ($row['name'] ?? '');
            }
            foreach ($categories as &$catRow) {
                $cid = (int) ($catRow['id'] ?? 0);
                $catRow['translations'] = $translations[$cid] ?? [];
            }
            unset($catRow);
        }
    } catch (Throwable $__) {
        // best effort; ignore translation hydration errors
    }
}

$formatDate = static function ($timestamp): string {
    if ($timestamp === null) {
        return '—';
    }
    $intValue = (int) $timestamp;
    if ($intValue <= 0) {
        return '—';
    }
    return gmdate('Y-m-d H:i', $intValue) . ' UTC';
};

$resolve = static function (string $key, string $fallback): string {
    $value = customLang($key);
    if (is_string($value) && $value !== '' && $value !== $key) {
        return $value;
    }
    return $fallback;
};

$title = $resolve('admin_podcast_categories_title', 'Podcast categories');
$intro = $resolve('admin_podcast_categories_intro', 'Create categories for podcasts. Active categories appear in the creator upload flow.');
$addLabel = $resolve('admin_podcast_category_add', 'Add category');
$editLabel = $resolve('admin_action_edit', 'Edit');
$deleteLabel = $resolve('admin_podcast_category_delete', 'Delete');
$deleteConfirm = $resolve('admin_podcast_category_delete_confirm', 'Delete this category? Assigned podcasts will lose this label.');
$statusActiveLabel = $resolve('admin_podcast_category_status_active', 'Active');
$statusInactiveLabel = $resolve('admin_podcast_category_status_inactive', 'Inactive');
$nameLabel = $resolve('admin_podcast_category_name_label', 'Category name');
$slugLabel = $resolve('admin_podcast_category_slug_label', 'Slug');
$slugHint = $resolve('admin_podcast_category_slug_hint', 'Leave blank to auto-generate.');
$statusLabel = $resolve('admin_podcast_category_status_label', 'Status');
$sortLabel = $resolve('admin_podcast_category_sort_label', 'Sort order');
$sortHint = $resolve('admin_podcast_category_sort_hint', 'Lower numbers appear first.');
$tableSortLabel = $resolve('admin_podcast_category_sort_column', 'Order');
$updatedLabel = $resolve('admin_podcast_category_updated_column', 'Updated');
$actionsLabel = $resolve('admin_actions', 'Actions');
$emptyLabel = $resolve('admin_podcast_category_empty', 'No podcast categories yet.');
$modalAddTitle = $resolve('admin_podcast_category_add', 'Add category');
$modalEditTitle = $resolve('admin_podcast_category_edit', 'Edit category');
$saveLabel = $resolve('admin_podcast_category_save_button', 'Save category');
$updateLabel = $resolve('admin_podcast_category_update_button', 'Update category');
$saveOrderLabel = $resolve('admin_podcast_category_save_order', 'Save order');
$reorderHint = $resolve('admin_podcast_category_reorder_hint', 'Drag rows to reorder, then save.');
$tableSlugLabel = $resolve('admin_podcast_category_slug_label', 'Slug');
$tableNameLabel = $resolve('admin_podcast_category_name_label', 'Name');
$tableStatusLabel = $resolve('admin_podcast_category_status_label', 'Status');
$idLabel = $resolve('admin_column_id', 'ID');
?>

<style>
.card-header-actions {
    display: flex;
    gap: 12px;
    align-items: center;
}
.admin-modal-overlay {
    position: fixed;
    inset: 0;
    background: rgba(15, 23, 42, 0.55);
    backdrop-filter: blur(2px);
    display: none;
    align-items: center;
    justify-content: center;
    padding: 18px;
    z-index: 99999;
}
.admin-modal-overlay.is-open {
    display: flex;
}
.admin-modal {
    width: 100%;
    max-width: 520px;
}
.admin-modal .card {
    margin: 0;
}
.drag-handle {
    cursor: grab;
    user-select: none;
    font-size: 18px;
    line-height: 1;
}
</style>

<section class="card rounded-2xl" role="region" aria-labelledby="podcastCategoriesHeading">
  <div class="card-header flex align_items space_between">
    <div>
      <h1 id="podcastCategoriesHeading"><?php echo iN_HelpSecure($title); ?></h1>
      <p class="box-note"><?php echo iN_HelpSecure($intro); ?></p>
      <p class="box-note text-muted"><?php echo iN_HelpSecure($reorderHint); ?></p>
    </div>
    <div class="card-header-actions">
      <button type="button" class="admin-button admin-button--primary" id="addPodcastCategory"><?php echo iN_HelpSecure($addLabel); ?></button>
      <button type="button" class="admin-button admin-button--neutral" id="savePodcastCategoryOrder"><?php echo iN_HelpSecure($saveOrderLabel); ?></button>
    </div>
  </div>

  <div class="table-responsive">
    <table class="table table-striped table-sm">
      <thead>
        <tr>
          <th aria-label="Reorder"></th>
          <th><?php echo iN_HelpSecure($idLabel); ?></th>
          <th><?php echo iN_HelpSecure($tableNameLabel); ?></th>
          <th><?php echo iN_HelpSecure($tableSlugLabel); ?></th>
          <th><?php echo iN_HelpSecure($tableStatusLabel); ?></th>
          <th><?php echo iN_HelpSecure($tableSortLabel); ?></th>
          <th><?php echo iN_HelpSecure($updatedLabel); ?></th>
          <th><?php echo iN_HelpSecure($actionsLabel); ?></th>
        </tr>
      </thead>
      <tbody data-sortable-list="podcast-categories">
        <?php if (empty($categories)): ?>
          <tr>
            <td colspan="8" class="text-center text-muted"><?php echo iN_HelpSecure($emptyLabel); ?></td>
          </tr>
        <?php else: ?>
          <?php foreach ($categories as $cat):
              $cid = (int) ($cat['id'] ?? 0);
              $cname = (string) ($cat['name'] ?? '');
              $cslug = (string) ($cat['slug'] ?? '');
              $cstatus = strtolower((string) ($cat['status'] ?? 'inactive'));
              $csort = (int) ($cat['sort_order'] ?? 0);
              $updatedAt = $formatDate($cat['updated_at'] ?? null);
              $toggleStatus = $cstatus === 'active' ? 'inactive' : 'active';
              $toggleLabel = $cstatus === 'active' ? $statusInactiveLabel : $statusActiveLabel;
              $ctranslations = isset($cat['translations']) && is_array($cat['translations']) ? $cat['translations'] : [];
              if (!isset($ctranslations[$defaultLang]) || trim((string) $ctranslations[$defaultLang]) === '') {
                  $ctranslations[$defaultLang] = $cname;
              }
              $namesData = iN_HelpSecure(json_encode($ctranslations, JSON_UNESCAPED_UNICODE), false, 0, false);
          ?>
          <tr data-sortable-item data-row-key="<?php echo $cid; ?>" draggable="true">
            <td class="text-muted" aria-label="Drag to reorder"><span class="drag-handle" aria-hidden="true">⋮⋮</span></td>
            <td><?php echo $cid; ?></td>
            <td><?php echo iN_HelpSecure($cname); ?></td>
            <td><?php echo iN_HelpSecure($cslug); ?></td>
            <td><?php echo iN_HelpSecure($cstatus === 'active' ? $statusActiveLabel : $statusInactiveLabel); ?></td>
            <td><?php echo (int) $csort; ?></td>
            <td><?php echo iN_HelpSecure($updatedAt); ?></td>
            <td class="admin-table-actions">
              <div class="post-settings-btn-box flex align_items relative">
                <button
                  type="button"
                  class="post-settings-btn flex align_items_justify_content relative js-cat-actions"
                  aria-expanded="false"
                  aria-haspopup="menu"
                  title="<?php echo iN_HelpSecure(customLang('admin_users_actions_label') ?: 'Actions'); ?>"
                  data-id="<?php echo $cid; ?>">
                  <?php echo renderVerifiedBadge($iconPath . 'dots.svg', true); ?>
                </button>
              </div>
              <div id="catMenuPopup-<?php echo $cid; ?>" class="post-menu-popup none" aria-hidden="true" role="dialog" aria-label="<?php echo iN_HelpSecure('Category actions for #' . $cid); ?>">
                <div class="pm-sheet-container">
                  <div class="pm-sheet">
                    <button type="button"
                            class="pm-item flex align_items_justify_content gap js-edit-category"
                            data-id="<?php echo $cid; ?>"
                            data-name="<?php echo iN_HelpSecure($cname); ?>"
                            data-slug="<?php echo iN_HelpSecure($cslug); ?>"
                            data-status="<?php echo iN_HelpSecure($cstatus); ?>"
                            data-sort="<?php echo $csort; ?>"
                            data-names="<?php echo $namesData; ?>">
                      <span><?php echo iN_HelpSecure($editLabel); ?></span>
                    </button>
                    <button type="button"
                            class="pm-item flex align_items_justify_content gap js-cat-action"
                            data-action="status"
                            data-category-id="<?php echo $cid; ?>"
                            data-status="<?php echo iN_HelpSecure($toggleStatus); ?>"
                            data-url="<?php echo $actionUrl; ?>">
                      <?php echo iN_HelpSecure($toggleLabel); ?>
                    </button>
                    <button type="button"
                            class="pm-item flex align_items_justify_content gap js-cat-action is-danger"
                            data-action="delete"
                            data-category-id="<?php echo $cid; ?>"
                            data-url="<?php echo $actionUrl; ?>"
                            data-confirm="<?php echo iN_HelpSecure($deleteConfirm); ?>">
                      <?php echo iN_HelpSecure($deleteLabel); ?>
                    </button>
                    <button type="button" class="pm-item pm-cancel"><?php echo iN_HelpSecure(customLang('admin_users_action_cancel') ?: 'Cancel'); ?></button>
                  </div>
                </div>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>

<div class="admin-modal-overlay" id="podcastCategoryModal"
     data-add-title="<?php echo iN_HelpSecure($modalAddTitle); ?>"
     data-edit-title="<?php echo iN_HelpSecure($modalEditTitle); ?>"
     data-save-label="<?php echo iN_HelpSecure($saveLabel); ?>"
     data-update-label="<?php echo iN_HelpSecure($updateLabel); ?>"
     hidden>
  <div class="admin-modal">
    <section class="card rounded-2xl" role="dialog" aria-modal="true" aria-labelledby="podcastCategoryModalTitle">
      <div class="card-header flex align_items space_between">
        <h2 id="podcastCategoryModalTitle"><?php echo iN_HelpSecure($modalAddTitle); ?></h2>
        <button type="button" class="admin-button admin-button--ghost" data-modal-close>&times;</button>
      </div>
      <form class="form-container flex flexBoxColumn" id="podcastCategoryForm" method="post" action="<?php echo $actionUrl; ?>" data-languages="<?php echo iN_HelpSecure(json_encode($langOptions, JSON_UNESCAPED_UNICODE), false, 0, false); ?>" data-default-lang="<?php echo iN_HelpSecure($defaultLang); ?>">
        <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
        <input type="hidden" name="action" value="create">
        <input type="hidden" name="category_id" value="">
        <input type="hidden" name="default_lang" value="<?php echo iN_HelpSecure($defaultLang); ?>">

        <div class="landing-lang-tabs" data-lang-tabs role="tablist" aria-label="<?php echo iN_HelpSecure($nameLabel); ?>">
          <?php foreach ($langOptions as $index => $langCode):
              $langSafe = iN_HelpSecure(strtolower((string) $langCode));
              $isActive = $index === 0;
          ?>
            <button type="button" class="landing-lang-tab<?php echo $isActive ? ' is-active' : ''; ?>" data-lang-target="<?php echo $langSafe; ?>" aria-selected="<?php echo $isActive ? 'true' : 'false'; ?>"><?php echo iN_HelpSecure(strtoupper((string) $langCode)); ?></button>
          <?php endforeach; ?>
        </div>

        <?php foreach ($langOptions as $index => $langCode):
            $langKey = strtolower((string) $langCode);
            $langSafe = iN_HelpSecure($langKey);
            $isActive = $index === 0;
            $isDefaultLang = $langKey === $defaultLang;
        ?>
          <div class="landing-lang-panel<?php echo $isActive ? ' is-active' : ''; ?>" data-lang-panel="<?php echo $langSafe; ?>" aria-hidden="<?php echo $isActive ? 'false' : 'true'; ?>"<?php echo $isActive ? '' : ' hidden'; ?>>
            <label class="form-label" for="podcastCategoryName_<?php echo $langSafe; ?>">
              <?php echo iN_HelpSecure($nameLabel); ?>
              <span class="text-muted">(<?php echo iN_HelpSecure(strtoupper((string) $langCode)); ?>)</span>
            </label>
            <input
              id="podcastCategoryName_<?php echo $langSafe; ?>"
              class="form-input"
              type="text"
              name="name[<?php echo $langSafe; ?>]"
              data-lang-field="<?php echo $langSafe; ?>"
              maxlength="120"
              <?php echo $isDefaultLang ? 'required' : ''; ?>
              <?php echo $isDefaultLang ? 'aria-required="true"' : ''; ?>>
          </div>
        <?php endforeach; ?>

        <label class="form-label" for="podcastCategorySlug"><?php echo iN_HelpSecure($slugLabel); ?></label>
        <input id="podcastCategorySlug" class="form-input" type="text" name="slug" maxlength="160" placeholder="<?php echo iN_HelpSecure($slugHint); ?>">
        <small class="form-text text-muted"><?php echo iN_HelpSecure($slugHint); ?></small>

        <label class="form-label" for="podcastCategoryStatus"><?php echo iN_HelpSecure($statusLabel); ?></label>
        <select id="podcastCategoryStatus" class="form-input" name="status">
          <option value="active"><?php echo iN_HelpSecure($statusActiveLabel); ?></option>
          <option value="inactive"><?php echo iN_HelpSecure($statusInactiveLabel); ?></option>
        </select>

        <label class="form-label" for="podcastCategorySort"><?php echo iN_HelpSecure($sortLabel); ?></label>
        <input id="podcastCategorySort" class="form-input" type="number" name="sort_order" value="0">
        <small class="form-text text-muted"><?php echo iN_HelpSecure($sortHint); ?></small>

        <div class="form-actions">
          <button type="submit" id="podcastCategorySubmit" class="admin-button admin-button--primary"><?php echo iN_HelpSecure($saveLabel); ?></button>
          <button type="button" class="admin-button admin-button--neutral" data-modal-close><?php echo iN_HelpSecure(customLang('menu_cancel') ?: 'Cancel'); ?></button>
        </div>
      </form>
    </section>
  </div>
</div>
