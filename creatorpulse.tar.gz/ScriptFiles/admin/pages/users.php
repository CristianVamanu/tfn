<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $base_url, $ADMIN_CSRF, $ADM, $iconPath;

$q    = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
$page = isset($_GET['page_no']) ? max(1, (int)$_GET['page_no']) : 1;
$per  = isset($_GET['per']) ? max(5, min(100, (int)$_GET['per'])) : 20;

$verified = isset($_GET['verified']) ? trim((string)$_GET['verified']) : '';
$banned   = isset($_GET['banned']) ? trim((string)$_GET['banned']) : '';
$role     = isset($_GET['role']) ? strtolower(trim((string)$_GET['role'])) : '';
if (!in_array($verified, ['', '0', '1'], true)) { $verified = ''; }
if (!in_array($banned, ['', '0', '1'], true)) { $banned = ''; }
if (!in_array($role, ['', 'user', 'moderator', 'admin'], true)) { $role = ''; }
$filters  = ['verified'=>$verified,'banned'=>$banned,'role'=>$role];
$data = $ADM->ADM_PagedUsers($q, $page, $per, $filters);
$rows = $data['rows'];
$total= (int)$data['total'];
$pages= (int)max(1, ceil($total / max(1,$per)));
$canUserBan = admin_has_permission('users.ban');
$permissionTip = customLang('admin_permission_denied_tooltip') ?: 'You do not have permission to perform this action.';
?>
<section class="card rounded-2xl" role="region" aria-labelledby="adminUsersHeading">
  <div class="list-header" id="adminUsersHeading">
    <span class="icon"><?= renderVerifiedBadge($iconPath . 'dashboard_user.svg', true); ?></span>
    <span><strong><?= iN_HelpSecure(customLang('admin_users_heading') ?: 'Manage Users', false); ?></strong></span>
  </div>

  <form class="form-container form-container--columns" method="get" action="<?= iN_HelpSecure($base_url . 'admin/index.php', false); ?>">
    <input type="hidden" name="page" value="users">
    <div class="form-input-wrapper" data-field="search">
      <label class="form-label" for="q"><?= iN_HelpSecure(customLang('admin_common_search') ?: 'Search', false); ?></label>
      <input id="q" class="form-input" type="text" name="q" value="<?= iN_HelpSecure($q, false); ?>" placeholder="<?= iN_HelpSecure(customLang('admin_users_search_placeholder') ?: 'username, email, name', false); ?>">
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="per"><?= iN_HelpSecure(customLang('admin_users_filter_per_page') ?: 'Per page', false); ?></label>
      <select id="per" name="per" class="form-input">
        <?php foreach ([10,20,50,100] as $pp): ?>
          <option value="<?= $pp; ?>"<?= $pp===$per?' selected':''; ?>><?= $pp; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="verified"><?= iN_HelpSecure(customLang('admin_users_filter_verified') ?: 'Verified', false); ?></label>
      <select id="verified" name="verified" class="form-input">
        <?php
          $vopts = [
            ''  => customLang('admin_users_filter_any') ?: 'Any',
            '1' => customLang('admin_users_filter_verified') ?: 'Verified',
            '0' => customLang('admin_users_filter_unverified') ?: 'Unverified',
          ];
          foreach ($vopts as $vk => $vt):
        ?>
          <option value="<?= $vk; ?>"<?= ($verified===(string)$vk?' selected':''); ?>><?= iN_HelpSecure($vt, false); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="banned"><?= iN_HelpSecure(customLang('admin_users_filter_banned') ?: 'Banned', false); ?></label>
      <select id="banned" name="banned" class="form-input">
        <?php
          $bopts = [
            ''  => customLang('admin_users_filter_any') ?: 'Any',
            '0' => customLang('admin_users_filter_active') ?: 'Active',
            '1' => customLang('admin_users_filter_banned') ?: 'Banned',
          ];
          foreach ($bopts as $bk => $bt):
        ?>
          <option value="<?= $bk; ?>"<?= ($banned===(string)$bk?' selected':''); ?>><?= iN_HelpSecure($bt, false); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="role"><?= iN_HelpSecure(customLang('admin_users_filter_role') ?: 'Type', false); ?></label>
      <select id="role" name="role" class="form-input">
        <?php
          $ropts = [
            ''          => customLang('admin_users_filter_any') ?: 'Any',
            'user'      => customLang('admin_users_filter_role_user') ?: 'User',
            'moderator' => customLang('admin_users_filter_role_moderator') ?: 'Moderator',
            'admin'     => customLang('admin_users_filter_role_admin') ?: 'Admin',
          ];
          foreach ($ropts as $rk => $rt):
        ?>
          <option value="<?= $rk; ?>"<?= ($role===(string)$rk?' selected':''); ?>><?= iN_HelpSecure($rt, false); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper form-actions">
      <label class="form-label sr-only" for="btnSearch" aria-hidden="true"><?= iN_HelpSecure(customLang('admin_common_search') ?: 'Search', false); ?></label>
      <button id="btnSearch" type="submit" class="pe-save btn-hover"><?= iN_HelpSecure(customLang('admin_users_filter_apply') ?: 'Apply', false); ?></button>
    </div>
  </form>

  <form method="post" action="<?= iN_HelpSecure($base_url . 'admin/request/users.php', false); ?>" data-confirm="<?= iN_HelpSecure(customLang('admin_users_bulk_confirm') ?: 'Apply bulk action to selected users?', false); ?>">
    <input type="hidden" name="csrf_token" value="<?= iN_HelpSecure($ADMIN_CSRF, false); ?>">
    <div class="form-container form-container--columns pt-0">
      <div class="form-input-wrapper">
        <label class="form-label" for="bulk_action"><?= iN_HelpSecure(customLang('admin_users_bulk_label') ?: 'Bulk action', false); ?></label>
        <select id="bulk_action" name="bulk_action" class="form-input"<?= $canUserBan ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>>
          <option value="ban"><?= iN_HelpSecure(customLang('admin_users_bulk_option_ban') ?: 'Ban', false); ?></option>
          <option value="unban"><?= iN_HelpSecure(customLang('admin_users_bulk_option_unban') ?: 'Unban', false); ?></option>
        </select>
      </div>
      <div class="form-input-wrapper form-actions">
        <label class="form-label sr-only" for="bulkBtn"><?= iN_HelpSecure(customLang('admin_users_filter_apply') ?: 'Apply', false); ?></label>
        <button id="bulkBtn" type="submit" class="btn-hover pe-save"<?= $canUserBan ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?= iN_HelpSecure(customLang('admin_users_filter_apply') ?: 'Apply', false); ?></button>
      </div>
    </div>

    <?php
      $adminUsersTableRows = $rows;
      $adminUsersTableBaseUrl = $base_url;
      $adminUsersTableIconPath = $iconPath;
      $adminUsersTableUserData = $userData;
      $adminUsersShowFakeBadge = false;
      $adminUsersTablePagination = [
        'base_url' => $base_url . 'admin/index.php',
        'params'   => [
          'page'     => 'users',
          'q'        => $q,
          'verified' => $verified,
          'banned'   => $banned,
          'role'     => $role,
          'per'      => (string)$per,
        ],
        'page'    => (int)$page,
        'pages'   => (int)$pages,
        'options' => ['show_goto' => true, 'radius' => 1],
      ];
      include __DIR__ . '/partials/users_table.php';
      unset($adminUsersTableRows, $adminUsersTableBaseUrl, $adminUsersTableIconPath, $adminUsersTableUserData, $adminUsersShowFakeBadge, $adminUsersTablePagination);
    ?>
  </form>
</section>
