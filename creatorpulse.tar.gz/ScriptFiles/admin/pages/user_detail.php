<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $RL, $ADM, $base_url, $iconPath, $db, $userData, $currency, $currencies, $currencyFormatSettings;

$uid = isset($_GET['id']) ? max(1, (int)$_GET['id']) : 0;
$user = ($uid > 0 && $RL && method_exists($RL, 'RL_GetUserDetails')) ? (array)$RL->RL_GetUserDetails($uid) : [];

if (!$user || isset($user['error'])) {
    echo '<section class="card rounded-2xl"><div class="p-4">User not found.</div></section>';
    return;
}

$username  = (string)($user['username'] ?? '');
$fullname  = (string)($user['user_fullname'] ?? $username);
$email     = (string)($user['user_email'] ?? '');
$phone     = (string)($user['user_phone'] ?? '');
$avatarPath = (string)($user['user_avatar'] ?? '');
if ($avatarPath === '') {
    $avatarPath = 'uploads/user_avatars/default.jpeg';
}
$avatar    = admin_resolve_media_url($avatarPath);
$coverPath = (string)($user['user_cover'] ?? '');
if ($coverPath === '') {
    $coverPath = 'uploads/user_covers/default_cover.jpg';
}
$cover     = admin_resolve_media_url($coverPath);
$verified  = (int)($user['verified_status'] ?? 0) === 1;
$type      = (int)($user['user_type'] ?? 1);
$mode      = (string)($user['user_mode'] ?? '');
$currentRole = $mode !== '' ? strtolower($mode) : (($type >= 3) ? 'admin' : (($type === 2) ? 'moderator' : 'user'));
$isBanned  = (int)($user['is_banned'] ?? 0) === 1;
$firstSeen = isset($user['first_seen']) && $user['first_seen']>0 ? date('d-m-Y H:i', (int)$user['first_seen']) : '-';
$lastLogin = isset($user['last_login_time']) && $user['last_login_time']>0 ? date('d-m-Y H:i', (int)$user['last_login_time']) : '-';
$myType = (int)($userData['user_type'] ?? 0);
$meId = (int)($userData['user_id'] ?? 0);
$isOwnerOrAdmin = ($meId === 1) || ($myType >= 3);
$isOwnerTarget = ((int)$uid === 1);
$isSelfTarget   = ($meId === (int)$uid);
$isModeratorActor = ($myType === 2);
$creatorStatus = (string)($user['creator_status'] ?? 'none');
$creatorStatusUpdated = isset($user['creator_status_updated_at']) && (int)$user['creator_status_updated_at'] > 0 ? date('d-m-Y H:i', (int)$user['creator_status_updated_at']) : '-';
$verificationRow = (isset($RL) && method_exists($RL, 'RL_GetCreatorVerificationRequest')) ? $RL->RL_GetCreatorVerificationRequest((int)$uid) : [];
if (isset($verificationRow['documents']) && !is_array($verificationRow['documents'])) {
    $decodedDocs = json_decode((string)$verificationRow['documents'], true);
    if (is_array($decodedDocs)) {
        $verificationRow['documents'] = $decodedDocs;
    }
}
$verificationDocs = isset($verificationRow['documents']) && is_array($verificationRow['documents']) ? $verificationRow['documents'] : [];
$verificationDocLabels = [
    'id_front'       => customLang('creator_identity_id_front', 'Government ID - front'),
    'id_back'        => customLang('creator_identity_id_back', 'Government ID - back'),
    'passport'       => customLang('creator_identity_passport', 'Passport'),
    'driver_license' => customLang('creator_identity_driver_license', 'Driver license'),
    'selfie'         => customLang('creator_identity_selfie', 'Selfie'),
    'additional'     => customLang('admin_verification_docs_additional', 'Additional file #{index}'),
];
$verificationStatus = isset($verificationRow['request_status']) ? (string)$verificationRow['request_status'] : 'pending';
$verificationSubmitted = isset($verificationRow['created_at']) && (int)$verificationRow['created_at'] > 0 ? date('d-m-Y H:i', (int)$verificationRow['created_at']) : '-';
$verificationNote = isset($verificationRow['notes']) ? (string)$verificationRow['notes'] : '';
$verificationAdminNote = isset($verificationRow['admin_note']) ? (string)$verificationRow['admin_note'] : '';
$payoutMethod = isset($user['payout_method']) ? (string)$user['payout_method'] : 'none';
$payoutDetailsRaw = '';
if (!empty($user['payout_details_json'])) {
    $decoded = json_decode((string)$user['payout_details_json'], true);
    if (is_array($decoded)) {
        $payoutDetailsRaw = json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    } else {
        $payoutDetailsRaw = (string)$user['payout_details_json'];
    }
}
$creatorStatusBadgeMap = [
    'approved' => 'creator-badge--success',
    'pending'  => 'creator-badge--warning',
    'rejected' => 'creator-badge--danger',
    'none'     => 'creator-badge--muted',
];
$creatorStatusClass = $creatorStatusBadgeMap[strtolower($creatorStatus)] ?? 'badge-muted';
$adminPermRaw = '';
if (isset($user['admin_permissions'])) {
    $adminPermRaw = (string) $user['admin_permissions'];
} elseif (admin_permission_column_exists($db)) {
    try {
        $permStmt = $db->prepare('SELECT admin_permissions FROM i_users WHERE user_id = :uid LIMIT 1');
        $permStmt->execute([':uid' => (int) $uid]);
        $adminPermRaw = (string) $permStmt->fetchColumn();
    } catch (Throwable $__) {
        $adminPermRaw = '';
    }
}
$targetPermissions = admin_normalize_permissions($adminPermRaw);
$targetPermissionsJson = htmlspecialchars(json_encode(array_values($targetPermissions)), ENT_QUOTES, 'UTF-8');
$targetPermissionsSet = trim($adminPermRaw) !== '';
$displayName = $fullname !== '' ? $fullname : $username;
$canUserView = admin_has_permission('users.view');
$canEditProfile = admin_has_permission('users.edit_profile');
$canEditEmail = admin_has_permission('users.edit_email');
$canResetPassword = admin_has_permission('users.reset_password');
$canUserBan = admin_has_permission('users.ban');
$canUserDelete = admin_has_permission('users.delete');
$canUserSetRole = admin_has_permission('users.set_role');
$canUserManage = admin_has_permission('users.manage');
$canEditWallet = admin_has_permission('users.edit_wallet');
$canVerify = admin_has_permission('verification.approve');
$canSaveUser = $canEditProfile || $canEditEmail || $canResetPassword || $canUserBan || $canUserSetRole || $canUserManage || $canEditWallet || $canVerify;
$permissionTip = customLang('admin_permission_denied_tooltip') ?: 'You do not have permission to perform this action.';

if (!$canUserView) {
    echo '<section class="card rounded-2xl"><div class="p-4 text-muted">' .
        iN_HelpSecure(customLang('admin_permission_denied_message') ?: 'You do not have permission to access this page.', false) .
        '</div></section>';
    return;
}

?>
<section class="card rounded-2xl" role="region" aria-labelledby="userDetailHeading">
  <div class="list-header" id="userDetailHeading">
    <span class="icon"><?= renderVerifiedBadge($iconPath . 'dashboard_user.svg', true); ?></span>
    <span><strong>User Details</strong></span>
    <a class="view-all transition" href="<?= iN_HelpSecure(($base_url ?? '/') . 'admin/index.php?page=users', false); ?>">Back to Users</a>
  </div>

  <div class="admin-section">
    <div class="ud-row">
      <img class="ud-avatar" src="<?= iN_HelpSecure($avatar, false); ?>" alt="Avatar">
      <div class="ud-dt flex flexBoxColumn">
        <div class="ud-title">@<?= iN_HelpSecure($username, false); ?> — <?= iN_HelpSecure($fullname, false); ?></div>
        <div class="ud-line">Email: <?= iN_HelpSecure($email, false); ?></div>
        <div class="ud-line">Role: <?= iN_HelpSecure($mode !== '' ? ucfirst($mode) : (string)$type, false); ?></div>
        <div class="ud-line">Verified: <?= $verified ? 'Yes' : 'No'; ?> · Banned: <?= $isBanned ? 'Yes' : 'No'; ?></div>
        <div class="ud-line">First seen: <?= iN_HelpSecure($firstSeen, false); ?> · Last login: <?= iN_HelpSecure($lastLogin, false); ?></div>
      </div>
    </div>
  </div>

  <?php
    $stats = isset($ADM) && method_exists($ADM, 'ADM_UserOverviewStats') ? $ADM->ADM_UserOverviewStats((int)$uid) : [];
    $postsCnt    = (int)($stats['posts'] ?? 0);
    $followersCnt= (int)($stats['followers'] ?? 0);
    $followingCnt= (int)($stats['following'] ?? 0);
    $subsCnt     = (int)($stats['subscribers'] ?? 0);
    $tipsCnt     = (int)($stats['tips_count'] ?? 0);
    $tipsSum     = (float)($stats['tips_sum'] ?? 0);
    $currenciesMap = isset($currencies) && is_array($currencies) ? $currencies : [];
    $currencyFormatSettings = $currencyFormatSettings ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
    $currencyCode = isset($currency) && $currency !== '' ? strtoupper((string) $currency) : 'USD';
    $formatTipsAmount = static function (float $value) use ($currenciesMap, $currencyFormatSettings, $currencyCode): string {
        $symbol = $currenciesMap[$currencyCode] ?? null;

        return dz_format_currency($value, $currencyCode, $symbol, $currencyFormatSettings);
    };
  ?>

  <div class="admin-section">
    <h3>Overview</h3>
    <div class="kpi-row">
      <div class="kpi-card kpi-bg-blue">
        <div class="kpi-left">
          <div class="kpi-title"><span class="kpi-icon kpi-icon--posts"><?= renderVerifiedBadge($iconPath . 'reels.svg', true); ?></span><strong>Posts</strong></div>
          <div class="kpi-amount"><?= (int)$postsCnt; ?></div>
        </div>
      </div>
      <div class="kpi-card kpi-bg-cyan">
        <div class="kpi-left">
          <div class="kpi-title"><span class="kpi-icon kpi-icon--users"><?= renderVerifiedBadge($iconPath . 'dashboard_user.svg', true); ?></span><strong>Followers</strong></div>
          <div class="kpi-amount"><?= (int)$followersCnt; ?></div>
        </div>
      </div>
      <div class="kpi-card kpi-bg-muted">
        <div class="kpi-left">
          <div class="kpi-title"><span class="kpi-icon kpi-icon--subs"><?= renderVerifiedBadge($iconPath . 'subscription_fees.svg', true); ?></span><strong>Subscribers</strong></div>
          <div class="kpi-amount"><?= (int)$subsCnt; ?></div>
        </div>
      </div>
      <div class="kpi-card kpi-bg-rose">
        <div class="kpi-left">
          <div class="kpi-title"><span class="kpi-icon kpi-icon--tips"><?= renderVerifiedBadge($iconPath . 'super_thanks.svg', true); ?></span><strong>Tips</strong></div>
          <div class="kpi-amount"><?= (int)$tipsCnt; ?> · <span class="amount-mono"><?= iN_HelpSecure($formatTipsAmount($tipsSum), false); ?></span></div>
        </div>
      </div>
    </div>
  </div>

  <div class="admin-section">
    <h3>Quick actions</h3>
    <div class="ud-actions">
      <?php
        $makeUserLabel = customLang('admin_users_action_make_user') ?: 'Make User';
        $makeModLabel = customLang('admin_users_action_make_moderator') ?: 'Make Moderator';
        $makeAdminLabel = customLang('admin_users_action_make_admin') ?: 'Make Admin';
        $isUserLabel = customLang('admin_users_action_is_user') ?: 'User is User';
        $isModLabel = customLang('admin_users_action_is_moderator') ?: 'User is Moderator';
        $isAdminLabel = customLang('admin_users_action_is_admin') ?: 'User is Admin';
        $roleIsUser = $currentRole === 'user';
        $roleIsMod = $currentRole === 'moderator';
        $roleIsAdmin = $currentRole === 'admin';
      ?>
      <?php if ($isOwnerTarget): ?>
        <div class="text-muted">Owner account is protected. Ban/Delete/Role changes are disabled.</div>
      <?php else: ?>
        <?php if ($isBanned): ?>
          <button type="button" class="btn js-uact<?= $canUserBan ? '' : ' is-disabled'; ?>" data-action="unban" data-user-id="<?= (int)$uid; ?>"<?= $canUserBan ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?php echo renderVerifiedBadge($iconPath . 'unban.svg', true); ?> <span>Unban</span></button>
        <?php else: ?>
          <button type="button" class="btn btn-danger js-uact<?= $canUserBan ? '' : ' is-disabled'; ?>" data-action="ban" data-user-id="<?= (int)$uid; ?>"<?= $canUserBan ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?php echo renderVerifiedBadge($iconPath . 'ban.svg', true); ?> <span>Ban</span></button>
        <?php endif; ?>
        <button type="button" class="btn btn-danger js-uact<?= $canUserDelete ? '' : ' is-disabled'; ?>" data-action="delete" data-user-id="<?= (int)$uid; ?>"<?= $canUserDelete ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?php echo renderVerifiedBadge($iconPath . 'delete.svg', true); ?> <span>Delete</span></button>

        <?php if ($isOwnerOrAdmin && $canUserSetRole): ?>
          <?php if ($isSelfTarget): ?>
            <button type="button" class="btn js-uact<?php echo $roleIsUser ? ' is-role-active is-role-user' : ''; ?>" data-action="set_role" data-role="user" data-user-id="<?= (int)$uid; ?>" disabled aria-disabled="true" data-tip="Admins cannot change their own role." title="Admins cannot change their own role."><?php echo renderVerifiedBadge($iconPath . 'make_user.svg', true); ?> <span><?php echo iN_HelpSecure($roleIsUser ? $isUserLabel : $makeUserLabel, false); ?></span></button>
            <button type="button" class="btn js-uact<?php echo $roleIsMod ? ' is-role-active is-role-moderator' : ''; ?>" data-action="set_role" data-role="moderator" data-user-id="<?= (int)$uid; ?>" data-permissions="<?= $targetPermissionsJson; ?>" data-permissions-set="<?= $targetPermissionsSet ? '1' : '0'; ?>" data-user-name="<?= iN_HelpSecure($displayName, false); ?>" disabled aria-disabled="true" data-tip="Admins cannot change their own role." title="Admins cannot change their own role."><?php echo renderVerifiedBadge($iconPath . 'moderator.svg', true); ?> <span><?php echo iN_HelpSecure($roleIsMod ? $isModLabel : $makeModLabel, false); ?></span></button>
            <button type="button" class="btn btn-primary js-uact<?php echo $roleIsAdmin ? ' is-role-active is-role-admin' : ''; ?>" data-action="set_role" data-role="admin" data-user-id="<?= (int)$uid; ?>" disabled aria-disabled="true" data-tip="Admins cannot change their own role." title="Admins cannot change their own role."><?php echo renderVerifiedBadge($iconPath . 'admin.svg', true); ?> <span><?php echo iN_HelpSecure($roleIsAdmin ? $isAdminLabel : $makeAdminLabel, false); ?></span></button>
          <?php else: ?>
            <button type="button" class="btn js-uact<?php echo $roleIsUser ? ' is-role-active is-role-user' : ''; ?>" data-action="set_role" data-role="user" data-user-id="<?= (int)$uid; ?>"<?php echo $roleIsUser ? ' disabled aria-disabled="true"' : ''; ?>><?php echo renderVerifiedBadge($iconPath . 'make_user.svg', true); ?> <span><?php echo iN_HelpSecure($roleIsUser ? $isUserLabel : $makeUserLabel, false); ?></span></button>
            <button type="button" class="btn js-uact<?php echo $roleIsMod ? ' is-role-active is-role-moderator' : ''; ?>" data-action="set_role" data-role="moderator" data-user-id="<?= (int)$uid; ?>" data-permissions="<?= $targetPermissionsJson; ?>" data-permissions-set="<?= $targetPermissionsSet ? '1' : '0'; ?>" data-user-name="<?= iN_HelpSecure($displayName, false); ?>"><?php echo renderVerifiedBadge($iconPath . 'moderator.svg', true); ?> <span><?php echo iN_HelpSecure($roleIsMod ? $isModLabel : $makeModLabel, false); ?></span></button>
            <button type="button" class="btn btn-primary js-uact<?php echo $roleIsAdmin ? ' is-role-active is-role-admin' : ''; ?>" data-action="set_role" data-role="admin" data-user-id="<?= (int)$uid; ?>"<?php echo $roleIsAdmin ? ' disabled aria-disabled="true"' : ''; ?>><?php echo renderVerifiedBadge($iconPath . 'admin.svg', true); ?> <span><?php echo iN_HelpSecure($roleIsAdmin ? $isAdminLabel : $makeAdminLabel, false); ?></span></button>
          <?php endif; ?>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>

  <div class="admin-section">
    <h3>Quick links</h3>
    <?php $pUrl = iN_HelpSecure($base_url . 'profile/' . rawurlencode($username), false); ?>
    <div class="ud-actions">
      <a class="btn gap" href="<?= $pUrl; ?>"><?php echo renderVerifiedBadge($iconPath . 'link_out.svg', true); ?> <span>View Profile</span></a>
      <a class="btn gap" href="<?= $pUrl; ?>/followers"><?php echo renderVerifiedBadge($iconPath . 'follower.svg', true); ?> <span>Followers</span></a>
      <a class="btn gap" href="<?= $pUrl; ?>/following"><?php echo renderVerifiedBadge($iconPath . 'following.svg', true); ?> <span>Following</span></a>
    </div>
  </div>

  <form id="adminUserForm" class="form-container admin-section flex flexBoxColumn" method="post" action="<?= iN_HelpSecure(($base_url ?? '/') . 'admin/request/user_update.php', false); ?>" data-action="save-user">
    <input type="hidden" name="user_id" value="<?= (int)$uid; ?>">

    <h3>Basic</h3>
    <div class="form-grid">
    <div class="form-input-wrapper">
      <label class="form-label" for="username">Username</label>
      <input id="username" class="form-input" type="text" name="username" value="<?= iN_HelpSecure($username, false); ?>"<?= $canEditProfile ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="user_fullname">Full name</label>
      <input id="user_fullname" class="form-input" type="text" name="user_fullname" value="<?= iN_HelpSecure($fullname, false); ?>"<?= $canEditProfile ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="user_email">Email</label>
      <input id="user_email" class="form-input" type="email" name="user_email" value="<?= iN_HelpSecure($email, false); ?>"<?= $canEditEmail ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="user_phone">Phone</label>
      <input id="user_phone" class="form-input" type="tel" name="user_phone" value="<?= iN_HelpSecure($phone, false); ?>" maxlength="32" placeholder="+15551234567"<?= $canEditProfile ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="about_me">About</label>
      <textarea id="about_me" class="form-input" name="about_me" rows="3"<?= $canEditProfile ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?= iN_HelpSecure((string)($user['about_me'] ?? ''), false); ?></textarea>
    </div>

    <h3>Access & Status</h3>
    <?php if (!$isModeratorActor): ?>
      <div class="form-input-wrapper">
        <label class="form-label" for="role">Role</label>
        <?php $curRole = $mode !== '' ? strtolower($mode) : (($type>=3)?'admin':(($type===2)?'moderator':'user')); ?>
        <?php $disableRoleSelect = $isOwnerTarget || ($isSelfTarget && $myType >= 3) || !$canUserSetRole; ?>
        <?php $roleDisableTip = !$canUserSetRole ? $permissionTip : (customLang('admin_users_action_self_role_tip') ?: 'Admins cannot change their own role.'); ?>
        <select id="role" name="role" class="form-input"<?= $disableRoleSelect ? ' disabled aria-disabled="true" title="' . iN_HelpSecure($roleDisableTip, false) . '"' : ''; ?>>
          <?php foreach (['user'=>'User','moderator'=>'Moderator','admin'=>'Admin'] as $rk=>$rt): ?>
            <?php if ($isSelfTarget && $myType >= 3 && $rk !== 'admin') { /* hide lower roles for self */ continue; } ?>
            <option value="<?= $rk; ?>"<?= $curRole===$rk?' selected':''; ?>><?= $rt; ?></option>
          <?php endforeach; ?>
        </select>
        <?php if ($isOwnerTarget): ?>
          <div class="text-muted fs-13 mt-1">Owner role cannot be changed.</div>
        <?php elseif ($isSelfTarget && $myType >= 3): ?>
          <div class="text-muted fs-13 mt-1">You cannot demote your own account.</div>
        <?php elseif (!$canUserSetRole): ?>
          <div class="text-muted fs-13 mt-1"><?php echo iN_HelpSecure($permissionTip, false); ?></div>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <div class="form-input-wrapper">
      <label class="form-label" for="verified_status">Verified</label>
      <select id="verified_status" name="verified_status" class="form-input"<?= $canUserManage ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>>
        <option value="0"<?= $verified? '':' selected'; ?>>No</option>
        <option value="1"<?= $verified? ' selected':''; ?>>Yes</option>
      </select>
    </div>

    <div class="form-input-wrapper">
      <label class="form-label" for="is_banned">Banned</label>
      <select id="is_banned" name="is_banned" class="form-input"<?= $canUserBan ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>>
        <option value="0"<?= $isBanned? '':' selected'; ?>>No</option>
        <option value="1"<?= $isBanned? ' selected':''; ?>>Yes</option>
      </select>
    </div>

    <div class="form-input-wrapper">
      <label class="form-label" for="who_can_send_message">Who can message</label>
      <?php $wcsm = (string)($user['who_can_send_message'] ?? 'everyone'); ?>
      <select id="who_can_send_message" name="who_can_send_message" class="form-input"<?= $canUserManage ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>>
        <?php foreach (['everyone'=>'Everyone','followers'=>'Followers','subscribers'=>'Subscribers'] as $k=>$v): ?>
          <option value="<?= $k; ?>"<?= $wcsm===$k?' selected':''; ?>><?= $v; ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="form-input-wrapper">
      <label class="form-label" for="subscription_status">Subscription status</label>
      <?php $ss = (string)($user['subscription_status'] ?? 'close'); ?>
      <select id="subscription_status" name="subscription_status" class="form-input"<?= $canUserManage ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>>
        <option value="open"<?= $ss==='open'?' selected':''; ?>>Open</option>
        <option value="close"<?= $ss==='close'?' selected':''; ?>>Close</option>
      </select>
    </div>

    <div class="form-input-wrapper">
      <label class="form-label" for="subscrition_status">Account status</label>
      <?php $as = (string)($user['subscrition_status'] ?? 'passive'); ?>
      <select id="subscrition_status" name="subscrition_status" class="form-input"<?= $canUserManage ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>>
        <option value="active"<?= $as==='active'?' selected':''; ?>>Active</option>
        <option value="passive"<?= $as!=='active'?' selected':''; ?>>Passive</option>
      </select>
    </div>

    <h3>Creator onboarding</h3>
    <div class="form-input-wrapper">
      <div class="creator-status-line flex align_items gap">
        <span class="creator-badge <?= iN_HelpSecure($creatorStatusClass, false); ?>">Status: <?= ucfirst(iN_HelpSecure($creatorStatus, false)); ?></span>
        <span class="text-muted fs-13">Updated: <?= iN_HelpSecure($creatorStatusUpdated, false); ?></span>
      </div>
      <?php if ($verificationSubmitted !== '-' || $verificationNote !== ''): ?>
        <div class="text-muted fs-13 mt-2">Last submission: <?= iN_HelpSecure($verificationSubmitted, false); ?></div>
        <?php if ($verificationNote !== ''): ?>
          <div class="text-muted fs-13">Applicant note: <?= nl2br(iN_HelpSecure($verificationNote, false)); ?></div>
        <?php endif; ?>
        <?php if ($verificationAdminNote !== ''): ?>
          <div class="text-muted fs-13">Admin note: <?= nl2br(iN_HelpSecure($verificationAdminNote, false)); ?></div>
        <?php endif; ?>
      <?php else: ?>
        <div class="text-muted fs-13 mt-2">No verification request submitted yet.</div>
      <?php endif; ?>
    </div>

    <?php if (!empty($verificationDocs)): ?>
      <div class="form-input-wrapper">
        <label class="form-label">Uploaded documents</label>
        <ul class="doc-list doc-list--compact">
          <?php foreach ($verificationDocs as $key => $value): ?>
            <?php $labelTemplate = $verificationDocLabels[$key] ?? ucfirst(str_replace('_', ' ', (string)$key)); ?>
            <?php if (is_array($value)): ?>
              <?php foreach ($value as $idx => $path): ?>
                <?php if (!$path) { continue; } ?>
                <?php $indexLabel = (int)$idx + 1; ?>
                <?php $label = (strpos((string)$labelTemplate, '{index}') !== false)
                  ? str_replace('{index}', (string)$indexLabel, (string)$labelTemplate)
                  : $labelTemplate . ' #' . $indexLabel; ?>
                <li><a href="<?= iN_HelpSecure(($base_url ?? '/') . ltrim($path, '/'), false); ?>" target="_blank" rel="noopener"><?= iN_HelpSecure($label, false); ?></a></li>
              <?php endforeach; ?>
            <?php elseif ($value): ?>
              <?php $label = (strpos((string)$labelTemplate, '{index}') !== false)
                ? str_replace('{index}', '1', (string)$labelTemplate)
                : $labelTemplate; ?>
              <li><a href="<?= iN_HelpSecure(($base_url ?? '/') . ltrim((string)$value, '/'), false); ?>" target="_blank" rel="noopener"><?= iN_HelpSecure($label, false); ?></a></li>
            <?php endif; ?>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <div class="form-input-wrapper">
      <label class="form-label" for="creator_status">Update status</label>
      <select id="creator_status" name="creator_status" class="form-input"<?= $canVerify ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>>
        <?php foreach (['none'=>'Reset (none)','pending'=>'Pending','approved'=>'Approved','rejected'=>'Rejected'] as $csValue => $csLabel): ?>
          <option value="<?= $csValue; ?>"<?= $creatorStatus === $csValue ? ' selected' : ''; ?>><?= $csLabel; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="creator_admin_note">Admin note</label>
      <textarea id="creator_admin_note" class="form-input" name="creator_admin_note" rows="2" placeholder="Optional note sent to creator on approval/rejection."<?= $canVerify ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?= iN_HelpSecure($verificationAdminNote, false); ?></textarea>
      <div class="text-muted fs-12 mt-1">If you approve or reject the application, this note is sent to the creator in the notification.</div>
    </div>

    <?php if ($canEditWallet): ?>
      <div class="form-input-wrapper">
        <label class="form-label" for="wallet">Wallet</label>
        <input id="wallet" class="form-input" type="number" step="0.01" name="wallet" value="<?= iN_HelpSecure((string)($user['wallet'] ?? '0'), false); ?>">
      </div>
      <div class="form-input-wrapper">
        <label class="form-label" for="earned">Earned</label>
        <input id="earned" class="form-input" type="number" step="0.01" name="earned" value="<?= iN_HelpSecure((string)($user['earned'] ?? '0'), false); ?>">
      </div>

      <div class="form-input-wrapper">
        <label class="form-label" for="for_billing_first_name">Billing first name</label>
        <input id="for_billing_first_name" class="form-input" type="text" name="for_billing_first_name" value="<?= iN_HelpSecure((string)($user['for_billing_first_name'] ?? ''), false); ?>">
      </div>
      <div class="form-input-wrapper">
        <label class="form-label" for="for_billing_last_name">Billing last name</label>
        <input id="for_billing_last_name" class="form-input" type="text" name="for_billing_last_name" value="<?= iN_HelpSecure((string)($user['for_billing_last_name'] ?? ''), false); ?>">
      </div>
      <div class="form-input-wrapper">
        <label class="form-label" for="country_code">Country</label>
        <?php
          // Resolve current country code from stored name or code
          $countryStored = (string)($user['for_billing_country'] ?? '');
          $countryCode = '';
          if (isset($countries) && is_array($countries)) {
            $keys = array_keys($countries);
            if (strlen($countryStored) === 2 && isset($countries[strtoupper($countryStored)])) {
              $countryCode = strtoupper($countryStored);
            } else {
              // match by name (case-insensitive)
              foreach ($countries as $cc => $nm) { if (strcasecmp($nm, $countryStored) === 0) { $countryCode = $cc; break; } }
            }
          }
        ?>
        <select id="country_code" name="country_code" class="form-input">
          <?php if (isset($countries) && is_array($countries)): foreach ($countries as $cc => $nm): ?>
            <option value="<?= iN_HelpSecure($cc, false); ?>"<?= ($countryCode===$cc?' selected':''); ?>><?= iN_HelpSecure($nm, false); ?></option>
          <?php endforeach; endif; ?>
        </select>
      </div>
      <div class="form-input-wrapper">
        <label class="form-label" for="for_billing_city">City</label>
        <input id="for_billing_city" class="form-input" type="text" name="for_billing_city" value="<?= iN_HelpSecure((string)($user['for_billing_city'] ?? ''), false); ?>">
      </div>
      <div class="form-input-wrapper">
        <label class="form-label" for="for_billing_state">State</label>
        <input id="for_billing_state" class="form-input" type="text" name="for_billing_state" value="<?= iN_HelpSecure((string)($user['for_billing_state'] ?? ''), false); ?>">
      </div>
      <div class="form-input-wrapper">
        <label class="form-label" for="for_billing_postcode">Postcode</label>
        <input id="for_billing_postcode" class="form-input" type="text" name="for_billing_postcode" value="<?= iN_HelpSecure((string)($user['for_billing_postcode'] ?? ''), false); ?>">
      </div>
      <div class="form-input-wrapper">
        <label class="form-label" for="for_billing_address">Address</label>
        <textarea id="for_billing_address" class="form-input" name="for_billing_address" rows="2"><?= iN_HelpSecure((string)($user['for_billing_address'] ?? ''), false); ?></textarea>
      </div>

      <div class="form-input-wrapper">
        <label class="form-label" for="payout_method">Payout method</label>
        <select id="payout_method" name="payout_method" class="form-input">
          <?php foreach (['none'=>'None','bank'=>'Bank transfer','paypal'=>'PayPal','other'=>'Other'] as $pmValue => $pmLabel): ?>
            <option value="<?= $pmValue; ?>"<?= $payoutMethod === $pmValue ? ' selected' : ''; ?>><?= $pmLabel; ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-input-wrapper">
        <label class="form-label" for="payout_details_json">Payout details</label>
        <textarea id="payout_details_json" class="form-input" name="payout_details_json" rows="4" placeholder="JSON or free-form notes about the payout account."><?= iN_HelpSecure($payoutDetailsRaw, false); ?></textarea>
        <div class="text-muted fs-12 mt-1">Provide structured JSON (e.g., {"iban":"TR00..."}) or plain text for the finance team.</div>
      </div>
    <?php endif; ?>

    <div class="form-input-wrapper">
      <label class="form-label" for="new_password">Set new password</label>
      <input id="new_password" class="form-input" type="password" name="new_password" autocomplete="new-password"<?= $canResetPassword ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>>
    </div>
    </div>

  </form>

  <div class="admin-section">
    <h3>Avatar & Cover</h3>
    <div class="profile-media-row">
      <div class="pm-avatar pm-box">
        <img id="avatarPreviewImg" src="<?= iN_HelpSecure($avatar, false); ?>" alt="avatar" />
        <?php $avatarTitle = $canEditProfile ? 'Change avatar' : $permissionTip; ?>
        <button type="button" class="pm-edit pm-avatar" title="<?= iN_HelpSecure($avatarTitle, false); ?>"<?= $canEditProfile ? '' : ' disabled aria-disabled="true"'; ?>><?= renderVerifiedBadge($iconPath . 'image.svg', true); ?></button>
        <input type="file" name="avatar" accept="image/*" class="none"<?= $canEditProfile ? '' : ' disabled aria-disabled="true"'; ?> />
      </div>
      <div class="pm-cover pm-box">
        <img id="coverPreviewImg" src="<?= iN_HelpSecure($cover, false); ?>" alt="cover" />
        <?php $coverTitle = $canEditProfile ? 'Change cover' : $permissionTip; ?>
        <button type="button" class="pm-edit pm-cover" title="<?= iN_HelpSecure($coverTitle, false); ?>"<?= $canEditProfile ? '' : ' disabled aria-disabled="true"'; ?>><?= renderVerifiedBadge($iconPath . 'image.svg', true); ?></button>
        <input type="file" name="cover" accept="image/*" class="none"<?= $canEditProfile ? '' : ' disabled aria-disabled="true"'; ?> />
      </div>
    </div>
    <div class="ud-actions mt-3">Tip: Use “Save changes” to upload cropped avatar/cover.</div>
  </div>
  <div class="admin-actions">
    <button type="submit" form="adminUserForm" class="pe-save btn-hover transition"<?= $canSaveUser ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>>Save changes</button>
  </div>
</section>
