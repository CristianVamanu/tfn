<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $ADM, $base_url, $iconPath, $currencies, $currencyFormatSettings;

$pageKey   = 'wallet_topups';
$pageTitle = customLang('admin_wallet_topups_title');
$iconName  = 'payments.svg';

$q        = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
$status   = isset($_GET['status']) ? trim((string)$_GET['status']) : '';
$provider = isset($_GET['provider']) ? trim((string)$_GET['provider']) : '';
$page     = isset($_GET['page_no']) ? max(1, (int)$_GET['page_no']) : 1;
$per      = isset($_GET['per']) ? max(5, min(100, (int)$_GET['per'])) : 20;

$data     = $ADM->ADM_PagedWalletTopups($q, $status, $provider, $page, $per);
$rows     = $data['rows'];
$total    = (int)$data['total'];
$pages    = (int)max(1, ceil($total / max(1, $per)));

$availableStatuses  = $ADM->ADM_WalletTopupStatuses();
$availableProviders = $ADM->ADM_WalletTopupProviders();

$statusLabels = [
    ''           => customLang('admin_wallet_topups_status_any'),
    'succeeded'  => customLang('admin_wallet_topups_status_succeeded'),
    'pending'    => customLang('admin_wallet_topups_status_pending'),
    'failed'     => customLang('admin_wallet_topups_status_failed'),
    'canceled'   => customLang('admin_wallet_topups_status_canceled'),
    'cancelled'  => customLang('admin_wallet_topups_status_canceled'),
    'refunded'   => customLang('admin_wallet_topups_status_refunded'),
];
$statusOptions = ['' => $statusLabels['']];
foreach ($availableStatuses as $st) {
    if ($st === '') {
        continue;
    }
    $key = strtolower($st);
    $statusOptions[$st] = $statusLabels[$key] ?? ucfirst($st);
}

$providerOptions = ['' => customLang('admin_wallet_topups_provider_any')];
foreach ($availableProviders as $prov) {
    if ($prov === '') {
        continue;
    }
    $providerOptions[$prov] = ucfirst($prov);
}

$currenciesMap = isset($currencies) && is_array($currencies) ? $currencies : [];
$currencyFormatSettings = $currencyFormatSettings ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
$resolvePrecision = static function (string $currencyCode) use ($currencyFormatSettings): int {
    return dz_currency_resolve_precision($currencyCode, (int) ($currencyFormatSettings['decimal_places'] ?? 2));
};
$formatAmount = static function (?int $minor, string $currencyCode, array $currencyMap) use ($resolvePrecision, $currencyFormatSettings): string {
    if ($minor === null) {
        return '—';
    }
    $code = strtoupper($currencyCode ?: ($GLOBALS['currency'] ?? 'USD'));
    $precision = $resolvePrecision($code);
    $factor = pow(10, max(0, $precision));
    if ($factor <= 0) {
        $factor = 1;
    }
    $value = (float) $minor / $factor;
    $symbol = $currencyMap[$code] ?? null;

    return dz_format_currency($value, $code, $symbol, $currencyFormatSettings);
};

?>
<section class="card rounded-2xl" role="region" aria-labelledby="walletTopupsHeading">
  <div class="list-header" id="walletTopupsHeading">
    <span class="icon"><?= renderVerifiedBadge($iconPath . $iconName, true); ?></span>
    <span><strong><?= iN_HelpSecure($pageTitle, false); ?></strong></span>
  </div>

  <form method="get" class="form-container form-container--columns" action="<?= iN_HelpSecure($base_url . 'admin/index.php', false); ?>">
    <input type="hidden" name="page" value="<?= iN_HelpSecure($pageKey, false); ?>">
    <div class="form-input-wrapper" data-field="search">
      <label class="form-label" for="wallet-topups-q"><?= iN_HelpSecure(customLang('admin_wallet_topups_search_label'), false); ?></label>
      <input
          id="wallet-topups-q"
          class="form-input"
          type="text"
          name="q"
          value="<?= iN_HelpSecure($q, false); ?>"
          placeholder="<?= iN_HelpSecure(customLang('admin_wallet_topups_search_placeholder'), false); ?>"
      >
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="wallet-topups-provider"><?= iN_HelpSecure(customLang('admin_wallet_topups_provider_label'), false); ?></label>
      <select id="wallet-topups-provider" name="provider" class="form-input">
        <?php foreach ($providerOptions as $provValue => $provLabel): ?>
          <option value="<?= iN_HelpSecure($provValue, false); ?>"<?= $provider === $provValue ? ' selected' : ''; ?>>
            <?= iN_HelpSecure($provLabel, false); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="wallet-topups-status"><?= iN_HelpSecure(customLang('admin_wallet_topups_status_label'), false); ?></label>
      <select id="wallet-topups-status" name="status" class="form-input">
        <?php foreach ($statusOptions as $optValue => $optLabel): ?>
          <option value="<?= iN_HelpSecure((string)$optValue, false); ?>"<?= $status === (string)$optValue ? ' selected' : ''; ?>>
            <?= iN_HelpSecure($optLabel, false); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="wallet-topups-per"><?= iN_HelpSecure(customLang('admin_wallet_topups_per_page'), false); ?></label>
      <select id="wallet-topups-per" name="per" class="form-input">
        <?php foreach ([10, 20, 50, 100] as $pp): ?>
          <option value="<?= $pp; ?>"<?= $pp === $per ? ' selected' : ''; ?>><?= $pp; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper form-actions">
      <label class="form-label sr-only" for="wallet-topups-submit"><?= iN_HelpSecure(customLang('admin_wallet_topups_apply'), false); ?></label>
      <button id="wallet-topups-submit" type="submit" class="pe-save btn-hover"><?= iN_HelpSecure(customLang('admin_wallet_topups_apply'), false); ?></button>
    </div>
  </form>

  <div class="table-responsive mt-4">
    <table class="table table-striped table-sm table-subs">
      <thead>
        <tr>
          <th><?= iN_HelpSecure(customLang('admin_wallet_topups_col_id'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_wallet_topups_col_user'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_wallet_topups_col_provider'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_wallet_topups_col_status'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_wallet_topups_col_amount'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_wallet_topups_col_fee'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_wallet_topups_col_tax'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_wallet_topups_col_net'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_wallet_topups_col_created'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_wallet_topups_col_credited'), false); ?></th>
        </tr>
      </thead>
      <tbody>
      <?php if (empty($rows)): ?>
        <tr>
          <td colspan="10" class="text-center text-muted empty_class_table">
            <?= iN_HelpSecure(customLang('admin_wallet_topups_empty'), false); ?>
          </td>
        </tr>
      <?php else: foreach ($rows as $row):
        $id        = (int)($row['id'] ?? 0);
        $username  = (string)($row['user_username'] ?? '');
        $display   = (string)($row['user_fullname'] ?? $username);
        $avatar    = admin_resolve_media_url((string)($row['user_avatar'] ?? 'uploads/user_avatars/default.jpeg'));
        $userUrl   = ($base_url ?? '/') . 'profile/' . rawurlencode($username);
        $providerName = (string)($row['provider'] ?? '');
        $reference = (string)($row['reference'] ?? '');
        $statusRaw = strtolower((string)($row['status'] ?? ''));
        $statusLabel = $statusLabels[$statusRaw] ?? ucfirst($statusRaw);
        $statusClass = 'pill-gray';
        if ($statusRaw === 'succeeded') {
            $statusClass = 'pill-green';
        } elseif (in_array($statusRaw, ['failed', 'canceled', 'cancelled'], true)) {
            $statusClass = 'pill-red';
        }
        $currencyCode = strtoupper((string)($row['currency'] ?? ''));
        $amount = $formatAmount($row['amount_minor'] ?? null, $currencyCode, $currenciesMap);
        $fee    = $formatAmount($row['fee_minor'] ?? null, $currencyCode, $currenciesMap);
        $tax    = $formatAmount($row['tax_minor'] ?? null, $currencyCode, $currenciesMap);
        $net    = $formatAmount($row['net_minor'] ?? null, $currencyCode, $currenciesMap);
        $createdAt  = isset($row['created_at']) && $row['created_at'] ? date('d/m/Y H:i', (int)$row['created_at']) : '-';
        $creditedAt = isset($row['credited_at']) && $row['credited_at'] ? date('d/m/Y H:i', (int)$row['credited_at']) : '-';
        $providerDisplay = $providerName !== '' ? ucfirst($providerName) : customLang('admin_wallet_topups_provider_any');
        $referenceDisplay = $reference !== '' ? $reference : '—';
      ?>
        <tr>
          <td><?= $id; ?></td>
          <td>
            <?php $userAlt = sprintf(customLang('alt_avatar_of_user'), $display); ?>
            <a class="user-pill" href="<?= iN_HelpSecure($userUrl, false); ?>">
              <img class="avatar-32" src="<?= iN_HelpSecure($avatar, false); ?>" alt="<?= iN_HelpSecure($userAlt, false); ?>">
              <span class="name"><?= iN_HelpSecure($display, false); ?></span>
            </a>
          </td>
          <td>
            <div class="flex align_items space_between">
              <span class="amount-mono fw-600"><?= iN_HelpSecure($providerDisplay, false); ?></span>
              <span class="amount-mono text-muted fs-13"><?= iN_HelpSecure($referenceDisplay, false); ?></span>
            </div>
          </td>
          <td><span class="pill <?= $statusClass; ?>"><?= iN_HelpSecure($statusLabel, false); ?></span></td>
          <td class="amount-mono"><?= iN_HelpSecure($amount, false); ?></td>
          <td class="amount-mono"><?= iN_HelpSecure($fee, false); ?></td>
          <td class="amount-mono"><?= iN_HelpSecure($tax, false); ?></td>
          <td class="amount-mono"><?= iN_HelpSecure($net, false); ?></td>
          <td class="text-muted fs-13"><?= iN_HelpSecure($createdAt, false); ?></td>
          <td class="text-muted fs-13"><?= iN_HelpSecure($creditedAt, false); ?></td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <?php
    echo dz_render_pagination(
        $base_url . 'admin/index.php',
        [
          'page'     => $pageKey,
          'q'        => $q,
          'status'   => $status,
          'provider' => $provider,
          'per'      => (string)$per,
        ],
        (int)$page,
        (int)$pages,
        [ 'show_goto' => true, 'radius' => 1 ]
    );
  ?>
</section>
