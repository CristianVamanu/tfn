<?php
declare(strict_types=1);
require_once __DIR__ . '/../../_bootstrap.php'; // Guard admin access

global $siteData, $base_url, $ADMIN_CSRF, $currencies, $currencys;

// Current (masked) values
$stripeSecret        = (string)($siteData['stripe_secret'] ?? '');
$stripeWebhookSecret = (string)($siteData['stripe_webhook_secret'] ?? '');
$stripeCurrency      = strtoupper((string)($siteData['stripe_currency'] ?? 'USD'));
$paypalClientId      = (string)($siteData['paypal_client_id'] ?? '');
$paypalClientSecret  = (string)($siteData['paypal_client_secret'] ?? '');
$paypalWebhookId     = (string)($siteData['paypal_webhook_id'] ?? '');
$paypalEnv           = (string)($siteData['paypal_env'] ?? 'sandbox');
$paypalCurrency      = strtoupper((string)($siteData['paypal_currency'] ?? 'USD'));
$nowApiKey           = (string)($siteData['nowpayments_api_key'] ?? '');
$nowWebhookSecret    = (string)($siteData['nowpayment_webhook_secret_key'] ?? ($siteData['nowpayments_webhook_secret'] ?? ''));
$nowPaymentCurrency  = strtoupper((string)($siteData['now_payment_currency'] ?? 'BTC'));
$coinbaseApiKey      = (string)($siteData['coinbase_commerce_api_key'] ?? '');
$coinbaseWebhook     = (string)($siteData['coinbase_commerce_webhook_secret'] ?? '');
$coinbaseCurrency    = strtoupper((string)($siteData['coinbase_currency'] ?? 'BTC'));
$flutterwavePublicKey     = (string)($siteData['flutterwave_public_key'] ?? '');
$flutterwaveSecretKey     = (string)($siteData['flutterwave_secret_key'] ?? '');
$flutterwaveEncryptionKey = (string)($siteData['flutterwave_encryption_key'] ?? '');
$flutterwaveSecretHash    = (string)($siteData['flutterwave_secret_hash'] ?? '');
$flutterwaveCurrency      = strtoupper((string)($siteData['flutterwave_currency'] ?? ''));
$paystackPublicKey        = (string)($siteData['paystack_public_key'] ?? '');
$paystackSecretKey        = (string)($siteData['paystack_secret_key'] ?? '');
$paystackWebhookSecret    = (string)($siteData['paystack_webhook_secret'] ?? '');
$paystackCurrency         = strtoupper((string)($siteData['paystack_currency'] ?? ''));
$paystackMerchantEmail    = (string)($siteData['paystack_merchant_email'] ?? '');
$iyzicoApiKey             = (string)($siteData['iyzico_api_key'] ?? '');
$iyzicoSecretKey          = (string)($siteData['iyzico_secret_key'] ?? '');
$iyzicoWebhookSecret      = (string)($siteData['iyzico_webhook_secret'] ?? '');
$iyzicoCurrency           = strtoupper((string)($siteData['iyzico_currency'] ?? ''));
$iyzicoApiBase            = (string)($siteData['iyzico_api_base'] ?? '');
$payuMerchantPosId        = (string)($siteData['payu_merchant_pos_id'] ?? '');
$payuMerchantId           = (string)($siteData['payu_merchant_id'] ?? '');
$payuClientId             = (string)($siteData['payu_client_id'] ?? '');
$payuClientSecret         = (string)($siteData['payu_client_secret'] ?? '');
$payuSignatureKey         = (string)($siteData['payu_signature_key'] ?? '');
$payuCurrency             = strtoupper((string)($siteData['payu_currency'] ?? ''));
$payuApiBase              = (string)($siteData['payu_api_base'] ?? '');
$paymentsCurrency         = strtoupper((string)($siteData['payments_currency'] ?? ($siteData['site_currency'] ?? 'USD')));
// Currency format settings
$currencySymbolPosition   = (string)($siteData['currency_symbol_position'] ?? 'left');
$currencyDecimalPlaces    = (int)($siteData['currency_decimal_places'] ?? 2);
$currencyThousandsSep     = (string)($siteData['currency_thousands_sep'] ?? ',');
$currencyDecimalSep       = (string)($siteData['currency_decimal_sep'] ?? '.');
if (!in_array($currencySymbolPosition, ['left', 'right', 'left_space', 'right_space'], true)) {
    $currencySymbolPosition = 'left';
}
if ($currencyDecimalPlaces < 0) { $currencyDecimalPlaces = 0; }
if ($currencyDecimalPlaces > 8) { $currencyDecimalPlaces = 8; }
$thousandsMap = [',' => ',', '.' => '.', ' ' => ' ', '' => ''];
if (!array_key_exists($currencyThousandsSep, $thousandsMap)) { $currencyThousandsSep = ','; }
if (!in_array($currencyDecimalSep, ['.', ','], true)) { $currencyDecimalSep = '.'; }
if ($currencyThousandsSep === $currencyDecimalSep) { $currencyThousandsSep = ''; }

// Currency options list
$currencyMap = [];
if (isset($currencies) && is_array($currencies) && $currencies) {
    $currencyMap = $currencies;
} elseif (isset($currencys) && is_array($currencys) && $currencys) {
    $currencyMap = $currencys;
} else {
    $currencyFile = dirname(__DIR__, 3) . '/includes/currencies.php';
    if (is_file($currencyFile)) {
        require_once $currencyFile;
    }
    if (isset($currencys) && is_array($currencys)) {
        $currencyMap = $currencys;
    }
}
$currencyOptions = [];
foreach ($currencyMap as $code => $symbol) {
    $code = strtoupper(trim((string) $code));
    if ($code === '') {
        continue;
    }
    $symbol = trim((string) $symbol);
    $label = $code;
    if ($symbol !== '' && $symbol !== $code) {
        $label .= ' (' . $symbol . ')';
    }
    $currencyOptions[$code] = $label;
}
if ($currencyOptions) {
    ksort($currencyOptions);
}
$currencyCodes = array_keys($currencyOptions);
if ($paymentsCurrency === '' || !isset($currencyOptions[$paymentsCurrency])) {
    $paymentsCurrency = $currencyCodes[0] ?? 'USD';
}
if ($stripeCurrency === '' || !isset($currencyOptions[$stripeCurrency])) {
    $stripeCurrency = $paymentsCurrency;
}
if ($paypalCurrency === '' || !isset($currencyOptions[$paypalCurrency])) {
    $paypalCurrency = $paymentsCurrency;
}
if ($nowPaymentCurrency === '' || !isset($currencyOptions[$nowPaymentCurrency])) {
    $nowPaymentCurrency = isset($currencyOptions['BTC']) ? 'BTC' : $paymentsCurrency;
}
if ($coinbaseCurrency === '' || !isset($currencyOptions[$coinbaseCurrency])) {
    $coinbaseCurrency = isset($currencyOptions['BTC']) ? 'BTC' : $paymentsCurrency;
}
if ($flutterwaveCurrency !== '' && !isset($currencyOptions[$flutterwaveCurrency])) {
    $flutterwaveCurrency = '';
}
if ($paystackCurrency !== '' && !isset($currencyOptions[$paystackCurrency])) {
    $paystackCurrency = '';
}
if ($iyzicoCurrency !== '' && !isset($currencyOptions[$iyzicoCurrency])) {
    $iyzicoCurrency = '';
}
if ($payuCurrency !== '' && !isset($currencyOptions[$payuCurrency])) {
    $payuCurrency = '';
}

$inheritGlobalTpl = customLang('admin_currency_inherit_global');
if (!is_string($inheritGlobalTpl) || $inheritGlobalTpl === '' || $inheritGlobalTpl === 'admin_currency_inherit_global') {
    $inheritGlobalTpl = 'Use global payments currency (%s)';
}
$inheritGlobalLabel = sprintf($inheritGlobalTpl, $paymentsCurrency);
// Provider statuses from DB (enum open/close). Default: close when missing.
$statusVal = static function($v): string { $s = strtolower((string)$v); return ($s === 'open' || $s === 'close') ? $s : 'close'; };
$stripeStatus      = $statusVal($siteData['stripe_status'] ?? 'close');
$paypalStatus      = $statusVal($siteData['paypal_status'] ?? 'close');
$nowpaymentStatus  = $statusVal($siteData['nowpayment_status'] ?? 'close');
$coinbaseStatus    = $statusVal($siteData['coinbase_status'] ?? 'close');
$flutterwaveStatus = $statusVal($siteData['flutterwave_status'] ?? 'close');
$paystackStatus    = $statusVal($siteData['paystack_status'] ?? 'close');
$iyzicoStatus      = $statusVal($siteData['iyzico_status'] ?? 'close');
$payuStatus        = $statusVal($siteData['payu_status'] ?? 'close');

function maskVal(string $v): string { return $v !== '' ? str_repeat('•', 8) : ''; }

$actionUrl   = htmlspecialchars($base_url . 'admin/request/payment_settings.php', ENT_QUOTES, 'UTF-8');
$csrfToken   = htmlspecialchars($ADMIN_CSRF, ENT_QUOTES, 'UTF-8');
$paypalHook   = htmlspecialchars(rtrim($base_url, '/') . '/request/webhooks.php?provider=paypal', ENT_QUOTES, 'UTF-8');
$stripeHook   = htmlspecialchars(rtrim($base_url, '/') . '/request/webhooks.php?provider=stripe', ENT_QUOTES, 'UTF-8');
$nowHook      = htmlspecialchars(rtrim($base_url, '/') . '/request/webhooks.php?provider=nowpayments', ENT_QUOTES, 'UTF-8');
$coinbaseHook = htmlspecialchars(rtrim($base_url, '/') . '/request/webhooks.php?provider=coinbase', ENT_QUOTES, 'UTF-8');
$flutterwaveHook = htmlspecialchars(rtrim($base_url, '/') . '/request/webhooks.php?provider=flutterwave', ENT_QUOTES, 'UTF-8');
$paystackHook = htmlspecialchars(rtrim($base_url, '/') . '/request/webhooks.php?provider=paystack', ENT_QUOTES, 'UTF-8');
$iyzicoHook = htmlspecialchars(rtrim($base_url, '/') . '/request/webhooks.php?provider=iyzico', ENT_QUOTES, 'UTF-8');
$payuHook = htmlspecialchars(rtrim($base_url, '/') . '/request/webhooks.php?provider=payu', ENT_QUOTES, 'UTF-8');

$pageTitleText = customLang('admin_settings_payments_title');
if (!is_string($pageTitleText) || $pageTitleText === '' || $pageTitleText === 'admin_settings_payments_title') {
    $pageTitleText = 'Settings · Payments';
}
$pageIntroMain = customLang('admin_env_priority_intro');
if (!is_string($pageIntroMain) || $pageIntroMain === '' || $pageIntroMain === 'admin_env_priority_intro') {
    $pageIntroMain = 'Runtime resolves secrets with precedence: ENV → DB. Prefer ENV in production; keep DB as fallback for development/testing.';
}
$pageIntroExamples = customLang('admin_env_var_examples');
if (!is_string($pageIntroExamples) || $pageIntroExamples === '' || $pageIntroExamples === 'admin_env_var_examples') {
    $pageIntroExamples = 'Examples: STRIPE_SECRET, STRIPE_WEBHOOK_SECRET, PAYPAL_CLIENT_ID, PAYPAL_WEBHOOK_ID, NOWPAYMENTS_API_KEY, COINBASE_COMMERCE_WEBHOOK_SECRET.';
}

$pageTitleSafe = iN_HelpSecure($pageTitleText, false);
?>

<section class="card rounded-2xl admin-settings" role="region" aria-labelledby="adminPaymentSettingsHeading" data-page-title="<?= $pageTitleSafe ?>">
  <h1 id="adminPaymentSettingsHeading"><?= $pageTitleSafe ?></h1>
  <p class="box-note full-width text-muted fs-13 admin-payments-intro">
    <?= iN_HelpSecure($pageIntroMain, false) ?><br>
    <span class="admin-payments-intro__hint"><?= iN_HelpSecure($pageIntroExamples, false) ?></span>
  </p>

  <form method="post" action="<?= $actionUrl ?>" class="form-container flex flexBoxColumn admin-payments-settings-form" data-action="save-payments">
    <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('admin_payments_currency_title') ?: 'Global payments currency'); ?></legend>
      <div class="form-grid form-grid--half admin-payments-grid">
        <div class="form-input-wrapper">
          <label class="form-label" for="payments_currency"><?php echo iN_HelpSecure(customLang('admin_payments_currency_label') ?: 'Payments currency'); ?></label>
          <select id="payments_currency" class="form-input" name="payments_currency">
            <?php foreach ($currencyOptions as $code => $label): ?>
              <option value="<?= $code ?>"<?= $code === $paymentsCurrency ? ' selected' : '' ?>><?php echo iN_HelpSecure($label, false); ?></option>
            <?php endforeach; ?>
          </select>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_payments_currency_hint') ?: 'Used as the default currency for all payment providers unless overridden.', false); ?></p>
        </div>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('admin_currency_format_title', 'Currency formatting')); ?></legend>
      <div class="form-grid form-grid--half admin-payments-grid">
        <div class="form-input-wrapper">
          <label class="form-label" for="currency_symbol_position"><?php echo iN_HelpSecure(customLang('admin_currency_symbol_position_label', 'Currency symbol position')); ?></label>
          <select id="currency_symbol_position" class="form-input" name="currency_symbol_position">
            <?php
            $symbolOptions = [
                'left'         => customLang('admin_currency_symbol_left', 'Left of amount'),
                'left_space'   => customLang('admin_currency_symbol_left_space', 'Left with space'),
                'right'        => customLang('admin_currency_symbol_right', 'Right of amount'),
                'right_space'  => customLang('admin_currency_symbol_right_space', 'Right with space'),
            ];
            foreach ($symbolOptions as $key => $label): ?>
              <option value="<?= $key ?>"<?= $key === $currencySymbolPosition ? ' selected' : '' ?>><?php echo iN_HelpSecure($label, false); ?></option>
            <?php endforeach; ?>
          </select>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_currency_symbol_position_hint', 'Controls where the currency symbol appears for public prices.'), false); ?></p>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="currency_decimal_places"><?php echo iN_HelpSecure(customLang('admin_currency_decimal_places_label', 'Decimal places')); ?></label>
          <input id="currency_decimal_places" class="form-input" type="number" min="0" max="8" name="currency_decimal_places" value="<?= (int) $currencyDecimalPlaces ?>">
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_currency_decimal_places_hint', 'Use 0 to hide decimals. Crypto keeps up to 8 decimals.'), false); ?></p>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="currency_thousands_sep"><?php echo iN_HelpSecure(customLang('admin_currency_thousands_sep_label', 'Thousands separator')); ?></label>
          <select id="currency_thousands_sep" class="form-input" name="currency_thousands_sep">
            <?php
            $thousandsOptions = [
                ','    => customLang('admin_currency_sep_comma', 'Comma (,)'),
                '.'    => customLang('admin_currency_sep_dot', 'Dot (.)'),
                ' '    => customLang('admin_currency_sep_space', 'Space'),
                'none' => customLang('admin_currency_sep_none', 'None'),
            ];
            foreach ($thousandsOptions as $key => $label):
                $isSelected = ($key === 'none' && $currencyThousandsSep === '') || ($key !== 'none' && $currencyThousandsSep === $key);
                ?>
              <option value="<?= $key === ' ' ? 'space' : $key ?>"<?= $isSelected ? ' selected' : '' ?>><?php echo iN_HelpSecure($label, false); ?></option>
            <?php endforeach; ?>
          </select>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_currency_separator_hint', 'Choose how numbers are separated in prices.'), false); ?></p>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="currency_decimal_sep"><?php echo iN_HelpSecure(customLang('admin_currency_decimal_sep_label', 'Decimal separator')); ?></label>
          <select id="currency_decimal_sep" class="form-input" name="currency_decimal_sep">
            <?php
            $decimalOptions = [
                'dot'   => customLang('admin_currency_sep_dot', 'Dot (.)'),
                'comma' => customLang('admin_currency_sep_comma', 'Comma (,)'),
            ];
            foreach ($decimalOptions as $key => $label):
                $isSelected = ($key === 'dot' && $currencyDecimalSep === '.') || ($key === 'comma' && $currencyDecimalSep === ',');
                ?>
              <option value="<?= $key ?>"<?= $isSelected ? ' selected' : '' ?>><?php echo iN_HelpSecure($label, false); ?></option>
            <?php endforeach; ?>
          </select>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_currency_separator_hint', 'Choose how numbers are separated in prices.'), false); ?></p>
        </div>
      </div>
      <div class="form-actions">
        <button type="submit"
                name="action"
                value="update_currency_format"
                class="btn btn-primary">
            <?php echo iN_HelpSecure(customLang('admin_currency_format_save', 'Save formatting')); ?>
        </button>
      </div>
    </fieldset>

    <div class="admin-payments-panel-grid">
      <fieldset class="form-input-wrapper admin-settings-panel admin-payments-panel" data-payment-panel="stripe">
        <legend><?php echo iN_HelpSecure(customLang('pay_provider_stripe') ?: 'Stripe'); ?></legend>
        <div class="admin-payments-toggle">
          <span class="admin-payments-toggle__label"><?php echo iN_HelpSecure(customLang('pay_provider_stripe') ?: 'Stripe'); ?></span>
          <label class="el-switch el-switch-sm" aria-label="Enable Stripe">
            <input type="hidden" name="stripe_status" value="close">
            <input type="checkbox" name="stripe_status" value="open" <?= $stripeStatus === 'open' ? 'checked' : '' ?> />
            <span class="el-switch-style"></span>
          </label>
        </div>
        <div class="form-grid form-grid--half admin-payments-grid">
        <div class="form-input-wrapper">
          <label class="form-label" for="stripe_secret"><?php echo iN_HelpSecure(customLang('admin_field_secret_key') ?: 'Secret Key'); ?></label>
          <input id="stripe_secret" class="form-input" type="password" name="stripe_secret" value="<?= htmlspecialchars(maskVal($stripeSecret), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($stripeSecret), ENT_QUOTES, 'UTF-8') ?>">
          <p class="form-text text-muted fs-13">
            <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
            <?php echo iN_HelpSecure(customLang('admin_help_stripe_secret_text')); ?>
            <a href="https://dashboard.stripe.com/apikeys" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('admin_help_stripe_secret_link_label')); ?></a>.
          </p>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="stripe_webhook_secret"><?php echo iN_HelpSecure(customLang('admin_field_webhook_secret') ?: 'Webhook Secret'); ?></label>
          <input id="stripe_webhook_secret" class="form-input" type="password" name="stripe_webhook_secret" value="<?= htmlspecialchars(maskVal($stripeWebhookSecret), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($stripeWebhookSecret), ENT_QUOTES, 'UTF-8') ?>">
          <p class="form-text text-muted fs-13">
            <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
            <?php echo iN_HelpSecure(customLang('admin_help_stripe_webhook_text')); ?>
            <a href="https://dashboard.stripe.com/webhooks" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('admin_help_stripe_webhook_link_label')); ?></a>.
          </p>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="stripe_currency"><?php echo iN_HelpSecure(customLang('admin_field_currency') ?: 'Currency'); ?></label>
          <select id="stripe_currency" class="form-input" name="stripe_currency">
            <?php foreach ($currencyOptions as $code => $label): ?>
              <option value="<?= $code ?>"<?= $code === $stripeCurrency ? ' selected' : '' ?>><?php echo iN_HelpSecure($label, false); ?></option>
            <?php endforeach; ?>
          </select>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_help_stripe_currency_text') ?: 'Select the currency used by Stripe. Defaults to the global payments currency.', false); ?></p>
        </div>
      </div>
      <div class="admin-payments-note box-note full-width text-muted fs-13">
        <strong><?php echo iN_HelpSecure(customLang('admin_stripe_webhook_help_title') ?: 'Stripe Webhook Help (optional)'); ?></strong><br />
        1) <?php echo iN_HelpSecure(customLang('admin_stripe_webhook_step1_intro') ?: 'In your Stripe dashboard, create a webhook endpoint pointing to:'); ?><br />
        <code><?= $stripeHook ?></code><br />
        2) <?php echo iN_HelpSecure(customLang('admin_stripe_webhook_step2_intro') ?: 'Enable these recommended events:'); ?><br />
        <code>checkout.session.completed</code><br />
        <code>invoice.payment_succeeded</code><br />
        <code>customer.subscription.deleted</code><br />
        <code>customer.subscription.updated</code><br />
        3) <?php echo iN_HelpSecure(customLang('admin_stripe_webhook_step3_intro') ?: 'Copy the Signing Secret and paste it above.'); ?><br />
        <a href="https://dashboard.stripe.com/webhooks" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('admin_stripe_webhook_link_label') ?: 'Stripe Dashboard – Webhooks'); ?></a>
      </div>
      </fieldset>

      <fieldset class="form-input-wrapper admin-settings-panel admin-payments-panel" data-payment-panel="paypal">
        <legend><?php echo iN_HelpSecure(customLang('pay_provider_paypal') ?: 'PayPal'); ?></legend>
        <div class="admin-payments-toggle">
          <span class="admin-payments-toggle__label"><?php echo iN_HelpSecure(customLang('pay_provider_paypal') ?: 'PayPal'); ?></span>
          <label class="el-switch el-switch-sm" aria-label="Enable PayPal">
            <input type="hidden" name="paypal_status" value="close">
            <input type="checkbox" name="paypal_status" value="open" <?= $paypalStatus === 'open' ? 'checked' : '' ?> />
            <span class="el-switch-style"></span>
          </label>
        </div>
        <div class="form-grid form-grid--half admin-payments-grid">
        <div class="form-input-wrapper">
          <label class="form-label" for="paypal_client_id"><?php echo iN_HelpSecure(customLang('admin_field_client_id') ?: 'Client ID'); ?></label>
          <input id="paypal_client_id" class="form-input" type="password" name="paypal_client_id" value="<?= htmlspecialchars(maskVal($paypalClientId), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($paypalClientId), ENT_QUOTES, 'UTF-8') ?>">
          <p class="form-text text-muted fs-13">
            <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
            <?php echo iN_HelpSecure(customLang('admin_help_paypal_app_text')); ?>
            <a href="https://developer.paypal.com/developer/applications" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('admin_help_paypal_app_link_label')); ?></a>.
          </p>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="paypal_client_secret"><?php echo iN_HelpSecure(customLang('admin_field_client_secret') ?: 'Client Secret'); ?></label>
          <input id="paypal_client_secret" class="form-input" type="password" name="paypal_client_secret" value="<?= htmlspecialchars(maskVal($paypalClientSecret), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($paypalClientSecret), ENT_QUOTES, 'UTF-8') ?>">
          <p class="form-text text-muted fs-13">
            <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
            <?php echo iN_HelpSecure(customLang('admin_help_paypal_app_text')); ?>
            <a href="https://developer.paypal.com/developer/applications" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('admin_help_paypal_app_link_label')); ?></a>.
          </p>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="paypal_webhook_id"><?php echo iN_HelpSecure(customLang('admin_field_webhook_id') ?: 'Webhook ID'); ?></label>
          <input id="paypal_webhook_id" class="form-input" type="password" name="paypal_webhook_id" value="<?= htmlspecialchars(maskVal($paypalWebhookId), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($paypalWebhookId), ENT_QUOTES, 'UTF-8') ?>">
          <p class="form-text text-muted fs-13">
            <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
            <?php echo iN_HelpSecure(customLang('admin_help_paypal_webhook_id_text')); ?>
            <a href="https://developer.paypal.com/developer/applications" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('admin_help_paypal_webhook_id_link_label')); ?></a>.
          </p>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="paypal_env"><?php echo iN_HelpSecure(customLang('admin_field_environment') ?: 'Environment'); ?></label>
          <select id="paypal_env" class="form-input" name="paypal_env">
            <?php foreach (['sandbox', 'live'] as $opt): ?>
              <option value="<?= $opt ?>"<?= $opt === $paypalEnv ? ' selected' : '' ?>><?= strtoupper($opt) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="paypal_currency"><?php echo iN_HelpSecure(customLang('admin_field_currency') ?: 'Currency'); ?></label>
          <select id="paypal_currency" class="form-input" name="paypal_currency">
            <?php foreach ($currencyOptions as $code => $label): ?>
              <option value="<?= $code ?>"<?= $code === $paypalCurrency ? ' selected' : '' ?>><?php echo iN_HelpSecure($label, false); ?></option>
            <?php endforeach; ?>
          </select>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_help_paypal_currency_text') ?: 'Select the currency used by PayPal. Defaults to the global payments currency.', false); ?></p>
        </div>
      </div>
      <div class="admin-payments-note box-note full-width text-muted fs-13">
        <strong><?php echo iN_HelpSecure(customLang('admin_paypal_webhook_help_title') ?: 'PayPal Webhook (Subscriptions)'); ?></strong><br />
        1) <?php echo iN_HelpSecure(customLang('admin_paypal_webhook_step1_intro') ?: 'In your PayPal dashboard, create a Webhook that points to:'); ?><br />
        <code><?= $paypalHook ?></code><br />
        2) <?php echo iN_HelpSecure(customLang('admin_paypal_webhook_step2_intro') ?: 'Enable these event types (subscriptions):'); ?><br />
        <code>BILLING.SUBSCRIPTION.ACTIVATED</code>, <code>BILLING.SUBSCRIPTION.RE-ACTIVATED</code>, <code>BILLING.SUBSCRIPTION.CANCELLED</code>, <code>BILLING.SUBSCRIPTION.EXPIRED</code>, <code>BILLING.SUBSCRIPTION.SUSPENDED</code>, <code>BILLING.SUBSCRIPTION.UPDATED</code>.<br />
        3) <?php echo iN_HelpSecure(customLang('admin_paypal_webhook_step3_intro') ?: 'Copy the Webhook ID from PayPal and paste it above.'); ?><br />
        <?php echo iN_HelpSecure(customLang('admin_paypal_webhook_tip') ?: 'Tip: For one-time payments (tips/ads), you may also add'); ?> <code>PAYMENT.CAPTURE.COMPLETED</code>.<br />
      </div>
      </fieldset>

      <fieldset class="form-input-wrapper admin-settings-panel admin-payments-panel" data-payment-panel="nowpayments">
        <legend><?php echo iN_HelpSecure(customLang('pay_provider_nowpayments') ?: 'NOWPayments'); ?></legend>
        <div class="admin-payments-toggle">
          <span class="admin-payments-toggle__label"><?php echo iN_HelpSecure(customLang('pay_provider_nowpayments') ?: 'NOWPayments'); ?></span>
          <label class="el-switch el-switch-sm" aria-label="Enable NOWPayments">
            <input type="hidden" name="nowpayment_status" value="close">
            <input type="checkbox" name="nowpayment_status" value="open" <?= $nowpaymentStatus === 'open' ? 'checked' : '' ?> />
            <span class="el-switch-style"></span>
          </label>
        </div>
        <div class="form-grid form-grid--half admin-payments-grid">
        <div class="form-input-wrapper">
          <label class="form-label" for="nowpayments_api_key"><?php echo iN_HelpSecure(customLang('admin_field_api_key') ?: 'API Key'); ?></label>
          <input id="nowpayments_api_key" class="form-input" type="password" name="nowpayments_api_key" value="<?= htmlspecialchars(maskVal($nowApiKey), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($nowApiKey), ENT_QUOTES, 'UTF-8') ?>">
          <p class="form-text text-muted fs-13">
            <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
            <?php echo iN_HelpSecure(customLang('admin_help_now_api_text')); ?>
            <a href="https://account.nowpayments.io/" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('admin_help_now_api_link_label')); ?></a>.
          </p>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="nowpayment_webhook_secret_key"><?php echo iN_HelpSecure(customLang('admin_field_webhook_secret') ?: 'Webhook Secret'); ?></label>
          <input id="nowpayment_webhook_secret_key" class="form-input" type="password" name="nowpayment_webhook_secret_key" value="<?= htmlspecialchars(maskVal($nowWebhookSecret), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($nowWebhookSecret), ENT_QUOTES, 'UTF-8') ?>">
          <p class="form-text text-muted fs-13">
            <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
            <?php echo iN_HelpSecure(customLang('admin_help_now_webhook_text')); ?>
            <a href="https://account.nowpayments.io/integration" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('admin_help_now_webhook_link_label')); ?></a>.
          </p>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="now_payment_currency"><?php echo iN_HelpSecure(customLang('admin_field_currency') ?: 'Currency'); ?></label>
          <select id="now_payment_currency" class="form-input" name="now_payment_currency">
            <?php foreach ($currencyOptions as $code => $label): ?>
              <option value="<?= $code ?>"<?= $code === $nowPaymentCurrency ? ' selected' : '' ?>><?php echo iN_HelpSecure($label, false); ?></option>
            <?php endforeach; ?>
          </select>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_help_nowpayments_currency_text') ?: 'Select the base currency for NOWPayments. Defaults to the global payments currency.', false); ?></p>
        </div>
      </div>
      <div class="admin-payments-note box-note full-width text-muted fs-13">
        <strong><?php echo iN_HelpSecure(customLang('admin_now_webhook_help_title') ?: 'NOWPayments Webhook/IPN'); ?></strong><br />
        1) <?php echo iN_HelpSecure(customLang('admin_now_webhook_step1_intro') ?: 'Set IPN/Webhook URL to:'); ?><br />
        <code><?= $nowHook ?></code><br />
        2) <?php echo iN_HelpSecure(customLang('admin_now_webhook_secret_hint') ?: 'Use the same Webhook Secret you entered above to verify callbacks.'); ?>
      </div>
      </fieldset>

      <fieldset class="form-input-wrapper admin-settings-panel admin-payments-panel" data-payment-panel="coinbase">
        <legend><?php echo iN_HelpSecure(customLang('pay_provider_coinbase') ?: 'Coinbase Commerce'); ?></legend>
        <div class="admin-payments-toggle">
          <span class="admin-payments-toggle__label"><?php echo iN_HelpSecure(customLang('pay_provider_coinbase') ?: 'Coinbase Commerce'); ?></span>
          <label class="el-switch el-switch-sm" aria-label="Enable Coinbase Commerce">
            <input type="hidden" name="coinbase_status" value="close">
            <input type="checkbox" name="coinbase_status" value="open" <?= $coinbaseStatus === 'open' ? 'checked' : '' ?> />
            <span class="el-switch-style"></span>
          </label>
        </div>
        <div class="form-grid form-grid--half admin-payments-grid">
        <div class="form-input-wrapper">
          <label class="form-label" for="coinbase_commerce_api_key"><?php echo iN_HelpSecure(customLang('admin_field_api_key') ?: 'API Key'); ?></label>
          <input id="coinbase_commerce_api_key" class="form-input" type="password" name="coinbase_commerce_api_key" value="<?= htmlspecialchars(maskVal($coinbaseApiKey), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($coinbaseApiKey), ENT_QUOTES, 'UTF-8') ?>">
          <p class="form-text text-muted fs-13">
            <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
            <?php echo iN_HelpSecure(customLang('admin_help_coinbase_api_text')); ?>
            <a href="https://commerce.coinbase.com/dashboard/settings" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('admin_help_coinbase_api_link_label')); ?></a>.
          </p>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="coinbase_commerce_webhook_secret"><?php echo iN_HelpSecure(customLang('admin_field_webhook_secret') ?: 'Webhook Secret'); ?></label>
          <input id="coinbase_commerce_webhook_secret" class="form-input" type="password" name="coinbase_commerce_webhook_secret" value="<?= htmlspecialchars(maskVal($coinbaseWebhook), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($coinbaseWebhook), ENT_QUOTES, 'UTF-8') ?>">
          <p class="form-text text-muted fs-13">
            <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
            <?php echo iN_HelpSecure(customLang('admin_help_coinbase_webhook_text')); ?>
            <a href="https://commerce.coinbase.com/dashboard/settings" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('admin_help_coinbase_webhook_link_label')); ?></a>.
          </p>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="coinbase_currency"><?php echo iN_HelpSecure(customLang('admin_field_currency') ?: 'Currency'); ?></label>
          <select id="coinbase_currency" class="form-input" name="coinbase_currency">
            <?php foreach ($currencyOptions as $code => $label): ?>
              <option value="<?= $code ?>"<?= $code === $coinbaseCurrency ? ' selected' : '' ?>><?php echo iN_HelpSecure($label, false); ?></option>
            <?php endforeach; ?>
          </select>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_help_coinbase_currency_text') ?: 'Select the base currency for Coinbase Commerce. Defaults to the global payments currency.', false); ?></p>
        </div>
      </div>
      <div class="admin-payments-note box-note full-width text-muted fs-13">
        <strong><?php echo iN_HelpSecure(customLang('admin_coinbase_webhook_help_title') ?: 'Coinbase Commerce Webhook'); ?></strong><br />
        1) <?php echo iN_HelpSecure(customLang('admin_coinbase_webhook_intro') ?: 'Create a webhook and point it to:'); ?><br />
        <code><?= $coinbaseHook ?></code><br />
        2) <?php echo iN_HelpSecure(customLang('admin_coinbase_webhook_secret_hint') ?: 'Use the same Webhook Secret (shared secret) you entered above.'); ?>
      </div>
      </fieldset>

      <fieldset class="form-input-wrapper admin-settings-panel admin-payments-panel" data-payment-panel="flutterwave">
        <legend><?php echo iN_HelpSecure(customLang('pay_provider_flutterwave') ?: 'Flutterwave'); ?></legend>
        <div class="admin-payments-toggle">
          <span class="admin-payments-toggle__label"><?php echo iN_HelpSecure(customLang('pay_provider_flutterwave') ?: 'Flutterwave'); ?></span>
          <label class="el-switch el-switch-sm" aria-label="Enable Flutterwave">
            <input type="hidden" name="flutterwave_status" value="close">
            <input type="checkbox" name="flutterwave_status" value="open" <?= $flutterwaveStatus === 'open' ? 'checked' : '' ?> />
            <span class="el-switch-style"></span>
          </label>
        </div>
        <div class="form-grid form-grid--half admin-payments-grid">
          <div class="form-input-wrapper">
            <label class="form-label" for="flutterwave_public_key"><?php echo iN_HelpSecure(customLang('admin_field_flutterwave_public_key') ?: 'Flutterwave Public Key'); ?></label>
            <input id="flutterwave_public_key" class="form-input" type="password" name="flutterwave_public_key" value="<?= htmlspecialchars(maskVal($flutterwavePublicKey), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($flutterwavePublicKey), ENT_QUOTES, 'UTF-8') ?>">
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
              <?php echo iN_HelpSecure(customLang('admin_help_flutterwave_keys_text') ?: 'Generate your keys inside the Flutterwave dashboard.'); ?>
              <a href="https://dashboard.flutterwave.com/" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('admin_help_flutterwave_link_label') ?: 'Flutterwave Dashboard'); ?></a>.
            </p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="flutterwave_secret_key"><?php echo iN_HelpSecure(customLang('admin_field_flutterwave_secret_key') ?: 'Flutterwave Secret Key'); ?></label>
            <input id="flutterwave_secret_key" class="form-input" type="password" name="flutterwave_secret_key" value="<?= htmlspecialchars(maskVal($flutterwaveSecretKey), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($flutterwaveSecretKey), ENT_QUOTES, 'UTF-8') ?>">
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
              <?php echo iN_HelpSecure(customLang('admin_help_flutterwave_secret_hint') ?: 'Use your live or test secret depending on environment.'); ?>
            </p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="flutterwave_encryption_key"><?php echo iN_HelpSecure(customLang('admin_field_flutterwave_encryption_key') ?: 'Encryption Key'); ?></label>
            <input id="flutterwave_encryption_key" class="form-input" type="password" name="flutterwave_encryption_key" value="<?= htmlspecialchars(maskVal($flutterwaveEncryptionKey), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($flutterwaveEncryptionKey), ENT_QUOTES, 'UTF-8') ?>">
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
              <?php echo iN_HelpSecure(customLang('admin_help_flutterwave_encryption_hint') ?: 'Required for encrypting payloads in some flows.'); ?>
            </p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="flutterwave_secret_hash"><?php echo iN_HelpSecure(customLang('admin_field_flutterwave_secret_hash') ?: 'Secret Hash'); ?></label>
            <input id="flutterwave_secret_hash" class="form-input" type="password" name="flutterwave_secret_hash" value="<?= htmlspecialchars(maskVal($flutterwaveSecretHash), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($flutterwaveSecretHash), ENT_QUOTES, 'UTF-8') ?>">
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
              <?php echo iN_HelpSecure(customLang('admin_help_flutterwave_hash_hint') ?: 'Flutterwave sends this value via the verif-hash header for webhook verification.'); ?>
            </p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="flutterwave_currency"><?php echo iN_HelpSecure(customLang('admin_field_flutterwave_currency') ?: 'Currency'); ?></label>
            <select id="flutterwave_currency" class="form-input" name="flutterwave_currency">
              <option value=""<?= $flutterwaveCurrency === '' ? ' selected' : '' ?>><?php echo iN_HelpSecure($inheritGlobalLabel, false); ?></option>
              <?php foreach ($currencyOptions as $code => $label): ?>
                <option value="<?= $code ?>"<?= $code === $flutterwaveCurrency ? ' selected' : '' ?>><?php echo iN_HelpSecure($label, false); ?></option>
              <?php endforeach; ?>
            </select>
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('admin_help_flutterwave_currency_text') ?: 'Three-letter ISO code. Leave blank to use the global payments currency.'); ?>
            </p>
          </div>
        </div>
        <div class="admin-payments-note box-note full-width text-muted fs-13">
        <strong><?php echo iN_HelpSecure(customLang('admin_flutterwave_webhook_help_title') ?: 'Flutterwave Webhook'); ?></strong><br />
        1) <?php echo iN_HelpSecure(customLang('admin_flutterwave_webhook_intro') ?: 'Set your webhook URL to:'); ?><br />
        <code><?= $flutterwaveHook ?></code><br />
        2) <?php echo iN_HelpSecure(customLang('admin_flutterwave_webhook_hash_hint') ?: 'Use the Secret Hash above — Flutterwave includes it via the verif-hash header.'); ?>
      </div>
      </fieldset>

      <fieldset class="form-input-wrapper admin-settings-panel admin-payments-panel" data-payment-panel="paystack">
        <legend><?php echo iN_HelpSecure(customLang('pay_provider_paystack') ?: 'Paystack'); ?></legend>
        <div class="admin-payments-toggle">
          <span class="admin-payments-toggle__label"><?php echo iN_HelpSecure(customLang('pay_provider_paystack') ?: 'Paystack'); ?></span>
          <label class="el-switch el-switch-sm" aria-label="Enable Paystack">
            <input type="hidden" name="paystack_status" value="close">
            <input type="checkbox" name="paystack_status" value="open" <?= $paystackStatus === 'open' ? 'checked' : '' ?> />
            <span class="el-switch-style"></span>
          </label>
        </div>
        <div class="form-grid form-grid--half admin-payments-grid">
          <div class="form-input-wrapper">
            <label class="form-label" for="paystack_public_key"><?php echo iN_HelpSecure(customLang('admin_field_public_key') ?: 'Public Key'); ?></label>
            <input id="paystack_public_key" class="form-input" type="password" name="paystack_public_key" value="<?= htmlspecialchars(maskVal($paystackPublicKey), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($paystackPublicKey), ENT_QUOTES, 'UTF-8') ?>">
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
              <?php echo iN_HelpSecure(customLang('admin_help_paystack_keys') ?: 'Copy your public/secret keys from Paystack Dashboard → Settings → API Keys & Webhooks.'); ?>
            </p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="paystack_secret_key"><?php echo iN_HelpSecure(customLang('admin_field_secret_key') ?: 'Secret Key'); ?></label>
            <input id="paystack_secret_key" class="form-input" type="password" name="paystack_secret_key" value="<?= htmlspecialchars(maskVal($paystackSecretKey), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($paystackSecretKey), ENT_QUOTES, 'UTF-8') ?>">
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
              <?php echo iN_HelpSecure(customLang('admin_help_paystack_secret_hint') ?: 'Use your secret key that matches the environment (test/live).'); ?>
            </p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="paystack_webhook_secret"><?php echo iN_HelpSecure(customLang('admin_field_webhook_secret') ?: 'Webhook Secret'); ?></label>
            <input id="paystack_webhook_secret" class="form-input" type="password" name="paystack_webhook_secret" value="<?= htmlspecialchars(maskVal($paystackWebhookSecret), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($paystackWebhookSecret), ENT_QUOTES, 'UTF-8') ?>">
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
              <?php echo iN_HelpSecure(customLang('admin_help_paystack_webhook') ?: 'Set the same secret in Paystack when configuring the webhook below.'); ?>
            </p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="paystack_currency"><?php echo iN_HelpSecure(customLang('admin_field_currency') ?: 'Currency'); ?></label>
            <select id="paystack_currency" class="form-input" name="paystack_currency">
              <option value=""<?= $paystackCurrency === '' ? ' selected' : '' ?>><?php echo iN_HelpSecure($inheritGlobalLabel, false); ?></option>
              <?php foreach ($currencyOptions as $code => $label): ?>
                <option value="<?= $code ?>"<?= $code === $paystackCurrency ? ' selected' : '' ?>><?php echo iN_HelpSecure($label, false); ?></option>
              <?php endforeach; ?>
            </select>
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('admin_help_paystack_currency_text') ?: 'Three-letter ISO code. Leave blank to inherit the global payments currency.'); ?>
            </p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="paystack_merchant_email"><?php echo iN_HelpSecure(customLang('admin_field_merchant_email') ?: 'Merchant Email (optional)'); ?></label>
            <input id="paystack_merchant_email" class="form-input" type="email" name="paystack_merchant_email" value="<?= htmlspecialchars($paystackMerchantEmail, ENT_QUOTES, 'UTF-8') ?>" placeholder="merchant@example.com">
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('admin_help_paystack_merchant_email') ?: 'Used for receipts/metadata. Leave empty if not needed.'); ?>
            </p>
          </div>
        </div>
        <div class="admin-payments-note box-note full-width text-muted fs-13">
          <strong><?php echo iN_HelpSecure(customLang('admin_paystack_webhook_help_title') ?: 'Paystack Webhook'); ?></strong><br />
          1) <?php echo iN_HelpSecure(customLang('admin_paystack_webhook_intro') ?: 'In Paystack Dashboard → Settings → API Keys & Webhooks, set the webhook URL to:'); ?><br />
          <code><?= $paystackHook ?></code><br />
          2) <?php echo iN_HelpSecure(customLang('admin_paystack_webhook_secret_hint') ?: 'Use the same Webhook Secret entered above to validate signatures.'); ?>
        </div>
      </fieldset>

      <fieldset class="form-input-wrapper admin-settings-panel admin-payments-panel" data-payment-panel="payu">
        <legend><?php echo iN_HelpSecure(customLang('pay_provider_payu') ?: 'PayU'); ?></legend>
        <div class="admin-payments-toggle">
          <span class="admin-payments-toggle__label"><?php echo iN_HelpSecure(customLang('pay_provider_payu') ?: 'PayU'); ?></span>
          <label class="el-switch el-switch-sm" aria-label="Enable PayU">
            <input type="hidden" name="payu_status" value="close">
            <input type="checkbox" name="payu_status" value="open" <?= $payuStatus === 'open' ? 'checked' : '' ?> />
            <span class="el-switch-style"></span>
          </label>
        </div>
        <div class="form-grid form-grid--half admin-payments-grid">
          <div class="form-input-wrapper">
            <label class="form-label" for="payu_merchant_pos_id"><?php echo iN_HelpSecure(customLang('admin_field_merchant_pos_id') ?: 'Merchant POS ID'); ?></label>
            <input id="payu_merchant_pos_id" class="form-input" type="text" name="payu_merchant_pos_id" value="<?= htmlspecialchars($payuMerchantPosId, ENT_QUOTES, 'UTF-8') ?>" maxlength="191">
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
              <?php echo iN_HelpSecure(customLang('admin_help_payu_pos_id') ?: 'Your PayU POS ID (often matches client_id for REST).'); ?>
            </p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="payu_merchant_id"><?php echo iN_HelpSecure(customLang('admin_field_merchant_id') ?: 'Merchant ID'); ?></label>
            <input id="payu_merchant_id" class="form-input" type="text" name="payu_merchant_id" value="<?= htmlspecialchars($payuMerchantId, ENT_QUOTES, 'UTF-8') ?>" maxlength="191">
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
              <?php echo iN_HelpSecure(customLang('admin_help_payu_merchant_id') ?: 'Merchant ID from PayU settings.'); ?>
            </p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="payu_client_id"><?php echo iN_HelpSecure(customLang('admin_field_client_id') ?: 'Client ID'); ?></label>
            <input id="payu_client_id" class="form-input" type="password" name="payu_client_id" value="<?= htmlspecialchars(maskVal($payuClientId), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($payuClientId), ENT_QUOTES, 'UTF-8') ?>">
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
              <?php echo iN_HelpSecure(customLang('admin_help_payu_client_id') ?: 'OAuth client_id used for token requests.'); ?>
            </p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="payu_client_secret"><?php echo iN_HelpSecure(customLang('admin_field_client_secret') ?: 'Client Secret'); ?></label>
            <input id="payu_client_secret" class="form-input" type="password" name="payu_client_secret" value="<?= htmlspecialchars(maskVal($payuClientSecret), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($payuClientSecret), ENT_QUOTES, 'UTF-8') ?>">
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
              <?php echo iN_HelpSecure(customLang('admin_help_payu_client_secret') ?: 'OAuth client_secret paired with the Client ID.'); ?>
            </p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="payu_signature_key"><?php echo iN_HelpSecure(customLang('admin_field_signature_key') ?: 'Signature Key (Second Key)'); ?></label>
            <input id="payu_signature_key" class="form-input" type="password" name="payu_signature_key" value="<?= htmlspecialchars(maskVal($payuSignatureKey), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($payuSignatureKey), ENT_QUOTES, 'UTF-8') ?>">
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('env_precedence_note')); ?><br>
              <?php echo iN_HelpSecure(customLang('admin_help_payu_signature_key') ?: 'Use the PayU second key to validate webhook signatures.'); ?>
            </p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="payu_currency"><?php echo iN_HelpSecure(customLang('admin_field_currency') ?: 'Currency'); ?></label>
            <select id="payu_currency" class="form-input" name="payu_currency">
              <option value=""<?= $payuCurrency === '' ? ' selected' : '' ?>><?php echo iN_HelpSecure($inheritGlobalLabel, false); ?></option>
              <?php foreach ($currencyOptions as $code => $label): ?>
                <option value="<?= $code ?>"<?= $code === $payuCurrency ? ' selected' : '' ?>><?php echo iN_HelpSecure($label, false); ?></option>
              <?php endforeach; ?>
            </select>
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('admin_help_payu_currency_text') ?: 'Three-letter ISO code. Leave blank to inherit the global payments currency.'); ?>
            </p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="payu_api_base"><?php echo iN_HelpSecure(customLang('admin_field_api_base') ?: 'API Base (optional)'); ?></label>
            <input id="payu_api_base" class="form-input" type="text" name="payu_api_base" value="<?= htmlspecialchars($payuApiBase, ENT_QUOTES, 'UTF-8') ?>" placeholder="https://secure.payu.com" maxlength="191">
            <p class="form-text text-muted fs-13">
              <?php echo iN_HelpSecure(customLang('admin_help_payu_api_base') ?: 'Override the API base (e.g., sandbox https://secure.snd.payu.com). Leave empty for defaults.'); ?>
            </p>
          </div>
        </div>
        <div class="admin-payments-note box-note full-width text-muted fs-13">
          <strong><?php echo iN_HelpSecure(customLang('admin_payu_webhook_help_title') ?: 'PayU Webhook'); ?></strong><br />
          1) <?php echo iN_HelpSecure(customLang('admin_payu_webhook_intro') ?: 'Set your PayU notification URL to:'); ?><br />
          <code><?= $payuHook ?></code><br />
          2) <?php echo iN_HelpSecure(customLang('admin_payu_webhook_signature_hint') ?: 'Use the Second Key as the signature key to validate callbacks.'); ?>
        </div>
      </fieldset>

      <fieldset class="form-input-wrapper admin-settings-panel admin-payments-panel" data-payment-panel="iyzico">
        <legend><?php echo iN_HelpSecure(customLang('pay_provider_iyzico') ?: 'IyziCo'); ?></legend>
        <div class="admin-payments-toggle">
          <span class="admin-payments-toggle__label"><?php echo iN_HelpSecure(customLang('pay_provider_iyzico') ?: 'IyziCo'); ?></span>
          <label class="el-switch el-switch-sm" aria-label="Enable IyziCo">
            <input type="hidden" name="iyzico_status" value="close">
            <input type="checkbox" name="iyzico_status" value="open" <?= $iyzicoStatus === 'open' ? 'checked' : '' ?> />
            <span class="el-switch-style"></span>
          </label>
        </div>

        <div class="form-grid form-grid--half admin-payments-grid">
          <div class="form-input-wrapper">
            <label class="form-label" for="iyzico_api_key"><?php echo iN_HelpSecure(customLang('admin_field_api_key') ?: 'API Key'); ?></label>
            <input id="iyzico_api_key" class="form-input" type="password" name="iyzico_api_key" value="<?= htmlspecialchars(maskVal($iyzicoApiKey), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($iyzicoApiKey), ENT_QUOTES, 'UTF-8') ?>">
            <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_help_iyzico_api_key') ?: 'Use the IyziCo API Key for your environment (sandbox/live).'); ?></p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="iyzico_secret_key"><?php echo iN_HelpSecure(customLang('admin_field_secret_key') ?: 'Secret Key'); ?></label>
            <input id="iyzico_secret_key" class="form-input" type="password" name="iyzico_secret_key" value="<?= htmlspecialchars(maskVal($iyzicoSecretKey), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($iyzicoSecretKey), ENT_QUOTES, 'UTF-8') ?>">
            <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_help_iyzico_secret_key') ?: 'Secret key used to sign IyziCo requests.'); ?></p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="iyzico_webhook_secret"><?php echo iN_HelpSecure(customLang('admin_field_webhook_secret') ?: 'Webhook Secret'); ?></label>
            <input id="iyzico_webhook_secret" class="form-input" type="password" name="iyzico_webhook_secret" value="<?= htmlspecialchars(maskVal($iyzicoWebhookSecret), ENT_QUOTES, 'UTF-8') ?>" data-mask="<?= htmlspecialchars(maskVal($iyzicoWebhookSecret), ENT_QUOTES, 'UTF-8') ?>">
            <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_help_iyzico_webhook_secret') ?: 'Provide the signing secret/token configured in IyziCo webhooks.'); ?></p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="iyzico_currency"><?php echo iN_HelpSecure(customLang('admin_field_currency') ?: 'Currency'); ?></label>
            <select id="iyzico_currency" class="form-input" name="iyzico_currency">
              <option value=""<?= $iyzicoCurrency === '' ? ' selected' : '' ?>><?php echo iN_HelpSecure($inheritGlobalLabel, false); ?></option>
              <?php foreach ($currencyOptions as $code => $label): ?>
                <option value="<?= $code ?>"<?= $code === $iyzicoCurrency ? ' selected' : '' ?>><?php echo iN_HelpSecure($label, false); ?></option>
              <?php endforeach; ?>
            </select>
            <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_help_iyzico_currency_text') ?: 'Three-letter ISO code. Leave blank to inherit the global payments currency.'); ?></p>
          </div>
          <div class="form-input-wrapper">
            <label class="form-label" for="iyzico_api_base"><?php echo iN_HelpSecure(customLang('admin_field_api_base') ?: 'API Base (optional)'); ?></label>
            <input id="iyzico_api_base" class="form-input" type="url" name="iyzico_api_base" value="<?= htmlspecialchars($iyzicoApiBase, ENT_QUOTES, 'UTF-8') ?>" placeholder="https://sandbox-api.iyzipay.com">
            <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_help_iyzico_api_base') ?: 'Override IyziCo API base for sandbox/custom endpoints. Leave empty for default.'); ?></p>
          </div>
        </div>

        <div class="admin-payments-note box-note full-width text-muted fs-13">
          <strong><?php echo iN_HelpSecure(customLang('admin_iyzico_webhook_help_title') ?: 'IyziCo Webhook'); ?></strong><br />
          1) <?php echo iN_HelpSecure(customLang('admin_iyzico_webhook_intro') ?: 'Set the webhook/callback URL in IyziCo to:'); ?><br />
          <code><?= $iyzicoHook ?></code><br />
          2) <?php echo iN_HelpSecure(customLang('admin_iyzico_webhook_secret_hint') ?: 'Use the same webhook secret/token above to validate signatures.'); ?>
        </div>
      </fieldset>
    </div>

    <div class="form-input-wrapper form-input-wrapper--actions admin-payments-actions">
      <button type="button" class="follow-btn btn-hover reneval transition" data-action="reauth-payments"><?php echo iN_HelpSecure(customLang('reveal_edit') ?: 'Reveal/Edit'); ?></button>
      <button type="submit" name="action" value="update" class="pe-save btn-hover transition"><?php echo iN_HelpSecure(customLang('save_changes') ?: 'Save'); ?></button>
    </div>
  </form>
</section>
