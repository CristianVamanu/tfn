<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';

global $base_url, $ADMIN_CSRF, $ADM, $iconPath;

$mailSettings = [];
if (isset($ADM) && $ADM instanceof Admin_Data) {
    try {
        $stmt = $ADM->db()->query('SELECT * FROM i_mail_settings WHERE id = 1 LIMIT 1');
        if ($stmt !== false) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row !== false) {
                $mailSettings = $row;
            }
        }
    } catch (Throwable $e) {
        if (defined('APP_DEBUG') && APP_DEBUG === true) {
            error_log('admin contact email settings load failed: ' . $e->getMessage());
        }
    }
}

$fromName   = (string)($mailSettings['from_name'] ?? '');
$fromEmail  = (string)($mailSettings['from_email'] ?? '');
$toEmail    = (string)($mailSettings['to_email'] ?? '');
$rateLimit  = (int)($mailSettings['rate_limit_per_hour'] ?? 1);
if ($rateLimit < 0) {
    $rateLimit = 0;
}
$allowGuests = (int)($mailSettings['allow_guest_messages'] ?? 0) === 1 ? 1 : 0;
$guestRecaptchaRequired = (int)($mailSettings['guest_recaptcha_required'] ?? 1) === 1 ? 1 : 0;
$maxMessageLength = (int)($mailSettings['max_message_length'] ?? 1000);
if ($maxMessageLength < 100) {
    $maxMessageLength = 100;
}
$subjectLabelFeedback = (string)($mailSettings['subject_label_feedback'] ?? 'Feedback');
$subjectLabelComplaint = (string)($mailSettings['subject_label_complaint'] ?? 'Complaint');
$subjectLabelSuggestion = (string)($mailSettings['subject_label_suggestion'] ?? 'Suggestion');
$subjectLabelBug = (string)($mailSettings['subject_label_bug'] ?? 'Bug');
$subjectOptions = [
    'feedback' => $subjectLabelFeedback,
    'complaint' => $subjectLabelComplaint,
    'suggestion' => $subjectLabelSuggestion,
    'bug' => $subjectLabelBug,
];
$recaptchaSite   = (string)($mailSettings['recaptcha_site_key'] ?? '');
$recaptchaSecret = (string)($mailSettings['recaptcha_secret_key'] ?? '');
$recaptchaEnabled = (int)($mailSettings['recaptcha_enabled'] ?? 0) === 1;

$host   = (string)($mailSettings['host'] ?? '');
$port   = (int)($mailSettings['port'] ?? 587);
if ($port <= 0 || $port > 65535) {
    $port = 587;
}
$secure = (string)($mailSettings['secure'] ?? 'none');
$secureOptions = ['tls', 'ssl', 'none'];
if (!in_array($secure, $secureOptions, true)) {
    $secure = 'none';
}
$username = (string)($mailSettings['username'] ?? '');
$hasPassword = trim((string)($mailSettings['password_enc'] ?? '')) !== '';

$actionUrl = iN_HelpSecure($base_url . 'admin/request/contact_email.php', false);
$csrfToken = iN_HelpSecure($ADMIN_CSRF, false);

$panelTitle = customLang('admin_settings_contact_email') ?: 'Contact & Email Settings';
$contactTabLabel = customLang('admin_contact_form_settings') ?: 'Contact Form Settings';
$smtpTabLabel = customLang('admin_smtp_settings') ?: 'SMTP Settings';
$contactLegend = customLang('admin_contact_rate_settings') ?: 'Contact Form Limits';
$smtpServerLegend = customLang('admin_smtp_server_settings') ?: 'Server Configuration';
$smtpAuthLegend = customLang('admin_smtp_auth_settings') ?: 'Authentication';
$smtpSenderLegend = customLang('admin_smtp_sender_settings') ?: 'Sender Details';
$smtpSecurityLegend = customLang('admin_contact_spam_protection') ?: 'Spam Protection';
$smtpTestLegend = customLang('admin_smtp_test_settings') ?: 'Send Test Email';
$saveContactLabel = customLang('admin_save_contact_settings') ?: 'Save Contact Settings';
$saveSmtpLabel = customLang('admin_save_email_security_settings') ?: 'Save Email & reCAPTCHA Settings';
$smtpTestLabel = customLang('admin_smtp_send_test') ?: 'Send Test';
$recaptchaHint = customLang('admin_contact_recaptcha_hint') ?: 'Provide keys to enable Google reCAPTCHA v2 checkbox on the public contact form.';
$rateLimitHint = customLang('admin_contact_rate_limit_hint') ?: 'Maximum number of contact messages accepted per IP within 1 hour. Set 0 to disable rate limiting.';
$fromEmailHint = customLang('admin_contact_from_email_hint') ?: 'Displayed to recipients as the sender address.';
$toEmailHint = customLang('admin_contact_to_email_hint') ?: 'Incoming contact messages will be forwarded to this address.';
$passwordHint = customLang('admin_smtp_password_hint') ?: 'Leave blank to keep the existing password. Use the toggle below to clear the saved password.';
$hasPasswordText = customLang('admin_smtp_password_saved') ?: 'A password is currently stored.';
$noPasswordText = customLang('admin_smtp_password_missing') ?: 'No password saved yet.';

$initialTab = 'contact';
if ($host === '' || $fromEmail === '') {
    $initialTab = 'smtp';
}
$requestedTab = isset($_GET['tab']) ? strtolower(trim((string) $_GET['tab'])) : '';
$validTabs = ['contact', 'smtp', 'messages'];
if ($requestedTab !== '' && in_array($requestedTab, $validTabs, true)) {
    $initialTab = $requestedTab;
}
if (!in_array($initialTab, $validTabs, true)) {
    $initialTab = 'contact';
}

$tabGroupId = 'contactEmailTabs';
$tabHintTemplate = customLang('admin_contact_email_tab_hint') ?: 'Need to configure outgoing email? Switch to the "%s" tab below to manage SMTP host, port, username, and password.';
$tabHintText = sprintf($tabHintTemplate, $smtpTabLabel);
$tabHintAction = customLang('admin_contact_email_tab_hint_action') ?: 'Open SMTP Settings';

$contactTabActive = $initialTab === 'contact';
$smtpTabActive = $initialTab === 'smtp';
$messagesTabActive = $initialTab === 'messages';
?>

<section class="card rounded-2xl" role="region" aria-labelledby="contactEmailSettingsHeading">
  <div class="list-header" id="contactEmailSettingsHeading">
    <span class="icon"><?php echo renderVerifiedBadge($iconPath . 'email.svg', true); ?></span>
    <span><strong><?php echo iN_HelpSecure($panelTitle, false); ?></strong></span>
  </div>

  <div class="box-note admin-contact-tab-hint">
    <p><?php echo iN_HelpSecure($tabHintText, false); ?></p>
    <button type="button" class="btn-outline" data-open-tab="smtp" data-tab-group="<?php echo iN_HelpSecure($tabGroupId, false); ?>"><?php echo iN_HelpSecure($tabHintAction, false); ?></button>
  </div>

  <div class="landing-section-tabs" data-landing-tabs data-tab-group="<?php echo iN_HelpSecure($tabGroupId, false); ?>" data-default-tab="<?php echo iN_HelpSecure($initialTab, false); ?>" role="tablist">
    <button type="button" class="landing-section-tab<?php echo $contactTabActive ? ' is-active' : ''; ?>" data-section-target="contact" role="tab" aria-selected="<?php echo $contactTabActive ? 'true' : 'false'; ?>"><?php echo iN_HelpSecure($contactTabLabel, false); ?></button>
    <button type="button" class="landing-section-tab<?php echo $smtpTabActive ? ' is-active' : ''; ?>" data-section-target="smtp" role="tab" aria-selected="<?php echo $smtpTabActive ? 'true' : 'false'; ?>"><?php echo iN_HelpSecure($smtpTabLabel, false); ?></button>
  </div>

  <div class="landing-section-panel<?php echo $contactTabActive ? ' is-active' : ''; ?>" data-section-panel="contact" role="tabpanel"<?php echo $contactTabActive ? ' aria-hidden="false"' : ' aria-hidden="true" hidden'; ?>>
    <form class="form-container flex flexBoxColumn admin-contact-settings-form" method="post" action="<?php echo $actionUrl; ?>" data-action="save-contact-settings">
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
      <input type="hidden" name="action" value="save_contact_cfg">

      <div class="admin-contact-panel-grid">
        <fieldset class="form-input-wrapper admin-settings-panel admin-contact-panel" data-contact-panel="general">
          <legend><?php echo iN_HelpSecure($contactLegend, false); ?></legend>

          <div class="admin-contact-toggle">
            <div class="admin-contact-toggle__body">
              <span class="admin-contact-toggle__label"><?php echo iN_HelpSecure(customLang('admin_contact_allow_guests') ?: 'Allow guest submissions', false); ?></span>
              <p class="admin-contact-toggle__hint"><?php echo iN_HelpSecure(customLang('admin_contact_allow_guests_hint') ?: 'Enable this to let unauthenticated visitors use the contact form.', false); ?></p>
            </div>
            <label class="el-switch el-switch-sm" for="allow_guest_messages">
              <input type="hidden" name="allow_guest_messages" value="0">
              <input id="allow_guest_messages" type="checkbox" name="allow_guest_messages" value="1" <?php echo $allowGuests ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>

          <div class="admin-contact-toggle">
            <div class="admin-contact-toggle__body">
              <span class="admin-contact-toggle__label"><?php echo iN_HelpSecure(customLang('admin_contact_require_guest_recaptcha') ?: 'Require reCAPTCHA for guests', false); ?></span>
              <p class="admin-contact-toggle__hint"><?php echo iN_HelpSecure(customLang('admin_contact_guest_recaptcha_hint') ?: 'Keep this on to reduce spam from guest submissions.', false); ?></p>
            </div>
            <label class="el-switch el-switch-sm" for="guest_recaptcha_required">
              <input type="hidden" name="guest_recaptcha_required" value="0">
              <input id="guest_recaptcha_required" type="checkbox" name="guest_recaptcha_required" value="1" <?php echo $guestRecaptchaRequired ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>

          <div class="admin-contact-field">
            <label class="form-label" for="max_message_length"><?php echo iN_HelpSecure(customLang('admin_contact_max_length') ?: 'Maximum message length (characters)', false); ?></label>
            <input id="max_message_length" class="form-input" type="number" name="max_message_length" min="100" max="5000" value="<?php echo iN_HelpSecure((string) $maxMessageLength, false); ?>">
            <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_contact_max_length_hint') ?: 'Most contact messages fit within 500–2000 characters.', false); ?></p>
          </div>

          <div class="admin-contact-field">
            <label class="form-label"><?php echo iN_HelpSecure(customLang('admin_contact_subject_labels') ?: 'Subject presets', false); ?></label>
            <div class="form-grid form-grid--half admin-contact-grid">
              <div class="form-input-wrapper">
                <label class="form-label" for="subject_label_feedback"><?php echo iN_HelpSecure(customLang('admin_contact_subject_feedback') ?: 'Feedback', false); ?></label>
                <input id="subject_label_feedback" class="form-input" type="text" name="subject_label_feedback" value="<?php echo iN_HelpSecure($subjectLabelFeedback, false); ?>" maxlength="120">
              </div>
              <div class="form-input-wrapper">
                <label class="form-label" for="subject_label_complaint"><?php echo iN_HelpSecure(customLang('admin_contact_subject_complaint') ?: 'Complaint', false); ?></label>
                <input id="subject_label_complaint" class="form-input" type="text" name="subject_label_complaint" value="<?php echo iN_HelpSecure($subjectLabelComplaint, false); ?>" maxlength="120">
              </div>
              <div class="form-input-wrapper">
                <label class="form-label" for="subject_label_suggestion"><?php echo iN_HelpSecure(customLang('admin_contact_subject_suggestion') ?: 'Suggestion', false); ?></label>
                <input id="subject_label_suggestion" class="form-input" type="text" name="subject_label_suggestion" value="<?php echo iN_HelpSecure($subjectLabelSuggestion, false); ?>" maxlength="120">
              </div>
              <div class="form-input-wrapper">
                <label class="form-label" for="subject_label_bug"><?php echo iN_HelpSecure(customLang('admin_contact_subject_bug') ?: 'Bug Report', false); ?></label>
                <input id="subject_label_bug" class="form-input" type="text" name="subject_label_bug" value="<?php echo iN_HelpSecure($subjectLabelBug, false); ?>" maxlength="120">
              </div>
            </div>
          </div>

          <div class="admin-contact-field">
            <label class="form-label" for="rate_limit_per_hour"><?php echo iN_HelpSecure(customLang('admin_contact_rate_limit') ?: 'Rate limit per hour', false); ?></label>
            <input id="rate_limit_per_hour" class="form-input" type="number" min="0" max="1000" name="rate_limit_per_hour" value="<?php echo iN_HelpSecure((string) $rateLimit, false); ?>">
            <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure($rateLimitHint, false); ?></p>
          </div>
        </fieldset>
      </div>

      <div class="form-input-wrapper form-input-wrapper--actions admin-contact-actions">
        <button type="submit" class="pe-save btn-hover transition"><?php echo iN_HelpSecure($saveContactLabel, false); ?></button>
      </div>
    </form>
  </div>

  <div class="landing-section-panel<?php echo $smtpTabActive ? ' is-active' : ''; ?>" data-section-panel="smtp" role="tabpanel"<?php echo $smtpTabActive ? ' aria-hidden="false"' : ' aria-hidden="true" hidden'; ?>>
    <form class="form-container flex flexBoxColumn admin-contact-settings-form" method="post" action="<?php echo $actionUrl; ?>" data-action="save-smtp-settings">
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
      <input type="hidden" name="action" value="save_smtp">

      <?php
        $smtpGuideTitle = customLang('admin_smtp_setup_title') ?: 'SMTP Configuration Guide';
        $smtpHostTitle = customLang('admin_smtp_setup_host_port_title') ?: (customLang('admin_smtp_setup_host_port') ?: 'SMTP Host & Encryption');
        $smtpAuthTitle = customLang('admin_smtp_setup_auth_title') ?: (customLang('admin_smtp_setup_auth') ?: 'SMTP Authentication & Credentials');
        $smtpSpfTitle  = customLang('admin_smtp_setup_spf_dkim_title') ?: (customLang('admin_smtp_setup_spf_dkim') ?: 'Domain Authentication (SPF/DKIM)');
        $smtpTestTitle = customLang('admin_smtp_setup_test_title') ?: (customLang('admin_smtp_setup_test') ?: 'Test & Monitor Deliverability');
        $smtpAltTitle  = customLang('admin_smtp_setup_alt_title') ?: (customLang('admin_smtp_setup_alt') ?: 'Transactional SMTP Alternatives');
      ?>
      <div class="form-input-wrapper box-note">
        <strong><?= iN_HelpSecure($smtpGuideTitle, false); ?></strong>
        <div class="admin-guide-accordion" data-smtp-guide>
          <details class="admin-guide-item">
            <summary>
              <span class="admin-guide-title"><?= iN_HelpSecure($smtpHostTitle, false); ?></span>
            </summary>
            <div class="admin-guide-body">
              <p><?= iN_HelpSecure(customLang('admin_smtp_setup_host_port_desc') ?: 'Tell the application which SMTP server is responsible for sending replies and notifications.', false); ?></p>
              <ul class="admin-guide-bullets">
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_host_port_where') ?: 'In cPanel open Email Accounts → Manage → Connect Devices → Mail Client Manual Settings to copy the SMTP hostname, SSL/TLS mode, and port; use the equivalent SMTP/Outgoing Mail screen if you rely on Google Workspace, Microsoft 365, Plesk, or another provider.', false); ?></li>
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_host_port_errors') ?: 'Misconfigured host or port results in connection timeouts, TLS handshake failures, or “Could not connect to SMTP host” errors.', false); ?></li>
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_host_port_examples') ?: 'Shared hosting example: dizzyscripts.com (SSL, port 465). Other common values: smtp.gmail.com (STARTTLS, port 587), email-smtp.eu-west-1.amazonaws.com (TLS, port 587).', false); ?></li>
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_host_port_security') ?: 'Always enable TLS/SSL when available and verify the hostname matches the certificate to avoid downgrade or MITM risks.', false); ?></li>
              </ul>
            </div>
          </details>

          <details class="admin-guide-item">
            <summary>
              <span class="admin-guide-title"><?= iN_HelpSecure($smtpAuthTitle, false); ?></span>
            </summary>
            <div class="admin-guide-body">
              <p><?= iN_HelpSecure(customLang('admin_smtp_setup_auth_desc') ?: 'Credentials confirm that this mailbox authorizes the application to relay outgoing messages.', false); ?></p>
              <ul class="admin-guide-bullets">
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_auth_where') ?: 'In cPanel use Email Accounts → Manage to copy the SMTP username (the full mailbox) and reset the password when necessary; repeat the equivalent step inside Google Workspace, Microsoft 365, or any third-party SMTP panel.', false); ?></li>
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_auth_errors') ?: 'Incorrect credentials or a From Email that does not match the authenticated mailbox trigger 535/534 errors and block every message.', false); ?></li>
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_auth_examples') ?: 'Use the full mailbox address (for example creatorpulse@dizzyscripts.com) both for the username and the From Email field; providers such as Google Workspace or Outlook 365 may require app-specific passwords.', false); ?></li>
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_auth_security') ?: 'Store passwords securely, rotate them periodically, enable 2FA where available, and avoid reusing SMTP credentials for interactive logins.', false); ?></li>
              </ul>
            </div>
          </details>

          <details class="admin-guide-item">
            <summary>
              <span class="admin-guide-title"><?= iN_HelpSecure($smtpSpfTitle, false); ?></span>
            </summary>
            <div class="admin-guide-body">
              <p><?= iN_HelpSecure(customLang('admin_smtp_setup_spf_dkim_desc') ?: 'SPF and DKIM DNS records allow receiving servers to verify that this SMTP host is permitted to send for your domain.', false); ?></p>
              <ul class="admin-guide-bullets">
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_spf_dkim_where') ?: 'Publish SPF/DKIM values in your DNS provider (Cloudflare, Route53, cPanel) using the instructions supplied by your mail vendor.', false); ?></li>
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_spf_dkim_errors') ?: 'Missing or incorrect records lead to “SPF fail/DKIM none” and push legitimate messages into spam folders.', false); ?></li>
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_spf_dkim_examples') ?: 'Example SPF: v=spf1 include:_spf.google.com ~all. Example DKIM: google._domainkey.yourdomain.com with the public key from Google Workspace.', false); ?></li>
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_spf_dkim_security') ?: 'Validate changes with tools like MXToolbox and monitor DMARC reports to catch spoofing or misalignment quickly.', false); ?></li>
              </ul>
            </div>
          </details>

          <details class="admin-guide-item">
            <summary>
              <span class="admin-guide-title"><?= iN_HelpSecure($smtpTestTitle, false); ?></span>
            </summary>
            <div class="admin-guide-body">
              <p><?= iN_HelpSecure(customLang('admin_smtp_setup_test_desc') ?: 'Routine test sends expose misconfigurations before customers encounter delivery problems.', false); ?></p>
              <ul class="admin-guide-bullets">
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_test_where') ?: 'Use the “Send Test Email” button here or CLI tools (swaks, openssl s_client) to verify the entire SMTP handshake.', false); ?></li>
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_test_errors') ?: 'Check returned SMTP codes (454 TLS not available, 550 relay denied) to identify what still needs attention.', false); ?></li>
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_test_examples') ?: 'Send tests to both your support inbox and an external mailbox (Gmail/Outlook) to confirm final inbox placement.', false); ?></li>
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_test_security') ?: 'Log test attempts and review bounce/complaint metrics so repeated failures alert you before deliverability tanks.', false); ?></li>
              </ul>
            </div>
          </details>

          <details class="admin-guide-item">
            <summary>
              <span class="admin-guide-title"><?= iN_HelpSecure($smtpAltTitle, false); ?></span>
            </summary>
            <div class="admin-guide-body">
              <p><?= iN_HelpSecure(customLang('admin_smtp_setup_alt_desc') ?: 'Dedicated transactional SMTP providers offer higher deliverability, analytics, and scalability when shared hosting is restrictive.', false); ?></p>
              <ul class="admin-guide-bullets">
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_alt_where') ?: 'Register with providers such as SendGrid, Mailgun, Amazon SES, Postmark, or Brevo to obtain dedicated SMTP credentials.', false); ?></li>
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_alt_errors') ?: 'Sticking with a throttled host risks delivery delays, blocked notifications, or IP blacklisting during traffic spikes.', false); ?></li>
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_alt_examples') ?: 'Example configurations: smtp.sendgrid.net (TLS/587, username “apikey”), smtp.mailgun.org (TLS/587), email-smtp.us-east-1.amazonaws.com (TLS/587).', false); ?></li>
                <li class="admin_li_icon"><?= iN_HelpSecure(customLang('admin_smtp_setup_alt_security') ?: 'Issue app-specific credentials, enable 2FA, and monitor provider dashboards for bounce and spam complaint trends.', false); ?></li>
              </ul>
            </div>
          </details>
        </div>
      </div>

      <div class="admin-contact-panel-grid">
        <fieldset class="form-input-wrapper admin-settings-panel admin-contact-panel" data-contact-panel="server">
          <legend><?php echo iN_HelpSecure($smtpServerLegend, false); ?></legend>

        <?php $smtpHostRequired = $host === '' ? '' : 'required'; ?>
        <label class="form-label" for="smtp_host"><?php echo iN_HelpSecure(customLang('admin_smtp_host') ?: 'SMTP Host', false); ?></label>
        <input id="smtp_host" class="form-input" type="text" name="host" value="<?php echo iN_HelpSecure($host, false); ?>" maxlength="191"<?php echo $smtpHostRequired ? ' required' : ''; ?>>

        <label class="form-label" for="smtp_port"><?php echo iN_HelpSecure(customLang('admin_smtp_port') ?: 'Port', false); ?></label>
        <input id="smtp_port" class="form-input" type="number" name="port" min="1" max="65535" value="<?php echo iN_HelpSecure((string) $port, false); ?>"<?php echo $smtpHostRequired ? ' required' : ''; ?>>

        <label class="form-label" for="smtp_secure"><?php echo iN_HelpSecure(customLang('admin_smtp_secure') ?: 'Encryption', false); ?></label>
        <select id="smtp_secure" class="form-input" name="secure">
          <?php foreach ($secureOptions as $option):
            $label = customLang('admin_smtp_secure_' . $option) ?: strtoupper($option);
            $selected = $option === $secure ? ' selected' : '';
          ?>
            <option value="<?php echo iN_HelpSecure($option, false); ?>"<?php echo $selected; ?>><?php echo iN_HelpSecure($label, false); ?></option>
          <?php endforeach; ?>
        </select>
        </fieldset>

        <fieldset class="form-input-wrapper admin-settings-panel admin-contact-panel" data-contact-panel="auth">
          <legend><?php echo iN_HelpSecure($smtpAuthLegend, false); ?></legend>

        <label class="form-label" for="smtp_username"><?php echo iN_HelpSecure(customLang('admin_smtp_username') ?: 'Username', false); ?></label>
        <input id="smtp_username" class="form-input" type="text" name="username" value="<?php echo iN_HelpSecure($username, false); ?>" maxlength="191">

        <label class="form-label" for="smtp_password"><?php echo iN_HelpSecure(customLang('admin_smtp_password') ?: 'Password', false); ?></label>
        <input id="smtp_password" class="form-input" type="password" name="password" value="" autocomplete="new-password" maxlength="191">
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure($passwordHint, false); ?></p>
        <p class="form-text fs-13"><?php echo iN_HelpSecure($hasPassword ? $hasPasswordText : $noPasswordText, false); ?></p>

          <div class="admin-contact-toggle">
            <div class="admin-contact-toggle__body">
              <span class="admin-contact-toggle__label"><?php echo iN_HelpSecure(customLang('admin_smtp_password_clear') ?: 'Clear saved password', false); ?></span>
              <p class="admin-contact-toggle__hint"><?php echo iN_HelpSecure(customLang('admin_smtp_password_clear_hint') ?: 'Enable if you need to remove the stored credentials before saving.', false); ?></p>
            </div>
            <label class="el-switch el-switch-sm" for="smtp_clear_password">
              <input type="hidden" name="clear_password" value="0">
              <input id="smtp_clear_password" type="checkbox" name="clear_password" value="1">
              <span class="el-switch-style"></span>
            </label>
          </div>
        </fieldset>

        <fieldset class="form-input-wrapper admin-settings-panel admin-contact-panel" data-contact-panel="sender">
          <legend><?php echo iN_HelpSecure($smtpSenderLegend, false); ?></legend>

        <label class="form-label" for="smtp_from_name"><?php echo iN_HelpSecure(customLang('admin_contact_from_name') ?: 'From Name', false); ?></label>
        <input id="smtp_from_name" class="form-input" type="text" name="from_name" value="<?php echo iN_HelpSecure($fromName, false); ?>" maxlength="120">

        <?php $fromEmailRequired = $fromEmail !== '' ? 'required' : ''; ?>
        <label class="form-label" for="smtp_from_email"><?php echo iN_HelpSecure(customLang('admin_contact_from_email') ?: 'From Email', false); ?></label>
        <input id="smtp_from_email" class="form-input" type="email" name="from_email" value="<?php echo iN_HelpSecure($fromEmail, false); ?>" maxlength="191"<?php echo $fromEmailRequired ? ' required' : ''; ?>>
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure($fromEmailHint, false); ?></p>

        <?php $toEmailRequired = $toEmail !== '' ? 'required' : ''; ?>
        <label class="form-label" for="smtp_to_email"><?php echo iN_HelpSecure(customLang('admin_contact_to_email') ?: 'Notification Email', false); ?></label>
        <input id="smtp_to_email" class="form-input" type="email" name="to_email" value="<?php echo iN_HelpSecure($toEmail, false); ?>" maxlength="191"<?php echo $toEmailRequired ? ' required' : ''; ?>>
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure($toEmailHint, false); ?></p>
        </fieldset>

        <fieldset class="form-input-wrapper admin-settings-panel admin-contact-panel" data-contact-panel="security">
          <legend><?php echo iN_HelpSecure($smtpSecurityLegend, false); ?></legend>

          <div class="admin-contact-toggle">
            <div class="admin-contact-toggle__body">
              <span class="admin-contact-toggle__label"><?php echo iN_HelpSecure(customLang('admin_contact_recaptcha_enable') ?: 'Enable reCAPTCHA', false); ?></span>
              <p class="admin-contact-toggle__hint"><?php echo iN_HelpSecure($recaptchaHint, false); ?></p>
            </div>
            <label class="el-switch el-switch-sm" for="recaptcha_enabled">
              <input type="hidden" name="recaptcha_enabled" value="0">
              <input id="recaptcha_enabled" type="checkbox" name="recaptcha_enabled" value="1" <?php echo $recaptchaEnabled ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>

          <?php
            $hostExample = htmlspecialchars(parse_url($base_url, PHP_URL_HOST) ?? 'example.com', ENT_QUOTES, 'UTF-8');
            $langOrFallback = static function (string $key, string $fallback, array $replacements = []): string {
                $value = customLang($key);
                if (!is_string($value) || $value === '' || $value === $key) {
                    $value = $fallback;
                }
                foreach ($replacements as $needle => $replacement) {
                    $value = str_replace('{' . $needle . '}', $replacement, $value);
                }
                return $value;
            };

            $recaptchaGuideTitle = $langOrFallback('admin_contact_recaptcha_steps_title', 'How to get your reCAPTCHA keys');
            $envatoSteps = [
              $langOrFallback('admin_contact_recaptcha_step_envato_1', 'Sign in to the <a href="https://www.google.com/recaptcha/admin/" target="_blank" rel="noopener noreferrer">Google reCAPTCHA Admin Console</a> and log in with your Google account.'),
              $langOrFallback('admin_contact_recaptcha_step_envato_2', 'Create a new reCAPTCHA<ul class="admin-contact-sublist"><li>Click “+ Create”.</li><li>Select <strong>reCAPTCHA v2</strong> → <strong>“I’m not a robot” Checkbox</strong>.</li><li>Give your project a clear label (e.g., <em>My Website reCAPTCHA</em>).</li></ul>'),
              $langOrFallback('admin_contact_recaptcha_step_envato_3', 'Set your domain<ul class="admin-contact-sublist"><li>Add your live domain under “Domains” (for example: <code>{domain}</code>).</li><li>If you are testing locally, you can also add <code>localhost</code>.</li></ul>', ['domain' => $hostExample]),
              $langOrFallback('admin_contact_recaptcha_step_envato_4', 'Accept terms and submit<ul class="admin-contact-sublist"><li>Leave the owners as your Google account.</li><li>Accept Google’s reCAPTCHA terms and click <strong>Submit</strong>.</li></ul>'),
              $langOrFallback('admin_contact_recaptcha_step_envato_5', 'Copy your keys<ul class="admin-contact-sublist"><li>After submission you will see a <strong>Site Key</strong> and a <strong>Secret Key</strong>.</li><li>Paste both keys into the fields below and save your settings.</li></ul>'),
              $langOrFallback('admin_contact_recaptcha_step_envato_6', 'Test the integration<ul class="admin-contact-sublist"><li>Open your contact or sign-up form and submit a test.</li><li>You should see the “I’m not a robot” checkbox and the form should validate successfully.</li></ul>'),
            ];
          ?>
          <div class="admin-contact-guide box-note">
            <strong><?php echo iN_HelpSecure($recaptchaGuideTitle, false); ?></strong>
            <ol class="admin-contact-step-list">
              <?php foreach ($envatoSteps as $step): ?>
                <li><?php echo $step; ?></li>
              <?php endforeach; ?>
            </ol>
          </div>

          <label class="form-label" for="smtp_recaptcha_site"><?php echo iN_HelpSecure(customLang('admin_contact_recaptcha_site') ?: 'reCAPTCHA Site Key', false); ?></label>
          <input id="smtp_recaptcha_site" class="form-input" type="text" name="recaptcha_site_key" value="<?php echo iN_HelpSecure($recaptchaSite, false); ?>" maxlength="191">

          <label class="form-label" for="smtp_recaptcha_secret"><?php echo iN_HelpSecure(customLang('admin_contact_recaptcha_secret') ?: 'reCAPTCHA Secret Key', false); ?></label>
          <input id="smtp_recaptcha_secret" class="form-input" type="text" name="recaptcha_secret_key" value="<?php echo iN_HelpSecure($recaptchaSecret, false); ?>" maxlength="191">
        </fieldset>
      </div>

      <div class="form-input-wrapper form-input-wrapper--actions admin-contact-actions">
        <button type="submit" class="pe-save btn-hover transition"><?php echo iN_HelpSecure($saveSmtpLabel, false); ?></button>
      </div>
    </form>

    <form class="form-container flex flexBoxColumn admin-contact-settings-form" method="post" action="<?php echo $actionUrl; ?>" data-action="smtp-test">
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
      <input type="hidden" name="action" value="smtp_test">

      <div class="admin-contact-panel-grid">
        <fieldset class="form-input-wrapper admin-settings-panel admin-contact-panel" data-contact-panel="smtp-test">
          <legend><?php echo iN_HelpSecure($smtpTestLegend, false); ?></legend>
        <label class="form-label" for="smtp_test_email"><?php echo iN_HelpSecure(customLang('admin_smtp_test_email') ?: 'Recipient Email', false); ?></label>
        <input id="smtp_test_email" class="form-input" type="email" name="test_email" value="" maxlength="191" required>
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_smtp_test_hint') ?: 'Sends a one-off test message using the current SMTP configuration.', false); ?></p>
        </fieldset>
      </div>

      <div class="form-input-wrapper form-input-wrapper--actions admin-contact-actions">
        <button type="submit" class="btn-outline" data-action="smtp-test-send"><?php echo iN_HelpSecure($smtpTestLabel, false); ?></button>
      </div>
      <p class="form-helper fs-13" data-smtp-test-status hidden></p>
    </form>
  </div>

  <div class="landing-section-panel<?php echo $messagesTabActive ? ' is-active' : ''; ?>" data-section-panel="messages" role="tabpanel"<?php echo $messagesTabActive ? ' aria-hidden="false"' : ' aria-hidden="true" hidden'; ?>>
    <section
      class="form-container flex flexBoxColumn"
      data-role="contact-messages-panel"
      data-status-new="<?php echo iN_HelpSecure(customLang('contact_status_new') ?: 'New', false); ?>"
      data-status-read="<?php echo iN_HelpSecure(customLang('contact_status_read') ?: 'Read', false); ?>"
      data-status-resolved="<?php echo iN_HelpSecure(customLang('contact_status_resolved') ?: 'Resolved', false); ?>"
      data-type-feedback="<?php echo iN_HelpSecure($subjectLabelFeedback, false); ?>"
      data-type-complaint="<?php echo iN_HelpSecure($subjectLabelComplaint, false); ?>"
      data-type-suggestion="<?php echo iN_HelpSecure($subjectLabelSuggestion, false); ?>"
      data-type-bug="<?php echo iN_HelpSecure($subjectLabelBug, false); ?>"
      data-empty-text="<?php echo iN_HelpSecure(customLang('admin_contact_no_messages') ?: 'No messages found.', false); ?>"
      data-loading-text="<?php echo iN_HelpSecure(customLang('admin_loading') ?: 'Loading…', false); ?>"
      data-updated-text="<?php echo iN_HelpSecure(customLang('contact_modal_updated') ?: 'Status updated.', false); ?>"
      data-error-fetch="<?php echo iN_HelpSecure(customLang('contact_error_fetch') ?: 'Unable to load messages.', false); ?>"
      data-view-label="<?php echo iN_HelpSecure(customLang('contact_view_details') ?: 'View', false); ?>"
      data-page-template="<?php echo iN_HelpSecure(customLang('admin_contact_page_info') ?: 'Page %current% of %total%', false); ?>"
    >
      <form class="form-grid form-grid--third" data-role="contact-messages-filters">
        <div class="form-input-wrapper">
          <label class="form-label" for="contactFilterStatus"><?php echo iN_HelpSecure(customLang('admin_contact_filter_status') ?: 'Status', false); ?></label>
          <select id="contactFilterStatus" class="form-input" name="status">
            <option value="all"><?php echo iN_HelpSecure(customLang('contact_status_all') ?: 'All', false); ?></option>
            <option value="new"><?php echo iN_HelpSecure(customLang('contact_status_new') ?: 'New', false); ?></option>
            <option value="read"><?php echo iN_HelpSecure(customLang('contact_status_read') ?: 'Read', false); ?></option>
            <option value="resolved"><?php echo iN_HelpSecure(customLang('contact_status_resolved') ?: 'Resolved', false); ?></option>
          </select>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="contactFilterType"><?php echo iN_HelpSecure(customLang('admin_contact_filter_type') ?: 'Type', false); ?></label>
          <select id="contactFilterType" class="form-input" name="msg_type">
            <option value="all"><?php echo iN_HelpSecure(customLang('contact_type_all') ?: 'All', false); ?></option>
            <?php foreach ($subjectOptions as $type => $label): ?>
              <option value="<?php echo iN_HelpSecure($type); ?>"><?php echo iN_HelpSecure($label); ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="contactFilterStart"><?php echo iN_HelpSecure(customLang('admin_contact_filter_start') ?: 'Start date', false); ?></label>
          <input id="contactFilterStart" class="form-input" type="date" name="start_date">
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="contactFilterEnd"><?php echo iN_HelpSecure(customLang('admin_contact_filter_end') ?: 'End date', false); ?></label>
          <input id="contactFilterEnd" class="form-input" type="date" name="end_date">
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="contactFilterPerPage"><?php echo iN_HelpSecure(customLang('admin_contact_filter_per_page') ?: 'Per page', false); ?></label>
          <select id="contactFilterPerPage" class="form-input" name="per_page">
            <option value="10">10</option>
            <option value="20" selected>20</option>
            <option value="50">50</option>
          </select>
        </div>

        <div class="form-input-wrapper align-end">
          <button type="submit" class="btn-outline" data-action="contact-messages-apply"><?php echo iN_HelpSecure(customLang('admin_contact_filter_apply') ?: 'Apply filters', false); ?></button>
        </div>
      </form>

      <div class="table-responsive">
        <table class="table contact-messages-table">
          <thead>
            <tr>
              <th scope="col"><?php echo iN_HelpSecure(customLang('admin_contact_table_created') ?: 'Received', false); ?></th>
              <th scope="col"><?php echo iN_HelpSecure(customLang('admin_contact_table_subject') ?: 'Subject', false); ?></th>
              <th scope="col"><?php echo iN_HelpSecure(customLang('admin_contact_table_sender') ?: 'Sender', false); ?></th>
              <th scope="col"><?php echo iN_HelpSecure(customLang('admin_contact_table_type') ?: 'Type', false); ?></th>
              <th scope="col"><?php echo iN_HelpSecure(customLang('admin_contact_table_status') ?: 'Status', false); ?></th>
              <th scope="col"><?php echo iN_HelpSecure(customLang('admin_contact_table_actions') ?: 'Actions', false); ?></th>
            </tr>
          </thead>
          <tbody data-role="contact-messages-body">
            <tr data-role="contact-messages-empty">
              <td colspan="6"><?php echo iN_HelpSecure(customLang('admin_contact_no_messages') ?: 'No messages found.', false); ?></td>
            </tr>
          </tbody>
        </table>
      </div>

      <nav class="pagination" data-role="contact-messages-pagination"></nav>
    </section>

    <dialog id="contactMessageDialog" data-role="contact-message-dialog">
      <form method="dialog" class="contact-message-dialog">
        <header class="dialog-header">
          <h2 data-field="subject"></h2>
          <button type="submit" value="close" class="btn-outline" data-action="close-contact-message"><?php echo iN_HelpSecure(customLang('contact_modal_close') ?: 'Close', false); ?></button>
        </header>
        <section class="dialog-body">
          <dl class="message-meta">
            <div>
              <dt><?php echo iN_HelpSecure(customLang('contact_field_name') ?: 'Your name', false); ?></dt>
              <dd data-field="name"></dd>
            </div>
            <div>
              <dt><?php echo iN_HelpSecure(customLang('contact_field_email') ?: 'Email address', false); ?></dt>
              <dd data-field="email"></dd>
            </div>
            <div>
              <dt><?php echo iN_HelpSecure(customLang('admin_contact_table_type') ?: 'Type', false); ?></dt>
              <dd data-field="msg_type"></dd>
            </div>
            <div>
              <dt><?php echo iN_HelpSecure(customLang('admin_contact_table_status') ?: 'Status', false); ?></dt>
              <dd data-field="status"></dd>
            </div>
            <div>
              <dt><?php echo iN_HelpSecure(customLang('admin_contact_table_created') ?: 'Received', false); ?></dt>
              <dd data-field="created_at"></dd>
            </div>
            <div>
              <dt><?php echo iN_HelpSecure(customLang('contact_modal_meta_ip') ?: 'IP address', false); ?></dt>
              <dd data-field="ip"></dd>
            </div>
            <div>
              <dt><?php echo iN_HelpSecure(customLang('contact_modal_meta_user_agent') ?: 'User agent', false); ?></dt>
              <dd data-field="user_agent"></dd>
            </div>
            <div>
              <dt><?php echo iN_HelpSecure(customLang('contact_modal_meta_user') ?: 'User ID', false); ?></dt>
              <dd data-field="user_id"></dd>
            </div>
          </dl>

          <div class="message-body">
            <h3><?php echo iN_HelpSecure(customLang('contact_modal_message_label') ?: 'Message', false); ?></h3>
            <pre data-field="message"></pre>
          </div>

          <div class="form-input-wrapper">
            <label class="form-label" for="contactMessageStatus"><?php echo iN_HelpSecure(customLang('contact_modal_status_label') ?: 'Set status', false); ?></label>
            <select id="contactMessageStatus" class="form-input" data-field="status-select">
              <option value="new"><?php echo iN_HelpSecure(customLang('contact_status_new') ?: 'New', false); ?></option>
              <option value="read"><?php echo iN_HelpSecure(customLang('contact_status_read') ?: 'Read', false); ?></option>
              <option value="resolved"><?php echo iN_HelpSecure(customLang('contact_status_resolved') ?: 'Resolved', false); ?></option>
            </select>
          </div>
        </section>
        <footer class="dialog-footer">
          <button type="button" class="btn-hover" data-action="contact-message-update"><?php echo iN_HelpSecure(customLang('contact_modal_save') ?: 'Save', false); ?></button>
        </footer>
      </form>
    </dialog>
  </div>
</section>
