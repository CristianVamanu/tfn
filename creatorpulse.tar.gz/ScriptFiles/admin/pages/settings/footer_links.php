<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';

global $base_url, $ADMIN_CSRF, $RL, $iconPath;

$themeSlug = 'welcome_default';
$actionUrl = iN_HelpSecure($base_url . 'admin/request/landing_sections.php', false);
$csrfToken = iN_HelpSecure($ADMIN_CSRF, false);

$langDir = dirname(__DIR__, 3) . '/langs';
$langOptions = [];
if (is_dir($langDir)) {
    foreach (scandir($langDir) as $entry) {
        if (preg_match('/^(\w+)\.php$/', (string) $entry, $m)) {
            $langOptions[] = $m[1];
        }
    }
}
if (!$langOptions) {
    $langOptions = ['eng'];
}

$defaultLang = strtolower((string) ($langOptions[0] ?? 'eng')) ?: 'eng';
$pageRows = [];
if (isset($RL) && method_exists($RL, 'RL_GetPagesWithTranslations')) {
    $pageRows = $RL->RL_GetPagesWithTranslations($langOptions);
}

?>
<section class="card rounded-2xl" role="region" aria-labelledby="footerLinksHeading">
  <div class="list-header" id="footerLinksHeading">
    <span class="icon"><?php echo renderVerifiedBadge($iconPath . 'link.svg', true); ?></span>
    <span><strong><?php echo iN_HelpSecure(customLang('admin_footer_tabs_pages') ?: 'Pages', false); ?></strong></span>
  </div>

  <div class="landing-section-panel is-active" data-section-panel="pages" role="tabpanel" aria-hidden="false">
    <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="save-landing-pages" data-default-lang="<?php echo iN_HelpSecure($defaultLang, false); ?>" data-error-default-title="<?php echo iN_HelpSecure(customLang('admin_page_default_required') ?: 'Default language title is required.', false); ?>">
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
      <input type="hidden" name="action" value="save_footer_pages">
      <input type="hidden" name="theme" value="<?php echo iN_HelpSecure($themeSlug, false); ?>">
      <input type="hidden" name="default_lang" value="<?php echo iN_HelpSecure($defaultLang, false); ?>">

      <div class="landing-feature-list" data-sortable-list="pages">
        <?php foreach ($pageRows as $rowKey => $page):
          $rowKeySafe = iN_HelpSecure('page_' . $rowKey, false);
          $pageId = (int) ($page['id'] ?? 0);
          $slugVal = iN_HelpSecure((string) ($page['slug'] ?? ''), false);
          $activeVal = !empty($page['is_active']);
          $sortVal = (int) ($page['sort_order'] ?? 0);
          $translations = isset($page['translations']) && is_array($page['translations']) ? $page['translations'] : [];
        ?>
        <div class="landing-feature-card" data-sortable-item data-row-key="<?php echo $rowKeySafe; ?>" draggable="true">
          <div class="landing-feature-controls">
            <span class="landing-drag-handle" aria-hidden="true">☰</span>
            <button type="button" class="landing-remove-row" data-remove-page aria-label="<?php echo iN_HelpSecure(customLang('admin_remove_row') ?: 'Remove row', false); ?>" data-page-id="<?php echo $pageId; ?>">&times;</button>
          </div>
          <input type="hidden" name="page_id[<?php echo $rowKeySafe; ?>]" value="<?php echo $pageId; ?>">

          <div class="landing-feature-main">
            <label class="form-label" for="page_slug_<?php echo $rowKeySafe; ?>"><?php echo iN_HelpSecure(customLang('admin_page_slug') ?: 'Slug', false); ?></label>
            <input id="page_slug_<?php echo $rowKeySafe; ?>" class="form-input" type="text" name="page_slug[<?php echo $rowKeySafe; ?>]" value="<?php echo $slugVal; ?>" maxlength="120" data-page-slug>

            <label class="form-label" for="page_sort_<?php echo $rowKeySafe; ?>"><?php echo iN_HelpSecure(customLang('admin_page_sort_order') ?: 'Sort order', false); ?></label>
            <input id="page_sort_<?php echo $rowKeySafe; ?>" class="form-input" type="number" name="page_sort[<?php echo $rowKeySafe; ?>]" value="<?php echo iN_HelpSecure((string) $sortVal, false); ?>">

            <div class="form-switch flex align_items column-gap">
              <span class="fs-13"><?php echo iN_HelpSecure(customLang('admin_page_active') ?: 'Active', false); ?></span>
              <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('admin_page_active') ?: 'Active', false); ?>">
                <input type="hidden" name="page_active[<?php echo $rowKeySafe; ?>]" value="0">
                <input type="checkbox" name="page_active[<?php echo $rowKeySafe; ?>]" value="1" <?php echo $activeVal ? 'checked' : ''; ?>>
                <span class="el-switch-style"></span>
              </label>
            </div>
          </div>

          <div class="landing-feature-langs-plus flexBoxColumn" data-lang-switcher>
            <div class="landing-lang-tabs" data-lang-tabs>
              <?php foreach ($langOptions as $index => $langCode):
                $langSafe = iN_HelpSecure(strtolower($langCode), false);
                $isActive = $index === 0;
              ?>
                <button type="button" class="landing-lang-tab<?php echo $isActive ? ' is-active' : ''; ?>" data-lang-target="<?php echo $langSafe; ?>" aria-selected="<?php echo $isActive ? 'true' : 'false'; ?>"><?php echo iN_HelpSecure(strtoupper($langCode), false); ?></button>
              <?php endforeach; ?>
            </div>

            <?php foreach ($langOptions as $index => $langCode):
              $langKey = strtolower($langCode);
              $langSafe = iN_HelpSecure($langKey, false);
              $isActive = $index === 0;
              $titleVal = iN_HelpSecure((string) ($translations[$langKey]['title'] ?? ''), false);
              $contentVal = iN_HelpSecure((string) ($translations[$langKey]['content'] ?? ''), false, 0, false);
              $titlePlaceholder = iN_HelpSecure(customLang('footer_cta_title') ?: 'Page title', false);
            ?>
              <div class="landing-lang-panel<?php echo $isActive ? ' is-active' : ''; ?>" data-lang-panel="<?php echo $langSafe; ?>" aria-hidden="<?php echo $isActive ? 'false' : 'true'; ?>"<?php echo $isActive ? '' : ' hidden'; ?>>
                <label class="form-label" for="page_title_<?php echo $langSafe . '_' . $rowKeySafe; ?>"><?php echo iN_HelpSecure(customLang('admin_page_title') ?: 'Title', false); ?></label>
                <input id="page_title_<?php echo $langSafe . '_' . $rowKeySafe; ?>" class="form-input" type="text" name="page_title[<?php echo $langSafe; ?>][<?php echo $rowKeySafe; ?>]" value="<?php echo $titleVal; ?>" maxlength="255" data-page-title="<?php echo $langSafe === $defaultLang ? 'default' : 'other'; ?>">

                <label class="form-label" for="page_content_<?php echo $langSafe . '_' . $rowKeySafe; ?>"><?php echo iN_HelpSecure(customLang('admin_page_content') ?: 'Content', false); ?></label>
                <textarea id="page_content_<?php echo $langSafe . '_' . $rowKeySafe; ?>" class="form-input js-page-editor" name="page_content[<?php echo $langSafe; ?>][<?php echo $rowKeySafe; ?>]" rows="6" data-editor><?php echo $contentVal; ?></textarea>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <button type="button" class="btn-outline" data-action="add-page"><?php echo iN_HelpSecure(customLang('admin_add_page') ?: 'Add Page', false); ?></button>

      <template id="footerPageTemplate">
        <div class="landing-feature-card" data-sortable-item data-row-key="__KEY__" draggable="true">
          <div class="landing-feature-controls">
            <span class="landing-drag-handle" aria-hidden="true">☰</span>
            <button type="button" class="landing-remove-row" data-remove-page aria-label="<?php echo iN_HelpSecure(customLang('admin_remove_row') ?: 'Remove row', false); ?>">&times;</button>
          </div>
          <input type="hidden" name="page_id[__KEY__]" value="0">
          <div class="landing-feature-main">
            <label class="form-label" for="page_slug___KEY__"><?php echo iN_HelpSecure(customLang('admin_page_slug') ?: 'Slug', false); ?></label>
            <input id="page_slug___KEY__" class="form-input" type="text" name="page_slug[__KEY__]" value="" maxlength="120" data-page-slug>

            <label class="form-label" for="page_sort___KEY__"><?php echo iN_HelpSecure(customLang('admin_page_sort_order') ?: 'Sort order', false); ?></label>
            <input id="page_sort___KEY__" class="form-input" type="number" name="page_sort[__KEY__]" value="0">

            <div class="form-switch flex align_items column-gap">
              <span class="fs-13"><?php echo iN_HelpSecure(customLang('admin_page_active') ?: 'Active', false); ?></span>
              <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('admin_page_active') ?: 'Active', false); ?>">
                <input type="hidden" name="page_active[__KEY__]" value="0">
                <input type="checkbox" name="page_active[__KEY__]" value="1" checked>
                <span class="el-switch-style"></span>
              </label>
            </div>
          </div>
          <div class="landing-feature-langs-plus" data-lang-switcher>
            <div class="landing-lang-tabs" data-lang-tabs>
              <?php foreach ($langOptions as $index => $langCode):
                $langSafe = iN_HelpSecure(strtolower($langCode), false);
              ?>
                <button type="button" class="landing-lang-tab<?php echo $index === 0 ? ' is-active' : ''; ?>" data-lang-target="<?php echo $langSafe; ?>" aria-selected="<?php echo $index === 0 ? 'true' : 'false'; ?>"><?php echo iN_HelpSecure(strtoupper($langCode), false); ?></button>
              <?php endforeach; ?>
            </div>
            <?php foreach ($langOptions as $index => $langCode):
              $langSafe = iN_HelpSecure(strtolower($langCode), false);
              $isActive = $index === 0;
            ?>
              <div class="landing-lang-panel<?php echo $isActive ? ' is-active' : ''; ?>" data-lang-panel="<?php echo $langSafe; ?>" aria-hidden="<?php echo $isActive ? 'false' : 'true'; ?>"<?php echo $isActive ? '' : ' hidden'; ?>>
                <label class="form-label" for="page_title_<?php echo $langSafe; ?>___KEY__"><?php echo iN_HelpSecure(customLang('admin_page_title') ?: 'Title', false); ?></label>
                <input id="page_title_<?php echo $langSafe; ?>___KEY__" class="form-input" type="text" name="page_title[<?php echo $langSafe; ?>][__KEY__]" value="" maxlength="255" data-page-title="<?php echo strtolower($langCode) === $defaultLang ? 'default' : 'other'; ?>">

                <label class="form-label" for="page_content_<?php echo $langSafe; ?>___KEY__"><?php echo iN_HelpSecure(customLang('admin_page_content') ?: 'Content', false); ?></label>
                <textarea id="page_content_<?php echo $langSafe; ?>___KEY__" class="form-input js-page-editor" name="page_content[<?php echo $langSafe; ?>][__KEY__]" rows="6" data-editor></textarea>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </template>

      <div class="pages-deleted"></div>

      <button type="submit" class="pe-save btn-hover align-self-start"><?php echo iN_HelpSecure(customLang('admin_save_changes') ?: 'Save Changes', false); ?></button>
    </form>
  </div>
</section>

<?php
$tinymceBase = rtrim((string) $base_url, '/') . '/admin/js/tinymce';
?>
<script defer src="<?php echo iN_HelpSecure($tinymceBase . '/tinymce.min.js', false); ?>"></script>
