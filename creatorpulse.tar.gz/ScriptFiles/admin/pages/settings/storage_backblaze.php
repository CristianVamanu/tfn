<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';
require_once __DIR__ . '/storage_helpers.php';

global $siteData, $base_url, $ADMIN_CSRF;

$storageSettings = admin_storage_settings($siteData);
$backblazeConfig = admin_storage_provider($storageSettings, 'backblaze');

$enabled = admin_storage_bool($backblazeConfig['enabled'] ?? null, false);
$isDefault = ($storageSettings['driver'] ?? 'local') === 'backblaze';
$visibility = admin_storage_visibility($backblazeConfig['default_visibility'] ?? 'private', 'private');
$publicBase = (string) ($backblazeConfig['public_base_url'] ?? '');
$region = (string) ($backblazeConfig['region'] ?? ($backblazeConfig['backblaze_region'] ?? ''));
$bucket = (string) ($backblazeConfig['bucket'] ?? '');
$prefix = (string) ($backblazeConfig['prefix'] ?? '');
$endpoint = (string) ($backblazeConfig['endpoint'] ?? '');
$pathStyle = admin_storage_bool($backblazeConfig['path_style'] ?? null, true);
$deferNetwork = admin_storage_bool($backblazeConfig['defer_network'] ?? null, false);
$ttl = isset($backblazeConfig['default_presign_ttl']) ? (int) $backblazeConfig['default_presign_ttl'] : 3600;
$rawKey = storage_decrypt_secret($backblazeConfig['access_key'] ?? '');
$rawSecret = storage_decrypt_secret($backblazeConfig['secret_key'] ?? '');
$maskedKey = admin_storage_mask_secret($rawKey);
$maskedSecret = admin_storage_mask_secret($rawSecret);
$hasKey = $rawKey !== '';
$hasSecret = $rawSecret !== '';
$cdnDomain = (string) ($backblazeConfig['cdn_domain'] ?? '');
$keepLocalCopy = admin_storage_bool($backblazeConfig['keep_local_copy'] ?? null, true);
$syncMode = admin_storage_sync_mode($backblazeConfig, 'manual');
$backblazeRegions = [
    'us-west-000'  => 'US West (Northern California)',
    'us-west-001'  => 'US West (Las Vegas)',
    'us-west-004'  => 'US West (Phoenix)',
    'us-east-001'  => 'US East (Northern Virginia)',
    'eu-central-003' => 'EU Central (Frankfurt)',
    'eu-west-001'  => 'EU West (Amsterdam)',
    'ap-south-001' => 'AP South (Mumbai)',
    'ap-east-001'  => 'AP East (Tokyo)',
];

$actionUrl = iN_HelpSecure($base_url . 'admin/request/storage_settings.php', false);
$csrfToken = iN_HelpSecure($ADMIN_CSRF, false);
?>

<section class="card rounded-2xl admin-settings" role="region" aria-labelledby="adminStorageBackblazeHeading">
  <h1 id="adminStorageBackblazeHeading"><?php echo iN_HelpSecure(customLang('storage_heading_backblaze') ?: 'Storage · Backblaze B2'); ?></h1>
  <p class="box-note full-width"><?php echo iN_HelpSecure(customLang('storage_intro_backblaze') ?: 'Connect Backblaze B2 (S3-compatible) for remote media storage.'); ?></p>

  <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="storage-settings" data-storage-provider="backblaze">
    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
    <input type="hidden" name="provider" value="backblaze">
    <input type="hidden" name="action" value="save">

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('storage_section_status') ?: 'Provider Status'); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="backblaze_enable_provider"><?php echo iN_HelpSecure(customLang('storage_toggle_enable') ?: 'Enable provider'); ?></label>
          <div class="flex align_items column-gap">
            <input type="hidden" name="enable_provider" value="0">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_toggle_enable') ?: 'Enable provider'); ?>">
              <input id="backblaze_enable_provider" type="checkbox" name="enable_provider" value="1" <?php echo $enabled ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_toggle_enable_hint_backblaze') ?: 'Send new uploads to your Backblaze bucket.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="backblaze_set_default"><?php echo iN_HelpSecure(customLang('storage_toggle_default') ?: 'Set as default storage'); ?></label>
          <div class="flex align_items column-gap">
            <input type="hidden" name="set_default" value="0">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_toggle_default') ?: 'Set as default storage'); ?>">
              <input id="backblaze_set_default" type="checkbox" name="set_default" value="1" <?php echo $isDefault ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_toggle_default_hint_backblaze') ?: 'Activates Backblaze for all future uploads.'); ?></small>
        </div>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('storage_section_credentials') ?: 'Credentials'); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="backblaze_access_key"><?php echo iN_HelpSecure(customLang('storage_field_access_key') ?: 'Access key ID'); ?></label>
          <input id="backblaze_access_key" class="form-input" type="password" name="access_key" placeholder="B2_KEYID" autocomplete="off">
          <small class="form-text text-muted">
            <?php echo iN_HelpSecure(customLang('storage_field_access_key_hint') ?: 'Leave blank to keep the stored key.'); ?>
            <?php if ($maskedKey !== ''): ?>
              <span class="text-muted"><?php echo iN_HelpSecure(customLang('storage_field_current_value') ?: 'Current:'); ?> <?php echo $maskedKey; ?></span>
            <?php endif; ?>
          </small>
          <?php if ($hasKey): ?>
            <label class="form-checkbox">
              <input type="checkbox" name="access_key_clear" value="1">
              <span><?php echo iN_HelpSecure(customLang('storage_field_clear_value') ?: 'Clear stored value'); ?></span>
            </label>
          <?php endif; ?>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="backblaze_secret_key"><?php echo iN_HelpSecure(customLang('storage_field_secret_key') ?: 'Secret access key'); ?></label>
          <input id="backblaze_secret_key" class="form-input" type="password" name="secret_key" placeholder="Secret" autocomplete="off">
          <small class="form-text text-muted">
            <?php echo iN_HelpSecure(customLang('storage_field_secret_key_hint') ?: 'Leave blank to keep the stored secret.'); ?>
            <?php if ($maskedSecret !== ''): ?>
              <span class="text-muted"><?php echo iN_HelpSecure(customLang('storage_field_current_value') ?: 'Current:'); ?> <?php echo $maskedSecret; ?></span>
            <?php endif; ?>
          </small>
          <?php if ($hasSecret): ?>
            <label class="form-checkbox">
              <input type="checkbox" name="secret_key_clear" value="1">
              <span><?php echo iN_HelpSecure(customLang('storage_field_clear_value') ?: 'Clear stored value'); ?></span>
            </label>
          <?php endif; ?>
        </div>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('storage_section_bucket') ?: 'Bucket & routing'); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="backblaze_region"><?php echo iN_HelpSecure(customLang('storage_field_backblaze_region') ?: 'Region'); ?></label>
          <select id="backblaze_region" class="form-input" name="backblaze_region">
            <?php if ($region === ''): ?>
              <option value="" disabled selected>— <?php echo iN_HelpSecure(customLang('storage_field_select_option') ?: 'Choose a region'); ?> —</option>
            <?php endif; ?>
            <?php foreach ($backblazeRegions as $regionKey => $label): ?>
              <option value="<?php echo iN_HelpSecure($regionKey, false); ?>" <?php echo $region === $regionKey ? 'selected' : ''; ?>>
                <?php echo iN_HelpSecure($label); ?>
              </option>
            <?php endforeach; ?>
            <?php if ($region !== '' && !isset($backblazeRegions[$region])): ?>
              <option value="<?php echo iN_HelpSecure($region, false); ?>" selected>
                <?php echo iN_HelpSecure(customLang('storage_field_custom_region_option') ?: 'Custom region'); ?> (<?php echo iN_HelpSecure($region, false); ?>)
              </option>
            <?php endif; ?>
          </select>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_backblaze_region_hint') ?: 'Use the Backblaze S3 region, e.g., us-west-000 or eu-central-003.'); ?></small>
          <div class="form-input-wrapper mt-2">
            <label class="form-label" for="backblaze_region_custom"><?php echo iN_HelpSecure(customLang('storage_field_backblaze_region_custom') ?: 'Custom region (optional)'); ?></label>
            <input id="backblaze_region_custom" class="form-input" type="text" name="backblaze_region_custom" value="<?php echo !isset($backblazeRegions[$region]) ? iN_HelpSecure($region, false) : ''; ?>" placeholder="custom-region-code" autocomplete="off">
            <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_backblaze_region_custom_hint') ?: 'Leave blank unless your bucket lives in a region not listed above.'); ?></small>
          </div>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="backblaze_bucket"><?php echo iN_HelpSecure(customLang('storage_field_bucket') ?: 'Bucket name'); ?></label>
          <input id="backblaze_bucket" class="form-input" type="text" name="bucket" value="<?php echo iN_HelpSecure($bucket, false); ?>" placeholder="my-b2-bucket" autocomplete="off">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_bucket_hint') ?: 'The bucket must already exist and allow S3 API access.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="backblaze_prefix"><?php echo iN_HelpSecure(customLang('storage_field_prefix') ?: 'Key prefix (optional)'); ?></label>
          <input id="backblaze_prefix" class="form-input" type="text" name="prefix" value="<?php echo iN_HelpSecure($prefix, false); ?>" placeholder="media/uploads">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_prefix_hint') ?: 'Prepends this folder to every uploaded object.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="backblaze_endpoint"><?php echo iN_HelpSecure(customLang('storage_field_endpoint') ?: 'Custom endpoint (optional)'); ?></label>
          <input id="backblaze_endpoint" class="form-input" type="url" name="endpoint" value="<?php echo iN_HelpSecure($endpoint, false); ?>" placeholder="https://s3.us-west-000.backblazeb2.com">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_backblaze_endpoint_hint') ?: 'Only override if you use a private / region-specific S3 endpoint.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="backblaze_cdn_domain"><?php echo iN_HelpSecure(customLang('storage_field_cdn_domain') ?: 'CDN domain (optional)'); ?></label>
          <input id="backblaze_cdn_domain" class="form-input" type="text" name="cdn_domain" value="<?php echo iN_HelpSecure($cdnDomain, false); ?>" placeholder="cdn.example.com">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_cdn_domain_hint') ?: 'If you front the bucket with a CDN, enter the hostname.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="backblaze_visibility"><?php echo iN_HelpSecure(customLang('storage_field_visibility') ?: 'Default visibility'); ?></label>
          <select id="backblaze_visibility" class="form-input" name="default_visibility">
            <option value="private" <?php echo $visibility === 'private' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('storage_field_visibility_private') ?: 'Private (signed URLs)'); ?></option>
            <option value="public" <?php echo $visibility === 'public' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('storage_field_visibility_public') ?: 'Public (direct URL)'); ?></option>
          </select>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_visibility_hint') ?: 'Controls how new uploads are exposed.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="backblaze_presign_ttl"><?php echo iN_HelpSecure(customLang('storage_field_presign_ttl') ?: 'Signed URL TTL (seconds)'); ?></label>
          <input id="backblaze_presign_ttl" class="form-input" type="number" name="default_presign_ttl" value="<?php echo iN_HelpSecure((string) $ttl, false); ?>" min="60" max="604800">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_presign_ttl_hint') ?: 'Expiry for temporary URLs when visibility is private.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="backblaze_path_style"><?php echo iN_HelpSecure(customLang('storage_field_path_style') ?: 'Force path-style URLs'); ?></label>
          <div class="flex align_items column-gap">
            <input type="hidden" name="path_style" value="0">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_field_path_style') ?: 'Force path-style URLs'); ?>">
              <input id="backblaze_path_style" type="checkbox" name="path_style" value="1" <?php echo $pathStyle ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_backblaze_path_style_hint') ?: 'Keep enabled for most Backblaze buckets (virtual-host style may fail).'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="backblaze_defer_network"><?php echo iN_HelpSecure(customLang('storage_field_defer_network') ?: 'Defer network calls (dry-run mode)'); ?></label>
          <div class="flex align_items column-gap">
            <input type="hidden" name="defer_network" value="0">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_field_defer_network') ?: 'Defer network calls (dry-run mode)'); ?>">
              <input id="backblaze_defer_network" type="checkbox" name="defer_network" value="1" <?php echo $deferNetwork ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_defer_network_hint') ?: 'Skip live connectivity checks until the background sync runs.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="backblaze_keep_local_copy"><?php echo iN_HelpSecure(customLang('storage_field_keep_local_copy') ?: 'Keep local copies'); ?></label>
          <div class="flex align_items column-gap">
            <input type="hidden" name="keep_local_copy" value="0">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_field_keep_local_copy') ?: 'Keep local copies'); ?>">
              <input id="backblaze_keep_local_copy" type="checkbox" name="keep_local_copy" value="1" <?php echo $keepLocalCopy ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_keep_local_copy_hint') ?: 'Mirror uploads locally for rollbacks and CDN failover.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="backblaze_sync_mode"><?php echo iN_HelpSecure(customLang('storage_field_sync_mode') ?: 'Sync mode'); ?></label>
          <select id="backblaze_sync_mode" class="form-input" name="sync_mode">
            <option value="manual" <?php echo $syncMode === 'manual' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('storage_field_sync_mode_manual') ?: 'Manual (CLI / cron)'); ?></option>
            <option value="background" <?php echo $syncMode === 'background' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('storage_field_sync_mode_background') ?: 'Background worker'); ?></option>
          </select>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_sync_mode_hint') ?: 'Manual mode uses the storage_sync CLI stub; background mode assumes a worker calls the admin endpoint.'); ?></small>
        </div>
      </div>
    </fieldset>

    <div class="form-actions flex align_items column-gap">
      <button type="submit" class="admin-button admin-button--primary" data-role="storage-save">
        <?php echo iN_HelpSecure(customLang('storage_button_save') ?: 'Save changes'); ?>
      </button>
      <button type="button" class="admin-button admin-button--ghost" data-action="storage-test" data-storage-provider="backblaze">
        <?php echo iN_HelpSecure(customLang('storage_button_test') ?: 'Test connection'); ?>
      </button>
    </div>
  </form>
</section>
