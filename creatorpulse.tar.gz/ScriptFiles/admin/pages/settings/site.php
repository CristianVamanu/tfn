<?php
declare(strict_types=1);
require_once __DIR__ . '/../../_bootstrap.php'; // Guard admin access

global $siteData, $base_url, $ADMIN_CSRF, $db;

$siteName        = (string)($siteData['site_name'] ?? '');
$siteTitle       = (string)($siteData['site_title'] ?? '');
$siteDescription = (string)($siteData['site_description'] ?? '');
$siteKeywords    = (string)($siteData['site_keywords'] ?? '');
$siteLang        = (string)($siteData['site_language'] ?? 'eng');
$siteTheme       = (string)($siteData['site_theme'] ?? 'default');
$logoWhite       = (string)($siteData['logo_white'] ?? '');
$logoDark        = (string)($siteData['logo_dark'] ?? '');
$logoMobileWhite = (string)($siteData['logo_mobile_white'] ?? '');
$logoMobileDark  = (string)($siteData['logo_mobile_dark'] ?? '');
$premiumMin      = (string)($siteData['premium_post_price_minimum'] ?? '');
$premiumMax      = (string)($siteData['premium_post_price_maximum'] ?? '');
$subscriptionFee = (string)($siteData['subscription_fee'] ?? '');
$paymentTaxPercent = (string)($siteData['payment_tax_percent'] ?? '');
$paymentFeePercent = (string)($siteData['payment_fee_percent'] ?? '');
$paymentFeeFixed   = (string)($siteData['payment_fee_fixed'] ?? '');
$videoExts       = (string)($siteData['available_video_extensions'] ?? '');
$uploadSizeMb    = (string)($siteData['available_file_upload_size'] ?? '');
$maxVideoDuration= (string)($siteData['maximum_video_duration'] ?? '');
$maxAudioDuration= (string)($siteData['maximum_audio_duration'] ?? '');
$messageScroll   = (string)($siteData['message_scroll_limit'] ?? '5');
$pageScroll      = (string)($siteData['page_scroll_limit'] ?? '10');
$toggleNormalize = static function ($value, string $default = 'open'): string {
    $v = strtolower((string) $value);
    if ($v === 'open' || $v === 'close') {
        return $v;
    }
    return $default;
};
$imagePostsStatus = $toggleNormalize($siteData['image_posts_status'] ?? 'open');
$videoPostsStatus = $toggleNormalize($siteData['video_posts_status'] ?? 'open');
$podcastPostsStatus = $toggleNormalize($siteData['podcast_posts_status'] ?? 'open');
$adsStatus        = $toggleNormalize($siteData['ads_status'] ?? 'open');
$suggestedUsersStatus = $toggleNormalize($siteData['suggested_users_status'] ?? 'open');
$suggestedUsersReload = $toggleNormalize($siteData['suggested_users_reload'] ?? 'open');
$suggestedUsersLimit = (int)($siteData['suggested_users_limit'] ?? 5);
if ($suggestedUsersLimit < 1) { $suggestedUsersLimit = 1; }
if ($suggestedUsersLimit > 20) { $suggestedUsersLimit = 20; }
$suggestedUsersModeRaw = (string)($siteData['suggested_users_mode'] ?? 'creators');
$suggestedUsersMode = in_array($suggestedUsersModeRaw, ['creators', 'users', 'mixed'], true) ? $suggestedUsersModeRaw : 'creators';
$postApprovalRequired = $toggleNormalize($siteData['post_approval_required'] ?? 'close', 'close');
$registerAutoUsername = $toggleNormalize($siteData['register_auto_username'] ?? 'open');
$registerPhoneEnabled = $toggleNormalize($siteData['register_phone_enabled'] ?? 'open');
$lockedPreviewModeBase = (string)($siteData['locked_preview_mode'] ?? 'off');
if (!in_array($lockedPreviewModeBase, ['off', 'static', 'animated'], true)) {
    $lockedPreviewModeBase = 'off';
}
$lockedPreviewModeImages = (string)($siteData['locked_preview_mode_images'] ?? $lockedPreviewModeBase);
if (!in_array($lockedPreviewModeImages, ['off', 'static', 'animated'], true)) {
    $lockedPreviewModeImages = 'off';
}
$lockedPreviewModeVideos = (string)($siteData['locked_preview_mode_videos'] ?? $lockedPreviewModeBase);
if (!in_array($lockedPreviewModeVideos, ['off', 'static', 'animated'], true)) {
    $lockedPreviewModeVideos = 'off';
}
$ffmpegPathValue = (string)($siteData['ffmpeg_path'] ?? '');
$ffprobePathValue = (string)($siteData['ffmpeg_probe_bin'] ?? '');
$scriptVersion   = (string)($siteData['script_version'] ?? '');
$baseDb          = (string)($siteData['site_base_url'] ?? '');
$envBase         = (string) (getenv('BASE_URL') ?: ($_ENV['BASE_URL'] ?? ($_SERVER['BASE_URL'] ?? '')));
$gtmIdValue      = strtoupper(trim((string)($siteData['gtm_id'] ?? '')));
$gtmDisableAdmins = (int)($siteData['gtm_disable_admins'] ?? 0) === 1;
$gtmEnvValue = '';
if (function_exists('env')) {
    $gtmEnvValue = (string) env('GTM_ID', '');
}
if ($gtmEnvValue === '') {
    $gtmEnvValue = (string) getenv('GTM_ID');
}
$gtmEnvValue = strtoupper(trim($gtmEnvValue));

$maintenanceStatus   = strtolower((string)($siteData['maintenance'] ?? 'off')) === 'on' ? 'on' : 'off';
$maintenanceMessage  = (string)($siteData['maintenance_message'] ?? '');
$maintenanceEtaRaw   = $siteData['maintenance_eta'] ?? null;
$maintenanceEtaValue = '';
if (is_numeric($maintenanceEtaRaw) && (int)$maintenanceEtaRaw > 0) {
    $maintenanceEtaValue = gmdate('Y-m-d\TH:i', (int)$maintenanceEtaRaw);
}
$maintenanceStatusUrl    = (string)($siteData['maintenance_status_url'] ?? ($siteData['status_page_url'] ?? ''));
$maintenanceSupportUrl   = (string)($siteData['maintenance_support_url'] ?? ($siteData['support_url'] ?? ''));
$maintenanceTwitterUrl   = (string)($siteData['maintenance_twitter_url'] ?? ($siteData['twitter_url'] ?? ''));
$maintenanceFacebookUrl  = (string)($siteData['maintenance_facebook_url'] ?? ($siteData['facebook_url'] ?? ''));
$maintenanceInstagramUrl = (string)($siteData['maintenance_instagram_url'] ?? ($siteData['instagram_url'] ?? ''));
$maintenanceTiktokUrl    = (string)($siteData['maintenance_tiktok_url'] ?? ($siteData['tiktok_url'] ?? ''));

$maintenanceUpdatedAt  = isset($siteData['maintenance_updated_at']) ? (int)$siteData['maintenance_updated_at'] : 0;
$maintenanceUpdatedBy  = isset($siteData['maintenance_updated_by']) ? (int)$siteData['maintenance_updated_by'] : 0;
$maintenanceUpdatedName = '';
if ($maintenanceUpdatedBy > 0 && isset($db) && $db instanceof PDO) {
    try {
        $stmt = $db->prepare('SELECT user_fullname, username FROM i_users WHERE user_id = :uid LIMIT 1');
        $stmt->execute([':uid' => $maintenanceUpdatedBy]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $maintenanceUpdatedName = (string)($row['user_fullname'] ?: $row['username'] ?: '');
        }
    } catch (Throwable $__) {
        $maintenanceUpdatedName = '';
    }
}
$maintenanceUpdatedDisplay = '';
if ($maintenanceUpdatedAt > 0) {
    $timeLabel = gmdate('M j, Y H:i', $maintenanceUpdatedAt) . ' UTC';
    if ($maintenanceUpdatedName !== '') {
        $maintenanceUpdatedDisplay = sprintf(customLang('admin_maintenance_last_updated_by') ?: 'Last updated %s by %s.', $timeLabel, $maintenanceUpdatedName);
    } else {
        $maintenanceUpdatedDisplay = sprintf(customLang('admin_maintenance_last_updated_unknown') ?: 'Last updated %s.', $timeLabel);
    }
}
$maintenanceLiveOnLabel  = customLang('admin_maintenance_live_on') ?: 'Maintenance is currently ON';
$maintenanceLiveOffLabel = customLang('admin_maintenance_live_off') ?: 'Maintenance is currently OFF';
$maintenanceRefreshingLabel = customLang('admin_maintenance_refreshing') ?: 'Refreshing live state…';
$maintenanceLiveLabel = $maintenanceStatus === 'on'
    ? $maintenanceLiveOnLabel
    : $maintenanceLiveOffLabel;


// Language options from langs directory
$langDir = dirname(__DIR__, 3) . '/langs';
$langOpts = [];
if (is_dir($langDir)) {
    foreach (scandir($langDir) as $entry) {
        if (preg_match('/^(\\w+)\\.php$/', $entry, $m)) {
            $langOpts[] = $m[1];
        }
    }
}
sort($langOpts);

// Load per-language dial code list values (language pack + overrides).
$registerDialCodesByLang = [];
if (function_exists('loadLanguage')) {
    foreach ($langOpts as $code) {
        $langData = loadLanguage($code);
        $list = '';
        if (is_array($langData) && isset($langData['register_phone_dial_codes_list'])) {
            $list = (string) $langData['register_phone_dial_codes_list'];
        }
        $registerDialCodesByLang[$code] = trim($list);
    }
} else {
    foreach ($langOpts as $code) {
        $registerDialCodesByLang[$code] = '';
    }
}

// Theme options from themes directory
$themesDir = dirname(__DIR__, 3) . '/themes';
$themeOpts = [];
if (is_dir($themesDir)) {
    foreach (scandir($themesDir) as $entry) {
        if ($entry === '.' || $entry === '..') { continue; }
        $path = $themesDir . '/' . $entry;
        if (is_dir($path) && !str_starts_with($entry, '.')) {
            $themeOpts[] = $entry;
        }
    }
}
sort($themeOpts);
if (!in_array($siteTheme, $themeOpts, true) && $themeOpts) {
    $siteTheme = $themeOpts[0];
}

$actionUrl  = iN_HelpSecure($base_url . 'admin/request/site_settings.php', false);
$csrfToken  = iN_HelpSecure($ADMIN_CSRF, false);
$baseValue  = $envBase !== '' ? $envBase : $baseDb;
$envOverride = customLang('admin_env_override_base_url') ?: 'If your hosting sets a BASE_URL environment variable, that value will be used instead of what you save here.';
$maintenanceStatusEndpoint = iN_HelpSecure($base_url . 'admin/request/maintenance_status.php', false);

$pageTitleText = customLang('admin_settings_site_title');
if (!is_string($pageTitleText) || $pageTitleText === '' || $pageTitleText === 'admin_settings_site_title') {
    $fallbackTitle = customLang('admin_menu_settings_site');
    if (is_string($fallbackTitle) && $fallbackTitle !== '' && $fallbackTitle !== 'admin_menu_settings_site') {
        $pageTitleText = $fallbackTitle;
    } else {
        $pageTitleText = 'Site Settings';
    }
}
$pageTitleSafe = iN_HelpSecure($pageTitleText, false);
?>

<section class="card rounded-2xl admin-settings" role="region" aria-labelledby="adminSiteSettingsHeading" data-page-title="<?php echo $pageTitleSafe; ?>">
  <h1 id="adminSiteSettingsHeading"><?php echo $pageTitleSafe; ?></h1>

  <form class="form-container flex flexBoxColumn admin-site-settings-form" method="post" action="<?php echo $actionUrl; ?>" enctype="multipart/form-data" data-action="save-site">
    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('admin_site_general') ?: 'General Information', false); ?></legend>
      <label class="form-label" for="site_name"><?php echo iN_HelpSecure(customLang('admin_site_name') ?: 'Site Name', false); ?></label>
      <input id="site_name" class="form-input" type="text" name="site_name" value="<?php echo iN_HelpSecure($siteName, false); ?>" maxlength="120" required>

      <div class="form-grid form-grid--quarter">
        <div class="form-input-wrapper">
          <label class="form-label" for="site_title"><?php echo iN_HelpSecure(customLang('admin_site_title') ?: 'Site Title', false); ?></label>
          <input id="site_title" class="form-input" type="text" name="site_title" value="<?php echo iN_HelpSecure($siteTitle, false); ?>" maxlength="255" placeholder="<?php echo iN_HelpSecure(customLang('admin_site_title_placeholder') ?: 'Used in <title> tag.', false); ?>">
        </div>

        <div class="form-input-wrapper form-input-wrapper--span2">
          <label class="form-label" for="site_description"><?php echo iN_HelpSecure(customLang('admin_site_description') ?: 'Meta Description', false); ?></label>
          <textarea id="site_description" class="form-input" name="site_description" rows="2" maxlength="1000" placeholder="<?php echo iN_HelpSecure(customLang('admin_site_description_placeholder') ?: 'Short summary for search engines.', false); ?>"><?php echo iN_HelpSecure($siteDescription, false); ?></textarea>
        </div>

        <div class="form-input-wrapper form-input-wrapper--span2">
          <label class="form-label" for="site_keywords"><?php echo iN_HelpSecure(customLang('admin_site_keywords') ?: 'Meta Keywords', false); ?></label>
          <textarea id="site_keywords" class="form-input" name="site_keywords" rows="2" maxlength="500" placeholder="<?php echo iN_HelpSecure(customLang('admin_site_keywords_placeholder') ?: 'Comma-separated keywords.', false); ?>"><?php echo iN_HelpSecure($siteKeywords, false); ?></textarea>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="site_language"><?php echo iN_HelpSecure(customLang('admin_site_language') ?: 'Default Language', false); ?></label>
          <select id="site_language" class="form-input" name="site_language">
            <?php foreach ($langOpts as $code): ?>
              <option value="<?php echo iN_HelpSecure($code, false); ?>"<?php echo $code === $siteLang ? ' selected' : ''; ?>><?php echo iN_HelpSecure(strtoupper($code), false); ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="site_theme"><?php echo iN_HelpSecure(customLang('admin_site_theme') ?: 'Theme', false); ?></label>
          <select id="site_theme" class="form-input" name="site_theme">
            <?php foreach ($themeOpts as $theme): ?>
              <option value="<?php echo iN_HelpSecure($theme, false); ?>"<?php echo $theme === $siteTheme ? ' selected' : ''; ?>><?php echo iN_HelpSecure(ucfirst($theme), false); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
    </fieldset>
    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('admin_site_base_section') ?: 'Base URL & Locale', false); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="site_base_url"><?php echo iN_HelpSecure(customLang('admin_site_base_url') ?: 'Base URL', false); ?></label>
          <input id="site_base_url" class="form-input" type="url" name="site_base_url" value="<?php echo iN_HelpSecure($baseValue, false); ?>" placeholder="https://example.com/">
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure($envOverride, false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="script_version"><?php echo iN_HelpSecure(customLang('admin_script_version') ?: 'Script Version', false); ?></label>
          <input id="script_version" class="form-input" type="text" value="<?php echo iN_HelpSecure($scriptVersion ?: '-', false); ?>" readonly>
        </div>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('admin_tracking_heading') ?: 'Analytics & Tracking', false); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="gtm_id"><?php echo iN_HelpSecure(customLang('admin_gtm_id_label') ?: 'Google Tag Manager ID', false); ?></label>
          <input
            id="gtm_id"
            class="form-input"
            type="text"
            name="gtm_id"
            value="<?php echo iN_HelpSecure($gtmIdValue, false); ?>"
            maxlength="32"
            pattern="^GTM-[A-Za-z0-9]+$"
            placeholder="GTM-XXXXXXX"
            autocomplete="off"
            inputmode="text"
          >
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_gtm_id_hint') ?: 'Example: GTM-XXXX. Leave empty to disable or set via GTM_ID env variable.', false); ?></p>
          <?php if ($gtmEnvValue !== ''): ?>
            <p class="form-text text-info fs-13"><?php echo iN_HelpSecure(sprintf(customLang('admin_gtm_env_override') ?: 'Runtime override active from GTM_ID=%s.', $gtmEnvValue), false); ?></p>
          <?php endif; ?>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="gtm_disable_admins"><?php echo iN_HelpSecure(customLang('admin_gtm_disable_admins_label') ?: 'Disable tracking for admins', false); ?></label>
          <div class="flex align_items column-gap">
            <label class="el-switch el-switch-sm margin-bottom-zero" aria-label="<?php echo iN_HelpSecure(customLang('admin_gtm_disable_admins_label') ?: 'Disable tracking for admins', false); ?>">
              <input type="hidden" name="gtm_disable_admins" value="0">
              <input
                type="checkbox"
                id="gtm_disable_admins"
                name="gtm_disable_admins"
                value="1"
                <?php echo $gtmDisableAdmins ? 'checked' : ''; ?>
              />
              <span class="el-switch-style"></span>
            </label>
            <span class="form-text fs-13"><?php echo iN_HelpSecure(customLang('admin_gtm_disable_admins_hint') ?: 'Skip GTM when an admin is logged in.', false); ?></span>
          </div>
        </div>
      </div>
    </fieldset>

    <fieldset
      class="form-input-wrapper admin-settings-panel"
      data-maintenance-section
      data-maintenance-endpoint="<?php echo $maintenanceStatusEndpoint; ?>"
      data-maintenance-label-on="<?php echo iN_HelpSecure($maintenanceLiveOnLabel, false); ?>"
      data-maintenance-label-off="<?php echo iN_HelpSecure($maintenanceLiveOffLabel, false); ?>"
      data-maintenance-label-refresh="<?php echo iN_HelpSecure($maintenanceRefreshingLabel, false); ?>"
    >
      <legend><?php echo iN_HelpSecure(customLang('admin_maintenance_heading') ?: 'Maintenance Mode', false); ?></legend>

      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="maintenance_toggle"><?php echo iN_HelpSecure(customLang('admin_maintenance_enable_label') ?: 'Enable maintenance mode', false); ?></label>
          <div class="flex align_items column-gap">
            <label class="el-switch el-switch-sm margin-bottom-zero" aria-label="<?php echo iN_HelpSecure(customLang('admin_maintenance_enable_label') ?: 'Enable maintenance mode', false); ?>">
              <input type="hidden" name="maintenance" value="off">
              <input
                type="checkbox"
                id="maintenance_toggle"
                name="maintenance"
                value="on"
                <?php echo $maintenanceStatus === 'on' ? 'checked' : ''; ?>
                data-maintenance-toggle
              />
              <span class="el-switch-style"></span>
            </label>
            <span class="form-text fs-13" data-maintenance-indicator><?php echo iN_HelpSecure($maintenanceLiveLabel, false); ?></span>
          </div>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_maintenance_enable_hint') ?: 'Blocks public traffic and shows a maintenance page. Admins keep full access.', false); ?></p>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_maintenance_timezone_hint') ?: 'Times are stored in UTC.', false); ?></p>
          <p class="form-text text-muted fs-13" data-maintenance-last-update><?php echo $maintenanceUpdatedDisplay !== '' ? iN_HelpSecure($maintenanceUpdatedDisplay, false) : ''; ?></p>
          <p class="form-text text-warning fs-13" data-maintenance-conflict style="display:none;"><?php echo iN_HelpSecure(customLang('admin_maintenance_conflict') ?: 'Another admin changed maintenance settings. Refresh to load the latest values.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="maintenance_eta"><?php echo iN_HelpSecure(customLang('admin_maintenance_eta_label') ?: 'Scheduled return (UTC)', false); ?></label>
          <input
            id="maintenance_eta"
            class="form-input"
            type="datetime-local"
            name="maintenance_eta"
            value="<?php echo iN_HelpSecure($maintenanceEtaValue, false); ?>"
            step="60"
            data-maintenance-eta
          >
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_maintenance_eta_hint') ?: 'Optional. Used for the Retry-After header and countdown messaging.', false); ?></p>
        </div>
      </div>

      <div class="form-input-wrapper">
        <label class="form-label" for="maintenance_message"><?php echo iN_HelpSecure(customLang('admin_maintenance_message_label') ?: 'Visitor-facing message', false); ?></label>
        <textarea
          id="maintenance_message"
          class="form-input"
          name="maintenance_message"
          rows="3"
          maxlength="2000"
          data-maintenance-message
        ><?php echo iN_HelpSecure($maintenanceMessage, false); ?></textarea>
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_maintenance_message_hint') ?: 'Plain text only. URLs starting with http(s) become clickable.', false); ?></p>
      </div>

      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="maintenance_status_url"><?php echo iN_HelpSecure(customLang('admin_maintenance_status_url_label') ?: 'Status page URL', false); ?></label>
          <input id="maintenance_status_url" class="form-input" type="url" name="maintenance_status_url" value="<?php echo iN_HelpSecure($maintenanceStatusUrl, false); ?>" placeholder="https://status.example.com" data-maintenance-link="status">
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="maintenance_support_url"><?php echo iN_HelpSecure(customLang('admin_maintenance_support_url_label') ?: 'Support URL', false); ?></label>
          <input id="maintenance_support_url" class="form-input" type="url" name="maintenance_support_url" value="<?php echo iN_HelpSecure($maintenanceSupportUrl, false); ?>" placeholder="https://support.example.com" data-maintenance-link="support">
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="maintenance_twitter_url"><?php echo iN_HelpSecure(customLang('admin_maintenance_twitter_url_label') ?: 'Twitter / X URL', false); ?></label>
          <input id="maintenance_twitter_url" class="form-input" type="url" name="maintenance_twitter_url" value="<?php echo iN_HelpSecure($maintenanceTwitterUrl, false); ?>" placeholder="https://twitter.com/yourhandle" data-maintenance-link="twitter">
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="maintenance_facebook_url"><?php echo iN_HelpSecure(customLang('admin_maintenance_facebook_url_label') ?: 'Facebook URL', false); ?></label>
          <input id="maintenance_facebook_url" class="form-input" type="url" name="maintenance_facebook_url" value="<?php echo iN_HelpSecure($maintenanceFacebookUrl, false); ?>" placeholder="https://facebook.com/YourPage" data-maintenance-link="facebook">
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="maintenance_instagram_url"><?php echo iN_HelpSecure(customLang('admin_maintenance_instagram_url_label') ?: 'Instagram URL', false); ?></label>
          <input id="maintenance_instagram_url" class="form-input" type="url" name="maintenance_instagram_url" value="<?php echo iN_HelpSecure($maintenanceInstagramUrl, false); ?>" placeholder="https://instagram.com/yourhandle" data-maintenance-link="instagram">
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="maintenance_tiktok_url"><?php echo iN_HelpSecure(customLang('admin_maintenance_tiktok_url_label') ?: 'TikTok URL', false); ?></label>
          <input id="maintenance_tiktok_url" class="form-input" type="url" name="maintenance_tiktok_url" value="<?php echo iN_HelpSecure($maintenanceTiktokUrl, false); ?>" placeholder="https://www.tiktok.com/@yourhandle" data-maintenance-link="tiktok">
        </div>
      </div>
      <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_maintenance_links_hint') ?: 'Optional. Links appear on the maintenance screen as status badges.', false); ?></p>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('admin_site_branding') ?: 'Branding Assets', false); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper form-input-wrapper--branding">
          <label class="form-label" for="logo_white"><?php echo iN_HelpSecure(customLang('admin_logo_light') ?: 'Logo (Light Background)', false); ?></label>
          <?php if ($logoWhite !== ''): ?>
            <div class="logo-preview">
              <img src="<?php echo iN_HelpSecure($base_url . $logoWhite, false); ?>" alt="<?php echo iN_HelpSecure(customLang('admin_logo_light') ?: 'Logo (Light)', false); ?>">
            </div>
            <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_current_logo') ?: 'Current file:', false); ?> <?php echo iN_HelpSecure($logoWhite, false); ?></p>
          <?php endif; ?>
          <label class="file-picker" for="logo_white">
            <span class="file-picker__icon" aria-hidden="true"><?php echo renderVerifiedBadge($iconPath . 'image.svg', true); ?></span>
            <span><?php echo iN_HelpSecure(customLang('admin_upload_logo_light') ?: 'Upload light logo', false); ?></span>
          </label>
          <p class="file-picker-status" data-status-for="logo_white"></p>
          <input id="logo_white" class="form-input sr-only" type="file" name="logo_white" accept="image/*" data-status-target="logo_white">
        </div>

        <div class="form-input-wrapper form-input-wrapper--branding">
          <label class="form-label" for="logo_dark"><?php echo iN_HelpSecure(customLang('admin_logo_dark') ?: 'Logo (Dark Background)', false); ?></label>
          <?php if ($logoDark !== ''): ?>
            <div class="logo-preview logo-preview--dark">
              <img src="<?php echo iN_HelpSecure($base_url . $logoDark, false); ?>" alt="<?php echo iN_HelpSecure(customLang('admin_logo_dark') ?: 'Logo (Dark)', false); ?>">
            </div>
            <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_current_logo') ?: 'Current file:', false); ?> <?php echo iN_HelpSecure($logoDark, false); ?></p>
          <?php endif; ?>
          <label class="file-picker" for="logo_dark">
            <span class="file-picker__icon" aria-hidden="true"><?php echo renderVerifiedBadge($iconPath . 'image.svg', true); ?></span>
            <span><?php echo iN_HelpSecure(customLang('admin_upload_logo_dark') ?: 'Upload dark logo', false); ?></span>
          </label>
          <p class="file-picker-status" data-status-for="logo_dark"></p>
          <input id="logo_dark" class="form-input sr-only" type="file" name="logo_dark" accept="image/*" data-status-target="logo_dark">
        </div>

        <div class="form-input-wrapper form-input-wrapper--branding">
          <label class="form-label" for="logo_mobile_white"><?php echo iN_HelpSecure(customLang('admin_logo_mobile_light') ?: 'Mobile Logo (Light)', false); ?></label>
          <?php if ($logoMobileWhite !== ''): ?>
            <div class="logo-preview">
              <img src="<?php echo iN_HelpSecure($base_url . $logoMobileWhite, false); ?>" alt="<?php echo iN_HelpSecure(customLang('admin_logo_mobile_light') ?: 'Mobile Logo (Light)', false); ?>">
            </div>
            <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_current_logo') ?: 'Current file:', false); ?> <?php echo iN_HelpSecure($logoMobileWhite, false); ?></p>
          <?php endif; ?>
          <label class="file-picker" for="logo_mobile_white">
            <span class="file-picker__icon" aria-hidden="true"><?php echo renderVerifiedBadge($iconPath . 'image.svg', true); ?></span>
            <span><?php echo iN_HelpSecure(customLang('admin_upload_logo_mobile_light') ?: 'Upload mobile light logo', false); ?></span>
          </label>
          <p class="file-picker-status" data-status-for="logo_mobile_white"></p>
          <input id="logo_mobile_white" class="form-input sr-only" type="file" name="logo_mobile_white" accept="image/*" data-status-target="logo_mobile_white">
        </div>

        <div class="form-input-wrapper form-input-wrapper--branding">
          <label class="form-label" for="logo_mobile_dark"><?php echo iN_HelpSecure(customLang('admin_logo_mobile_dark') ?: 'Mobile Logo (Dark)', false); ?></label>
          <?php if ($logoMobileDark !== ''): ?>
            <div class="logo-preview logo-preview--dark">
              <img src="<?php echo iN_HelpSecure($base_url . $logoMobileDark, false); ?>" alt="<?php echo iN_HelpSecure(customLang('admin_logo_mobile_dark') ?: 'Mobile Logo (Dark)', false); ?>">
            </div>
            <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_current_logo') ?: 'Current file:', false); ?> <?php echo iN_HelpSecure($logoMobileDark, false); ?></p>
          <?php endif; ?>
          <label class="file-picker" for="logo_mobile_dark">
            <span class="file-picker__icon" aria-hidden="true"><?php echo renderVerifiedBadge($iconPath . 'image.svg', true); ?></span>
            <span><?php echo iN_HelpSecure(customLang('admin_upload_logo_mobile_dark') ?: 'Upload mobile dark logo', false); ?></span>
          </label>
          <p class="file-picker-status" data-status-for="logo_mobile_dark"></p>
          <input id="logo_mobile_dark" class="form-input sr-only" type="file" name="logo_mobile_dark" accept="image/*" data-status-target="logo_mobile_dark">
        </div>
      </div>
      <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_logo_hint') ?: 'Accepted formats: PNG, JPG, WEBP (max 5 MB). We optimise the image automatically during upload.', false); ?></p>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('admin_site_content_rules') ?: 'Content & Monetization', false); ?></legend>
      <div class="form-grid form-grid--quarter">
        <div class="form-input-wrapper">
          <label class="form-label" for="premium_post_price_minimum"><?php echo iN_HelpSecure(customLang('admin_premium_min_price') ?: 'Premium Post Price · Minimum', false); ?></label>
          <input id="premium_post_price_minimum" class="form-input" type="number" name="premium_post_price_minimum" min="0" step="0.01" value="<?php echo iN_HelpSecure($premiumMin, false); ?>">
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_premium_min_price_hint') ?: 'Smallest amount a creator can charge for a paywalled post. Example: 1.00 USD forces every premium post to cost at least $1.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="premium_post_price_maximum"><?php echo iN_HelpSecure(customLang('admin_premium_max_price') ?: 'Premium Post Price · Maximum', false); ?></label>
          <input id="premium_post_price_maximum" class="form-input" type="number" name="premium_post_price_maximum" min="0" step="0.01" value="<?php echo iN_HelpSecure($premiumMax, false); ?>">
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_premium_max_price_hint') ?: 'Largest price creators may set for a premium post. Example: 500.00 keeps one-time unlocks below $500.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="subscription_fee"><?php echo iN_HelpSecure(customLang('admin_subscription_fee') ?: 'Default Subscription Fee (%)', false); ?></label>
          <input id="subscription_fee" class="form-input" type="number" name="subscription_fee" min="0" step="0.01" value="<?php echo iN_HelpSecure($subscriptionFee, false); ?>">
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_subscription_fee_hint') ?: 'Platform share kept from every subscription payment. Example: 5% on a $10 plan sends $0.50 to the platform and $9.50 to the creator.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="payment_fee_percent"><?php echo iN_HelpSecure(customLang('admin_payment_fee_percent') ?: 'Payment Fee (%)', false); ?></label>
          <input id="payment_fee_percent" class="form-input" type="number" name="payment_fee_percent" min="0" max="100" step="0.01" value="<?php echo iN_HelpSecure($paymentFeePercent, false); ?>" placeholder="0.00">
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_payment_fee_percent_hint') ?: 'Percentage added to cover processor costs (tips, post unlocks, subscriptions). Example: 2% on a $20 tip adds $0.40 in platform fees.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="payment_fee_fixed"><?php echo iN_HelpSecure(customLang('admin_payment_fee_fixed') ?: 'Payment Fee (Fixed)', false); ?></label>
          <input id="payment_fee_fixed" class="form-input" type="number" name="payment_fee_fixed" min="0" step="0.01" value="<?php echo iN_HelpSecure($paymentFeeFixed, false); ?>" placeholder="0.00">
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_payment_fee_fixed_hint') ?: 'Flat amount added on top of each checkout. Example: 0.30 mimics Stripe’s fixed $0.30 charge.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="payment_tax_percent"><?php echo iN_HelpSecure(customLang('admin_payment_tax_percent') ?: 'Payment Tax (%)', false); ?></label>
          <input id="payment_tax_percent" class="form-input" type="number" name="payment_tax_percent" min="0" max="100" step="0.01" value="<?php echo iN_HelpSecure($paymentTaxPercent, false); ?>" placeholder="0.00">
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_payment_tax_percent_hint') ?: 'Extra percentage added as tax or regulatory cost. Example: 2% on a $5.99 subscription shows $0.12 tax to the buyer.', false); ?></p>
        </div>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel" data-ffmpeg-section>
      <legend><?php echo iN_HelpSecure(customLang('admin_ffmpeg_section_title') ?: 'FFmpeg & FFprobe', false); ?></legend>
      <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_ffmpeg_section_hint') ?: 'Configure the transcoding binaries used for video processing tasks.', false); ?></p>

      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="ffmpeg_path"><?php echo iN_HelpSecure(customLang('admin_ffmpeg_path_label') ?: 'FFmpeg executable', false); ?></label>
          <input
            id="ffmpeg_path"
            class="form-input"
            type="text"
            name="ffmpeg_path"
            value="<?php echo iN_HelpSecure($ffmpegPathValue, false); ?>"
            placeholder="<?php echo iN_HelpSecure(customLang('admin_ffmpeg_path_placeholder') ?: '/usr/bin/ffmpeg', false); ?>"
            autocomplete="off"
          >
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_ffmpeg_path_hint') ?: 'Enter the absolute path or command name. Leave blank to fall back to the default.', false); ?></p>
          <p class="form-text fs-13 is-hidden" data-ffmpeg-status="ffmpeg"></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="ffprobe_bin"><?php echo iN_HelpSecure(customLang('admin_ffprobe_path_label') ?: 'FFprobe executable', false); ?></label>
          <input
            id="ffprobe_bin"
            class="form-input"
            type="text"
            name="ffprobe_bin"
            value="<?php echo iN_HelpSecure($ffprobePathValue, false); ?>"
            placeholder="<?php echo iN_HelpSecure(customLang('admin_ffprobe_path_placeholder') ?: '/usr/bin/ffprobe', false); ?>"
            autocomplete="off"
          >
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_ffprobe_path_hint') ?: 'Enter the absolute path or command name. Leave blank to fall back to the default.', false); ?></p>
          <p class="form-text fs-13 is-hidden" data-ffmpeg-status="ffprobe"></p>
        </div>
      </div>

      <div class="form-actions flex align_items column-gap">
        <button type="button" class="admin-button admin-button--ghost" data-action="ffmpeg-test"><?php echo iN_HelpSecure(customLang('admin_ffmpeg_test_button') ?: 'Test binaries', false); ?></button>
        <p class="form-text fs-13 is-hidden" data-ffmpeg-status="overall"></p>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('admin_register_settings_title') ?: 'Registration', false); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="register_auto_username"><?php echo iN_HelpSecure(customLang('admin_register_auto_username_label') ?: 'Auto-generate username', false); ?></label>
          <input type="hidden" name="register_auto_username" value="close">
          <label class="el-switch el-switch-sm margin-bottom-zero" aria-label="<?php echo iN_HelpSecure(customLang('admin_register_auto_username_label') ?: 'Auto-generate username', false); ?>">
            <input id="register_auto_username" type="checkbox" name="register_auto_username" value="open" <?php echo $registerAutoUsername === 'open' ? 'checked' : ''; ?>>
            <span class="el-switch-style"></span>
          </label>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_register_auto_username_hint') ?: 'When enabled, empty usernames are generated from the email address.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="register_phone_enabled"><?php echo iN_HelpSecure(customLang('admin_register_phone_enabled_label') ?: 'Phone field on registration', false); ?></label>
          <input type="hidden" name="register_phone_enabled" value="close">
          <label class="el-switch el-switch-sm margin-bottom-zero" aria-label="<?php echo iN_HelpSecure(customLang('admin_register_phone_enabled_label') ?: 'Phone field on registration', false); ?>">
            <input id="register_phone_enabled" type="checkbox" name="register_phone_enabled" value="open" <?php echo $registerPhoneEnabled === 'open' ? 'checked' : ''; ?>>
            <span class="el-switch-style"></span>
          </label>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_register_phone_enabled_hint') ?: 'Toggle the optional phone number fields on the registration form.', false); ?></p>
        </div>
      </div>

      <div class="form-input-wrapper">
        <label class="form-label"><?php echo iN_HelpSecure(customLang('admin_register_dial_codes_label') ?: 'Dial code list', false); ?></label>
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_register_dial_codes_hint') ?: 'One entry per line: Country name | +Code. Leave empty to use the default list.', false); ?></p>
      </div>
      <div class="form-grid form-grid--half">
        <?php foreach ($langOpts as $langCode):
          $dialList = $registerDialCodesByLang[$langCode] ?? '';
          $langCodeSafe = iN_HelpSecure($langCode, false);
          $langLabel = iN_HelpSecure(strtoupper($langCode), false);
        ?>
          <div class="form-input-wrapper">
            <label class="form-label" for="register_phone_dial_codes_<?php echo $langCodeSafe; ?>"><?php echo $langLabel; ?></label>
            <textarea
              id="register_phone_dial_codes_<?php echo $langCodeSafe; ?>"
              class="form-input"
              name="register_phone_dial_codes[<?php echo $langCodeSafe; ?>]"
              rows="6"
              maxlength="5000"
              placeholder="<?php echo iN_HelpSecure(customLang('admin_register_dial_codes_placeholder') ?: "United States | +1\nUnited Kingdom | +44\nTurkey | +90", false); ?>"
            ><?php echo iN_HelpSecure($dialList, false); ?></textarea>
          </div>
        <?php endforeach; ?>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('admin_site_upload_rules') ?: 'Uploads & Limits', false); ?></legend>
      <div class="form-grid form-grid--quarter">
        <div class="form-input-wrapper">
          <label class="form-label" for="image_posts_status"><?php echo iN_HelpSecure(customLang('admin_content_images_label') ?: 'Image posts', false); ?></label>
          <input type="hidden" name="image_posts_status" value="close">
          <label class="el-switch el-switch-sm margin-bottom-zero" aria-label="<?php echo iN_HelpSecure(customLang('admin_content_images_label') ?: 'Image posts', false); ?>">
            <input id="image_posts_status" type="checkbox" name="image_posts_status" value="open" <?php echo $imagePostsStatus === 'open' ? 'checked' : ''; ?>>
            <span class="el-switch-style"></span>
          </label>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_content_images_hint') ?: 'Turn off to hide image upload UI and block new image posts across the site.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="video_posts_status"><?php echo iN_HelpSecure(customLang('admin_content_videos_label') ?: 'Video posts', false); ?></label>
          <input type="hidden" name="video_posts_status" value="close">
          <label class="el-switch el-switch-sm margin-bottom-zero" aria-label="<?php echo iN_HelpSecure(customLang('admin_content_videos_label') ?: 'Video posts', false); ?>">
            <input id="video_posts_status" type="checkbox" name="video_posts_status" value="open" <?php echo $videoPostsStatus === 'open' ? 'checked' : ''; ?>>
            <span class="el-switch-style"></span>
          </label>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_content_videos_hint') ?: 'Disable to hide video posting and reels navigation for everyone.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="post_approval_required"><?php echo iN_HelpSecure(customLang('admin_post_approval_required_label') ?: 'Require approval for posts', false); ?></label>
          <input type="hidden" name="post_approval_required" value="close">
          <label class="el-switch el-switch-sm margin-bottom-zero" aria-label="<?php echo iN_HelpSecure(customLang('admin_post_approval_required_label') ?: 'Require approval for posts', false); ?>">
            <input id="post_approval_required" type="checkbox" name="post_approval_required" value="open" <?php echo $postApprovalRequired === 'open' ? 'checked' : ''; ?>>
            <span class="el-switch-style"></span>
          </label>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_post_approval_required_hint') ?: 'When enabled, new image and video posts stay hidden until an admin approves them.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="ads_status"><?php echo iN_HelpSecure(customLang('admin_content_ads_label') ?: 'Advertisements', false); ?></label>
          <input type="hidden" name="ads_status" value="close">
          <label class="el-switch el-switch-sm margin-bottom-zero" aria-label="<?php echo iN_HelpSecure(customLang('admin_content_ads_label') ?: 'Advertisements', false); ?>">
            <input id="ads_status" type="checkbox" name="ads_status" value="open" <?php echo $adsStatus === 'open' ? 'checked' : ''; ?>>
            <span class="el-switch-style"></span>
          </label>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_content_ads_hint') ?: 'When disabled, users cannot create or view advertisements, and related menu links are hidden.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="suggested_users_status"><?php echo iN_HelpSecure(customLang('admin_suggested_users_label') ?: 'Suggested users', false); ?></label>
          <input type="hidden" name="suggested_users_status" value="close">
          <label class="el-switch el-switch-sm margin-bottom-zero" aria-label="<?php echo iN_HelpSecure(customLang('admin_suggested_users_label') ?: 'Suggested users', false); ?>">
            <input id="suggested_users_status" type="checkbox" name="suggested_users_status" value="open" <?php echo $suggestedUsersStatus === 'open' ? 'checked' : ''; ?>>
            <span class="el-switch-style"></span>
          </label>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_suggested_users_hint') ?: 'Toggle the sidebar block that recommends people to follow.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="suggested_users_limit"><?php echo iN_HelpSecure(customLang('admin_suggested_users_limit_label') ?: 'Suggested users limit', false); ?></label>
          <select
            id="suggested_users_limit"
            class="form-input"
            name="suggested_users_limit"
          >
            <?php for ($i = 1; $i <= 20; $i++): ?>
              <option value="<?php echo $i; ?>" <?php echo (int) $suggestedUsersLimit === $i ? 'selected' : ''; ?>><?php echo $i; ?></option>
            <?php endfor; ?>
          </select>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_suggested_users_limit_hint') ?: 'How many people to show in the sidebar.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="suggested_users_reload"><?php echo iN_HelpSecure(customLang('admin_suggested_users_reload_label') ?: 'Show reload control', false); ?></label>
          <input type="hidden" name="suggested_users_reload" value="close">
          <label class="el-switch el-switch-sm margin-bottom-zero" aria-label="<?php echo iN_HelpSecure(customLang('admin_suggested_users_reload_label') ?: 'Show reload control', false); ?>">
            <input id="suggested_users_reload" type="checkbox" name="suggested_users_reload" value="open" <?php echo $suggestedUsersReload === 'open' ? 'checked' : ''; ?>>
            <span class="el-switch-style"></span>
          </label>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_suggested_users_reload_hint') ?: 'Allow viewers to refresh the list via the reload icon.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="suggested_users_mode"><?php echo iN_HelpSecure(customLang('admin_suggested_users_mode_label') ?: 'Who to suggest', false); ?></label>
          <select id="suggested_users_mode" class="form-input" name="suggested_users_mode">
            <option value="creators" <?php echo $suggestedUsersMode === 'creators' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_suggested_users_mode_creators') ?: 'Creators only', false); ?></option>
            <option value="users" <?php echo $suggestedUsersMode === 'users' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_suggested_users_mode_users') ?: 'Non-creators only', false); ?></option>
            <option value="mixed" <?php echo $suggestedUsersMode === 'mixed' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_suggested_users_mode_mixed') ?: 'Mixed', false); ?></option>
          </select>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_suggested_users_mode_hint') ?: 'Choose whether to promote creators, regular users, or a mix.', false); ?></p>
        </div>
      </div>
      <div class="form-grid form-grid--quarter">
        <div class="form-input-wrapper">
          <label class="form-label" for="available_video_extensions"><?php echo iN_HelpSecure(customLang('admin_video_extensions') ?: 'Allowed Video Extensions', false); ?></label>
          <input id="available_video_extensions" class="form-input" type="text" name="available_video_extensions" value="<?php echo iN_HelpSecure($videoExts, false); ?>" placeholder="mp4,MP4,mp3">
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="available_file_upload_size"><?php echo iN_HelpSecure(customLang('admin_upload_size_mb') ?: 'Max Upload Size (MB)', false); ?></label>
          <input id="available_file_upload_size" class="form-input" type="number" name="available_file_upload_size" min="1" step="1" value="<?php echo iN_HelpSecure($uploadSizeMb, false); ?>">
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="maximum_video_duration"><?php echo iN_HelpSecure(customLang('admin_video_duration') ?: 'Max Video Duration (minutes)', false); ?></label>
          <input id="maximum_video_duration" class="form-input" type="number" name="maximum_video_duration" min="1" step="1" value="<?php echo iN_HelpSecure($maxVideoDuration, false); ?>">
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="maximum_audio_duration"><?php echo iN_HelpSecure(customLang('admin_audio_duration') ?: 'Max Podcast Duration (minutes)', false); ?></label>
          <input id="maximum_audio_duration" class="form-input" type="number" name="maximum_audio_duration" min="1" step="1" value="<?php echo iN_HelpSecure($maxAudioDuration, false); ?>">
        </div>

        <?php
          $lockedPreviewOptions = [
            'off'      => customLang('admin_locked_preview_mode_option_off') ?: 'Disabled',
            'static'   => customLang('admin_locked_preview_mode_option_static') ?: 'Static (pixelated image)',
            'animated' => customLang('admin_locked_preview_mode_option_animated') ?: 'Animated (pixelated loop)',
          ];
        ?>
        <div class="form-input-wrapper">
          <label class="form-label" for="locked_preview_mode_images"><?php echo iN_HelpSecure(customLang('admin_locked_preview_mode_images_label') ?: 'Locked Preview (Images)', false); ?></label>
          <select id="locked_preview_mode_images" class="form-input" name="locked_preview_mode_images">
            <?php foreach ($lockedPreviewOptions as $value => $label):
              $selected = $lockedPreviewModeImages === $value ? 'selected' : '';
            ?>
              <option value="<?php echo iN_HelpSecure($value, false); ?>" <?php echo $selected; ?>><?php echo iN_HelpSecure($label, false); ?></option>
            <?php endforeach; ?>
          </select>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_locked_preview_mode_images_hint') ?: 'Choose what unauthorized viewers see on locked image posts. Static creates a single heavily pixelated frame; animated renders a short loop.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="locked_preview_mode_videos"><?php echo iN_HelpSecure(customLang('admin_locked_preview_mode_videos_label') ?: 'Locked Preview (Videos)', false); ?></label>
          <select id="locked_preview_mode_videos" class="form-input" name="locked_preview_mode_videos">
            <?php foreach ($lockedPreviewOptions as $value => $label):
              $selected = $lockedPreviewModeVideos === $value ? 'selected' : '';
            ?>
              <option value="<?php echo iN_HelpSecure($value, false); ?>" <?php echo $selected; ?>><?php echo iN_HelpSecure($label, false); ?></option>
            <?php endforeach; ?>
          </select>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_locked_preview_mode_videos_hint') ?: 'Select a pixelated teaser for subscriber-only or PPV videos. Static grabs one frame, animated encodes a short loop.', false); ?></p>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="message_scroll_limit"><?php echo iN_HelpSecure(customLang('admin_message_scroll_limit') ?: 'Message Scroll Batch', false); ?></label>
          <input id="message_scroll_limit" class="form-input" type="number" name="message_scroll_limit" min="1" max="100" step="1" value="<?php echo iN_HelpSecure($messageScroll, false); ?>">
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="page_scroll_limit"><?php echo iN_HelpSecure(customLang('admin_page_scroll_limit') ?: 'Page Scroll Batch', false); ?></label>
          <input id="page_scroll_limit" class="form-input" type="number" name="page_scroll_limit" min="1" max="100" step="1" value="<?php echo iN_HelpSecure($pageScroll, false); ?>">
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="podcast_posts_status"><?php echo iN_HelpSecure(customLang('admin_content_podcasts_label') ?: 'Podcast posts', false); ?></label>
          <select id="podcast_posts_status" class="form-input" name="podcast_posts_status">
            <option value="open" <?php echo $podcastPostsStatus === 'open' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_toggle_enable') ?: 'Enable', false); ?></option>
            <option value="close" <?php echo $podcastPostsStatus === 'close' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_toggle_disable', 'Disable'), false); ?></option>
          </select>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_content_podcasts_hint') ?: 'Turn off to hide podcast upload UI and block new podcast posts across the site.', false); ?></p>
        </div>
      </div>
    </fieldset>

    <div class="form-input-wrapper form-input-wrapper--actions">
      <button type="submit" class="pe-save btn-hover"><?php echo iN_HelpSecure(customLang('admin_save_changes') ?: 'Save Changes', false); ?></button>
    </div>
  </form>
</section>
