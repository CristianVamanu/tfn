<?php

declare(strict_types=1);

if (!function_exists('admin_storage_settings')) {
    function admin_storage_settings(array $siteData): array
    {
        $raw = $siteData['storage_settings'] ?? null;
        $settings = [];
        if (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                $settings = $decoded;
            }
        }
        if (!isset($settings['providers']) || !is_array($settings['providers'])) {
            $settings['providers'] = [];
        }
        if (!isset($settings['driver']) || !is_string($settings['driver'])) {
            $settings['driver'] = 'local';
        }

        return $settings;
    }
}

if (!function_exists('admin_storage_provider')) {
    function admin_storage_provider(array $storageSettings, string $provider): array
    {
        $providers = $storageSettings['providers'] ?? [];
        $config = $providers[$provider] ?? [];
        if (!is_array($config)) {
            $config = [];
        }

        return $config;
    }
}

if (!function_exists('admin_storage_bool')) {
    function admin_storage_bool($value, bool $default = false): bool
    {
        if ($value === null) {
            return $default;
        }

        if (is_bool($value)) {
            return $value;
        }

        $normalized = strtolower(trim((string) $value));
        if ($normalized === '') {
            return $default;
        }

        if (in_array($normalized, ['0', 'false', 'off', 'no', 'closed', 'close'], true)) {
            return false;
        }

        if (in_array($normalized, ['1', 'true', 'yes', 'on', 'enabled', 'open'], true)) {
            return true;
        }

        return $default;
    }
}

if (!function_exists('admin_storage_visibility')) {
    function admin_storage_visibility($value, string $default = 'public'): string
    {
        $candidate = strtolower(trim((string) ($value ?? '')));
        if ($candidate === 'public' || $candidate === 'private') {
            return $candidate;
        }

        return $default === 'private' ? 'private' : 'public';
    }
}

if (!function_exists('admin_storage_mask_secret')) {
    function admin_storage_mask_secret(?string $value): string
    {
        $value = (string) $value;
        if ($value === '') {
            return '';
        }
        $len = strlen($value);
        $tail = $len >= 4 ? substr($value, -4) : $value;
        return '••••' . htmlspecialchars($tail, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('admin_storage_sync_mode')) {
    function admin_storage_sync_mode(array $providerConfig, string $default = 'manual'): string
    {
        $mode = strtolower(trim((string) ($providerConfig['sync_mode'] ?? $default)));
        return in_array($mode, ['manual', 'background'], true) ? $mode : $default;
    }
}
