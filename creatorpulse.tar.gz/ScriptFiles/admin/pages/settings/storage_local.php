<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';
require_once __DIR__ . '/storage_helpers.php';

global $siteData, $base_url, $ADMIN_CSRF;

$storageSettings = admin_storage_settings($siteData);
$localConfig = admin_storage_provider($storageSettings, 'local');

$enabled = admin_storage_bool($localConfig['enabled'] ?? true, true);
$isDefault = ($storageSettings['driver'] ?? 'local') === 'local';
$visibility = admin_storage_visibility($localConfig['default_visibility'] ?? 'public', 'public');
$publicBase = (string) ($localConfig['public_base_url'] ?? rtrim((string) $base_url, '/') . '/');
$rootPath = (string) ($localConfig['root_path'] ?? (
    isset($GLOBALS['uploadFile']) ? dirname((string) $GLOBALS['uploadFile']) : dirname(__DIR__, 4) . '/uploads'
));
$actionUrl = iN_HelpSecure($base_url . 'admin/request/storage_settings.php', false);
$csrfToken = iN_HelpSecure($ADMIN_CSRF, false);
$defaultVisibilityPublic = $visibility === 'public';
$defaultVisibilityPrivate = $visibility === 'private';
?>

<section class="card rounded-2xl admin-settings" role="region" aria-labelledby="adminStorageLocalHeading">
  <h1 id="adminStorageLocalHeading"><?php echo iN_HelpSecure(customLang('storage_heading_local') ?: 'Storage · Local Filesystem'); ?></h1>
  <p class="box-note full-width"><?php echo iN_HelpSecure(customLang('storage_intro_local') ?: 'Configure the local uploads directory and default visibility.'); ?></p>

  <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="storage-settings" data-storage-provider="local">
    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
    <input type="hidden" name="provider" value="local">
    <input type="hidden" name="action" value="save">

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('storage_section_status') ?: 'Provider Status'); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="local_enable_provider"><?php echo iN_HelpSecure(customLang('storage_toggle_enable') ?: 'Enable provider'); ?></label>
          <div class="flex align_items column-gap">
            <input type="hidden" name="enable_provider" value="0">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_toggle_enable') ?: 'Enable provider'); ?>">
              <input id="local_enable_provider" type="checkbox" name="enable_provider" value="1" <?php echo $enabled ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_toggle_enable_hint_local') ?: 'Keep this enabled to continue storing uploads on the local filesystem.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="local_set_default"><?php echo iN_HelpSecure(customLang('storage_toggle_default') ?: 'Set as default storage'); ?></label>
          <div class="flex align_items column-gap">
            <input type="hidden" name="set_default" value="0">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_toggle_default') ?: 'Set as default storage'); ?>">
              <input id="local_set_default" type="checkbox" name="set_default" value="1" <?php echo $isDefault ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_toggle_default_hint_local') ?: 'The default provider handles new uploads.'); ?></small>
        </div>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('storage_section_local_paths') ?: 'Local Paths'); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="local_root_path"><?php echo iN_HelpSecure(customLang('storage_field_root_path') ?: 'Uploads root path'); ?></label>
          <input id="local_root_path" class="form-input" type="text" name="root_path" value="<?php echo iN_HelpSecure($rootPath, false); ?>" readonly>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_root_path_hint') ?: 'Derived from your current uploads directory.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="local_public_base"><?php echo iN_HelpSecure(customLang('storage_field_public_base_url') ?: 'Base URL / CDN'); ?></label>
          <input id="local_public_base" class="form-input" type="url" name="public_base_url" value="<?php echo iN_HelpSecure($publicBase, false); ?>" placeholder="https://example.com/uploads/">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_public_base_url_hint') ?: 'Optional. Overrides the default base URL for serving media.'); ?></small>
        </div>
      </div>

      <div class="form-input-wrapper">
        <label class="form-label" for="local_visibility"><?php echo iN_HelpSecure(customLang('storage_field_visibility') ?: 'Default visibility'); ?></label>
        <select id="local_visibility" class="form-input" name="default_visibility">
          <option value="public" <?php echo $defaultVisibilityPublic ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('storage_visibility_public') ?: 'Public'); ?></option>
          <option value="private" <?php echo $defaultVisibilityPrivate ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('storage_visibility_private') ?: 'Private'); ?></option>
        </select>
        <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_visibility_hint_local') ?: 'Private assets require signed URLs.'); ?></small>
      </div>
    </fieldset>

    <div class="form-actions flex align_items column-gap">
      <button type="submit" class="admin-button admin-button--primary" data-role="storage-save">
        <?php echo iN_HelpSecure(customLang('storage_button_save') ?: 'Save changes'); ?>
      </button>
      <button type="button" class="admin-button admin-button--ghost" data-action="storage-test" data-storage-provider="local">
        <?php echo iN_HelpSecure(customLang('storage_button_test') ?: 'Test connection'); ?>
      </button>
    </div>
  </form>
</section>
