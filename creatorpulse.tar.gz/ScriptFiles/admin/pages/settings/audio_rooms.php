<?php
declare(strict_types=1);
require_once __DIR__ . '/../../_bootstrap.php';

global $siteData, $base_url, $ADMIN_CSRF, $ADM, $currency, $currencies, $currencyFormatSettings;

$boolConfig = static function ($value, bool $default = true): bool {
    if ($value === null) {
        return $default;
    }
    return in_array(strtolower(trim((string)$value)), ['1', 'true', 'yes', 'on', 'enabled'], true);
};

$audioRoomsEnabled = $boolConfig($siteData['audio_rooms_enabled'] ?? null, true);
$chatEnabled = $boolConfig($siteData['audio_room_chat_enabled'] ?? null, true);
$paidEnabled = $boolConfig($siteData['audio_room_paid_enabled'] ?? null, true);
$customPriceEnabled = $boolConfig($siteData['audio_room_custom_price_enabled'] ?? null, true);
$pricePresets = (string)($siteData['audio_room_price_presets'] ?? '5,10,15,20');
$minimumPrice = number_format(max(0, (float)($siteData['audio_room_price_minimum'] ?? 1)), 2, '.', '');
$maximumPrice = number_format(max(0, (float)($siteData['audio_room_price_maximum'] ?? 500)), 2, '.', '');
$dailyMinutes = max(0, (int)($siteData['audio_room_non_creator_daily_minutes'] ?? 60));
$maxSpeakers = max(1, (int)($siteData['audio_room_max_speakers'] ?? 12));
$maxListeners = max(0, (int)($siteData['audio_room_max_listeners'] ?? 0));
$titlePrefix = (string)($siteData['audio_room_title_prefix'] ?? '');
$agoraAppId = trim((string)($siteData['agora_app_id'] ?? ''));
$agoraCertificate = trim((string)($siteData['agora_app_certificate'] ?? ''));
$agoraReady = preg_match('/^[0-9a-f]{32}$/i', $agoraAppId) === 1
    && preg_match('/^[0-9a-f]{32}$/i', $agoraCertificate) === 1
    && strcasecmp($agoraAppId, $agoraCertificate) !== 0;
$maskedAppId = $agoraAppId !== '' && strlen($agoraAppId) >= 12
    ? substr($agoraAppId, 0, 6) . str_repeat('*', 20) . substr($agoraAppId, -6)
    : '';
$overview = isset($ADM) && method_exists($ADM, 'ADM_AudioRoomOverview')
    ? (array)$ADM->ADM_AudioRoomOverview()
    : [];
$currencyCode = strtoupper((string)($currency ?? $siteData['default_currency'] ?? 'USD'));
$currenciesMap = isset($currencies) && is_array($currencies) ? $currencies : [];
$currencySymbol = trim((string)($currenciesMap[$currencyCode] ?? ''));
if ($currencySymbol === '') {
    $currencySymbol = $currencyCode;
}
$resolvedCurrencyFormat = function_exists('dz_currency_normalize_settings')
    ? dz_currency_normalize_settings(is_array($currencyFormatSettings ?? null) ? $currencyFormatSettings : [])
    : (is_array($currencyFormatSettings ?? null) ? $currencyFormatSettings : []);
$formatMoney = static function (float $amount) use ($currencyCode, $currencySymbol, $resolvedCurrencyFormat): string {
    return function_exists('dz_format_currency')
        ? dz_format_currency($amount, $currencyCode, $currencySymbol, $resolvedCurrencyFormat)
        : number_format($amount, 2);
};
$grossRevenue = (float)($overview['ticket_gross'] ?? 0) + (float)($overview['tip_gross'] ?? 0);
$actionUrl = iN_HelpSecure($base_url . 'admin/request/audio_room_settings.php', false);
$csrfToken = iN_HelpSecure($ADMIN_CSRF, false);
$pageTitle = customLang('admin_audio_room_settings_title') ?: 'Audio Room Settings';
$pageIntro = customLang('admin_audio_room_settings_intro') ?: 'Control room availability, paid access, capacity and community defaults from one place.';
?>
<div class="admin-audio-settings-page" data-page-title="<?php echo iN_HelpSecure($pageTitle, false); ?>">
  <section class="card rounded-2xl admin-audio-settings-shell" role="region" aria-labelledby="adminAudioSettingsHeading">
    <header class="admin-audio-settings-header">
      <span class="admin-audio-settings-header__icon"><?php echo render_icon('podcast', true); ?></span>
      <div>
        <h1 id="adminAudioSettingsHeading"><?php echo iN_HelpSecure($pageTitle, false); ?></h1>
        <p><?php echo iN_HelpSecure($pageIntro, false); ?></p>
      </div>
      <div class="admin-audio-settings-header__actions">
        <a class="admin-button admin-button--soft" href="<?php echo iN_HelpSecure($base_url . 'admin/index.php?page=audio_rooms', false); ?>"><?php echo iN_HelpSecure(customLang('admin_audio_rooms_manage') ?: 'Manage rooms', false); ?></a>
        <a class="admin-button admin-button--neutral" href="<?php echo iN_HelpSecure($base_url . 'audio-rooms', false); ?>" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('admin_audio_rooms_open') ?: 'Open Audio Rooms', false); ?></a>
      </div>
    </header>

    <div class="admin-audio-settings-kpis" aria-label="<?php echo iN_HelpSecure(customLang('admin_audio_room_overview') ?: 'Audio Room overview', false); ?>">
      <div><span><?php echo render_icon('podcast', true); ?></span><strong><?php echo (int)($overview['total_rooms'] ?? 0); ?></strong><small><?php echo iN_HelpSecure(customLang('admin_audio_rooms_total') ?: 'Total rooms', false); ?></small></div>
      <div><span><?php echo render_icon('speaker', true); ?></span><strong><?php echo (int)($overview['live_rooms'] ?? 0); ?></strong><small><?php echo iN_HelpSecure(customLang('admin_audio_rooms_live') ?: 'Live now', false); ?></small></div>
      <div><span><?php echo render_icon('payments', true); ?></span><strong><?php echo iN_HelpSecure($formatMoney($grossRevenue), false); ?></strong><small><?php echo iN_HelpSecure(customLang('admin_audio_rooms_gross') ?: 'Gross revenue', false); ?></small></div>
      <div><span><?php echo render_icon('wallet', true); ?></span><strong><?php echo iN_HelpSecure($formatMoney((float)($overview['platform_revenue'] ?? 0)), false); ?></strong><small><?php echo iN_HelpSecure(customLang('admin_audio_rooms_platform') ?: 'Platform revenue', false); ?></small></div>
    </div>

    <form class="admin-audio-settings-form" method="post" action="<?php echo $actionUrl; ?>" data-action="save-live-settings">
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

      <section class="admin-audio-settings-panel" aria-labelledby="audioFeaturesHeading">
        <div class="admin-audio-settings-panel__head">
          <div><h2 id="audioFeaturesHeading"><?php echo iN_HelpSecure(customLang('admin_audio_room_features') ?: 'Features and access', false); ?></h2><p><?php echo iN_HelpSecure(customLang('admin_audio_room_features_hint') ?: 'Choose which room capabilities are available to creators and listeners.', false); ?></p></div>
        </div>
        <div class="admin-audio-toggle-grid">
          <?php
          $toggles = [
              ['audio_rooms_enabled', $audioRoomsEnabled, customLang('admin_audio_rooms_enabled') ?: 'Enable audio rooms', customLang('admin_audio_rooms_enabled_hint') ?: 'Shows Audio Rooms entry points and allows users to join eligible rooms.'],
              ['audio_room_chat_enabled', $chatEnabled, customLang('admin_audio_room_chat_enabled') ?: 'Enable room chat', customLang('admin_audio_room_chat_hint') ?: 'Allows participants to exchange text messages inside rooms.'],
              ['audio_room_paid_enabled', $paidEnabled, customLang('admin_audio_room_paid_enabled') ?: 'Allow paid creator rooms', customLang('admin_audio_room_paid_hint') ?: 'Approved creators may charge an entry price.'],
              ['audio_room_custom_price_enabled', $customPriceEnabled, customLang('admin_audio_room_custom_price') ?: 'Allow custom creator prices', customLang('admin_audio_room_custom_price_hint') ?: 'When disabled, creators must choose an approved preset.'],
          ];
          foreach ($toggles as [$name, $checked, $label, $hint]): ?>
            <div class="admin-audio-toggle-card">
              <div><label for="<?php echo $name; ?>"><?php echo iN_HelpSecure($label, false); ?></label><p><?php echo iN_HelpSecure($hint, false); ?></p></div>
              <label class="el-switch el-switch-sm margin-bottom-zero" aria-label="<?php echo iN_HelpSecure($label, false); ?>">
                <input type="hidden" name="<?php echo $name; ?>" value="0">
                <input type="checkbox" id="<?php echo $name; ?>" name="<?php echo $name; ?>" value="1" <?php echo $checked ? 'checked' : ''; ?>>
                <span class="el-switch-style"></span>
              </label>
            </div>
          <?php endforeach; ?>
        </div>
      </section>

      <section class="admin-audio-settings-panel" aria-labelledby="audioPricingHeading">
        <div class="admin-audio-settings-panel__head">
          <div><h2 id="audioPricingHeading"><?php echo iN_HelpSecure(customLang('admin_audio_room_pricing') ?: 'Pricing rules', false); ?></h2><p><?php echo iN_HelpSecure(customLang('admin_audio_room_pricing_hint') ?: 'Amounts use the site currency and the global payment fee and tax configuration.', false); ?></p></div>
          <span class="admin-audio-currency-note" title="<?php echo iN_HelpSecure($currencyCode, false); ?>"><?php echo iN_HelpSecure($currencySymbol, false); ?></span>
        </div>
        <div class="admin-audio-fields-grid">
          <label><span><?php echo iN_HelpSecure(customLang('admin_audio_room_price_presets') ?: 'Price presets', false); ?></span><input id="audio_room_price_presets" type="text" name="audio_room_price_presets" maxlength="191" value="<?php echo iN_HelpSecure($pricePresets, false); ?>" placeholder="5,10,15,20"><small><?php echo iN_HelpSecure(customLang('admin_audio_room_price_presets_hint') ?: 'Comma-separated positive amounts.', false); ?></small></label>
          <label><span><?php echo iN_HelpSecure(customLang('admin_audio_room_min_price') ?: 'Minimum paid entry', false); ?></span><input id="audio_room_price_minimum" type="number" name="audio_room_price_minimum" min="0" max="100000" step="0.01" value="<?php echo $minimumPrice; ?>"></label>
          <label><span><?php echo iN_HelpSecure(customLang('admin_audio_room_max_price') ?: 'Maximum paid entry', false); ?></span><input id="audio_room_price_maximum" type="number" name="audio_room_price_maximum" min="0" max="100000" step="0.01" value="<?php echo $maximumPrice; ?>"></label>
        </div>
      </section>

      <section class="admin-audio-settings-panel" aria-labelledby="audioLimitsHeading">
        <div class="admin-audio-settings-panel__head"><div><h2 id="audioLimitsHeading"><?php echo iN_HelpSecure(customLang('admin_audio_room_limits') ?: 'Duration and capacity', false); ?></h2><p><?php echo iN_HelpSecure(customLang('admin_audio_room_limits_hint') ?: 'Protect room quality by setting daily usage and attendance limits.', false); ?></p></div></div>
        <div class="admin-audio-fields-grid">
          <label><span><?php echo iN_HelpSecure(customLang('admin_audio_room_daily_limit') ?: 'Non-creator daily minutes', false); ?></span><input id="audio_room_non_creator_daily_minutes" type="number" name="audio_room_non_creator_daily_minutes" min="0" max="1440" step="1" value="<?php echo $dailyMinutes; ?>"><small><?php echo iN_HelpSecure(customLang('admin_audio_room_zero_unlimited') ?: '0 means unlimited.', false); ?></small></label>
          <label><span><?php echo iN_HelpSecure(customLang('admin_audio_room_max_speakers') ?: 'Maximum speakers', false); ?></span><input id="audio_room_max_speakers" type="number" name="audio_room_max_speakers" min="1" max="100" step="1" value="<?php echo $maxSpeakers; ?>"></label>
          <label><span><?php echo iN_HelpSecure(customLang('admin_audio_room_max_listeners') ?: 'Maximum listeners', false); ?></span><input id="audio_room_max_listeners" type="number" name="audio_room_max_listeners" min="0" max="500000" step="1" value="<?php echo $maxListeners; ?>"><small><?php echo iN_HelpSecure(customLang('admin_audio_room_zero_unlimited') ?: '0 means unlimited.', false); ?></small></label>
          <label class="admin-audio-field--wide"><span><?php echo iN_HelpSecure(customLang('admin_audio_room_title_prefix') ?: 'Default title prefix', false); ?></span><input id="audio_room_title_prefix" type="text" name="audio_room_title_prefix" maxlength="180" value="<?php echo iN_HelpSecure($titlePrefix, false); ?>" placeholder="<?php echo iN_HelpSecure(customLang('admin_audio_room_title_prefix_placeholder') ?: 'Example: Room with', false); ?>"></label>
        </div>
      </section>

      <section class="admin-audio-settings-panel admin-audio-agora-panel" aria-labelledby="audioAgoraHeading">
        <div class="admin-audio-settings-panel__head"><div><h2 id="audioAgoraHeading"><?php echo iN_HelpSecure(customLang('admin_audio_room_agora_readiness') ?: 'Agora readiness', false); ?></h2><p><?php echo iN_HelpSecure(customLang('admin_audio_room_agora_hint') ?: 'Audio Rooms reuse the protected Agora credentials configured in Live Settings.', false); ?></p></div><span class="admin-audio-readiness <?php echo $agoraReady ? 'is-ready' : 'is-missing'; ?>"><?php echo iN_HelpSecure($agoraReady ? (customLang('admin_audio_room_agora_ready') ?: 'Ready') : (customLang('admin_audio_room_agora_missing') ?: 'Configuration required'), false); ?></span></div>
        <div class="admin-audio-agora-row"><code><?php echo iN_HelpSecure($maskedAppId !== '' ? $maskedAppId : (customLang('admin_not_configured') ?: 'Not configured'), false); ?></code><a class="admin-button admin-button--soft" href="<?php echo iN_HelpSecure($base_url . 'admin/index.php?page=settings_live', false); ?>"><?php echo iN_HelpSecure(customLang('admin_audio_room_manage_agora') ?: 'Manage Agora credentials', false); ?></a></div>
      </section>

      <div class="admin-audio-settings-actions"><button type="submit" class="admin-button admin-button--primary"><?php echo iN_HelpSecure(customLang('admin_save_changes') ?: 'Save changes', false); ?></button></div>
    </form>
  </section>
</div>
