<?php
declare(strict_types=1);
require_once __DIR__ . '/../../_bootstrap.php';

global $base_url, $ADMIN_CSRF, $RL, $currency, $currencies, $currencyFormatSettings;

$themeSlug = 'welcome_default';
if (isset($RL) && method_exists($RL, 'RL_GetActiveLandingTheme')) {
    try {
        $activeTheme = $RL->RL_GetActiveLandingTheme();
        if (is_string($activeTheme) && $activeTheme !== '') {
            $themeSlug = $activeTheme;
        }
    } catch (Throwable $e) {
        // fall back to default
    }
}

$landingLogFile = dirname(__DIR__, 3) . '/includes/functions_error.txt';
$landingLogger = static function (string $message) use ($landingLogFile): void {
    $line = '[' . date('c') . '] landing.php · ' . $message . PHP_EOL;
    if ($landingLogFile && is_string($landingLogFile)) {
        @file_put_contents($landingLogFile, $line, FILE_APPEND | LOCK_EX);
    }
};
$landingLogger('init start');

$themes = [];
$landingThemeLabels = [
    'welcome_default' => customLang('admin_landing_theme_label_welcome') ?: 'Welcome landing page',
    'guest_main' => customLang('admin_landing_theme_label_guest') ?: 'Guest feed experience',
];
$imageListDefaults = [
    'media_mode' => 'mixed',
    'target' => 'profile',
    'show_views' => true,
    'show_likes' => true,
];
$imageListConfig = $imageListDefaults;
$imageListItems = [];
$mediaModeVal = 'mixed';
$targetVal = 'profile';
$showViewsVal = true;
$showLikesVal = true;

$marqueeDefaults = [
    'list_count' => 4,
    'show_avatar' => true,
    'name_mode' => 'full',
];
$marqueeConfig = $marqueeDefaults;
$listCountVal = (int) $marqueeDefaults['list_count'];
$showAvatarVal = !empty($marqueeDefaults['show_avatar']);
$nameModeVal = $marqueeDefaults['name_mode'];
$marqueeItemsRaw = [];
$marqueeRows = [
    'item_1' => ['id' => 0, 'display' => '', 'username' => '', 'avatar' => '', 'verified' => false],
];
$earningsSimulatorDefaults = [
    'default_followers' => 1000,
    'default_price' => 10.0,
    'conversion_rate' => 0.2,
];
$earningsSimulatorConfig = $earningsSimulatorDefaults;
$earningsSimulatorFollowers = (int) $earningsSimulatorDefaults['default_followers'];
$earningsSimulatorPrice = (float) $earningsSimulatorDefaults['default_price'];
$earningsSimulatorConversionRate = (float) $earningsSimulatorDefaults['conversion_rate'];
$earningsSimulatorConversionPercent = $earningsSimulatorConversionRate * 100.0;

try {
    if (isset($RL)) {
        $themes = $RL->RL_ListLandingThemes();
    }
    if (!$themes) {
        $themes = [
            [
                'theme' => 'welcome_default',
                'is_active' => 1,
                'updated_at' => time(),
            ],
        ];
    }
    usort($themes, static function (array $a, array $b): int {
        $aActive = (int) ($a['is_active'] ?? 0);
        $bActive = (int) ($b['is_active'] ?? 0);
        if ($aActive !== $bActive) {
            return $bActive <=> $aActive;
        }
        return strcmp((string) ($a['theme'] ?? ''), (string) ($b['theme'] ?? ''));
    });

    $imageListConfig = $imageListDefaults;
    if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionConfig') && method_exists($RL, 'RL_GetLandingImageList')) {
        $fetchedConfig = $RL->RL_GetLandingSectionConfig($themeSlug, 'image_list');
        if (is_array($fetchedConfig)) {
            $imageListConfig = array_replace($imageListDefaults, array_intersect_key($fetchedConfig, $imageListDefaults));
        }
        $imageListItems = $RL->RL_GetLandingImageList($themeSlug, $imageListConfig, 8);
    }
    $mediaModeVal = (string) ($imageListConfig['media_mode'] ?? 'mixed');
    if (!in_array($mediaModeVal, ['mixed', 'image', 'video'], true)) { $mediaModeVal = 'mixed'; }
    $targetVal = (string) ($imageListConfig['target'] ?? 'profile');
    if (!in_array($targetVal, ['profile', 'post'], true)) { $targetVal = 'profile'; }
    $showViewsVal = !empty($imageListConfig['show_views']);
    $showLikesVal = !empty($imageListConfig['show_likes']);

    $marqueeConfig = $marqueeDefaults;
    if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionConfig')) {
        $fetchedMarquee = $RL->RL_GetLandingSectionConfig($themeSlug, 'marquee');
        if (is_array($fetchedMarquee)) {
            $marqueeConfig = array_replace($marqueeDefaults, array_intersect_key($fetchedMarquee, $marqueeDefaults));
        }
        $fetchedEarnings = $RL->RL_GetLandingSectionConfig($themeSlug, 'earnings_simulator');
        if (is_array($fetchedEarnings)) {
            $earningsSimulatorConfig = array_replace($earningsSimulatorDefaults, array_intersect_key($fetchedEarnings, $earningsSimulatorDefaults));
        }
    }
    $listCountVal = max(1, min((int) ($marqueeConfig['list_count'] ?? 4), 10));
    $showAvatarVal = !empty($marqueeConfig['show_avatar']);
    $nameModeVal = $marqueeConfig['name_mode'] ?? 'full';
    if (!in_array($nameModeVal, ['full', 'username'], true)) { $nameModeVal = 'full'; }

    if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionItems')) {
        $marqueeItemsRaw = $RL->RL_GetLandingSectionItems($themeSlug, 'marquee', 200);
    }
    $marqueeRows = [];
    $rowIndex = 0;
    foreach ($marqueeItemsRaw as $row) {
        $meta = isset($row['meta']) && is_array($row['meta']) ? $row['meta'] : [];
        $key = 'item_' . (++$rowIndex);
        $marqueeRows[$key] = [
            'id' => (int) ($row['id'] ?? 0),
            'display' => (string) ($meta['display'] ?? ''),
            'username' => (string) ($meta['username'] ?? ''),
            'avatar' => (string) ($meta['avatar'] ?? ''),
            'verified' => !empty($meta['verified']),
        ];
    }
    if (!$marqueeRows) {
        $marqueeRows['item_1'] = ['id' => 0, 'display' => '', 'username' => '', 'avatar' => '', 'verified' => false];
    }
} catch (Throwable $e) {
    $landingLogger('init error: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
}
$earningsSimulatorFollowers = max(0, min((int) ($earningsSimulatorConfig['default_followers'] ?? 1000), 1000000));
$earningsSimulatorPrice = (float) ($earningsSimulatorConfig['default_price'] ?? 10.0);
if (!is_finite($earningsSimulatorPrice)) {
    $earningsSimulatorPrice = 10.0;
}
$earningsSimulatorPrice = round($earningsSimulatorPrice, 2);
if ($earningsSimulatorPrice < 1.0) {
    $earningsSimulatorPrice = 1.0;
}
if ($earningsSimulatorPrice > 1000.0) {
    $earningsSimulatorPrice = 1000.0;
}
$earningsSimulatorConversionRate = (float) ($earningsSimulatorConfig['conversion_rate'] ?? 0.2);
if (!is_finite($earningsSimulatorConversionRate)) {
    $earningsSimulatorConversionRate = 0.2;
}
if ($earningsSimulatorConversionRate < 0.0) {
    $earningsSimulatorConversionRate = 0.0;
}
if ($earningsSimulatorConversionRate > 1.0) {
    $earningsSimulatorConversionRate = 1.0;
}
$earningsSimulatorConversionPercent = round($earningsSimulatorConversionRate * 100.0, 2);
$earningsSimulatorConfig = [
    'default_followers' => $earningsSimulatorFollowers,
    'default_price' => $earningsSimulatorPrice,
    'conversion_rate' => $earningsSimulatorConversionRate,
];
$landingLogger('init complete');

$actionUrl = iN_HelpSecure($base_url . 'admin/request/landing_settings.php', false);
$csrfToken = iN_HelpSecure($ADMIN_CSRF, false);

$currenciesMap = isset($currencies) && is_array($currencies) ? $currencies : [];
$currencyFormatSettings = $currencyFormatSettings ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
$currencyCode = isset($currency) && $currency !== '' ? strtoupper((string) $currency) : 'USD';
$currencyPrecision = dz_currency_resolve_precision($currencyCode, (int) ($currencyFormatSettings['decimal_places'] ?? 2));
$formatNumberForInput = static function (float $value, int $precision) use ($currencyFormatSettings, $currencyCode): string {
    $settings = $currencyFormatSettings;
    $settings['decimal_places'] = $precision;
    $settings['decimal_sep'] = '.';
    $settings['thousands_sep'] = '';

    return dz_format_number($value, $currencyCode, $settings);
};

// Discover available languages from langs directory
$langDir = dirname(__DIR__, 3) . '/langs';
$langOptions = [];
if (is_dir($langDir)) {
    foreach (scandir($langDir) as $entry) {
        if (preg_match('/^(\\w+)\\.php$/', $entry, $m)) {
            $langOptions[] = $m[1];
        }
    }
}
sort($langOptions);
if (!$langOptions) {
    $langOptions = ['eng'];
}

$heroKeys = ['hero_title', 'hero_description', 'hero_start_button'];
$heroOverrides = isset($RL) ? $RL->RL_GetLangOverrides($heroKeys, $langOptions) : [];

$featureTextKeys = ['features_title_why_choose', 'features_subtitle_publish_protect'];
$featureTextOverrides = isset($RL) ? $RL->RL_GetLangOverrides($featureTextKeys, $langOptions) : [];

$sampleTextKeys = ['features_tags_title', 'features_tags_subtitle'];
$sampleTextOverrides = isset($RL) ? $RL->RL_GetLangOverrides($sampleTextKeys, $langOptions) : [];

$pricingTextKeys = ['pricing_section_title', 'pricing_section_description', 'pricing_note'];
$pricingTextOverrides = isset($RL) ? $RL->RL_GetLangOverrides($pricingTextKeys, $langOptions) : [];

$rawTranslations = [];
foreach ($langOptions as $code) {
    $file = $langDir . '/' . $code . '.php';
    $rawTranslations[$code] = is_file($file) ? include $file : [];
    if (!is_array($rawTranslations[$code])) {
        $rawTranslations[$code] = [];
    }
}

if (!function_exists('adminLandingFieldValue')) {
    function adminLandingFieldValue(array $overrides, string $lang, string $key): string
    {
        if (isset($overrides[$lang][$key])) {
            return (string) $overrides[$lang][$key];
        }
        return '';
    }
}

if (!function_exists('adminLandingDefaultValue')) {
    function adminLandingDefaultValue(array $rawTranslations, string $lang, string $key): string
    {
        return isset($rawTranslations[$lang][$key]) ? (string) $rawTranslations[$lang][$key] : '';
    }
}

if (!function_exists('landingAdminStorageLangKey')) {
    function landingAdminStorageLangKey(string $langCode): string
    {
        $langCode = strtolower(trim($langCode));
        $map = [
            'eng' => 'en',
            'en' => 'en',
            'english' => 'en',
            'tr' => 'tr',
            'tur' => 'tr',
            'trk' => 'tr',
            'turkish' => 'tr',
        ];
        if (isset($map[$langCode])) {
            return $map[$langCode];
        }
        if (strlen($langCode) >= 2) {
            return substr($langCode, 0, 2);
        }
        return $langCode;
    }
}

if (!function_exists('landingAdminExtractGetStarted')) {
    function landingAdminExtractGetStarted(array $langData, array $langOptions): array
    {
        $out = [];
        foreach ($langOptions as $langCode) {
            $key = landingAdminStorageLangKey($langCode);
            $payload = isset($langData[$key]) && is_array($langData[$key]) ? $langData[$key] : [];
            $out[$langCode] = [
                'title' => isset($payload['title']) ? (string) $payload['title'] : '',
                'desc' => isset($payload['desc']) ? (string) $payload['desc'] : '',
                'button' => isset($payload['button']) ? (string) $payload['button'] : '',
            ];
        }
        return $out;
    }
}

$imageListDefaults = [
    'media_mode' => 'mixed',
    'target' => 'profile',
    'show_views' => true,
    'show_likes' => true,
];
$imageListConfig = $imageListDefaults;
if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionConfig')) {
    $fetchedConfig = $RL->RL_GetLandingSectionConfig($themeSlug, 'image_list');
    if (is_array($fetchedConfig)) {
        $imageListConfig = array_replace($imageListDefaults, array_intersect_key($fetchedConfig, $imageListDefaults));
    }
}
$mediaModeVal = (string) ($imageListConfig['media_mode'] ?? 'mixed');
if (!in_array($mediaModeVal, ['mixed', 'image', 'video'], true)) { $mediaModeVal = 'mixed'; }
$targetVal = (string) ($imageListConfig['target'] ?? 'profile');
if (!in_array($targetVal, ['profile', 'post'], true)) { $targetVal = 'profile'; }
$showViewsVal = !empty($imageListConfig['show_views']);
$showLikesVal = !empty($imageListConfig['show_likes']);

$marqueeDefaults = [
    'list_count' => 4,
    'show_avatar' => true,
    'name_mode' => 'full',
];
$marqueeConfig = $marqueeDefaults;
if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionConfig')) {
    $fetchedMarquee = $RL->RL_GetLandingSectionConfig($themeSlug, 'marquee');
    if (is_array($fetchedMarquee)) {
        $marqueeConfig = array_replace($marqueeDefaults, array_intersect_key($fetchedMarquee, $marqueeDefaults));
    }
}
$listCountVal = max(1, min((int) ($marqueeConfig['list_count'] ?? 4), 10));
$showAvatarVal = !empty($marqueeConfig['show_avatar']);
$nameModeVal = $marqueeConfig['name_mode'] ?? 'full';
if (!in_array($nameModeVal, ['full', 'username'], true)) { $nameModeVal = 'full'; }

$marqueeItemsRaw = [];
if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionItems')) {
    $marqueeItemsRaw = $RL->RL_GetLandingSectionItems($themeSlug, 'marquee', 200);
}
$marqueeRows = [];
$rowIndex = 0;
foreach ($marqueeItemsRaw as $row) {
    $meta = isset($row['meta']) && is_array($row['meta']) ? $row['meta'] : [];
    $key = 'item_' . (++$rowIndex);
    $marqueeRows[$key] = [
        'id' => (int) ($row['id'] ?? 0),
        'display' => (string) ($meta['display'] ?? ''),
        'username' => (string) ($meta['username'] ?? ''),
        'avatar' => (string) ($meta['avatar'] ?? ''),
        'verified' => !empty($meta['verified']),
    ];
}
if (!$marqueeRows) {
    $marqueeRows['item_1'] = ['id' => 0, 'display' => '', 'username' => '', 'avatar' => '', 'verified' => false];
}

$featureItemsRaw = [];
if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionItems')) {
    $featureItemsRaw = $RL->RL_GetLandingSectionItems($themeSlug, 'features', 50);
}
$featureRows = [];
$featureIndex = 0;
foreach ($featureItemsRaw as $row) {
    $meta = isset($row['meta']) && is_array($row['meta']) ? $row['meta'] : [];
    $langPack = isset($row['lang']) && is_array($row['lang']) ? $row['lang'] : [];
    $key = 'item_' . (++$featureIndex);
    $translations = [];
    $variant = strtolower((string) ($meta['variant'] ?? 'light'));
    if (!in_array($variant, ['light', 'dark', 'muted'], true)) {
        $variant = 'light';
    }
    foreach ($langOptions as $langCode) {
        $langCodeLower = strtolower($langCode);
        $payload = isset($langPack[$langCodeLower]) && is_array($langPack[$langCodeLower]) ? $langPack[$langCodeLower] : [];
        $translations[$langCodeLower] = [
            'title' => (string) ($payload['title'] ?? ''),
            'desc'  => (string) ($payload['desc'] ?? ''),
        ];
    }
    $featureRows[$key] = [
        'id' => (int) ($row['id'] ?? 0),
        'icon' => (string) ($meta['icon'] ?? ''),
        'color' => (string) ($meta['color'] ?? ''),
        'translations' => $translations,
        'variant' => $variant,
    ];
}
if (!$featureRows) {
    $defaultPresets = [
        ['variant' => 'dark'],
        ['variant' => 'light'],
        ['variant' => 'light'],
        ['variant' => 'light'],
        ['variant' => 'light'],
        ['variant' => 'muted'],
    ];
    foreach ($defaultPresets as $slotIndex => $preset) {
        $translations = [];
        foreach ($langOptions as $langCode) {
            $langCodeLower = strtolower($langCode);
            $translations[$langCodeLower] = ['title' => '', 'desc' => ''];
        }
        $rowKey = 'item_' . ($slotIndex + 1);
        $featureRows[$rowKey] = [
            'id' => 0,
            'icon' => '',
            'color' => '#4F86F7',
            'translations' => $translations,
            'variant' => $preset['variant'],
        ];
    }
}

$noHassleConfigDefaults = [
    'ma_color' => '#4F86F7',
];
$noHassleConfig = $noHassleConfigDefaults;
if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionConfig')) {
    $fetchedNoHassle = $RL->RL_GetLandingSectionConfig($themeSlug, 'no_hassle');
    if (is_array($fetchedNoHassle)) {
        $noHassleConfig = array_replace($noHassleConfigDefaults, array_intersect_key($fetchedNoHassle, $noHassleConfigDefaults));
    }
}
$noHassleDefaultColor = (string) ($noHassleConfig['ma_color'] ?? '#4F86F7');
if ($noHassleDefaultColor === '' || !preg_match('/^#[0-9a-fA-F]{3,8}$/', $noHassleDefaultColor)) {
    $noHassleDefaultColor = '#4F86F7';
}

$noHassleItemsRaw = [];
if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionItems')) {
    $noHassleItemsRaw = $RL->RL_GetLandingSectionItems($themeSlug, 'no_hassle', 40);
}
$noHassleRows = [];
$noHassleIndex = 0;
foreach ($noHassleItemsRaw as $row) {
    $meta = isset($row['meta']) && is_array($row['meta']) ? $row['meta'] : [];
    $langPack = isset($row['lang']) && is_array($row['lang']) ? $row['lang'] : [];
    $key = 'item_' . (++$noHassleIndex);
    $translations = [];
    foreach ($langOptions as $langCode) {
        $langCodeLower = strtolower($langCode);
        $payload = isset($langPack[$langCodeLower]) && is_array($langPack[$langCodeLower]) ? $langPack[$langCodeLower] : [];
        $translations[$langCodeLower] = [
            'label' => (string) ($payload['label'] ?? ''),
        ];
    }
    $color = isset($meta['data_ma_color']) ? (string) $meta['data_ma_color'] : '';
    if ($color === '' || !preg_match('/^#[0-9a-fA-F]{3,8}$/', $color)) {
        $color = $noHassleDefaultColor;
    }
    $itemType = strtolower((string) ($row['item_type'] ?? 'feature'));
    if (!in_array($itemType, ['feature', 'badge'], true)) {
        $itemType = 'feature';
    }

    $noHassleRows[$key] = [
        'id' => (int) ($row['id'] ?? 0),
        'icon' => (string) ($meta['icon'] ?? ''),
        'color' => $color,
        'type' => $itemType,
        'translations' => $translations,
    ];
}
if (!$noHassleRows) {
    $defaultNoHasslePresets = [
        ['translation_key' => 'no_hassle_post_reels',    'color' => '#FF3C3C'],
        ['translation_key' => 'no_hassle_grow_fans',     'color' => '#F67D2E'],
        ['translation_key' => 'no_hassle_monetize_subs', 'color' => '#FFD700'],
        ['translation_key' => 'no_hassle_set_access',    'color' => '#43E97B'],
        ['translation_key' => 'no_hassle_sell_videos',   'color' => '#4F86F7'],
        ['translation_key' => 'no_hassle_create_earn',   'color' => '#9B59B6'],
    ];
    foreach ($defaultNoHasslePresets as $slotIndex => $preset) {
        $translations = [];
        foreach ($langOptions as $langCode) {
            $langCodeLower = strtolower($langCode);
            $translations[$langCodeLower] = [
                'label' => adminLandingDefaultValue($rawTranslations, $langCodeLower, $preset['translation_key']) ?? '',
            ];
        }
        $rowKey = 'item_' . ($slotIndex + 1);
        $fallbackColor = (string) ($preset['color'] ?? $noHassleDefaultColor);
        if ($fallbackColor === '' || !preg_match('/^#[0-9a-fA-F]{3,8}$/', $fallbackColor)) {
            $fallbackColor = $noHassleDefaultColor;
        }
        $noHassleRows[$rowKey] = [
            'id' => 0,
            'icon' => '',
            'color' => $fallbackColor,
            'type' => 'feature',
            'translations' => $translations,
        ];
    }
}

$getStartedConfigDefaults = ['data_ma_color' => '#FF3C3C'];
$getStartedConfig = $getStartedConfigDefaults;
if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionConfig')) {
    $fetchedGetStarted = $RL->RL_GetLandingSectionConfig($themeSlug, 'get_started');
    if (is_array($fetchedGetStarted)) {
        $getStartedConfig = array_replace($getStartedConfigDefaults, array_intersect_key($fetchedGetStarted, $getStartedConfigDefaults));
    }
}
$getStartedColor = (string) ($getStartedConfig['data_ma_color'] ?? '#FF3C3C');
if ($getStartedColor === '' || !preg_match('/^#[0-9a-fA-F]{3,8}$/', $getStartedColor)) {
    $getStartedColor = '#FF3C3C';
}

$getStartedItems = [];
$getStartedItemId = 0;
if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionItems')) {
    $getStartedItems = $RL->RL_GetLandingSectionItems($themeSlug, 'get_started', 1);
}
$getStartedStored = [];
if ($getStartedItems) {
    $firstItem = $getStartedItems[0];
    $getStartedItemId = (int) ($firstItem['id'] ?? 0);
    $langData = isset($firstItem['lang']) && is_array($firstItem['lang']) ? $firstItem['lang'] : [];
    $getStartedStored = landingAdminExtractGetStarted($langData, $langOptions);
}

$getStartedRows = [];
foreach ($langOptions as $langCode) {
    $stored = isset($getStartedStored[$langCode]) ? $getStartedStored[$langCode] : ['title' => '', 'desc' => '', 'button' => ''];
    $getStartedRows[$langCode] = [
        'title' => (string) ($stored['title'] ?? ''),
        'desc' => (string) ($stored['desc'] ?? ''),
        'button' => (string) ($stored['button'] ?? ''),
        'default_title' => adminLandingDefaultValue($rawTranslations, $langCode, 'footer_cta_title'),
        'default_desc' => adminLandingDefaultValue($rawTranslations, $langCode, 'footer_cta_subtitle'),
        'default_button' => adminLandingDefaultValue($rawTranslations, $langCode, 'footer_cta_button'),
    ];
}

$sampleDefaultKeys = [
    'public_videos',
    'followers_only',
    'subscribers_only',
    'premium_access',
    'seven_second_reels',
    'fourteen_second_reels',
    'hashtag_discovery',
    'creator_tips',
    'subscription_revenue',
    'explore_feed',
    'fast_payouts',
    'responsive_design',
    'more_tags',
];

$sampleItemsRaw = [];
if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionItems')) {
    $sampleItemsRaw = $RL->RL_GetLandingSectionItems($themeSlug, 'samples', 100);
}
$sampleRows = [];
$sampleIndex = 0;
foreach ($sampleItemsRaw as $row) {
    $meta = isset($row['meta']) && is_array($row['meta']) ? $row['meta'] : [];
    $langPack = isset($row['lang']) && is_array($row['lang']) ? $row['lang'] : [];
    $key = 'item_' . (++$sampleIndex);
    $translations = [];
    foreach ($langOptions as $langCode) {
        $langCodeLower = strtolower($langCode);
        $payload = isset($langPack[$langCodeLower]) && is_array($langPack[$langCodeLower]) ? $langPack[$langCodeLower] : [];
        $translations[$langCodeLower] = [
            'label' => (string) ($payload['label'] ?? ''),
        ];
    }
    $sampleRows[$key] = [
        'id' => (int) ($row['id'] ?? 0),
        'style' => (string) ($meta['style'] ?? 'narrow'),
        'translations' => $translations,
        'placeholder_key' => $sampleDefaultKeys[$sampleIndex - 1] ?? $sampleDefaultKeys[0],
    ];
}

$pricingDefaultPlans = [
    [
        'variant' => 'default',
        'highlight' => false,
        'cta_url' => '',
        'title_key' => 'pricing_public_title',
        'tagline_key' => 'pricing_visible_to_explore',
        'description_key' => 'pricing_public_desc',
        'badge_key' => 'pricing_public_price',
        'cta_label_key' => 'pricing_cta_default',
        'features_keys' => [
            'pricing_public_info_1',
            'pricing_public_info_2',
            'pricing_public_info_3',
            'pricing_public_info_4',
            'pricing_public_info_5',
        ],
    ],
    [
        'variant' => 'highlight',
        'highlight' => true,
        'cta_url' => '',
        'title_key' => 'pricing_subscriber_title',
        'tagline_key' => 'pricing_only_visible_for_subscribers',
        'description_key' => 'pricing_subscriber_desc',
        'badge_key' => 'pricing_subscriber_price',
        'cta_label_key' => 'pricing_cta_subscriber',
        'features_keys' => [
            'pricing_subscriber_info_1',
            'pricing_subscriber_info_2',
            'pricing_subscriber_info_3',
            'pricing_subscriber_info_4',
            'pricing_subscriber_info_5',
        ],
    ],
    [
        'variant' => 'muted',
        'highlight' => false,
        'cta_url' => '',
        'title_key' => 'pricing_premium_title',
        'tagline_key' => 'pricing_premium_label',
        'description_key' => 'pricing_premium_desc',
        'badge_key' => 'pricing_premium_price',
        'cta_label_key' => 'pricing_cta_premium',
        'features_keys' => [
            'pricing_premium_info_1',
            'pricing_premium_info_2',
            'pricing_premium_info_3',
            'pricing_premium_info_4',
        ],
    ],
];

$pricingItemsRaw = [];
if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionItems')) {
    $pricingItemsRaw = $RL->RL_GetLandingSectionItems($themeSlug, 'pricing', 50);
}
$pricingRows = [];
$pricingIndex = 0;
foreach ($pricingItemsRaw as $row) {
    $fallbackPlan = $pricingDefaultPlans[$pricingIndex % count($pricingDefaultPlans)];
    $meta = isset($row['meta']) && is_array($row['meta']) ? $row['meta'] : [];
    $langPack = isset($row['lang']) && is_array($row['lang']) ? $row['lang'] : [];
    $key = 'item_' . (++$pricingIndex);
    $badgeText = isset($meta['badge']) ? trim((string) $meta['badge']) : '';
    $highlight = !empty($meta['highlight']);
    $variant = isset($meta['variant']) ? (string) $meta['variant'] : ($highlight ? 'highlight' : 'default');
    if (!in_array($variant, ['default', 'highlight', 'muted'], true)) { $variant = $highlight ? 'highlight' : 'default'; }
    $ctaUrl = isset($meta['cta_url']) ? (string) $meta['cta_url'] : '';
    $features = [];
    if (isset($meta['features']) && is_array($meta['features'])) {
        foreach ($meta['features'] as $featureLine) {
            $line = trim((string) $featureLine);
            if ($line !== '') {
                $features[] = $line;
            }
        }
    }
    $featuresText = implode("\n", $features);

    $translations = [];
    foreach ($langOptions as $langCode) {
        $langKey = strtolower($langCode);
        $pack = isset($langPack[$langKey]) && is_array($langPack[$langKey]) ? $langPack[$langKey] : [];
        $translations[$langKey] = [
            'title' => (string) ($pack['title'] ?? ''),
            'tagline' => (string) ($pack['tagline'] ?? ''),
            'description' => (string) ($pack['description'] ?? ''),
            'cta_label' => (string) ($pack['cta_label'] ?? ''),
        ];
    }

    $pricingRows[$key] = [
        'id' => (int) ($row['id'] ?? 0),
        'badge' => $badgeText,
        'highlight' => $highlight,
        'variant' => $variant,
        'cta_url' => $ctaUrl,
        'features_text' => $featuresText,
        'translations' => $translations,
        'placeholder_keys' => [
            'title' => $fallbackPlan['title_key'],
            'tagline' => $fallbackPlan['tagline_key'],
            'description' => $fallbackPlan['description_key'],
            'cta_label' => $fallbackPlan['cta_label_key'],
            'badge' => $fallbackPlan['badge_key'],
            'features' => $fallbackPlan['features_keys'],
        ],
    ];
}

if (!$pricingRows) {
    foreach ($pricingDefaultPlans as $index => $plan) {
        $translations = [];
        foreach ($langOptions as $langCode) {
            $langKey = strtolower($langCode);
            $translations[$langKey] = [
                'title' => '',
                'tagline' => '',
                'description' => '',
                'cta_label' => '',
            ];
        }
        $rowKey = 'item_' . ($index + 1);
        $pricingRows[$rowKey] = [
            'id' => 0,
            'badge' => '',
            'highlight' => !empty($plan['highlight']),
            'variant' => $plan['variant'],
            'cta_url' => '',
            'features_text' => '',
            'translations' => $translations,
            'placeholder_keys' => [
                'title' => $plan['title_key'],
                'tagline' => $plan['tagline_key'],
                'description' => $plan['description_key'],
                'cta_label' => $plan['cta_label_key'],
                'badge' => $plan['badge_key'],
                'features' => $plan['features_keys'],
            ],
        ];
    }
}
if (!$sampleRows) {
    foreach ($sampleDefaultKeys as $index => $sampleKey) {
        $translations = [];
        foreach ($langOptions as $langCode) {
            $langCodeLower = strtolower($langCode);
            $translations[$langCodeLower] = ['label' => ''];
        }
        $rowKey = 'item_' . ($index + 1);
        $sampleRows[$rowKey] = [
            'id' => 0,
            'style' => 'narrow',
            'translations' => $translations,
            'placeholder_key' => $sampleKey,
        ];
    }
}

$landingLogger('init complete prep');
?>

<section class="card rounded-2xl" role="region" aria-labelledby="landingPageSettingsHeading">
  <h1 id="landingPageSettingsHeading"><?php echo iN_HelpSecure(customLang('admin_landing_settings_title') ?: 'Landing Page Settings', false); ?></h1>

  <div class="form-input-wrapper">
    <h2 class="form-subheading"><?php echo iN_HelpSecure(customLang('admin_landing_theme_heading') ?: 'Landing Theme', false); ?></h2>
    <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_landing_theme_hint') ?: 'Choose which layout guests see before logging in.', false); ?></p>
    <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="save-landing-theme">
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
      <input type="hidden" name="action" value="activate_theme">
      <fieldset>
        <legend class="form-label"><?php echo iN_HelpSecure(customLang('admin_landing_theme_select_label') ?: 'Active layout', false); ?></legend>
        <div class="landing-theme-options">
          <?php foreach ($themes as $theme):
              $slug = (string) ($theme['theme'] ?? 'welcome_default');
              $slugSafe = iN_HelpSecure($slug, false);
              $isActive = (int) ($theme['is_active'] ?? 0) === 1;
              $label = $landingThemeLabels[$slug] ?? ucwords(str_replace('_', ' ', $slug));
              $labelSafe = iN_HelpSecure($label, false);
              $meta = $slugSafe;
              if ($isActive) {
                  $meta .= ' · ' . iN_HelpSecure(customLang('admin_page_active') ?: 'Active', false);
              }
              $inputId = 'landing_theme_' . preg_replace('/[^a-z0-9]+/i', '_', $slug);
              $inputIdSafe = iN_HelpSecure($inputId, false);
          ?>
            <label class="landing-theme-option el-switch el-switch-sm<?php echo $isActive ? ' is-active' : ''; ?>" for="<?php echo $inputIdSafe; ?>">
              <input id="<?php echo $inputIdSafe; ?>" type="radio" name="theme" value="<?php echo $slugSafe; ?>" <?php echo $isActive ? 'checked' : ''; ?>>
              <span class="el-switch-style" aria-hidden="true"></span>
              <span class="landing-theme-option__body">
                <span class="landing-theme-option__title"><?php echo $labelSafe; ?></span>
                <span class="landing-theme-option__meta"><?php echo $meta; ?></span>
              </span>
            </label>
          <?php endforeach; ?>
        </div>
      </fieldset>
      <button type="submit" class="pe-save btn-hover"><?php echo iN_HelpSecure(customLang('admin_landing_theme_save') ?: customLang('admin_save_changes') ?: 'Save changes', false); ?></button>
    </form>
  </div>

  <div class="landing-section-tabs" data-landing-tabs role="tablist">
    <button type="button" class="landing-section-tab is-active" data-section-target="hero" role="tab" aria-selected="true"><?php echo iN_HelpSecure(customLang('admin_landing_tab_hero') ?: 'Hero', false); ?></button>
    <button type="button" class="landing-section-tab" data-section-target="image-list" role="tab" aria-selected="false"><?php echo iN_HelpSecure(customLang('admin_landing_tab_image') ?: 'Image List', false); ?></button>
    <button type="button" class="landing-section-tab" data-section-target="marquee" role="tab" aria-selected="false"><?php echo iN_HelpSecure(customLang('admin_landing_tab_marquee') ?: 'Marquee', false); ?></button>
    <button type="button" class="landing-section-tab" data-section-target="features" role="tab" aria-selected="false"><?php echo iN_HelpSecure(customLang('admin_landing_tab_features') ?: 'Features', false); ?></button>
    <button type="button" class="landing-section-tab" data-section-target="samples" role="tab" aria-selected="false"><?php echo iN_HelpSecure(customLang('admin_landing_tab_samples') ?: 'Samples', false); ?></button>
    <button type="button" class="landing-section-tab" data-section-target="pricing" role="tab" aria-selected="false"><?php echo iN_HelpSecure(customLang('admin_landing_tab_pricing') ?: 'Pricing', false); ?></button>
    <button type="button" class="landing-section-tab" data-section-target="earnings-simulator" role="tab" aria-selected="false"><?php echo iN_HelpSecure(customLang('admin_landing_tab_earnings_simulator') ?: 'Earnings Simulator Settings', false); ?></button>
    <button type="button" class="landing-section-tab" data-section-target="no-hassle" role="tab" aria-selected="false"><?php echo iN_HelpSecure(customLang('admin_landing_tab_no_hassle') ?: 'No-hassle', false); ?></button>
    <button type="button" class="landing-section-tab" data-section-target="get-started" role="tab" aria-selected="false"><?php echo iN_HelpSecure(customLang('admin_landing_tab_get_started') ?: 'Get Started', false); ?></button>
  </div>

  <div class="landing-section-panel is-active" data-section-panel="hero" role="tabpanel" aria-hidden="false">
  <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="save-landing-hero">
    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
    <input type="hidden" name="action" value="save_hero">
    <input type="hidden" name="theme" value="<?php echo iN_HelpSecure($themeSlug, false); ?>">

    <fieldset class="form-input-wrapper" data-lang-switcher>
      <legend><?php echo iN_HelpSecure(customLang('admin_landing_hero_section') ?: 'Hero Content', false); ?></legend>
      <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_landing_hero_hint') ?: 'Leave a field empty to fall back to the theme\'s default translation.', false); ?></p>

      <div class="landing-lang-tabs" data-lang-tabs role="tablist">
        <?php foreach ($langOptions as $idx => $langCode):
          $langSafe = iN_HelpSecure($langCode, false);
          $isActive = $idx === 0;
        ?>
          <button type="button"
                  class="landing-lang-tab<?php echo $isActive ? ' is-active' : ''; ?>"
                  data-lang-target="<?php echo $langSafe; ?>"
                  role="tab"
                  aria-selected="<?php echo $isActive ? 'true' : 'false'; ?>">
            <?php echo iN_HelpSecure(strtoupper($langCode), false); ?>
          </button>
        <?php endforeach; ?>
      </div>

      <?php foreach ($langOptions as $idx => $langCode):
        $langSafe = iN_HelpSecure($langCode, false);
        $defaultTitle = adminLandingDefaultValue($rawTranslations, $langCode, 'hero_title');
        $defaultDescription = adminLandingDefaultValue($rawTranslations, $langCode, 'hero_description');
        $defaultButton = adminLandingDefaultValue($rawTranslations, $langCode, 'hero_start_button');
        $valTitle = adminLandingFieldValue($heroOverrides, $langCode, 'hero_title');
        $valDescription = adminLandingFieldValue($heroOverrides, $langCode, 'hero_description');
        $valButton = adminLandingFieldValue($heroOverrides, $langCode, 'hero_start_button');
        $isActive = $idx === 0;
      ?>
        <div class="landing-lang-panel<?php echo $isActive ? ' is-active' : ''; ?>"
             data-lang-panel="<?php echo $langSafe; ?>"
             role="tabpanel"
             aria-hidden="<?php echo $isActive ? 'false' : 'true'; ?>"<?php echo $isActive ? '' : ' hidden'; ?>>
          <label class="form-label" for="hero_title_<?php echo $langSafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_hero_title') ?: 'Hero Title', false); ?></label>
          <input id="hero_title_<?php echo $langSafe; ?>" class="form-input" type="text" name="hero_title[<?php echo $langSafe; ?>]" value="<?php echo iN_HelpSecure($valTitle, false); ?>" maxlength="180" placeholder="<?php echo iN_HelpSecure($defaultTitle, false); ?>">

          <label class="form-label" for="hero_description_<?php echo $langSafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_hero_description') ?: 'Hero Description', false); ?></label>
          <textarea id="hero_description_<?php echo $langSafe; ?>" class="form-input" name="hero_description[<?php echo $langSafe; ?>]" rows="3" maxlength="420" placeholder="<?php echo iN_HelpSecure($defaultDescription, false); ?>"><?php echo iN_HelpSecure($valDescription, false); ?></textarea>

          <label class="form-label" for="hero_start_button_<?php echo $langSafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_hero_button') ?: 'Hero Primary Button', false); ?></label>
          <input id="hero_start_button_<?php echo $langSafe; ?>" class="form-input" type="text" name="hero_start_button[<?php echo $langSafe; ?>]" value="<?php echo iN_HelpSecure($valButton, false); ?>" maxlength="80" placeholder="<?php echo iN_HelpSecure($defaultButton, false); ?>">
        </div>
      <?php endforeach; ?>
    </fieldset>

    <button type="submit" class="pe-save btn-hover"><?php echo iN_HelpSecure(customLang('admin_save_changes') ?: 'Save Changes', false); ?></button>
  </form>
  </div>

  <div class="landing-section-panel" data-section-panel="image-list" role="tabpanel" aria-hidden="true" hidden>
    <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="save-landing-image-list">
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
      <input type="hidden" name="action" value="save_image_list">
      <input type="hidden" name="theme" value="<?php echo iN_HelpSecure($themeSlug, false); ?>">

      <fieldset class="form-input-wrapper">
        <legend><?php echo iN_HelpSecure(customLang('admin_landing_image_section') ?: 'Image List', false); ?></legend>

        <label class="form-label" for="image_list_media_mode"><?php echo iN_HelpSecure(customLang('admin_landing_image_media_mode') ?: 'Media Mode', false); ?></label>
        <select id="image_list_media_mode" class="form-input" name="media_mode">
          <option value="mixed"<?php echo $mediaModeVal === 'mixed' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_option_media_mode_mixed') ?: 'Mixed (images & videos)', false); ?></option>
          <option value="image"<?php echo $mediaModeVal === 'image' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_option_media_mode_image') ?: 'Images only', false); ?></option>
          <option value="video"<?php echo $mediaModeVal === 'video' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_option_media_mode_video') ?: 'Videos only', false); ?></option>
        </select>

        <label class="form-label" for="image_list_target"><?php echo iN_HelpSecure(customLang('admin_landing_image_target') ?: 'Target when clicked', false); ?></label>
        <select id="image_list_target" class="form-input" name="target">
          <option value="profile"<?php echo $targetVal === 'profile' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_option_target_profile') ?: 'Creator profile', false); ?></option>
          <option value="post"<?php echo $targetVal === 'post' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_option_target_post') ?: 'Post page', false); ?></option>
        </select>

        <label class="form-checkbox">
          <input type="checkbox" name="show_views" value="1" <?php echo $showViewsVal ? 'checked' : ''; ?>>
          <span><?php echo iN_HelpSecure(customLang('admin_landing_image_show_views') ?: 'Display view count overlay', false); ?></span>
        </label>

        <label class="form-checkbox">
          <input type="checkbox" name="show_likes" value="1" <?php echo $showLikesVal ? 'checked' : ''; ?>>
          <span><?php echo iN_HelpSecure(customLang('admin_landing_image_show_likes') ?: 'Expose like totals to the carousel JS', false); ?></span>
        </label>
      </fieldset>

      <button type="submit" class="pe-save btn-hover"><?php echo iN_HelpSecure(customLang('admin_save_changes') ?: 'Save Changes', false); ?></button>
    </form>
  </div>

  <div class="landing-section-panel" data-section-panel="marquee" role="tabpanel" aria-hidden="true" hidden>
    <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="save-landing-marquee">
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
      <input type="hidden" name="action" value="save_marquee">
      <input type="hidden" name="theme" value="<?php echo iN_HelpSecure($themeSlug, false); ?>">

      <fieldset class="form-input-wrapper">
        <legend><?php echo iN_HelpSecure(customLang('admin_landing_marquee_section') ?: 'Marquee Lists', false); ?></legend>

        <label class="form-label" for="marquee_list_count"><?php echo iN_HelpSecure(customLang('admin_landing_marquee_list_count') ?: 'Number of lists', false); ?></label>
        <input id="marquee_list_count" class="form-input" type="number" name="list_count" min="1" max="10" value="<?php echo (int) $listCountVal; ?>">

        <label class="form-checkbox">
          <input type="checkbox" name="show_avatar" value="1" <?php echo $showAvatarVal ? 'checked' : ''; ?>>
          <span><?php echo iN_HelpSecure(customLang('admin_landing_marquee_show_avatar') ?: 'Display avatars', false); ?></span>
        </label>

        <label class="form-label" for="marquee_name_mode"><?php echo iN_HelpSecure(customLang('admin_landing_marquee_name_mode') ?: 'Display mode', false); ?></label>
        <select id="marquee_name_mode" class="form-input" name="name_mode">
          <option value="full"<?php echo $nameModeVal === 'full' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_option_name_mode_full') ?: 'Full name', false); ?></option>
          <option value="username"<?php echo $nameModeVal === 'username' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_option_name_mode_username') ?: 'Username', false); ?></option>
        </select>
      </fieldset>

      <fieldset class="form-input-wrapper">
        <legend><?php echo iN_HelpSecure(customLang('admin_landing_marquee_items') ?: 'Marquee Items', false); ?></legend>
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_landing_marquee_items_hint') ?: 'Leave a row empty to remove it. Provide either a display name or username.', false); ?></p>

        <table class="landing-marquee-table">
          <thead>
            <tr>
              <th><?php echo iN_HelpSecure(customLang('admin_landing_marquee_display') ?: 'Display Name', false); ?></th>
              <th><?php echo iN_HelpSecure(customLang('admin_landing_marquee_username') ?: 'Username', false); ?></th>
              <th><?php echo iN_HelpSecure(customLang('admin_landing_marquee_avatar') ?: 'Avatar URL', false); ?></th>
              <th><?php echo iN_HelpSecure(customLang('admin_landing_marquee_verified') ?: 'Verified', false); ?></th>
              <th aria-hidden="true"></th>
            </tr>
          </thead>
          <tbody data-sortable-list="marquee">
            <?php foreach ($marqueeRows as $rowKey => $item): ?>
              <tr class="landing-marquee-row" data-sortable-item data-row-key="<?php echo iN_HelpSecure($rowKey, false); ?>" draggable="true">
                <td>
                  <input type="hidden" name="item_id[<?php echo iN_HelpSecure($rowKey, false); ?>]" value="<?php echo iN_HelpSecure((string)($item['id'] ?? 0), false); ?>">
                  <input type="text" class="form-input" name="display_name[<?php echo iN_HelpSecure($rowKey, false); ?>]" value="<?php echo iN_HelpSecure($item['display'] ?? '', false); ?>" placeholder="<?php echo iN_HelpSecure(customLang('admin_placeholder_display_name') ?: 'e.g. Mustafa Öztürk', false); ?>">
                </td>
                <td>
                  <input type="text" class="form-input" name="username[<?php echo iN_HelpSecure($rowKey, false); ?>]" value="<?php echo iN_HelpSecure($item['username'] ?? '', false); ?>" placeholder="<?php echo iN_HelpSecure(customLang('admin_placeholder_username') ?: 'e.g. mustafaozturk', false); ?>">
                </td>
                <td>
                  <input type="text" class="form-input" name="avatar[<?php echo iN_HelpSecure($rowKey, false); ?>]" value="<?php echo iN_HelpSecure($item['avatar'] ?? '', false); ?>" placeholder="<?php echo iN_HelpSecure(customLang('admin_placeholder_avatar_url') ?: 'https://', false); ?>">
                </td>
                <td class="landing-marquee-checkbox">
                  <input type="checkbox" name="verified[<?php echo iN_HelpSecure($rowKey, false); ?>]" value="1" <?php echo !empty($item['verified']) ? 'checked' : ''; ?> aria-label="<?php echo iN_HelpSecure(customLang('admin_landing_marquee_verified') ?: 'Verified', false); ?>">
                </td>
                <td>
                  <button type="button" class="landing-remove-row" data-remove-marquee aria-label="<?php echo iN_HelpSecure(customLang('admin_remove_row') ?: 'Remove row', false); ?>">&times;</button>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <button type="button" class="btn-outline" data-action="add-marquee-item"><?php echo iN_HelpSecure(customLang('admin_add_item') ?: 'Add Item', false); ?></button>

        <template id="marqueeItemTemplate">
          <tr class="landing-marquee-row" data-sortable-item data-row-key="__KEY__" draggable="true">
            <td>
              <input type="hidden" name="item_id[__KEY__]" value="0">
              <input type="text" class="form-input" name="display_name[__KEY__]" value="" placeholder="<?php echo iN_HelpSecure(customLang('admin_placeholder_display_name') ?: 'e.g. Mustafa Öztürk', false); ?>">
            </td>
            <td>
              <input type="text" class="form-input" name="username[__KEY__]" value="" placeholder="<?php echo iN_HelpSecure(customLang('admin_placeholder_username') ?: 'e.g. mustafaozturk', false); ?>">
            </td>
            <td>
              <input type="text" class="form-input" name="avatar[__KEY__]" value="" placeholder="<?php echo iN_HelpSecure(customLang('admin_placeholder_avatar_url') ?: 'https://', false); ?>">
            </td>
            <td class="landing-marquee-checkbox">
              <input type="checkbox" name="verified[__KEY__]" value="1" aria-label="<?php echo iN_HelpSecure(customLang('admin_landing_marquee_verified') ?: 'Verified', false); ?>">
            </td>
            <td>
              <button type="button" class="landing-remove-row" data-remove-marquee aria-label="<?php echo iN_HelpSecure(customLang('admin_remove_row') ?: 'Remove row', false); ?>">&times;</button>
            </td>
          </tr>
        </template>
      </fieldset>

      <button type="submit" class="pe-save btn-hover"><?php echo iN_HelpSecure(customLang('admin_save_changes') ?: 'Save Changes', false); ?></button>
    </form>
  </div>

  <div class="landing-section-panel" data-section-panel="features" role="tabpanel" aria-hidden="true" hidden>
    <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="save-landing-features">
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
      <input type="hidden" name="action" value="save_features">
      <input type="hidden" name="theme" value="<?php echo iN_HelpSecure($themeSlug, false); ?>">

      <fieldset class="form-input-wrapper">
        <legend><?php echo iN_HelpSecure(customLang('admin_landing_features_section') ?: 'Feature Cards', false); ?></legend>
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_landing_features_hint') ?: 'Set the icon, accent color, and localized title & description for each feature card. Drag to reorder.', false); ?></p>

        <fieldset class="form-input-wrapper" data-lang-switcher>
          <legend><?php echo iN_HelpSecure(customLang('admin_landing_features_text_section') ?: 'Section Title & Subtitle', false); ?></legend>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_landing_features_text_hint') ?: 'Leave blank to fall back to the default theme translation.', false); ?></p>

          <div class="landing-lang-tabs" data-lang-tabs role="tablist">
            <?php foreach ($langOptions as $idx => $langCode):
              $langSafe = iN_HelpSecure($langCode, false);
              $isActive = $idx === 0;
            ?>
              <button type="button"
                      class="landing-lang-tab<?php echo $isActive ? ' is-active' : ''; ?>"
                      data-lang-target="feature-<?php echo $langSafe; ?>"
                      role="tab"
                      aria-selected="<?php echo $isActive ? 'true' : 'false'; ?>">
                <?php echo iN_HelpSecure(strtoupper($langCode), false); ?>
              </button>
            <?php endforeach; ?>
          </div>

          <?php foreach ($langOptions as $idx => $langCode):
            $langSafe = iN_HelpSecure($langCode, false);
            $defaultFeatureTitle = adminLandingDefaultValue($rawTranslations, $langCode, 'features_title_why_choose');
            $defaultFeatureSubtitle = adminLandingDefaultValue($rawTranslations, $langCode, 'features_subtitle_publish_protect');
            $valFeatureTitle = adminLandingFieldValue($featureTextOverrides, $langCode, 'features_title_why_choose');
            $valFeatureSubtitle = adminLandingFieldValue($featureTextOverrides, $langCode, 'features_subtitle_publish_protect');
            $isActive = $idx === 0;
          ?>
            <div class="landing-lang-panel<?php echo $isActive ? ' is-active' : ''; ?>"
                 data-lang-panel="feature-<?php echo $langSafe; ?>"
                 role="tabpanel"
                 aria-hidden="<?php echo $isActive ? 'false' : 'true'; ?>"<?php echo $isActive ? '' : ' hidden'; ?>>
              <label class="form-label" for="feature_section_title_<?php echo $langSafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_feature_heading_title') ?: 'Section Title', false); ?></label>
              <input id="feature_section_title_<?php echo $langSafe; ?>" class="form-input" type="text" name="feature_section_title[<?php echo $langSafe; ?>]" value="<?php echo iN_HelpSecure($valFeatureTitle, false); ?>" maxlength="180" placeholder="<?php echo iN_HelpSecure($defaultFeatureTitle, false); ?>">

              <label class="form-label" for="feature_section_subtitle_<?php echo $langSafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_feature_heading_subtitle') ?: 'Section Subtitle', false); ?></label>
              <textarea id="feature_section_subtitle_<?php echo $langSafe; ?>" class="form-input" name="feature_section_subtitle[<?php echo $langSafe; ?>]" rows="3" maxlength="420" placeholder="<?php echo iN_HelpSecure($defaultFeatureSubtitle, false); ?>"><?php echo iN_HelpSecure($valFeatureSubtitle, false); ?></textarea>
            </div>
          <?php endforeach; ?>
        </fieldset>

        <div class="landing-feature-list" data-sortable-list="features">
          <?php foreach ($featureRows as $rowKey => $feature):
            $featureKey = iN_HelpSecure($rowKey, false);
            $iconValue = iN_HelpSecure((string) ($feature['icon'] ?? ''), false);
            $colorValue = (string) ($feature['color'] ?? '');
            if ($colorValue === '' || !preg_match('/^#[0-9a-fA-F]{3,8}$/', $colorValue)) { $colorValue = '#4F86F7'; }
            $colorEsc = iN_HelpSecure($colorValue, false);
            $translations = is_array($feature['translations'] ?? null) ? $feature['translations'] : [];
            $variantValue = (string) ($feature['variant'] ?? 'light');
            if (!in_array($variantValue, ['light', 'dark', 'muted'], true)) { $variantValue = 'light'; }
          ?>
          <div class="landing-feature-card" data-sortable-item data-row-key="<?php echo $featureKey; ?>" draggable="true">
            <div class="landing-feature-controls">
              <span class="landing-drag-handle" aria-hidden="true">☰</span>
              <button type="button" class="landing-remove-row" data-remove-feature aria-label="<?php echo iN_HelpSecure(customLang('admin_remove_row') ?: 'Remove row', false); ?>">&times;</button>
            </div>
            <input type="hidden" name="feature_id[<?php echo $featureKey; ?>]" value="<?php echo iN_HelpSecure((string)($feature['id'] ?? 0), false); ?>">
            <div class="landing-feature-main">
              <label class="form-label" for="feature_icon_<?php echo $featureKey; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_feature_icon') ?: 'Icon (URL or text)', false); ?></label>
              <input id="feature_icon_<?php echo $featureKey; ?>" class="form-input" type="text" name="feature_icon[<?php echo $featureKey; ?>]" value="<?php echo $iconValue; ?>" placeholder="<?php echo iN_HelpSecure(customLang('admin_placeholder_feature_icon') ?: 'e.g. verified (icon key) or uploads/icons/custom.svg', false); ?>">

              <label class="form-label" for="feature_color_<?php echo $featureKey; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_feature_color') ?: 'Accent color', false); ?></label>
              <input id="feature_color_<?php echo $featureKey; ?>" class="form-input" type="color" name="feature_color[<?php echo $featureKey; ?>]" value="<?php echo $colorEsc; ?>">

              <label class="form-label" for="feature_variant_<?php echo $featureKey; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_feature_variant') ?: 'Card style', false); ?></label>
              <select id="feature_variant_<?php echo $featureKey; ?>" class="form-input" name="feature_variant[<?php echo $featureKey; ?>]">
                <option value="light"<?php echo $variantValue === 'light' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_landing_feature_variant_light') ?: 'Light', false); ?></option>
                <option value="dark"<?php echo $variantValue === 'dark' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_landing_feature_variant_dark') ?: 'Dark highlight', false); ?></option>
                <option value="muted"<?php echo $variantValue === 'muted' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_landing_feature_variant_muted') ?: 'Muted grey', false); ?></option>
              </select>
            </div>
            <div class="landing-feature-langs">
              <?php foreach ($langOptions as $langCode):
                $langKey = strtolower($langCode);
                $langSafe = iN_HelpSecure($langKey, false);
                $titleVal = iN_HelpSecure((string) ($translations[$langKey]['title'] ?? ''), false);
                $descVal  = iN_HelpSecure((string) ($translations[$langKey]['desc'] ?? ''), false);
              ?>
                <div class="landing-feature-lang-card">
                  <h4><?php echo iN_HelpSecure(strtoupper($langCode), false); ?></h4>
                  <label class="form-label" for="feature_title_<?php echo $langSafe . '_' . $featureKey; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_feature_title') ?: 'Title', false); ?></label>
                  <input id="feature_title_<?php echo $langSafe . '_' . $featureKey; ?>" class="form-input" type="text" name="feature_title[<?php echo $langSafe; ?>][<?php echo $featureKey; ?>]" value="<?php echo $titleVal; ?>" maxlength="120">

                  <label class="form-label" for="feature_desc_<?php echo $langSafe . '_' . $featureKey; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_feature_desc') ?: 'Description', false); ?></label>
                  <textarea id="feature_desc_<?php echo $langSafe . '_' . $featureKey; ?>" class="form-input" name="feature_desc[<?php echo $langSafe; ?>][<?php echo $featureKey; ?>]" rows="3" maxlength="400"><?php echo $descVal; ?></textarea>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <button type="button" class="btn-outline" data-action="add-feature-item"><?php echo iN_HelpSecure(customLang('admin_add_feature') ?: 'Add Feature', false); ?></button>

        <template id="featureItemTemplate">
          <div class="landing-feature-card" data-sortable-item data-row-key="__KEY__" draggable="true">
            <div class="landing-feature-controls">
              <span class="landing-drag-handle" aria-hidden="true">☰</span>
              <button type="button" class="landing-remove-row" data-remove-feature aria-label="<?php echo iN_HelpSecure(customLang('admin_remove_row') ?: 'Remove row', false); ?>">&times;</button>
            </div>
            <input type="hidden" name="feature_id[__KEY__]" value="0">
            <div class="landing-feature-main">
              <label class="form-label" for="feature_icon___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_feature_icon') ?: 'Icon (URL or text)', false); ?></label>
              <input id="feature_icon___KEY__" class="form-input" type="text" name="feature_icon[__KEY__]" value="" placeholder="<?php echo iN_HelpSecure(customLang('admin_placeholder_feature_icon') ?: 'e.g. verified (icon key) or uploads/icons/custom.svg', false); ?>">

              <label class="form-label" for="feature_color___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_feature_color') ?: 'Accent color', false); ?></label>
              <input id="feature_color___KEY__" class="form-input" type="color" name="feature_color[__KEY__]" value="#4F86F7">

              <label class="form-label" for="feature_variant___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_feature_variant') ?: 'Card style', false); ?></label>
              <select id="feature_variant___KEY__" class="form-input" name="feature_variant[__KEY__]">
                <option value="light"><?php echo iN_HelpSecure(customLang('admin_landing_feature_variant_light') ?: 'Light', false); ?></option>
                <option value="dark"><?php echo iN_HelpSecure(customLang('admin_landing_feature_variant_dark') ?: 'Dark highlight', false); ?></option>
                <option value="muted"><?php echo iN_HelpSecure(customLang('admin_landing_feature_variant_muted') ?: 'Muted grey', false); ?></option>
              </select>
            </div>
            <div class="landing-feature-langs">
              <?php foreach ($langOptions as $langCode):
                $langKey = strtolower($langCode);
                $langSafe = iN_HelpSecure($langKey, false);
              ?>
                <div class="landing-feature-lang-card">
                  <h4><?php echo iN_HelpSecure(strtoupper($langCode), false); ?></h4>
                  <label class="form-label" for="feature_title_<?php echo $langSafe; ?>___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_feature_title') ?: 'Title', false); ?></label>
                  <input id="feature_title_<?php echo $langSafe; ?>___KEY__" class="form-input" type="text" name="feature_title[<?php echo $langSafe; ?>][__KEY__]" value="" maxlength="120">

                  <label class="form-label" for="feature_desc_<?php echo $langSafe; ?>___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_feature_desc') ?: 'Description', false); ?></label>
                  <textarea id="feature_desc_<?php echo $langSafe; ?>___KEY__" class="form-input" name="feature_desc[<?php echo $langSafe; ?>][__KEY__]" rows="3" maxlength="400"></textarea>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        </template>
      </fieldset>

      <button type="submit" class="pe-save btn-hover"><?php echo iN_HelpSecure(customLang('admin_save_changes') ?: 'Save Changes', false); ?></button>
    </form>
  </div>

  <div class="landing-section-panel" data-section-panel="samples" role="tabpanel" aria-hidden="true" hidden>
    <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="save-landing-samples">
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
      <input type="hidden" name="action" value="save_samples">
      <input type="hidden" name="theme" value="<?php echo iN_HelpSecure($themeSlug, false); ?>">

      <fieldset class="form-input-wrapper" data-lang-switcher>
        <legend><?php echo iN_HelpSecure(customLang('admin_landing_samples_text_section') ?: 'Samples Section Text', false); ?></legend>
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_landing_samples_text_hint') ?: 'Leave blank to use the default language strings.', false); ?></p>

        <div class="landing-lang-tabs" data-lang-tabs role="tablist">
          <?php foreach ($langOptions as $idx => $langCode):
            $langSafe = iN_HelpSecure($langCode, false);
            $isActive = $idx === 0;
          ?>
            <button type="button"
                    class="landing-lang-tab<?php echo $isActive ? ' is-active' : ''; ?>"
                    data-lang-target="samples-<?php echo $langSafe; ?>"
                    role="tab"
                    aria-selected="<?php echo $isActive ? 'true' : 'false'; ?>">
              <?php echo iN_HelpSecure(strtoupper($langCode), false); ?>
            </button>
          <?php endforeach; ?>
        </div>

        <?php foreach ($langOptions as $idx => $langCode):
          $langSafe = iN_HelpSecure($langCode, false);
          $defaultTitle = adminLandingDefaultValue($rawTranslations, $langCode, 'features_tags_title');
          $defaultSubtitle = adminLandingDefaultValue($rawTranslations, $langCode, 'features_tags_subtitle');
          $valTitle = adminLandingFieldValue($sampleTextOverrides, $langCode, 'features_tags_title');
          $valSubtitle = adminLandingFieldValue($sampleTextOverrides, $langCode, 'features_tags_subtitle');
          $isActive = $idx === 0;
        ?>
          <div class="landing-lang-panel<?php echo $isActive ? ' is-active' : ''; ?>"
               data-lang-panel="samples-<?php echo $langSafe; ?>"
               role="tabpanel"
               aria-hidden="<?php echo $isActive ? 'false' : 'true'; ?>"<?php echo $isActive ? '' : ' hidden'; ?>>
            <label class="form-label" for="sample_section_title_<?php echo $langSafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_samples_heading_title') ?: 'Section Title', false); ?></label>
            <input id="sample_section_title_<?php echo $langSafe; ?>" class="form-input" type="text" name="sample_section_title[<?php echo $langSafe; ?>]" value="<?php echo iN_HelpSecure($valTitle, false); ?>" maxlength="160" placeholder="<?php echo iN_HelpSecure($defaultTitle, false); ?>">

            <label class="form-label" for="sample_section_subtitle_<?php echo $langSafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_samples_heading_subtitle') ?: 'Section Subtitle', false); ?></label>
            <textarea id="sample_section_subtitle_<?php echo $langSafe; ?>" class="form-input" name="sample_section_subtitle[<?php echo $langSafe; ?>]" rows="3" maxlength="400" placeholder="<?php echo iN_HelpSecure($defaultSubtitle, false); ?>"><?php echo iN_HelpSecure($valSubtitle, false); ?></textarea>
          </div>
        <?php endforeach; ?>
      </fieldset>

      <fieldset class="form-input-wrapper">
        <legend><?php echo iN_HelpSecure(customLang('admin_landing_samples_section') ?: 'Samples Grid', false); ?></legend>
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_landing_samples_hint') ?: 'Manage the labels shown in the samples grid. Leave a language empty to fall back to the default translation.', false); ?></p>

        <div class="landing-feature-list" data-sortable-list="samples">
          <?php $sampleIdx = 0; foreach ($sampleRows as $rowKey => $sample):
            $sampleIdx++;
            $sampleKeySafe = iN_HelpSecure($rowKey, false);
            $styleValue = (string) ($sample['style'] ?? 'narrow');
            if (!in_array($styleValue, ['narrow', 'wide'], true)) { $styleValue = 'narrow'; }
            $translations = is_array($sample['translations'] ?? null) ? $sample['translations'] : [];
            $placeholderKey = (string) ($sample['placeholder_key'] ?? ($sampleDefaultKeys[($sampleIdx - 1) % count($sampleDefaultKeys)] ?? 'public_videos'));
          ?>
          <div class="landing-feature-card" data-sortable-item data-row-key="<?php echo $sampleKeySafe; ?>" draggable="true">
            <div class="landing-feature-controls">
              <span class="landing-drag-handle" aria-hidden="true">☰</span>
              <button type="button" class="landing-remove-row" data-remove-sample aria-label="<?php echo iN_HelpSecure(customLang('admin_remove_row') ?: 'Remove row', false); ?>">&times;</button>
            </div>
            <input type="hidden" name="sample_id[<?php echo $sampleKeySafe; ?>]" value="<?php echo iN_HelpSecure((string)($sample['id'] ?? 0), false); ?>">
            <div class="landing-feature-main">
              <label class="form-label" for="sample_style_<?php echo $sampleKeySafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_sample_style') ?: 'Tag size', false); ?></label>
              <select id="sample_style_<?php echo $sampleKeySafe; ?>" class="form-input" name="sample_style[<?php echo $sampleKeySafe; ?>]">
                <option value="narrow"<?php echo $styleValue === 'narrow' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_landing_sample_style_narrow') ?: 'Narrow', false); ?></option>
                <option value="wide"<?php echo $styleValue === 'wide' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_landing_sample_style_wide') ?: 'Wide', false); ?></option>
              </select>
            </div>
            <div class="landing-feature-langs">
              <?php foreach ($langOptions as $langCode):
                $langKey = strtolower($langCode);
                $langSafe = iN_HelpSecure($langKey, false);
                $labelVal = iN_HelpSecure((string) ($translations[$langKey]['label'] ?? ''), false);
                $placeholderVal = adminLandingDefaultValue($rawTranslations, $langCode, $placeholderKey) ?: adminLandingDefaultValue($rawTranslations, $langCode, 'public_videos');
              ?>
                <div class="landing-feature-lang-card">
                  <h4><?php echo iN_HelpSecure(strtoupper($langCode), false); ?></h4>
                  <label class="form-label" for="sample_label_<?php echo $langSafe . '_' . $sampleKeySafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_sample_label') ?: 'Label', false); ?></label>
                  <input id="sample_label_<?php echo $langSafe . '_' . $sampleKeySafe; ?>" class="form-input" type="text" name="sample_label[<?php echo $langSafe; ?>][<?php echo $sampleKeySafe; ?>]" value="<?php echo $labelVal; ?>" maxlength="120" placeholder="<?php echo iN_HelpSecure($placeholderVal ?: customLang('admin_landing_placeholder_sample_label') ?: 'Tag label', false); ?>">
                </div>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <button type="button" class="btn-outline" data-action="add-sample-item"><?php echo iN_HelpSecure(customLang('admin_add_sample') ?: 'Add Sample', false); ?></button>

        <template id="sampleItemTemplate">
          <div class="landing-feature-card" data-sortable-item data-row-key="__KEY__" draggable="true">
            <div class="landing-feature-controls">
              <span class="landing-drag-handle" aria-hidden="true">☰</span>
              <button type="button" class="landing-remove-row" data-remove-sample aria-label="<?php echo iN_HelpSecure(customLang('admin_remove_row') ?: 'Remove row', false); ?>">&times;</button>
            </div>
            <input type="hidden" name="sample_id[__KEY__]" value="0">
            <div class="landing-feature-main">
              <label class="form-label" for="sample_style___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_sample_style') ?: 'Tag size', false); ?></label>
              <select id="sample_style___KEY__" class="form-input" name="sample_style[__KEY__]">
                <option value="narrow"><?php echo iN_HelpSecure(customLang('admin_landing_sample_style_narrow') ?: 'Narrow', false); ?></option>
                <option value="wide"><?php echo iN_HelpSecure(customLang('admin_landing_sample_style_wide') ?: 'Wide', false); ?></option>
              </select>
            </div>
            <div class="landing-feature-langs">
              <?php foreach ($langOptions as $langCode):
                $langKey = strtolower($langCode);
                $langSafe = iN_HelpSecure($langKey, false);
                $placeholderVal = adminLandingDefaultValue($rawTranslations, $langCode, $sampleDefaultKeys[0]) ?: customLang('admin_landing_placeholder_sample_label');
              ?>
                <div class="landing-feature-lang-card">
                  <h4><?php echo iN_HelpSecure(strtoupper($langCode), false); ?></h4>
                  <label class="form-label" for="sample_label_<?php echo $langSafe; ?>___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_sample_label') ?: 'Label', false); ?></label>
                  <input id="sample_label_<?php echo $langSafe; ?>___KEY__" class="form-input" type="text" name="sample_label[<?php echo $langSafe; ?>][__KEY__]" value="" maxlength="120" placeholder="<?php echo iN_HelpSecure($placeholderVal ?: customLang('admin_landing_placeholder_sample_label') ?: 'Tag label', false); ?>">
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        </template>
      </fieldset>

      <button type="submit" class="pe-save btn-hover"><?php echo iN_HelpSecure(customLang('admin_save_changes') ?: 'Save Changes', false); ?></button>
    </form>
  </div>

  <div class="landing-section-panel" data-section-panel="pricing" role="tabpanel" aria-hidden="true" hidden>
    <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="save-landing-pricing">
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
      <input type="hidden" name="action" value="save_pricing">
      <input type="hidden" name="theme" value="<?php echo iN_HelpSecure($themeSlug, false); ?>">

      <fieldset class="form-input-wrapper" data-lang-switcher>
        <legend><?php echo iN_HelpSecure(customLang('admin_landing_pricing_text_section') ?: 'Earning Modes Text', false); ?></legend>
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_text_hint') ?: 'Leave blank to fall back to the default language strings.', false); ?></p>

        <div class="landing-lang-tabs" data-lang-tabs role="tablist">
          <?php foreach ($langOptions as $idx => $langCode):
            $langSafe = iN_HelpSecure($langCode, false);
            $isActive = $idx === 0;
          ?>
            <button type="button"
                    class="landing-lang-tab<?php echo $isActive ? ' is-active' : ''; ?>"
                    data-lang-target="pricing-<?php echo $langSafe; ?>"
                    role="tab"
                    aria-selected="<?php echo $isActive ? 'true' : 'false'; ?>">
              <?php echo iN_HelpSecure(strtoupper($langCode), false); ?>
            </button>
          <?php endforeach; ?>
        </div>

        <?php foreach ($langOptions as $idx => $langCode):
          $langSafe = iN_HelpSecure($langCode, false);
          $defaultPricingTitle = adminLandingDefaultValue($rawTranslations, $langCode, 'pricing_section_title');
          $defaultPricingSubtitle = adminLandingDefaultValue($rawTranslations, $langCode, 'pricing_section_description');
          $defaultPricingNote = adminLandingDefaultValue($rawTranslations, $langCode, 'pricing_note');
          $valPricingTitle = adminLandingFieldValue($pricingTextOverrides, $langCode, 'pricing_section_title');
          $valPricingSubtitle = adminLandingFieldValue($pricingTextOverrides, $langCode, 'pricing_section_description');
          $valPricingNote = adminLandingFieldValue($pricingTextOverrides, $langCode, 'pricing_note');
          $isActive = $idx === 0;
        ?>
          <div class="landing-lang-panel<?php echo $isActive ? ' is-active' : ''; ?>"
               data-lang-panel="pricing-<?php echo $langSafe; ?>"
               role="tabpanel"
               aria-hidden="<?php echo $isActive ? 'false' : 'true'; ?>"<?php echo $isActive ? '' : ' hidden'; ?>>
            <label class="form-label" for="pricing_section_title_<?php echo $langSafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_section_title_label') ?: 'Section Title', false); ?></label>
            <input id="pricing_section_title_<?php echo $langSafe; ?>" class="form-input" type="text" name="pricing_section_title[<?php echo $langSafe; ?>]" value="<?php echo iN_HelpSecure($valPricingTitle, false); ?>" maxlength="160" placeholder="<?php echo iN_HelpSecure($defaultPricingTitle, false); ?>">

            <label class="form-label" for="pricing_section_subtitle_<?php echo $langSafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_section_subtitle_label') ?: 'Section Subtitle', false); ?></label>
            <textarea id="pricing_section_subtitle_<?php echo $langSafe; ?>" class="form-input" name="pricing_section_subtitle[<?php echo $langSafe; ?>]" rows="3" maxlength="400" placeholder="<?php echo iN_HelpSecure($defaultPricingSubtitle, false); ?>"><?php echo iN_HelpSecure($valPricingSubtitle, false); ?></textarea>

            <label class="form-label" for="pricing_section_note_<?php echo $langSafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_section_note_label') ?: 'Footer note', false); ?></label>
            <textarea id="pricing_section_note_<?php echo $langSafe; ?>" class="form-input" name="pricing_section_note[<?php echo $langSafe; ?>]" rows="2" maxlength="400" placeholder="<?php echo iN_HelpSecure($defaultPricingNote, false); ?>"><?php echo iN_HelpSecure($valPricingNote, false); ?></textarea>
          </div>
        <?php endforeach; ?>
      </fieldset>

      <fieldset class="form-input-wrapper">
        <legend><?php echo iN_HelpSecure(customLang('admin_landing_pricing_section') ?: 'Earning Modes', false); ?></legend>
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_hint') ?: 'Drag to reorder cards. Leave a language field empty to use the theme’s default text.', false); ?></p>

        <div class="landing-feature-list" data-sortable-list="pricing">
          <?php foreach ($pricingRows as $rowKey => $plan):
            $planKey = iN_HelpSecure($rowKey, false);
            $badgeVal = iN_HelpSecure((string) ($plan['badge'] ?? ''), false);
            $ctaUrlVal = iN_HelpSecure((string) ($plan['cta_url'] ?? ''), false);
            $variantVal = (string) ($plan['variant'] ?? 'default');
            if (!in_array($variantVal, ['default', 'highlight', 'muted'], true)) { $variantVal = 'default'; }
            $featuresText = (string) ($plan['features_text'] ?? '');
            $translations = is_array($plan['translations'] ?? null) ? $plan['translations'] : [];
            $placeholderKeys = is_array($plan['placeholder_keys'] ?? null) ? $plan['placeholder_keys'] : [];
          ?>
          <div class="landing-feature-card" data-sortable-item data-row-key="<?php echo $planKey; ?>" draggable="true">
            <div class="landing-feature-controls">
              <span class="landing-drag-handle" aria-hidden="true">☰</span>
              <button type="button" class="landing-remove-row" data-remove-plan aria-label="<?php echo iN_HelpSecure(customLang('admin_remove_row') ?: 'Remove row', false); ?>">&times;</button>
            </div>
            <input type="hidden" name="plan_id[<?php echo $planKey; ?>]" value="<?php echo iN_HelpSecure((string) ($plan['id'] ?? 0), false); ?>">
            <div class="landing-feature-main">
              <?php
                $badgePlaceholder = '';
                if (!empty($placeholderKeys['badge'])) {
                    $badgePlaceholder = adminLandingDefaultValue($rawTranslations, 'eng', $placeholderKeys['badge']);
                }
                $badgeHintText = customLang('admin_landing_pricing_plan_badge_hint');
              ?>
              <label class="form-label" for="plan_badge_<?php echo $planKey; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_badge') ?: 'Badge label', false); ?></label>
              <input id="plan_badge_<?php echo $planKey; ?>" class="form-input" type="text" name="plan_badge[<?php echo $planKey; ?>]" value="<?php echo $badgeVal; ?>" maxlength="80" placeholder="<?php echo iN_HelpSecure($badgePlaceholder, false); ?>">
              <?php if (!empty($badgeHintText)): ?>
                <p class="form-text text-muted fs-12"><?php echo iN_HelpSecure($badgeHintText, false); ?></p>
              <?php endif; ?>

              <label class="form-checkbox">
                <input type="checkbox" name="plan_highlight[<?php echo $planKey; ?>]" value="1" <?php echo !empty($plan['highlight']) ? 'checked' : ''; ?>>
                <span><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_highlight') ?: 'Highlight plan', false); ?></span>
              </label>

              <label class="form-label" for="plan_variant_<?php echo $planKey; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_variant') ?: 'Card style', false); ?></label>
              <select id="plan_variant_<?php echo $planKey; ?>" class="form-input" name="plan_variant[<?php echo $planKey; ?>]">
                <option value="default"<?php echo $variantVal === 'default' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_landing_pricing_variant_default') ?: 'Standard', false); ?></option>
                <option value="highlight"<?php echo $variantVal === 'highlight' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_landing_pricing_variant_highlight') ?: 'Highlight (black)', false); ?></option>
                <option value="muted"<?php echo $variantVal === 'muted' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_landing_pricing_variant_muted') ?: 'Muted grey', false); ?></option>
              </select>

              <label class="form-label" for="plan_cta_url_<?php echo $planKey; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_cta_url') ?: 'CTA URL', false); ?></label>
              <input id="plan_cta_url_<?php echo $planKey; ?>" class="form-input" type="url" name="plan_cta_url[<?php echo $planKey; ?>]" value="<?php echo $ctaUrlVal; ?>" placeholder="https://">

              <label class="form-label" for="plan_features_<?php echo $planKey; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_features') ?: 'Feature list', false); ?></label>
              <?php
                $featuresPlaceholderLines = [];
                if (!empty($placeholderKeys['features']) && is_array($placeholderKeys['features'])) {
                    foreach ($placeholderKeys['features'] as $featureKey) {
                        $line = adminLandingDefaultValue($rawTranslations, 'eng', $featureKey);
                        if ($line !== '') { $featuresPlaceholderLines[] = $line; }
                    }
                }
                $featuresPlaceholderText = implode("\n", $featuresPlaceholderLines);
              ?>
              <textarea id="plan_features_<?php echo $planKey; ?>" class="form-input" name="plan_features[<?php echo $planKey; ?>]" rows="4" placeholder="<?php echo iN_HelpSecure($featuresPlaceholderText ?: customLang('admin_landing_pricing_plan_features_hint') ?: '', false); ?>"><?php echo iN_HelpSecure($featuresText, false); ?></textarea>
            </div>
            <div class="landing-feature-langs">
              <?php foreach ($langOptions as $langCode):
                $langKey = strtolower($langCode);
                $langSafe = iN_HelpSecure($langKey, false);
                $titleVal = iN_HelpSecure((string) ($translations[$langKey]['title'] ?? ''), false);
                $taglineVal = iN_HelpSecure((string) ($translations[$langKey]['tagline'] ?? ''), false);
                $descriptionVal = iN_HelpSecure((string) ($translations[$langKey]['description'] ?? ''), false);
                $ctaLabelVal = iN_HelpSecure((string) ($translations[$langKey]['cta_label'] ?? ''), false);
                $titlePlaceholder = !empty($placeholderKeys['title']) ? adminLandingDefaultValue($rawTranslations, $langCode, $placeholderKeys['title']) : '';
                $taglinePlaceholder = !empty($placeholderKeys['tagline']) ? adminLandingDefaultValue($rawTranslations, $langCode, $placeholderKeys['tagline']) : '';
                $descriptionPlaceholder = !empty($placeholderKeys['description']) ? adminLandingDefaultValue($rawTranslations, $langCode, $placeholderKeys['description']) : '';
                $ctaLabelPlaceholder = !empty($placeholderKeys['cta_label']) ? adminLandingDefaultValue($rawTranslations, $langCode, $placeholderKeys['cta_label']) : '';
              ?>
                <div class="landing-feature-lang-card">
                  <h4><?php echo iN_HelpSecure(strtoupper($langCode), false); ?></h4>
                  <label class="form-label" for="plan_title_<?php echo $langSafe . '_' . $planKey; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_title') ?: 'Plan title', false); ?></label>
                  <input id="plan_title_<?php echo $langSafe . '_' . $planKey; ?>" class="form-input" type="text" name="plan_title[<?php echo $langSafe; ?>][<?php echo $planKey; ?>]" value="<?php echo $titleVal; ?>" maxlength="160" placeholder="<?php echo iN_HelpSecure($titlePlaceholder, false); ?>">

                  <label class="form-label" for="plan_tagline_<?php echo $langSafe . '_' . $planKey; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_tagline') ?: 'Support line (under badge)', false); ?></label>
                  <input id="plan_tagline_<?php echo $langSafe . '_' . $planKey; ?>" class="form-input" type="text" name="plan_tagline[<?php echo $langSafe; ?>][<?php echo $planKey; ?>]" value="<?php echo $taglineVal; ?>" maxlength="160" placeholder="<?php echo iN_HelpSecure($taglinePlaceholder, false); ?>">

                  <label class="form-label" for="plan_description_<?php echo $langSafe . '_' . $planKey; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_description') ?: 'Description', false); ?></label>
                  <textarea id="plan_description_<?php echo $langSafe . '_' . $planKey; ?>" class="form-input" name="plan_description[<?php echo $langSafe; ?>][<?php echo $planKey; ?>]" rows="3" maxlength="420" placeholder="<?php echo iN_HelpSecure($descriptionPlaceholder, false); ?>"><?php echo $descriptionVal; ?></textarea>

                  <label class="form-label" for="plan_cta_label_<?php echo $langSafe . '_' . $planKey; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_cta_label') ?: 'CTA label', false); ?></label>
                  <input id="plan_cta_label_<?php echo $langSafe . '_' . $planKey; ?>" class="form-input" type="text" name="plan_cta_label[<?php echo $langSafe; ?>][<?php echo $planKey; ?>]" value="<?php echo $ctaLabelVal; ?>" maxlength="120" placeholder="<?php echo iN_HelpSecure($ctaLabelPlaceholder, false); ?>">
                </div>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <button type="button" class="btn-outline" data-action="add-pricing-plan"><?php echo iN_HelpSecure(customLang('admin_add_pricing_plan') ?: 'Add Mode', false); ?></button>

        <template id="pricingPlanTemplate">
          <?php $defaultPricingPlan = $pricingDefaultPlans[0]; ?>
          <div class="landing-feature-card" data-sortable-item data-row-key="__KEY__" draggable="true">
            <div class="landing-feature-controls">
              <span class="landing-drag-handle" aria-hidden="true">☰</span>
              <button type="button" class="landing-remove-row" data-remove-plan aria-label="<?php echo iN_HelpSecure(customLang('admin_remove_row') ?: 'Remove row', false); ?>">&times;</button>
            </div>
            <input type="hidden" name="plan_id[__KEY__]" value="0">
            <div class="landing-feature-main">
              <?php
                $defaultBadgePlaceholder = adminLandingDefaultValue($rawTranslations, 'eng', $defaultPricingPlan['badge_key']);
                $badgeHintText = customLang('admin_landing_pricing_plan_badge_hint');
              ?>
              <label class="form-label" for="plan_badge___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_badge') ?: 'Badge label', false); ?></label>
              <input id="plan_badge___KEY__" class="form-input" type="text" name="plan_badge[__KEY__]" value="" maxlength="80" placeholder="<?php echo iN_HelpSecure($defaultBadgePlaceholder, false); ?>">
              <?php if (!empty($badgeHintText)): ?>
                <p class="form-text text-muted fs-12"><?php echo iN_HelpSecure($badgeHintText, false); ?></p>
              <?php endif; ?>

              <label class="form-checkbox">
                <input type="checkbox" name="plan_highlight[__KEY__]" value="1">
                <span><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_highlight') ?: 'Highlight plan', false); ?></span>
              </label>

              <label class="form-label" for="plan_variant___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_variant') ?: 'Card style', false); ?></label>
              <select id="plan_variant___KEY__" class="form-input" name="plan_variant[__KEY__]">
                <option value="default"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_variant_default') ?: 'Standard', false); ?></option>
                <option value="highlight"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_variant_highlight') ?: 'Highlight (black)', false); ?></option>
                <option value="muted"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_variant_muted') ?: 'Muted grey', false); ?></option>
              </select>

              <label class="form-label" for="plan_cta_url___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_cta_url') ?: 'CTA URL', false); ?></label>
              <input id="plan_cta_url___KEY__" class="form-input" type="url" name="plan_cta_url[__KEY__]" value="" placeholder="https://">

              <?php
                $defaultFeaturePlaceholderLines = [];
                foreach ($defaultPricingPlan['features_keys'] as $featureKey) {
                    $line = adminLandingDefaultValue($rawTranslations, 'eng', $featureKey);
                    if ($line !== '') { $defaultFeaturePlaceholderLines[] = $line; }
                }
                $defaultFeaturePlaceholderText = implode("\n", $defaultFeaturePlaceholderLines);
              ?>
              <label class="form-label" for="plan_features___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_features') ?: 'Feature list', false); ?></label>
              <textarea id="plan_features___KEY__" class="form-input" name="plan_features[__KEY__]" rows="4" placeholder="<?php echo iN_HelpSecure($defaultFeaturePlaceholderText ?: customLang('admin_landing_pricing_plan_features_hint') ?: '', false); ?>"></textarea>
            </div>
            <div class="landing-feature-langs">
              <?php foreach ($langOptions as $langCode):
                $langKey = strtolower($langCode);
                $langSafe = iN_HelpSecure($langKey, false);
                $titlePlaceholder = adminLandingDefaultValue($rawTranslations, $langCode, $defaultPricingPlan['title_key']);
                $taglinePlaceholder = adminLandingDefaultValue($rawTranslations, $langCode, $defaultPricingPlan['tagline_key']);
                $descriptionPlaceholder = adminLandingDefaultValue($rawTranslations, $langCode, $defaultPricingPlan['description_key']);
                $ctaPlaceholder = adminLandingDefaultValue($rawTranslations, $langCode, $defaultPricingPlan['cta_label_key']);
              ?>
                <div class="landing-feature-lang-card">
                  <h4><?php echo iN_HelpSecure(strtoupper($langCode), false); ?></h4>
                  <label class="form-label" for="plan_title_<?php echo $langSafe; ?>___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_title') ?: 'Plan title', false); ?></label>
                  <input id="plan_title_<?php echo $langSafe; ?>___KEY__" class="form-input" type="text" name="plan_title[<?php echo $langSafe; ?>][__KEY__]" value="" maxlength="160" placeholder="<?php echo iN_HelpSecure($titlePlaceholder, false); ?>">

                  <label class="form-label" for="plan_tagline_<?php echo $langSafe; ?>___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_tagline') ?: 'Support line (under badge)', false); ?></label>
                  <input id="plan_tagline_<?php echo $langSafe; ?>___KEY__" class="form-input" type="text" name="plan_tagline[<?php echo $langSafe; ?>][__KEY__]" value="" maxlength="160" placeholder="<?php echo iN_HelpSecure($taglinePlaceholder, false); ?>">

                  <label class="form-label" for="plan_description_<?php echo $langSafe; ?>___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_description') ?: 'Description', false); ?></label>
                  <textarea id="plan_description_<?php echo $langSafe; ?>___KEY__" class="form-input" name="plan_description[<?php echo $langSafe; ?>][__KEY__]" rows="3" maxlength="420" placeholder="<?php echo iN_HelpSecure($descriptionPlaceholder, false); ?>"></textarea>

                  <label class="form-label" for="plan_cta_label_<?php echo $langSafe; ?>___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_pricing_plan_cta_label') ?: 'CTA label', false); ?></label>
                  <input id="plan_cta_label_<?php echo $langSafe; ?>___KEY__" class="form-input" type="text" name="plan_cta_label[<?php echo $langSafe; ?>][__KEY__]" value="" maxlength="120" placeholder="<?php echo iN_HelpSecure($ctaPlaceholder, false); ?>">
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        </template>
      </fieldset>

      <button type="submit" class="pe-save btn-hover"><?php echo iN_HelpSecure(customLang('admin_save_changes') ?: 'Save Changes', false); ?></button>
    </form>
  </div>

  <?php
    $earningsPriceValue = $formatNumberForInput($earningsSimulatorPrice, $currencyPrecision);
    $earningsConversionValue = $formatNumberForInput($earningsSimulatorConversionPercent, 2);
  ?>
  <div class="landing-section-panel" data-section-panel="earnings-simulator" role="tabpanel" aria-hidden="true" hidden>
    <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="save-landing-earnings-simulator">
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
      <input type="hidden" name="action" value="save_earnings_simulator">
      <input type="hidden" name="theme" value="<?php echo iN_HelpSecure($themeSlug, false); ?>">

      <fieldset class="form-input-wrapper">
        <legend><?php echo iN_HelpSecure(customLang('admin_landing_earnings_heading') ?: 'Earnings Simulator Defaults', false); ?></legend>
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_landing_earnings_hint') ?: 'Control the default follower count and subscription price used by the public earnings simulator.', false); ?></p>

        <label class="form-label" for="earnings_default_followers"><?php echo iN_HelpSecure(customLang('admin_landing_earnings_followers_label') ?: 'Default follower count', false); ?></label>
        <input id="earnings_default_followers"
               class="form-input"
               type="number"
               name="default_followers"
               min="0"
               max="1000000"
               step="50"
               value="<?php echo iN_HelpSecure((string) $earningsSimulatorFollowers, false); ?>"
               placeholder="<?php echo iN_HelpSecure(customLang('admin_landing_earnings_followers_placeholder') ?: '1000', false); ?>"
               aria-describedby="earnings_followers_help">
        <p class="form-text text-muted fs-12" id="earnings_followers_help"><?php echo iN_HelpSecure(customLang('admin_landing_earnings_followers_help') ?: 'Used as the starting point for the followers slider.', false); ?></p>

        <label class="form-label" for="earnings_default_price"><?php echo iN_HelpSecure(customLang('admin_landing_earnings_price_label') ?: 'Default subscription price', false); ?></label>
        <input id="earnings_default_price"
               class="form-input"
               type="number"
               name="default_price"
               min="1"
               max="1000"
               step="0.5"
               value="<?php echo iN_HelpSecure($earningsPriceValue, false); ?>"
               placeholder="<?php echo iN_HelpSecure(customLang('admin_landing_earnings_price_placeholder') ?: '10.00', false); ?>"
               aria-describedby="earnings_price_help">
        <p class="form-text text-muted fs-12" id="earnings_price_help"><?php echo iN_HelpSecure(customLang('admin_landing_earnings_price_help') ?: 'Applies to the price slider and result preview.', false); ?></p>

        <label class="form-label" for="earnings_conversion_rate"><?php echo iN_HelpSecure(customLang('admin_landing_earnings_conversion_label') ?: 'Conversion assumption (%)', false); ?></label>
        <input id="earnings_conversion_rate"
               class="form-input"
               type="number"
               name="conversion_rate"
               min="0"
               max="100"
               step="0.5"
               value="<?php echo iN_HelpSecure($earningsConversionValue, false); ?>"
               placeholder="<?php echo iN_HelpSecure(customLang('admin_landing_earnings_conversion_placeholder') ?: '20', false); ?>"
               aria-describedby="earnings_conversion_help">
        <p class="form-text text-muted fs-12" id="earnings_conversion_help"><?php echo iN_HelpSecure(customLang('admin_landing_earnings_conversion_help') ?: 'Estimated subscriber rate. Defaults to 20% if left blank.', false); ?></p>
      </fieldset>

      <button type="submit" class="pe-save btn-hover"><?php echo iN_HelpSecure(customLang('admin_save_changes') ?: 'Save Changes', false); ?></button>
    </form>
  </div>

  <div class="landing-section-panel" data-section-panel="no-hassle" role="tabpanel" aria-hidden="true" hidden>
    <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="save-landing-no-hassle">
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
      <input type="hidden" name="action" value="save_no_hassle">
      <input type="hidden" name="theme" value="<?php echo iN_HelpSecure($themeSlug, false); ?>">

      <fieldset class="form-input-wrapper">
        <legend><?php echo iN_HelpSecure(customLang('admin_landing_no_hassle_section') ?: 'No-hassle Lines', false); ?></legend>
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_landing_no_hassle_hint') ?: 'Control the text and marker color for each line. Drag to reorder items.', false); ?></p>

        <label class="form-label" for="no_hassle_ma_color"><?php echo iN_HelpSecure(customLang('admin_landing_no_hassle_default_color') ?: 'Default marker color', false); ?></label>
        <input id="no_hassle_ma_color" class="form-input" type="color" name="no_hassle_ma_color" value="<?php echo iN_HelpSecure($noHassleDefaultColor, false); ?>">

        <div class="landing-feature-list" data-sortable-list="no-hassle">
          <?php foreach ($noHassleRows as $rowKey => $entry):
            $rowKeySafe = iN_HelpSecure($rowKey, false);
            $iconValue = iN_HelpSecure((string) ($entry['icon'] ?? ''), false);
            $colorValue = iN_HelpSecure((string) ($entry['color'] ?? $noHassleDefaultColor), false);
            $typeValue = (string) ($entry['type'] ?? 'feature');
            $itemId = (int) ($entry['id'] ?? 0);
            $translations = isset($entry['translations']) && is_array($entry['translations']) ? $entry['translations'] : [];
          ?>
            <div class="landing-feature-card" data-sortable-item data-row-key="<?php echo $rowKeySafe; ?>" draggable="true">
              <div class="landing-feature-controls">
                <span class="landing-drag-handle" aria-hidden="true">☰</span>
                <button type="button" class="landing-remove-row" data-remove-no-hassle aria-label="<?php echo iN_HelpSecure(customLang('admin_remove_row') ?: 'Remove row', false); ?>">&times;</button>
              </div>
              <input type="hidden" name="no_hassle_id[<?php echo $rowKeySafe; ?>]" value="<?php echo $itemId; ?>">
              <div class="landing-feature-main">
                <label class="form-label" for="no_hassle_icon_<?php echo $rowKeySafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_no_hassle_icon') ?: 'Icon (optional)', false); ?></label>
                <input id="no_hassle_icon_<?php echo $rowKeySafe; ?>" class="form-input" type="text" name="no_hassle_icon[<?php echo $rowKeySafe; ?>]" value="<?php echo $iconValue; ?>" maxlength="200" placeholder="<?php echo iN_HelpSecure(customLang('admin_placeholder_no_hassle_icon') ?: 'e.g. verified (icon key) or uploads/icons/custom.svg', false); ?>">

                <label class="form-label" for="no_hassle_color_<?php echo $rowKeySafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_no_hassle_color') ?: 'Marker color', false); ?></label>
                <input id="no_hassle_color_<?php echo $rowKeySafe; ?>" class="form-input" type="color" name="no_hassle_color[<?php echo $rowKeySafe; ?>]" value="<?php echo $colorValue; ?>">

                <label class="form-label" for="no_hassle_type_<?php echo $rowKeySafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_no_hassle_type') ?: 'Display style', false); ?></label>
                <select id="no_hassle_type_<?php echo $rowKeySafe; ?>" class="form-input" name="no_hassle_type[<?php echo $rowKeySafe; ?>]">
                  <option value="feature"<?php echo $typeValue === 'feature' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_landing_no_hassle_type_feature') ?: 'Feature line', false); ?></option>
                  <option value="badge"<?php echo $typeValue === 'badge' ? ' selected' : ''; ?>><?php echo iN_HelpSecure(customLang('admin_landing_no_hassle_type_badge') ?: 'Badge', false); ?></option>
                </select>
              </div>
              <div class="landing-feature-langs">
                <?php foreach ($langOptions as $langCode):
                  $langKey = strtolower($langCode);
                  $langSafe = iN_HelpSecure($langKey, false);
                  $labelVal = iN_HelpSecure((string) ($translations[$langKey]['label'] ?? ''), false);
                ?>
                  <div class="landing-feature-lang-card">
                    <h4><?php echo iN_HelpSecure(strtoupper($langCode), false); ?></h4>
                    <label class="form-label" for="no_hassle_label_<?php echo $langSafe . '_' . $rowKeySafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_no_hassle_label') ?: 'Label', false); ?></label>
                    <input id="no_hassle_label_<?php echo $langSafe . '_' . $rowKeySafe; ?>" class="form-input" type="text" name="no_hassle_label[<?php echo $langSafe; ?>][<?php echo $rowKeySafe; ?>]" value="<?php echo $labelVal; ?>" maxlength="180" placeholder="<?php echo iN_HelpSecure(customLang('admin_placeholder_no_hassle_label') ?: 'Enter label', false); ?>">
                  </div>
                <?php endforeach; ?>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </fieldset>

      <button type="button" class="btn-outline" data-action="add-no-hassle-item"><?php echo iN_HelpSecure(customLang('admin_add_no_hassle_item') ?: 'Add line', false); ?></button>

      <template id="noHassleItemTemplate">
        <div class="landing-feature-card" data-sortable-item data-row-key="__KEY__" draggable="true">
          <div class="landing-feature-controls">
            <span class="landing-drag-handle" aria-hidden="true">☰</span>
            <button type="button" class="landing-remove-row" data-remove-no-hassle aria-label="<?php echo iN_HelpSecure(customLang('admin_remove_row') ?: 'Remove row', false); ?>">&times;</button>
          </div>
          <input type="hidden" name="no_hassle_id[__KEY__]" value="0">
          <div class="landing-feature-main">
            <label class="form-label" for="no_hassle_icon___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_no_hassle_icon') ?: 'Icon (optional)', false); ?></label>
            <input id="no_hassle_icon___KEY__" class="form-input" type="text" name="no_hassle_icon[__KEY__]" value="" maxlength="200" placeholder="<?php echo iN_HelpSecure(customLang('admin_placeholder_no_hassle_icon') ?: 'e.g. verified (icon key) or uploads/icons/custom.svg', false); ?>">

            <label class="form-label" for="no_hassle_color___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_no_hassle_color') ?: 'Marker color', false); ?></label>
            <input id="no_hassle_color___KEY__" class="form-input" type="color" name="no_hassle_color[__KEY__]" value="<?php echo iN_HelpSecure($noHassleDefaultColor, false); ?>">

            <label class="form-label" for="no_hassle_type___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_no_hassle_type') ?: 'Display style', false); ?></label>
            <select id="no_hassle_type___KEY__" class="form-input" name="no_hassle_type[__KEY__]">
              <option value="feature"><?php echo iN_HelpSecure(customLang('admin_landing_no_hassle_type_feature') ?: 'Feature line', false); ?></option>
              <option value="badge"><?php echo iN_HelpSecure(customLang('admin_landing_no_hassle_type_badge') ?: 'Badge', false); ?></option>
            </select>
          </div>
          <div class="landing-feature-langs">
            <?php foreach ($langOptions as $langCode):
              $langKey = strtolower($langCode);
              $langSafe = iN_HelpSecure($langKey, false);
            ?>
              <div class="landing-feature-lang-card">
                <h4><?php echo iN_HelpSecure(strtoupper($langCode), false); ?></h4>
                <label class="form-label" for="no_hassle_label_<?php echo $langSafe; ?>___KEY__"><?php echo iN_HelpSecure(customLang('admin_landing_no_hassle_label') ?: 'Label', false); ?></label>
                <input id="no_hassle_label_<?php echo $langSafe; ?>___KEY__" class="form-input" type="text" name="no_hassle_label[<?php echo $langSafe; ?>][__KEY__]" value="" maxlength="180" placeholder="<?php echo iN_HelpSecure(customLang('admin_placeholder_no_hassle_label') ?: 'Enter label', false); ?>">
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </template>

      <button type="submit" class="pe-save btn-hover"><?php echo iN_HelpSecure(customLang('admin_save_changes') ?: 'Save Changes', false); ?></button>
    </form>
  </div>

  <div class="landing-section-panel" data-section-panel="get-started" role="tabpanel" aria-hidden="true" hidden>
    <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="save-landing-get-started">
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
      <input type="hidden" name="action" value="save_get_started">
      <input type="hidden" name="theme" value="<?php echo iN_HelpSecure($themeSlug, false); ?>">
      <input type="hidden" name="get_started_item_id" value="<?php echo iN_HelpSecure((string) $getStartedItemId, false); ?>">

      <fieldset class="form-input-wrapper">
        <legend><?php echo iN_HelpSecure(customLang('admin_landing_get_started_section') ?: 'Get Started CTA', false); ?></legend>
        <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_landing_get_started_hint') ?: 'Customize the headline, supporting copy, and button for the landing page call-to-action.', false); ?></p>

        <label class="form-label" for="get_started_color"><?php echo iN_HelpSecure(customLang('admin_landing_get_started_color') ?: 'Accent colour', false); ?></label>
        <div class="landing-color-picker">
          <input id="get_started_color" class="landing-color-input" type="color" name="data_ma_color" value="<?php echo iN_HelpSecure($getStartedColor, false); ?>">
          <span class="form-helper"><?php echo iN_HelpSecure(customLang('admin_landing_get_started_color_hint') ?: 'Controls the marker animation colour.', false); ?></span>
        </div>
      </fieldset>

      <div class="landing-get-started-grid">
        <?php foreach ($getStartedRows as $langCode => $row):
          $langKey = strtolower((string) $langCode);
          $langSafe = iN_HelpSecure($langKey, false);
          $titleVal = iN_HelpSecure($row['title'], false);
          $descVal = iN_HelpSecure($row['desc'], false);
          $buttonVal = iN_HelpSecure($row['button'], false);
          $placeholderTitle = iN_HelpSecure($row['default_title'], false);
          $placeholderDesc = iN_HelpSecure($row['default_desc'], false);
          $placeholderButton = iN_HelpSecure($row['default_button'], false);
        ?>
          <div class="landing-feature-lang-card landing-get-started-card">
            <h4><?php echo iN_HelpSecure(strtoupper((string) $langCode), false); ?></h4>

            <label class="form-label" for="get_started_title_<?php echo $langSafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_get_started_title') ?: 'Heading', false); ?></label>
            <input id="get_started_title_<?php echo $langSafe; ?>" class="form-input" type="text" name="get_started_title[<?php echo $langSafe; ?>]" value="<?php echo $titleVal; ?>" maxlength="200" placeholder="<?php echo $placeholderTitle; ?>">

            <label class="form-label" for="get_started_desc_<?php echo $langSafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_get_started_desc') ?: 'Subheading', false); ?></label>
            <textarea id="get_started_desc_<?php echo $langSafe; ?>" class="form-input" name="get_started_desc[<?php echo $langSafe; ?>]" rows="3" maxlength="600" placeholder="<?php echo $placeholderDesc; ?>"><?php echo $descVal; ?></textarea>

            <label class="form-label" for="get_started_button_<?php echo $langSafe; ?>"><?php echo iN_HelpSecure(customLang('admin_landing_get_started_button') ?: 'Button label', false); ?></label>
            <input id="get_started_button_<?php echo $langSafe; ?>" class="form-input" type="text" name="get_started_button[<?php echo $langSafe; ?>]" value="<?php echo $buttonVal; ?>" maxlength="100" placeholder="<?php echo $placeholderButton; ?>">
          </div>
        <?php endforeach; ?>
      </div>

      <button type="submit" class="pe-save btn-hover"><?php echo iN_HelpSecure(customLang('admin_save_changes') ?: 'Save Changes', false); ?></button>
    </form>
  </div>
</section>
