<?php
declare(strict_types=1);
require_once __DIR__ . '/../../_bootstrap.php';

global $siteData, $base_url, $ADMIN_CSRF;

$boolConfig = static function ($value, bool $default = true): bool {
    if ($value === null) {
        return $default;
    }
    if (is_bool($value)) {
        return $value;
    }
    $normalized = strtolower(trim((string)$value));
    if ($normalized === '') {
        return $default;
    }
    return in_array($normalized, ['1', 'true', 'yes', 'on', 'enabled'], true);
};

$ebooksEnabled = $boolConfig($siteData['ebooks_enabled'] ?? null, true);
$ebookCreatorUploadsEnabled = $boolConfig($siteData['ebook_creator_uploads_enabled'] ?? null, true);
$ebookMinPrice = max(0, (float)($siteData['ebook_min_price'] ?? 0));
$ebookMaxPrice = max($ebookMinPrice, (float)($siteData['ebook_max_price'] ?? 500));
$ebookMaxFileMb = max(1, (int)($siteData['ebook_max_file_mb'] ?? 120));
$ebookDownloadLimit = max(0, (int)($siteData['ebook_download_limit'] ?? 5));
$ebookAccessDays = max(0, (int)($siteData['ebook_access_days'] ?? 0));
$actionUrl = iN_HelpSecure($base_url . 'admin/request/ebook_settings.php', false);
$csrfToken = iN_HelpSecure($ADMIN_CSRF, false);
$pageTitleText = customLang('admin_ebooks_settings_title') ?: 'eBook Settings';
$pageIntroText = customLang('admin_ebooks_settings_intro') ?: 'Control the eBook store, creator uploads, and public navigation entry points.';
?>

<div class="admin-ebook-settings-page" data-page-title="<?php echo iN_HelpSecure($pageTitleText, false); ?>">
  <section class="card rounded-2xl admin-settings admin-ebook-settings-shell" role="region" aria-labelledby="adminEbookSettingsHeading">
    <div class="list-header admin-ebook-settings-header">
      <span class="icon"><?php echo render_icon('ebook', true); ?></span>
      <span>
        <strong id="adminEbookSettingsHeading"><?php echo iN_HelpSecure($pageTitleText, false); ?></strong>
        <small><?php echo iN_HelpSecure($pageIntroText, false); ?></small>
      </span>
    </div>

    <form class="admin-ebook-settings-form" method="post" action="<?php echo $actionUrl; ?>" data-action="save-live-settings">
      <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
      <input type="hidden" name="ebook_settings_action" value="settings">

      <div class="admin-ebook-settings-grid" aria-label="<?php echo iN_HelpSecure(customLang('admin_menu_ebooks') ?: 'eBooks', false); ?>">
        <div class="admin-ebook-toggle-card">
          <div>
            <label class="admin-ebook-setting-label" for="ebooks_enabled"><?php echo iN_HelpSecure(customLang('admin_ebooks_enabled') ?: 'Enable eBook store', false); ?></label>
            <p><?php echo iN_HelpSecure(customLang('admin_ebooks_enabled_hint') ?: 'Shows the eBooks link in the left menu and allows users to browse, buy, and download eBooks.', false); ?></p>
          </div>
          <div class="admin-ebook-toggle-row">
            <label class="el-switch el-switch-sm margin-bottom-zero" aria-label="<?php echo iN_HelpSecure(customLang('admin_ebooks_enabled') ?: 'Enable eBook store', false); ?>">
              <input type="hidden" name="ebooks_enabled" value="0">
              <input type="checkbox" id="ebooks_enabled" name="ebooks_enabled" value="1" <?php echo $ebooksEnabled ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
            <span><?php echo iN_HelpSecure($ebooksEnabled ? (customLang('admin_ebooks_status_on') ?: 'eBooks are visible.') : (customLang('admin_ebooks_status_off') ?: 'eBooks are hidden.'), false); ?></span>
          </div>
        </div>

        <div class="admin-ebook-toggle-card">
          <div>
            <label class="admin-ebook-setting-label" for="ebook_creator_uploads_enabled"><?php echo iN_HelpSecure(customLang('admin_ebook_creator_uploads_enabled') ?: 'Allow creator uploads', false); ?></label>
            <p><?php echo iN_HelpSecure(customLang('admin_ebook_creator_uploads_hint') ?: 'When disabled, the store remains visible but approved creators cannot add new eBooks.', false); ?></p>
          </div>
          <div class="admin-ebook-toggle-row">
            <label class="el-switch el-switch-sm margin-bottom-zero" aria-label="<?php echo iN_HelpSecure(customLang('admin_ebook_creator_uploads_enabled') ?: 'Allow creator uploads', false); ?>">
              <input type="hidden" name="ebook_creator_uploads_enabled" value="0">
              <input type="checkbox" id="ebook_creator_uploads_enabled" name="ebook_creator_uploads_enabled" value="1" <?php echo $ebookCreatorUploadsEnabled ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
            <span><?php echo iN_HelpSecure($ebookCreatorUploadsEnabled ? (customLang('admin_ebook_uploads_status_on') ?: 'Creators can publish eBooks.') : (customLang('admin_ebook_uploads_status_off') ?: 'Creator publishing is disabled.'), false); ?></span>
          </div>
        </div>
      </div>

      <div class="admin-ebook-settings-panel" aria-labelledby="adminEbookLimitsHeading">
        <div class="admin-ebook-settings-panel__head">
          <div>
            <h2 id="adminEbookLimitsHeading"><?php echo iN_HelpSecure(customLang('admin_ebook_limits_title') ?: 'Publishing and download limits', false); ?></h2>
            <p><?php echo iN_HelpSecure(customLang('admin_ebook_limits_intro') ?: 'Set pricing, file size, access and download rules for creator eBooks.', false); ?></p>
          </div>
          <a class="admin-ebook-link-button" href="<?php echo iN_HelpSecure($base_url . 'admin/index.php?page=ebook_languages', false); ?>">
            <?php echo render_icon('ebook', true); ?>
            <span><?php echo iN_HelpSecure(customLang('admin_ebook_languages_manage') ?: 'Manage content languages', false); ?></span>
          </a>
        </div>

        <div class="admin-ebook-limits-grid">
          <label class="admin-ebook-setting-field" for="ebook_min_price">
            <span><?php echo iN_HelpSecure(customLang('admin_ebook_minimum_price') ?: 'Minimum price', false); ?></span>
            <input id="ebook_min_price" type="number" name="ebook_min_price" min="0" step="0.01" value="<?php echo iN_HelpSecure(number_format($ebookMinPrice, 2, '.', '')); ?>">
          </label>
          <label class="admin-ebook-setting-field" for="ebook_max_price">
            <span><?php echo iN_HelpSecure(customLang('admin_ebook_maximum_price') ?: 'Maximum price', false); ?></span>
            <input id="ebook_max_price" type="number" name="ebook_max_price" min="0" step="0.01" value="<?php echo iN_HelpSecure(number_format($ebookMaxPrice, 2, '.', '')); ?>">
          </label>
          <label class="admin-ebook-setting-field" for="ebook_max_file_mb">
            <span><?php echo iN_HelpSecure(customLang('admin_ebook_max_file_size') ?: 'Maximum file size (MB)', false); ?></span>
            <input id="ebook_max_file_mb" type="number" name="ebook_max_file_mb" min="1" max="2048" value="<?php echo $ebookMaxFileMb; ?>">
          </label>
          <label class="admin-ebook-setting-field" for="ebook_download_limit">
            <span><?php echo iN_HelpSecure(customLang('admin_ebook_download_limit') ?: 'Downloads per purchase', false); ?></span>
            <input id="ebook_download_limit" type="number" name="ebook_download_limit" min="0" max="1000" value="<?php echo $ebookDownloadLimit; ?>">
            <small><?php echo iN_HelpSecure(customLang('admin_ebook_zero_unlimited') ?: 'Use 0 for unlimited.', false); ?></small>
          </label>
          <label class="admin-ebook-setting-field" for="ebook_access_days">
            <span><?php echo iN_HelpSecure(customLang('admin_ebook_access_days') ?: 'Access duration in days', false); ?></span>
            <input id="ebook_access_days" type="number" name="ebook_access_days" min="0" max="36500" value="<?php echo $ebookAccessDays; ?>">
            <small><?php echo iN_HelpSecure(customLang('admin_ebook_zero_lifetime') ?: 'Use 0 for lifetime access.', false); ?></small>
          </label>
        </div>
      </div>

      <div class="admin-ebook-settings-actions">
        <button type="submit" class="admin-button admin-button--primary"><?php echo iN_HelpSecure(customLang('admin_save_changes') ?: 'Save changes', false); ?></button>
        <a class="admin-button admin-button--soft" href="<?php echo iN_HelpSecure($base_url . 'admin/index.php?page=ebook_languages', false); ?>"><?php echo iN_HelpSecure(customLang('admin_ebook_languages_title') ?: 'eBook content languages', false); ?></a>
        <a class="admin-button admin-button--neutral" href="<?php echo iN_HelpSecure($base_url . 'ebooks', false); ?>" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('admin_ebooks_open_store') ?: 'Open Store', false); ?></a>
      </div>
    </form>
  </section>
</div>
