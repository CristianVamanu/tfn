<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';
require_once __DIR__ . '/storage_helpers.php';

global $siteData, $base_url, $ADMIN_CSRF;

$storageSettings = admin_storage_settings($siteData);
$s3Config = admin_storage_provider($storageSettings, 's3');

$enabled = admin_storage_bool($s3Config['enabled'] ?? null, false);
$isDefault = ($storageSettings['driver'] ?? 'local') === 's3';
$visibility = admin_storage_visibility($s3Config['default_visibility'] ?? 'private', 'private');
$publicBase = (string) ($s3Config['public_base_url'] ?? '');
$region = (string) ($s3Config['region'] ?? '');
$bucket = (string) ($s3Config['bucket'] ?? '');
$prefix = (string) ($s3Config['prefix'] ?? '');
$endpoint = (string) ($s3Config['endpoint'] ?? '');
$pathStyle = admin_storage_bool($s3Config['path_style'] ?? null, false);
$deferNetwork = admin_storage_bool($s3Config['defer_network'] ?? null, false);
$ttl = isset($s3Config['default_presign_ttl']) ? (int) $s3Config['default_presign_ttl'] : 3600;
$rawAccessKey = storage_decrypt_secret($s3Config['access_key'] ?? '');
$rawSecretKey = storage_decrypt_secret($s3Config['secret_key'] ?? '');
$rawSessionToken = storage_decrypt_secret($s3Config['session_token'] ?? '');
$maskedAccessKey = admin_storage_mask_secret($rawAccessKey);
$maskedSecretKey = admin_storage_mask_secret($rawSecretKey);
$hasAccessKey = $rawAccessKey !== '';
$hasSecretKey = $rawSecretKey !== '';
$hasSessionToken = $rawSessionToken !== '';
$keepLocalCopy = admin_storage_bool($s3Config['keep_local_copy'] ?? null, true);
$syncMode = admin_storage_sync_mode($s3Config, 'manual');

$actionUrl = iN_HelpSecure($base_url . 'admin/request/storage_settings.php', false);
$csrfToken = iN_HelpSecure($ADMIN_CSRF, false);
?>

<section class="card rounded-2xl admin-settings" role="region" aria-labelledby="adminStorageS3Heading">
  <h1 id="adminStorageS3Heading"><?php echo iN_HelpSecure(customLang('storage_heading_s3') ?: 'Storage · Amazon S3'); ?></h1>
  <p class="box-note full-width"><?php echo iN_HelpSecure(customLang('storage_intro_s3') ?: 'Connect Amazon S3 buckets for storing media remotely.'); ?></p>

  <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="storage-settings" data-storage-provider="s3">
    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
    <input type="hidden" name="provider" value="s3">
    <input type="hidden" name="action" value="save">

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('storage_section_status') ?: 'Provider Status'); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="s3_enable_provider"><?php echo iN_HelpSecure(customLang('storage_toggle_enable') ?: 'Enable provider'); ?></label>
          <div class="flex align_items column-gap">
            <input type="hidden" name="enable_provider" value="0">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_toggle_enable') ?: 'Enable provider'); ?>">
              <input id="s3_enable_provider" type="checkbox" name="enable_provider" value="1" <?php echo $enabled ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_toggle_enable_hint_s3') ?: 'Store new uploads in your configured S3 bucket.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="s3_set_default"><?php echo iN_HelpSecure(customLang('storage_toggle_default') ?: 'Set as default storage'); ?></label>
          <div class="flex align_items column-gap">
            <input type="hidden" name="set_default" value="0">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_toggle_default') ?: 'Set as default storage'); ?>">
              <input id="s3_set_default" type="checkbox" name="set_default" value="1" <?php echo $isDefault ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_toggle_default_hint_s3') ?: 'Activates S3 for all new uploads.'); ?></small>
        </div>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('storage_section_credentials') ?: 'Credentials'); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="s3_access_key"><?php echo iN_HelpSecure(customLang('storage_field_access_key') ?: 'Access key ID'); ?></label>
          <input id="s3_access_key" class="form-input" type="password" name="access_key" placeholder="AKIA..." autocomplete="off">
          <small class="form-text text-muted">
            <?php echo iN_HelpSecure(customLang('storage_field_access_key_hint') ?: 'Leave blank to keep the stored key.'); ?>
            <?php if ($maskedAccessKey !== ''): ?>
              <span class="text-muted"><?php echo iN_HelpSecure(customLang('storage_field_current_value') ?: 'Current:' ); ?> <?php echo $maskedAccessKey; ?></span>
            <?php endif; ?>
          </small>
          <?php if ($hasAccessKey): ?>
            <label class="form-checkbox">
              <input type="checkbox" name="access_key_clear" value="1">
              <span><?php echo iN_HelpSecure(customLang('storage_field_clear_value') ?: 'Clear stored value'); ?></span>
            </label>
          <?php endif; ?>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="s3_secret_key"><?php echo iN_HelpSecure(customLang('storage_field_secret_key') ?: 'Secret access key'); ?></label>
          <input id="s3_secret_key" class="form-input" type="password" name="secret_key" placeholder="Secret" autocomplete="off">
          <small class="form-text text-muted">
            <?php echo iN_HelpSecure(customLang('storage_field_secret_key_hint') ?: 'Leave blank to keep the stored secret.'); ?>
            <?php if ($maskedSecretKey !== ''): ?>
              <span class="text-muted"><?php echo iN_HelpSecure(customLang('storage_field_current_value') ?: 'Current:' ); ?> <?php echo $maskedSecretKey; ?></span>
            <?php endif; ?>
          </small>
          <?php if ($hasSecretKey): ?>
            <label class="form-checkbox">
              <input type="checkbox" name="secret_key_clear" value="1">
              <span><?php echo iN_HelpSecure(customLang('storage_field_clear_value') ?: 'Clear stored value'); ?></span>
            </label>
          <?php endif; ?>
        </div>
      </div>
      <div class="form-input-wrapper">
        <label class="form-label" for="s3_session_token"><?php echo iN_HelpSecure(customLang('storage_field_session_token') ?: 'Session token (optional)'); ?></label>
        <input id="s3_session_token" class="form-input" type="password" name="session_token" placeholder="Optional temporary session token" autocomplete="off">
        <small class="form-text text-muted">
          <?php echo iN_HelpSecure(customLang('storage_field_session_token_hint') ?: 'Required only for temporary credentials (STS/IAM roles). Leave blank to keep existing.'); ?>
          <?php if ($hasSessionToken): ?>
            <span class="text-muted"><?php echo iN_HelpSecure(customLang('storage_field_current_value') ?: 'Current:' ); ?> <?php echo admin_storage_mask_secret($rawSessionToken); ?></span>
          <?php endif; ?>
        </small>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('storage_section_bucket') ?: 'Bucket & Region'); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="s3_region"><?php echo iN_HelpSecure(customLang('storage_field_region') ?: 'Region'); ?></label>
          <input id="s3_region" class="form-input" type="text" name="region" value="<?php echo iN_HelpSecure($region, false); ?>" placeholder="us-east-1" autocomplete="off">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_region_hint') ?: 'Match the AWS region of your bucket.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="s3_bucket"><?php echo iN_HelpSecure(customLang('storage_field_bucket') ?: 'Bucket name'); ?></label>
          <input id="s3_bucket" class="form-input" type="text" name="bucket" value="<?php echo iN_HelpSecure($bucket, false); ?>" placeholder="my-reels-bucket" autocomplete="off">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_bucket_hint') ?: 'Objects will be stored under this bucket.'); ?></small>
        </div>
      </div>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="s3_prefix"><?php echo iN_HelpSecure(customLang('storage_field_prefix') ?: 'Key prefix (optional)'); ?></label>
          <input id="s3_prefix" class="form-input" type="text" name="prefix" value="<?php echo iN_HelpSecure($prefix, false); ?>" placeholder="media/uploads">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_prefix_hint') ?: 'Automatically prepended to every stored object key.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="s3_endpoint"><?php echo iN_HelpSecure(customLang('storage_field_endpoint') ?: 'Custom endpoint (optional)'); ?></label>
          <input id="s3_endpoint" class="form-input" type="url" name="endpoint" value="<?php echo iN_HelpSecure($endpoint, false); ?>" placeholder="https://s3.amazonaws.com">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_endpoint_hint') ?: 'Override for S3-compatible endpoints. Leave blank for AWS default.'); ?></small>
        </div>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('storage_section_delivery') ?: 'Delivery & URLs'); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="s3_public_base"><?php echo iN_HelpSecure(customLang('storage_field_public_base_url') ?: 'Base URL / CDN'); ?></label>
          <input id="s3_public_base" class="form-input" type="url" name="public_base_url" value="<?php echo iN_HelpSecure($publicBase, false); ?>" placeholder="https://cdn.example.com/">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_public_base_url_hint_remote') ?: 'Optional CDN or CloudFront domain. Leave blank to use bucket URL.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="s3_visibility"><?php echo iN_HelpSecure(customLang('storage_field_visibility') ?: 'Default visibility'); ?></label>
          <select id="s3_visibility" class="form-input" name="default_visibility">
            <option value="public" <?php echo $visibility === 'public' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('storage_visibility_public') ?: 'Public'); ?></option>
            <option value="private" <?php echo $visibility === 'private' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('storage_visibility_private') ?: 'Private'); ?></option>
          </select>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_visibility_hint_remote') ?: 'Private assets require signed URLs. Public objects are accessible directly.'); ?></small>
        </div>
      </div>

      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="s3_presign_ttl"><?php echo iN_HelpSecure(customLang('storage_field_presign_ttl') ?: 'Signed URL TTL (seconds)'); ?></label>
          <input id="s3_presign_ttl" class="form-input" type="number" name="default_presign_ttl" value="<?php echo iN_HelpSecure((string) $ttl, false); ?>" min="60" max="604800">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_presign_ttl_hint') ?: 'Used when generating signed URLs for private objects.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="s3_path_style"><?php echo iN_HelpSecure(customLang('storage_field_path_style') ?: 'Force path-style URLs'); ?></label>
          <div class="flex align_items column-gap">
            <input type="hidden" name="path_style" value="0">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_field_path_style') ?: 'Force path-style URLs'); ?>">
              <input id="s3_path_style" type="checkbox" name="path_style" value="1" <?php echo $pathStyle ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_path_style_hint') ?: 'Enable for legacy buckets or custom endpoints without virtual-host support.'); ?></small>
        </div>
      </div>

      <div class="form-input-wrapper">
        <label class="form-label" for="s3_defer_network"><?php echo iN_HelpSecure(customLang('storage_field_defer_network') ?: 'Defer network calls (dry-run mode)'); ?></label>
        <div class="flex align_items column-gap">
          <input type="hidden" name="defer_network" value="0">
          <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_field_defer_network') ?: 'Defer network calls (dry-run mode)'); ?>">
            <input id="s3_defer_network" type="checkbox" name="defer_network" value="1" <?php echo $deferNetwork ? 'checked' : ''; ?>>
            <span class="el-switch-style"></span>
          </label>
        </div>
        <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_defer_network_hint') ?: 'Keep enabled on development servers without outbound access.'); ?></small>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('storage_section_migration') ?: 'Migration & Fallback'); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="s3_keep_local_copy"><?php echo iN_HelpSecure(customLang('storage_field_keep_local_copy') ?: 'Keep local copies'); ?></label>
          <div class="flex align_items column-gap">
            <input type="hidden" name="keep_local_copy" value="0">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_field_keep_local_copy') ?: 'Keep local copies'); ?>">
              <input id="s3_keep_local_copy" type="checkbox" name="keep_local_copy" value="1" <?php echo $keepLocalCopy ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_keep_local_copy_hint') ?: 'Mirror new uploads under /uploads for rollback and CDN failover.'); ?></small>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="s3_sync_mode"><?php echo iN_HelpSecure(customLang('storage_field_sync_mode') ?: 'Sync mode'); ?></label>
          <select id="s3_sync_mode" class="form-input" name="sync_mode">
            <option value="manual" <?php echo $syncMode === 'manual' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('storage_field_sync_mode_manual') ?: 'Manual (CLI / cron)'); ?></option>
            <option value="background" <?php echo $syncMode === 'background' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('storage_field_sync_mode_background') ?: 'Background worker'); ?></option>
          </select>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_sync_mode_hint') ?: 'Manual mode uses the storage_sync CLI stub; background mode assumes an external worker will call the admin endpoint.'); ?></small>
        </div>
      </div>
    </fieldset>

    <div class="form-actions flex align_items column-gap">
      <button type="submit" class="admin-button admin-button--primary" data-role="storage-save">
        <?php echo iN_HelpSecure(customLang('storage_button_save') ?: 'Save changes'); ?>
      </button>
      <button type="button" class="admin-button admin-button--ghost" data-action="storage-test" data-storage-provider="s3">
        <?php echo iN_HelpSecure(customLang('storage_button_test') ?: 'Test connection'); ?>
      </button>
    </div>
  </form>
</section>
