<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';
require_once __DIR__ . '/storage_helpers.php';

global $siteData, $base_url, $ADMIN_CSRF;

$storageSettings = admin_storage_settings($siteData);
$spacesConfig = admin_storage_provider($storageSettings, 'do_spaces');

$enabled = admin_storage_bool($spacesConfig['enabled'] ?? null, false);
$isDefault = ($storageSettings['driver'] ?? 'local') === 'do_spaces';
$visibility = admin_storage_visibility($spacesConfig['default_visibility'] ?? 'private', 'private');
$publicBase = (string) ($spacesConfig['public_base_url'] ?? '');
$region = (string) ($spacesConfig['region'] ?? ($spacesConfig['space_region'] ?? ''));
$spaceName = (string) ($spacesConfig['bucket'] ?? ($spacesConfig['space_name'] ?? ''));
$prefix = (string) ($spacesConfig['prefix'] ?? '');
$endpoint = (string) ($spacesConfig['endpoint'] ?? '');
$pathStyle = admin_storage_bool($spacesConfig['path_style'] ?? null, false);
$deferNetwork = admin_storage_bool($spacesConfig['defer_network'] ?? null, false);
$ttl = isset($spacesConfig['default_presign_ttl']) ? (int) $spacesConfig['default_presign_ttl'] : 3600;
$rawKey = storage_decrypt_secret($spacesConfig['access_key'] ?? '');
$rawSecret = storage_decrypt_secret($spacesConfig['secret_key'] ?? '');
$maskedKey = admin_storage_mask_secret($rawKey);
$maskedSecret = admin_storage_mask_secret($rawSecret);
$hasKey = $rawKey !== '';
$hasSecret = $rawSecret !== '';
$cdnDomain = (string) ($spacesConfig['cdn_domain'] ?? '');
$keepLocalCopy = admin_storage_bool($spacesConfig['keep_local_copy'] ?? null, true);
$syncMode = admin_storage_sync_mode($spacesConfig, 'manual');

$actionUrl = iN_HelpSecure($base_url . 'admin/request/storage_settings.php', false);
$csrfToken = iN_HelpSecure($ADMIN_CSRF, false);
?>

<section class="card rounded-2xl admin-settings" role="region" aria-labelledby="adminStorageSpacesHeading">
  <h1 id="adminStorageSpacesHeading"><?php echo iN_HelpSecure(customLang('storage_heading_spaces') ?: 'Storage · DigitalOcean Spaces'); ?></h1>
  <p class="box-note full-width"><?php echo iN_HelpSecure(customLang('storage_intro_spaces') ?: 'Use DigitalOcean Spaces (S3-compatible) for remote uploads.'); ?></p>

  <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="storage-settings" data-storage-provider="do_spaces">
    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
    <input type="hidden" name="provider" value="do_spaces">
    <input type="hidden" name="action" value="save">

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('storage_section_status') ?: 'Provider Status'); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="spaces_enable_provider"><?php echo iN_HelpSecure(customLang('storage_toggle_enable') ?: 'Enable provider'); ?></label>
          <div class="flex align_items column-gap">
            <input type="hidden" name="enable_provider" value="0">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_toggle_enable') ?: 'Enable provider'); ?>">
              <input id="spaces_enable_provider" type="checkbox" name="enable_provider" value="1" <?php echo $enabled ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_toggle_enable_hint_spaces') ?: 'Route new uploads to your Space.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="spaces_set_default"><?php echo iN_HelpSecure(customLang('storage_toggle_default') ?: 'Set as default storage'); ?></label>
          <div class="flex align_items column-gap">
            <input type="hidden" name="set_default" value="0">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_toggle_default') ?: 'Set as default storage'); ?>">
              <input id="spaces_set_default" type="checkbox" name="set_default" value="1" <?php echo $isDefault ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_toggle_default_hint_spaces') ?: 'Activates Spaces for all new uploads.'); ?></small>
        </div>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('storage_section_credentials') ?: 'Credentials'); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="spaces_access_key"><?php echo iN_HelpSecure(customLang('storage_field_access_key') ?: 'Access key ID'); ?></label>
          <input id="spaces_access_key" class="form-input" type="password" name="access_key" placeholder="DO00..." autocomplete="off">
          <small class="form-text text-muted">
            <?php echo iN_HelpSecure(customLang('storage_field_access_key_hint') ?: 'Leave blank to keep the stored key.'); ?>
            <?php if ($maskedKey !== ''): ?>
              <span class="text-muted"><?php echo iN_HelpSecure(customLang('storage_field_current_value') ?: 'Current:' ); ?> <?php echo $maskedKey; ?></span>
            <?php endif; ?>
          </small>
          <?php if ($hasKey): ?>
            <label class="form-checkbox">
              <input type="checkbox" name="access_key_clear" value="1">
              <span><?php echo iN_HelpSecure(customLang('storage_field_clear_value') ?: 'Clear stored value'); ?></span>
            </label>
          <?php endif; ?>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="spaces_secret_key"><?php echo iN_HelpSecure(customLang('storage_field_secret_key') ?: 'Secret access key'); ?></label>
          <input id="spaces_secret_key" class="form-input" type="password" name="secret_key" placeholder="Secret" autocomplete="off">
          <small class="form-text text-muted">
            <?php echo iN_HelpSecure(customLang('storage_field_secret_key_hint') ?: 'Leave blank to keep the stored secret.'); ?>
            <?php if ($maskedSecret !== ''): ?>
              <span class="text-muted"><?php echo iN_HelpSecure(customLang('storage_field_current_value') ?: 'Current:' ); ?> <?php echo $maskedSecret; ?></span>
            <?php endif; ?>
          </small>
          <?php if ($hasSecret): ?>
            <label class="form-checkbox">
              <input type="checkbox" name="secret_key_clear" value="1">
              <span><?php echo iN_HelpSecure(customLang('storage_field_clear_value') ?: 'Clear stored value'); ?></span>
            </label>
          <?php endif; ?>
        </div>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('storage_section_bucket') ?: 'Bucket & Region'); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="spaces_region"><?php echo iN_HelpSecure(customLang('storage_field_spaces_region') ?: 'Region'); ?></label>
          <input id="spaces_region" class="form-input" type="text" name="space_region" value="<?php echo iN_HelpSecure($region, false); ?>" placeholder="nyc3" autocomplete="off">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_spaces_region_hint') ?: 'Use the slug shown in the Spaces dashboard (e.g., nyc3, fra1).'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="spaces_name"><?php echo iN_HelpSecure(customLang('storage_field_space_name') ?: 'Space name'); ?></label>
          <input id="spaces_name" class="form-input" type="text" name="space_name" value="<?php echo iN_HelpSecure($spaceName, false); ?>" placeholder="my-space" autocomplete="off">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_space_name_hint') ?: 'Matches the bucket name for your Space.'); ?></small>
        </div>
      </div>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="spaces_prefix"><?php echo iN_HelpSecure(customLang('storage_field_prefix') ?: 'Key prefix (optional)'); ?></label>
          <input id="spaces_prefix" class="form-input" type="text" name="prefix" value="<?php echo iN_HelpSecure($prefix, false); ?>" placeholder="media/uploads">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_prefix_hint') ?: 'Automatically prepended to every stored object key.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="spaces_endpoint"><?php echo iN_HelpSecure(customLang('storage_field_endpoint') ?: 'Custom endpoint (optional)'); ?></label>
          <input id="spaces_endpoint" class="form-input" type="url" name="endpoint" value="<?php echo iN_HelpSecure($endpoint, false); ?>" placeholder="https://nyc3.digitaloceanspaces.com">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_spaces_endpoint_hint') ?: 'Override for CNAME or region-specific endpoints.'); ?></small>
        </div>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('storage_section_delivery') ?: 'Delivery & URLs'); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="spaces_cdn_domain"><?php echo iN_HelpSecure(customLang('storage_field_cdn_domain') ?: 'CDN domain (optional)'); ?></label>
          <input id="spaces_cdn_domain" class="form-input" type="text" name="cdn_domain" value="<?php echo iN_HelpSecure($cdnDomain, false); ?>" placeholder="cdn.example.com">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_cdn_domain_hint') ?: 'If using the Spaces CDN, paste the edge domain (no path).'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="spaces_visibility"><?php echo iN_HelpSecure(customLang('storage_field_visibility') ?: 'Default visibility'); ?></label>
          <select id="spaces_visibility" class="form-input" name="default_visibility">
            <option value="public" <?php echo $visibility === 'public' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('storage_visibility_public') ?: 'Public'); ?></option>
            <option value="private" <?php echo $visibility === 'private' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('storage_visibility_private') ?: 'Private'); ?></option>
          </select>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_visibility_hint_remote') ?: 'Private assets require signed URLs. Public objects are accessible directly.'); ?></small>
        </div>
      </div>

      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="spaces_presign_ttl"><?php echo iN_HelpSecure(customLang('storage_field_presign_ttl') ?: 'Signed URL TTL (seconds)'); ?></label>
          <input id="spaces_presign_ttl" class="form-input" type="number" name="default_presign_ttl" value="<?php echo iN_HelpSecure((string) $ttl, false); ?>" min="60" max="604800">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_presign_ttl_hint') ?: 'Used when generating signed URLs for private objects.'); ?></small>
        </div>
        <div class="form-input-wrapper">
          <label class="form-label" for="spaces_path_style"><?php echo iN_HelpSecure(customLang('storage_field_path_style') ?: 'Force path-style URLs'); ?></label>
          <div class="flex align_items column-gap">
            <input type="hidden" name="path_style" value="0">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_field_path_style') ?: 'Force path-style URLs'); ?>">
              <input id="spaces_path_style" type="checkbox" name="path_style" value="1" <?php echo $pathStyle ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_spaces_path_style_hint') ?: 'Enable if your CDN expects path-based addressing.'); ?></small>
        </div>
      </div>

      <div class="form-input-wrapper">
        <label class="form-label" for="spaces_defer_network"><?php echo iN_HelpSecure(customLang('storage_field_defer_network') ?: 'Defer network calls (dry-run mode)'); ?></label>
        <div class="flex align_items column-gap">
          <input type="hidden" name="defer_network" value="0">
          <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_field_defer_network') ?: 'Defer network calls (dry-run mode)'); ?>">
            <input id="spaces_defer_network" type="checkbox" name="defer_network" value="1" <?php echo $deferNetwork ? 'checked' : ''; ?>>
            <span class="el-switch-style"></span>
          </label>
        </div>
        <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_defer_network_hint') ?: 'Keep enabled on development servers without outbound access.'); ?></small>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('storage_section_migration') ?: 'Migration & Fallback'); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="spaces_keep_local_copy"><?php echo iN_HelpSecure(customLang('storage_field_keep_local_copy') ?: 'Keep local copies'); ?></label>
          <div class="flex align_items column-gap">
            <input type="hidden" name="keep_local_copy" value="0">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('storage_field_keep_local_copy') ?: 'Keep local copies'); ?>">
              <input id="spaces_keep_local_copy" type="checkbox" name="keep_local_copy" value="1" <?php echo $keepLocalCopy ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
          </div>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_keep_local_copy_hint') ?: 'Mirror new uploads under /uploads for rollback and CDN failover.'); ?></small>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="spaces_sync_mode"><?php echo iN_HelpSecure(customLang('storage_field_sync_mode') ?: 'Sync mode'); ?></label>
          <select id="spaces_sync_mode" class="form-input" name="sync_mode">
            <option value="manual" <?php echo $syncMode === 'manual' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('storage_field_sync_mode_manual') ?: 'Manual (CLI / cron)'); ?></option>
            <option value="background" <?php echo $syncMode === 'background' ? 'selected' : ''; ?>><?php echo iN_HelpSecure(customLang('storage_field_sync_mode_background') ?: 'Background worker'); ?></option>
          </select>
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('storage_field_sync_mode_hint') ?: 'Manual mode uses the storage_sync CLI stub; background mode assumes an external worker will call the admin endpoint.'); ?></small>
        </div>
      </div>
    </fieldset>

    <div class="form-actions flex align_items column-gap">
      <button type="submit" class="admin-button admin-button--primary" data-role="storage-save">
        <?php echo iN_HelpSecure(customLang('storage_button_save') ?: 'Save changes'); ?>
      </button>
      <button type="button" class="admin-button admin-button--ghost" data-action="storage-test" data-storage-provider="do_spaces">
        <?php echo iN_HelpSecure(customLang('storage_button_test') ?: 'Test connection'); ?>
      </button>
    </div>
  </form>
</section>
