<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';

global $base_url, $ADMIN_CSRF, $RL, $iconPath;

$themeSlug = 'welcome_default';
$actionUrl = iN_HelpSecure($base_url . 'admin/request/landing_sections.php', false);
$csrfToken = iN_HelpSecure($ADMIN_CSRF, false);

$langDir = dirname(__DIR__, 3) . '/langs';
$langOptions = [];
if (is_dir($langDir)) {
    foreach (scandir($langDir) as $entry) {
        if (preg_match('/^(\w+)\.php$/', (string) $entry, $m)) {
            $langOptions[] = $m[1];
        }
    }
}
if (!$langOptions) {
    $langOptions = ['eng'];
}

$rawTranslations = [];
foreach ($langOptions as $langCode) {
    $file = $langDir . '/' . $langCode . '.php';
    $rawTranslations[$langCode] = is_file($file) ? include $file : [];
    if (!is_array($rawTranslations[$langCode])) {
        $rawTranslations[$langCode] = [];
    }
}

if (!function_exists('landingAdminStorageLangKey')) {
    function landingAdminStorageLangKey(string $langCode): string
    {
        $langCode = strtolower(trim($langCode));
        $map = [
            'eng' => 'en',
            'en'  => 'en',
            'english' => 'en',
            'tur' => 'tr',
            'trk' => 'tr',
            'tr'  => 'tr',
            'turkish' => 'tr',
        ];
        if (isset($map[$langCode])) {
            return $map[$langCode];
        }
        if (strlen($langCode) >= 2) {
            return substr($langCode, 0, 2);
        }
        return $langCode;
    }
}

if (!function_exists('faqAdminExtractTranslations')) {
    function faqAdminExtractTranslations(array $langData, array $langOptions): array
    {
        $out = [];
        foreach ($langOptions as $langCode) {
            $key = landingAdminStorageLangKey($langCode);
            $payload = isset($langData[$key]) && is_array($langData[$key]) ? $langData[$key] : [];
            $question = isset($payload['q']) ? (string) $payload['q'] : '';
            $answer = isset($payload['a']) ? (string) $payload['a'] : '';
            $out[$langCode] = [
                'question' => $question,
                'answer'   => $answer,
            ];
        }
        return $out;
    }
}

$faqItems = [];
if (isset($RL) && method_exists($RL, 'RL_GetLandingSectionItems')) {
    $faqItems = $RL->RL_GetLandingSectionItems($themeSlug, 'faqs', 200);
}

$faqRows = [];
$rowIndex = 0;
foreach ($faqItems as $item) {
    $rowKey = 'item_' . (++$rowIndex);
    $langData = isset($item['lang']) && is_array($item['lang']) ? $item['lang'] : [];
    $faqRows[$rowKey] = [
        'id' => (int) ($item['id'] ?? 0),
        'translations' => faqAdminExtractTranslations($langData, $langOptions),
    ];
}

if (!$faqRows) {
    for ($i = 1; $i <= 8; $i++) {
        $translations = [];
        $hasContent = false;
        foreach ($langOptions as $langCode) {
            $questionKey = 'faq_q_' . $i;
            $answerKey   = 'faq_a_' . $i;
            $question = isset($rawTranslations[$langCode][$questionKey]) ? (string) $rawTranslations[$langCode][$questionKey] : '';
            $answer   = isset($rawTranslations[$langCode][$answerKey]) ? (string) $rawTranslations[$langCode][$answerKey] : '';
            if ($question !== '' || $answer !== '') {
                $hasContent = true;
            }
            $translations[$langCode] = [
                'question' => $question,
                'answer' => $answer,
            ];
        }
        if (!$hasContent) {
            continue;
        }
        $faqRows['default_' . $i] = [
            'id' => 0,
            'translations' => $translations,
        ];
    }
}

$hasFaqs = !empty($faqRows);
$searchPlaceholder = customLang('admin_faqs_search_placeholder') ?: 'Search questions';
$noResultsText = customLang('admin_faqs_no_results') ?: 'No FAQs match your search.';
$emptyStateText = customLang('admin_faqs_empty_state') ?: 'No FAQs configured yet. Add your first entry to get started.';
$addFaqLabel = customLang('admin_add_faq') ?: 'Add FAQ';
$saveLabel = customLang('admin_save_changes') ?: 'Save Changes';
$questionsLabel = customLang('admin_faq_question') ?: 'Question';
$answersLabel = customLang('admin_faq_answer') ?: 'Answer';
$removeLabel = customLang('admin_remove_row') ?: 'Remove row';
$manageFaqHeading = customLang('admin_faq_manage_heading') ?: 'Manage FAQs';
$searchLabel = customLang('admin_common_search') ?: 'Search';

?>
<section class="card rounded-2xl" role="region" aria-labelledby="adminFaqsHeading">
  <div class="list-header" id="adminFaqsHeading">
    <span class="icon"><?php echo renderVerifiedBadge($iconPath . 'help_center.svg', true); ?></span>
    <span><strong><?php echo iN_HelpSecure($manageFaqHeading, false); ?></strong></span>
  </div>

  <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="save-landing-faqs">
    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
    <input type="hidden" name="action" value="save_faqs">
    <input type="hidden" name="theme" value="<?php echo iN_HelpSecure($themeSlug, false); ?>">

    <div class="form-container">
      <div class="form-input-wrapper">
        <label class="form-label" for="faq_search"><?php echo iN_HelpSecure($searchLabel, false); ?></label>
        <input id="faq_search" class="form-input" type="search" name="faq_search" value="" placeholder="<?php echo iN_HelpSecure($searchPlaceholder, false); ?>" data-faq-search>
      </div>
      <div class="form-input-wrapper align-end">
        <label class="form-label sr-only" for="btnAddFaq" aria-hidden="true"><?php echo iN_HelpSecure($addFaqLabel, false); ?></label>
        <button id="btnAddFaq" type="button" class="btn-outline" data-action="add-faq-item"><?php echo iN_HelpSecure($addFaqLabel, false); ?></button>
      </div>
    </div>

    <div class="landing-feature-list" data-sortable-list="faqs">
      <?php foreach ($faqRows as $rowKey => $data):
        $rowKeySafe = iN_HelpSecure($rowKey, false);
        $rowId = (int) ($data['id'] ?? 0);
        $translations = is_array($data['translations'] ?? null) ? $data['translations'] : [];
      ?>
      <div class="landing-feature-card" data-sortable-item data-row-key="<?php echo $rowKeySafe; ?>" data-faq-item draggable="true">
        <div class="landing-feature-controls">
          <span class="landing-drag-handle" aria-hidden="true">☰</span>
          <button type="button" class="landing-remove-row" data-remove-faq aria-label="<?php echo iN_HelpSecure($removeLabel, false); ?>">&times;</button>
        </div>
        <input type="hidden" name="faq_id[<?php echo $rowKeySafe; ?>]" value="<?php echo iN_HelpSecure((string) $rowId, false); ?>">
        <div class="landing-feature-langs">
          <?php foreach ($langOptions as $langCode):
            $langKey = strtolower((string) $langCode);
            $langSafe = iN_HelpSecure($langKey, false);
            $translation = isset($translations[$langCode]) && is_array($translations[$langCode]) ? $translations[$langCode] : ['question' => '', 'answer' => ''];
            $questionVal = iN_HelpSecure((string) ($translation['question'] ?? ''), false);
            $answerVal = iN_HelpSecure((string) ($translation['answer'] ?? ''), false);
          ?>
          <div class="landing-feature-lang-card" data-faq-lang-card>
            <h4><?php echo iN_HelpSecure(strtoupper($langCode), false); ?></h4>
            <label class="form-label" for="faq_question_<?php echo $langSafe . '_' . $rowKeySafe; ?>"><?php echo iN_HelpSecure($questionsLabel, false); ?></label>
            <input id="faq_question_<?php echo $langSafe . '_' . $rowKeySafe; ?>" class="form-input" type="text" name="faq_question[<?php echo $langSafe; ?>][<?php echo $rowKeySafe; ?>]" value="<?php echo $questionVal; ?>" maxlength="200" data-faq-question-field>

            <label class="form-label" for="faq_answer_<?php echo $langSafe . '_' . $rowKeySafe; ?>"><?php echo iN_HelpSecure($answersLabel, false); ?></label>
            <textarea id="faq_answer_<?php echo $langSafe . '_' . $rowKeySafe; ?>" class="form-input" name="faq_answer[<?php echo $langSafe; ?>][<?php echo $rowKeySafe; ?>]" rows="3" maxlength="600" data-faq-answer-field><?php echo $answerVal; ?></textarea>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <p class="form-helper" data-faq-empty<?php echo $hasFaqs ? ' hidden' : ''; ?>><?php echo iN_HelpSecure($emptyStateText, false); ?></p>
    <p class="form-helper" data-faq-no-results hidden><?php echo iN_HelpSecure($noResultsText, false); ?></p>

    <button type="submit" class="pe-save btn-hover align-self-start"><?php echo iN_HelpSecure($saveLabel, false); ?></button>
  </form>
</section>

<template id="faqItemTemplate">
  <div class="landing-feature-card" data-sortable-item data-row-key="__KEY__" data-faq-item draggable="true">
    <div class="landing-feature-controls">
      <span class="landing-drag-handle" aria-hidden="true">☰</span>
      <button type="button" class="landing-remove-row" data-remove-faq aria-label="<?php echo iN_HelpSecure($removeLabel, false); ?>">&times;</button>
    </div>
    <input type="hidden" name="faq_id[__KEY__]" value="0">
    <div class="landing-feature-langs">
      <?php foreach ($langOptions as $langCode):
        $langKey = strtolower((string) $langCode);
        $langSafe = iN_HelpSecure($langKey, false);
      ?>
      <div class="landing-feature-lang-card" data-faq-lang-card>
        <h4><?php echo iN_HelpSecure(strtoupper($langCode), false); ?></h4>
        <label class="form-label" for="faq_question_<?php echo $langSafe; ?>___KEY__"><?php echo iN_HelpSecure($questionsLabel, false); ?></label>
        <input id="faq_question_<?php echo $langSafe; ?>___KEY__" class="form-input" type="text" name="faq_question[<?php echo $langSafe; ?>][__KEY__]" value="" maxlength="200" data-faq-question-field>

        <label class="form-label" for="faq_answer_<?php echo $langSafe; ?>___KEY__"><?php echo iN_HelpSecure($answersLabel, false); ?></label>
        <textarea id="faq_answer_<?php echo $langSafe; ?>___KEY__" class="form-input" name="faq_answer[<?php echo $langSafe; ?>][__KEY__]" rows="3" maxlength="600" data-faq-answer-field></textarea>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</template>
