<?php
declare(strict_types=1);
require_once __DIR__ . '/../../_bootstrap.php';

global $siteData, $base_url, $ADMIN_CSRF;

$boolFlag = static function ($value, bool $default = false): bool {
    if ($value === null) {
        return $default;
    }
    $normalized = strtolower(trim((string) $value));
    if ($normalized === '') {
        return $default;
    }
    return in_array($normalized, ['1', 'true', 'on', 'yes', 'enabled'], true);
};

$oneSignalEnabled     = $boolFlag($siteData['onesignal_enabled'] ?? null, false);
$oneSignalAppId       = (string)($siteData['onesignal_app_id'] ?? '');
$oneSignalRestApiKey  = (string)($siteData['onesignal_rest_api_key'] ?? '');
$oneSignalSafariWebId = (string)($siteData['onesignal_safari_web_id'] ?? '');
$oneSignalAutoPrompt  = $boolFlag($siteData['onesignal_auto_prompt'] ?? null, true);
$oneSignalWelcomeTitle   = (string)($siteData['onesignal_welcome_title'] ?? '');
$oneSignalWelcomeMessage = (string)($siteData['onesignal_welcome_message'] ?? '');

$actionUrl  = iN_HelpSecure($base_url . 'admin/request/onesignal_settings.php', false);
$csrfToken  = iN_HelpSecure($ADMIN_CSRF, false);

$restKeyTail = '';
if ($oneSignalRestApiKey !== '') {
    $restKeyTail = substr($oneSignalRestApiKey, -4);
}
$restKeyMaskedDisplay = $restKeyTail !== ''
    ? '••••' . iN_HelpSecure(strtoupper($restKeyTail), false)
    : iN_HelpSecure(customLang('admin_onesignal_rest_key_not_set') ?: 'Not set', false);

$pageTitle = customLang('admin_settings_onesignal_title');
if (!is_string($pageTitle) || $pageTitle === '' || $pageTitle === 'admin_settings_onesignal_title') {
    $pageTitle = customLang('admin_menu_settings_onesignal') ?: 'OneSignal Settings';
}
$pageTitleSafe = iN_HelpSecure($pageTitle, false);
?>

<section class="card shadow-soft rounded-2xl admin-settings" role="region" aria-labelledby="adminOneSignalHeading" data-page-title="<?php echo $pageTitleSafe; ?>">
  <h1 id="adminOneSignalHeading"><?php echo $pageTitleSafe; ?></h1>
  <p class="box-note full-width">
    <?php echo iN_HelpSecure(customLang('admin_settings_onesignal_intro') ?: 'Configure browser push notifications via OneSignal. The SDK only loads for authenticated users when enabled.'); ?>
  </p>
  <div class="box-note admin-onesignal-guide" role="note">
    <h2><?php echo iN_HelpSecure(customLang('admin_onesignal_setup_title') ?: 'How to configure OneSignal', false); ?></h2>
    <p><?php echo iN_HelpSecure(customLang('admin_onesignal_setup_intro') ?: 'Follow the checklist below to collect the required keys and enable push in minutes.', false); ?></p>
    <ol>
      <li><?php echo iN_HelpSecure(customLang('admin_onesignal_setup_step_dashboard') ?: 'Sign in or create an account at OneSignal, then create a new Web Push app.', false); ?></li>
      <li><?php echo iN_HelpSecure(customLang('admin_onesignal_setup_step_channel') ?: 'Inside Settings → Push & In-App, click “Set up Push & In-App”, choose Web, and complete the wizard to enable the Web Push channel.', false); ?></li>
      <li><?php echo iN_HelpSecure(customLang('admin_onesignal_setup_step_keys') ?: 'Open the OneSignal dashboard → Settings → Keys & IDs to copy the App ID and (optional) Safari Web ID.', false); ?></li>
      <li><?php echo iN_HelpSecure(customLang('admin_onesignal_setup_step_rest') ?: 'Generate a REST API key under REST API Keys. Paste the App ID and REST API key below, then save.', false); ?></li>
      <li><?php echo iN_HelpSecure(customLang('admin_onesignal_setup_step_safari') ?: 'If you need Safari push, enable Apple Safari under OneSignal → Settings → Web Push and follow the prompts to generate a Safari Web ID (requires an Apple Developer account).', false); ?></li>
      <li><?php echo iN_HelpSecure(customLang('admin_onesignal_setup_step_domain') ?: 'In OneSignal → Settings → Web Push, set your site URL to match the base URL used by ReelsProject.', false); ?></li>
      <li><?php echo iN_HelpSecure(customLang('admin_onesignal_setup_step_prompt') ?: 'Return here to enable OneSignal and choose whether the browser prompt appears automatically or via a custom trigger.', false); ?></li>
    </ol>
    <p>
      <a href="https://documentation.onesignal.com/docs/web-push-quickstart" target="_blank" rel="noopener noreferrer" class="button button--ghost">
        <?php echo iN_HelpSecure(customLang('admin_onesignal_setup_docs_link') ?: 'View OneSignal quickstart guide', false); ?>
      </a>
    </p>
  </div>

  <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="save-onesignal-settings">
    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
    <input type="hidden" name="onesignal_rest_api_key_clear" value="0">

    <div class="admin-onesignal-panels">
    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('admin_onesignal_section_general') ?: 'OneSignal Status'); ?></legend>
      <div class="form-grid form-grid--third">
        <div class="form-input-wrapper">
          <label class="form-label" for="onesignal_enabled">
            <?php echo iN_HelpSecure(customLang('admin_onesignal_field_enable') ?: 'Enable OneSignal Push', false); ?>
          </label>
          <div class="flex align_items column-gap">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('admin_onesignal_field_enable') ?: 'Enable OneSignal Push', false); ?>">
              <input type="hidden" name="onesignal_enabled" value="0">
              <input id="onesignal_enabled" type="checkbox" name="onesignal_enabled" value="1" <?php echo $oneSignalEnabled ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
            <span class="form-text text-muted">
              <?php echo iN_HelpSecure(customLang('admin_onesignal_enable_hint') ?: 'Loads the OneSignal SDK for signed-in users when enabled.', false); ?>
            </span>
          </div>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="onesignal_auto_prompt">
            <?php echo iN_HelpSecure(customLang('admin_onesignal_field_auto_prompt') ?: 'Auto-Prompt Subscription', false); ?>
          </label>
          <div class="flex align_items column-gap">
            <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('admin_onesignal_field_auto_prompt') ?: 'Auto-Prompt Subscription', false); ?>">
              <input type="hidden" name="onesignal_auto_prompt" value="0">
              <input id="onesignal_auto_prompt" type="checkbox" name="onesignal_auto_prompt" value="1" <?php echo $oneSignalAutoPrompt ? 'checked' : ''; ?>>
              <span class="el-switch-style"></span>
            </label>
            <span class="form-text text-muted">
              <?php echo iN_HelpSecure(customLang('admin_onesignal_auto_prompt_hint') ?: 'If disabled, trigger the prompt via JavaScript when appropriate.', false); ?>
            </span>
          </div>
        </div>

        <div class="form-input-wrapper">
          <span class="form-label">&nbsp;</span>
          <div class="box-note">
            <?php echo iN_HelpSecure(customLang('admin_onesignal_login_hint') ?: 'Push notifications remain hidden for guests and when keys are missing.', false); ?>
          </div>
        </div>
      </div>

      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="onesignal_app_id"><?php echo iN_HelpSecure(customLang('admin_onesignal_field_app_id') ?: 'OneSignal App ID', false); ?></label>
          <input id="onesignal_app_id" class="form-input" type="text" name="onesignal_app_id" value="<?php echo iN_HelpSecure($oneSignalAppId, false); ?>" maxlength="64" autocomplete="off" spellcheck="false">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('admin_onesignal_app_id_hint') ?: 'UUID from OneSignal dashboard (Settings → Keys & IDs).', false); ?></small>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="onesignal_safari_web_id"><?php echo iN_HelpSecure(customLang('admin_onesignal_field_safari_web_id') ?: 'Safari Web ID', false); ?></label>
          <input id="onesignal_safari_web_id" class="form-input" type="text" name="onesignal_safari_web_id" value="<?php echo iN_HelpSecure($oneSignalSafariWebId, false); ?>" maxlength="191" autocomplete="off" spellcheck="false">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('admin_onesignal_safari_hint') ?: 'Optional. Required only for Safari push support.', false); ?></small>
        </div>
      </div>
    </fieldset>

    <fieldset class="form-input-wrapper admin-settings-panel">
      <legend><?php echo iN_HelpSecure(customLang('admin_onesignal_section_credentials') ?: 'Credentials & Messages', false); ?></legend>
      <div class="form-grid form-grid--half">
        <div class="form-input-wrapper">
          <label class="form-label" for="onesignal_rest_api_key">
            <?php echo iN_HelpSecure(customLang('admin_onesignal_field_rest_api_key') ?: 'REST API Key', false); ?>
          </label>
          <div class="flex align_items column-gap">
            <input id="onesignal_rest_api_key" class="form-input" type="password" name="onesignal_rest_api_key" value="" maxlength="191" autocomplete="new-password" placeholder="<?php echo iN_HelpSecure(customLang('admin_onesignal_rest_key_placeholder') ?: 'Enter new REST API key', false); ?>" data-role="onesignal-rest-input">
            <button type="button" class="admin-button admin-button--neutral" data-action="onesignal-clear-rest-key">
              <?php echo iN_HelpSecure(customLang('admin_onesignal_rest_key_clear_button') ?: 'Clear', false); ?>
            </button>
          </div>
          <small class="form-text text-muted">
            <?php echo iN_HelpSecure(customLang('admin_onesignal_rest_key_hint') ?: 'Submit a new key to replace the stored value. Use Clear to remove the existing key.', false); ?><br>
            <span class="text-muted"><?php echo iN_HelpSecure(customLang('admin_onesignal_rest_key_current') ?: 'Current key ending with:', false); ?> <?php echo $restKeyMaskedDisplay; ?></span>
          </small>
        </div>

        <div class="form-input-wrapper">
          <label class="form-label" for="onesignal_welcome_title"><?php echo iN_HelpSecure(customLang('admin_onesignal_field_welcome_title') ?: 'Welcome Notification Title', false); ?></label>
          <input id="onesignal_welcome_title" class="form-input" type="text" name="onesignal_welcome_title" value="<?php echo iN_HelpSecure($oneSignalWelcomeTitle, false); ?>" maxlength="80" autocomplete="off">
          <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('admin_onesignal_welcome_title_hint') ?: 'Shown on the optional in-app welcome notification.', false); ?></small>
        </div>
      </div>

      <div class="form-input-wrapper">
        <label class="form-label" for="onesignal_welcome_message"><?php echo iN_HelpSecure(customLang('admin_onesignal_field_welcome_message') ?: 'Welcome Notification Message', false); ?></label>
        <textarea id="onesignal_welcome_message" class="form-input" name="onesignal_welcome_message" rows="3" maxlength="240" placeholder="<?php echo iN_HelpSecure(customLang('admin_onesignal_welcome_message_hint') ?: 'Short message sent when a user subscribes (optional).', false); ?>"><?php echo iN_HelpSecure($oneSignalWelcomeMessage, false); ?></textarea>
      </div>
    </fieldset>
    </div>

    <div class="form-actions">
      <button type="submit" class="admin-button admin-button--primary">
        <?php echo iN_HelpSecure(customLang('admin_save_changes') ?: 'Save Changes', false); ?>
      </button>
    </div>
  </form>
</section>
