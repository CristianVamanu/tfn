<?php
declare(strict_types=1);
require_once __DIR__ . '/../../_bootstrap.php';

global $siteData, $base_url, $ADMIN_CSRF;

$boolConfig = static function ($value, bool $default = false): bool {
    if ($value === null) {
        return $default;
    }
    if (is_bool($value)) {
        return $value;
    }
    $normalized = strtolower(trim((string)$value));
    if ($normalized === '') {
        return $default;
    }
    return in_array($normalized, ['1', 'true', 'on', 'yes', 'enabled'], true);
};

$liveStreamingEnabled = $boolConfig($siteData['live_streaming_enabled'] ?? null, true);
$liveChatEnabled      = $boolConfig($siteData['live_chat_enabled'] ?? null, true);
$agoraAppIdValue      = (string)($siteData['agora_app_id'] ?? '');
$agoraAppCertValue    = (string)($siteData['agora_app_certificate'] ?? '');
$agoraReadOnlyToken   = (string)($siteData['agora_readonly_token'] ?? '');
$liveViewerLimitValue = (string)($siteData['live_viewer_limit'] ?? '');
$liveTitlePrefixValue = (string)($siteData['live_title_prefix'] ?? '');

$liveStreamingStatusLabel = $liveStreamingEnabled
    ? (customLang('admin_live_streaming_status_on') ?: 'Live streaming is enabled.')
    : (customLang('admin_live_streaming_status_off') ?: 'Live streaming is disabled.');
$liveChatStatusLabel = $liveChatEnabled
    ? (customLang('admin_live_chat_status_on') ?: 'Live chat is enabled.')
    : (customLang('admin_live_chat_status_off') ?: 'Live chat is disabled.');

$actionUrl = iN_HelpSecure($base_url . 'admin/request/live_settings.php', false);
$csrfToken = iN_HelpSecure($ADMIN_CSRF, false);
$pageTitleText = customLang('admin_menu_settings_live') ?: 'Live Settings';
$pageIntroText = customLang('admin_live_settings_intro') ?: 'Manage global live streaming availability, Agora credentials, and viewer experience defaults.';
$pageTitleSafe = iN_HelpSecure($pageTitleText, false);
$pageIntroSafe = iN_HelpSecure($pageIntroText, false);
?>
<section class="card rounded-2xl admin-settings" role="region" aria-labelledby="adminLiveSettingsHeading" data-page-title="<?php echo $pageTitleSafe; ?>">
  <h1 id="adminLiveSettingsHeading"><?php echo $pageTitleSafe; ?></h1>
  <p class="text-muted fs-13"><?php echo $pageIntroSafe; ?></p>

  <form class="form-container flex flexBoxColumn admin-live-settings-form" method="post" action="<?php echo $actionUrl; ?>" data-action="save-live-settings">
    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

    <fieldset class="form-input-wrapper admin-settings-panel admin-live-settings">
      <legend><?php echo iN_HelpSecure(customLang('admin_live_settings_heading') ?: 'Agora Live Settings', false); ?></legend>
      <div class="form-grid form-grid--half admin-live-grid">
        <div class="form-input-wrapper" data-live-wrapper="master">
          <label class="form-label" for="live_streaming_enabled"><?php echo iN_HelpSecure(customLang('admin_live_streaming_label') ?: 'Enable live streaming', false); ?></label>
          <div class="flex align_items column-gap admin-live-toggle">
            <label class="el-switch el-switch-sm margin-bottom-zero" aria-label="<?php echo iN_HelpSecure(customLang('admin_live_streaming_label') ?: 'Enable live streaming', false); ?>">
              <input type="hidden" name="live_streaming_enabled" value="0">
              <input
                type="checkbox"
                id="live_streaming_enabled"
                name="live_streaming_enabled"
                value="1"
                <?php echo $liveStreamingEnabled ? 'checked' : ''; ?>
                data-live-master
              />
              <span class="el-switch-style"></span>
            </label>
            <span class="form-text fs-13" data-live-status><?php echo iN_HelpSecure($liveStreamingStatusLabel, false); ?></span>
          </div>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_live_streaming_hint') ?: 'Disables the live entry points and Agora initialisation for everyone except admins.', false); ?></p>
        </div>

        <div class="form-input-wrapper" data-live-wrapper="chat">
          <label class="form-label" for="live_chat_enabled"><?php echo iN_HelpSecure(customLang('admin_live_chat_label') ?: 'Enable live chat', false); ?></label>
          <div class="flex align_items column-gap admin-live-toggle">
            <label class="el-switch el-switch-sm margin-bottom-zero" aria-label="<?php echo iN_HelpSecure(customLang('admin_live_chat_label') ?: 'Enable live chat', false); ?>">
              <input type="hidden" name="live_chat_enabled" value="0">
              <input
                type="checkbox"
                id="live_chat_enabled"
                name="live_chat_enabled"
                value="1"
                <?php echo $liveChatEnabled ? 'checked' : ''; ?>
                data-live-chat
              />
              <span class="el-switch-style"></span>
            </label>
            <span class="form-text fs-13" data-live-chat-status><?php echo iN_HelpSecure($liveChatStatusLabel, false); ?></span>
          </div>
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_live_chat_hint') ?: 'Hides the live chat panel and blocks chat requests while still allowing video.', false); ?></p>
        </div>

        <div class="form-input-wrapper" data-live-wrapper="agora-app">
          <label class="form-label" for="agora_app_id"><?php echo iN_HelpSecure(customLang('admin_live_agora_app_id') ?: 'Agora App ID', false); ?></label>
          <input
            id="agora_app_id"
            class="form-input"
            type="text"
            name="agora_app_id"
            value="<?php echo iN_HelpSecure($agoraAppIdValue, false); ?>"
            maxlength="64"
            placeholder="<?php echo iN_HelpSecure(customLang('admin_live_agora_app_id_placeholder') ?: '32 character App ID', false); ?>"
            data-live-dependent
          >
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_live_agora_app_id_hint') ?: 'Required for both hosts and viewers. Paste the App ID from your Agora console.', false); ?></p>
        </div>

        <div class="form-input-wrapper" data-live-wrapper="agora-cert">
          <label class="form-label" for="agora_app_certificate"><?php echo iN_HelpSecure(customLang('admin_live_agora_certificate') ?: 'Agora App Certificate', false); ?></label>
          <input
            id="agora_app_certificate"
            class="form-input"
            type="text"
            name="agora_app_certificate"
            value="<?php echo iN_HelpSecure($agoraAppCertValue, false); ?>"
            maxlength="64"
            placeholder="<?php echo iN_HelpSecure(customLang('admin_live_agora_certificate_placeholder') ?: 'Optional but required for token generation', false); ?>"
            data-live-dependent
          >
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_live_agora_certificate_hint') ?: 'Needed to mint temporary tokens for hosts. Leave blank only if you provide static tokens.', false); ?></p>
        </div>

        <div class="form-input-wrapper" data-live-wrapper="agora-token">
          <label class="form-label" for="agora_readonly_token"><?php echo iN_HelpSecure(customLang('admin_live_agora_token') ?: 'Read-only audience token', false); ?></label>
          <input
            id="agora_readonly_token"
            class="form-input"
            type="text"
            name="agora_readonly_token"
            value="<?php echo iN_HelpSecure($agoraReadOnlyToken, false); ?>"
            maxlength="512"
            placeholder="<?php echo iN_HelpSecure(customLang('admin_live_agora_token_placeholder') ?: 'Optional pre-generated token for viewers', false); ?>"
            data-live-dependent
            autocomplete="off"
          >
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_live_agora_token_hint') ?: 'Optional. If set, viewers use this token when joining. Regenerate it from Agora when you rotate credentials.', false); ?></p>
        </div>

        <div class="form-input-wrapper" data-live-wrapper="viewer-limit">
          <label class="form-label" for="live_viewer_limit"><?php echo iN_HelpSecure(customLang('admin_live_viewer_limit') ?: 'Viewer limit', false); ?></label>
          <input
            id="live_viewer_limit"
            class="form-input"
            type="number"
            name="live_viewer_limit"
            min="0"
            max="500000"
            step="1"
            value="<?php echo iN_HelpSecure($liveViewerLimitValue, false); ?>"
            placeholder="<?php echo iN_HelpSecure(customLang('admin_live_viewer_limit_placeholder') ?: '0 = unlimited', false); ?>"
            data-live-dependent
          >
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_live_viewer_limit_hint') ?: 'Blocks new viewers once the live room reaches this number. Leave blank or 0 for no cap.', false); ?></p>
        </div>

        <div class="form-input-wrapper" data-live-wrapper="title-prefix">
          <label class="form-label" for="live_title_prefix"><?php echo iN_HelpSecure(customLang('admin_live_title_prefix') ?: 'Default title prefix', false); ?></label>
          <input
            id="live_title_prefix"
            class="form-input"
            type="text"
            name="live_title_prefix"
            value="<?php echo iN_HelpSecure($liveTitlePrefixValue, false); ?>"
            maxlength="120"
            placeholder="<?php echo iN_HelpSecure(customLang('admin_live_title_prefix_placeholder') ?: 'Example: Live with', false); ?>"
            data-live-dependent
          >
          <p class="form-text text-muted fs-13"><?php echo iN_HelpSecure(customLang('admin_live_title_prefix_hint') ?: 'Prefills the stream title when creators open the Go Live dialog.', false); ?></p>
        </div>
      </div>
    </fieldset>

    <div class="form-input-wrapper form-input-wrapper--actions">
      <button type="submit" class="pe-save btn-hover"><?php echo iN_HelpSecure(customLang('admin_save_changes') ?: 'Save Changes', false); ?></button>
    </div>
  </form>
</section>
