<?php
declare(strict_types=1);
require_once __DIR__ . '/../../_bootstrap.php';

global $siteData, $base_url, $ADMIN_CSRF;

$boolFlag = static function ($value, bool $default = false): bool {
    if ($value === null) {
        return $default;
    }
    $normalized = strtolower(trim((string) $value));
    if ($normalized === '') {
        return $default;
    }
    return in_array($normalized, ['1', 'true', 'on', 'yes', 'enabled'], true);
};

$smsEnabled    = $boolFlag($siteData['sms_enabled'] ?? null, false);
$smsProvider   = isset($siteData['sms_provider']) ? (string) $siteData['sms_provider'] : 'twilio';
$twilioSid     = (string) ($siteData['sms_twilio_sid'] ?? '');
$twilioToken   = (string) ($siteData['sms_twilio_token'] ?? '');
$twilioFrom    = (string) ($siteData['sms_twilio_from'] ?? '');
$smsRateLimit  = isset($siteData['sms_rate_limit_per_hour']) ? (int) $siteData['sms_rate_limit_per_hour'] : 30;

$actionUrl  = iN_HelpSecure($base_url . 'admin/request/sms_settings.php', false);
$csrfToken  = iN_HelpSecure($ADMIN_CSRF, false);

$tokenTail = '';
if ($twilioToken !== '') {
    $tokenTail = substr($twilioToken, -4);
}
$tokenMaskedDisplay = $tokenTail !== ''
    ? '••••' . iN_HelpSecure($tokenTail, false)
    : iN_HelpSecure(customLang('admin_sms_token_not_set') ?: 'Not set', false);

$pageTitle = customLang('admin_settings_sms_title');
if (!is_string($pageTitle) || $pageTitle === '' || $pageTitle === 'admin_settings_sms_title') {
    $pageTitle = customLang('admin_menu_settings_sms') ?: 'SMS Settings';
}
$pageTitleSafe = iN_HelpSecure($pageTitle, false);
?>

<section class="card shadow-soft rounded-2xl admin-settings" role="region" aria-labelledby="adminSmsHeading" data-page-title="<?php echo $pageTitleSafe; ?>">
  <h1 id="adminSmsHeading"><?php echo $pageTitleSafe; ?></h1>
  <p class="box-note full-width">
    <?php echo iN_HelpSecure(customLang('admin_settings_sms_intro') ?: 'Configure Twilio SMS for critical alerts. Requires phone numbers with country code and user opt-in.', false); ?>
  </p>

  <div class="box-note admin-sms-guide" role="note">
    <h2><?php echo iN_HelpSecure(customLang('admin_sms_setup_help_title') ?: 'SMS setup checklist', false); ?></h2>
    <p>
      <?php echo iN_HelpSecure(customLang('admin_sms_section_credentials_hint') ?: 'Use your Twilio Account SID/Auth Token and an SMS-capable number. Make sure Geo Permissions include your target country.', false); ?>
      <a href="https://www.twilio.com/docs/sms" target="_blank" rel="noopener noreferrer"><?php echo iN_HelpSecure(customLang('admin_sms_setup_docs_link') ?: 'Twilio SMS docs', false); ?></a>
    </p>
    <ol>
      <li><?php echo iN_HelpSecure(customLang('admin_sms_setup_step_1') ?: 'Create a Twilio account and note your Account SID and Auth Token.', false); ?></li>
      <li><?php echo iN_HelpSecure(customLang('admin_sms_setup_step_2') ?: 'Purchase or verify an SMS-capable Twilio phone number in the correct region. Enable Geo Permissions for your destinations.', false); ?></li>
      <li><?php echo iN_HelpSecure(customLang('admin_sms_setup_step_3') ?: 'Enter the SID, Auth Token, and From number below, then save. Trial users must add the destination number to Verified Caller IDs.', false); ?></li>
      <li><?php echo iN_HelpSecure(customLang('admin_sms_setup_step_4') ?: 'Ask users to add their phone number with country code and opt into SMS from Preferences.', false); ?></li>
    </ol>
  </div>

  <form class="form-container flex flexBoxColumn" method="post" action="<?php echo $actionUrl; ?>" data-action="save-sms-settings">
    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
    <input type="hidden" name="sms_twilio_token_clear" value="0">

    <div class="admin-onesignal-panels">
      <fieldset class="form-input-wrapper admin-settings-panel">
        <legend><?php echo iN_HelpSecure(customLang('admin_sms_section_status') ?: 'SMS Status'); ?></legend>
        <div class="form-grid form-grid--third">
          <div class="form-input-wrapper">
            <label class="form-label" for="sms_enabled"><?php echo iN_HelpSecure(customLang('admin_sms_field_enable') ?: 'Enable SMS', false); ?></label>
            <div class="flex align_items column-gap sms-toggle-row">
              <label class="el-switch el-switch-sm" aria-label="<?php echo iN_HelpSecure(customLang('admin_sms_field_enable') ?: 'Enable SMS', false); ?>">
                <input type="hidden" name="sms_enabled" value="0">
                <input id="sms_enabled" type="checkbox" name="sms_enabled" value="1" <?php echo $smsEnabled ? 'checked' : ''; ?>>
                <span class="el-switch-style"></span>
              </label>
              <span class="form-text text-muted">
                <?php echo iN_HelpSecure(customLang('admin_sms_field_enable_hint') ?: 'Requires valid Twilio SID, token, and a verified From number.', false); ?>
              </span>
            </div>
          </div>

          <div class="form-input-wrapper">
            <label class="form-label" for="sms_rate_limit_per_hour"><?php echo iN_HelpSecure(customLang('admin_sms_field_rate_limit') ?: 'Rate limit per hour', false); ?></label>
            <input id="sms_rate_limit_per_hour" class="form-input" type="number" min="1" max="500" step="1" name="sms_rate_limit_per_hour" value="<?php echo (int) $smsRateLimit; ?>" />
            <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('admin_sms_field_rate_limit_hint') ?: 'Maximum SMS sends per phone number per hour.', false); ?></small>
          </div>

          <div class="form-input-wrapper">
            <span class="form-label">&nbsp;</span>
            <div class="box-note">
              <?php echo iN_HelpSecure(customLang('admin_sms_section_status_hint') ?: 'Enable or disable Twilio SMS delivery.', false); ?>
            </div>
          </div>
        </div>
      </fieldset>

      <fieldset class="form-input-wrapper admin-settings-panel">
        <legend><?php echo iN_HelpSecure(customLang('admin_sms_section_credentials') ?: 'Twilio Credentials', false); ?></legend>
        <div class="form-grid form-grid--half">
          <div class="form-input-wrapper">
            <label class="form-label" for="sms_twilio_sid"><?php echo iN_HelpSecure(customLang('admin_sms_field_twilio_sid') ?: 'Account SID', false); ?></label>
            <input id="sms_twilio_sid" class="form-input" type="text" name="sms_twilio_sid" value="<?php echo iN_HelpSecure($twilioSid, false); ?>" maxlength="64" autocomplete="off">
            <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('admin_sms_field_twilio_sid_hint') ?: 'Starts with AC…, copy from Twilio Console > Account Info.', false); ?></small>
          </div>

          <div class="form-input-wrapper">
            <label class="form-label" for="sms_twilio_token"><?php echo iN_HelpSecure(customLang('admin_sms_field_twilio_token') ?: 'Auth Token', false); ?></label>
            <div class="flex align_items column-gap">
              <input id="sms_twilio_token" class="form-input" type="password" name="sms_twilio_token" value="" maxlength="128" autocomplete="new-password" placeholder="<?php echo iN_HelpSecure(customLang('admin_sms_field_twilio_token_placeholder') ?: 'Enter new token to replace', false); ?>">
              <button type="button" class="admin-button admin-button--neutral" data-action="sms-clear-token"><?php echo iN_HelpSecure(customLang('admin_sms_clear_token') ?: 'Clear', false); ?></button>
            </div>
            <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('admin_sms_field_twilio_token_hint') ?: 'Update to rotate credentials. Current token ending:', false); ?> <?php echo $tokenMaskedDisplay; ?></small>
          </div>
        </div>

        <div class="form-grid form-grid--half">
          <div class="form-input-wrapper">
            <label class="form-label" for="sms_twilio_from"><?php echo iN_HelpSecure(customLang('admin_sms_field_twilio_from') ?: 'From number (E.164)', false); ?></label>
            <input id="sms_twilio_from" class="form-input" type="text" name="sms_twilio_from" value="<?php echo iN_HelpSecure($twilioFrom, false); ?>" maxlength="32" autocomplete="off" placeholder="+12025550123">
            <small class="form-text text-muted"><?php echo iN_HelpSecure(customLang('admin_sms_field_twilio_from_hint') ?: 'A verified Twilio number or sender ID including country code.', false); ?></small>
          </div>
        </div>
      </fieldset>
    </div>

    <div class="form-actions">
      <button type="submit" class="admin-button admin-button--primary"><?php echo iN_HelpSecure(customLang('save_changes') ?: 'Save changes', false); ?></button>
    </div>
  </form>
</section>
