<?php
declare(strict_types=1);

global $ADM, $base_url, $ADMIN_CSRF, $iconPath, $userData;

$perPage = isset($_GET['per']) ? max(5, min(100, (int)$_GET['per'])) : 20;
$pageNo  = isset($_GET['page_no']) ? max(1, (int)$_GET['page_no']) : 1;

$filters   = ['fake' => '1'];
$listing   = $ADM->ADM_PagedUsers('', $pageNo, $perPage, $filters);
$rows      = $listing['rows'];
$total     = (int)($listing['total'] ?? 0);
$pages     = (int)max(1, ceil($total / max(1, $perPage)));

$actionUrl = $base_url . 'admin/request/fake_users.php';
$flash     = $_SESSION['admin_fake_generator_flash'] ?? null;
unset($_SESSION['admin_fake_generator_flash']);
?>
<section class="card rounded-2xl" role="region" aria-labelledby="fakeUserGeneratorHeading">
  <h1 id="fakeUserGeneratorHeading"><?= iN_HelpSecure(customLang('admin_fake_generator_title') ?: 'Fake User Generator', false); ?></h1>
  <p class="mb-3 text-muted">
    <?= iN_HelpSecure(customLang('admin_fake_generator_desc') ?: 'Create placeholder accounts for testing or seeding and mark them as fake.', false); ?>
  </p>

  <?php if (is_array($flash)): ?>
    <div class="box-note <?= $flash['type'] === 'success' ? 'note-success' : 'note-danger'; ?>" role="status">
      <?= iN_HelpSecure((string)($flash['message'] ?? ''), false); ?>
    </div>
  <?php endif; ?>

  <form id="fakeUserGeneratorForm" class="form-container form-container--columns" method="post" action="<?= iN_HelpSecure($actionUrl, false); ?>" data-module="fake-user-generator">
    <input type="hidden" name="csrf_token" value="<?= iN_HelpSecure($ADMIN_CSRF, false); ?>">
    <input type="hidden" name="per" value="<?= (int)$perPage; ?>">

    <div class="form-input-wrapper">
      <label class="form-label" for="fake_user_count"><?= iN_HelpSecure(customLang('admin_fake_generator_number_label') ?: 'Number of users', false); ?></label>
      <input id="fake_user_count" class="form-input" type="number" name="fake_user_count" min="1" max="1000" step="1" value="5" required>
      <small class="form-text text-muted"><?= iN_HelpSecure(customLang('admin_fake_generator_number_help') ?: 'Enter how many fake users to create (1-1000).', false); ?></small>
    </div>

    <div class="form-input-wrapper">
      <label class="form-label" for="fake_user_password"><?= iN_HelpSecure(customLang('admin_fake_generator_password_label') ?: 'Password', false); ?></label>
      <input id="fake_user_password" class="form-input" type="password" name="fake_user_password" minlength="8" maxlength="64" required>
      <small class="form-text text-muted"><?= iN_HelpSecure(customLang('admin_fake_generator_password_help') ?: 'All generated accounts will share this password.', false); ?></small>
    </div>

    <div class="form-input-wrapper form-actions">
      <button type="submit" class="pe-save btn-hover" data-state="idle">
        <?= iN_HelpSecure(customLang('admin_fake_generator_submit') ?: 'Generate', false); ?>
      </button>
    </div>
  </form>

  <div id="fakeUserFeedback" aria-live="polite" aria-atomic="true"></div>

  <div id="fakeUserTableRegion">
    <form class="form-container flex flexBoxColumn gap" method="post" action="<?= iN_HelpSecure($actionUrl, false); ?>" data-module="fake-user-delete" data-confirm="<?= iN_HelpSecure(customLang('admin_fake_generator_delete_confirm') ?: 'Delete selected fake users? This cannot be undone.', false); ?>">
      <input type="hidden" name="csrf_token" value="<?= iN_HelpSecure($ADMIN_CSRF, false); ?>">
      <input type="hidden" name="per" value="<?= (int)$perPage; ?>">
      <input type="hidden" name="action" value="delete_selected">

      <?php
        $adminUsersTableRows = $rows;
        $adminUsersTableBaseUrl = $base_url;
        $adminUsersTableIconPath = $iconPath;
        $adminUsersTableUserData = $userData;
        $adminUsersShowFakeBadge = true;
        $adminUsersTablePagination = [
          'base_url' => $base_url . 'admin/generate_fake_user.php',
          'params'   => [
            'per'  => (string)$perPage,
          ],
          'page'    => $pageNo,
          'pages'   => $pages,
          'options' => ['show_goto' => true, 'radius' => 1],
        ];
        include __DIR__ . '/partials/users_table.php';
        unset($adminUsersTableRows, $adminUsersTableBaseUrl, $adminUsersTableIconPath, $adminUsersTableUserData, $adminUsersShowFakeBadge, $adminUsersTablePagination);
      ?>

      <div class="form-input-wrapper">
        <button type="submit" class="btn-hover admin-bulk-delete-btn" data-bulk-button="fake-user-delete" disabled aria-disabled="true">
          <span class="admin-bulk-delete-icon" aria-hidden="true">
            <?= renderVerifiedBadge($iconPath . 'delete.svg', true); ?>
          </span>
          <span class="admin-bulk-delete-text">
            <?= iN_HelpSecure(customLang('admin_fake_generator_delete_label') ?: 'Delete Selected', false); ?>
          </span>
          <span class="admin-bulk-delete-count is-hidden" data-bulk-count aria-hidden="true">0</span>
        </button>
        <small class="form-text text-muted"><?= iN_HelpSecure(customLang('admin_fake_generator_delete_help') ?: 'Select fake users above and remove them permanently.', false); ?></small>
      </div>
    </form>
  </div>
</section>
