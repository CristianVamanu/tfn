<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';

global $ADM, $base_url, $iconPath, $currency, $currencies, $currencyFormatSettings;

$config = isset($advertPageConfig) && is_array($advertPageConfig) ? $advertPageConfig : [];
$pageKey        = (string) ($config['page_key'] ?? 'ads_all');
$titleKey       = (string) ($config['title_key'] ?? 'admin_ads_all_title');
$defaultStatus  = (string) ($config['default_status'] ?? '');
$mediaTypeFixed = (string) ($config['media_type'] ?? '');
$iconName       = (string) ($config['icon'] ?? 'ads.svg');
$emptyKey       = (string) ($config['empty_lang_key'] ?? 'admin_ads_empty_default');

$pageTitle = customLang($titleKey);
if ($pageTitle === $titleKey || $pageTitle === '') {
    $pageTitle = $config['fallback_title'] ?? 'Advertisements';
}

$status = strtolower(trim((string) ($_GET['status'] ?? '')));
if ($status === '' && $defaultStatus !== '') {
    $status = $defaultStatus;
}

$search   = trim((string) ($_GET['q'] ?? ''));
$pageNo   = max(1, (int) ($_GET['page_no'] ?? 1));
$perPage  = max(6, min(24, (int) ($_GET['per'] ?? 12)));

$mediaType = $mediaTypeFixed !== '' ? $mediaTypeFixed : strtolower(trim((string) ($_GET['type'] ?? '')));
if (!in_array($mediaType, ['image', 'video'], true)) {
    $mediaType = $mediaTypeFixed !== '' ? $mediaTypeFixed : '';
}

$data   = $ADM->ADM_PaginateAdvertisements($pageNo, $perPage, $mediaType, $status, $search);
$ads    = $data['rows'] ?? [];
$total  = (int) ($data['total'] ?? 0);
$pages  = max(1, (int) ceil($total / max(1, $perPage)));

$statusOptions = [
    ''        => customLang('admin_ads_filter_status_any') ?: 'All statuses',
    'draft'   => customLang('admin_ads_status_draft') ?: 'Pending approval',
    'active'  => customLang('admin_ads_status_active') ?: 'Active',
    'paused'  => customLang('admin_ads_status_paused') ?: 'Paused',
    'ended'   => customLang('admin_ads_status_ended') ?: 'Rejected',
];

$statusLabels = $statusOptions;
$statusClasses = [
    'draft'  => 'is-pending',
    'active' => 'is-active',
    'paused' => 'is-paused',
    'ended'  => 'is-ended',
];

$baseAdminUrl = rtrim((string) $base_url, '/') . '/admin/index.php';
$formAction   = $baseAdminUrl;
$currencyMap = isset($currencies) && is_array($currencies) ? $currencies : [];
$currencyFormatSettings = $currencyFormatSettings ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
$currencyCode = isset($currency) && $currency !== '' ? strtoupper((string) $currency) : 'USD';
$formatCurrency = static function (float $value, ?string $code = null) use ($currencyMap, $currencyFormatSettings, $currencyCode): string {
    $resolvedCode = strtoupper((string) ($code ?? $currencyCode));
    $symbol = $currencyMap[$resolvedCode] ?? null;

    return dz_format_currency($value, $resolvedCode, $symbol, $currencyFormatSettings);
};
$projectRoot  = dirname(__DIR__, 3);

?>
<section class="card rounded-2xl admin-ads" role="region" aria-labelledby="adminAdsHeading">
  <div class="list-header" id="adminAdsHeading">
    <span class="icon"><?= renderVerifiedBadge($iconPath . $iconName, true); ?></span>
    <span><strong><?= iN_HelpSecure($pageTitle, false); ?></strong></span>
  </div>

  <form method="get" action="<?= iN_HelpSecure($formAction, false); ?>" class="admin-ads__filters">
    <input type="hidden" name="page" value="<?= iN_HelpSecure($pageKey, false); ?>">
    <?php if ($mediaTypeFixed !== ''): ?>
      <input type="hidden" name="type" value="<?= iN_HelpSecure($mediaTypeFixed, false); ?>">
    <?php endif; ?>
    <div class="form-input-wrapper">
      <label class="form-label" for="admin-ads-search"><?= iN_HelpSecure(customLang('admin_ads_filter_search'), false); ?></label>
      <input
          id="admin-ads-search"
          class="form-input"
          type="text"
          name="q"
          value="<?= iN_HelpSecure($search, false); ?>"
          placeholder="<?= iN_HelpSecure(customLang('admin_ads_filter_search_placeholder'), false); ?>"
      >
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="admin-ads-status"><?= iN_HelpSecure(customLang('admin_ads_filter_status'), false); ?></label>
      <select id="admin-ads-status" name="status" class="form-input">
        <?php foreach ($statusOptions as $value => $label): ?>
          <option value="<?= iN_HelpSecure($value, false); ?>"<?= $status === $value ? ' selected' : ''; ?>><?= iN_HelpSecure($label, false); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="admin-ads-per"><?= iN_HelpSecure(customLang('admin_ads_filter_per_page'), false); ?></label>
      <select id="admin-ads-per" name="per" class="form-input">
        <?php foreach ([12, 18, 24] as $pp): ?>
          <option value="<?= $pp; ?>"<?= $perPage === $pp ? ' selected' : ''; ?>><?= $pp; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper form-actions">
      <button type="submit" class="pe-save btn-hover"><?= iN_HelpSecure(customLang('admin_ads_filter_apply'), false); ?></button>
    </div>
  </form>

  <?php if (empty($ads)): ?>
    <div class="admin-ads__empty">
      <?= iN_HelpSecure(customLang($emptyKey), false); ?>
    </div>
  <?php else: ?>
    <div class="admin-ads__grid">
      <?php foreach ($ads as $ad):
        $adId      = (int) ($ad['ad_id'] ?? 0);
        $ownerName = trim((string) ($ad['user_fullname'] ?? ''));
        $ownerName = $ownerName !== '' ? $ownerName : (string) ($ad['username'] ?? '');
        $username  = (string) ($ad['username'] ?? '');
        $statusRaw = strtolower((string) ($ad['status'] ?? 'draft'));
        if (!isset($statusLabels[$statusRaw])) { $statusRaw = 'draft'; }

        $avatarRel = (string) ($ad['user_avatar'] ?? 'uploads/user_avatars/default.jpeg');
        $avatarUrl = admin_resolve_media_url($avatarRel);

        $title = (string) ($ad['title'] ?? '');
        $description = (string) ($ad['description'] ?? '');

        $mediaTypeRow = (string) ($ad['media_type'] ?? 'image');
        $mediaPath    = trim((string) ($ad['ad_media'] ?? ''));
        $mediaUrl     = '';
        $posterUrl    = '';

        if ($mediaTypeRow === 'image') {
            $parts = array_filter(array_map('trim', explode(',', $mediaPath)));
            if (!empty($parts)) {
                $mediaUrl = admin_resolve_media_url((string) $parts[0]);
            }
        } elseif ($mediaTypeRow === 'video') {
            $mediaUrl = admin_resolve_media_url($mediaPath);
            if ($mediaPath !== '') {
                $posterCandidate = preg_replace('~\.[^.]+$~', '.png', $mediaPath);
                if ($posterCandidate) {
                    $posterCandidate = str_replace(['..\\', '../'], '', $posterCandidate);
                    $posterCandidate = ltrim($posterCandidate, '/');
                    $posterFull = $projectRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $posterCandidate);
                    if (is_file($posterFull)) {
                        $posterUrl = admin_resolve_media_url($posterCandidate);
                    }
                }
            }
        }

        $createdAt = (int) ($ad['created_at'] ?? 0);
        $createdTxt = $createdAt > 0 ? date('Y-m-d H:i', $createdAt) : '';
        $targetImpressions = (int) ($ad['target_impressions'] ?? 0);
        $views  = (int) ($ad['views'] ?? 0);
        $clicks = (int) ($ad['clicks'] ?? 0);
        $budget = (float) ($ad['total_budget'] ?? 0);
        $pricePer = (float) ($ad['price_per_impression'] ?? 0);
        $duration = (int) ($ad['duration_days'] ?? 0);

        $detailItems = [
            customLang('admin_ads_detail_created') => $createdTxt,
            customLang('admin_ads_detail_target')  => number_format(max(0, $targetImpressions)),
            customLang('admin_ads_detail_budget')  => $formatCurrency($budget, $currencyCode),
            customLang('admin_ads_detail_price')   => $formatCurrency($pricePer, $currencyCode),
            customLang('admin_ads_detail_duration')=> strtr(customLang('admin_ads_detail_duration_value'), ['{days}' => max(1, $duration)]),
            customLang('admin_ads_detail_views')   => number_format(max(0, $views)),
            customLang('admin_ads_detail_clicks')  => number_format(max(0, $clicks)),
        ];

        $editUrl = $baseAdminUrl . '?page=' . rawurlencode($pageKey) . '&ad_id=' . $adId;

        $actions = [
            [
                'key'   => 'edit',
                'label' => customLang('admin_ads_action_edit'),
                'style' => 'ghost',
                'url'   => $editUrl,
            ],
        ];
        if ($statusRaw === 'draft') {
            $actions[] = ['key' => 'approve', 'label' => customLang('admin_ads_action_approve'), 'style' => 'primary'];
            $actions[] = ['key' => 'reject', 'label' => customLang('admin_ads_action_reject'), 'style' => 'ghost'];
        } elseif ($statusRaw === 'active') {
            $actions[] = ['key' => 'pause', 'label' => customLang('admin_ads_action_pause'), 'style' => 'ghost'];
            $actions[] = ['key' => 'reject', 'label' => customLang('admin_ads_action_reject'), 'style' => 'ghost'];
        } elseif ($statusRaw === 'paused') {
            $actions[] = ['key' => 'resume', 'label' => customLang('admin_ads_action_resume'), 'style' => 'primary'];
            $actions[] = ['key' => 'reject', 'label' => customLang('admin_ads_action_reject'), 'style' => 'ghost'];
        }
        $actions[] = ['key' => 'delete', 'label' => customLang('admin_ads_action_delete'), 'style' => 'danger'];

        $statusLabel = $statusLabels[$statusRaw] ?? ucfirst($statusRaw);
        $statusClass = $statusClasses[$statusRaw] ?? '';
      ?>
      <article class="admin-ad-card" data-ad-id="<?= $adId; ?>" data-ad-status="<?= iN_HelpSecure($statusRaw, false); ?>">
        <header class="admin-ad-card__header">
          <div class="admin-ad-card__owner">
            <img src="<?= iN_HelpSecure($avatarUrl, false); ?>" alt="" class="admin-ad-card__avatar" loading="lazy">
            <div class="admin-ad-card__owner-info">
              <span class="admin-ad-card__owner-name"><?= iN_HelpSecure($ownerName, false); ?></span>
              <?php if ($username !== ''): ?>
                <span class="admin-ad-card__owner-username">@<?= iN_HelpSecure($username, false); ?></span>
              <?php endif; ?>
            </div>
          </div>
          <div class="admin-ad-card__header-actions">
            <span class="admin-ad-card__status-pill <?= iN_HelpSecure($statusClass, false); ?>"><?= iN_HelpSecure($statusLabel, false); ?></span>
          </div>
        </header>

        <div class="admin-ad-card__media admin-ad-card__media--<?= iN_HelpSecure($mediaTypeRow, false); ?>">
          <?php if ($mediaTypeRow === 'video'): ?>
            <video src="<?= iN_HelpSecure($mediaUrl, false); ?>" poster="<?= iN_HelpSecure($posterUrl, false); ?>" controls preload="metadata"></video>
          <?php elseif ($mediaUrl !== ''): ?>
            <img src="<?= iN_HelpSecure($mediaUrl, false); ?>" alt="" loading="lazy">
          <?php else: ?>
            <div class="admin-ad-card__media-placeholder"><?= iN_HelpSecure(customLang('admin_ads_media_missing'), false); ?></div>
          <?php endif; ?>
        </div>

        <div class="admin-ad-card__body">
          <h3 class="admin-ad-card__title"><?= iN_HelpSecure($title, false); ?></h3>
          <p class="admin-ad-card__description"><?= nl2br(iN_HelpSecure($description, false)); ?></p>
        </div>

        <footer class="admin-ad-card__footer">
          <div class="admin-ad-card__details" aria-label="<?= iN_HelpSecure(customLang('admin_ads_details_label'), false); ?>">
            <?php foreach ($detailItems as $label => $value):
              if ($label === '' || $label === null) { continue; }
            ?>
              <div class="admin-ad-card__detail-item">
                <span class="label"><?= iN_HelpSecure((string) $label, false); ?></span>
                <span class="value"><?= iN_HelpSecure((string) $value, false); ?></span>
              </div>
            <?php endforeach; ?>
          </div>
          <div class="admin-ad-card__actions">
            <?php foreach ($actions as $act):
              $actKey   = (string) ($act['key'] ?? '');
              $actLabel = (string) ($act['label'] ?? '');
              $actStyle = (string) ($act['style'] ?? 'ghost');
              $actUrl   = isset($act['url']) ? (string) $act['url'] : '';
              $btnClasses = 'admin-ad-card__btn admin-ad-card__btn--' . preg_replace('~[^a-z0-9_-]+~i', '', $actStyle);
            ?>
              <button
                  type="button"
                  class="<?= iN_HelpSecure($btnClasses, false); ?>"
                  data-ad-action="<?= iN_HelpSecure($actKey, false); ?>"
                  data-ad-id="<?= $adId; ?>"
                  <?php if ($actUrl !== ''): ?>data-edit-url="<?= iN_HelpSecure($actUrl, false); ?>"<?php endif; ?>
              ><?= iN_HelpSecure($actLabel, false); ?></button>
            <?php endforeach; ?>
          </div>
        </footer>
      </article>
      <?php endforeach; ?>
    </div>

    <?php if ($pages > 1):
      $queryBase = $_GET;
      $queryBase['page'] = $pageKey;
    ?>
      <nav class="admin-ads__pagination" aria-label="<?= iN_HelpSecure(customLang('admin_ads_pagination_label'), false); ?>">
        <?php for ($i = 1; $i <= $pages; $i++):
          $queryBase['page_no'] = $i;
          $query = http_build_query($queryBase);
          $href = $baseAdminUrl . '?' . $query;
        ?>
          <a
              class="admin-ads__pagination-link<?= $i === $pageNo ? ' is-active' : ''; ?>"
              href="<?= iN_HelpSecure($href, false); ?>"
          ><?= $i; ?></a>
        <?php endfor; ?>
      </nav>
    <?php endif; ?>
  <?php endif; ?>
</section>
