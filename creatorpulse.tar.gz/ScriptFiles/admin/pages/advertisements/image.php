<?php
declare(strict_types=1);

$advertPageConfig = [
    'page_key'       => 'ads_images',
    'title_key'      => 'admin_ads_image_title',
    'default_status' => '',
    'media_type'     => 'image',
    'icon'           => 'image.svg',
    'empty_lang_key' => 'admin_ads_empty_image',
];

$adId = (int) ($_GET['ad_id'] ?? 0);

if ($adId > 0) {
    require __DIR__ . '/edit_common.php';
} else {
    require __DIR__ . '/list_common.php';
}
