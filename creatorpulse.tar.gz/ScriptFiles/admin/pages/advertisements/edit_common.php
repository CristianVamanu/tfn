<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';

global $ADM, $base_url, $ADMIN_CSRF, $currency, $iconPath, $currencies, $currencyFormatSettings;

$config = isset($advertPageConfig) && is_array($advertPageConfig) ? $advertPageConfig : [];
$pageKey        = (string) ($config['page_key'] ?? 'ads_all');
$titleKey       = (string) ($config['title_key'] ?? 'admin_ads_all_title');
$mediaTypeFixed = (string) ($config['media_type'] ?? '');
$iconName       = (string) ($config['icon'] ?? 'ads.svg');
$currencyMap = isset($currencies) && is_array($currencies) ? $currencies : [];
$currencyFormatSettings = $currencyFormatSettings ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
$currencyCode = isset($currency) && $currency !== '' ? strtoupper((string) $currency) : 'USD';
$currencyPrecision = dz_currency_resolve_precision($currencyCode, (int) ($currencyFormatSettings['decimal_places'] ?? 2));
$pricePrecision = max(4, $currencyPrecision);
$budgetPrecision = max(2, $currencyPrecision);
$priceStep = number_format(pow(10, -$pricePrecision), $pricePrecision, '.', '');
$budgetStep = number_format(pow(10, -$budgetPrecision), $budgetPrecision, '.', '');
$formatCurrency = static function (float $value, ?string $code = null) use ($currencyMap, $currencyFormatSettings, $currencyCode): string {
    $resolvedCode = strtoupper((string) ($code ?? $currencyCode));
    $symbol = $currencyMap[$resolvedCode] ?? null;

    return dz_format_currency($value, $resolvedCode, $symbol, $currencyFormatSettings);
};
$formatNumber = static function (float $value, string $code, int $precision, array $settings, bool $forInput = false): string {
    $settings['decimal_places'] = $precision;
    if ($forInput) {
        $settings['decimal_sep'] = '.';
        $settings['thousands_sep'] = '';
    }

    return dz_format_number($value, $code, $settings);
};

$pageTitle = customLang($titleKey);
if ($pageTitle === $titleKey || $pageTitle === '') {
    $pageTitle = $config['fallback_title'] ?? 'Advertisements';
}

$adId = max(0, (int) ($_GET['ad_id'] ?? 0));
$adRow = $adId > 0 ? $ADM->ADM_GetAdvertisementById($adId) : null;

$baseAdminUrl = rtrim((string) $base_url, '/') . '/admin/index.php';
$backUrl = $baseAdminUrl . '?page=' . rawurlencode($pageKey);
$requestUrl = rtrim((string) $base_url, '/') . '/admin/request/advertisements.php';
$csrfToken = iN_HelpSecure($ADMIN_CSRF ?? generateCsrfToken(), false);

$statusLabels = [
    'draft'  => customLang('admin_ads_status_draft') ?: 'Pending approval',
    'active' => customLang('admin_ads_status_active') ?: 'Active',
    'paused' => customLang('admin_ads_status_paused') ?: 'Paused',
    'ended'  => customLang('admin_ads_status_ended') ?: 'Rejected',
];
$statusClasses = [
    'draft'  => 'is-pending',
    'active' => 'is-active',
    'paused' => 'is-paused',
    'ended'  => 'is-ended',
];

$base = rtrim((string) $base_url, '/');

$mediaType = '';
$mediaMismatch = false;
$mediaList = [];
$mediaUrl = '';
$ownerName = '';
$username = '';
$avatarUrl = '';
$status = 'draft';
$statusLabel = $statusLabels[$status] ?? ucfirst($status);
$statusClass = $statusClasses[$status] ?? '';
$titleValue = '';
$descriptionValue = '';
$targetImpressions = 0;
$pricePer = 0.0;
$durationDays = 1;
$totalBudget = 0.0;
$views = 0;
$clicks = 0;
$createdAtTs = 0;
$createdAtDisplay = '';
$currencyCode = $currency ?? 'USD';

if ($adRow) {
    $mediaType = strtolower((string) ($adRow['media_type'] ?? ''));
    if ($mediaTypeFixed !== '' && $mediaType !== $mediaTypeFixed) {
        $mediaMismatch = true;
    }

    $ownerName = trim((string) ($adRow['user_fullname'] ?? ''));
    $usernameRaw = trim((string) ($adRow['username'] ?? ''));
    if ($ownerName === '') {
        $ownerName = $usernameRaw;
    }
    $username = $usernameRaw !== '' ? '@' . $usernameRaw : '';
    $avatarRel = trim((string) ($adRow['user_avatar'] ?? ''));
    if ($avatarRel === '') {
        $avatarRel = 'uploads/user_avatars/default.jpeg';
    }
    $avatarUrl = admin_resolve_media_url($avatarRel, $base);

    $status = strtolower((string) ($adRow['status'] ?? 'draft'));
    $statusLabel = $statusLabels[$status] ?? ucfirst($status);
    $statusClass = $statusClasses[$status] ?? '';

    $titleValue = trim((string) ($adRow['title'] ?? ''));
    $descriptionValue = trim((string) ($adRow['description'] ?? ''));
    $targetImpressions = (int) ($adRow['target_impressions'] ?? 0);
    $pricePer = (float) ($adRow['price_per_impression'] ?? 0);
    $durationDays = max(1, (int) ($adRow['duration_days'] ?? 1));
    $totalBudget = (float) ($adRow['total_budget'] ?? 0);
    $views = (int) ($adRow['views'] ?? 0);
    $clicks = (int) ($adRow['clicks'] ?? 0);
    $createdAtTs = (int) ($adRow['created_at'] ?? 0);
    $createdAtDisplay = $createdAtTs > 0 ? date('M j, Y H:i', $createdAtTs) : '-';

    if ($mediaType === 'image') {
        $mediaRaw = trim((string) ($adRow['ad_media'] ?? ''));
        if ($mediaRaw !== '') {
            foreach (explode(',', $mediaRaw) as $path) {
                $path = trim(str_replace('\\', '/', $path));
                if ($path === '') {
                    continue;
                }
                $mediaList[] = [
                    'path' => $path,
                    'url'  => admin_resolve_media_url($path, $base),
                ];
            }
        }
    } elseif ($mediaType === 'video') {
        $mediaPath = trim((string) ($adRow['ad_media'] ?? ''));
        if ($mediaPath !== '') {
            $mediaUrl = admin_resolve_media_url($mediaPath, $base);
        }
    }
}

$mediaEmpty = empty($mediaList);
$canEdit = $adRow && in_array($mediaType, ['image', 'video'], true);

?>

<section class="card rounded-2xl admin-ad-edit" role="region" aria-labelledby="adminAdEditHeading">
  <header class="admin-ad-edit__header">
    <div class="admin-ad-edit__header-main">
      <a class="admin-ad-edit__back" href="<?= iN_HelpSecure($backUrl, false); ?>">
        <?= iN_HelpSecure(customLang('admin_ads_edit_back') ?: 'Back to list', false); ?>
      </a>
      <div class="admin-ad-edit__title">
        <span class="admin-ad-edit__icon"><?= renderVerifiedBadge($iconPath . $iconName, true); ?></span>
        <div>
          <h1 id="adminAdEditHeading"><?= iN_HelpSecure(customLang('admin_ads_edit_heading') ?: 'Edit advertisement', false); ?></h1>
        </div>
      </div>
    </div>
    <div class="admin-ad-edit__status">
      <span class="admin-ad-edit__status-pill <?= iN_HelpSecure($statusClass, false); ?>"><?= iN_HelpSecure($statusLabel, false); ?></span>
      <span class="admin-ad-edit__meta">ID #<?= $adId; ?></span>
      <?php if ($createdAtDisplay !== ''): ?><span class="admin-ad-edit__meta"><?= iN_HelpSecure(customLang('admin_ads_detail_created') ?: 'Created', false); ?>: <?= iN_HelpSecure($createdAtDisplay, false); ?></span><?php endif; ?>
    </div>
  </header>

  <?php if ($adRow && $ownerName !== ''): ?>
    <div class="admin-ad-edit__owner-card">
      <img src="<?= iN_HelpSecure($avatarUrl, false); ?>" alt="" class="admin-ad-edit__avatar" loading="lazy">
      <div class="admin-ad-edit__owner">
        <span class="admin-ad-edit__owner-label"><?= iN_HelpSecure(customLang('admin_ads_edit_owner') ?: 'Advertiser', false); ?></span>
        <span class="admin-ad-edit__owner-name"><?= iN_HelpSecure($ownerName, false); ?></span>
        <?php if ($username !== ''): ?>
          <span class="admin-ad-edit__owner-username"><?= iN_HelpSecure($username, false); ?></span>
        <?php endif; ?>
      </div>
    </div>
  <?php endif; ?>

  <?php if (!$canEdit): ?>
    <div class="box-note admin-ad-edit__notice">
      <?= iN_HelpSecure(customLang('admin_ads_edit_not_found') ?: 'Advertisement not found or cannot be edited.', false); ?>
    </div>
  <?php elseif ($mediaMismatch): ?>
    <div class="box-note admin-ad-edit__notice">
      <?= iN_HelpSecure(customLang('admin_ads_edit_mismatch') ?: 'This advertisement belongs to another media tab.', false); ?>
    </div>
  <?php else: ?>
    <form
        method="post"
        action="<?= iN_HelpSecure($requestUrl, false); ?>"
        class="admin-ad-edit__form"
        data-action="save-advertisement"
        data-ad-media-type="<?= iN_HelpSecure($mediaType, false); ?>"
        data-upload-url="<?= iN_HelpSecure($requestUrl, false); ?>"
    >
      <input type="hidden" name="action" value="update">
      <input type="hidden" name="csrf_token" value="<?= $csrfToken; ?>">
      <input type="hidden" name="ad_id" value="<?= $adId; ?>">
      <input type="hidden" name="page_key" value="<?= iN_HelpSecure($pageKey, false); ?>">

      <div class="admin-ad-edit__layout">
        <div class="admin-ad-edit__main">
          <div class="form-input-wrapper">
            <label class="form-label" for="ad-edit-title"><?= iN_HelpSecure(customLang('admin_ads_edit_field_title') ?: 'Title', false); ?></label>
            <input
                id="ad-edit-title"
                class="form-input"
                type="text"
                name="title"
                value="<?= iN_HelpSecure($titleValue, false); ?>"
                maxlength="180"
                required
            >
          </div>

          <div class="form-input-wrapper">
            <label class="form-label" for="ad-edit-description"><?= iN_HelpSecure(customLang('admin_ads_edit_field_description') ?: 'Description', false); ?></label>
            <textarea
                id="ad-edit-description"
                class="form-input"
                name="description"
                rows="5"
                maxlength="1000"
                required><?= iN_HelpSecure($descriptionValue, false); ?></textarea>
          </div>

          <div class="admin-ad-edit__grid">
            <div class="form-input-wrapper">
              <label class="form-label" for="ad-edit-target"><?= iN_HelpSecure(customLang('admin_ads_detail_target') ?: 'Target impressions', false); ?></label>
              <input
                  id="ad-edit-target"
                  class="form-input"
                  type="number"
                  min="1"
                  step="1"
                  name="target_impressions"
                  value="<?= max(1, $targetImpressions); ?>"
                  required
              >
            </div>
            <div class="form-input-wrapper">
              <label class="form-label" for="ad-edit-price"><?= iN_HelpSecure(customLang('admin_ads_detail_price') ?: 'Price per impression', false); ?></label>
              <input
                  id="ad-edit-price"
                  class="form-input"
                  type="number"
                  min="<?= iN_HelpSecure($priceStep, false); ?>"
                  step="<?= iN_HelpSecure($priceStep, false); ?>"
                  name="price_per_impression"
                  value="<?= iN_HelpSecure($formatNumber(max((float) $priceStep, $pricePer), $currencyCode, $pricePrecision, $currencyFormatSettings, true), false); ?>"
                  required
              >
            </div>
            <div class="form-input-wrapper">
              <label class="form-label" for="ad-edit-budget"><?= iN_HelpSecure(customLang('admin_ads_detail_budget') ?: 'Total budget', false); ?></label>
              <input
                  id="ad-edit-budget"
                  class="form-input"
                  type="number"
                  min="<?= iN_HelpSecure($budgetStep, false); ?>"
                  step="<?= iN_HelpSecure($budgetStep, false); ?>"
                  name="total_budget"
                  value="<?= iN_HelpSecure($formatNumber(max((float) $budgetStep, $totalBudget), $currencyCode, $budgetPrecision, $currencyFormatSettings, true), false); ?>"
                  required
              >
            </div>
            <div class="form-input-wrapper">
              <label class="form-label" for="ad-edit-duration"><?= iN_HelpSecure(customLang('admin_ads_detail_duration') ?: 'Duration', false); ?></label>
              <input
                  id="ad-edit-duration"
                  class="form-input"
                  type="number"
                  min="1"
                  step="1"
                  name="duration_days"
                  value="<?= max(1, $durationDays); ?>"
                  required
              >
            </div>
          </div>
        </div>

        <aside class="admin-ad-edit__sidebar">
          <?php if ($mediaType === 'image'): ?>
            <div class="admin-ad-edit__media-card" data-ad-media-manager>
              <div class="admin-ad-edit__media-header">
                <h2><?= iN_HelpSecure(customLang('admin_ads_edit_media_title') ?: 'Gallery', false); ?></h2>
                <span><?= iN_HelpSecure(customLang('admin_ads_edit_media_hint') ?: 'Drag to reorder. Remove images you no longer want to display.', false); ?></span>
              </div>
              <div class="admin-ad-edit__media-list-wrapper">
                <ul class="admin-ad-edit__media-list" data-sortable-list="ad-media" data-ad-media-list>
                  <?php foreach ($mediaList as $index => $media):
                    $path = (string) ($media['path'] ?? '');
                    $url = (string) ($media['url'] ?? '');
                  ?>
                  <li class="admin-ad-edit__media-item" data-sortable-item draggable="true">
                    <input type="hidden" name="media[]" value="<?= iN_HelpSecure($path, false); ?>">
                    <span class="admin-ad-edit__media-handle" aria-hidden="true">☰</span>
                    <img src="<?= iN_HelpSecure($url, false); ?>" alt="" loading="lazy">
                    <button type="button" class="admin-ad-edit__media-remove" data-remove-media aria-label="<?= iN_HelpSecure(customLang('admin_ads_edit_media_remove') ?: 'Remove image', false); ?>">&times;</button>
                  </li>
                  <?php endforeach; ?>
                </ul>
                <p class="admin-ad-edit__media-empty" data-ad-media-empty<?= $mediaEmpty ? '' : ' hidden'; ?>>
                  <?= iN_HelpSecure(customLang('admin_ads_edit_media_empty') ?: 'No images yet. Upload to add.', false); ?>
                </p>
              </div>
              <div class="admin-ad-edit__media-actions">
                <input type="file" name="images[]" accept="image/jpeg,image/png" multiple hidden data-ad-media-input>
                <button type="button" class="admin-ad-edit__media-upload" data-ad-media-add><?= iN_HelpSecure(customLang('admin_ads_edit_add_images') ?: 'Add images', false); ?></button>
              </div>
            </div>
          <?php elseif ($mediaType === 'video'): ?>
            <div class="admin-ad-edit__video-card">
              <h2><?= iN_HelpSecure(customLang('admin_ads_edit_video_preview') ?: 'Video preview', false); ?></h2>
              <?php if ($mediaUrl !== ''): ?>
                <video src="<?= iN_HelpSecure($mediaUrl, false); ?>" controls preload="metadata"></video>
              <?php else: ?>
                <p class="admin-ad-edit__media-empty"><?= iN_HelpSecure(customLang('admin_ads_media_missing') ?: 'Media unavailable', false); ?></p>
              <?php endif; ?>
              <p class="admin-ad-edit__note"><?= iN_HelpSecure(customLang('admin_ads_edit_video_note') ?: 'Video files cannot be replaced from the admin panel.', false); ?></p>
            </div>
          <?php endif; ?>

          <div class="admin-ad-edit__stats">
            <h2><?= iN_HelpSecure(customLang('admin_ads_edit_stats_title') ?: 'Performance', false); ?></h2>
            <dl>
              <div>
                <dt><?= iN_HelpSecure(customLang('admin_ads_detail_views') ?: 'Views', false); ?></dt>
                <dd><?= number_format(max(0, $views)); ?></dd>
              </div>
              <div>
                <dt><?= iN_HelpSecure(customLang('admin_ads_detail_clicks') ?: 'Clicks', false); ?></dt>
                <dd><?= number_format(max(0, $clicks)); ?></dd>
              </div>
              <div>
                <dt><?= iN_HelpSecure(customLang('admin_ads_detail_budget') ?: 'Total budget', false); ?></dt>
                <dd><?= iN_HelpSecure($formatCurrency(max(0, $totalBudget), $currencyCode), false); ?></dd>
              </div>
            </dl>
          </div>
        </aside>
      </div>

      <footer class="admin-ad-edit__actions">
        <button type="submit" class="pe-save btn-hover" data-ad-save><?= iN_HelpSecure(customLang('admin_ads_edit_save') ?: 'Save changes', false); ?></button>
        <a class="admin-ad-edit__cancel" href="<?= iN_HelpSecure($backUrl, false); ?>"><?= iN_HelpSecure(customLang('cancel') ?: 'Cancel', false); ?></a>
      </footer>
    </form>
  <?php endif; ?>
</section>
