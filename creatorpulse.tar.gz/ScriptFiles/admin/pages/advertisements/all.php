<?php
declare(strict_types=1);

$advertPageConfig = [
    'page_key'       => 'ads_all',
    'title_key'      => 'admin_ads_all_title',
    'default_status' => '',
    'media_type'     => '',
    'icon'           => 'media.svg',
    'empty_lang_key' => 'admin_ads_empty_all',
];

$adId = (int) ($_GET['ad_id'] ?? 0);

if ($adId > 0) {
    require __DIR__ . '/edit_common.php';
} else {
    require __DIR__ . '/list_common.php';
}
