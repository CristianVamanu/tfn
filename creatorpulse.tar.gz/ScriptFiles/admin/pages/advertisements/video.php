<?php
declare(strict_types=1);

$advertPageConfig = [
    'page_key'       => 'ads_videos',
    'title_key'      => 'admin_ads_video_title',
    'default_status' => '',
    'media_type'     => 'video',
    'icon'           => 'video.svg',
    'empty_lang_key' => 'admin_ads_empty_video',
];

$adId = (int) ($_GET['ad_id'] ?? 0);

if ($adId > 0) {
    require __DIR__ . '/edit_common.php';
} else {
    require __DIR__ . '/list_common.php';
}
