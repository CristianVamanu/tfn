<?php
declare(strict_types=1);
require_once __DIR__ . '/../_bootstrap.php'; // Guard admin access

global $db, $base_url, $ADMIN_CSRF, $ADM, $iconPath, $RL;

// Prepare data (no logic changes)
$pageSlug = 'content';
$pageNo = isset($_GET['page_no']) ? max(1, (int)$_GET['page_no']) : 1;
$per    = isset($_GET['per']) ? max(10, min(100, (int)$_GET['per'])) : 20;
$posts   = $ADM->ADM_ListRecentPosts(200);
$total   = (int) count($posts);
$pages   = (int) max(1, ceil($total / max(1,$per)));
$start   = (int) (($pageNo - 1) * $per);
$display = array_slice($posts, $start, $per);
$canContentDelete = admin_has_permission('content.delete');
$permissionTip = customLang('admin_permission_denied_tooltip') ?: 'You do not have permission to perform this action.';
?>

<section class="card rounded-2xl" role="region" aria-labelledby="adminUserPostsHeading">
  <div class="list-header" id="adminUserPostsHeading">
    <span class="icon"><?php echo renderVerifiedBadge($iconPath . 'trending.svg', true); ?></span>
    <span><strong><?php echo iN_HelpSecure((customLang('admin_posts_heading') ?: 'User Posts') . ' > ' . (customLang('admin_posts_tab_all') ?: 'All Posts'), false); ?></strong></span>
  </div>
  <form method="get" class="form-container form-container--columns" action="<?php echo iN_HelpSecure($base_url . 'admin/index.php', false); ?>">
    <input type="hidden" name="page" value="<?php echo iN_HelpSecure($pageSlug, false); ?>">
    <div class="form-input-wrapper">
      <label class="form-label" for="per"><?php echo iN_HelpSecure(customLang('admin_posts_filter_per_page') ?: 'Per page', false); ?></label>
      <select id="per" name="per" class="form-input">
        <?php foreach ([10,20,50,100] as $pp): ?>
          <option value="<?php echo $pp; ?>"<?php echo $pp===$per?' selected':''; ?>><?php echo $pp; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper form-actions">
      <label class="form-label sr-only" for="btnGo"><?php echo iN_HelpSecure(customLang('admin_posts_filter_apply') ?: 'Apply', false); ?></label>
      <button id="btnGo" type="submit" class="pe-save btn-hover"><?php echo iN_HelpSecure(customLang('admin_posts_filter_apply') ?: 'Apply', false); ?></button>
    </div>
  </form>
  <div class="table-responsive mt-4">
    <table class="table table-striped table-sm table-subs full-width">
      <thead>
        <tr>
          <th><?php echo iN_HelpSecure(customLang('admin_posts_col_id') ?: 'ID'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_posts_col_owner') ?: 'Owner'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_posts_col_visibility') ?: 'Visibility'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_posts_col_type') ?: 'Type'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_posts_col_likes') ?: 'Likes'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_posts_col_comments') ?: 'Comments'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_posts_col_shares') ?: 'Shares'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_posts_col_created') ?: 'Created'); ?></th>
          <th><?php echo iN_HelpSecure(customLang('admin_posts_col_actions') ?: 'Actions'); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$display): ?>
        <tr>
          <td colspan="9" class="text-center text-muted empty_class_table">
            <?php echo iN_HelpSecure(customLang('admin_posts_empty_posts') ?: 'No posts found.', false); ?>
          </td>
        </tr>
        <?php else: foreach ($display as $p):
          $pid = (int) $p['post_id'];
          $vis = (string) $p['post_visibility'];
          $postUrl = ($base_url ?? '/') . 'posts/' . $pid . '/' . rawurlencode((string)($p['username'] ?? ''));
        ?>
        <tr data-row-href="<?php echo iN_HelpSecure($postUrl, false); ?>">
          <td><?php echo $pid; ?></td>
          <td>
            <?php
              $ownerId = (int) ($p['post_owner_id'] ?? 0);
              $ownerU  = (string) ($p['username'] ?? '');
              $ownerAvRel = (isset($RL) && method_exists($RL, 'RL_userAvatar')) ? $RL->RL_userAvatar($ownerId) : 'uploads/user_avatars/default.jpeg';
              $ownerAvUrl = admin_resolve_media_url($ownerAvRel);
              $ownerUrl= ($base_url ?? '/') . 'profile/' . rawurlencode($ownerU);
              $owner   = (isset($RL) && method_exists($RL,'RL_GetUserDetails')) ? $RL->RL_GetUserDetails($ownerId) : [];
              $ownerName = (string) ($owner['user_fullname'] ?? $ownerU);
            ?>
            <a class="user-pill" href="<?php echo iN_HelpSecure($ownerUrl, false); ?>">
              <img class="avatar-32" src="<?php echo iN_HelpSecure($ownerAvUrl, false); ?>" alt="<?php echo iN_HelpSecure('Avatar of ' . $ownerU, false); ?>">
              <span class="name"><?php echo iN_HelpSecure($ownerName, false); ?></span>
            </a>
          </td>
          <td>
            <?php
              $v = strtolower($vis);
              $vIcon = ($v === 'everyone') ? 'world.svg' : (($v === 'subscribers') ? 'subscriber.svg' : (($v === 'locked') ? 'locked.svg' : (($v === 'followers') ? 'follower.svg' : 'world.svg')));
            ?>
            <span class="vis-tag vis--<?php echo iN_HelpSecure($v, false); ?>">
              <span class="tag-icon"><?php echo renderVerifiedBadge($iconPath . $vIcon, true); ?></span>
              <span class="vis-label"><?php echo iN_HelpSecure(ucfirst($v)); ?></span>
              <span class="tag-link"><?php echo renderVerifiedBadge($iconPath . 'link_out.svg', true); ?></span>
            </span>
          </td>
          <?php
            $pd = (isset($RL) && method_exists($RL,'RL_GetPostData')) ? ($RL->RL_GetPostData($pid) ?: []) : [];
            $ptype = (string) ($pd['post_type'] ?? '');
            $likes = (isset($RL) && method_exists($RL,'RL_CountLikes')) ? (int)$RL->RL_CountLikes($pid) : 0;
            $comms = (isset($RL) && method_exists($RL,'RL_TotalComment')) ? (int)$RL->RL_TotalComment($pid) : 0;
            $shares= (isset($RL) && method_exists($RL,'RL_CountPostShares')) ? (int)$RL->RL_CountPostShares($pid) : 0;
            $createdTs = (int)($p['post_created_time'] ?? 0);
            $createdTxt= $createdTs > 0 ? date('Y-m-d H:i', $createdTs) : '-';
          ?>
          <td>
            <?php $tIcon = ($ptype === 'video') ? 'video.svg' : 'image.svg'; ?>
            <span class="type-tag type--<?php echo iN_HelpSecure($ptype ?: 'unknown', false); ?>">
              <span class="tag-icon"><?php echo renderVerifiedBadge($iconPath . $tIcon, true); ?></span>
              <span class="type-label"><?php echo iN_HelpSecure(ucfirst($ptype) ?: '-'); ?></span>
            </span>
          </td>
          <td><span class="amount-mono metric-mini"><?php echo renderVerifiedBadge($iconPath . 'like.svg', true); ?> <?php echo (int)$likes; ?></span></td>
          <td><span class="amount-mono metric-mini"><?php echo renderVerifiedBadge($iconPath . 'comment.svg', true); ?> <?php echo (int)$comms; ?></span></td>
          <td><span class="amount-mono metric-mini"><?php echo renderVerifiedBadge($iconPath . 'send.svg', true); ?> <?php echo (int)$shares; ?></span></td>
          <td><span class="text-muted fs-13 meta-time"><?php echo renderVerifiedBadge($iconPath . 'time.svg', true); ?> <?php echo iN_HelpSecure($createdTxt, false); ?></span></td>
          <td>
            <?php
              $ownerDetailUrl = iN_HelpSecure(($base_url ?? '/') . 'admin/index.php?page=user_detail&id=' . (string)(int)$ownerId, false);
            ?>
            <div class="post-settings-btn-box flex align_items relative">
              <button
                type="button"
                class="post-settings-btn flex align_items_justify_content relative"
                aria-expanded="false"
                aria-haspopup="menu"
                title="Actions"
                data-id="<?php echo (int)$pid; ?>"
              >
                <?php echo renderVerifiedBadge($iconPath . 'dots.svg', false); ?>
              </button>
            </div>

            <div id="postMenuPopup-<?php echo (int)$pid; ?>" class="post-menu-popup none" aria-hidden="true" role="dialog" aria-label="<?php echo iN_HelpSecure('Post actions for #' . $pid, false); ?>">
              <div class="pm-sheet-container">
                <div class="pm-sheet">
                  <a class="pm-item" href="<?php echo iN_HelpSecure($postUrl, false); ?>"><?php echo renderVerifiedBadge($iconPath . 'link_out.svg', true); ?> <span><?php echo iN_HelpSecure(customLang('admin_posts_action_open') ?: 'Open post', false); ?></span></a>
                  <a class="pm-item" href="<?php echo iN_HelpSecure(($base_url ?? '/') . 'admin/index.php?page=post_edit&id=' . (string)(int)$pid, false); ?>"><?php echo renderVerifiedBadge($iconPath . 'settings.svg', true); ?> <span><?php echo iN_HelpSecure(customLang('admin_posts_action_edit') ?: 'Edit post', false); ?></span></a>
                  <a class="pm-item" href="<?php echo $ownerDetailUrl; ?>"><?php echo renderVerifiedBadge($iconPath . 'profile.svg', true); ?> <span><?php echo iN_HelpSecure(customLang('admin_posts_action_owner_details') ?: 'Owner details', false); ?></span></a>
                  <div class="pm-divider"></div>
                  <button type="button" class="pm-item flex align_items_justify_content js-pact is-danger<?= $canContentDelete ? '' : ' is-disabled'; ?>" data-action="delete" data-post-id="<?php echo (int)$pid; ?>"<?= $canContentDelete ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?php echo renderVerifiedBadge($iconPath . 'delete.svg', true); ?> <span><?php echo iN_HelpSecure(customLang('admin_posts_action_delete') ?: 'Delete post', false); ?></span></button>
                  <button type="button" class="pm-item pm-cancel">Cancel</button>
                </div>
              </div>
            </div>
          </td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <?php
    echo dz_render_pagination(
      $base_url . 'admin/index.php',
      [ 'page' => $pageSlug, 'per' => (string)$per ],
      (int)$pageNo,
      (int)$pages,
      [ 'show_goto' => true, 'radius' => 1 ]
    );
  ?>

</section>
