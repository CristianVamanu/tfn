<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

global $ADM, $base_url, $ADMIN_CSRF, $siteData, $currency, $currencies, $currencyFormatSettings;

$q = trim((string)($_GET['q'] ?? ''));
$status = strtolower(trim((string)($_GET['status'] ?? '')));
$access = strtolower(trim((string)($_GET['access'] ?? '')));
$page = max(1, (int)($_GET['page_no'] ?? 1));
$per = max(10, min(100, (int)($_GET['per'] ?? 20)));
$data = $ADM->ADM_PagedAudioRooms($q, $page, $per, ['status' => $status, 'access' => $access]);
$overview = $ADM->ADM_AudioRoomOverview();
$rows = $data['rows'];
$total = (int)$data['total'];
$pages = max(1, (int)ceil($total / max(1, $per)));
$canManage = admin_has_permission('content.edit');
$actionUrl = rtrim((string)$base_url, '/') . '/admin/request/audio_room_action.php';
$currenciesMap = isset($currencies) && is_array($currencies) ? $currencies : [];
$defaultCurrencyCode = strtoupper(trim((string)($currency ?? $siteData['default_currency'] ?? 'USD')));
$resolvedCurrencyFormat = function_exists('dz_currency_normalize_settings')
    ? dz_currency_normalize_settings(is_array($currencyFormatSettings ?? null) ? $currencyFormatSettings : [])
    : (is_array($currencyFormatSettings ?? null) ? $currencyFormatSettings : []);
$money = static function (float $amount, ?string $code = null) use ($defaultCurrencyCode, $currenciesMap, $resolvedCurrencyFormat): string {
    $currencyCode = strtoupper(trim((string)($code ?: $defaultCurrencyCode)));
    $currencySymbol = trim((string)($currenciesMap[$currencyCode] ?? ''));
    if ($currencySymbol === '') {
        $currencySymbol = $currencyCode;
    }
    return function_exists('dz_format_currency')
        ? dz_format_currency($amount, $currencyCode, $currencySymbol, $resolvedCurrencyFormat)
        : number_format($amount, 2);
};
$label = static fn(string $key, string $fallback): string => customLang($key) ?: $fallback;
$queryBase = ['page' => 'audio_rooms', 'q' => $q, 'status' => $status, 'access' => $access, 'per' => $per];
?>
<section class="card rounded-2xl admin-audio-rooms" data-admin-audio-rooms data-action-url="<?= iN_HelpSecure($actionUrl); ?>" data-csrf="<?= iN_HelpSecure($ADMIN_CSRF); ?>">
  <div class="admin-audio-rooms__header">
    <div class="admin-audio-rooms__title">
      <span class="admin-audio-rooms__title-icon"><?= render_icon('podcast', true); ?></span>
      <div>
        <h1><?= iN_HelpSecure($label('admin_audio_rooms_title', 'Audio Rooms'), false); ?></h1>
        <p><?= iN_HelpSecure($label('admin_audio_rooms_intro', 'Monitor live rooms, attendance, access and room earnings.'), false); ?></p>
      </div>
    </div>
    <a class="admin-button admin-button--neutral" href="<?= iN_HelpSecure($base_url . 'audio-rooms'); ?>" target="_blank" rel="noopener">
      <?= iN_HelpSecure($label('admin_audio_rooms_open_public', 'Open Audio Rooms'), false); ?>
    </a>
  </div>

  <div class="admin-audio-rooms__stats" aria-label="<?= iN_HelpSecure($label('admin_audio_rooms_summary', 'Audio Room summary')); ?>">
    <article><span><?= render_icon('podcast', true); ?></span><div><strong><?= (int)$overview['total_rooms']; ?></strong><small><?= iN_HelpSecure($label('admin_audio_rooms_total', 'Total rooms'), false); ?></small></div></article>
    <article><span><?= render_icon('speaker', true); ?></span><div><strong><?= (int)$overview['live_rooms']; ?></strong><small><?= iN_HelpSecure($label('admin_audio_rooms_live', 'Live now'), false); ?></small></div></article>
    <article><span><?= render_icon('payments', true); ?></span><div><strong><?= iN_HelpSecure($money((float)$overview['ticket_gross'] + (float)$overview['tip_gross'])); ?></strong><small><?= iN_HelpSecure($label('admin_audio_rooms_gross', 'Gross revenue'), false); ?></small></div></article>
    <article><span><?= render_icon('wallet', true); ?></span><div><strong><?= iN_HelpSecure($money((float)$overview['platform_revenue'])); ?></strong><small><?= iN_HelpSecure($label('admin_audio_rooms_platform_revenue', 'Platform revenue'), false); ?></small></div></article>
  </div>

  <form class="form-container form-container--columns admin-audio-rooms__filters" method="get" action="<?= iN_HelpSecure($base_url . 'admin/index.php'); ?>">
    <input type="hidden" name="page" value="audio_rooms">
    <div class="form-input-wrapper" data-field="search">
      <label class="form-label" for="audio-room-search"><?= iN_HelpSecure($label('admin_common_search', 'Search'), false); ?></label>
      <input id="audio-room-search" class="form-input" type="search" name="q" value="<?= iN_HelpSecure($q); ?>" placeholder="<?= iN_HelpSecure($label('admin_audio_rooms_search_placeholder', 'Room title, host or room ID')); ?>">
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="audio-room-status"><?= iN_HelpSecure($label('status', 'Status'), false); ?></label>
      <select id="audio-room-status" class="form-input" name="status">
        <?php foreach (['' => 'All statuses', 'live' => 'Live', 'created' => 'Created', 'ended' => 'Ended', 'cancelled' => 'Cancelled'] as $value => $text): ?>
          <option value="<?= iN_HelpSecure($value); ?>"<?= $status === $value ? ' selected' : ''; ?>><?= iN_HelpSecure($label('admin_audio_room_status_' . ($value ?: 'all'), $text), false); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="audio-room-access"><?= iN_HelpSecure($label('admin_audio_rooms_access', 'Access'), false); ?></label>
      <select id="audio-room-access" class="form-input" name="access">
        <?php foreach (['' => 'All access', 'free' => 'Free', 'paid' => 'Paid'] as $value => $text): ?>
          <option value="<?= iN_HelpSecure($value); ?>"<?= $access === $value ? ' selected' : ''; ?>><?= iN_HelpSecure($label('admin_audio_room_access_' . ($value ?: 'all'), $text), false); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="audio-room-per"><?= iN_HelpSecure($label('admin_users_filter_per_page', 'Per page'), false); ?></label>
      <select id="audio-room-per" class="form-input" name="per">
        <?php foreach ([10, 20, 50, 100] as $value): ?><option value="<?= $value; ?>"<?= $per === $value ? ' selected' : ''; ?>><?= $value; ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper form-actions">
      <button type="submit" class="pe-save btn-hover"><?= iN_HelpSecure($label('admin_users_filter_apply', 'Apply'), false); ?></button>
    </div>
  </form>

  <div class="admin-audio-rooms__table-wrap table-responsive">
    <table class="table table-striped table-sm admin-audio-rooms__table">
      <thead><tr>
        <th><?= iN_HelpSecure($label('admin_audio_rooms_room', 'Room'), false); ?></th>
        <th><?= iN_HelpSecure($label('creator', 'Host'), false); ?></th>
        <th><?= iN_HelpSecure($label('status', 'Status'), false); ?></th>
        <th><?= iN_HelpSecure($label('admin_audio_rooms_access', 'Access'), false); ?></th>
        <th><?= iN_HelpSecure($label('admin_audio_rooms_attendance', 'Attendance'), false); ?></th>
        <th><?= iN_HelpSecure($label('admin_audio_rooms_earnings', 'Earnings'), false); ?></th>
        <th><?= iN_HelpSecure($label('updated', 'Schedule'), false); ?></th>
        <th><?= iN_HelpSecure($label('admin_users_actions_label', 'Actions'), false); ?></th>
      </tr></thead>
      <tbody>
      <?php if (!$rows): ?><tr><td colspan="8" class="text-center text-muted"><?= iN_HelpSecure($label('admin_audio_rooms_empty', 'No Audio Rooms match these filters.'), false); ?></td></tr><?php endif; ?>
      <?php foreach ($rows as $room):
        $id = (int)$room['room_id'];
        $roomStatus = strtolower((string)$room['status']);
        $name = trim((string)($room['user_fullname'] ?? '')) ?: '@' . (string)($room['username'] ?? '');
        $avatar = admin_resolve_media_url((string)($room['user_avatar'] ?? 'uploads/user_avatars/default.jpeg'));
        $roomCurrency = (string)($room['currency'] ?: null);
        $gross = (float)$room['ticket_gross'] + (float)$room['tip_gross'];
        $started = (int)($room['started_at'] ?: $room['created_at']);
        $canClose = $canManage && in_array($roomStatus, ['created', 'live'], true);
      ?>
        <tr data-audio-room-row="<?= $id; ?>" data-status="<?= iN_HelpSecure($roomStatus); ?>">
          <td><div class="admin-audio-room-cell"><span><?= render_icon('podcast', true); ?></span><div><strong><?= iN_HelpSecure((string)$room['title']); ?></strong><small>#<?= $id; ?> · <?= iN_HelpSecure((string)$room['audience']); ?></small></div></div></td>
          <td><a class="admin-audio-room-host" href="<?= iN_HelpSecure($base_url . 'profile/' . rawurlencode((string)$room['username'])); ?>" target="_blank" rel="noopener"><img src="<?= iN_HelpSecure($avatar); ?>" alt=""><span><?= iN_HelpSecure($name); ?><small>@<?= iN_HelpSecure((string)$room['username']); ?></small></span></a></td>
          <td><span class="admin-audio-room-status admin-audio-room-status--<?= iN_HelpSecure($roomStatus); ?>"><?= iN_HelpSecure($label('admin_audio_room_status_' . $roomStatus, ucfirst($roomStatus)), false); ?></span></td>
          <td><strong><?= (int)$room['is_paid'] === 1 ? iN_HelpSecure($money((float)$room['entry_price'], $roomCurrency)) : iN_HelpSecure($label('admin_audio_room_access_free', 'Free'), false); ?></strong><small class="admin-audio-room-subtext"><?= (int)$room['is_paid'] === 1 ? (int)$room['ticket_count'] . ' ' . iN_HelpSecure($label('admin_audio_rooms_tickets', 'tickets'), false) : iN_HelpSecure($label('admin_audio_rooms_open_access', 'Open access'), false); ?></small></td>
          <td><strong><?= (int)$room['participant_count']; ?></strong><small class="admin-audio-room-subtext"><?= (int)$room['online_count']; ?> <?= iN_HelpSecure($label('admin_audio_rooms_online', 'online'), false); ?> · <?= (int)$room['speaker_count']; ?> <?= iN_HelpSecure($label('admin_audio_rooms_speakers', 'speakers'), false); ?></small></td>
          <td><strong><?= iN_HelpSecure($money($gross, $roomCurrency)); ?></strong><small class="admin-audio-room-subtext"><?= (int)$room['tip_count']; ?> <?= iN_HelpSecure($label('admin_audio_rooms_tips', 'tips'), false); ?></small></td>
          <td><time datetime="<?= date('c', $started); ?>"><?= iN_HelpSecure(date('Y-m-d H:i', $started)); ?></time><?php if (!empty($room['ended_at'])): ?><small class="admin-audio-room-subtext"><?= iN_HelpSecure($label('admin_audio_rooms_ended', 'Ended'), false); ?> <?= iN_HelpSecure(date('Y-m-d H:i', (int)$room['ended_at'])); ?></small><?php endif; ?></td>
          <td>
            <div class="post-settings-btn-box flex align_items relative"><button type="button" class="post-settings-btn flex align_items_justify_content relative" aria-expanded="false" aria-haspopup="menu" data-id="audio-room-<?= $id; ?>" title="<?= iN_HelpSecure($label('admin_users_actions_label', 'Actions')); ?>"><?= render_icon('dots', true); ?></button></div>
            <div id="postMenuPopup-audio-room-<?= $id; ?>" class="post-menu-popup none" aria-hidden="true" role="dialog"><div class="pm-sheet-container"><div class="pm-sheet">
              <a class="pm-item" href="<?= iN_HelpSecure($base_url . 'audio-room/' . $id); ?>" target="_blank" rel="noopener"><?= iN_HelpSecure($label('admin_audio_rooms_view', 'View room'), false); ?></a>
              <a class="pm-item" href="<?= iN_HelpSecure($base_url . 'profile/' . rawurlencode((string)$room['username'])); ?>" target="_blank" rel="noopener"><?= iN_HelpSecure($label('view_profile', 'View profile'), false); ?></a>
              <?php if ($canClose): ?><button type="button" class="pm-item is-danger js-admin-audio-room-close" data-room-id="<?= $id; ?>" data-room-title="<?= iN_HelpSecure((string)$room['title']); ?>"><?= iN_HelpSecure($roomStatus === 'live' ? $label('admin_audio_rooms_end', 'End room') : $label('admin_audio_rooms_cancel', 'Cancel room'), false); ?></button><?php endif; ?>
              <button type="button" class="pm-item pm-cancel"><?= iN_HelpSecure($label('cancel', 'Cancel'), false); ?></button>
            </div></div></div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <?php if ($pages > 1): ?>
    <nav class="admin-audio-rooms__pagination" aria-label="Pagination">
      <?php if ($page > 1): ?><a href="?<?= iN_HelpSecure(http_build_query(array_merge($queryBase, ['page_no' => $page - 1]))); ?>"><?= iN_HelpSecure($label('previous', 'Previous')); ?></a><?php endif; ?>
      <span><?= $page; ?> / <?= $pages; ?></span>
      <?php if ($page < $pages): ?><a href="?<?= iN_HelpSecure(http_build_query(array_merge($queryBase, ['page_no' => $page + 1]))); ?>"><?= iN_HelpSecure($label('next', 'Next')); ?></a><?php endif; ?>
    </nav>
  <?php endif; ?>
  <div class="admin-audio-rooms__feedback" data-audio-room-feedback role="status" aria-live="polite"></div>
</section>
