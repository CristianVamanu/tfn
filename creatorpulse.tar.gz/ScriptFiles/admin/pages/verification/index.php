<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';

global $RL, $db, $base_url, $ADMIN_CSRF, $iconPath;

$allowedStatuses = ['pending', 'approved', 'rejected'];
$statusParam = isset($_GET['status']) ? strtolower((string)$_GET['status']) : 'pending';
$status = in_array($statusParam, $allowedStatuses, true) ? $statusParam : 'pending';

$pageNo = isset($_GET['p']) ? (int)$_GET['p'] : 1;
if ($pageNo < 1) {
    $pageNo = 1;
}

$perPage = 50;
$offset = ($pageNo - 1) * $perPage;

$requests = [];
if (isset($RL) && is_object($RL) && method_exists($RL, 'RL_ListCreatorVerificationRequests')) {
    $requests = $RL->RL_ListCreatorVerificationRequests($status, $perPage, $offset);
} else {
    try {
        $stmt = $db->prepare('SELECT * FROM i_verification_requests WHERE request_status = :st ORDER BY updated_at DESC, request_id DESC LIMIT :lim OFFSET :off');
        $stmt->bindValue(':st', $status, PDO::PARAM_STR);
        $stmt->bindValue(':lim', $perPage, PDO::PARAM_INT);
        $stmt->bindValue(':off', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $requests = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $__) {
        $requests = [];
    }
}

foreach ($requests as &$requestRow) {
    if (isset($requestRow['documents']) && !is_array($requestRow['documents'])) {
        $decoded = json_decode((string)$requestRow['documents'], true);
        if (is_array($decoded)) {
            $requestRow['documents'] = $decoded;
        }
    }
    if (!isset($requestRow['documents']) || !is_array($requestRow['documents'])) {
        $requestRow['documents'] = [];
    }
}
unset($requestRow);

$userIds = [];
$adminIds = [];
foreach ($requests as $row) {
    if (isset($row['user_id'])) {
        $userIds[] = (int)$row['user_id'];
    }
    if (!empty($row['admin_id'])) {
        $adminIds[] = (int)$row['admin_id'];
    }
}
$userIds = array_values(array_unique(array_filter($userIds, static fn(int $id): bool => $id > 0)));
$adminIds = array_values(array_unique(array_filter($adminIds, static fn(int $id): bool => $id > 0)));

$fetchUsers = static function (array $ids) use ($db): array {
    $map = [];
    if (empty($ids)) {
        return $map;
    }
    $placeholders = [];
    $params = [];
    foreach ($ids as $idx => $id) {
        $placeholder = ':u' . $idx;
        $placeholders[] = $placeholder;
        $params[$placeholder] = (int)$id;
    }
    $sql = 'SELECT user_id, username, user_fullname, user_avatar, creator_status FROM i_users WHERE user_id IN (' . implode(',', $placeholders) . ')';
    try {
        $stmt = $db->prepare($sql);
        foreach ($params as $placeholder => $value) {
            $stmt->bindValue($placeholder, $value, PDO::PARAM_INT);
        }
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($rows as $row) {
            $map[(int)$row['user_id']] = $row;
        }
    } catch (Throwable $__) {
        // ignore
    }
    return $map;
};

$userMap = $fetchUsers($userIds);
$adminMap = $fetchUsers($adminIds);

$siteBase = isset($base_url) && $base_url !== '' ? (string)$base_url : '/';
$siteBase = rtrim($siteBase, '/') . '/';

$actionUrl = $siteBase . 'admin/request/verification.php';
$detailUrlBase = $siteBase . 'admin/index.php?page=user_detail&id=';

$buildFilterUrl = static function (string $targetStatus, int $page = 1) use ($siteBase): string {
    $params = [
        'page'   => 'verification_requests',
        'status' => $targetStatus,
    ];
    if ($page > 1) {
        $params['p'] = $page;
    }
    return $siteBase . 'admin/index.php?' . http_build_query($params);
};

$buildPageUrl = static function (int $page) use ($status, $siteBase): string {
    $params = [
        'page'   => 'verification_requests',
        'status' => $status,
    ];
    if ($page > 1) {
        $params['p'] = $page;
    }
    return $siteBase . 'admin/index.php?' . http_build_query($params);
};

$documentLabels = [
    'id_front'       => customLang('creator_identity_id_front', 'Government ID - front'),
    'id_back'        => customLang('creator_identity_id_back', 'Government ID - back'),
    'passport'       => customLang('creator_identity_passport', 'Passport'),
    'driver_license' => customLang('creator_identity_driver_license', 'Driver license'),
    'selfie'         => customLang('creator_identity_selfie', 'Selfie'),
];

$docLabelFor = static function (string $key, int $index = 0) use ($documentLabels): string {
    if ($key === 'additional') {
        return str_replace('{index}', (string)($index + 1), customLang('admin_verification_docs_additional', 'Additional file #{index}'));
    }
    return $documentLabels[$key] ?? ucwords(str_replace('_', ' ', $key));
};

$statusLabels = [
    'pending'  => customLang('admin_verification_status_pending', 'Pending'),
    'approved' => customLang('admin_verification_status_approved', 'Approved'),
    'rejected' => customLang('admin_verification_status_rejected', 'Rejected'),
];

$statusClasses = [
    'pending'  => 'creator-badge creator-badge--warning',
    'approved' => 'creator-badge creator-badge--success',
    'rejected' => 'creator-badge creator-badge--danger',
];

$formatDate = static function ($value): string {
    $intValue = (int)$value;
    if ($intValue <= 0) {
        return '—';
    }
    return date('d.m.Y H:i', $intValue);
};

$totalRows = 0;
try {
    $countStmt = $db->prepare('SELECT COUNT(*) FROM i_verification_requests WHERE request_status = :st');
    $countStmt->bindValue(':st', $status, PDO::PARAM_STR);
    $countStmt->execute();
    $totalRows = (int)$countStmt->fetchColumn();
} catch (Throwable $__) {
    $totalRows = count($requests);
}
$totalPages = max(1, (int)ceil($totalRows / $perPage));

$csrfToken = isset($ADMIN_CSRF) ? (string)$ADMIN_CSRF : '';
$sectionTitle = customLang('admin_verification_heading', 'Creator verification requests');
$sectionIntro = customLang('admin_verification_intro', 'Review documents submitted by creators and approve or reject their onboarding status.');
$bulkHeading = customLang('admin_verification_bulk_heading', 'Bulk review');
$bulkActionPlaceholder = customLang('admin_verification_bulk_action_placeholder', 'Select action');
$bulkNotePlaceholder = customLang('admin_verification_bulk_note_placeholder', 'Optional note sent to selected creators');
$bulkSubmitLabel = customLang('admin_verification_bulk_submit', 'Apply');
$approveLabel = customLang('admin_verification_action_approve', 'Approve');
$rejectLabel = customLang('admin_verification_action_reject', 'Reject');
$viewUserLabel = customLang('admin_verification_action_view_user', 'View user');
$emptyMessage = customLang('admin_verification_empty', 'No verification requests found for this filter.');
$userNoteLabel = customLang('admin_verification_user_note_label', 'Applicant note');
$adminNoteLabel = customLang('admin_verification_admin_note_label', 'Admin note');
$canVerify = admin_has_permission('verification.approve');
$permissionTip = customLang('admin_permission_denied_tooltip') ?: 'You do not have permission to perform this action.';

$tabs = [
    'pending'  => customLang('admin_verification_tab_pending', 'Pending'),
    'approved' => customLang('admin_verification_tab_approved', 'Approved'),
    'rejected' => customLang('admin_verification_tab_rejected', 'Rejected'),
];

$statusHeader = customLang('admin_verification_table_status', 'Status');
$creatorHeader = customLang('admin_verification_table_creator', 'Creator');
$documentsHeader = customLang('admin_verification_table_documents', 'Documents');
$notesHeader = customLang('admin_verification_table_notes', 'Notes');
$submittedHeader = customLang('admin_verification_table_submitted', 'Submitted');
$updatedHeader = customLang('admin_verification_table_updated', 'Updated');
$actionsHeader = customLang('admin_verification_table_actions', 'Actions');

?>

<section class="card rounded-2xl" data-module="verification-requests" data-action-url="<?= iN_HelpSecure($actionUrl, false); ?>">
  <div class="list-header">
    <span class="icon"><?= renderVerifiedBadge($iconPath . 'creator_icon.svg', true); ?></span>
    <span><strong><?= iN_HelpSecure($sectionTitle); ?></strong></span>
  </div>
  <p class="box-note full-width margin-top-bottom"><?= iN_HelpSecure($sectionIntro); ?></p>

  <nav class="verification-tabs" aria-label="Verification status filters">
    <?php foreach ($tabs as $tabKey => $tabLabel): ?>
      <?php $tabUrl = $buildFilterUrl($tabKey); ?>
      <a
        href="<?= iN_HelpSecure($tabUrl, false); ?>"
        class="verification-tab<?= $tabKey === $status ? ' is-active' : ''; ?>"
      ><?= iN_HelpSecure($tabLabel); ?></a>
    <?php endforeach; ?>
  </nav>

  <form class="verification-form" data-role="bulk" method="post" action="<?= iN_HelpSecure($actionUrl, false); ?>">
    <input type="hidden" name="csrf_token" value="<?= iN_HelpSecure($csrfToken, false); ?>">

    <header class="verification-bulk-bar" aria-label="<?= iN_HelpSecure($bulkHeading); ?>">
      <div class="verification-bulk-group">
        <label class="sr-only" for="verification-bulk-action"><?= iN_HelpSecure($bulkHeading); ?></label>
        <select id="verification-bulk-action" name="bulk_action" class="form-input verification-bulk-select"<?= $canVerify ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>>
          <option value=""><?= iN_HelpSecure($bulkActionPlaceholder); ?></option>
          <option value="approve"><?= iN_HelpSecure($approveLabel); ?></option>
          <option value="reject"><?= iN_HelpSecure($rejectLabel); ?></option>
        </select>
      </div>
      <div class="verification-bulk-group">
        <label class="sr-only" for="verification-bulk-note">Notes</label>
        <input
          id="verification-bulk-note"
          class="form-input verification-bulk-note"
          type="text"
          name="note"
          placeholder="<?= iN_HelpSecure($bulkNotePlaceholder, false); ?>"
          <?= $canVerify ? '' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>
        >
      </div>
      <div class="verification-bulk-actions">
        <span class="verification-selected-count" data-selected-count>0</span>
        <button type="submit" class="admin-button admin-button--primary" data-bulk-submit<?= $canVerify ? ' disabled' : ' disabled aria-disabled="true" title="' . iN_HelpSecure($permissionTip, false) . '"'; ?>><?= iN_HelpSecure($bulkSubmitLabel); ?></button>
      </div>
    </header>

    <div class="table-responsive verification-table-wrapper">
      <table class="table table-striped table-sm table-subs verification-table">
        <thead>
          <tr>
            <th class="verification-col-select">
              <input type="checkbox" id="verification-select-all" data-verify-master<?= $canVerify ? '' : ' disabled aria-disabled="true"'; ?>>
              <label for="verification-select-all" class="sr-only">Select all</label>
            </th>
            <th><?= iN_HelpSecure($creatorHeader); ?></th>
            <th><?= iN_HelpSecure($statusHeader); ?></th>
            <th><?= iN_HelpSecure($submittedHeader); ?></th>
            <th><?= iN_HelpSecure($updatedHeader); ?></th>
            <th><?= iN_HelpSecure($documentsHeader); ?></th>
            <th><?= iN_HelpSecure($notesHeader); ?></th>
            <th class="verification-col-actions"><?= iN_HelpSecure($actionsHeader); ?></th>
          </tr>
        </thead>
        <tbody>
        <?php if (empty($requests)): ?>
          <tr>
            <td colspan="8" class="verification-empty"><?= iN_HelpSecure($emptyMessage); ?></td>
          </tr>
        <?php else: ?>
          <?php foreach ($requests as $row):
            $reqId = (int)($row['request_id'] ?? 0);
            $userId = (int)($row['user_id'] ?? 0);
            $reqStatus = isset($row['request_status']) ? (string)$row['request_status'] : 'pending';
            $reqStatus = in_array($reqStatus, $allowedStatuses, true) ? $reqStatus : 'pending';
            $statusClass = $statusClasses[$reqStatus] ?? 'creator-badge';
            $statusLabel = $statusLabels[$reqStatus] ?? ucwords($reqStatus);
            $userRow = $userMap[$userId] ?? [];
            $username = (string)($userRow['username'] ?? 'user-' . $userId);
            $fullName = (string)($userRow['user_fullname'] ?? '');
            $avatarPath = (string)($userRow['user_avatar'] ?? 'uploads/user_avatars/default.jpeg');
            $avatarUrl = admin_resolve_media_url($avatarPath, $siteBase);
            $submittedAt = isset($row['created_at']) ? $formatDate($row['created_at']) : '—';
            $updatedAt = isset($row['updated_at']) ? $formatDate($row['updated_at']) : '—';
            $userDetailUrl = $detailUrlBase . $userId;
            $documents = is_array($row['documents']) ? $row['documents'] : [];
            $userNote = isset($row['notes']) ? trim((string)$row['notes']) : '';
            $adminNote = isset($row['admin_note']) ? trim((string)$row['admin_note']) : '';
            $adminId = isset($row['admin_id']) ? (int)$row['admin_id'] : 0;
            $adminUser = $adminId > 0 ? ($adminMap[$adminId] ?? null) : null;
            $adminName = $adminUser ? (string)($adminUser['username'] ?? $adminUser['user_fullname'] ?? '') : '';
            $isApproved = ($reqStatus === 'approved');
            $isRejected = ($reqStatus === 'rejected');
          ?>
          <tr data-request-row data-request-id="<?= $reqId; ?>">
            <td class="verification-col-select">
              <input
                type="checkbox"
                class="verification-checkbox"
                name="request_ids[]"
                value="<?= $reqId; ?>"
                data-verify-select
                <?= $canVerify ? '' : ' disabled aria-disabled="true"'; ?>
              >
            </td>
            <td class="verification-col-user">
              <div class="verification-user">
                <img src="<?= iN_HelpSecure($avatarUrl, false); ?>" alt="<?= iN_HelpSecure('@' . $username, false); ?>" class="verification-avatar">
                <div class="verification-user-info">
                  <div class="verification-user-name">@<?= iN_HelpSecure($username); ?></div>
                  <?php if ($fullName !== '' && $fullName !== $username): ?>
                    <div class="verification-user-full"><?= iN_HelpSecure($fullName); ?></div>
                  <?php endif; ?>
                </div>
              </div>
            </td>
            <td class="verification-col-status">
              <span class="<?= iN_HelpSecure($statusClass, false); ?>"><?= iN_HelpSecure($statusLabel); ?></span>
            </td>
            <td><?= iN_HelpSecure($submittedAt); ?></td>
            <td><?= iN_HelpSecure($updatedAt); ?></td>
            <td class="verification-col-docs">
              <?php if (!empty($documents)): ?>
                <ul class="doc-list doc-list--compact">
                  <?php foreach ($documents as $docKey => $docValue): ?>
                    <?php if (is_array($docValue)): ?>
                      <?php foreach ($docValue as $idx => $innerPath):
                        if (!$innerPath) { continue; }
                        $docUrl = admin_resolve_media_url((string)$innerPath, $siteBase);
                        $label = $docLabelFor((string)$docKey, (int)$idx);
                      ?>
                        <li><a href="<?= iN_HelpSecure($docUrl, false); ?>" target="_blank" rel="noopener"><?= iN_HelpSecure($label); ?></a></li>
                      <?php endforeach; ?>
                    <?php else:
                      if (!$docValue) { continue; }
                      $docUrl = admin_resolve_media_url((string)$docValue, $siteBase);
                      $label = $docLabelFor((string)$docKey, 0);
                    ?>
                      <li><a href="<?= iN_HelpSecure($docUrl, false); ?>" target="_blank" rel="noopener"><?= iN_HelpSecure($label); ?></a></li>
                    <?php endif; ?>
                  <?php endforeach; ?>
                </ul>
              <?php else: ?>
                <span class="text-muted">—</span>
              <?php endif; ?>
            </td>
            <td class="verification-col-notes">
              <?php if ($userNote !== ''): ?>
                <div class="verification-note">
                  <strong><?= iN_HelpSecure($userNoteLabel); ?>:</strong>
                  <div><?= nl2br(iN_HelpSecure($userNote, false)); ?></div>
                </div>
              <?php endif; ?>
              <?php if ($adminNote !== ''): ?>
                <div class="verification-note">
                  <strong><?= iN_HelpSecure($adminNoteLabel); ?><?= $adminName !== '' ? ' (' . iN_HelpSecure($adminName) . ')' : ''; ?>:</strong>
                  <div><?= nl2br(iN_HelpSecure($adminNote, false)); ?></div>
                </div>
              <?php endif; ?>
              <?php if ($userNote === '' && $adminNote === ''): ?>
                <span class="text-muted">—</span>
              <?php endif; ?>
            </td>
            <td class="verification-col-actions">
              <div class="verification-actions">
                <button
                  type="button"
                  class="admin-button admin-button--primary<?= $canVerify ? '' : ' is-disabled'; ?>"
                  data-verify-action="approve"
                  data-request-id="<?= $reqId; ?>"
                  data-username="<?= iN_HelpSecure($username, false); ?>"
                  data-action-label="<?= iN_HelpSecure($approveLabel, false); ?>"
                  <?php
                    $approveDisabled = $isApproved || !$canVerify;
                    $approveTitle = !$canVerify ? $permissionTip : '';
                    echo $approveDisabled ? ' disabled aria-disabled="true"' . ($approveTitle !== '' ? ' title="' . iN_HelpSecure($approveTitle, false) . '"' : '') : '';
                  ?>
                ><?= iN_HelpSecure($approveLabel); ?></button>
                <button
                  type="button"
                  class="admin-button admin-button--danger<?= $canVerify ? '' : ' is-disabled'; ?>"
                  data-verify-action="reject"
                  data-request-id="<?= $reqId; ?>"
                  data-username="<?= iN_HelpSecure($username, false); ?>"
                  data-action-label="<?= iN_HelpSecure($rejectLabel, false); ?>"
                  <?php
                    $rejectDisabled = $isRejected || !$canVerify;
                    $rejectTitle = !$canVerify ? $permissionTip : '';
                    echo $rejectDisabled ? ' disabled aria-disabled="true"' . ($rejectTitle !== '' ? ' title="' . iN_HelpSecure($rejectTitle, false) . '"' : '') : '';
                  ?>
                ><?= iN_HelpSecure($rejectLabel); ?></button>
                <a class="admin-button admin-button--neutral" href="<?= iN_HelpSecure($userDetailUrl, false); ?>"><?= iN_HelpSecure($viewUserLabel); ?></a>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </form>

  <?php if ($totalPages > 1): ?>
    <div class="dz-pagination">
      <div class="page-core">
        <a class="page-btn<?= $pageNo <= 1 ? ' is-disabled' : ''; ?>" href="<?= iN_HelpSecure($buildPageUrl(max(1, $pageNo - 1)), false); ?>" aria-label="Previous">‹</a>
        <ul class="page-list">
          <?php
            $window = 2;
            $start = max(1, $pageNo - $window);
            $end = min($totalPages, $pageNo + $window);
            if ($start > 1) {
                echo '<li><a class="page-link" href="' . iN_HelpSecure($buildPageUrl(1), false) . '">1</a></li>';
                if ($start > 2) {
                    echo '<li class="page-ellipsis">…</li>';
                }
            }
            for ($i = $start; $i <= $end; $i++) {
                $active = $i === $pageNo ? ' is-active' : '';
                echo '<li><a class="page-link' . $active . '" href="' . iN_HelpSecure($buildPageUrl($i), false) . '">' . $i . '</a></li>';
            }
            if ($end < $totalPages) {
                if ($end < $totalPages - 1) {
                    echo '<li class="page-ellipsis">…</li>';
                }
                echo '<li><a class="page-link" href="' . iN_HelpSecure($buildPageUrl($totalPages), false) . '">' . $totalPages . '</a></li>';
            }
          ?>
        </ul>
        <a class="page-btn<?= $pageNo >= $totalPages ? ' is-disabled' : ''; ?>" href="<?= iN_HelpSecure($buildPageUrl(min($totalPages, $pageNo + 1)), false); ?>" aria-label="Next">›</a>
      </div>
    </div>
  <?php endif; ?>
</section>
