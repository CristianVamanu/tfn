<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_bootstrap.php';

global $ADM, $base_url, $iconPath, $currency, $currencies, $RL, $currencyFormatSettings;
$currenciesMap = isset($currencies) && is_array($currencies) ? $currencies : [];
$currencyFormatSettings = $currencyFormatSettings ?? ($GLOBALS['currency_format_settings'] ?? dz_currency_normalize_settings([]));
$formatAmount = static function (?float $value, string $currencyCode) use ($currenciesMap, $currencyFormatSettings): string {
    if ($value === null) {
        return '-';
    }

    $code = strtoupper($currencyCode ?: ($GLOBALS['currency'] ?? 'USD'));
    $symbol = $currenciesMap[$code] ?? null;

    return dz_format_currency((float) $value, $code, $symbol, $currencyFormatSettings);
};

$pageKey       = 'tips_canceled';
$pageTitle     = customLang('admin_tips_canceled');
$defaultStatus = 'canceled';
$iconName      = 'ban.svg';

$q      = isset($_GET['q']) ? (string)trim($_GET['q']) : '';
$status = isset($_GET['status']) ? (string)trim($_GET['status']) : '';
if ($status === '' && $defaultStatus !== '') {
    $status = $defaultStatus;
}
$page   = isset($_GET['page_no']) ? max(1, (int)$_GET['page_no']) : 1;
$per    = isset($_GET['per']) ? max(5, min(100, (int)$_GET['per'])) : 20;
$data   = $ADM->ADM_PagedTips($q, $status, $page, $per);
$rows   = $data['rows'];
$total  = (int)$data['total'];
$pages  = (int)max(1, ceil($total / max(1, $per)));
$statusOptions = [
    ''          => customLang('admin_tips_status_any'),
    'succeeded' => customLang('admin_tips_status_succeeded'),
    'pending'   => customLang('admin_tips_status_pending'),
    'failed'    => customLang('admin_tips_status_failed'),
    'canceled'  => customLang('admin_tips_status_canceled'),
];
?>
<section class="card rounded-2xl" role="region" aria-labelledby="tipsCanceledHeading">
  <div class="list-header" id="tipsCanceledHeading">
    <span class="icon"><?= renderVerifiedBadge($iconPath . $iconName, true); ?></span>
    <span><strong><?= iN_HelpSecure($pageTitle, false); ?></strong></span>
  </div>
  <form method="get" class="form-container form-container--columns" action="<?= iN_HelpSecure($base_url . 'admin/index.php', false); ?>">
    <input type="hidden" name="page" value="<?= iN_HelpSecure($pageKey, false); ?>">
    <div class="form-input-wrapper" data-field="search">
      <label class="form-label" for="tips-canceled-q"><?= iN_HelpSecure(customLang('admin_tips_search_label'), false); ?></label>
      <input
          id="tips-canceled-q"
          class="form-input"
          type="text"
          name="q"
          value="<?= iN_HelpSecure($q, false); ?>"
          placeholder="<?= iN_HelpSecure(customLang('admin_tips_search_placeholder'), false); ?>"
      >
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="tips-canceled-status"><?= iN_HelpSecure(customLang('admin_tips_status_label'), false); ?></label>
      <select id="tips-canceled-status" name="status" class="form-input">
        <?php foreach ($statusOptions as $optValue => $optLabel): ?>
          <option value="<?= iN_HelpSecure($optValue, false); ?>"<?= $status === $optValue ? ' selected' : ''; ?>><?= iN_HelpSecure($optLabel, false); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper">
      <label class="form-label" for="tips-canceled-per"><?= iN_HelpSecure(customLang('admin_tips_per_page'), false); ?></label>
      <select id="tips-canceled-per" name="per" class="form-input">
        <?php foreach ([10,20,50,100] as $pp): ?>
          <option value="<?= $pp; ?>"<?= $pp===$per?' selected':''; ?>><?= $pp; ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-input-wrapper form-actions">
      <label class="form-label sr-only" for="tips-canceled-submit"><?= iN_HelpSecure(customLang('admin_tips_apply'), false); ?></label>
      <button id="tips-canceled-submit" type="submit" class="pe-save btn-hover"><?= iN_HelpSecure(customLang('admin_tips_apply'), false); ?></button>
    </div>
  </form>

  <div class="table-responsive mt-4">
    <table class="table table-striped table-sm table-subs table-tips">
      <thead>
        <tr>
          <th><?= iN_HelpSecure(customLang('admin_tips_col_id'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_tips_col_buyer'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_tips_col_recipient'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_tips_col_date'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_tips_col_post'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_tips_col_status'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_tips_col_amount'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_tips_col_tax'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_tips_col_net'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_tips_col_admin_fee'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_tips_col_ref'), false); ?></th>
          <th><?= iN_HelpSecure(customLang('admin_tips_col_invoice'), false); ?></th>
        </tr>
      </thead>
      <tbody>
      <?php if (empty($rows)): ?>
        <tr>
          <td colspan="12" class="text-center text-muted">
            <?= iN_HelpSecure(customLang('admin_tips_empty_canceled'), false); ?>
          </td>
        </tr>
      <?php else: foreach ($rows as $r):
        $id = (int)($r['id'] ?? 0);
        $bUser = (string)($r['buyer_username'] ?? '');
        $bName = (string)($r['buyer_fullname'] ?? $bUser);
        $bAv   = admin_resolve_media_url((string)($r['buyer_avatar'] ?? 'uploads/user_avatars/default.jpeg'));
        $rUser = (string)($r['recip_username'] ?? '');
        $rName = (string)($r['recip_fullname'] ?? $rUser);
        $rAv   = admin_resolve_media_url((string)($r['recip_avatar'] ?? 'uploads/user_avatars/default.jpeg'));
        $postId= (int)($r['post_id'] ?? 0);
        $created = isset($r['created_at']) && $r['created_at'] > 0 ? date('d/m/Y', (int)$r['created_at']) : '-';

        $amtVal = (float)($r['amount'] ?? 0);
        $netVal = isset($r['net_amount']) && $r['net_amount'] !== null ? (float)$r['net_amount'] : null;
        $taxVal = isset($r['tax_amount']) && $r['tax_amount'] !== null ? (float)$r['tax_amount'] : null;
        $feeVal = isset($r['fee_amount']) && $r['fee_amount'] !== null ? (float)$r['fee_amount'] : null;
        $cur    = (string)($r['currency'] ?? ($currency ?? 'USD'));
        $amount = $formatAmount($amtVal, $cur);
        $taxTxt = $taxVal !== null ? $formatAmount($taxVal, $cur) : '-';
        $netTxt = $netVal !== null ? $formatAmount($netVal, $cur) : '-';
        if ($feeVal === null && $netVal !== null) {
            $feeVal = max(0, $amtVal - $netVal - ($taxVal ?? 0));
        }
        $feeTxt = $feeVal !== null ? $formatAmount($feeVal, $cur) : '-';

        $provider = (string)($r['provider'] ?? '');
        $reference= (string)($r['reference'] ?? '');
        $statusRaw= (string)($r['status'] ?? '');
        $statusMap = [
            'succeeded' => customLang('admin_tips_status_succeeded'),
            'pending'   => customLang('admin_tips_status_pending'),
            'failed'    => customLang('admin_tips_status_failed'),
            'canceled'  => customLang('admin_tips_status_canceled'),
        ];
        $statusTxt = $statusMap[$statusRaw] ?? ucfirst($statusRaw);
        $statusClass = ($statusRaw === 'succeeded') ? 'pill-green' : (($statusRaw === 'pending') ? 'pill-gray' : 'pill-red');

        $bUrl  = ($base_url ?? '/') . 'profile/' . rawurlencode($bUser);
        $rUrl  = ($base_url ?? '/') . 'profile/' . rawurlencode($rUser);
        $postUrl = ($base_url ?? '/') . 'posts/' . $postId . '/' . rawurlencode($rUser);
        $invUrl  = ($base_url ?? '/') . 'admin/index.php?page=invoice_tip&id=' . $id;
        $postData = ($postId > 0 && isset($RL) && method_exists($RL, 'RL_GetPostData')) ? ($RL->RL_GetPostData($postId) ?: []) : [];
        $postVisRaw = strtolower((string)($postData['post_visibility'] ?? ''));
        $postVisSlug = preg_replace('~[^a-z0-9_-]+~', '', $postVisRaw);
        $visIconMap = [
            'everyone'    => 'world.svg',
            'subscribers' => 'subscriber.svg',
            'locked'      => 'locked.svg',
            'followers'   => 'follower.svg',
        ];
        $postVisIcon = $visIconMap[$postVisSlug] ?? 'world.svg';
        $visLabelMap = [
            'everyone'    => customLang('admin_tips_visibility_everyone'),
            'subscribers' => customLang('admin_tips_visibility_subscribers'),
            'locked'      => customLang('admin_tips_visibility_locked'),
            'followers'   => customLang('admin_tips_visibility_followers'),
        ];
        $postVisLabel = $visLabelMap[$postVisSlug] ?? '';
        if ($postId > 0 && $postVisLabel === '') {
            $postVisLabel = customLang('admin_tips_visibility_unknown');
        }
        $postVisClass = $postVisSlug !== '' ? ' vis--' . $postVisSlug : ' vis--everyone';
      ?>
        <tr>
          <td class="tip-id"><?= $id; ?></td>
          <td>
            <?php $buyerAlt = sprintf(customLang('alt_avatar_of_user'), $bName); ?>
            <a class="user-pill" href="<?= iN_HelpSecure($bUrl, false); ?>">
            <img class="avatar-32" src="<?= iN_HelpSecure($bAv, false); ?>" alt="<?= iN_HelpSecure($buyerAlt, false); ?>">
              <span class="name"><?= iN_HelpSecure($bName, false); ?></span>
            </a>
          </td>
          <td>
            <?php $recipientAlt = sprintf(customLang('alt_avatar_of_user'), $rName); ?>
            <a class="user-pill" href="<?= iN_HelpSecure($rUrl, false); ?>">
              <img class="avatar-32" src="<?= iN_HelpSecure($rAv, false); ?>" alt="<?= iN_HelpSecure($recipientAlt, false); ?>">
              <span class="name"><?= iN_HelpSecure($rName, false); ?></span>
            </a>
          </td>
          <td class="text-muted fs-13"><?= iN_HelpSecure($created, false); ?></td>
          <td>
            <?php if ($postId > 0): ?>
              <div class="flex align_items gap-10">
                <span class="vis-tag<?= iN_HelpSecure($postVisClass, false); ?> vis-tag">
                  <span class="tag-icon"><?= renderVerifiedBadge($iconPath . $postVisIcon, true); ?></span>
                  <span class="vis-label"><?= iN_HelpSecure($postVisLabel, false); ?></span>
                  <span class="tag-link"><?= renderVerifiedBadge($iconPath . 'link_out.svg', true); ?></span>
                </span>
              </div>
            <?php else: ?>
              <span class="text-muted"><?= iN_HelpSecure(customLang('ui_deleted'), false); ?></span>
            <?php endif; ?>
          </td>
          <td><span class="pill <?= $statusClass; ?>"><?= iN_HelpSecure($statusTxt, false); ?></span></td>
          <td class="amount-mono"><?= iN_HelpSecure($amount, false); ?></td>
          <td class="amount-mono"><?= iN_HelpSecure($taxTxt, false); ?></td>
          <td class="amount-mono"><?= iN_HelpSecure($netTxt, false); ?></td>
          <td class="amount-mono"><?= iN_HelpSecure($feeTxt, false); ?></td>
          <td>
            <div class="ref-row">
              <span class="amount-mono fw-600 text-muted"><?= iN_HelpSecure($provider !== '' ? $provider : customLang('admin_tips_provider'), false); ?></span>
              <span class="amount-mono">&middot;</span>
              <span class="amount-mono ref-code"><?= iN_HelpSecure($reference, false); ?></span>
            </div>
          </td>
          <td><a class="view-all vivew-invoice" href="<?= iN_HelpSecure($invUrl, false); ?>"><?= iN_HelpSecure(customLang('admin_tips_invoice'), false); ?></a></td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <?php
    echo dz_render_pagination(
      $base_url . 'admin/index.php',
      [
        'page'   => $pageKey,
        'q'      => $q,
        'status' => $status,
        'per'    => (string)$per,
      ],
      (int)$page,
      (int)$pages,
      [ 'show_goto' => true, 'radius' => 1 ]
    );
  ?>
</section>
